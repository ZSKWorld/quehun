/**
* name 
*/
module app{
	export class CookieMgr{
		
		private static _tmpCookie:Object = null;

		private static _init() {
			if (this._tmpCookie !=null )return ;
			this._tmpCookie = {};
			let list:Array<string> = document.cookie.split(';');
			for (let i:number = 0; i < list.length; i++) {
				let str:string = list[i];
				let arr:Array<string> = str.split('=');
				if (arr && arr.length >= 2) {
					let key:string = arr[0];
					while (key.charAt(0) == ' ') key = key.substring(1);
					this._tmpCookie[key] = arr[1];
				}
			}
		}

		public static setCookie(key:string, val:string) {
			this._init();
			let date = new Date();
			document.cookie = key + '=' + val + ';max-age=' + (60*60*24*30).toString();
			this._tmpCookie[key] = val;
		}

		public static getCookie(key):string {
			this._init();
			if (this._tmpCookie.hasOwnProperty(key)) {
				return this._tmpCookie[key];
			} else {
				return '';
			}
		}

	}
}