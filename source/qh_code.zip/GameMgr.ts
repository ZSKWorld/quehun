interface iPlayerBaseView {
    account_id: number;
    avatar_id: number;
    title: number;
    nickname: string;
    level: { id: number, score: number };
    level3: { id: number, score: number };
    avatar_frame: number;
    verified: number;
}

interface iViewSlot {
    solt: number;
    value: number;
}

interface PlayerVerifiedData {
    verified_hidden: number;
    verified_value: number;
}

enum E_Activity_State { none, liandong };

class GameMgr {

    private static _inRes: boolean = true;
    public static get inRelease(): boolean { return this._inRes; };

    public static Inst: GameMgr = null;
    public static config_data: Object = {};
    public static system_email_url: string = '';
    public static dhs_url: string = '';
    public static prefix_url: string = '';
    public static device_id: string = '';
    private static _in_china: boolean = true; //大陆包，可以用微信和支付宝支付
    private static _in_google_play: boolean = false; //是否是google_play_app
    private static _in_dmm: boolean = false; // 是否是dmm
    private static _client_region: string = 'mainland'; //客户端地区版本
    public static client_language: string = 'chs'; //'chs'; 客户端语言版本
    public static client_type: string = 'chs'; // 'chs', 'chs_t', 'en', 'jp', 'kr' 客户端行政版本
    public static country: string = ''; // 玩家ip所在国家

    public static get inConch(): boolean { return Laya.Browser.window.conch; }
    public static get iniOSWebview(): boolean { return Laya.Browser.window.wkbridge; }
    public static get inHttps(): boolean {
        // ==DevDebug Start==
        if (game.LobbyNetMgr.Inst && net.GatewayFetcher.inHttps()) {
            return true;
        }
        // ==DevDebug End==	
        return this.iniOSWebview || Laya.Browser.window.location.protocol == 'https:';
    }
    public static get inChina(): boolean { return this._in_china; }
    public static get inGooglePlay(): boolean { return this._in_google_play; }
    public static get ClientRegion(): string { return this._client_region; }
    public static get inDmm(): boolean { return this._in_dmm; }
    public static get regionLimited(): boolean { return GameMgr.client_type == 'kr'; }
    public static get payChannelId(): number {
        if (this.inDmm) {
            return 403;
        } else if (GameMgr.client_type == 'en') {
            return 302;
        } else if (GameMgr.client_type == 'chs_t') {
            return 204;
        } else if (GameMgr.client_type == 'kr') {
            return 502;
        } else {
            return 402;
        }
    }

    public static get gmoOpen(): boolean { return GameMgr.client_language == 'jp' && !GameMgr.inDmm };
    public static get shelevesId(): string {
        let goods_sheleve_id = '';
        let info = cfg.mall.channel_config.get(GameMgr.payChannelId);
        if (info) {
            goods_sheleve_id = info.shelves_id;
        } else if (GameMgr.inDmm) {
            goods_sheleve_id = 'shelves_005';
        } else if (GameMgr.client_type == 'chs') {
            goods_sheleve_id = 'shelves_001';
        } else if (GameMgr.client_type == 'jp') {
            goods_sheleve_id = 'shelves_002';
        } else if (GameMgr.client_type == 'en') {
            goods_sheleve_id = 'shelves_003';
        } else if (GameMgr.client_type == 'chs_t') {
            goods_sheleve_id = 'shelves_004';
        } else if (GameMgr.client_type == 'kr') {
            goods_sheleve_id = 'shelves_007';
        }
        return goods_sheleve_id;
    }
    public static get inYoStar() {
        const client_type = GameMgr.client_type;
        return client_type == "en" || client_type == "jp" || client_type == "kr";
    }

    public static get fbAppId() {
        // ==DevDebug Start==
        //测试fb appId
        return "836035199428996";
        // ==DevDebug End==
        //线上fb appId
        return "511764882872601";
    }

    public static encodeP(password: string) {
        return CryptoJS.HmacSHA256(password, 'lailai').toString();
    }


    public stage: laya.display.Node = null;

    public uimgr: uiscript.UIMgr = null;

    public root_ui: Laya.Sprite = null;                     //ui根节点
    public root_scene: Laya.Sprite = null;                  //场景根节点
    public root_front_scene_effect: Laya.Sprite = null;      //场景上UI特效的节点
    public root_front_effect: Laya.Sprite = null;            //最顶层特效更节点

    public logined: boolean = false;                 //是否已经登陆
    public link_url: string = '';                    //浏览器地址
    public player_name: string = '';                //玩家昵称
    public account_id: number = -1;                  //账号id
    public account_setting: Object = {};             //玩家账号状态,比如用户协议
    public account_data: Object = null;              //通用account
    public accountVerifiedData: PlayerVerifiedData = { //是否显示玩家认证信息
        verified_hidden: 0,
        verified_value: 0
    };
    public account_numerical_resource: Object = {};//数字类资源，比如各种平台的货币
    public yostar_accessToken: string = '';          //悠星登陆时保存的accessToken
    public yostar_uid: string = '';                  //悠星uid
    public yostar_login_info: LoginRootType.defaultRes = {} as any;           //悠星login协议返回的内容
    public player_in_haiwai: boolean = false;        //玩家是海外用户
    public last_mod_name_time: number;               //上次改名的时间
    // public commonview_slot:Object = {};             //牌桌、立直棒等通用装扮
    public mjp_view: string = '';                    //麻将牌背的外观
    public mjp_surface_view: string = '';                   //麻将牌的外观
    public touming_mjp_view: string = '';
    public specialMJPMView: string = '';
    public mjp_item_id: number = 0;                  //麻将牌物品id
    public mjp_surface_id: number = 0;                 //麻将牌背物品id                  
    public mj_server_location: string = '';          //zone or local
    public mj_game_token: string = '';               //麻将连接token
    public mj_game_uuid: string = '';                //麻将uuid
    public ingame: boolean = false;                  //在麻将中
    public beinvited_roomid: number = -1;            //被邀请的房间id
    public outsee_paipuid: string = '';              //牌谱id
    public custom_match_id: number = 0;              //大会室id
    public in_shilian: boolean = false;              //处于试炼模式
    public in_ab_match: boolean = false;             // 处于ab赛模式
    public in_kuangdu: boolean = false;              // 处于狂赌模式
    public in_saki: boolean = false;               // 处于Saki模式
    public in_huiye: boolean = false;               // 处于幻境模式
    public in_activity: boolean = false;               // 处于大活动中（有loading）
    public in_activity_mode: E_Activity_State = E_Activity_State.none; // 处于什么活动模式, 属于lobby场景, 没有loading的活动
    public last_game_mode_id: number = -1;           // 记录上一场对局的modeId，用于进入lobby判定
    public spot_chara_id: number = 0;                //剧情角色id
    public spot_activity_id: number = 0;             // 剧情uniqueid
    public account_refresh_time: number = 0;         //防沉迷时间？
    private _current_scene: game.SceneBase = null;   //当前场景，lobby|mj|spot
    private _scene_lobby: game.Scene_Lobby = null;   //scene_lobby
    private _scene_mj: game.Scene_MJ = null;         //scene_mj
    private _scene_amulet: game.Scene_Amulet = null;         //scene_amulet
    private _scene_spot: game.Scene_Spot = null;     //scene_spot
    private _scene_kuangdu: game.Scene_Kuangdu = null; // scene_kuangdu
    private _scene_saki: game.Scene_Saki = null; // 
    private _scene_huiye: game.Scene_Huiye = null; // 
    private _scene_activity: game.Scene_Activity = null; // 通用大活动场景
    public duringPaipu: boolean = false;             //正在看牌谱
    private _statisticinfo: Object = {};             //玩家操作统计
    private _last_heatbeat_time: number = 0;         //上一次玩家操作的时间，挂机计时
    private _pre_mouse_point: Laya.Point = new Laya.Point(0, 0); //上次鼠标位置，挂机
    private _fastin: boolean = false;                //快速登录
    public comment_allow: number = 0;                //留言权限设置
    public server_time_delta: number = 0;            //跟服务器时间的差异
    public client_endpoint: { family: string, address: string, port: number } = null; //客户端连接ip
    public _ad_str: string = '';                      // 谷歌广告位的信息，注册的时候要用
    public _mail_account: string = '';               // 悠星登陆的话，有邮箱信息
    public phone_login: number = -1;                 // -1:未赋值，0=无绑定登录方式 1=已绑定登录方式且是本游戏账号 2=已绑定登录方式但不是本游戏账号
    public fb_login_info: Object = null;             // facebook的登陆信息
    public runtime_id: string = '';                  // 运行时id，每次启动随机一次
    public need_test_ws: boolean = false;            // 是否要上报ws信息
    public first_logined: boolean = false;           // 是否是首次进入
    public annual_report_info: game.IResFetchAnnualReportInfo; // 年度报告开启信息
    public free_diamonds: Array<string> = [];
    public paid_diamonds: Array<string> = [];
    public free_pifuquans: Array<string> = [];
    public paid_pifuquans: Array<string> = [];

    public record_uuid: string = '';//牌谱uuid
    public record_start_time: number = -1;
    public record_end_time: number = -1; //牌谱结束时间，收藏使用

    public fetch_count: number = 0;
    public have_send_login_beat: boolean = false;

    public in_emergence: boolean = false;
    public emergence_notice: string = '';
    public last_load_start_time: number = 0;
    public login_loading_end: boolean = false;
    public game_status: Object = {};
    public nickname_replace_enable: boolean = false;
    public nickname_replace_lst: Array<string>;
    public nickname_replace_table: Object;
    private auth_check_id: number = 0;
    private auth_nc_retry_count: number = 0;
    public open_dongtai: boolean = true;

    private anys: string = 'an' + 'ony' + 'mous';
    private save_items: Array<any> = [];

    private logUpCount: number = -1; // <0 不计数
    private logSuccessCount: number = 0;
    private logFailedCount: number = 0;
    private logAutoCount: number = 0; //autorun检测次数 

    private _tracker_post: game.Tracker;
    // private headless: boolean = false;

    public move: boolean = false;

    private mouseMoveCount: number = 0;
    private registMove: boolean;

    // 主播模式相关
    public hide_nickname: boolean = false;
    public hide_other_zone_name: boolean = false;
    public hide_desktop_name: boolean = false;
    public hide_paipu_name: boolean = false;
    public hide_ob_name: boolean = false;
    public hide_match_name: boolean = false;
    public hide_rank_name: boolean = false;

    public crashInfo: { audio_type: string, time?: string };
    // 开关是否使用fetchInfo

    public use_fetch_info: boolean = true;

    public get_hide_name(type: string): boolean {
        if (!this.hide_nickname) return false;
        if (type == 'desktop') {
            return this.hide_desktop_name;
        } else if (type == 'paipu') {
            return this.hide_paipu_name;
        } else if (type == 'ob') {
            return this.hide_ob_name;
        } else if (type == 'match') {
            return this.hide_match_name;
        } else if (type == 'rank') {
            return this.hide_rank_name;
        } else if (type == 'other_zone') {
            return this.hide_other_zone_name;
        }
    }
    constructor() {
        // ==DevDebug Start==
        game.LogCollector.Inst.init();
        // ==DevDebug End==
        if ('serviceWorker' in navigator) {
            let refreshing = false
            navigator['serviceWorker'].addEventListener('controllerchange', () => {
                if (refreshing) {
                    return
                }
                // TODO 进行二次确认？
                refreshing = true;
                // window.location.reload();
            });
            let file = 'sw.js'
            // 可以选择放在version中
            if (document.getElementById('sw_file')) {
                file = document.getElementById('sw_file').innerText;
            }

            // ==DevDebug Start==
            // 如果是本地调试，serviceWorker不注册
            if (location.protocol !== 'file:') {
            // ==DevDebug End==
                navigator['serviceWorker'].register(file).then(() => {
                    if (navigator.serviceWorker && navigator.serviceWorker.controller !== null) {
                        let HEARTBEAT_INTERVAL = 5 * 1000;//每5s发一次心跳
                        let sessionId = game.Tools.generateUUID();
                        let heartbeat = function () {
                            navigator.serviceWorker.controller.postMessage({
                                type: 'heartbeat',
                                id: sessionId,
                                audio_type: window['useWebAudio'] ? 'webAudio' : 'audio',
                                data: {} //附加信息，如果页面crash，上报的附加数据
                            });
                        }
                        let interval_id;
                        var startInterval = function () {
                            if (!interval_id) {
                                clearInterval(interval_id);
                                interval_id = setInterval(heartbeat, HEARTBEAT_INTERVAL);
                                heartbeat();
                            }

                            window.removeEventListener('click', startInterval);
                        }
                        window.addEventListener("beforeunload", function (event) {
                            navigator.serviceWorker.controller.postMessage({
                                type: 'unload',
                                id: sessionId
                            });
                        });
                        window.addEventListener('click', startInterval);
                    }
                });
            // ==DevDebug Start==
            }  
            // ==DevDebug End==
            

        };

        GameMgr.Inst = this;
        //初始化引擎
        if (Laya.Browser.window['conch']) {
            GameMgr._inRes = true;
        } else {
            if (document.getElementById('environment'))
                GameMgr._inRes = document.getElementById('environment').innerText != 'dev';
            else
                GameMgr._inRes = true;
        }

        this.initAliTracker();
        //game配置
        Laya3D.init(1920, 1080, true);
        Laya.stage.scaleMode = Laya.Stage.SCALE_SHOWALL;
        if (Laya.Browser.onMobile) {
            Laya.stage.screenMode = Laya.Stage.SCREEN_HORIZONTAL;
        } else {
            Laya.stage.screenMode = Laya.Stage.SCREEN_NONE;
        }
        Laya.stage.alignH = Laya.Stage.ALIGN_CENTER;
        Laya.stage.alignV = Laya.Stage.ALIGN_MIDDLE;
        Laya.stage.bgColor = "#000000";
        document.body['background'] = 'background.jpg';
        if (!GameMgr._inRes) Laya.Stat.show();
        document.body.style.overflow = "hidden";

        this.save0();
        Laya.loader.load('client_language.txt', Laya.Handler.create(this, () => {
            let language = Laya.loader.getRes('client_language.txt');
            if (language === 'en') {
                GameMgr.client_language = 'en';
            } else if (language === 'jp') {
                GameMgr.client_language = 'jp';
            } else if (language === 'chs_t') {
                GameMgr.client_language = 'chs_t';
            } else if (language == 'kr') {
                GameMgr.client_language = 'kr';
            } else {
                GameMgr.client_language = 'chs_t';
            }
            Laya.loader.clearRes('client_language.txt');
            GameMgr.client_type = GameMgr.client_language;
            //检查url，如果有参数需要重新跳转
            if (this.pendinglink()) {
                Laya.Browser.window.location.href = this.link_url;
                return;
            }
            if (GameMgr.client_type == 'chs') GameMgr.client_type = 'chs_t';
            if (GameMgr.client_type == 'chs_t') {
                let s_language: string = Laya.LocalStorage.getItem('language');
                if (s_language == 'chs' || s_language == 'chs_t') GameMgr.client_language = s_language;
                else {
                    // 如果之前未登陆过，则判定语言决定当前语言版本
                    let ssocio: string = Laya.LocalStorage.getItem('_pre_sociotype');
                    if (ssocio == null) {
                        GameMgr.client_language = navigator.language.toLowerCase() == 'zh-cn' ? 'chs' : 'chs_t';
                    }
                }
            } else if (GameMgr.client_type == 'en') {
                let s_language: string = Laya.LocalStorage.getItem('language');
                if (s_language == 'chs_t' || s_language == 'en' || s_language == 'kr') GameMgr.client_language = s_language;
                else {
                    // 如果之前未登陆过，则判定语言决定当前语言版本
                    let ssocio: string = Laya.LocalStorage.getItem('_pre_sociotype');
                    if (ssocio == null) {
                        let language = navigator.language.toLowerCase();
                        GameMgr.client_language = (language == 'zh-cn' || language == 'zh-tw' || language == 'zh-hk') ? 'chs_t' : (language == 'ko' ? 'kr' : 'en');
                    }
                }
            }

            this.init();
            //加载的开始
            if (GameMgr.iniOSWebview) {
                Laya.timer.once(500, this, () => {
                    this.load0();
                });
            } else {
                this.load0();
            }

        }));

        this.runtime_id = game.Tools.generateUUID();

        this.last_load_start_time = Date.now();
        // this.checkError();
        // try  {
        //     navigator.permissions.query({name:'notifications'}).then(function(permissionStatus) {
        //         if(Notification.permission === 'denied' && permissionStatus.state === 'prompt') {
        //         } else {
        //             this.headless = true;
        //         }
        //     });
        // }
        // catch (ex) {

        // }
        (function (e, w: any, g, a) {
            if (w.Proxy) {
                var sent = false;
                var re = function (prop, mode) {
                    if (sent) return;
                    var o = new e();
                    var stack = o.stack;
                    let lines = stack.split('\n');
                    var errStack = lines.some(function (line) { return line.includes('at <anonymous>') || line.includes('userscript.html'); });
                    var new_stack = '';
                    for (let line of lines) {
                        if (!line.includes('code.js')) new_stack += line + '\n';
                    }

                    if (errStack && g.Inst.logined) {
                        sent = true;
                        var content = {
                            err: errStack,
                            stack: game.Tools.stringTobase64(new_stack),
                            prop: prop,
                            mode: mode
                        };
                        g.Inst.postNewInfo2Server('re_err', content, false);

                        a.NetAgent.sendReq2Lobby('Lobby', 'loginBeat', {
                            contract: window['p2'] + 'z'
                        }, (err, res) => {

                        });
                    }
                }

                w.view = new Proxy(w.view || {}, {
                    get: (target, prop, receiver) => {
                        re(prop, false)
                        return target[prop];
                    },
                    set: (target, prop, value) => {
                        re(prop, false)
                        target[prop] = value;
                        return true;
                    }
                });
                w.uiscript = new Proxy(w.uiscript || {}, {
                    get: (target, prop, receiver) => {
                        re(prop, true)
                        return target[prop];
                    },
                    set: (target, prop, value) => {
                        re(prop, true)
                        target[prop] = value;
                        return true;
                    }
                });
                w.amulet = new Proxy(w.amulet || {}, {
                    get: (target, prop, receiver) => {
                        re(prop, true)
                        return target[prop];
                    },
                    set: (target, prop, value) => {
                        re(prop, true)
                        target[prop] = value;
                        return true;
                    }
                });
            }
        })(Error, window, GameMgr, app);
        Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMove);

        let bp = document.createElement('style');
        bp.innerHTML = 'input::-webkit-outer-spin-button,input::-webkit-inner-spin-button {-webkit-appearance: none;}input[type="number"] {-moz-appearance: textfield;}';
        let s = document.getElementsByTagName("head")[0];
        s.appendChild(bp);


    }

    private onMove() {
        this.move = true;
        Laya.stage.off(Laya.Event.MOUSE_MOVE, this, this.onMove);
    }
    init() {
        let fpsmode: string = Laya.LocalStorage.getItem('fpsmode');
        if (!fpsmode || fpsmode == '') {
            if (!Laya.Browser.onMobile || GameMgr.inConch || GameMgr.iniOSWebview) {
                fpsmode = 'fast';
            } else {
                fpsmode = 'slow';
            }
            Laya.LocalStorage.setItem('fpsmode', fpsmode);
        }
        Laya.stage.frameRate = fpsmode;

        let device_id: string = Laya.LocalStorage.getItem('dddddcv');
        if (!device_id || device_id == '') {
            device_id = game.Tools.generateUUID();
            Laya.LocalStorage.setItem('dddddcv', device_id);
        }
        GameMgr.device_id = device_id;

        Laya.Browser.window.onerror = this.handleWindowError;

        this.root_scene = new Laya.Sprite();
        this.root_ui = new Laya.Sprite();
        this.root_front_effect = new Laya.Sprite();
        Laya.stage.addChild(this.root_scene);
        Laya.stage.addChild(this.root_ui);
        Laya.stage.addChild(this.root_front_effect);
        this.logined = false;
        this._current_scene = null;
        this.duringPaipu = false;
        this._scene_lobby = new game.Scene_Lobby();
        this._scene_mj = new game.Scene_MJ();
        this._scene_amulet = new game.Scene_Amulet();
        this._scene_spot = new game.Scene_Spot();
        this._scene_kuangdu = new game.Scene_Kuangdu();
        this._scene_saki = new game.Scene_Saki();
        this._scene_huiye = new game.Scene_Huiye();
        this._scene_activity = new game.Scene_Activity();
        view.AudioMgr.init();
        let click_prefer: string = Laya.LocalStorage.getItem('click_prefer');
        if (click_prefer && click_prefer == '1') view.DesktopMgr.click_prefer = 1;
        else view.DesktopMgr.click_prefer = 0;
        let double_click_pass: string = Laya.LocalStorage.getItem('double_click_pass');
        if (double_click_pass && double_click_pass == '1') view.DesktopMgr.double_click_pass = 1;
        else view.DesktopMgr.double_click_pass = 0;
        if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
            view.DesktopMgr.en_mjp = true;
            let s_en_mjp: string = game.LocalStorage.getItem('en_mjp');
            if (s_en_mjp == 'false') view.DesktopMgr.en_mjp = false;
        } else {
            view.DesktopMgr.en_mjp = false;
        }
        let open_dongtai: string = game.LocalStorage.getItem('open_dongtai');
        this.open_dongtai = open_dongtai == 'false' ? false : true;

        // 主播模式
        let hide_nickname: string = game.LocalStorage.getItem('hide_nickname');
        this.hide_nickname = hide_nickname == 'true' ? true : false;
        let hide_desktop_name: string = game.LocalStorage.getItem('hide_desktop_name');
        this.hide_desktop_name = hide_desktop_name == 'true' ? true : false;
        let hide_paipu_name: string = game.LocalStorage.getItem('hide_paipu_name');
        this.hide_paipu_name = hide_paipu_name == 'true' ? true : false;
        let hide_ob_name: string = game.LocalStorage.getItem('hide_ob_name');
        this.hide_ob_name = hide_ob_name == 'true' ? true : false;
        let hide_match_name: string = game.LocalStorage.getItem('hide_match_name');
        this.hide_match_name = hide_match_name == 'true' ? true : false;
        let hide_rank_name: string = game.LocalStorage.getItem('hide_rank_name');
        this.hide_rank_name = hide_rank_name == 'true' ? true : false;
        let hide_other_zone_name: string = game.LocalStorage.getItem('hide_other_zone_name');
        this.hide_other_zone_name = hide_other_zone_name == 'true' ? true : false;

        //好友房、查阅牌谱、QQ登陆
        let sroomid = Laya.LocalStorage.getItem('_pre_room');
        if (sroomid && sroomid != '') this.beinvited_roomid = parseInt(sroomid);
        this.outsee_paipuid = Laya.LocalStorage.getItem('_pre_paipu');
        if (!this.outsee_paipuid) this.outsee_paipuid = '';
        this.trasform_storage();

        // if (GameMgr.client_type == 'chs_t' && Math.random() < 0.1) {
        //     this.need_test_ws = true;
        // }


        var canvas = document.getElementById('layaCanvas');
        let time = Laya.timer.currTimer;
        canvas.addEventListener('webglcontextlost', function (e) {
            GameMgr.Inst.postNewInfo2Server('webgl_lose_context', { play_time: Laya.timer.currTimer - time, scene: GameMgr.Inst._current_scene ? GameMgr.Inst._current_scene.constructor.name : '' });
        }, false);

        WebEngine.init();

        if ('serviceWorker' in navigator) {
            if (caches) {
                caches.has('crash_log').then((crash) => {
                    if (crash) {
                        caches.match('/crash_info').then((res) => {
                            if (res && res.text) {
                                res.text().then((a) => {
                                    GameMgr.Inst.crashInfo = { audio_type: 'webAudio', time: a };
                                })
                            } else {
                                GameMgr.Inst.crashInfo = { audio_type: 'webAudio' };
                            }

                            caches.delete('crash_log');
                        })

                    }

                }).catch(() => { });
            }
        }
    }

    // 变化一下保存的信息，方便后面的程序调用，也用于隐藏必要的信息
    private trasform_storage() {
        {
            let st = Laya.LocalStorage.getItem('_pre_st');
            if (st && st != '') {
                this._fastin = true;
                Laya.LocalStorage.setItem('_pre_sociotype', st);
                Laya.LocalStorage.setItem('_pre_st', '');
            }
        }
        {
            let st = Laya.LocalStorage.getItem('_pre_xdsfdl');
            if (st && st != '') {
                this._fastin = true;
                Laya.LocalStorage.setItem('_pre_sociotype', st);
                Laya.LocalStorage.setItem('_pre_xdsfdl', '');
            }
        }
        {
            let state = Laya.LocalStorage.getItem('_pre_state');
            if (state && state != '' && (state == 'xdsfdl3' || state == 'xdsfdl4')) {
                this._fastin = true;
                Laya.LocalStorage.setItem('_pre_sociotype', '3');
                Laya.LocalStorage.setItem('_pre_st', '');
            }
            Laya.LocalStorage.setItem('_pre_state', '');
        }
    }

    //0加载，加载resource version和字体
    load0() {
        // console.log('load0');
        this.setLoadProgress(30);
        let after_region = () => {
            // console.log('after_region');
            game.ResourceVersion.init(Laya.Handler.create(this, () => {
                // console.log('resource version 加载成功');
                this.setLoadProgress(40);
                this.load1();
            }));
        };

        GameMgr._client_region = 'mainland';
        after_region();
        if (GameMgr.client_type == 'chs_t') {
            this.load_fblogin();
            app.Google.init();
        }
    }

    load_fblogin() {
        if (GameMgr.client_type != 'chs_t' || !GameMgr.inRelease) return;
        Laya.Browser.window.fbAsyncInit = function () {
            window['FB'].init({
                appId: GameMgr.fbAppId,
                cookie: true,
                xfbml: true,
                version: 'v7.0'
            });
            window['FB'].AppEvents.logPageView();
        };
        (function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) { return; }
            js = d.createElement(s); js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    }

    //1加载，加载config、协议和shader
    load1() {


        // console.log('load1');
        game.LoadMgr.httpload('config.json', 'json', GameMgr.client_type == 'chs_t', Laya.Handler.create(this, ret => {
            // console.log('load config.json');
            this.setLoadProgress(65);
            if (ret.success) {
                const __config_data = ret.data;
                GameMgr.config_data = __config_data;
                Laya.loader.load("res/proto/liqi.json", new Laya.Handler(this, () => {
                    // console.log('load liqi.json');
                    this.setLoadProgress(80);
                    const liqiDescriptor = Laya.loader.getRes('res/proto/liqi.json');
                    if (!liqiDescriptor) {
                        console.error(`load protobuf failed: liqiDescriptor is null`);
                        return;
                    }
                    net.ProtobufManager.loadProto(liqiDescriptor);
                    net.MessageWrapper.initWrapper();
                    app.NetAgent.init();
                    this.setLoadProgress(85);
                    let ui_path: string = '';
                    ui_path = 'uiconfig/ui_' + GameMgr.client_language + '.json';
                    let promise: Promise<any>;
                    if (GameMgr.client_type == 'en' || GameMgr.client_type == 'jp' || GameMgr.client_type == 'kr') {
                        promise = this.loadUStarLogin();
                    } else
                        promise = Promise.resolve();
                    if (GameMgr.config_data['dmm']) {
                        GameMgr._in_dmm = true;
                        GameMgr._in_china = false;
                    }
                    Laya.loader.clearRes("res/proto/liqi.json");
                    promise.then(() => {
                        Laya.loader.load(ui_path, Laya.Handler.create(this, () => {
                            // console.log('load ui_path');
    
                            let s = Laya.loader.getRes(ui_path);
                            Laya.View['uiMap'] = s;
                            Laya.loader.clearRes(ui_path);
                            this.setLoadProgress(100);
                            this.initUIRoot();
                        }));
                    });
                }));
                this.postNewInfo2Server('game_start', {});
            } else {
                app.Log.Error('未找到配置文件：config.json');
            }
        }));

    }

    // 设置加载进度
    setLoadProgress(rate: number) {
        if (window && window['conch']) {
            window['loadingView'].loading(rate);
        }
        if (GameMgr.iniOSWebview) {
            Laya.Browser.window.wkbridge.callNative('setloadrate', rate.toString(), () => { });
        }
    }
    loadUStarLogin() {
        return game.YoStarSDK.Inst.init();
    }

    // 加载字体
    loadFont(complete: Laya.Handler) {
        let atlas_root = game.LoadMgr.getAtlasRoot();
        let font_atlas_path = atlas_root + 'bitmapfont.atlas';
        if (GameMgr.client_language == 'jp') {
            font_atlas_path = atlas_root + 'bitmapfont/jp.atlas';
        } else if (GameMgr.client_language == 'en') {
            font_atlas_path = atlas_root + 'bitmapfont/en.atlas';
        } else if (GameMgr.client_language == 'chs_t') {
            font_atlas_path = atlas_root + 'bitmapfont/chs_t.atlas';
        } else if (GameMgr.client_language == 'kr') {
            font_atlas_path = atlas_root + 'bitmapfont/kr.atlas';
        }


        Laya.loader.create(font_atlas_path, Laya.Handler.create(this, () => {
            let fonts: Array<string> = [];
            if (GameMgr.client_language == 'jp') {
                fonts = [
                    'jp_haolong',
                    'jp_jiye'];
            } else if (GameMgr.client_language == 'en') {
                fonts = [
                    'en_haolong',
                    'en_hanyi',
                    'en_shuhun'];
            } else if (GameMgr.client_language == 'chs_t') {
                fonts = [
                    'chst_fengyu',
                    'chst_haolong',
                    'chst_youyuan',
                    'chst_hyyk'];
            } else if (GameMgr.client_language == 'kr') {
                fonts = [
                    'kr_solmoe'
                ];
            } else {
                fonts = [
                    'fengyu',
                    'hanyi',
                    'haolong',
                    'youyuan',
                    'youyuan_bold',
                    'hyyk'];
            }
            let count: number = 0;
            let onloaded = () => {
                count++;
                this.setLoadProgress(Math.floor(40 + 20 * (count / fonts.length)));
                if (count == fonts.length) {
                    let normal_fonts: string[] = [];
                    if (GameMgr.client_language == 'chs') normal_fonts.push('fonts/HYWH.ttf');
                    if (GameMgr.client_language == 'chs_t') normal_fonts.push('fonts/FZHT.ttf');
                    let u: string = Laya.Browser.userAgent;
                    if (u.indexOf('LayaAirIDE') == -1) {
                        if (GameMgr.client_language == 'kr') {
                            normal_fonts.push('fonts/kr_solmoe_1.ttf');
                            normal_fonts.push('fonts/NotoSansKR.ttf');
                        }
                    }
                    if (normal_fonts.length > 0) {
                        Laya.loader.load(normal_fonts, Laya.Handler.create(this, () => {
                            Laya.timer.frameOnce(2, this, () => {
                                complete.run();
                            });
                        }));
                    } else {
                        Laya.timer.frameOnce(2, this, () => {
                            complete.run();
                        });
                    }

                }
            };

            if (GameMgr.client_language == 'chs') {
                for (let i: number = 0; i < fonts.length; i++) {
                    let bitmapFont: Laya.BitmapFont = new Laya.BitmapFont();
                    bitmapFont.loadFont('bitmapfont/' + fonts[i] + '.fnt', Laya.Handler.create(this, () => {
                        bitmapFont.setSpaceWidth(10);
                        Laya.Text.registerBitmapFont(fonts[i], bitmapFont);
                        onloaded();
                    }));
                }
            } else {
                for (let i: number = 0; i < fonts.length; i++) {
                    let bitmapFont: Laya.BitmapFont = new Laya.BitmapFont();
                    bitmapFont.loadFont('bitmapfont/' + GameMgr.client_language + '/' + fonts[i] + '.fnt', Laya.Handler.create(this, () => {
                        bitmapFont.setSpaceWidth(10);
                        Laya.Text.registerBitmapFont(fonts[i], bitmapFont);
                        onloaded();
                    }));
                }
            }
        }));
    }

    //加载excel表
    loadExcel(complete: Laya.Handler) {
        Laya.loader.load("res/proto/config.proto", new Laya.Handler(this, () => {
            if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(1);
            let bin_path: string = 'res/config/lqc.lqbin';
            // let bin_path:string = 'http://58.87.125.18:9808/mj-clst-0910/data.bin';
            Laya.loader.load(bin_path, new Laya.Handler(this, () => {
                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(2);
                const configProto = Laya.loader.getRes('res/proto/config.proto');
                if (!configProto) {
                    console.error(`load configProto failed: configProto is null`);
                    return;
                }
                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(3);
                const bincontent: ArrayBuffer = Laya.loader.getRes(bin_path);
                if (!bincontent) {
                    console.error(`load bincontent failed: bindata is null`);
                    return;
                }
                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(4);
                var bytes = new Laya.Byte();
                bytes.writeArrayBuffer(bincontent);

                const parser = new bin.BinParser();
                parser.parseSync(configProto, bytes.getUint8Array(0, bytes.length));
                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(5);
                const format = new bin.TSDataFormat(parser.exportSchema(), parser.exportData());
                cfg.load(format.toFormat());
                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(6);
                if (complete) complete.run();
                // 初始化货币相关
                {
                    this.free_diamonds = [];
                    this.paid_diamonds = [];
                    this.free_pifuquans = [];
                    this.paid_pifuquans = [];
                    let info = cfg.mall.channel_config.get(GameMgr.payChannelId);
                    if (info) {
                        if (info.free_jade_ids) {
                            this.free_diamonds = info.free_jade_ids.split('-');
                        }
                        if (info.free_voucher_ids) {
                            this.free_pifuquans = info.free_voucher_ids.split('-');
                        }
                        if (info.paid_jade_ids) {
                            this.paid_diamonds = info.paid_jade_ids.split('-');
                        }
                        if (info.paid_voucher_ids) {
                            this.paid_pifuquans = info.paid_voucher_ids.split('-');
                        }
                    }
                }
                // 初始化屏蔽词库
                {
                    let words: Array<{ s: string, type: number, near: number }> = [];
                    let region: string = 'chs';
                    switch (GameMgr.client_language) {
                        case 'chs': region = 'chs'; break;
                        case 'en': region = 'us'; break;
                        case 'jp': region = 'jp'; break;
                        case 'chs_t': region = 'chs'; break;
                        case 'kr': region = 'us'; break;
                    }
                    cfg.info.forbidden.forEach(x => {
                        if (x.word == '') return;
                        if (region && x[region]) return;
                        words.push({
                            s: x.word,
                            type: x['type_' + region],
                            near: x['near_' + region]
                        });
                    });
                    let near_char: Array<Array<string>> = [];
                    cfg.info.near.forEach(x => {
                        let lst: Array<string> = [];
                        for (let i: number = 1; i <= 5; i++) {
                            let c: string = x['word' + i];
                            if (c && c != '') lst.push(c);
                        }
                        near_char.push(lst);
                    });
                    app.Taboo.init(words, near_char);
                }
                // 初始化en的繁体
                {
                    if (game.Tools.isEnChst()) {
                        cfg.item_definition.item.forEach((data) => {
                            // 去掉readonly报错
                            let value: any = data;
                            if (value.name_chs_t2) {
                                value['name_chs_t'] = data.name_chs_t2;
                                value['icon'] = data['icon'].replace('.jpg', '_2.jpg');
                            }
                            if (value.desc_chs_t2) {
                                value['desc_chs_t'] = data.desc_chs_t2
                            }

                            // if (data.desc_func_chs_t2) {
                            //     data['desc_func_chs_t'] = data.desc_func_chs_t2;
                            // }
                        })
                    }

                }
                { 
                    // 重置voice.sound
                    cfg.item_definition.character.forEach((data) => { 
                        var group = cfg.voice.sound.getGroup(data.sound);
                        if (group) { 
                            group.forEach((soundData) => { 
                                let value: any = soundData;
                                value['path'] = 'audio/sound/' + data.sound_folder + '/' + soundData.path.replace('lobby/', '');
                            })
                        }
                    })
                }
                // 重新进行item的character和item排序
                // {
                //     cfg.item_definition.item.rows_.sort((a, b) => { return a['sort'] - b['sort']; });
                //     cfg.item_definition.character.rows_.sort((a, b) => { return a['sort'] - b['sort']; })
                // }
                this.clearCfgData();

                Laya.loader.clearRes('res/proto/config.proto');
                Laya.loader.clearRes(bin_path);
            }), null, Laya.Loader.BUFFER);
        }));

        // window.onbeforeunload = function (e){
        //     console.log(e);
        // }
    }

    clearCfgData() {
        //加入这个列表内的表不会被加载，如果需要对应的表，请在下面的列表内移除并在下面注释内添加对应的名字，方便加回
        //'exchange', 'activity_room', 'flip_task', 'flip_info','mine_activity', 'mine_reward','richman_info', 'richman_event', 'richman_map', 'richman_level',
        let clearExcelInfos: Array<{ excel: string, sheets?: Array<string> }> = [{ excel: 'ab_match' }, {
            excel: 'activity', sheets: [
                'feed_activity_info', 'feed_activity_reward',
                'game_point_rank', 'condition_reward', 'rank', 'rank_reward', 'segment_task',
                'rpg_v2_activity', 'rpg_activity', 'rpg_monster_group', 'arena_reward', 'arena_reward_display', 'gacha_control',
                'random_task_info', 'activity_item', 'game_point', 'game_point_filter']
        },
        { excel: 'chest', sheets: ['item_price', 'item_pool', 'pool', 'up', 'replace_pool', 'pool_seq', 'segment_task', 'exchange'] }, { excel: 'compose' },
        { excel: 'contest' }, { excel: 'desktop', sheets: ['field_spell'] }, { excel: 'item_definition', sheets: ['item_recovery'] }, //'item_package', 
        { excel: 'leaderboard' }, { excel: 'mail' }, { excel: 'mall', sheets: ['zone_params'] }, { excel: 'match_shilian' }, { excel: 'misc_function' },
        { excel: 'season', sheets: ['season_reward', 'level_ticket_pool', 'level_ticket', 'ticket_retry'] },
        { excel: 'info', sheets: ['near', 'forbidden'] },
        { excel: 'quest_crew' },
        { excel: 'simulation' },
        { excel: 'snowball' },
        { excel: 'marathon' }
        ];
        for (let info of clearExcelInfos) {
            if (!info.sheets) {
                delete cfg[info.excel];
            } else {
                for (let sheet of info.sheets) {
                    delete cfg[info.excel][sheet];
                }
            }
        }
        // 删除本地化信息
        let clearLocalExcel: Array<{ excel: string, sheets: Array<string>, keys: Array<string> }> = [{ excel: 'str', sheets: ['str', 'event'], keys: [''] },
        { excel: 'item_definition', sheets: ['item'], keys: ['name_{0}', 'desc_{0}', 'desc_func_{0}'] },
        { excel: 'item_definition', sheets: ['character'], keys: ['desc_stature_{0}', 'desc_birth_{0}', 'desc_age_{0}', 'desc_bloodtype_{0}', 'desc_hobby_{0}', 'desc_{0}'] },
        { excel: 'item_definition', sheets: ['skin'], keys: ['name_{0}', 'desc_{0}', 'lock_tips_{0}'] }];
        let languageList = ['chs', 'chs_t', 'en', 'jp', 'kr'];
        for (let i = 0; i < languageList.length; i++) {
            if (languageList[i] == GameMgr.client_language) {
                languageList.splice(i, 1);
                break;
            }
        }
        for (let info of clearLocalExcel) {

            for (let sheet of info.sheets) {
                let dataMap = cfg[info.excel][sheet] as lqc.UniqueSheet<Object>;
                let keyList: Array<string> = [];
                for (let key of info.keys) {
                    languageList.forEach((value) => {
                        if (key) {
                            keyList.push(key.replace('{0}', value));
                        } else {
                            keyList.push(value);
                        }
                    })

                }
                dataMap.forEach(element => {
                    keyList.forEach(value => {
                        delete element[value]
                    })
                });
            }

        }
    }
    pendinglink(): boolean {
        let link: string = '';
        if (document.getElementById('game_link'))
            link = document.getElementById('game_link').innerText;

        if (link) this.link_url = game.Tools.getFinalUrl(link);

        let href: string = Laya.Browser.window.location.href;
        let infos: Object = {};
        let need_restart: boolean = false;
        if (href) {
            if (Laya.LocalStorage.getItem('fblogin') == "1") { // 跳过fb登录

            } else if (Laya.LocalStorage.getItem('sgooglelogin') == "1") { // 跳过google登录

            } else if (href.indexOf('#') > 0) {
                href = href.substr(0, href.indexOf('#'));
            }
            let index: number = href.indexOf("?");
            if (index >= 0) {
                need_restart = true;
                if (!link) {
                    this.link_url = href.substr(0, index);
                }
                let str: string = href.substring(index + 1, href.length); //取得所有参数   stringvar.substr(start [, length ]
                str = str.replace('#_=_', '');
                str = str.replace('#', '');
                var arr: Array<string> = str.split("&"); //各个参数放到数组里
                for (let i: number = 0; i < arr.length; i++) {
                    index = arr[i].indexOf("=");
                    if (index > 0) {
                        let _name: string = arr[i].substring(0, index);
                        let _val: string = arr[i].substring(index + 1, arr[i].length);
                        infos[_name] = _val;
                    }
                }
            } else if ((Laya.LocalStorage.getItem('fblogin') == "1" && href.indexOf("#") != -1)
                || Laya.LocalStorage.getItem('sgooglelogin') == "1" && href.indexOf("#") != -1) {
                need_restart = true;
                index = href.indexOf("#");
                if (!link) {
                    this.link_url = href.substr(0, index);
                }
                let str: string = href.substring(index, href.length); //取得所有参数   stringvar.substr(start [, length ]
                str = str.replace('#_=_', '');
                str = str.replace('#', '');
                var arr: Array<string> = str.split("&"); //各个参数放到数组里
                for (let i: number = 0; i < arr.length; i++) {
                    index = arr[i].indexOf("=");
                    if (index > 0) {
                        let _name: string = arr[i].substring(0, index);
                        let _val: string = arr[i].substring(index + 1, arr[i].length);
                        infos[_name] = _val;
                    }
                }
            } else {
                this.beinvited_roomid = -1;
                this.outsee_paipuid = '';
            }
            if (!link) {
                if (this.link_url.indexOf('index.html') >= 0) this.link_url = this.link_url.substr(0, this.link_url.indexOf('index.html'));
                if (this.link_url.charAt(this.link_url.length - 1) != '/') this.link_url += '/';
            }
        }
        let ad_str: string = '';
        for (var k in infos) {
            if (k.substr(0, 3) == 'mv_') {
                // switch(k) {
                //     case 'mv_sociotype': Laya.LocalStorage.setItem('_pre_sociotype', game.Tools.decode_str(infos[k]));
                //     case 'mv_ssoodd': Laya.LocalStorage.setItem('ssssoooodd', game.Tools.decode_str(infos[k]));
                //     case 'mv_at': Laya.LocalStorage.setItem('account', game.Tools.decode_str(infos[k]));
                //     case 'mv_pd': Laya.LocalStorage.setItem('password', game.Tools.decode_str(infos[k]));
                // }
            } else if (k.substr(0, 4) == 'utm_') {
                if (ad_str != '') ad_str += '&';
                ad_str += k + '=' + infos[k];
            } else if (k == 'h') {
                Laya.LocalStorage.setItem('_pre_sociotype', '14');
                Laya.LocalStorage.setItem('_pre_code', infos[k]);
            } else {
                Laya.LocalStorage.setItem('_pre_' + k, infos[k]);
            }
        }
        if (ad_str) {
            Laya.LocalStorage.setItem('__ad_s', ad_str);
            Laya.LocalStorage.setItem('__ad_t', Date.now().toString());
        }
        return need_restart;
    }

    public addScene(scene: Laya.Sprite): void {
        this.root_scene.addChild(scene);
    }

    public addUI(ui: Laya.Node): void {
        this.root_ui.addChild(ui);
    }

    public initUIRoot(): void {
        // console.log('initUIRoot');
        this.uimgr = new uiscript.UIMgr();
        this.uimgr.init();
        this.showEntrance();
    }

    public showEntrance() {
        // uiscript.UI_ChooseLanguage.show(Laya.Handler.create(this, ()=>{
        // 检查是否有FB登陆
        if (GameMgr.client_type == 'chs_t' && GameMgr.inRelease) {
            let s_fb: string = Laya.LocalStorage.getItem('fblogin');
            if (s_fb == '1' && !Laya.LocalStorage.getItem('_pre_access_token')) {
                if (window['FB'] != null && window['FB'] != undefined) {
                    window['FB'].getLoginStatus(function (response) {
                        GameMgr.Inst.fb_login_info = response;
                    });
                    Laya.LocalStorage.setItem('fblogin', '0');
                }
            }
        }
        this.showChooseServer();
        // }));
    }

    public showChooseServer() {
        uiscript.UI_ChooseServer.show(Laya.Handler.create(this, () => {
            if (this._fastin) {
                //跳过抬头流程
                this.showKrTip(true, Laya.Handler.create(this, () => {
                    this.loadFont(Laya.Handler.create(this, () => {
                        this.loadShader(Laya.Handler.create(this, () => {
                            this.loadExcel(Laya.Handler.create(this, () => {
                                if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(7);
                                game.LoadMgr.loadRes(game.E_LoadType.entrance, Laya.Handler.create(this, () => {
                                    this.uimgr.showEntrance();
                                    this._scene_lobby.init(null);
                                }));
                            }));
                        }));
                    }));
                }));
            } else {
                this.showKrTip(true, Laya.Handler.create(this, () => {
                    //普通登录流程
                    let start_show_atlas: string = 'res/atlas' + (GameMgr.client_language == 'chs' ? '' : ('/' + GameMgr.client_language)) + '/myres/start_show.atlas';
                    Laya.loader.create(start_show_atlas, Laya.Handler.create(this, () => {
                        this.uimgr.showRemind();
                        let showremindtime: number = Laya.timer.currTimer;
                        this.loadFont(Laya.Handler.create(this, () => {
                            this.loadShader(Laya.Handler.create(this, () => {
                                this.loadExcel(Laya.Handler.create(this, () => {
                                    if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(7);
                                    if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(8);
                                    game.LoadMgr.loadRes(game.E_LoadType.entrance, Laya.Handler.create(this, () => {
                                        let __time: number = showremindtime + 3000 - Laya.timer.currTimer;
                                        if (__time <= 60) __time = 60;
                                        Laya.timer.once(__time, this, () => {
                                            if (uiscript.UI_Remind.Inst) uiscript.UI_Remind.Inst.setprocess(9);
                                            this.uimgr.showEntrance();
                                            this._scene_lobby.init(null);
                                        });
                                    }));
                                }));
                            }));

                        }))

                    }));
                }));

            }
        }));
    }

    private showKrTip(show_text: boolean, complete: Laya.Handler = null) {
        if (GameMgr.client_type != 'kr') {
            if (complete) complete.run();
            return;
        }
        let start_show_atlas: string = game.LoadMgr.getAtlasRoot() + 'kr/myres/start_info.atlas';
        Laya.loader.create(start_show_atlas, Laya.Handler.create(this, () => {
            uiscript.UIMgr.Inst.showKrTip(show_text);
            Laya.timer.once(3300, this, () => {
                uiscript.UIMgr.Inst.closeKrTip(complete);
            });
        }));
    }
    private loadShader(complete: Laya.Handler) {
        (new caps.ShaderInitor()).init(complete);
    }
    //同步登录信息
    public fetch_login_info() {

        this.fetch_count = 0;
        // 有全量数据需要优先拉取再触发后续
        let fetchHandler = new Laya.Handler(this, (add) => {
            if (add) {
                this.fetch_count++;
            } else {
                this.onFetchFinished();
            }

        });
        game.FriendMgr.init();
        uiscript.UI_Mail.Init();
        uiscript.UI_Activity_Xuanshang.Init();
        uiscript.UI_Activity_Jiuji.Init();
        uiscript.UI_TitleBook.Init();
        uiscript.UI_Bag.init();
        uiscript.UI_Shop.init();
        uiscript.UI_Activity.init();
        uiscript.UI_Recharge.init();
        if (!this.use_fetch_info) {
            uiscript.UI_Activity_Yueka.Init();
        }

        uiscript.UI_Nianshou_Main.Init();
        // uiscript.UI_Rpg.init();
        // uiscript.UI_Shilian.init();
        // uiscript.UI_AB_Match.init();
        uiscript.UI_Achievement.init(fetchHandler);
        // uiscript.UI_Chunjie.fetchSelfRank();
        // uiscript.UI_Treasure.init();
        uiscript.QuestionairData.fetchList();

        //存储在服务器的通用设置
        if (!this.use_fetch_info) {
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchCommentSetting', {}, (err, res) => {
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError('fetchCommentSetting', err, res);
                } else {
                    this.comment_allow = res['comment_allow'];
                }
            });


            app.NetAgent.sendReq2Lobby('Lobby', 'fetchAccountSettings', {}, (err, res) => {
                if (err || res['error']) {

                } else {
                    this.account_setting = [];
                    if (res['settings']) {
                        for (let i: number = 0; i < res['settings'].length; i++) {
                            this.account_setting[res['settings'][i]['key']] = res['settings'][i]['value'];
                        }
                    }
                }
            });

            this.last_mod_name_time = 0;
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchModNicknameTime', {}, (err, res) => {
                if (err || res['error']) {

                } else {
                    if (res['last_mod_time']) {
                        this.last_mod_name_time = res['last_mod_time'];
                    }
                }
            });

            //获取首充等数据
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchMisc', {}, (err, res: game.IResMisc) => {
                if (err || res['error']) {
                    //首冲获取失败，要么就全部都显示成非首冲
                    cfg.mall.goods.forEach(value => {
                        uiscript.UI_Recharge.new_recharge_list[value.cny] = 1;
                    });
                } else {
                    if (res['recharged_list']) {
                        for (let i: number = 0; i < res['recharged_list'].length; i++) {
                            uiscript.UI_Recharge.new_recharge_list[res['recharged_list'][i]] = 1;
                        }
                    }
                    if (res['faiths']) {
                        uiscript.UI_Treasure.on_chest_count_change(res['faiths']);
                    }
                    // uiscript.UI_Config.onFetchSuccess({ disable_room_random_bot_char: res.disable_room_random_bot_char });
                    uiscript.UI_Config_New.onFetchSuccess({ disable_room_random_bot_char: res.disable_room_random_bot_char });
                }
            });
            this.afterFetchInfo();
        }

        this.player_in_haiwai = false;
    }

    public onFetchFinished() {
        if (this.fetch_count > 0) {
            this.fetch_count--;
            if (this.fetch_count == 0) {
                this.afterFetchInfo()
            }
        }
    }

    public afterFetchInfo() {
        app.NetAgent.sendReq2Lobby('Lobby', 'loginSuccess', {}, (err, res) => {
            if (err || res['error']) {
                uiscript.UIMgr.Inst.showNetReqError('loginSuccess', err, res);
            } else {
                uiscript.UI_RollNotice.init();
                uiscript.UI_Maintain_Notice.init();
                if (uiscript.UI_Match_Lobby.Inst) {
                    uiscript.UI_Match_Lobby.Inst.init();
                }
                game.MaintainMgr.init();
                game.MakaManager.Inst.init();
            }
        });
    }
    //弃用完全无人维护的维护模式
    // public initEmergency(complete: Laya.Handler) {
    //     if (!GameMgr.inRelease) {
    //         complete.run();
    //         return;
    //     }
    //     if (!GameMgr.config_data['emergency_url']) {
    //         complete.run();
    //         return;
    //     }
    //     let file_url = GameMgr.config_data['emergency_url'] + 'emergency_config.json';

    //     var xhr = new Laya.HttpRequest();
    //     xhr.once(Laya.Event.COMPLETE, this, (data: any) => {
    //         let _config = JSON.parse(data);
    //         this.in_emergence = _config.in_emergence;
    //         this.emergence_notice = _config.context;
    //         complete.run();
    //     });
    //     xhr.once(Laya.Event.ERROR, this, (e: Object) => {
    //         complete.run();
    //     });
    //     let heads: Array<string> = [];
    //     xhr.send(file_url, "", "get", 'text/html');
    // }

    //游戏初始化，绑定监听事件
    public gameInit() {
        window['p2'] = 'DF2vkXCnfeXp4WoGSBGNcJBufZiMN3UP' + (window['pertinent3'] ? window['pertinent3'] : '');
        this.sendLoginBeat(); // 2024/10/29 提前发送loginbeat
        view.BgmListMgr.init();
        if (!this.use_fetch_info) {
            //同步服务器时间
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchServerTime', {}, (err, res) => {
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError('fetchServerTime', err, res);
                } else {
                    this.server_time_delta = res['server_time'] * 1000 - Laya.timer.currTimer;
                }
            });
            //获取服务器设置
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchServerSettings', {}, (err, res) => {
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError('fetchServerSettings', err, res);
                } else {
                    app.Log.log('fetchServerSettings: ' + JSON.stringify(res));
                    this.updateServerSettings(res['settings']);

                }
            });
        }

        //获取本地连接ip
        app.NetAgent.sendReq2Lobby('Lobby', 'fetchConnectionInfo', {}, (err, res) => {
            if (err || res['error']) {

            } else {
                this.client_endpoint = res.client_endpoint;
            }
        });
        // app.NetAgent.sendReq2Lobby('Lobby', 'fetchPhoneLoginBind', {}, (err, res)=>{
        //     if (err || res['error']) {

        //     } else {
        //         this.phone_login = res['phone_login'];
        //     }
        // });

        app.PlayerBehaviorStatistic.init();

        if (this.account_data['nickname']) {
            this.fetch_login_info();
        }
        uiscript.UI_Info.Init();

        app.NetAgent.addListener2Lobby('NotifyAccountUpdate', Laya.Handler.create(this, (msg: game.INotifyAccountUpdate) => {
            app.Log.log('NotifyAccountUpdate :' + JSON.stringify(msg));
            let __data = msg.update;
            if (__data) {
                if (__data['numerical']) {
                    for (let i: number = 0; i < __data['numerical'].length; i++) {
                        let __id: number = __data['numerical'][i]['id'];
                        let __count: number = __data['numerical'][i]['final'];
                        switch (__id) {
                            case 100001: this.account_data['diamond'] = __count; break;
                            case 100002: this.account_data['gold'] = __count; break;
                            case 100099: {
                                this.account_data['vip'] = __count;
                                if (uiscript.UI_Recharge.Inst && uiscript.UI_Recharge.Inst.enable) {
                                    uiscript.UI_Recharge.Inst.refreshVipRedpoint();
                                }
                                break;
                            }
                        }
                        if (__id >= 101001 || __id <= 102999) {
                            //平台渠道辉玉
                            this.account_numerical_resource[__id] = __count;
                        }
                    }
                }
                //解锁了新角色
                uiscript.UI_Sushe.on_data_updata(__data);

                if (__data['daily_task']) {
                    uiscript.UI_Activity_Xuanshang.dataUpdate(__data['daily_task']);
                }
                if (__data['title']) {
                    uiscript.UI_TitleBook.title_update(__data['title']);
                }
                if (__data['new_recharged_list']) {
                    uiscript.UI_Recharge.on_new_recharge_refresh(__data);
                }
                if (__data['activity_task'] || __data['activity_period_task'] || __data['activity_random_task'] || __data['activity_segment_task']) {
                    uiscript.UI_Activity.accountUpdate(__data);
                }
                if (__data['activity_flip_task']) {
                    uiscript.UI_Activity_Fanpai.onTaskDataUpdate(__data['activity_flip_task']['progresses']);
                }
                if (__data['activity']) {
                    if (__data['activity']['friend_gift_data']) {
                        uiscript.UI_Activity_Miaohui.updateFriendGiftData(__data['activity']['friend_gift_data']);
                    }
                    if (__data['activity']['upgrade_data']) {
                        uiscript.UI_Activity_Miaohui.updateUpgradeData(__data['activity']['upgrade_data']);
                    }
                    if (__data['activity']['gacha_data']) {
                        uiscript.UI_Activity_Niudan.update_data(__data['activity']['gacha_data']);
                    }

                    if (__data['activity']['simulation_data']) {
                        // uiscript.UI_Activity_Simulation_Old.update_data(__data['activity']['simulation_data']);
                    }

                    if (__data['activity']['spot_data']) {
                        uiscript.UI_Activity_Spot.update_data(__data['activity']['spot_data']);
                        game.ActivitySpotDataHelper.updateData(__data['activity']['spot_data']);
                    }
                    if (__data['activity']['story_data']) {
                        game.ActivityStoryDataHelper.updateData(__data['activity']['story_data']);
                    }
                    if (__data['activity']['combining_data']) {
                        uiscript.UI_Activity_Combining.update_data(__data['activity']['combining_data']);
                    }
                    if (__data['activity']['village_data']) {
                        uiscript.UI_Activity_Chunjie.update_data(__data['activity']['village_data']);
                    }
                    if (__data['activity']['choose_up_data']) {
                        uiscript.UI_Treasure.updateChooseData(__data['activity']['choose_up_data']);
                    }
                    if (__data['activity']['choose_group_up_data']) {
                        uiscript.UI_Treasure.updateChooseGroupData(__data['activity']['choose_group_up_data']);
                    }
                    if (__data['activity']['festival_data']) {
                        uiscript.UI_Activity_24ba.updateData(__data['activity']['festival_data']);
                    }

                    if (__data['activity']['island_data']) {
                        uiscript.UI_Activity_Haidao.updateData(__data['activity']['island_data']);
                    }
                    if (__data['activity']['shoot_data']) {
                        uiscript.UI_Activity_Shoot.onFetchSuccess(__data['activity']['shoot_data']);
                    }

                    if (__data.activity.bingo_data) {
                        uiscript.UI_Activity_Bingo.onFetchSuccess(__data.activity.bingo_data);
                    }
                    if (__data.activity.activity_buff && __data.activity.activity_buff.dirty) {
                        //更新活动buff数据
                        uiscript.UI_Activity.updateBuffData(__data.activity.activity_buff.value);

                    }

                }
                if (__data['month_ticket']) {
                    uiscript.UI_Activity_Yueka.updateData(__data['month_ticket']);
                    Laya.stage.event(EventCode.MONTH_TICKET_CHANGE);
                }
               
            }
        }, null, false));
        app.NetAgent.addListener2Lobby('NotifyAnotherLogin', Laya.Handler.create(this, msg => {
            uiscript.UI_AnotherLogin.Inst.show();
        }));
        app.NetAgent.addListener2Lobby('NotifyAccountLogout', Laya.Handler.create(this, msg => {
            uiscript.UI_Hanguplogout.Inst.show();
        }));
        app.NetAgent.addListener2Lobby('NotifyClientMessage', Laya.Handler.create(this, msg => {
            app.Log.log('收到消息：' + JSON.stringify(msg));
            if (msg.type == game.EFriendMsgType.room_invite) {
                uiscript.UI_Invite.onNewInvite(msg.content);
            }
        }));
        app.NetAgent.addListener2Lobby('NotifyServerSetting', Laya.Handler.create(this, msg => {
            uiscript.UI_Recharge.open_payment = false;
            uiscript.UI_Recharge.payment_info = '';
            uiscript.UI_Recharge.open_wx = true;
            uiscript.UI_Recharge.wx_type = 0;
            uiscript.UI_Recharge.open_alipay = true;
            uiscript.UI_Recharge.alipay_type = 0;
            if (msg['settings']) {
                uiscript.UI_Recharge.update_payment_setting(msg['settings']);
                if (msg['settings']['nickname_setting']) {
                    this.nickname_replace_enable = !!msg['settings']['nickname_setting']['enable'];
                    this.nickname_replace_lst = msg['settings']['nickname_setting']['nicknames'];
                }
            }
            uiscript.UI_Change_Nickname.allow_modify_nickname = msg['allow_modify_nickname'];
            // console.log('NotifyServerSetting:' + JSON.stringify(msg));
        }));
        app.NetAgent.addListener2Lobby('NotifyVipLevelChange', Laya.Handler.create(this, msg => {
            uiscript.UI_Sushe.send_gift_limit = msg['gift_limit'];
            game.FriendMgr.friend_max_count = msg['friend_max_count'];
            uiscript.UI_Shop.shopinfo['zhp']['free_refresh']['limit'] = msg['zhp_free_refresh_limit'];
            uiscript.UI_Shop.shopinfo['zhp']['cost_refresh']['limit'] = msg['zhp_cost_refresh_limit'];
            uiscript.UI_PaiPu.collect_limit = msg['record_collect_limit'];
        }));

        app.NetAgent.addListener2Lobby('NotifyAFKResult', new Laya.Handler(this, msg => {
            game.Tools.showGuaJiChengFa(msg);
        }));

        //每6分钟心跳一次，挂机超过1个小时会掉线
        Laya.timer.loop(6 * 60 * 1000, this, () => {
            if (game.LobbyNetMgr.Inst.isOK) {
                if (game.Tools.CheckReconnectInfoNeedSend()) { 
                    if (GameMgr.client_type == 'kr') { 
                        var delay = net.NetRouteGroup.Inst?.getDelay();
                        var content = { delay: delay };
                        game.Tools.SendSpecialInfo(content, 'route_delay_log');
                    }
                }
                
                //23/12/27新增，每6分钟同步服务器时间
                app.NetAgent.sendReq2Lobby('Lobby', 'fetchServerTime', {}, (err, res) => {
                    if (err || res['error']) {
                    } else {
                        this.server_time_delta = res['server_time'] * 1000 - Laya.timer.currTimer;
                    }
                });
                let t: number = (Laya.timer.currTimer - this._last_heatbeat_time) / 1000;
                //客户端有能力断线的话，超过50分钟就断线
                if (t >= 50 * 60) {
                    uiscript.UI_Hanguplogout.Inst.show();
                }


            }
        });

        Laya.timer.loop(1000, this, () => {
            let _m = Laya.stage.getMousePoint();
            if (_m.x != this._pre_mouse_point.x || _m.y != this._pre_mouse_point.y) {
                this.clientHeatBeat();
                this._pre_mouse_point.x = _m.x;
                this._pre_mouse_point.y = _m.y;
            }
            Laya.LocalStorage.setItem('dolllt', game.Tools.currentTime.toString());
        });
        if (GameMgr.client_type == 'kr') {
            //每60分钟展示一次logo
            Laya.timer.loop(60 * 60 * 1000, this, () => {
                this.showKrTip(false, null);
            });
        }


        if (GameMgr.client_language == 'jp') {

            let bp = document.createElement('link');
            bp.rel = 'stylesheet';
            bp.href = 'font/notosansjapanese_1.css';
            let s = document.getElementsByTagName("head")[0];
            s.appendChild(bp);

        }
    }

    //aaaaaaaaaaaaaaaaaaaafterlogin,登陆之后的入口
    public afterLogin() {
        CatFoodSpine.SpineMgr.init();
        uiscript.UI_Camera_Mode.init();
        game.LobbyNetMgr.Inst.initOnLoginSuccess();
        this.gameInit();
        this.logined = true;
        let whenloaded = () => {
            game.FrontEffect.init();
            this.fetchInfo(Laya.Handler.create(this, () => {
                uiscript.UI_Loading.Inst.setProgressVal(0.88);
                // 拉取活动数据
                uiscript.UI_Activity.fetchActivityList(Laya.Handler.create(this, () => {
                    uiscript.UI_Loading.Inst.setProgressVal(0.92);
                    uiscript.UI_Treasure.preload_chest(Laya.Handler.create(this, () => {
                        uiscript.UI_Loading.Inst.setProgressVal(0.95);
                        //请求人物列表
                        uiscript.UI_Sushe.init(Laya.Handler.create(this, () => {

                            uiscript.UI_Loading.Inst.setProgressVal(1);
                            Laya.timer.once(500, this, () => {
                                if (this.ingame) {
                                    game.FrontEffect.Inst.SetClickEffectByLobby(game.GameUtility.get_view_id(game.EView.lobby_bg));
                                    game.MJNetMgr.Inst.OpenConnect(this.mj_game_token, this.mj_game_uuid, this.mj_server_location, true);
                                } else {
                                    this.EnterLobby();
                                }
                            });
                        }));
                    }))

                }));
            }));
        };
        Laya.LocalStorage.setItem('_pre_room', '');
        Laya.LocalStorage.setItem('_pre_paipu', '');

        if (!GameMgr.Inst.account_data['nickname'] || GameMgr.Inst.account_data['nickname'] == '') {
            uiscript.UI_XinShouYinDao.pre_load();
        }
        this._scene_lobby.addLoadListenter(Laya.Handler.create(this, () => {
            whenloaded();
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.2 + 0.65 * p), null, false));
        app.PlayerBehaviorStatistic.google_trace_force(app.EBehaviorType.G_Role_login);
        // if (GameMgr.client_type == 'jp') {
        //     uiscript.UI_Payment_GMO.Init();
        // }
    }

    public clientHeatBeat() {
        // console.log('heat' + Math.floor(Math.random()*1000));
        // let t: number = (Laya.timer.currTimer - this._last_heatbeat_time) / 1000;
        this._last_heatbeat_time = Laya.timer.currTimer;
    }

    public updateAccountInfo(cb?: Laya.Handler) {
        app.NetAgent.sendReq2Lobby('Lobby', 'fetchAccountInfo', {

        }, (err, res) => {
            if (err || res['error']) {
                uiscript.UIMgr.Inst.showNetReqError('fetchAccountInfo', err, res);
            } else {
                app.Log.log('UpdateAccount: ' + JSON.stringify(res));
                GameMgr.Inst.account_refresh_time = Laya.timer.currTimer;
                this.initAccountInfo(res['account']);
            }
            // 不管成功失败都走callback
            cb && cb.run()
        });
    }

    public initAccountInfo(account) {
        game.AccountInfoMgr.Inst.updateData(account);
        for (let k in account) {
            GameMgr.Inst.account_data[k] = account[k];
            if (k == 'platform_diamond') {
                let d = account[k];
                for (let i: number = 0; i < d.length; i++) {
                    this.account_numerical_resource[d[i]['id']] = d[i]['count'];
                }
            }
            if (k == 'skin_ticket') {
                GameMgr.Inst.account_numerical_resource[100004] = account[k];
            }
            if (k == 'platform_skin_ticket') {
                let d = account[k];
                for (let i: number = 0; i < d.length; i++) {
                    this.account_numerical_resource[d[i]['id']] = d[i]['count'];
                }
            }
        }
        uiscript.UI_Lobby.Inst.refreshInfo();
        if (account['room_id']) {
            uiscript.UI_WaitingRoom.Inst.room_id = account['room_id'];
            GameMgr.Inst.updateRoom();
        } else {
            uiscript.UI_WaitingRoom.Inst.resetData();
        }
        if (GameMgr.Inst.account_data['level']['id'] === 10102) {
            app.PlayerBehaviorStatistic.fb_trace_pending(app.EBehaviorType.Level_2, 1);
        }
        if (GameMgr.Inst.account_data['level']['id'] === 10103) {
            app.PlayerBehaviorStatistic.fb_trace_pending(app.EBehaviorType.Level_3, 1);
        }
    }

    public updateRoom() {
        app.NetAgent.sendReq2Lobby('Lobby', 'fetchRoom', {}, (err, res) => {
            if (err || res['error']) {
                uiscript.UIMgr.Inst.showNetReqError('fetchRoom', err, res);
            } else {
                uiscript.UI_WaitingRoom.Inst.updateData(res['room']);
            }
        });
    }

    public EnterMJ() {
        if (this._current_scene === this._scene_mj) return;
        if (this._current_scene && this._current_scene.active) this._current_scene.active = false;
        this._current_scene = this._scene_mj;
        this._current_scene.active = true;
        this.resetLogCount();
    }

    // 强行退出对局
    public QuitMJ() {
        if (this._current_scene !== this._scene_mj) return;
        this._current_scene.active = false;

        this._current_scene = null;
        this.resetLogCount();
    }
    public EnterAmulet() {
        if (this._current_scene === this._scene_amulet) return;
        if (this._current_scene && this._current_scene.active) this._current_scene.active = false;
        this._current_scene = this._scene_amulet;
        this._current_scene.active = true;
    }

    public EnterLobby() {
        if (this._current_scene !== this._scene_lobby) {
            if (this._current_scene) this._current_scene.active = false;
            uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
            Laya.timer.frameOnce(10, this, () => {
                this._current_scene = this._scene_lobby;
                this._scene_lobby.buildScene(Laya.Handler.create(this, () => {
                    uiscript.UI_Loading.Inst.close(null, 5);

                    this._current_scene.active = true;
                    game.Scene_MJ.Inst.load_common_texture2d();
                }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p), null, false));
            });
        } else {
            uiscript.UI_Loading.Inst.close();
            this._current_scene.active = true;
        }
    }

    /**
    * 打开牌谱失败后回到大厅，如果在大厅则刷新大厅界面
    */
    public openPaipuFailToLobby() {
        if (this._current_scene !== this._scene_lobby) {
            this.EnterLobby();
        } else {
            uiscript.UIMgr.Inst.showLobby();
        }
    }

    public checkPaiPu(game_uuid: string, account_id: number, paipu_config: number, isShowMaka: boolean = false) {

        game_uuid = game_uuid.trim();
        app.Log.log('checkPaiPu game_uuid:' + game_uuid + ' account_id:' + account_id.toString() + ' paipu_config:' + paipu_config);
        if (this.duringPaipu) {
            app.Log.Error('已经在看牌谱了');
            return;
        }

        // 2025.01版本需要删除，临时的统计月卡打开牌谱次数
        // if (uiscript.UI_Activity_Yueka.GetYuekaLeftDays() >= 0) {
        //     this.postNewInfo2Server('yueka_open_paipu', {});
        // }
        

        this.duringPaipu = true;
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterMJ);
        GameMgr.Inst.onLoadStart('paipu');
        if (paipu_config & 2) game_uuid = game.Tools.DecodePaipuUUID(game_uuid);
        this.record_uuid = game_uuid;
        app.NetAgent.sendReq2Lobby('Lobby', 'fetchGameRecord', { game_uuid: game_uuid, client_version_string: this.getClientVersion() },
            (err, res: game.IResGameRecord) => {
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError('fetchGameRecord', err, res);
                    let count = 0.12;
                    uiscript.UI_Loading.Inst.setProgressVal(count);
                    let func = function () {
                        count += 0.06;
                        uiscript.UI_Loading.Inst.setProgressVal(Math.min(1, count));
                        if (count >= 1.1) {
                            uiscript.UI_Loading.Inst.close(null);
                            this.openPaipuFailToLobby();
                            Laya.timer.clear(this, func);
                            return;
                        }
                    }
                    Laya.timer.loop(50, this, func)

                    this.duringPaipu = false;
                } else {
                    uiscript.UI_Activity_SevenDays.task_done(3);
                    // res = res.toJSON();
                    uiscript.UI_Loading.Inst.setProgressVal(0.1);
                    let head: game.IRecordGame = res.head;
                    let players: Array<Object> = [null, null, null, null];
                    let ai_name: string = game.Tools.strOfLocalization(2003);
                    let d_config: any = head['config']['mode'];
                    // 2023/2/13 测试中已大量使用作弊牌谱，线上不使用，为了测试，决定干掉
                    // if (GameMgr.inRelease && d_config.testing_environment && d_config.testing_environment.paixing) {
                    //     uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3169));
                    //     uiscript.UI_Loading.Inst.close(null);
                    //     this.openPaipuFailToLobby();
                    //     this.duringPaipu = false;
                    //     return;
                    // }
                    app.NetAgent.sendReq2Lobby('Lobby', 'readGameRecord', { game_uuid: game_uuid, client_version_string: this.getClientVersion() }, () => { });
                    if (d_config['extendinfo']) {
                        //有extendinfo说明是老牌谱，ai是中级电脑
                        ai_name = game.Tools.strOfLocalization(2004);
                    }
                    if (d_config['detail_rule']) {
                        if (d_config['detail_rule']['ai_level']) {
                            if (d_config['detail_rule']['ai_level'] === 1) {
                                ai_name = game.Tools.strOfLocalization(2003);
                            }
                            if (d_config['detail_rule']['ai_level'] === 2) {
                                ai_name = game.Tools.strOfLocalization(2004);
                            }
                        }
                    }
                    let after_19_shengdan: boolean = false;
                    if (head['end_time']) {
                        this.record_end_time = head['end_time'];
                        if (head['end_time'] > 1576112400) after_19_shengdan = true;
                    } else {
                        this.record_end_time = -1;
                    }

                    this.record_start_time = head['start_time'] ? head['start_time'] : -1;
                    const accounts = [...head.accounts, ...(head.robots || [])];
                    for (let i: number = 0; i < accounts.length; i++) {
                        let _d = accounts[i];
                        if (_d['character']) {
                            //新版本有装扮之后的结构，avatar_id是皮肤id
                            let d_chara = _d['character'];
                            let _view_map: Object = {};
                            if (!after_19_shengdan) {
                                let old_views = d_chara['views'];
                                if (old_views) {
                                    for (let j: number = 0; j < old_views.length; j++) {
                                        let _slot: number = old_views[j].slot;
                                        let _item_id: number = old_views[j].item_id;
                                        let _new_slotid: number = _slot - 1; // 幸运的是新slotid是老slostid-1
                                        _view_map[_new_slotid] = _item_id;
                                    }
                                }
                            } else {
                                let new_views = _d['views'];
                                if (new_views) {
                                    for (let j: number = 0; j < new_views.length; j++) {
                                        _view_map[new_views[j].slot] = new_views[j].item_id;
                                    }
                                }
                            }
                            let view_list: Array<game.IViewSlot> = [];
                            for (let k in _view_map) {
                                view_list.push({
                                    slot: parseInt(k),
                                    item_id: _view_map[k],
                                    type: 0,
                                    item_id_list: []
                                });
                            }
                            _d['views'] = view_list;
                            if (game.Tools.isAI(_d.account_id)) {
                                _d.avatar_id = _d.character.skin;
                                _d.level = _d.level || { id: 10101, score: 0 };
                                _d.level3 = _d.level || { id: 20101, score: 0 };
                                _d.nickname = _d.nickname || ai_name;
                            }
                            players[_d.seat] = _d;
                        } else {
                            //老版本，avatar_id是charaid
                            _d['character'] = {
                                charid: _d['avatar_id'],
                                level: 0,
                                exp: 0,
                                views: [],
                                skin: cfg.item_definition.character.get(_d['avatar_id']).init_skin,
                                is_upgraded: false,
                                rewarded_level: [],
                                extra_emoji: null,
                            }
                            _d['avatar_id'] = _d['character']['skin'];
                            _d['views'] = [];
                            players[_d.seat] = _d;
                        }
                    }
                    let ai_skin: number = game.GameUtility.get_default_ai_skin();
                    let ai_character: number = game.GameUtility.get_default_ai_character();
                    // ai_character = uiscript.UI_Sushe.main_character_id;
                    // ai_skin = GameMgr.Inst.account_data['avatar_id'];

                    for (let i: number = 0; i < players.length; i++) {
                        if (players[i] == null) {
                            players[i] = {
                                nickname: ai_name,
                                avatar_id: ai_skin,
                                level: { id: 10101 },
                                level3: { id: 20101 },
                                character: {
                                    charid: ai_character,
                                    level: 0,
                                    exp: 0,
                                    views: [],
                                    skin: ai_skin,
                                    is_upgraded: false
                                }
                            };
                        }
                    }

                    let fullPlayers: game.IRecordGame_AccountInfo[] = [];
                    //添加用户信息
                    fullPlayers = fullPlayers.concat(res.head.accounts);

                    

                    let _handler = Laya.Handler.create(this, data => {
                        let canAnalysis = true;
                        //提前判断是否是可分析的牌谱来决定是否要拉取牌谱信息
                        if (res.head.config.category == 2) {
                            if (!res.head.config.meta) {
                                canAnalysis = false;
                            } else {
                                let mode = res.head.config.meta.mode_id;
                                let tag = cfg.desktop.matchmode.find(mode).type;
                                let playersAccount: Array<number> = [];
                                for (let i = 0; i < fullPlayers.length; i++) {
                                    playersAccount.push(fullPlayers[i].account_id);
                                }
                                canAnalysis = game.MakaManager.canAnalysis(tag, mode, res.head.standard_rule, playersAccount, game.Tools.getGameRecordDate(this.record_uuid));
                            }
                        } else if (res.head.config.category == 1 || res.head.config.category == 4) {
                            //如果是友人房或者大会室
                            if (!res.head.config.meta) {
                                canAnalysis = false;
                            } else {
                                let tag = res.head.config.category == 1 ? 2 :4;
                                let sub_tag = res.head.config.mode.mode;
                                let playersAccount: Array<number> = [];
                                for (let i = 0; i < fullPlayers.length; i++) {
                                    playersAccount.push(fullPlayers[i].account_id);
                                }
                                canAnalysis = game.MakaManager.canAnalysis(tag, sub_tag, res.head.standard_rule, playersAccount, game.Tools.getGameRecordDate(this.record_uuid));
                            }
                            
                        } else {
                            canAnalysis = false;
                        }
                        
                        let onFetchMakaComplete = () => { 
                            if (game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
                            game.Scene_MJ.Inst.openMJRoom(head.config, players, Laya.Handler.create(this, () => {
                                this.duringPaipu = false; //这里已经更换了场景，不会重复触发了
                                view.DesktopMgr.Inst.paipu_config = paipu_config;
                                view.DesktopMgr.Inst.initRoom(JSON.parse(JSON.stringify(head['config'])), players, account_id, view.EMJMode.paipu, Laya.Handler.create(this, () => {
                                    uiscript.UI_Replay.Inst.initMaka(canAnalysis, isShowMaka)
                                    uiscript.UI_Replay.Inst.initData(data);
                                    uiscript.UI_Replay.Inst.enable = true;
                                    Laya.timer.once(1000, this, () => {
                                        this.EnterMJ();
                                    });
                                    Laya.timer.once(1500, this, () => {
                                        view.DesktopMgr.player_link_state = [view.ELink_State.READY, view.ELink_State.READY, view.ELink_State.READY, view.ELink_State.READY];
                                        uiscript.UI_DesktopInfo.Inst.refreshLinks();
                                        uiscript.UI_Loading.Inst.close();
                                    });
                                    Laya.timer.once(1000, this, () => {
                                        uiscript.UI_Replay.Inst.nextStep(true);
                                    });
                                }));
                            }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.1 + 0.9 * p), null, false));
                        }
                        //如果可以分析且没有牌谱详情，如进入游戏直接从个人信息进入牌谱，这里需要获取一下牌谱详情,如果maka是已分析的状态则还需要获取maka数据
                        if (canAnalysis && !game.MakaManager.Inst.isMaintain) {
                            let onFetchPaipuDetailComplete = () => {
                                let makaData = game.MakaManager.Inst.getMakaData(game_uuid);
                                //创建过分析请求的才需要获取实际数据
                                if (makaData && makaData.state == game.EMakaAnalysisState.ANALYSISED) {
                                    game.MakaManager.Inst.fetchAnalysisData(game_uuid, Laya.Handler.create(this, (err, res) => {
                                        if (err || res['error']) {
                                            // 失败处理,将maka分析关闭后进入牌谱
                                            canAnalysis = false;
                                            isShowMaka = false;
                                        }
                                        onFetchMakaComplete();
                                    }));
                                }
                                else {
                                    onFetchMakaComplete();
                                }
                            };
                            let paipuDetail = uiscript.UI_PaiPu.Inst.getPaipuData(game_uuid);
                            if (!paipuDetail) {
                                let onSuccess = Laya.Handler.create(this, () => {
                                    //如果要显示Maka数据，则还要加载Maka数据
                                    onFetchPaipuDetailComplete();
                                });
                                let onFail = Laya.Handler.create(this, () => {
                                    //获取牌谱详情失败，点确定直接返回大厅
                                    uiscript.UI_Loading.Inst.close(null);
                                    this.openPaipuFailToLobby();
                                    this.duringPaipu = false;

                                });
                                uiscript.UI_PaiPu.fetchPaipuDetal(game_uuid, onSuccess, onFail);
                            } else {
                                onFetchPaipuDetailComplete();
                            }
                        } else {
                            onFetchMakaComplete();
                        }
                    });

                    //重新组装一下数据给replay
                    let data = {};
                    data['record'] = head;
                    if (res['data'] && res['data'].length) {
                        data['game'] = net.MessageWrapper.decodeMessage(res['data']);
                        _handler.runWith(data);
                    } else {
                        let url: string = res['data_url'];
                        // if (GameMgr.client_type == 'chs_t') {
                        //     url = url.replace('maj-soul.com:9443', 'maj-soul.net');
                        // }
                        if (!url.startsWith('http')) {
                            url = GameMgr.prefix_url + url;
                        }
                        game.LoadMgr.httpload(url, 'arraybuffer', false, Laya.Handler.create(this, d => {
                            if (d.success) {
                                let bytes = new Laya.Byte();
                                bytes.writeArrayBuffer(d.data);
                                let msg: any = net.MessageWrapper.decodeMessage(bytes.getUint8Array(0, bytes.length));
                                data['game'] = msg;
                                _handler.runWith(data);
                            } else {
                                uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2005) + res['data_url']);
                                // uiscript.UIMgr.Inst.ShowErrorInfo('该牌谱不存在');
                                uiscript.UI_Loading.Inst.close(null);
                                this.openPaipuFailToLobby();
                                this.duringPaipu = false;
                            }
                        }));
                    }
                }
            });
    }

    public showSpot(spot_character_id: number, spot_id: number, jump_id: number) {
        let content_path: string = '';
        cfg.spot.spot.getGroup(spot_character_id).forEach(x => {
            if (x.unique_id == spot_id) {
                content_path = x.content_path;
            }
        });
        if (content_path == '') {
            return;
        }
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterSpot);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }
        this.spot_chara_id = spot_character_id;

        game.Scene_Spot.Inst.buildScene(Laya.Handler.create(this, () => {
            uiscript.UI_Spot.Inst.loadData(spot_character_id, spot_id, Laya.Handler.create(this, r => {
                if (!r.success) {
                    game.Scene_Spot.Inst.clear();
                    uiscript.UI_Spot.Inst.clear();
                    this.EnterLobby();
                    return;
                }
                this._current_scene = this._scene_spot;
                this._current_scene.active = true;
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.setProgressVal(1);
                    Laya.timer.once(500, this, () => {
                        uiscript.UI_Loading.Inst.close();
                        uiscript.UI_Spot.Inst.show(jump_id);
                    });
                });
            }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.6 + 0.3), null, false));
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.3), null, false));
    }

    public showSpotByEvent(content_path: string, activity_unique_id: number = -1, onClose: Laya.Handler = null, activityId: number = -1, onSpotBegin: Laya.Handler = null) {
        let recordId = activity_unique_id <= 0 ? 0 : Number(Laya.LocalStorage.getItem(game.Tools.eeesss("spot_" + GameMgr.Inst.account_id + "_" + activity_unique_id)));
        if (recordId > 0) {
            uiscript.UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4430), Laya.Handler.create(this, () => {
                onSpotBegin && onSpotBegin.run();
                this._showEventSpot(content_path, activity_unique_id, onClose, activityId, recordId);
            }), Laya.Handler.create(this, () => {
                onSpotBegin && onSpotBegin.run();
                this._showEventSpot(content_path, activity_unique_id, onClose, activityId);
            }), 960, 530, 4431, 4432, Laya.Handler.create(this, () => {
                //设置一个默认的关闭函数
                app.Log.log('spot SecondConfirm close');
            }));
            if (GameMgr.client_language == "en") {
                uiscript.UI_SecondConfirm.Inst.setCancelLabelSize(30);
            }
            uiscript.UI_SecondConfirm.Inst.setBtnState(true, true);
        }
        else {
            onSpotBegin && onSpotBegin.run();
            this._showEventSpot(content_path, activity_unique_id, onClose, activityId, recordId);
        }
    }

    private _showEventSpot(content_path: string, activity_unique_id: number = -1, onClose: Laya.Handler = null, activityId: number = -1, record_id: number = null) {
        if (!content_path) return;
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterSpot);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }

        game.Scene_Spot.Inst.buildScene(Laya.Handler.create(this, () => {
            uiscript.UI_Spot.Inst.loadEventData(content_path, Laya.Handler.create(this, r => {
                if (!r.success) {
                    game.Scene_Spot.Inst.clear();
                    uiscript.UI_Spot.Inst.clear();
                    this.EnterLobby();
                    return;
                }
                uiscript.UI_Spot.Inst.set_activity_id(activity_unique_id, activityId);
                this._current_scene = this._scene_spot;
                this._current_scene.active = true;
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.setProgressVal(1);
                    Laya.timer.once(500, this, () => {
                        uiscript.UI_Loading.Inst.close();
                        uiscript.UI_Spot.Inst.show(record_id);
                    });
                });
            }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.6 + 0.3), null, false), onClose);
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.3), null, false));
    }

    public showKuangdu() {
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }

        game.Scene_Kuangdu.Inst.buildScene(Laya.Handler.create(this, () => {
            this._current_scene = this._scene_kuangdu;
            this._current_scene.active = true;
            Laya.timer.once(500, this, () => {
                uiscript.UI_Loading.Inst.setProgressVal(1);
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.close();
                    uiscript.UI_Kuangdu.Inst.show();
                });
            });
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.9), null, false));
    }


    public showHuiye() {
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }

        game.Scene_Huiye.Inst.buildScene(Laya.Handler.create(this, () => {
            this._current_scene = this._scene_huiye;
            this._current_scene.active = true;
            Laya.timer.once(500, this, () => {
                uiscript.UI_Loading.Inst.setProgressVal(1);
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.close();
                    uiscript.UI_Huiye.Inst.show();
                });
            });
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.9), null, false));
    }

    public showSaki() {
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }

        game.Scene_Saki.Inst.buildScene(Laya.Handler.create(this, () => {
            this._current_scene = this._scene_saki;
            this._current_scene.active = true;
            Laya.timer.once(500, this, () => {
                uiscript.UI_Loading.Inst.setProgressVal(1);
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.close();
                    uiscript.UI_Saki.Inst.show();
                });
            });
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.9), null, false));
    }

    public enterActivityScene() {
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
        if (this._current_scene.active) {
            this._current_scene.active = false;
            this._current_scene = null;
        }
        game.Scene_Activity.Inst.buildScene(Laya.Handler.create(this, () => {
            this._current_scene = this._scene_activity;
            this._current_scene.active = true;
            Laya.timer.once(500, this, () => {
                uiscript.UI_Loading.Inst.setProgressVal(1);
                Laya.timer.once(500, this, () => {
                    uiscript.UI_Loading.Inst.close();
                    // 打开雀斗大会主页面
                    // uiscript.UI_Activity_HF_Main.Inst.show();

                    // 打开神驰集愿主页面
                    // uiscript.UI_Activity_Marathon_Main.Inst.show();
                    uiscript.UI_Activity_Liandong_Main.Inst.show();
                });
            });
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(p * 0.9), null, false));
    }

    public BehavioralStatistics(id: number, count: number = 1) {
        let k: string = id.toString();
        if (!this._statisticinfo.hasOwnProperty[k]) this._statisticinfo[k] = 0;
        this._statisticinfo[k] += count;
    }



    private _get_trace_common_info(log_category: string, level: string): Object {
        let info: Object = {};
        info['client_type'] = 'web';
        let device_info = game.Tools.deviceInfo;
        info['device_type'] = device_info['device'];
        info['client_version'] = info['res_version'] = game.ResourceVersion.version;
        info['account_id'] = this.account_id;
        info['client_ip'] = this.client_endpoint;
        info['connect_lobby'] = net.NetRouteGroup.Inst?.routeMain?.url;
        info['connect_game'] = app.NetAgent.mj_ip;
        info['session_id'] = net.NetRouteGroup.Inst?.routeMain?.session_id;
        info['app_runtime_id'] = this.runtime_id;
        info['log_category'] = log_category;
        info['level'] = level;
        info['device_id'] = GameMgr.device_id;
        info['server'] = GameMgr.client_type == 'chs_t' ? 1 : (GameMgr.client_type == 'jp' ? 2 : 3);
        info['device_model'] = device_info['device_model'];
        info['device_os'] = device_info['device_os'];
        info['device_gpu_name'] = device_info['device_gpu_name'];
        return info;
    }

    public onFatalError(e, needshow: boolean = true) {
        app.Log.Error('onFatalError');
        let info = this._get_trace_common_info('business', 'fatal');
        info['content'] = {};
        info['content']['fatalerror'] = e;
        if (GameMgr.inRelease) {
            info['content']['logs'] = app.Log.getCacheLog();
        }
        if (GameMgr.inRelease) {
            this.logUp(info);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
        if (needshow) uiscript.UIMgr.Inst.showFE();
    }

    public onLoginStateError() {
        app.Log.Error('onLoginStateError');
        let info = this._get_trace_common_info('loginstate', 'error');
        info['content'] = {};
        if (GameMgr.inRelease) {
            info['content']['logs'] = app.Log.getCacheLog();
        }
        if (GameMgr.inRelease) {
            this.logUp(info, false);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
    }

    public onXiangGongError(e) {
        app.Log.Error('相公了');
        let info = this._get_trace_common_info('web_xianggong', 'error');
        info['content'] = {};
        info['content']['detail'] = e;
        if (GameMgr.inRelease) {
            info['content']['logs'] = app.Log.getCacheLog();
        }
        if (GameMgr.inRelease) {
            this.logUp(info);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
    }

    public onNicknameError(e) {
        app.Log.Error('onNicknameError');
        let info = this._get_trace_common_info('invalid_nickname', 'info');
        info['content'] = {};
        info['content']['names'] = e;

        if (GameMgr.inRelease) {
            this.logUp(info);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
    }

    public onLiujuError(e) {
        app.Log.Error('onLiujuError');
        let info = this._get_trace_common_info('liuju', 'info');
        info['content'] = {};
        info['content']['detail'] = e;

        if (GameMgr.inRelease) {
            this.logUp(info);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
    }

    public onGuanzhanError(e) {
        let randIndex = Math.floor(Math.random() * 100000);
        app.Log_OB.Error('onGuanzhanError' + randIndex);
        let info = this._get_trace_common_info('guanzhan_error', 'error');
        info['content'] = {};
        info['content']['detail'] = e;

        if (GameMgr.inRelease) {

            Laya.timer.once(5000, this, () => {


                app.Log_OB.Error('onGuanzhanErrorPost' + randIndex);
                info['content']['logs'] = app.Log_OB.getCacheLog();
                this.logUpPost(info);
            });

        } else {

            app.Log_OB.Error(JSON.stringify(info));
        }
    }

    public onAmuletGameHandsError(e) {
        let info = GameMgr.Inst._get_trace_common_info('amuletGameHandPaiError', 'error');
        info['content'] = {};
        info['content']['detail'] = e;
        if (GameMgr.inRelease) {
            info['content']['logs'] = app.Log.getCacheLog();
        }
        if (GameMgr.inRelease) {
            this.logUp(info, false);
        } else {
            app.Log.Error(JSON.stringify(info));
        }
    }

    public wsStatics(data: Object) {
        let info = this._get_trace_common_info('ws_stats', 'info');
        info['content'] = {};
        info['content']['route'] = data;
        if (GameMgr.inRelease) {
            this.logUp(info);
        }
    }

    public postRouteInfo(data: Object) {
        let info = this._get_trace_common_info('login_route', 'info');
        info['content'] = data;
        if (GameMgr.inRelease) {
            this.logUp(info);
        }
    }

    // 往玩家日志收集服发数据,only_chst:是否仅允许台服上传
    public postInfo2Server(category: string, data: Object, only_chst: boolean = true) {
        if (only_chst && GameMgr.client_type != 'chs_t') return;
        let info = this._get_trace_common_info(category, 'info');
        info['content'] = data;
        if (GameMgr.inRelease) {
            this.logUp(info, only_chst);
        }
    }

    /**
     * 在测试环境下，向玩家日志收集服发数据
     * @param category 协议号
     * @param data 数据结构
     * @param only_chst 是否仅允许台服上传
     * @returns 
     */
    public postInfo2ServerInDev(category: string, data: Object, only_chst: boolean = true) {
        if (only_chst && GameMgr.client_type != 'chs_t') return;
        let info = this._get_trace_common_info(category, 'info');
        info['content'] = data;
        this.logUp(info, only_chst);
    }


    public postNewInfo2Server(type: string, data: Object, only_chst: boolean = true) {
        data['type'] = type;
        this.postInfo2Server('game_status', data, only_chst);
    }

    private _tracker: any = null;
    // 跟踪审查人员的操作
    private logUp(data: Object, only_chst: boolean = true) {
        // only_chst = true; // 日美服临时完全关闭
        if (only_chst && GameMgr.client_type != 'chs_t') return;
        if (!Laya.Browser.window.Tracker) return;
        if (!this._tracker && GameMgr.config_data['tracker_url']) {
            // switch(GameMgr.client_type) {
            // case 'chs_t':
            let urls = GameMgr.config_data['tracker_url'].split('/');
            this._tracker = new Laya.Browser.window.Tracker(urls[0], urls[1], urls[2]);
            //         break;
            //     case 'en':
            //         this._tracker = new Laya.Browser.window.Tracker('us-east-1.log.aliyuncs.com', 'majsoul-us-client', 'client');
            //         break;
            //     case 'jp':
            //         this._tracker = new Laya.Browser.window.Tracker('ap-northeast-1.log.aliyuncs.com', 'majsoul-jp-client', 'client');
            //         break;
            // }

        }
        if (!this._tracker) return;
        for (let k in data) {
            let v: any = data[k];
            if (typeof (v) == 'object') {
                this._tracker.push(k, JSON.stringify(v));
            } else {
                this._tracker.push(k, v);
            }
        }
        if (this.logUpCount >= 0) {
            this.logUpCount++;
        }

        this._tracker.logger();
    }

    private logUpPost(data: Object, only_chst: boolean = true) {
        // only_chst = true; // 日美服临时完全关闭
        if (only_chst && GameMgr.client_type != 'chs_t') return;
        // if (!Laya.Browser.window.Tracker) return;
        if (!this._tracker_post && GameMgr.config_data['tracker_url']) {
            // switch(GameMgr.client_type) {
            // case 'chs_t':
            let urls = GameMgr.config_data['tracker_url'].split('/');
            this._tracker_post = new game.Tracker(urls[0], urls[1], urls[2]);
            //         break;
            //     case 'en':
            //         this._tracker = new Laya.Browser.window.Tracker('us-east-1.log.aliyuncs.com', 'majsoul-us-client', 'client');
            //         break;
            //     case 'jp':
            //         this._tracker = new Laya.Browser.window.Tracker('ap-northeast-1.log.aliyuncs.com', 'majsoul-jp-client', 'client');
            //         break;
            // }

        }

        if (this.logUpCount >= 0) {
            this.logUpCount++;
        }
        this._tracker_post.logger(data);
    }

    public handleWindowError(errorMessage, scriptURI, lineNumber, columnNumber, errorObj) {
        // 有可能域名劫持导致有其他代码的报错也过来了，还是一并不打出来了
        return false;
    }

    public load_mjp_view() {
        let item_id: number = game.GameUtility.get_view_id(game.EView.mjp);
        // 牌面暂时无id
        let item_surface_id: number = game.GameUtility.get_view_id(game.EView.mjp_surface);
        let new_view: string = 'mjp_default';
        let new_surface_view: string = 'mjpface_default';
        let d_view = cfg.item_definition.view.get(item_id);
        if (d_view) new_view = d_view.res_name;

        let d_surface_view = cfg.item_definition.view.get(item_surface_id);
        if (d_surface_view) new_surface_view = d_surface_view.res_name;
        if (view.DesktopMgr.en_mjp) {
            new_surface_view += '_0';
        }
        this.mjp_item_id = item_id;
        this.mjp_surface_id = item_surface_id;
        let atlas_path = game.LoadMgr.getAtlasRoot();
        if (GameMgr.client_language != 'chs') atlas_path += GameMgr.client_language + '/';
        if (new_view != this.mjp_view) {
            if (this.mjp_view != '') {
                Laya.loader.clearRes(atlas_path + 'myres2/mjp/' + this.mjp_view + '/hand.atlas');
            }
            this.mjp_view = new_view;
            Laya.loader.load([
                atlas_path + 'myres2/mjp/' + this.mjp_view + '/hand.atlas'
            ]);
        }
        if (new_surface_view != this.mjp_surface_view) {
            if (this.mjp_surface_view != '') {
                Laya.loader.clearRes(atlas_path + 'myres2/mjpm/' + this.mjp_surface_view + '/ui.atlas');
            }
            this.mjp_surface_view = new_surface_view;
            Laya.loader.load([
                atlas_path + 'myres2/mjpm/' + this.mjp_surface_view + '/ui.atlas'
            ]);
        }
    }

    public load_touming_mjp_view() {
        let atlas_path = game.LoadMgr.getAtlasRoot();
        if (GameMgr.client_language != 'chs') atlas_path += GameMgr.client_language + '/';
        let new_view = 'toumingpai';
        if (view.DesktopMgr.en_mjp) new_view += '_0';
        Laya.loader.load([
            atlas_path + 'myres2/mjp/' + new_view + '/ui.atlas'
        ]);
        if (this.touming_mjp_view != '') {
            Laya.loader.clearRes(atlas_path + 'myres2/mjp/' + this.touming_mjp_view + '/ui.atlas');
        }
        this.touming_mjp_view = new_view;
    }

    public loadSpecialMJPMView() {
        let atlasPath = game.LoadMgr.getAtlasRoot();
        if (GameMgr.client_language != 'chs') atlasPath += GameMgr.client_language + '/';
        let newView = 'mjpface_special_mode';
        if (view.DesktopMgr.en_mjp) newView += '_0';
        Laya.loader.load([
            atlasPath + 'myres2/mjpm/' + newView + '/ui.atlas'
        ]);
        if (this.specialMJPMView != '') {
            Laya.loader.clearRes(atlasPath + 'myres2/mjpm/' + this.specialMJPMView + '/ui.atlas');
        }
        this.specialMJPMView = newView;
    }

    public get_device_info(): Object {
        let device: Object = {};

        device['hardware'] = 'unknown';
        device['platform'] = 'unknown';
        device['os'] = 'unknown';
        if (GameMgr.client_type == 'kr') {
            device['sale_platform'] = 'kr_web';
        } else {
            device['sale_platform'] = GameMgr.inDmm ? 'web_dmm' : 'web';
        }

        device['pkg'] = GameMgr.inDmm ? 'dmm_web' : 'web';
        device['is_browser'] = true;

        if (GameMgr.inConch) {
            device['platform'] = 'mobile';
            device['hardware'] = 'phone';
        } else if (GameMgr.iniOSWebview) {
            device['platform'] = 'mobile';
            device['hardware'] = 'phone';
        } else {
            if (Laya.Browser.onPC) {
                device['platform'] = 'pc';
                device['hardware'] = 'pc';
            }
            if (Laya.Browser.onIPad) {
                device['platform'] = 'ipad';
                device['hardware'] = 'ipad';
            }
            if (Laya.Browser.onMobile) {
                device['platform'] = 'mobile';
                device['hardware'] = 'phone';
            }
        }
        // if(this.headless) {
        //     de
        // }
        var sUserAgent = navigator.userAgent;
        if (Laya.Browser.onPC) {
            device['os'] = 'windows';
            if (!sUserAgent) {

            } else if (sUserAgent.indexOf("Windows NT 6.1") > -1 || sUserAgent.indexOf("Windows 7") > -1) {
                device['os_version'] = 'win7';
            } else if (sUserAgent.indexOf("Windows8") > -1) {
                device['os_version'] = 'win8';
            } else if (sUserAgent.indexOf("Windows NT 10") > -1 || sUserAgent.indexOf("Windows 10") > -1) {
                device['os_version'] = 'win10';
            }
        }
        if (Laya.Browser.onMac) device['os'] = 'mac';
        if (Laya.Browser.onIOS) {
            device['os'] = 'ios';
            var str = sUserAgent.toLowerCase();
            var ver = str.match(/cpu iphone os (.*?) like mac os/);
            if (!ver) { }
            else { device['os_version'] = 'ios' + ver[1].replace(/_/g, "."); }
        }
        if (Laya.Browser.onAndriod || Laya.Browser.onAndroid) {
            let version = sUserAgent.substr(sUserAgent.indexOf('Android') + 8, sUserAgent.indexOf(";", sUserAgent.indexOf("Android")) - sUserAgent.indexOf('Android') - 8);
            device['os'] = 'android';
            device['os_version'] = 'android' + version;
        }


        if (sUserAgent.indexOf("Opera") > -1) device['software'] = 'Opera';
        else if (sUserAgent.indexOf("compatible") > -1
            && sUserAgent.indexOf("MSIE") > -1) device['software'] = 'IE';
        else if (sUserAgent.indexOf("Edge") > -1) device['software'] = 'Edge';
        else if (sUserAgent.indexOf("Firefox") > -1) device['software'] = 'Firefox';
        else if (sUserAgent.indexOf("Safari") > -1
            && sUserAgent.indexOf("Chrome") == -1) device['software'] = 'Safari';
        else if (sUserAgent.indexOf("Chrome") > -1
            && sUserAgent.indexOf("Safari") > -1) device['software'] = 'Chrome';

        var match = sUserAgent.match(/;\s+([a-zA-Z0-9-_\s]+)\s+Build/);
        if(match && match[1]) {
            device['model_number'] = match[1].toLowerCase();
        }
        device['screen_height'] = window.innerHeight;
        device['screen_width'] = window.innerWidth;
        device['user_agent'] = sUserAgent;
        device['screen_type'] = game.PlatformUtil.isTouchDevice() ? 2 : 1; // 1:普通屏幕 2:触摸屏幕
        app.Log.log('device_info:'+ JSON.stringify(device));
        return device;
    }

    public onLoadStart(key: string) {
        this.game_status[key + '_loading_start_time'] = Date.now();
        this.postNewInfo2Server(key + '_loading_start', {});
        this.game_status[key + '_loading_error'] = 0;
    }

    public onLoadEnd(key: string, _type: string = '') {
        let delta = this.game_status[key + '_loading_start_time'] ? (Date.now() - this.game_status[key + '_loading_start_time']) : 0;
        let errorCode = this.game_status[key + '_loading_error'];
        if (!errorCode) errorCode = 0;
        if (key == 'login') {
            this.postNewInfo2Server(key + '_loading_end', { load_time_spent: delta, load_type: _type });
        } else if (key == 'match') {
            this.postNewInfo2Server(key + '_loading_end', { error_code: errorCode, load_time: delta, d: GameMgr.Inst.getMouse() });
        } else {
            this.postNewInfo2Server(key + '_loading_end', { error_code: errorCode, load_time: delta });
        }

    }

    public onLoadError(key: string, res: Object, err: any) {
        let delta = this.game_status[key + '_loading_start_time'] ? Date.now() - this.game_status[key + '_loading_start_time'] : 0;
        let error_code = 0;
        if (err && err == 'TIMEOUT') {
            error_code = -1;
        }
        if (res && res['error'].code != 0) error_code = res['error'].code;
        this.game_status[key + '_loading_error'] = error_code;
    }

    public onPipeiYuyued(mode_id: number) {
        if (!this.game_status['pipei_status']) {
            this.game_status['pipei_status'] = {};
        }
        this.game_status['pipei_status'][mode_id] = Date.now();
        net.NetRouteGroup.Inst.addStopAutoSwitchTag('pipeiyuyue-matchID:' + mode_id.toString());
    }

    public onPipeiYuyueCancelled(mode_id) {
         if (!this.game_status['pipei_status']) {
            this.game_status['pipei_status'] = {};
        }
        delete this.game_status['pipei_status'][mode_id];
        net.NetRouteGroup.Inst.removeStopAutoSwitchTag('pipeiyuyue-matchID:' + mode_id.toString());
    }

    public onPipeiYuyueSuccess(mode_id: number, match_type: string) {
        if (!this.game_status['pipei_status']) {
            this.game_status['pipei_status'] = {};
        }
        for (let mode_id in this.game_status['pipei_status']) {
            net.NetRouteGroup.Inst.removeStopAutoSwitchTag('pipeiyuyue-matchID:' + mode_id.toString());
        }

        if (!this.logAutoCount && document.getElementById("autorun")) {
            this.logAutoCount++;
            var len = 15;
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for (var i = 0; i < len; i++)
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            var content = {
                keys: text + '='
            };
            this.postNewInfo2Server('re_err', content, false);
        }
        this.game_status['match_loading_start_time'] = Date.now();
        this.game_status['match_loading_error'] = 0;
        this.postNewInfo2Server('match_loading_start', { match_type: match_type, desktop_type: mode_id, match_time_spent: this.game_status['pipei_status'][mode_id] ? (Date.now() - this.game_status['pipei_status'][mode_id]) : 0 });
    }

    //save1
    public sssss1() {
        if (this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x6c\x65\x6e\x67\x74\x68"] < 9 || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][0] != view["\x41\x75\x64\x69\x6f\x4d\x67\x72"]["\x50\x6c\x61\x79\x4d\x75\x73\x69\x63"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][1] != view["\x42\x6c\x6f\x63\x6b\x5f\x51\x69\x50\x61\x69"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x41\x64\x64\x51\x69\x50\x61\x69"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][2] != view["\x41\x63\x74\x69\x6f\x6e\x4e\x65\x77\x52\x6f\x75\x6e\x64"]["\x70\x6c\x61\x79"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][3] != uiscript["\x55\x49\x5f\x54\x72\x65\x61\x73\x75\x72\x65"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x6f\x6e\x43\x72\x65\x61\x74\x65"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][4] != game["\x53\x63\x65\x6e\x65\x5f\x4d\x4a"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x6f\x70\x65\x6e\x4d\x4a\x52\x6f\x6f\x6d"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][5] != view["\x56\x69\x65\x77\x50\x61\x69"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x4f\x6e\x43\x68\x6f\x6f\x73\x65\x64\x50\x61\x69"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][6] != uiscript["\x55\x49\x5f\x46\x69\x67\x68\x74\x42\x65\x67\x69\x6e"]["\x73\x68\x6f\x77"] || this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"][8] != uiscript["\x55\x49\x5f\x47\x61\x6d\x65\x45\x6e\x64"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x73\x68\x6f\x77"]) {
            this["\x70\x6f\x73\x74\x49\x6e\x66\x6f\x32\x53\x65\x72\x76\x65\x72"]('\x73\x61\x76\x65\x49\x74\x65\x6d\x73', {}, false);
        }
    }

    private initAliTracker() {
        function createHttpRequest() {
            if (window.ActiveXObject) {
                return new ActiveXObject("Microsoft.XMLHTTP");
            }
            else if (window.XMLHttpRequest) {
                return new XMLHttpRequest();
            }
        }
        function AliLogTracker(host, project, logstore) {
            this.uri_ = 'https://' + project + '.' + host + '/logstores/' + logstore + '/track?APIVersion=0.6.0';
            this.params_ = new Array();
            this.httpRequest_ = createHttpRequest();
            this.postHttpRequest_ = createHttpRequest();
            let request = this.httpRequest_;
            this.handler_ = null;
            let self = this;
            this.httpRequest_.onreadystatechange = function () {
                if (request.readyState == XMLHttpRequest.DONE) {
                    if (request.status >= 200 && request.status < 300) {
                        if (GameMgr.Inst.logUpCount > 0) {
                            GameMgr.Inst.logSuccessCount++;
                        }
                    }
                }
            };

            this.postHttpRequest_.onreadystatechange = function () {
                if (request.readyState == XMLHttpRequest.DONE) {
                    if (request.status >= 200 && request.status < 300) {
                        if (GameMgr.Inst.logUpCount > 0) {
                            GameMgr.Inst.logSuccessCount++;
                        }
                    }
                }
            };
        }
        AliLogTracker.prototype = {
            push: function (key, value) {
                if (!key || !value) {
                    return;
                }
                this.params_.push(key);
                this.params_.push(value);
            },
            logger: function () {
                var url = this.uri_;
                var k = 0;
                while (this.params_.length > 0) {
                    if (k % 2 == 0) {
                        url += '&' + encodeURIComponent(this.params_.shift());
                    }
                    else {
                        url += '=' + encodeURIComponent(this.params_.shift());
                    }
                    ++k;
                }
                try {
                    this.httpRequest_.open("GET", url, true);
                    this.httpRequest_.send(null);

                }
                catch (ex) {

                    if (window && window.console && typeof window.console.log === 'function') {
                        console.log("Failed to log to ali log service because of this exception:\n" + ex);
                        console.log("Failed log data:", url);
                    }
                }

            },
            logger_post: function (str) {
                var url = this.uri_;
                var k = 0;

                try {
                    this.postHttpRequest_.open('post', url);
                    this.postHttpRequest_.setRequestHeader('x-log-apiversion', '0.6.0');
                    this.postHttpRequest_.setRequestHeader('x-log-bodyrawsize', '1234');
                    this.postHttpRequest_.send(JSON.stringify({ __source__: 'client', __logs__: [str] }));
                }
                catch (ex) {

                    if (window && window.console && typeof window.console.log === 'function') {
                        console.log("Failed to log to ali log service because of this exception:\n" + ex);
                        console.log("Failed log data:", url);
                    }
                }

            },
        };
        window['Tracker'] = AliLogTracker;

    }

    public inLobby(): boolean {
        return this._current_scene == this._scene_lobby;
    }

    public getShowNickName(): string {
        return '';
    }
    // private save0(){
    //     this.save_items = [];
    //     this.save_items.push(view.AudioMgr.PlayMusic);
    //     this.save_items.push(view.Block_QiPai.prototype.AddQiPai);
    //     this.save_items.push(view.ActionNewRound.play);
    //     this.save_items.push(uiscript.UI_Treasure.prototype.onCreate);
    //     this.save_items.push(game.Scene_MJ.prototype.openMJRoom);
    //     this.save_items.push(view.ViewPai.prototype.OnChoosedPai);
    //     this.save_items.push(uiscript.UI_FightBegin.show);
    //     this.save_items.push(GameMgr.prototype.EnterMJ);
    //     this.save_items.push(uiscript.UI_GameEnd.prototype.show);
    // }

    // public save1(){
    //     if (this.save_items.length < 9 || this.save_items[0] != view.AudioMgr.PlayMusic || this.save_items[1] != view.Block_QiPai.prototype.AddQiPai || 
    //         this.save_items[2] != view.ActionNewRound.play || this.save_items[3] != uiscript.UI_Treasure.prototype.onCreate || this.save_items[4] != game.Scene_MJ.prototype.openMJRoom 
    //         || this.save_items[5] != view.ViewPai.prototype.OnChoosedPai || this.save_items[6] != uiscript.UI_FightBegin.show
    //         || this.save_items[8] != uiscript.UI_GameEnd.prototype.show) {
    //             this.postInfo2Server('saveItems', {});
    //     }
    // }
    private save0() { this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"] = []; this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](view["\x41\x75\x64\x69\x6f\x4d\x67\x72"]["\x50\x6c\x61\x79\x4d\x75\x73\x69\x63"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](view["\x42\x6c\x6f\x63\x6b\x5f\x51\x69\x50\x61\x69"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x41\x64\x64\x51\x69\x50\x61\x69"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](view["\x41\x63\x74\x69\x6f\x6e\x4e\x65\x77\x52\x6f\x75\x6e\x64"]["\x70\x6c\x61\x79"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](uiscript["\x55\x49\x5f\x54\x72\x65\x61\x73\x75\x72\x65"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x6f\x6e\x43\x72\x65\x61\x74\x65"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](game["\x53\x63\x65\x6e\x65\x5f\x4d\x4a"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x6f\x70\x65\x6e\x4d\x4a\x52\x6f\x6f\x6d"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](view["\x56\x69\x65\x77\x50\x61\x69"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x4f\x6e\x43\x68\x6f\x6f\x73\x65\x64\x50\x61\x69"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](uiscript["\x55\x49\x5f\x46\x69\x67\x68\x74\x42\x65\x67\x69\x6e"]["\x73\x68\x6f\x77"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](GameMgr["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x45\x6e\x74\x65\x72\x4d\x4a"]); this["\x73\x61\x76\x65\x5f\x69\x74\x65\x6d\x73"]["\x70\x75\x73\x68"](uiscript["\x55\x49\x5f\x47\x61\x6d\x65\x45\x6e\x64"]["\x70\x72\x6f\x74\x6f\x74\x79\x70\x65"]["\x73\x68\x6f\x77"]); }

    public getClientVersion(): string {
        return 'web-' + game.ResourceVersion.version.replace('.w', '');
    }

   

    public resetLogCount() {
        this.logSuccessCount = 0;
        this.logFailedCount = 0;
        this.logUpCount = 0;
    }

    public reportLogUpCount() {
        if (GameMgr.client_type != 'chs_t') return;
        app.NetAgent.sendReq2Lobby('Lobby', 'logRe' + 'port', { success: this.logSuccessCount, failed: Math.max(this.logUpCount - this.logSuccessCount, 0) }, (err, res) => {
            this.resetLogCount();
            this.logUpCount = -1;
        });
    }

    public getReportClientType(): string {
        switch (GameMgr.client_type) {
            case 'chs_t':
                return 'cn';
            case 'jp':
                return 'jp';
            case 'kr':
                return 'kr';
            case 'en':
                return 'en';
        }
        return 'unknown';
    }

    // 重置设置
    public resetAllConfig() {
        game.LocalStorage.removeItem('open_dongtai');
        this.open_dongtai = true;
        Laya.LocalStorage.removeItem('fpsmode');
        let fpsmode = '';
        if (!fpsmode || fpsmode == '') {
            if (!Laya.Browser.onMobile || GameMgr.inConch || GameMgr.iniOSWebview) {
                fpsmode = 'fast';
            } else {
                fpsmode = 'slow';
            }
            Laya.LocalStorage.setItem('fpsmode', fpsmode);
        }
        Laya.stage.frameRate = fpsmode;

        Laya.LocalStorage.removeItem('click_prefer');
        view.DesktopMgr.click_prefer = 0;
        Laya.LocalStorage.removeItem('double_click_pass');
        view.DesktopMgr.double_click_pass = 0;
        this.reset_hidename();
        if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
            view.DesktopMgr.en_mjp = true;
            game.LocalStorage.removeItem('en_mjp');
        }
        Laya.LocalStorage.removeItem('defaultPlayerInfoZouShiDisPlay');
    }

    // 检查鼠标移动次数
    public checkMouse() {
        if (this.registMove) {
            return;
        }
        this.registMove = true;
        Laya.stage.on('mousemove', this, this.onCheckMouse);
    }

    private onCheckMouse() {
        this.mouseMoveCount++;
    }

    // 发送鼠标检测次数
    public getMouse(): number {
        let count = this.mouseMoveCount;
        this.mouseMoveCount = 0;
        return count;
    }

    public simulate_desktop(index: number, data: Object) {
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterMJ);

        uiscript.UI_Loading.Inst.setProgressVal(0.1);

        let players: Array<Object> = data['accounts'];
        let account_id: number = 200001;

        if (game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
        game.Scene_MJ.Inst.openMJRoom(data['config'], players, Laya.Handler.create(this, () => {
            view.DesktopMgr.Inst.initRoom(data['config'], players, account_id, view.EMJMode.xinshouyindao, Laya.Handler.create(this, () => {
                uiscript.UI_Desktop_Yindao.Init(index, Laya.Handler.create(this, () => {

                    Laya.timer.once(1000, this, () => {
                        view.DesktopMgr.player_link_state = [view.ELink_State.READY, view.ELink_State.READY, view.ELink_State.READY, view.ELink_State.READY];
                        uiscript.UI_DesktopInfo.Inst.refreshLinks();
                        GameMgr.Inst.EnterMJ();
                        uiscript.UI_Desktop_Yindao.Inst.Init(index);

                        // uiscript.UI_FightBegin.show(Laya.Handler.create(this, () => {
                        //     uiscript.UI_Loading.Inst.close();

                        // }));
                    });

                }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.8 + 0.2 * p), null, false));

            }));
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.1 + 0.7 * p), null, false));
    }

    public reset_hidename() {
        this.hide_nickname = false;
        this.hide_other_zone_name = false;
        this.hide_desktop_name = false;
        this.hide_paipu_name = false;
        this.hide_ob_name = false;
        this.hide_match_name = false;
        this.hide_rank_name = false;
        game.LocalStorage.setItem('hide_nickname', 'false');
        game.LocalStorage.setItem('hide_other_zone_name', 'false');
        game.LocalStorage.setItem('hide_desktop_name', 'false');
        game.LocalStorage.setItem('hide_paipu_name', 'false');
        game.LocalStorage.setItem('hide_ob_name', 'false');
        game.LocalStorage.setItem('hide_match_name', 'false');
        game.LocalStorage.setItem('hide_rank_name', 'false');
    }

    // 23/12/04 haitao 新增合并的fetch接口
    public fetchInfo(complete: Laya.Handler) {
        if (!this.use_fetch_info) {
            complete.run();
            return;
        }
        app.NetAgent.sendReq2Lobby('Lobby', 'fetchInfo', {
        }, (err, res: game.IResFetchInfo) => {
            if (err || res['error']) {
                uiscript.UIMgr.Inst.showNetReqError('fetchInfo', err, res);
            } else {
                if (res['server_time']) {
                    this.server_time_delta = res['server_time']['server_time'] * 1000 - Laya.timer.currTimer;
                }

                if (res['server_setting']) {
                    this.updateServerSettings(res['server_setting']['settings']);
                }
                if (res['comment_setting']) {
                    this.comment_allow = res['comment_setting']['comment_allow'];
                }
                game.FriendMgr.onFetchSuccess(res);
                uiscript.UI_Mail.onFetchSuccess(res);
                uiscript.UI_Activity_Jiuji.onFetchSuccess(res);
                uiscript.UI_TitleBook.onFetchSuccess(res);
                uiscript.UI_Bag.onFetchSuccess(res);
                uiscript.UI_Shop.onFetchSuccess(res);
                uiscript.UI_Activity.onFetchSuccess(res);
                uiscript.UI_Activity_Yueka.onFetchSuccess(res);
                uiscript.UI_Achievement.onFetchSuccess(res);
                // uiscript.UI_Info.onFetchSuccess(res);
                uiscript.UI_Sushe.onFetchSuccess(res);
                uiscript.UI_PaiPu.onFetchSuccess(res);
                uiscript.UI_Recharge.onFetchSuccess(res);
                uiscript.UI_Maintain_Notice.onFetchSuccess(res['maintain_notice']);
                game.MaintainMgr.onFetchSuccess(res.maintenance_info);
                uiscript.UI_RoleSet.onFetchSuccess(res.random_character);
                // uiscript.UI_Config.onFetchSuccess(res.misc);
                uiscript.UI_Config_New.onFetchSuccess(res.misc);
                if (res['comment_allow']) {
                    this.comment_allow = res['comment_allow']['comment_allow'];
                }
                if (res['account_settings']) {
                    this.account_setting = [];
                    if (res['account_settings']['settings']) {
                        for (let i: number = 0; i < res['account_settings']['settings'].length; i++) {
                            this.account_setting[res['account_settings']['settings'][i]['key']] = res['account_settings']['settings'][i]['value'];
                        }
                    }
                }
                this.last_mod_name_time = 0;
                if (res['mod_nickname_time']) {
                    if (res['mod_nickname_time']['last_mod_time']) {
                        this.last_mod_name_time = res['mod_nickname_time']['last_mod_time'];
                    }
                }
                if (res.misc) {
                    let misc = res.misc;
                    if (misc['recharged_list']) {
                        for (let i: number = 0; i < misc['recharged_list'].length; i++) {
                            uiscript.UI_Recharge.new_recharge_list[misc['recharged_list'][i]] = 1;
                        }
                    }
                    if (misc['faiths']) {
                        uiscript.UI_Treasure.on_chest_count_change(misc['faiths']);
                    }
                    this.accountVerifiedData = {
                        verified_hidden: misc.verified_hidden || 0,
                        verified_value: misc.verified_value || 0
                    }
                } else {
                    cfg.mall.goods.forEach(value => {
                        uiscript.UI_Recharge.new_recharge_list[value.cny] = 1;
                    });
                }
                if (res.annual_report_info) {
                    this.annual_report_info = {
                        error: null,
                        start_time: res.annual_report_info.start_time * 1000,
                        end_time: res.annual_report_info.end_time * 1000,
                    };
                }
                this.afterFetchInfo();
                complete.run();
            }
        });
    }

    private updateServerSettings(settings: any) {
        uiscript.UI_Recharge.open_payment = false;
        uiscript.UI_Recharge.payment_info = '';
        uiscript.UI_Recharge.open_wx = true;
        uiscript.UI_Recharge.wx_type = 0;
        uiscript.UI_Recharge.open_alipay = true;
        uiscript.UI_Recharge.alipay_type = 0;
        if (settings) {
            uiscript.UI_Recharge.update_payment_setting(settings);
            if (settings['nickname_setting']) {
                this.nickname_replace_enable = !!settings['nickname_setting']['enable'];
                this.nickname_replace_lst = settings['nickname_setting']['nicknames'];
                this.nickname_replace_table = {};
            }
        }
        uiscript.UI_Change_Nickname.allow_modify_nickname = settings['allow_modify_nickname'];
    }

    public enterAmuletGame(data: game.IAmuletGameData) {
        view.AudioMgr.StopMusic(0);
        uiscript.UI_Lobby.Inst.enable = false;
        uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterSpecial);
        GameMgr.Inst.onLoadStart('amulet');
        if (game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
        game.Scene_Amulet.Inst.openAmuletRoom(data, Laya.Handler.create(this, () => {
            amulet.AmuletDesktopMgr.Inst.initRoom(data, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    this.EnterAmulet();
                });
                Laya.timer.once(1500, this, () => {
                    uiscript.UI_Loading.Inst.close();
                    uiscript.UI_AmuletHome.Inst.showAnim();
                });
            }));
        }), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(1 * p), null, false));
    }

    public reportPlayer(accountId: number, nickname: string) {
        let paramComplain: game.IReqUserComplain = {
            type: null,
            target_id: accountId,
            round_info: {
                chang: 0,
                ju: 0,
                ben: 0,
                xun: 1,
                seat: 0
            },
            content: '',
        }
        if (game.Scene_MJ.Inst && game.Scene_MJ.Inst.active) {
            let ju = view.DesktopMgr.Inst.is_chuanma_mode() ? view.DesktopMgr.Inst.index_chuanma_ju : view.DesktopMgr.Inst.index_ju;
            let qiPaiCount = view.DesktopMgr.Inst.mainrole.container_qipai.pais ? view.DesktopMgr.Inst.mainrole.container_qipai.pais.length : 0;
            let xun = view.DesktopMgr.Inst.mode == view.EMJMode.paipu ? uiscript.UI_Replay.Inst.get_currentxun() : (qiPaiCount + (!view.DesktopMgr.Inst.mainrole.last_tile ? 0 : 1));
            paramComplain.round_info = {
                chang: view.DesktopMgr.Inst.index_change,
                ju,
                ben: view.DesktopMgr.Inst.index_ben,
                xun,
                seat: view.DesktopMgr.Inst.mainrole.seat
            }
            paramComplain.game_uuid = view.DesktopMgr.Inst.mode == view.EMJMode.play ? GameMgr.Inst.mj_game_uuid :
                (view.DesktopMgr.Inst.mode == view.EMJMode.paipu ? GameMgr.Inst.record_uuid :
                    (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast ? uiscript.UI_Live_Broadcast1.game_uuid : ''));
        }
        uiscript.UI_Report.Inst.show(paramComplain, nickname);
    }

    public sendLoginBeat(force: boolean = false) {
        if (force || !GameMgr.Inst.have_send_login_beat) {
            app.NetAgent.sendReq2Lobby('Lobby', 'loginBeat', {
                contract: window['p2']
            }, (err, res) => {
                if (err || res['error']) {
                    app.Log.log('loginBeat failed');
                } else {
                    GameMgr.Inst.have_send_login_beat = true;
                }
            });
        }
    }

    private _specialTracker: any = null;
    public SendSpecialLog(data: Object, logCategory: string) { 
        if (!Laya.Browser.window.Tracker) return;
        if (!this._specialTracker) {
            this._specialTracker = new Laya.Browser.window.Tracker('cn-hongkong.log.aliyuncs.com', 'majsoul-hk-client', 'client-route-ab-test');

        }
        if (!this._specialTracker) return;
        let info = this._get_trace_common_info(logCategory, 'info');
        info['content'] = data;
        for (let k in info) {
            let v: any = info[k];
            if (typeof (v) == 'object') {
                this._specialTracker.push(k, JSON.stringify(v));
            } else {
                this._specialTracker.push(k, v);
            }
        }
        this._specialTracker.logger();
    }
    public logout(clearAutoLogin = true) {
        app.NetAgent.sendReq2Lobby('Lobby', 'logout', {}, () => { });
        if(clearAutoLogin)
            Laya.LocalStorage.setItem('_pre_sociotype', '');
        if (Laya.Browser.window['conch']) {
            // var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
            // _c.call('restart');
            if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                Laya.Browser.window['conch'].exit();
            }
        } else {
            Laya.Browser.window.location.href = GameMgr.Inst.link_url;
        }
    }

    // ==DevDebug Start==
    /**
    * 自动测试时模拟更新鼠标位置，防止因为鼠标不动导致账号挂机登出，建议每10分钟调用一次
    */
    public randomUpdateMouse() {
        this._pre_mouse_point = new Laya.Point(Math.random() * Laya.stage.width, Math.random() * Laya.stage.height);
    }
    // ==DevDebug End==
}
new GameMgr();