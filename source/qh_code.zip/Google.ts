module app {
    const client_id: string = "90981655031-3urq72m1to787vf5fl0iho2h5kfgqo5u.apps.googleusercontent.com";
    const scope: string = "";
    const enum InitStat {
        None,
        Initing,
        LoadFail,
        Fail,
        Success,
    }
    interface AuthResponse {
        /** 授予的访问令牌。 */
        access_token: string;
        /** 授予的 ID 令牌。 */
        id_token: string;
        /** 访问令牌中授予的范围。 */
        scope: string;
        /** 访问令牌到期前的秒数。 */
        expires_in: number;
        /** 用户首次授予所请求的范围的时间戳。 */
        first_issued_at: number;
        /** 访问令牌过期时的时间戳。 */
        expires_at: number;
    }
    export class Google {
        private static initStat: InitStat = InitStat.None;
        private static get gapi() { return window['gapi']; }
        public static get inited() { return this.initStat == InitStat.Success; }
        public static get idToken() {
            const _pre_error = Laya.LocalStorage.getItem('_pre_error');
            if (_pre_error && _pre_error == 'access_denied') {
                Laya.LocalStorage.removeItem('_pre_error');
                Laya.LocalStorage.removeItem('_pre_id_token');
                Laya.LocalStorage.removeItem('sgooglelogin');
                return '';
            }
            return Laya.LocalStorage.getItem('_pre_id_token');
        }
        public static init() {
            if (this.initStat != InitStat.None) return;
            this.initStat = InitStat.Initing;
            const script = document.createElement('script');
            const onLoadSuccess = () => {
                
                Google.gapi.load("auth2", () => {
                    try {
                        Google.gapi.auth2.init({
                            client_id,
                            scope,
                            redirect_uri: GameMgr.config_data["sgoogle_redirect_uri"],
                            ux_mode: "redirect",
                        }).then((data) => {
                            this.initStat = InitStat.Success;
                        }, (error) => {
                            app.Log.Error("google init error " + JSON.stringify(error));
                            this.initStat = InitStat.Fail;
                        });
                    } catch(e) {
                        app.Log.Error("google init error1 " + JSON.stringify(e));
                        this.initStat = InitStat.Fail;
                    }
                    
                });
               
                
            };
            const onLoadError = (error) => {
                this.initStat = InitStat.LoadFail;
                app.Log.Error("google load error " + JSON.stringify(error));
            };
            if (!Google.gapi) {
                script.src = "https://apis.google.com/js/platform.js";
                script.async = true;
                script.onload = onLoadSuccess;
                script.onerror = onLoadError;
                document.head.appendChild(script);
            } else {
                onLoadSuccess();
            }
        }

        public static authGoogle() {
            if (!this.inited) return;
            Laya.LocalStorage.setItem('sgooglelogin', '1');
            Laya.LocalStorage.removeItem('_pre_error');
            Laya.LocalStorage.removeItem('_pre_id_token');
            // Laya.LocalStorage.removeItem('_pre_scope');
            // Laya.LocalStorage.removeItem('_pre_login_hint');
            // Laya.LocalStorage.removeItem('_pre_prompt');
            // Laya.LocalStorage.removeItem('_pre_client_id');
            Google.gapi.auth2.getAuthInstance().signIn({
                scope,
                prompt: "select_account",
            });
        }
    }
}