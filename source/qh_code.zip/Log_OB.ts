/**
* name 
*/
module app{
	export class Log_OB {
		private static _getDate(): string {
			let _date:Date = new Date();
			return _date.getFullYear()+'/'+(_date.getMonth() + 1)+'/'+_date.getDate()+' '
			+_date.getHours()+':'+_date.getMinutes()+':'+_date.getSeconds()+'.'+_date.getMilliseconds();
		}

		private static _cache_logs:Array<string> = [];
		private static _ceche_index:number = 0;

		private static _insertCacheLog(_info:string) {
			if (this._cache_logs.length < 200) {
				this._cache_logs.push(_info);
			} else {
				this._cache_logs[this._ceche_index++ % 200] = _info;
			}
		}

		public static log(info:string): void {
			let s = '['+ this._getDate() + ' f:' + Laya.timer.currFrame +']log: ' + info;
			// if (!GameMgr.inRelease) console.log(s);
			this._insertCacheLog(s);
		}

		public static info(info:string): void {
			let s = '['+ this._getDate() + ' f:' + Laya.timer.currFrame +']info: ' + info;
			if (!GameMgr.inRelease) console.info(s);
			this._insertCacheLog(s);
		}

		public static Error(info:string): void {
			let s = '['+ this._getDate() + ' f:' + Laya.timer.currFrame +']error: ' + info;
			if (!GameMgr.inRelease) console.error(s);
			this._insertCacheLog(s);
		}

		public static info_net(info:string): void {
			let s = '[' + this._getDate() + ' f:' + Laya.timer.currFrame + ']info_net: ' + info;
			// if (!GameMgr.inRelease)  console.info(s);
		}

		public static getCacheLog():string {
			if (this._cache_logs.length == 0) {
				return 'nolog';
			} else {
				let s:string = '';
				for (let i:number = 0; i < this._cache_logs.length; i++) {
					let _index:number = (this._ceche_index + i) % this._cache_logs.length;
					if (i != 0) s += '\n';
					s += this._cache_logs[_index];
				}
				return s;
			}
		}

		private static getFunctionName(func) {
			if ( typeof func == 'function' || typeof func == 'object' ) {
				var name = ('' + func).match(/function\s*([\w\$]*)\s*\(/);
			}
			return name && name[1];
		}

		public static trace():string {
			let s:string = '';
			let caller = arguments.callee.caller;
			let count = 10;
			while (caller && count > 0) {
				if (s != '') s += '\n';
				s += caller.toString();
				caller = caller.caller;
				count--;
			}
			return s;
		}
	}
}