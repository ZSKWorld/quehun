/**
* name 
*/
module app {
	class SendSpeedChecker {
		public countLimit: number;	// 总共请求数限制
		public singleLimit: number; // 单个请求数限制
		public count: number = 0;
		public summary: basic.Dictionary<string, number[]> = new basic.Dictionary();

		constructor(countLimit:number, singleLimit:number) {
			this.countLimit = countLimit; 
			this.singleLimit = singleLimit;
		}

		public reset(): void {
			this.count = 0;
			this.summary.clear();
		}

		public addItem(key: string): number {
			if (this.count >= this.countLimit) {
				return 1;
			}
			let nowTime:number = game.Tools.getServerTime();
			if (!this.summary.has(key)) {
				this.summary.set(key, [nowTime]);
				this.count++;
			} else {
				let lst:number[] = this.summary.get(key);
				if (lst.length >= this.singleLimit) {
					return 2;
				}
				lst.push(nowTime);
				this.count++;
			}
			return 0;
		}
	}

	export class NetAgent {
		public static netRouteGroup_mj: net.NetRouteGroup_Single = null;

		private static lobbySummary3Min: SendSpeedChecker = new SendSpeedChecker(5000, 150);
		private static lobbySummary1Min: SendSpeedChecker = new SendSpeedChecker(3000, 100);
		private static mjSummary3Min: SendSpeedChecker = new SendSpeedChecker(5000, 150);
		private static mjSummary1Min: SendSpeedChecker = new SendSpeedChecker(3000, 100);

		public static init() {
			this.netRouteGroup_mj = new net.NetRouteGroup_Single();

			// 每分钟检查一次异常，有问题上报
			Laya.timer.loop(60 * 1000, null, () => {
				this.checkValid1Min(this.lobbySummary1Min, 'lobby');
				this.lobbySummary1Min.reset();
				this.checkValid1Min(this.mjSummary1Min, 'game');
				this.mjSummary1Min.reset();
			});
			// 每3分钟上报一次总次数
			Laya.timer.loop(3 * 60 * 1000, null, () => {
				this.postInfo3Min(this.lobbySummary3Min, 'lobby');
				this.lobbySummary3Min.reset();
				this.postInfo3Min(this.mjSummary3Min, 'game');
				this.mjSummary3Min.reset();
			});
		}

		private static checkValid1Min(checker:SendSpeedChecker, scene:'lobby' | 'game' ) {
			for (let index = 0; index < checker.summary.getCount(); index++) {
				let key = checker.summary.keys()[index];
				let reqArray = checker.summary.get(key);
				if (reqArray.length > checker.singleLimit) {
					let lastRequest = reqArray[reqArray.length - 1];
					let lastRequest60 = reqArray[0];
					let errorInfo = {
						name: key,
						lastReqTime: lastRequest,
						thisReqTime: lastRequest60,
						allCount: reqArray.length
					};
					app.Log.log(`【NetAgent】${scene} net request error,${JSON.stringify(errorInfo)}`);
					//测试环境下弹窗提示
					if (!GameMgr.inRelease) {
						uiscript.UIMgr.Inst.ShowErrorInfo(`${scene}协议[${key}]一分钟内请求了超过${checker.singleLimit}次,请检查代码`);
					}
					GameMgr.Inst.postInfo2Server(scene + "_rqs_count_error", errorInfo, false);
				}
			}
		}

		private static postInfo3Min(checker:SendSpeedChecker, scene:'lobby' | 'game' ) {
			if (checker.count > 0) {
				app.Log.log(`【NetAgent】 ${scene} Rqs Summary : ` + checker.count);
				GameMgr.Inst.postInfo2Server(scene + "_rqs_count_summary", {total: checker.count}, false);
			}
		}

		public static sendReq2Lobby(service_name: string, rpc_name: string, data: any, func_response: (error, res) => void): boolean {
			let _func_response = func_response
			if (rpc_name == 'startUnifiedMatch') {
				let mode_id = data.match_sid.split(':')[1];
				GameMgr.Inst.onPipeiYuyued(mode_id);
				_func_response = (error, res) => {
					if (error || res['error']) { 
						GameMgr.Inst.onPipeiYuyueCancelled(mode_id);
					}
					if (func_response) func_response(error, res)
				}
			} else if (rpc_name == 'cancelUnifiedMatch') {
				let mode_id = data.match_sid.split(':')[1];
				GameMgr.Inst.onPipeiYuyueCancelled(mode_id);
			}

			if (this.lobbySummary1Min.addItem(rpc_name) == 0 && this.lobbySummary3Min.addItem(rpc_name) == 0) {
				if (net.NetRouteGroup_Entrance.Inst) {
					net.NetRouteGroup_Entrance.Inst.sendRequest(service_name, rpc_name, data, _func_response);
				} else {
					net.NetRouteGroup.Inst.sendRequest(service_name, rpc_name, data, _func_response);
				}
				return true;
			} else {
				if (_func_response) _func_response("send too fast", null);
				return false;
			}
		}

		public static addListener2Lobby(name: string, handler: Laya.Handler) {
			handler.once = false;
			net.NetRouteGroup.Inst.addMsgListener('.lq.' + name, handler);
			if (net.NetRouteGroup_Entrance.Inst) {
				net.NetRouteGroup_Entrance.Inst.notifyHander.addHandler('.lq.' + name, handler);
			}
		}

		public static removeListener2Lobby(name: string, handler: Laya.Handler) {
			handler.once = false;
			net.NetRouteGroup.Inst.removeMsgListener('.lq.' + name, handler);
			if (net.NetRouteGroup_Entrance.Inst) {
				net.NetRouteGroup_Entrance.Inst.notifyHander.removeHandler('.lq.' + name, handler);
			}
		}

		public static sendReq2MJ(service_name: string, rpc_name: string, data: any, func_response: (error, res) => void): boolean {
			if (this.mjSummary1Min.addItem(rpc_name) == 0 && this.mjSummary3Min.addItem(rpc_name) == 0) {
				this.netRouteGroup_mj.sendRequest(service_name, rpc_name, data, func_response);
				return true;
			} else {
				if (func_response) func_response("send too fast", null);
				return false;
			}
		}

		public static addListener2MJ(name: string, handler: Laya.Handler) {
			handler.once = false;
			this.netRouteGroup_mj.addMsgListener('.lq.' + name, handler);
		}
	}
}