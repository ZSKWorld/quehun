module app {

    // 0-100:fb投放，1000-1100:google分析
    export enum EBehaviorType { 
        None, 
        CompleteRegistration, 
        CompleteTutorial,  
        Level_1, 
        Level_2, 
        Level_3, 
        Get_The_Title1, 
        Purchase_Click, 
        Purchase, 
        XinShouYinDao = 10,
    
        G_Role_create           = 1001, // 成功创建角色
        G_Role_login            = 1002, // 登录进所选服务器
        G_Role_logout           = 1003, // 角色离开服务器
        G_tutorial_complete     = 1004, // 完成新手引导
        G_Purchase              = 1005, // 成功充值
        G_Purchase_click        = 1006, // 点击充值相关按钮，辉玉，铜币等等
        G_Purchase_first        = 1007, // 历史上完成首次购买in-app purchase，排重
        G_Role_level_1          = 1008, // 初心1星
        G_Role_level_2          = 1009, // 初心2星
        G_Role_level_3          = 1010, // 初心3星
        G_Role_level_4          = 1011, // 雀士1星
        G_Role_level_5          = 1012, // 雀士2星
        G_Role_level_6          = 1013, // 雀士3星
        G_Role_level_7          = 1014, // 雀杰1星
        G_Role_level_8          = 1015, // 雀杰2星
        G_Role_level_9          = 1016, // 雀杰3星
        G_Role_level_10         = 1017, // 雀豪1星
        G_Role_level_11         = 1018, // 雀豪2星
        G_Role_level_12         = 1018, // 雀豪3星
        G_Role_level_13         = 1020, // 雀圣1星
        G_Role_level_14         = 1021, // 雀圣2星
        G_Role_level_15         = 1022, // 雀圣3星
        G_Role_level_16         = 1023, // 魂天
        G_get_title_1           = 1024, // 获得称号魂之契约者（充值6元）
        G_get_title_2           = 1025, // 获得称号魂之契约者（充值30元）
        G_get_title_3           = 1026, // 获得称号魂之契约者（充值60元）
        G_get_title_4           = 1027, // 获得称号魂之启迪者（充值100元）
        G_get_title_5           = 1028, // 获得称号魂之启迪者（充值250元）
        G_get_title_6           = 1029, // 获得称号魂之启迪者（充值500元）
        G_get_title_7           = 1030, // 获得称号魂之缔造者（充值1000元）
        G_get_title_8           = 1031, // 获得称号魂之缔造者（充值2000元）
        G_get_title_9           = 1032, // 获得称号魂之缔造者（充值3000元）
        G_get_title_10          = 1033, // 获得称号魂之超越者（充值4000元）
        G_get_title_11          = 1034, // 猫粮供应商（充值5000元）
        G_tutorial_jump         = 1035, // 跳过新手引导

        TW_Purchase             = 2001, // 付费
        TW_Signup               = 2002, // 注册
        TW_Tutorial_Completed   = 2003, // 新手引导结束

        Shilian_Reward          = 3001,
        Chunjie_Anim_Point      = 3002,

        Chara_Show_Star         = 3003, //寮舍是否只显示角色
        Recharge_Xieyi_Checked  = 3004, // 充值协议确认
        Chunjie_Yindao_Checked  = 3005, // 春节活动是否展示过新手引导
        event2403_followed      = 3006, // 2403主播活动是否已关注
        BA_Yindao_Checked       = 3008, // ba活动是否展示过新手引导
        HaiDao_Yindao_Checked = 3009, // 2406海岛活动是否展示过新手引导
        Spot_2408_Checked = 3010, // 2408剧情活动是否展示过新手引导
        Imas_Yindao_Checked = 3011, // 2411偶像大师活动是否展示过新手引导
        BA2501_Yindao_Checked = 3012, //2501春节庙会动是否展示过新手引导
        BA2501_LastEvent_Checked = 3013, //2501春节庙会动是否已完成最后一个事件
        BA2501_PlayCG_Checked = 3014, //2501春节庙会动是否展示过告别cg
        HF_Yindao_Checked = 3015, // 2404天之杯活动是否展示过新手引导
        YH_Yindao_Checked = 3016, // 2410银魂活动是否展示过新手引导
        SnowBall_Yindao_Checked = 3017, // 2412打雪仗是否展示过新手引导
        Marathon_2602_Checked = 3018, // 2602马拉松是否展示过 1.导入剧情 2.引导 3.导出剧情
        MMO_2604_Checked = 3019, // 2604剑域契约是否展示过新手引导
    };

    export class PlayerBehaviorStatistic {
        private static _datas: { [key: number]: number } = null;
        public static recharged_count = 0;
        public static unknownKey = 'unknown'

        public static init() {
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchClientValue', {}, (err, res: game.IResClientValue)=>{
                if (err || res['error']) {

                } else {
                    this._datas = {};
                    if (res.datas) {
                        for (let k in res.datas) {
                            this._datas[res.datas[k].key] = res.datas[k].value;
                        }
                    }
                    this.recharged_count = res.recharged_count;
                }
            });
        }

        private static _get_type_str (type:EBehaviorType): string {
            switch(type) {
                case EBehaviorType.CompleteRegistration: return 'CompleteRegistration';
                case EBehaviorType.CompleteTutorial: return 'CompleteTutorial';
                case EBehaviorType.Level_1: return 'Level_1';
                case EBehaviorType.Level_2: return 'Level_2';
                case EBehaviorType.Level_3: return 'Level_3';
                case EBehaviorType.Get_The_Title1: return 'Get_The_Title1';
                case EBehaviorType.Purchase_Click: return 'Purchase_Click';
                case EBehaviorType.Purchase: return 'Purchase';

                case EBehaviorType.G_Role_create:               return 'Role_create';
                case EBehaviorType.G_Role_login:                return 'Role_login';
                case EBehaviorType.G_tutorial_complete:         return 'tutorial_complete';
                case EBehaviorType.G_Purchase:                  return 'Purchase';
                case EBehaviorType.G_Purchase_click:            return 'Purchase_click';
                case EBehaviorType.G_Purchase_first:            return 'Purchase_first';
                case EBehaviorType.G_Role_level_1:              return 'Role_level_1';
                case EBehaviorType.G_Role_level_2:              return 'Role_level_2';
                case EBehaviorType.G_Role_level_3:              return 'Role_level_3';
                case EBehaviorType.G_Role_level_4:              return 'Role_level_4';
                case EBehaviorType.G_Role_level_5:              return 'Role_level_5';
                case EBehaviorType.G_Role_level_6:              return 'Role_level_6';
                case EBehaviorType.G_Role_level_7:              return 'Role_level_7';
                case EBehaviorType.G_Role_level_8:              return 'Role_level_8';
                case EBehaviorType.G_Role_level_9:              return 'Role_level_9';
                case EBehaviorType.G_Role_level_10:             return 'Role_level_10';
                case EBehaviorType.G_Role_level_11:             return 'Role_level_11';
                case EBehaviorType.G_Role_level_12:             return 'Role_level_12';
                case EBehaviorType.G_Role_level_13:             return 'Role_level_13';
                case EBehaviorType.G_Role_level_14:             return 'Role_level_14';
                case EBehaviorType.G_Role_level_15:             return 'Role_level_15';
                case EBehaviorType.G_Role_level_16:             return 'Role_level_16';
                case EBehaviorType.G_get_title_1:               return 'get_title_1';
                case EBehaviorType.G_get_title_2:               return 'get_title_2';
                case EBehaviorType.G_get_title_3:               return 'get_title_3';
                case EBehaviorType.G_get_title_4:               return 'get_title_4';
                case EBehaviorType.G_get_title_5:               return 'get_title_5';
                case EBehaviorType.G_get_title_6:               return 'get_title_6';
                case EBehaviorType.G_get_title_7:               return 'get_title_7';
                case EBehaviorType.G_get_title_8:               return 'get_title_8';
                case EBehaviorType.G_get_title_9:               return 'get_title_9';
                case EBehaviorType.G_get_title_10:              return 'get_title_10';
                case EBehaviorType.G_get_title_11:              return 'get_title_11';
                case EBehaviorType.G_tutorial_jump:             return 'tutorial_jump';

                case EBehaviorType.TW_Purchase:                 return 'o1xcs';
                case EBehaviorType.TW_Signup:                   return 'o1xcr';
                case EBehaviorType.TW_Tutorial_Completed:       return 'o1xcx';
            }
            return PlayerBehaviorStatistic.unknownKey;
        }

        public static fb_trace_force(type:EBehaviorType) {
            if (type < 0 || type > 100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            // if (window['fbq']) {
            //     window['fbq']('trackCustom', skey);
            // }
            // if (GameMgr.client_language == 'en') {
            //     var xhr = new Laya.HttpRequest();
            //     xhr.send('https://mjusgs.mahjongsoul.com:3002', `type=fb&key=${skey}&account=${GameMgr.Inst.account_id}&url=${GameMgr.Inst.link_url}`, "post");
            // }
        }

        public static fb_trace_pending(type:EBehaviorType, count:number) {
            if (!this._datas) return;
            if (type < 0 || type > 100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            let _send_count:number = 0;
            if (this._datas[type]) _send_count = this._datas[type];
            if (_send_count != count) {
                for (let i:number = 0; i < count - _send_count; i++) {
                    // if (window['fbq']) window['fbq']('track', skey);
                    // if (GameMgr.client_language == 'en') {
                    //     var xhr = new Laya.HttpRequest();
                    //     xhr.send('https://mjusgs.mahjongsoul.com:3002', `type=fb&key=${skey}&count=${count}&account=${GameMgr.Inst.account_id}&url=${GameMgr.Inst.link_url}`, "post");
                    // }
                }
                this.update_val(type, count);
            }
        }

        public static google_trace_force(type:EBehaviorType, callback = null) {
            // if (GameMgr.client_language != 'en') return null;
            if (type < 1000 || type >= 1100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            let called:boolean = false;
            let fn = (from_ga) => {
                if (called) return;
                called = true;
                if (callback) callback();
                if (from_ga) {
                    // if (GameMgr.client_language == 'en') {
                    //     let xhr = new Laya.HttpRequest();
                    //     xhr.send('https://mjusgs.mahjongsoul.com:3002', `type=ga_success&key=${skey}&account=${GameMgr.Inst.account_id}&url=${GameMgr.Inst.link_url}`, "post");
                    // }
                }
            };
            setTimeout(()=>{fn(false)}, 1000);
            if (window['gtag']) {
                window['gtag']('event', skey, {
                    'event_category': 'category0',
                    'event_label': 'label0',
                    'value': 1,
                    'event_callback': ()=>{
                        fn(true);
                    }
                });
            }
            // if (GameMgr.client_language == 'en') {
            //     let xhr = new Laya.HttpRequest();
            //     xhr.send('https://mjusgs.mahjongsoul.com:3002', `type=ga&key=${skey}&account=${GameMgr.Inst.account_id}&url=${GameMgr.Inst.link_url}`, "post");
            // }
        }

        public static google_trace_pending(type:EBehaviorType, count:number) {
            // if (GameMgr.client_language != 'en') return null;
            if (!this._datas) return;
            if (type < 1000 || type >= 1100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            let _send_count:number = 0;
            if (this._datas[type]) _send_count = this._datas[type];
            if (_send_count != count) {
                for (let i:number = 0; i < count - _send_count; i++) {
                    if (window['gtag']) {
                        window['gtag']('event', skey, {
                            'event_category': 'category0',
                            'event_label': 'label0',
                            'value': 'value0'
                        });
                    }
                    // if (GameMgr.client_language == 'en') {
                    //     var xhr = new Laya.HttpRequest();
                    //     xhr.send('https://mjusgs.mahjongsoul.com:3002', `type=ga&key=${skey}&count=${count}&account=${GameMgr.Inst.account_id}&url=${GameMgr.Inst.link_url}`, "post");
                    // }
                }
                this.update_val(type, count);
            }
        }

        public static tw_trace_force(type:EBehaviorType) {
            if (type < 2000 || type > 2100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            if (window['twttr'] && window['twttr'].conversion && window['twttr'].conversion.trackPid) {
                window['twttr'].conversion.trackPid(skey, { tw_sale_amount: 0, tw_order_quantity: 0 });
            }
        }

        public static tw_trace_pending(type:EBehaviorType, count:number) {
            if (!this._datas) return;
            if (type < 2000 || type > 2100) return; // 数值不对
            let skey:string = this._get_type_str(type);
            if (skey == PlayerBehaviorStatistic.unknownKey) return;
            let _send_count:number = 0;
            if (this._datas[type]) _send_count = this._datas[type];
            if (_send_count != count) {
                for (let i:number = 0; i < count - _send_count; i++) {
                    if (window['twttr'] && window['twttr'].conversion && window['twttr'].conversion.trackPid) {
                        window['twttr'].conversion.trackPid(skey, { tw_sale_amount: 0, tw_order_quantity: 0 });
                    }
                }
                this.update_val(type, count);
            }
        }

        public static get_val(type:EBehaviorType): number {
            if (!this._datas) return 0;
            if (this._datas[type]) return this._datas[type];
            return 0;
        }

        public static update_val(type:EBehaviorType, value:number) {
            if (!this._datas) return;
            this._datas[type] = value;
            // 和服务器同步次数
            app.NetAgent.sendReq2Lobby('Lobby', 'updateClientValue', { key: type, value: value}, () => {});
        }
    }
}
