/**
* name 
*/
module app {
	// 字典树的节点
	interface iTree {
		code:number; //当前字符的code
		str:string;
		isEnd:boolean;
		childs:Object;
		id:number;
	}

	// 字典树
	class WordTree {
		private tree:iTree = null;
		private count:number = 0;

		public constructor(words:Array<{s:string, id:number}>) {
			this.tree = {
				code: 0,
				str:'',
				isEnd: false,
				childs: {},
				id:0,
			};
			this.count = 1;
			for (let i:number = 0; i < words.length; i++) {
				this._add_word(words[i].s, words[i].id);
			}
		}

		// 添加屏蔽字
		private _add_word(word:string, id:number) {
			if (!word || word == '') return;
			let _root:iTree = this.tree;
			for (let j:number = 0; j < word.length; j++) {
				let _c:string = word.charAt(j);
				if (!_root.childs[_c]) {
					_root.childs[_c] = {
						code: _c.charCodeAt(0),
						str: word.substr(0, j + 1),
						isEnd: false,
						childs: {},
						id: 0
					}
					this.count++;
				}
				_root = _root.childs[_c];
			}
			_root.isEnd = true;
			_root.id = id;
		}

		public get tree_count() { return this.count; }

		// 动态增加屏蔽字，考虑到性能问题如果节点超过10w个就停止增加，返回false，需要人工再检查
		public add_extra_word(word:string):boolean {
			if (Taboo.test(word)) return true;
			if (this.count > 100000) return false;
			this._add_word(word, 999999);
			return true;
		}

		// 动态删除屏蔽字，尽量不要删除基础的屏蔽字，因为有剪枝，基础的有些已经被过滤了
		public remove_extra_word(word:string) {
			let _root:iTree = this.tree;
			for (let j:number = 0; j < word.length; j++) {
				let _c:string = word.charAt(j);
				if (_root.childs[_c]) {
					_root = _root.childs[_c];
				} else {
					return;
				}
			}
			_root.isEnd = false;
			_root.id = 0;
		}

		// 以子序列方式匹配
		public test_zixulie(word:string):{s:string, id:number} {
			let poss:Array<iTree> = [];
			poss.push(this.tree);
			let in_map:Object = {};
			for (let i:number = 0; i < word.length; i++) {
				let c:string = word.charAt(i);
				let n:number = poss.length;
				for (let j:number = 0; j < n; j++) {
					let node:iTree = poss[j];
					if (node !== this.tree && in_map[node.str] + 10 < i) continue;
					if (node.childs[c]) {
						let _nd:iTree = node.childs[c];
						if (_nd.isEnd) {
							return {s: _nd.str, id: _nd.id};
						}
						if (!in_map.hasOwnProperty(_nd.str)) {
							in_map[_nd.str] = i;
							poss.push(_nd);
						} else {
							in_map[_nd.str] = i;
						}
					}
				}
			}
			return null;
		}

		// 以子串方式匹配
		public test_zichuan(word:string):{s:string, id:number} {
			let poss:Array<iTree> = [];
			poss.push(this.tree);
			let m:number = 0;
			for (let i:number = 0; i < word.length; i++) {
				let c:string = word.charAt(i);
				let n:number = poss.length;
				let _poss:Array<iTree> = [];
				_poss.push(this.tree);
				for (let j:number = 0; j < n; j++) {
					let node:iTree = poss[j];
					m++;
					if (node.childs[c]) {
						let _nd:iTree = node.childs[c];
						if (_nd.isEnd) {
							return {s:_nd.str, id: _nd.id};
						}
						_poss.push(_nd);
					}
				}
				poss = _poss;
			}
			return null;
		}
	}

	// 屏蔽词管理器
	export class Taboo {

		private static tree_zixulie:WordTree; 	// 子序列字典树
		private static tree_zichuan:WordTree;	// 子串字典树
		private static near_char_father:Object; // 形近字a-father(a)，并查集

		// 查找形近字
		private static _find_near_char(c:string):string {
			if (!this.near_char_father[c] || this.near_char_father[c] == c) return c;
			this.near_char_father[c] = this._find_near_char(this.near_char_father[c]);
			return this.near_char_father[c];
		}
		
		// 构建形近字并查集
		private static _build_near_char(near_char:Array<Array<string>>) {
			this.near_char_father = {};
			for (let i:number = 0; i < near_char.length; i++) {
				let lst = near_char[i];
				for (let j:number = 0; j < lst.length; j++) {
					let c:string = lst[j];
					let fa:string = this._find_near_char(c);
					if (j > 0) {
						this.near_char_father[fa] = this._find_near_char(lst[0]);
					}
				}
			}
		}

		// 删除标点符号只留下小写、数字和中日韩文
		private static _remove_biaodian(str:string):string {
			if (GameMgr.client_type != 'chs_t') return str;
			let code_0:number = '0'.charCodeAt(0);
			let code_a:number = 'a'.charCodeAt(0);
			str = str.toLowerCase();
			let _str:string = '';
			for (let i:number = 0; i < str.length; i++) {
				let _code:number = str.charCodeAt(i);
				if (_code > 256 || (_code >= code_a && _code < code_a + 26) || (_code >= code_0 && _code < code_0 + 10)) {
					_str += str.charAt(i);
				}
			}
			return _str;
		}

		// 字符串标准化
		private static _normalize_str(str:string):string {
			let code_0:number = '0'.charCodeAt(0);
			let code_a:number = 'a'.charCodeAt(0);
			str = str.toLowerCase();
			let _str:string = '';
			for (let i:number = 0; i < str.length; i++) {
				let _code:number = str.charCodeAt(i);
				if (_code > 256 || (_code >= code_a && _code < code_a + 26) || (_code >= code_0 && _code < code_0 + 10)) {
					_str += this._find_near_char(str.charAt(i));
				}
			}
			return _str;
		}

		// 外部初始化
		public static init(words:Array<{s:string, near:number, type:number}>, near_char:Array<Array<string>>) {
			this._build_near_char(near_char);
			// 先子序列再子串，否则子序列可能会被子串判掉导致子序列内容不全

			let words_zixulie:Array<{s:string, id:number}> = [];
			let words_zichuan:Array<{s:string, id:number}> = [];
			for (let i:number = 0; i < words.length; i++) {
				if (words[i].near) words[i].s = this._normalize_str(words[i].s);
				else words[i].s = this._remove_biaodian(words[i].s);
				if (words[i].type) words_zixulie.push({s: words[i].s, id: i + 3});
				else words_zichuan.push({s: words[i].s, id: i + 3});
			}
			this.tree_zixulie = new WordTree(words_zixulie);
			// console.log('子序列字典树count：' + this.tree_zixulie.tree_count);
			this.tree_zichuan = new WordTree(words_zichuan);
			// console.log('子串字典树count:' + this.tree_zichuan.tree_count);
		}

		// 动态增加屏蔽字，考虑到性能问题如果节点超过10w个就停止增加，返回false，需要人工再检查, type:1=子序列，其他=子串
		public static add_extra_word(word:string, type:number):boolean {
			word =  this._remove_biaodian(word);
			if (this.test(word)) return true;
			if (type == 1) return this.tree_zixulie.add_extra_word(word);
			else return this.tree_zichuan.add_extra_word(word);
		}

		// 动态删除屏蔽字，尽量不要删除基础的屏蔽字，因为有剪枝，基础的有些已经被过滤了, type:1=子序列，其他=子串
		public static remove_extra_word(word:string, type:number) {
			word = this._remove_biaodian(word);
			if (type == 1) this.tree_zixulie.remove_extra_word(word);
			else this.tree_zichuan.remove_extra_word(word);
		}

		// 测试是否有屏蔽字，null=无屏蔽字
		public static test(str:string):{s:string, id:number} {
			str = this._remove_biaodian(str);
			let ret:{s:string, id:number} = null;
			if (this.tree_zichuan) {
				ret = this.tree_zichuan.test_zichuan(str);
			}
			if (ret) return ret;
			if (this.tree_zixulie) {
				ret = this.tree_zixulie.test_zixulie(str);
			}
			if (ret) return ret;
			let str2:string = this._normalize_str(str);
			if (str2 != str) {
				if (this.tree_zichuan) {
					ret = this.tree_zichuan.test_zichuan(str2);
				}
				if (ret) return ret;
				if (this.tree_zixulie) {
					ret = this.tree_zixulie.test_zixulie(str2);
				}
				if (ret) return ret;
			}
			return null;
		}
	}
}