module game {
    // post用
    export class Tracker {
        private _url: string;
        private _httpRequest: any;
        private _handler: any;

        public constructor(host: string, project: string, logstore: string) {
            this._url = 'https://' + project + '.' + host + '/logstores/' + logstore + '/track';
            this._httpRequest = this.createHttpRequest();
            this._handler = null;
        }

        public logger(data: any) {
            let { _url, _httpRequest } = this;
            var k = 0;

            // while (_params.length > 0) {
            //     if (k % 2 == 0)
            //         _url += '&' + encodeURIComponent(_params.shift());
            //     else
            //         _url += '=' + encodeURIComponent(_params.shift());
            //     ++k;
            // }
            try {
                // _httpRequest.open("GET", _url, true);
                // _httpRequest.send(null);
                _httpRequest.open('post', _url);
                _httpRequest.setRequestHeader('x-log-apiversion', '0.6.0');
                _httpRequest.setRequestHeader('x-log-bodyrawsize', '1234');
                _httpRequest.send(JSON.stringify({ __source__: 'client', __logs__: [this.data2AliData(data)] }));
                // var xhr = new Laya.HttpRequest();
                // xhr.send(_url, data, 'post', 'x-log-apiversion: 0.6.0');
            }
            catch (ex) {
                if (window && window.console && typeof window.console.log === 'function') {
                    console.log("Failed to log to ali log service because of this exception:\n" + ex);
                    console.log("Failed log data:", _url);
                }
            }
        }
        private createHttpRequest() {
            if (window.ActiveXObject)
                return new ActiveXObject("Microsoft.XMLHTTP");
            else if (window.XMLHttpRequest)
                return new XMLHttpRequest();
            return null;
        }

        // 阿里云日志需要所有value都是string类型.否则会400
        private data2AliData(data: any, keepNull = false): any {
            if (typeof (data) == 'object') {
                let d = {};
                for (let k in data) {
                    let v: any = data[k];
                    if (keepNull || (v != null && v != undefined)) {
                        d[k] = JSON.stringify(v);
                    }
                }
                return d;
            } else {
                return data.toString();
            }
        }
    }
}