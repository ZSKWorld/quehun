/**
* name 
*/
module anim{
	export class Bling extends Laya.Script{
	
		private mat:Laya.BlinnPhongMaterial = null;
		public tick:number = 2000;
		private lasttime:number = 0;
		
		constructor(){
			super();
		}

		public _load (owner:Laya.Sprite3D): void {
			this.mat = (owner as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
			this.lasttime = 0;
			Laya.timer.frameLoop(1, this, this.update);
		}

		public update() {
			if (this.destroyed) {
				Laya.timer.clearAll(this);
				return ;
			}
			if (!this.enable){
				this.lasttime = 0;
				return;
			}
			let t:number = Laya.timer.currTimer - this.lasttime;
			if (t >= this.tick) {
				t = 0;
				this.lasttime = Laya.timer.currTimer;
			}
			let rate:number = 0;
			if (t < this.tick / 2) {
				rate = t * 2 / this.tick;
			} else {
				rate = 1 - ((t - this.tick / 2) / (this.tick / 2));
			}
			let color:Laya.Vector4 = this.mat.albedoColor.clone();
			color.w = 1 - rate;
			//color.x = color.y = color.z = (1 - rate)*0.5 + 0.5;
			this.mat.albedoColor = color;
		}
	}
}