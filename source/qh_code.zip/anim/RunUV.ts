/**
* name 
*/
module anim {
	export class RunUV extends Laya.Script{
		
		private static tilingOffset:Laya.Vector4 = new Laya.Vector4(0.8,0.2,0,0);
		private static lastupdateframe:number = 0;
		private static lastupdatetime: number = 0;
		private static v:number = 0;
		private static __v: number = 0;

		private mat:Laya.BlinnPhongMaterial = null;
		
		constructor(){
			super();
		}

		public _load (owner:Laya.Sprite3D): void {
			this.mat = (owner as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
			this.update();
			Laya.timer.frameLoop(1, this, this.update);
		}

		public update() {
			if (this.destroyed) {
				Laya.timer.clearAll(this);
				return ;
			}
			if (!this.enable) return;
			if (RunUV.lastupdateframe < Laya.timer.currFrame) {
				if (RunUV.lastupdateframe < Laya.timer.currFrame - 10) {
					RunUV.lastupdateframe = Laya.timer.currFrame;
					RunUV.lastupdatetime = Laya.timer.currTimer;
				} else {
					RunUV.lastupdateframe = Laya.timer.currFrame;
					let dt:number = (Laya.timer.currTimer - RunUV.lastupdatetime) / 1000;
					if (RunUV.tilingOffset.w >= -0.35) {
						RunUV.v += dt * 2.2;
					} else if (RunUV.tilingOffset.w >= -0.65) {
						RunUV.v -= dt * 1.6;
						if (RunUV.v < 0.1) RunUV.v = 0.1;
					} else {
						RunUV.v = 0.3;
					}
					if (RunUV.__v != 0) {
						RunUV.v = RunUV.__v;
					}
					
					RunUV.tilingOffset.w -= RunUV.v * dt ;
					if (RunUV.tilingOffset.w < -1) {
						RunUV.tilingOffset.w = -0.1;
						RunUV.v = 0;
					} 
					
					RunUV.lastupdatetime = Laya.timer.currTimer;
				}
			}

			this.mat.tilingOffset = RunUV.tilingOffset.clone();
		}


	}
}