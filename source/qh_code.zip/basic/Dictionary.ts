module basic {
    export class Dictionary<TKey, TValue> {
        private items: { [key: string]: TValue } = {};
        private count: number = 0;
    
        constructor(initialValues?: Array<[TKey, TValue]>) {
            if (initialValues) {
                initialValues.forEach(([key, value]) => this.set(key, value));
            }
        }
    
        public set(key: TKey, value: TValue): void {
            const keyStr = JSON.stringify(key);
            if (!this.items.hasOwnProperty(keyStr)) {
                this.count++;
            }
            this.items[keyStr] = value;
        }
    
        public get(key: TKey): TValue | undefined {
            return this.items[JSON.stringify(key)];
        }
    
        public has(key: TKey): boolean {
            return this.items.hasOwnProperty(JSON.stringify(key));
        }
    
        public remove(key: TKey): boolean {
            const keyStr = JSON.stringify(key);
            if (this.items.hasOwnProperty(keyStr)) {
                delete this.items[keyStr];
                this.count--;
                return true;
            }
            return false;
        }
    
        public getCount(): number {
            return this.count;
        }
    
        public keys(): TKey[] {
            return Object.keys(this.items).map(key => JSON.parse(key));
        }
    
        public values(): TValue[] {
            return Object.keys(this.items).map(key => this.items[key]);
        }
    
        public clear(): void {
            this.items = {};
            this.count = 0;
        }

      
    }
}