/**
* name 
*/
module basic{
	export class Pair<TKey,TVal> {
		public key:TKey = null;
		public val:TVal = null;
	}
}