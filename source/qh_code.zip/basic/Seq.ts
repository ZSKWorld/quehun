/**
* name 
*/
module basic{
	export class Seq<T> extends Array<T>{
		constructor(){
			super();
		}

		public Clone(): Seq<T> {
			let ret: Seq<T> = new Seq<T>();
			for (let i:number = 0; i < this.length; i++) {
				ret.push(this[i]);
			}
			return ret;
		}

		public RemoveAt(index: number): T {
			if (index < 0 || index >= this.length) return;
			let tmp:T = this[index];
			this[index] = this[this.length - 1];
			this[this.length - 1] = tmp;
			return this.pop();
		}

		public RemoveX(value:T): Seq<T> {
			for (let i:number = 0; i < this.length; i++) {
				if (this[i] === value) {
					this.RemoveAt(i);
					break;
				}
			}
			return this;
		}
	}
}