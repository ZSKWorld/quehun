module caps {
    enum ECodeJumpType { none, _return, _break, _continue } // 代码跳过执行的返回类型，return:代码返回，break:跳出loop，continue：进入下一个loop

    export class CodeReturnValue {
        public jumpType: ECodeJumpType = ECodeJumpType.none;
        public value: CapsValue = new CapsValue(EValueType.unknow, null);
    }

    export class CapsLanVM {
        public static CurrentVM: CapsLanVM = new CapsLanVM();
        private vars: { [index: string]: any } = {};

        constructor() {
            CapsLanVM.CurrentVM = this;
        }

        public GetVar(varName: string) {
            if (this.vars[varName] != null) {
                return this.vars[varName];
            }
            return null;
        }

        public static GetOperatorPriority(str: string): number {
            switch (str) {
                case '__lineEnd__': return -99999;          // 最低优先级，用来触发前面所有的计算
                case ',': return -1000;
                case '=': return 1000;
                case 'or': return 2000;
                case 'and': return 2001;
                case 'not': return 2002;
                case '==':
                case '!=': return 3000;
                case '<':
                case '<=':
                case '>':
                case '>=': return 4000;
                case '+':
                case '-': return 5000;
                case '*':
                case '/':
                case '%': return 5001;
                case '+=':
                case '-=':
                case '*=':
                case '/=':
                case '%=': return 5002;
                default: return -1;
            }
        }

        // 脚本内置函数
        private DoFunction(functionName: string, args: Array<CapsValue>): CapsValue {
            if (functionName == 'print') {
                if (args.length != 1) {
                    app.Log.log('print参数数量不对:' + args.length);
                }
                app.Log.log('<脚本内打印>: ' + args[0].GetRuntimeValue().ToString());
                return null;
            } else if (functionName == 'abs') {
                if (args.length != 1) {
                    app.Log.log('abs参数数量不对:' + args.length);
                    return null;
                }
                let v: number = Math.abs(args[0].GetRuntimeValue().GetFloatValue());
                return new CapsValue(EValueType.number, v);
            } else if (functionName == 'random') {
                if (args.length != 0) {
                    app.Log.log('random参数数量不对:' + args.length);
                    return null;
                }
                return new CapsValue(EValueType.number, Math.random());
            } else if (functionName == 'len') {
                if (args.length != 1) {
                    app.Log.log('len参数数量不对:' + args.length);
                    return null;
                }
                return new CapsValue(EValueType.number, args[0].GetRuntimeValue().GetLength());
            } else if (functionName == 'push') {
                if (args.length != 2) {
                    app.Log.log('push参数数量不对:' + args.length);
                    return null;
                }
                args[0].GetRuntimeValue().AddItem(args[1]);
                return args[0].GetRuntimeValue();
            } else if (functionName == 'insert') {
                if (args.length != 3) {
                    app.Log.log('insert参数数量不对:' + args.length);
                    return null;
                }
                args[0].GetRuntimeValue().Insert(args[1].GetFloatValue(), args[2]);
                return args[0].GetRuntimeValue();
            } else if (functionName == 'removeAt') {
                if (args.length != 2) {
                    app.Log.log('push参数数量不对:' + args.length);
                    return null;
                }
                args[0].GetRuntimeValue().RemoveAt(args[1].GetFloatValue());
                return args[0].GetRuntimeValue();
            }
            app.Log.log('不认识的function:' + functionName);
            return null;
        }

        private DoCodeTree(words: Array<Word>, tree: CodeTree): CodeReturnValue {
            if (tree.type == CodeTreeType.codeBlock) {
                let ret: CodeReturnValue = new CodeReturnValue();
                for (let i = 0; i < tree.sons.length; i++) {
                    ret = this.DoCodeTree(words, tree.sons[i]);
                    if (ret != null && ret.jumpType != ECodeJumpType.none) {
                        return ret;
                    }
                }
                return ret;
            } else if (tree.type == CodeTreeType._if) {
                if (tree.sons.length < 2) {
                    app.Log.log('语法错误3001, $[{words[tree.wordStartIndex].lineIndex}, {words[tree.wordStartIndex].charIndex}]处的if语句不合法');
                    return null;
                }
                let condition: CodeReturnValue = this.DoCodeTree(words, tree.sons[0]);
                if (condition == null) {
                    app.Log.log('语法错误3002, $[{words[tree.wordStartIndex].lineIndex}, {words[tree.wordStartIndex].charIndex}]处的if条件无法判断');
                }
                if (condition.jumpType != ECodeJumpType.none) {
                    app.Log.log('语法错误3003, $[{words[tree.wordStartIndex].lineIndex}, {words[tree.wordStartIndex].charIndex}]处的if条件不应该会返回jumpType');
                }
                let isTrue: boolean = false;
                try {
                    isTrue = condition.value.GetItem(0).GetBoolValue();
                } catch {
                    app.Log.log('语法错误3004, $[{words[tree.wordStartIndex].lineIndex}, {words[tree.wordStartIndex].charIndex}]处的if条件无法判断类型');
                }
                let actionReturn: CodeReturnValue = new CodeReturnValue();
                if (isTrue) {
                    actionReturn = this.DoCodeTree(words, tree.sons[1]);
                } else {
                    if (tree.sons.length == 3) {
                        actionReturn = this.DoCodeTree(words, tree.sons[2]);
                    }
                }
                return actionReturn;
            } else if (tree.type == CodeTreeType._loop) {
                let isBreak: boolean = false;
                let loopMaxLimit: number = 100000000; // 防止死循环，加了个1亿次循环的上限，碰到了就报错
                while (true) {
                    if (loopMaxLimit == 0) {
                        app.Log.log('语法错误3011, $[{words[tree.wordStartIndex].lineIndex}, {words[tree.wordStartIndex].charIndex}]处的loop次数过多，疑似死循环');
                    }
                    loopMaxLimit--;
                    for (let i = 0; i < tree.sons.length; i++) {
                        let ret: CodeReturnValue = this.DoCodeTree(words, tree.sons[i]);
                        if (ret != null) {
                            if (ret.jumpType == ECodeJumpType._return) {
                                return ret;
                            } else if (ret.jumpType == ECodeJumpType._break) {
                                isBreak = true;
                                break;
                            } else if (ret.jumpType == ECodeJumpType._continue) {
                                break;
                            }
                        }
                    }
                    if (isBreak) break;
                }
                return null;
            } else if (tree.type == CodeTreeType._continue) {
                let ret: CodeReturnValue = new CodeReturnValue();
                ret.jumpType = ECodeJumpType._continue;
                return ret;
            } else if (tree.type == CodeTreeType._break) {
                let ret: CodeReturnValue = new CodeReturnValue();
                ret.jumpType = ECodeJumpType._break;
                return ret;
            } else if (tree.type == CodeTreeType.phrase) {
                if (tree.phraseWords.length == 0) {
                    let ret: CodeReturnValue = new CodeReturnValue();
                    ret.jumpType = ECodeJumpType.none;
                    ret.value = new CapsValue(EValueType._list, []);
                    return ret;
                }

                let values: Array<CapsValue> = [];
                let operators: Array<string> = [];
                let singleOperator: string = ''; // 单目运算符，后面必须立刻跟一个值，再跟操作符视为错误
                let preIsOperator: boolean = true;
                let lineIndex: number = 0;
                let charIndex: number = 0;

                let insertValue = (value: CapsValue) => {
                    if (singleOperator != '') {
                        if (singleOperator == '+') {
                            if (value.type != EValueType.number) {
                                app.Log.log(`语法错误3071, [${lineIndex}, ${charIndex}]处的单目操作符${singleOperator}后面不是数字`);
                                return;
                            }
                            values.push(value);
                        } else if (singleOperator == '-') {
                            if (value.type != EValueType.number) {
                                app.Log.log(`语法错误3072, [${lineIndex}, ${charIndex}]处的单目操作符${singleOperator}后面不是数字`);
                                return;
                            }
                            values.push(new CapsValue(EValueType.number, -value.GetFloatValue()));
                        } else if (singleOperator == 'not') {
                            values.push(new CapsValue(EValueType._bool, !value.GetBoolValue()));
                        } else {
                            app.Log.log(`语法错误3070, [${lineIndex}, ${charIndex}]处的单目操作符` + singleOperator + '不合法');
                            return;
                        }
                        singleOperator = '';
                    } else if (!preIsOperator) {
                        app.Log.log(`语法错误3071, [${lineIndex}, ${charIndex}]处的连续两个值中间没有操作符`);
                        return;
                    } else {
                        values.push(value);
                    }
                    preIsOperator = false;
                };

                let insertOperator = (strOperator: string) => {
                    if (singleOperator != '') {
                        app.Log.log(`语法错误3100, [${lineIndex}, ${charIndex}]处有单目运算法符后面不应该带有操作符`);
                        return;
                    }
                    if (preIsOperator) {
                        if (strOperator == '-') {
                            singleOperator = '-';
                            return;
                        }

                        app.Log.log(`语法错误3101, [${lineIndex}, ${charIndex}]处不应该连续有两个操作符`);
                        return;
                    }
                    let priority: number = CapsLanVM.GetOperatorPriority(strOperator);
                    while (operators.length > 0 && CapsLanVM.GetOperatorPriority(operators[operators.length - 1]) > priority) {
                        if (values.length < 2) {
                            app.Log.log(`运行时错误110005, [${lineIndex}, ${charIndex}]前面的逻辑运算数值不够了`);
                            return;
                        }
                        let v1 = values.pop();
                        if (v1 == null) {
                            app.Log.log(`运行时错误110003, [${lineIndex}, ${charIndex}]存在无效v1`);
                            return;
                        }

                        let v0 = values.pop();
                        if (v0 == null) {
                            app.Log.log(`运行时错误110004, [${lineIndex}, ${charIndex}]存在无效v0`);
                            return;
                        }

                        let sOp = operators.pop();
                        preIsOperator = true;
                        if (sOp == '=') { // 赋值语句
                            if (v0.type != EValueType._var) {
                                app.Log.log(`运行时错误110001, [${lineIndex}, ${charIndex}]赋值语句存在无效左值`);
                                return;
                            }
                            if (v1.type == EValueType._var && CapsLanVM.CurrentVM.vars[v1.GetVarName()] == null) {
                                app.Log.log(`运行时错误110002, [${lineIndex}, ${charIndex}]赋值语句使用了未声明的变量:` + v1.GetVarName());
                                return;
                            }
                            CapsLanVM.CurrentVM.vars[v0.GetVarName()] = v1;
                            values.push(v1);
                        }
                        else if (sOp == '+=') {
                            let newValue: CapsValue;
                            if (v0.type != EValueType._var) {
                                app.Log.log(`运行时错误110009, [${lineIndex}, ${charIndex}]赋值语句存在无效左值`);
                                return;
                            }

                            if (v1.type == EValueType._var) {
                                if (CapsLanVM.CurrentVM.vars[v1.GetVarName()] == null) {
                                    app.Log.log(`运行时错误110010, [${lineIndex}]语句使用了未声明的变量:` + v1.GetVarName());
                                    return;
                                }

                                v1 = CapsLanVM.CurrentVM.vars[v1.GetVarName()] as CapsValue;
                            }

                            if (v1.type != EValueType._var && v1.type != EValueType.number && v1.type != EValueType.str) {
                                app.Log.log(`运行时错误110011, [${lineIndex}, ${charIndex}]错误的右值类型`);
                                return;
                            }

                            if (v1.type == EValueType.str) {
                                newValue = new CapsValue(EValueType.str, v0.GetStringValue() + v1.GetStringValue());
                            }
                            else {
                                newValue = new CapsValue(EValueType.number,
                                    v0.GetFloatValue() + v1.GetFloatValue());
                            }

                            CapsLanVM.CurrentVM.vars[v0.GetVarName()] = newValue;
                        }
                        else if (sOp == '-=' || sOp == '*=' || sOp == '/=' || sOp == '%=') {
                            let newValue: CapsValue;
                            if (v0.type != EValueType._var) {
                                app.Log.log(`运行时错误110012, [${lineIndex}, ${charIndex}]赋值语句存在无效左值`);
                                return;
                            }

                            if (v1.type != EValueType._var && v1.type != EValueType.number) {
                                app.Log.log(`运行时错误110013, [${lineIndex}, ${charIndex}]错误的右值类型`);
                                return;
                            }

                            if (v1.type == EValueType._var) {
                                if (CapsLanVM.CurrentVM.vars[v1.GetVarName()] == null) {
                                    app.Log.log(`运行时错误110014, [${lineIndex}]语句使用了未声明的变量:` + v1.GetVarName());
                                    return;
                                }

                                v1 = CapsLanVM.CurrentVM.vars[v1.GetVarName()] as CapsValue;
                            }

                            if (sOp == '-=') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() - v1.GetFloatValue());
                                CapsLanVM.CurrentVM.vars[v0.GetVarName()] = newValue;
                            }
                            else if (sOp == '*=') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() * v1.GetFloatValue());
                                CapsLanVM.CurrentVM.vars[v0.GetVarName()] = newValue;
                            }
                            else if (sOp == '/=') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() / v1.GetFloatValue());
                                CapsLanVM.CurrentVM.vars[v0.GetVarName()] = newValue;
                            }
                            else if (sOp == '%=') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() % v1.GetFloatValue());
                                CapsLanVM.CurrentVM.vars[v0.GetVarName()] = newValue;
                            }
                        }
                        else {
                            // 普通二目运算符
                            if (v0.type == EValueType._var) {
                                if (CapsLanVM.CurrentVM.vars[v0.GetVarName()] == null) {
                                    app.Log.log(`运行时错误110006, [${lineIndex}]语句使用了未声明的变量:` + v0.GetVarName());
                                    return;
                                }
                                v0 = CapsLanVM.CurrentVM.vars[v0.GetVarName()] as CapsValue;
                            }
                            if (v1.type == EValueType._var) {
                                if (CapsLanVM.CurrentVM.vars[v1.GetVarName()] == null) {
                                    app.Log.log(`运行时错误110007, [${lineIndex}]语句使用了未声明的变量:` + v1.GetVarName());
                                    return;
                                }
                                v1 = CapsLanVM.CurrentVM.vars[v1.GetVarName()] as CapsValue;
                            }
                            let newValue: CapsValue = new CapsValue(EValueType.unknow, null);
                            if (sOp == 'and') {
                                newValue = new CapsValue(EValueType._bool, v0.GetBoolValue() && v1.GetBoolValue());
                            }
                            else if (sOp == 'or') {
                                newValue = new CapsValue(EValueType._bool, v0.GetBoolValue() || v1.GetBoolValue());
                            }
                            else if (sOp == '==') {
                                newValue = new CapsValue(EValueType._bool, CapsValue.Equal(v0, v1));
                            }
                            else if (sOp == '!=') {
                                newValue = new CapsValue(EValueType._bool, !CapsValue.Equal(v0, v1));
                            }
                            else if (sOp == '<') {
                                newValue = new CapsValue(EValueType._bool, !CapsValue.Equal(v0, v1) && !CapsValue.BiggerThan(v0, v1));
                            }
                            else if (sOp == '<=') {
                                newValue = new CapsValue(EValueType._bool, !CapsValue.BiggerThan(v0, v1));
                            }
                            else if (sOp == '>') {
                                newValue = new CapsValue(EValueType._bool, CapsValue.BiggerThan(v0, v1));
                            }
                            else if (sOp == '>=') {
                                newValue = new CapsValue(EValueType._bool, CapsValue.BiggerThan(v0, v1) || CapsValue.Equal(v0, v1));
                            }
                            else if (sOp == '+') {
                                if (v0.type == EValueType.str || v1.type == EValueType.str) {
                                    newValue = new CapsValue(EValueType.str, v0.GetStringValue() + v1.GetStringValue());
                                }
                                else {
                                    newValue = new CapsValue(EValueType.number, v0.GetFloatValue() + v1.GetFloatValue());
                                }
                            }
                            else if (sOp == '-') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() - v1.GetFloatValue());
                            }
                            else if (sOp == '*') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() * v1.GetFloatValue());
                            }
                            else if (sOp == '/') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() / v1.GetFloatValue());
                            }
                            else if (sOp == '%') {
                                newValue = new CapsValue(EValueType.number, v0.GetFloatValue() % v1.GetFloatValue());
                            }
                            else {
                                app.Log.log(`语法错误3105, [${lineIndex}]语句使用了不支持的操作符:` + sOp);
                                return;
                            }
                            values.push(newValue);
                        }

                    }
                    operators.push(strOperator);
                    preIsOperator = true;

                };

                let args: Array<CapsValue> = [];    // 多个返回值，只有当函数的时候，用','分割出来多个参数的情况

                let onRunEnd = (op: string) => {
                    insertOperator(op);
                    if (operators.length != 1 || singleOperator != '') { // 最后只能留一个__lineEnd__或者,
                        app.Log.log(`语法错误3117, [${lineIndex}]结尾有未运算的操作符`);
                        return;
                    }
                    if (values.length == 1) {
                        if (values[0] != null) {
                            args.push(values[0].Clone());
                        }
                    } else if (values.length > 1) {
                        app.Log.log(`语法错误3118, [${lineIndex}]还有数值没有计算完成`);
                        return;
                    } else {
                        if (op == ',') {
                            app.Log.log(`语法错误3119, [${lineIndex}]逗号前不能为空`);
                            return;
                        }
                    }
                    singleOperator = '';
                    preIsOperator = true;
                    values = [];
                    operators = [];
                };

                for (let i = 0; i < tree.phraseWords.length; i++) {
                    let pw: PhraseWord = tree.phraseWords[i];
                    if (pw.isCodeTree) {
                        let startOperator: string = words[pw.codeTree.wordStartIndex].strValue;
                        let ret: CodeReturnValue = this.DoCodeTree(words, pw.codeTree);
                        if (ret == null) {
                            app.Log.log(`语法错误3021, [${lineIndex}, ${charIndex}]处的没有正确的计算值`);
                            return null;
                        }
                        if (ret.jumpType != ECodeJumpType.none) {
                            app.Log.log(`语法错误3022, [${lineIndex}, ${charIndex}]处的不应该有跳出符`);
                            return null;
                        }
                        if (ret.value.type != EValueType._list) {
                            app.Log.log(`语法错误3023, [${lineIndex}, ${charIndex}]处的计算值无效`);
                            return null;
                        }
                        let retArgs = ret.value.value;

                        if (startOperator == '(') {
                            if (preIsOperator) { // 运算符
                                if (retArgs.length != 1) {
                                    app.Log.log(`语法错误3024, [${lineIndex}, ${charIndex}]处的计算值数量不对：` + retArgs.length);
                                    return null;
                                }
                                insertValue(retArgs[0]);
                            } else {
                                let v: CapsValue = values.pop() as CapsValue;
                                preIsOperator = true;
                                if (v.type != EValueType._var) {
                                    app.Log.log(`语法错误3025, [${lineIndex}, ${charIndex}]处不是函数`);
                                    return null;
                                }
                                let functionName: string = v.GetVarName();
                                if (functionName == 'return') {
                                    if (retArgs.length != 1) {
                                        app.Log.log(`语法错误3026, [${lineIndex}, ${charIndex}]处参数数量不对:` + retArgs.length);
                                        return null;
                                    }
                                    let returnValue: CodeReturnValue = new CodeReturnValue()
                                    returnValue.jumpType = ECodeJumpType._return;
                                    returnValue.value = retArgs[0].GetRuntimeValue();
                                    return returnValue;
                                } else {
                                    let _v: CapsValue = this.DoFunction(functionName, retArgs);
                                    insertValue(_v);
                                }
                            }
                        } else if (startOperator == '[') {
                            if (preIsOperator) { // 前面是操作符的话，相当于声明了一个新的数组
                                insertValue(ret.value);
                            } else { // 变量带[index] 数组的访问
                                let v = values.pop() as CapsValue;
                                preIsOperator = true;
                                if (retArgs.length != 1) {
                                    app.Log.log(`语法错误3029, [${lineIndex}, ${charIndex}]处访问数组只能用一个int，length:` + retArgs.length);
                                    return null;
                                }
                                insertValue(v.GetRuntimeValue().GetItem(retArgs[0].GetFloatValue()));
                            }
                        } else {
                            if (retArgs.length != 1) {
                                app.Log.log(`语法错误3032, [${lineIndex}, ${charIndex}]处计算值无效`);
                                return null;
                            }
                            insertValue(retArgs[0]);
                        }
                    } else {
                        let w: Word = words[pw.wordIndex];
                        lineIndex = words[pw.wordIndex].lineIndex;
                        charIndex = words[pw.wordIndex].charIndex;
                        if (w.type == WordType._operator) {
                            let operatorStr: string = w.strValue;
                            if (w.strValue == '+' || w.strValue == '-' || w.strValue == 'not') {
                                if (values.length == 0 && operators.length == 0) { // 第一个打头的+算单目运算符
                                    if (singleOperator != '') {
                                        app.Log.log(`语法错误3050, [${lineIndex}, ${charIndex}]处有重复的单目运算符`);
                                        return null;
                                    }
                                    singleOperator = operatorStr;
                                    continue;
                                }
                            }
                            if (w.strValue == ',') {
                                onRunEnd(',');
                            } else {
                                insertOperator(operatorStr);
                            }
                        } else if (w.type == WordType.number) {
                            insertValue(new CapsValue(EValueType.number, Number(w.strValue)));
                        } else if (w.type == WordType.var) {
                            if (w.strValue == 'true' || w.strValue == 'false') {
                                insertValue(new CapsValue(EValueType._bool, w.strValue == 'true'));
                            } else {
                                insertValue(new CapsValue(EValueType._var, w.strValue));
                            }
                        } else if (w.type == WordType.str) {
                            insertValue(new CapsValue(EValueType.str, w.strValue));
                        } else {
                            app.Log.log(`语法错误3051, [${lineIndex}, ${charIndex}]处有不合法的类型:` + w.toString());
                            return null;
                        }
                    }
                }

                onRunEnd('__lineEnd__');
                let ret = new CodeReturnValue();
                ret.jumpType = ECodeJumpType.none;
                ret.value = new CapsValue(EValueType._list, args);
                return ret;
            }

            return null;
        }

        public DoScript(script: string) {
            let lines: Array<string> = script.split('\n');
            let words: Array<Word> = [];
            for (let indexLines = 0; indexLines < lines.length; indexLines++) {
                let line: string = lines[indexLines];
                let _words: Array<Word> = Word.ParseWords(indexLines, line);
                words = words.concat(_words);
            }

            words.splice(0, 0, new Word(-1, -1, WordType.scriptStart, ""));
            words.push(new Word(-1, -1, WordType.scriptEnd, ""));
            let codeTree: CodeTree = CodeTree.Build(words, 0, null);
            let ret: CodeReturnValue = this.DoCodeTree(words, codeTree);
            return ret
        }

        public DoScriptWithBoolReturn(script: string) {
            let ret: any = this.DoScript(script);
            if (ret == null || ret.value == null || ret.value.value == null || ret.value.value[0] == null)
                return false;
            return ret.value.value[0].GetBoolValue();
        }

        public GetAllVarValue():string{
            let result = '';
            for(let key in this.vars){
                result += key + '=' + this.vars[key].value + '\n';
            }
            app.Log.log(result);
            return result;
        }

        public clear(){
            this.vars = {};
        }
    }
}