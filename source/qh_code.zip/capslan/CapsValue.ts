module caps{
    
export enum EValueType { unknow, number, str, _bool, _var, _list }

export class CapsValue {
    public type: EValueType = EValueType.unknow;
    public value: any;

    constructor(type: EValueType, value: any) {
        this.type = type;
        this.value = value;
    }

    public GetRuntimeValue(): CapsValue {
        if (this.type == EValueType._var) {
            let varName: string = this.value.toString();
            let val: CapsValue = CapsLanVM.CurrentVM.GetVar(varName);
            if (val == null) {
                app.Log.log('语法错误200001, 使用了未定义的变量:' + varName);
                return new CapsValue(EValueType.unknow, null);
            }
            return val.GetRuntimeValue();
        }
        return this;
    }

    public Clone(): CapsValue {
        let runtimeValue: CapsValue = this.GetRuntimeValue();
        let _clone: CapsValue = new CapsValue(runtimeValue.type, null);
        switch (runtimeValue.type) {
            case EValueType.number: _clone.value = Number(runtimeValue.value); break;
            case EValueType._bool: _clone.value = Boolean(runtimeValue.value); break;
            case EValueType.str: _clone.value = runtimeValue.value.toString(); break;
            case EValueType._list: _clone.value = runtimeValue.value; break;
            default: app.Log.log('语法错误200020, Clone出错, 不应该有其他类型');
        }
        return _clone;
    }

    public GetBoolValue(): boolean {
        let v: CapsValue = this.GetRuntimeValue();
        switch (v.type) {
            case EValueType.number: return Number(v.value) != 0;
            case EValueType._bool: return Boolean(v.value);
            case EValueType.str: return v.value.toString() == '';
            case EValueType.unknow: return false;
            default: app.Log.log('语法错误200003, 无法解析成bool类型:' + this.ToString());
        }
        return false;
    }

    public GetStringValue(): string {
        let v: CapsValue = this.GetRuntimeValue();
        switch (v.type) {
            case EValueType.number:
            case EValueType._bool:
            case EValueType.str: return v.value.toString();
            case EValueType.unknow: return '';
            default: app.Log.log('语法错误200004, 无法解析成string类型' + this.ToString());
        }
        return '';
    }

    public GetFloatValue(): number {
        let v: CapsValue = this.GetRuntimeValue();
        if (v.type == EValueType.number) {
            return Number(v.value);
        }
        if(v.type == EValueType.unknow){
            return 0;
        }
        app.Log.log('语法错误200005, 无法解析成float类型' + this.ToString());
        return 0;
    }

    public GetVarName(): string {
        if (this.type == EValueType._var) {
            return this.value.toString();
        }
        app.Log.log('语法错误200006, 不是变量' + this.ToString());
        return '';
    }

    public GetItem(index: number): CapsValue {
        if (this.type != EValueType._list) {
            app.Log.log('语法错误200010, GetItem不是数组:' + this.ToString());
            return null;
        }
        if (index < 0) {
            app.Log.log('语法错误200011, GetItem中index为负数:' + index);
            return null;
        }
        if (index >= this.value.length) {
            app.Log.log('语法错误200012, GetItem中index越界:' + index + ' >= 长度' + this.value.length);
            return null;
        }
        return this.value[index];
    }

    public GetLength(): number {
        if (this.type != EValueType._list) {
            app.Log.log('语法错误200013, GetLength不是数组:' + this.ToString());
            return 0;
        }
        return Object.keys(this.value).length;
    }

    public AddItem(item: CapsValue) { // 添加数组中的元素，除了数组元素是浅拷贝，其他的都是深拷贝
        if (this.type != EValueType._list) {
            app.Log.log('语法错误200014, AddItem不是数组:' + this.ToString());
            return;
        }
        this.value.push(item.GetRuntimeValue().Clone());
    }
    public Insert(index: number, item: CapsValue) {// 添加数组中的元素，除了数组元素是浅拷贝，其他的都是深拷贝
        if (this.type != EValueType._list) {
            app.Log.log('语法错误200018, Insert不是数组:' + this.ToString());
            return;
        }
        if (index < 0 || index >= this.value.length) {
            app.Log.log('语法错误200021, Insert非法的index:' + index);
            return;
        }
        this.value.splice(index, 0, item.GetRuntimeValue().Clone());
    }

    public RemoveAt(index: number) {
        if (this.type != EValueType._list) {
            app.Log.log('语法错误200015, RemoveAt不是数组:' + this.ToString());
            return;
        }
        if (index < 0) {
            app.Log.log('语法错误200016, RemoveAt中index为负数:' + index);
            return;
        }
        if (index >= this.value.length) {
            app.Log.log('语法错误200017, RemoveAt中index越界:' + index + ' >= 长度' + this.value.length);
            return;
        }
        this.value.splice(index,1);
    }


    public static Equal(a: CapsValue, b: CapsValue): boolean {
        if (a == null || b == null) return false;
        a = a.GetRuntimeValue();
        b = b.GetRuntimeValue();
        if (a.type != b.type) return false;
        switch (a.type) {
            case EValueType.number: return Number(a.value) == Number(b.value);
            case EValueType._bool: return Boolean(a.value) == Boolean(b.value);
            case EValueType.str: return a.value.toString() == b.value.toString();
        }
        return false;
    }

    public static BiggerThan(a: CapsValue, b: CapsValue): boolean {
        if (a == null || b == null) {
            app.Log.log('运行错误10000, null不能比较大小');
            return false;
        }
        a = a.GetRuntimeValue();
        b = b.GetRuntimeValue();
        if (a.type != EValueType.number || b.type != EValueType.number) {
            app.Log.log('运行错误10001, 两个非数字之间不能比较大小');
            return false;
        }
        return Number(a.value) > Number(b.value);
    }

    public ToString(): string {
        let str: string = '';
        switch (this.type) {
            case EValueType.number: str = '数值类型：' + this.value; break;
            case EValueType.str: str = '字符串：' + this.value; break;
            case EValueType._bool: str = '布尔值：' + this.value; break;
            case EValueType._list: {
                str = '数组类型, ';
                str += '长度' + this.value.length + ':[';
                for (let i = 0; i < this.value.length; i++) {
                    if (i != 0) str += ', ';
                    str += (this.value[i]).ToString();
                }
                str += ']';
                break;
            }
            case EValueType._var: {
                str = '变量, 值为(' + this.GetRuntimeValue().ToString() + ')'; break;
            }
            default: str = '未知类型'; break;
        }
        return str;
    }
}

}