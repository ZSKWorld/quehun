module caps {
    export enum CodeTreeType { codeBlock, phrase, brackets, _if, _loop, _break, _continue }

    export class PhraseWord {
        public isCodeTree: boolean = false;
        public codeTree: CodeTree;
        public wordIndex: number = -1;
    }

    export class CodeTree {
        public type: CodeTreeType = CodeTreeType.codeBlock;
        public wordStartIndex: number = 0;
        public wordEndIndex: number = 0;
        public father: CodeTree;
        public sons: Array<CodeTree> = [];
        public phraseWords: Array<PhraseWord> = [];

        public static PrintTree(tree: CodeTree, deep: number, words: Array<Word>) {
            let str: string = '';
            for (let i = 0; i < deep; i++) {
                if (i == 0) {
                    str += '|';
                }
                str += '--';
            }
            str += '[' + tree.wordStartIndex + ' - ' + tree.wordEndIndex + ']: \"';
            let lastStr: string = '';
            for (let i = tree.wordStartIndex; i <= tree.wordEndIndex; i++) {
                if (words[i].strValue != '') {
                    if (lastStr != '') str += ',';
                    str += words[i].strValue;
                    lastStr = words[i].strValue;
                }
            }
            str += '\"';
            app.Log.log(str);
            for (let i = 0; i < tree.sons.length; i++) {
                CodeTree.PrintTree(tree.sons[i], deep + 1, words);
            }
        }

        private static GetNextIndex(words: Array<Word>, startIndex: number): number {
            while (startIndex < words.length) {
                if (words[startIndex].type == WordType.lineEnd) {
                    startIndex++;
                } else {
                    return startIndex;
                }
            }
            app.Log.log('语法错误2005, 无法获取下一个字符');
            return -1;
        }

        private static BuildAsPhrase(words: Array<Word>, startIndex: number): CodeTree {
            let tree: CodeTree = new CodeTree();
            tree.wordStartIndex = startIndex;
            let endIndex: number = startIndex;
            if (words[endIndex].type == WordType._operator && words[endIndex].strValue == ',') { // 逗号单独成一个点
                tree.type = CodeTreeType.phrase;
                tree.wordEndIndex = endIndex;
                return tree;
            }

            while (true) {
                if (words[endIndex].type == WordType.lineEnd || words[endIndex].type == WordType.scriptEnd) {
                    break;
                }
                if (words[endIndex].type == WordType._operator && (words[endIndex].strValue == ')' || words[endIndex].strValue == ']'
                    || words[endIndex].strValue == ',' || words[endIndex].strValue == '{')) {
                    break;
                }
                if (words[endIndex].type == WordType.reservedWord) {
                    app.Log.log(`语法错误2020, 在[{words[endIndex].lineIndex}, {words[endIndex].charIndex}]处的出现不合法保留字:` + words[endIndex].strValue);
                    break;
                }

                if (words[endIndex].type == WordType._operator && (words[endIndex].strValue == '(' || words[endIndex].strValue == '[')) {
                    let rightBrackets: string = words[endIndex].strValue == '(' ? ')' : ']';
                    let treeBrackets: CodeTree = new CodeTree();
                    treeBrackets.wordStartIndex = endIndex;
                    treeBrackets.father = tree;
                    endIndex++;
                    while (true) {
                        if (words[endIndex].type == WordType._operator && words[endIndex].strValue == rightBrackets) {
                            break;
                        }
                        if (words[endIndex].type == WordType.lineEnd || words[endIndex].type == WordType.scriptEnd) {
                            app.Log.log(`语法错误2021, 在[{words[endIndex].lineIndex}]处的括号不匹配`);
                            break;
                        }
                        let w0: PhraseWord = new PhraseWord();
                        w0.isCodeTree = true;
                        w0.codeTree = CodeTree.BuildAsPhrase(words, endIndex);
                        treeBrackets.phraseWords.push(w0);
                        endIndex = CodeTree.GetNextIndex(words, w0.codeTree.wordEndIndex + 1);
                        if (words[endIndex].type == WordType._operator && words[endIndex].strValue == ',') { // 括号中的,
                            let w1: PhraseWord = new PhraseWord();
                            w1.isCodeTree = false;
                            w1.wordIndex = endIndex;
                            treeBrackets.phraseWords.push(w1);
                            endIndex = endIndex + 1;
                        }
                    }
                    treeBrackets.wordEndIndex = endIndex;
                    treeBrackets.type = CodeTreeType.phrase;
                    let w2: PhraseWord = new PhraseWord();
                    w2.isCodeTree = true;
                    w2.codeTree = treeBrackets;
                    tree.phraseWords.push(w2);
                } else {
                    let w1: PhraseWord = new PhraseWord();
                    w1.isCodeTree = false;
                    w1.wordIndex = endIndex;
                    tree.phraseWords.push(w1);
                }
                endIndex++;
            }
            tree.type = CodeTreeType.phrase;
            tree.wordEndIndex = endIndex - 1;
            return tree;
        }

        public static Build(words: Array<Word>, startIndex: number, father: any): CodeTree {
            startIndex = CodeTree.GetNextIndex(words, startIndex);
            let tree: CodeTree = new CodeTree();
            tree.father = father;
            tree.wordStartIndex = startIndex;

            let wordStart: Word = words[startIndex];
            if (words[startIndex].type == WordType.scriptStart) {
                let endIndex: number = startIndex + 1;
                while (true) {
                    if (words[endIndex].type == WordType.scriptEnd) {
                        break;
                    }
                    let son: CodeTree = CodeTree.Build(words, endIndex, tree);
                    tree.sons.push(son);
                    endIndex = CodeTree.GetNextIndex(words, son.wordEndIndex + 1);
                }
                tree.wordEndIndex = endIndex;
                tree.type = CodeTreeType.codeBlock;
                return tree;
            } else if (wordStart.type == WordType._operator) {
                if (wordStart.strValue == '{') {  // 找到下一个右括号为止
                    let endIndex: number = startIndex + 1;
                    while (true) {
                        if (words[endIndex].type == WordType._operator && words[endIndex].strValue == '}') {
                            break;
                        }
                        let son: CodeTree = CodeTree.Build(words, endIndex, tree);
                        tree.sons.push(son);
                        endIndex = CodeTree.GetNextIndex(words, son.wordEndIndex + 1);
                    }
                    tree.wordEndIndex = endIndex;
                    tree.type = CodeTreeType.codeBlock;
                    return tree;
                } else {
                    return CodeTree.BuildAsPhrase(words, startIndex);
                }
            } else if (wordStart.type == WordType.reservedWord) {
                if (wordStart.strValue == 'if') {   // if的第0个son一定是条件判断，第1个是执行if为true的代码，第2个可以缺省，执行false的代码
                    if (startIndex + 1 >= words.length) {
                        app.Log.log(`语法错误2003, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处的if有误`);
                        return null;
                    }
                    if (words[startIndex + 1].type != WordType._operator || words[startIndex + 1].strValue != '(') {
                        app.Log.log(`语法错误2004, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处的if有误, 后面没有(`);
                        return null;
                    }
                    let codeCondition: CodeTree = CodeTree.Build(words, startIndex + 1, tree);
                    tree.sons.push(codeCondition);
                    let codeIf: CodeTree = CodeTree.Build(words, codeCondition.wordEndIndex + 1, tree);
                    tree.sons.push(codeIf);
                    let nextIndex: number = codeIf.wordEndIndex + 1;
                    while (nextIndex < words.length) {
                        if (words[nextIndex].type == WordType.lineEnd) {
                            nextIndex++;
                        } else {
                            break;
                        }
                    }
                    if (nextIndex < words.length) {
                        if (words[nextIndex].type == WordType.reservedWord && words[nextIndex].strValue == 'else') {
                            let codeElse: CodeTree = CodeTree.Build(words, nextIndex + 1, tree);
                            tree.sons.push(codeElse);
                        }
                    }
                    tree.wordEndIndex = tree.sons[tree.sons.length - 1].wordEndIndex;
                    tree.type = CodeTreeType._if;
                    return tree;
                } else if (wordStart.strValue == 'loop') { // 有且只有一个son
                    tree.type = CodeTreeType._loop;
                    tree.sons.push(CodeTree.Build(words, startIndex + 1, tree));
                    tree.wordEndIndex = tree.sons[0].wordEndIndex;
                    return tree;
                } else if (wordStart.strValue == 'continue') {
                    let f: CodeTree = father;
                    while (f != null) {
                        if (f.type == CodeTreeType._loop) {
                            break;
                        }
                        f = f.father;
                    }
                    if (f == null) {
                        app.Log.log(`语法错误2008, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处` + words[startIndex].strValue + '未被包含在loop中');
                        return null;
                    }
                    tree.type = CodeTreeType._continue;
                    tree.wordEndIndex = startIndex;
                    return tree;
                } else if (wordStart.strValue == 'break') {
                    let f: CodeTree = father;
                    while (f != null) {
                        if (f.type == CodeTreeType._loop) {
                            break;
                        }
                        f = f.father;
                    }
                    if (f == null) {
                        app.Log.log(`语法错误2009, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处` + words[startIndex].strValue + '未被包含在loop中');
                        return null;
                    }
                    tree.type = CodeTreeType._break;
                    tree.wordEndIndex = startIndex;
                    return tree;
                } else {
                    app.Log.log(`语法错误2007, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处存在不合法的保留字：` + words[startIndex].strValue);
                    return null;
                }
            } else if (wordStart.type == WordType.var || wordStart.type == WordType.str || wordStart.type == WordType.number) {
                return CodeTree.BuildAsPhrase(words, startIndex);
            }

            app.Log.log(`语法错误2005, 在[${wordStart.lineIndex}, ${wordStart.charIndex}]处无法解析`);
            return new CodeTree();
        }
    }

}