module caps {
    export enum WordType { unknown, number, str, var, reservedWord, _operator, lineEnd, scriptStart, scriptEnd }
    enum ECharType { unknown, empty, letter, number, _operator }
    enum EWordState { none, var, _operator, number, str }

    export class Word {
        public lineIndex: number = 0;
        public charIndex: number = 0;
        public type: WordType = WordType.unknown;
        public strValue: string = '';

        constructor(lineIndex: number, charIndex: number, type: WordType, strValue: string) {
            this.lineIndex = lineIndex;
            this.charIndex = charIndex;
            this.type = type;
            this.strValue = strValue;
        }

        toString(): string {
            let str: string = `[${this.lineIndex}, ${this.charIndex}]`
            switch (this.type) {
                case WordType.var: str += '变量'; break;
                case WordType._operator: str += '操作符'; break;
                case WordType.lineEnd: str += '句末结尾符'; break;
                case WordType.scriptStart: str += '代码开始符'; break;
                case WordType.scriptEnd: str += '代码结尾符'; break;
                case WordType.number: str += '数字'; break;
                case WordType.str: str += '字符串'; break;
                case WordType.reservedWord: str += '保留字'; break;

                default: str += '未知类型'; break;
            }
            str += ': ' + this.strValue;
            return str;
        }

        private static GetCharType(c: string): ECharType {
            if (c == ' ' || c == '\t' || c == '\r' || c == '\n') return ECharType.empty;
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_') return ECharType.letter;
            if (c >= '0' && c <= '9') return ECharType.number;
            if (c == '+' || c == '-' || c == '*' || c == '/' || c == '>' || c == '<' || c == '='
                || c == '(' || c == ')' || c == '{' || c == '}' || c == '[' || c == ']' || c == ';' || c == '\"' || c == '.' || c == ',' || c == '!') return ECharType._operator;
            return ECharType.unknown;
        }

        public static ParseWords(lineIndex: number, lineCode: string): Array<Word> {
            let words: Array<Word> = [];
            let state: EWordState = EWordState.none;
            let nowChars: string = '';
            let charIndex: number = 0;
            for (let i = 0; i < lineCode.length; i++) {
                let c = lineCode[i];
                if (state == EWordState.str) {
                    if (c == '\"') {
                        words.push(new Word(lineIndex, charIndex, WordType.str, nowChars));
                        state = EWordState.none;
                    } else {
                        nowChars += c;
                    }
                    continue;
                }

                let charType: ECharType = this.GetCharType(c);
                let wordContine = false;
                if (charType == ECharType.unknown) {
                    app.Log.log(`语法错误1001，第${lineIndex}行，第${i}个字符为未知字符：${lineCode}`)
                    return words;
                } else if (charType == ECharType.letter) {
                    wordContine = state == EWordState.var;
                } else if (charType == ECharType._operator) {
                    wordContine = false;
                    if (state == EWordState._operator) {
                        let op: string = nowChars + c;
                        if (op == '>=' || op == '<=' || op == '==' || op == '!=' || op == '-=' || op == '+=') // 多个字符组成的操作符需要特殊处理
                        {
                            words.push(new Word(lineIndex, charIndex, WordType._operator, op));
                            state = EWordState.none;
                            nowChars = '';
                            continue;
                        }
                    }
                    if (c == '.') {
                        if (state == EWordState.number) {
                            if (nowChars.includes('.')) {
                                app.Log.log(`语法错误1010，第${lineIndex}行，第${i}个小数点过多了`);
                                return words;
                            }
                            wordContine = true;
                        } else {
                            app.Log.log(`语法错误1011，第${lineIndex}行，第${i}个的.意义不明`);
                            return words;
                        }
                    }
                } else if (charType == ECharType.number) {
                    wordContine = state == EWordState.number;
                }

                if (wordContine) {
                    nowChars += c;
                    continue;
                }
                switch (state) {
                    case EWordState.var: {
                        let type: WordType = WordType.var;
                        if (nowChars == 'and' || nowChars == 'or' || nowChars == 'not') {
                            type = WordType._operator;
                        } else if (nowChars == 'if' || nowChars == 'else' || nowChars == 'loop' || nowChars == 'break' || nowChars == 'continue') {
                            type = WordType.reservedWord;
                        }
                        words.push(new Word(lineIndex, charIndex, type, nowChars));
                        break;
                    }
                    case EWordState._operator:
                        words.push(new Word(lineIndex, charIndex, WordType._operator, nowChars));
                        break;
                    case EWordState.number:
                        words.push(new Word(lineIndex, charIndex, WordType.number, nowChars));
                        break;
                }
                state = EWordState.none;
                charIndex = i;
                if (charType == ECharType.letter) {
                    state = EWordState.var;
                    nowChars = c.toString();
                } else if (charType == ECharType._operator) {
                    if (c == ';') {
                        words.push(new Word(lineIndex, charIndex, WordType.lineEnd, ';'));
                    } else if (c == '\"') {
                        state = EWordState.str;
                        nowChars = '';
                    } else {
                        state = EWordState._operator;
                        nowChars = c.toString();
                    }
                } else if (charType == ECharType.number) {
                    state = EWordState.number;
                    nowChars = c.toString();
                }
            }
            switch (state) {
                case EWordState.var:
                    words.push(new Word(lineIndex, charIndex, WordType.var, nowChars));
                    break;
                case EWordState._operator:
                    words.push(new Word(lineIndex, charIndex, WordType._operator, nowChars));
                    break;
                case EWordState.number:
                    words.push(new Word(lineIndex, charIndex, WordType.number, nowChars));
                    break;
            }
            words.push(new Word(lineIndex, charIndex, WordType.lineEnd, ''));
            return words;
        }
    }
}