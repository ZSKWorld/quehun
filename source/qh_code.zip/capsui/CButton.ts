/**
* name 
*/
module capsui{

	const ButtonTweenTime:number = 50;

	export class CButton extends UIComponent{

		private mousedowned: boolean = false;
		private origin_scale_x:number = 1;
		private origin_scale_y:number = 1;
		private starttime:number = 0;
		private origin_x:number = 0;
		private enableClickDarken: boolean = false;
		private imgGray: Laya.Image;

		constructor() {
			super();
		}

		public onCreate(): void {
			this.origin_scale_x = this.me.scaleX;
			this.origin_scale_y = this.me.scaleY;
			this.me.on('mousedown', this, this.OnMouseDown);
			this.me.on('mouseup', this, this.OnMouseUp);
			this.me.on('mouseout', this, this.OnMouseUp);
			this.me.filters = [new Laya.ColorFilter([
                1, 0, 0, 0, 0,  //R
                0, 1, 0, 0, 0, //G
                0, 0, 1, 0, 0,  //B
                0, 0, 0, 1, 0, //A
			])];
			this.imgGray = this.me.getChildByName("gray") as Laya.Image;
		}

		public onEnable() {
			
			this.me.scaleX = this.me.scaleY = 1;
			this.origin_scale_x = this.me.scaleX;
			this.origin_scale_y = this.me.scaleY;
			if (this.enableClickDarken && this.imgGray) {
				this.imgGray.alpha = 0;
			}
		}

		public onDisable(){
			this.mousedowned = false;
			Laya.Tween.clearAll(this.me);
			if (this.me.destroyed) return;
			this.me.scaleX = this.origin_scale_x;
			this.me.scaleY = this.origin_scale_y;
		}

		public OnMouseDown() {
			if (this.mousedowned) return;
			this.mousedowned = true;
			this.origin_x = this.me.scaleX;
			this.starttime = Laya.timer.currTimer;
			Laya.timer.clear(this, this.DoAnim);
			Laya.timer.frameLoop(1, this, this.DoAnim);
		}
		
		public OnMouseUp() {
			if (!this.mousedowned) return;
			this.mousedowned = false;
			this.origin_x = this.me.scaleX;
			this.starttime = Laya.timer.currTimer;
			Laya.timer.clear(this, this.DoAnim);
			Laya.timer.frameLoop(1, this, this.DoAnim);
		}

		public DoAnim() {
			if (!this.me || this.me.destroyed) return;
			let t:number = Laya.timer.currTimer - this.starttime;
			let target:number = this.mousedowned ? 1.1 : 1;
			if (t >= ButtonTweenTime) {
				this.me.scaleX = this.me.scaleY = target;
				Laya.timer.clear(this, this.DoAnim);
				if (this.enableClickDarken && this.imgGray) {
					this.imgGray.alpha = this.mousedowned ? 1 : 0;
				}
			} else {
				let rate:number = t / ButtonTweenTime;
				this.me.scaleX = this.me.scaleY = this.origin_x * (1 - rate) + target * rate;
				if (this.enableClickDarken && this.imgGray) {
					this.imgGray.alpha = this.mousedowned ? rate : 1 - rate;
				}
			}
		}
	}
}