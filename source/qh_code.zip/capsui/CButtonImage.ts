/**
* name 
*/
module capsui {



    export class CButtonImage extends UIComponent {

        private mousedowned: boolean = false;
        private changeTarget: Laya.Image | Laya.Button;
        /**
         * 目前仅支持挂载物体下的第一层,不填的话就是父节点
         */
        public changeTargetName: string;
        /**
         * 抬起图片路径,没填会按照目标的skin来
         */
        public upImagePath: string;
        /**
         * 按下图片路径
         */
        public downImagePath: string;


        constructor() {
            super();
        }

        public onCreate(): void {
            if (this.changeTargetName && this.changeTargetName != "") {
                this.changeTarget = this.me.getChildByName(this.changeTargetName) as Laya.Image;
            } else {
                this.changeTarget = this.me as Laya.Button;
            }
            if (!this.upImagePath && this.upImagePath == "") {
                this.upImagePath = this.changeTarget.skin;
            }

            this.me.on('mousedown', this, this.OnMouseDown);
            this.me.on('mouseup', this, this.OnMouseUp);
            this.me.on('mouseout', this, this.OnMouseUp);

        }

        public onEnable() {
            this.changeTarget.skin = game.Tools.localUISrc(this.upImagePath);
        }

        public onDisable() {
            this.mousedowned = false;
            if (this.me.destroyed) return;
            this.changeTarget.skin = game.Tools.localUISrc(this.upImagePath);
        }

        public OnMouseDown() {
            if (this.mousedowned) return;
            this.mousedowned = true;
            this.changeTarget.skin = game.Tools.localUISrc(this.downImagePath);
        }

        public OnMouseUp() {
            if (!this.mousedowned) return;
            this.mousedowned = false;
            this.changeTarget.skin = game.Tools.localUISrc(this.upImagePath);
        }


    }
}