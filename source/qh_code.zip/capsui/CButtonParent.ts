/**
* name 
*/
module capsui{

	const ButtonTweenTime:number = 50;

	export class CButtonParent extends UIComponent{

		private mousedowned: boolean = false;
		private origin_scale_x:number = 1;
		private origin_scale_y:number = 1;
		private starttime:number = 0;
		private origin_x:number = 0;
        private parent:Laya.Sprite;
		public targetScale: number = 1.1;

		constructor() {
			super();
		}

		public onCreate(): void {
			
			this.me.on('mousedown', this, this.OnMouseDown);
			this.me.on('mouseup', this, this.OnMouseUp);
			this.me.on('mouseout', this, this.OnMouseUp);
			this.me.filters = [new Laya.ColorFilter([
                1, 0, 0, 0, 0,  //R
                0, 1, 0, 0, 0, //G
                0, 0, 1, 0, 0,  //B
                0, 0, 0, 1, 0, //A
			])];
            this.parent = (this.me.parent as Laya.Sprite);
            this.origin_scale_x = this.parent.scaleX;
			this.origin_scale_y = this.parent.scaleY;
		}

		public onEnable() {
            this.parent = (this.me.parent as Laya.Sprite);
			this.parent.scaleX = this.parent.scaleY = 1;
			this.origin_scale_x = this.parent.scaleX;
			this.origin_scale_y = this.parent.scaleY;
		}

		public onDisable(){
			this.mousedowned = false;
			Laya.Tween.clearAll(this.me);
			if (this.me.destroyed) return;
			this.parent.scaleX = this.origin_scale_x;
			this.parent.scaleY = this.origin_scale_y;
		}

		public OnMouseDown() {
			if (this.mousedowned) return;
			this.mousedowned = true;
			this.origin_x = this.parent.scaleX;
			this.starttime = Laya.timer.currTimer;
			Laya.timer.clear(this, this.DoAnim);
			Laya.timer.frameLoop(1, this, this.DoAnim);
		}
		
		public OnMouseUp() {
			if (!this.mousedowned) return;
			this.mousedowned = false;
			this.origin_x = this.parent.scaleX;
			this.starttime = Laya.timer.currTimer;
			Laya.timer.clear(this, this.DoAnim);
			Laya.timer.frameLoop(1, this, this.DoAnim);
		}

		public DoAnim() {
			if (!this.me || this.me.destroyed) return;
			let t:number = Laya.timer.currTimer - this.starttime;
			let target:number = this.mousedowned ? this.targetScale : 1;
			if (t >= ButtonTweenTime) {
				this.parent.scaleX = this.parent.scaleY = target;
				Laya.timer.clear(this, this.DoAnim);
			} else {
				let rate:number = t / ButtonTweenTime;
				this.parent.scaleX = this.parent.scaleY = this.origin_x * (1 - rate) + target * rate;
			}
		}
	}
}