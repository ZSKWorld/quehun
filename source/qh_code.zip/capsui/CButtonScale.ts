/**
* name 
*/
module capsui {

    

    export class CButtonScale extends UIComponent {

        private mousedowned: boolean = false;
        private origin_scale_x: number = 1;
        private origin_scale_y: number = 1;
        private starttime: number = 0;
        private targetScaleX: number = 0;
        private targetScaleY: number = 0;
        private animTarget: Laya.Sprite;
        public targetRateX: number = 1.1;
        public targetRateY: number = 1.1;
        public isTargetParent: boolean = false;
        public animTime: number = 50;

        constructor() {
            super();
        }

        public onCreate(): void {
            if (this.isTargetParent) {
                this.animTarget = (this.me.parent as Laya.Sprite);
            }
            else {
                this.animTarget = this.me;
            }
            this.origin_scale_x = this.animTarget.scaleX;
            this.origin_scale_y = this.animTarget.scaleY;
            this.targetScaleX = this.origin_scale_x * this.targetRateX;
            this.targetScaleY = this.origin_scale_y * this.targetRateY;
            this.me.on('mousedown', this, this.OnMouseDown);
            this.me.on('mouseup', this, this.OnMouseUp);
            this.me.on('mouseout', this, this.OnMouseUp);
            this.me.filters = [new Laya.ColorFilter([
                1, 0, 0, 0, 0,  //R
                0, 1, 0, 0, 0, //G
                0, 0, 1, 0, 0,  //B
                0, 0, 0, 1, 0, //A
            ])];


        }

        public onEnable() {
            this.animTarget.scaleX = this.origin_scale_x;
            this.animTarget.scaleY = this.origin_scale_y;
        }

        public onDisable() {
            this.mousedowned = false;
            Laya.Tween.clearAll(this.me);
            if (this.me.destroyed) return;
            this.animTarget.scaleX = this.origin_scale_x;
            this.animTarget.scaleY = this.origin_scale_y;
        }

        public OnMouseDown() {
            if (this.mousedowned) return;
            this.mousedowned = true;
            this.starttime = Laya.timer.currTimer;
            Laya.timer.clear(this, this.DoAnim);
            Laya.timer.frameLoop(1, this, this.DoAnim);
        }

        public OnMouseUp() {
            if (!this.mousedowned) return;
            this.mousedowned = false;
            this.starttime = Laya.timer.currTimer;
            Laya.timer.clear(this, this.DoAnim);
            Laya.timer.frameLoop(1, this, this.DoAnim);
        }

        public DoAnim() {
            if (!this.me || this.me.destroyed) return;
            let t: number = Laya.timer.currTimer - this.starttime;
            let targetX: number = this.mousedowned ? this.targetScaleX : this.origin_scale_x;
            let targetY: number = this.mousedowned ? this.targetScaleY : this.origin_scale_y;
            if (t >= this.animTime) {
                this.animTarget.scaleX = targetX;
                this.animTarget.scaleY = targetY;
                Laya.timer.clear(this, this.DoAnim);
            } else {
                let rate: number = t / this.animTime;
                this.animTarget.scaleX = this.origin_scale_x * (1 - rate) + targetX * rate;
                this.animTarget.scaleY = this.origin_scale_y * (1 - rate) + targetY * rate;
            }
        }
    }
}