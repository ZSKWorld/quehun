/**
* 拖拽按钮
*/
module capsui {
    const ResetTweenSpeed:number = 400;
    export class CDragButton extends UIComponent {

        private mousedowned: boolean = false;
        private origin_x: number = 0;
        private origin_y: number = 0;
        private delta_x: number = 0; // 触发点开始偏移量
        private delta_y: number = 0;
        private changeHandler: Laya.Handler;
        private lockHandler: Laya.Handler;
        private mouseDownHandler: Laya.Handler;
        private moved: boolean = false;

        constructor() {
            super();
        }

        public onCreate(): void {
            this.me.on('mousedown', this, this.OnMouseDown);
            // this.me.on('mouseout', this, this.OnMouseUp);
            this.origin_x = this.me.x;
            this.origin_y = this.me.y;
        }
        public pos(x: number, y: number) {
            this.origin_x = x;
            this.origin_y = y;
        }
        public onEnable() {
            Laya.Tween.clearAll(this.me);
            this.me.x = this.origin_x;
            this.me.y = this.origin_y;
            this.mousedowned = false;
        }

        public onDisable() {
            this.mousedowned = false;
            Laya.Tween.clearAll(this.me);
            if (this.me.destroyed) return;
            this.me.x = this.origin_x;
            this.me.y = this.origin_y;
        }

        // hchangeHandler 结束回调  lockHandler判断是否锁定
		public init(changeHandler: Laya.Handler, lockHandler: Laya.Handler, mouseDownHandler: Laya.Handler) {
            this.changeHandler = changeHandler;
            this.mouseDownHandler = mouseDownHandler;
            this.lockHandler = lockHandler;
        }
        public OnMouseDown() {
            if (this.mousedowned) return;
            if (this.me.destroyed) return;
            if (this.lockHandler.run()) return; // s
            Laya.Tween.clearAll(this);
            this.mousedowned = true;
            this.me.zOrder = 3;
            if (this.mouseDownHandler) {
                this.mouseDownHandler.run();    
            }
            this.delta_x = Laya.stage.mouseX - this.me.x;
            this.delta_y = Laya.stage.mouseY - this.me.y;
            this.moved = false;
            Laya.stage.on('mouseup', this, this.OnMouseUp);
            Laya.stage.on('mouseout', this, this.OnMouseUp);
            Laya.timer.frameLoop(1, this, ()=>{
                this.OnMouseMove();
            });
        }

        public OnMouseUp() {
            if (!this.mousedowned) return;
            if (this.me.destroyed) return;
            this.mousedowned = false;
            this.clearEvent();
            Laya.Tween.clearAll(this);
            this.me.zOrder = 0;
            // 判断是否需要还原，如果无事发生则还原按钮
            if (!this.changeHandler.runWith(this.moved)) {
                let delta = Math.abs(this.me.x - this.origin_x) + Math.abs(this.me.y - this.origin_y);
                Laya.Tween.to(this.me, {x: this.origin_x, y: this.origin_y}, delta / ResetTweenSpeed);
            }
        }

        private OnMouseMove() {
            if (!this.mousedowned) {
                this.clearEvent();
                return;
            }
            if (this.me.destroyed) {
                this.clearEvent();
                return;
            }
            
            this.me.x = Laya.stage.mouseX - this.delta_x;
            this.me.y = Laya.stage.mouseY - this.delta_y;
            if (!this.moved) {
                if (this.me.x + this.delta_x != Laya.stage.mouseX || this.me.y + this.delta_y != Laya.stage.mouseY) {
                    this.moved = true;
                }
            }
        }

        private clearEvent() {
            Laya.stage.off('mouseup', this, this.OnMouseUp);
            Laya.stage.off('mouseout', this, this.OnMouseUp);
        }
    }
}