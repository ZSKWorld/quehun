/**
* name 
*/
module capsui {
	//下拉选项不得超过10个
	export class CDropdown {
		private _data: any = null;

		private _me: Laya.Sprite = null; //绑定的位置
		private out: Laya.Button;
		private bg: Laya.Sprite;
		private line: Laya.Sprite;
		private item_templete: Laya.Button;
		private content: Laya.Panel;
		private items: Array<Laya.Sprite> = [];
		private lines: Array<Laya.Sprite> = [];
		private _is_down:boolean;	// 是否处于打开状态
		private _choosed_index: number;
		private _value_count: number;
		private _render: Laya.Handler;
		private _onChange: Laya.Handler;
		private _onStateChange: Laya.Handler;
		private _locking: boolean;
		private _max_show_count: number;

		public get is_down():boolean { return this._is_down; }

		constructor() {

		}

		public get locking(): boolean {
			return this._locking;
		}

		public get me(): Laya.Sprite {
			return this._me;
		}

		public set owner(value: any) {
			this._me = value;
			Laya.timer.frameOnce(3, this, this.onCreate);
		}

		public get choosed_index(): number {
			return this._choosed_index;
		}

		public onCreate() {
			this.out = this.me.getChildByName('out') as Laya.Button;
			this.bg = this.me.getChildByName('bg') as Laya.Sprite;
			this.line = this.me.getChildByName('line') as Laya.Sprite;
			this.item_templete = this.me.getChildByName('templete') as Laya.Button;
			this.content = this.me.getChildByName('content') as Laya.Panel;
			this.content.vScrollBarSkin = game.Tools.localUISrc('myres/vscroll.png');
			this.content.vScrollBar.visible = false;
			this.item_templete.visible = false;
			let _clone = this.item_templete.scriptMap['capsui.UICopy'];
			for (let i: number = 0; i < 10; i++) {
				let _item: Laya.Sprite = _clone.getNodeClone();
				this.content.addChild(_item);
				this.items.push(_item);
			}
			for (let i: number = 0; i < 12; i++) {
				let _line: Laya.Sprite = this.line.scriptMap['capsui.UICopy']['getNodeClone']();
				this.content.addChild(_line);
				this.lines.push(_line);
			}

			this.item_templete.visible = true;
			(this.item_templete as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (this._locking) return;
				if (this.out.visible) this.up();
				else this.down();
			}, null, false);
			this.out.clickHandler = Laya.Handler.create(this, () => {
				if (this._locking) return;
				this.up();
			}, null, false);
		}

		public init(render: Laya.Handler, onChange: Laya.Handler, onStateChange: Laya.Handler = null) {
			this._render = render;
			this._onChange = onChange;
			this._onStateChange = onStateChange;
		}

		public reset_show(init_index: number, total_count: number, max_show_count: number = 3) {
			this._is_down = false;
			this.out.visible = false;
			this.line.visible = false;
			this.content.visible = false;
			this._max_show_count = max_show_count;
			this.bg.height = this.item_templete.height;
			this._value_count = total_count;
			this._choosed_index = init_index;
			let _clone = this.item_templete.scriptMap['capsui.UICopy'];
			for (let i: number = this.items.length; i < total_count; i++) {
				let _item: Laya.Sprite = _clone.getNodeClone();
				this.content.addChild(_item);
				this.items.push(_item);
			}
			this._render.runWith({ index: init_index, container: this.item_templete });
			this._locking = false;
		}

		public down() {
			this._is_down = true;
			this._locking = true;
			this.out.visible = true;
			for (let i: number = 0; i < this.items.length; i++) this.items[i].visible = false;

			this.content.visible = false;
			this.line.visible = true;
			this.line.y = this.item_templete.height;
			this.content.y = this.item_templete.height + this.line.height;

			for (let i: number = 0; i < this.items.length; i++) {
				if (i < this._value_count) {
					if (i != 0) {
						this.lines[i - 1].visible = true;
						this.lines[i - 1].y = this.item_templete.height * i + this.line.height * (i - 1);
					}
					this._render.runWith({ index: i, container: this.items[i] });
					this.items[i].visible = true;
					this.items[i].y = (this.item_templete.height + this.line.height) * i;
					(this.items[i] as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
						if (this._locking) return;
						this.up();
						if (this._choosed_index != i) {
							this._choosed_index = i;
							this._render.runWith({ index: i, container: this.item_templete });
							this._onChange.runWith(this._choosed_index);
						}
					}, null, false);
				} else {
					this.items[i].visible = false;
				}
			}
			this.content.visible = true;
			this.content.alpha = 0;
			if (this._value_count <= this._max_show_count) {
				let bg_h: number = (this.item_templete.height + this.line.height) * (this._value_count + 1);
				this.content.height = (this.item_templete.height + this.line.height) * this._value_count;
				Laya.Tween.to(this.bg, { height: bg_h }, 150, Laya.Ease.strongOut);
				Laya.Tween.to(this.content, { alpha: 1 }, 150);
			} else {
				let bg_h: number = (this.item_templete.height + this.line.height) * 4.5;
				this.content.height = (this.item_templete.height + this.line.height) * 3.4;
				Laya.Tween.to(this.bg, { height: bg_h }, 150, Laya.Ease.strongOut);
				Laya.Tween.to(this.content, { alpha: 1 }, 150);
			}
			this.line.alpha = 0;
			Laya.Tween.to(this.line, { alpha: 1 }, 150);
			Laya.timer.once(150, this, () => {
				this._locking = false;
			});

			if (this._onStateChange) {
				this._onStateChange.run();
			}
		}

		private up() {
			this._is_down = false;
			this._locking = true;
			let bg_h: number = this.item_templete.height;
			Laya.Tween.to(this.bg, { height: bg_h }, 150, Laya.Ease.strongOut);
			Laya.Tween.to(this.content, { alpha: 0 }, 150);
			Laya.Tween.to(this.line, { alpha: 0 }, 150);
			if (this._onStateChange) {
				this._onStateChange.run();
			}
			Laya.timer.once(150, this, () => {
				this.out.visible = false;
				this.line.visible = false;
				this.content.visible = false;
				this._locking = false;
			});
		}
	}
}