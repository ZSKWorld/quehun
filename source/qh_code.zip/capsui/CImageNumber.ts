/**
* name 
*/
module capsui {

	export class CImageNumber extends UIComponent {
		private imgs: Laya.Image[] = [];
		private disX: number = 0;
		private singleWidth: number = 0;
		private imgUrl: string = '';
		private align: 'center' | 'left' | 'right' = 'left';
		private alignX: number = 0;

		constructor() {
			super();
		}

		public onCreate(): void {
			this.imgs = [];
			for (let i = 0; i < this.me.numChildren; i++) {
				const img = this.me.getChildByName(i.toString()) as Laya.Image;
				if (img) {
					this.imgs.push(img);
				}
			}
			if (!this.disX) this.disX = this.imgs[1].x - this.imgs[0].x;
			if (!this.singleWidth) this.singleWidth = this.imgs[0].width;
			this.alignX = this.me.x;
		}

		public onEnable() {

		}

		public onDisable() {

		}

		public setImgUrl(url: string) {
			this.imgUrl = url;
		}

		public setContent(str: string[]) {
			for (let i = 0; i < this.imgs.length; i++) {
				if (i < str.length) {
					this.imgs[i].visible = true;
					this.imgs[i].skin = game.Tools.localUISrc(this.imgUrl + str[i] + '.png');
					this.imgs[i].x = i * this.disX;
				} else {
					this.imgs[i].visible = false;
				}
			}
			const width = str.length * this.disX - (this.disX - this.singleWidth);
			this.me.width = width;
			this.me.pivotX = this.align === 'center' ? width / 2 : this.align === 'right' ? width : 0;
			this.me.x = this.alignX;
		}

	}
}