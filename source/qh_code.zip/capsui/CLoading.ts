/**
* name 
*/
module capsui{
	export class CLoading extends UIComponent{
		constructor() {
			super();
		}

		private img_round:Laya.Sprite;
		private img_shine:Laya.Sprite;
		private starttime:number = 0;

		public onCreate(){
			this.img_round = this.me.getChildByName('flower').getChildByName('round') as Laya.Sprite;
			this.img_shine = this.me.getChildByName('flower').getChildByName('shine') as Laya.Sprite;
		}

		public onEnable() {
			this.starttime = Laya.timer.currTimer;
			this.refreshShow();
			Laya.timer.frameLoop(1, this, this.refreshShow);
		}

		public onDisable() {
			Laya.timer.clearAll(this);
		}

		private refreshShow() {
			let t = Laya.timer.currTimer - this.starttime;
			if (t > 2000) {
				t = 0 ;
				this.starttime = Laya.timer.currTimer;
			}
			let rate = t / 2000;
			if (this.img_round) this.img_round.rotation = 360 * rate;
			if (rate < 0.5) {
				let r:number = rate * 2;
				if (this.img_shine) this.img_shine.alpha = r * r;
			} 
			else{
				let r:number = 2 - rate * 2;
				if (this.img_shine) this.img_shine.alpha = r * r;
			} 
		}

	}
}