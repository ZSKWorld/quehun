/**
* name 
*/
module capsui{
	export class CScrollBar extends UIComponent {

		private scrollpoint:Laya.Sprite;

		public islong:boolean = false;
		private handler_change:Laya.Handler;
		private _drag_scroll:boolean = false;
		private _width: number = 0;
		private _height: number = 0;
		private _click_height: number = 0;
		private _delta_half_height: number = 0;
		private _origin_y: number = 0;

		private deltaLongY: number = 0; // 处理按下时在长条内的情况

		public onCreate() {
			this.scrollpoint = this.me.getChildByName('scrollpoint') as Laya.Sprite;
			this._width = this.me.width;
			this._height = this.me.height;
			this._click_height = this._height;
			this._origin_y = (this.me.getChildAt(0) as Laya.Sprite).y;
			if (!this.islong) {
				this._click_height += this.scrollpoint.height;
				this.centerScrollBar(this._width, this._click_height);
			}
		}

		// hander_change = null时无法手动拖滚动条
		public init(handler_change:Laya.Handler) {
			this.handler_change = handler_change;

			if (handler_change) {
				this.me.on('mousedown', this, ()=>{
					this._drag_scroll = true;
					this.deltaLongY = 0;
					let rate:number = (this.me.mouseY - this._delta_half_height) / this._height;
					if (this.islong) {
						if (this.me.mouseY >= this.scrollpoint.y - this._delta_half_height && this.me.mouseY <= this.scrollpoint.y - this._delta_half_height + this.scrollpoint.height) {
							this.deltaLongY = this.scrollpoint.y - this.me.mouseY;
							this.centerScrollBar(4000, 2100);
							return;
						} else {
							if (this.me.mouseY > this.scrollpoint.y - this._delta_half_height + this.scrollpoint.height) {
								this.deltaLongY = - this.scrollpoint.height;
							}
							rate = (this.me.mouseY + this.deltaLongY - this._delta_half_height) / (this._height - this.scrollpoint.height);
						}
					}
					rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
					handler_change.runWith(rate);
					this.centerScrollBar(4000, 2100);
				});
				this.me.on('mousemove', this, ()=>{
					if (!this._drag_scroll) return;
					let rate: number;
					if (this.islong) {
						rate = (this.me.mouseY + this.deltaLongY - this._delta_half_height) / (this._height - this.scrollpoint.height);
					} else {
						rate = (this.me.mouseY + this.deltaLongY - this._delta_half_height) / this._height;
					}
					rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
					handler_change.runWith(rate);
				});
				this.me.on('mouseup', this, ()=>{
					this._drag_scroll = false;
					this.deltaLongY = 0;
					this.centerScrollBar(this._width, this._click_height);
				});
				this.me.on('mouseout', this, () => {
					this._drag_scroll = false;
					this.deltaLongY = 0;
					this.centerScrollBar(this._width, this._click_height);
				});
			}
		}

		// rate:滚动比例，screen_rate:可视区域/总视图长度，用来控制滚动条的显示与否以及滚动调的长度
		public setVal(rate:number, screen_rate:number) {
			rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
			screen_rate = screen_rate < 0 ? 0 : screen_rate;
			if (screen_rate >= 1) {
				if (this.me.visible) this.me.visible = false;
			} else {
				if (!this.me.visible) this.me.visible = true;
				if (!this.islong) {
					this.scrollpoint.y = this._height * rate + this._delta_half_height;
				} else {
					this.scrollpoint.height = this._height * screen_rate;
					if (this.scrollpoint.height < 20) this.scrollpoint.height = 20;
					this.scrollpoint.y = (this._height - this.scrollpoint.height) * rate + this._delta_half_height;
				}
			}
		}

		public reset() {
			this._drag_scroll = false;
			this.me.width = this._width;
		}

		private centerScrollBar(width: number, height: number) {
			let preWidth = this.me.width;
			this.me.width = width;

			this.me.x += (preWidth - width) / 2;
			for (let i = 0; i < this.me.numChildren; i++) {
				(this.me.getChildAt(i) as Laya.Sprite).x -= (preWidth - width) / 2;
			}

			let preHeight = this.me.height;
			this.me.height = height;

			this.me.y += (preHeight - height) / 2;
			for (let i = 0; i < this.me.numChildren; i++) {
				(this.me.getChildAt(i) as Laya.Sprite).y -= (preHeight - height) / 2;
			}
			this._delta_half_height = (this.me.height - this._height) / 2;
		}

		public updateHeight(height: number) {
			this._height = height;
			this._click_height = this._height;
			(this.me.getChildAt(0) as Laya.Sprite).height = height;
			this.me.height = height;
			if (!this.islong) {
				this._click_height += this.scrollpoint.height;
				// this.centerScrollBar(this._width, this._click_height);
			}
			(this.me.getChildAt(0) as Laya.Sprite).y = this._origin_y;
			this._delta_half_height = 0;
		}

		public set posY(y: number){
			this.me.y = y;
		}
	}
}