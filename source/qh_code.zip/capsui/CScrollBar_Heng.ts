/**
* name 
*/
module capsui{
	export class CScrollBar_Heng extends UIComponent {

		private scrollpoint: Laya.Sprite;
		private scrollBar: Laya.Sprite;

		public islong:boolean = false;
		private handler_change:Laya.Handler;
		private _drag_scroll:boolean = false;
		private _height: number = 0;
		private _click_width: number = 0;
		private _width: number = 0;
		private _delta_half_width: number = 0;
		private _origin_x: number = 0;

		private deltaLongX: number = 0; // 处理按下时在长条内的情况
		

		public onCreate() {
			this.scrollpoint = this.me.getChildByName('scrollpoint') as Laya.Sprite;
			this.scrollBar = this.me.getChildByName('scrollbar') as Laya.Sprite;
			this._height = this.me.height;
			this._width = this.me.width;
			this._click_width = this._width;
			this._origin_x = (this.me.getChildAt(0) as Laya.Sprite).x;
			if (!this.islong) {
				this._click_width += this.scrollpoint.width;
				this.centerScrollBar(this._click_width, this._height);
			}
		}

		// hander_change = null时无法手动拖滚动条
		public init(handler_change:Laya.Handler) {
			this.handler_change = handler_change;

			if (handler_change) {
				this.me.on('mousedown', this, () => {
					this._drag_scroll = true;
					this.deltaLongX = 0;
					let rate: number = (this.me.mouseX - this._delta_half_width) / this._width;
					if (this.islong) {
						if (this.me.mouseX >= this.scrollpoint.x - this._delta_half_width && this.me.mouseX <= this.scrollpoint.x - this._delta_half_width + this.scrollpoint.width) {
							this.deltaLongX = this.scrollpoint.x - this.me.mouseX;
							this.centerScrollBar(4000, 2100);
							return;
						} else {
							if (this.me.mouseX > this.scrollpoint.x - this._delta_half_width + this.scrollpoint.width) {
								this.deltaLongX = - this.scrollpoint.width;
							}
							rate = (this.me.mouseX + this.deltaLongX - this._delta_half_width) / (this._width - this.scrollpoint.width);
						}
					}
					rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
					handler_change.runWith(rate);
					this.centerScrollBar(4000, 2100);
				});
				this.me.on('mousemove', this, ()=>{
					if (!this._drag_scroll) return;
					let rate: number;
					if (this.islong) {
						rate = (this.me.mouseX + this.deltaLongX - this._delta_half_width) / (this._width - this.scrollpoint.width);
					} else {
						rate = (this.me.mouseX + this.deltaLongX - this._delta_half_width) / this._width;
					}
					rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
					handler_change.runWith(rate);
				});
				this.me.on('mouseup', this, ()=>{
					this._drag_scroll = false;
					this.deltaLongX = 0;
					this.centerScrollBar(this._click_width, this._height);
				});
				this.me.on('mouseout', this, ()=>{
					this._drag_scroll = false;
					this.deltaLongX = 0;
					this.centerScrollBar(this._click_width, this._height);
				});
			}
		}

		// rate:滚动比例，screen_rate:可视区域/总视图长度，用来控制滚动条的显示与否以及滚动调的长度
		public setVal(rate:number, screen_rate:number) {
			rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
			screen_rate = screen_rate < 0 ? 0 : screen_rate;
			if (screen_rate >= 1) {
				if (this.me.visible) this.me.visible = false;
			} else {
				if (!this.me.visible) this.me.visible = true;
				if (!this.islong) {
					this.scrollpoint.x = this._width * rate + this._delta_half_width;
				} else {
					this.scrollpoint.width = this._width * screen_rate;
					if (this.scrollpoint.width < 20) this.scrollpoint.width = 20;
					this.scrollpoint.x = (this._width - this.scrollpoint.width) * rate + this._delta_half_width;
				}
			}
		}

		public reset() {
			this._drag_scroll = false;
		}


		private centerScrollBar(width: number, height: number) {
			let preWidth = this.me.width;
			this.me.width = width;

			this.me.x += (preWidth - width) / 2;
			for (let i = 0; i < this.me.numChildren; i++) {
				(this.me.getChildAt(i) as Laya.Sprite).x -= (preWidth - width) / 2;
			}

			let preHeight = this.me.height;
			this.me.height = height;

			this.me.y += (preHeight - height) / 2;
			for (let i = 0; i < this.me.numChildren; i++) {
				(this.me.getChildAt(i) as Laya.Sprite).y -= (preHeight - height) / 2;
			}
			this._delta_half_width = (this.me.width - this._width) / 2;
		}

		/**
		 * 改变滚动条的宽度
		 * @param width 
		 */
		public updateWidth(width: number) {
			this._width = width;
			this._click_width = this._width;
			this.scrollBar.width = width;
			this.me.width = width;
			if (!this.islong) {
				this._click_width += this.scrollpoint.width;
			}
			this.scrollBar.y = this._origin_x;
			this._delta_half_width = 0;
		}
	}
}