/**
* 无限长竖滑动
* 记得添加条目之后修改height,滑动条会在不满的时候隐藏

结构：me
	 |
	 |-scrollbar（可以没有）
	 |	|
	 |	|-scrollpoint
	 |
	 |-content（panel）
	 	|
		|-templete
*/
module capsui{

	interface IItem {
		container:Laya.Sprite;
		value_index:number;
		cache_data:Object;
	}

	export class CScrollView extends UIComponent{
		public get scrollbar(): capsui.CScrollBar {
			return this._scrollbar;
		}
		private _scrollbar:capsui.CScrollBar = null;
		private _drag_scroll:boolean = false;
		private _container_items:Laya.Sprite = null;
		public _content:Laya.Panel = null;
		private _templete:Laya.Sprite = null;
		private _items:Array<IItem> = [];
		private _item_heights:Array<number> = [];
		private _total_height:number = 0;
		private _rate:number = 0;
		private _repeat_x:number = 1;
		private _span_x:number = 0;

		private _value_count:number = 0;
		private _render_func:Laya.Handler = null;

		private _elastic:boolean = false;
		private _bar_width: number = 0;
		public get items(): Array<IItem> {
			return this._items;
		}
		public set rate(value:number) {
			if (this._total_height <= this._content.height) this._content.vScrollBar.value = 0;
			else this._content.vScrollBar.value = (this._total_height - this._content.height) * value / 1;
		}

		public get rate(): number {
			return this._rate;
		}

		public get value_count(): number {
			return this._value_count;
		}

		//需要滑动
		public get need_scroll():boolean {
			return this._total_height > this._content.height;
		}

		public get total_height(): number {
			return this._total_height;
		}

		public get view_height(): number {
			return this._content.height;
		}

		public set posY(y: number) {
			this._scrollbar.posY = y;
			this._content.y = y;
		}

		public set height(h: number) {
			this._scrollbar.updateHeight(h);
			this._content.height = h;
		}

		public set total_height(value:number) {
			this._total_height = value;
			if (this._elastic) {
				this._container_items.height = value;
			  	value != 0 && this._content.refresh();
			}
		}

		// 接近底部， 比如聊天框可以以此来刷新
		public get near_bottom(): boolean {
			if (this.total_height <= this.view_height) return true;
			return (1 - this.rate) * this.value_count < 0.5;
		}

		/**
		 * 额外高度，用于下方需要多显示一截的情况
		 */
		private _extraHeight: number = 0;
		public set extraHeight(height: number) {
			this._extraHeight = height;
		}
		/*
		 * 添加项到列表中，需要输入高度，默认值使用templete的高度
         */
		public addItem(count:number, height:number = -1) {
			let old_count:number = this._value_count;
			if (height <= 0) height = this._templete.height;
			for (let i:number = 0; i < count; i++){
				this._item_heights.push(height);
			}
			this._value_count += count;
			if (this._repeat_x <= 1) {
				this.total_height += height * count;
			} else {
				this.total_height += height * Math.ceil(count / this._repeat_x);
			}
			
			if (old_count > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					if (this._items[i].value_index == old_count - 1) {
						let item:IItem = this._items[i];
						if (this._render_func) this._render_func.runWith({index: item.value_index, container: item.container, cache_data: item.cache_data});
					}
				}
			}
			this._onChange();
		}

		public addItems(heights:Array<number>) {
			let old_count:number = this._value_count;
			let _total_h:number = 0;
			for (let i:number = 0; i < heights.length; i++){
				this._item_heights.push(heights[i]);
				_total_h += heights[i];
			}
			this._value_count += heights.length;
			if (this._repeat_x <= 1) {
				this.total_height += _total_h;
			} else {
				// this._total_height = height * Math.ceil(this._value_count / this._repeat_x);
			}
			
			if (old_count > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					if (this._items[i].value_index == old_count - 1) {
						let item:IItem = this._items[i];
						if (this._render_func) this._render_func.runWith({index: item.value_index, container: item.container, cache_data: item.cache_data});
					}
				}
			}
			this._onChange();
		}

		//删除某项
		public delItem(index: number) {

			let h = 0;
			let items = [];
			for (let i: number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= index) {
					if (this._items[i].value_index == this.value_count - 1) {
					} else {
						// this._items[i].container.y = this._items[i].container.y - this._item_heights[this._items[i].value_index];
						// this._items[i].container.height = this._item_heights[this._items[i].value_index + 1];
						// app.Log.log('this._items[i].container.y ====' + this._items[i].container.y);
						// app.Log.log('this._items[i].container.height ====' + this._items[i].container.height);
						this._render_func.runWith({ index: this._items[i].value_index, container: this._items[i].container, cache_data: this._items[i].cache_data });
					}
				}
			}
			if (this._value_count == 0) return;
			let _h: number = this._item_heights[index];
			this.total_height -= _h;
			this._item_heights.splice(index, 1);
			this._value_count--;
			this._onChange(true);
		}

		/*
		 * 删除列表中最后一项
		 */
		public popItem() {
			if (this._value_count == 0) return;
			let _h:number = this._item_heights[this._item_heights.length - 1];
			let _y:number = this.total_height * this._rate;
			this.total_height -= _h;
			this._value_count --;
			this._item_heights.pop();
			this._onChange();
		}

		constructor() {
			super();
		}

		public onCreate(): void {
			let scrollbar:Laya.Sprite = this.me.getChildByName('scrollbar') as Laya.Sprite;
			if (scrollbar) {
				if (scrollbar.scriptMap) {
					this._scrollbar = scrollbar.scriptMap['capsui.CScrollBar'];
				}
				if (!this._scrollbar) {
					this._scrollbar = new capsui.CScrollBar();
					this._scrollbar.owner = scrollbar;
				}
				this._bar_width = scrollbar.width;
				
				Laya.timer.frameOnce(3, this, ()=>{
					this._scrollbar.init(new Laya.Handler(this, (_rate)=>{
						this.rate = _rate;
					}));
					// scrollbar.on('mousedown', this, ()=>{
					// 	this._drag_scroll = true;
					// 	this.rate = scrollbar.mouseY / scrollbar.height;
					// 	this.centerScrollBar(scrollbar, 4000);
					// });
					// scrollbar.on('mousemove', this, ()=>{
					// 	if (!this._drag_scroll) return;
					// 	this.rate = scrollbar.mouseY / scrollbar.height;
						
					// });
					// scrollbar.on('mouseup', this, ()=>{
					// 	if (!this._drag_scroll) return;
					// 	this._drag_scroll = false;
					// 	this.centerScrollBar(scrollbar, this._bar_width);
					// });

					// scrollbar.on('mouseout', this, ()=>{
					// 	if (!this._drag_scroll) return;
					// 	this._drag_scroll = false;
					// 	this.centerScrollBar(scrollbar, this._bar_width);
					// });
				});
			}
			this._content = this.me.getChildByName('content') as Laya.Panel;
			this._content.vScrollBarSkin = game.Tools.localUISrc('myres/vscroll.png');
			this._container_items = new Laya.Sprite();
			this._content.addChild(this._container_items);
			this._container_items.x = this._container_items.y = 0;
			this._container_items.height = 10000000; //这里有个隐患，如果列表特别长可能出问题，但是长也要长到几万项了，很难说
			Laya.timer.frameOnce(3, this, ()=>{
				this._content.vScrollBar.visible = false;
				this._content.vScrollBar.on('change', this, this._onChange);
			});
			this._templete = this._content.getChildByName('templete') as Laya.Sprite;
			this._templete.visible = false;
		}


		/**
		 * 初始化滑动页
		 * @param render_func 设置节点的函数
		 * @param min_height 可预见的单个节点最小的高度，用来初始化渲染个数，输入小于等于0的时候，默认用templete的高度
		 * @param repeat_x 一行有几个节点
		 * @param span_x 每个节点横向的间距
		 */
		public init_scrollview(render_func:Laya.Handler, min_height:number = -1, repeat_x:number = 1, span_x:number = 0) {
			this._repeat_x = repeat_x;
			this._span_x = span_x;
			this._render_func = render_func;
			if (this._items.length > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					this._container_items.removeChild(this._items[i].container);
					this._items[i].container.destroy();
				}
				this._items = [];
			}
			if (min_height <= 0) min_height = this._templete.height;
			let item_num:number = Math.ceil(this._content.height / min_height) + 2;
			item_num *= this._repeat_x;
			for (let i:number = 0; i < item_num; i++) {
				this._items.push({
					container: this._templete.scriptMap['capsui.UICopy']['getNodeClone'](),
					value_index: -1,
					cache_data: {}
				});
				this._content.removeChild(this._items[i].container);
				this._container_items.addChild(this._items[i].container);
			}
		}

		/*
		 * 重置列表状态，不会重置item个数和renderfunc等值
		 */
		public reset(): void {
			this._content.vScrollBar.stopScroll();
			this._drag_scroll = false;
			this._value_count = 0;
			this._item_heights = [];
			this.total_height = this._extraHeight;
			this.rate = 0;
			this._onRateChange(0);
		}

		public change_render_handler(render_func:Laya.Handler) {
			this.reset();
			this._render_func = render_func;
		}

		private _onChange(forceFresh: boolean = false): void {
			// if (this.total_height <= this._content.height) return;
			let vscrollbar:Laya.VScrollBar = this._content.vScrollBar;
			let k:number = 1;
			let v:number = vscrollbar.value * k;
			if (this.total_height <= this._content.height) {
				if (v > 0) vscrollbar.value = 0;
				else this._onRateChange(0,forceFresh);
			} else {
				if (!this._elastic && v > this.total_height - this._content.height) {
					vscrollbar.value = (this.total_height - this._content.height) / k;
				} else {
					let rate = v / (this.total_height - this._content.height);
					this._onRateChange(rate,forceFresh);
				}
			}
		}

		//滚动特定距离
		public scrollDelta(v:number) {
			if (this.need_scroll) {
				this._content.vScrollBar.value += v;
			}
		}

		protected _onRateChange(rate: number, forceFresh: boolean = false): void {
			let yline:number = 0;
			if (this.total_height <= this._content.height) {
				this._rate = 0;
				if (this._scrollbar) this._scrollbar.setVal(0, 1);
			} else {
				this._rate = rate;
				if (this._rate < 0) this._rate = 0;
				else if (this._rate > 1) {
					this._rate = 1;
				}
				if (this._scrollbar) this._scrollbar.setVal(rate, this._content.height / this.total_height);
				yline = (this.total_height - this._content.height) * this._rate;
			}
			
			let value_start:number = 0;
			let __y:number = 0;
			for (let i:number = 0; i < this._item_heights.length; i += this._repeat_x) {
				if (__y + this._item_heights[i] >= yline) {
					value_start = i;
					break; 
				} else {
					__y += this._item_heights[i];
				}
			}
			let item_start:number = value_start % this._items.length;
			for (let i:number = 0; i < this._items.length; i+= this._repeat_x) {
				let value_index:number = value_start + i;
				if (value_index >= this._value_count || __y - yline > this._content.height) {
					for (let j:number = 0; j < this._repeat_x; j++) {
						let item:IItem = this._items[(item_start + i + j) % this._items.length];
						item.container.visible = false;
						item.value_index = -1;
					}					
				} else {
					for (let j:number = 0; j < this._repeat_x; j++) {
						let item:IItem = this._items[(item_start + i + j) % this._items.length];
						let _value_index:number = value_index + j;
						if (_value_index >= this.value_count) {
							item.container.visible = false;
							item.value_index = -1;
						} else {
							if (item.value_index != _value_index || forceFresh) {
								item.container.visible = true;
								item.value_index = _value_index;
								item.container.y = __y;
								item.container.x = (this._templete.width + this._span_x) * j;
								this._container_items.removeChild(item.container);
								this._container_items.addChild(item.container);
								if (this._render_func) this._render_func.runWith({index: _value_index, container: item.container, cache_data: item.cache_data});
							}
						}
					}
					__y += this._item_heights[value_index];
				}
			}

			this.me.event('ratechange');
		}

		public wantToRefreshItem(value_index:number) {
			for (let i:number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index == value_index) {
					this._render_func.runWith({index: value_index, container: this._items[i].container, cache_data: this._items[i].cache_data});
				}
			}
		}

		public wantToRefreshAll() {
			for (let i:number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= 0)
					this._render_func.runWith({index: this._items[i].value_index, container: this._items[i].container, cache_data: this._items[i].cache_data});
			}
		}

		public setElastic(distance:number = 350, time:number = 250) {
			this._content.vScrollBar.elasticDistance = distance;
			this._content.vScrollBar.elasticBackTime = time;
			this._elastic = true;
		}
		

		public setScrollEnable(enable: boolean) {
			this._content.mouseEnabled = enable;
			if (this.scrollbar) {
				this.scrollbar.me.mouseEnabled = enable;
			}
		}

		/**
		 * 按照当前每一个Item的高度刷新高度
		 */
		public refreshHeight(heights: Array<number>) {
			this._item_heights = [];
			this.total_height = 0;
			for (let i: number = 0; i < heights.length; i++) {
				this._item_heights.push(heights[i]);
				this.total_height += heights[i];
				
			}
			this.total_height += this._extraHeight;
			this._onChange(true);

		}

		/**
		 * 获取当前在视野中的项，按照value_index排序
		 */
		public getItemsInView(): Array<IItem> {
			if (this.items.length == 0) return [];
			let items: Array<IItem> = [];
			for (let i: number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= 0 && this._items[i].container.visible) {
					if (this._items[i].container.y + this._item_heights[this._items[i].value_index] > this._content.vScrollBar.value && this._items[i].container.y < this._content.vScrollBar.value + this._content.height) {
						items.push(this._items[i]);
					}
				}
			}
			items.sort((a, b) => {
				return a.value_index - b.value_index;
			});
			return items;
		}
	}
}