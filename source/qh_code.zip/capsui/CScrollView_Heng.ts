/**
* 无限长竖滑动
* 记得添加条目之后修改height,滑动条会在不满的时候隐藏

结构：me
	 |
	 |-scrollbar（可以没有）
	 |	|
	 |	|-scrollpoint
	 |
	 |-content（panel）
	 	|
		|-templete
*/
module capsui{

	interface IItem {
		container:Laya.Sprite;
		value_index:number;
		cache_data:Object;
	}

	export class CScrollView_Heng extends UIComponent {

		private _scrollbar:capsui.CScrollBar_Heng = null;
		private _drag_scroll:boolean = false;
		private _container_items:Laya.Sprite = null;
		private _content:Laya.Panel = null;
		private _templete:Laya.Sprite = null;
		private _items:Array<IItem> = [];
		private _item_widths:Array<number> = [];
		private _total_width:number = 0;
		private _rate:number = 0;
		private _repeat_y:number = 1;
		private _span_y:number = 0;

		private _value_count:number = 0;
		private _render_func:Laya.Handler = null;

		private _elastic:boolean = false;
		private _bar_height: number = 0;
		private on_change_handler: Laya.Handler = null;

		public get items(): Array<IItem> {
			return this._items;
		}

		public get content(): Laya.Panel {
			return this._content;
		}

		public set rate(value:number) {
			if (this._total_width <= this._content.width) this._content.hScrollBar.value = 0;
			else this._content.hScrollBar.value = (this._total_width - this._content.width) * value / 1;
		}

		public get rate(): number {
			return this._rate;
		}

		public get value_count(): number {
			return this._value_count;
		}

		//需要滑动
		public get need_scroll():boolean {
			return this._total_width > this._content.width;
		}

		public get total_width(): number {
			return this._total_width;
		}

		public set total_width(value:number) {
			this._total_width = value;
			if (this._elastic) {
				this._container_items.width = value;
			  	value != 0 && this._content.refresh();
			}
		}

		public get view_width(): number {
			return this._content.width;
		}

		public set view_width(value:number) {
			this._content.width = value;
		}

		public get onChange(): Laya.Handler { 
			return this.on_change_handler;
		}

		public set onChange(value: Laya.Handler) {
			this.on_change_handler = value;
		}

		// 接近底部， 比如聊天框可以以此来刷新
		public get near_bottom(): boolean {
			if (this.total_width <= this.view_width) return true;
			return (1 - this.rate) * this.value_count < 0.5;
		}

		/*
		 * 添加项到列表中，需要输入高度，默认值使用templete的高度
         */
		public addItem(count:number, width:number = -1) {
			let old_count:number = this._value_count;
			if (width <= 0) width = this._templete.width;
			for (let i:number = 0; i < count; i++){
				this._item_widths.push(width);
			}
			this._value_count += count;
			if (this._repeat_y <= 1) {
				this.total_width += width * count;
			} else {
				this.total_width = width * Math.ceil(this._value_count / this._repeat_y);
			}
			
			if (old_count > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					if (this._items[i].value_index == old_count - 1) {
						let item:IItem = this._items[i];
						if (this._render_func) this._render_func.runWith({index: item.value_index, container: item.container, cache_data: item.cache_data});
					}
				}
			}
			this._onChange();
		}

		public addItems(widths:Array<number>) {
			let old_count:number = this._value_count;
			let _total_w:number = 0;
			for (let i:number = 0; i < widths.length; i++){
				this._item_widths.push(widths[i]);
				_total_w += widths[i];
			}
			this._value_count += widths.length;
			if (this._repeat_y <= 1) {
				this.total_width += _total_w;
			} else {
				// this._total_height = height * Math.ceil(this._value_count / this._repeat_x);
			}
			
			if (old_count > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					if (this._items[i].value_index == old_count - 1) {
						let item:IItem = this._items[i];
						if (this._render_func) this._render_func.runWith({index: item.value_index, container: item.container, cache_data: item.cache_data});
					}
				}
			}
			this._onChange();
		}

		//删除某项
		public delItem(index:number) {
			for (let i:number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= index) {
					if (this._items[i].value_index == this.value_count - 1) {

					} else {
						this._render_func.runWith({index: this._items[i].value_index, container: this._items[i].container, cache_data: this._items[i].cache_data});
					}
				}
			}
			if (this._value_count == 0) return;
			let _h: number = this._item_widths[index];
			this.total_width -= _h;
			this._item_widths.splice(index, 1);
			this._value_count--;
			this._onChange(true);
		}

		/*
		 * 删除列表中最后一项
		 */
		public popItem() {
			if (this._value_count == 0) return;
			let _w:number = this._item_widths[this._item_widths.length - 1];
			let _y:number = this.total_width * this._rate;
			this.total_width -= _w;
			this._value_count --;
			this._item_widths.pop();
			this._onChange();
		}

		constructor() {
			super();
		}

		public onCreate(): void {
			let scrollbar:Laya.Sprite = this.me.getChildByName('scrollbar') as Laya.Sprite;
			if (scrollbar) {
				if (scrollbar.scriptMap) {
					this._scrollbar = scrollbar.scriptMap['capsui.CScrollBar_Heng'];
				}
				if (!this._scrollbar) {
					this._scrollbar = new capsui.CScrollBar_Heng();
					this._scrollbar.owner = scrollbar;
				}
				this._bar_height = scrollbar.height;
			
				Laya.timer.frameOnce(3, this, ()=>{
					this._scrollbar.init(new Laya.Handler(this, (_rate)=>{
						this.rate = _rate;
					}));
				});
			}
			this._content = this.me.getChildByName('content') as Laya.Panel;
			this._content.hScrollBarSkin = '';
			this._container_items = new Laya.Sprite();
			this._content.addChild(this._container_items);
			this._container_items.x = this._container_items.y = 0;
			this._container_items.width = 10000000; //这里有个隐患，如果列表特别长可能出问题，但是长也要长到几万项了，很难说
			Laya.timer.frameOnce(3, this, ()=>{
				this._content.hScrollBar.visible = false;
				this._content.hScrollBar.on('change', this, this._onChange);
			});
			this._templete = this._content.getChildByName('templete') as Laya.Sprite;
			this._templete.visible = false;
		}

		/*
		 * 初始化滑动页
		 * render_func(data:IItem): 设置节点的函数
		 * min_width: 可预见的单个节点最小的宽度，用来初始化渲染个数，输入小于等于0的时候，默认用templete的宽度
		 */
		public init_scrollview(render_func:Laya.Handler, min_width:number = -1, repeat_y:number = 1, span_y:number = 0) {
			this._repeat_y = repeat_y;
			this._span_y = span_y;
			this._render_func = render_func;
			if (this._items.length > 0) {
				for (let i:number = 0; i < this._items.length; i++) {
					this._container_items.removeChild(this._items[i].container);
					this._items[i].container.destroy();
				}
				this._items = [];
			}
			if (min_width <= 0) min_width = this._templete.width;
			let item_num:number = Math.ceil(this._content.width / min_width) + 2;
			item_num *= this._repeat_y;
			for (let i:number = 0; i < item_num; i++) {
				this._items.push({
					container: this._templete.scriptMap['capsui.UICopy']['getNodeClone'](),
					value_index: -1,
					cache_data: {}
				});
				this._content.removeChild(this._items[i].container);
				this._container_items.addChild(this._items[i].container);
			}
		}

		/*
		 * 重置列表状态，不会重置item个数和renderfunc等值
		 */
		public reset(): void {
			this._content.hScrollBar.stopScroll();
			this._drag_scroll = false;
			this.total_width = 0;
			this._value_count = 0;
			this._item_widths = [];
			this.rate = 0;
			this._onRateChange(0);
		}

		public change_render_handler(render_func:Laya.Handler) {
			this.reset();
			this._render_func = render_func;
		}

		private _onChange(forceFresh: boolean = false): void {
			let hscrollbar:Laya.HScrollBar = this._content.hScrollBar as Laya.HScrollBar;
			let k:number = 1;
			let v:number = hscrollbar.value * k;
			if (this.total_width <= this._content.width) {
				if (v > 0) hscrollbar.value = 0;
				else this._onRateChange(0, forceFresh);
			} else {
				if (!this._elastic && v > this._total_width - this._content.width) {
					hscrollbar.value = (this._total_width - this._content.width) / k;
				} else {
					let rate = v / (this._total_width - this._content.width);
					this._onRateChange(rate, forceFresh);
				}
			}
			this.onChange?.run();
		}

		//滚动特定距离
		public scrollDelta(v:number) {
			if (this.need_scroll) {
				this._content.hScrollBar.value += v;
			}
		}

		protected _onRateChange(rate:number, forceFresh: boolean = false): void {
			let xline:number = 0;
			if (this._total_width <= this._content.width) {
				this._rate = 0;
				if (this._scrollbar) this._scrollbar.setVal(0, 1);
			} else {
				this._rate = rate;
				if (this._rate < 0) this._rate = 0;
				else if (this._rate > 1) {
					this._rate = 1;
				}
				if (this._scrollbar) this._scrollbar.setVal(rate, this._content.width / this.total_width);
				xline = (this._total_width - this._content.width) * this._rate;
			}
			
			let value_start:number = 0;
			let __x:number = 0;
			for (let i:number = 0; i < this._item_widths.length; i += this._repeat_y) {
				if (__x + this._item_widths[i] >= xline) {
					value_start = i;
					break; 
				} else {
					__x += this._item_widths[i];
				}
			}
			let item_start:number = value_start % this._items.length;
			for (let i:number = 0; i < this._items.length; i+= this._repeat_y) {
				let value_index:number = value_start + i;
				if (value_index >= this._value_count || __x - xline > this._content.width) {
					for (let j:number = 0; j < this._repeat_y; j++) {
						let item:IItem = this._items[(item_start + i + j) % this._items.length];
						item.container.visible = false;
						item.value_index = -1;
					}					
				} else {
					for (let j:number = 0; j < this._repeat_y; j++) {
						let item:IItem = this._items[(item_start + i + j) % this._items.length];
						let _value_index:number = value_index + j;
						if (_value_index >= this.value_count) {
							item.container.visible = false;
							item.value_index = -1;
						} else {
							if (item.value_index != _value_index || forceFresh) {
								item.container.visible = true;
								item.value_index = _value_index;
								item.container.y = (this._templete.height + this._span_y) * j;
								item.container.x = __x;
								this._container_items.removeChild(item.container);
								this._container_items.addChild(item.container);
								if (this._render_func) this._render_func.runWith({index: _value_index, container: item.container, cache_data: item.cache_data});
							}
						}
					}
					__x += this._item_widths[value_index];
				}
			}

			this.me.event('ratechange');
		}

		public wantToRefreshItem(value_index:number) {
			for (let i:number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index == value_index) {
					this._render_func.runWith({index: value_index, container: this._items[i].container, cache_data: this._items[i].cache_data});
				}
			}
		}

		public wantToRefreshAll() {
			for (let i:number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= 0)
					this._render_func.runWith({index: this._items[i].value_index, container: this._items[i].container, cache_data: this._items[i].cache_data});
			}
		}

		public setElastic(distance:number = 350, time:number = 250) {
			this._content.hScrollBar.elasticDistance = distance;
			this._content.hScrollBar.elasticBackTime = time;
			this._elastic = true;
		}
		
		private centerScrollBar(scrollbar: Laya.Sprite, height: number) {
			let preHeight = scrollbar.height;
			scrollbar.height = height;

			scrollbar.y += (preHeight - height) / 2;
			for (let i = 0; i < scrollbar.numChildren; i++) {
				(scrollbar.getChildAt(i) as Laya.Sprite).y -= (preHeight - height) / 2;
			}
		}

		/**
		 * 获取当前在视野中的项，按照value_index排序
		 */
		public getItemsInView(): Array<IItem> {
			if (this.items.length == 0) return [];
			let items: Array<IItem> = [];
			for (let i: number = 0; i < this._items.length; i++) {
				if (this._items[i].value_index >= 0 && this._items[i].container.visible) {
					if (this._items[i].container.x + this._item_widths[this._items[i].value_index] > this._content.hScrollBar.value && this._items[i].container.y < this._content.hScrollBar.value + this._content.height) {
						items.push(this._items[i]);
					}
				}
			}
			items.sort((a, b) => {
				return a.value_index - b.value_index;
			});
			return items;
		}
	}
}