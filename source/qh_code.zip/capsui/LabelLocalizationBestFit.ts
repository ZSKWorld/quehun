/**
* name 
*/
module capsui{

	/**
	 * 根据文本组件大小，自动缩小字体大小
	 */
	export class LabelLocalizationBestFit extends UIComponent{
        private label:Laya.Label;
        private origin_fontSize:number = 20;
        public min_fontSize:number = 3;
		private origin_width: number;
		constructor() {
			super();
		}

		public onCreate(): void {
            this.label = this.me as Laya.Label;
            this.origin_fontSize = (this.me as Laya.Label).fontSize;
			this.origin_width = this.me.width;
			this.me.on('change', this, this.refresh_size);
			this.refresh_size();
		}

		public onEnable() {

		}

		public onDisable(){

		}


		private refresh_size() {
			this.label.fontSize = this.origin_fontSize;
			this.label.wordWrap = false;
			let tw:number = this.label.textField.textWidth;
          
			if (tw > this.origin_width) {
				this.label.fontSize = this.min_fontSize;
				if (this.label.textField.textWidth > this.origin_width) {
					this.label.wordWrap = true;
				} else {
					this.label.fontSize = Math.floor(this.min_fontSize / (this.label.textField.textWidth / this.origin_width));
				}
			}
			this.label.repaint();
			
		}

	}
}