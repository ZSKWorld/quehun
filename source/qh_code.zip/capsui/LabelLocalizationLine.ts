/**
* name 
*/
module capsui{

	/**
	 * 设定一个行数(可以为小数)，当文本的行数超过这个值是，会自动缩小字体大小
	 */
	export class LabelLocalizationLine extends UIComponent{
        private label:Laya.Label;
        private origin_fontSize:number = 20;
        private origin_leading:number = 20;
        public max_line:number = 3;
		public adaptLeading: boolean = false;

		constructor() {
			super();
		}

		public onCreate(): void {
            this.label = this.me as Laya.Label;
            this.origin_fontSize = (this.me as Laya.Label).fontSize;
            this.origin_leading = (this.me as Laya.Label).leading;
			this.me.on('change', this, this.refresh_size);
			this.refresh_size();
		}

		public onEnable() {

		}

		public onDisable(){

		}

		public change_line_count(count:number) {
			this.max_line = count;
			this.refresh_size();
		}

		private refresh_size() {
			this.label.fontSize = this.origin_fontSize;
			let tw:number = this.label.textField.textHeight;
            let lineCount = Math.ceil(tw / (this.label.fontSize + this.label.leading));
			if (lineCount > this.max_line) {
				let fontSize = Math.floor(this.origin_fontSize / Math.sqrt(lineCount / this.max_line));
				this.label.fontSize = fontSize;
				if (this.adaptLeading) {
					let leading = Math.floor(this.origin_leading / Math.sqrt(lineCount / this.max_line));
					this.label.leading = leading;
				}
			} else {
				this.label.fontSize = this.origin_fontSize;
				this.label.leading = this.origin_leading;
			}
			this.label.repaint();
		}

	}
}