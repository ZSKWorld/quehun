/**
* name 
*/
module capsui{

	export class LabelLocalizationPosition extends UIComponent{

		private origin_x:number = 1;
		private origin_width:number = 1;
		public extend_right:boolean = true;

		constructor() {
			super();
		}

		public onCreate(): void {
			this.origin_x = this.me.x;
			this.origin_width = this.me.width;
			this.me.on('change', this, this.refresh_position);
			this.refresh_position();
		}

		public onEnable() {

		}

		public onDisable(){

		}

		private refresh_position() {
			let tw:number = (this.me as Laya.Label).textField.textWidth;
			if (tw > this.origin_width) {
				this.me.x = this.origin_x + (tw - this.origin_width) / 2 * this.me.scaleX * (this.extend_right ? 1 : -1);
			} else {
				this.me.x = this.origin_x;
			}
		}

	}
}