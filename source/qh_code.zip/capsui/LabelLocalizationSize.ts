
module capsui{

	export class LabelLocalizationSize extends UIComponent{

		private origin_scale:number = 1;
		public origin_width:number = 1;

		constructor() {
			super();
		}

		public onCreate(): void {
			this.origin_scale = this.me.scaleX;
			this.origin_width = this.me.width;
			this.me.on('change', this, this.refresh_size);
			this.refresh_size();
		}

		public onEnable() {

		}

		public onDisable(){

		}

		public change_width(width:number) {
			this.origin_width = width;
			this.refresh_size();
		}

		private refresh_size() {
			let tw:number = (this.me as Laya.Label).textField.textWidth;
			if (tw > this.origin_width) {
				let rate:number = tw / this.origin_width;
				this.me.width = this.origin_width * rate;
				this.me.scaleX = this.me.scaleY = this.origin_scale / rate;
			} else {
				this.me.width = this.origin_width;
				this.me.scaleX = this.me.scaleY = this.origin_scale;
			}
		}

	}
}