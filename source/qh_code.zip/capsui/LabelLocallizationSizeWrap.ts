/**
* name 
*/
module capsui{

	export class LabelLocalizationSizeWrap extends UIComponent{
        private label:Laya.Label;
        private origin_fontSize:number = 20;
        public min_fontSize: number = 0;
        private origin_width: number = 20;

		constructor() {
			super();
		}

		public onCreate(): void {
            this.label = this.me as Laya.Label;
            this.origin_width = this.me.width;
            this.origin_fontSize = (this.me as Laya.Label).fontSize;
			this.me.on('change', this, this.refresh_size);
			this.refresh_size();
		}

		public onEnable() {

		}

		public onDisable(){

		}


		private refresh_size() {
			this.label.fontSize = this.origin_fontSize;
			let tw:number = this.label.textField.textHeight;
			if (tw > this.label.fontSize + this.label.leading) {
				this.label.fontSize = this.min_fontSize;
                tw = this.label.textField.textHeight;
                if (tw <= this.label.fontSize + this.label.leading) {
                    this.label.fontSize = Math.floor(this.min_fontSize / this.label.textField.textWidth * this.origin_width);
                }
			}
			this.label.repaint();
			
		}

	}
}