
module capsui {

    /**
     * 挂载在Label物体下面，用于控制Label在不同语言下的字体大小，如果没有配置，则不设置
     */
    export class LanguageLableSetting extends UIComponent {

        private labelText: Laya.Label;
        public chs_fontSize: number | null = null;
        public chst_fontSize: number | null = null;
        public kr_fontSize: number | null = null;
        public en_fontSize: number|null = null;
        public jp_fontSize: number | null = null;
        public chs_font: string | null = null;
        public chst_font: string | null = null;
        public kr_font: string | null = null;
        public en_font: string | null = null;
        public jp_font: string | null = null;
     


        constructor() {
            super();

        }


        public onCreate(): void {
            this.labelText = this.me as Laya.Label;
            if (GameMgr.client_language == "chs") {
                if (this.chs_fontSize != null) {
                    this.labelText.fontSize = this.chs_fontSize;
                }
                if (this.chs_font != null) {
                    this.labelText.font = this.chs_font;
                }
            }
            if (GameMgr.client_language == "chs_t") {
                if (this.chst_fontSize != null) {
                    this.labelText.fontSize = this.chst_fontSize;
                }
                if (this.chst_font != null) {
                    this.labelText.font = this.chst_font;
                }
            }
            if (GameMgr.client_language == "en") {
                if (this.en_fontSize != null) {
                    this.labelText.fontSize = this.en_fontSize;
                }
                if (this.en_font != null) {
                    this.labelText.font = this.en_font;
                }
            }
            if (GameMgr.client_language == "jp") {
                if (this.jp_fontSize != null) {
                    this.labelText.fontSize = this.jp_fontSize;
                }
                if (this.jp_font != null) {
                    this.labelText.font = this.jp_font;
                }
            }
            if (GameMgr.client_language == "kr") {
                if (this.kr_fontSize != null) {
                    this.labelText.fontSize = this.kr_fontSize;
                }
                if (this.kr_font != null) {
                    this.labelText.font = this.kr_font;
                }
            }
        }

        public onEnable() {
            
        }

    }
}