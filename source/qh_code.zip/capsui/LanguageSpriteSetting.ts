
module capsui {

    /**
     * 挂载在物体下面，用于控制Sprite在不同语言下的不同位置，如果没有配置，则不设置
     */
    export class LanguageSpriteSetting extends UIComponent {


        public chs_x: number | null = null;
        public chs_y: number | null = null;
        public chs_width: number | null = null;
        public chs_height: number | null = null;
        public chst_x: number | null = null;
        public chst_y: number | null = null;
        public chst_width: number | null = null;
        public chst_height: number | null = null;
        public kr_x: number | null = null;
        public kr_y: number | null = null;
        public kr_width: number | null = null;
        public kr_height: number | null = null;
        public en_x: number | null = null;
        public en_y: number | null = null;
        public en_width: number | null = null;
        public en_height: number | null = null;
        public jp_x: number | null = null;
        public jp_y: number | null = null;
        public jp_width: number | null = null;
        public jp_height: number | null = null;




        constructor() {
            super();

        }


        public onCreate(): void {
           

        }

        public onEnable() {
            if (GameMgr.client_language == "chs") {
                if (this.chs_x != null) {
                    this.me.x = this.chs_x;
                }
                if (this.chs_y != null) {
                    this.me.y = this.chs_y;
                }
                if (this.chs_width != null) {
                    this.me.width = this.chs_width;
                }
                if (this.chs_height != null) {
                    this.me.height = this.chs_height;
                }
            }
            if (GameMgr.client_language == "chs_t") {
                if (this.chst_x != null) {
                    this.me.x = this.chst_x;
                }
                if (this.chst_y != null) {
                    this.me.y = this.chst_y;
                }
                if (this.chst_width != null) {
                    this.me.width = this.chst_width;
                }
                if (this.chst_height != null) {
                    this.me.height = this.chst_height;
                }
            }
            if (GameMgr.client_language == "en") {
                if (this.en_x != null) {
                    this.me.x = this.en_x;
                }
                if (this.en_y != null) {
                    this.me.y = this.en_y;
                }
                if (this.en_width != null) {
                    this.me.width = this.en_width;
                }
                if (this.en_height != null) {
                    this.me.height = this.en_height;
                }
            }
            if (GameMgr.client_language == "jp") {
                if (this.jp_x != null) {
                    this.me.x = this.jp_x;
                }
                if (this.jp_y != null) {
                    this.me.y = this.jp_y;
                }
                if (this.jp_width != null) {
                    this.me.width = this.jp_width;
                }
                if (this.jp_height != null) {
                    this.me.height = this.jp_height;
                }
            }
            if (GameMgr.client_language == "kr") {
                if (this.kr_x != null) {
                    this.me.x = this.kr_x;
                }
                if (this.kr_y != null) {
                    this.me.y = this.kr_y;
                }
                if (this.kr_width != null) {
                    this.me.width = this.kr_width;
                }
                if (this.kr_height != null) {
                    this.me.height = this.kr_height;
                }
            }
        }

    }
}