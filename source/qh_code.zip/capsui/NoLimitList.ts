/**
* name 
*/
module capsui{

	export class NoLimitList extends CScrollView {

		private _total_count:number = 0;
		private _func_load:Laya.Handler = null;
		private _loading:Laya.Sprite = null;
		private _duringLoading: boolean = false;
		private _load_id:number = 0;

		public set total_count(value: number) {
			this._total_count = value;
			this._pendingLoad();
		}

		public get total_count():number {
			return this._total_count;
		}

		constructor() {
			super();
		}

		public reset() {
			this._load_id = 0;
			this._total_count = 0;
			this._duringLoading = false;
			this._loading.visible = false;
			super.reset();
		}

		public onCreate() {
			this._loading = this.me.getChildByName('loading') as Laya.Sprite;
			this._loading.visible = false;
			super.onCreate();
		}

		public init_nolimitlist(func_load:Laya.Handler, func_render:Laya.Handler) {
			this._func_load = func_load;
			this.init_scrollview(func_render);
		}

		protected _onRateChange(value:number): void {
			super._onRateChange(value);
			this._pendingLoad();
		}

		private _pendingLoad(): void {
			if (!this._duringLoading) {
				if (this._total_count > this.value_count) {
					if ((1 - this.rate) * this.value_count <= 3) {
						if (this._func_load) { 
							this._duringLoading = true;
							this._load_id++;
							let __id:number = this._load_id;
							this._func_load.runWith(this.value_count);
							Laya.timer.once(700, this, ()=>{
								if (this._duringLoading && __id == this._load_id) {
									this._loading.visible = true;
								}
							});
						}
					}
				}
			}
		}

		public loadOver(succuess:boolean, delta_count:number): void {
			if (!this._duringLoading) return;
			this._duringLoading = false;
			if (this._loading) this._loading.visible = false;
			if (succuess) {
				this.addItem(delta_count);
			} else {
				this._total_count = this.value_count;
			}
		}

		public popItem() {
			this._total_count--;
			super.popItem();
		}

	}
}