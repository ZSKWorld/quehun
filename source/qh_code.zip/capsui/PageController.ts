/**
* name 
*/
module capsui{
	export class PageController {
		public me:Laya.Sprite;
		public btn_left:Laya.Button;
		public btn_right:Laya.Button;
		public btn_page:Laya.Button;
		public label_current_page:Laya.Label;
		public container_pages:Laya.Sprite;
		public scroll_pages:CScrollView;

		public current_index:number;
		public total_count:number;
		private render_page:Laya.Handler;
		private page_show_locking:boolean;
		private singleHeight: number;
		private maxHeight: number = -1;

		public constructor(me:Laya.Sprite, render_page:Laya.Handler, maxHeight: number = -1) {
			this.me = me;
			this.maxHeight = maxHeight;
			this.render_page = render_page;

			this.btn_left = this.me.getChildByName('btn_left') as Laya.Button;
			let left_cd:number = 0;
			this.btn_left.clickHandler = Laya.Handler.create(this, ()=>{
				this.change_page(this.current_index - 1, false);
			}, null, false);

			this.btn_right = this.me.getChildByName('btn_right') as Laya.Button;
			this.btn_right.clickHandler = Laya.Handler.create(this, ()=>{
				this.change_page(this.current_index + 1, false);
			}, null, false);
			this.label_current_page = this.me.getChildByName('curr_page') as Laya.Label;
			this.btn_page = this.me.getChildByName('btn_page') as Laya.Button;
			this.btn_page.clickHandler = Laya.Handler.create(this, ()=>{
				if (this.page_show_locking) return;
				this._show_page_choose();
			}, null, false);
			this.container_pages = this.me.getChildByName('container_pages') as Laya.Sprite;
			(this.container_pages.getChildByName('close') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				if (this.page_show_locking) return;
				this._close_page_choose();
			}, null, false);
			this.scroll_pages = (this.container_pages.getChildByName('bg') as Laya.Sprite).scriptMap['capsui.CScrollView'];
			this.scroll_pages.init_scrollview(Laya.Handler.create(this, this._render_page_choose_item, null, false));
			let templete = this.container_pages.getChildByName('bg').getChildByName('content').getChildByName('templete') as Laya.Sprite;
			this.singleHeight = templete.height;
		}

		public reset() {
			this.me.visible = false;
			this.container_pages.visible = false;
			this.scroll_pages.reset();
			this.btn_left.visible = false;
			this.btn_right.visible = false;
			this.btn_page.visible = false;
			this.page_show_locking = false;
			this.current_index = -1;
			this.label_current_page.text = '';
		}

		public set_total_page_count(total_count:number) {
			this.total_count = total_count;
			this.me.visible = this.total_count > 0;
			this.btn_page.visible = this.total_count > 1;
			this.btn_left.visible = this.current_index > 0;
			this.btn_right.visible = this.current_index + 1 < this.total_count;
			this.change_page(this.current_index, false);
		}

		public change_page(index:number, force:boolean) {
			if (index >= this.total_count) index = this.total_count - 1;
			if (index < 0) index = 0;
			if (!force && this.current_index == index) return;
			this.current_index = index;
			this.btn_left.visible = this.current_index > 0;
			this.btn_right.visible = this.current_index + 1 < this.total_count;
			this.label_current_page.text = (this.current_index + 1).toString();
			if (this.render_page) this.render_page.runWith(index);
		}

		private _show_page_choose() {
			if (this.total_count <= 1) {
				this.page_show_locking = false;
				return;
			}
			this.container_pages.visible = true;
			this.scroll_pages.reset();
			this.scroll_pages.addItem(this.total_count);
			let bg:Laya.Sprite = this.container_pages.getChildByName('bg') as Laya.Sprite;
			let content:Laya.Sprite = bg.getChildByName('content') as Laya.Sprite;

			if (this.maxHeight < 0 || this.total_count * this.singleHeight <= this.maxHeight) {
				content.height = this.singleHeight * this.total_count;
				bg.height = content.height;
				bg.y = this.container_pages.height - bg.height;
			} else {
				content.height = this.container_pages.height;
				bg.height = content.height;
				bg.y = 0;
			}
			bg.alpha = 0;
			Laya.Tween.to(bg, {alpha: 1}, 150);
			Laya.timer.once(150, this, ()=>{
				this.page_show_locking = false;
			});
		}

		private _close_page_choose() {
			let bg:Laya.Sprite = this.container_pages.getChildByName('bg') as Laya.Sprite;
			Laya.Tween.to(bg, {alpha: 0}, 150);
			this.page_show_locking = true;
			Laya.timer.once(150, this, ()=>{
				this.page_show_locking = false;
				this.container_pages.visible = false;
			});
		}

		private _render_page_choose_item(data) {
			let index:number = data.index;
			let container:Laya.Sprite = data.container;
			
			(container.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				if (this.page_show_locking) return;
				this.change_page(index, false);
				this._close_page_choose();
			}, null, false);

			(container.getChildByName('page') as Laya.Label).text = (index + 1).toString();
		}
	}
}