module capsui{
    /**
     * 富文本，根据所挂Label的属性生成对应的Laya.HTMLDivElement并为其赋值
     * 目前支持，字体大小，字体加粗，斜体，字体颜色，水平对齐方式，居中对齐方式等
     * TODO 图文混排，下划线
     */
    export class RichLabel extends UIComponent{
        
        constructor() {
            super();
        }

        public onCreate(): void {
            
        }

    }

    export class RichLabelProps{
        /**
         * 字体大小
         */
        public fontSize: number;
        public text: string;
        public color: string;
        public bold: boolean;
        public font: string;
        public align: string;
        public valign: string;
    }
}