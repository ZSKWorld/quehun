
module capsui {

	export class SpriteLocalizationPos extends UIComponent {
		public align_to_left: boolean = false;
		public align_to_right: boolean = false;
		public align_to_center: boolean = false;
		public align_to_top: boolean = false;
		public align_to_bottom: boolean = false;
		public align_to_middle: boolean = false;
		public horizontal_extension: boolean = false;
		public vertical_extension: boolean = false;
		private hAlignDistance: number;
		private vAlignDistance: number;
		private hExtensionDis: number;
		private vExtensionDis: number;

		constructor() {
			super();
		}

		public onCreate(): void {
			let parent = this.me.parent as Laya.Sprite;
			let pivotX = parent.pivotX || parent.width / 2;
			let pivotY = parent.pivotY || parent.height / 2;
			if (this.align_to_right) this.hAlignDistance = parent.width - this.me.x;
			if (this.align_to_left) this.hAlignDistance = - this.me.x;
			if (this.align_to_center) this.hAlignDistance = pivotX - this.me.x;
			if (this.align_to_top) this.vAlignDistance = parent.height - this.me.y;
			if (this.align_to_bottom) this.vAlignDistance = - this.me.y;
			if (this.align_to_middle) this.vAlignDistance = pivotY - this.me.y;
			if (this.horizontal_extension) this.hExtensionDis = parent.width - this.me.width;
			if (this.vertical_extension) this.vExtensionDis = parent.height - this.me.height;
			this.me.parent.on('size_change', this, this.refreshPos);
		}

		public onEnable() {

		}

		public onDisable() {

		}

		private refreshPos() {
			let parent = this.me.parent as Laya.Sprite;
			let pivotX = parent.pivotX || parent.width / 2;
			let pivotY = parent.pivotY || parent.height / 2;
			if (this.align_to_right) this.me.x = parent.width - this.hAlignDistance;
			if (this.align_to_left) this.me.x = - this.hAlignDistance;
			if (this.align_to_center) this.me.x = pivotX - this.hAlignDistance;
			if (this.align_to_top) this.me.y = parent.height - this.vAlignDistance;
			if (this.align_to_bottom) this.me.y = - this.vAlignDistance;
			if (this.align_to_middle) this.me.y = pivotY - this.vAlignDistance;
			if (this.horizontal_extension) this.me.width = parent.width - this.hExtensionDis;
			if (this.vertical_extension) this.me.height = parent.height - this.vExtensionDis;
		}

	}
}