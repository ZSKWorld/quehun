/**
* name 
*/
module capsui{
	export class UIAnim {
		
		private static _dfs_idmap(root:Laya.Sprite, data:Object, idmap:Object) {
			if (data['compId']) {
				idmap[data['compId']] = root;
			}
			if (data['child']) {
				for (let i = 0; i < data['child'].length; i++) {
					let __data:Object = data['child'][i];
					if (__data['props'] && __data['props']['name']) {
						let child:Laya.Sprite = root.getChildByName(__data['props']['name']) as Laya.Sprite;
						if (child) {
							this._dfs_idmap(child, __data, idmap);
						}
					}
				}
			}
		}

		public static createFrameAnimation(root:Laya.Sprite, viewfrom:any, animRootPath:string, animName:string): Laya.FrameAnimation {
			let __data:Object = viewfrom;
			if (!__data['animations'] || __data['animations'].length == 0) return null;
			let __animtiondata:Object = null;
			if (animName == '') {
				__animtiondata = __data['animations'][0];
			} else {
				for (let i:number = 0; i < __data['animations'].length; i++) {
					if (__data['animations'][i]['name'] == animName) {
						__animtiondata = __data['animations'][i];
						break;
					}
				}
			}
			if (__animtiondata == null) return null;
			let idmap:Object = {};

			let __templete_root:Object = viewfrom;
			if (animRootPath != '') {
				let _paths:Array<string> = animRootPath.split('/');
				for (let a:number = 0; a < _paths.length; a++) {
					if (__templete_root['child']) {
						for (let i = 0; i < __templete_root['child'].length; i++) {
							let d:Object = __templete_root['child'][i];
							if (d['props'] && d['props']['name'] && d['props']['name'] == _paths[a]) {
								__templete_root = d;
							}
						}
					} else {
						return null;
					}
				}
			}

			this._dfs_idmap(root, __templete_root, idmap);
			let frameanim:Laya.FrameAnimation = new Laya.FrameAnimation();
			frameanim._setUp(idmap, __animtiondata);
			frameanim.stop();
			return frameanim;
		}
	}
}