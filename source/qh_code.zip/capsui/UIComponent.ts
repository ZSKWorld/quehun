/**
* name 
*/
module capsui{

	//丑陋的layabox的附加脚本的封装
	export class UIComponent {

		private _me: Laya.Sprite = null; //绑定的位置
		private _root_view: Laya.View = null; //根UI

		constructor() {
		
		}

		public get me(): Laya.Sprite {
			return this._me;
		}

		public get root_view(): Laya.View {
			return this._root_view;
		}

		public set owner(value: any) {
			this._me = value;
			this._me.frameOnce(2, this, () => { 
				let _root:Laya.Sprite = this._me;
				while(_root && !(_root instanceof Laya.View)) {
					_root = _root.parent as Laya.Sprite;
				}
				this._root_view = _root as Laya.View;
				if (this._root_view) {
					this._root_view.on('onenable', this, this._onEnable);
					this._root_view.on('ondisable', this, this._onDisable);
				}
				this.onCreate();
			});
		}

		private _onEnable() {
			if (!this.me || this.me.destroyed) {
				this.onDestroy();
			} else {
				this.onEnable();
			}
		}

		private _onDisable() {
			if (!this.me || this.me.destroyed) {
				this.onDestroy();
			} else {
				this.onDisable();
			}
		}

		public onCreate(): void {

		}

		public onEnable(): void {

		}

		public onDisable(): void {

		}

		public onDestroy(): void {
			if (this._root_view) {
				this._root_view.off('onenable', this, this._onEnable);
				this._root_view.off('ondisable', this, this._onDisable);
			}
		}
	}
}