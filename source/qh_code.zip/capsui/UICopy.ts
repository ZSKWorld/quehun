/**
* name 
*/
module capsui{
	export class UICopy{

		private _data:any = null;

		private _me: Laya.Sprite = null; //绑定的位置
		public active:boolean = false;

		constructor() {
		
		}

		public get me(): Laya.Sprite {
			return this._me;
		}

		public set owner(value: any) {
			this._me = value;
		}

		public set copydata(data:any) {
			this._data = data;
		}

		public getNodeClone():Laya.Sprite {
			let ret:Laya.Sprite = Laya.View.createComp(this._data);
			this.me.parent.addChild(ret);
			return ret;
		}
	}
}