enum Color {
    /**
     * 纯白
     */
    WHITE = "#FFFFFF",

}