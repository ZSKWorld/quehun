namespace common{
    /**
     * 当前客户端支持的语言类型
     */
    export enum ELanguageType { 
        SIMPLE_CHINESE = 'chs',
        TRADITIONAL_CHINESE = 'chs_t',
        ENGLISH = 'en',
        JAPANESE = 'jp',
        KOREAN = 'kr',
    }

    /**
     * 当前客户端支持的地区
     */
    export enum ERegionType{
        SIMPLE_CHINESE = 'chs',
        TRADITIONAL_CHINESE = 'chs_t',
        ENGLISH = 'en',
        JAPANESE = 'jp',
        KOREAN = 'kr',
    }

    export enum EActivityType{
        TASK = 'task',
        EXCHANGE = 'exchange',
        CHEST_UP = 'chest_up',
        CHEST_REPLACE_UP = 'chest_replace_up',
        GAME_TASK = 'game_task',
        GAME_POINT = 'game_point',
        GAME_POINT_RANK = 'game_point_rank',
        RANK = 'rank',
        RICHMAN = 'richman',
        FLIP_TASK = 'flip_task',
        PERIOD_TASK = 'period_task',
        RANDOM_TASK = 'random_task',
        ACTIVITY_ROOM = 'activity_room',
        MINE = 'mine',
        RPG = 'rpg',
        RPG_V2 = 'rpg_v2',
        SEGMENT_TASK = 'segment_task',
        FEED = 'feed',
        ITEM = 'item',
        GACHA = 'gacha',
        SIMULATION = 'simulation',
        SIMULATION_V2 = 'sim_v2',
        COMBINING = 'combining',
        VILLAGE = 'village',
        FESTIVAL = 'festival',
        ISLAND = 'island',
        AMULET = 'amulet',
        STORY = 'story',
        CHOOSE_UP = 'choose_up',
        PROGRESS_REWARD = 'progress_reward',
        VOTE = 'vote',
        QUEST_CREW = 'quest_crew',
        SHOOT = 'shoot',
        BINGO = 'bingo',
        SNOWBALL = 'snowball',
        MARATHON = 'marathon',
        CHOOSE_GROUP_UP = 'choose_group_up',
        BANNER_ENTRANCE = 'banner_entrance', // 新增banner活动入口类型
    }

    export enum EBannerEntranceType { 
        MATCH = 1, // 大会室入口
    }


}