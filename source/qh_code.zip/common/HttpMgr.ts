namespace common{

    enum HttpMethod { 
        GET = "GET",
        POST = "POST",
        PUT = "PUT",
        DELETE = "DELETE",
    }

    enum HttpResponseType { 
        TEXT = "text",
        JSON = "json",
        BLOB = "blob",
        ARRAY_BUFFER = "arraybuffer",
        DOCUMENT = "document",
    }

    export class HttpMgr {
        public static get Inst(): HttpMgr {
            if (!HttpMgr.instance) {
                HttpMgr.instance = new HttpMgr();
            }
            return HttpMgr.instance;
        }
        private static instance: HttpMgr;


        public get(url: string, data?: any, responseType?: HttpResponseType, headers?: Array<any>, onComplete?: Laya.Handler, onError?: Laya.Handler): void {
            this.request(HttpMethod.GET, url, data, responseType, headers, onComplete, onError);

        }

        public post(url: string, data?: any, responseType?: HttpResponseType, headers?: Array<any>, onComplete?: Laya.Handler, onError?: Laya.Handler): void {
            this.request(HttpMethod.POST, url, data, responseType, headers, onComplete, onError);
        }

        public put(url: string, data?: any, responseType?: HttpResponseType, headers?: Array<any>, onComplete?: Laya.Handler, onError?: Laya.Handler): void {
            this.request(HttpMethod.PUT, url, data, responseType, headers, onComplete, onError);
        }

        public delete(url: string, data?: any, responseType?: HttpResponseType, headers?: Array<any>, onComplete?: Laya.Handler, onError?: Laya.Handler): void {
            this.request(HttpMethod.DELETE, url, data, responseType, headers, onComplete, onError);
        }

        private request(method: HttpMethod, url: string, data?: any, responseType?: HttpResponseType, headers?: Array<any>, onComplete?: Laya.Handler, onError?: Laya.Handler): void {
            let request = new Laya.HttpRequest();
            request.once(Laya.Event.COMPLETE, this, (data: any) => {
                app.Log.log(`HttpMgr request complete: ${url}, data: ${JSON.stringify(data)}`);
                if (onComplete) {
                    onComplete.runWith(data);
                }
            });
            
            request.once(Laya.Event.ERROR, this, (data: any) => {
                app.Log.log(`HttpMgr request error: ${url}, data: ${JSON.stringify(data)}`);
                if (onError) {
                    onError.runWith(data);
                }
            });
            request.send(url, data, method, responseType, headers);
        }

       
        
    }
}