interface IRelease{
    release();
}