namespace common {
    export class TimeConvert {

        private totalSeconds: number;
        private day;
        private hour;
        private minutes;
        private seconds;

        private secondsPerMinute = 60;
        private minutesPerHour = 60;
        private hoursPerDay = 24;

        /**
         * 将秒数转换成日/时/分/秒
         * @param seconds 用于换算的总秒数
         */
        constructor(seconds: number) {

            this.totalSeconds = seconds;
            this.convertFloor();

        }



        private convertFloor() {
            let remainingSeconds = this.totalSeconds;

            this.day = Math.floor(remainingSeconds / (this.hoursPerDay * this.minutesPerHour * this.secondsPerMinute));
            remainingSeconds -= this.day * this.hoursPerDay * this.minutesPerHour * this.secondsPerMinute;

            this.hour = Math.floor(remainingSeconds / (this.minutesPerHour * this.secondsPerMinute));
            remainingSeconds -= this.hour * this.minutesPerHour * this.secondsPerMinute;

            this.minutes = Math.floor(remainingSeconds / this.secondsPerMinute);
            this.seconds = remainingSeconds - this.minutes * this.secondsPerMinute;

        }

        // 添加get方法来访问计算后的时间
        public getDays(): number {
            return this.day;
        }

        public getHours(): number {
            return this.hour;
        }

        public getMinutes(): number {
            return this.minutes;
        }

        public getSeconds(): number {
            return this.seconds;
        }

        /**
         * 把秒数转化成DD:HH:MM:SS格式
         * @param totalSeconds 
         * @returns 
         */
        public toDDHHMMSS(): string {
            const days = this.getDays();
            const hours = this.getHours();
            const minutes = this.getMinutes();
            const seconds = this.getSeconds();
            const daysStr = days < 10 ? '0' + days : days.toString();
            const hoursStr = hours < 10 ? '0' + hours : hours.toString();
            const minutesStr = minutes < 10 ? '0' + minutes : minutes.toString();
            const secondsStr = seconds < 10 ? '0' + seconds : seconds.toString();
            return daysStr + ':' + hoursStr + ':' + minutesStr + ':' + secondsStr;
        }

        /**
         * 把秒数转化成HH:MM:SS格式
         * @param totalSeconds 
         * @returns 
         */
        public toHHMMSS(): string {
            const hours = this.getHours();
            const minutes = this.getMinutes();
            const seconds = this.getSeconds();
            const hoursStr = hours < 10 ? '0' + hours : hours.toString()
            const minutesStr = minutes < 10 ? '0' + minutes : minutes.toString()
            const secondsStr = seconds < 10 ? '0' + seconds : seconds.toString();
            return hoursStr + ':' + minutesStr + ':' + secondsStr;
        }

        /**
         * 把秒数转化成MM:SS格式
         * @param totalSeconds 
         * @returns 
         */
        public toMMSS(): string {
            const minutes = this.getMinutes();
            const seconds = this.getSeconds();
            const minutesStr = minutes < 10 ? '0' + minutes : minutes.toString();
            const secondsStr = seconds < 10 ? '0' + seconds : seconds.toString();
            return minutesStr + ':' + secondsStr;
        }
    }
}