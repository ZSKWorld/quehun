module common {
    export class ConfigHelper {
        public static split1 = "-";
        public static split2 = ",";
        /**
         * 将诸如'20001-1',这样的值切分成对应的数组<T>，如果包含",",则会返回多个数组
         * @param str 
         * @returns 这里返回值不会强制类型转换，即返回的是string类型
         */
        public static configString2Array<T>(str: string): Array<Array<T>> {

            //先由,切割
            let baseData:string[] =  str.split(ConfigHelper.split2);
            let result: Array<Array<T>> = new Array();
            for (let index = 0; index < baseData.length; index++) {
                //处理每一个
                let splitStr = baseData[index];
                let datas: string[] = splitStr.split(ConfigHelper.split1);
                let arrayItem: Array<T> = new Array();
                for (let i = 0; i < datas.length; i++) {
                    let data = datas[i]; 
                    try {
                        // 尝试将数据解析为 T 类型
                        let dataType = JSON.parse(data);
                        arrayItem.push(dataType);
                    } catch (error) {
                        // 如果解析失败，将原始字符串作为结果返回
                        arrayItem.push(data as unknown as T);
                    }
                }
                result.push(arrayItem);
            }
            return result;
        }

     
       
        /**
         * 根据PeriodTaskId获取对应的basetask
         * @param taskId 
         * @returns Sheet_Events_BaseTask
         */
        public static getPeriodTaskTarget(taskId): lqc.Sheet_Events_BaseTask{
            let baseTask = null;
            let period_task = cfg.activity.period_task.get(taskId);
            if (period_task) {
                baseTask = cfg.events.base_task.find(period_task.base_task_id);
            }
            return baseTask;
        }

        /**
         * 获取指定活动id对应的所有任务
         * @param activityId 
         * @returns lqc.Sheet_Activity_PeriodTask[]
         */
        public static getPeriodTasksByActivityId(activityId: number): lqc.Sheet_Activity_PeriodTask[] { 
            let tasks:lqc.Sheet_Activity_PeriodTask[] = [];
            cfg.activity.period_task.forEach((v, i) => { 
                if (v.activity_id == activityId) {
                    tasks.push(v);
                }
            })
            return tasks;
        }

        /**
         * desc_chs,desc_en等
         * @returns 获取当前语言的描述字段
         */
        public static getDescLangugeName() {
            return "desc_" + GameMgr.client_language;
        }

        /**
         * 通过活动id和奖励id获取对应的兑换id
         * @param activityId 
         * @param rewardId 
         * @returns 
         */
        public static getExchangeIdByRewardId(activityId:number,rewardId: number): number {
            let exchangeId = 0;
            cfg.activity.exchange.forEach((v, i) => {
                if (v.activity_id == activityId && v.reward_id == rewardId) {
                    exchangeId = v.id;
                }
            })
            return exchangeId;
        }

        /**
         * 获取当前语言名字，用于拼接字段
         * @returns 
         */
        public static getLanguageName() {
            //如果是英文的繁体，则使用chs2
            if (GameMgr.client_type == "en" && GameMgr.client_language == "chs_t") {
                return "name_chs2";
            }
            return GameMgr.client_language;
        }

     
    }


}

