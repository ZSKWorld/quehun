module common {
    export type Matrix = number[][];
    export type MatrixCoordinate = [number, number];

    export class MatrixUtils {
        /**
         * 将一个矩阵90°旋转
         * @param matrix 初始矩阵
         * @param direction 方向，0是顺时针，1是逆时针 ，默认是0
         * @param times 旋转次数，默认是1
         * @returns 
         */
        static rotate(matrix: Matrix, direction: 0 | 1 = 0, times: number = 1): Matrix {
            let rotatedMatrix = matrix;
            const rotations = times % 4; // 因为旋转四次会回到原位

            for (let i = 0; i < rotations; i++) {
                rotatedMatrix = direction === 0
                    ? this.rotateClockwise(rotatedMatrix)
                    : this.rotateCounterclockwise(rotatedMatrix);
            }

            return rotatedMatrix;
        }

        /**
         * 顺时针旋转
         * @param matrix 
         * @returns 
         */
        private static rotateClockwise(matrix: Matrix): Matrix {
            const rows = matrix.length;
            const cols = matrix[0].length;
            const rotated: Matrix = [];

            for (let col = 0; col < cols; col++) {
                const newRow: number[] = [];
                for (let row = rows - 1; row >= 0; row--) {
                    newRow.push(matrix[row][col]);
                }
                rotated.push(newRow);
            }

            return rotated;
        }

        /**
         * 逆时针旋转矩阵
         * @param matrix 
         * @returns 
         */
        private static rotateCounterclockwise(matrix: Matrix): Matrix {
            const rows = matrix.length;
            const cols = matrix[0].length;
            const rotated: Matrix = [];

            for (let col = cols - 1; col >= 0; col--) {
                const newRow: number[] = [];
                for (let row = 0; row < rows; row++) {
                    newRow.push(matrix[row][col]);
                }
                rotated.push(newRow);
            }

            return rotated;
        }

        /**
         * 相同大小矩阵相减。
         * @param matrixA - 被减矩阵。
         * @param matrixB - 减矩阵。
         * @returns 相减后的矩阵，如果矩阵大小不同则返回null。
         */
        static subtract(matrixA: Matrix, matrixB: Matrix): Matrix | null {
            if (matrixA.length !== matrixB.length || matrixA[0].length !== matrixB[0].length) {
                return null;
            }

            return matrixA.map((row, i) =>
                row.map((val, j) => val - matrixB[i][j])
            );
        }


        /**
         * 将矩阵A放入矩阵B中，从指定起始位置开始。
         * @param matrixA 要放入的矩阵
         * @param matrixB 被放入的矩阵
         * @param startRow 起始行位置
         * @param startCol 起始列位置
         * @returns 包含相加后的矩阵和不在矩阵B中的矩阵坐标数组的对象。
         */
        static placeMatrix(matrixA: Matrix, matrixB: Matrix, startRow: number, startCol: number): { result: Matrix | null, overflow: MatrixCoordinate[] } {
            const rowsA = matrixA.length;
            const colsA = matrixA[0].length;
            const rowsB = matrixB.length;
            const colsB = matrixB[0].length;

            const overflow: MatrixCoordinate[] = [];
            const result: Matrix = matrixB.map(row => row.slice());

            for (let i = 0; i < rowsA; i++) {
                for (let j = 0; j < colsA; j++) {
                    const targetRow = startRow + i;
                    const targetCol = startCol + j;

                    if (targetRow >= rowsB || targetCol >= colsB) {
                        // 确保不超过矩阵B的范围
                        overflow.push([i, j]);
                    } else {
                        // 确保在范围内
                        result[targetRow][targetCol] += matrixA[i][j];
                    }
                }
            }

            return { result, overflow };

        }

        /**
         * 旋转矩阵中的指定坐标
         * @param matrix 初始矩阵
         * @param coordinates 需要旋转的坐标数组
         * @param direction 方向，0是顺时针，1是逆时针，默认是0
         * @param times 旋转次数，默认是1
         * @returns 包含旋转后的矩阵和坐标的对象
         */
        static rotateCoordinates(matrix: Matrix, coordinates: MatrixCoordinate[], direction: 0 | 1 = 0, times: number = 1): { rotatedMatrix: Matrix, rotatedCoordinates: MatrixCoordinate[] } {
            const rotatedMatrix = this.rotate(matrix, direction, times);
            const size = { rows: matrix.length, cols: matrix[0].length };
            const rotatedCoordinates: MatrixCoordinate[] = coordinates.map(([row, col]) => {
                let newRow = row;
                let newCol = col;
                for (let i = 0; i < times; i++) {
                    if (direction === 0) { // 顺时针
                        [newRow, newCol] = [newCol, size.rows - 1 - newRow];
                    } else { // 逆时针
                        [newRow, newCol] = [size.cols - 1 - newCol, newRow];
                    }
                }
                return [newRow, newCol];
            });

            return { rotatedMatrix, rotatedCoordinates };
        }

        /**
         * 判断两个矩阵是否完全相等
         * @param matrixA 
         * @param matrixB 
         * @returns 
         */
        static isMatrixEqual(matrixA: Matrix,matrixB:Matrix) {
            let aString = JSON.stringify(matrixA);
            let bString = JSON.stringify(matrixB);
            return aString == bString;
        }

        
    }

}