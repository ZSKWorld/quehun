/**
 * 协议号，通过这个协议号和ProtoHelper取对应接口发送消息时使用的字符串
 * 每次添加枚举，需要到ProtoHelper的字典内手动添加对应的字符串
 */
enum ProtoCode {
    /**
     * 剧情打点
     */
    SPOTLOGGING = "spot_detail",
    /**
     * 开始匹配
     */
    MATCH_UNIFIED = "startUnifiedMatch",
    /**
     * 取消匹配
     */
    STOPMATCH_UNIFIED = "cancelUnifiedMatch",
    /**
     * 完成活动任务
     */
    COMPLETE_PERIOD_ACTIVITY_TASK = "completePeriodActivityTask",
    /**
     * 批量完成活动任务
     */
    COMPLETE_PERIOD_ACTIVITY_TASK_BATCH = "completePeriodActivityTaskBatch",
    /**
     * 请求创建房间
     */
    REQUEST_CREATE_ROOM = "createRoom",
    /**
     * 海岛活动区域移动
     */
    ISLAND_ACTIVITY_MOVE = "islandActivityMove",
    /**
     * 海岛活动购买物品
     */
    ISLAND_ACTIVITY_BUY = "islandActivityBuy",
    /**
     * 海岛活动出售物品
     */
    ISLAND_ACTIVITY_SELL = "islandActivitySell",
    /**
     * 海岛活动整理背包
     */
    ISLAND_ACTIVITY_TIDY_BAG = "islandActivityTidyBag",
    /**
     * 海岛活动解锁背包格子
     */
    ISLAND_ACTIVITY_UNLOCK_BAG_GRID = "islandActivityUnlockBagGrid",
    /**
     * 请求创建大会室
     */
    REQ_CREATE_CUSTOMIZED_CONTEST = "createCustomizedContest",
    /**
     * 请求更新大会室
     */
    UPDATE_MANAGER_CUSTOMIZED_CONTEST = "updateManagerCustomizedContest",
    /**
     * 请求大会室网页登录token
     */
    GENERATE_CONTEST_MANAGER_LOGINCODE = "generateContestManagerLoginCode",
    /**
     * 请求当前用户管理的大会室列表
     */
    FETCH_MANAGER_CUSTOMIZED_CONTEST_LIST = "fetchManagerCustomizedContestList",
    /**
     * 获取除了自己管理的以外的大会室列表
     */
    FETCH_CUSTOMIZED_CONTEST_LIST = "fetchCustomizedContestList",
    /**
     * 获取多个玩家的简要信息
     */
    FETCH_MULTI_ACCOUNT_BRIEF = "fetchMultiAccountBrief",
    /*
     * 获取邮件数据
     */
    FETCH_MAIL_INFO = "fetchMailInfo",
    
}

enum ServerType {
    /**
     * 大厅
     */
    LOBBY = "Lobby",
    /**
     * 麻将
     */
    MJ = "FastTest",
    
}