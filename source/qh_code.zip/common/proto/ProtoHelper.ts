module common {

    /**
     * 协助进行消息发送的工具类
     */
    export class ProtoHelper {
        /**
         * 手动制作的字典
         */
        private static codeDictionary: basic.Dictionary<ProtoCode, string> = new basic.Dictionary([
            [ProtoCode.SPOTLOGGING, "spot_detail"],
            [ProtoCode.MATCH_UNIFIED, "startUnifiedMatch"],
            [ProtoCode.STOPMATCH_UNIFIED, "cancelUnifiedMatch"],
            [ProtoCode.COMPLETE_PERIOD_ACTIVITY_TASK, "completePeriodActivityTask"],
            [ProtoCode.COMPLETE_PERIOD_ACTIVITY_TASK_BATCH, "completePeriodActivityTaskBatch"],
            [ProtoCode.REQUEST_CREATE_ROOM, "createRoom"],

        ]);

        private static serverDictionary: basic.Dictionary<ServerType, string> = new basic.Dictionary([
            [ServerType.LOBBY, "Lobby"],
        ]);

        /**
         * 通过枚举获取对应的字符串,已废弃，请使用game.ERequest
         * @param code CategoryCode
         */
        static getCode(code: ProtoCode): string {
            
            if (this.codeDictionary.has(code)) {
                return this.codeDictionary.get(code);
            }
            app.Log.log(`未找到${code.toString()}对应的字符串`);
            return null;
        }

        /**
         * 通过枚举获取对应的服务器字符串,已废弃，可以直接使用ServerType枚举,ServerType.LOBBY
         */
        static getServer(code: ServerType): string {
            if (this.serverDictionary.has(code)) {
                return this.serverDictionary.get(code);
            }
            app.Log.log(`未找到${code.toString()}对应的字符串`);
            return null;
        }
    }
}