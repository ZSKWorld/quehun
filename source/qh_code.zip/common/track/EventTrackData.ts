namespace common {
    export interface IEventTrackVtuber2601 {
        /**
         * 活动页面打开的时长(单位：秒)
         */
        open_time: number;
        /**
         * 点击关注按钮次数
         */
        focus_times: number;
    }
}