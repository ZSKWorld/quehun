namespace common{

    export enum ETrackCategory {
        GAME_STATUS = 'game_status',

        // 登录游戏
        GAME_START = 'game_start',                   /** 启动游戏时候 */
        ENTER_ENTRANCE = 'enter_entrance',           /** 看见登陆界面 */
        LOGIN_LOADING_START = 'login_loading_start', /** 登录加载开始 */
        LOGIN_LOADING_END = 'login_loading_end',     /** 登录后加载成功 */

        // 对局
        MATCH_LOADING_START = 'match_loading_start', /** 对局加载开始 */
        MATCH_LOADING_FAIL = 'match_loading_fail',   /** 对局资源加载失败 */
        MATCH_EFFECT_LOADED = 'match_effect_loaded', /** 特效加载时长 */
        MATCH_LOADING_END = 'match_loading_end',     /** 对局加载结束 */

        // 观战
        OB_LOADING_START = 'ob_loading_start',       /** 观战loading开始 */
        OB_LOADING_END = 'ob_loading_end',           /** 观战Loading结束 */

        // 牌谱
        PAIPU_LOADING_START = 'paipu_loading_start', /** 牌谱Loading开始 */
        PAIPU_LOADING_END = 'paipu_loading_end',     /** 牌谱Loading结束 */
        YUEKA_OPEN_PAIPU = 'yueka_open_paipu',       /** 月卡打开牌谱 */
        GAME_RECORD_LIST_ERROR = 'game_record_list_error', /** 拉取牌谱列表数据出错 */

        // 游戏线路
        network_route = 'network_route',             /** 对局网络质量定期报告 */

        // 报错监听
        WEBGL_LOSE_CONTEXT = 'webgl_lose_context',   /** WEBGL上下文丢失 */

        // ai检测
        ERROR_REPORT = 'error-report',               /** 网页对局协议和匹配调用栈检查出错 */
        REPORT_ERROR = 'report-error',               /** 没移动鼠标进行匹配的玩家 */
        RE_ERR = 're-err',                           /** 通过注入修改栈 */

        // 崩溃
        CRASH_AUDIO = 'crash_audio',                 /** web崩溃 */

        // 网络
        LOBBY_RQS_COUNT_ERROR = 'lobby_rqs_count_error',   /** 大厅网络请求数量异常 */
        GAME_RQS_COUNT_ERROR = 'game_rqs_count_error',     /** 对局网络请求数量异常 */
        LOBBY_RQS_COUNT_SUMMARY = 'lobby_rqs_count_summary', /** 3分钟内大厅网络请求数量 */
        GAME_RQS_COUNT_SUMMARY = 'game_rqs_count_summary',   /** 3分钟内对局网络请求数量 */
        RES_NO_ERROR_CODE = 'res_no_error_code',     /** 收到无报错码的报错协议 */

        // 再来一局
        START_ANOTHER_GAME = 'start_another_game',   /** 点击再来一局 */
        ENTER_ANOTHER_GAME = 'enter_another_game',   /** 再来一局成功匹配 */

        // Maka
        MAKA_GANG_ERROR = 'maka_gang_error',         /** 杠数据异常 */
        MAKA_ROUND_ERROR = 'maka_round_error',       /** web round数据异常 */

        // 玩家操作相关
        CANCEL_HU = 'cancel_hu',                     /** 玩家弃和 */

        // 对局重连相关(在test的logstore内)
        RECONNECT_SUCCESS = 'reconnect_success',     /** 特殊的用于是否打开主备的ab测，上报重连相关信息的日志 */
        ENTER_BLACK_HOLE = 'enter_black_hole',       /** 判定进入黑洞导致断连 */
        RECONNECT_FAILED = 'reconnect_failed',       /** 超过30s未重连成功 */
        ROUTE_DELAY_LOG = 'route_delay_log',         /** 和heartbeat一起，记录延迟,仅kr */

        // 进入对局报错相关(在test的logstore内)
        SHOW_EFFECT_ERROR = 'show_effect_error',     /** 胡牌动画播放异常，卡在84的一种情况 */
        MJ_LOAD_GROUP_ERROR = 'mj_load_group_error', /** 进入对局加载组失败，70-84中如果游戏下载失败发送 */
        OPEN_CONNECT_TIMEOUT = 'open_connect_timeout', /** 连接对局超时（30s） */
        MJ_CONNECT_SUCCESS = 'mj_connect_success',   /** 连接对局成功 */
        MJ_CONNECT_TIMEOUT = 'mj_connect_timeout',   /** 进入对局总消耗时间超过70s */

        //活动数据埋点
        ACTIVITY_VTUBER_2601 = 'activity_vtuber_2601',   /** 主播活动数据埋点 */
    }


    /**
     * 数据埋点，操作流程为在Category中新增枚举，然后调用trackEventByType进行打点
     * 需要同步Confluence文档中的埋点说明
     */
    export class EventTrackMgr { 
        private static _instance: EventTrackMgr;

        public static get Instance(): EventTrackMgr {
            if (this._instance == null) {
                this._instance = new EventTrackMgr();
            }
            return this._instance;
        }

        /**
         * 事件打点，通过category区分具体事件
         * @param category ETrackCategory
         * @param data EventTrackData.ts中的数据结构
         * @param only_chst 是否只在繁体环境上传，默认为false
         */
        public trackEvent(category: string, data: Object, only_chst: boolean = true): void { 
            app.Log.log('【TrackEvent】'+category + ': ' + JSON.stringify(data) + ", only_chst=" + only_chst);
            GameMgr.Inst.postInfo2Server(category, data, only_chst);
        }
        

        /**
         * 在开发环境下事件打点，通过category区分具体事件
         * @param category 
         * @param data 
         * @param only_chst 
         */
        public trackEventDev(category: string, data: Object, only_chst: boolean = true) {
            GameMgr.Inst.postInfo2ServerInDev(category, data, only_chst);
        }

        /**
         * 事件打点，category固定为game_status,通过type区分具体事件
         * @param type 
         * @param data 
         * @param only_chst 
         */
        public trackEventByType(type: string, data: Object, only_chst: boolean = true) {
            data['type'] = type;
            this.trackEvent('game_status', data, only_chst);
        }


    }
}