enum EventCode{
    /**
     * 在活动界面，点击PeriodTask种类的领取
     */
    ACTIVITY_PERIOD_TASK_GET_REWARD = "ActivityPeriodTaskGetReward",
    /**
     * 在活动界面，点击PeriodTask种类的领取，发送消息结束
     */
    ACTIVITY_PERIOD_TASK_GET_REWARD_FINISH = "ActivityPeriodTaskGetRewardFinish",
    /**
     * 有活动结束
     * param activityId 活动id
     */
    REMOVE_ACTIVITY = "RemoveActivity",
    /**
     * 竹云庆典数据更新
     */
    ACTIVITY_SPOT_UPDATE = "ActivitySpotUpdate",
    /**
     * 开始匹配页面
     */
    OPEN_MATCH_UI = "OpenMatchUI",
    /**
     * 关闭匹配页面
     */
    CLOSE_MATCH_UI = "CloseMatchUI",
    /**
     * 点击邀请界面的加入按钮
     */
    ON_CLICK_JOIN_ROOM = "OnClickJoinRoom",
    /**
     * 徽章数据变化
     */
    BADGE_DATA_UPDATE = "BadgeDataUpdate",
    /** 
     * MAKA分析次数变更
     */
    ON_MAKA_ANALYSIS_COUNT_CHANGE = "OnMakaAnalysisCountChange",
    /**
     * MAKA分析数据列表变更
     */
    ON_MAKA_ANALYSIS_LIST_CHANGE = "OnMakaAnalysisListChange",
    /**
     * 请求服务器分析MAKA完成
     */
    ON_MAKA_ANALYSIS_COMPLETE = "OnMakaAnalysisComplete",
    /**
     * 请求详细的MAKA分析数据
     * 
     */
    ON_FETCH_MAKA_DETAIL_COMPLETE = "OnFetchMakaDetailComplete",
    /**
     * 月卡数据变更
     */
    MONTH_TICKET_CHANGE = "MonthTicketChange",
    /**
     * Maka维护信息变更
     */
    MAKA_MAINTAIN_CHANGE = "MakaMaintainChange",
    /**
     * 服饰投票女性排名更新
     */
    CLOTHES_VOTE_FAMALE_RANK_UPDATE = "ClothesVoteFamaleRankUpdate",
    /**
     * 服饰投票男性排名更新
     */
    CLOTHES_VOTE_MALE_RANK_UPDATE = "ClothesVotemaleRankUpdate",
    /**
     * 服饰投票热度进度更新
     */
    CLOTHES_VOTE_HOT_PROGRESS_UPDATE = "ClothesVoteHotProgressUpdate",
    /**
     * 服饰投票个人投票数量更新
     */
    CLOTHES_VOTE_COUNT_UPDATE = "ClothesVoteCountUpdate",
    /**
     * 服饰投票热度奖励领取数据更新
     */
    CLOTHES_VOTE_PROGRESS_REWARDED_UPDATE = "ClothesVoteProgressRewardedUpdate",
    /**
     * 活动周期任务更新,参数是任务id
     */
    ACTIVITY_PERIOD_TASK_UPDATE = "ActivityPeriodTaskUpdate",
    /**
     * 活动随机任务更新,参数是任务id
     */
    ACTIVITY_RANDOM_TASK_UPDATE = "ActivityRandomTaskUpdate",
    /**
     * Maka分析窗口关闭
     */
    ON_MAKA_ANALYSIS_WINDOW_CLOSE = "OnMakaAnalysisWindowClose",
    /**
     * BGM改变
     */
    ON_BGM_CHANGE = "OnBgmChange",
    /**
     * 设置界面滑动条拖动开始
     */
    CONFIG_SLIDER_START_CHANGE = "config_slider_start_change",
    /**
     * 设置界面滑动条拖动结束
     */
    CONFIG_SLIDER_END_CHANGE = "config_slider_end_change",
    /**
     * 设置界面某些选项更改需要重启生效
     */
    CONFIG_NEED_RESTART = "config_need_restart",
    /**
     * 语言改变
     */
    CONFIG_LANGUAGE_CHANGE = "language_change",
    /**
     * 有活动开启
     * param activityId 活动id
     */
    ADD_ACTIVITIES = "AddActivities",
    /**
     * MMO装备页信息变动
     */
    MMO_EQUIPMENT_INFO_CHANGE = "mmo_equipment_info_change",
}