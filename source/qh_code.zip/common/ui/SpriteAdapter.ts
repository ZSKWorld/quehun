enum SpriteAdapterType {
    /**
     * 在不改变SpriteA的大小的情况下，他的左边缘与目标的左边缘保持固定差值
     */
    LEFT2LEFT = 1,
    /**
     * 在不改变SpriteA的大小的情况下，他的左边缘与目标的右边缘保持固定差值
     */
    LEFT2RIGHT = 2,
    /**
     * 在不改变SpriteA的大小的情况下，他的右边缘与目标的左边缘保持固定差值
     */
    RIGHT2LEFT = 3,
    /**
     * 在不改变SpriteA的大小的情况下，他的右边缘与目标的右边缘保持固定差值
     */
    RIGHT2RIGHT = 4,
    /**
     * 在不改变SpriteA的大小的情况下，他的顶部边缘与目标的顶部边缘保持固定差值
     */
    TOP2TOP = 5,
    /**
     * 在不改变SpriteA的大小的情况下，他的顶部边缘与目标的底部边缘保持固定差值
     */
    TOP2BOTTOM = 6,
    /**
     * 在不改变SpriteA的大小的情况下，他的底部边缘与目标的底部边缘保持固定差值
     */
    BOTTOM2BOTTOM = 7,
    /**
     * 在不改变SpriteA的大小的情况下，他的底部边缘与目标的顶部边缘保持固定差值
     */
    BOTTOM2TOP = 8,
    /**
     * 改变SpriteA的大小，使他的宽度与目标宽度差值固定
     */
    WIDTH2WIDTH = 9,
    /**
     * 改变SpriteA的大小，使他的高度与目标高度差值固定
     */
    HEIGHT2HEIGHT = 10,
    /**
     * 改变SpriteA的宽，使其左下角和目标左下角保持固定距离
     */
    LEFTEXTEND = 11,
    /**
    * 改变SpriteA的宽，使其右下角和目标右下角保持固定距离
    */
    RIGHTEXTEND = 12,
    /**
     * TODO 顶延展，改变SpriteA的高，使其左上角和目标左上角保持固定距离
     */
    TOPEXTEND = 13,
    /**
     * TODO 底延展，改变SpriteA的高，使其左下角和目标左下角保持固定距离
     */
    BOTTOMEXTEND = 14,
    

}
namespace common {

    export class SpriteAdapter {
        private item: Laya.Component;
        private target: Laya.Component;
        private difference: number;
        private adapterType: SpriteAdapterType;
        /**
         * 0,0
         */
        private static anchorLeft = new Laya.Vector2(0, 0);
        /**
         * 1,0
         */
        private static anchorRight = new Laya.Vector2(1, 0);
        /**
         * 0,1
         */
        private static anchorBottom = new Laya.Vector2(0, 1);

        /**
        * 使两个组件之间产生适配关系，创建的时候会保存他们对应的差值，当调用刷新时，会使他们适配,不支持Sprite,因为Sprite没有大小，也不能应用锚点
        * 注意：差值，如果是左对左=目标左上角-物体左上角
        * @param item 位置或大小会跟随target改变
        * @param target 目标
        * @param adapterType 适配类型
        * @param difference 直接写死差值，有些内容在运行之后会改变，所以直接写死距离会比较合适，不填会在创建这个新对象的时候进行计算
        */
        constructor(item: Laya.Component, target: Laya.Component, adapterType: SpriteAdapterType, difference: number|null = null) {
            this.item = item;
            this.target = target;
            this.adapterType = adapterType;
            if (difference === null) {
                this.registerInitialDifference();
            }
            else {
                this.difference = difference;
            }


        }

        private registerInitialDifference() {

            let itemTopLeft = this.getTopLeft(this.item);
            let itemTopRight = this.getTopRight(this.item);
            let itemBottomLeft = this.getBottomLeft(this.item);
            let itemBottonRight = this.getBottomRight(this.item);

            let targetTopLeft = this.getTopLeft(this.target);
            let targetTopRight = this.getTopRight(this.target);
            let targetBottomLeft = this.getBottomLeft(this.target);
            let targetBottonRight = this.getBottomRight(this.target);

            switch (this.adapterType) {
                case SpriteAdapterType.LEFT2LEFT:
                case SpriteAdapterType.LEFTEXTEND:
                    this.difference = targetTopLeft.x - itemTopLeft.x;
                    break;
                case SpriteAdapterType.RIGHT2LEFT:
                    this.difference = targetTopLeft.x - itemTopRight.x;
                    break;
                case SpriteAdapterType.LEFT2RIGHT:
                    this.difference = targetTopRight.x - itemTopLeft.x;
                    break;
                case SpriteAdapterType.RIGHT2RIGHT:
                case SpriteAdapterType.RIGHTEXTEND:
                    this.difference = targetTopRight.x - itemTopRight.x;
                    break;
                case SpriteAdapterType.TOP2TOP:
                    this.difference = targetTopLeft.y - itemTopLeft.y;
                    break;
                case SpriteAdapterType.BOTTOM2TOP:
                    this.difference = targetTopLeft.y - itemBottomLeft.y;
                    break;
                case SpriteAdapterType.TOP2BOTTOM:
                    this.difference = targetBottomLeft.y - itemTopLeft.y
                    break;
                case SpriteAdapterType.BOTTOM2BOTTOM:
                    this.difference = targetBottomLeft.y - itemBottomLeft.y
                    break;
                case SpriteAdapterType.WIDTH2WIDTH:
                    let itemWidth = this.getTrueWidth(this.item);
                    let targetWidth = this.getTrueWidth(this.target);
                    this.difference = itemWidth - targetWidth;
                    break;
                case SpriteAdapterType.HEIGHT2HEIGHT:
                    let itemHeight = this.getTrueHeight(this.item);
                    let targetHeight = this.getTrueHeight(this.target);
                    this.difference = itemHeight - targetHeight;
                    break;
            }
        }

        public fresh() {
            let currentDifference: number;
            let delta: number;
            let oldAnchor: Laya.Vector2;

            let itemTopLeft = this.getTopLeft(this.item);
            let itemTopRight = this.getTopRight(this.item);
            let itemBottomLeft = this.getBottomLeft(this.item);
            let itemBottonRight = this.getBottomRight(this.item);

            let targetTopLeft = this.getTopLeft(this.target);
            let targetTopRight = this.getTopRight(this.target);
            let targetBottomLeft = this.getBottomLeft(this.target);
            let targetBottonRight = this.getBottomRight(this.target);

            switch (this.adapterType) {
                case SpriteAdapterType.LEFT2LEFT:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopLeft.x - itemTopLeft.x;
                    delta = currentDifference - this.difference;
                    this.item.x = this.item.x + delta;
                    break;
                case SpriteAdapterType.LEFT2RIGHT:
                    currentDifference = targetTopRight.x - itemTopLeft.x;
                    delta = currentDifference - this.difference;
                    this.item.x = this.item.x + delta;
                    break;
                case SpriteAdapterType.RIGHT2LEFT:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopLeft.x - itemTopRight.x;
                    delta = currentDifference - this.difference;
                    this.item.x = this.item.x + delta;
                    break;
                case SpriteAdapterType.RIGHT2RIGHT:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopRight.x - itemTopRight.x;
                    delta = currentDifference - this.difference;
                    // console.log(`现在右上角的值${targetTopRight.x}`);

                    // console.log(`之前的差值:${this.difference},现在的差值${currentDifference},之间的差值:${delta}`);
                    this.item.x = this.item.x + delta;
                    break;
                case SpriteAdapterType.TOP2TOP:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopLeft.y - itemTopLeft.y;
                    delta = currentDifference - this.difference;
                    this.item.y = this.item.y + delta;
                    break;
                case SpriteAdapterType.TOP2BOTTOM:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetBottomLeft.y - itemTopLeft.y;
                    delta = currentDifference - this.difference;
                    // console.log(`目标左下${targetBottomLeft.y},当前左上${itemTopLeft.y}`);
                    // console.log(`当前差值${currentDifference},目标差值${this.difference}`);
                    this.item.y = this.item.y + delta;
                    break;
                case SpriteAdapterType.BOTTOM2TOP:
                    currentDifference = targetTopLeft.y - itemBottomLeft.y;
                    delta = currentDifference - this.difference;

                    this.item.y = this.item.y + delta;
                    break;
                case SpriteAdapterType.BOTTOM2BOTTOM:
                    currentDifference = targetBottomLeft.y - itemBottomLeft.y;
                    delta = currentDifference - this.difference;
                    this.item.y = this.item.y + delta;
                    break;
                case SpriteAdapterType.WIDTH2WIDTH:
                    this.item.width = this.getTrueWidth(this.target) - this.difference;
                    break;
                case SpriteAdapterType.HEIGHT2HEIGHT:
                    this.item.height = this.getTrueHeight(this.target) - this.difference;
                    break;
                case SpriteAdapterType.RIGHTEXTEND:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopRight.x - itemTopRight.x;
                    delta = currentDifference - this.difference;
                    //记录item之前的锚点
                    oldAnchor = this.getTrueAnchor(this.item);
                    if (delta > 0) {
                        this.item.anchorX = SpriteAdapter.anchorLeft.x;
                        this.item.anchorY = SpriteAdapter.anchorLeft.y;

                    }
                    else {
                        this.item.anchorX = SpriteAdapter.anchorRight.x;
                        this.item.anchorY = SpriteAdapter.anchorRight.y;
                    }
                    this.item.width = this.getTrueWidth(this.item) + delta;
                    this.item.anchorX = oldAnchor.x;
                    this.item.anchorY = oldAnchor.y;
                    break;
                case SpriteAdapterType.LEFTEXTEND:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopLeft.x - itemTopLeft.x;
                    delta = currentDifference - this.difference;
                    //记录item之前的锚点
                    oldAnchor = this.getTrueAnchor(this.item);
                    this.item.anchorX = SpriteAdapter.anchorRight.x;
                    this.item.anchorY = SpriteAdapter.anchorRight.y;
                    this.item.width = this.getTrueWidth(this.item) - delta;
                    this.item.anchorX = oldAnchor.x;
                    this.item.anchorY = oldAnchor.y;
                    break;
                case SpriteAdapterType.TOPEXTEND:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetTopLeft.x - itemTopLeft.x;
                    delta = currentDifference - this.difference;
                    //记录item之前的锚点
                    oldAnchor = this.getTrueAnchor(this.item);
                    this.item.anchorX = SpriteAdapter.anchorBottom.x;
                    this.item.anchorY = SpriteAdapter.anchorBottom.y;
                    this.item.height = this.getTrueHeight(this.item) - delta;
                    this.item.anchorX = oldAnchor.x;
                    this.item.anchorY = oldAnchor.y;
                    break;
                case SpriteAdapterType.BOTTOMEXTEND:
                    //所有的差值计算都是目标-当前
                    currentDifference = targetBottomLeft.x - itemBottomLeft.x;
                    delta = currentDifference - this.difference;
                    //记录item之前的锚点
                    oldAnchor = this.getTrueAnchor(this.item);
                    this.item.anchorX = SpriteAdapter.anchorLeft.x;
                    this.item.anchorY = SpriteAdapter.anchorLeft.y;
                    this.item.height = this.getTrueHeight(this.item) - delta;
                    this.item.anchorX = oldAnchor.x;
                    this.item.anchorY = oldAnchor.y;
                    break;


            }
        }

        /**
         * 获取UI左上角在全局的坐标
         * @param comp 
         */
        private getTopLeft(comp: Laya.Component): Laya.Vector2 {
            let anchorX = isNaN(comp.anchorX) ? 0 : comp.anchorX;
            let anchorY = isNaN(comp.anchorY) ? 0 : comp.anchorY;
            let worldPos = Laya.stage.localToGlobal(new Laya.Point(comp.x, comp.y));
            let x = worldPos.x - anchorX * this.getTrueWidth(comp);
            let y = worldPos.y - anchorY * this.getTrueHeight(comp);
            return new Laya.Vector2(x, y);
        }

        /**
        * 获取UI右上角在全局的坐标
        * @param comp 
        */
        private getTopRight(comp: Laya.Component): Laya.Vector2 {
            let anchorX = isNaN(comp.anchorX) ? 0 : comp.anchorX;
            let anchorY = isNaN(comp.anchorY) ? 0 : comp.anchorY;
            let worldPos = Laya.stage.localToGlobal(new Laya.Point(comp.x, comp.y));
            let x = worldPos.x - anchorX * this.getTrueWidth(comp) + this.getTrueWidth(comp);
            let y = worldPos.y - anchorY * this.getTrueHeight(comp);
            return new Laya.Vector2(x, y);
        }

        /**
        * 获取UI左下角在全局的坐标
        * @param comp 
        */
        private getBottomLeft(comp: Laya.Component): Laya.Vector2 {
            let anchorX = isNaN(comp.anchorX) ? 0 : comp.anchorX;
            let anchorY = isNaN(comp.anchorY) ? 0 : comp.anchorY;
            let worldPos = Laya.stage.localToGlobal(new Laya.Point(comp.x, comp.y));
            let x = worldPos.x - anchorX * this.getTrueWidth(comp);
            let y = worldPos.y - anchorY * this.getTrueHeight(comp) + this.getTrueHeight(comp);
            return new Laya.Vector2(x, y);
        }

        /**
        * 获取UI左上角在全局的坐标
        * @param comp 
        */
        private getBottomRight(comp: Laya.Component): Laya.Vector2 {
            let anchorX = isNaN(comp.anchorX) ? 0 : comp.anchorX;
            let anchorY = isNaN(comp.anchorY) ? 0 : comp.anchorY;
            let worldPos = Laya.stage.localToGlobal(new Laya.Point(comp.x, comp.y));
            let x = worldPos.x - anchorX * this.getTrueWidth(comp) + this.getTrueWidth(comp);
            let y = worldPos.y - anchorY * this.getTrueHeight(comp) + this.getTrueHeight(comp);
            return new Laya.Vector2(x, y);
        }

        private getTrueWidth(comp: Laya.Component): number {
            if (comp instanceof Laya.Label) {
                let label = comp as Laya.Label;
                return label.textField.textWidth * label.scaleX;
            }
            if (comp.width !== 0) {
                return comp.width * comp.scaleX;
            }
            if (comp instanceof Laya.Image) {
                let img = comp as Laya.Image;
                if (img._bitmap && img._bitmap.source) {
                    return img._bitmap.source.width * img.scaleX;
                }
                
            }
           
            let bounds = comp.getBounds();
            return bounds.width * comp.scaleX;
        }

        private getTrueHeight(comp: Laya.Component): number {
            if (comp instanceof Laya.Label) {

                let label = comp as Laya.Label;
                return label.textField.textHeight * label.scaleY;
            }
            if (comp.height !== 0) {
                return comp.height * comp.scaleY;
            }
            if (comp instanceof Laya.Image) {
                let img = comp as Laya.Image;
                if (img._bitmap && img._bitmap.source) {
                    return img._bitmap.source.height * img.scaleY;
                }
            }
            let bounds = comp.getBounds();
            return bounds.height * comp.scaleY;
        }

        private getTrueAnchor(comp: Laya.Component): Laya.Vector2 {
            let anchorX = isNaN(comp.anchorX) ? 0 : comp.anchorX;
            let anchorY = isNaN(comp.anchorY) ? 0 : comp.anchorY;
            return new Laya.Vector2(anchorX, anchorY);
        }
    }
}