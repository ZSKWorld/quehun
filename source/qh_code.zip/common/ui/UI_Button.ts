module uiscript {



    /**
     * 结构为title标题,icon图标,up抬起时图片,按下时down图片,over放在该位置时的图片
     */
    export class UI_Button extends UI_Component {

        private innerTitle: Laya.Label;
        private innerIcon: Laya.Image;
        private up: Laya.Image;
        private down: Laya.Image;
        private over: Laya.Image;
        private gray: Laya.Image;

        private button: Laya.Button;
        private handlers: Array<Laya.Handler>;

        private innerOnMouseDown: Laya.Handler;
        private innerOnMouseUp: Laya.Handler;
        private innerIsGray: boolean = false;


        //#region 缩放动画部分
        private innerIsAnimScale: boolean = false;
        private innerScaleCount: number = 1.1;
        private innerScaleAnimCostTime: number = 50;
        private originScaleX: number = 1;
        private originScaleY: number = 1;
        private mousedowned: boolean = false;
        private starttime: number = 0;
        private originX: number = 0;
        //#endregion




        /**
         * 文字标题的内容
         */
        public set title(str: string) {
            if (this.innerTitle) {
                this.innerTitle.text = str;
            }
        }
        /**
         * 文字标题的内容
         */
        public get title() {
            if (this.innerTitle) {
                return this.innerTitle.text;
            }
        }

        /**
         * 文字标题的颜色
         */
        public set titleColor(color: string) {
            if (this.innerTitle) {
                this.innerTitle.color = color;
            }
        }
        /**
         * 文字标题的颜色
         */
        public get titleColor() {
            if (this.innerTitle) {
                return this.innerTitle.color;
            }
        }

        /**
         * 文字标题的文字大小
         */
        public set titleFontSize(size: number) {
            if (this.innerTitle) {
                this.innerTitle.fontSize = size;
            }
        }

        /**
         * 文字标题的文字大小
         */
        public get titleFontSize() {
            if (this.innerTitle) {
                return this.innerTitle.fontSize;
            }
        }

        /**
         * 图片标题
         */
        public set icon(url: string) {
            if (this.innerIcon) {
                this.innerIcon.skin = url;
            }
        }

        /**
         * 图片标题
         */
        public get icon() {
            if (this.innerIcon) {
                return this.innerIcon.skin;
            }
        }

        /**
         * 是否在按下按钮时执行缩放
         */
        public set isAnimScale(isAnim: boolean) {
            this.innerIsAnimScale = isAnim;
        }


        /**
         * 鼠标按下时触发
         */
        public set setOnMouseDown(handler: Laya.Handler) {
            this.innerOnMouseDown = handler;
        }

        /**
         * 鼠标松开和移出按钮范围内触发
         */
        public set setOnMouseUp(handler: Laya.Handler) {
            this.innerOnMouseDown = handler;
        }



        /**
         * 是否置灰
         */
        public set grayed(isGray: boolean) {

            this.innerIsGray = isGray;
            if (this.gray) {
                this.gray.visible = isGray;
            }
            else {
                game.Tools.setGray(this.me, isGray);
            }
            if (this.up) {
                this.up.visible = !isGray;
            }
        }

        /**
         * 是否置灰
         */
        public get grayed() {
            return this.innerIsGray;
        }


        constructor(comp: Laya.Sprite, isScaleAnim: boolean = false) {
            super(comp);
            this.innerIsAnimScale = isScaleAnim;
        }

        public onCreate(): void {
            this.innerTitle = this.me.getChildByName("title") as Laya.Label;
            this.innerIcon = this.me.getChildByName("icon") as Laya.Image;
            this.up = this.me.getChildByName("up") as Laya.Image;
            this.down = this.me.getChildByName("down") as Laya.Image;
            this.over = this.me.getChildByName("over") as Laya.Image;
            this.gray = this.me.getChildByName("gray") as Laya.Image;
            this.button = this.me.getChildByName("btn") as Laya.Button;
            this.button.on('mousedown', this, this.onMouseDown);
            this.button.on('mouseup', this, this.onMouseUp);
            this.button.on('mouseout', this, this.onMouseUp);
            this.button.on('mousein', this, this.onMouseOver);
            this.button.clickHandler = new Laya.Handler(this, this.onClick);
            this.handlers = new Array();
            this.originScaleX = this.me.scaleX;
            this.originScaleY = this.me.scaleY;
            this.onMouseUp();
            this.grayed = false;
        }

        private onMouseOver() {
            if (this.over) {
                this.over.visible = true;
            }
        }

        private onMouseDown() {
            if (this.over) {
                this.over.visible = false;
            }
            if (this.up && this.down) {
                this.up.visible = false;
                this.down.visible = true;
            }
            if (this.innerOnMouseDown) {
                this.innerOnMouseDown.run();
            }

            if (this.innerIsAnimScale) {
                if (this.mousedowned) return;
                this.mousedowned = true;
                this.originX = this.me.scaleX;
                this.starttime = Laya.timer.currTimer;
                Laya.timer.clear(this, this.doScaleAnim);
                Laya.timer.frameLoop(1, this, this.doScaleAnim);
            }
        }

        private onMouseUp() {
            if (this.over) {
                this.over.visible = false;
            }
            if (this.up && this.down) {
                this.up.visible = true;
                this.down.visible = false;
            }
            if (this.innerOnMouseUp) {
                this.innerOnMouseUp.run();
            }
            if (this.innerIsAnimScale) {
                if (!this.mousedowned) return;
                this.mousedowned = false;
                this.originX = this.me.scaleX;
                this.starttime = Laya.timer.currTimer;
                Laya.timer.clear(this, this.doScaleAnim);
                Laya.timer.frameLoop(1, this, this.doScaleAnim);
            }
        }

        //如果父物体直接改变了显示或隐藏，该部分并不会被触发
        public onEnable(): void {
            if (this.innerIsAnimScale) {
                //此处默认执行缩放动画按钮的大小为1
                this.me.scaleX = this.me.scaleY = 1;
                this.originScaleX = this.me.scaleX;
                this.originScaleY = this.me.scaleY;
            }
        }

        public onDisable(): void {
            if (this.innerIsAnimScale) {
                this.mousedowned = false;
                Laya.Tween.clearAll(this.me);
                if (this.me.destroyed) return;
                this.me.scaleX = this.originScaleX;
                this.me.scaleY = this.originScaleY;
            }
        }

        private onClick() {
            this.handlers.forEach(handler => {
                handler.run();
            });
        }


        public addClickListener(handler: Laya.Handler) {
            this.handlers.push(handler);
        }


        public setClickListener(handler: Laya.Handler) {
            this.handlers = new Array();
            this.addClickListener(handler)
        }

        public removeAllListener() {
            this.handlers = new Array();
        }

        /**
         * 移除指定的点击处理
         * @param handler 
         */
        public removeClickListener(handler: Laya.Handler): void {
            const index = this.handlers.indexOf(handler);
            if (index > -1) {
                this.handlers.splice(index, 1);
            }
        }




        private doScaleAnim() {
            if (!this.me || this.me.destroyed) {
                Laya.timer.clear(this, this.doScaleAnim);
                return;
            }
            if (!this.innerIsAnimScale) {
                Laya.timer.clear(this, this.doScaleAnim);
                this.me.scaleX = this.originX;
                this.me.scaleY = this.originScaleY;
                return;
            }
            let t: number = Laya.timer.currTimer - this.starttime;
            let target: number = this.mousedowned ? this.innerScaleCount : 1;
            if (t >= this.innerScaleAnimCostTime) {
                this.me.scaleX = this.me.scaleY = target;
                Laya.timer.clear(this, this.doScaleAnim);
            } else {
                let rate: number = t / this.innerScaleAnimCostTime;
                this.me.scaleX = this.me.scaleY = this.originX * (1 - rate) + target * rate;
            }
        }

    }


}