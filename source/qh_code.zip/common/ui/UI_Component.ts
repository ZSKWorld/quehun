module uiscript {
    /**
     * 所有UI组件的基类
     * UI组件=已经创建/加载完毕的UI，为其添加一些通用的处理
     */
    export class UI_Component {
        private innerMe: Laya.Sprite;

        private innerIsGrayed: boolean = false;

        constructor(comp: Laya.Sprite) {
            this.innerMe = comp;
            this.onCreate();
        }

        public set visible(isVisible: boolean) {

            if (isVisible) {
                this.onEnable();
            }
            else {
                this.onDisable();
            }
            this.innerMe.visible = isVisible;
        }

        public get visible() {
            return this.innerMe.visible;
        }

        /**
        * 是否置灰
        */
        public set grayed(isGray: boolean) {
            this.innerIsGrayed = isGray
            game.Tools.setGray(this.me, isGray);
        }

        /**
        * 是否置灰
        */
        public get grayed() {
            return this.innerIsGrayed;
        }


        /**
        * 是否可以接收点击
        */
        public set touchable(touch: boolean) {
            this.me.mouseEnabled = touch;
        }

        /**
         * 是否可以接收点击
         */
        public get touchable() {
            return this.me.mouseEnabled;
        }


        public onCreate() {

        }

        public onEnable() {

        }

        public onDisable() {

        }

        public onDispose() {

        }

        public dispose() {
            this.onDispose();
            this.me.destroy();
        }

        public get me() {
            return this.innerMe;
        }

    }
}