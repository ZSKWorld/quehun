module uiscript {
    interface IEffectData {
        id: number;
        path: string;
        effect: game.UIEffect;
    }
    export class UI_EffectMgr {
        private runningEffects: Array<IEffectData> = [];
        private currentId: number = 0;
        private get nextId(): number {
            this.currentId++;
            return this.currentId;
        }

        /**
         * 创建特效
         * @param path 特效路径
         * @param target 目标对象
         * @param offset 偏移量
         * @param destroyDelay 销毁延迟
         * @param scale 缩放比例
         * @returns 特效ID
         */
        public createEffect(path: string, target: Laya.Sprite, offset: Laya.Point, destroyDelay: number = -1, onDestroy: Laya.Handler = null, scale: number = 1) {
            let effect = game.FrontEffect.Inst.create_ui_effect(target, path, offset, scale);
            let id = this.nextId;
            this.runningEffects.push({ id: id, effect: effect, path: path });
            if (destroyDelay > 0) {
                Laya.timer.once(destroyDelay, this, () => {
                    this.destoryEffect(id);
                    onDestroy?.run();
                })
            }
            return id;
        }

        public destoryEffect(id: number) {
            let effectData = this.runningEffects.find(data => data.id === id);
            if (!effectData) {
                return;
            }
            effectData.effect.destory();
            this.runningEffects.splice(this.runningEffects.indexOf(effectData), 1);
        }

        public clearAllEffects() {

            for (let index = this.runningEffects.length - 1; index >= 0; index--) {
                const element = this.runningEffects[index];
                element.effect.destory();
            }
            this.runningEffects = [];
        }

        public clearEffectsByPath(path: string) {

            for (let index = this.runningEffects.length - 1; index >= 0; index--) {
                const element = this.runningEffects[index];
                if (element.path === path) {
                    this.destoryEffect(element.id);
                }
            }
        }

    }
}