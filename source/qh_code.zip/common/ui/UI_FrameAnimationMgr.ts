module uiscript {
    interface IAnimData {
        name: string;
        isLoop: boolean;
        onComplete?: Laya.Handler;
        id: number;
    }
    //T 需要继承laya.view
    export class UI_FrameAnimationMgr<T extends Laya.View> {
        private animBase: T;
        private runningAnimations: Array<IAnimData> = [];
        private currentAnimId: number = 0;
        private isLogOpen: boolean = false;
        private get nextAnimId(): number {
            this.currentAnimId++;
            return this.currentAnimId;
        }
        constructor(sprite: Laya.Sprite) {
            this.animBase = sprite as T;

        }

        /**
         * 是否有正在播放的动画
         */
        public get hasRunningAnimations(): boolean {
            return this.runningAnimations.length > 0;
        }

        /**
         * 播放动画
         * @param name 动画名称 
         * @param isLoop 是否循环播放
         * @param onComplete 动画完成回调
         * @param speed 播放速度, 默认为1
         * @returns 动画ID，可用于停止指定动画
         */
        public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler, speed: number = 1) {
           

            let anim = this.animBase[name];
            if (!anim) {
                onComplete?.run();
                app.Log.log("【UI_FrameAnimationMgr】: playAnim - Animation not found: " + name);
                return;
            }
            if (this.isLogOpen) {
                app.Log.log(`【UI_FrameAnimationMgr】: playAnim - Playing animation: ${name}, Loop: ${isLoop}, Speed: ${speed}`);
            }
            let animId = this.nextAnimId;
            let animData: IAnimData = { name: name, isLoop: isLoop, onComplete: onComplete, id: animId };
            anim.interval = 1 / (speed * Config.animationInterval) * 1000;
            anim.play(0, isLoop);
            if (this.isAnimRunning(name)) {
                this.stopAnim(name);
            } 
            this.runningAnimations.push(animData);
            if (onComplete && !isLoop) {
                anim.once(Laya.Event.COMPLETE, this, () => {
                    onComplete.run();
                    const index = this.runningAnimations.findIndex((data) => {
                        return data.id == animId;
                    });
                    if (index !== -1) {
                        this.runningAnimations.splice(index, 1);
                    }
                });
            }
            return animId;
        }

        public stopAnim(name: string) {
           

            let anim = this.animBase[name];
            if (!anim) {
                app.Log.log("【UI_FrameAnimationMgr】: stopAnim - Animation not found: " + name);
                return;
            }
            anim.stop();
            if (this.isLogOpen) {
                app.Log.log(`【UI_FrameAnimationMgr】: stopAnim - Stopping animation: ${name}`);
            }
            const index = this.runningAnimations.findIndex((data) => {
                return data.name == name;
            })
            if (index !== -1) {
                this.runningAnimations.splice(index, 1);
            }
        }

        public stopAnimById(id: number) {
            const index = this.runningAnimations.findIndex((data) => {
                return data.id == id;
            });

            if (index !== -1) {
                let animData = this.runningAnimations[index];
                let anim = this.animBase[animData.name];
                if (anim) {
                    anim.stop();
                    if (this.isLogOpen) {
                        app.Log.log(`【UI_FrameAnimationMgr】: stopAnim - Stopping animation: ${name}`);
                    }
                }
                this.runningAnimations.splice(index, 1);
            }
        }

        public stopAllAnimations() {
            for (let index = this.runningAnimations.length - 1; index >= 0; index--) {
                const element = this.runningAnimations[index];
                this.stopAnimById(element.id);
            }
            this.runningAnimations = [];
        }

        public isAnimRunning(name: string): boolean { 
            return this.runningAnimations.findIndex((data) => {
                return data.name == name;
            }) !== -1;
        }

        public completeRunningAnim(name: string,isRunComplete: boolean = true) { 
            const index = this.runningAnimations.findIndex((data) => {
                return data.name == name;
            });
            if (index !== -1) {
                let animData = this.runningAnimations[index];
                let anim = this.animBase[animData.name];
                if (anim) {
                    anim.gotoAndStop(anim.count);
                    if (this.isLogOpen) {
                        app.Log.log(`【UI_FrameAnimationMgr】: completeAnim - Completing animation: ${name}`);
                    }
                    if (isRunComplete) {
                        animData.onComplete?.run();
                    }
                }
                this.runningAnimations.splice(index, 1);
            }
        }

        /**
         * 直接播放到动画结束帧
         * @param name 
         * @returns 
         */
        public playAnimToEnd(name: string) { 
            let anim = this.animBase[name];
            if (!anim) {
                app.Log.log("【UI_FrameAnimationMgr】: playAnimToEnd - Animation not found: " + name);
                return;
            }
            anim.gotoAndStop(anim.count);
            if (this.isLogOpen) {
                app.Log.log(`【UI_FrameAnimationMgr】: playAnimToEnd - Completing animation: ${name}`);
            }
        }

        /**
         * 是否开启日志，用于调试动画播放情况
         */
        public set logOpen(value: boolean) { 
            this.isLogOpen = value;
        }
    }
}