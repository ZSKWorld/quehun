module uiscript {

    export class HTweenListItem extends UI_Component {
        /**
         * 渲染的Index
         */
        public renderIndex: number;
        /**
         * 逻辑的Index
         */
        public logicIndex: number;

        public get x(): number {
            return this.me.x;
        }

        public get y(): number {
            return this.me.y;
        }

        public set x(value: number) {
            this.me.x = value;
        }

        public set y(value: number) {
            this.me.y = value;
        }

        public set width(value: number) {
            this.me.width = value;
        }

        public get width(): number {
            return this.me.width;
        }

        public set height(value: number) {
            this.me.height = value;
        }

        public get height(): number {
            return this.me.height;
        }

        private innerCacheData: Object;
        public set cacheData(data: Object) {
            this.innerCacheData = data;

        }

        public get cacheData(): Object {
            return this.innerCacheData;
        }

        private innerDeltaAngle: number;
        public get deltaAngle(): number {
            return this.innerDeltaAngle;
        }
        public set deltaAngle(value: number) {
            this.innerDeltaAngle = value;
        }



    }

    /**
     * todo 水平动画列表 施工中 
     */
    export class UI_HTweenList extends UI_Component {
        private content: Laya.Sprite;
        private template: Laya.Sprite;
        private items: HTweenListItem[] = [];
        private renderHandler: Laya.Handler;
        private onScrollHandler: Laya.Handler;
        private onStopHandler: Laya.Handler;
        private innerCenterPos: Laya.Vector2;
        private centerLogicIndex: number;
        private current_angle: number;
        private target_angle: number;
        /**
         * item的实体数量
         */
        private itemEntityCount: number;
        /**
         * item的数据数量
         */
        private itemDatasCount: number;
        /**
         * 每个item占的角度
         */
        private itemAngle: number;
        /**
         * 总角度
         */
        private totalAngle: number;
        /**
        * 是否正在拖拽
        */
        private isDrag: boolean = false;
        /**
         * 鼠标是否按下
         */
        private isMouseDown: boolean = false;
        /**
         * 鼠标摁下的坐标
         */
        private clickStartPos: Laya.Vector2;
        /**
         * 上一帧的鼠标位置
         */
        private lastMousePos: Laya.Vector2;



        /**
         * 在滚动时被调用，这里会传回一个跟中心位置的偏移值
         * @param HTweenListItem 
         */
        public set onScroll(handler: Laya.Handler) {
            this.onScrollHandler = handler;
        }

        /**
         * 在停止滚动时被调用
         * @param HTweenListItem 
         */
        public set onStop(handler: Laya.Handler) {
            this.onStopHandler = handler;
        }

        /**
         * 设置渲染函数
         * HTweenListItem
         */
        public set itemRender(handler: Laya.Handler) {
            this.renderHandler = handler;
        }

        public get selectIndex(): number {
            return this.centerLogicIndex;
        }




        public onCreate(): void {
            this.content = this.me.getChildByName('content') as Laya.Sprite;
            this.innerCenterPos = new Laya.Vector2(this.content.width / 2, this.content.height / 2);
            this.template = this.content.getChildByName('template') as Laya.Sprite;
            this.template.visible = false;

        }

        public init(itemCount: number) {
            this.itemEntityCount = itemCount;
            this.itemDatasCount = itemCount;
            this.current_angle = 0;
            this.target_angle = 0;
            this.itemAngle = 30;
            this.centerLogicIndex = 0;
            this.totalAngle = this.itemAngle * this.itemEntityCount;
            this.items = [];
            for (let index = 0; index < this.itemEntityCount; index++) {
                this.items.push(this.createItem());
            }

        }

        public onEnable(): void {
            this.me.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            this.isMouseDown = false;
            this.isDrag = false;
            Laya.timer.frameLoop(1, this, this.update_anim);
        }

        public onDisable(): void {
            this.me.off(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.off(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.off(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            Laya.timer.clearAll(this);

        }



        private createItem(): HTweenListItem {
            let itemSprite = this.template.scriptMap['capsui.UICopy'].getNodeClone();
            this.content.addChild(itemSprite);
            let item = new HTweenListItem(itemSprite);
            item.visible = false;
            return item;
        }


        /**
         * 指定的logicIndex移动到中间
         * @param logicIndex 
         * @param isTween 默认开启动画
         */
        public scrollTo(logicIndex: number, isTween: boolean = true) {
            if (isTween) {
                this.onChangeAngle(logicIndex * this.itemAngle);
            }
            else {
                this.target_angle = logicIndex * this.itemAngle;
                this.current_angle = this.target_angle;
                this.refresh_scroll();
            }
           
        }

        /**
         * 滚动到下一个
         */
        public scrollToNext() {
            if (this.centerLogicIndex + 1 < this.itemDatasCount) {
                this.onChangeAngle((this.centerLogicIndex + 1) * this.itemAngle);
            }
        }

        /**
         * 滚动到上一个
         */
        public scrollToPrev() {
            if (this.centerLogicIndex - 1 >= 0) {
                this.onChangeAngle((this.centerLogicIndex - 1) * this.itemAngle);
            }
        }



        private onMouseDown() {
            this.isMouseDown = true;
            this.clickStartPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            Laya.timer.once(1, this, this.checkDrag);
        }

        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            //拖拽的结束
            if (this.isDrag) {
                this.isDrag = false;
                this.onDragEnd();
            }

        }

        private checkDrag() {
            if (!this.isMouseDown) {
                return;
            }
            if (!this.isDrag) {
                if (this.clickStartPos.x != Laya.stage.mouseX || this.clickStartPos.y != Laya.stage.mouseY) {
                    this.isDrag = true;
                    this.onDragStart();
                    Laya.timer.frameLoop(1, this, this.onDragMove);
                    return;
                }
            }
            Laya.timer.once(1, this, this.checkDrag);
        }

        private onDragStart() {
            let mousePosX = Laya.stage.mouseX;
            let mousePosY = Laya.stage.mouseY;
            this.lastMousePos = new Laya.Vector2(mousePosX, mousePosY);
        }

        private onDragMove() {
            if (!this.isDrag) {
                return;
            }
            let mousePosX = Laya.stage.mouseX;
            let mousePosY = Laya.stage.mouseY;
            let offset = mousePosX - this.lastMousePos.x;
            let targetAngle = this.target_angle - offset * this.totalAngle / 400;
            this.onChangeAngle(targetAngle);
            this.lastMousePos = new Laya.Vector2(mousePosX, mousePosY);
        }

        private onDragEnd() {

            const targetIndex = Math.round(this.target_angle / this.itemAngle);
            const finalAngle = targetIndex * this.itemAngle;
            if (this.current_angle == 0 && finalAngle <= 0) {
                this.onMoveEnd();
            }
            else if (this.current_angle == this.itemAngle * this.itemDatasCount - this.itemAngle && finalAngle >= this.itemAngle * this.itemDatasCount - this.itemAngle) {
                this.onMoveEnd();
            }
            else {
                this.onChangeAngle(finalAngle);
            }

            Laya.timer.clear(this, this.onDragMove);
            this.lastMousePos = null;
        }





        /**
         * 刷新数据
         */
        public freshAll() {
            for (let index = 0; index < this.items.length; index++) {
                let item = this.items[index];
                if (item.visible && item.logicIndex >= 0) {
                    this.freshItem(item.logicIndex);
                    this.onStopHandler && this.onStopHandler.runWith(item);
                }
            }


        }

        /**
         * 根据数据index刷新item
         * @param logicIndex 
         * @returns 
         */
        public freshItem(logicIndex: number) {
            let item = this.items.find(x => x.logicIndex == logicIndex);
            if (item && item.visible) {
                if (item.logicIndex < 0 || item.logicIndex >= this.itemDatasCount) {
                    item.visible = false;
                    return;
                }
                this.renderHandler && this.renderHandler.runWith(item);
            }
        }


        private onChangeAngle(angle: number) {
            if (angle < 0) angle = 0;
            if (angle > this.itemAngle * this.itemDatasCount - this.itemAngle)
                angle = this.itemAngle * this.itemDatasCount - this.itemAngle;

            this.target_angle = angle;
            let center_index: number = Math.floor((angle + this.itemAngle / 2) / this.itemAngle);

            if (center_index != this.centerLogicIndex) {
                this.centerLogicIndex = center_index;
            }
        }

        private refresh_scroll() {
            let centerIndex = Math.round(this.current_angle / this.itemAngle);
            let offsetAngle = this.current_angle - centerIndex * this.itemAngle;

            let totalItems = this.items.length;
            let half = Math.floor(totalItems / 2);

            let used_cells: boolean[] = Array(totalItems).fill(false);

            // 第一步：计算所有item宽高
            const sizes: Laya.Vector2[] = [];
            for (let i = 0; i < totalItems; i++) {
                let delta_angle = ((centerIndex + i - half) * this.itemAngle) - this.current_angle;
                sizes[i] = this.calculateItemSize(delta_angle);
                this.items[i].deltaAngle = delta_angle;
            }

            let centerX = this.innerCenterPos.x;
            let centerY = 259;

            // 第二步：确定中心item位置
            let centerItem = this.items[half];
            centerItem.width = sizes[half].x;
            centerItem.height = sizes[half].y;
            centerItem.x = centerX - centerItem.width / 2 - (offsetAngle / this.itemAngle) * centerItem.width;
            centerItem.y = centerY;
            if (centerIndex != centerItem.logicIndex) {
                centerItem.logicIndex = centerIndex;
                this.renderHandler && this.renderHandler.runWith(centerItem);
            }
            centerItem.visible = true;
            used_cells[half] = true;

            // 从中心向右摆放
            for (let i = half + 1; i < totalItems; i++) {
                let logicIndex = centerIndex + (i - half);
                let item = this.items[i];

                if (logicIndex >= 0 && logicIndex < this.itemDatasCount && Math.abs(item.deltaAngle) <= 75) {
                    item.width = sizes[i].x;
                    item.height = sizes[i].y;
                    item.x = this.items[i - 1].x + this.items[i - 1].width;
                    item.y = centerY;
                    if (logicIndex != item.logicIndex) {
                        item.logicIndex = logicIndex;
                        this.renderHandler && this.renderHandler.runWith(item);
                    }
                    item.visible = true;
                    used_cells[i] = true;
                } else {
                    item.visible = false;
                }
            }

            // 从中心向左摆放
            for (let i = half - 1; i >= 0; i--) {
                let item = this.items[i];
                let logicIndex = centerIndex - (half - i);
                if (logicIndex >= 0 && logicIndex < this.itemDatasCount && Math.abs(item.deltaAngle) <= 75) {
                    item.width = sizes[i].x;
                    item.height = sizes[i].y;
                    item.x = this.items[i + 1].x - item.width;
                    item.y = centerY;
                    if (logicIndex != item.logicIndex) {
                        item.logicIndex = logicIndex;
                        this.renderHandler && this.renderHandler.runWith(item);
                    }
                    item.visible = true;
                    used_cells[i] = true;
                } else {
                    item.visible = false;
                }
            }

            // 隐藏未使用的item
            for (let i = 0; i < totalItems; i++) {
                if (!used_cells[i]) {
                    this.items[i].logicIndex = -1;
                    this.items[i].visible = false;
                }
            }

            // 更新渲染和滚动回调
            for (let item of this.items) {
                if (item.visible && item.logicIndex >= 0) {
                    this.onScrollHandler && this.onScrollHandler.runWith(item);
                }
            }
        }




        private update_anim() {
            if (this.current_angle != this.target_angle) {
                let d_angle: number = Math.abs(this.target_angle - this.current_angle);
                // 采用v(速度) = k * d * d (距离)，当距离越大速度越快，距离越小速度越慢
                let k: number = 1 / 200 / 30; // k越大，结束的速度越快
                let v: number = k * d_angle * d_angle + 10 / 100;
                let dis: number = Laya.timer.delta * v;
                let needStop: boolean = dis >= d_angle;
                if (needStop) {
                    this.current_angle = this.target_angle;
                } else {
                    if (this.target_angle > this.current_angle) this.current_angle += dis;
                    else this.current_angle -= dis;
                }

                this.refresh_scroll();
                if (needStop && !this.isDrag) {
                    // 动画完全停止后调用onStopHandler
                    this.onMoveEnd();
                }
            }
        }

        /**
         * 在每个点位的固定大小，0是中心点的大小
         */
        private itemPoses: Laya.Vector2[] = [
            new Laya.Vector2(219, 468),
            new Laya.Vector2(100, 444),
            new Laya.Vector2(72, 414),
        ];
        private calculateItemSize(delta_angle: number): Laya.Vector2 {
            const absDelta = Math.abs(delta_angle);
            let size = new Laya.Vector2();

            if (absDelta === 0) {
                // 正中心位置的尺寸
                size.x = this.itemPoses[0].x;
                size.y = this.itemPoses[0].y;
            } else if (absDelta <= this.itemAngle) {
                // 从中心到稍微偏离中心线性缩小
                const t = absDelta / this.itemAngle;
                size.x = this.itemPoses[0].x - ((this.itemPoses[0].x - this.itemPoses[1].x) * t);   // 从219线性缩小到100
                size.y = this.itemPoses[0].y - ((this.itemPoses[0].y - this.itemPoses[1].y) * t);   // 从468线性缩小到444
            } else if (absDelta <= this.itemAngle * 2) {
                // 从稍偏离中心到更远线性缩小
                const t = (absDelta - this.itemAngle) / this.itemAngle;
                size.x = this.itemPoses[1].x - ((this.itemPoses[1].x - this.itemPoses[2].x) * t);   // 从100线性缩小到72
                size.y = this.itemPoses[1].y - ((this.itemPoses[1].y - this.itemPoses[2].y) * t);   // 从444线性缩小到414
            } else {
                // 超过60角度后统一为最小尺寸
                size.x = this.itemPoses[2].x;
                size.y = this.itemPoses[2].y;
            }
            return size;
        }


        private onMoveEnd() {
            for (let index = 0; index < this.items.length; index++) {
                let item = this.items[index];
                if (item.visible && item.logicIndex >= 0) {
                    this.onStopHandler && this.onStopHandler.runWith(item);
                }
            }
        }

        public setData(dataCount:number,centerIndex:number = 0) {
            this.current_angle = centerIndex * this.itemAngle;
            this.itemDatasCount = dataCount;
            this.centerLogicIndex = centerIndex;
            this.target_angle = this.current_angle;
            this.refresh_scroll();
            this.freshAll();
            this.onMoveEnd();
        }

    }

}