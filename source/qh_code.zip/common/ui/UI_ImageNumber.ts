module uiscript {
    /**
     * 图片字，水平
     * Sprite
     * |- image(temp)
     *   |- UICopy
     */
    export class UI_ImageNumber extends UI_Component {
        private templateImage: Laya.Image;
        private currentValue: number = 0;
        private maxValue: number = null;
        private minValue: number = null;
        private alignWay: 'left' | 'center' | 'right' = 'left' ;
        private imageList: Laya.Image[] = [];
        /**
         * 0-9的图片路径
         */
        private numberPath: string[] = [];
        /**
         * 减号的图片路径，没有代表不支持负数
         */
        private minusPath: string = '';
        private numberSpace: number = 0; // 数字之间的间隔
        private limitMinCount: number = -1; // 最小限制数量,不足则在前面补0,-1代表不限制




        public onCreate(): void {
            this.templateImage = this.me.getChildByName('temp') as Laya.Image;
            this.templateImage.visible = false; //模板图片默认不可见
        }

        /**
         * @param numberPath 数字图片路径，0-9的图片路径
         * @param minusPath 减号的图片路径，没有代表不支持负数
         * @param maxValue 最大值，会根据这个值来生成img1
         * @param space 数字之间的间隔
         * @param minValue 最小值
         * @param limitCount 最小限制数量,不足则在前面补0,-1代表不限制
         */
        public init(numberPath: string[], space: number = 0, minusPath: string = '', maxValue: number = null, minValue: number = null, limitCount: number = -1) {
            this.maxValue = maxValue;
            this.minValue = minValue;
            this.numberPath = numberPath;
            this.minusPath = minusPath;
            this.numberSpace = space;
            this.limitMinCount = limitCount;
            //现根据maxValue生成图片
            if (this.maxValue !== null) {
                let maxStr = this.maxValue.toString();
                for (let i: number = 0; i < maxStr.length; i++) {
                    this.createImage();
                }
            }
        }



        /**
         * 新生成的图片如何对齐
         * left,template所在位置是最左边
         * center,template所在位置是最中间
         * right,template所在位置是最右边
         */
        public set align(value: 'left' | 'center' | 'right') {
            this.alignWay = value;
            this.refresh();
        }

        /**
         * 根据对齐方式和当前值显示图片
         */
        public refresh() {
            if (this.numberPath.length === 0) return;

            let str: string = this.currentValue.toString();
            if (this.maxValue !== null && str.length > this.maxValue.toString().length) {
                str = str.slice(0, this.maxValue.toString().length);
            }

            //根据限制补0
            if (this.limitMinCount !== -1 && str.length < this.limitMinCount) {
                str = str.padStart(this.limitMinCount, '0');
            }
            
            while (this.imageList.length < str.length) {
                this.createImage();
            }

            while (this.imageList.length > str.length) {
                let img = this.imageList.pop();
                img.visible = false;
            }

            // —— 等宽：按模板图宽度 —— 
            const charWidth = this.templateImage.width * this.templateImage.scaleX;
            const totalWidth = str.length * charWidth + Math.max(0, str.length - 1) * this.numberSpace;

            // —— 父的本地原点对齐——
            const originLeft = 0;
            const originRight = this.me.width;       // 需要 this.me.width 有值
            const originCenter = this.me.width / 2;

            let baseX = originLeft; // left = 0
            if (this.alignWay === 'center') {
                baseX = originCenter - totalWidth / 2;
            } else if (this.alignWay === 'right') {
                baseX = originRight - totalWidth;
            }

            // 垂直仍用模板的当前 y（不做 pivot 抵消）
            const baseY = this.templateImage.y;

            // —— 摆放 —— 
            let curX = baseX;
            for (let i = 0; i < str.length; i++) {
                const ch = str[i];
                const img = this.imageList[i];
                img.visible = true;

                if (ch === '-') {
                    if (this.minusPath) img.skin = this.minusPath;
                    else { img.visible = false; continue; }
                } else {
                    const num = parseInt(ch);
                    if (num >= 0 && num <= 9) img.skin = this.numberPath[num];
                    else { img.visible = false; continue; }
                }

                img.x = curX;
                img.y = baseY;
                curX += charWidth + this.numberSpace;
            }

        }
        

        private createImage() {
            let img: Laya.Image = this.templateImage.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Image;
            this.me.addChild(img);
            img.name = 'number' + this.imageList.length;
            img.visible = false; //新创建的图片默认不可见
            this.imageList.push(img);
            return img;
        }

        public set value(value: number) {
            //如果没有对应的负号图片，则设置为0
            if (this.minusPath === '' && value < 0) {
                value = 0;
            }
            if (this.maxValue && value > this.maxValue) {
                value = this.maxValue; //如果超过最大值，则设置为最大值
            }
            if (this.minValue !== null && value < this.minValue) {
                value = this.minValue; //如果低于最小值，则设置为最小值
            }
            if (this.currentValue !== value) {
                this.currentValue = value;
                this.refresh();
            }
        }
    }

}