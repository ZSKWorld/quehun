module uiscript {
    /**
     * 页面切换回调
     * @param manualSwitching 是否是手动切换页面 true:手动点击切换 false:代码切换
     */
    export type UI_PageControllHandler = (manualSwitching?: boolean) => void;
    class DotButton extends UI_Component {
        private diselect: Laya.Sprite;
        private select: Laya.Sprite;
        private btn: Laya.Button;
        private locking: boolean;
        private onClickButtonHandler: Laya.Handler;
        public onCreate(): void {
            this.diselect = this.me.getChildByName('diselect') as Laya.Sprite;
            this.select = this.me.getChildByName('select') as Laya.Sprite;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.onClickButtonHandler?.run();
            }, null, false);
        }

        public set clickHandler(value: Laya.Handler) {
            this.onClickButtonHandler = value;
        }

        public set selected(value: boolean) {
            this.select.visible = value;
            this.diselect.visible = !value;
        }

        public set mouseEnabled(value: boolean) {
            this.btn.mouseEnabled = value;
        }

        public set isLocking(value: boolean) {
            this.locking = value;
            this.btn.mouseEnabled = !value;
        }




    }
    /**
     * 页面，含有左箭头和右箭头，可含有点表示当前页数
     * 点的结构
     * |-sprite
     *  |- dot
     *   |- diselect
     *   |- select
     *   |- btn
     *   |- copy
     */
    export class UI_PageControll {
        private lastPageBtn: Laya.Button;
        private nextPageBtn: Laya.Button;
        private dotContainer: Laya.Sprite;
        private dotList: DotButton[] = [];
        private dotTemplate: Laya.Sprite;
        private onChangePageHandler: UI_PageControllHandler;
        private pageCount: number;
        private currentPageIndex: number;
        private onClickDotHandler: Laya.Handler;
        private dotSpace: number;
        private locking: boolean = false;


        public set isLocking(value: boolean) {
            this.locking = value;
        }

        public init(lastPageBtn: Laya.Button, nextPageBtn: Laya.Button, onChangePage: UI_PageControllHandler): void {
            this.lastPageBtn = lastPageBtn;
            this.nextPageBtn = nextPageBtn;
            this.onChangePageHandler = onChangePage;
           
            this.lastPageBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.lastPage(true);
            },null,false);

            this.nextPageBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.nextPage(true);
            },null,false);
        }

        public initDot(dotContainer?: Laya.Sprite, dotSpace: number = 0, onClickDotHandler: Laya.Handler = null): void {
            this.dotList = [];
            this.dotSpace = dotSpace;
            this.dotContainer = dotContainer;
            this.onClickDotHandler = onClickDotHandler;
            this.dotTemplate = this.dotContainer.getChildByName('dot') as Laya.Sprite;
            this.dotTemplate.visible = false;
        }

        public set count(value: number) {
            this.pageCount = value;
            if (this.dotContainer) {
                // 不足的补齐
                for (let i = this.dotList.length; i < value; i++) {
                    let dot = this.dotTemplate.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
                    this.dotContainer.addChild(dot);
                    let dotBtn = new DotButton(dot);
                    if (this.onClickDotHandler) {
                        dotBtn.clickHandler = Laya.Handler.create(this, () => { });
                    }
                    this.dotList.push(dotBtn);
                }
                //遍历所有的点，设置显示
                for (let i = 0; i < this.dotList.length; i++) {
                    let dot = this.dotList[i];
                    if (i < value) {
                        dot.visible = true;
                    } else {
                        dot.visible = false;
                    }
                }
                let spans: number[] = [];
                for (let i = 0; i < value; i++) {
                    spans.push(this.dotSpace);
                }
                game.Tools.child_align_center(this.dotContainer, spans);
            }
        }

        public get count(): number {
            return this.pageCount;
        }

        public set pageIndex(value: number) {
            this.currentPageIndex = value;
            this.refresh(false);
        }

        public get pageIndex(): number {
            return this.currentPageIndex;
        }


        public refresh(manualSwitching: boolean = true): void {
            if (this.dotContainer) {
                for (let i = 0; i < this.dotList.length; i++) {
                    this.dotList[i].selected = (i == this.currentPageIndex);
                }
            }
            this.onChangePageHandler?.(manualSwitching);
          
        }

        public set mouseDotEnabled(value: boolean) {
            if (!this.dotContainer) {
                return;
            }
            for (let i = 0; i < this.dotList.length; i++) {
                this.dotList[i].mouseEnabled = value;
            }
        }

        public lastPage(manualSwitching: boolean = false) {
            if (this.currentPageIndex > 0) {
                this.currentPageIndex--;
            }
            this.refresh(manualSwitching);
        }

        public nextPage(manualSwitching: boolean = false) {
            if (this.currentPageIndex < this.pageCount - 1) {
                this.currentPageIndex++;
            }
            this.refresh(manualSwitching);
        }
           
    }

}