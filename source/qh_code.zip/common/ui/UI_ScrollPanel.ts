module uiscript {

    /**
     * 滚动面板,垂直滚动
     * Sprite
     * |- panel
     *   |- container
     * |- scrollbar
     */
    export class ScrollPanel extends UI_Component {
        private contentPanel: Laya.Panel;
        private container: Laya.Sprite;
        private scrollBar: capsui.CScrollBar;
        private onValueChangeHandler: Laya.Handler;
        private elastic: boolean = false;
        public onCreate(): void {
            this.contentPanel = this.me.getChildByName("panel") as Laya.Panel;
            this.container = this.contentPanel.getChildByName("container") as Laya.Sprite;
            let scrollBarSprite = this.me.getChildByName("scrollbar");
            if (scrollBarSprite) {
                this.scrollBar = (scrollBarSprite as Laya.Sprite).scriptMap["capsui.CScrollBar"];
            }
            if (this.scrollBar) {
                this.scrollBar.init(new Laya.Handler(this, rate => {
                    this.contentPanel.vScrollBar.value = this.contentPanel.vScrollBar.max * rate;
                }));
            }
           
            this.contentPanel.vScrollBarSkin = '';
            this.contentPanel.vScrollBar.on('change', this, () => {
                if (this.scrollBar) {
                    this.scrollBar.setVal(this.contentPanel.vScrollBar.value / this.contentPanel.vScrollBar.max, this.contentPanel.height / (this.container.height + this.container.y));
                }
                if (this.onValueChangeHandler) {
                    this.onValueChangeHandler.run();
                }
               
            });
        }

        /**
         * 设置内容的高度
         */
        public set contentHeight(value: number) {
            this.container.height = value;
            this.contentPanel.refresh();
            if (this.scrollBar) {
                this.scrollBar.setVal(this.contentPanel.vScrollBar.value / this.contentPanel.vScrollBar.max, this.contentPanel.height / (this.container.height + this.container.y));
            }
           
        }

        public get contentHeight(): number {
            return this.container.height;
        }

        public get content(): Laya.Sprite {
            return this.container;
        }

        /**
         * 滚动条的值
         */
        public get scrollValue(): number {
            return this.contentPanel.vScrollBar.value;
        }

        public set scrollValue(value: number) {
            this.contentPanel.vScrollBar.value = value;
        }

        /**
         * 滚动到底部
         */
        public gotoBottom() {
            this.scrollValue = this.contentPanel.vScrollBar.max;
        }

        /**
         * 滚动到顶部
         */
        public gotoTop() {
            this.scrollValue = 0;
        }


        /**
         * 滚动条的比例
         */
        public get rate(): number {
            let currentRate = this.contentPanel.vScrollBar.value / this.contentPanel.vScrollBar.max;
            //这里如果不是数字，返回0
            if (isNaN(currentRate)) {
                return 0;
            }
            return currentRate;
        }

        public set rate(value: number) {
            this.contentPanel.vScrollBar.value = this.contentPanel.vScrollBar.max * value;
        }

        /**
         * 滚动条的值变化事件
         */
        public set onValueChange(handler: Laya.Handler) {
            this.onValueChangeHandler = handler;
        }

        /**
         * 是否需要滚动，内容高度大于面板高度时返回true
         */
        public get needScroll(): boolean {
            return this.contentPanel.vScrollBar.max > this.contentPanel.height;
        }

        public fresh() {
            this.contentPanel.refresh();
        }

        public setElastic(distance: number = 350, time: number = 250) {
            this.contentPanel.vScrollBar.elasticDistance = distance;
            this.contentPanel.vScrollBar.elasticBackTime = time;
            this.elastic = true;
        }

        public get panelHeight(): number {
            return this.contentPanel.height;
        }
        
        public set panelHeight(value: number) {
            this.contentPanel.height = value;
            this.contentPanel.refresh();
        }

        public stopScroll() {
            this.contentPanel.vScrollBar.stopLoop = true;
        }

        public startScroll() {
            this.contentPanel.vScrollBar.stopLoop = false;
        }
    }
}
