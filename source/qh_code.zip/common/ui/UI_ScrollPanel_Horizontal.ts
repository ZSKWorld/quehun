module uiscript {

    /**
     * 滚动面板.水平滚动
     * Sprite
     * |- Panel
     *  |- container
     * |- scrollbar
     */
    export class UI_ScrollPanel_Horizontal extends UI_Component {
        private contentPanel: Laya.Panel;
        private container: Laya.Sprite;
        private scrollBar: capsui.CScrollBar_Heng;
        private onValueChangeHandler: Laya.Handler;
        public onCreate(): void {
            this.contentPanel = this.me.getChildByName("panel") as Laya.Panel;
            this.container = this.contentPanel.getChildByName("container") as Laya.Sprite;
            let scrollBarSprite = this.me.getChildByName("scrollbar");
            if (scrollBarSprite) {
                this.scrollBar = (scrollBarSprite as Laya.Sprite).scriptMap["capsui.CScrollBar_Heng"];
            }
            if (this.scrollBar) {
                this.scrollBar.init(new Laya.Handler(this, rate => {
                    this.contentPanel.hScrollBar.value = this.contentPanel.hScrollBar.max * rate;
                }));
            }

            this.contentPanel.hScrollBarSkin = '';
            this.contentPanel.hScrollBar.on('change', this, () => {
                if (this.scrollBar) {
                    this.scrollBar.setVal(this.contentPanel.hScrollBar.value / this.contentPanel.hScrollBar.max, this.contentPanel.width / (this.container.width + this.container.x));
                }
                if (this.onValueChangeHandler) {
                    this.onValueChangeHandler.run();
                }

            });
        }

        /**
         * 设置内容的高度
         */
        public set contentWidth(value: number) {
            this.container.width = value;
            this.contentPanel.refresh();
            if (this.scrollBar) {
                this.scrollBar.setVal(this.contentPanel.hScrollBar.value / this.contentPanel.hScrollBar.max, this.contentPanel.width / (this.container.width + this.container.x));
            }

        }

        public set contentHeight(value: number) {
            this.container.height = value;
            this.contentPanel.refresh();
        }

        public get contentWidth(): number {
            return this.container.width;
        }

        public get content(): Laya.Sprite {
            return this.container;
        }

        /**
         * 滚动条的值
         */
        public get scrollValue(): number {
            return this.contentPanel.hScrollBar.value;
        }

        public set scrollValue(value: number) {
            this.contentPanel.hScrollBar.value = value;
        }

        /**
         * 滚动到底部
         */
        public gotoBottom() {
            this.scrollValue = this.contentPanel.hScrollBar.max;
        }

        /**
         * 滚动到顶部
         */
        public gotoTop() {
            this.scrollValue = 0;
        }


        /**
         * 滚动条的比例
         */
        public get rate(): number {
            let currentRate = this.contentPanel.hScrollBar.value / this.contentPanel.hScrollBar.max;
            //这里如果不是数字，返回0
            if (isNaN(currentRate)) {
                return 0;
            }
            return currentRate;
        }

        public set rate(value: number) {
            this.contentPanel.hScrollBar.value = this.contentPanel.hScrollBar.max * value;
        }

        /**
         * 滚动条的值变化事件
         */
        public set onValueChange(handler: Laya.Handler) {
            this.onValueChangeHandler = handler;
        }

        /**
         * 是否需要滚动，内容高度大于面板高度时返回true
         */
        public get needScroll(): boolean {
            return this.contentPanel.hScrollBar.max > this.contentPanel.width;
        }

        public get panelWidth(): number {
            return this.contentPanel.width;
        }

        public set panelWidth(value: number) {
            this.contentPanel.width = value;
        }

        public get panelHeight(): number {
            return this.contentPanel.height;
        }

        public set panelHeight(value: number) {
            this.contentPanel.height = value;
        }

        public set scollBarWidth(value: number) {
            if (this.scrollBar) {
                this.scrollBar.updateWidth(value);
            }
        }

        public fresh() {
            this.contentPanel.refresh();
            if (this.scrollBar) {
                this.scrollBar.setVal(this.contentPanel.hScrollBar.value / this.contentPanel.hScrollBar.max, this.contentPanel.width / (this.container.width + this.container.x));
            }
        }
    }
}