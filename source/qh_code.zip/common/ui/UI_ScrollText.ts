module uiscript {
    export class UI_ScrollText extends UI_Component {
        private label: Laya.Label;
        private currentValue: number = 0;
        private targetValue: number = 0;
        private isAnimating: boolean = false;
        private animationDuration: number = 500;
        private queue: number[] = [];
        private animType: 'linear' | 'easeOut' = 'easeOut';

        public onChangeComplete: (finalValue: number) => void; 
        public onCreate(): void {
            this.label = this.me as Laya.Label;
        }

        public set animDuration(value: number) {
            this.animationDuration = value;
        }

        public set animationType(type: 'linear' | 'easeOut') {
            this.animType = type;
        }

        public set(value: number): void {
            this.stopAnimation();
            this.queue = [];
            this.currentValue = value;
            this.targetValue = value;
            this.label.text = value.toString();
        }

        public change(value: number): void {
            if (value === this.targetValue && (this.isAnimating || this.currentValue === value)) return;
            this.queue.push(value);
            if (!this.isAnimating) {
                this.playNext();
            }
        }

        private playNext(): void {
            if (this.queue.length === 0) {
                this.isAnimating = false;
                return;
            }

            const nextValue = this.queue.shift()!;
            if (nextValue === this.currentValue) {
                this.playNext();
                return;
            }

            this.targetValue = nextValue;
            this.animateToTarget(this.currentValue, this.targetValue);
        }

        private animateToTarget(from: number, to: number): void {
            this.isAnimating = true;
            const duration = this.animationDuration;
            const startTime = Laya.timer.currTimer;

            const update = () => {
                const now = Laya.timer.currTimer;
                const elapsed = now - startTime;
                const progress = Math.min(1, elapsed / duration);

                let easedProgress = progress;
                if (this.animType === 'easeOut') {
                    easedProgress = Laya.Ease.quadOut(progress, 0, 1, 1);
                }

                const value = Math.floor(from + (to - from) * easedProgress);
                this.currentValue = value;
                this.label.text = value.toString();

                if (progress < 1) {
                    Laya.timer.frameOnce(1, this, update);
                } else {
                    this.currentValue = to;
                    this.label.text = to.toString();
                    this.onChangeComplete?.(to); 
                    this.playNext();
                }
            };

            update();
        }

        public stopAnimation(): void {
            Laya.timer.clearAll(this);
            this.isAnimating = false;
        }
    }
}
