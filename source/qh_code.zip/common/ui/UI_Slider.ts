module uiscript {
    /**
     * 滑动条组件，目前仅支持整数
     * 结构：
     * Sprite
     * |- bg:背景
     * |- fill:填充条
     * |- thumb:滑块
     * |- value:值文本
     */
    export class UI_Slider extends UI_Component {
        private fill: Laya.Image;
        private thumb: Laya.Image;
        private bg: Laya.Image;
        private onValueChange: Laya.Handler = null;
        private currentValue: number = 0;
        private limitArea: Laya.Sprite;
        private locking: boolean = false;
        private minValue: number = 0;
        private maxValue: number = 100;


        /**
         *
         */
        constructor(comp: Laya.Sprite, minValue: number = 0, maxValue: number = 100, limitArea: Laya.Sprite = null) {
            super(comp);
            this.minValue = minValue;
            this.maxValue = maxValue;
            if (limitArea) {
                this.limitArea = limitArea;
            }
            else {
                this.limitArea = Laya.stage;
            }
            this.bindDragEvent();
            this.setRate(0);

        }

        public onCreate(): void {
            this.fill = this.me.getChildByName("fill") as Laya.Image;
            this.thumb = this.me.getChildByName("thumb") as Laya.Image;
            this.bg = this.me.getChildByName("bg") as Laya.Image;
        }

        public set onValueChangeHandler(onValueChange: Laya.Handler) {
            this.onValueChange = onValueChange;
        }

        /**
        * 鼠标摁下的坐标
        */
        private clickStartPos: Laya.Vector2;
        /**
         * 当前是否在执行拖拽
         */
        private isDrag: boolean;
        private lastClickPos: Laya.Vector2;
        private isMouseDown: boolean = false;
        /**
         * 如果滑动条在panel里，拖拽滑动条也会触发panel的滚动，这里用来锁定滑动条
         */
        private onChangeStart: Laya.Handler = null;
        private onChangeEnd: Laya.Handler = null;

        public set onChangeStartHandler(handler: Laya.Handler) {
            this.onChangeStart = handler;
        }

        public set onChangeEndHandler(handler: Laya.Handler) {
            this.onChangeEnd = handler;
        }

        private bindDragEvent() {
            this.me.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.limitArea.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.limitArea.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);

        }
        private onMouseDown() {
            if (this.locking) {
                return;
            }
            this.isMouseDown = true;
            this.onChangeStart?.run();
            this.clickStartPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.lastClickPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.isDrag = false;
            //计算点击位置对应的值
            let mousePosX = Laya.stage.mouseX;
            let localPos = this.me.globalToLocal(new Laya.Point(mousePosX, 0));
            let rate = (localPos.x - this.fill.x) / this.fill.width;
            this.setRate(rate, EConfigOpreateType.USER);
            Laya.timer.once(1, this, this.checkDrag);
        }

        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            //拖拽的结束
            if (this.isDrag) {
                this.onDragEnd();
                this.isDrag = false;
            }
            //点击的结束
            else {
                
            }
            this.clickStartPos = new Laya.Vector2(0, 0);
            this.lastClickPos = new Laya.Vector2(0, 0);
            Laya.timer.clear(this, this.checkDrag);
            Laya.timer.clear(this, this.onDragMove);
            this.onChangeEnd?.run();
        }

        private checkDrag() {
            if (!this.isDrag) {
                this.isDrag = true;
                this.onDragStart();
                Laya.timer.loop(16, this, this.onDragMove);
                return;
            }

            Laya.timer.once(1, this, this.checkDrag);
        }

        private onDragStart() {

        }

        private onDragMove() {
            if (this.isDrag) {
                let mousePosX = Laya.stage.mouseX;
                let mousePosY = Laya.stage.mouseY;
                let localPos = this.me.globalToLocal(new Laya.Point(mousePosX, 0));
                let rate = (localPos.x - this.fill.x) / this.fill.width;
                this.setRate(rate, EConfigOpreateType.USER);
                this.lastClickPos = new Laya.Vector2(mousePosX, mousePosY);
            }
        }

        private onDragEnd() {

        }




        public setRate(val: number,operateType:EConfigOpreateType=EConfigOpreateType.CODE) {
            //rate在0-1之间
            if (val < 0) val = 0;
            else if (val > 1) val = 1;
            this.fill.scaleX = val;
            this.thumb.x = this.fill.x + this.fill.width * val;
            this.currentValue = Math.round(this.minValue + (this.maxValue - this.minValue) * val);
            this.onValueChange?.runWith(operateType);
        }

        public setValue(val: number, operateType: EConfigOpreateType = EConfigOpreateType.CODE) { 
            if (val < this.minValue) val = this.minValue;
            else if (val > this.maxValue) val = this.maxValue;
            let rate = (val - this.minValue) / (this.maxValue - this.minValue);
            this.setRate(rate, operateType);
        }
      

        public set fillImage(path: string) {
            this.fill.skin = path;
        }

        public set thumbImage(path: string) {
            this.thumb.skin = path;
        }

        public set lock(isLock: boolean) {
            this.locking = isLock;
        }

        public get lock() {
            return this.locking;
        }

        public get rate(): number {
            return this.fill.scaleX;
        }

        public get value(): number { 
            return this.currentValue;
        }


    }

}