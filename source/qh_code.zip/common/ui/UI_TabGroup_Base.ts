module uiscript {


    /**
     * tab按钮状态改变的处理函数
     * @param index 改变状态的按钮的index
     * @param button 改变状态的按钮
     * @param manualSwitching 是否是手动点击按钮触发的状态改变
     */
    export type UI_TabBtnChangeHandler = (index: number, button: Laya.Button, manualSwitching?: boolean) => void;

    export class UI_TabGroup_TabButton extends UI_Component {
        private selectSprite: Laya.Sprite;
        private deselectSprite: Laya.Sprite;
        public onCreate(): void {
            this.selectSprite = this.me.getChildByName('select') as Laya.Sprite;
            this.deselectSprite = this.me.getChildByName('diselect') as Laya.Sprite;
        }


        public set selected(v: boolean) {
            if (v) {
                this.onSelect();
            } else {
                this.onDeselect();
            }
        }

        public onSelect() {
            this.selectSprite.visible = true;
            this.deselectSprite.visible = false;
        }

        public onDeselect() {
            this.selectSprite.visible = false;
            this.deselectSprite.visible = true;
        }
    }

    /**
     * 使用方法：
     * 1.new UI_TabGroup_Base()
     * 2.tabGroup.AddTabButton 将所有要控制的按钮添加进Group
     * 3.tabGroup.OnSelectChange = (index: number, button: Laya.Button, manualSwitching?: boolean) 有按钮状态改变的时候触发，如果有n个按钮状态改变，则会触发n次, manualSwitching指是不是手动点击按钮
     * 4.tabGroup.Init() 强制选中0
     * 请不要为group中的button单独设置点击事件
     */

    export class UI_TabGroup_Base {
        private tabs: Array<Laya.Button> = new Array<Laya.Button>();
        /**
         * 当tab中被选择的选项改变后的触发事件，参数为当前物体的index和物体本身
         */
        public onSelectChange: UI_TabBtnChangeHandler | null = null;


        /**
         * 默认选择第一个
         */
        private currentSelectIndex = 0;
        private lockHandler: Laya.Handler;
        private isLocking: boolean = false;
        //是否忽视相同判定
        private isIgnoreSameCheck: boolean = false;

        constructor(father?: UIBase, lockFunc?: Function) {
            if (lockFunc) this.lockHandler = new Laya.Handler(father, lockFunc);
        }
        /**
         * 当前选择的序号
         */
        public get selectedIndex(): number {
            return this.currentSelectIndex;
        }

        /**
        * 改变当前的选择
        * @param index 选中的序号 
        */
        public set selectedIndex(v: number) {
            this.changeSelect(v, false);
        }

        public set locking(v: boolean) {
            this.isLocking = v;
        }

        public get locking(): boolean {
            return this.isLocking;
        }

        /**
         * 是否忽视相同判定，如果为true，则当点击当前选中项时也会触发onSelectChange事件，默认为false
         */
        public set ignoreSameCheck(v: boolean) { 
            this.isIgnoreSameCheck = v;
        }

        /**
         * 是否忽视相同判定，如果为true，则当点击当前选中项时也会触发onSelectChange事件，默认为false
         */
        public get ignoreSameCheck(): boolean { 
            return this.isIgnoreSameCheck;
        }



        /**
         * 添加一个按钮到管理类
         * @param btn 
         */
        public AddTabButton(btn: Laya.Button) {
            let btnIndex = this.tabs.length;
            //不要在别的地方赋值clickHandler
            btn.clickHandler = new Laya.Handler(this, () => {
                if (this.lockHandler && this.lockHandler.run() == true) {
                    return;
                }
                if (this.locking) {
                    return;
                }
                this.changeSelect(btnIndex, true);
            })
            this.tabs.push(btn);
        }


        /**
         * 给所有的tab发送事件
         * @param index 选中的tabIndex
         * @returns 
         */
        private changeSelect(index: number, manualSwitching: boolean) {
           
            if (index == this.currentSelectIndex) {
                if (this.ignoreSameCheck) {
                    this.onSelectChange?.(index, this.tabs[index], manualSwitching);
                }
                return;
            }
            // 获取上一个选中的索引
            let previousIndex = this.currentSelectIndex;
            this.currentSelectIndex = index;

            // 对于上一个选中的 Tab，如果它的索引不等于新的索引
            if (previousIndex >= 0 && previousIndex < this.tabs.length) {
                this.onSelectChange?.(previousIndex, this.tabs[previousIndex]);
            }
            // 对于新选中的 Tab，触发 onBtnStateChange
            this.onSelectChange?.(index, this.tabs[index], manualSwitching);
        }

        /**
         * 在添加完所有的btn之后调用，
         */
        public init() {
            this.currentSelectIndex = 0;
            for (let i = 0; i < this.tabs.length; i++) {
                let tabIndex = i;
                let tab = this.tabs[tabIndex];
                this.onSelectChange?.(tabIndex, tab, false);
            }
        }

        public clear() {
            this.currentSelectIndex = 0;
            this.tabs = new Array();
        }

        /**
         * 不管当前是否一致，强行执行onChange
         * @param index 
         */
        public forceSelect(index: number) {
            this.currentSelectIndex = index;
            for (let i = 0; i < this.tabs.length; i++) {
                let tabIndex = i;
                let tab = this.tabs[tabIndex];
                this.onSelectChange?.(tabIndex, tab, false);
            }
        }
    }
}