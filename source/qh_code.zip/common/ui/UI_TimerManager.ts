module uiscript {
    export interface UI_Timer {
        /**
         * 执行的延迟时间
         */
        delay: number;
        /**
         * 任务
         */
        task: () => void;
        /**
         * 是否循环执行
         */
        isLoop: boolean;
        /**
         * 执行的时间
         */
        runningTime: number;
        /**
         * timer的id
         */
        id: number;
        /**
         * 循环次数
         * 0表示无限循环，1表示执行一次，2表示执行两次
         */
        loopTimes: number;

    }

    export class UI_TimerManager {
        private taskList: Array<UI_Timer>;
        /**
         * 当前运行的时间，单位ms
         */
        private runningTime: number = 0;
        /**
         * 用来给每个任务一个唯一的id
         */
        private currentId: number = 0;
        private isRunning: boolean = false;

        constructor() {
            this.taskList = new Array<UI_Timer>();
            this.runningTime = 0;
            this.currentId = 0;
        }

        public addTimerOnce(delay: number, task: () => void) {
            let taskData: UI_Timer = {
                delay: delay,
                task: task,
                isLoop: false,
                runningTime: this.runningTime + delay,
                id: this.getId(),
                loopTimes: 0,
            };
            this.taskList.push(taskData);
           
        }

        public addTimerLoop(space: number, times: number, task: () => void) {
            let taskData: UI_Timer = {
                delay: space,
                task: task,
                isLoop: true,
                runningTime: this.runningTime + space,
                id: this.getId(),
                loopTimes: times,
            };
            this.taskList.push(taskData);
        }

        /**
         * 继续计时器
         */
        public start() {
            if (this.isRunning) {
                return;
            }
            this.isRunning = true;
            Laya.timer.frameLoop(1, this, this.update);
        }

        /**
         * 暂停计时器
         * @returns 
         */
        public stop() {
            this.isRunning = false;
            Laya.timer.clear(this, this.update);
        }

        /**
         * 将目前所有的计时器任务进行
         */
        public complete() {
            //未开始播放的任务进行到最后
            for (let i = 0; i < this.taskList.length; i++) {
                let taskData = this.taskList[i];
                if (taskData.task) {
                    taskData.task();
                }
            }
            this.taskList = new Array<UI_Timer>();
        }

        public clear() {

            this.taskList = new Array<UI_Timer>();
            this.currentId = 0;
        }

        private update() {
            this.runningTime += Laya.timer.delta;
            // console.log("update", this.runningTime);

            let needRunIds: Array<number> = new Array<number>();
            let needRemoveIds: Array<number> = new Array<number>();
            //找到符合时间的任务，如果非循环任务，要从列表中删除，循环则更改delay
            for (let i = 0; i < this.taskList.length; i++) {
                let taskData = this.taskList[i];
                if (taskData.runningTime <= this.runningTime) {
                    needRunIds.push(taskData.id);
                    if (!taskData.isLoop) {
                        needRemoveIds.push(taskData.id);
                    } else {
                        taskData.runningTime = this.runningTime + taskData.delay;
                        if (taskData.loopTimes > 0) {
                            taskData.loopTimes--;
                            if (taskData.loopTimes == 0) {
                                needRemoveIds.push(taskData.id);
                            }
                        }
                    }

                }
            }
            //执行任务
            for (let i = 0; i < needRunIds.length; i++) {
                let id = needRunIds[i];
                let taskData = this.taskList.find((t) => t.id == id);
                if (taskData) {
                    taskData.task();
                }
            }
            //删除非循环任务
            for (let i = 0; i < needRemoveIds.length; i++) {
                let id = needRemoveIds[i];
                let index = this.taskList.findIndex((t) => t.id == id);
                if (index != -1) {
                    this.taskList.splice(index, 1);
                }
            }

        }



        private getId(): number {
            this.currentId++;
            return this.currentId;
        }


        public destroy() {
            this.clear();
            this.stop();

        }



    }

}