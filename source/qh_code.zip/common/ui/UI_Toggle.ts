module uiscript {
    /**
     * 复选框组件
     * Sprite
     * |- up 没选中显示的部分
     * |- down 选中显示的部分
     * |- btn
     * |- title 可以没有
     * |- icon 可以没有
     */
    export class UI_Toggle extends UI_Component {
        
        private innerTitle: Laya.Label;
        private innerIcon: Laya.Image;
        private up: Laya.Sprite;
        private down: Laya.Sprite;
        private button: Laya.Button;
        private innerOn: boolean = false;
        private handlers: Array<Laya.Handler>;

        constructor(comp: Laya.Sprite) {
            super(comp);
        }

        public onCreate(): void {

            this.innerTitle = this.me.getChildByName("title") as Laya.Label;
            this.innerIcon = this.me.getChildByName("icon") as Laya.Image;
            this.up = this.me.getChildByName("up") as Laya.Sprite;
            this.down = this.me.getChildByName("down") as Laya.Sprite;
            this.button = this.me.getChildByName("btn") as Laya.Button;
            this.button.clickHandler = new Laya.Handler(this, this.onClick);
            this.handlers = new Array();
            this.on = false;
        }


        private onClick() {
            
            this.on = !this.on;
            this.handlers.forEach(handler => {
                handler.run();
            });
        }

        public set title(str: string) {
            if (this.innerTitle) {
                this.innerTitle.text = str;
            }
        }

        public get titleLabel() {
            if (this.innerTitle) {
                return this.innerTitle;
            }
        }

        public set titleColor(color: string) {
            if (this.innerTitle) {
                this.innerTitle.color = color;
            }
        }


        public set titleFontSize(size: number) {
            if (this.innerTitle) {
                this.innerTitle.fontSize = size;
            }
        }

        public set icon(url: string) {
            if (this.innerIcon) {
                this.innerIcon.loadImage(url);
            }
        }

        public set visible(isVisible: boolean){
            this.me.visible = isVisible;
        }

        /**
         * 当前是否被选中
         */
        public get on(){
            return this.innerOn;
        }

        public set on(isOn:boolean){
            this.innerOn = isOn;
            if (this.up && this.down) {
                this.up.visible = !isOn;
                this.down.visible = isOn;
            }
        }

        public addClickListener(handler: Laya.Handler) {
            this.handlers.push(handler);
        }


        public setClickListener(handler: Laya.Handler) {
            this.handlers = new Array();
            this.addClickListener(handler)
        }

        public removeAllListener(){
            this.handlers = new Array();
        }

        public removeClickListener(handler: Laya.Handler): void {
            const index = this.handlers.indexOf(handler);
            if (index > -1) {
                this.handlers.splice(index, 1);
            }
        }

        public vitrualClick() { 
            this.onClick();
        }

    }
}