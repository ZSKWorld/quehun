module uiscript {
    export interface UI_Tweener { 
        /**
         * tween的id
         */
        id: number;
        /**
         * tweener正在执行的动画
         */
        tweener: Laya.Tween;
        /**
         * 动画目标
         */
        target: any;
        /**
         * 动画属性
         */
        props: any;
        /**
         * 动画时长
         */
        duration: number;
        /**
         * 动画缓动函数
         */
        ease?: Function;
        /**
         * 动画完成回调
         */
        complete?: Laya.Handler;
        /**
         * 动画延迟
         */
        delay?: number;
        /**
         * 是否覆盖之前的动画
         */
        coverBefore?: boolean;
        /**
         * 是否自动恢复
         */
        autoRecover?: boolean;
        /**
         * 动画开始时间
         */
        startTime: number;
        /**
         * 动画类型：to 或 from
         */
        type: 'to' | 'from';
        /**
         * 初始属性值
         */
        startProps: any;
        /**
         * 动画倍速
         */
        timeScale: number;
    }
    
    export class UI_TweenManager {
        private runningTweeners: basic.Dictionary<number, UI_Tweener> = new basic.Dictionary<number, UI_Tweener>();
        /**
         * 用来给每个任务一个唯一的id
         */
        private currentId: number = 0;
        /**
         * 全局动画倍速
         */
        private globalTimeScale: number = 1;
        constructor() {
            this.runningTweeners = new basic.Dictionary<number, UI_Tweener>();
        }
        
        public addTweenTo(target: any, props: any, duration: number, ease?: Function, complete?: Laya.Handler, delay?: number, coverBefore?: boolean, autoRecover?: boolean) {
            let id = this.getId();
            // 保存初始属性值
            let startProps = {};
            for (let key in props) {
                startProps[key] = target[key];
            }
            let onComplete = Laya.Handler.create(this, () => {
                //移除已经播放完毕的tweener
                this.removeTweener(id);
                if (complete) complete.run();
            });
            // 根据全局倍速调整动画时长
            let adjustedDuration = duration / this.globalTimeScale;
            let tweener = Laya.Tween.to(target, props, adjustedDuration, ease, onComplete, delay, coverBefore, autoRecover);
            let uiTweener:UI_Tweener = {
                id: id,
                tweener: tweener,
                target: target,
                props: props,
                duration: duration,
                ease: ease,
                complete: complete,
                delay: delay || 0,
                coverBefore: coverBefore || false,
                autoRecover: autoRecover || false,
                startTime: Laya.timer.currTimer,
                type: 'to',
                startProps: startProps,
                timeScale: this.globalTimeScale
            };
            this.runningTweeners.set(id, uiTweener);
            return id; // 返回id以便后续操作
        }

        public addTweenFrom(target: any, props: any, duration: number, ease?: Function, complete?: Laya.Handler, delay?: number, coverBefore?: boolean, autoRecover?: boolean) {
            let id = this.getId();
            // 保存初始属性值
            let startProps = {};
            for (let key in props) {
                startProps[key] = target[key];
            }
            let onComplete = Laya.Handler.create(this, () => {
                //移除已经播放完毕的tweener
                this.removeTweener(id);
                if (complete) complete.run();
               
            });
            // 根据全局倍速调整动画时长
            let adjustedDuration = duration / this.globalTimeScale;
            let tweener = Laya.Tween.from(target, props, adjustedDuration, ease, onComplete, delay, coverBefore, autoRecover);
            let uiTweener: UI_Tweener = {
                id: id,
                tweener: tweener,
                target: target,
                props: props,
                duration: duration,
                ease: ease,
                complete: complete,
                delay: delay || 0,
                coverBefore: coverBefore || false,
                autoRecover: autoRecover || false,
                startTime: Laya.timer.currTimer,
                type: 'from',
                startProps: startProps,
                timeScale: this.globalTimeScale
            };
            this.runningTweeners.set(id, uiTweener);
            return id; // 返回id以便后续操作


        }

        public completeAllTweens() {
            for (let i: number = 0; i < this.runningTweeners.keys().length; i++) {
                this.runningTweeners.get(this.runningTweeners.keys()[i]).tweener?.complete();
            }
            this.runningTweeners = new basic.Dictionary<number, UI_Tweener>();
        }

        public clearAllTweens() {
            for (let i: number = 0; i < this.runningTweeners.keys().length; i++) {
                this.runningTweeners.get(this.runningTweeners.keys()[i]).tweener?.clear();
            }
            this.runningTweeners = new basic.Dictionary<number, UI_Tweener>();
        }

        private getId(): number {
            this.currentId++;
            return this.currentId;
        }

        public removeTweener(id: number) {
            let tweener = this.runningTweeners.get(id);
            if (tweener) {
                this.runningTweeners.remove(id);
            }
        }

        public isTweenRunning(id: number): boolean {
            return this.runningTweeners.has(id);
        }

        //暂停所有缓动
        public pauseAllTweens() {
            for (let i: number = 0; i < this.runningTweeners.keys().length; i++) {
                this.runningTweeners.get(this.runningTweeners.keys()[i]).tweener?.pause();
            }
        }

        //恢复所有缓动
        public resumeAllTweens() {
            for (let i: number = 0; i < this.runningTweeners.keys().length; i++) {
                this.runningTweeners.get(this.runningTweeners.keys()[i]).tweener?.resume();
            }
        }

        // 若动画未完成需要打断可调用
        public clearTweener(id: number) {
            let tweener = this.runningTweeners.get(id);
            if (tweener) {
                tweener.tweener?.clear();
                this.runningTweeners.remove(id);
            }
        }
        
        /**
         * 设置全局动画倍速
         * @param timeScale 倍速值
         */
        public setGlobalTimeScale(timeScale: number): void {
            // 检查参数有效性
            if (timeScale <= 0) return;
            
            // 更新全局倍速
            this.globalTimeScale = timeScale;
            
            // 更新所有正在运行的动画的倍速
            let tweenIds = [];
            for (let i: number = 0; i < this.runningTweeners.keys().length; i++) {
                tweenIds.push(this.runningTweeners.keys()[i]);
            }
            
            // 逐个修改动画倍速
            for (let id of tweenIds) {
                this.setTweenTimeScale(id, timeScale);
            }
        }
        
        /**
         * 获取全局动画倍速
         */
        public getGlobalTimeScale(): number {
            return this.globalTimeScale;
        }
        
        /**
         * 设置单个动画倍速
         * @param id 动画ID
         * @param timeScale 倍速值
         */
        public setTweenTimeScale(id: number, timeScale: number): number {
            // 1. 检查参数有效性
            if (timeScale <= 0) return -1;
            
            // 2. 获取旧动画
            let oldTweener = this.runningTweeners.get(id);
            if (!oldTweener || !oldTweener.tweener) return -1;
            
            // 3. 计算已用时间
            let currentTime = Laya.timer.currTimer;
            // 检查系统时间是否异常（比如时间倒流或时间跳跃过大）
            if (currentTime < 0 || currentTime - oldTweener.startTime > oldTweener.duration * 10) {
                // 系统时间异常，清除旧动画并返回
                oldTweener.tweener.clear();
                this.runningTweeners.remove(id);
                return -1;
            }
            
            let elapsedTime = currentTime - oldTweener.startTime;
            if (elapsedTime < 0) elapsedTime = 0;
            if (elapsedTime > oldTweener.duration) elapsedTime = oldTweener.duration;
            
            // 4. 计算剩余时间
            let remainingTime = oldTweener.duration - elapsedTime;
            if (remainingTime <= 0) {
                // 动画已完成，清除旧动画并返回
                oldTweener.tweener.clear();
                this.runningTweeners.remove(id);
                return -1;
            }
            
            // 5. 计算新的剩余时间
            let newRemainingTime = remainingTime / timeScale;
            if (newRemainingTime <= 0 || isNaN(newRemainingTime)) return -1;
            
            // 6. 计算剩余距离（新的目标属性值）
            let newProps = {};
            for (let key in oldTweener.props) {
                let startValue = oldTweener.startProps[key];
                let targetValue = oldTweener.props[key];
                let currentValue = oldTweener.target[key];
                
                // 只处理数字属性
                if (typeof startValue === 'number' && typeof targetValue === 'number' && typeof currentValue === 'number') {
                    // 计算剩余距离
                    if (oldTweener.type === 'to') {
                        // to 动画：从 startValue 到 targetValue
                        let totalDistance = targetValue - startValue;
                        let currentDistance = currentValue - startValue;
                        let remainingDistance = totalDistance - currentDistance;
                        newProps[key] = currentValue + remainingDistance;
                    } else {
                        // from 动画：从 targetValue 到 startValue
                        let totalDistance = startValue - targetValue;
                        let currentDistance = currentValue - targetValue;
                        let remainingDistance = totalDistance - currentDistance;
                        newProps[key] = currentValue + remainingDistance;
                    }
                } else {
                    // 非数字属性直接使用目标值
                    newProps[key] = oldTweener.props[key];
                }
            }
            
            // 7. 清除旧动画
            oldTweener.tweener.clear();
            this.runningTweeners.remove(id);
            
            // 8. 重新开新动画
            let newId = -1;
            if (oldTweener.type === 'to') {
                newId = this.addTweenTo(
                    oldTweener.target,
                    newProps,
                    newRemainingTime,
                    oldTweener.ease,
                    oldTweener.complete,
                    0, // 新动画不需要延迟
                    oldTweener.coverBefore,
                    oldTweener.autoRecover
                );
            } else {
                newId = this.addTweenFrom(
                    oldTweener.target,
                    newProps,
                    newRemainingTime,
                    oldTweener.ease,
                    oldTweener.complete,
                    0, // 新动画不需要延迟
                    oldTweener.coverBefore,
                    oldTweener.autoRecover
                );
            }
            
            return newId;
        }
    }

}