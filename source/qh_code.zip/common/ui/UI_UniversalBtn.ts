module uiscript {
    export enum EUniversalBtnType {
        DEFAULT,
        CONFIRM_YELLOW,
        CANCEL_BLUE,
        WARNING_BLUE,
        GRAY_DISABLE,
    }
    /**
     * 通用按钮,结构为btn按钮，子物体下有个“title”用于显示标题,字体为fengyu,字体大小为42
     * 黄色按钮（确认、领取、购买） myres/pop_panel/btn_y.png + 棕色字体 #442334 
     * 蓝色按钮 （取消）myres/pop_panel/btn_b.png + 黄色字体 #e5b673
     * 蓝色警示按钮myres/pop_panel/btn_b.png + 红色字体 #ff3338
     * 灰色按钮 myres/pop_panel/btn_g.png + 灰色字体 #525a6b
     */
    export class UI_UniversalBtn extends UI_Component {
        private btn: Laya.Button;
        private title: Laya.Label;
        private skinPath: string = "myres/pop_panel/btn_y.png";
        private color: string = "#442334";
        private grayBgPath: string = "myres/pop_panel/btn_g.png";
        private grayTextColor: string = "#525a6b";
        private btnType: EUniversalBtnType = EUniversalBtnType.DEFAULT;
      
        constructor(comp: Laya.Sprite) {
            super(comp);
        }
        
        public onCreate() {
            this.btn = this.me as Laya.Button;
            this.title = this.btn.getChildByName('title') as Laya.Label;
            this.skinPath = this.btn.skin;
            this.color = this.title.color;
            
        }

        public set type(value: EUniversalBtnType) { 
            this.btnType = value;
            switch (this.btnType) {
                case EUniversalBtnType.DEFAULT:
                    this.skinPath = "myres/pop_panel/btn_y.png";
                    this.color = "#442334";
                    break;
                case EUniversalBtnType.CONFIRM_YELLOW:
                    this.skinPath = "myres/pop_panel/btn_y.png";
                    this.color = "#442334";
                    break;
                case EUniversalBtnType.CANCEL_BLUE:
                    this.skinPath = "myres/pop_panel/btn_b.png";
                    this.color = "#e5b673";
                    break;
                case EUniversalBtnType.WARNING_BLUE:
                    this.skinPath = "myres/pop_panel/btn_b.png";
                    this.color = "#ff3338";
                    break;
                case EUniversalBtnType.GRAY_DISABLE:
                    this.skinPath = "myres/pop_panel/btn_g.png";
                    this.color = "#525a6b";
                    break;
            }

        }



        public setTitle(title: string) {
            this.title.text = title;
        }

        public set clickHandler(handler: Laya.Handler) {
            this.btn.clickHandler = handler;
        }

        public setEnabled(isEnabled: boolean) {
            this.btn.mouseEnabled = isEnabled;
        }

        public setGrayed(isGray: boolean) {
            this.skin = isGray ? this.grayBgPath : this.skinPath;
            this.title.color = isGray ? this.grayTextColor : this.color;
            
        }
        
        public setSkinPath(skin: string) {
            this.skinPath = skin;
        }

        public setTextColor(color: string) {
            this.color = color;
            this.title.color = color;
        }

        public set skin(skin: string) {
            this.btn.skin = game.Tools.localUISrc(skin);
        }
        

    }

}