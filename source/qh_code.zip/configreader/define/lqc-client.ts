
namespace lqc {

type MapSheetData<T> = {[id: number]: T};
type GroupSheetData<T> = {[id: number]: T[]};

function throwError(code, message) {
  const error = new Error(message);
  error['code'] = code;
  throw error;
}

// 键值唯一表
export class UniqueSheet<T> {

  constructor(table: string, sheet: string, rows: T[], keyName: string) {
    this.table_ = table;
    this.sheet_ = sheet;
    this.rows_ = rows || [];

    this.map_ = {};
    this.minKey_ = null;
    this.maxKey_ = null;

    rows.sort((a, b) => { return a[keyName] - b[keyName]; });

    if (rows.length > 0) {
      this.minKey_ = rows[0][keyName];
      this.maxKey_ = rows[rows.length - 1][keyName];
    }

    rows.forEach(row => {
      let key = row[keyName];
      this.map_[key] = row;
    });
  }

  get(id): T {
    return this.map_[id];
  }

  find(id): T {
    if (!this.map_[id])
      throwError('ERR_CONFIG_ROW_NOT_FIND', '[unique] ' + this.table_ + '.' + this.sheet_ + '#' + id);

    return this.map_[id];
  }

  forEach(each: (value: T, index: number, array: T[]) => void) {
    this.rows_.forEach(each);
  }

  get table(): string { return this.table_; }
  get sheet(): string { return this.sheet_; }

  get count(): number { return this.rows_.length; }
  get minKey(): number { return this.minKey_; }
  get maxKey(): number { return this.maxKey_; }

  private table_: string;
  private sheet_: string;
  private rows_: T[];
  private map_: MapSheetData<T>;
  private minKey_: number;
  private maxKey_: number;
}

// 无键表
export class NoKeySheet<T> {

  constructor(table: string, sheet: string, rows: T[]) {
    this.table_ = table;
    this.sheet_ = sheet;
    this.rows_ = rows || [];
  }

  forEach(each: (value: T, index: number, array: T[]) => void) {
    this.rows_.forEach(each);
  }

  get table(): string { return this.table_; }
  get sheet(): string { return this.sheet_; }
  get count(): number { return this.rows_.length; }

  private table_: string;
  private sheet_: string;
  private rows_: T[];
}

// 分组表
export class GroupSheet<T> {

  constructor(table: string, sheet: string, rows: T[], keyName: string) {
    this.table_ = table;
    this.sheet_ = sheet;
    this.rows_ = rows || [];
    this.groups_ = {};

    this.rows_.forEach(row =>{
      const key = row[keyName];
      if (!this.groups_[key])
        this.groups_[key] = [];
      const group = this.groups_[key];
      group.push(row);
    });
  }

  // 注意：返回引用，不要修改返回值
  getGroup(id): T[] {
    return this.groups_[id];
  }

  // 注意：返回引用，不要修改返回值
  findGroup(id): T[] {
    if (!this.groups_[id])
      throwError('ERR_CONFIG_ROW_NOT_FIND', '[unique] ' + this.table_ + '.' + this.sheet_ + '#' + id);

    return this.groups_[id];
  }

  // 遍历所有行记录
  forEach(each: (value: T, index: number, array: T[]) => void) {
    this.rows_.forEach(each);
  }

  // 遍历所有组记录
  forEachGroup(eachGroup: (values: T[], groupKey: number|string) => void) {
    Object.keys(this.groups_).forEach((key) => {
      eachGroup(this.groups_[key], key);
    });
  }

  get table(): string { return this.table_; }
  get sheet(): string { return this.sheet_; }
  get count(): number { return this.rows_.length; }

  private table_: string;
  private sheet_: string;
  private rows_: T[];
  private groups_: GroupSheetData<T>;
}

export class ReferenceField<T> {

  constructor(value: any) {
    this.value_ = value;
    this.ref_ = null;
  }

  resolve(ref) {
    this.ref_ = ref;
  }

  get value(): any { return this.value_; }

  get ref() { return this.ref_; }

  private value_: string | number;
  private ref_: T;
}

//////////////////// ab_match.match_info ////////////////////
export interface Sheet_AbMatch_MatchInfo {
  readonly id: number;
  readonly ab_match_activity_id: number;
  readonly match_activity_id: number;
  readonly desktop_id_list: string;
  readonly consume_id: number; // 每次买入的消耗id
  readonly buy_in_condition: string; // 买入条件
  readonly mail_template_id: number; // 邮件补发奖品编号
  readonly max_match_count: number; // 单次买入对局数
  readonly reward_id: number;
  readonly point_id: number;
  readonly match_level: number;
  readonly priority: number; // 优先级，优先进入满足买入条件的优先级高的组别
}
//////////////////// ab_match.point ////////////////////
export interface Sheet_AbMatch_Point {
  readonly id: number;
  readonly rank: number;
  readonly desktop_id_list: string;
  readonly point: number;
}
//////////////////// ab_match.reward_seq ////////////////////
export interface Sheet_AbMatch_RewardSeq {
  readonly id: number;
  readonly point_lower: number;
  readonly point_upper: number;
  readonly reward: string;
  readonly chest_mark: number;
}
//////////////////// ab_match.consume_seq ////////////////////
export interface Sheet_AbMatch_ConsumeSeq {
  readonly id: number;
  readonly match_count: number;
  readonly item_id: number;
  readonly item_count: number;
}
//////////////////// ab_match ////////////////////
export interface Table_AbMatch {
  readonly match_info: UniqueSheet<Sheet_AbMatch_MatchInfo>;
  readonly point: GroupSheet<Sheet_AbMatch_Point>;
  readonly reward_seq: GroupSheet<Sheet_AbMatch_RewardSeq>;
  readonly consume_seq: GroupSheet<Sheet_AbMatch_ConsumeSeq>;
}
//////////////////// achievement.achievement ////////////////////
export interface Sheet_Achievement_Achievement {
  readonly id: number;
  readonly name_chs: string;
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string;
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly rare: number; // 0不判定1铜2银3金
  readonly locked: number; // 1为加锁，0为普通
  readonly group_id: number; // 所属大类
  readonly sort: number; // 同一分类的排序从小到大
  readonly segment_id: number;
  readonly base_task: number;
  readonly reward: string; // 完成奖励
  readonly hidden: number; // 服务端不计入【成就收集者】的数量
  readonly deprecated: number; // 1废弃，0正常
}
//////////////////// achievement.achievement_group ////////////////////
export interface Sheet_Achievement_AchievementGroup {
  readonly id: number;
  readonly name_chs: string;
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly img: string; // 图片名
  readonly reward: string; // 大类下所有成就完成后奖励,没有就留空
  readonly percentage: number; // 1可统计占比 0不统计
  readonly deprecated: number; // 1废弃，0正常
  readonly sort: number; // 分类排序从小到大
}
//////////////////// achievement.badge ////////////////////
export interface Sheet_Achievement_Badge {
  readonly id: number;
  readonly base_task: number; // 对应任务id
  readonly deprecated: number; // 是否废弃（0-正常 1-废弃）
}
//////////////////// achievement.badge_group ////////////////////
export interface Sheet_Achievement_BadgeGroup {
  readonly id: number;
  readonly badge_id: number[];
  readonly name: number; // 勋章名
  readonly desc: number; // 勋章描述
  readonly type: number; // 1段位 2友人 3活动，同一tab内四麻三麻完成次数加起来
  readonly img: string; // myres2/badge/图片名
}
//////////////////// achievement ////////////////////
export interface Table_Achievement {
  readonly achievement: UniqueSheet<Sheet_Achievement_Achievement>;
  readonly achievement_group: UniqueSheet<Sheet_Achievement_AchievementGroup>;
  readonly badge: UniqueSheet<Sheet_Achievement_Badge>;
  readonly badge_group: UniqueSheet<Sheet_Achievement_BadgeGroup>;
}
//////////////////// activity.activity ////////////////////
export interface Sheet_Activity_Activity {
  readonly id: number; // 活动id
  readonly name_chs: string; // 活动名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly type: string; // 活动类型
  readonly need_popout: number; // 是否需要弹出来
}
//////////////////// activity.task ////////////////////
export interface Sheet_Activity_Task {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动id
  readonly day: number; // 自活动开始的天数
  readonly base_task_id: number; // 基础任务id
  readonly reward_id: number; // 奖励id
  readonly reward_count: number; // 奖励数量
  readonly hidden_reward: string; // 隐藏奖励
  readonly limit_id: number; // 限制ID source_limit表
  readonly deprecated: number; // 维护用字段，将任务转变为不可见不可领状态
}
//////////////////// activity.exchange ////////////////////
export interface Sheet_Activity_Exchange {
  readonly id: number; // 兑换id
  readonly activity_id: number; // 活动id
  readonly reward_id: number; // 奖励id
  readonly reward_count: number; // 奖励数量
  readonly consume_id: number; // 消耗id
  readonly consume_count: number; // 消耗数量
  readonly exchange_limit: number; // 兑换次数限制
  readonly item_limit_id: number; // 兑换限制道具id
  readonly item_limit_count: number; // 已有超过/等于数量的物品就不能兑换
  readonly unlock_day: string; // 解锁时间
}
//////////////////// activity.chest_up ////////////////////
export interface Sheet_Activity_ChestUp {
  readonly activity_id: number; // 活动id
  readonly chest_id: number; // 宝箱ID
  readonly title_str_id: number; // 卡池短名
  readonly str_id: string; // 卡池说明文，高亮用[tag]区分[/tag]
  readonly chara_str_id: number; // 角色出率文本
  readonly item_str_id: number; // 装扮出率文本
  readonly img: string; // 宣传图
  readonly title_img: string; // 卡池标题图
  readonly title_img_2: string; // 卡池标题图2（左下，联动/ur）
  readonly typeset: number; // 排版种类
  readonly enter_animation: string; // 进入动画
  readonly special_effect_front: string; // 特效前
  readonly special_effect_back: string; // 特效后，常驻，特效替换樱花特效
  readonly special_audio: number; // audio表内音效
  readonly up_items_type: number; // 0=无up装扮，1=新装扮，2=特定老装扮，3=常驻装扮
  readonly up_items: number[]; // UP的物品
}
//////////////////// activity.game_task ////////////////////
export interface Sheet_Activity_GameTask {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动id
  readonly base_task_id: number; // 基础任务id
  readonly reward: string; // 奖励id
  readonly hidden_reward: string; // 隐藏奖励
  readonly limit_id: number; // 限制ID source_limit表
  readonly single_trigger: number; // 一场对局只能完成1次
  readonly deprecated: number; // 维护用字段，将任务转变为不可见不可领状态
}
//////////////////// activity.game_point ////////////////////
export interface Sheet_Activity_GamePoint {
  readonly id: number;
  readonly activity_id: number; // 活动ID
  readonly point_id: number; // 分数ID
  readonly point: number; // 分数
  readonly res_id: number; // 奖励ID
  readonly res_count: number; // 奖励数量
  readonly unlock_day: number; // 第几天解锁
  readonly node_mark: number; // 各节点0普通1突出
  readonly image_mark: number; // 显示的立绘差分
}
//////////////////// activity.rank ////////////////////
export interface Sheet_Activity_Rank {
  readonly activity_id: number; // 活动ID
  readonly leaderboard_id: number; // 排行榜ID
  readonly rank_reward_id: number; // 奖励ID
  readonly require_point: number; // 上榜最低点数
}
//////////////////// activity.rank_reward ////////////////////
export interface Sheet_Activity_RankReward {
  readonly id: number;
  readonly lower_rank_bound: number; // 档位排名下界
  readonly reward: string; // 奖励列表
}
//////////////////// activity.flip_task ////////////////////
export interface Sheet_Activity_FlipTask {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动ID
  readonly base_task_id: number; // 基础任务id
  readonly reward: string; // 奖励列表
  readonly matrix_x: number; // 矩阵位置x
  readonly matrix_y: number; // 矩阵位置y
  readonly is_reward: number; // 是否是奖励格
}
//////////////////// activity.flip_info ////////////////////
export interface Sheet_Activity_FlipInfo {
  readonly id: number; // 活动ID
  readonly flip_count: number; // 每日翻牌次数
  readonly init_task_list: string; // 初始任务列表
  readonly start_time: string; // 翻牌开始时间
  readonly end_time: string; // 翻牌结束时间（不影响领奖）
}
//////////////////// activity.daily_sign ////////////////////
export interface Sheet_Activity_DailySign {
  readonly activity_id: number; // 活动ID
  readonly reward_id: number; // 奖励id
  readonly reward_count: number; // 奖励数量
  readonly day: number; // 自活动开始的天数
}
//////////////////// activity.richman_info ////////////////////
export interface Sheet_Activity_RichmanInfo {
  readonly activity_id: number; // 活动ID
  readonly map_id: number; // 活动地图ID
  readonly map_distance: number; // 地图长度
  readonly chest_id: number; // 活动宝箱 poolId
  readonly consume_item_id: number; // 消耗道具id
  readonly special_item_id: number; // 消耗特殊道具id
  readonly step_bank_save: number; // 丢骰子获得的存款
  readonly finish_bank_save: number; // 完成一圈获得存款
  readonly finish_reward_seq: number; // 完成一圈获得的奖励序列
  readonly step_exp: number; // 用一次骰子的经验
  readonly finish_exp: number; // 走完一圈的经验
  readonly item_worth_pool: number; // 物品价值表
  readonly min_avg_worth: number; // 最低每步收益
  readonly max_avg_worth: number; // 最高每步收益
  readonly chest_pool_seq: number; // 宝箱序列
}
//////////////////// activity.richman_map ////////////////////
export interface Sheet_Activity_RichmanMap {
  readonly map_id: number; // 地图ID
  readonly location: number; // 地图位置
  readonly pos_x: number; // 格子坐标
  readonly pos_y: number;
  readonly piece_face: number; // 面朝方向
  readonly type: number; // 格子类型
  readonly param: number; // 参数
  readonly bonus_type: number; // 配置奖励类型
  readonly worth: number; // 预期价值
}
//////////////////// activity.richman_level ////////////////////
export interface Sheet_Activity_RichmanLevel {
  readonly activity_id: number; // 活动ID
  readonly name: string; // 名称
  readonly id: number; // 等级ID
  readonly exp: number; // 所需累积经验
  readonly buff: number; // 铜币加成（百分比整数）
}
//////////////////// activity.richman_event ////////////////////
export interface Sheet_Activity_RichmanEvent {
  readonly event_id: number; // event唯一标识
  readonly activity_id: number; // 活动ID
  readonly event_type: number; // 事件类型
  readonly weight: number; // 随机权重
  readonly param: number[];
}
//////////////////// activity.period_task ////////////////////
export interface Sheet_Activity_PeriodTask {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动id
  readonly base_task_id: number; // 基础任务id
  readonly reward: string; // 奖励
  readonly node_mark: number; // 0普通1突出
  readonly interval: number; // 刷新周期
  readonly progress_limit: number; // 周期内能完成的次数限制
  readonly progress_limit_interval: number; // 次数限制周期
  readonly reward_limit_day: number; // 活动开始x天后才可以领取
  readonly accessible_days: string; // 任务有效时间，在有效时间内才可以累计任务进度，领取任务奖励，格式：{startDay}-{endDay} 例: 0-5 代表活动开始第0天至活动开始后第5天[0, 5]
  readonly unlock_day: number; // 第一次拉到活动后x天解锁
  readonly deprecated: number; // 维护用字段，将任务转变为不可见不可领状态
  readonly omit_mail_reward: number; // 补发邮件是否忽略
}
//////////////////// activity.random_task_pool ////////////////////
export interface Sheet_Activity_RandomTaskPool {
  readonly pool_id: number; // 任务池ID
  readonly task_id: number; // 任务id
  readonly activity_id: number; // 活动ID
  readonly base_task_id: number; // 基础任务id
  readonly reward_id: number; // 奖励id
  readonly reward_count: number; // 奖励数量
  readonly weight: number; // 权重
  readonly hidden_reward: string; // 隐藏奖励
  readonly limit_id: number; // 限制ID source_limit表
}
//////////////////// activity.random_task_info ////////////////////
export interface Sheet_Activity_RandomTaskInfo {
  readonly activity_id: number; // 活动ID
  readonly pool_id: number[]; // 任务池ID
}
//////////////////// activity.richman_reward_seq ////////////////////
export interface Sheet_Activity_RichmanRewardSeq {
  readonly id: number; // id
  readonly count: number; // 完成圈数
  readonly reward: string; // 奖励
}
//////////////////// activity.activity_buff ////////////////////
export interface Sheet_Activity_ActivityBuff {
  readonly buff_id: number; // buffid
  readonly activity_id: number; // 活动ID
  readonly buff_level: number; // buff等级
  readonly resetable: number; // 可升级重置
  readonly buff_group: number; // buff组
  readonly buff_type: number; // buff类型
  readonly upgrade_resource_id: number; // 升级资源ID
  readonly upgrade_resource_count: number; // 升级资源数量
  readonly effect: number; // buff效果
  readonly unlock_params: number[]; // 解锁条件参数0
  readonly effect_desc: number; // 当前buff效果描述strid
  readonly effect_desc_2: number; // 当前buff效果描述strid2
  readonly limit_count: number; // 次数限制
  readonly limit_interval: number; // 次数限制周期
}
//////////////////// activity.buff_condition ////////////////////
export interface Sheet_Activity_BuffCondition {

}
//////////////////// activity.game_point_info ////////////////////
export interface Sheet_Activity_GamePointInfo {
  readonly activity_id: number; // 活动ID
  readonly filter_id: number; // 得分筛选器id
  readonly reward_mail_template: number; // 邮件补发奖品编号
  readonly max_point_limit_day: number; // 活动点数解除限制的day，全程不解限填-1
  readonly should_rank: number; // 如果为0则game_point_rank不生效
}
//////////////////// activity.game_point_rank ////////////////////
export interface Sheet_Activity_GamePointRank {
  readonly activity_id: number; // 活动ID
  readonly rank_rate_lower: number; // 大于（百分比）
  readonly rank_rate_upper: number; // 小于等于（百分比）
  readonly reward: string; // 奖励
}
//////////////////// activity.game_point_filter ////////////////////
export interface Sheet_Activity_GamePointFilter {
  readonly id: number;
  readonly has_robot: string; // 是否可以带AI
  readonly category: string; // 对局类别
  readonly room: string; // 匹配房间
  readonly mode: string; // 对局模式
  readonly point_coe: number; // 点数比例（x分之一）
}
//////////////////// activity.activity_room ////////////////////
export interface Sheet_Activity_ActivityRoom {
  readonly activity_id: number; // 友人房活动ID
  readonly sort: number; // 数字小的在前
  readonly str_name: string; // 对局名
  readonly str_rule: string; // 拼接规则
  readonly friend_room_id: number; // 对应desktop/friend_room
  readonly dora3_mode: number; // 是否允许开dora3
  readonly begin_open_mode: number; // 是否允许开配牌open
  readonly muyu_mode: number; // 是否允许开目玉
  readonly xuezhan_mode: number; // 是否允许开血战
  readonly huanzhang_mode: number; // 是否允许开换三张
  readonly chuanma_mode: number; // 川麻模式
  readonly jiuchao_mode: number; // 三透牌模式
  readonly reveal_discard: number; // 暗牌模式
  readonly field_spell_mode: number;
  readonly zhanxing_mode: number;
  readonly tianming_mode: number;
  readonly yongchang_mode: number;
  readonly hunzhiyiji_mode: number;
  readonly wanxiangxiuluo_mode: number;
  readonly beishuizhizhan_mode: number;
  readonly xiakeshang_mode: number;
  readonly qiangduozhizhan_mode: number;
}
//////////////////// activity.sns_activity ////////////////////
export interface Sheet_Activity_SnsActivity {
  readonly id: number; // snsID
  readonly disable: number;
  readonly pm: number; // 是否私信
  readonly period: number; // 对话结束标记
  readonly activity_id: number; // sns活动ID
  readonly content_str_id: number; // 博客内容
  readonly parent_id: number; // 父snsID
  readonly char_id: number; // 昵称，自定id和玩家id填0
  readonly char_str_id: number; // 指定str-event，玩家id填0
  readonly reply_char_id: number; // 回复，玩家id填1，自定id填0
  readonly reply_char_str_id: number; // 指定str-event
  readonly choice_id: number; // 用户选项分组
  readonly like: number; // 点赞数
  readonly unlock_time: string; // 解锁时间，解锁物品是【且】关系
  readonly type: number; // 消息类型
  readonly content_head: string; // 自定头像
  readonly content_image: string[]; // 博客图片
  readonly unlock_item_id: number; // 解锁物品ID
  readonly unlock_item_count: number; // 解锁物品数量
}
//////////////////// activity.mine_activity ////////////////////
export interface Sheet_Activity_MineActivity {
  readonly activity_id: number; // activity_id
  readonly reward_group: number; // 奖励组ID
  readonly cost_item: string; // 挖矿消耗物品
  readonly map_size_x: number; // 地图大小
  readonly map_size_y: number; // 地图大小
}
//////////////////// activity.mine_reward ////////////////////
export interface Sheet_Activity_MineReward {
  readonly group_id: number;
  readonly reward_id: number; // 唯一奖励id
  readonly reward: string; // 奖励内容
  readonly type: number; // 显示类型
  readonly x: number; // 宽度
  readonly y: number; // 高度
}
//////////////////// activity.rpg_activity ////////////////////
export interface Sheet_Activity_RpgActivity {
  readonly activity_id: number;
  readonly base_hp: number; // 玩家基础生命
  readonly base_atk: number; // 玩家基础攻击
  readonly base_dex: number; // 玩家基础回避
  readonly base_luk: number; // 玩家基础暴击
  readonly ds_atk: number; // 击飞额外攻击力
  readonly special_heal: number; // 无铳治疗量
  readonly chain_atk: number[]; // 连续胡牌攻击倍率
  readonly monster_group: number; // 怪物组
  readonly sanma_debuff: number; // 三麻敌我攻击力削弱
  readonly has_robot: number; // 是否可以带AI
  readonly category: string; // 对局类别
  readonly mode: string; // 匹配模式
  readonly room: string; // 对局模式
  readonly daily_limit: number; // 每日击破上限
}
//////////////////// activity.rpg_monster_group ////////////////////
export interface Sheet_Activity_RpgMonsterGroup {
  readonly group_id: number;
  readonly seq: number; // 顺序
  readonly type: number; // 怪类型（纯前端）0杂兵，1boss
  readonly hp: number; // 血量
  readonly atk: number; // 攻击力
  readonly reward: string; // 奖励
  readonly season: number; // 前端用
  readonly chapters: string; // 前端用
  readonly imaget_path: string; // 前端用
  readonly background: string; // 前端用
  readonly name_str_id: number; // 对应str/event
}
//////////////////// activity.arena_activity ////////////////////
export interface Sheet_Activity_ArenaActivity {
  readonly activity_id: number;
  readonly match_time: string; // 匹配时间控制
  readonly ticket_time_limit: string; // 最晚购买门票时间
  readonly ticket_item_id: number; // 门票物品ID
  readonly ticket_price: string; // 门票购买价格
  readonly desktop_id: number; // 匹配桌ID
  readonly max_win_count: number; // 最大胜场
  readonly max_lose_count: number; // 最大败场
  readonly reward_group: number; // 奖励组ID
  readonly daily_ticket_limit: number; // 每日买入限制
  readonly mail_template: number; // 奖励邮件ID
  readonly arena_reward_display_group: number;
  readonly level_limit: number;
}
//////////////////// activity.arena_reward ////////////////////
export interface Sheet_Activity_ArenaReward {
  readonly group_id: number;
  readonly win_count: number; // 胜场数量
  readonly reward: string; // 奖励
}
//////////////////// activity.arena_reward_display ////////////////////
export interface Sheet_Activity_ArenaRewardDisplay {
  readonly group_id: number;
  readonly win_count_min: number;
  readonly win_count_max: number;
  readonly reward_1: number; // 奖励
  readonly reward_1_remark: string; // 备注数量
  readonly reward_2: number; // 奖励
  readonly reward_2_remark: string; // 备注数量
  readonly reward_3: number; // 奖励
  readonly reward_3_remark: string; // 备注数量
  readonly reward_4: number; // 奖励
  readonly reward_4_remark: string; // 备注数量
}
//////////////////// activity.segment_task ////////////////////
export interface Sheet_Activity_SegmentTask {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动id
  readonly base_task_id: number; // 基础任务id
  readonly max_finish_count: number; // 最多完成次数
  readonly reward: string; // 每次完成给的奖励
  readonly interval: number; // 刷新周期
}
//////////////////// activity.feed_activity_info ////////////////////
export interface Sheet_Activity_FeedActivityInfo {
  readonly activity_id: number; // 活动id
  readonly max_feed_count: number; // 最多喂次数
  readonly feed_reward_id: number; // 奖励组id
  readonly friend_send_limit: number; // 赠送给好友次数限制
  readonly friend_recv_limit: number; // 从好友收取次数限制
  readonly food_item_id: number[]; // 食物物品ID
}
//////////////////// activity.feed_activity_reward ////////////////////
export interface Sheet_Activity_FeedActivityReward {
  readonly id: number; // 奖励id
  readonly count: number; // 次数
  readonly reward: string; // 奖励物品
  readonly img_stage: number; // 图片切换
}
//////////////////// activity.vote_activity ////////////////////
export interface Sheet_Activity_VoteActivity {
  readonly id: number; // 活动id
  readonly vote_item: number; // 投票道具ID
  readonly choice_id_list: string; // 投票ID列表用,分割，用来填写shop内的id
  readonly vote_end_time: string; // 投票结束时间，之后不接受新投票
}
//////////////////// activity.rpg_v2_activity ////////////////////
export interface Sheet_Activity_RpgV2Activity {
  readonly activity_id: number;
  readonly base_atk: number; // 玩家基础攻击
  readonly monster_group: number; // 怪物组
  readonly sanma_debuff: number; // 三麻敌我攻击力削弱
  readonly special_debuff: number; // 特殊模式（非常规立直模式）
  readonly has_robot: number; // 是否可以带AI
  readonly category: string; // 对局类别
  readonly mode: string; // 匹配模式
  readonly room: string; // 对局模式
  readonly daily_limit: number; // 每日击破上限
  readonly mail_template_id: number;
}
//////////////////// activity.spot_activity ////////////////////
export interface Sheet_Activity_SpotActivity {
  readonly unique_id: number; // 剧情id
  readonly activity_id: number; // 活动id
  readonly dep: number; // 前置依赖剧情解锁
  readonly limit_day: number; // 解锁天数
  readonly unlock_task_id: number; // 解锁基础任务id
  readonly unlock_task_activity_id: number; // 解锁任务对应活动id
  readonly spot_group: number; // 剧情锁同一组别
  readonly unlock_spot_item: string; // 解锁编辑器入口的道具
  readonly content_path: string; // 交互剧情的路径
  readonly title: number; // 标题
  readonly subtitle_title: number; // 副标题
  readonly unlock_item: string; // 解锁结局道具
  readonly unlock_by_ending_id: number; // 被某个结局id解锁
  readonly unlock_ending_id: string[]; // 完成ending_id后解锁unique_id
  readonly ending_id: number[]; // 关键选项分支，每段剧情第一个
  readonly ending_res: string; // 封面图
  readonly ending_id_dep: number[]; // 关键选项分支可用道具解锁依赖
  readonly reward: string; // 结局奖励
}
//////////////////// activity.activity_item ////////////////////
export interface Sheet_Activity_ActivityItem {
  readonly activity_id: number; // 活动id
  readonly item_list: string; // 发放道具到背包
}
//////////////////// activity.upgrade_activity ////////////////////
export interface Sheet_Activity_UpgradeActivity {
  readonly activity_id: number; // 活动id
  readonly mail_id: number; // 奖励邮件
  readonly consume_item: string; // 升级消耗的物品，id-count,id-count形式
  readonly total_reward_id: number; // 总等级奖励组id
  readonly reward_id: number[]; // 奖励组id
}
//////////////////// activity.upgrade_activity_reward ////////////////////
export interface Sheet_Activity_UpgradeActivityReward {
  readonly id: number; // 奖励组id，group形式
  readonly level: number; // 等级
  readonly reward: string; // 升级到level等级的奖励
  readonly unlock_day: number; // 解锁天数
  readonly highlight: number;
}
//////////////////// activity.friend_gift_activity ////////////////////
export interface Sheet_Activity_FriendGiftActivity {
  readonly activity_id: number; // 活动id
  readonly friend_send_limit: number; // 赠送给好友次数限制
  readonly friend_send_consume: number; // 赠送好友自己消耗的个数
  readonly friend_recv_limit: number; // 从好友收取次数限制
  readonly extra_gift: number; // 赠送人可以额外获得的数量
  readonly gift_item_id: number[]; // 礼品id
}
//////////////////// activity.upgrade_activity_display ////////////////////
export interface Sheet_Activity_UpgradeActivityDisplay {
  readonly id: number; // 奖励组id，group形式
  readonly level: number; // 等级
  readonly display: number;
}
//////////////////// activity.activity_desktop ////////////////////
export interface Sheet_Activity_ActivityDesktop {
  readonly activity_id: number;
  readonly desktop_id: number;
  readonly interval: number;
  readonly interval_type: number;
}
//////////////////// activity.gacha_activity_info ////////////////////
export interface Sheet_Activity_GachaActivityInfo {
  readonly activity_id: number; // 活动id
  readonly gacha_pool: number; // 奖池
  readonly gacha_control: number; // 控制池
  readonly sp_trigger_times: number; // 触发sp奖的抽取次数-抽够次数就送
  readonly sp_rewards: string; // SP赏
  readonly consume: string; // 抽取消耗物品
}
//////////////////// activity.gacha_pool ////////////////////
export interface Sheet_Activity_GachaPool {
  readonly pool_id: number; // 奖品池id
  readonly reward_id: number; // 奖品id
  readonly count: number; // 这种奖品在扭蛋机中一共有几份
  readonly rare: number; // 稀有度
  readonly item: string; // 奖品
}
//////////////////// activity.gacha_control ////////////////////
export interface Sheet_Activity_GachaControl {

}
//////////////////// activity.task_display ////////////////////
export interface Sheet_Activity_TaskDisplay {
  readonly activity_id: number;
  readonly day: number; // 自然日
  readonly task_serial_number: number; // 0为特殊整体，123为顺序
  readonly task_type: number; // 0普通任务，1问答，999整体条件
  readonly period_task_id: number; // 任务编号
  readonly answer: number; // 正确答案（当成str拆）
  readonly right_str: number; // 答对的文本
  readonly wrong_str: number; // 答错的文本
}
//////////////////// activity.simulation_activity_info ////////////////////
export interface Sheet_Activity_SimulationActivityInfo {
  readonly activity_id: number; // 活动ID
  readonly stamina_item_id: number; // 体力值物品ID
}
//////////////////// activity.reward_mail ////////////////////
export interface Sheet_Activity_RewardMail {
  readonly activity_id: number; // 活动ID
  readonly mail_template_id: number; // 对应邮件
}
//////////////////// activity.combining_activity_info ////////////////////
export interface Sheet_Activity_CombiningActivityInfo {
  readonly activity_id: number; // 活动id
  readonly craft_bin: number[]; // 材料桶1id
  readonly craft_bin_price: string[]; // 材料桶1费用
  readonly craft_bin_unlock: number[]; // 材料桶1解锁积分
  readonly point_item: number; // 积分道具id
  readonly bonus_daily_limit: number; // 每日最大红包生成数
  readonly multi_order_rate: number; // 双订单价格倍率
  readonly one_coin_num: number; // 飞包动画单硬币对应代币数
  readonly coin_num_max: number; // 飞包硬币最大数量
}
//////////////////// activity.combining_craft_pool ////////////////////
export interface Sheet_Activity_CombiningCraftPool {
  readonly bin_id: number; // 材料桶id
  readonly craft_id: number; // 素材id
}
//////////////////// activity.combining_map ////////////////////
export interface Sheet_Activity_CombiningMap {
  readonly activity_id: number; // 活动id
  readonly point_item_id: number; // 分数道具id
  readonly point_item_count: number; // 道具数量
  readonly workbench_count: number; // 合成格数量
}
//////////////////// activity.combining_order ////////////////////
export interface Sheet_Activity_CombiningOrder {

}
//////////////////// activity.combining_craft ////////////////////
export interface Sheet_Activity_CombiningCraft {
  readonly id: number; // 素材id
  readonly activity_id: number; // 活动id
  readonly group: number; // 素材分组，用于伪随机
  readonly recycling_price: string; // 回收价格
  readonly level: number; // 等级
  readonly upgrade_craft_id: number; // 升级后素材id
  readonly order_price: string; // 订单价格
  readonly if_bonus: number; // 是否为红包
  readonly img_name: string; // 材料资源名
  readonly craft_name: number; // 材料名
  readonly craft_desc: number; // 材料描述
}
//////////////////// activity.combining_customer ////////////////////
export interface Sheet_Activity_CombiningCustomer {
  readonly customer_id: number; // 客人id
  readonly activity_id: number; // 活动id
  readonly order_type: number; // 订单类型
  readonly customer_location: number; // 出现位置左中右
  readonly customer_skin: string; // 客人素材
  readonly customer_loading: number; // 是否使用loading图
  readonly complete_sound: string; // 完成语音
}
//////////////////// activity.chest_replace_up ////////////////////
export interface Sheet_Activity_ChestReplaceUp {
  readonly chest_id: number; // 宝箱ID（索引）
}
//////////////////// activity.village_activity_info ////////////////////
export interface Sheet_Activity_VillageActivityInfo {
  readonly activity_id: number; // 活动id
  readonly worker_item_id: number; // 工人物品ID
  readonly round_consume: string; // 每回合消耗道具
  readonly random_building: string; // 每个玩家只能拥有列表中的一个建筑，具体是哪个由玩家的账号id决定
  readonly food_item_id: number; // 食物道具id
  readonly trip_consume: number; // 远征消耗食物数量
  readonly trip_cold_down: number; // 远征一次消耗时间/秒
  readonly trip_round: number; // 远征一次消耗回合数
  readonly trip_reward: string[]; // 随机建筑远征系数1
  readonly stage_require: string[]; // 白龙阶段需求[0]
}
//////////////////// activity.village_building ////////////////////
export interface Sheet_Activity_VillageBuilding {
  readonly activity_id: number; // 活动id
  readonly building_id: number; // 建筑ID
  readonly initial: number; // 是否是初始建筑
  readonly building_name: number; // 建筑名称strid
  readonly level: number; // 等级
  readonly next_level_id: number; // 下等级id
  readonly produce_item: string; // 每个工人每小时生产内容
  readonly base_produce: string; // 基础产出
  readonly upgrade_item: string; // 升到下级需求材料
  readonly max_worker_count: number;
  readonly upgrade_reward: string; // 升到下级奖励（繁荣度）
  readonly building_stage: number; // 建筑阶段图
  readonly worker_consume: number; // 每个工人每小时消耗食物数量
  readonly func: string; // 特殊功能
  readonly args: number[]; // 特殊参数
  readonly type: number; // 建筑类别
}
//////////////////// activity.village_task ////////////////////
export interface Sheet_Activity_VillageTask {
  readonly activity_id: number; // 活动id
  readonly mission_id: number; // 委托id
  readonly mission_str: number; // 委托文本strid
  readonly fruit_type: string; // 果园类型
  readonly consume: string; // 委托消耗
  readonly reward: string; // 委托奖励
  readonly unlock_day: number; // 活动开始后N天解锁
  readonly unlock_point: string; // 繁荣度达到对应值解锁
  readonly if_loop: number; // 是否可以循环完成
}
//////////////////// activity.liver_event_info ////////////////////
export interface Sheet_Activity_LiverEventInfo {
  readonly activity_id: number; // 活动id
  readonly follower_amount: number; // 初始关注人数
  readonly daily_follower_plus: number; // 每日关注人数增加
  readonly intro_text: number; // 直播间简介文本，str/event表初始值，每日递增+1，共14天，封顶2243
  readonly text_max_amount: number; // 最多保留文本条数
  readonly text_create_timer: string; // 两个随机值毫秒生成一条文本
  readonly text_create_weight: string; // 生成文本的种类，1=雀魂角色纯文本，2=雀魂角色打赏文本，3=路人角色纯文本，4=路人角色打赏无文本
  readonly rolltext_speed: number; // 每条弹幕在左侧滚动时间ms
  readonly gift_weight: string; // 出现打赏时，四种类权重
  readonly rolltext_gift_time: string; // 左下角四种礼物的展示时间
  readonly key_item_id: number; // 人气值道具的id
  readonly face_time_block: string; // 表情的时间区块范围ms
  readonly face_weight: string; // 每个时间区块，随机0普通，1开心，2生气，3疑惑的权重
}
//////////////////// activity.liver_text_info ////////////////////
export interface Sheet_Activity_LiverTextInfo {
  readonly activity_id: number; // 活动id
  readonly type: number; // 角色类型1=雀魂角色，2=路人id
  readonly chara_id: number; // 雀魂角色的六位id
  readonly mob_str_id: number; // 路人角色的str/event的id
  readonly normal_text: string; // 普通聊天随机范围，连续数字
  readonly gift_text: string; // 打赏文本随机范围，连续数字，为空为只打赏不说话
}
//////////////////// activity.festival_activity ////////////////////
export interface Sheet_Activity_FestivalActivity {
  readonly activity_id: number; // 活动id
  readonly funds_id: number; // 资金道具id
  readonly proposal_id: number; // 提案道具id
  readonly proposal_consume: number; // 购买提案消耗资金数量
  readonly daily_buy_limit: number; // 提案每日购买上限
  readonly arrow_amount: number; // 指标单箭头代表的值
  readonly max_amount: number; // 指标上限
  readonly max_proposal_pos: number; // 主界面普通提案点位数
}
//////////////////// activity.festival_level ////////////////////
export interface Sheet_Activity_FestivalLevel {
  readonly activity_id: number; // 活动id
  readonly level: number; // 等级
  readonly level_name: number; // 等级名strid
  readonly level_require: string; // 升到本级所需道具
  readonly level_res: string; // 等级图
  readonly unlock_event_count: number; // 本级解锁的事件数量
}
//////////////////// activity.festival_proposal ////////////////////
export interface Sheet_Activity_FestivalProposal {
  readonly activity_id: number; // 活动id
  readonly proposal_id: number; // 提案id
  readonly unlock_level: number; // 解锁等级
  readonly ending_group: number[]; // 选项A结果festival_ending.group_id
  readonly client_name: number; // 委托人名称strid
  readonly client_icon: string; // 委托人头像
  readonly proposal_text: number; // 委托正文strid
  readonly option_text_a: number; // 选项A文本strid
  readonly option_text_b: number; // 选项B文本strid
}
//////////////////// activity.festival_event ////////////////////
export interface Sheet_Activity_FestivalEvent {
  readonly activity_id: number; // 活动id
  readonly event_id: number; // 事件id
  readonly position: number; // 场地点位
  readonly unlock_level: number; // 解锁等级
  readonly ending_group: number[]; // 选项A结果
  readonly event_title: number; // 事件标题strid
  readonly client_name: number; // 委托人名称strid
  readonly client_icon: string; // 委托人头像
  readonly event_text: number; // 委托正文strid
  readonly option_text_a: number; // 选项A文本strid
  readonly option_text_b: number; // 选项B文本strid
}
//////////////////// activity.festival_ending ////////////////////
export interface Sheet_Activity_FestivalEnding {
  readonly group_id: number;
  readonly ending_id: number; // 结局ID
  readonly ending_type: number; // 结局类型
  readonly weight: number; // 权重
  readonly item_plus: string; // 增加道具
  readonly item_minus: string; // 减少道具
  readonly funds: number; // 庆典资金变动
  readonly ending_text: number; // 结局文本strid
}
//////////////////// activity.island_activity ////////////////////
export interface Sheet_Activity_IslandActivity {
  readonly activity_id: number; // 活动id
  readonly food_id: number; // 食物id
  readonly currency_id: number; // 货币id
  readonly food_consume: number; // 移动每格消耗食物数量
  readonly sell_discount: number; // 收购折价百分比
  readonly guide_bottle_price: number; // 引导中瓶子的市场价
}
//////////////////// activity.island_goods ////////////////////
export interface Sheet_Activity_IslandGoods {
  readonly activity_id: number; // 活动id
  readonly goods_id: number; // 商品id
  readonly goods_name: number; // 商品名
  readonly matrix: string; // 矩阵（亮的部分为物品形状）
  readonly price: number; // 基础价格
  readonly goods_res: string; // 商品图
  readonly icon: string; // 图标
}
//////////////////// activity.island_bag ////////////////////
export interface Sheet_Activity_IslandBag {
  readonly activity_id: number; // 活动id
  readonly bag_id: number; // 背包id
  readonly bag_name: number; // 背包名
  readonly bag_desc: number; // 背包描述
  readonly bag_icon_locked: string; // 背包未解锁时图标
  readonly bag_icon_unlocked: string; // 背包已解锁时图标
  readonly matrix: string; // 背包矩阵（亮的为不可放置物品格）
  readonly max_matrix: string; // 最大解锁背包矩阵
  readonly unlock_consume: string; // 解锁背包一格消耗
  readonly initial: number; // 初始化时就解锁
  readonly unlock_task_id: number; // 解锁任务id
}
//////////////////// activity.island_map ////////////////////
export interface Sheet_Activity_IslandMap {
  readonly activity_id: number; // 活动id
  readonly zone_id: number; // 地区id,从0开始
  readonly zone_name: number; // 地区名称
  readonly zone_icon_unlocked: string; // 地区已解锁时图标
  readonly currency_amount: number; // 每日商人货币数量
  readonly initial: number; // 初始化时是否解锁
  readonly distance: number[]; // 到0地区的距离
  readonly route: string[]; // 到0地区的路线
  readonly unlock_task_id: number; // 解锁任务id
}
//////////////////// activity.island_shop ////////////////////
export interface Sheet_Activity_IslandShop {
  readonly activity_id: number; // 活动id
  readonly day: number; // 活动第几日
  readonly zone_id: number; // 所在地区
  readonly goods_id: number; // 商品id
  readonly count: number; // 商品数量
  readonly discount: number; // 折扣百分数
}
//////////////////// activity.island_news ////////////////////
export interface Sheet_Activity_IslandNews {
  readonly activity_id: number; // 活动id
  readonly day: number; // 第几日
  readonly show_day: number; // 第几日显示
  readonly news_date: number; // 新闻日期
  readonly news_week: number; // 新闻星期几
  readonly zone: number; // 受影响地区id
  readonly news_desc: number; // 新闻描述
  readonly goods_id: number; // 受影响商品id
  readonly effect: number; // 影响百分数
}
//////////////////// activity.summer_story ////////////////////
export interface Sheet_Activity_SummerStory {
  readonly activity_id: number; // 活动id
  readonly id: number; // 页签ID
  readonly story_name: number; // 页签名
  readonly building: number; // 建筑编号
  readonly building_name: number; // 建筑名称
  readonly exchange_activity: number; // 兑换建筑活动id
  readonly building_unlock: number; // 建筑解锁道具id
  readonly story_unlock: string; // 剧情解锁道具
  readonly story_id: string; // 剧情id
  readonly story_desc: number; // 故事梗概
  readonly show_character: string; // 角色显示，skin_id
}
//////////////////// activity.story_activity ////////////////////
export interface Sheet_Activity_StoryActivity {
  readonly activity_id: number; // 活动id
  readonly story_id: number; // 故事id
  readonly unlock_day: number; // 解锁天数
  readonly unlock_item: string; // 解锁物品
  readonly unlock_story: string; // 前置故事
  readonly unlock_ending: string; // 解锁条件（结局）
  readonly unlock_consume: string; // 解锁需要消耗的道具
  readonly finish_reward: string; // 通关奖励
  readonly all_finish_reward: string; // 全通奖励
  readonly content_path: string; // 交互剧情的路径
  readonly title: number; // 标题
  readonly subtitle_title: number; // 副标题
}
//////////////////// activity.story_ending ////////////////////
export interface Sheet_Activity_StoryEnding {
  readonly story_id: number; // 故事id
  readonly ending_id: number; // 结局id
  readonly unlock_day: number; // 解锁天数
  readonly unlock_item: string; // 解锁物品
  readonly unlock_story: string; // 解锁条件（故事）
  readonly unlock_ending: string; // 解锁条件（结局）
  readonly unlock_consume: string; // 解锁需要消耗的道具
  readonly reward: string; // 完成该结局后的奖励
}
//////////////////// activity.activity_banner ////////////////////
export interface Sheet_Activity_ActivityBanner {
  readonly id: number; // id
  readonly sort: number; // 排序,大的在上面
  readonly banner_type: number; // 类型
  readonly enter_icon: string; // 大厅入口
  readonly banner_big: string; // 大banner
  readonly banner_left: string; // 左banner底图
  readonly banner_left_selected: string; // 左banner选中
  readonly banner_left_icon: string; // 左banner加图标
  readonly time_remind: number; // 小于等于该天数时显示倒计时提示
}
//////////////////// activity.activity_guide ////////////////////
export interface Sheet_Activity_ActivityGuide {
  readonly guide_id: number; // 引导id
  readonly activity_id: number; // 活动id
  readonly guide_location: number; // 文本框位置，0下1上
  readonly char_id: number; // 昵称，自定id和玩家id填0
  readonly char_str_id: number; // 指定str-event，玩家id填0
  readonly content_str_id: number; // 文本框内容
}
//////////////////// activity.summer_story_reward ////////////////////
export interface Sheet_Activity_SummerStoryReward {
  readonly activity_id: number; // 活动id
  readonly period_task_id: number; // 奖励任务ID
  readonly building_icon: string; // 左上角建筑图显示
  readonly click_notice: number; // 已解锁，未完成点击提示文本
}
//////////////////// activity.choose_up_activity ////////////////////
export interface Sheet_Activity_ChooseUpActivity {
  readonly activity_id: number; // 活动id
  readonly replace_id: number; // choose_up_replace.id
  readonly base_chest_id: number[]; // 可选卡池,国女
  readonly ban_list: number[]; // 不可选雀士1
  readonly choose_type: string[]; // 可选类型
  readonly sort: number; // 卡池排序大的靠上
  readonly title_str_id: number; // 卡池短名
  readonly str_id: string; // 卡池说明文，高亮用[tag]区分[/tag]
  readonly chara_str_id: number; // 角色出率文本
  readonly item_str_id: number; // 装扮出率文本
  readonly img: string; // 宣传图
  readonly title_img: string; // 卡池标题图
  readonly title_img_2: string; // 卡池标题图2（左下的）
  readonly typeset: number; // 排版种类
  readonly enter_animation: string; // 进入动画
  readonly special_effect_front: string; // 特效前
  readonly special_effect_back: string; // 特效后，常驻，特效替换樱花特效
  readonly special_audio: number; // audio表内音效
  readonly up_items_type: number; // 0=无up装扮，1=新装扮，2=特定老装扮，3=常驻装扮
  readonly up_items: number[]; // UP的物品
}
//////////////////// activity.choose_up_replace ////////////////////
export interface Sheet_Activity_ChooseUpReplace {
  readonly id: number; // 替换选择组id
  readonly chest_id: number[]; // 卡池id,国
}
//////////////////// activity.progress_reward ////////////////////
export interface Sheet_Activity_ProgressReward {
  readonly activity_id: number; // 活动id
  readonly progress: number; // 进度（百分数*100）
  readonly reward: string; // 奖励
}
//////////////////// activity.bingo_info ////////////////////
export interface Sheet_Activity_BingoInfo {
  readonly activity_id: number;
  readonly card_id: number;
  readonly unlock_day: number;
}
//////////////////// activity.bingo_card ////////////////////
export interface Sheet_Activity_BingoCard {
  readonly card_id: number; // 冰果卡id
  readonly type: string; // 冰菓格类型
  readonly base_task_id: number; // 任务id
  readonly pos: number; // 从左到右，从上到下1-9
}
//////////////////// activity.bingo_reward ////////////////////
export interface Sheet_Activity_BingoReward {
  readonly card_id: number;
  readonly reward_id: number;
  readonly reward: string; // 奖励str
  readonly required_pos: number[]; // 需要完成的三个position
  readonly reward_type: number; // 奖励图标种类
  readonly node_mark: number; // 0普通1突出
}
//////////////////// activity.choose_group_up_activity ////////////////////
export interface Sheet_Activity_ChooseGroupUpActivity {
  readonly activity_id: number; // 活动id
  readonly group_id: number; // choose_group.group_id
  readonly base_chest_id: number[]; // 可选卡池，国
  readonly choose_type: string[]; // 可选类型
  readonly type: number; // 樱花1竹林2
  readonly sort: number; // 卡池排序大的靠上
  readonly title_str_id: number; // 卡池短名
  readonly str_id: string; // 卡池说明文，高亮用[tag]区分[/tag]
  readonly chara_str_id: number; // 角色出率文本
  readonly item_str_id: number; // 装扮出率文本
  readonly img: string; // 宣传图
  readonly title_img: string; // 卡池标题图
  readonly title_img_2: string; // 卡池标题图2（左下的）
  readonly typeset: number; // 排版种类
  readonly enter_animation: string; // 进入动画
  readonly special_effect_front: string; // 特效前
  readonly special_effect_back: string; // 特效后，常驻，特效替换樱花特效
  readonly special_audio: number; // audio表内音效
  readonly up_items_type: number; // 0=无up装扮，1=新装扮，2=特定老装扮，3=常驻装扮
  readonly up_items: number[]; // UP的物品
}
//////////////////// activity.choose_group ////////////////////
export interface Sheet_Activity_ChooseGroup {
  readonly group_id: number; // 组id
  readonly selection_id: number; // 选项id
  readonly item_id: number; // 道具id
  readonly item_position: number; // 卡池站位
  readonly chest_id: number[]; // 卡池id,国
}
//////////////////// activity.task_tab ////////////////////
export interface Sheet_Activity_TaskTab {
  readonly id: number; // 活动任务id
  readonly activity_id: number; // 活动id
  readonly tab_id: number; // 页签编号（小的在前）
}
//////////////////// activity ////////////////////
export interface Table_Activity {
  readonly activity: UniqueSheet<Sheet_Activity_Activity>;
  readonly task: UniqueSheet<Sheet_Activity_Task>;
  readonly exchange: UniqueSheet<Sheet_Activity_Exchange>;
  readonly chest_up: GroupSheet<Sheet_Activity_ChestUp>;
  readonly game_task: UniqueSheet<Sheet_Activity_GameTask>;
  readonly game_point: UniqueSheet<Sheet_Activity_GamePoint>;
  readonly rank: GroupSheet<Sheet_Activity_Rank>;
  readonly rank_reward: GroupSheet<Sheet_Activity_RankReward>;
  readonly flip_task: UniqueSheet<Sheet_Activity_FlipTask>;
  readonly flip_info: UniqueSheet<Sheet_Activity_FlipInfo>;
  readonly daily_sign: GroupSheet<Sheet_Activity_DailySign>;
  readonly richman_info: UniqueSheet<Sheet_Activity_RichmanInfo>;
  readonly richman_map: GroupSheet<Sheet_Activity_RichmanMap>;
  readonly richman_level: GroupSheet<Sheet_Activity_RichmanLevel>;
  readonly richman_event: UniqueSheet<Sheet_Activity_RichmanEvent>;
  readonly period_task: UniqueSheet<Sheet_Activity_PeriodTask>;
  readonly random_task_pool: GroupSheet<Sheet_Activity_RandomTaskPool>;
  readonly random_task_info: UniqueSheet<Sheet_Activity_RandomTaskInfo>;
  readonly richman_reward_seq: GroupSheet<Sheet_Activity_RichmanRewardSeq>;
  readonly activity_buff: GroupSheet<Sheet_Activity_ActivityBuff>;
  readonly buff_condition: GroupSheet<Sheet_Activity_BuffCondition>;
  readonly game_point_info: UniqueSheet<Sheet_Activity_GamePointInfo>;
  readonly game_point_rank: GroupSheet<Sheet_Activity_GamePointRank>;
  readonly game_point_filter: GroupSheet<Sheet_Activity_GamePointFilter>;
  readonly activity_room: UniqueSheet<Sheet_Activity_ActivityRoom>;
  readonly sns_activity: UniqueSheet<Sheet_Activity_SnsActivity>;
  readonly mine_activity: UniqueSheet<Sheet_Activity_MineActivity>;
  readonly mine_reward: GroupSheet<Sheet_Activity_MineReward>;
  readonly rpg_activity: UniqueSheet<Sheet_Activity_RpgActivity>;
  readonly rpg_monster_group: GroupSheet<Sheet_Activity_RpgMonsterGroup>;
  readonly arena_activity: UniqueSheet<Sheet_Activity_ArenaActivity>;
  readonly arena_reward: GroupSheet<Sheet_Activity_ArenaReward>;
  readonly arena_reward_display: GroupSheet<Sheet_Activity_ArenaRewardDisplay>;
  readonly segment_task: UniqueSheet<Sheet_Activity_SegmentTask>;
  readonly feed_activity_info: UniqueSheet<Sheet_Activity_FeedActivityInfo>;
  readonly feed_activity_reward: GroupSheet<Sheet_Activity_FeedActivityReward>;
  readonly vote_activity: UniqueSheet<Sheet_Activity_VoteActivity>;
  readonly rpg_v2_activity: UniqueSheet<Sheet_Activity_RpgV2Activity>;
  readonly spot_activity: UniqueSheet<Sheet_Activity_SpotActivity>;
  readonly activity_item: UniqueSheet<Sheet_Activity_ActivityItem>;
  readonly upgrade_activity: UniqueSheet<Sheet_Activity_UpgradeActivity>;
  readonly upgrade_activity_reward: GroupSheet<Sheet_Activity_UpgradeActivityReward>;
  readonly friend_gift_activity: UniqueSheet<Sheet_Activity_FriendGiftActivity>;
  readonly upgrade_activity_display: GroupSheet<Sheet_Activity_UpgradeActivityDisplay>;
  readonly activity_desktop: GroupSheet<Sheet_Activity_ActivityDesktop>;
  readonly gacha_activity_info: UniqueSheet<Sheet_Activity_GachaActivityInfo>;
  readonly gacha_pool: GroupSheet<Sheet_Activity_GachaPool>;
  readonly gacha_control: GroupSheet<Sheet_Activity_GachaControl>;
  readonly task_display: GroupSheet<Sheet_Activity_TaskDisplay>;
  readonly simulation_activity_info: UniqueSheet<Sheet_Activity_SimulationActivityInfo>;
  readonly reward_mail: UniqueSheet<Sheet_Activity_RewardMail>;
  readonly combining_activity_info: UniqueSheet<Sheet_Activity_CombiningActivityInfo>;
  readonly combining_craft_pool: GroupSheet<Sheet_Activity_CombiningCraftPool>;
  readonly combining_map: GroupSheet<Sheet_Activity_CombiningMap>;
  readonly combining_order: UniqueSheet<Sheet_Activity_CombiningOrder>;
  readonly combining_craft: UniqueSheet<Sheet_Activity_CombiningCraft>;
  readonly combining_customer: UniqueSheet<Sheet_Activity_CombiningCustomer>;
  readonly chest_replace_up: GroupSheet<Sheet_Activity_ChestReplaceUp>;
  readonly village_activity_info: UniqueSheet<Sheet_Activity_VillageActivityInfo>;
  readonly village_building: GroupSheet<Sheet_Activity_VillageBuilding>;
  readonly village_task: GroupSheet<Sheet_Activity_VillageTask>;
  readonly liver_event_info: UniqueSheet<Sheet_Activity_LiverEventInfo>;
  readonly liver_text_info: GroupSheet<Sheet_Activity_LiverTextInfo>;
  readonly festival_activity: UniqueSheet<Sheet_Activity_FestivalActivity>;
  readonly festival_level: GroupSheet<Sheet_Activity_FestivalLevel>;
  readonly festival_proposal: GroupSheet<Sheet_Activity_FestivalProposal>;
  readonly festival_event: GroupSheet<Sheet_Activity_FestivalEvent>;
  readonly festival_ending: GroupSheet<Sheet_Activity_FestivalEnding>;
  readonly island_activity: UniqueSheet<Sheet_Activity_IslandActivity>;
  readonly island_goods: GroupSheet<Sheet_Activity_IslandGoods>;
  readonly island_bag: GroupSheet<Sheet_Activity_IslandBag>;
  readonly island_map: GroupSheet<Sheet_Activity_IslandMap>;
  readonly island_shop: GroupSheet<Sheet_Activity_IslandShop>;
  readonly island_news: GroupSheet<Sheet_Activity_IslandNews>;
  readonly summer_story: GroupSheet<Sheet_Activity_SummerStory>;
  readonly story_activity: GroupSheet<Sheet_Activity_StoryActivity>;
  readonly story_ending: GroupSheet<Sheet_Activity_StoryEnding>;
  readonly activity_banner: UniqueSheet<Sheet_Activity_ActivityBanner>;
  readonly activity_guide: UniqueSheet<Sheet_Activity_ActivityGuide>;
  readonly summer_story_reward: GroupSheet<Sheet_Activity_SummerStoryReward>;
  readonly choose_up_activity: UniqueSheet<Sheet_Activity_ChooseUpActivity>;
  readonly choose_up_replace: GroupSheet<Sheet_Activity_ChooseUpReplace>;
  readonly progress_reward: GroupSheet<Sheet_Activity_ProgressReward>;
  readonly bingo_info: GroupSheet<Sheet_Activity_BingoInfo>;
  readonly bingo_card: GroupSheet<Sheet_Activity_BingoCard>;
  readonly bingo_reward: GroupSheet<Sheet_Activity_BingoReward>;
  readonly choose_group_up_activity: UniqueSheet<Sheet_Activity_ChooseGroupUpActivity>;
  readonly choose_group: GroupSheet<Sheet_Activity_ChooseGroup>;
  readonly task_tab: UniqueSheet<Sheet_Activity_TaskTab>;
}
//////////////////// amulet.amulet_activity ////////////////////
export interface Sheet_Amulet_AmuletActivity {
  readonly activity_id: number;
  readonly skill_item: number; // 强化道具编号
  readonly init_coin: number; // 初始星币数
  readonly shop_count: number; // 商店货架卡包数量
  readonly record_level_id: number; // 超过该关卡记录对局记录
  readonly record_level_node: number; // 关卡节点
  readonly book_unlock_level_id: number; // 钦定初始护身符功能解锁关卡
  readonly book_unlock_level_node: number; // 关卡节点
  readonly free_effect_goods_id: number; // 初始免费护身符包id
  readonly shop_refresh_coin: number; // 商店首次刷新的价格
  readonly effect_max_count: number; // 持有护身符最多数量
  readonly init_dora_indicator: number; // 初始宝牌指示牌
  readonly init_change_hand: number; // 初始换牌次数
  readonly init_mount_count: number; // 初始王牌（确定摸不到）
  readonly init_level: number; // 初始关卡id
  readonly advanced_shop_upgrade_count: number; // 额外商店升级数量
}
//////////////////// amulet.amulet_node ////////////////////
export interface Sheet_Amulet_AmuletNode {
  readonly id: number;
  readonly node: number; // 节点id
  readonly type: number; // 地图节点类型
  readonly node_name: string; // 节点名
  readonly node_sub_id: number; // 事件随机池
  readonly hp_rate: string; // 战斗生命倍率
  readonly atk_rate: number; // 战斗攻击倍率
  readonly pack_reward: string; // 过关奖励卡包
  readonly coin_reward: number; // 过关星币数量
  readonly clear_mark: number; // 游戏通关
  readonly guaranteed_goods: number; // 保底卡包,填amulet_goods.id
  readonly level_amulet_pool: number; // 关卡使用的护身符池
}
//////////////////// amulet.amulet_level ////////////////////
export interface Sheet_Amulet_AmuletLevel {
  readonly activity_id: number;
  readonly level: number; // 大关等级
  readonly node_id: number; // 地图节点
  readonly next_level: number; // 下一关level
}
//////////////////// amulet.amulet_map_event ////////////////////
export interface Sheet_Amulet_AmuletMapEvent {
  readonly id: number;
  readonly event_type: number; // 事件类型
  readonly event_desc: number; // str/event事件描述
}
//////////////////// amulet.amulet_character ////////////////////
export interface Sheet_Amulet_AmuletCharacter {
  readonly activity_id: number;
  readonly character_id: number; // 角色编号
  readonly hp: number; // 生命值
  readonly tile_score_map_id: number; // 牌库初始分数id
  readonly reload_count: number; // 重填牌数量
  readonly effect_weight_id: number; // 卡池影响权重
  readonly unlock_item_id: number; // 解锁物品id(0为直接解锁)
  readonly init_desktop_count: number; // 初始待摸牌次数
  readonly init_open_desktop_count: number; // 初始待摸牌中，公开的数量
  readonly init_tian_count: number; // 初始魂牌数量
  readonly character_name: number; // str/event角色名
}
//////////////////// amulet.amulet_tile_score_map ////////////////////
export interface Sheet_Amulet_AmuletTileScoreMap {
  readonly id: number;
  readonly tile: string; // 牌类型
  readonly score: number; // 初始分数
}
//////////////////// amulet.amulet_effect_weight ////////////////////
export interface Sheet_Amulet_AmuletEffectWeight {
  readonly id: number;
  readonly effect_id: number; // 护身符id
}
//////////////////// amulet.amulet_enemy ////////////////////
export interface Sheet_Amulet_AmuletEnemy {
  readonly id: number; // 敌人编号
  readonly boss_id: number; // 敌人类别id
  readonly hp: string; // 生命值
  readonly damage_tile_count: number; // 狂暴牌数量
  readonly atk: number; // 攻击力
  readonly skill_pool: number; // 技能池
  readonly type: number; // boss标记(1为boss，0不是)
  readonly group: number; // 分组，用于关卡内随机
  readonly enemy_name: number; // str/event敌人名
}
//////////////////// amulet.amulet_enemy_skill ////////////////////
export interface Sheet_Amulet_AmuletEnemySkill {
  readonly group_id: number;
  readonly buff_id: number; // 敌人buffid
}
//////////////////// amulet.amulet_effect ////////////////////
export interface Sheet_Amulet_AmuletEffect {
  readonly id: number; // 护身符id
  readonly book_enabled: number; // 是否允许钦定(1可以,0不行)
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly group: string; // 区分权重隐藏标签{,分隔}
  readonly effect_group: number; // 1=秘籍，2=梅兰竹菊, 3=海盗，4=小鬼
  readonly shop_badge: number; // 在商店中是否必定有印章
  readonly duplicate_enabled: number; // 已有升级卡时是否依旧可以在卡包中出现
  readonly upgrade: number; // 升级后的卡
  readonly rarity: number; // 珍贵度，1SSR，2SR，3R，4N
  readonly price: number; // 商店买入价格
  readonly can_sell: number; // 是否允许出售1-可以，0-不行
  readonly sell_price: number; // 商店出售价格
  readonly name: number; // str/event卡名
  readonly desc: number; // str/event效果
  readonly card_image: string; // 卡图
  readonly card_remark: number; // 角标
  readonly init_param_view: number[]; // 前端无成长进度时的初始值
  readonly args: number[];
  readonly tag_id: number[];
}
//////////////////// amulet.amulet_pool ////////////////////
export interface Sheet_Amulet_AmuletPool {
  readonly level_amulet_pool_id: number; // 护身符池id
  readonly amulet_id: number; // 护身符id
}
//////////////////// amulet.amulet_tag ////////////////////
export interface Sheet_Amulet_AmuletTag {
  readonly tag_id: number; // 关键词id
  readonly tag_name: number; // str/event关键词名
  readonly tag_desc: number; // str/event关键词描述
}
//////////////////// amulet.amulet_effect_group ////////////////////
export interface Sheet_Amulet_AmuletEffectGroup {
  readonly id: number; // 护身符组id
  readonly merge_card: number; // 融合后护身符id
}
//////////////////// amulet.amulet_badge ////////////////////
export interface Sheet_Amulet_AmuletBadge {
  readonly id: number; // 印章id
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly coverable: number; // 可以被覆盖或删除
  readonly weight: number; // 商店刷新权重
  readonly rarity: number; // 档位，1铜，2银，3金
  readonly volume: number; // 印章体积，0普通1大
  readonly badge_name: number; // str/event印章名
  readonly badge_desc: number; // str/event效果
  readonly badge_image: string; // 印章图
  readonly args: number[];
}
//////////////////// amulet.amulet_advanced_shop ////////////////////
export interface Sheet_Amulet_AmuletAdvancedShop {
  readonly activity_id: number; // 活动id
  readonly refresh_price_rate: number; // 刷新价格系数（百分比）
  readonly shop_refresh_coin: number; // 初始刷新价格
  readonly effect_goods_pack: number; // 护身符商品=卡包结果
}
//////////////////// amulet.amulet_advanced_shop_upgrade ////////////////////
export interface Sheet_Amulet_AmuletAdvancedShopUpgrade {
  readonly id: number; // 升级 id
  readonly type: number; // 类型
  readonly selection_desc: number[]; // str/event选项描述
  readonly price: number; // 购买价格
  readonly display_value: number; // 显示数值
  readonly args: number[];
}
//////////////////// amulet.amulet_gamble ////////////////////
export interface Sheet_Amulet_AmuletGamble {
  readonly activity_id: number; // 活动id
  readonly id: number; // 转盘id
  readonly level_range: number[]; // 大关下限
  readonly selection_group_id: number; // 选项组id
  readonly destroy_rate: number; // 爆炸初始概率（百分比）
  readonly destroy_inc_rate: number; // 爆炸概率增长系数（百分比）
  readonly price: number; // 初始价格
  readonly price_inc_rate: number; // 价格增长系数（百分比）
}
//////////////////// amulet.amulet_gamble_group ////////////////////
export interface Sheet_Amulet_AmuletGambleGroup {
  readonly id: number;
  readonly selection_id: number; // selection.id
  readonly category: number; // 选项好坏类型
  readonly count: number; // 数量
}
//////////////////// amulet.amulet_gamble_selection ////////////////////
export interface Sheet_Amulet_AmuletGambleSelection {
  readonly id: number;
  readonly selection_id: number; // 选项id，全局唯一
  readonly category: number; // 选项好坏类型
  readonly type: number; // 选项类型
  readonly selection_image: string; // 选项图标
  readonly selection_name: number; // str/event选项标题
  readonly selection_desc: number; // str/event选项描述
  readonly args: number[]; // 参数
}
//////////////////// amulet.amulet_forge ////////////////////
export interface Sheet_Amulet_AmuletForge {
  readonly activity_id: number; // 活动id
  readonly type: number; // 1-护身符 2-印章
  readonly rarity: number; // 稀有度
  readonly price: number; // 价格
}
//////////////////// amulet.amulet_trade_item ////////////////////
export interface Sheet_Amulet_AmuletTradeItem {
  readonly id: number; // id
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly type: number; // 种类
  readonly group: number; // 分组（同组的不会随机到多个）
  readonly value: number; // 价值
  readonly desc: number; // str/event说明文
  readonly image: string; // 选项图
  readonly args: number[];
}
//////////////////// amulet.amulet_trade_reward ////////////////////
export interface Sheet_Amulet_AmuletTradeReward {
  readonly id: number; // id
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly min_value: number; // 价格区间最小值
  readonly max_value: number; // 价格区间最大值（包括）
  readonly desc: number; // str/event说明文
  readonly type: number; // 奖励类型（1=护身符，2=符文石）
  readonly args: number[];
}
//////////////////// amulet.amulet_bonfire_selection ////////////////////
export interface Sheet_Amulet_AmuletBonfireSelection {
  readonly activity_id: number; // 活动id
  readonly selection_id: number; // 篝火选项id
  readonly random: number; // (1固定选项2随机选项)
  readonly type: number; // 选项类型
  readonly selection_name: number; // str/event选项名称
  readonly selection_desc: number; // str/event选项描述
  readonly selection_image: string; // 选项图
  readonly args: number[]; // 参数
}
//////////////////// amulet.amulet_transport ////////////////////
export interface Sheet_Amulet_AmuletTransport {
  readonly activity_id: number; // 活动id
  readonly price: number; // 价格
}
//////////////////// amulet.amulet_shop_upgrade ////////////////////
export interface Sheet_Amulet_AmuletShopUpgrade {
  readonly id: number; // 升级group
  readonly level: number; // 等级
  readonly price: number; // 升级价格
  readonly add_value: number; // 效果量
}
//////////////////// amulet.amulet_upgrade ////////////////////
export interface Sheet_Amulet_AmuletUpgrade {
  readonly id: number; // 升级group
  readonly level: number; // 等级
  readonly skill_point: number; // 所需升级点
  readonly buff_id: number; // 每个等级对应一个buff，args设置效果
  readonly display_value: number; // 前端展示数值
}
//////////////////// amulet.amulet_buff ////////////////////
export interface Sheet_Amulet_AmuletBuff {
  readonly id: number; // buffid
  readonly type: number; // 1-boss，2-商店升级，3-场外升级
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly common_weight: number; // 随机权重
  readonly ex_weight: number; // record_level后的随机权重
  readonly can_stack: number; // buff是否可叠加1-可以，0-不可以
  readonly desc: number; // str/event说明文
  readonly invalid_type: number; // 屏蔽天牌/里宝指示：1万2筒3索0里宝指示牌
  readonly args: number[];
}
//////////////////// amulet.amulet_goods ////////////////////
export interface Sheet_Amulet_AmuletGoods {
  readonly id: number; // goods_id
  readonly guaranteed: number; // 保底卡珍贵度，1SSR，2SR，3R，4N
  readonly pack_name: number; // 卡包名称str/event
  readonly pack_desc: number; // 卡包简介str/event
  readonly price: number; // 价格
}
//////////////////// amulet.amulet_fan ////////////////////
export interface Sheet_Amulet_AmuletFan {
  readonly id: number; // 番种id
  readonly val: number; // 初始番数（都按照门清役计算，可重复时填写1个）
  readonly yiman: number; // 役满役种
  readonly name: number; // str/event的番名，0为普通番
  readonly desc: number; // str/event的番名，0为普通番
  readonly type: number; // 役种类型
  readonly case: string; // 番型例子
}
//////////////////// amulet.amulet_rune_stone ////////////////////
export interface Sheet_Amulet_AmuletRuneStone {
  readonly id: number;
  readonly deprecated: number; // 屏蔽标记，0正常，1屏蔽
  readonly weight: number; // 商店刷新权重
  readonly price: number; // 价格
  readonly unlock_fan: number; // 解锁番种id
  readonly rune_stone_image: string; // 符文石图片
}
//////////////////// amulet.amulet_task ////////////////////
export interface Sheet_Amulet_AmuletTask {
  readonly id: number; // 任务id
  readonly amulet_id: number; // 相关护身符id
  readonly activity_id: number; // 活动id
  readonly base_task_id: number; // 基础任务id
  readonly reward: string; // 奖励
}
//////////////////// amulet.amulet_large_number ////////////////////
export interface Sheet_Amulet_AmuletLargeNumber {
  readonly number_id: string; // 数字id（10的n次方）
  readonly number_unit_cn: string; // str/str万进制单位
  readonly number_unit_en: string; // 千进制单位
}
//////////////////// amulet ////////////////////
export interface Table_Amulet {
  readonly amulet_activity: UniqueSheet<Sheet_Amulet_AmuletActivity>;
  readonly amulet_node: GroupSheet<Sheet_Amulet_AmuletNode>;
  readonly amulet_level: GroupSheet<Sheet_Amulet_AmuletLevel>;
  readonly amulet_map_event: GroupSheet<Sheet_Amulet_AmuletMapEvent>;
  readonly amulet_character: GroupSheet<Sheet_Amulet_AmuletCharacter>;
  readonly amulet_tile_score_map: GroupSheet<Sheet_Amulet_AmuletTileScoreMap>;
  readonly amulet_effect_weight: GroupSheet<Sheet_Amulet_AmuletEffectWeight>;
  readonly amulet_enemy: UniqueSheet<Sheet_Amulet_AmuletEnemy>;
  readonly amulet_enemy_skill: GroupSheet<Sheet_Amulet_AmuletEnemySkill>;
  readonly amulet_effect: UniqueSheet<Sheet_Amulet_AmuletEffect>;
  readonly amulet_pool: GroupSheet<Sheet_Amulet_AmuletPool>;
  readonly amulet_tag: UniqueSheet<Sheet_Amulet_AmuletTag>;
  readonly amulet_effect_group: UniqueSheet<Sheet_Amulet_AmuletEffectGroup>;
  readonly amulet_badge: UniqueSheet<Sheet_Amulet_AmuletBadge>;
  readonly amulet_advanced_shop: UniqueSheet<Sheet_Amulet_AmuletAdvancedShop>;
  readonly amulet_advanced_shop_upgrade: UniqueSheet<Sheet_Amulet_AmuletAdvancedShopUpgrade>;
  readonly amulet_gamble: GroupSheet<Sheet_Amulet_AmuletGamble>;
  readonly amulet_gamble_group: GroupSheet<Sheet_Amulet_AmuletGambleGroup>;
  readonly amulet_gamble_selection: GroupSheet<Sheet_Amulet_AmuletGambleSelection>;
  readonly amulet_forge: GroupSheet<Sheet_Amulet_AmuletForge>;
  readonly amulet_trade_item: UniqueSheet<Sheet_Amulet_AmuletTradeItem>;
  readonly amulet_trade_reward: UniqueSheet<Sheet_Amulet_AmuletTradeReward>;
  readonly amulet_bonfire_selection: GroupSheet<Sheet_Amulet_AmuletBonfireSelection>;
  readonly amulet_transport: UniqueSheet<Sheet_Amulet_AmuletTransport>;
  readonly amulet_shop_upgrade: GroupSheet<Sheet_Amulet_AmuletShopUpgrade>;
  readonly amulet_upgrade: GroupSheet<Sheet_Amulet_AmuletUpgrade>;
  readonly amulet_buff: UniqueSheet<Sheet_Amulet_AmuletBuff>;
  readonly amulet_goods: UniqueSheet<Sheet_Amulet_AmuletGoods>;
  readonly amulet_fan: UniqueSheet<Sheet_Amulet_AmuletFan>;
  readonly amulet_rune_stone: UniqueSheet<Sheet_Amulet_AmuletRuneStone>;
  readonly amulet_task: UniqueSheet<Sheet_Amulet_AmuletTask>;
  readonly amulet_large_number: UniqueSheet<Sheet_Amulet_AmuletLargeNumber>;
}
//////////////////// animation.animation ////////////////////
export interface Sheet_Animation_Animation {
  readonly id: number;
  readonly name: string;
  readonly type: string;
  readonly lifetime: number; // 总时长
  readonly speed: number; // 播放速度
  readonly keypoint: number[]; // 关键帧的时间
}
//////////////////// animation ////////////////////
export interface Table_Animation {
  readonly animation: UniqueSheet<Sheet_Animation_Animation>;
}
//////////////////// audio.audio ////////////////////
export interface Sheet_Audio_Audio {
  readonly id: number;
  readonly path: string; // 路径
  readonly time_length: number; // 声音长度
  readonly type: string; // 类型，lobby或是mj或是effect
}
//////////////////// audio.bgm ////////////////////
export interface Sheet_Audio_Bgm {
  readonly id: number;
  readonly auto_hide: number;
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly path: string; // 路径
  readonly time_length: number; // 声音长度
  readonly type: string; // 类型，lobby或是mj
  readonly unlock_desc_chs: string; // 解锁条件描述
  readonly unlock_desc_chs_t: string;
  readonly unlock_desc_jp: string;
  readonly unlock_desc_en: string;
  readonly unlock_desc_kr: string;
  readonly unlock_item: number;
}
//////////////////// audio ////////////////////
export interface Table_Audio {
  readonly audio: UniqueSheet<Sheet_Audio_Audio>;
  readonly bgm: UniqueSheet<Sheet_Audio_Bgm>;
}
//////////////////// character.emoji ////////////////////
export interface Sheet_Character_Emoji {
  readonly charid: number; // 角色ID
  readonly sub_id: number; // 表情ID
  readonly unlock_desc_chs: string; // 解锁条件描述
  readonly unlock_desc_chs_t: string;
  readonly unlock_desc_jp: string;
  readonly unlock_desc_en: string;
  readonly unlock_desc_kr: string;
  readonly type: number;
  readonly view: string; // 特效表情的资源名字
  readonly audio: number; // audio_id
  readonly after_unlock_desc_chs: string; // 解锁后描述
  readonly after_unlock_desc_chs_t: string;
  readonly after_unlock_desc_jp: string;
  readonly after_unlock_desc_en: string;
  readonly after_unlock_desc_kr: string;
  readonly unlock_type: number; // 解锁类型
  readonly unlock_param: number[]; // 解锁参数
}
//////////////////// character.cutin ////////////////////
export interface Sheet_Character_Cutin {
  readonly skinid: number; // 皮肤ID
  readonly cutin_name: string; // 本体名
  readonly effect: string; // 特效
  readonly atlas: string;
  readonly char_x: number;
  readonly char_y: number;
  readonly char_width: number;
  readonly char_height: number;
  readonly type: number;
}
//////////////////// character.skin ////////////////////
export interface Sheet_Character_Skin {
  readonly skinid: number; // 皮肤ID
  readonly spine_layers: number; // 动皮有几层
  readonly has_effect: number; // 特效动皮
  readonly audio_celebrate: string; // 庆祝音效
  readonly audio_celebrate_idle: string; // 庆祝待机音效
  readonly audio_idle: string;
  readonly audio_greeting: string; // 打招呼音效
  readonly audio_click: string; // 点击音效1
  readonly audio_click2: string; // 点击音效2
  readonly celebrate_delay: number; // 结局界面的胜利动画是否延迟播放
}
//////////////////// character ////////////////////
export interface Table_Character {
  readonly emoji: GroupSheet<Sheet_Character_Emoji>;
  readonly cutin: UniqueSheet<Sheet_Character_Cutin>;
  readonly skin: UniqueSheet<Sheet_Character_Skin>;
}
//////////////////// chest.chest ////////////////////
export interface Sheet_Chest_Chest {
  readonly id: number;
  readonly type: number; // 卡池类型
  readonly name_chs: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly desc_chs: string; // 描述
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly img: string; // 宣传图
  readonly gift: number; // 赠品（许愿石等）
  readonly currency: number; // 货币ID
  readonly price: number; // 单抽价格
  readonly price10: number; // 十连价格
  readonly ticket_id: number; // 可用道具Id
  readonly ticket_10_id: number; // 十连抽道具
  readonly faith_id: number;
  readonly zone: number; // 0国服，1外服
  readonly sort: number; // 数字越大越靠上
}
//////////////////// chest.pool ////////////////////
export interface Sheet_Chest_Pool {

}
//////////////////// chest.pool_seq ////////////////////
export interface Sheet_Chest_PoolSeq {

}
//////////////////// chest.item_pool ////////////////////
export interface Sheet_Chest_ItemPool {

}
//////////////////// chest.chest_shop ////////////////////
export interface Sheet_Chest_ChestShop {
  readonly id: number;
  readonly chest_id: number; // 其实是个faithid
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly item_id: number; // 物品ID
  readonly price: number; // 价格
  readonly need_amount: number; // 指定购买数量
  readonly check_activity: number; // 依赖于某个活动
  readonly launch_time: string; // 起售时间，之后才可兑换
  readonly remove_limit_mark: number; // 标记为1则不显示限定角标
  readonly sort: number; // 排序
}
//////////////////// chest.preview ////////////////////
export interface Sheet_Chest_Preview {
  readonly chest_id: number;
  readonly item_id: number;
  readonly type: string; // 类型
  readonly check_activity: number; // 依赖于某个活动
}
//////////////////// chest.up ////////////////////
export interface Sheet_Chest_Up {

}
//////////////////// chest.item_price ////////////////////
export interface Sheet_Chest_ItemPrice {

}
//////////////////// chest.replace_up ////////////////////
export interface Sheet_Chest_ReplaceUp {
  readonly id: number; // id
  readonly replace_pool_id: number; // replace池ID
  readonly count: number; // 触发保底次数
  readonly activity_id: number; // 活动ID
  readonly count_id: number; // 计数id
  readonly type: number; // 区分1人物/2装扮
}
//////////////////// chest.replace_pool ////////////////////
export interface Sheet_Chest_ReplacePool {
  readonly id: number;
  readonly resource_id: number; // 资源Id
  readonly is_replace: number; // 是否是当期替换up
  readonly add_count: number; // 增加计数量
}
//////////////////// chest ////////////////////
export interface Table_Chest {
  readonly chest: UniqueSheet<Sheet_Chest_Chest>;
  readonly pool: GroupSheet<Sheet_Chest_Pool>;
  readonly pool_seq: GroupSheet<Sheet_Chest_PoolSeq>;
  readonly item_pool: GroupSheet<Sheet_Chest_ItemPool>;
  readonly chest_shop: UniqueSheet<Sheet_Chest_ChestShop>;
  readonly preview: GroupSheet<Sheet_Chest_Preview>;
  readonly up: GroupSheet<Sheet_Chest_Up>;
  readonly item_price: GroupSheet<Sheet_Chest_ItemPrice>;
  readonly replace_up: UniqueSheet<Sheet_Chest_ReplaceUp>;
  readonly replace_pool: GroupSheet<Sheet_Chest_ReplacePool>;
}
//////////////////// compose.characompose ////////////////////
export interface Sheet_Compose_Characompose {
  readonly id: number;
  readonly item_id: number; // 碎片id
  readonly item_num: number; // 碎片数量
  readonly chara_id: number; // 对应角色id
}
//////////////////// compose ////////////////////
export interface Table_Compose {
  readonly characompose: UniqueSheet<Sheet_Compose_Characompose>;
}
//////////////////// contest.contest ////////////////////
export interface Sheet_Contest_Contest {
  readonly id: string;
  readonly int_value: number;
}
//////////////////// contest ////////////////////
export interface Table_Contest {
  readonly contest: UniqueSheet<Sheet_Contest_Contest>;
}
//////////////////// desktop.matchmode ////////////////////
export interface Sheet_Desktop_Matchmode {
  readonly id: number; // 匹配ID
  readonly is_open: number; // 是否开放
  readonly match_group: number; // 匹配组别，相同的可以同时多个匹配
  readonly type: number; // 匹配类型
  readonly activity_id: number; // 活动ID
  readonly open_guyi: number; // 开启古役
  readonly dora3_mode: number; // 开启宝牌宝牌宝牌模式
  readonly begin_open_mode: number; // 开启配牌open模式
  readonly muyu_mode: number; // 开启目玉模式
  readonly xuezhan_mode: number; // 开启血战到底模式
  readonly chuanma_mode: number; // 开启川麻模式
  readonly huanzhang_mode: number; // 开启换三张模式
  readonly jiuchao_mode: number; // 三透牌模式
  readonly reveal_discard: number; // 暗牌模式
  readonly field_spell_mode: number; // 暗牌模式
  readonly zhanxing_mode: number; // 占星模式
  readonly tianming_mode: number; // 天命模式
  readonly yongchang_mode: number; // 咏唱模式
  readonly hunzhiyiji_mode: number; // 魂之一击模式
  readonly wanxiangxiuluo_mode: number; // 万象修罗
  readonly beishuizhizhan_mode: number; // 背水之战
  readonly xiakeshang_mode: number; // 下克上
  readonly qiangduozhizhan_mode: number; // 强夺之战
  readonly room: number; // 匹配房间
  readonly mode: number; // 对局模式
  readonly can_sumup: number; // 是否结算
  readonly room_name_chs: string;
  readonly room_name_chs_t: string;
  readonly room_name_jp: string;
  readonly room_name_en: string;
  readonly room_name_kr: string;
  readonly str_rule: string; // 拼接规则
  readonly interval_image: string; // 规则文本小图
  readonly rule_images: string[]; // 图片
  readonly glimit_floor: number; // 金币下限
  readonly glimit_ceil: number; // 金币上限
  readonly gcarry: number; // 入场金额
  readonly exchange_rate: number; // 兑换比例
  readonly levelpoint1: number; // 1位段位分
  readonly levelpoint2: number; // 2位段位分
  readonly levelpoint3: number; // 3位段位分
  readonly levelpoint4: number; // 4位段位分
  readonly fish_point: number; // 渔点
  readonly init_point: number; // 起始配点
  readonly back_point: number; // 返场点数
  readonly count_point: number; // 精算点数
  readonly buchang: number[]; // 顺位补偿1
  readonly level_limit: number; // 准入段位限制
  readonly level_limit_ceil: number; // 准入段位限制3
  readonly tip: number; // 场代
  readonly friendship: number; // 好感度
  readonly chest_id: number; // 宝箱ID
  readonly chest_exp_add: number[]; // 宝箱经验增加
  readonly level_match: number; // 是否开启等级匹配
  readonly level_match_range: number; // 等级匹配范围
  readonly level_match_max: number; // 等级匹配最高等级
}
//////////////////// desktop.chest ////////////////////
export interface Sheet_Desktop_Chest {
  readonly id: number; // 宝箱ID
  readonly exp_step: number; // 经验条长度
  readonly name_chs: string; // 宝箱名字
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly icon: string; // 宝箱图标
  readonly reward_pool: number; // 奖池id
  readonly select_count: number; // 抽取数量
  readonly repeated: number; // 是否可以重复
}
//////////////////// desktop.settings ////////////////////
export interface Sheet_Desktop_Settings {
  readonly key: string;
  readonly int_value: number;
}
//////////////////// desktop.field_spell ////////////////////
export interface Sheet_Desktop_FieldSpell {
  readonly field: number; // 位置，取值范围[1,3]
  readonly id: number; // id值，取值范围[1,5]
  readonly cardname: string; // 前端用字段
  readonly sord_card_id: number; // 前端排序用卡编号
}
//////////////////// desktop.friend_room ////////////////////
export interface Sheet_Desktop_FriendRoom {
  readonly id: number; // 友人房模式
  readonly pre_rule: string; // 对应activity_room,三人四人无
  readonly sort: number; // 数字小的在前
  readonly str_name: string; // 对局名
  readonly str_rule: string; // 拼接规则
  readonly set_jushu: number; // 创建时允许玩家配置局数
  readonly rule_images: string[]; // 图片
}
//////////////////// desktop.tour_preset_rule ////////////////////
export interface Sheet_Desktop_TourPresetRule {
  readonly id: number;
  readonly preset_rule: number; // 预设规则名的strID
  readonly params: number[]; // 默认初始点数
}
//////////////////// desktop ////////////////////
export interface Table_Desktop {
  readonly matchmode: UniqueSheet<Sheet_Desktop_Matchmode>;
  readonly chest: UniqueSheet<Sheet_Desktop_Chest>;
  readonly settings: UniqueSheet<Sheet_Desktop_Settings>;
  readonly field_spell: UniqueSheet<Sheet_Desktop_FieldSpell>;
  readonly friend_room: UniqueSheet<Sheet_Desktop_FriendRoom>;
  readonly tour_preset_rule: UniqueSheet<Sheet_Desktop_TourPresetRule>;
}
//////////////////// events.soscoin ////////////////////
export interface Sheet_Events_Soscoin {
  readonly id: number;
  readonly level_limit: number; // 段位限制
  readonly level3_limit: number; // 段位限制
  readonly gold_limit: number; // 铜币阈值
  readonly gold_num: number; // 奖励铜币数量
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
}
//////////////////// events.dailyevent ////////////////////
export interface Sheet_Events_Dailyevent {
  readonly id: number;
  readonly reward_type: number; // 奖励类型
  readonly reward_num: number; // 奖励数量
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly active_type: number; // 活动类型
  readonly type: number; // 任务类型
  readonly target: number; // 完成次数
  readonly param: string[];
  readonly level_limit: string; // 段位限制1
}
//////////////////// events.base_task ////////////////////
export interface Sheet_Events_BaseTask {
  readonly id: number;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly type: number; // 任务类型
  readonly target: number; // 完成次数
  readonly param: string[]; // 参数列表
}
//////////////////// events ////////////////////
export interface Table_Events {
  readonly soscoin: UniqueSheet<Sheet_Events_Soscoin>;
  readonly dailyevent: UniqueSheet<Sheet_Events_Dailyevent>;
  readonly base_task: UniqueSheet<Sheet_Events_BaseTask>;
}
//////////////////// exchange.exchange ////////////////////
export interface Sheet_Exchange_Exchange {
  readonly id: number;
  readonly source_currency: number; // 源币种
  readonly source_value: number; // 金额
  readonly target_currency: number; // 目标币种
  readonly target_value: number; // 金额
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
}
//////////////////// exchange.searchexchange ////////////////////
export interface Sheet_Exchange_Searchexchange {
  readonly id: number;
  readonly source_currency: number; // 源币种
  readonly source_value: number; // 金额
  readonly target_currency: number; // 目标币种
  readonly target_value: number; // 金额
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kor: string;
}
//////////////////// exchange.fushiquanexchange ////////////////////
export interface Sheet_Exchange_Fushiquanexchange {
  readonly id: number;
  readonly source_currency: number; // 源币种
  readonly source_value: number; // 金额
  readonly target_currency: number; // 目标币种
  readonly target_value: number; // 金额
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string; // 描述
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
}
//////////////////// exchange ////////////////////
export interface Table_Exchange {
  readonly exchange: UniqueSheet<Sheet_Exchange_Exchange>;
  readonly searchexchange: UniqueSheet<Sheet_Exchange_Searchexchange>;
  readonly fushiquanexchange: UniqueSheet<Sheet_Exchange_Fushiquanexchange>;
}
//////////////////// fan.fan ////////////////////
export interface Sheet_Fan_Fan {
  readonly id: number;
  readonly name_chs: string;
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly xuanshang: number; // 是否悬赏，悬赏不算役
  readonly yiman: number; // 役满
  readonly fan_menqing: number; // 门清时候的番数
  readonly fan_fulu: number; // 副露时候的番数
  readonly show_index: number; // 排序
  readonly sound: string; // 报番语音
  readonly is_guyi: number; // 是否古役
  readonly rarity: number; // 役满特效的珍稀度
  readonly show_range_1: string; // 显示区间三四麻
  readonly show_range_2: string; // 显示区间段位友人活动
  readonly merge_id: number; // 合并至其他役种id
  readonly mark: number; // 特殊标记字色
}
//////////////////// fan ////////////////////
export interface Table_Fan {
  readonly fan: UniqueSheet<Sheet_Fan_Fan>;
}
//////////////////// fandesc.fandesc ////////////////////
export interface Sheet_Fandesc_Fandesc {
  readonly id: number;
  readonly tag: number; // 标签
  readonly name_chs: string; // 番名
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 说明
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly desc2_chs: string; // 状态说明
  readonly desc2_jp: string;
  readonly desc2_en: string;
  readonly desc2_chs_t: string;
  readonly desc2_kr: string;
  readonly case: string; // 例子
  readonly show: number; // 是否显示
  readonly mode: number; // 0通常 1川麻
}
//////////////////// fandesc ////////////////////
export interface Table_Fandesc {
  readonly fandesc: UniqueSheet<Sheet_Fandesc_Fandesc>;
}
//////////////////// game_live.select_filters ////////////////////
export interface Sheet_GameLive_SelectFilters {
  readonly id: number;
  readonly category: number; // 游戏分类
  readonly mode_id: number; // 匹配模式id
  readonly mode: number; // 游戏模式（好友模式）
  readonly tournament_id: number; // 联赛id
  readonly open: number; // 开关
  readonly initial: number; // 初始选项
  readonly name1_chs: string; // 选项名字1
  readonly name1_chs_t: string;
  readonly name1_jp: string;
  readonly name1_en: string;
  readonly name1_kr: string;
  readonly name2_chs: string; // 选项名字2
  readonly name2_chs_t: string;
  readonly name2_jp: string;
  readonly name2_en: string;
  readonly name2_kr: string;
}
//////////////////// game_live ////////////////////
export interface Table_GameLive {
  readonly select_filters: UniqueSheet<Sheet_GameLive_SelectFilters>;
}
//////////////////// global.global ////////////////////
export interface Sheet_Global_Global {
  readonly id: number;
  readonly args: string; // 参数
}
//////////////////// global ////////////////////
export interface Table_Global {
  readonly global: UniqueSheet<Sheet_Global_Global>;
}
//////////////////// info.error ////////////////////
export interface Sheet_Info_Error {
  readonly id: number;
  readonly chs: string;
  readonly chs_t: string;
  readonly jp: string;
  readonly en: string;
  readonly kr: string;
}
//////////////////// info.forbidden ////////////////////
export interface Sheet_Info_Forbidden {
  readonly word: string;
  readonly type_chs: number;
  readonly near_chs: number;
  readonly chs: number;
  readonly type_us: number;
  readonly near_us: number;
  readonly us: number;
  readonly type_jp: number;
  readonly near_jp: number;
  readonly jp: number;
}
//////////////////// info.near ////////////////////
export interface Sheet_Info_Near {
  readonly word1: string; // 形近字1
  readonly word2: string; // 形近字2
  readonly word3: string; // 形近字3
  readonly word4: string; // 形近字4
  readonly word5: string; // 形近字5
}
//////////////////// info.translate ////////////////////
export interface Sheet_Info_Translate {
  readonly original: string;
  readonly chs: string;
  readonly chs_t: string;
  readonly jp: string;
  readonly en: string;
  readonly kr: string;
}
//////////////////// info ////////////////////
export interface Table_Info {
  readonly error: UniqueSheet<Sheet_Info_Error>;
  readonly forbidden: NoKeySheet<Sheet_Info_Forbidden>;
  readonly near: NoKeySheet<Sheet_Info_Near>;
  readonly translate: UniqueSheet<Sheet_Info_Translate>;
}
//////////////////// item_definition.currency ////////////////////
export interface Sheet_ItemDefinition_Currency {
  readonly id: number;
  readonly name_chs: string; // 名称
  readonly name_chs_t: string; // 名称
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string;
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly icon: string; // 图标
  readonly icon_jpg: string; // 图标
}
//////////////////// item_definition.item ////////////////////
export interface Sheet_ItemDefinition_Item {
  readonly id: number;
  readonly sort: number; // 递增 数字大的在后
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_chs_t2: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string; // 名称
  readonly desc_func_chs: string; // 描述
  readonly desc_chs: string; // 描述
  readonly desc_func_chs_t: string;
  readonly desc_chs_t: string;
  readonly desc_chs_t2: string;
  readonly desc_func_jp: string;
  readonly desc_jp: string;
  readonly desc_func_en: string;
  readonly desc_en: string;
  readonly desc_func_kr: string;
  readonly desc_kr: string;
  readonly icon: string; // 图标
  readonly icon_transparent: string; // 半透图标
  readonly category: number; // 类别
  readonly type: number; // 子类型
  readonly is_unique: number; // 是否唯一
  readonly max_stack: number; // 物品持有上限
  readonly access: string; // 获取途径
  readonly accessinfo: number; // 获取文本 STRID
  readonly func: string; // 功能
  readonly iargs: number[]; // 数值参数
  readonly sargs: string[]; // 文本参数
  readonly can_sell: number; // 是否可出售
  readonly sell_reward_id: number; // 出售获得id
  readonly sell_reward_count: number; // 出售获得数量
  readonly item_expire: string; // 过期时间
  readonly expire_desc_chs: string; // 过期时间描述
  readonly expire_desc_chs_t: string; // 过期时间描述
  readonly expire_desc_jp: string; // 过期时间描述
  readonly expire_desc_en: string; // 过期时间描述
  readonly expire_desc_kr: string; // 过期时间描述
  readonly region_limit: number; // 1=KR区域不展示
  readonly cross_view: number; // 跨服可视性，1为可跨服，0为不可跨服
  readonly database_cache: number; // 其他玩家可见性
}
//////////////////// item_definition.title ////////////////////
export interface Sheet_ItemDefinition_Title {
  readonly id: number;
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly icon: string; // 图标
  readonly icon_item: string; // 图标
  readonly priority: number; // 优先级高的限制在前面
  readonly unlock_type: number; // 解锁类型
  readonly unlock_param: number[]; // 解锁参数
  readonly cross_view: number; // 跨服可视性，1为可跨服，0为不可跨服
}
//////////////////// item_definition.character ////////////////////
export interface Sheet_ItemDefinition_Character {
  readonly id: number;
  readonly sort: number; // 递增 数字大的在后
  readonly launch_time: string; // 起售时间，之后才显示在声音和仓库
  readonly name_chs: string; // 名称
  readonly name_chs2: string; // 名称
  readonly name_chs_t: string;
  readonly name_chs_t2: string;
  readonly name_jp: string;
  readonly name_jp2: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly open: number; // 是否开放
  readonly init_skin: number; // 初始皮肤
  readonly full_fetter_skin: number; // 满羁绊皮肤
  readonly hand: number; // 默认手
  readonly favorite: number; // 喜好
  readonly star_5_material: string; // 5星突破材料 1-8
  readonly star_5_cost: number; // 5星突破铜币消耗
  readonly can_marry: number; // 是否可缔结契约
  readonly exchange_item_id: number; // 重复兑换物品ID
  readonly exchange_item_num: number; // 重复兑换物品数量
  readonly emo: string; // 表情
  readonly sound: number; // 语音库
  readonly sound_volume: number; // 声音音效修正
  readonly sound_folder: string;
  readonly sex: number; // 性别,1女，2:男
  readonly desc_stature_chs: string; // 身高
  readonly desc_stature_chs_t: string; // 身高
  readonly desc_stature_jp: string;
  readonly desc_stature_en: string;
  readonly desc_stature_kr: string;
  readonly desc_birth_chs: string; // 生日
  readonly desc_birth_chs_t: string;
  readonly desc_birth_jp: string;
  readonly desc_birth_en: string;
  readonly desc_birth_kr: string;
  readonly desc_age_chs: string; // 年龄
  readonly desc_age_chs_t: string;
  readonly desc_age_jp: string;
  readonly desc_age_en: string;
  readonly desc_age_kr: string;
  readonly desc_bloodtype_chs: string; // 血型
  readonly desc_bloodtype_chs_t: string; // 血型
  readonly desc_bloodtype_jp: string; // 血型
  readonly desc_bloodtype_en: string; // 血型
  readonly desc_bloodtype_kr: string; // 血型
  readonly desc_cv_chs: string; // 声优
  readonly desc_cv_chs_t: string;
  readonly desc_cv_jp: string;
  readonly desc_cv_en: string;
  readonly desc_cv_kr: string;
  readonly desc_hobby_chs: string; // 爱好
  readonly desc_hobby_chs_t: string;
  readonly desc_hobby_jp: string;
  readonly desc_hobby_en: string;
  readonly desc_hobby_kr: string;
  readonly desc_chs: string; // 档案描述
  readonly desc_item_chs: string;
  readonly desc_chs_t: string;
  readonly desc_item_chs_t: string;
  readonly desc_jp: string;
  readonly desc_item_jp: string;
  readonly desc_en: string;
  readonly desc_item_en: string;
  readonly desc_kr: string;
  readonly desc_item_kr: string;
  readonly collaboration: number; // 联动标记，12的生日=年级，其他的不替换
  readonly region_limit: number; // 1=KR入口屏蔽
  readonly skin_lib: number[]; // 皮肤库
  readonly ur: number; // UR标记
  readonly ur_ron: number; // 默认自带和牌
  readonly ur_liqi: number; // 默认自带立直
  readonly ur_cutin: string;
  readonly limited: number; // 期间限定雀士标签
  readonly treasure_sp: number; // 抽卡界面固定在左侧
}
//////////////////// item_definition.view ////////////////////
export interface Sheet_ItemDefinition_View {
  readonly id: number;
  readonly res_name: string; // 资源名字
  readonly audio_id: number;
  readonly character_id: number; // 专属人物ID
  readonly sargs: string[]; // 额外参数
  readonly old_effect_mark: number; // 旧特效标记
  readonly hand_version: number; // 手模型版本
  readonly seat_related: number; // 不同座位特效不同
}
//////////////////// item_definition.skin ////////////////////
export interface Sheet_ItemDefinition_Skin {
  readonly id: number;
  readonly type: number; // 是不是原皮
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string; // 描述
  readonly desc_jp: string;
  readonly desc_jp2: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly character_id: number; // 角色id索引
  readonly lock_tips_chs: string; // 未解锁的提示
  readonly lock_tips_chs_t: string;
  readonly lock_tips_jp: string;
  readonly lock_tips_en: string;
  readonly lock_tips_kr: string;
  readonly path: string; // 文件夹路径
  readonly exchange_item_id: number; // 重复兑换物品ID
  readonly exchange_item_num: number; // 重复兑换物品数量
  readonly direction: number; // 立绘朝向1左0右
  readonly no_reverse: number; // 和服不可翻转
  readonly lock_reverse: number; // 全局禁止反转，针对特殊角色
  readonly offset_x: number; // 剧情用偏移
  readonly offset_y: number; // 剧情用偏移
  readonly spot_scale: string; // 剧情用偏移
  readonly effective_time: string; // 生效时间，此服务端时间后才开始展示
  readonly lobby_offset: string; // 大厅偏移数据
  readonly liaoshe_offset: string; // 偏移数据
  readonly shop_offset: string; // 偏移数据
  readonly win_offset: string; // 偏移数据
  readonly gameend_offset: string; // 偏移数据
  readonly starup_offset: string; // 偏移数据
  readonly treasure_offset: string; // 偏移数据
  readonly ck_full_0_offset: string; // 偏移数据
  readonly ck_full_1_offset: string; // 偏移数据
  readonly ck_full_2_offset: string; // 偏移数据
  readonly ck_full_3_offset: string; // 偏移数据
  readonly ck_full_single_offset: string; // 偏移数据
  readonly ck_half_0_offset: string; // 偏移数据
  readonly ck_half_1_offset: string; // 偏移数据
  readonly ck_half_2_offset: string; // 偏移数据
  readonly ck_half_3_offset: string; // 偏移数据
  readonly ck_half_single_offset: string; // 偏移数据
  readonly smallhead_x: number;
  readonly smallhead_y: number;
  readonly smallhead_width: number;
  readonly full_x: number;
  readonly full_y: number;
  readonly full_width: number;
  readonly full_height: number;
  readonly half_x: number;
  readonly half_y: number;
  readonly half_width: number;
  readonly half_height: number;
  readonly spine_type: number; // 皮肤类型
  readonly spine_width: number;
  readonly spine_height: number;
  readonly pivot_x: number;
  readonly pivot_y: number;
  readonly idle: number;
  readonly greeting: number; // 三项span动画时间
  readonly celebrate: number;
  readonly click: number;
  readonly greeting_init: number; // 获得动画持续时间长度
  readonly click2: number;
  readonly celebrate_idle: number;
  readonly illust_data: string;
  readonly blink: number; // 传记眨眼
}
//////////////////// item_definition.item_recovery ////////////////////
export interface Sheet_ItemDefinition_ItemRecovery {

}
//////////////////// item_definition.item_manual_pool ////////////////////
export interface Sheet_ItemDefinition_ItemManualPool {
  readonly id: number;
  readonly res_id: number; // 资源ID
  readonly res_count: number; // 资源数量
}
//////////////////// item_definition.source_limit ////////////////////
export interface Sheet_ItemDefinition_SourceLimit {
  readonly id: number; // 限制ID
  readonly item_id: number; // 道具ID
  readonly item_limit: number; // 获得上限每日
}
//////////////////// item_definition.item_package ////////////////////
export interface Sheet_ItemDefinition_ItemPackage {
  readonly id: number;
  readonly res_id: number; // 资源ID
  readonly res_count: number; // 资源数量
}
//////////////////// item_definition.fake_random_pool ////////////////////
export interface Sheet_ItemDefinition_FakeRandomPool {
  readonly id: number; // ID
  readonly stage_count: number[];
  readonly stage_weight: number[];
}
//////////////////// item_definition.loading_image ////////////////////
export interface Sheet_ItemDefinition_LoadingImage {
  readonly id: number;
  readonly img_path: string; // 大图路径
  readonly thumb_path: string; // 缩略图路径
  readonly sort: number; // 排序，数字大（新）的靠前展示
  readonly unlock_items: number[];
  readonly args: number[];
}
//////////////////// item_definition.function_item ////////////////////
export interface Sheet_ItemDefinition_FunctionItem {
  readonly id: number; // 功能道具id
  readonly type: number; // 类型
  readonly args: number[]; // 参数0
  readonly name: number; // 名称strid
  readonly desc_func: number; // 功能描述strid
  readonly desc: number; // 道具描述strid
  readonly icon: string; // 图标
  readonly icon_transparent: string; // 半透图标
}
//////////////////// item_definition ////////////////////
export interface Table_ItemDefinition {
  readonly currency: UniqueSheet<Sheet_ItemDefinition_Currency>;
  readonly item: UniqueSheet<Sheet_ItemDefinition_Item>;
  readonly title: UniqueSheet<Sheet_ItemDefinition_Title>;
  readonly character: UniqueSheet<Sheet_ItemDefinition_Character>;
  readonly view: UniqueSheet<Sheet_ItemDefinition_View>;
  readonly skin: UniqueSheet<Sheet_ItemDefinition_Skin>;
  readonly item_recovery: GroupSheet<Sheet_ItemDefinition_ItemRecovery>;
  readonly item_manual_pool: GroupSheet<Sheet_ItemDefinition_ItemManualPool>;
  readonly source_limit: GroupSheet<Sheet_ItemDefinition_SourceLimit>;
  readonly item_package: GroupSheet<Sheet_ItemDefinition_ItemPackage>;
  readonly fake_random_pool: UniqueSheet<Sheet_ItemDefinition_FakeRandomPool>;
  readonly loading_image: UniqueSheet<Sheet_ItemDefinition_LoadingImage>;
  readonly function_item: UniqueSheet<Sheet_ItemDefinition_FunctionItem>;
}
//////////////////// leaderboard.leaderboard ////////////////////
export interface Sheet_Leaderboard_Leaderboard {
  readonly id: number;
  readonly start_time: string; // 开始排名时间
  readonly end_time: string; // 最终排名时间
  readonly refresh_cd: number; // 刷新cd（秒）
  readonly max_count: number; // 上榜最多人数
  readonly show_list: string; // 展示列表（排名）
}
//////////////////// leaderboard ////////////////////
export interface Table_Leaderboard {
  readonly leaderboard: UniqueSheet<Sheet_Leaderboard_Leaderboard>;
}
//////////////////// level_definition.level_definition ////////////////////
export interface Sheet_LevelDefinition_LevelDefinition {
  readonly id: number;
  readonly type: number;
  readonly primary_level: number;
  readonly secondary_level: number;
  readonly init_point: number;
  readonly end_point: number;
  readonly primary_icon: string;
  readonly name_chs: string;
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly full_name_chs: string;
  readonly full_name_chs_t: string;
  readonly full_name_jp: string;
  readonly full_name_en: string;
  readonly full_name_kr: string;
  readonly can_degrade: number;
  readonly can_upgrade: number;
  readonly can_getpoint: number;
  readonly rankpt1: number; // 东风场4位扣分
  readonly rankpt2: number; // 南风场4位扣分
  readonly top_rank_id: number; // top_rank规则的id
}
//////////////////// level_definition.character ////////////////////
export interface Sheet_LevelDefinition_Character {
  readonly level: number;
  readonly character_id: number;
  readonly exp: number; // 经验槽
  readonly reward: string; // 升级好感后的奖励道具
  readonly unlock_says: number; // 升级后说的话
  readonly unlock_desc_chs: string; // 解锁时的描述
  readonly unlock_desc_chs_t: string;
  readonly unlock_desc_jp: string;
  readonly unlock_desc_en: string;
  readonly unlock_desc_kr: string;
}
//////////////////// level_definition.trail ////////////////////
export interface Sheet_LevelDefinition_Trail {
  readonly id: number;
  readonly init_level: number; // 初始等级
  readonly end_level: number; // 截止等级
  readonly trail_icon: number; // 图标
  readonly trail_fire: number; // 火数
}
//////////////////// level_definition.top_rank ////////////////////
export interface Sheet_LevelDefinition_TopRank {
  readonly id: number;
  readonly rank_pt: number[]; // 第一名获得pt
  readonly top_rank_pt: number[]; // 巅峰对决第一名
  readonly mode: number;
}
//////////////////// level_definition ////////////////////
export interface Table_LevelDefinition {
  readonly level_definition: UniqueSheet<Sheet_LevelDefinition_LevelDefinition>;
  readonly character: GroupSheet<Sheet_LevelDefinition_Character>;
  readonly trail: UniqueSheet<Sheet_LevelDefinition_Trail>;
  readonly top_rank: GroupSheet<Sheet_LevelDefinition_TopRank>;
}
//////////////////// mail ////////////////////
export interface Table_Mail {

}
//////////////////// mall.goods ////////////////////
export interface Sheet_Mall_Goods {
  readonly id: number;
  readonly name_chs: string;
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc: string; // 描述
  readonly desc_chs: string;
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly icon: string; // 图标
  readonly resource_id: number; // 资源ID
  readonly resource_count: number; // 资源数量
  readonly vip_exp: number; // 增加的vip经验
  readonly cny: number; // 首充档位ID
  readonly price: string; // 显示用的价格
  readonly first_desc_chs: string;
  readonly first_desc_chs_t: string;
  readonly first_desc_jp: string;
  readonly first_desc_en: string;
  readonly first_desc_kr: string;
  readonly first_extend_add: number; // 首冲额外赠送
  readonly normal_desc_chs: string;
  readonly normal_desc_chs_t: string;
  readonly normal_desc_jp: string;
  readonly normal_desc_en: string;
  readonly normal_desc_kr: string;
  readonly normal_extend_add: number; // 非首冲赠送辉玉
  readonly type: number; // 显示在哪个屋
}
//////////////////// mall.product ////////////////////
export interface Sheet_Mall_Product {
  readonly payment_platform: number; // 支付平台
  readonly goods_id: number; // 商品ID
  readonly product_type: number; // 商品类型
  readonly product_id: string; // 上架平台商品ID
  readonly currency_code: string; // 货币标准符号
  readonly currency_price: number; // 货币价格
  readonly actual_code: string; // 实际使用的货币符号
  readonly actual_price: number; // 实际支付价格（用于第三方支付）
  readonly brief_desc: string; // 简要描述
  readonly detail_desc: string; // 详细描述
}
//////////////////// mall.goods_shelves ////////////////////
export interface Sheet_Mall_GoodsShelves {
  readonly id: string; // 货架ID
  readonly goods_id: number; // 商品ID
  readonly currency_code: string; // 货币标准符号
  readonly currency_price: number; // 货币价格
  readonly price: string;
  readonly is_monthcard: number; // 是不是月卡
}
//////////////////// mall.zone_params ////////////////////
export interface Sheet_Mall_ZoneParams {
  readonly zone_id: string;
  readonly key: string;
  readonly string_value: string;
}
//////////////////// mall.month_ticket ////////////////////
export interface Sheet_Mall_MonthTicket {
  readonly id: number; // 月票ID 和goods里的ID是同一个 不要重复
  readonly name_chs: string; // 月票名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly resource_id: number; // 资源ID
  readonly resource_count: number; // 一次性交付资源数量
  readonly vip_exp: number; // 增加的vip经验
  readonly effective_time: number; // 有效期(日)
  readonly icon: string; // 图标
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly desc_detail_chs: string; // 购买弹出来的描述
  readonly desc_detail_chs_t: string;
  readonly desc_detail_jp: string;
  readonly desc_detail_en: string;
  readonly desc_detail_kr: string;
  readonly desc_detail2_chs: string; // 购买弹出来的描述
  readonly desc_detail2_chs_t: string;
  readonly desc_detail2_jp: string;
  readonly desc_detail2_en: string;
  readonly desc_detail2_kr: string;
}
//////////////////// mall.channel_config ////////////////////
export interface Sheet_Mall_ChannelConfig {
  readonly id: number; // 渠道ID
  readonly currency_platforms: string; // 渠道可消费货币种类
  readonly free_jade_ids: string; // 免费辉玉ID
  readonly paid_jade_ids: string; // 付费辉玉ID
  readonly free_voucher_ids: string; // 免费服饰券ID
  readonly paid_voucher_ids: string; // 付费服饰券ID
  readonly goods_id: number; // 渠道使用的goods_id
  readonly shelves_id: string; // 货架id
  readonly name: string; // 渠道代号
}
//////////////////// mall.month_ticket_info ////////////////////
export interface Sheet_Mall_MonthTicketInfo {
  readonly id: number;
}
//////////////////// mall.recharge_bonus ////////////////////
export interface Sheet_Mall_RechargeBonus {
  readonly zone_id: number;
  readonly reset_time: string;
}
//////////////////// mall ////////////////////
export interface Table_Mall {
  readonly goods: UniqueSheet<Sheet_Mall_Goods>;
  readonly product: GroupSheet<Sheet_Mall_Product>;
  readonly goods_shelves: GroupSheet<Sheet_Mall_GoodsShelves>;
  readonly zone_params: GroupSheet<Sheet_Mall_ZoneParams>;
  readonly month_ticket: UniqueSheet<Sheet_Mall_MonthTicket>;
  readonly channel_config: UniqueSheet<Sheet_Mall_ChannelConfig>;
  readonly month_ticket_info: UniqueSheet<Sheet_Mall_MonthTicketInfo>;
  readonly recharge_bonus: GroupSheet<Sheet_Mall_RechargeBonus>;
}
//////////////////// marathon.marathon_info ////////////////////
export interface Sheet_Marathon_MarathonInfo {
  readonly activity_id: number; // 活动id
  readonly tick: number; // 一秒多少tick
  readonly hands_count: number; // gameover的手牌数
  readonly start_time: number; // 起始倒计时（tick）
  readonly fever_speed: number; // fever time 期间速度（两面墙之间tick数）
  readonly fever_time_bonus: number; // fevertime期间的分数倍率，百分比
  readonly fever_time_duration: number; // 持续墙的面数
  readonly wall_tile_count: number; // 一面墙有多少张牌
  readonly wall_max_same_tile: number; // 一面墙最多能有多少张相同牌
  readonly wall_group_id: number; // 关卡组
  readonly tile_group: number; // 牌组
  readonly reward_group: number; // 分数
  readonly item_group: number; // 道具
  readonly point_item_id: number; // 胡萝卜id
  readonly fever_item_type: number; // fevertime期间的道具类型
  readonly distance_item_id: number; // 训练度id
  readonly distance_reward_rate: number; // 单轮游戏每N距离获得1训练度
  readonly max_distance_reward: number; // 单轮游戏获得训练度数量上限
  readonly wall_empty_pos: number[]; // 无效牌位置
}
//////////////////// marathon.marathon_reward ////////////////////
export interface Sheet_Marathon_MarathonReward {
  readonly group_id: number; // 分数组
  readonly type: number;
  readonly point: number;
  readonly time: number; // tick每秒30
}
//////////////////// marathon.marathon_tile_group ////////////////////
export interface Sheet_Marathon_MarathonTileGroup {
  readonly group_id: number; // 牌组
  readonly tile: string; // 牌
  readonly weight: number; // 基础权重
  readonly fever_weight: number; // 福牌权重
}
//////////////////// marathon.marathon_wall_group ////////////////////
export interface Sheet_Marathon_MarathonWallGroup {
  readonly group_id: number; // 牌墙组
  readonly lower: number; // 下限(闭区间)
  readonly upper: number; // 上限（闭区间，0表示无穷大）
  readonly speed: number; // 速度（两面墙之间消耗几个tick）
  readonly speed_bonus: number; // 期间的分数倍率，百分比
  readonly final_mode: number; // 终局模式，福牌必定不会出现，不使用仓检
  readonly fever_weight_addition: number; // 福牌额外权重
  readonly near_fever_weight_addition: number; // 福牌相邻牌额外权重
  readonly must_fever_count: number; // 必定出现福牌次数
  readonly finish_hands_check: number; // 完成检查概率%
  readonly strong_hands_check: number; // 强仓检概率%
  readonly weak_hands_check: number; // 弱仓检概率%
  readonly item_rate: number; // 生成道具概率%
  readonly item_group_id: number; // 道具组
}
//////////////////// marathon.marathon_item_group ////////////////////
export interface Sheet_Marathon_MarathonItemGroup {
  readonly group_id: number; // 道具组
  readonly type: number; // 道具类型
  readonly weight: number; // 权重
}
//////////////////// marathon ////////////////////
export interface Table_Marathon {
  readonly marathon_info: UniqueSheet<Sheet_Marathon_MarathonInfo>;
  readonly marathon_reward: GroupSheet<Sheet_Marathon_MarathonReward>;
  readonly marathon_tile_group: GroupSheet<Sheet_Marathon_MarathonTileGroup>;
  readonly marathon_wall_group: GroupSheet<Sheet_Marathon_MarathonWallGroup>;
  readonly marathon_item_group: GroupSheet<Sheet_Marathon_MarathonItemGroup>;
}
//////////////////// match_shilian.shilian ////////////////////
export interface Sheet_MatchShilian_Shilian {
  readonly id: number;
  readonly name: string;
  readonly ticket_id: number;
  readonly currency_id: number;
  readonly currency_count: number;
  readonly mode: number; // 见mode解释
  readonly mode1: number;
  readonly mode2: number;
  readonly init_point: number; // 起始配点
  readonly back_point: number; // 返场点数
}
//////////////////// match_shilian.shilian_reward ////////////////////
export interface Sheet_MatchShilian_ShilianReward {
  readonly id: number;
  readonly reward_id: number;
  readonly reward_count: number;
}
//////////////////// match_shilian.shilian_time ////////////////////
export interface Sheet_MatchShilian_ShilianTime {
  readonly id: number;
  readonly start: string;
  readonly end: string;
}
//////////////////// match_shilian ////////////////////
export interface Table_MatchShilian {
  readonly shilian: UniqueSheet<Sheet_MatchShilian_Shilian>;
  readonly shilian_reward: GroupSheet<Sheet_MatchShilian_ShilianReward>;
  readonly shilian_time: UniqueSheet<Sheet_MatchShilian_ShilianTime>;
}
//////////////////// misc_function.daily_sign_in ////////////////////
export interface Sheet_MiscFunction_DailySignIn {
  readonly id: number; // 天数 1-7
  readonly reward_id: number; // 奖励Id
  readonly reward_count: number; // 奖励数量
}
//////////////////// misc_function ////////////////////
export interface Table_MiscFunction {
  readonly daily_sign_in: UniqueSheet<Sheet_MiscFunction_DailySignIn>;
}
//////////////////// mmo.mmo_activity ////////////////////
export interface Sheet_Mmo_MmoActivity {
  readonly activity_id: number; // 活动id
  readonly equipment_bag_max: number; // 装备最大数量
  readonly random_equipment_count: number; // 随机合成需要装备数量
  readonly appoint_equipment_count: number; // 指定合成需要的装备数量
  readonly initial_level_id: number; // 初始关卡id
  readonly next_level_time: number; // 成功后几秒下一关
  readonly tick: number; // 1秒多少tick
  readonly total_tick_red: number; // 倒计时小于多少tick变红
}
//////////////////// mmo.mmo_character ////////////////////
export interface Sheet_Mmo_MmoCharacter {
  readonly activity_id: number; // 活动id
  readonly character_id: number; // 角色id
  readonly hp: number; // 基础生命值
  readonly atk: number; // 攻击力
  readonly critical_rate: number; // 暴击率%
  readonly critical_damage: number; // 暴击倍率%
  readonly aggro: number; // 仇恨权重，优先攻击权重高的
  readonly action_seq: number; // 行动顺序
  readonly weapon_type: number; // 专武类型
  readonly init_equipment: string; // 初始装备列表
  readonly job_name: number; // 职业名称
  readonly job_desc: number; // 职业描述
  readonly res_name: string; // spine名字
}
//////////////////// mmo.mmo_enemy ////////////////////
export interface Sheet_Mmo_MmoEnemy {
  readonly activity_id: number; // 活动id
  readonly enemy_id: number; // 敌人id
  readonly hp: number; // 生命值
  readonly atk: number; // 攻击力
  readonly critical_rate: number; // 暴击率%
  readonly critical_damage: number; // 暴击倍率%
  readonly action_seq: number; // 行动顺序
  readonly res_name: string; // spine名字
  readonly equipment_list: string; // 装备列表
}
//////////////////// mmo.mmo_equipment ////////////////////
export interface Sheet_Mmo_MmoEquipment {
  readonly activity_id: number; // 活动id
  readonly item_id: number; // 对应function_item表的道具id
  readonly type: number; // 装备类型
  readonly weapon_type_id: number; // 武器类型
  readonly rarity: number; // 稀有度
  readonly atk_fixed: number; // 攻击加固定值
  readonly atk_rate: number; // 攻击加百分比
  readonly critical_rate: number; // 暴击率
  readonly critical_damage_fixed: number; // 暴击伤害加固定值
  readonly critical_damage_rate: number; // 暴击伤害加百分比
  readonly hp_fixed: number; // 血量加固定值
  readonly hp_rate: number; // 血量加百分比
  readonly heal_rate: number; // 治疗转化率
  readonly buff_list: string; // 装备特殊效果
  readonly power: number; // 战力值
  readonly attachment_pre_name: string[]; // 皮肤部件前缀名
}
//////////////////// mmo.mmo_equipment_buff ////////////////////
export interface Sheet_Mmo_MmoEquipmentBuff {
  readonly buff_id: number; // buffid
  readonly type: number; // buff类型
  readonly args: number[]; // 参数0
  readonly equipment_buff_desc: number; // 装备效果描述
}
//////////////////// mmo.mmo_level ////////////////////
export interface Sheet_Mmo_MmoLevel {
  readonly activity_id: number; // 活动id
  readonly level_id: number; // 关卡id
  readonly next_level: number; // 下一关卡id
  readonly enemy_id: number; // 敌人id
  readonly reward: string; // 奖励
  readonly unlock_day: number; // 解锁日
  readonly consume: string; // 闯关消耗
  readonly total_tick: number; // 倒计时
  readonly team_max_count: number; // 人数上限
  readonly background: string; // 背景素材
  readonly recommend_power: number; // 推荐战力
}
//////////////////// mmo.mmo_npc ////////////////////
export interface Sheet_Mmo_MmoNpc {
  readonly activity_id: number; // 活动id
  readonly npc_id: number; // npcid
  readonly character_id: number; // 职业
  readonly equipment_list: string; // 装备列表
  readonly accessible_days: string; // 随机时段
  readonly npc_name: number; // npc名称,str/event
}
//////////////////// mmo.mmo_buff_banned ////////////////////
export interface Sheet_Mmo_MmoBuffBanned {
  readonly id: number;
  readonly ban_rare: number; // 禁用的稀有度
}
//////////////////// mmo.mmo_buff_replace ////////////////////
export interface Sheet_Mmo_MmoBuffReplace {
  readonly id: number;
  readonly item_id: number; // 从物品id
  readonly replace_id: number; // 替换为物品id
}
//////////////////// mmo.mmo_support ////////////////////
export interface Sheet_Mmo_MmoSupport {
  readonly activity_id: number; // 活动id
  readonly support_count_range: number[]; // 支援数下限，闭区间
  readonly reward: string; // 奖励
}
//////////////////// mmo.mmo_weapon_type ////////////////////
export interface Sheet_Mmo_MmoWeaponType {
  readonly activity_id: number; // 活动id
  readonly weapon_type_id: number; // 武器类型
  readonly attack_tick: number; // 攻击动画
  readonly attack_recovery_tick: number; // 攻击后摇
  readonly hit_tick: number; // 受击动画
  readonly move_tick: number; // 移动动画
  readonly back_tick: number; // 移动回程动画
  readonly cure_tick: number; // 治疗动画
  readonly cure_recovery_tick: number; // 治疗后摇
  readonly anim_type: number; // 动画种类
  readonly hand_type: number; // 处理手持类型
  readonly counter_attack: number; // 是否是反击攻击
  readonly attack_distance: number; // 攻击距离，0近战，1远程
  readonly attack2_target: number; // attack2目标挂点
  readonly attack2_tick: number; // attack2攻击delay
  readonly hit_effect_param: string; // 受击位置
  readonly die_effect_param: string; // 死亡特效
  readonly die_tick: number; // 死亡动画
  readonly res_name: string; // spine名字
  readonly audio_move: string; // 移动音效
  readonly audio_hit: string; // 受击音效
  readonly audio_down: string; // 倒地音效
  readonly down_delay: number; // 倒地延迟
  readonly audio_die: string; // 死亡消散
  readonly audio_attack_lv0: string; // 攻击音效lv0
  readonly attack_lv0_delay: number; // 攻击音效lv0延迟
  readonly audio_attack_lv1: string; // 攻击音效lv1
  readonly attack_lv1_delay: number; // 攻击音效lv1延迟
  readonly audio_attack_lv2: string; // 攻击音效lv2
  readonly attack_lv2_delay: number; // 攻击音效lv1延迟
  readonly audio_attack_lv3: string; // 攻击音效lv3
  readonly attack_lv3_delay: number; // 攻击音效lv1延迟
  readonly audio_heal: string; // 治疗音效
  readonly audio_move_speed2: string; // 移动音效
  readonly audio_hit_speed2: string; // 受击音效
  readonly audio_down_speed2: string; // 倒地音效
  readonly audio_die_speed2: string; // 死亡消散
  readonly audio_attack_lv0_speed2: string; // 攻击音效lv0_倍速2
  readonly audio_attack_lv1_speed2: string; // 攻击音效lv1_倍速2
  readonly audio_attack_lv2_speed2: string; // 攻击音效lv2_倍速2
  readonly audio_attack_lv3_speed2: string; // 攻击音效lv3_倍速2
  readonly audio_heal_speed2: string; // 治疗音效
}
//////////////////// mmo.mmo_team_talent ////////////////////
export interface Sheet_Mmo_MmoTeamTalent {
  readonly activity_id: number; // 活动id
  readonly buff_id: number; // buffid
  readonly buff_level: number; // buff等级
  readonly weapon_type_id: string; // 武器类型id
  readonly power: number; // 战力值
}
//////////////////// mmo ////////////////////
export interface Table_Mmo {
  readonly mmo_activity: UniqueSheet<Sheet_Mmo_MmoActivity>;
  readonly mmo_character: GroupSheet<Sheet_Mmo_MmoCharacter>;
  readonly mmo_enemy: GroupSheet<Sheet_Mmo_MmoEnemy>;
  readonly mmo_equipment: GroupSheet<Sheet_Mmo_MmoEquipment>;
  readonly mmo_equipment_buff: UniqueSheet<Sheet_Mmo_MmoEquipmentBuff>;
  readonly mmo_level: GroupSheet<Sheet_Mmo_MmoLevel>;
  readonly mmo_npc: GroupSheet<Sheet_Mmo_MmoNpc>;
  readonly mmo_buff_banned: GroupSheet<Sheet_Mmo_MmoBuffBanned>;
  readonly mmo_buff_replace: GroupSheet<Sheet_Mmo_MmoBuffReplace>;
  readonly mmo_support: GroupSheet<Sheet_Mmo_MmoSupport>;
  readonly mmo_weapon_type: GroupSheet<Sheet_Mmo_MmoWeaponType>;
  readonly mmo_team_talent: GroupSheet<Sheet_Mmo_MmoTeamTalent>;
}
//////////////////// outfit_config.ron ////////////////////
export interface Sheet_OutfitConfig_Ron {
  readonly id: number; // 道具id
  readonly is_fullscreen: number; // 是含有全屏特效，1有，0无
  readonly queue_change_delay: number; // 牌层级恢复时间
}
//////////////////// outfit_config.liqi ////////////////////
export interface Sheet_OutfitConfig_Liqi {
  readonly id: number; // 道具id
  readonly hide_direction: string; // 部分方向隐藏特效
}
//////////////////// outfit_config.effect_liqi ////////////////////
export interface Sheet_OutfitConfig_EffectLiqi {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.mpzs ////////////////////
export interface Sheet_OutfitConfig_Mpzs {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.tablecloth ////////////////////
export interface Sheet_OutfitConfig_Tablecloth {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.mjp ////////////////////
export interface Sheet_OutfitConfig_Mjp {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.mjpface ////////////////////
export interface Sheet_OutfitConfig_Mjpface {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.headframe ////////////////////
export interface Sheet_OutfitConfig_Headframe {
  readonly id: number; // 道具id
}
//////////////////// outfit_config.hand ////////////////////
export interface Sheet_OutfitConfig_Hand {
  readonly id: number; // 道具id
}
//////////////////// outfit_config ////////////////////
export interface Table_OutfitConfig {
  readonly ron: UniqueSheet<Sheet_OutfitConfig_Ron>;
  readonly liqi: UniqueSheet<Sheet_OutfitConfig_Liqi>;
  readonly effect_liqi: UniqueSheet<Sheet_OutfitConfig_EffectLiqi>;
  readonly mpzs: UniqueSheet<Sheet_OutfitConfig_Mpzs>;
  readonly tablecloth: UniqueSheet<Sheet_OutfitConfig_Tablecloth>;
  readonly mjp: UniqueSheet<Sheet_OutfitConfig_Mjp>;
  readonly mjpface: UniqueSheet<Sheet_OutfitConfig_Mjpface>;
  readonly headframe: UniqueSheet<Sheet_OutfitConfig_Headframe>;
  readonly hand: UniqueSheet<Sheet_OutfitConfig_Hand>;
}
//////////////////// quest_crew.qc_info ////////////////////
export interface Sheet_QuestCrew_QcInfo {
  readonly id: number; // 活动ID
  readonly character_pool_id: number; // 角色池id
  readonly quest_pool_id: number; // 委托池id
  readonly refresh_market_price: string; // 刷新商店价格
  readonly market_count: number; // 人才中心角色数量
  readonly character_charging_price: string; // 角色回满体力价格
  readonly great_success_effect_ceo: number; // 大成功体力减免系数，百分数
  readonly great_success_ceo: number; // 大成功需要的属性值系数，百分数
  readonly init_character_id: number[]; // 初始赠送员工
}
//////////////////// quest_crew.qc_character_pool ////////////////////
export interface Sheet_QuestCrew_QcCharacterPool {
  readonly id: number; // 角色池
  readonly character_id: number; // 角色ID
  readonly sta: number; // 体力值
  readonly str: number; // 力量值
  readonly spd: number; // 速度值
  readonly luc: number; // 运气值
  readonly effect: number; // 特性
  readonly show_in_market: number; // 是否在雇佣池中
  readonly hiring_price: string; // 雇佣价格
  readonly item_id: number; // 雀魂雀士角色ID
  readonly name: number; // 员工名str/event
  readonly skill: number; // 特性描述文str/event
  readonly npc_code: string; // npc素材编号0001-0016
  readonly display_change: number; // 前端变动展示
}
//////////////////// quest_crew.qc_effect ////////////////////
export interface Sheet_QuestCrew_QcEffect {
  readonly id: number; // 特性ID
  readonly type: number; // 特性类型
  readonly args: number[]; // 参数
}
//////////////////// quest_crew.qc_quest_pool ////////////////////
export interface Sheet_QuestCrew_QcQuestPool {
  readonly id: number; // 委托池id
  readonly quest_id: number; // 委托ID
  readonly sort: number; // 委托排序从小到大
  readonly type: number; // 委托种类
  readonly str: number; // 需求力量
  readonly spd: number; // 需求速度
  readonly luc: number; // 需求运气
  readonly unlock_days: number; // 解锁日，0表示活动开始日
  readonly consume: number; // 消耗体力值
  readonly rewards: number; // 赠送qc_character的id
  readonly client: number; // 委托人种类
  readonly character_id: number; // 雀魂雀士id
  readonly client_name: number; // 委托人名str/event
  readonly quest_desc: number; // 委托描述文str/event
  readonly npc_code: string; // npc素材编号0001-0016
}
//////////////////// quest_crew ////////////////////
export interface Table_QuestCrew {
  readonly qc_info: UniqueSheet<Sheet_QuestCrew_QcInfo>;
  readonly qc_character_pool: GroupSheet<Sheet_QuestCrew_QcCharacterPool>;
  readonly qc_effect: UniqueSheet<Sheet_QuestCrew_QcEffect>;
  readonly qc_quest_pool: GroupSheet<Sheet_QuestCrew_QcQuestPool>;
}
//////////////////// rank_introduce.rank ////////////////////
export interface Sheet_RankIntroduce_Rank {
  readonly id: number;
  readonly info: string[];
}
//////////////////// rank_introduce.rank3 ////////////////////
export interface Sheet_RankIntroduce_Rank3 {
  readonly id: number;
  readonly info: string[];
}
//////////////////// rank_introduce ////////////////////
export interface Table_RankIntroduce {
  readonly rank: UniqueSheet<Sheet_RankIntroduce_Rank>;
  readonly rank3: UniqueSheet<Sheet_RankIntroduce_Rank3>;
}
//////////////////// season.season ////////////////////
export interface Sheet_Season_Season {
  readonly id: number;
  readonly start_time: string; // 开始时间
  readonly end_time: string; // 结束时间
  readonly disappear_time: string; // 消失不显示时间
  readonly match_mode: number; // 匹配房id
  readonly level_ticket_pool: number; // 课题券池
  readonly ticket_retry: number; // 再发行ID
  readonly point_item_id: number; // 积分道具ID
  readonly point_consume: number; // 敲章消耗积分
  readonly desc_chs: string; // 赛季名
  readonly desc_chs_t: string; // 赛季名
  readonly desc_jp: string; // 赛季名
  readonly desc_en: string; // 赛季名
  readonly desc_kr: string; // 赛季名
  readonly desktop_type: number; // 桌类型
}
//////////////////// season.level_ticket ////////////////////
export interface Sheet_Season_LevelTicket {
  readonly id: number; // 课题券ID
  readonly level: number; // 难度
  readonly game_count: number; // 最大对局数
  readonly weight: number; // 权重
  readonly task: number[]; // 课题券任务
  readonly reward: string;
}
//////////////////// season.level_ticket_pool ////////////////////
export interface Sheet_Season_LevelTicketPool {
  readonly pool_id: number; // 课题券池ID
  readonly level_lower: number; // 等级下限
  readonly level_upper: number; // 等级上限
  readonly ticket_level: number; // 课题券难度
}
//////////////////// season.ticket_retry ////////////////////
export interface Sheet_Season_TicketRetry {
  readonly group_id: number; // 组别id
  readonly count: number; // 次数
  readonly cost: number; // 花费铜币
}
//////////////////// season.season_reward ////////////////////
export interface Sheet_Season_SeasonReward {
  readonly season_id: number; // 赛季ID
  readonly rank_lower: number; // 排名下限
  readonly rank_upper: number; // 排名上限
  readonly rewards: string; // 奖励列表
}
//////////////////// season ////////////////////
export interface Table_Season {
  readonly season: UniqueSheet<Sheet_Season_Season>;
  readonly level_ticket: UniqueSheet<Sheet_Season_LevelTicket>;
  readonly level_ticket_pool: GroupSheet<Sheet_Season_LevelTicketPool>;
  readonly ticket_retry: GroupSheet<Sheet_Season_TicketRetry>;
  readonly season_reward: GroupSheet<Sheet_Season_SeasonReward>;
}
//////////////////// shoot.shoot_info ////////////////////
export interface Sheet_Shoot_ShootInfo {
  readonly activity_id: number; // 活动id
  readonly missions_group_id: number; // 关卡组id
  readonly level_count: number; // 关卡总数
  readonly bullet_item_id: number; // 子弹道具
}
//////////////////// shoot.shoot_mission ////////////////////
export interface Sheet_Shoot_ShootMission {
  readonly group_id: number; // 关卡配置组
  readonly level: number; // 关卡
  readonly enemy_group_id: number; // 敌人组
}
//////////////////// shoot.shoot_enemy ////////////////////
export interface Sheet_Shoot_ShootEnemy {
  readonly group_id: number; // 敌人配置组
  readonly enemy_id: number; // 敌人id独立
  readonly hp: number; // 敌人生命值
  readonly reward_group_id: number; // 奖励组
  readonly x: number; // 敌人初始坐标
  readonly y: number; // 敌人所处高度，3最高
  readonly width: number; // 敌人宽度
}
//////////////////// shoot.shoot_reward ////////////////////
export interface Sheet_Shoot_ShootReward {
  readonly group_id: number; // 道具奖励组
  readonly reward_id: number; // 奖励id唯一
  readonly reward: string; // 奖励内容，道具id-个数
  readonly reward_level: number; // 奖励等级，3最高1最低
  readonly star_num: number; // 星星数
  readonly reward_merge: number; // 合并等级，同一level内数字小的靠前
  readonly activity_id: number; // 活动id
}
//////////////////// shoot ////////////////////
export interface Table_Shoot {
  readonly shoot_info: UniqueSheet<Sheet_Shoot_ShootInfo>;
  readonly shoot_mission: GroupSheet<Sheet_Shoot_ShootMission>;
  readonly shoot_enemy: GroupSheet<Sheet_Shoot_ShootEnemy>;
  readonly shoot_reward: GroupSheet<Sheet_Shoot_ShootReward>;
}
//////////////////// shops.zhp_goods ////////////////////
export interface Sheet_Shops_ZhpGoods {
  readonly id: number;
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly item_id: number; // 物品ID
  readonly name_kr: string;
  readonly buy_limit: number; // 购买数量限制
  readonly currency: number; // 货币种类
  readonly price: number; // 单价
  readonly need_amount: number; // 需要指定购买数量
  readonly show_has: number; // 显示已拥有数量
}
//////////////////// shops.zhp_refresh_group ////////////////////
export interface Sheet_Shops_ZhpRefreshGroup {

}
//////////////////// shops.zhp_refresh_price ////////////////////
export interface Sheet_Shops_ZhpRefreshPrice {
  readonly id: number; // 组id
  readonly refresh_price: number; // 刷新价格
}
//////////////////// shops.goods ////////////////////
export interface Sheet_Shops_Goods {
  readonly id: number;
  readonly category: number; // 商店类型
  readonly category_goods: number; // 商品类型
  readonly icon: string; // 图标
  readonly name_chs: string; // 名称
  readonly name_chs_t: string; // 名称
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string;
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly item_id: number; // 物品ID
  readonly price: string; // 价格
  readonly show_original_price: string; // 价格
  readonly need_amount: number; // 指定购买数量
  readonly buy_limit: number; // 购买数量限制
  readonly show_has: number; // 显示已拥有数量
  readonly sort: number; // 排序
  readonly discount: number; // 折扣(万分比)
  readonly sell_activity: number; // 销售期间活动id
  readonly launch_time: string; // 起售时间，之后才可兑换
  readonly func: string;
  readonly discount_activity: number; // 打折期间活动id
  readonly zone: string; // 分服启用，1中文服 2日服 3美服
}
//////////////////// shops.goods_package ////////////////////
export interface Sheet_Shops_GoodsPackage {
  readonly id: number;
  readonly good_id: number; // 商品ID
  readonly good_count: number; // 商品数量
}
//////////////////// shops.interval_refresh_goods ////////////////////
export interface Sheet_Shops_IntervalRefreshGoods {
  readonly group_id: number;
  readonly goods_id: number;
  readonly interval: number;
  readonly interval_type: number;
}
//////////////////// shops.item_package ////////////////////
export interface Sheet_Shops_ItemPackage {
  readonly id: number;
  readonly item_info: string; // 包含道具
}
//////////////////// shops.selected_package ////////////////////
export interface Sheet_Shops_SelectedPackage {
  readonly id: number; // 自选服饰商品id
  readonly goods_id: number; // 可选商品id
  readonly price: string; // 价格
}
//////////////////// shops ////////////////////
export interface Table_Shops {
  readonly zhp_goods: UniqueSheet<Sheet_Shops_ZhpGoods>;
  readonly zhp_refresh_group: UniqueSheet<Sheet_Shops_ZhpRefreshGroup>;
  readonly zhp_refresh_price: UniqueSheet<Sheet_Shops_ZhpRefreshPrice>;
  readonly goods: UniqueSheet<Sheet_Shops_Goods>;
  readonly goods_package: GroupSheet<Sheet_Shops_GoodsPackage>;
  readonly interval_refresh_goods: GroupSheet<Sheet_Shops_IntervalRefreshGoods>;
  readonly item_package: UniqueSheet<Sheet_Shops_ItemPackage>;
  readonly selected_package: GroupSheet<Sheet_Shops_SelectedPackage>;
}
//////////////////// simulation.sim_v2_info ////////////////////
export interface Sheet_Simulation_SimV2Info {
  readonly activity_id: number; // 绑定activity表的活动
  readonly player_chara_id: number; // 玩家控制角色一姬（200001）
  readonly event_group_id: number; // 本次雀斗大会使用的事件组
  readonly train_result_fail: number; // 养成数值变动-失败
  readonly train_result_normal: number; // 养成数值变动-成功
  readonly train_result_great: number; // 养成数值变动-大成功
  readonly train_cap: number; // 五维数值的封顶上限
  readonly find_ting_adj: number; // 发现听牌后放铳调整
  readonly shunweima_2: number; // 2位马点
  readonly shunweima_3: number; // 3位马点
  readonly shunweima_4: number; // 4位马点
  readonly match_event_cd: number; // 对局事件的余牌cd
  readonly show_arrow_buff: string; // 显示箭头的buff
  readonly add_sub_buff: string; // 描述内{0}正数需要加+的buff
  readonly attribute_add_buff: string; // 描述内{0}填特性名，{1}填加成值，{1}正数需要加+
  readonly arrow_amount_12001: number; // 单加减号值_自摸和牌
  readonly arrow_amount_12002: number; // 单加减号值_放铳概率
  readonly arrow_amount_12004: number; // 单加减号值_副露倾向
  readonly arrow_amount_12005: number; // 单加减号值_向听推进速度
  readonly arrow_amount_12014: number; // 单加减号值_对手向听推进速度
}
//////////////////// simulation.sim_v2_round ////////////////////
export interface Sheet_Simulation_SimV2Round {
  readonly activity_id: number; // 绑定activity表的活动
  readonly round_id: number; // 回合数（1-50）
  readonly round_type: number; // 1=养成 2=比赛
}
//////////////////// simulation.sim_v2_character ////////////////////
export interface Sheet_Simulation_SimV2Character {
  readonly activity_id: number; // 绑定activity表的活动
  readonly id: number; // 角色id
  readonly luk: number; // 运气
  readonly tec: number; // 技术
  readonly ins: number; // 洞察
  readonly int: number; // 直觉
  readonly res: number; // 智谋
  readonly leaderboard_score: number; // 排行榜分数
  readonly show_round: string; // 出现回合数
}
//////////////////// simulation.sim_v2_roll ////////////////////
export interface Sheet_Simulation_SimV2Roll {
  readonly event_group_id: number; // 事件组ID
  readonly name: number; // 事件（注释）
  readonly value: number; // 值
  readonly weight: number; // 权重（万分制）
}
//////////////////// simulation.sim_v2_event ////////////////////
export interface Sheet_Simulation_SimV2Event {
  readonly event_group_id: number; // 雀斗大会事件组
  readonly event_id: number; // 单个事件id
  readonly event_title: number; // 事件标题str_event
  readonly event_desc: number; // 事件描述str_event
  readonly type: number; // 触发时点
  readonly cd_round: number; // 冷却回合数
  readonly trigger_rate: number; // 触发概率
  readonly trigger_sort: number; // 触发优先级
  readonly trigger: number[]; // 触发条件id（且）
}
//////////////////// simulation.sim_v2_trigger ////////////////////
export interface Sheet_Simulation_SimV2Trigger {
  readonly trigger_id: number; // 触发条件每个一行
  readonly type: number; // 列举所有用到的条件type
  readonly param: string[]; // 参数0
}
//////////////////// simulation.sim_v2_selection ////////////////////
export interface Sheet_Simulation_SimV2Selection {
  readonly event_id: number; // 单个事件ID
  readonly selection_id: number; // 选项ID
  readonly selection_desc: number; // 选项内容，str_event
  readonly type: number; // 1固定显示，2持有特性显示，3持有特性消失
  readonly check: string[]; // 检查五维（1或2种）
  readonly args: number[]; // 特性id
}
//////////////////// simulation.sim_v2_effect ////////////////////
export interface Sheet_Simulation_SimV2Effect {
  readonly effect_id: number; // 特性ID
  readonly luk: number; // 运气（1-10000）
  readonly tec: number; // 技术
  readonly ins: number; // 洞察
  readonly int: number; // 直觉
  readonly res: number; // 智谋
  readonly effect_title: number; // 特性名str/event
  readonly effect_desc: number; // 特性描述str/event
}
//////////////////// simulation.sim_v2_selection_result ////////////////////
export interface Sheet_Simulation_SimV2SelectionResult {
  readonly selection_id: number; // 选项id组，每个结果配置一行
  readonly selection_result_id: number; // 结果id
  readonly selection_result_type: number; // 结果分类1=大成功，2=成功，3=普通
  readonly initial_weight: number; // 这个结果的初始权重
  readonly luk: number; // 五维变动-运气
  readonly tec: number; // 技术
  readonly ins: number; // 洞察
  readonly int: number; // 直觉
  readonly res: number; // 智谋
  readonly effect: number[]; // 此结果会获得的特性id
  readonly buff: number[]; // 如果是对局事件，此结果会获得的对局buff（种类多）
}
//////////////////// simulation.sim_v2_buff ////////////////////
export interface Sheet_Simulation_SimV2Buff {
  readonly buff_id: number; // 对局结果，每种1行
  readonly buff_result_desc: number; // buff的结果页显示文本，str_event
  readonly buff_desc: number; // buff的说明文本，str_event
  readonly type: number; // type
  readonly match_effect: number; // 比赛事件的生效时间，0当局1下局
  readonly param: string[]; // 需要引入的其他参数用
}
//////////////////// simulation.sim_v2_upgrade ////////////////////
export interface Sheet_Simulation_SimV2Upgrade {
  readonly activity_id: number; // 活动id
  readonly skill_point: number; // 一个升级点对应属性点个数
  readonly limit: number; // 单维属性加点上限
  readonly item_id: number; // 对应道具id
}
//////////////////// simulation.sim_v2_story ////////////////////
export interface Sheet_Simulation_SimV2Story {
  readonly activity_id: number; // 绑定activity表的活动
  readonly story_id: number;
  readonly trigger_type: number; // 触发类型
  readonly weight: number; // 触发几率
  readonly str_id: number; // 文字描述
  readonly args: number[];
}
//////////////////// simulation.sim_v2_reward ////////////////////
export interface Sheet_Simulation_SimV2Reward {
  readonly activity_id: number; // 绑定activity表的活动
  readonly rank: number; // 排位 1-4
  readonly ability: number; // 能力值加点
  readonly random_effect: number; // 随机获得特性个数
}
//////////////////// simulation ////////////////////
export interface Table_Simulation {
  readonly sim_v2_info: UniqueSheet<Sheet_Simulation_SimV2Info>;
  readonly sim_v2_round: GroupSheet<Sheet_Simulation_SimV2Round>;
  readonly sim_v2_character: GroupSheet<Sheet_Simulation_SimV2Character>;
  readonly sim_v2_roll: GroupSheet<Sheet_Simulation_SimV2Roll>;
  readonly sim_v2_event: GroupSheet<Sheet_Simulation_SimV2Event>;
  readonly sim_v2_trigger: UniqueSheet<Sheet_Simulation_SimV2Trigger>;
  readonly sim_v2_selection: GroupSheet<Sheet_Simulation_SimV2Selection>;
  readonly sim_v2_effect: UniqueSheet<Sheet_Simulation_SimV2Effect>;
  readonly sim_v2_selection_result: GroupSheet<Sheet_Simulation_SimV2SelectionResult>;
  readonly sim_v2_buff: UniqueSheet<Sheet_Simulation_SimV2Buff>;
  readonly sim_v2_upgrade: UniqueSheet<Sheet_Simulation_SimV2Upgrade>;
  readonly sim_v2_story: GroupSheet<Sheet_Simulation_SimV2Story>;
  readonly sim_v2_reward: GroupSheet<Sheet_Simulation_SimV2Reward>;
}
//////////////////// snowball.snowball_activity ////////////////////
export interface Sheet_Snowball_SnowballActivity {
  readonly activity_id: number; // 活动id
  readonly monster_group: number; // 怪物组
  readonly player_attack_group: number; // 玩家基础攻击模组
  readonly monster_attack_group: number; // 敌人基础攻击模组
  readonly hp: number; // 玩家/怪基础血量
  readonly mp: number; // 玩家/怪基础蓝量
  readonly player_luk: number; // 玩家暴击率百分比
  readonly critical_hit: number; // 玩家暴击倍率
  readonly mp_recover: number; // 蓝量恢复（tick）
  readonly tick: number; // 一秒多少tick
  readonly player_id: string; // 玩家素材
  readonly skill_item: number; // 技能升级道具
  readonly attack_interval: number; // 连续攻击时的雪球间隔（tick）
  readonly player_attack_delay: number; // 玩家攻击前摇
  readonly player_height: number; // 玩家身高
  readonly audio_enter: string; // 玩家进场音效
  readonly audio_hit: string; // 玩家受击音效
  readonly audio_win: string; // 玩家胜利音效
  readonly audio_die: string; // 玩家失败音效
}
//////////////////// snowball.snowball_attack_group ////////////////////
export interface Sheet_Snowball_SnowballAttackGroup {
  readonly group_id: number;
  readonly track: number; // 弹道0下、1中、2上
  readonly flight_time: number; // 弹道飞行时间（tick）
  readonly atk: number; // 攻击力
  readonly mp_consume: number; // 蓝量消耗
  readonly cd: number; // cd时间（tick）
  readonly snowball_name_str: number; // 雪球名
}
//////////////////// snowball.snowball_monster_group ////////////////////
export interface Sheet_Snowball_SnowballMonsterGroup {
  readonly group_id: number;
  readonly level: number; // 关卡
  readonly next_level: number; // 下一关卡
  readonly type: number; // 怪类型
  readonly chapters: string; // 关卡名
  readonly reward: string; // 关卡奖励
  readonly node_mark: number; // 0普通1突出
  readonly boss_id: string; // 敌人素材
  readonly name_str_id: number; // 对应str/event
  readonly round_time: number; // 回合时长（tick）
  readonly unlock_day: number; // 解锁日期
  readonly enter_delay: number; // 入场前摇
  readonly attack_delay: number; // 攻击前摇
  readonly monster_height: number; // 怪物身高
  readonly dead_offset: number; // 死亡特效偏移
  readonly audio_enter: string; // 进场音效
  readonly audio_hit: string; // 受击音效
  readonly audio_win: string; // 胜利音效
  readonly audio_die: string; // 失败音效
}
//////////////////// snowball.player_snowball_buff ////////////////////
export interface Sheet_Snowball_PlayerSnowballBuff {
  readonly activity_id: number; // 活动id
  readonly buff_id: number; // buffid
  readonly level: number; // 等级
  readonly next_level_id: number; // 下一等级
  readonly type: number; // 下0中1上2血量3
  readonly effect: number; // 血量增加的值，上中下雪球填attack_level_id
  readonly unlock: number; // 解锁关卡
  readonly auto: number; // 自动获得
  readonly price: number; // 升到该级价格
}
//////////////////// snowball.monster_snowball_buff ////////////////////
export interface Sheet_Snowball_MonsterSnowballBuff {
  readonly activity_id: number; // 活动id
}
//////////////////// snowball.snowball_attack_level ////////////////////
export interface Sheet_Snowball_SnowballAttackLevel {
  readonly attack_level_id: number;
  readonly snowball_count: number; // 单次投掷额外增加数
  readonly mp_buff: number; // 蓝量消耗减少
  readonly cd_buff: number; // 冷却减少
}
//////////////////// snowball ////////////////////
export interface Table_Snowball {
  readonly snowball_activity: UniqueSheet<Sheet_Snowball_SnowballActivity>;
  readonly snowball_attack_group: GroupSheet<Sheet_Snowball_SnowballAttackGroup>;
  readonly snowball_monster_group: GroupSheet<Sheet_Snowball_SnowballMonsterGroup>;
  readonly player_snowball_buff: GroupSheet<Sheet_Snowball_PlayerSnowballBuff>;
  readonly monster_snowball_buff: GroupSheet<Sheet_Snowball_MonsterSnowballBuff>;
  readonly snowball_attack_level: UniqueSheet<Sheet_Snowball_SnowballAttackLevel>;
}
//////////////////// spot.spot ////////////////////
export interface Sheet_Spot_Spot {
  readonly id: number; // 角色ID
  readonly unique_id: number; // 剧情id
  readonly type: number; // 剧情类型
  readonly name_chs: string; // 剧情名字
  readonly name_chs_t: string;
  readonly name_jp: string; // 剧情名字JP
  readonly name_en: string; // 剧情名字en
  readonly name_kr: string; // 剧情名字kr
  readonly level_limit: number; // 解锁条件
  readonly is_married: number; // 缔结契约
  readonly lock_tips_chs: string; // 解锁文字
  readonly lock_tips_chs_t: string;
  readonly lock_tips_jp: string; // 解锁文字JP
  readonly lock_tips_en: string; // 解锁文字EN
  readonly lock_tips_kr: string; // 解锁文字kr
  readonly queque: number; // 排序
  readonly content_chs: string; // 文本剧情的内容CH
  readonly content_chs_t: string;
  readonly content_jp: string; // 文本剧情的内容JP
  readonly content_en: string; // 文本剧情的内容En
  readonly content_kr: string; // 文本剧情的内容kr
  readonly content_path: string; // 交互剧情的路径
  readonly jieju: number[]; // 结局奖励id
}
//////////////////// spot.rewards ////////////////////
export interface Sheet_Spot_Rewards {
  readonly id: number; // 奖励ID
  readonly type: number; // 结局种类
  readonly content_chs: string; // 获得条件
  readonly content_chs_t: string;
  readonly content_jp: string;
  readonly content_en: string;
  readonly content_kr: string;
  readonly reward: string; // 奖励物品
}
//////////////////// spot.event ////////////////////
export interface Sheet_Spot_Event {
  readonly id: number; // 唯一id
  readonly activity_id: number; // 活动ID
  readonly key_item_id: number; // 解锁道具id
  readonly key_amount: number; // 解限所需数量，0为不限制
  readonly unlock_task_id: number; // 解锁基础任务id
  readonly sort: number; // 排序从小到大
  readonly unlock_time: string; // 交互剧情的解锁时间
  readonly content_path: string; // 交互剧情的路径
  readonly title_chs: string; // 标题
  readonly title_chs_t: string;
  readonly title_jp: string;
  readonly title_en: string;
  readonly title_kr: string;
  readonly subtitle_chs: string; // 副标题
  readonly subtitle_chs_t: string;
  readonly subtitle_jp: string;
  readonly subtitle_en: string;
  readonly subtitle_kr: string;
  readonly content_chs: string; // 简介
  readonly content_chs_t: string;
  readonly content_jp: string;
  readonly content_en: string;
  readonly content_kr: string;
  readonly ending_id: number[]; // 分支1id
  readonly ending_res: string; // 封面图
}
//////////////////// spot.character_spot ////////////////////
export interface Sheet_Spot_CharacterSpot {
  readonly id: number;
  readonly sort: number; // 递增 数字大的在后
  readonly name_chs: string; // 名称
  readonly name_chs2: string; // 名称
  readonly name_chs_t: string;
  readonly name_chs_t2: string;
  readonly name_jp: string;
  readonly name_jp2: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly open: number; // 是否开放
  readonly init_skin: number; // 初始皮肤
  readonly full_fetter_skin: number; // 满羁绊皮肤
  readonly hand: number; // 默认手
  readonly favorite: number; // 喜好
  readonly star_5_material: string; // 5星突破材料 1-8
  readonly star_5_cost: number; // 5星突破铜币消耗
  readonly can_marry: number; // 是否可缔结契约
  readonly exchange_item_id: number; // 重复兑换物品ID
  readonly exchange_item_num: number; // 重复兑换物品数量
  readonly emo: string; // 表情
  readonly sound: number; // 语音库
  readonly sound_volume: number; // 声音音效修正
  readonly sex: number; // 性别,1女，2:男
  readonly desc_stature_chs: string; // 身高
  readonly desc_stature_chs_t: string; // 身高
  readonly desc_stature_jp: string;
  readonly desc_stature_en: string;
  readonly desc_stature_kr: string;
  readonly desc_birth_chs: string; // 生日
  readonly desc_birth_chs_t: string;
  readonly desc_birth_jp: string;
  readonly desc_birth_en: string;
  readonly desc_birth_kr: string;
  readonly desc_age_chs: string; // 年龄
  readonly desc_age_chs_t: string;
  readonly desc_age_jp: string;
  readonly desc_age_en: string;
  readonly desc_age_kr: string;
  readonly desc_bloodtype_chs: string; // 血型
  readonly desc_bloodtype_chs_t: string; // 血型
  readonly desc_bloodtype_jp: string; // 血型
  readonly desc_bloodtype_en: string; // 血型
  readonly desc_bloodtype_kr: string; // 血型
  readonly desc_cv_chs: string; // 声优
  readonly desc_cv_chs_t: string;
  readonly desc_cv_jp: string;
  readonly desc_cv_en: string;
  readonly desc_cv_kr: string;
  readonly desc_hobby_chs: string; // 爱好
  readonly desc_hobby_chs_t: string;
  readonly desc_hobby_jp: string;
  readonly desc_hobby_en: string;
  readonly desc_hobby_kr: string;
  readonly desc_chs: string; // 档案描述
  readonly desc_item_chs: string;
  readonly desc_chs_t: string;
  readonly desc_item_chs_t: string;
  readonly desc_jp: string;
  readonly desc_item_jp: string;
  readonly desc_en: string;
  readonly desc_item_en: string;
  readonly desc_kr: string;
  readonly desc_item_kr: string;
  readonly collaboration: number; // 联动标记，12的生日=年级，其他的不替换
  readonly skin_lib: number[]; // 皮肤库
  readonly ur: number; // UR标记
  readonly ur_ron: number; // 默认自带和牌
  readonly ur_liqi: number; // 默认自带立直
  readonly ur_cutin: string;
  readonly limited: number; // 期间限定雀士标签
  readonly treasure_sp: number; // 抽卡界面固定在左侧
}
//////////////////// spot.skin_spot ////////////////////
export interface Sheet_Spot_SkinSpot {
  readonly id: number;
  readonly type: number; // 是不是原皮
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly desc_chs: string; // 描述
  readonly desc_chs_t: string; // 描述
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly character_id: number; // 角色id索引
  readonly lock_tips_chs: string; // 未解锁的提示
  readonly lock_tips_chs_t: string;
  readonly lock_tips_jp: string;
  readonly lock_tips_en: string;
  readonly lock_tips_kr: string;
  readonly path: string; // 文件夹路径
  readonly exchange_item_id: number; // 重复兑换物品ID
  readonly exchange_item_num: number; // 重复兑换物品数量
  readonly direction: number; // 立绘朝向1左0右
  readonly no_reverse: number; // 和服不可翻转
  readonly lock_reverse: number; // 全局禁止反转，针对特殊角色
  readonly offset_x: number; // 剧情用偏移
  readonly offset_y: number; // 剧情用偏移
  readonly spot_scale: string; // 剧情用偏移
  readonly effective_time: string; // 生效时间，此服务端时间后才开始展示
  readonly lobby_offset: string; // 大厅偏移数据
  readonly liaoshe_offset: string; // 偏移数据
  readonly shop_offset: string; // 偏移数据
  readonly win_offset: string; // 偏移数据
  readonly gameend_offset: string; // 偏移数据
  readonly starup_offset: string; // 偏移数据
  readonly treasure_offset: string; // 偏移数据
  readonly ck_full_0_offset: string; // 偏移数据
  readonly ck_full_1_offset: string; // 偏移数据
  readonly ck_full_2_offset: string; // 偏移数据
  readonly ck_full_3_offset: string; // 偏移数据
  readonly ck_full_single_offset: string; // 偏移数据
  readonly ck_half_0_offset: string; // 偏移数据
  readonly ck_half_1_offset: string; // 偏移数据
  readonly ck_half_2_offset: string; // 偏移数据
  readonly ck_half_3_offset: string; // 偏移数据
  readonly ck_half_single_offset: string; // 偏移数据
  readonly smallhead_x: number;
  readonly smallhead_y: number;
  readonly smallhead_width: number;
  readonly full_x: number;
  readonly full_y: number;
  readonly full_width: number;
  readonly full_height: number;
  readonly half_x: number;
  readonly half_y: number;
  readonly half_width: number;
  readonly half_height: number;
  readonly spine_type: number;
  readonly spine_width: number;
  readonly spine_height: number;
  readonly pivot_x: number;
  readonly pivot_y: number;
  readonly idle: string;
  readonly greeting: number; // 三项span动画时间
  readonly celebrate: number;
  readonly click: number;
  readonly greeting_init: number;
  readonly click2: number;
  readonly celebrate_idle: number;
  readonly illust_data: string;
  readonly blink: number; // 传记眨眼
}
//////////////////// spot.audio_spot ////////////////////
export interface Sheet_Spot_AudioSpot {
  readonly id: number;
  readonly path: string; // 路径
  readonly time_length: number; // 声音长度
  readonly str: string; // 音效名称
  readonly type: number; // 编辑器用的音乐音效，0=se，1=bgm，2=环境音
}
//////////////////// spot ////////////////////
export interface Table_Spot {
  readonly spot: GroupSheet<Sheet_Spot_Spot>;
  readonly rewards: UniqueSheet<Sheet_Spot_Rewards>;
  readonly event: UniqueSheet<Sheet_Spot_Event>;
  readonly character_spot: UniqueSheet<Sheet_Spot_CharacterSpot>;
  readonly skin_spot: UniqueSheet<Sheet_Spot_SkinSpot>;
  readonly audio_spot: UniqueSheet<Sheet_Spot_AudioSpot>;
}
//////////////////// str.str ////////////////////
export interface Sheet_Str_Str {
  readonly id: number;
  readonly type: string;
  readonly chs: string;
  readonly chs_t: string;
  readonly jp: string;
  readonly en: string;
  readonly kr: string;
}
//////////////////// str.event ////////////////////
export interface Sheet_Str_Event {
  readonly id: number;
  readonly type: string;
  readonly chs: string;
  readonly chs_t: string;
  readonly jp: string;
  readonly en: string;
  readonly kr: string;
}
//////////////////// str ////////////////////
export interface Table_Str {
  readonly str: UniqueSheet<Sheet_Str_Str>;
  readonly event: UniqueSheet<Sheet_Str_Event>;
}
//////////////////// tournament.tournaments ////////////////////
export interface Sheet_Tournament_Tournaments {
  readonly id: number;
  readonly name: string; // 比赛名称
  readonly game_ticket_id: number; // 参与比赛门票Id
}
//////////////////// tournament ////////////////////
export interface Table_Tournament {
  readonly tournaments: UniqueSheet<Sheet_Tournament_Tournaments>;
}
//////////////////// tutorial.init ////////////////////
export interface Sheet_Tutorial_Init {
  readonly episode_id: number; // 1-4章
  readonly dora: string; // 宝牌指示牌
  readonly rival: string; // 四家的头像(东-南-西-北)
  readonly init_score: string; // 四家的初始点数
  readonly paihe: string; // 四家牌河，格式：1m,2m,.....3m;1m,2m,.....3m;1m,2m,.....3m;1m,2m,.....3m
  readonly chang: number; // 场（0-1）
  readonly ju: number; // 局（0-3）
  readonly benchang: number; // 0本场，可以写死0
  readonly first_position: number; // 第一回合谁开始打，默认0东家
  readonly view_position: number; // 本局主视角的方位
  readonly start_shoupai: string; // 主视角的初始配牌
  readonly start_ming: string; // 初始鸣牌（如果有的话）
  readonly end_shoupai: string; // 主视角的和牌型
  readonly end_ming: string; // 和牌时显示
  readonly end_yaku: string; // 和牌后的报菜名
  readonly ura_dora: string; // 里宝牌指示牌（如果有）
  readonly end_fu: number; // 符数
  readonly hu_score: number; // 和牌点数
  readonly flow_score: string; // 收取下家-对家-上家点数
}
//////////////////// tutorial.step ////////////////////
export interface Sheet_Tutorial_Step {
  readonly episode_id: number; // 章节1234
  readonly id: number; // 唯一步骤id
  readonly seat: number; // 0123=东一局的东南西北
  readonly act_type: number; // 0=摸牌，1=打牌，2=吃牌 3=碰牌，4=暗杠，7=立直 8=自摸，9=荣和， 999= 无action，1000=结束文本
  readonly act_param: string; // 行动的额外参数
  readonly tingpai_param: string; // 听的牌，逗号分隔
  readonly is_zhenting: number; // 1=振听，空/0=没振
  readonly str_type: number; // 0=底部文本，1=顶部文本
  readonly str_id: number; // 教学文本，可能连续播放
  readonly view_ui_hand: number; // 1=UI手牌高亮
  readonly pic_path: string; // 教学图路径，可能为空
  readonly button_show: string; // 哪些吃碰按钮会出现，2=吃，3=碰，7=立直，8=自摸和，9 = 荣和，4=暗杠，5=明杠，6=加杠
  readonly button_pai: string; // 点了按钮后，手牌中哪些牌被移除例5m,6m
  readonly player_act: number; // 玩家行为，0=无行为，1=选按钮, 2=选牌,3=选红色标记，4=选余牌，5=选自风指示，6=选宝牌指示区域

  readonly player_param: string; // 参数
}
//////////////////// tutorial ////////////////////
export interface Table_Tutorial {
  readonly init: UniqueSheet<Sheet_Tutorial_Init>;
  readonly step: GroupSheet<Sheet_Tutorial_Step>;
}
//////////////////// vip.vip ////////////////////
export interface Sheet_Vip_Vip {
  readonly id: number;
  readonly name_chs: string; // 称号名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly img: string; // 称号图标
  readonly desc_chs: string; // 等级描述
  readonly desc_chs_t: string;
  readonly desc_jp: string;
  readonly desc_en: string;
  readonly desc_kr: string;
  readonly charge: number; // 所需累计充值金额
  readonly gift_limit: number; // 每日送礼次数上限
  readonly friend_added: number; // 增加好友上限
  readonly shop_free_refresh: number; // 商店每日免费刷新次数
  readonly shop_refresh_limit: number; // 商店每日刷新次数上限
  readonly buddy_bonus: number; // 对局好感度加成
  readonly favourite_limit: number; // 牌谱收藏上限
  readonly title_id: number; // 称号ID
  readonly rewards: string[]; // VIP领取奖励
}
//////////////////// vip ////////////////////
export interface Table_Vip {
  readonly vip: UniqueSheet<Sheet_Vip_Vip>;
}
//////////////////// voice.sound ////////////////////
export interface Sheet_Voice_Sound {
  readonly id: number;
  readonly name_chs: string; // 名称
  readonly name_chs_t: string;
  readonly name_jp: string;
  readonly name_en: string;
  readonly name_kr: string;
  readonly words_chs: string; // 台词
  readonly words_chs_t: string;
  readonly words_jp: string;
  readonly words_en: string;
  readonly words_kr: string;
  readonly category: number; // 1.lobby,2.mj
  readonly type: string; // 类型
  readonly level_limit: number; // 羁绊等级限制
  readonly bond_limit: number; // 契约限制 0无限制1限制
  readonly time_length: number; // 音效长度
  readonly path: string; // 语音路径
  readonly hide: number; // 不在语音列表内显示
  readonly date_limit: string; // 限定展示日期
}
//////////////////// voice.event ////////////////////
export interface Sheet_Voice_Event {
  readonly id: number;
  readonly words_chs: string; // 台词
  readonly words_chs_t: string;
  readonly words_jp: string;
  readonly words_en: string;
  readonly words_kr: string;
  readonly category: number; // 1.lobby,2.mj
  readonly type: string; // 类型/玩家操作
  readonly stage: number; // 好感度阶段
  readonly time_length: number; // 音效长度
  readonly path: string; // 语音路径
  readonly volume_fix: number; // 声音音效修正
}
//////////////////// voice.spot ////////////////////
export interface Sheet_Voice_Spot {
  readonly id: number;
  readonly character: number;
  readonly type: number; // 语音种类14种，定义见右侧
  readonly path: string; // 语音路径
  readonly type_desc: string; // 编辑器内名称
}
//////////////////// voice ////////////////////
export interface Table_Voice {
  readonly sound: GroupSheet<Sheet_Voice_Sound>;
  readonly event: GroupSheet<Sheet_Voice_Event>;
  readonly spot: UniqueSheet<Sheet_Voice_Spot>;
}




export interface SheetField {
  field_name: string;
  array_length: number;
  pb_type: string;
}

export interface SheetMeta {
  category: 'unique' | 'nokey' | 'group' | 'kv'; // 四种类型：唯一、无键、分组、KV对
  key: string;
}

export interface SheetRawData {
  table: string; // excel 名字
  sheet: string; // sheet 名字
  meta: SheetMeta; // sheet meta 信息
  header: SheetField[]; // sheet 结构信息
  rows: any[]; // sheet 行数据
}

}

class cfg {
  static readonly ab_match: lqc.Table_AbMatch;
  static readonly achievement: lqc.Table_Achievement;
  static readonly activity: lqc.Table_Activity;
  static readonly amulet: lqc.Table_Amulet;
  static readonly animation: lqc.Table_Animation;
  static readonly audio: lqc.Table_Audio;
  static readonly character: lqc.Table_Character;
  static readonly chest: lqc.Table_Chest;
  static readonly compose: lqc.Table_Compose;
  static readonly contest: lqc.Table_Contest;
  static readonly desktop: lqc.Table_Desktop;
  static readonly events: lqc.Table_Events;
  static readonly exchange: lqc.Table_Exchange;
  static readonly fan: lqc.Table_Fan;
  static readonly fandesc: lqc.Table_Fandesc;
  static readonly game_live: lqc.Table_GameLive;
  static readonly global: lqc.Table_Global;
  static readonly info: lqc.Table_Info;
  static readonly item_definition: lqc.Table_ItemDefinition;
  static readonly leaderboard: lqc.Table_Leaderboard;
  static readonly level_definition: lqc.Table_LevelDefinition;
  static readonly mail: lqc.Table_Mail;
  static readonly mall: lqc.Table_Mall;
  static readonly marathon: lqc.Table_Marathon;
  static readonly match_shilian: lqc.Table_MatchShilian;
  static readonly misc_function: lqc.Table_MiscFunction;
  static readonly mmo: lqc.Table_Mmo;
  static readonly outfit_config: lqc.Table_OutfitConfig;
  static readonly quest_crew: lqc.Table_QuestCrew;
  static readonly rank_introduce: lqc.Table_RankIntroduce;
  static readonly season: lqc.Table_Season;
  static readonly shoot: lqc.Table_Shoot;
  static readonly shops: lqc.Table_Shops;
  static readonly simulation: lqc.Table_Simulation;
  static readonly snowball: lqc.Table_Snowball;
  static readonly spot: lqc.Table_Spot;
  static readonly str: lqc.Table_Str;
  static readonly tournament: lqc.Table_Tournament;
  static readonly tutorial: lqc.Table_Tutorial;
  static readonly vip: lqc.Table_Vip;
  static readonly voice: lqc.Table_Voice;

  static load(sheets: lqc.SheetRawData[]) {
    const tmpLoad: any = {};

    sheets.forEach(sheet => {
      if (!tmpLoad[sheet.table]) {
        tmpLoad[sheet.table] = {};
      }

      let rows = [];

      sheet.rows.forEach(row => {

        const tsrow: any = {};
        sheet.header.forEach(field => {
          tsrow[field.field_name] = row[field.field_name];
        });

        rows.push(tsrow);
      });

      let configSheet: any = null;
      switch (sheet.meta.category)  {
        case 'unique':
        {
          configSheet = new lqc.UniqueSheet(sheet.table, sheet.sheet, rows, sheet.meta.key);
          break;
        }
        case 'nokey':
        {
          configSheet = new lqc.NoKeySheet(sheet.table, sheet.sheet, rows);
          break;
        }
        case 'group':
        {
          configSheet = new lqc.GroupSheet(sheet.table, sheet.sheet, rows, sheet.meta.key);
          break;
        }
        case 'kv':
        {
          configSheet = {};
          rows.forEach(row => {
            let key = row[sheet.meta.key];
            configSheet[key] = row;
          });
          break;
        }
      }

      if (configSheet)
        tmpLoad[sheet.table][sheet.sheet] = configSheet;
    });

    // resolve reference

    Object.keys(tmpLoad).forEach(table => {
      this[table] = tmpLoad[table];
    });
  }
}
