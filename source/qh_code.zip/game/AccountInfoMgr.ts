module game {
    /**
     * 账号信息管理
     */
    export class AccountInfoMgr{
        private static _inst: AccountInfoMgr;
        public static get Inst(): AccountInfoMgr {
            if (!AccountInfoMgr._inst) {
                AccountInfoMgr._inst = new AccountInfoMgr();
            }
            return AccountInfoMgr._inst;
        }
        private badgesData: Array<game.IAccount_Badge> = [];
        private baseData: game.IAccount = null;

        public get data(): game.IAccount {
            return this.baseData;
        }

        public updateData(data: game.IAccount) { 
            if (this.baseData == null) {
                this.baseData = data;
            }
            else {
                //只有部分数据更新
                for (let k in data) {
                    this.baseData[k] = data[k];
                }
            }
            if (data.badges) {
                this.updateBadges(data.badges);
            }
            
        }

        public get badgeData(): Array<game.IAccount_Badge> { 
            return this.badgesData;
        }

        /**
         * 更新徽章数据
         * @param data 
         */
        private updateBadges(data: Array<game.IAccount_Badge>) { 
            //统计产生变化的数据
            let oldDatas = this.badgesData;
            this.badgesData = data;
            //比较数据
            let diffData = [];
            for (let i = 0; i < data.length; i++) {
                let old = oldDatas.find(predicate => predicate.id == data[i].id);
                let dataChange = {id: data[i].id, changeCount: data[i].achieved_counter};
                if (!old && dataChange.changeCount > 0) {
                    diffData.push(dataChange);
                } else {
                    if (old && old.achieved_counter != data[i].achieved_counter) {
                        dataChange.changeCount = data[i].achieved_counter - old.achieved_counter;
                        diffData.push(dataChange);
                    }
                }
            }
            app.Log.log("徽章数据变化:"+JSON.stringify(diffData));
            Laya.stage.event(EventCode.BADGE_DATA_UPDATE, [diffData]);
        }


    }
}
