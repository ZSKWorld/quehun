/**
* name 
*/
module game{

	export abstract class ChatInfoBase {
		public timeStamp:number;
		abstract init(data:Object);
		abstract get height():number;
		abstract get width():number;
		abstract render(container:Laya.Sprite);

		public static Create(data:Object):ChatInfoBase {
			let _info:ChatInfoBase = null;
			switch(data['t']) {
				case 's': _info = new ChatInfo_Str(); _info.init(data); break;
			}
			return _info;
		}
	}

	export class ChatInfo_Str extends ChatInfoBase { 
		private val:string;
		private _height:number;
		private _width:number;

		public init(data:Object) {
			this.val = data['v'];
			let _text:Laya.Text = uiscript.UI_LobbyChat.Inst.render_text;
			_text.text = this.val;
			this._height = _text.textWidth;
			this._height = _text.textHeight;
		}

		public get height(): number { return this._height; }
		public get width(): number { return this._width; }

		public render(container:Laya.Sprite) {
			let _text:Laya.Text = container.getChildByName('word') as Laya.Text;
			_text.text = this.val;
			_text.visible = true;
		}
	}

	export class PersonChat {
		public account_id:number;
		public infos:Array<{info: ChatInfoBase, isme:boolean}> = [];
		public lastTimeStamp:number = 0;

		public constructor( account_id:number) {
			this.account_id = account_id;
			this.infos = [];
			this.lastTimeStamp = 0;
		}

		public addInfo(timeStamp:number, data:string, isme:boolean):boolean {
			let _info:ChatInfoBase = ChatInfoBase.Create(JSON.parse(data));
			if (_info == null) {
				app.Log.Error('未找到合适的聊天类型 data:' + data);
				return false;
			} else {
				_info.timeStamp = timeStamp;
				this.infos.push({info: _info, isme: isme});
				this.lastTimeStamp = timeStamp;
				return true;
			}
		}
	}

	export class ChannelChat {
		public infos:Array<Object> = [];

		public constructor() {

		}

		public addInfo(msg:Object):boolean {
			let _info:ChatInfoBase = ChatInfoBase.Create(msg['content']);
			if (_info != null) {
				this.infos.push(msg);
				return true;
			} else {
				return false;
			}
		}
	}

	export class ChatMgr {
		public static Inst: ChatMgr;

		public chat_world:ChannelChat = null;
		public friend_chat:Array<PersonChat> = [];

		public static init() {
			this.Inst = new ChatMgr();
			this.Inst._init();
		}

		private _init() {
			this.chat_world = new ChannelChat();
			this.friend_chat = [];
			app.NetAgent.addListener2Lobby('NotifyChatMessage', Laya.Handler.create(this, this._onReceiveChat, null, false));
		}

		private _onReceiveChat(msg) {
			let type:number = msg['type'];
			if (type == 1) {
				if (msg['world_chat']) {
					this.chat_world.addInfo(msg['world_chat']);
				}
			} else {
				if (msg['private_chat']) {
					let __data:Object = msg['private_chat'];
					let friend_account_id:number = 0;
					let isme:boolean = false;
					if (__data['sender_id'] == GameMgr.Inst.account_id) {
						isme = true;
						friend_account_id = __data['target_id'];
					} else {
						isme = false;
						friend_account_id = __data['sender_id'];
					}

					let chat:PersonChat = this.findFriend(friend_account_id);
					chat.addInfo(__data['timestamp'], __data['content'], isme);
				}
			}
		}

		public findFriend(account_id:number): PersonChat {
			let chat:PersonChat = null;
			for (let i:number = 0; i < this.friend_chat.length; i++) {
				if (this.friend_chat[i].account_id == account_id) {
					chat = this.friend_chat[i];
					break;
				}
			}
			if (chat == null) {
				chat = new PersonChat(account_id);
				this.friend_chat.push(chat);
			}
			return chat;
		}

	}
}