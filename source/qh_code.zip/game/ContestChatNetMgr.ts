/**
* name 
*/
module game {
	const reconnect_span: Array<number> = [1000, 2000, 4000, 4000, 4000];

	export class ContestChatNetMgr {

		private static _Inst: ContestChatNetMgr = null;
		public static get Inst(): ContestChatNetMgr {
			return this._Inst == null ? (this._Inst = new ContestChatNetMgr()) : this._Inst;
		}
		private _routeID: string;
		private _tokenUrl: string;
		public set tokenUrl(url: string) {
			this._tokenUrl = url;
		}
		private _socket: net.ContestChatSocket;
		private lasterrortime: number = 0;
		private _connect_state: EConnectState;
		private _reconnect_count: number = 0; // 重连次数
		private _reconnect_failed_time: number = 0;

		private sending_heart: boolean = false;

		private _open_func: Laya.Handler;
		private _fetch_seq_func: Laya.Handler;
		private _close_func: Laya.Handler;

		private _heart_id: number = 0;

		public get connect_state(): EConnectState { return this._connect_state; }
		public get socket(): net.ContestChatSocket { return this._socket; }

		public constructor() {
			this._socket = new net.ContestChatSocket(Laya.Handler.create(this, this.onReceiveMsgError, null, false));
		}

		public connect(token: string, func: Laya.Handler, fetch_seq_func: Laya.Handler, _close_func?: Laya.Handler) {
			this.clearTimer();
			this._socket.addSocketLister(new Laya.Handler(this, this._onConnent));
			this._set_connect_state(EConnectState.tryconnect);
			this._routeID = net.NetRouteGroup.Inst.getMainRouteID();
			this.tokenUrl = net.NetRouteGroup.Inst.getChoosedUrl() + '/contest-chat?stream=binary&token=' + token;
			let url = this._tokenUrl + '&support_id=true&message_id=' + uiscript.UI_Match_Room.Inst.getLastChatId(uiscript.EChatMsgType.message)
				+ '&system_id=' + uiscript.UI_Match_Room.Inst.getLastChatId(uiscript.EChatMsgType.system);
			this._socket.connect(this._routeID, url);
			this._open_func = func;
			this._fetch_seq_func = fetch_seq_func;
			this._close_func = _close_func;
			this._reconnect_count = 0;
		}

		public sendMessage(msg: string, func_response: (error, res) => void) {
			this._socket.sendMessage(msg, func_response);
		}

		private _onConnent(event: string): void {
			if (event == Laya.Event.CLOSE || event == Laya.Event.ERROR) {
				if (Laya.timer.currTimer - this.lasterrortime > 100) { // 由于有时候 error和close事件会同时过来
					this.lasterrortime = Laya.timer.currTimer;
					if (this.connect_state == EConnectState.tryconnect) {
						this._try_reconnect();
					} else if (this.connect_state == EConnectState.connecting) {
						if (uiscript.UI_Match_Room.Inst && uiscript.UI_Match_Room.Inst.enable) {
							this._set_connect_state(EConnectState.reconnecting);
							this._reconnect_count = 0;
							this._try_reconnect();
							this.showSystemTip(10103);
						} else {
							//UI_Match_Room已经关闭
							this._set_connect_state(EConnectState.disconnect);
						}
					} else if (this.connect_state == EConnectState.reconnecting) {
						this._try_reconnect();
					}
					if (this._close_func) {
						this._close_func.run();
					}
				}
			} else if (event == Laya.Event.OPEN) {
				// 重连次数清零
				this._reconnect_count = 0;
				if (this.connect_state == EConnectState.tryconnect) {
					this._set_connect_state(EConnectState.connecting);
					if (this._open_func) this._open_func.runWith({ open: true });
				} else if (this.connect_state == EConnectState.reconnecting) {
					// 重连次数+1
					this._set_connect_state(EConnectState.connecting);
					if (this._open_func) this._open_func.runWith({ open: true });
					this.showSystemTip(10104);
				} else if (this.connect_state != EConnectState.connecting) {
					this.close();
				}
			}
		}

		private _try_reconnect() {
			if (this._reconnect_count >= reconnect_span.length) {
				app.Log.log('ContestChat重连失败');
				// 防止error和close同时触发
				if (Laya.timer.currTimer - this._reconnect_failed_time > 3000 && this._open_func) {
					this._open_func.runWith({ open: false, info: this.connect_state == EConnectState.reconnecting ? 'disconnect' : 'connect failed' });
				}
				this._set_connect_state(EConnectState.disconnect);
				this.showSystemTip(10105);
				this._reconnect_failed_time = Laya.timer.currTimer;
			} else {
				Laya.timer.once(reconnect_span[this._reconnect_count], this, () => {
					if (this.connect_state == EConnectState.reconnecting || this.connect_state == EConnectState.tryconnect) {
						app.Log.log('ContestChatNetMgr _Reconnect  count:' + this._reconnect_count);
						let url = this._tokenUrl + '&support_id=true&message_id=' + uiscript.UI_Match_Room.Inst.getLastChatId(uiscript.EChatMsgType.message)
							+ '&system_id=' + uiscript.UI_Match_Room.Inst.getLastChatId(uiscript.EChatMsgType.system);
						this._socket.connect(this._routeID, url);
					}
				});
				this._reconnect_count++;
			}
		}

		private _set_connect_state(v: EConnectState) {
			this._connect_state = v;
		}

		public close(): void {
			this._heart_id = 0;
			this._set_connect_state(EConnectState.none);
			this._socket.close();
			this.clearTimer();
		}

		public onReceiveMsgError(data: any) {

		}

		public addListener(name: string, handler: Laya.Handler) {
			handler.once = false;
			this._socket.addMsgListener(name, handler);
		}

		public removeListener(name: string, handler: Laya.Handler) {
			this._socket.removeMsgListener(name, handler);
		}

		public force_reconnect() {
			this._reconnect_count = 0;
			this._set_connect_state(EConnectState.reconnecting);
			this._try_reconnect();
		}

		// seq失败
		public on_seq_error(seq_1: number, seq_2: number) {
			this.sending_heart = false;
			if (this._connect_state != EConnectState.none) {
				this.close();
				Laya.timer.once(150, this, this.force_reconnect);
			} else {
				this.force_reconnect();
			}
			// GameMgr.Inst.onGuanzhanError('seq检验失败: fetch:' + seq_1 + '  local:' + seq_2);
		}

		public clearTimer() {
			Laya.timer.clearAll(this);
			this.sending_heart = false;
		}

		//提示断线重连等信息，模拟一个系统消息
		private showSystemTip(strId: number) {
			let tipStr = game.Tools.strOfLocalization(strId);
			this._socket.sendSystemMsg({
				type: 'client_system',
				content: tipStr
			});
		}
	}
}