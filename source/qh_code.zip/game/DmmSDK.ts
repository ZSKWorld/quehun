/**
* name 
*/
module game{
	export class DmmSDK {

		public static login() {
			let url:string = GameMgr.config_data['dmm_url'];  // 实际使用地址
			// let url = 'http://www.dmm.com/netgame/channeling/-/login/index/'
			// let url:string = 'http://sbx-browsergame.dmm.com/login/'; // 开发地址

			var xhr = new Laya.HttpRequest();
			xhr.once(Laya.Event.COMPLETE,this, (data)=>{
				let d = JSON.parse(data);
				Laya.Browser.window.location.href = url + '?p=' + d['parameter'];
			});
			xhr.once(Laya.Event.ERROR,this, (e)=>{
				uiscript.UI_Entrance.Inst.showError('prelogin not found');
			});
			xhr.send(GameMgr.system_email_url + '/api/user/dmm_pre_login',
			 `finish_url=${GameMgr.Inst.link_url}`,
			// `finish_url=http://192.168.1.105:8900/bin/index.html`,
			 "post"); 
		}

		// 购买
		public static recharge(goods_id: number) {
			//充值地址需要在线上换为https的地址
			let url: string = GameMgr.config_data['dmm_url'];
			if (GameMgr.config_data['dmm_recharge_url'] && GameMgr.inRelease) {
				url = GameMgr.config_data['dmm_recharge_url'];
			}
			url = url.replace('login', 'item');  // 实际使用地址
			// let url = http://www.dmm.com/netgame/channeling/-/item/index/
			// let url:string = 'http://sbx-browsergame.dmm.com/item/'; // 开发地址

			uiscript.UI_Lite_Loading.Inst.show();
			app.NetAgent.sendReq2Lobby('Lobby', `createDMMOrder`, {
				goods_id: goods_id,
				client_type: 1,
				account_id: GameMgr.Inst.account_id,
				client_version_string: GameMgr.Inst.getClientVersion()
			}, (err, res) => {
				if (err || res['error']) {
					uiscript.UI_Lite_Loading.Inst.close();
					uiscript.UIMgr.Inst.showNetReqError('createDMMOrder', err, res);
				} else {
					let d_product = cfg.mall.product.getGroup(70);
					let prize:number = 0;
					let is_monthcard:boolean = false;
					let _name:string = '';
					for (let i:number = 0; i < d_product.length; i++) {
						if (d_product[i].goods_id == goods_id) {
							prize = d_product[i].currency_price;
							if (d_product[i].product_type == 2) {
								_name = cfg.mall.month_ticket.get(goods_id)['name_jp'];
							} else {
								_name = cfg.mall.goods.get(goods_id)['name_jp'];
							}
						}
					}
					let finishpage_url = GameMgr.Inst.link_url;
					let _index:number = -1;
					for (let i:number = finishpage_url.length - 1; i >= 0; i--) {
						if (finishpage_url[i] == '/') {
							_index = i;
							break;
						}
					}
					if (_index != -1) {
						finishpage_url = finishpage_url.substr(0, _index) + '/close.html';
					}
					let params:Object = {
						transaction_id: res['transaction_id'],
						dmm_app_id: res['dmm_app_id'],
						dmm_user_id: res['dmm_user_id'],
						token: res['token'],
						order_id: res['order_id'],
						callback_url: res['callback_url'],
						finishpage_url: finishpage_url, //
						request_time: res['request_time'],
						item_id: goods_id,
						item_name: _name,
						unit_price: prize / 1000,
						quantity: 1,
						is_test: 0, // 0=正式，1=测试
					};
					if (url.startsWith("https")) {
						let newUrl = url + "?";
						let index = 0;
						for (var key in params) {
							if (index++ != 0) {
								newUrl += "&"
							}
							newUrl += key + "=" + params[key];
						}
						game.Tools.open_new_window(newUrl);
					} else {
						game.Tools.formPost(url, params, false);
					}
					
					Laya.timer.once(1000, this, () => {
						uiscript.UI_Lite_Loading.Inst.close();
					});
				}
			});
		}

	}
}