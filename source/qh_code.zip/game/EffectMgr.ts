/**
* name 
*/
module game {

	class AssetMgr {
		private static _refrence_map:Object = {}; // 图片、材质等资源的引用计数

		public static add_refrence(asset_url:string, effect_url:string) {
			if (!this._refrence_map[asset_url]) {
				this._refrence_map[asset_url] = [];
			}
			this._refrence_map[asset_url].push(effect_url);
		}

		public static remove_refrence(asset_url:string, effect_url:string) {
			let lst_old:Array<string> = this._refrence_map[asset_url];
			if (!lst_old || lst_old.length == 0) {
				app.Log.log(`资源并未记录1, assetUrl:${asset_url}, effectUrl:${effect_url}`);
				return;
			}
			let lst_new:Array<string> = [];
			let haved:boolean = false;
			for (let i:number = 0; i < lst_old.length; i++) {
				let s:string = lst_old[i];
				if (haved || s != effect_url) {
					lst_new.push(s);
				} else {
					haved = true;
				}
			}
			if (!haved) {
				app.Log.log(`资源并未记录2, assetUrl:${asset_url}, effectUrl:${effect_url}`);
			} else {
				this._refrence_map[asset_url] = lst_new;
				if (lst_new.length == 0) {
					let __r = Laya.loader.getRes(asset_url);
					if (__r) {
						if (__r.clearTexture) __r.clearTexture();
						else __r.dispose();
					}
					Laya.loader.clearRes(asset_url);
				}
			}
		}

		public static get_count(asset_url:string) {
			let lst:Array<string> = this._refrence_map[asset_url];
			if (!lst) return 0;
			return lst.length;
		}
	}

	export class EffectBase {

		public url:string;
		private _loaded:boolean = false;
		private _destroyed:boolean = false;
		private _root:Laya.Sprite3D = null;

		public get loaded(): boolean { return this._loaded; }
		public get destroyed(): boolean { return this._destroyed; }
		public get root():Laya.Sprite3D { return this._root; }
		public get effect_root():Laya.Sprite3D { return this._effect; }

		private _effect:Laya.Sprite3D = null;
		private _when_loaded:Laya.Handler = null;

		public constructor(url:string) {
			this.url = url;
			this._loaded = false;
			this._destroyed = false;

			this._root = new Laya.Sprite3D();
			this._root.active = true;
			
			let self = this;
			this._root.on('undisplay', this, ()=>{
				if (!self._root.destroyed) return;
				if (self._destroyed) return;
				self.destroy();
			});
			EffectMgr.try2get_effect(url, Laya.Handler.create(this, _effect => {
				if (this._root == null || this._root.destroyed || this._destroyed) {
					_effect.destroy(true);
					EffectMgr.on_effectbase_destory(this.url, _effect);
				} else {
					this._loaded = true;
					if (_effect && _effect instanceof Laya.Sprite3D) {
						this._effect = _effect;
						this._root.addChild(this._effect);
						this._effect.transform.localPosition = new Laya.Vector3(0, 0, 0);
						this._effect.active = true;
					}
					if (this._when_loaded != null) this._when_loaded.run();
				}
			}));
		}

		public addLoadedListener(handler:Laya.Handler) {
			if (this.loaded) handler.run();
			else this._when_loaded = handler;
		}

		public destroy() {
			if (this._destroyed) return;
			this._destroyed = true;
			if (this._root && !this._root.destroyed) {
				this._root.destroy(true);
			}
			if (this._loaded) {
				this._effect.destroy(true);
				EffectMgr.on_effectbase_destory(this.url, this._effect);
			}
		}

		public clone():EffectBase {
			return new EffectBase(this.url);
		}
	}
	// 特效状态 0:未加载进内存，1：正在加载进内存，2：已经在内存里
	enum EEffectStatus { none, loading, loaded};
	export class EffectMgr {

		public static d3res_map:Object = null; //特效和资源对应表

		private static _effect_status:{[key: string]: {status: number, count: EEffectStatus, listeners: Array<Laya.Handler>, gameObjects: Array<Laya.Sprite3D>}} = {}; // 当前特效状态，是否加载完，以及计数

		public static init(complete:Laya.Handler) {
			Laya.loader.load('d3_prefab.json', Laya.Handler.create(this, ()=>{
				this.d3res_map = Laya.loader.getRes('d3_prefab.json');
				let eternal_res:Array<string> = this.d3res_map['eternal_res'];
				for (let i:number = 0; i < eternal_res.length; i++) {
					let _res:string = eternal_res[i];
					AssetMgr.add_refrence(_res, 'eternal_res');
				}
				if (complete) complete.run();
			}));
		}

		public static try2get_effect(url:string, complete:Laya.Handler) {
			if (!this._effect_status.hasOwnProperty(url) || this._effect_status[url].status == 0) {
				this._effect_status[url] = {
					status: 0,  //0:未加载进内存，1：正在加载进内存，2：已经在内存里
					count: 0,
					listeners: [],
					gameObjects: []
				};
			}
			if (this._effect_status[url].status == 0) {
				this._effect_status[url].listeners.push(complete);
				this._effect_status[url].status = 1;
				if (this.d3res_map.hasOwnProperty(url)) {
					let _lst = this.d3res_map[url];
					for (let j:number = 0; j < _lst.length; j++) {
						AssetMgr.add_refrence(_lst[j], url);
					}
				}
				Laya.loader.create(url, Laya.Handler.create(this, ()=>{
					this._effect_status[url].status = 2;
					let _r:Laya.Sprite3D = Laya.loader.getRes(url);
					_r.active = false;
					let rs:Array<Laya.Sprite3D> = [];
					rs.push(_r);
					for (let i:number = 1; i < this._effect_status[url].listeners.length; i++) {
						rs.push(_r.clone());
					}
					this._effect_status[url].gameObjects = rs;
					for (let i:number = 0; i < this._effect_status[url].listeners.length; i++) {
						this._effect_status[url].listeners[i].runWith(rs[i]);
					}
					this._effect_status[url].listeners = [];
				}), null, null, [], 0);
			} else if (this._effect_status[url].status == 1) {
				this._effect_status[url].listeners.push(complete);
			} else {
				if (this._effect_status[url].gameObjects.length == 0) {
					this._effect_status[url].status = 0;
					this.try2get_effect(url, complete);
				} else {
					if (this._effect_status[url].gameObjects[0].destroyed){
						this._effect_status[url].status = 0;
						this.try2get_effect(url, complete);
					} else {
						let go = this._effect_status[url].gameObjects[0].clone();
						this._effect_status[url].gameObjects.push(go);
						complete.runWith(go);
					}
					
				}
			}
		}

		public static on_effectbase_destory(url:string, gameObject:Laya.Sprite3D) {
			if (this._effect_status.hasOwnProperty(url)) {
				let lst_new = [];
				let lst_old = this._effect_status[url].gameObjects;
				for (let i:number = 0; i < lst_old.length; i++) {
					let go:Laya.Sprite3D = lst_old[i];
					if (!go || go.destroyed) continue;
					if (go === gameObject) go.destroy(true);
					else lst_new.push(go);
				}

				if (lst_new.length <= 0) {
					this._effect_status[url].status = 0;
					if (this.d3res_map.hasOwnProperty(url)) {
						let _lst = this.d3res_map[url];
						for (let j:number = 0; j < _lst.length; j++) {
							AssetMgr.remove_refrence(_lst[j], url);
						}
					}
				} else {
					this._effect_status[url].gameObjects = lst_new;
				}
				// console.log(url + ' count:' + lst_new.length);
			}
		}

		//外部强制释放3d资源，如lobby场景资源
		public static force_dispose_3d_res(url:string) {
			let _lst = this.d3res_map[url];
			if (!_lst) return;
			for (let i:number = 0; i < _lst.length; i++) {
				let _res = Laya.loader.getRes(_lst[i]);
				if (_res) _res.dispose();
			}
		}

		//预热3d特效
		public static preheat_3d_effect(urls:Array<string>, root:Laya.Scene, is_ui:boolean, complete?:Laya.Handler, progress?:Laya.Handler) {
			let _urls:Array<string> = [];
			let _url_map:Object = {};
			for (let i:number = 0; i < urls.length; i++) {
				let __url:string = urls[i];
				if (!_url_map[__url]) {
					_url_map[__url] = 1;
					_urls.push(__url);
					if (this.d3res_map.hasOwnProperty(__url)) {
						let ress = this.d3res_map[__url];
						for (let j:number = 0; j < ress.length; j++) {
							let _res = ress[j];
							AssetMgr.add_refrence(_res, __url);
						}
					}
				}
			} 

			this._prehead_3d_effect(_urls, root, is_ui, complete, progress);
		}

		private static _prehead_3d_effect(urls:Array<string>, root:Laya.Scene, is_ui:boolean, complete?:Laya.Handler, progress?:Laya.Handler) {
			if (urls.length == 0) {
				if (progress) progress.runWith(1);
				if (complete) complete.run();
				return;
			}
			let index:number = 0;
			let limt_count:number = is_ui ? 8 : 5;//同时预热的数量

			if (progress) progress.runWith(0);
			let load = () => {
				if (index >= urls.length) {
					for (let i:number = 0; i < urls.length; i++) {
						
						// 美服韩服测试服预热后不清资源，测试时候网巨差 清除后特效无法正常预览
						if (!GameMgr.inHttps && (GameMgr.client_type == 'kr' || GameMgr.client_type == 'en')) {
							if (progress) progress.runWith(1);
							if (complete) complete.run();
							return;
						}

						let __url:string = urls[i];
						if (this.d3res_map.hasOwnProperty(__url)) {
							let ress = this.d3res_map[__url];
							for (let j:number = 0; j < ress.length; j++) {
								AssetMgr.remove_refrence(ress[j], __url);
							}
							
						}
					}

					if (progress) progress.runWith(1);
					if (complete) complete.run();
					return;
				}
				if (progress) progress.runWith(index / urls.length);
				let _lst:Array<string> = [];
				for (let i:number = 0; i < limt_count && index < urls.length; i++) {
					_lst.push(urls[index++]);
				}

				Laya.loader.create(_lst, Laya.Handler.create(this, ()=>{
					Laya.timer.frameOnce(1, this,  () => {
						let max_t:number = 50;
						for (let i:number = 0; i < _lst.length; i++) {
							let _url:string = _lst[i]['url'];
							let t:number = 50;
							let e:Laya.Sprite3D = Laya.loader.getRes(_url);
							if (e) {
								this.dfsCompileShader(root, e);
								// if (GameMgr.inHttps) {
									Laya.timer.frameOnce(1, this, () => {
										let _e = Laya.loader.getRes(_url);
										if (_e) _e.destroy(true);
									});
								// }
								
							} else {
								let _errorinfo:Object = {};
								_errorinfo['error'] = 'preheart effect url:' + _url + ' =null';
								_errorinfo['stack'] = '';
								_errorinfo['method'] = '_prehead_3d_effect';
								_errorinfo['name'] = '_prehead_3d_effect';
								GameMgr.Inst.onFatalError(_errorinfo, false);
							}
						}
						Laya.timer.frameOnce(3, this, ()=>{
							load();
						});
					});
				}));
			}
			load();
		}

		/**
		 * @deprecated 直接清除某个特效所引用的资源，如果有其他的应用则不清除，外部用,非常非常不建议走这个接口，废除中
		 */
		public static clear_3d_resource(url:string) {
			if (this.d3res_map.hasOwnProperty(url)) {
				let _lst = this.d3res_map[url];
				for (let j:number = 0; j < _lst.length; j++) {
					let _res = _lst[j];
					if (AssetMgr.get_count(_res) == 0) {
						let __r = Laya.loader.getRes(_res);
						if (__r) {
							if (__r.clearTexture) __r.clearTexture();
							else __r.dispose();
						}
					}
				}
			}
		}

		// 递归预编译shader
		public static dfsCompileShader(scene: Laya.Scene, root: Laya.Sprite3D) {
			if (root == null) return;
			let vertexDeclaration = null;
			if (root['_geometryFilter'] && root['_geometryFilter']['_vertexBuffer']
				&& root['_geometryFilter']['_vertexBuffer']['vertexDeclaration']) {
				vertexDeclaration = root['_geometryFilter']['_vertexBuffer']['vertexDeclaration'];
				let _render = root['_render'];
				if (_render != null) {
					let _materials = _render['_materials'];
					if (_materials != null) {
						for (let i = 0; i < _materials.length; i++) {
							let material = _materials[i];
							if (material != null) {
								material._getShader(scene._shaderDefineValue, vertexDeclaration.shaderDefineValue, root._shaderDefineValue);
							}
						}
					}
				}
			}
			if (root['meshFilter'] && root['meshFilter']['sharedMesh'] && root['meshRender']) {
				let subMeshes = root['meshFilter']['sharedMesh']._subMeshes;
				let _materials = root['meshRender']['_materials'];
				if (subMeshes && subMeshes.length > 0) {
					for (let i:number = 0; i < subMeshes.length; i++) {
						let _mesh = subMeshes[i];
						let vertexBuffer = _mesh._getVertexBuffer(0);
						let vertexDeclaration = vertexBuffer.vertexDeclaration;
						for (let j:number = 0; j < _materials.length; j++) {
							let material = _materials[j];
							if (material != null) {
								material._getShader(scene._shaderDefineValue, vertexDeclaration.shaderDefineValue, root._shaderDefineValue);
							}
						}
					}
				}
			}

			if (root._childs != null) {
				for (let i: number = 0; i < root._childs.length; i++) {
					this.dfsCompileShader(scene, root._childs[i]);
				}
			}
		}

		// 走AssetMgr的effect
		public static add_3d_resource(url: string) {
			let _lst = this.d3res_map[url];
			if (_lst) {
				for (let j:number = 0; j < _lst.length; j++) {
					AssetMgr.add_refrence(_lst[j], url);
				}
			}
			
		}

		public static remove_3d_resource(url: string) {
			let _lst = this.d3res_map[url];
			if (_lst) {
				for (let j:number = 0; j < _lst.length; j++) {
					AssetMgr.remove_refrence(_lst[j], url);
				}
			}
		}
	}
}