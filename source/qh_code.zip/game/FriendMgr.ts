/**
* name 
*/
module game {

	export enum EFriendMsgType { none, room_invite }

	export interface iAccountState {
		account_id: number;
		login_time: number;
		logout_time: number;
		playing: Object;
		is_online: boolean;
	}

	export interface iFriendInfo {
		remark: string;
		base: iPlayerBaseView;
		state: iAccountState;
	}

	export interface iFriendApply {
		account_id: number;
		apply_time: number;
	}

	export interface iRecentPlayer {
		account_id: number;
		base: iPlayerBaseView;
	}

	export class FriendMgr {
		private static _friend_list: Array<iFriendInfo> = [];
		private static _listener: Array<Laya.Handler> = [];
		private static _friendapply_list: Array<iFriendApply> = [];
		private static _recentplayer_list: Array<iRecentPlayer> = [];
		public static friend_max_count: number = 0;
		public static friend_count: number = 0;
		public static recentplayer_changed: boolean = true;

		public static init(): void {
			if (!GameMgr.Inst.use_fetch_info) {
				this._friend_list = [];
				this._friendapply_list = [];
				app.NetAgent.sendReq2Lobby('Lobby', 'fetchFriendList', {}, (err, res) => {
					if (err) {
						app.Log.log('获取好友列表时发生错误:' + err);
					} else if (res['error']) {
						app.Log.log('获取好友列表时发生错误，错误码：' + res['error']['code']);
					} else {
						app.Log.log(JSON.stringify(res));
						if (res['friends']) {
							for (let i: number = 0; i < res['friends'].length; i++) {
								let data = res['friends'][i];
								this._friend_list.push(data);
							}
						}
						this.friend_count = res['friend_count'];
						this.friend_max_count = res['friend_max_count'];
					}
				});


				app.NetAgent.sendReq2Lobby('Lobby', 'fetchFriendApplyList', {}, (err, res) => {
					if (err || res['error']) {
						app.Log.log('获取好友申请列表发生错误');
					} else {
						app.Log.log(JSON.stringify(res));
						if (res['applies']) {
							for (let i: number = 0; i < res['applies'].length; i++) {
								this._friendapply_list.push(res['applies'][i]);
							}
						}
					}
				});
				this.fetchRecentPlayer();
			}


			app.NetAgent.addListener2Lobby('NotifyFriendViewChange', Laya.Handler.create(this, this._onFriendViewChange, null, false));
			app.NetAgent.addListener2Lobby('NotifyFriendStateChange', Laya.Handler.create(this, this._onFriendStateChange, null, false));
			app.NetAgent.addListener2Lobby('NotifyFriendChange', Laya.Handler.create(this, this._onFriendChange, null, false));
			app.NetAgent.addListener2Lobby('NotifyNewFriendApply', Laya.Handler.create(this, this._onFriendApplyChange, null, false));
		}

		public static onFetchSuccess(res: any) {
			this._friend_list = [];
			this._friendapply_list = [];
			let friend_list = res['friend_list'];
			if (friend_list) {
				if (friend_list['friends']) {
					for (let i: number = 0; i < friend_list['friends'].length; i++) {
						let data = friend_list['friends'][i];
						this._friend_list.push(data);
					}
				}
				this.friend_count = friend_list['friend_count'];
				this.friend_max_count = friend_list['friend_max_count'];
			}
			let apply_list = res['friend_apply_list'];
			if (apply_list) {
				if (apply_list['applies']) {
					for (let i: number = 0; i < apply_list['applies'].length; i++) {
						this._friendapply_list.push(apply_list['applies'][i]);
					}
				}
			}
			let recent_friend = res['recent_friend'];
			if (recent_friend) {
				this._recentplayer_list = [];
				if (recent_friend['account_list']) {
					for (let i: number = 0; i < recent_friend['account_list'].length; i++) {
						this._recentplayer_list.push({ account_id: recent_friend['account_list'][i], base: null });
					}
				}
			}
		}

		public static get friend_list(): Array<iFriendInfo> {
			return this._friend_list;
		}

		public static get friendapply_list(): Array<iFriendApply> {
			return this._friendapply_list;
		}

		public static get recentplayer_list(): Array<iRecentPlayer> {
			return this._recentplayer_list;
		}
		public static find(account_id: number): iFriendInfo {
			for (let i: number = 0; i < this._friend_list.length; i++) {
				if (this._friend_list[i].base.account_id == account_id) {
					return this._friend_list[i];
				}
			}
			return null;
		}

		private static _onFriendStateChange(msg) {
			app.Log.log(JSON.stringify(msg));
			let f: iFriendInfo = this.find(msg['target_id']);
			if (f == null) {
				app.Log.Error('收到并非好友的人的信息:' + JSON.stringify(msg));
				return;
			}
			msg = msg['active_state'];
			if (!msg) return;
			if (msg['login_time'] != null && msg['login_time'] != undefined) f.state.login_time = msg['login_time'];
			if (msg['logout_time'] != null && msg['logout_time'] != undefined) f.state.logout_time = msg['logout_time'];
			f.state.playing = msg['playing'];
			if (msg['is_online'] != null && msg['is_online'] != undefined) f.state.is_online = msg['is_online'];
			this.triggerMsg({ type: 'singlechange', account_id: f.base.account_id });
		}

		private static _onFriendViewChange(msg) {
			let f: iFriendInfo = this.find(msg['target_id']);
			if (f == null) {
				app.Log.Error('收到并非好友的人的信息:' + JSON.stringify(msg));
				return;
			}
			if (msg['base']['avatar_id'] != null && msg['base']['avatar_id'] != undefined) f.base.avatar_id = msg['base']['avatar_id'];
			if (msg['base']['title'] != null && msg['base']['title'] != undefined) f.base.title = msg['base']['title'];
			if (msg['base']['nickname'] != null && msg['base']['nickname'] != undefined) f.base.nickname = msg['base']['nickname'];
			if (msg['base']['verified'] != null && msg['base']['verified'] != undefined) f.base.verified = msg['base']['verified'];
			if (msg['base']['level'] != null && msg['base']['level'] != undefined) f.base.level = msg['base']['level'];
			if (msg['base']['level3'] != null && msg['base']['level3'] != undefined) f.base.level3 = msg['base']['level3'];
			if (msg['base']['avatar_frame'] != null && msg['base']['avatar_frame'] != undefined) f.base.avatar_frame = msg['base']['avatar_frame'];
			this.triggerMsg({ type: 'singlechange', account_id: f.base.account_id });
		}

		public static addListener(func: Laya.Handler) {
			this.removeListener(func);
			this._listener.push(func);
		}

		public static removeListener(func: Laya.Handler) {
			for (let i: number = 0; i < this._listener.length; i++) {
				if (this._listener[i] === func) {
					this._listener[i] = this._listener[this._listener.length - 1];
					this._listener.pop();
					break;
				}
			}
		}

		private static triggerMsg(data: any) {
			for (let i: number = 0; i < this._listener.length; i++) {
				if (this._listener[i]) this._listener[i].runWith(data);
			}
		}

		public static removeFriend(account_id: number) {
			for (let i: number = 0; i < this._friend_list.length; i++) {
				if (this._friend_list[i].base.account_id == account_id) {
					for (let j: number = i; j < this._friend_list.length - 1; j++) {
						this._friend_list[j] = this._friend_list[j + 1];
					}
					this._friend_list.pop();
					this.friend_count--;
					break;
				}
			}

		}

		private static _onFriendChange(data: Object) {
			let account_id: number = data['account_id'];
			if (data['type'] == 1) {
				if (!this.find(account_id)) {
					this.friend_count++;
					this.friend_list.push(data['friend']);
				}
			} else if (data['type'] == 2) {
				this.removeFriend(account_id);
			}
			this.triggerMsg({ type: 'listchange' });
		}

		private static _onFriendApplyChange(data: Object) {
			for (let i: number = 0; i < this._friendapply_list.length; i++) {
				if (this._friendapply_list[i].account_id == data['account_id']) {
					this._friendapply_list[i].apply_time = data['apply_time'];
					return;
				}
			}
			this._friendapply_list.push({
				account_id: data['account_id'],
				apply_time: data['apply_time']
			});
			if (data['removed_id']) {
				for (let i: number = 0; i < this._friendapply_list.length; i++) {
					if (this._friendapply_list[i].account_id == data['removed_id']) {
						for (let j: number = 0; j < this._friendapply_list.length - 1; j++) {
							this._friendapply_list[j] = this._friendapply_list[j + 1];
						}
						this._friendapply_list.pop();
						break;
					}
				}
			}
		}

		public static delFriendApply(account_id: number) {
			for (let i: number = 0; i < this._friendapply_list.length; i++) {
				if (this._friendapply_list[i].account_id == account_id) {
					for (let j: number = i; j < this._friendapply_list.length - 1; j++) {
						this._friendapply_list[j] = this._friendapply_list[j + 1];
					}
					this._friendapply_list.pop();
					break;
				}
			}
		}

		public static needShowRedpoint(): boolean {
			let _t = Laya.LocalStorage.getItem('friend_apply_' + GameMgr.Inst.account_id);
			let last_check_time = 0;
			if (_t) {
				last_check_time = Number(_t) / 1000;
			}
			if (game.FriendMgr.friendapply_list) {
				for (let _apply of game.FriendMgr.friendapply_list) {
					if (_apply.apply_time > last_check_time) return true;
				}
			}
			return false;
		}

		public static fetchRecentPlayer(complete?: Laya.Handler) {
			if (!this.recentplayer_changed) {
				if (complete) {
					complete.run();
				}
				return;
			}
			this.recentplayer_changed = false;
			app.NetAgent.sendReq2Lobby('Lobby', 'fetchRecentFriend', {}, (err, res) => {
				if (err || res['error']) {
					app.Log.log('fetchRecentFriend');

				} else {
					let list = this._recentplayer_list;
					this._recentplayer_list = [];
					if (res['account_list']) {
						for (let i: number = 0; i < res['account_list'].length; i++) {
							let _have_info = false;
							for (let _player of list) {
								if (_player.account_id == res['account_list'][i]) {
									this._recentplayer_list.push(_player);
									_have_info = true;
									break;
								}
							}
							if (!_have_info) {
								this._recentplayer_list.push({ account_id: res['account_list'][i], base: null });
							}
						}
					}
				}
				if (complete) {
					complete.runWith({ err: err, res: res });
				}
			});
		}
	}
}