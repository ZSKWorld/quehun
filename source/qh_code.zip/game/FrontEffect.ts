/**
* name 
*/
module game {

	//不要自己创建,用FrontEffect创建，毕竟放在他下面
	export class UIEffect {

		private static effects: Array<UIEffect> = [];

		private static regist(e: UIEffect) {
			UIEffect.effects.push(e);
		}

		public static update() {
			let index: number = 0;
						for (let i: number = 0; i < this.effects.length; i++) {
				if (!this.effects[i].destoryed) {
					this.effects[i]._update();
					this.effects[index++] = this.effects[i];
				}
			}
			for (let i: number = this.effects.length - index; i > 0; i--) {
				this.effects.pop();
			}
		}

		// 获得特效在屏幕位置
		public static getTargetPos(target: Laya.Sprite, offset: Laya.Point): Laya.Vector3 { 
			let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(target, offset);
			pos.x = pos.x - 0.5;
			pos.y = 0.5 - pos.y;
			// console.log(new Laya.Vector3(pos.x * FrontEffect.scene_width, pos.y * FrontEffect.scene_height, 0));
			return new Laya.Vector3(pos.x * FrontEffect.scene_width, pos.y * FrontEffect.scene_height, 0);
		}

		public destoryed: boolean = false;
		public target: Laya.Sprite;
		public effect: EffectBase;
		public pos_offset: Laya.Point;
		public scale: number;
		/**
		 * 是否跟随目标节点显示隐藏
		 */
		public enableFollowTarget:boolean = false;

		public constructor(target: Laya.Sprite, url: string, pos_offset: Laya.Point, scale: number) {
			this.target = target;
			this.destoryed = false;
			this.pos_offset = pos_offset;
			this.scale = scale;
			this.effect = new EffectBase(url);
			UIEffect.effects.push(this);
			this._update();
		}

		private _update() {
			if (this.destoryed) return;
			if (!this.target) return;
			if (this.enableFollowTarget) {
				this.effect.root.active = game.Tools.isSpriteVisible(this.target);
			}
			let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(this.target, this.pos_offset);
			pos.x = pos.x - 0.5;
			pos.y = 0.5 - pos.y;

			if (this.effect && this.effect.root) {
				this.effect.root.transform.localPosition = new Laya.Vector3(pos.x * FrontEffect.scene_width, pos.y * FrontEffect.scene_height, 0);
				if (this.scale != 0) {
					this.effect.root.transform.localScale = new Laya.Vector3(this.target.scaleX * this.scale, this.target.scaleY * this.scale, 1);
				} else {
					this.effect.root.transform.localScale = new Laya.Vector3(1, 1, 1);
				}
			}
		}

		public destory() {
			if (this.destoryed) return;
			this.destoryed = true;
			this.effect.destroy();
		}
	}

	export class FrontEffect {

		public static Inst: FrontEffect = null;
		public static readonly scene_click_effect_path: string = 'scene/scene_click_effect.ls';
		public static readonly scene_ui_effect_path: string = 'scene/scene_ui_effect.ls';
		public static scene_width: number = 32;
		public static scene_height: number = 18;
		private _scene_click_effect: Laya.Scene = null;
		private _root_click_effect: Laya.Sprite3D = null;
		private _scene_ui_effect: Laya.Scene = null;
		private _root_ui_effect: Laya.Sprite3D = null;
		private _container_preheat_click_effect: Laya.Sprite3D = null;

		private _effect_click_path: string = '';
		private _effect_click: Laya.Sprite3D = null;
		private _click_audio: number = 0;
		private _effects: Object = {};

		public get root_click_effect(): Laya.Sprite3D { return this._root_click_effect; }
		public get root_ui_effect(): Laya.Sprite3D { return this._root_ui_effect; }
		public get scene_ui_effect(): Laya.Scene { return this._scene_ui_effect };

		public static init(): void {
			FrontEffect.Inst = new FrontEffect();
			FrontEffect.Inst._init();
			Laya.timer.frameLoop(1, this, () => {
				UIEffect.update();
			});
		}

		private _init() {
			// scene_click_effect
			this._scene_click_effect = Laya.loader.getRes(FrontEffect.scene_click_effect_path);
			GameMgr.Inst.root_front_effect.addChild(this._scene_click_effect);
			this._root_click_effect = this._scene_click_effect.getChildByName('root') as Laya.Sprite3D;
			this._container_preheat_click_effect = this._scene_click_effect.getChildByName('contianer_preheat') as Laya.Sprite3D;
			this._effect_click = this._container_preheat_click_effect.getChildByName('effect_click') as Laya.Sprite3D;
			this._scene_click_effect.visible = true;
			Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.bangClickEffect);
			this.SetClickEffectByLobby(game.GameUtility.get_view_id(game.EView.lobby_bg));

			// scene_ui_effect
			this._scene_ui_effect = Laya.loader.getRes(FrontEffect.scene_ui_effect_path);
			this._root_ui_effect = this._scene_ui_effect.getChildByName('root') as Laya.Sprite3D;
			GameMgr.Inst.root_front_scene_effect.addChild(this._scene_ui_effect);
			this._scene_ui_effect.visible = true;
		}

		public SetClickEffectByLobby(lobby_bg_id: number, onComplete?: Laya.Handler) {
			const clickEffectPath = this.getClickPathByLobby(lobby_bg_id);
			this.SetClickEffect(clickEffectPath, onComplete);
		}

		// onComplete回调返回true：设置成功，返回false：设置失败
		public SetClickEffect(path: string, onComplete?: Laya.Handler) {
			if (path == this._effect_click_path) {
				if (onComplete) onComplete.runWith(true);
				return;
			}
			let origin_path = this._effect_click_path;
			if (this._effect_click_path != '') {
				
				if (this._effect_click) {
					this._effect_click.destroy(true);
				}
				let _effect = Laya.loader.getRes(this._effect_click_path);
				if (_effect && _effect.destoryed) {
					_effect.destroy(true);
				}
				
				this._effect_click_path = '';
			}

			this._effect_click = null;
			this._effect_click_path = path;
			//可能存在特效持续中，延迟销毁
			if (origin_path) {
				Laya.timer.once(2000, this, ()=>{
					EffectMgr.remove_3d_resource(origin_path);
				})
			}
			EffectMgr.add_3d_resource(this._effect_click_path);
			Laya.loader.create([this._effect_click_path], Laya.Handler.create(this, () => {
				this._effect_click = Laya.loader.getRes(this._effect_click_path);
				
				if (this._effect_click) {
					this._container_preheat_click_effect.addChild(this._effect_click);
					this._effect_click.active = true;
					Laya.timer.once(1000, this, () => {
						if (this._effect_click) this._effect_click.active = false;
						if (onComplete) onComplete.runWith(true);
					});
				} else {
					app.Log.Error("加载点击特效" + this._effect_click_path + "失败");
					if (onComplete) onComplete.runWith(false);
				}
				
				
			}));
			
			
		}

		private bangClickEffect() {
			if (!this._effect_click || this._effect_click.destroyed) return;
			let mouseX: number = Laya.MouseManager.instance.mouseX;
			let mouseY: number = Laya.MouseManager.instance.mouseY;
			if (!game.Scene_MJ.Inst.active || (uiscript.UI_GameEnd.Inst && uiscript.UI_GameEnd.Inst.enable)) view.AudioMgr.PlayAudio(this._click_audio);
			let w_offset: number = 0;
			let h_offset: number = 0;
			if (Laya.Browser.width / 1920 < Laya.Browser.height / 1080) {
				h_offset = (Laya.Browser.height - Laya.Browser.width / 1920 * 1080) / 2;
			} else {
				w_offset = (Laya.Browser.width - Laya.Browser.height / 1080 * 1920) / 2;
			}

			let x: number = mouseX / (Laya.Browser.width - w_offset * 2) * (FrontEffect.scene_width) - FrontEffect.scene_width / 2;
			let y: number = FrontEffect.scene_height - mouseY / (Laya.Browser.height - h_offset * 2) * (FrontEffect.scene_height) - FrontEffect.scene_height / 2;
			let effect: Laya.Sprite3D = this._effect_click.clone();
			this._root_click_effect.addChild(effect);
			effect.active = false;
			effect.active = true;
			effect.transform.localPosition = new Laya.Vector3(x, y, 1);
			Laya.timer.once(1500, this, () => {
				effect.destroy(true);
			});
		}

		//创建跟随节点的ui特效
		public create_ui_effect(target: Laya.Sprite, url: string, offset: Laya.Point, scale: number): UIEffect {
			let effect: UIEffect = new UIEffect(target, url, offset, scale);
			this._root_ui_effect.addChild(effect.effect.root);
			return effect;
		}

		public get effect_click_path(): string {
			return this._effect_click_path;
		}

		public getClickPathByLobby(lobbyId: number) {
			let path: string = 'scene/effect_click_default.lh';
			this._click_audio = 103;
			switch (lobbyId) {
				case 307003:
				case 307007:
					path = 'scene/effect_click_xuehua.lh';
					break;
				case 307008:
					path = 'scene/effect_click_22summer.lh';
					break;
				case 307009:
					path = 'scene/effect_click_jidian.lh';
					break;
				case 307010:
					path = 'scene/effect_click_zxy.lh';
					break;
				case 307011:
					path = 'scene/effect_click_22shengdan.lh';
					break;
				case 307012:
					path = 'scene/effect_click_wht.lh';
					break;
				case 307014:
					path = 'scene/effect_click_xiuqiu01.lh';
					break;
				case 30700001:
					path = 'scene/effect_click_jiuba.lh';
					break;
				case 30700002:
					path = 'scene/effect_click_fenwoshi.lh';
					break;
				case 30700003:
					path = 'scene/effect_click_gufengwoshi.lh';
					break;
				case 30700005:
					path = 'scene/effect_click_dongmudaqiao.lh';
					break;
				case 30700004:
					path = 'scene/effect_click_tangquan.lh';
					break;
				case 30700006:
					path = 'scene/effect_click_shamo.lh';
					break;
				case 30700007:
					path = 'scene/effect_click_yuanlin.lh';
					break; 
			}
			return path;
		}
	}
}