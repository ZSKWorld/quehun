/**
* name 
*/
module game {
	export const DefaultGirlSkinId: number = 400000; // 默认女角色剪影皮肤
	export const DefaultBoySkinId: number = 400001; // 默认男角色剪影皮肤
	export const stardust_id:number = 302004;

	export enum ECommonView { desktop = 1, mjp = 2, lobby_bg = 3 }

	export enum EView { liqibang = 0, hupai_effect, lizhi_effect, hand_model, lizhi_bgm, head_frame, desktop, mjp, lobby_bg, mingpai_zhishi = 10, title, loading_CG, mjp_surface }
	export enum EIDType { none, currency, character, item, skin, title, functionItem }
	export enum EFunctionItemType { none, activity = 1, yueka = 2 }
	//账号设置，user_xieyi：用户协议
	export enum EAccountSetKey { user_xieyi = 1 }

	export enum EMatchMode {shilian = 36, hesu = 40, dora = 33, chiyu = 41, jjc = 42}

	export interface iCharacterInfo {
		charid:number;
		level:number;
		exp:number;
		views:Array<{slot:number, item_id:number}>;
		skin:number;
		is_upgraded:boolean;
		extra_emoji:Array<number>;
		rewarded_level:Array<number>;
	}

	export class GameUtility {

		public static get_default_ai_character(): number { return 200001; }
		public static get_default_ai_skin(): number { return 400101; }

		//注意：view_default_item中 装扮有默认id的物品 在背包中可能并不是已拥有状态
		private static view_default_item:Array<number> = [ 0, 0, 0, 0, 0, 305501, 305044, 305045, 307001, 0, 0, 0, 0, 305725];
		// private static view_default_item:Array<number> = [ 0, 305207, 305307, 0, 0, 305501, 305044, 305045, 307001, 0, 0];
		public static get_view_default_item_id(type:EView): number {
			return this.view_default_item[type];
		}

		public static get_view_id(type:EView): number {
			if (type == EView.mjp && (uiscript.UI_Sushe.now_mjp_id || uiscript.UI_Sushe.now_mjp_id === 0)) {
				return uiscript.UI_Sushe.now_mjp_id;
			} else if (type == EView.desktop && (uiscript.UI_Sushe.now_desktop_id || uiscript.UI_Sushe.now_desktop_id === 0)) {
				return uiscript.UI_Sushe.now_desktop_id;
			} else if (type == EView.mjp_surface && (uiscript.UI_Sushe.now_mjp_surface_id || uiscript.UI_Sushe.now_mjp_surface_id === 0)) {
				return uiscript.UI_Sushe.now_mjp_surface_id;
			}
			
			let lst = uiscript.UI_Sushe.commonViewList[uiscript.UI_Sushe.using_commonview_index]?.values;
			if (lst) {
				for (let i:number = 0; i < lst.length; i++) {
					if (lst[i].slot == type) {
						if (lst[i].item_id) return lst[i].item_id;
						break;
					}
				}
			}
			return this.get_view_default_item_id(type);
		}

		public static get_view_res_name(type:EView): string {
			let d = cfg.item_definition.view.get(this.get_view_id(type));
			if (d) {
				// if (type == EView.mjp) {
				// 	if (view.DesktopMgr.en_mjp) return d.res_name + '_0';
				// 	else return d.res_name;
				// } else {
					return d.res_name;
				// }
			} 
			switch(type) {
				case EView.desktop: return 'tablecloth_default';
				case EView.mjp: return 'mjp_default';
				case EView.mingpai_zhishi: return 'mpzs_default';
				case EView.mjp_surface: return 'mjpface_default';
			}
			return 'default';
		}

		// public static get_common_view_id(view:ECommonView): number {
		// 	let stype:string = (view as number).toString();
		// 	if (GameMgr.Inst.commonview_slot.hasOwnProperty(stype)) return GameMgr.Inst.commonview_slot[stype];
		// 	return 0;
		// }

		public static get_id_type(id:number):EIDType {
			let n = id > 1000000 ?  Math.floor(id / 1000000) : Math.floor(id / 10000);
			if (n == 10) return EIDType.currency;
			if (n == 20) return EIDType.character;
			if (n == 30) return EIDType.item;
			if (n == 40) return EIDType.skin;
			if (n == 60) return EIDType.title;
			if (n == 70) return EIDType.functionItem;
			return EIDType.none;
		}

		

		public static get_item_view(id:number): {name:string, icon:string, desc:string, func?: string} {
			let idtype:EIDType = this.get_id_type(id);
			let name:string = '';
			let icon:string = '';
			let desc:string = '';
			let func:string = '';
			switch (idtype) {
				case EIDType.currency: 
					let d_currency = cfg.item_definition.currency.get(id);
					if (d_currency) {
						name = d_currency['name_' + GameMgr.client_language];
						icon = d_currency.icon;
						desc = d_currency['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.character: 
					let d_character = cfg.item_definition.character.get(id);
					if (d_character) {
						name = d_character['name_' + GameMgr.client_language];
						icon = cfg.item_definition.skin.get(d_character.init_skin).path + '/bighead.png';
						desc = d_character['desc_item_' + GameMgr.client_language];
					}
					break;
				case EIDType.item: 
					let d_item = cfg.item_definition.item.get(id);
					if (d_item) {
						name = d_item['name_' + GameMgr.client_language];
						icon = d_item.icon;
						desc = d_item['desc_' + GameMgr.client_language];
						func = d_item['desc_func_' + GameMgr.client_language];
					}
					break;
				case EIDType.skin: 
					let d_skin = cfg.item_definition.skin.get(id);
					if (d_skin) {
						name = d_skin['name_' + GameMgr.client_language];
						icon = d_skin.path + '/bighead.png';
						desc = d_skin['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.title: 
					let d_title = cfg.item_definition.title.get(id);
					if (d_title) {
						name = d_title['name_' + GameMgr.client_language];
						icon = d_title.icon_item;
						desc = d_title['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.functionItem: 
					let d_function = cfg.item_definition.function_item.get(id);
					if (d_function) {
						name = game.Tools.strOfLocalization(d_function.name);
						icon = d_function.icon;
						desc = game.Tools.strOfLocalization(d_function.desc);
						func = game.Tools.strOfLocalization(d_function.desc_func);
					}
					break;
			}
			return {
				name: name,
				icon: icon,
				desc: desc,
				func: func
			};
		}

		public static get_item_view_new(id: number): { name: string, icon: string, desc: string, func?: string } {
			let idtype: EIDType = this.get_id_type(id);
			let name: string = '';
			let icon: string = '';
			let desc: string = '';
			let func: string = '';
			switch (idtype) {
				case EIDType.currency:
					let d_currency = cfg.item_definition.currency.get(id);
					if (d_currency) {
						name = d_currency['name_' + GameMgr.client_language];
						icon = d_currency.icon_jpg;
						desc = d_currency['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.character:
					let d_character = cfg.item_definition.character.get(id);
					if (d_character) {
						name = d_character['name_' + GameMgr.client_language];
						icon = cfg.item_definition.skin.get(d_character.init_skin).path + '/bighead.png';
						desc = d_character['desc_item_' + GameMgr.client_language];
					}
					break;
				case EIDType.item:
					let d_item = cfg.item_definition.item.get(id);
					if (d_item) {
						name = d_item['name_' + GameMgr.client_language];
						icon = d_item.icon;
						desc = d_item['desc_' + GameMgr.client_language];
						func = d_item['desc_func_' + GameMgr.client_language];
					}
					break;
				case EIDType.skin:
					let d_skin = cfg.item_definition.skin.get(id);
					if (d_skin) {
						name = d_skin['name_' + GameMgr.client_language];
						icon = d_skin.path + '/bighead.png';
						desc = d_skin['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.title:
					let d_title = cfg.item_definition.title.get(id);
					if (d_title) {
						name = d_title['name_' + GameMgr.client_language];
						icon = d_title.icon_item;
						desc = d_title['desc_' + GameMgr.client_language];
					}
					break;
				case EIDType.functionItem:
					let d_function = cfg.item_definition.function_item.get(id);
					if (d_function) {
						name = game.Tools.strOfLocalization(d_function.name);
						icon = d_function.icon;
						desc = game.Tools.strOfLocalization(d_function.desc);
						func = game.Tools.strOfLocalization(d_function.desc_func);
					}
					break;
			}
			return {
				name: name,
				icon: icon,
				desc: desc,
				func: func
			};
		}

		//独占的物品，如装扮、角色，如果有了，就是拥有，其他的通用道具都不是已拥有
		public static item_owned(id:number): boolean {
			let idtype:EIDType = this.get_id_type(id);
			if (idtype == EIDType.character) {
				let lst = uiscript.UI_Sushe.characters;
				if (lst) {
					for (let i:number = 0; i < lst.length; i++) {
						if (lst[i] && lst[i].charid == id) {
							return true;
						}
					}
				}
			} else if (idtype == EIDType.item) {
				let d_item = cfg.item_definition.item.get(id);
				if (d_item && (d_item.category == 4 || d_item.category == 5)) {
					let count:number = uiscript.UI_Bag.get_item_count(id);
					if (count > 0) return true;
				}
			} else if (idtype == EIDType.skin) {
				return uiscript.UI_Sushe.skin_owned(id);
			} else if (idtype == EIDType.title) {
				let lst = uiscript.UI_TitleBook.owned_title;
				if (lst) {
					for (let i:number = 0; i < lst.length; i++) {
						if (lst[i] == id) {
							return true;
						}
					}
				}
			}

			return false;
		}

			
		public static char_limited(char_id:number):boolean {
			let data = cfg.item_definition.character.get(char_id);
			if(!data) return true;
			return data && data.region_limit == 1;
		}

		public static skin_limited(skin_id:number):boolean {
			let skin = cfg.item_definition.skin.get(skin_id);
			if(!skin) return true;
			return GameUtility.char_limited(skin.character_id);
		}
		
		public static get_limited_skin_id(skin_id:number):number {
			if (GameMgr.regionLimited && GameUtility.skin_limited(skin_id)) {
				return GameUtility.get_default_ai_skin();
			}
			return skin_id;
		}

		public static get_limited_chara_id(chara_id:number):number {
			if (GameMgr.regionLimited && GameUtility.char_limited(chara_id)) {
				return GameUtility.get_default_ai_character();
			}
			return chara_id;
		}

		public static checkAllActiveTexture() {
			let list = [];
			for (let key in Laya.Loader.loadedMap) {
				if (key.includes('.png') || key.includes('.jpg') || key.includes('blob')) {
					let item = Laya.Loader.loadedMap[key]
					if (item.bitmap && item.bitmap.source) {
						list.push(key);
						
					}
				}
			}
			console.log(list);
			return list;
		}
	}
}