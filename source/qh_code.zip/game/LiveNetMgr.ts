/**
* name 
*/
module game {
	const reconnect_span:Array<number> = [500, 500, 500];

	export class LiveNetMgr {

		private static _Inst:LiveNetMgr = null;
		public static get Inst():LiveNetMgr {
			return this._Inst == null ? (this._Inst = new LiveNetMgr()) : this._Inst;
		}
        private _url: string;
		public set url(url: string) {
			this._url = url;
		}
		private _socket: net.LiveSocket;
        private lasterrortime: number = 0;
        private _connect_state: EConnectState;
        private _reconnect_count: number = 0; // 重连次数
		private _reconnect_failed_time: number = 0;

		private sending_heart: boolean = false;

        private _open_func: Laya.Handler;
		private _fetch_seq_func: Laya.Handler;
		private _close_func: Laya.Handler;

		private _heart_id: number = 0;

        public get connect_state():EConnectState { return this._connect_state; }
		public get socket(): net.LiveSocket { return this._socket; }

		public constructor() {
			this._socket = new net.LiveSocket(Laya.Handler.create(this, this.onReceiveMsgError, null, false));
		}
		
        public connect(func:Laya.Handler, fetch_seq_func: Laya.Handler, _close_func: Laya.Handler) {
			this.clearTimer();
            this._socket.addSocketLister(new Laya.Handler(this, this._onConnent));
			this._set_connect_state(EConnectState.tryconnect);
			this._socket.connect(net.NetRouteGroup.Inst.getMainRouteID(), net.NetRouteGroup.Inst.getChoosedUrl() + '/ob');
            this._open_func = func;
			this._fetch_seq_func = fetch_seq_func;
			this._close_func = _close_func;
			this._reconnect_count = 0;
        }

        public sendReq(rpc_name:string, data: any, func_response: (error, res) => void) {
			this._socket.sendRequest(rpc_name, data, func_response);
		}

        private _onConnent(event:string): void {
			if (event == Laya.Event.CLOSE || event == Laya.Event.ERROR) {
				if (Laya.timer.currTimer - this.lasterrortime > 100) { // 由于有时候 error和close事件会同时过来
					this.lasterrortime = Laya.timer.currTimer;
					if (this.connect_state == EConnectState.tryconnect) {
						this._try_reconnect();
					} else if (this.connect_state == EConnectState.connecting) {
                        this._set_connect_state(EConnectState.reconnecting);
                        this._reconnect_count = 0;
                        this._try_reconnect();
					} else if (this.connect_state == EConnectState.reconnecting) {
						this._try_reconnect();
					}
					if (this._close_func) {
						this._close_func.run();
					}
				}
			} else if (event == Laya.Event.OPEN) {
                // 重连次数清零
				this._reconnect_count = 0;
				if (this.connect_state == EConnectState.tryconnect) {
					this._set_connect_state(EConnectState.connecting);
					if (this._open_func) this._open_func.runWith({open: true});
				} else if (this.connect_state == EConnectState.reconnecting) {
					// 重连次数+1
					this._set_connect_state(EConnectState.connecting);
					if (this._open_func) this._open_func.runWith({open: true});
					
				} else if (this.connect_state != EConnectState.connecting) {
					this.close();
				}
			}
		}

        private _try_reconnect() {
            if (this._reconnect_count >= reconnect_span.length) {
                app.Log.log('Live重连失败');
				// 防止error和close同时触发
                if (Laya.timer.currTimer - this._reconnect_failed_time > 3000 && this._open_func) {
                    this._open_func.runWith({open: false, info: this.connect_state == EConnectState.reconnecting  ? 'disconnect' : 'connect failed'});
                } 
				this._set_connect_state(EConnectState.disconnect);
				this._reconnect_failed_time = Laya.timer.currTimer;
            } else {
                Laya.timer.once(reconnect_span[this._reconnect_count], this, ()=>{
					if (this.connect_state == EConnectState.reconnecting || this.connect_state == EConnectState.tryconnect) {
						app.Log.log('LiveNetMgr _Reconnect  count:' + this._reconnect_count);
						this._socket.connect(net.NetRouteGroup.Inst.getMainRouteID(), net.NetRouteGroup.Inst.getChoosedUrl() + '/ob');
					}
				});
				this._reconnect_count++;
            }
        }

        private _set_connect_state(v:EConnectState) {
			this._connect_state = v;
        }

        public close(): void {
			this._heart_id = 0;
            this._set_connect_state(EConnectState.none);
			this._socket.close();
			this.clearTimer();
		}

		public onReceiveMsgError(data:any) {

		}

		public setNotifyHandler(handler: Laya.Handler) {
			this._socket.setNotifyHandler(handler);
		}

		public force_reconnect() {
			this._reconnect_count = 0;
			this._set_connect_state(EConnectState.reconnecting);
			this._try_reconnect();
		}


		// 发送fetchSequence协议
		public sendFetchSequence() {
			if (this.sending_heart) return;
			if (this._connect_state != EConnectState.connecting) return;
            Laya.timer.once(5000, this, this.on_heart_failed);
			this.sending_heart = true;
			let self = this;
			// app.Log_OB.log('send FetchSequence:' + this._heart_id);
			this.sendReq('FetchSequence', {id: this._heart_id++}, (err, res)=>{
				if (err) {
					app.Log_OB.log('FetchSequence Error+' + this._heart_id);
				} else {
					Laya.timer.clear(self, self.on_heart_failed);
					let seq = res['seq'];
					this.sending_heart = false;
					this._fetch_seq_func.runWith({success: true, seq: seq});
				}
			});
		}

		// fetchsequence 失败
		public on_heart_failed() {
			this.sending_heart = false;
			if (this._connect_state != EConnectState.none) {
				this.close();
				Laya.timer.once(150, this, this.force_reconnect);
			} else {
				this.force_reconnect();
			}
			this.force_reconnect();
			GameMgr.Inst.onGuanzhanError('心跳检测失败');
		}

		// seq失败
		public on_seq_error(seq_1: number, seq_2: number) {
			this.sending_heart = false;
			if (this._connect_state != EConnectState.none) {
				this.close();
				Laya.timer.once(150, this, this.force_reconnect);
			} else {
				this.force_reconnect();
			}
			
			// GameMgr.Inst.onGuanzhanError('seq检验失败: fetch:' + seq_1 + '  local:' + seq_2);
		}

		public clearTimer() {
			Laya.timer.clearAll(this);
			this.sending_heart = false;
		}
	}
}