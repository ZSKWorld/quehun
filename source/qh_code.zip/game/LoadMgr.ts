/**
* name 
*/
module game {

	interface LoadItem {
		loaded: boolean;
		precent: number;
		urls: Array<string>;
		complete: Array<Laya.Handler>;
		progress: Array<Laya.Handler>;
	}

	interface ResImage {
		loaded: boolean;
		success: boolean;
		origin_url: string;
		blob_url: string;
		complete: Array<Laya.Handler>;
	}

	export enum E_LoadType { common, scene_mj, lobby, ui_mj, entrance, spot, kuangdu, huiye, saki, scene_amulet, ui_amulet, activity }

	export class LoadMgr {

		private static _items: Array<LoadItem> = [];
		private static _resimage: Object = {};

		private static getUrls(type: E_LoadType): Array<string> {
			let urls: Array<string> = [];
			let atlas_root = game.LoadMgr.getAtlasRoot();
			if (GameMgr.client_language != 'chs') {
				atlas_root += GameMgr.client_language + '/';
			}
			if (type == E_LoadType.entrance) {
				urls = [
					atlas_root + 'myres/entrance.atlas',
					atlas_root + 'myres/necessary.atlas',
					atlas_root + 'myres/info.atlas',
					atlas_root + 'myres/pop_panel.atlas'
				];
				if (GameMgr.client_language != 'chs') {
					urls.push(`scene/entrance_${GameMgr.client_language}.ls`);
				} else {
					urls.push("scene/entrance.ls");
				}
				if (GameMgr.inDmm) urls.push(atlas_root + 'myres/dmm.atlas');
			}
			else if (type == E_LoadType.common) {
				urls = [
					atlas_root + 'myres.atlas',
					atlas_root + 'myres/bothui.atlas',
					atlas_root + 'myres/bothui/player_info.atlas',
					atlas_root + 'myres/rules_point.atlas',
					atlas_root + 'myres/bothui/maka.atlas',
					atlas_root + 'myres/bothui/config.atlas',
					atlas_root + 'myres/bothui/char_filter.atlas',
				];
			}
			else if (type == E_LoadType.scene_mj) {
				if (GameMgr.client_language == 'en') {
					urls.push('scene/mjdesktop_en.ls');
				} else {
					urls.push('scene/mjdesktop.ls');
				}
				urls.push('scene/mjhandpai.ls');
				let texture_path: string = 'myres2/mjp/recommend.png';
				if (GameMgr.client_language != 'chs') {
					texture_path = GameMgr.client_language + '/' + texture_path;
				}
				urls.push(texture_path);
				if (GameMgr.client_language == 'kr') {
					//加载部分韩语适配图
					let path = 'scene/Assets/Resource/table/tablemid/';
					urls.push(path + 'chang_kr.png');
					urls.push(path + 'feng_kr.png');
					urls.push(path + 'left_kr.png');

				}
				//全屏特效父节点
				urls.push('scene/mjdesktop_effect_fullscreen.ls');
			} else if (type == E_LoadType.scene_amulet) {
				urls.push('scene/mjdesktop_amulet_pk.ls');
				urls.push('scene/mjhandpai_amulet.ls');
				let texture_path: string = 'myres2/mjp/recommend.png';
				if (GameMgr.client_language != 'chs') {
					texture_path = GameMgr.client_language + '/' + texture_path;
				}
				urls.push(texture_path);
			} else if (type == E_LoadType.lobby) {
				urls = [
					atlas_root + 'myres/room.atlas',
					atlas_root + 'myres/shop.atlas',
					atlas_root + 'myres/shop/gift_pack.atlas',
					atlas_root + 'myres/shop/skin_choose.atlas',
					atlas_root + 'myres/sushe.atlas',
					atlas_root + 'myres/sushe_new.atlas',
					atlas_root + 'myres/sushe_new/flipback.atlas',
					atlas_root + 'myres/sushe_new/flipfront.atlas',
					atlas_root + 'myres/lobby.atlas',
					atlas_root + 'myres/activity_base.atlas',
					atlas_root + 'myres/match_lobby.atlas',
					atlas_root + 'myres/treasure.atlas',
					atlas_root + 'myres/yueka.atlas',
					// atlas_root + 'myres/friend_room.atlas', //新友人房
					atlas_root + 'myres/get_character.atlas',
					atlas_root + 'myres/yueka_auto.atlas',
					// atlas_root + 'myres/shilian.atlas',
					// atlas_root + 'myres/shilian_finished.atlas',
					// atlas_root + 'myres/ab_match.atlas',
					atlas_root + 'myres/achievement.atlas',
					// atlas_root + 'myres/activity_duanwu.atlas',
					// atlas_root + 'myres/activity_shaizi.atlas',
					atlas_root + 'myres/activity_sign.atlas',
					atlas_root + 'myres/activity_fanpai.atlas', 
					// atlas_root + 'myres/activity_yijidagong.atlas',
					// atlas_root + 'myres/activity_nianshou.atlas',
					// atlas_root + 'myres/wanxianggengxin.atlas',
					// atlas_root + 'myres/activity_wajue.atlas',
					
					// atlas_root + 'myres/activity_dongri.atlas',
					atlas_root + 'myres/activity_entrance.atlas',
					atlas_root + 'myres/activity_entrance_extra.atlas',
					atlas_root + 'myres/sns.atlas',
					atlas_root + 'myres/activity_entrance_amulet.atlas',
					// atlas_root + 'myres/activity_rpg.atlas',
					// atlas_root + 'myres/rpg.atlas',
					// atlas_root + 'myres/rpg/enemy.atlas',
					// atlas_root + 'myres/rpg/spring.atlas',
					// atlas_root + 'myres/rpg/autumn.atlas',
					// atlas_root + 'myres/rpg/summer.atlas',
					// atlas_root + 'myres/rpg/winter.atlas',
					// atlas_root + 'myres/activity_jjc.atlas',
					// atlas_root + 'myres/activity_spot.atlas',
					// atlas_root + 'myres/activity_clothes_vote.atlas',
					// atlas_root + 'myres/activity_vote_banner.atlas',
					// atlas_root + 'myres/activity_miaohui.atlas',
					// atlas_root + 'myres/activity_niudan.atlas',
					// atlas_root + 'myres/activity_2510questcrew.atlas',
					// atlas_root + 'myres/liandong_rules.atlas',
					atlas_root + 'myres/activity_qiri.atlas',
					atlas_root + 'myres/xinshouyindao.atlas',
					// atlas_root + 'myres/activity_2404ba.atlas',
					// atlas_root + 'myres/activity_2501miaohui.atlas',
					// atlas_root + 'myres/activity_2406_haidao.atlas',
					// atlas_root + 'myres/activity_2406_haidao/spot_images.atlas',
					// atlas_root + 'myres/activity_2408_spot.atlas',
					// atlas_root + 'myres/activity_2408_spot/fragment.atlas',
					// atlas_root + 'myres/activity_2411imas.atlas',
					// atlas_root + 'myres/activity_2411imas/spot.atlas',
					// atlas_root + 'myres/activity_2411imas/number.atlas',
					// atlas_root + 'myres/activity_vtuber.atlas',
					atlas_root + 'myres/activity_liandong_signup.atlas',
					// atlas_root + 'myres/activity_simulation.atlas',
					// atlas_root + 'myres/activity_combining.atlas',
					// atlas_root + 'myres/activity_combining_yindao.atlas',
					// atlas_root + 'myres/activity_2508navigation.atlas',
					// atlas_root + 'myres/activity_24chunjie.atlas',
					atlas_root + 'myres/activity_yindao.atlas',
					atlas_root + 'myres/role_set.atlas',
					atlas_root + 'myres/activity_interval_desktop.atlas',
					// atlas_root + 'myres/activity_shoot.atlas',
					// atlas_root + 'myres/activity_exchange.atlas',
					atlas_root + 'myres/activity_bingo.atlas',
					// atlas_root + 'myres/activity_2512winter.atlas',
					// atlas_root + 'myres/activity_2512winter/font.atlas',
					// atlas_root + 'myres/activity_2512winter/chara.atlas',
				];
				// 伊莉雅版本特殊
				// if (GameMgr.regionLimited) {
				// 	urls.push(atlas_root + 'myres/activity_dongri.atlas');
				// 	urls.push(atlas_root + 'myres/activity_entrance.atlas');
				// } else {
				// 	urls.push(atlas_root + 'myres/activity_liandong.atlas');
				// 	urls.push(atlas_root + 'myres/liandong_rules.atlas');
				// 	if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
				// 		urls.push(atlas_root + 'myres/activity_entrance.atlas');
				// 	} else {
				// 		urls.push(atlas_root + 'myres/activity_entrance_extra.atlas');
				// 	}
				
				//ba联动版本特殊
				// urls.push('scene/scene_24ba_sign_effect.ls')
				//海岛版本特殊
				// urls.push('scene/effect_haidao_bg.ls')
				// 扭蛋活动特殊
				uiscript.UI_Activity_Niudan.getPreloadList().forEach((value)=>{
					urls.push(value);
				});
				// }
				// urls.push('scene/effect_25chunjie_home.ls'); //春节版本特殊
				// 问卷目前仅国服
				// if (GameMgr.client_type == 'chs_t') {
					urls.push(atlas_root + 'myres/activity_questionair.atlas');
				// }
				// urls.push('scene/mzys.ls');
				// if (uiscript.UI_Lobby.is_SD_Type) {
				// urls.push('scene/effect_nianshou_firework.ls');
				// urls.push(atlas_root + 'myres/lobby_SD.atlas'); // 大厅雪顶开关
				// }
				if ((GameMgr.client_type == 'en' || GameMgr.client_type == 'kr') && GameMgr.client_language == 'chs_t') {
					urls.push(atlas_root + 'myres/yueka_en.atlas');
				}
				if (GameMgr.client_type == 'kr') {
					urls.push(atlas_root + 'myres/yueka_kr.atlas');
				}
				if (GameMgr.client_type == 'chs_t') {
					urls.push(atlas_root + 'myres/refund.atlas');
				}
				// {
				//     // 春节活动大底图，活动结束需要删除
				//     var texture_path = 'myres/activity_chunjie';
				//     if (GameMgr.client_language != 'chs') {
				//         texture_path = GameMgr.client_language + '/' + texture_path;
				//     }
				//     urls.push(texture_path + '/bg.png');
				//     urls.push(texture_path + '/bg_rank.png');
				// }
				// urls.push(atlas_root + 'myres/activity_yijidagong.atlas');
				// urls.push(atlas_root + 'myres/activity_xiari.atlas');
				// 仅美服欧服
				if (GameMgr.client_type == 'en' || GameMgr.client_type == 'kr') {
					urls.push(uiscript.UI_Tanfang.scene_path);// 寻觅主场景提前加载，加载完后卸载
					urls.push(atlas_root + 'tanfang.atlas');
				}
				
				// 加载寻觅本地化图
				urls.push('scene/Assets/Resource/effect/texture/effect_UI/chouka_tex/1/xunmi_text_' + GameMgr.client_language + '.png');
				urls.push(FrontEffect.scene_click_effect_path);
				urls.push(FrontEffect.scene_ui_effect_path);
				urls.push(CatFoodSpine.SpineMgr.scene_spine_front_path);
				urls.push(CatFoodSpine.SpineMgr.scene_spine_back_path);
			} else if (type == E_LoadType.ui_mj) {
				urls = [
					atlas_root + 'myres/mjdesktop.atlas',
					atlas_root + 'myres/mjdesktop/shengduan.atlas',
					atlas_root + 'myres/mjdesktop/number.atlas',
					atlas_root + 'myres/mjdesktop/pai.atlas',
					atlas_root + 'myres/mjdesktop/highlight.atlas',
					atlas_root + 'myres/mjdesktop/route.atlas',
					atlas_root + 'myres/mj_fieldspell.atlas',
					atlas_root + 'myres/mjdesktop/maka.atlas',
				];
			} else if (type == E_LoadType.spot) {
				urls = [
					atlas_root + 'myres/spot.atlas',
					Scene_Spot.Inst.scene_effect_path,
					Scene_Spot.Inst.scene_effect_path_front,
				];
			} else if (type == E_LoadType.kuangdu) {
				urls = [
					atlas_root + 'myres/activity_kuangdu.atlas',
					atlas_root + 'myres/liandong_rules.atlas',
					atlas_root + 'myres/kuangdu_rules.atlas',
				];
			} else if (type == E_LoadType.huiye) {
				urls = [
					atlas_root + 'myres/activity_huiye.atlas',
					atlas_root + 'myres/liandong_rules.atlas',
					// atlas_root + 'myres/huiye_rules.atlas',
				];

			} else if (type == E_LoadType.saki) {
				urls = [
					atlas_root + 'myres/activity_saki.atlas',
					atlas_root + 'myres/liandong_rules.atlas',
					// atlas_root + 'myres/huiye_rules.atlas',
				];
			} else if (type == E_LoadType.ui_amulet) {
				urls = [
					atlas_root + 'myres/amulet.atlas',
					atlas_root + 'myres/amulet/number.atlas',
					atlas_root + 'myres/amulet/card.atlas',
					atlas_root + 'myres/amulet/boss.atlas',
					atlas_root + 'myres/liandong_rules.atlas',
				];
			} else if (type == E_LoadType.activity) {
				urls = [
					// 雀斗大会图集
					// atlas_root + 'myres/activity_simulation.atlas',
					// atlas_root + 'myres/activity_simulation/sim_icon.atlas',
					// atlas_root + 'myres/activity_2602chunjie.atlas',
					// atlas_root + 'myres/activity_2602chunjie/tiles.atlas',
					atlas_root + 'myres/activity_2604dj.atlas',
					atlas_root + 'myres/activity_2604dj/item_icon.atlas',
					atlas_root + 'myres/activity_2604dj/number.atlas',
					atlas_root + 'myres/liandong_rules.atlas',
				];
			}
			return urls;
		}

		public static getAtlasRoot(){
			return game.ResourceVersion.quality == game.GameQuality.quality100 ?  'res/atlas/' : game.ResourceVersion.quality == game.GameQuality.quality70 ? 'res/atlas_q7/': 'res/atlas_q8/';
		}

		private static _createItem(urls: Array<string>): LoadItem {
			let ret: LoadItem = { loaded: false, precent: 0, urls: urls, complete: [], progress: [] };
			let ls_urls: Array<string> = [];
			let other_urls: Array<string> = [];
			let other_index: number = 0;
			let current_load_count: number = 0;
			for (let i: number = 0; i < urls.length; i++) {
				let _url: string = urls[i];
				if (_url.substr(_url.length - 3) == '.ls') {
					ls_urls.push(_url);
				} else {
					other_urls.push(_url);
				}
			}

			function complete_other(n) {
				current_load_count -= n;
				if (other_index >= other_urls.length) {
					if (current_load_count <= 0) {
						ret.loaded = true;
						ret.precent = 1;
						for (let i: number = 0; i < ret.complete.length; i++) {
							if (ret.complete[i]) ret.complete[i].run();
						}
					}
				} else {
					load_other();
				}
			}

			function process_other(percent) {
				ret.precent = (percent * other_urls.length + ls_urls.length) / urls.length;
				for (let i: number = 0; i < ret.progress.length; i++) {
					if (ret.progress[i]) ret.progress[i].runWith(ret.precent);
				}
			}

			function load_other() {
				if (other_urls.length > 0) {
					let __urls: Array<string> = [];
					while (current_load_count < 1000 && other_index < other_urls.length) {
						__urls.push(other_urls[other_index++]);
						current_load_count++;
					}

					Laya.loader.create(__urls,
						Laya.Handler.create(this, complete_other, [__urls.length], false),
						Laya.Handler.create(this, process_other, null, false));
				} else {
					complete_other(100000);
				}
			}

			function complete_ls() {
				ret.precent = ls_urls.length / urls.length;
				load_other();
			}

			function progress_ls(percent) {
				ret.precent = (percent * other_urls.length + ls_urls.length) / urls.length;
				for (let i: number = 0; i < ret.progress.length; i++) {
					if (ret.progress[i]) ret.progress[i].runWith(ret.precent);
				}
			}

			if (ls_urls.length > 0) {
				//先要加载场景，不然会报错
				Laya.loader.create(ls_urls,
					Laya.Handler.create(this, complete_ls),
					Laya.Handler.create(this, progress_ls));
			} else {
				complete_ls();
			}
			return ret;
		}

		public static loadRes(type: E_LoadType, complete?: Laya.Handler, progress?: Laya.Handler) {
			let index: number = type;
			while (this._items.length <= index) {
				this._items.push(null);
			}
			if (this._items[index] == null) {
				this._items[index] = this._createItem(this.getUrls(type));
			}

			if (this._items[index].loaded) {
				if (complete) complete.run();
			} else {
				if (complete) this._items[index].complete.push(complete);
				if (progress) {
					progress.once = false;
					this._items[index].progress.push(progress);
				}
			}
		}

		//type: png or jpg
		private static createResImage_web(url: string) {
			if (this._resimage.hasOwnProperty(url)) return;
			let type: string = '';
			let extendname: string = url.substr(url.length - 3);
			type = extendname.toLocaleLowerCase();
			let item: ResImage = {
				loaded: false,
				origin_url: url,
				blob_url: null,
				complete: [],
				success: false,
			}
			let mipmap = this.isMipMap(url);
			this._resimage[url] = item;
			var xhr = new Laya.HttpRequest();
			xhr.once(Laya.Event.COMPLETE, this, (data: Object) => {
				var byte: Laya.Byte = new Laya.Byte(data);
				var byte2: Laya.Byte = new Laya.Byte();
				for (let i: number = 0; i < byte.length; i++) {
					if (GameMgr.inRelease) {
						byte2.writeByte(byte.readByte() ^ 73);
					} else {
						byte2.writeByte(byte.readByte() /* ^ 73 */);
					}
				}
				var blob: Object = new Laya.Browser.window.Blob([byte2.buffer], { type: "image/" + type });
				var url = Laya.Browser.window.URL.createObjectURL(blob);//创建一个url对象；
				Laya.loader.load(url, Laya.Handler.create(this, (url: string) => {
					item.blob_url = url;
					item.loaded = true;
					item.success = true;
					for (let i: number = 0; i < item.complete.length; i++) {
						if (item.complete) item.complete[i].run();
					}
					item.complete = [];
				}, [url]), null, Laya.Loader.IMAGE, undefined, undefined, undefined, undefined, mipmap);

			});
			xhr.once(Laya.Event.ERROR, this, (e: Object) => {
				// console.log('加载'+url+'失败');
				item.loaded = true;
				item.success = false;
				for (let i: number = 0; i < item.complete.length; i++) {
					if (item.complete[i]) item.complete[i].run();
				}
				item.complete = [];
			});
			xhr.send(ResourceVersion.formatURL(url), "", "get", "arraybuffer");
		}

		private static createResImage_conch(url: string) {
			if (this._resimage.hasOwnProperty(url)) return;
			let item: ResImage = {
				loaded: false,
				origin_url: url,
				blob_url: null,
				complete: [],
				success: false,
			}
			this._resimage[url] = item;
			Laya.loader.load(url, Laya.Handler.create(this, () => {
				item.blob_url = url;
				item.loaded = true;
				item.success = true;
				for (let i: number = 0; i < item.complete.length; i++) {
					if (item.complete) item.complete[i].run();
				}
				item.complete = [];
			}), null, Laya.Loader.IMAGE, undefined, undefined, undefined, undefined, this.isMipMap(url));
		}

		//加载被加密的图片资源
		public static loadResImage(urls: Array<string>, complete?: Laya.Handler, progress?: Laya.Handler) {
			if (!urls || urls.length == 0) {
				if (progress) progress.runWith(1);
				if (complete) complete.run();
				return;
			}
			let complete_num: number = 0;
			let index: number = 0;
			let current_load_count: number = 0;
			for (let i = 0; i < urls.length; i++) {
				urls[i] = Tools.localUISrc(urls[i]);
			}

			let _load = () => {
				current_load_count = 0;
				while (current_load_count < 5 && index < urls.length) {
					let url: string = urls[index++];
					if (!this._resimage.hasOwnProperty(url)) {
						if (GameMgr.inConch)
							this.createResImage_conch(url);
						else
							this.createResImage_web(url);
					}
					let item: ResImage = this._resimage[url];
					if (item.loaded) _onloaded(false);
					else {
						current_load_count++;
						item.complete.push(Laya.Handler.create(this, _onloaded, [true]));
					}
				}
			}

			let _onloaded = f => {
				if (f) {
					current_load_count--;
					if (current_load_count == 0) {
						if (index < urls.length) {
							_load();
						}
					}
				}

				complete_num++;
				if (complete_num == urls.length) {
					if (progress) progress.runWith(1);
					if (complete) complete.run();
				} else {
					if (progress) progress.runWith(complete_num / urls.length);
				}
			}

			_load();
		}

		public static getResImage(url: string): Laya.Texture {
			url = Tools.localUISrc(url);
			if (!this._resimage.hasOwnProperty(url)) return null;
			var item: ResImage = this._resimage[url];
			if (item.loaded) {
				if (item.success) return Laya.loader.getRes(item.blob_url);
				else return null;
			} else {
				return null;
			}
		}

		public static getResImageSkin(url: string): string {
			url = Tools.localUISrc(url);
			if (!this._resimage.hasOwnProperty(url)) return '';
			if (!this._resimage[url].loaded) return '';
			var item: ResImage = this._resimage[url];
			return item.blob_url;
		}

		public static getResLoadState(url: string) {
			url = Tools.localUISrc(url);
			if (!this._resimage.hasOwnProperty(url)) return null;
			var item: ResImage = this._resimage[url];
			return item;
		}

		public static deleteResImageSkin(url: string) {
			url = Tools.localUISrc(url);
			delete this._resimage[url];
		}

		public static getItemSkin(id: number): string {
			let info = game.GameUtility.get_item_view(id);
			return this.getResImageSkin(info.icon);
		}

		public static disposeSceneRes(scene: string) {
			let urls: Array<string> = [];
			switch (scene) {
				case 'lobby': urls = this.getUrls(E_LoadType.lobby); break;
				case 'mjdesktop': urls = this.getUrls(E_LoadType.ui_mj); break;
				case 'spot': urls = this.getUrls(E_LoadType.spot); break;
				case 'kuangdu': urls = this.getUrls(E_LoadType.kuangdu); break;
				case 'amulet': urls = this.getUrls(E_LoadType.ui_amulet); break;
				case 'activity': urls = this.getUrls(E_LoadType.activity); break;
			}

			for (let i: number = 0; i < urls.length; i++) {
				let _url: string = urls[i];
				if (_url.indexOf('.atlas') != -1) {
					Laya.loader.clearTextureRes(_url);
				}
			}
		}

		//用http去加载直接资源，可以忽视浏览器缓存，type="text" || "json" || "arraybuffer"
		public static httpload(url: string, type: string, ignoreCache: boolean, complete: Laya.Handler) {
			var xhr = new Laya.HttpRequest();
			xhr.once(Laya.Event.COMPLETE, this, (data: any) => {
				if (complete) {
					if (type == "json") {
						complete.runWith({ success: true, data: JSON.parse(data) });
					} else {
						complete.runWith({ success: true, data: data });
					}
				}
			});
			xhr.once(Laya.Event.ERROR, this, (e: Object) => {
				// console.log('httpload加载'+url+'失败');
				if (complete) {
					complete.runWith({ success: false, error: e });
				}
			});
			let _url: string = game.ResourceVersion.formatURL(url);
			let heads: Array<string> = [];
			if (ignoreCache) {
				heads.push('If-Modified-Since');
				heads.push('0');
				if (_url.indexOf('?') != -1) _url += '&';
				else _url += '?';
				_url += 'randv=' + Math.floor(Math.random() * 100000000).toString() + Math.floor(Math.random() * 100000000).toString();
			}
			let _type: string = 'text';
			switch (type) {
				case 'json': _type = 'text'; break;
				case 'arraybuffer': _type = 'arraybuffer'; break;
			}
			xhr.send(_url, "", "get", _type, heads);
		}

		public static httpFetch(url: string, image: Laya.Image) {
			let promise = fetch(url, { mode: 'no-cors', method: 'GET' });
			promise.then(function (response) {
				var _promise = response['blob']();
				_promise.then(function (_image) {
					let url = URL.createObjectURL(_image);
					Laya.loader.load(url, Laya.Handler.create(this, (url: string) => {
						image.skin = url;
					}, [url]), null, Laya.Loader.IMAGE);
				})
			})

		}
		private static _waiting_load_img_skins: Array<{ img: Laya.Image, src: string }> = [];
		/**
		 * 设置图片的skin，未下载的话启动下载，适用与大图，如背包的桌面预览
		 * @param img Laya.Image控件
		 * @param src 图片路径，不需要再转换本地路径
		 * @param callback 加载完成回调
		 * @param uitag UI标签，用于管理临时图片
		 */
		public static setImgSkin(img: Laya.Image, src: string, callback: Laya.Handler = null, uitag: string = '') {
			if (src.indexOf('extendRes') >= 0) { //若是加密图
				let skin = this.getResImageSkin(src);
				if (skin != '' && skin != null && skin != undefined) {
					//已经存在，直接替换
					img.skin = skin;
					this.clearImgSkin(img);
					if (uitag != '') TempImageMgr.addImg(uitag, skin);
					if (callback) {
						callback.run();
					}
				} else {
					//未存在，加载后设置
					img.skin = '';
					this.clearImgSkin(img);
					this._waiting_load_img_skins.push({ img: img, src: src });
					this.loadResImage([src], Laya.Handler.create(this, () => {
						if (uitag != '') TempImageMgr.addImg(uitag, this.getResImageSkin(src));
						for (let i: number = 0; i < this._waiting_load_img_skins.length; i++) {
							if (this._waiting_load_img_skins[i].img === img) {
								if (this._waiting_load_img_skins[i].src == src) {
									img.skin = this.getResImageSkin(src);
									this._waiting_load_img_skins[i] = this._waiting_load_img_skins[this._waiting_load_img_skins.length - 1];
									this._waiting_load_img_skins.pop();
									if (callback) {
										callback.run();
									}
								}
								break;
							}
						}
					}));
				}
			} else {
				src = Tools.localUISrc(src);
				let skin = Laya.loader.getRes(src);
				if (skin) {
					//已经存在，直接替换
					img.skin = src;
					if (uitag != '') TempImageMgr.addImg(uitag, src);
					this.clearImgSkin(img);
					if (callback) {
						callback.run();
					}
				} else {
					//未存在，加载后设置
					img.skin = '';
					this.clearImgSkin(img);
					this._waiting_load_img_skins.push({ img: img, src: src });
					Laya.loader.load(src, Laya.Handler.create(this, () => {
						if (uitag != '') TempImageMgr.addImg(uitag, src);
						for (let i: number = 0; i < this._waiting_load_img_skins.length; i++) {
							if (this._waiting_load_img_skins[i].img === img) {
								if (this._waiting_load_img_skins[i].src == src) {
									img.skin = src;
									this._waiting_load_img_skins[i] = this._waiting_load_img_skins[this._waiting_load_img_skins.length - 1];
									this._waiting_load_img_skins.pop();
									if (callback) {
										callback.run();
									}
								}
								break;
							}
						}
					}));
				}
			}

		}


		//清除上面的预加载图片
		public static clearImgSkin(img: Laya.Image) {
			for (let i: number = 0; i < this._waiting_load_img_skins.length; i++) {
				if (this._waiting_load_img_skins[i].img === img) {
					this._waiting_load_img_skins[i] = this._waiting_load_img_skins[this._waiting_load_img_skins.length - 1];
					this._waiting_load_img_skins.pop();
					break;
				}
			}
		}

		/**
		 * 清除内容中的图集，图集并不会完全卸载，当再次进入页面时，会自动再次引入内存
		 * @param path myres/xxx.atlas 不需要本地处理
		 */
		public static clearAtlas(path: string) {
			let url = this.getAtlasRoot() + game.Tools.localUISrc(path);
			Laya.loader.clearTextureRes(url);
		}

		private static isMipMap(url: string): boolean {
			return url.indexOf(game.ResourceVersion.formatURL('extendRes/charactor')) != -1 || url.indexOf(game.ResourceVersion.formatURL('extendRes/emo/')) != -1;
		}
	}
}