/**
* name 
*/
module game {
	export enum EFetchState { none, fetching, success, error }
	export enum EConnectState { none, tryconnect, connecting, usable, reconnecting, closing, disconnect };
	const reconnect_span: Array<number> = [500, 1000, 3000, 6000, 10000, 15000];

	export class LobbyNetMgr {

		private static _Inst: LobbyNetMgr = null;
		public static get Inst(): LobbyNetMgr {
			return this._Inst == null ? (this._Inst = new LobbyNetMgr()) : this._Inst;
		}

		private _connect_listeners: Array<Laya.Handler> = [];
		public zone_ids: Array<number> = null;
		public server_name: string = '';

		public get connect_state(): EConnectState {
			if (net.NetRouteGroup.Inst) return net.NetRouteGroup.Inst.getConnectState();
			return EConnectState.none;
		}

		public get isOK(): boolean {
			return this.connect_state == EConnectState.usable;
		}

		public init(server_name: string, gateways: net.Gateway[], zone_ids: Array<number> = null) {
			this.server_name = server_name;
			net.GatewayFetcher.init(gateways);
			net.GatewayFetcher.checkFetch();
			net.GatewayFetcher.eventHandler.once("OnFetchEnd", this, (data) => {
				if (data && data.open) {
					net.NetRouteGroup_Entrance.Inst = new net.NetRouteGroup_Entrance();
				}
			});
			net.NetRouteGroup.Inst = new net.NetRouteGroup();
			this.zone_ids = zone_ids;
			// 每5分钟发一次质量定期报告
			// Laya.timer.loop(5 * 60 * 1000, this, () => {
			// 	if (game.LobbyNetMgr.Inst.isOK) {
			// 		GameMgr.Inst.postNewInfo2Server('network_route', {
			// 			client_type: 'web', route_type: 'lobby', route_index: LobbyNetMgr.GetReportRootIndex(this._choosed_index),
			// 			route_delay: Math.min(10000, Math.round(this.main_net.delay)), connection_time: Math.round(Date.now() - this.main_net.connect_start_time), reconnect_count: this.main_net.report_reconnect_count
			// 		})
			// 	}
			// });
		}


		// #region NetRouteGroup 事件监听

		private _onRouteUseable(data: any) {

		}

		private _onReconnectStart(data: any) {
			if (GameMgr.Inst.logined) {
				GameMgr.Inst.logined = false
				uiscript.UI_Disconnect.Inst.show();
			}
		}

		private _onReconnectSuccess(data: any) {
			if (!data.changed) { // 老线路重连要重新登录。新线路会走fastLogin
				LoginMgr.relogin();
			}
		}

		private _onReconnectFailed(data: any) {
			uiscript.UI_Disconnect.Inst.show();
		}

		private _onClose(data: any) {

		}

		// #endregion

		public initOnLoginSuccess() {
			app.Log.log_t('LobbyNetMgr', 'initOnLoginSuccess');
			net.NetRouteGroup.Inst.initFromEntrance();
			net.NetRouteGroup.Inst.eventHandler.on('OnRouteUseable', this, this._onRouteUseable);
			net.NetRouteGroup.Inst.eventHandler.on('OnReconnectStarted', this, this._onReconnectStart);
			net.NetRouteGroup.Inst.eventHandler.on('OnReconnectSuccess', this, this._onReconnectSuccess);
			net.NetRouteGroup.Inst.eventHandler.on('OnReconnectFailed', this, this._onReconnectFailed);
			net.NetRouteGroup.Inst.eventHandler.on('OnClose', this, this._onClose);
		}

		public add_connect_listener(eventNames: string[], caller, func) {
			for (let eventName of eventNames) {
				net.NetRouteGroup.Inst.eventHandler.on(eventName, caller, func);
			}
		}

		public remove_connect_listener(eventNames: string[], caller, func) {
			for (let eventName of eventNames) {
				net.NetRouteGroup.Inst.eventHandler.off(eventName, caller, func);
			}
		}

		public close(): void {
			GameMgr.Inst.logined = false;
			net.NetRouteGroup.Inst.close();
		}
	}
}