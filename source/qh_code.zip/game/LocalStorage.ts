/**
* name 
*/
module game{
	export class LocalStorage{
		// 2023/2/6删除
		public static removeItem(name: string) {
			let ename = game.Tools.eeesss('e__' + name);
			Laya.LocalStorage.removeItem(name);
			Laya.LocalStorage.removeItem(ename);
		}
		
		public static setItem(name:string, value: string) {
			let ename = game.Tools.eeesss('e__' + name);
			Laya.LocalStorage.setItem(name, 'FKU!!!');
			Laya.LocalStorage.setItem(ename, game.Tools.eeesss(value));
		}

		public static getItem(name:string):string {
			let ename = game.Tools.eeesss('e__' + name);
			let s = Laya.LocalStorage.getItem(name);
			if (s != null && s != 'FKU!!!') {
				Laya.LocalStorage.setItem(name, 'FKU!!!');
				Laya.LocalStorage.setItem(ename, game.Tools.eeesss(s));
				return s;
			} else {
				s = Laya.LocalStorage.getItem(ename);
				if (s != null) {
					s = game.Tools.dddsss(s);
				}
				return s;
			}
		}

		/**
		 * 保存新手引导已读状态
		 * @param activityId 
		 */
		public static setGuide(activityId: number) {
			let key = 'activity_guide' + activityId + GameMgr.Inst.account_id;
			this.setItem(key, '1');
		}

		/**
		 * 获取活动引导状态
		 * @param activityId 
		 * @returns 如果是1(字符串)，则表示已引导过
		 */
		public static getGuide(activityId: number): string {
			let key = 'activity_guide' + activityId + GameMgr.Inst.account_id;
			return this.getItem(key);
		}

		/**
		 * 保存活动静音状态
		* @param activityId 
		*/
		public static setActivityMute(activityId: number, mute: boolean) {
			let key = 'activity_mute' + activityId;
			this.setItem(key, mute ? '1' : '0');
		}

		/**
		 * 获取活动静音状态
		 * @param activityId 
		 * @returns 如果是1(字符串)，则表示已引导过
		 */
		public static getActivityMute(activityId: number): boolean {
			let key = 'activity_mute' + activityId;
			if (!this.getItem(key)) return false;
			return this.getItem(key) == '1';
		}


		public static setActivityData(activityId: number, key: string, data: string) { 
			let activityKey =  activityId + GameMgr.Inst.account_id + key;
			this.setItem(activityKey, data);
		}

		public static getActivityData(activityId: number, key: string): string {
			let activityKey =  activityId + GameMgr.Inst.account_id + key;
			return this.getItem(activityKey);
		}
	}
}