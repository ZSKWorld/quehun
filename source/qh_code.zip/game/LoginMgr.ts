module game {
    export class LoginMgr {
        public static eventHandler: Laya.EventDispatcher = new Laya.EventDispatcher();
        public static account: string = "";
        public static password: string = "";
        public static sociotype: number = -1; // 0:账号登陆,1:微信,2:微博,3:QQ
        public static access_token: string = "";

        // 重新登录
        public static relogin(): void {
            let device: Object = GameMgr.Inst.get_device_info();
			let currency_platforms: Array<number> = game.Tools.get_platform_currency();
			if (this.sociotype == -1) {
				app.NetAgent.sendReq2Lobby('Lobby', 'login', {
					account: this.account,
					password: GameMgr.encodeP(this.password),
					reconnect: true,
					device: device,
					random_key: GameMgr.device_id,
					client_version: {
						resource: game.ResourceVersion.version,
					},
					currency_platforms: currency_platforms,
					client_version_string: GameMgr.Inst.getClientVersion(),
					tag: GameMgr.Inst.getReportClientType()
				}, (err, res) => {
					if (err || res['error']) {
						if (res && res['error'] && res['error']['code'] == 156) {
							uiscript.UIMgr.Inst.showRestartError(game.Tools.strOfLocalization(3765));
						} else {
							uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2007));
						}
					} else {
						this.onReconnectLogin(res);
					}
				});
			} else {
				app.NetAgent.sendReq2Lobby('Lobby', 'oauth2Login', {
					type: this.sociotype,
					access_token: this.access_token,
					reconnect: true,
					device: device,
					random_key: GameMgr.device_id,
					client_version: {
						resource: game.ResourceVersion.version,
					},
					currency_platforms: currency_platforms,
					client_version_string: GameMgr.Inst.getClientVersion(),
					tag: GameMgr.Inst.getReportClientType()
				}, (err, res) => {
					if (err || res['error']) {
						uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2007));
					} else {
						this.onReconnectLogin(res);
					}
				});
			}
        }

        private static onReconnectLogin(msg) {
			app.Log.log('LobbyNetMgr 重连成功');
            this.onLoginSuccess(this.sociotype, msg);
			GameMgr.Inst.logined = true;
			GameMgr.Inst.initAccountInfo(msg['account']);

			if (msg.game_info && msg.game_info.game_uuid) {
				if (!game.Scene_MJ.Inst.active) {
					game.MJNetMgr.Inst.OpenConnect(msg.game_info['connect_token'], msg.game_info['game_uuid'], msg.game_info['location'], false);
				}
			}
            this.eventHandler.event('OnReloginSuccess', msg);
		}

        // 登录成功的处理逻辑
		public static onLoginSuccess(sociotype: number, msg: game.IResLogin): void {
            app.Log.log('登陆：' + JSON.stringify(msg));
			GameMgr.Inst.account_id = msg['account_id'];
			GameMgr.Inst.account_data = msg['account'];
			game.YoStarSDK.Inst.roleInfoUpload({ game_role_id: String(msg.account_id), game_role_name: msg.account.nickname });
			game.AccountInfoMgr.Inst.updateData(msg['account']);
			uiscript.UI_ShiMingRenZheng.renzhenged = msg['is_id_card_authed'];
			GameMgr.Inst.account_numerical_resource = {};
			if (msg['account']['platform_diamond']){
				let platform_diamond = msg['account']['platform_diamond'];
				for (let i:number = 0; i < platform_diamond.length; i++) {
					GameMgr.Inst.account_numerical_resource[platform_diamond[i]['id']] = platform_diamond[i]['count'];
				}
			}
			if (msg['account']['skin_ticket']) {
				GameMgr.Inst.account_numerical_resource[100004] = msg['account']['skin_ticket'];
			}
			if (msg['account']['platform_skin_ticket']){
				let platform_tickets = msg['account']['platform_skin_ticket'];
				for (let i:number = 0; i < platform_tickets.length; i++) {
					GameMgr.Inst.account_numerical_resource[platform_tickets[i]['id']] = platform_tickets[i]['count'];
				}
			}
			GameMgr.Inst.account_refresh_time = Laya.timer.currTimer;
			if (msg['game_info']) {
				GameMgr.Inst.ingame = true;
				GameMgr.Inst.mj_server_location = msg['game_info']['location'];
				GameMgr.Inst.mj_game_token = msg['game_info']['connect_token'];
				GameMgr.Inst.mj_game_uuid = msg['game_info']['game_uuid'];
			}
			if (msg['access_token']) {
				Laya.LocalStorage.setItem('_pre_sociotype', Laya.LocalStorage.getItem('autologin') == 'false' ? '' : sociotype.toString());
				Laya.LocalStorage.setItem('ssssoooodd', msg['access_token']);
				this.sociotype = sociotype;
				this.access_token = msg['access_token'];
			}
			if (GameMgr.Inst.crashInfo) {
				GameMgr.Inst.postInfo2Server('crash_audio', GameMgr.Inst.crashInfo, false);
				GameMgr.Inst.crashInfo = null;
			}
            GameMgr.Inst.sendLoginBeat(true);
        }

		public static onFastLogin(msg: any): void {
			GameMgr.Inst.logined = true;
			if (msg.game_info && msg.game_info.game_uuid) {
				GameMgr.Inst.ingame = true;
				GameMgr.Inst.mj_server_location = msg['game_info']['location'];
				GameMgr.Inst.mj_game_token = msg['game_info']['connect_token'];
				GameMgr.Inst.mj_game_uuid = msg['game_info']['game_uuid'];
				if (!game.Scene_MJ.Inst.active) {
					game.MJNetMgr.Inst.OpenConnect(msg.game_info['connect_token'], msg.game_info['game_uuid'], msg.game_info['location'], false);
				}
			}
			if (msg.room) {
				if (uiscript.UI_WaitingRoom.Inst) {
					uiscript.UI_WaitingRoom.Inst.updateData(msg['room']);
				}
			} else {
				if (uiscript.UI_WaitingRoom.Inst) {
					uiscript.UI_WaitingRoom.Inst.resetData();
				}
			}
		}
    }
}