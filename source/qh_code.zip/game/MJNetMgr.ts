/**
* name 
*/
module game {

	export class MJNetMgr {

		private static _Inst: MJNetMgr = null;
		public static get Inst(): MJNetMgr {
			return this._Inst == null ? (this._Inst = new MJNetMgr()) : this._Inst;
		}

		private token: string;
		private game_uuid: string;
		private server_location: string;
		public playerreconnect: boolean = false; //玩家点击按钮的重连方式
		private load_over: boolean = false;
		private loaded_player_count: number = 0;
		private real_player_count: number = 0;
		private is_ob: boolean = false;
		private ob_token: string = '';
		private _report_reconnect_count: number = 0;
		private _connect_start_time: number = 0;
		public netMJ: net.NetRouteGroup_Single = null;

		public get connect_state(): EConnectState {
			if (app.NetAgent.netRouteGroup_mj) {
				return app.NetAgent.netRouteGroup_mj.getConnectState();
			}
			return EConnectState.none;
		};

		public constructor() {
			let netMJ: net.NetRouteGroup_Single = app.NetAgent.netRouteGroup_mj;
			netMJ.eventHandler.on('OnRouteUseable', this, this._onRouteUseable);
			netMJ.eventHandler.on('OnReconnectStarted', this, this._onReconnectStart);
			netMJ.eventHandler.on('OnReconnectSuccess', this, this._onReconnectSuccess);
			netMJ.eventHandler.on('OnReconnectFailed', this, this._onReconnectFailed);
			netMJ.eventHandler.on('OnClose', this, this._onClose);
			this.netMJ = netMJ;

			app.NetAgent.addListener2MJ('NotifyPlayerLoadGameReady', Laya.Handler.create(this, (msg) => {
				app.Log.log('NotifyPlayerLoadGameReady: ' + JSON.stringify(msg));
				this.loaded_player_count = msg['ready_id_list'].length;
				if (this.load_over) {
					if (uiscript.UI_Loading.Inst.enable) uiscript.UI_Loading.Inst.showLoadCount(this.loaded_player_count, this.real_player_count);
				}
			}));
		}

		// #region ----------------------- NetRouteGroup_Single 事件监听 -----------------------------------------

		private _onRouteUseable() {
			let route: net.NetRoute = app.NetAgent.netRouteGroup_mj.route;
			app.Log.info_t('MJNetMgr', '_OnRouteUseable, routeID:' + route.routeID + ', url:' + route.url);
			if (!this.is_ob) {
				this._ConnectSuccess();
			} else {
				this._ConnectSuccessOb();
			}
		}

		private _onReconnectStart() {
			app.Log.info_t('MJNetMgr', '_onReconnectStart');
			uiscript.UI_Disconnect.Inst.show();
		}

		private _onReconnectSuccess() {
			app.Log.info_t('MJNetMgr', '_onReconnectSuccess');
		}

		private _onReconnectFailed() {
			app.Log.info_t('MJNetMgr', '_onReconnectFailed');
			uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(59));
			if (view.DesktopMgr.Inst && !view.DesktopMgr.Inst.active) {
				game.Scene_MJ.Inst.ForceOut();
			}
		}

		private _onClose() {
			app.Log.info_t('MJNetMgr', '_onClose');
		}

		// #endregion

		public OpenConnect(token: string, game_uuid: string, location: string, playerreconnect: boolean): void {
			uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterMJ);
			if (game.Scene_Lobby.Inst && game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
			if (game.Scene_Huiye.Inst && game.Scene_Huiye.Inst.active) game.Scene_Huiye.Inst.active = false;
			this.Close();
			view.BgmListMgr.stopBgm();
			this.is_ob = false;
			Laya.timer.once(500, this, () => {
				this.token = token;
				this.game_uuid = game_uuid;
				this.server_location = location;
				GameMgr.Inst.ingame = true;
				GameMgr.Inst.mj_server_location = location;
				GameMgr.Inst.mj_game_token = token;
				GameMgr.Inst.mj_game_uuid = game_uuid;
				this.playerreconnect = playerreconnect;
				this.load_over = false;
				this.loaded_player_count = 0;
				this.real_player_count = 0;
				this.openNet();
			});
			// 每5分钟发一次质量定期报告
			Laya.timer.loop(5 * 60 * 1000, this, this.reportInfo);
		}

		private openNet() {
			let tail: string = '';
			if (this.server_location == 'local') {
				tail = 'game-gateway';
			} else if (this.server_location == 'zone') {
				tail = 'game-gateway-zone';
			}
			app.NetAgent.netRouteGroup_mj.connect(tail);
		}

		private reportInfo() {
			if (this.connect_state == EConnectState.usable) {
				GameMgr.Inst.postNewInfo2Server('network_route', {
					client_type: 'web',
					route_type: 'game',
					route_index: app,
					route_delay: Math.min(10000, Math.round(app.NetAgent.netRouteGroup_mj.getDelay())), 
					connection_time: Math.round(Date.now() - this._connect_start_time), 
					reconnect_count: this._report_reconnect_count
				})
			}
		}

		public Close() {
			this.load_over = false;
			app.Log.log('MJNetMgr close');
			app.NetAgent.netRouteGroup_mj.close();
			Laya.timer.clear(this, this.reportInfo);
		}

		private GetAuthData(): Object {
			return {
				account_id: GameMgr.Inst.account_id,
				token: this.token,
				game_uuid: this.game_uuid,
				device: GameMgr.Inst.get_device_info(),
			}
		}

		//连接成功，进入验证流程
		private _ConnectSuccess() {
			app.Log.log('MJNetMgr _ConnectSuccess');
			this.load_over = false;

			app.NetAgent.sendReq2MJ('FastTest', 'authGame', this.GetAuthData(), (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('authGame', err, res);
					uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterLobby);
					GameMgr.Inst.updateAccountInfo(Laya.Handler.create(this, () => {
						game.Scene_MJ.Inst.GameEnd();
					}));

					view.BgmListMgr.PlayLobbyBgm();
				} else {
					app.Log.log('麻将桌验证通过：' + JSON.stringify(res));
					uiscript.UI_Loading.Inst.setProgressVal(0.1);
					view.DesktopMgr.player_link_state = res['state_list'];
					let ai_name: string = game.Tools.strOfLocalization(2003);
					let d_config: any = res['game_config']['mode'];
					let e_rule: view.ERuleMode = view.ERuleMode.Liqi4;
					if (d_config.mode < 10) {
						e_rule = view.ERuleMode.Liqi4;
						this.real_player_count = 4;
					} else if (d_config.mode < 20) {
						e_rule = view.ERuleMode.Liqi3;
						this.real_player_count = 3;
					}
					if (d_config['extendinfo']) {
						//有extendinfo说明是老牌谱，ai是中级电脑
						ai_name = game.Tools.strOfLocalization(2004);
					}
					if (d_config['detail_rule']) {
						if (d_config['detail_rule']['ai_level']) {
							if (d_config['detail_rule']['ai_level'] === 1) {
								ai_name = game.Tools.strOfLocalization(2003);
							}
							if (d_config['detail_rule']['ai_level'] === 2) {
								ai_name = game.Tools.strOfLocalization(2004);
							}
						}
					}

					const players = [];
					const robots = [...res.robots].map(v => v.toJSON());
					res.seat_list.forEach((id, i) => {
						let player = res.players.find(v => v.account_id == id);
						if (!player) {
							player = robots.find(v => v.account_id == id);
							if (player) {
								player.avatar_id = player.character.skin;
								player.level = player.level || { id: 10101, score: 0 };
								player.level3 = player.level || { id: 20101, score: 0 };
								player.nickname = player.nickname || ai_name;
							}
						}
						players.push(player);
					});
					let ai_skin: number = game.GameUtility.get_default_ai_skin();
					let ai_character: number = game.GameUtility.get_default_ai_character();
					for (let i: number = 0; i < this.real_player_count; i++) {
						if (players[i] == null) {
							players[i] = {
								account: 0,
								nickname: ai_name,
								avatar_id: ai_skin,
								level: { id: 10101 },
								level3: { id: 20101 },
								character: {
									charid: ai_character,
									level: 0,
									exp: 0,
									views: [],
									skin: ai_skin,
									is_upgraded: false
								}
							};
						}
					}

					this.loaded_player_count = res['ready_id_list'].length;
					this._AuthSuccess(players, res['is_game_start'], res['game_config'].toJSON());
				}
			});
		}

		//验证成功
		private _AuthSuccess(players: Array<Object>, game_start: boolean, game_config: IGameConfig) {
			if (view.DesktopMgr.Inst && view.DesktopMgr.Inst.active) {
				this.load_over = true;
				Laya.timer.once(500, this, () => {
					app.Log.log('重连信息1 round_id:' + view.DesktopMgr.Inst.round_id + ' step:' + view.DesktopMgr.Inst.current_step);
					view.DesktopMgr.Inst.Reset();
					view.DesktopMgr.Inst.duringReconnect = true;
					uiscript.UI_Loading.Inst.setProgressVal(0.2);
					app.NetAgent.sendReq2MJ('FastTest', 'syncGame', {
						round_id: view.DesktopMgr.Inst.round_id,
						step: view.DesktopMgr.Inst.current_step,
					}, (err, res) => {
						if (err || res['error']) {
							uiscript.UIMgr.Inst.showNetReqError('syncGame', err, res);
							game.Scene_MJ.Inst.ForceOut();
						} else {
							app.Log.log('[syncGame] ' + JSON.stringify(res));
							if (res['is_end']) {
								uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2011));
								game.Scene_MJ.Inst.GameEnd();
							} else {
								uiscript.UI_Loading.Inst.setProgressVal(0.3);
								view.DesktopMgr.Inst.fetchLinks();
								view.DesktopMgr.Inst.Reset();
								view.DesktopMgr.Inst.duringReconnect = true;
								view.DesktopMgr.Inst.syncGameByStep(res['game_restore']);
							}
						}
					});
				});
			} else {
				game.Scene_MJ.Inst.openMJRoom(game_config, players, Laya.Handler.create(this, () => {
					view.DesktopMgr.Inst.initRoom(JSON.parse(JSON.stringify(game_config)), players, GameMgr.Inst.account_id, view.EMJMode.play, Laya.Handler.create(this, () => {
						if (game_start) {
							Laya.timer.frameOnce(10, this, () => {
								app.Log.log('重连信息2 round_id:' + -1 + ' step:' + 1000000);
								view.DesktopMgr.Inst.Reset();
								view.DesktopMgr.Inst.duringReconnect = true;
								app.NetAgent.sendReq2MJ('FastTest', 'syncGame', {
									round_id: '-1',
									step: 1000000,
								}, (err, res) => {
									app.Log.log('syncGame ' + JSON.stringify(res));
									if (err || res['error']) {
										uiscript.UIMgr.Inst.showNetReqError('syncGame', err, res);
										game.Scene_MJ.Inst.ForceOut();
									} else {
										uiscript.UI_Loading.Inst.setProgressVal(1);
										view.DesktopMgr.Inst.fetchLinks();
										this._PlayerReconnectSuccess(res);
									}
								});
							});
						} else {
							Laya.timer.frameOnce(10, this, () => {
								app.Log.log('send enterGame');
								view.DesktopMgr.Inst.Reset();
								view.DesktopMgr.Inst.duringReconnect = true;
								app.NetAgent.sendReq2MJ('FastTest', 'enterGame', {}, (err, res) => {
									if (err || res['error']) {
										uiscript.UIMgr.Inst.showNetReqError('enterGame', err, res);
										game.Scene_MJ.Inst.ForceOut();
									} else {
										uiscript.UI_Loading.Inst.setProgressVal(1);
										app.Log.log('enterGame');
										this._EnterGame(res);
										view.DesktopMgr.Inst.fetchLinks();
									}
								});
							});
						}
					}));
				}), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.1 + p * 0.8), null, false));
			}
		}

		//正常流程进入游戏
		private _EnterGame(data: Object) {
			app.Log.log('正常进入游戏: ' + JSON.stringify(data));
			if (data['is_end']) {
				uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2011));
				game.Scene_MJ.Inst.GameEnd();
			} else if (data['game_restore']) {
				// view.DesktopMgr.Inst.SnapShot(data['step'], data['snapshot']);
				view.DesktopMgr.Inst.syncGameByStep(data['game_restore']);
			} else {
				//一切正常的开始
				// console.log('正常进入游戏：' + (Laya.Stat.currentMemorySize/1024/1024) + ' MB');
				this.load_over = true;
				if (this.load_over) {
					if (uiscript.UI_Loading.Inst.enable) uiscript.UI_Loading.Inst.showLoadCount(this.loaded_player_count, this.real_player_count);
				}
				view.DesktopMgr.Inst.duringReconnect = false;
				view.DesktopMgr.Inst.StartChainAction(0);
			}
		}

		//玩家点击的重连同步
		private _PlayerReconnectSuccess(data: Object) {
			app.Log.log('_PlayerReconnectSuccess data:' + JSON.stringify(data));
			if (data['is_end']) {
				uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2011));
				game.Scene_MJ.Inst.GameEnd();
			} else {
				if (!data['game_restore']) {
					GameMgr.Inst.ingame = false;
					uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2012));
					game.Scene_MJ.Inst.ForceOut();
				} else {
					view.DesktopMgr.Inst.syncGameByStep(data['game_restore']);
				}
			}
		}

		public OpenConnectObserve(token: string, location: string) {
			this.is_ob = true;
			uiscript.UI_Loading.Inst.show(uiscript.ELoadingType.EEnterMJ);
			this.Close();
			view.AudioMgr.StopMusic();
			Laya.timer.once(500, this, () => {
				this.server_location = location;
				this.ob_token = token;
				this.openNet();
			});
		}

		private _ConnectSuccessOb() {
			app.Log.log('MJNetMgr _ConnectSuccessOb');
			app.NetAgent.sendReq2MJ('FastTest', 'authObserve', {
				token: this.ob_token,
			}, (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('authObserve', err, res);
					game.Scene_MJ.Inst.GameEnd();
					view.BgmListMgr.PlayLobbyBgm();
				} else {
					app.Log.log('实时OB验证通过：' + JSON.stringify(res));
					uiscript.UI_Loading.Inst.setProgressVal(0.3);
					if (uiscript.UI_Live_Broadcast.Inst) uiscript.UI_Live_Broadcast.Inst.clearPendingUnits();
					app.NetAgent.sendReq2MJ('FastTest', 'startObserve', {}, (err, res) => {
						if (err || res['error']) {
							uiscript.UIMgr.Inst.showNetReqError('startObserve', err, res);
							game.Scene_MJ.Inst.GameEnd();
							view.BgmListMgr.PlayLobbyBgm();
						} else {
							let live_head = res.head;
							let d_config: any = live_head['game_config']['mode'];
							let ai_level = 2;
							let players: Array<Object> = [];
							let ai_name: string = game.Tools.strOfLocalization(2003);
							let e_rule: view.ERuleMode = view.ERuleMode.Liqi4;
							if (d_config.mode < 10) {
								e_rule = view.ERuleMode.Liqi4;
								this.real_player_count = 4;
							} else if (d_config.mode < 20) {
								e_rule = view.ERuleMode.Liqi3;
								this.real_player_count = 3;
							}

							for (let i: number = 0; i < this.real_player_count; i++) {
								players.push(null);
							}
							if (d_config['extendinfo']) {
								//有extendinfo说明是老牌谱，ai是中级电脑
								ai_name = game.Tools.strOfLocalization(2004);
							}
							if (d_config['detail_rule']) {
								if (d_config['detail_rule']['ai_level']) {
									if (d_config['detail_rule']['ai_level'] === 1) {
										ai_name = game.Tools.strOfLocalization(2003);
									}
									if (d_config['detail_rule']['ai_level'] === 2) {
										ai_name = game.Tools.strOfLocalization(2004);
									}
								}
							}
							let ai_skin: number = game.GameUtility.get_default_ai_skin();
							let ai_character: number = game.GameUtility.get_default_ai_character();

							for (let i: number = 0; i < live_head['seat_list'].length; i++) {
								let id: number = live_head['seat_list'][i];
								if (game.Tools.isAI(id)) {
									players[i] = {
										nickname: ai_name,
										avatar_id: ai_skin,
										level: { id: 10101 },
										level3: { id: 20101 },
										character: {
											charid: ai_character,
											level: 0,
											exp: 0,
											views: [],
											skin: ai_skin,
											is_upgraded: false
										}
									};
								} else {
									for (let j: number = 0; j < live_head['players'].length; j++) {
										if (live_head['players'][j]['account_id'] == id) {
											players[i] = live_head['players'][j];
											break;
										}
									}
								}
							}
							for (let i: number = 0; i < this.real_player_count; i++) {
								if (players[i] == null) {
									players[i] = {
										account: 0,
										nickname: game.Tools.strOfLocalization(2010),
										avatar_id: ai_skin,
										level: { id: 10101 },
										level3: { id: 20101 },
										character: {
											charid: ai_character,
											level: 0,
											exp: 0,
											views: [],
											skin: ai_skin,
											is_upgraded: false
										}
									};
								}
							}
							this._StartObSuccuess(players, res.passed, live_head['game_config'].toJSON(), live_head.start_time);
						}
					});
				}
			});
		}

		private _StartObSuccuess(players: Array<Object>, passed, game_config, start_time) {
			if (view.DesktopMgr.Inst && view.DesktopMgr.Inst.active) {
				this.load_over = true;
				Laya.timer.once(500, this, () => {
					app.Log.log('重连信息1 round_id:' + view.DesktopMgr.Inst.round_id + ' step:' + view.DesktopMgr.Inst.current_step);
					view.DesktopMgr.Inst.Reset();
					uiscript.UI_Live_Broadcast.Inst.startRealtimeLive(start_time, passed);
				});
			} else {
				uiscript.UI_Loading.Inst.setProgressVal(0.4);
				game.Scene_MJ.Inst.openMJRoom(game_config, players, Laya.Handler.create(this, () => {
					view.DesktopMgr.Inst.initRoom(JSON.parse(JSON.stringify(game_config)), players, GameMgr.Inst.account_id, view.EMJMode.live_broadcast, Laya.Handler.create(this, () => {
						uiscript.UI_Loading.Inst.setProgressVal(0.9);
						Laya.timer.once(1000, this, () => {
							GameMgr.Inst.EnterMJ();
							uiscript.UI_Loading.Inst.setProgressVal(0.95);
							uiscript.UI_Live_Broadcast.Inst.startRealtimeLive(start_time, passed);
						});
					}));
				}), Laya.Handler.create(this, p => uiscript.UI_Loading.Inst.setProgressVal(0.4 + p * 0.4), null, false));
			}
		}
	}
}