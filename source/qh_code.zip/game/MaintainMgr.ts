module game{

    export enum EMaintainFunctionName {
        /**
         * 随机角色
         */
        RANDOM_CHARACTER = 'random-character',
        /**
         * MAKA分析
         */
        MAKA = 'seer',
    }
    /**
     * 各模块维护信息获取
     */
    export class MaintainMgr { 

        public static maintainInfo: basic.Dictionary<EMaintainFunctionName, IResFetchServerMaintenanceInfo_ServerFunctionMaintenanceInfo> = new basic.Dictionary<EMaintainFunctionName, IResFetchServerMaintenanceInfo_ServerFunctionMaintenanceInfo>();
        /**
         * 维护错误码，如果收到的消息错误码是这个值，说明该模块正在维护
         */
        public static maintainErrorCode: number = 160;
        /**
         * 活动维护错误码
         */
        public static activityMaintainErrorCode: number = 26123;
        

        /**
         * 登录的时候获取一次初始化信息
         */
        public static init() {
            if (!GameMgr.Inst.use_fetch_info) {
                this.fetchMaintainInfo();
            }
        }

        /**
         * 从服务器获取维护信息
         */
        public static fetchMaintainInfo() {
           
            //在登陆时请求维护信息
            let req: game.IReqCommon = {};
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchServerMaintenanceInfo, req, (err, res: game.IResFetchServerMaintenanceInfo) => {
                
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchServerMaintenanceInfo, err, res);
                } else {
                    this.onFetchSuccess(res);
                }
            });
        }

        public static onFetchSuccess(res: game.IResFetchServerMaintenanceInfo) {
            
            app.Log.log('fetchServerMaintenanceInfo' + JSON.stringify(res));
            if (res) {
                let infos = res.function_maintenance;
                if (infos) {
                    for (let index = 0; index < infos.length; index++) {
                        const element = infos[index];
                        this.maintainInfo.set(element.name as EMaintainFunctionName, element);
                    }
                }
                
            }
            
        }

        /**
         * 获取某个模块是否维护
         * @param name 
         * @returns 
         */
        public static isModelMaintain(name: EMaintainFunctionName): boolean { 
            let info = this.maintainInfo.get(name);
            if (info) {
                return info.open;
            }
            return false;
        }

        /**
         * 显示通用的维护提示
         * @returns 
         */
        public static showMaintainTip(onComplete:Laya.Handler = null) { 
            if (GameMgr.client_language == 'kr') {
                uiscript.UIMgr.Inst.ShowErrorInfoChangeFont(game.Tools.strOfLocalization(20210), "NotoSansKR", onComplete);
            }
            else {
                uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(20210), onComplete);
            }
            return;
        }


        /**
         * 2025.12版本，需要即时fetch活动维护数据，暂不更新老的维护数据
          * 从服务器获取活动维护信息
          */
        public static activityMaintainInfo: basic.Dictionary<string, IResFetchServerMaintenanceInfo_ServerActivityMaintenanceInfo>;
        public static fetchActivityMaintainInfo(onComplete: Laya.Handler) {
            this.activityMaintainInfo = new basic.Dictionary<string, IResFetchServerMaintenanceInfo_ServerActivityMaintenanceInfo>();
            let req: game.IReqCommon = {};
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchServerMaintenanceInfo, req, (err, res: game.IResFetchServerMaintenanceInfo) => {
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchServerMaintenanceInfo, err, res);
                } else {
                    app.Log.log('fetchServerMaintenanceInfo' + JSON.stringify(res));
                    if (res) {
                        let infos = res.activity_maintenance;
                        if (infos) {
                            for (let index = 0; index < infos.length; index++) {
                                const element = infos[index];
                                this.activityMaintainInfo.set(element.activity_type, element);
                            }
                        }
                    }
                }
                onComplete && onComplete.run();
            });
        }
        /**
       * 获取某个活动是否维护
       * @param name
       * @returns
       */
        public static isActivityMaintain(activityId: number): boolean {
            if (!this.activityMaintainInfo) return false;
            let config = cfg.activity.activity.get(activityId);
            if (!config) return false;
            let type = config.type;
            let info = this.activityMaintainInfo.get(type);
            if (info) {
                return info.open;
            }
            return false;
        }

    }

}