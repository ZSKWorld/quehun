module game {
    export class PlatformUtil {
        /** 是否是微信小游戏 */
        public static isWeChatMiniGame(): boolean {
            return typeof window["wx"] !== "undefined";
        }

        /** 是否是 QQ 小游戏 */
        public static isQQMiniGame(): boolean {
            return typeof window["qq"] !== "undefined";
        }

        /** 是否是字节跳动小游戏 */
        public static isByteDanceMiniGame(): boolean {
            return typeof window["tt"] !== "undefined";
        }

        /** 是否是快手小游戏 */
        public static isKuaishouMiniGame(): boolean {
            return typeof window["ks"] !== "undefined";
        }

        /** 是否是 Facebook Instant Game */
        public static isFacebookInstantGame(): boolean {
            return typeof window["FBInstant"] !== "undefined";
        }

        /** 是否在原生平台（Conch） */
        public static isNative(): boolean {
            return typeof window["conch"] !== "undefined";
        }

        /** 是否是原生 Android */
        public static isNativeAndroid(): boolean {
            return this.isNative() && navigator.userAgent.indexOf("Android") !== -1;
        }

        /** 是否是原生 iOS */
        public static isNativeIOS(): boolean {
            return this.isNative() && navigator.userAgent.indexOf("iPhone") !== -1;
        }

        /** 是否在 PC 浏览器 */
        public static isPC(): boolean {
            return !this.isMobile() && !this.isNative();
        }

        /** 是否在移动设备（浏览器） */
        public static isMobile(): boolean {
            const ua = navigator.userAgent;
            return /Android|iPhone|iPad|iPod|BlackBerry|Windows Phone|Mobile/i.test(ua) && !this.isNative();
        }

        /** 是否在 H5 网页 */
        public static isWeb(): boolean {
            return !this.isNative() && !this.isWeChatMiniGame() && !this.isQQMiniGame() && !this.isByteDanceMiniGame();
        }
        
        /** 是否支持触摸事件 */
        public static isTouchDevice(): boolean {
            return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        }

        /** 获取当前平台简码 */
        public static getPlatformCode(): string {
            if (this.isWeChatMiniGame()) return "wx";
            if (this.isQQMiniGame()) return "qq";
            if (this.isByteDanceMiniGame()) return "tt";
            if (this.isKuaishouMiniGame()) return "ks";
            if (this.isFacebookInstantGame()) return "fb";
            if (this.isNativeAndroid()) return "native_android";
            if (this.isNativeIOS()) return "native_ios";
            if (this.isPC()) return "pc";
            if (this.isMobile()) return "mobile";
            return "unknown";
        }
    }
}
