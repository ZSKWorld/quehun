/**
* name 
*/
module game {
	export enum GameQuality {
		quality100 = 0,
		quality70 = 1,
		quality80 = 2
	}
	export class ResourceVersion {
		private static _manifest: Object = {};
		private static _version: string = '0.0.0';
		private static _quality: GameQuality = GameQuality.quality100;
		public static get quality(): GameQuality { return this._quality; }
		public static get version(): string { return this._version; }
		// 1是差量素材 0是全量素材
		public static get textureMode(): number {
			if (GameMgr.client_type == 'chs_t' && GameMgr.inRelease) {
				return 1;
			}
			return 0;
		}
		public static localized_map: Object = null

		public static init(complete: Laya.Handler) {
			this._manifest = {};
			LoadMgr.httpload('version.json', 'json', true, Laya.Handler.create(this, this.onManifestLoaded, [Laya.Handler.create(this, () => {
				if (this.textureMode) {
					Laya.loader.load(GameMgr.client_language + '.json', Laya.Handler.create(this, () => {
						this.localized_map = Laya.loader.getRes(GameMgr.client_language + '.json');
						complete.run();
					}));
				} else {
					complete.run();
				}
				
			})]));

			//textureLoadMode:1 差量 0 全量
			if (ResourceVersion.textureMode) {
				this._quality = Laya.LocalStorage.getItem('_gameQuality') ? Number(Laya.LocalStorage.getItem('_gameQuality')) : Laya.Browser.onMobile ? GameQuality.quality70 : GameQuality.quality100;
			} else {
				this._quality = GameQuality.quality100;
			}
			Laya.URL.customFormat = this.formatURL;
		}

		private static onManifestLoaded(callback: Laya.Handler, ret: any) {
			if (ret.success) {
				app.Log.log('version.json加载成功');
				let data = ret.data;
				this._version = data.version;

				LoadMgr.httpload('resversion' + this._version + '.json', 'json', false, Laya.Handler.create(this, this.onResVersionLoaded, [callback]));
			} else {
				app.Log.log('version.json加载失败');
				callback.run();
			}
		}

		private static onResVersionLoaded(callback: Laya.Handler, ret: any) {
			if (ret.success) {
				app.Log.log('Resversion.json加载成功');
				let data = ret.data;
				let ver_map = {};
				for (let _res in data.res) {
					this._manifest[_res] = data.res[_res]['prefix'];
					ver_map[data.res[_res]['prefix']] = 1;
				}
				let self = this;
				if ('serviceWorker' in navigator) {
					caches.keys().then(function (keyList) {
						return Promise.all(keyList.map(function (key) {
							if (key.startsWith('resversion')) {
								if (!key.startsWith('resversion' + self._version)) {
									return caches.delete(key);
								}
							} else if (!ver_map[key]) {
								return caches.delete(key);
							}
						}));
					})
				}
			} else {
				app.Log.log('Resversion.json加载失败');
			}
			callback.run();
		}

		public static formatURL(originURL: string) {
			if (originURL.indexOf("/../") > 0)
				originURL = Laya.URL["formatRelativePath"](originURL);
			if (ResourceVersion.textureMode) {
				var in_res = false;
				var cache_url = originURL.indexOf(GameMgr.client_language + '/') == 0 ? originURL.replace(GameMgr.client_language + '/', '') : originURL;
				if (game.ResourceVersion.localized_map && game.ResourceVersion.localized_map.hasOwnProperty(cache_url)) {
					in_res = true;
					if (game.ResourceVersion.localized_map[cache_url]) {
						originURL = GameMgr.client_language + '/' + cache_url;
					} else {
						originURL = cache_url;
					}

				} else {
					if (GameMgr.client_language == 'chs' && originURL.indexOf(GameMgr.client_language + '/') == 0) {
						originURL = cache_url;
						//中文情况下非res资源可以直接用原图，主要处理图集里的图片

					}
				}
				switch (ResourceVersion.quality) {
					case GameQuality.quality70:
						if (in_res) {
							if (originURL.indexOf(GameMgr.client_language + '/') == 0) {
								originURL = originURL.replace(GameMgr.client_language + '/', 'lang/' + GameMgr.client_language + '_q7/')
							}
							if (originURL.indexOf('myres2/') == 0) {
								originURL = originURL.replace('myres2/', 'lang/base_q7/myres2/');
							}
							if (originURL.indexOf('myres/') == 0) {
								originURL = originURL.replace('myres/', 'lang/base_q7/myres/');
							}
							if (originURL.indexOf('extendRes/') == 0) {
								originURL = originURL.replace('extendRes/', 'lang/base_q7/extendRes/')
							}
						}
						if (originURL.indexOf('scene/') == 0) {
							originURL = originURL.replace('scene/', 'lang/scene_q7/');
						}

						if (originURL.indexOf('res/atlas/') == 0) {
							originURL = originURL.replace('res/atlas/', 'res/atlas_q7/');
						}
						break;
					case GameQuality.quality80:
						if (in_res) {
							if (originURL.indexOf(GameMgr.client_language + '/') == 0) {
								originURL = originURL.replace(GameMgr.client_language + '/', 'lang/' + GameMgr.client_language + '_q8/')
							}
							if (originURL.indexOf('myres2/') == 0) {
								originURL = originURL.replace('myres2/', 'lang/base_q8/myres2/');
							}
							if (originURL.indexOf('myres/') == 0) {
								originURL = originURL.replace('myres/', 'lang/base_q8/myres/');
							}
							if (originURL.indexOf('extendRes/') == 0) {
								originURL = originURL.replace('extendRes/', 'lang/base_q8/extendRes/')
							}
						}
						if (originURL.indexOf('scene/') == 0) {
							originURL = originURL.replace('scene/', 'lang/scene_q8/');
						}

						if (originURL.indexOf('res/atlas/') == 0) {
							originURL = originURL.replace('res/atlas/', 'res/atlas_q8/');
						}
						break;
					case GameQuality.quality100:
						if (in_res) {
							if (originURL.indexOf(GameMgr.client_language + '/') == 0) {
								originURL = originURL.replace(GameMgr.client_language + '/', 'lang/' + GameMgr.client_language + '/')
							}
							if (originURL.indexOf('myres2/') == 0) {
								originURL = originURL.replace('myres2/', 'lang/base/myres2/');
							}
							if (originURL.indexOf('myres/') == 0) {
								originURL = originURL.replace('myres/', 'lang/base/myres/');
							}
							if (originURL.indexOf('extendRes/') == 0) {
								originURL = originURL.replace('extendRes/', 'lang/base/extendRes/')
							}
						}
						if (originURL.indexOf('scene/') == 0) {
							originURL = originURL.replace('scene/', 'lang/scene/');
						}

				}
			}
			// console.log(originURL)
			if (ResourceVersion._manifest.hasOwnProperty(originURL)) return ResourceVersion._manifest[originURL] + '/' + originURL;
			else return originURL;
		}

		public static setQuality(quality: GameQuality) {
			quality = quality != null ? quality : Laya.Browser.onPC ? GameQuality.quality80 : GameQuality.quality70;
			Laya.LocalStorage.setItem('_gameQuality', quality.toString());
		}


	}
}