/**
* name 
*/
module game{
	/**
	 * GG: 2022-1-20
	 * 临时图片管理器：针对那些UI打开状态下加载然后在UI关闭后需要卸载的图片
	 * setUIEnable：需要参与管理的UI需要在打开的时候调用一下，关闭的时候也调用一下，会自动卸载图片
	 * addImg：把临时图片加入管理器，关闭的时候会卸载
	 */
	export class TempImageMgr {

		private static ui_imags:Object = {};
		private static img_counts:Object = {}; // 图片计数

		public static setUIEnable(tag:string, enable:boolean) {
			if (this.ui_imags.hasOwnProperty(tag)) {
				let info = this.ui_imags[tag];
				if (info.enable != enable) {
					info.enable = enable;
					if (!enable) {
						let list = info.imgs;
						for (let i:number = 0; i < list.length; i++) {
							this.reduceImgCount(list[i]);
						}
						info.imgs = [];
					}
				}
			} else {
				this.ui_imags[tag] = {
					enable: enable,
					imgs: []
				}
			}
		}

		public static addImg(tag:string, skin:string):boolean {
			if (tag == '') return false;
			if (!this.ui_imags.hasOwnProperty(tag)) {
				this.ui_imags[tag] = {
					enable: true,
					imgs: []
				}
			}
			this.addImgCount(skin);
			this.ui_imags[tag].imgs.push(skin);
			return true;
		}

		public static addImgCount(skin: string) {
			if (this.img_counts[skin]) {
				this.img_counts[skin]++;;
			} else {
				this.img_counts[skin] = 1;
			}
		}

		public static reduceImgCount(skin: string) {
			let count = this.img_counts[skin];
			if (!this.img_counts[skin] || this.img_counts[skin] <= 1) {
				Laya.Loader.clearTextureRes(skin);
				this.img_counts[skin] = 0;
			} else {
				this.img_counts[skin]--;
			}
		}
	}
}