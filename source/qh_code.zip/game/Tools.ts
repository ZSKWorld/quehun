/**
* name 
*/
module game {
	export class Tools {
		public static get currentTime(): number {
			return Math.floor(Date.now() / 1000);
		}

		public static time2YearMounthDate(time: number, split: string = '/'): string {
			let date: Date = new Date(time * 1000);
			let s_date: string = '';
			s_date += date.getFullYear() + split;
			s_date += (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1).toString() + split;
			s_date += (date.getDate() < 10 ? '0' : '') + date.getDate();
			return s_date;
		}

		/**
		 * 把unix时间戳（秒） 转化成小时：分,这里传入的是具体的时间，返回的是，当天的小时分钟秒，不是时间长度
		 * @param time 单位秒
		 * @param need_second 是否需要秒
		 * @returns 
		 */
		public static time2HourMinute(time: number, need_second: boolean = false): string {
			let date: Date = new Date(time * 1000);
			let s_date: string = '';
			s_date += (date.getHours() < 10 ? '0' : '') + date.getHours() + ':';
			s_date += (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
			if (need_second) {
				s_date += ':';
				s_date += (date.getSeconds() < 10 ? '0' : '') + date.getSeconds();
			}
			return s_date;
		}

		public static time2YearMounthDateHourMinute(time: number, split: string = '/'): string {
			let date: Date = new Date(time * 1000);
			let s_date: string = '';
			s_date += date.getFullYear() + split;
			s_date += (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1).toString() + split;
			s_date += (date.getDate() < 10 ? '0' : '') + date.getDate() + ' ';
			s_date += (date.getHours() < 10 ? '0' : '') + date.getHours() + ':';
			s_date += (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
			return s_date;
		}

		public static time2YearMounthDateHourMinuteSeconds(time: number, split: string = '/'): string {
			let date: Date = new Date(time * 1000);
			let s_date: string = '';
			s_date += date.getFullYear() + split;
			s_date += (date.getMonth() < 9 ? '0' : '') + (date.getMonth() + 1).toString() + split;
			s_date += (date.getDate() < 10 ? '0' : '') + date.getDate() + ' ';
			s_date += (date.getHours() < 10 ? '0' : '') + date.getHours() + ':';
			s_date += (date.getMinutes() < 10 ? '0' : '') + date.getMinutes() + ":";
			s_date += (date.getSeconds() < 10 ? '0' : '') + date.getSeconds();
			return s_date;
		}


		//把unix时间戳（秒）根据现在时间转化成“刚刚”、“10分钟前”这样的描述
		public static time2Desc(time: number): string {
			let _current_time: number = Math.floor(Date.now() / 1000);
			let delta_time: number = _current_time - time;
			if (delta_time < 10 * 60) {
				return game.Tools.strOfLocalization(2013);
			} else if (delta_time < 60 * 60) {
				let k: number = Math.floor(delta_time / 10 / 60);
				return k.toString() + '0' + game.Tools.strOfLocalization(2014);
			} else if (delta_time < 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2015);
			} else if (delta_time < 7 * 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 24 / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2016);
			} else if (delta_time < 4 * 7 * 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 7 / 24 / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2017);
			} else {
				return '1' + game.Tools.strOfLocalization(2018);
			}
		}

		public static time2DescServer(time: number): string {
			let _current_time: number = Math.floor((Date.now() + GameMgr.Inst.server_time_delta) / 1000);
			let delta_time: number = _current_time - time;
			if (delta_time < 10 * 60) {
				return game.Tools.strOfLocalization(2013);
			} else if (delta_time < 60 * 60) {
				let k: number = Math.floor(delta_time / 10 / 60);
				return k.toString() + '0' + game.Tools.strOfLocalization(2014);
			} else if (delta_time < 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2015);
			} else if (delta_time < 7 * 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 24 / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2016);
			} else if (delta_time < 4 * 7 * 24 * 60 * 60) {
				let k: number = Math.floor(delta_time / 7 / 24 / 60 / 60);
				return k.toString() + game.Tools.strOfLocalization(2017);
			} else {
				return '1' + game.Tools.strOfLocalization(2018);
			}
		}

		//把时间长度（秒）转化成13天5小时6分钟这样的描述
		public static timelength2Desc(timelength: number): string {
			let s: string = '';
			let k: number = timelength;
			if (k % 60 > 0) s = k % 60 + game.Tools.strOfLocalization(2019);
			k = Math.floor(k / 60);
			if (k % 60 > 0) s = k % 60 + game.Tools.strOfLocalization(2020) + s;
			k = Math.floor(k / 60);
			if (k % 24 > 0) s = k % 24 + game.Tools.strOfLocalization(2021) + s;
			k = Math.floor(k / 24);
			if (k > 0) s = k + game.Tools.strOfLocalization(2022) + s;
			if (s == '') s = '0' + game.Tools.strOfLocalization(2019);
			return s;
		}

		public static playState2Desc(play: any): string {
			if (!play) return '';
			if (!play.game_uuid || play.game_uuid == '') return '';
			if (play.category == 1) return game.Tools.strOfLocalization(2023);
			if (play.category == 2 && play.meta) {
				let d = cfg.desktop.matchmode.get(play.meta.mode_id);
				if (d) return d['room_name_' + GameMgr.client_language];
			}
			if (play.category == 4) {
				return game.Tools.strOfLocalization(2025);
			}
			return '';
		}

		public static setGrayDisable(sprite: Laya.Sprite, v: boolean) {
			if (!sprite) {
				return;
			}
			if (v) {
				sprite.mouseEnabled = false;
				sprite.filters = [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
			} else {
				sprite.mouseEnabled = true;
				sprite.filters = [];
			}
		}

		public static setGray(sprite: Laya.Sprite, v: boolean) {
			if (!sprite) {
				return;
			}
			if (v) {
				sprite.filters = [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
			} else {
				sprite.filters = [];
			}
		}

		public static generateUUID(): string {
			var d = new Date().getTime();
			var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
				var r = (d + Math.random() * 16) % 16 | 0;
				d = Math.floor(d / 16);
				return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
			});
			return uuid;
		}

		// 获取 GPU 信息
		private static gpuText(gpuText) {
			try {
				if (/, or similar$/.test(gpuText)) return 'Unknown';
				if (/SwiftShader/.test(gpuText)) return 'Unknown';
				if (/^ANGLE/.test(gpuText)) {
					let t = gpuText.match(/\((.+)\)$/)[1],
						n = t.split(/,\s*/g),
						[_, info] = n;

					if (/^ANGLE Metal Renderer: /.test(info)) {
						info = gpuText.split(": ")[1].split(",")[0];
					}

					if (n.length === 1) {
						info = n[0].split(" ").slice(1).join(" ");
					}

					// 如果 i 包含 "Direct3D"，则将 i 重置为相应的值
					if (/Direct3D/.test(info)) {
						info = info.split("Direct3D")[0].trim();
					}
					if (/\(0x/.test(info)) {
						info = info.split("(0x")[0].trim();
					}
					return info;
				}
			} catch (err) {
				console.log('err: ', err);
			}

			let t = [], n = gpuText.split("");
			for (let r = 0; r < n.length; r++)
				if (n[r] === "(") t.push(r);
				else if (n[r] === ")") {
					let i = t.pop();
					i !== void 0 && (n.splice(i, r - i + 1), r = i - 1);
				}
			return n.join("").replace(/\/PCIe\/SSE2/g, "").replace(/\s+/g, " ").trim();
		}

		public static get deviceInfo(): Object {
			let info: Object = {};
			info['client-version'] = game.ResourceVersion.version;
			let deviceinfos: Array<string> = [];
			if (Laya.Browser.onIPhone) deviceinfos.push('iPhone');
			else if (Laya.Browser.onIPad) deviceinfos.push('iPad');
			else if (Laya.Browser.onMac) deviceinfos.push('mac');
			else if (Laya.Browser.onAndriod || Laya.Browser.onAndroid) deviceinfos.push('android');
			else if (game.PlatformUtil.isPC()) deviceinfos.push('pc');
			// if (Laya.Browser.onIOS) deviceinfos.push('iOS');
			// if (Laya.Browser.onMac) deviceinfos.push('mac');
			// if (Laya.Browser.onIPad) deviceinfos.push('iPad');
			// if (Laya.Browser.onAndriod || Laya.Browser.onAndroid) deviceinfos.push('android');
			// if (Laya.Browser.onSafari) deviceinfos.push('onSafari');
			// if (Laya.Browser.onFirefox) deviceinfos.push('onFirefox');
			// if (Laya.Browser.onEdge) deviceinfos.push('onEdge');
			// if (Laya.Browser.onWeiXin) deviceinfos.push('onWeiXin');
			// if (Laya.Browser.onMiniGame) deviceinfos.push('onMiniGame');
			// if (Laya.Browser.onMQQBrowser) deviceinfos.push('onMQQBrowser');
			// if (Laya.Render.isConchApp) {
			// 	deviceinfos.push('onApp');
			// } else if (Laya.Browser.onPC) deviceinfos.push('pc');
			if (deviceinfos.length > 0) {
				let sd: string = '';
				for (let i: number = 0; i < deviceinfos.length; i++) {
					if (i != 0) sd += '|';
					sd += deviceinfos[i];
				}
				info['device'] = sd;
			} else {
				info['device'] = 'unknown';
			}
			info['webgl2'] = laya.utils.RunDriver.WebGL2;

			let gpuText = '';
			try {
				const debugInfo = Laya.WebGL.mainContext.getExtension('WEBGL_debug_renderer_info');
				gpuText = debugInfo ? Laya.WebGL.mainContext.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : 'unknown';
			} catch (error) {
				gpuText = 'unknown';
			}
			// const platform = window['platform'];

			// if (platform) {
			// 	info['device_model'] = ((platform.manufacturer || '') + ' ' + (platform.product || '')).trim() || 'unknown';
			// 	// info['device_name'] = info['device_model'];
			// 	info['device_os'] = platform.os.toString();
			// 	// info['device_browser'] = platform.name + ' ' + platform.version;
			// 	info['device_gpu_name'] = this.gpuText(gpuText);
			// 	if (platform.product == 'iPhone') {
			// 		const iphoneMap: { [key: string]: string[] } = {
			// 			'2796_1290': ['iPhone 16 Pro Max', 'iPhone 16 Plus', 'iPhone 15 Pro Max', 'iPhone 15 Plus', 'iPhone 14 Pro Max'],
			// 			'2778_1284': ['iPhone 14 Plus', 'iPhone 13 Pro Max', 'iPhone 12 Pro Max'],
			// 			'2688_1242': ['iPhone 11 Pro Max', 'iPhone XS Max'],
			// 			'2622_1206': ['iPhone 16 Pro'],
			// 			'2556_1179': ['iPhone 16', 'iPhone 15 Pro', 'iPhone 15', 'iPhone 14 Pro'],
			// 			'2532_1170': ['iPhone 14', 'iPhone 13 Pro', 'iPhone 13', 'iPhone 12 Pro', 'iPhone 12'],
			// 			'2436_1125': ['iPhone 11 Pro', 'iPhone XS', 'iPhone X'],
			// 			'2340_1080': ['iPhone 13 mini', 'iPhone 12 mini'],
			// 			'1920_1080': ['iPhone 8 Plus', 'iPhone 7 Plus', 'iPhone 6s Plus', 'iPhone 6 Plus'],
			// 			'1792_828': ['iPhone 11', 'iPhone XR'],
			// 			'1334_750': ['iPhone SE (2022)', 'iPhone SE (2020)', 'iPhone 8', 'iPhone 7', 'iPhone 6s', 'iPhone 6',],
			// 			'1136_640': ['iPhone SE (2016)', 'iPhone 5c', 'iPhone 5s', 'iPhone 5'],
			// 			'960_640': ['iPhone 4s', 'iPhone 4'],
			// 			'480_320': ['iPhone 3GS', 'iPhone 3G', 'iPhone 2G'],
			// 		};
			// 		const width = screen.width * devicePixelRatio;
			// 		const height = screen.height * devicePixelRatio;
			// 		const model = iphoneMap[`${Math.max(width, height)}_${Math.min(width, height)}`];
			// 		info['device_model'] = model ? model.join(' or ') : info['device_model'];
			// 	} else if (platform.product == 'iPad' || Laya.Browser.onIPad || Laya.Browser.onMac) {
			// 		const ipadMap: { [key: string]: string[] } = {
			// 			'2752_2064': ['iPad Pro 13c'],
			// 			'2732_2048': ['iPad Air 13c', 'iPad Pro 12.9c'],
			// 			'2388_1668': ['iPad Pro 11c'],
			// 			'2360_1640': ['iPad 10', 'iPad Air 5', 'iPad Air 4'],
			// 			'2266_1488': ['iPad mini 6'],
			// 			'2224_1668': ['iPad Air 3', 'iPad Pro 10.5c'],
			// 			'2160_1620': ['iPad 9', 'iPad 8', 'iPad 7'],
			// 			'2048_1536': ['iPad 6', 'iPad 5', 'iPad mini 5', 'iPad mini 4', 'iPad mini 3', 'iPad mini 2', 'iPad Air 2', 'iPad Air 1', 'iPad Pro 9.7c'],
			// 			'1024_768': ['iPad 2', 'iPad mini 1'],
			// 		};
			// 		const width = screen.width * devicePixelRatio;
			// 		const height = screen.height * devicePixelRatio;
			// 		const model = ipadMap[`${Math.max(width, height)}_${Math.min(width, height)}`];
			// 		info['device_model'] = model ? model.join(' or ') : info['device_model'];
			// 	}
			// }
			return info;
		}

		//文字转化屏蔽字
		public static strWithoutForbidden(content: string, is_long: boolean = false): string {
			let _str: string = content;
			if (!_str) return '';
			if (!is_long) {
				if (app.Taboo.test(_str)) {
					return '******';
				}
				return _str;
			} else {
				let code_0: number = '0'.charCodeAt(0);
				let code_a: number = 'a'.charCodeAt(0);
				let code_A: number = 'A'.charCodeAt(0);
				let s: string = '';
				let index: number = 0;
				for (let i: number = 0; i < content.length; i++) {
					let _code: number = content.charCodeAt(i);
					if (_code > 256) continue;
					if (_code >= code_0 && _code < code_0 + 10) continue;
					if (_code >= code_A && _code < code_A + 26) continue;
					if (_code >= code_a && _code < code_a + 26) continue;
					if (index < i) {
						let word: string = content.substring(index, i);
						if (app.Taboo.test(word)) {
							s += '******';
						} else {
							s += word;
						}
					}
					s += content.charAt(i);
					index = i + 1;
				}
				if (index < content.length) {
					let word: string = content.substring(index, content.length);
					if (app.Taboo.test(word)) {
						s += '******';
					} else {
						s += word;
					}
				}
				return s;
			}

		}

		// 是不是含有屏蔽词
		public static isStrTaboo(str: string): boolean {
			let ret: boolean = false;
			cfg.info.forbidden.forEach((value, index) => {
				if (ret || value.word == '') return;
				if (str.indexOf(value.word) >= 0) {
					ret = true;
				}
			});
			return ret;
		}

		//face_img一定要是部位的直接子节点
		//part_name: full|half|smallhead
		public static faceOn(skin_id: number, face_name: string, part_name: string, face_mask_img: Laya.Image, part_img: Laya.Image, is_roll: boolean = false, face_img: Laya.Image = null, is_spot: boolean = true) {
			face_mask_img.visible = false;
			face_img.visible = false;
			let d_skin = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return;
			game.LoadMgr.setImgSkin(face_mask_img, (d_skin.path + '/' + face_name + '.png'));

			let rate_w: number = part_img.width / d_skin[part_name + '_width'];
			let rate_h: number = part_img.height / d_skin[part_name + '_height'];

			face_mask_img.anchorX = 0;
			face_mask_img.anchorY = 0;
			face_mask_img.width = d_skin.smallhead_width * rate_w;
			face_mask_img.height = d_skin.smallhead_width * rate_h;
			face_mask_img.x = (d_skin.smallhead_x - d_skin[part_name + '_x']) * rate_w;
			face_mask_img.y = (d_skin.smallhead_y - d_skin[part_name + '_y']) * rate_h;
			if (is_roll && d_skin.no_reverse && !d_skin.lock_reverse) {
				face_mask_img.scaleX = -1;
				let anchorX: number = 0;
				if (part_img.anchorX) anchorX = part_img.anchorX;
				face_mask_img.x -= 2 * (face_mask_img.x - (d_skin[part_name + '_x'] - d_skin.full_x - anchorX) * part_img.width);
			} else face_mask_img.scaleX = 1;

			if (face_img) {
				face_img.anchorX = 0;
				face_img.anchorY = 0;
				face_img.width = face_mask_img.width;
				face_img.height = face_mask_img.width;
				face_img.scaleX = face_mask_img.scaleX * (face_mask_img.parent as Laya.Sprite).scaleX;
				face_img.x = part_img.x + (face_mask_img.x - part_img.width * (part_img.anchorX ? part_img.anchorX : 0)) * face_img.scaleX;
				face_img.y = face_mask_img.y + part_img.y - part_img.height * (part_img.anchorY ? part_img.anchorY : 0);


				game.LoadMgr.setImgSkin(face_img, (d_skin.path + '/' + face_name + '.png'));
			}


			face_mask_img.visible = true;
			face_img.visible = true;
		}

		// 新设置表情
		public static faceOnNew(skin_id: number, face_name: string, part_name: string, img: Laya.Image, part_img: Laya.Image, is_roll: boolean = false) {
			let d_skin = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return;
			let anchor = Tools.getSmallHead(skin_id, part_name, img.width, img.height, is_roll);
			game.LoadMgr.setImgSkin(part_img, (d_skin.path + '/' + face_name + '.png'), Laya.Handler.create(this, () => {
				img.emoSkin = { skin: part_img.skin, anchor };
			}));
		}

		public static getSmallHead(skin_id: number, part_name: string, img_width: number, img_height: number, is_roll: boolean = false): Laya.Vector4 {
			let d_skin = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return;
			let rate_w: number = img_width / d_skin[part_name + '_width'];
			let rate_h: number = img_height / d_skin[part_name + '_height'];

			let width = d_skin.smallhead_width * rate_w;
			let height = d_skin.smallhead_width * rate_h;
			let x = (d_skin.smallhead_x - d_skin[part_name + '_x']) * rate_w;
			let y = (d_skin.smallhead_y - d_skin[part_name + '_y']) * rate_h;
			let anchor = new Laya.Vector4();
			if (is_roll && d_skin.no_reverse && !d_skin.lock_reverse) {
				anchor.x = x / img_width;
				anchor.y = y / img_height;
				anchor.z = width / img_width;
				anchor.w = height / img_height;
			} else {
				anchor.x = x / img_width;
				anchor.y = y / img_height;
				anchor.z = width / img_width;
				anchor.w = height / img_height;
			}
			return anchor
		}

		// 新规范计算表情位置
		public static CalculateEmo(skin_id: number, story:string, complete: Laya.Handler = null): boolean {
			let skin_info = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id);
			if (!skin_info || skin_info.illust_data == null || skin_info.illust_data == "")
				return false;

			// 加载对应立绘的json文件
			let skinData = skin_info.path.split('/');
			if (skinData.length <= 0)
				return false;
			let folder = skinData[skinData.length - 1]
			let illustName = story && story != '' ? `${skin_info.illust_data}_${story}` : skin_info.illust_data;
			let jsonPath = Tools.localUISrc(`extendRes/illust_data/${illustName}.json`);
			let illust = Laya.loader.getRes(jsonPath);
			if (illust) {
				if (!this.defaultIllust) {
					let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
					Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
						let defaultStr = Laya.loader.getRes(defaultPath);
						if (!defaultStr) {
							return false;
						}
						this.defaultIllust = defaultStr.default;
						if (!this.defaultIllust)
							return false;
						return this._calculateEmo(skin_info, illust, complete);
					}));
				}
				else {
					return this._calculateEmo(skin_info, illust, complete);
				}
			} else {
				Laya.loader.load(jsonPath, Laya.Handler.create(this, () => {
					let illust = Laya.loader.getRes(jsonPath);
					if (!illust) {
						return false;
					}

					if (!this.defaultIllust) {
						let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
						Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
							let defaultStr = Laya.loader.getRes(defaultPath);
							if (!defaultStr) {
								return false;
							}
							this.defaultIllust = defaultStr.default;
							if (!this.defaultIllust)
								return false;
							return this._calculateEmo(skin_info, illust, complete);
						}));
					}
					else {
						return this._calculateEmo(skin_info, illust, complete);
					}
				}))
			}
			return true
		}

		private static _calculateEmo(skin_info: lqc.Sheet_Spot_SkinSpot | lqc.Sheet_ItemDefinition_Skin, illust: any, complete: Laya.Handler = null): boolean {
 			let data: any = { anchor: new Laya.Vector4(), isSmallHead: false }
			if (illust.head) {
				data.anchor.x = illust.head.x;
				data.anchor.y = illust.head.y;
				data.anchor.z = illust.head.w / illust.w;
				data.anchor.w = illust.head.h / illust.h;
			} else {
				data.anchor.x = -(this.defaultIllust['H0'][0].x + 55) / (illust.w * illust["H0"][0].scale * this.defaultIllust['H0'][0].scale) - illust["H0"][0].x
				data.anchor.y = (this.defaultIllust['H0'][0].y - 55) / (illust.h * illust["H0"][0].scale * this.defaultIllust['H0'][0].scale) + illust["H0"][0].y
				data.anchor.z = 110 / illust["H0"][0].scale / this.defaultIllust['H0'][0].scale / illust.w
				data.anchor.w = 110 / illust["H0"][0].scale / this.defaultIllust['H0'][0].scale / illust.h
				data.isSmallHead = true;
			}
			if (complete) {
				complete.runWith(data);
			}
			return true;
		}

		public static DoHeadCalculate(skin_id: number, part_name, img_width: number, img_height: number, story:string, complete: Laya.Handler = null) {
			if (!this.CalculateEmo(skin_id, story, complete)) {
				let data = { anchor: this.getSmallHead(skin_id, part_name, img_width, img_height), isSmallHead: true };
				if (complete) {
					complete.runWith(data);
				}
			}
		}

		//获取新规格角色立绘默认数据
		private static defaultIllust: any;
		public static CalculateIllust(img: Laya.Image, skin_id: number, index: number, type: string, uitag: string = '', story: string = '',force_offset: Laya.Vector4 = null, complete: Laya.Handler = null, checkHandler: Laya.Handler = null): boolean {
			if (type == null || type == '') return false;
			let skin_info = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id)
			if (!skin_info) return false;
			if (skin_info.illust_data == null || skin_info.illust_data == "")
				return false
			let illustName = story && story != '' ? `${skin_info.illust_data}_${story}` : skin_info.illust_data;
			let jsonPath = Tools.localUISrc(`extendRes/illust_data/${illustName}.json`);
			let illust = Laya.loader.getRes(jsonPath);
			if (illust) {
				if (!this.defaultIllust) {
					let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
					Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
						let defaultStr = Laya.loader.getRes(defaultPath);
						if (!defaultStr) {
							return;
						}
						this.defaultIllust = defaultStr.default;
						if (!this.defaultIllust)
							return;
						this._calculateIllust(illust, skin_info, img, index, type, uitag, story, force_offset, complete, checkHandler);
					}));
				}
				else {
					this._calculateIllust(illust, skin_info, img, index, type, uitag, story, force_offset, complete, checkHandler);
				}
			} else {
				Laya.loader.load(jsonPath, Laya.Handler.create(this, () => {
					let illust = Laya.loader.getRes(jsonPath);
					if (!illust) {
						return;
					}

					if (!this.defaultIllust) {
						let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
						Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
							let defaultStr = Laya.loader.getRes(defaultPath);
							if (!defaultStr) {
								return;
							}
							this.defaultIllust = defaultStr.default;
							if (!this.defaultIllust)
								return;
							this._calculateIllust(illust, skin_info, img, index, type, uitag, story, force_offset, complete, checkHandler);
						}));
					}
					else {
						this._calculateIllust(illust, skin_info, img, index, type, uitag, story, force_offset, complete, checkHandler);
					}
				}))
			}
			return true;
		}

		public static SetIllustData(skin_id: number, type: string, index: number, force_offset: Laya.Vector4, complete: Laya.Handler) {
			let skin_info = cfg.spot.skin_spot.get(skin_id) || cfg.item_definition.skin.get(skin_id)
			if (!skin_info || skin_info.illust_data == null || skin_info.illust_data == "")
				return;

			let jsonPath = Tools.localUISrc(`extendRes/illust_data/${skin_info.illust_data}.json`);
			let illust = Laya.loader.getRes(jsonPath);
			if (illust) {
				if (!this.defaultIllust) {
					let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
					Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
						let defaultStr = Laya.loader.getRes(defaultPath);
						if (!defaultStr) {
							return;
						}
						this.defaultIllust = defaultStr.default;
						if (!this.defaultIllust)
							return;
						this._setIllustData(illust, this.defaultIllust, type, index, force_offset, complete);
					}));
				}
				else {
					this._setIllustData(illust, this.defaultIllust, type, index, force_offset, complete);
				}
			} else {
				Laya.loader.load(jsonPath, Laya.Handler.create(this, () => {
					let illust = Laya.loader.getRes(jsonPath);
					if (!illust)
						return
					if (!this.defaultIllust) {
						let defaultPath: string = Tools.localUISrc('extendRes/illust_data/default.json');
						Laya.loader.load(defaultPath, Laya.Handler.create(this, () => {
							let defaultStr = Laya.loader.getRes(defaultPath);
							if (!defaultStr) {
								return;
							}
							this.defaultIllust = defaultStr.default;
							if (!this.defaultIllust)
								return;
							this._setIllustData(illust, this.defaultIllust, type, index, force_offset, complete);
						}));
					}
					else {
						this._setIllustData(illust, this.defaultIllust, type, index, force_offset, complete);
					}
				}))
			}
		}

		private static _setIllustData(illust: any, defaultIllust: any, type: string, index: number, force_offset: Laya.Vector4, complete: Laya.Handler) {
			let primaryKey: string = type;
			let match = type.match(/[A-Z]/g);
			if (match && match.length > 0) {
				primaryKey = match[0] + '0';
			}
			index = index ? index : 0;

			let defaultData = this.defaultIllust[type] ? this.defaultIllust[type] : this.defaultIllust[primaryKey];
			defaultData = (defaultData && defaultData[index]) ? defaultData[index] : defaultData;
			let illustData = illust[type] ? illust[type] : illust[primaryKey];
			illustData = (illustData && illustData[index]) ? illustData[index] : illustData;

			if (!defaultData || !illustData)
				return false;

			let width: number = defaultData.scale * illust.w;
			let height: number = defaultData.scale * illust.h;
			let x: number = type == 'spot' ? (-1 * illust.center * width * illustData.scale) : (defaultData.x + illustData.x * width * illustData.scale);
			let y: number = -(defaultData.y + illustData.y * height * illustData.scale);

			let offsetX: number = force_offset ? force_offset.x : defaultData.offset.x;
			let offsetY: number = force_offset ? force_offset.y : defaultData.offset.y;
			let offset_scaleX = force_offset ? force_offset.z : defaultData.offset.scaleX;
			let offset_scaleY = force_offset ? force_offset.w : defaultData.offset.scaleY;
			x = offsetX + x / offset_scaleX;
			y = offsetY + y / offset_scaleY;
			width /= Math.abs(offset_scaleX);
			height /= Math.abs(offset_scaleY);
			if (complete)
				complete.runWith({
					delta_x: x,
					delta_y: y,
					width: width * illustData.scale,
					height: height * illustData.scale,
					scale: illustData.scale,
					offsetScale: offset_scaleX
				});
			return;
		}

		private static _calculateIllust(illust: any, skin_info: any, img: Laya.Image, index: number, type: string, uitag: string, story: string = '', force_offset: Laya.Vector4 = null, complete: Laya.Handler = null, checkHandler: Laya.Handler = null) {
			if (checkHandler && !checkHandler.run()) {
				return;
			}
			if (!img || img.destroyed) return;
			let primaryKey: string = type;
			let match = type.match(/[A-Z]/g);
			if (match && match.length > 0) {
				primaryKey = match[0] + '0';
			}
			index = index ? index : 0;

			let defaultData = this.defaultIllust[type] ? this.defaultIllust[type] : this.defaultIllust[primaryKey];
			defaultData = (defaultData && defaultData[index]) ? defaultData[index] : defaultData;
			let illustData = illust[type] ? illust[type] : illust[primaryKey];
			illustData = (illustData && illustData[index]) ? illustData[index] : illustData;

			if (!defaultData || !illustData)
				return false;

			let symbol: number = illustData.reverse ? -1 : 1;
			if (skin_info.lock_reverse) symbol = 1;
			let path = skin_info.path + '/full.png';
			if (story && story != '') {
				path = skin_info.path + `/full_${story}.png`;
			}
			// 因为和服的衣襟问题涉及到活人死人，如果不许强行翻转但是UI里已经翻转了需要使用翻转文件夹里的文件
			if (symbol <= 0 && skin_info.no_reverse) {
				path = skin_info.path + '/reverse/full.png';
			}
			game.LoadMgr.setImgSkin(img, path, null, uitag);

			let width: number = defaultData.scale * illust.w;
			let height: number = defaultData.scale * illust.h;
			let x: number = type == 'spot' ? (-1 * illust.center * width * illustData.scale) : (defaultData.x + illustData.x * width * illustData.scale);
			let y: number = -(defaultData.y + illustData.y * height * illustData.scale);

			if (symbol < 0)
				x += 2 * illust.center * width;

			let offsetX: number = force_offset ? force_offset.x : defaultData.offset.x;
			let offsetY: number = force_offset ? force_offset.y : defaultData.offset.y;
			let offset_scaleX = force_offset ? force_offset.z : defaultData.offset.scaleX;
			let offset_scaleY = force_offset ? force_offset.w : defaultData.offset.scaleY;
			x = offsetX + x / offset_scaleX;
			y = offsetY + y / offset_scaleY;
			width /= Math.abs(offset_scaleX);
			height /= Math.abs(offset_scaleY);

			symbol = symbol * (offset_scaleX > 0 ? 1 : -1);
			if (skin_info.lock_reverse > 0)
				symbol = offset_scaleX > 0 ? 1 : - 1;

			img.scale(illustData.scale * symbol, illustData.scale)
			img.width = width;
			img.height = height;
			img.x = x;
			img.y = y;

			if(complete){
				complete.run();
			}
			return true;
		}

		//设置角色立绘的图片，需要记录标准的值， need_pending_direction==true时需要判定该角色是否和一姬方向相反
		public static charaPart(skin_id: number, img: Laya.Image, part_name: string, standard_rect: uiscript.UIRect, need_pending_direction: boolean = false, attached_to_head: boolean = false, force_roll: boolean = false, only_pos: boolean = false, uitag: string = '', type: string = '', is_spot: boolean = false) {
			let origin_scaleX = img.scaleX;
			let origin_scaleY = img.scaleY;
			let skin_data = this.getSkinData(skin_id, standard_rect, part_name, attached_to_head, origin_scaleX, origin_scaleY, type, is_spot);
			let d_img_standard = cfg.item_definition.skin.get(400101); //以一姬的初始皮肤当的标准
			if (!d_img_standard) return;
			let d_skin = (is_spot && cfg.spot.skin_spot.get(skin_id)) || cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return;


			let father_scale_x: number = 1;
			let _father: Laya.Sprite = img.parent as Laya.Sprite;
			if (_father) {
				father_scale_x *= _father.scaleX > 0 ? 1 : -1;
				_father = _father.parent as Laya.Sprite;
				if (_father) {
					father_scale_x *= _father.scaleX > 0 ? 1 : -1;
				}
			}

			if (need_pending_direction && skin_data['diff_direction']) {
				img.scaleX = -1 * origin_scaleX;
			}
			if (force_roll) {
				img.scaleX = -1 * origin_scaleX;
			}

			let width = skin_data['width'];
			let height = skin_data['height'];
			let x = standard_rect.x + skin_data['delta_x'];
			let y = standard_rect.y + skin_data['delta_y'];
			let center_x = skin_data['center_x'];
			if (!only_pos) {
				if (img.scaleX * father_scale_x > 0) {
					// img.skin = game.LoadMgr.getResImageSkin(d_skin.path + '/' + part_name + '.png');
					game.LoadMgr.setImgSkin(img, d_skin.path + '/' + part_name + '.png', null, uitag);
				} else {
					if (d_skin.lock_reverse) {
						img.scaleX *= -1;
						game.LoadMgr.setImgSkin(img, d_skin.path + '/' + part_name + '.png', null, uitag);
					} else if (d_skin.no_reverse) {
						game.LoadMgr.setImgSkin(img, d_skin.path + '/reverse/' + part_name + '.png', null, uitag);
						// img.skin = game.LoadMgr.getResImageSkin(d_skin.path + '/reverse/' + part_name + '.png');
					} else {
						// img.skin = game.LoadMgr.getResImageSkin(d_skin.path + '/' + part_name + '.png');
						game.LoadMgr.setImgSkin(img, d_skin.path + '/' + part_name + '.png', null, uitag);
					}
				}
			}

			if (img.scaleX < 0) {
				x += 2 * center_x * width;
			}

			img.width = width;
			img.height = height;
			img.x = x;
			img.y = y;
		}

		public static getSkinData(skin_id: number, standard_rect: uiscript.UIRect, part_name: string, attached_to_head: boolean, scale_x: number, scale_y: number, type: string = '', is_spot: boolean = false) {
			let d_img_standard = cfg.item_definition.skin.get(400101); //以一姬的初始皮肤当的标准
			if (!d_img_standard) return null;
			let d_skin = (is_spot && cfg.spot.skin_spot.get(skin_id)) || cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return null;
			let width = standard_rect.width * d_skin[part_name + '_width'] / d_img_standard[part_name + '_width'];
			let height = standard_rect.height * d_skin[part_name + '_height'] / d_img_standard[part_name + '_height'];

			let delta_x = 0;
			let delta_y = 0;

			if (!attached_to_head) {
				let offset_x = 0;
				let offset_y = 0;
				if (type && d_skin[type + '_offset']) {
					let strs = d_skin[type + '_offset'].split(',');
					offset_x = Number(strs[0]);
					offset_y = Number(strs[1]);
				}
				delta_x = (d_skin[part_name + '_x'] - d_img_standard[part_name + '_x'] + offset_x) * standard_rect.width / d_img_standard[part_name + '_width'] * scale_x
				delta_y = (d_skin[part_name + '_y'] - d_img_standard[part_name + '_y'] - offset_y) * standard_rect.height / d_img_standard[part_name + '_height'] * scale_y
			}

			else {
				let center_delta_origin_x = (d_img_standard['smallhead_x'] + d_img_standard['smallhead_width'] * 0.5) - d_img_standard[part_name + '_x']
				let center_delta_origin_y = (d_img_standard['smallhead_y'] + d_img_standard['smallhead_width'] * 0.5) - d_img_standard[part_name + '_y']
				let center_delta_img_x = (d_skin['smallhead_x'] + d_skin['smallhead_width'] * 0.5) - d_skin[part_name + '_x']
				let center_delta_img_y = (d_skin['smallhead_y'] + d_skin['smallhead_width'] * 0.5) - d_skin[part_name + '_y']
				delta_x = (center_delta_origin_x - center_delta_img_x) * standard_rect.width / d_img_standard[part_name + '_width']
				delta_y = (center_delta_origin_y - center_delta_img_y) * standard_rect.width / d_img_standard[part_name + '_width']
			}

			let center_x = (d_skin['smallhead_x'] + d_skin['smallhead_width'] * 0.5 - d_skin[part_name + '_x']) / d_skin[part_name + '_width']

			//小鸟游全身立绘太大了，特判
			if (skin_id == 401902 && part_name == 'full' && !attached_to_head) {
				width = width * 0.9
				height = height * 0.9
			}

			return {
				delta_x: delta_x,
				delta_y: delta_y,
				width: width,
				height: height,
				center_x: center_x,
				diff_direction: d_skin.direction != d_img_standard.direction,
				no_reverse: d_skin.no_reverse,
				path: d_skin.path
			}
		}

		public static getSkinOffset(skin_id: number, standard_rect: uiscript.UIRect, part_name: string, scale_x: number, scale_y: number, type: string = ''): Laya.Point {
			let d_img_standard = cfg.item_definition.skin.get(400101); //以一姬的初始皮肤当的标准
			if (!d_img_standard) return new Laya.Point();
			let d_skin = cfg.item_definition.skin.get(skin_id);
			if (!d_skin) return new Laya.Point();
			let width = standard_rect.width * d_skin[part_name + '_width'] / d_img_standard[part_name + '_width'];
			let height = standard_rect.height * d_skin[part_name + '_height'] / d_img_standard[part_name + '_height'];

			let delta_x = 0;
			let delta_y = 0;

			let offset_x = 0;
			let offset_y = 0;
			if (type && d_skin[type + '_offset']) {
				let strs = d_skin[type + '_offset'].split(',');
				offset_x = Number(strs[0]);
				offset_y = Number(strs[1]);
			}
			delta_x = offset_x * standard_rect.width / d_img_standard[part_name + '_width'] * scale_x
			delta_y = - offset_y * standard_rect.height / d_img_standard[part_name + '_height'] * scale_y
			return new Laya.Point(delta_x, delta_y);
		}

		//称号和奖品混杂一起的话 可以分开
		public static showRewards(res, complete: Laya.Handler, tips: string = '', per_width: number = 50) {
			let items = [];
			let titles = [];
			let haveYueka = false;
			for (let i: number = 0; i < res['rewards'].length; i++) {
				let _id: number = res['rewards'][i]['id'];
				if (_id == 100099) continue;
				if (_id == 100098) {
					uiscript.UI_LightTips.Inst.show(game.Tools.strOfLocalization(2024));
					continue;
				}

				if (game.GameUtility.get_id_type(_id) == EIDType.title) {
					titles.push(_id);
				} else {
					if (game.GameUtility.get_id_type(_id) == EIDType.functionItem) {
						let d_item = cfg.item_definition.function_item.get(_id);
						if (d_item && d_item.type == game.EFunctionItemType.yueka) {
							haveYueka = true;
						}
					}
					items.push(res['rewards'][i]);
				}
			}

			let item_showed: boolean = false;
			let title_index: number = 0;

			let showover = () => {
				if (!item_showed && items.length > 0) {
					uiscript.UI_Getrewardextends.Inst.show(items, Laya.Handler.create(this, () => {
						showover();
					}), tips, per_width);
					item_showed = true;
					return;
				}
				if (title_index < titles.length) {
					uiscript.UI_Gettitle.Inst.show(titles[title_index++], Laya.Handler.create(this, () => {
						showover();
					}));
					return;
				}
				if (haveYueka) {
					haveYueka = false;
					uiscript.UI_LightTips.Inst.show(game.Tools.strOfLocalization(4305), Laya.Handler.create(this, () => {
						showover();
					}), false);
					return;
				}
				if (complete) complete.run();
			}
			showover();
		}

		private static debugfetchcd: number = 0;
		//调试debugFetchMultiAccountBrief
		public static debugFetchMultiAccountBrief(pos: string, index: number, total: number, value_count: number) {
			// if (Laya.timer.currTimer < this.debugfetchcd) return;
			// this.debugfetchcd = Laya.timer.currTimer + 5 * 60 * 1000;
			// let __err:Object = {};
			// __err['type'] = 'debugFetchMultiAccountBrief';
			// __err['pos'] = pos;
			// __err['index'] = index;
			// __err['total'] = total;
			// __err['value_count'] = value_count;

			// var xhr = new Laya.HttpRequest();
			// xhr.send(GameMgr.error_url, 'data=' + JSON.stringify(__err), "post");
		}

		/**
		 * 0 四人一局
		 * 1 四人东
		 * 2 四人南
		 * 3 四人人机
		 * 4 四人一局
		 * 10 三人一局
		 * 11 三人东
		 * 12 三人南
		 * 13 三人人机
		 * 14 三人一局
		 * @param mode 房间模式
		 * @returns 
		 */
		public static room_mode_desc(mode: number): string {
			let smode = '';
			switch (mode) {
				//四人一局
				case 0: smode = game.Tools.strOfLocalization(2026); break;
				//四人东
				case 1: smode = game.Tools.strOfLocalization(2027); break;
				//四人南
				case 2: smode = game.Tools.strOfLocalization(2028); break;
				//四人人机
				case 3: smode = game.Tools.strOfLocalization(2029); break;
				//四人一局
				case 4: smode = game.Tools.strOfLocalization(2026); break;
				//三人一局
				case 10: smode = game.Tools.strOfLocalization(2030); break;
				//三人东
				case 11: smode = game.Tools.strOfLocalization(2031); break;
				//三人南
				case 12: smode = game.Tools.strOfLocalization(2032); break;
				//三人人机
				case 13: smode = game.Tools.strOfLocalization(2033); break;
				//三人一局
				case 14: smode = game.Tools.strOfLocalization(2030); break;
			}
			return smode;
		}



		//金之间·四人南
		public static get_room_desc(config: Object): { text: string, isSimhei: boolean } {
			if (!config) return { text: '', isSimhei: false };
			let smode: string = '';
			if (config['meta'] && config['meta']['tournament_id']) {
				let d_t = cfg.tournament.tournaments.get(config['meta']['tournament_id']);
				if (d_t) {
					smode = d_t.name;
				}
				// this.label_gamemode.font = 'SimHei';
				return { text: smode, isSimhei: true };
			} else {

				if (config['category'] == 1) {
					//友人场
					smode += game.Tools.strOfLocalization(2023) + '·';
				} else if (config['category'] == 4) {
					//比赛场
					smode += game.Tools.strOfLocalization(2025) + '·';
				} else if (config['category'] == 2) {
					//匹配 使用mode_id获取对应的名字（铜之间...）
					let meta = config['meta'];
					if (meta) {
						let d_table = cfg.desktop.matchmode.get(meta.mode_id);
						if (d_table) {
							smode += d_table['room_name_' + GameMgr.client_language] + '·';
						}
					}
				} else if (config['category'] == 100) {
					return { text: game.Tools.strOfLocalization(2257), isSimhei: false };
				}
				let mode = config['mode'].mode;
				//如果友人场的规则是修罗之战则显示修罗之战
				if (config['category'] == 1 && config['mode']['detail_rule'] && config['mode']['detail_rule']['xuezhandaodi']) {
					smode += game.Tools.strOfLocalization(3384);
				} else {
					smode += this.room_mode_desc(mode);
				}


				// this.label_gamemode.font = 'hanyi';
				return { text: smode, isSimhei: false };
			}
		}

		//随机角色+羁绊等级该说的话
		public static get_chara_audio(character_info: any, type: string): { path: string, volume: number, time_length: number } {
			if (!type || type == '') return;
			let chara_id: number = character_info.charid;
			var d_chara = cfg.item_definition.character.get(chara_id);
			if (!d_chara) return null;
			let level = character_info.level;
			let sounds = cfg.voice.sound.findGroup(d_chara.sound);
			let _ss: Array<number> = [];
			for (let i: number = 0; i < sounds.length; i++) {
				if (sounds[i].type == type && sounds[i].level_limit <= level) {
					_ss.push(i);
				}
			}
			if (_ss.length == 0) return null;
			else {
				let index: number = _ss[Math.floor(Math.random() * _ss.length)];
				let volume: number = view.AudioMgr.getCVmute(d_chara.id) ? 0 : view.AudioMgr.getCVvolume(d_chara.id) * d_chara.sound_volume;
				if (view.AudioMgr.yuyinMuted) {
					volume = 0;
				} else {
					volume *= view.AudioMgr.yuyinVolume;
				}
				return {
					path: sounds[index].path,
					volume: volume,
					time_length: sounds[index].time_length
				}
			};
		}

		//剧情用 专属语音
		public static get_chara_audio_spot(sound_id: number): { path: string, volume: number } {
			let _spot_info = cfg.voice.spot.get(sound_id);
			if (!_spot_info) return null;
			let _data = cfg.spot.character_spot.get(_spot_info.character) || cfg.item_definition.character.get(_spot_info.character);
			let volume: number = view.AudioMgr.getCVmute(_data.id) ? 0 : view.AudioMgr.getCVvolume(_data.id) * _data.sound_volume;
			if (view.AudioMgr.yuyinMuted) {
				volume = 0;
			} else {
				volume *= view.AudioMgr.yuyinVolume;
			}
			return {
				path: _spot_info.path,
				volume: volume
			}
		}

		public static encode_account_id2(account_id: number): number {
			account_id = account_id ^ 6139246
			let v = 0x4000000 - 1; // 一亿里面最大的2的次方数,26个1
			let a = account_id & ~v;
			let b = account_id & v;
			b = ((b & 0x1FF) << 17) | (b >> 9);
			b = ((b & 0x1FF) << 17) | (b >> 9);
			b = ((b & 0x1FF) << 17) | (b >> 9);
			b = ((b & 0x1FF) << 17) | (b >> 9);
			b = ((b & 0x1FF) << 17) | (b >> 9);

			return b + a + 10000000;
		}

		public static decode_account_id2(account_id: number): number {
			let v = 0x4000000 - 1; // 一亿里面最大的2的次方数,26个1
			account_id -= 10000000;
			let a = account_id & ~v;
			let b = account_id & v;
			b = ((b & 0x1FFFF) << 9) | (b >> 17);
			b = ((b & 0x1FFFF) << 9) | (b >> 17);
			b = ((b & 0x1FFFF) << 9) | (b >> 17);
			b = ((b & 0x1FFFF) << 9) | (b >> 17);
			b = ((b & 0x1FFFF) << 9) | (b >> 17);

			return (a + b) ^ 6139246;
		}

		//牌谱中加密玩家id，不容易被看出来
		public static encode_account_id(account_id: number): number {
			return ((account_id * 7 + 1117113) ^ 86216345) + 1358437;
		}

		//对牌谱加密的玩家id解密
		public static decode_account_id(v: number): number {
			return (((v - 1358437) ^ 86216345) - 1117113) / 7;
		}

		/**
		 * 居中对齐所有子节点
		 * @param container 父节点
		 * @param span 每一个元素和上一个元素的间距，不填则间距为0
		 */
		public static child_align_center(container: Laya.Sprite, span?: Array<number>): void {
			let widths: Array<number> = [];
			for (let i: number = 0; i < container.numChildren; i++) {
				let child = container.getChildAt(i) as Laya.Sprite;
				if (!child.visible) continue;
				let width = child.width;
				if (child instanceof Laya.Text) {
					width = (child as Laya.Text).textWidth;
				} else if (child instanceof Laya.Label) {
					width = (child as Laya.Label).textField.textWidth;
				}
				widths.push(width * child.scaleX);
			}
			let total_w: number = 0;
			for (let i: number = 0; i < widths.length; i++) {
				total_w += widths[i];
				if (span && i < span.length) total_w += span[i];
			}
			let x: number = container.width / 2 - total_w / 2;
			let ii = 0;
			for (let i: number = 0; i < container.numChildren; i++) {
				let child = container.getChildAt(i) as Laya.Sprite;
				if (!child.visible) continue;
				child.x = x + child.pivotX * child.scaleX;
				x += widths[ii];
				if (span && ii < span.length) x += span[ii];
				ii++;
			}
		}

		/**
		 * 根据一个点居中对齐元素
		 * @param sprites 需要对齐的元素
		 * @param center_x 中心点的位置，局部坐标，
		 * @param span 每一个元素和上一个元素的间距，不填则间距为0
		 */
		public static sprite_align_center(sprites: Array<Laya.Sprite>, center_x: number, span?: Array<number>): void {
			let widths: Array<number> = [];
			for (let i: number = 0; i < sprites.length; i++) {
				let node: Laya.Sprite = sprites[i];
				if (!node.visible) continue;
				let width = node.width;
				if (node instanceof Laya.Text) {
					width = (node as Laya.Text).textWidth;
				} else if (node instanceof Laya.Label) {
					width = (node as Laya.Label).textField.textWidth;
				}
				widths.push(width * node.scaleX);
			}
			let total_w: number = 0;
			for (let i: number = 0; i < widths.length; i++) {
				total_w += widths[i];
				if (span && i < span.length) total_w += span[i];
			}
			let x: number = center_x - total_w / 2;
			let ii = 0;
			for (let i: number = 0; i < sprites.length; i++) {
				let node: Laya.Sprite = sprites[i];
				if (!node.visible) continue;
				node.x = x + node.pivotX * node.scaleX;
				x += widths[ii];
				if (span && ii < span.length) x += span[ii];
				ii++;
			}
		}

		public static char_lst: Array<string> = null;
		public static char_map: Object = null;

		private static build_char_map() {
			if (this.char_map) return;
			let lst = [];
			let charcode_a = ('a').charCodeAt(0);
			for (let i: number = 0; i < 26; i++) {
				lst.push(String.fromCharCode(charcode_a + i));
			}
			let charcode_A = ('A').charCodeAt(0);
			for (let i: number = 0; i < 26; i++) {
				lst.push(String.fromCharCode(charcode_A + i));
			}
			for (let i: number = 0; i < 10; i++) {
				lst.push(i.toString());
			}
			let str_sign: string = '!@#$%^&*()-_=+{}[]|\:;<>,.?/~';
			for (let i: number = 0; i < str_sign.length; i++) {
				lst.push(str_sign[i]);
			}

			this.char_lst = lst;
			this.char_map = {};
			for (let i: number = 0; i < lst.length; i++) {
				this.char_map[lst[i]] = i;
			}
		}

		//加密标准字符串，若出现不认识的字符，原样保留
		public static eeesss(str: string): string {
			this.build_char_map();
			let result = '';
			let start_index = (Math.floor(str.length / 3) + 17) % str.length;
			for (let i: number = 0; i < str.length; i++) {
				let index = (start_index - i + str.length * 2) % str.length;
				let offset: number = (2 + 3 * i) ^ 11;
				let c = str[index];
				let c1 = this.char_map[c];
				if (c1 != null) {
					result += this.char_lst[(c1 + offset) % this.char_lst.length];
				} else {
					result += c;
				}
			}
			return result;
		}

		//解码标准字符，与上面配合
		public static dddsss(str: string): string {
			if (!str) return str;
			this.build_char_map();
			let result = '';
			let start_index = (Math.floor(str.length / 3) + 17) % str.length;

			let s_lst: Array<string> = [];

			for (let i: number = 0; i < str.length; i++) {
				let offset: number = (2 + 3 * i) ^ 11;
				let c = str[i];
				let c1 = this.char_map[c];
				if (c1 != null) {
					s_lst.push(this.char_lst[(((c1 - offset) % this.char_lst.length) + this.char_lst.length) % this.char_lst.length]);
				} else {
					s_lst.push(c);
				}
			}
			for (let i: number = start_index; i >= 0; i--) {
				result += s_lst[i];
			}
			for (let i: number = str.length - 1; i > start_index; i--) {
				result += s_lst[i];
			}

			return result;
		}

		//尝试打开新窗口
		public static open_new_window(url: string) {
			if (Laya.Browser.userAgent.indexOf('Waterfox') != -1) {
				window.open(url, '_blank');
			} else {
				var a = document.createElement("a");
				a.href = url;
				a.target = '_blank';
				a.click();
				a.remove();
			}
		}

		public static open_link(url: string) {
			if (!Laya.Browser.onPC) {
				Laya.Browser.window.location.href = url;
			} else {
				game.Tools.open_new_window(url);
			}
		}
		//Post模拟表单提交跳转
		public static formPost(url: string, params: Object, self: boolean = false) {
			let tmp_form = document.createElement('form');
			tmp_form.action = url;
			tmp_form.target = self ? '_self' : '_blank';
			tmp_form.method = 'post';
			tmp_form.style.display = 'none';
			for (let k in params) {
				let opt = document.createElement('textarea');
				opt.name = k;
				opt.value = params[k];
				tmp_form.appendChild(opt);
			}
			document.body.appendChild(tmp_form);
			tmp_form.submit();
			tmp_form.remove();
		}
		public static stringTobase64(input: string) {
			let keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
			let output = "", chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0;
			input = this.utf8_encode(input);
			while (i < input.length) {
				chr1 = input.charCodeAt(i++);
				chr2 = input.charCodeAt(i++);
				chr3 = input.charCodeAt(i++);
				enc1 = chr1 >> 2;
				enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
				enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
				enc4 = chr3 & 63;
				if (isNaN(chr2)) {
					enc3 = enc4 = 64;
				} else if (isNaN(chr3)) {
					enc4 = 64;
				}
				output = output +
					keyStr.charAt(enc1) + keyStr.charAt(enc2) +
					keyStr.charAt(enc3) + keyStr.charAt(enc4);
			}
			return output;
		}
		private static utf8_encode(str: string) {
			str = str.replace(/\r\n/g, "\n");
			let utftext = "";
			for (let n = 0; n < str.length; n++) {
				let c = str.charCodeAt(n);
				if (c < 128) {
					utftext += String.fromCharCode(c);
				} else if ((c > 127) && (c < 2048)) {
					utftext += String.fromCharCode((c >> 6) | 192);
					utftext += String.fromCharCode((c & 63) | 128);
				} else {
					utftext += String.fromCharCode((c >> 12) | 224);
					utftext += String.fromCharCode(((c >> 6) & 63) | 128);
					utftext += String.fromCharCode((c & 63) | 128);
				}

			}
			return utftext;
		}
		public static base64ToBlob(urlData, type): Blob {
			let arr = urlData.split(',');
			let mime = arr[0].match(/:(.*?);/)[1] || type;
			// 去掉url的头，并转化为byte
			let bytes = window.atob(arr[1]);
			// 处理异常,将ascii码小于0的转换为大于0
			let ab = new ArrayBuffer(bytes.length);
			// 生成视图（直接针对内存）：8位无符号整数，长度1个字节
			let ia = new Uint8Array(ab);
			for (let i = 0; i < bytes.length; i++) {
				ia[i] = bytes.charCodeAt(i);
			}
			return new Blob([ab], {
				type: mime
			});
		}

		//判断主序列包含子序列
		public static stringContainerSub(max_str: string, sub_str: string): boolean {
			if (!sub_str || sub_str == '') return true;
			if (!max_str || max_str == '') return false;
			let index: number = 0;
			for (let i: number = 0; i < max_str.length; i++) {
				if (max_str.charAt(i) == sub_str.charAt(index)) {
					index++;
					if (index >= sub_str.length) {
						return true;
					}
				}
			}
			return false;
		}

		//本地化文字
		public static strOfLocalization(id, param: Array<string> = []): string {
			let d_excel = cfg.str.str.get(id);
			let s = '';
			if (d_excel) {
				s = d_excel[GameMgr.client_language];
				if (param) {
					for (let i: number = 0; i < param.length; i++) {
						let pid: string = '\\{' + i + '\\}';
						let reg = new RegExp(pid, 'g');
						s = s.replace(reg, param[i]);
					}
				}
			}
			return s;
		}

		//本地化文字
		public static eventStrOfLocalization(id, param: Array<string> = []): string {
			let d_excel = cfg.str.event.get(id);
			let s = '';
			if (d_excel) {
				s = d_excel[GameMgr.client_language];
				if (param) {
					for (let i: number = 0; i < param.length; i++) {
						let pid: string = '{' + i + '}';
						s = s.replace(pid, param[i]);
					}
				}
			}
			return s;
		}

		//本地化文字
		public static translateOfLocalization(str: string, param: Array<string> = []): string {
			let s = '';
			cfg.info.translate.forEach(item => {
				if (item.original == str) {
					s = item[GameMgr.client_language];
					if (param) {
						for (let i: number = 0; i < param.length; i++) {
							let pid: string = '{' + i + '}';
							s = s.replace(pid, param[i]);
						}
					}
				}
			});
			if (!s) {
				app.Log.Error('ob error:' + str);
				return str;
			}
			return s;
		}

		//精选服务器连接顺序，一台gateway连接两次还没连上的话，基本就不用再连了，网络有问题，用域名来判断
		public static deal_gateway(urls: Array<string>): Array<string> {
			let _index: Array<number> = [];
			for (let i: number = 0; i < urls.length; i++) {
				let _i: number = Math.floor(Math.random() * (i + 1));
				_index.push(i);
				_index[i] = _index[_i];
				_index[_i] = i;
			}

			let yuming: Object = {};
			let ret: Array<string> = [];
			for (let i: number = 0; i < urls.length; i++) {
				let _url: string = urls[_index[i]];
				let u = _url.split(':');
				if (u.length == 2) {
					let _y: string = u[0];
					if (!yuming[_y]) {
						yuming[_y] = 0;
					}
					if (yuming[_y] < 2) {
						yuming[_y]++
						ret.push(_url);
					}
				}
			}
			return ret;
		}

		public static localUISrc(src: string): string {
			if (game.ResourceVersion.textureMode) {
				src = GameMgr.client_language + '/' + src;
			} else {
				if (GameMgr.client_language != 'chs')
					src = GameMgr.client_language + '/' + src;
			}
			var cache_url = src.indexOf(GameMgr.client_language + '/') == 0 ? src.replace(GameMgr.client_language + '/', '') : src;
			if (game.ResourceVersion.localized_map && game.ResourceVersion.localized_map.hasOwnProperty(cache_url)) {
				if (!game.ResourceVersion.localized_map[cache_url]) {
					src = cache_url;
				}
			} else {
				if (GameMgr.client_language == 'chs' && src.indexOf(GameMgr.client_language + '/') == 0) {
					src = cache_url;
					//中文情况下非res资源可以直接用原图，主要处理图集里的图片
				}
			}
			return src;
		}

		//原本居中而本地化太长的label向左或向右衍生
		public static labelLocalizationPosition(label: Laya.Label, origin_x: number, origin_width: number, extend_right: boolean) {
			let text_width: number = label.textField.textWidth;
			if (text_width > origin_width) {
				label.x = origin_x + (text_width - origin_width) / 2 * label.scaleX * (extend_right ? 1 : -1);
			} else {
				label.x = origin_x;
			}
		}

		//如果label里面的字太宽了，就按比例缩小
		public static labelLocalizationSize(label: Laya.Label, origin_width: number, origin_scale: number) {
			let text_width: number = label.textField.textWidth;
			if (text_width > origin_width) {
				let rate = text_width / origin_width;
				label.width = origin_width * rate;
				label.scaleX = label.scaleY = origin_scale / rate;
			} else {
				label.width = origin_width;
				label.scaleX = label.scaleY = origin_scale;
			}
		}

		//全角转半角
		public static ToCDB(str: string) {
			var tmp = "";
			for (var i = 0; i < str.length; i++) {
				if (str.charCodeAt(i) == 12288) {
					tmp += String.fromCharCode(str.charCodeAt(i) - 12256);
					continue;
				}
				if (str.charCodeAt(i) > 65280 && str.charCodeAt(i) < 65375) {
					tmp += String.fromCharCode(str.charCodeAt(i) - 65248);
				}
				else {
					tmp += String.fromCharCode(str.charCodeAt(i));
				}
			}
			return tmp
		}

		//半角转全角
		public static ToDBC(str: string) {
			let ret_string: string = "";
			for (let i = 0; i < str.length; i++) {
				if (str.charCodeAt(i) == 32) {
					ret_string += String.fromCharCode(12288);
				}
				if (str.charCodeAt(i) < 127) {
					ret_string += String.fromCharCode(str.charCodeAt(i) + 65248);
				}
			}
			return ret_string;
		}

		public static isAI(account_id: number) {
			return !account_id || account_id < 1000;
		}

		public static get_zone_id(account_id: number) {
			if (this.isAI(account_id)) return 0;
			let z: number = account_id >> 23;
			if (game.LobbyNetMgr.Inst && game.LobbyNetMgr.Inst.zone_ids && game.LobbyNetMgr.Inst.zone_ids.length > 3) {
				let zone_ids = game.LobbyNetMgr.Inst.zone_ids;
				if (z >= zone_ids[0] && z < zone_ids[1]) return 1;
				else if (z >= zone_ids[1] && z < zone_ids[2]) return 2;
				else if (z >= zone_ids[2] && z < zone_ids[3]) return 3;
				return -1;
			} else {
				if (z >= 0 && z <= 6) return 1;
				else if (z >= 7 && z <= 12) return 2;
				else if (z >= 13 && z <= 15) return 3;
				return -1;
			}


		}

		//是否是同区域
		public static is_same_zone(account_id0: number, account_id1: number): boolean {
			if (this.isAI(account_id0) || this.isAI(account_id1)) return true;
			let zone_id0: number = this.get_zone_id(account_id0);
			let zone_id1: number = this.get_zone_id(account_id1);
			if (zone_id0 == -1 || zone_id1 == -1) return false;
			return zone_id0 == zone_id1;
		}

		//称号本地化，本服的称号不在外服显示
		public static titleLocalization(account_id: number, title_id: number): number {
			if (!title_id) return 0;
			if (!this.is_same_zone(GameMgr.Inst.account_id, account_id)) {
				let title = cfg.item_definition.title.get(title_id);
				if (!title.cross_view) {
					return 0;
				}
			}
			return title_id;
		}

		// 一个亚洲字占两个字符，一个英文字符占1个字符
		public static calu_word_length(str: string): number {
			let len: number = 0;
			for (let i: number = 0; i < str.length; i++) {
				if (str.charCodeAt(i) > 255) {
					len += 2;
				} else {
					len += 1;
				}
			}
			return len;
		}

		// 把邮箱显示加密成28******@qq.com
		public static encode_email(str: string): string {
			let index: number = str.indexOf('@');
			if (index < 0) return str;
			let s = '';
			if (index < 2) {
				s += str.substr(0, index);
			} else {
				s += str.substr(0, 2);
			}
			for (let i: number = 0; i < 6; i++) s += '*';
			s += str.substr(index);
			return s;
		}

		// 有11位手机号码加密成12******1234
		public static encode_phonenumber(str: string): string {
			return str.substr(0, 2) + '******' + str.substr(str.length - 4);
		}

		// 判断邮箱格式是否合法
		public static pending_email_vaild(str: string): boolean {
			let reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			return reg.test(str);
		}

		// 判断手机号码是否合法
		public static pending_phonenumber_valid(str: string): boolean {
			if (!str || str.length != 11) return false;
			let code0: number = '0'.charCodeAt(0);
			for (let i: number = 0; i < str.length; i++) {
				let c: number = str.charCodeAt(i) - code0;
				if (c < 0 || c >= 10) return false;
			}
			return true;
		}

		/**
		 * 判断传入时间是否已经越过刷新时间点
		 *
		 *   游戏预定凌晨5点刷新（通过和当前时间比较）
		 *
		 *   注意：这里使用固定时区而不是读取当前主机的时区来判断
		 *   全球统一按照+8时区的5点来刷新，等价于+3时区的0点刷新
		 *
		 * @param {number} t
		 * @returns {boolean} true=同一天
		 */
		public static isPassedRefreshTime(t: number): boolean {
			return Math.floor((t + 3 * 3600) / 86400) === Math.floor((Math.floor(Date.now() / 1000) + 3 * 3600) / 86400);
		}

		/**
		 * 判断传入时间是否已经越过刷新时间点
		 *
		 *   游戏预定凌晨5点刷新（通过和当前服务器时间比较）
		 *
		 *   注意：这里使用固定时区而不是读取当前主机的时区来判断
		 *   全球统一按照+8时区的5点来刷新，等价于+3时区的0点刷新
		 *
		 * @param {number} t 单位：秒
		 * @returns {boolean} true=同一天
		 */
		public static isPassedRefreshTimeServer(t: number): boolean {
			return Math.floor((t + 3 * 3600) / 86400) === Math.floor((Math.floor((Date.now() + GameMgr.Inst.server_time_delta) / 1000) + 3 * 3600) / 86400);
		}

		// 获得距离跨天还有多少秒
		public static getTime2PassedRefreshTime(t: number) {
			return 86400 - (t + 3 * 3600) % 86400;
		}

		public static ParseTime(str: string): number {
			let nums: Array<number> = [];
			let code0: number = '0'.charCodeAt(0);
			let _num: number = 0;
			let _in_num: boolean = false;
			for (let i: number = 0; i < str.length; i++) {
				let _n: number = str.charCodeAt(i) - code0;
				if (_n >= 0 && _n <= 9) {
					_in_num = true;
					_num = _num * 10 + _n;
				} else {
					if (_in_num) {
						_in_num = false;
						nums.push(_num);
						_num = 0;
					}
				}
			}
			if (_in_num) {
				nums.push(_num);
			}
			let _time: Date = new Date();

			_time.setUTCFullYear(nums[0], nums[1] - 1, nums[2]);
			_time.setUTCHours(nums[3], nums[4], nums[5], 0);
			let _t: number = _time.getTime();
			if (nums.length >= 7) {
				let _dt: number = nums[6] * 3600 * 1000;
				if (str[str.length - 3] == '+') _t -= _dt;
				else _t += _dt;
			}
			return _t;
		}

		public static CannotPay(): boolean {
			return false;
		}

		public static GetNodeByNameInChildren(root: Laya.Node, name: string): Laya.Node {
			if (root.name == name) return root;
			for (let i: number = 0; i < root.numChildren; i++) {
				let ret = this.GetNodeByNameInChildren(root.getChildAt(i), name);
				if (ret != null) return ret;
			}
			return null;
		}

		public static SetNickname(container_name: Laya.Sprite, data: { account_id?: number, nickname?: string, verified?: number }, hide_name?: boolean, ignore_zone?: boolean, show_remarks: boolean = true, remarkColor?: string, defaultColor?: string): boolean {
			let label_nickname: Laya.Label = container_name.getChildByName('name') as Laya.Label;
			let img_vip: Laya.Image = container_name.getChildByName('vip_tag') as Laya.Image;
			label_nickname.width = container_name.width;
			let nickname = data.nickname;
			let isRemarks = false;
			if (!GameMgr.Inst.hide_nickname && show_remarks) {
				const friendInfo = game.FriendMgr.find(data.account_id);
				if (friendInfo && friendInfo.remark) {
					nickname = friendInfo.remark;
					isRemarks = true;
				}
			}

			if (!this.isAI(data.account_id)) {
				if (hide_name && data.account_id && data.account_id != GameMgr.Inst.account_id) {
					nickname = this.strOfLocalization(3060);
					isRemarks = false;
				} else if (data.account_id && !this.is_same_zone(GameMgr.Inst.account_id, data.account_id)) {
					// 跨服隐藏
					if (GameMgr.Inst.nickname_replace_enable && GameMgr.Inst.nickname_replace_lst.length > 0) {
						if (GameMgr.Inst.nickname_replace_table[data.account_id]) {
							nickname = GameMgr.Inst.nickname_replace_table[data.account_id];
						} else {
							nickname = GameMgr.Inst.nickname_replace_lst[Math.floor(Math.random() * GameMgr.Inst.nickname_replace_lst.length)];
							GameMgr.Inst.nickname_replace_table[data.account_id] = nickname;
						}
						isRemarks = false;
					} else if (!ignore_zone && GameMgr.Inst.get_hide_name('other_zone')) {
						nickname = this.strOfLocalization(3060);
						isRemarks = false;
					} else if (app.Taboo.test(nickname) != null) {
						nickname = this.strOfLocalization(3060);
						isRemarks = false;
					}
				}

			}

			let len: number = 0;
			let str_nickname: string = '';
			if (this.calu_word_length(nickname) > 16) {
				for (let i: number = 0; i < nickname.length; i++) {
					if (nickname.charCodeAt(i) > 255) {
						len += 2;
					} else {
						len += 1;
					}
					str_nickname += nickname.charAt(i);
					if (len >= 14) break;
				}
				str_nickname += '..';
			} else {
				str_nickname = nickname;
			}
			label_nickname.text = str_nickname;
			if (remarkColor && isRemarks) {
				label_nickname.color = remarkColor;
			}
			else if (defaultColor) {
				label_nickname.color = defaultColor;
			}
			label_nickname.scaleX = label_nickname.scaleY = 1;
			label_nickname.width = label_nickname.textField.textWidth;
			let total_width: number = label_nickname.width;
			if (img_vip) {
				if (data.verified) {
					img_vip.visible = true;
					total_width += img_vip.width;
					img_vip.scaleX = img_vip.scaleY = 1;
					img_vip.skin = game.Tools.localUISrc(data.verified == 1 ? 'myres/vip_tag.png' : 'myres/vip_tag1.png');
				} else {
					img_vip.visible = false;
				}
			}
			if (total_width > container_name.width) {
				let rate: number = container_name.width / total_width;
				label_nickname.scaleX = label_nickname.scaleY = rate;
				img_vip && (img_vip.scaleX = img_vip.scaleY = rate);
				total_width = container_name.width;
			}
			if (label_nickname.align == 'left') {
				label_nickname.x = 0;
				img_vip && (img_vip.x = label_nickname.width * label_nickname.scaleX);
			} else {
				this.child_align_center(container_name);
				// let center_x: number = container_name.width / 2;
				// label_nickname.x = center_x - total_width / 2;
				// img_vip.x = label_nickname.x + label_nickname.width * label_nickname.scaleX;
			}
			return isRemarks;
		}

		public static SetNicknameColor(container_name: Laya.Sprite, color: string) {
			const label_nickname = container_name.getChildByName('name') as Laya.Label;
			if (!label_nickname) return;
			label_nickname.color = color;
		}

		public static money2Desc(n: number): string {
			if (n < 1000000) return n.toString();
			if (GameMgr.client_language == 'chs' || GameMgr.client_language == 'jp' || GameMgr.client_language == 'chs_t') {
				if (n < 100000000) {
					let s = (n / 10000).toFixed(3);
					let index: number = 0;
					for (let i: number = 0; i < s.length; i++) {
						if (s[i] == '.') {
							index = i;
							break;
						}
					}
					if (index >= 4) {
						s = s.substr(0, 4);
					} else {
						s = s.substr(0, 5);
					}
					return s + game.Tools.strOfLocalization(2148);
				} else {
					let s = (n / 100000000).toFixed(3);
					let index: number = 0;
					for (let i: number = 0; i < s.length; i++) {
						if (s[i] == '.') {
							index = i;
							break;
						}
					}
					if (index >= 4) {
						s = s.substr(0, 4);
					} else {
						s = s.substr(0, 5);
					}
					return s + game.Tools.strOfLocalization(2149);
				}
			} else {
				if (n < 1000000000) {
					let s = (n / 1000000).toFixed(3);
					let index: number = 0;
					for (let i: number = 0; i < s.length; i++) {
						if (s[i] == '.') {
							index = i;
							break;
						}
					}
					if (index >= 4) {
						s = s.substr(0, 4);
					} else {
						s = s.substr(0, 5);
					}
					return s + 'M';
				} else {
					let s = (n / 1000000000).toFixed(3);
					let index: number = 0;
					for (let i: number = 0; i < s.length; i++) {
						if (s[i] == '.') {
							index = i;
							break;
						}
					}
					if (index >= 4) {
						s = s.substr(0, 4);
					} else {
						s = s.substr(0, 5);
					}
					return s + 'B';
				}
			}
		}

		public static during_chat_close(): boolean {
			return false;
		}

		public static get_platform_currency(): Array<number> {
			let currency_platforms: Array<number> = [];
			let info = cfg.mall.channel_config.get(GameMgr.payChannelId);
			if (info.currency_platforms) {
				let lst = info.currency_platforms.split('-');
				for (let id of lst) {
					currency_platforms.push(parseInt(id));
				}
			}
			return currency_platforms;
		}


		public static EncodePaipuUUID(uuid: string): string {
			let s: string = '';
			let code0: number = '0'.charCodeAt(0);
			let codea: number = 'a'.charCodeAt(0);
			for (let i: number = 0; i < uuid.length; i++) {
				let c = uuid.charAt(i);
				let code = c.charCodeAt(0);
				let v = -1;
				if (code >= code0 && code < code0 + 10) {
					v = code - code0;
				} else if (code >= codea && code < codea + 26) {
					v = code - codea + 10;
				}
				if (v != -1) {
					v = (v + 17 + i) % 36;
					if (v < 10) s += String.fromCharCode(v + code0);
					else s += String.fromCharCode(v + codea - 10);
				} else {
					s += c;
				}
			}
			return s;
		}

		public static DecodePaipuUUID(uuid: string): string {
			let s: string = '';
			let code0: number = '0'.charCodeAt(0);
			let codea: number = 'a'.charCodeAt(0);
			for (let i: number = 0; i < uuid.length; i++) {
				let c = uuid.charAt(i);
				let code = c.charCodeAt(0);
				let v = -1;
				if (code >= code0 && code < code0 + 10) {
					v = code - code0;
				} else if (code >= codea && code < codea + 26) {
					v = code - codea + 10;
				}
				if (v != -1) {
					v = (v + 55 - i) % 36;
					if (v < 10) s += String.fromCharCode(v + code0);
					else s += String.fromCharCode(v + codea - 10);
				} else {
					s += c;
				}
			}
			return s;
		}

		public static Slerp(start: Laya.Vector3, end: Laya.Vector3, percent: number): Laya.Vector3 {
			// Dot product - the cosine of the angle between 2 vectors.
			let dot: number = Laya.Vector3.dot(start, end);
			0
			// Clamp it to be in the range of Acos()
			// This may be unnecessary, but floating point
			// precision can be a fickle mistress.
			dot = Math.min(Math.max(dot, -1), 1);
			// Acos(dot) returns the angle between start and end,
			// And multiplying that by percent returns the angle between
			// start and the final result.
			let theta: number = Math.acos(dot) * percent;
			let RelativeVec: Laya.Vector3 = new Laya.Vector3(end.x - start.x * dot, end.y - start.y * dot, end.z - start.z * dot);
			// Laya.Vector3.normalize(RelativeVec, RelativeVec);
			// Orthonormal basis
			// The final result.
			let out: Laya.Vector3 = new Laya.Vector3();
			let a: Laya.Vector3 = new Laya.Vector3();
			let b: Laya.Vector3 = new Laya.Vector3();
			Laya.Vector3.scale(start, Math.cos(theta), a);
			Laya.Vector3.scale(RelativeVec, Math.sin(theta), b);
			Laya.Vector3.add(a, b, out);
			return out;
		}

		public static EncodeHtmlText(str: string): string {
			str = str.replace(/&/g, '&amp;');
			// str = str.replace(/</g, '&#60;');
			// str = str.replace(/>/g, '&#62;');
			str = str.replace(/\"/g, "&quot;");
			str = str.replace(/\n/g, "<br>");
			return str;
		}

		/**
		 * 
		 * @returns 服务器时间(毫秒)
		 */
		public static getServerTime(isSecond: boolean = false): number {
			let time = Date.now() + GameMgr.Inst.server_time_delta;
			if (isSecond) {
				time = Math.floor(time / 1000);
			}
			return time;
		}

		public static toFloorFixed(n: number, count: number): string {
			let str = n.toString();
			let index = str.indexOf('.');
			if (index == -1) {
				str += '.';
				for (let i = 0; i < count; i++) {
					str += '0';
				}
			} else {
				if (index + count > str.length - 1) {
					let length = index + count - str.length + 1;
					for (let i = 0; i < length; i++) {
						str += '0';
					}
				} else {
					str = str.substring(0, index + count + 1);
				}
			}
			return str;
		}

		public static shuffle(arr: Array<any>) {
			let len = arr.length;
			for (let i = 0; i < len - 1; i++) {
				let index = Math.floor(Math.random() * (len - i));
				var temp = arr[index];
				arr[index] = arr[len - i - 1];
				arr[len - i - 1] = temp;
			}
			return arr;
		}

		public static getFinalUrl(url: string): string {
			return url;
			// if (GameMgr.client_type != 'chs_t') return url;
			// if (GameMgr.inRelease) {
			// 	let hostname = window.location.hostname;
			// 	url = url.replace('maj-soul.com', hostname.substring(hostname.indexOf('.') + 1));
			// }
			// // let is_net = window.location.hostname.indexOf('.net')!=-1;
			// // if (!is_net)  {
			// // 	url = url.replace('maj-soul.com', 'maj-soul.net');
			// // }
			// return url;
		}

		public static getShareUrl(url: string): string {
			// if (GameMgr.client_type == 'chs_t' && GameMgr.inRelease) {
			// 	url = url.replace('.com', '.net');
			// }
			return url;
		}

		public static getTimeByStr(time: string): number {
			let result = new Date(time.replace(/-/g, '/')).getTime();
			if (!result) {
				result = new Date(time.replace(/-/g, '/').replace('+', ' utc+')).getTime();
			}
			return result;
		}

		/**
		 * 添加长按处理
		 * @param btn 
		 * @param handler 
		 * @param dragParent 
		 */
		public static setButtonLongPressHandler(btn: Laya.Sprite, handler: Laya.Handler, dragParent: Laya.Sprite = null) {

			btn.offAll('mousedown');
			btn.offAll('mouseup');
			btn.offAll('mousemove');
			btn.offAll('mouseover');
			btn.offAll('mouseout');
			btn.on('mousedown', null, (event) => {
				let info = game.Tools.getMouseInfo();
				handler.runWith('down');
				let mouseMove = function (event) {
					let _info = game.Tools.getMouseInfo();
					if (Math.abs(info.x - _info.x) > 50 || Math.abs(info.y - _info.y) > 50) {
						handler.runWith(['drag', info.x - _info.x, info.y - _info.y]);
					} else {

						handler.runWith('move');
					}
				}

				let mouseUp = function (event) {
					handler.runWith('up');
					btn.offAll('mouseup');
					btn.offAll('mousemove');
					btn.offAll('mouseover');
					if (dragParent) {
						dragParent.off('mousemove', null, mouseMove);
						dragParent.off('mouseup', null, mouseUp);
						dragParent.off('mouseover', null, mouseOver);
					}
				}

				let mouseOver = function (event) {
					handler.runWith('over');
					btn.offAll('mouseup');
					btn.offAll('mousemove');
					btn.offAll('mouseover');
					if (dragParent) {
						dragParent.off('mousemove', null, mouseMove);
						dragParent.off('mouseup', null, mouseUp);
						dragParent.off('mouseover', null, mouseOver);
					}
				}
				btn.on('mouseup', null, mouseUp);
				btn.on('mouseout', null, mouseUp);
				btn.on('mousemove', null, mouseMove);
				if (dragParent) {
					dragParent.on('mousemove', null, mouseMove);
					dragParent.on('mouseup', null, mouseUp);
					dragParent.on('mouseover', null, mouseOver);
				}
				btn.on('mouseover', null, mouseOver);
			});

		}
		public static clearBtnEvent(btn: Laya.Sprite) {
			btn.offAll('mousedown');
			btn.offAll('mouseup');
			btn.offAll('mousemove');
			btn.offAll('mouseover');
			btn.offAll('mouseout');
		}
		public static getMouseInfo(): { x: number, y: number } {
			let mouseX: number = Laya.MouseManager.instance.mouseX;
			let mouseY: number = Laya.MouseManager.instance.mouseY;
			let w_offset: number = 0;
			let h_offset: number = 0;
			if (Laya.Browser.width / 1920 < Laya.Browser.height / 1080) {
				h_offset = (Laya.Browser.height - Laya.Browser.width / 1920 * 1080) / 2;
			} else {
				w_offset = (Laya.Browser.width - Laya.Browser.height / 1080 * 1920) / 2;
			}

			let x: number = mouseX / (Laya.Browser.width - w_offset * 2) * Laya.Browser.width;
			let y: number = mouseY / (Laya.Browser.height - h_offset * 2) * Laya.Browser.height;
			return {
				x: x,
				y: y
			}
		}

		/**
		 * 根据itemId为制定的Image设定图片
		 * @param img image本身
		 * @param rect image组件的大小
		 * @param item_id 道具的id
		 * @param ui_tag 自定义即可
		 * @param set_skin 是否设置skin属性为该道具的图片
		 */
		public static setItemIcon(img: Laya.Image, rect: uiscript.UIRect, item_id: number, ui_tag?: string, set_skin?: boolean) {
			let idtype: EIDType = GameUtility.get_id_type(item_id);
			img.width = rect.width;
			img.height = rect.height;
			img.x = rect.x;
			img.y = rect.y;
			if (idtype == EIDType.currency) {
				if (set_skin) {
					let d_currency = cfg.item_definition.currency.get(item_id);
					if (d_currency) {
						game.LoadMgr.setImgSkin(img, d_currency.icon_jpg, null, ui_tag);
					}
				}

			} else if (idtype === EIDType.item) {
				let d_item = cfg.item_definition.item.get(item_id);
				if (d_item) {
					if (set_skin)
						game.LoadMgr.setImgSkin(img, d_item.icon, null, ui_tag);
					if (d_item.category == 8) {
						img.height = rect.width * (338 / 600);
						if (img.anchorY != 0.5) {
							let anchor = img.anchorY ? img.anchorY : 0;
							img.y = rect.y - (rect.height - img.height) * (anchor - 0.5);
						}
					}
				}
			} else {
				if (set_skin)
					game.LoadMgr.setImgSkin(img, GameUtility.get_item_view(item_id).icon, null, ui_tag);
			}
		}

		public merge_items(res: any) {
			let rewards = [];
			var func = (info) => {
				let added = false;
				for (let reward of rewards) {
					if (reward.id == info.id) {
						reward.count += info.count;
						added = true;
						break;
					}
				}
				if (!added) {
					rewards.push(info);
				}
			}
			for (let reward of res['rewards']) {
				if (reward['replace_count'] == 0) {
					let info = reward['reward'];
					func(info)

				} else {
					reward['reward']['count'] -= reward['replace_count'];
					if (reward['reward']['count'] > 0) {
						func(reward['reward']);
					}
					func(reward['replace']);
				}
			}
			return rewards;
		}

		public static copyItems(str: string): boolean {
			if (GameMgr.inConch) {
				var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
				_c.call('setSysClipboardText', str);
				return true;
			} else if (GameMgr.iniOSWebview) {
				Laya.Browser.window.wkbridge.callNative('copy2clip', str, () => { });
				return true;
			} else {
				let copyInput = document.createElement('input');//创建input元素
				document.body.appendChild(copyInput);//向页面底部追加输入框
				copyInput.setAttribute('value', str);//添加属性，将url赋值给input元素的value属性
				copyInput.select();//选择input元素
				let result = document.execCommand("Copy");//执行复制命令
				//复制之后再删除元素，否则无法成功赋值
				copyInput.remove();//删除动态创建的节点
				return result;
			}

		}

		public static isJapanese(input: string = '', allowed: any = null): boolean {
			const augmented = this.typeOf(allowed) === 'regexp';
			return this.isEmpty(input)
				? false
				: [...input].every((char) => {
					const isJa = this.isCharJapanese(char);
					return !augmented ? isJa : isJa || allowed.test(char);
				});
		}

		private static typeOf(value: any): string {
			if (value === null) {
				return 'null';
			}
			if (value !== Object(value)) {
				return typeof value;
			}
			return {}.toString
				.call(value)
				.slice(8, -1)
				.toLowerCase();
		}

		private static isEmpty(input: any): boolean {
			if (this.typeOf(input) !== 'string') {
				return true;
			}
			return !input.length;
		}

		private static isCharInRange(char = '', start: number, end: number): boolean {
			if (this.isEmpty(char)) return false;
			const code = char.charCodeAt(0);
			return start <= code && code <= end;
		}

		private static isCharKatakana(char: string = ''): boolean {
			return this.isCharInRange(char, 0x30a1, 0x30fc);
		}

		private static isCharJapanese(char: string = ''): boolean {
			return JAPANESE_RANGES.some(([start, end]) => this.isCharInRange(char, start, end));
		}

		public static isKatakana(str: string): boolean {
			for (let char of str) {
				if (!this.isCharKatakana(char)) {
					return false;
				}
			}
			return true;
		}

		public static isFixGMO(str: string): boolean {
			for (let char of str) {
				if (!(this.isCharInRange(char, 0x30a1, 0x30fc) || this.isCharInRange(char, 65313, 65338) || this.isCharInRange(char, 65296, 65305) || char == 'ー')) {
					return false;
				}
			}
			return true;
		}

		// 禁止使用<>，只使用[tag]标注颜色
		public static ParseText(text: string, colorStr?: string) {
			let str = text.replace(/&/g, '&amp;');
			str = str.replace(/</g, '&#60;');
			str = str.replace(/>/g, '&#62;');
			str = str.replace(/\\n/g, '<br>');
			str = str.replace(/\n/g, '<br>');
			str = str.replace(/\"/g, "&quot;");
			str = str.replace(/\s/g, "&nbsp;");
			if (colorStr) {
				let matchLeftCount = 0;
				let matchRightCount = 0;
				if (str.match(/\[tag\]/g)) {
					matchLeftCount = (str.match(/\[tag\]/g)).length;
				}
				if (str.match(/\[\/tag\]/g)) {
					matchRightCount = (str.match(/\[\/tag\]/g)).length;
				}
				if (matchLeftCount == matchRightCount && matchLeftCount > 0) {
					str = str.replace(/\[tag\]/g, '[color=' + colorStr + ']')
					str = str.replace(/\[\/tag\]/g, '[/color]');
				}
			}
			return game.UBBParser.Inst.parse(str, null);
		}

		// 从小到大
		public static GetSheetSortBy(table_name: string, sheet_name: string, key: string): Array<any> {
			let _datas: Array<any> = [];
			cfg[table_name][sheet_name].forEach((a) => {
				_datas.push(a);
			});
			_datas.sort((a, b) => { return a[key] - b[key] });
			return _datas;
		}


		// 挂机惩罚s
		public static showGuaJiChengFa(data) {
			let title: string;
			let desc: string;
			if (data.type == 2) {
				let t: string = game.Tools.time2YearMounthDate(data.ban_end_time) + ' ' + game.Tools.time2HourMinute(data.ban_end_time, false);
				title = game.Tools.strOfLocalization(3040);
				desc = game.Tools.strOfLocalization(3041, [t]);
			} else {
				title = game.Tools.strOfLocalization(3038);
				desc = game.Tools.strOfLocalization(3039);
			}
			uiscript.UI_SecondConfirm_Title.Inst.show_only_confirm(desc, title, new Laya.Handler(this, () => {
				if (data.type == 2) {
					if (!uiscript.UI_Entrance.Inst || !uiscript.UI_Entrance.Inst.enable) {
						Laya.Browser.window.location.href = GameMgr.Inst.link_url;
					}
				}
			}))
		}

		// 重置3d物体粒子
		public static resetParticles(root: Laya.Sprite3D) {
			if (root instanceof Laya.ShuriKenParticle3D) {
				root.particleSystem.stop();
				root.particleSystem.play();
			}
			for (let child of root._childs) {
				this.resetParticles(child);
			}
		}

		// string转Laya.Vector4
		public static HexToColor(hexString: string): Laya.Vector4 {
			hexString = hexString.replace('0x', '');
			hexString = hexString.replace('#', '');
			let a = 255;
			let r = Number('0x' + hexString.substring(0, 2));
			let g = Number('0x' + hexString.substring(2, 4));
			let b = Number('0x' + hexString.substring(4, 6));
			if (hexString.length == 8) {
				a = Number('0x' + hexString.substring(6));
			}
			return new Laya.Vector4(r / 255, g / 255, b / 255, a / 255)
		}

		/**
		 * 此处仅能拷贝到数据，方法会丢失
		 * @param data 
		 * @returns 
		 */
		public static deepCopy<T>(data: Object): T {
			let tStr = JSON.stringify(data);
			return JSON.parse(tStr);
		}

		/** 解析pb数据为普通对象 */
		public static decodeProtoData(data: { $type?: protobuf.Type } | { $type?: protobuf.Type }[]) {
			if (!data) return data;
			if (Array.isArray(data))
				return data.map(this.decodeProtoData, this);
			const type = data.$type;
			if (!type) return data;
			const result = {};
			type.fieldsArray.forEach(v => {
				const value = data[v.name];
				result[v.name] = this.decodeProtoData(value);
			});
			return result;
		}

		/**
		 * pos必须是sprite子物体下的点，如果是物体本身的坐标，第一个参数要传sprite的父物体
		 */
		public static posLocalToGlobal(sprite: Laya.Sprite, posX: number, posY: number): Laya.Vector2 {
			let point: Laya.Point = new Laya.Point(posX, posY);
			point = sprite.localToGlobal(point);
			return new Laya.Vector2(point.x, point.y);
		}

		public static removeFromArray(array: Array<Object>, item: Object) {
			let index = array.indexOf(item);
			array.splice(index, 1);
		}

		/**
		 * 剩余时间≥1天：显示4209（{0}天后解锁） 在一行内展示
		 * 1天＞剩余时间≥1小时：显示4210（{0}小时后解锁）
		 * 1小时＞剩余时间：显示4214（{0}分钟后解锁）
		 * 时间向下取整，小于1分钟时特殊显示一分钟
		 * @param seconds 
		 * @returns 
		 */
		public static getLockTimeText1(seconds: number): string {
			let timeString = "";
			let date = new common.TimeConvert(seconds);
			let day = date.getDays();
			let hour = date.getHours();
			let minute = date.getMinutes();

			if (day > 0) {
				timeString = game.Tools.strOfLocalization(4209, [day.toString()]);
			}
			else if (date.getHours() > 0) {
				timeString = game.Tools.strOfLocalization(4210, [hour.toString()]);
			}
			else {
				if (minute == 0) {
					minute = minute + 1;
				}
				timeString = game.Tools.strOfLocalization(4211, [minute.toString()]);
			}
			return timeString;
		}

		/**
		 * 剩余时间≥1天：显示4433（{0}天后解锁）  与上面的区别是分了两行
		 * 1天＞剩余时间≥1小时：显示4434（{0}小时后解锁）
		 * 1小时＞剩余时间：显示4435（{0}分钟后解锁）
		 * 时间向下取整，小于1分钟时特殊显示一分钟
		 * @param seconds 
		 * @returns 
		 */
		public static getLockTimeText2(seconds: number): string {
			let timeString = "";
			let date = new common.TimeConvert(seconds);
			let day = date.getDays();
			let hour = date.getHours();
			let minute = date.getMinutes();
			if (day > 0) {
				timeString = game.Tools.strOfLocalization(4433, [day.toString()]);
			}
			else if (date.getHours() > 0) {
				timeString = game.Tools.strOfLocalization(4434, [hour.toString()]);
			}
			else {
				if (minute == 0) {
					minute = minute + 1;
				}
				timeString = game.Tools.strOfLocalization(4435, [minute.toString()]);
			}
			return timeString;
		}
		public static getCalendar(year: number, month: number) {
			let firstDay = new Date(year, month - 1, 1).getDay(); // 获取当月第一天是星期几
			firstDay = firstDay == 0 ? 7 : firstDay;
			let daysInMonth = new Date(year, month, 0).getDate(); // 获取当月的天数
			let calendar: number[][] = []; // 存储日历数据的数组
			let day = 1; // 从第一天开始
			// 生成日历数据
			for (let i = 0; i < 6; i++) {
				calendar[i] = [];
				for (let j = 0; j < 7; j++) {
					if ((i === 0 && j < firstDay - 1) || day > daysInMonth) {
						calendar[i][j] = 0;
					} else {
						calendar[i][j] = day;
						day++;
					}
				}
			}
			return calendar;
		}

		public static listAnim(list: capsui.CScrollView | capsui.CScrollView_Heng, most_count: number, tween_config: {}, start_config: {}, target_config: {}): number {
			if (list.items.length == 0) return 0;
			let __index = -1;
			var cache_pos = [];
			let move_count = 0;
			let delay: number = tween_config['delay'] ? tween_config['delay'] : 0;
			let duration: number = tween_config['duration'] ? tween_config['duration'] : 0;
			let Ease: Function = tween_config['ease'] ? tween_config['ease'] : null;
			list.items.forEach((value, index: number) => {
				let com = value.container
				let target = {};
				cache_pos.push({ x: com.x, y: com.y });
				for (let key in target_config) {
					target[key] = target_config[key];
					if (key == 'y') {
						//计算目标位置
						target['y'] = start_config['y_dis'] ? start_config['y_dis'] * index + target_config['y'] : target_config['y'];
					}
					if (key == 'x') {
						target['x'] = start_config['x_dis'] ? start_config['x_dis'] * index + target_config['x'] : target_config['x'];
					}
				}
				if (index < most_count) {
					move_count++;
					for (let key in start_config) {
						if (com[key] != null) {
							com[key] = start_config[key];
						}
						// 有相对坐标的情况下就不要再去用初始位置了,直接拿当前位置
						if (key == 'y_dis') {
							target['y'] = com.y;
							com.y = target['y'] + start_config[key]
						}

						if (key == 'x_dis') {
							target['x'] = com.x;
							com.x = target['x'] + start_config[key]
						}
					}
					Laya.Tween.to(com, target, duration, Ease, null, index * delay, true);
				} else {
					for (let key in target) {
						if (com[key]) {
							com[key] = target[key];
						}
					}
				}
			});
			return (move_count - 1) * delay + duration;
		}

		/**
		 * 列表动画
		 * @param sprites 列表的item
		 * @param tweenConfig 动画参数，delay是每个item之间的间隔，duration是动画时间，ease是缓动函数
		 * @param startConfig 开始参数，x_dis,y_dis是移动距离，其它参照tween
		 * @param targetConfig  目标参数,参照tween
		 * @returns 
		 */
		public static listSpritesAnim(sprites: Array<Laya.Sprite>, tweenConfig: { delay: number, duration: number, ease: Function }, startConfig: { x_dis?: number, y_dis?: number }, targetConfig: {}): number {
			if (sprites.length == 0) return 0;
			let __index = -1;
			var cache_pos = [];
			let move_count = 0;
			let delay: number = tweenConfig.delay ? tweenConfig.delay : 0;
			let duration: number = tweenConfig.duration ? tweenConfig.duration : 0;
			let Ease: Function = tweenConfig.ease ? tweenConfig.ease : null;
			sprites.forEach((value, index: number) => {
				let com = value
				let target = {};
				cache_pos.push({ x: com.x, y: com.y });
				for (let key in targetConfig) {
					target[key] = targetConfig[key];
					if (key == 'y') {
						//计算目标位置
						target['y'] = startConfig.y_dis ? startConfig.y_dis * index + targetConfig['y'] : targetConfig['y'];
					}
					if (key == 'x') {
						target['x'] = startConfig.x_dis ? startConfig.x_dis * index + targetConfig['x'] : targetConfig['x'];
					}
				}
				if (index < sprites.length) {
					move_count++;
					for (let key in startConfig) {
						if (com[key] != null) {
							com[key] = startConfig[key];
						}
						// 有相对坐标的情况下就不要再去用初始位置了,直接拿当前位置
						if (key == 'y_dis') {
							target['y'] = com.y;
							com.y = target['y'] + startConfig[key]
						}

						if (key == 'x_dis') {
							target['x'] = com.x;
							com.x = target['x'] + startConfig[key]
						}
					}
					Laya.Tween.to(com, target, duration, Ease, null, index * delay, true);
				} else {
					for (let key in target) {
						if (com[key]) {
							com[key] = target[key];
						}
					}
				}
			});
			return (move_count - 1) * delay + duration;
		}

		/**
		 * 当前节点是否在屏幕内显示
		 */
		public static isSpriteVisible(sprite: Laya.Sprite) {
			// 检查当前sprite的visible属性
			if (!sprite.visible) {
				return false;
			}

			// 检查sprite是否已经添加到舞台上
			if (!sprite.stage) {
				return false;
			}

			// 递归检查父节点的visible属性
			let currentNode = sprite.parent;
			while (currentNode) {
				// 只有Sprite及其子类有visible属性，因此需要判断
				if (currentNode instanceof Laya.Sprite && !currentNode.visible) {
					return false;
				}
				currentNode = currentNode.parent;
			}

			// 所有条件都通过，sprite是真正可见的
			return true;
		}

		/**
		 * 清除buttonclickhandler
		 */
		public static clearBtnClickHandler(btn: Laya.Button) {
			if (btn.clickHandler) {
				btn.clickHandler.recover();
				btn.clickHandler = null;
			}
		}


		public static dfsChangeParticleMat(root: Laya.Sprite3D) {
			for (let child of root._childs) {
				if (child._childs && child._childs.length > 0) {
					this.dfsChangeParticleMat(child);
				}
				if (child.particleRender && child.particleRender.material && child.particleRender.material.renderQueue > 3002) {
					child.particleRender.material.depthTest = 0;
				} else if (child.meshRender && child.meshRender.material && child.meshRender.material.renderQueue > 3002) {
					child.meshRender.material.depthTest = 0;
				}
			}
		}

		public static changePaiMat(pai: Laya.Sprite3D, renderQueue: number, renderQueue2: number, depthTest: number) {
			if (!pai) return;

			if (pai.getChildAt(0) && pai.getChildAt(0).getChildAt(0)) {
				if ((pai.getChildAt(0).getChildAt(0) as Laya.MeshSprite3D).meshRender) {
					// 透明牌
					let mat = (pai.getChildAt(0).getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial;
					mat.depthTest = depthTest;
					mat.renderQueue = renderQueue;
					mat = (pai.getChildAt(0).getChildAt(0).getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial;
					mat.depthTest = depthTest;

					mat.renderQueue = renderQueue2;
				} else {
					let mats = (pai.getChildAt(0).getChildAt(0).getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterials; //maque_new
					for (let mat_0 of mats) {
						mat_0.depthTest = depthTest;
						mat_0.renderQueue = renderQueue;
					}

					let mat = (pai.getChildAt(0).getChildAt(0).getChildAt(1) as Laya.MeshSprite3D).meshRender.sharedMaterial; //maque_outline
					mat.depthTest = depthTest;

					mat.renderQueue = renderQueue2;
				}


			} else if ((pai as Laya.MeshSprite3D).meshRender) {
				// 胡牌


				let mat = (pai as Laya.MeshSprite3D).meshRender.sharedMaterial;
				mat.depthTest = depthTest;
				mat.renderQueue = renderQueue;
				mat = (pai.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial;
				mat.depthTest = depthTest;
				mat.renderQueue = renderQueue2;
			} else if ((pai.getChildAt(0) as Laya.MeshSprite3D).meshRender) {
				let mats = (pai.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterials;
				for (let mat_0 of mats) {
					mat_0.depthTest = depthTest;
					mat_0.renderQueue = renderQueue;
				}

				let mat = (pai.getChildAt(1) as Laya.MeshSprite3D).meshRender.sharedMaterial;
				mat.depthTest = depthTest;

				mat.renderQueue = renderQueue2;
			}
		}

		public static checkEffectLocalization(effect: Laya.Sprite3D) {
			let localization = game.Tools.GetNodeByNameInChildren(effect, 'localization') as Laya.Sprite3D;
			if (localization) {
				localization._childs.forEach(v => v.active = false);
				let nodeName = GameMgr.client_language;
				if (localization.getChildByName(nodeName)) {
					(localization.getChildByName(nodeName) as Laya.Sprite3D).active = true;
				} else if (localization.getChildByName('common')) {
					(localization.getChildByName('common') as Laya.Sprite3D).active = true;
				}
			}
		}

		/** 
		 * 返回当前时间戳（秒）
		 * @returns 
		 */
		public static getSecondTimeStamp(): number {
			return Laya.timer.currTimer / 1000;
		}

		public static dateConver: Date;
		/**
		 * 根据年月日时分秒获取时间戳
		 * @param year 
		 * @param month monthIndex 0-11
		 * @param day 
		 * @param hour 
		 * @param minutes 
		 * @param seconds 
		 * @returns 毫秒时间戳
		 */
		public static getMSTimeStampByDate(year: number, month: number = 0, day: number = 0, hour: number = 0, minutes: number = 0, seconds: number = 0): number {

			if (!this.dateConver) {
				this.dateConver = new Date();
			}
			this.dateConver.setFullYear(year);
			this.dateConver.setMonth(month);
			this.dateConver.setDate(day);
			this.dateConver.setHours(hour);
			this.dateConver.setMinutes(minutes);
			this.dateConver.setSeconds(seconds);
			return this.dateConver.getTime();
		}

		/**
		 * 当前服务器时间，年月日的时间戳，秒数为0
		 * @returns 
		 */
		public static getServerDateTimestamp(): number {
			let serverDate = new Date(game.Tools.getServerTime());
			serverDate.setHours(0);
			serverDate.setMinutes(0);
			serverDate.setSeconds(0);
			serverDate.setMilliseconds(0);
			return serverDate.getTime();
		}



		public static titleSplit: string = "·";
		/**
		 * 获取牌谱标题 
		 *  【段位场=三段】：段位场-王座之间-四人南（段位场-x之间-局数信息）
		 *	【友人场=两段】：友人场-四人东（友人场-局数信息）
		 *	【活动场=两段】：修罗之战-四人东（活动场使用规则名-局数信息）
		 *	【赛事场=两段】：比赛场-四人东（比赛场-局数信息）
		 * @param tag 标题类型 1排位赛 2友人场 3活动场 4比赛场
		 * @param subtag 子标签，根据tag来 tag=1/3 就是matchmode.id，tag=2/4 就是mode.mode
		 * @returns 
		 */
		public static getPaipuTitle(tag: number, subtag: number): string {
			let title: string = '';
			let matchModeData: lqc.Sheet_Desktop_Matchmode;
			let mode: number;
			switch (tag) {

				case 1:
					title += game.Tools.strOfLocalization(2271) + game.Tools.titleSplit;
					matchModeData = cfg.desktop.matchmode.get(subtag);
					if (matchModeData) {
						title += matchModeData['room_name_' + GameMgr.client_language] + game.Tools.titleSplit;
						mode = matchModeData.mode;
					}
					title += game.Tools.room_mode_desc(mode);
					break;
				case 2:
					title += game.Tools.strOfLocalization(2023) + game.Tools.titleSplit;
					title += game.Tools.room_mode_desc(subtag);
					break;
				case 3:
					matchModeData = cfg.desktop.matchmode.get(subtag);
					title += matchModeData['room_name_' + GameMgr.client_language] + game.Tools.titleSplit;
					mode = matchModeData.mode;
					title += game.Tools.room_mode_desc(mode);
					break;
				case 4:
					title += game.Tools.strOfLocalization(2025) + game.Tools.titleSplit;
					title += game.Tools.room_mode_desc(subtag);
					break;


			}
			return title;
		}

		/**
		 * 获取指定月份有几天
		 * @param year 年
		 * @param month 月 1-12
		 * @returns 
		 */
		public static getMonthDays(year: number, month: number): number {
			return new Date(year, month, 0).getDate();
		}

		/**
		 * 获取指定的日期是星期几，因为国外是从周日开始，所以返回的是0-6，0是周日
		 * @param year 年
		 * @param month 月 1-12
		 * @param day 日 1-31
		 * @returns 0-6 周一是0
		 */
		public static getDayWeek(year: number, month: number, day: number): number {
			let date = new Date(year, month - 1, day);
			// 0-6 周日是0
			let weekDay = date.getDay();
			if (weekDay == 0) {
				weekDay = 6;
			} else {
				weekDay--;
			}
			return weekDay;


		}

		/**
		 * 按照牌的类型和值排序，从小到大,返回新数组
		 * @param tiles 
		 * @returns 
		 */
		public static sortPaiStr(tiles: string[]) {
			let newPais: mjcore.MJPai[] = [];
			for (let index = 0; index < tiles.length; index++) {
				const element = tiles[index];
				let pai = mjcore.MJPai.Create(element);
				newPais.push(pai);
			}
			newPais = this.sortPai(newPais)
			let newTiles: string[] = [];
			for (let index = 0; index < newPais.length; index++) {
				const element = newPais[index];
				newTiles.push(element.toString());
			}
			return newTiles;
		}

		/**
		 * 按照牌的类型和值排序，从小到大,返回新数组
		 * @param pai 
		 */
		public static sortPai(pais: mjcore.MJPai[]): mjcore.MJPai[] {
			let newPais: mjcore.MJPai[] = [];
			for (let index = 0; index < pais.length; index++) {
				const element = pais[index];
				newPais.push(element.Clone());
			};
			newPais.sort((a, b) => {
				return (a.numValue() * 10 + (a.dora ? 0 : 1)) - (b.numValue() * 10 + (b.dora ? 0 : 1));

			});
			return newPais;
		}

		/**
		 * 获取单张牌的名字
		 * @param pai 
		 * @returns 
		 */
		public static getTileName(pai: mjcore.MJPai): string {
			let tileName = "";

			if (pai.type == 3) {
				switch (pai.index) {
					case 1:
						tileName += "东";
						break;
					case 2:
						tileName += "南";
						break;
					case 3:
						tileName += "西";
						break;
					case 4:
						tileName += "北";
						break;
					case 5:
						tileName += "白";
						break;
					case 6:
						tileName += "发";
						break;
					case 7:
						tileName += "中";
						break;
					default:
						break;
				}
			} else if (pai.type == 4) {
				tileName = "百搭牌";
			} else {
				if (pai.dora) {
					tileName += "红5";
				} else {
					tileName += pai.index;
				}
				switch (pai.type) {
					case 0:
						tileName += "筒";
						break;
					case 1:
						tileName += "万";
						break;
					case 2:
						tileName += "条";
						break;
					default:
						break;
				}
			}
			return tileName;
		}

		/**
		 * 获取牌数组的文本版
		 * @param pais 
		 * @returns 
		 */
		public static getTilesLog(pais: mjcore.MJPai[], isSort: boolean = true): string {
			let str = '';
			//排序 然后打印
			if (isSort) {
				pais = this.sortPai(pais);
			}
			for (let index = 0; index < pais.length; index++) {
				const element = pais[index];
				str += this.getTileName(element) + ",";
			}
			return str;
		}

		/**
		 * 根据牌谱uuid获取牌谱的时间
		 * @param uuid 
		 * @returns 
		 */
		public static getGameRecordDate(uuid: string) {
			if (uuid.length === 36) {
				return 0;
			}

			if (uuid.length === 43) {
				return parseInt(uuid.slice(0, 6));
			}
			return 0;
		}

		/**
		 * 修复http请求的json数据中空缺的数据
		 * @param data 数据
		 * @param service_name 服务名
		 * @param rpc_name 请求名称，game.ERequest
		 * @returns 
		 */
		public static fixHttpJsonData(data: any, service_name: string, rpc_name: string): any {
			let rightData = null;
			let res_type = '';
			let service = net.ProtobufManager.lookupService('lq.' + service_name);
			for (let method in service.methods) {
				if (method == rpc_name) {
					res_type = service.methods[method].responseType;
					break;
				}
			}

			rightData = net.ProtobufManager.lookupType('lq.' + res_type).fromObject(data);
			return rightData;
		}

		/** 是否是en繁体 */
		public static isEnChst() {
			return GameMgr.client_language == 'chs_t' && (GameMgr.client_type == 'en');
		}

		/**
		 * 小数点保留后n位，向下截取
		 * @param num 数字
		 * @param decimalPlaces 小数点后保留的位数
		 * @returns 返回截取后的数字,如果是整数，则返回整数
		 */
		public static toFixedDown(num: number, decimalPlaces: number): number {
			if (decimalPlaces < 0) {
				return num;
			}
			const factor = Math.pow(10, decimalPlaces);
			//如果大于0
			if (num >= 0) {
				return Math.floor(num * factor) / factor;
			}
			//如果小于0
			return Math.ceil(num * factor) / factor;
		}

		public static getCharaVoiceByType(character_info: Partial<game.ICharacter>, type: string): lqc.Sheet_Voice_Sound {
			if (!character_info || !character_info.charid) {
				return null;
			}
			let chara_id: number = character_info.charid;
			var d_chara = cfg.item_definition.character.get(chara_id);
			if (!d_chara) {
				return null;
			}
			let level = character_info.level;
			let sounds = cfg.voice.sound.findGroup(d_chara.sound);
			let _ss: Array<number> = [];
			for (let i: number = 0; i < sounds.length; i++) {
				if (sounds[i].date_limit) {
					let date = new Date();
					let limits = sounds[i].date_limit.split('-');
					// 判定期限是否生效
					if (parseInt(limits[0]) == date.getMonth() + 1 && parseInt(limits[1]) == date.getDate()) {
						if (sounds[i].type == 'lobby_limited') {
							if (type == 'lobby_playerlogin') {
								if (sounds[i].bond_limit && !character_info.is_upgraded) continue;
								if (sounds[i].level_limit > level) continue;
								_ss = [i];
								break;
							} else if (type == 'lobby_normal') {

							} else {
								continue;
							}
						} else {
							continue;
						}

					} else {
						continue;
					}
				} else {
					if (sounds[i].type != type) continue;
				}

				if (sounds[i].bond_limit && !character_info.is_upgraded) continue;
				if (sounds[i].level_limit > level) continue;
				_ss.push(i);
			}
			if (_ss.length == 0) {
				return null;
			}
			else {
				let index: number = _ss[Math.floor(Math.random() * _ss.length)];
				return sounds[index];
			}
		}

		/**
		 * 打开大会室管理页面
		 * @param onComplete 
		 */
		public static jumpToMatchWebsite(onComplete: Laya.Handler = null) {
			let onConfirm = Laya.Handler.create(this, () => {
				let rqs: game.IReqCommon = {};
				app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.generateContestManagerLoginCode, rqs, (err, res: game.IResGenerateContestManagerLoginCode) => {
					if (err || res['error']) {
						uiscript.UIMgr.Inst.showNetReqError(game.ERequest.generateContestManagerLoginCode, err, res);
					} else {
						let token = res.code;
						let url = GameMgr.dhs_url + "?code=" + token;
						app.Log.log("dhs_url: " + url);
						game.Tools.open_link(url);
					}
					onComplete?.runWith({ err, res });
				});
			})
			let onCancel = Laya.Handler.create(this, () => {
				onComplete?.runWith(null);
			})
			uiscript.UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(10017), onConfirm, onCancel);
			uiscript.UI_SecondConfirm.Inst.setBtnState(true, true);
		}

		/**
		 * 获取字符串的字节长度，中文2字节，英文1字节
		 * @param str 
		 * @returns 
		 */
		public static getStringCodeLength(str: string): number {
			let len = 0;
			for (let i = 0; i < str.length; i++) {
				if (str.charCodeAt(i) > 255) {
					len += 2;
				} else {
					len += 1;
				}
			}
			return len;
		}

		/**
		 * 获取字符串的子串，按字节长度截取，英文1字节,其它2字节
		 * @param str 
		 * @param maxLength 
		 * @returns 
		 */
		public static substringByCodeLength(str: string, maxLength: number): string {
			let len = 0;
			let result = '';
			for (let i = 0; i < str.length; i++) {
				if (str.charCodeAt(i) > 255) {
					len += 2;
				} else {
					len += 1;
				}
				if (len > maxLength) {
					break;
				}
				result += str.charAt(i);
			}
			return result;
		}

		/**
		 * 获取某个时间戳当天n时n分n秒n毫秒的时间戳，默认为0点
		 * @param timestamp ，单位是毫秒
		 * @returns timestamp，单位是毫秒
		 */
		public static getDayStartTimestamp(timestamp: number, hours: number = 0, min: number = 0, sec: number = 0, ms: number = 0): number {
			let date = new Date(timestamp);
			date.setHours(hours, min, sec, ms);
			return date.getTime();
		}

		//是否开启主备ab测的日志
		public static CheckReconnectInfoNeedSend(): boolean { 
			// if (GameMgr.client_type == 'kr') {
			// 	return true;
			// }
			return false;
		}

		// 从app移植，发送特殊日志到服务器，由于不使用，内容不保留
		public static SendSpecialInfo(data: Object, logCategory: string) { 
			GameMgr.Inst.SendSpecialLog(data, logCategory)
		}

		public static StrColor2FilterMartix(str: string) {
			if (str === null) str = "#ffffff";
			str.charAt(0) == '#' && (str = str.substring(1));
			const len = str.length;
			if (len == 3 || len == 4) {
				let temp = "";
				for (let i = 0; i < len; i++) {
					temp += (str[i] + str[i]);
				}
				str = temp;
			};
			const color = parseInt(str, 16);
			let r = 1, g = 1, b = 1, a = 1;
			if (str.length == 8) {
				r = parseInt(str.substring(0, 2), 16) / 255;
				g = ((0x00FF0000 & color) >> 16) / 255;
				b = ((0x0000FF00 & color) >> 8) / 255;
				a = (0x000000FF & color) / 255;
			} else {
				r = ((0xFF0000 & color) >> 16) / 255;
				g = ((0xFF00 & color) >> 8) / 255;
				b = (0xFF & color) / 255;
			}
			return [
				r, 0, 0, 0, 0,
				0, g, 0, 0, 0,
				0, 0, b, 0, 0,
				0, 0, 0, 1, 0,
			];
		}

		// 强制重播节点上的所有效果
		public static replayAllEffect(node) {
            // 重播所有粒子
            let particle = node.particleSystem;
            if (particle) {
                particle.stop();
                particle.simulate(0, true);
                particle.play();
            }

            // 重播所有动画
			let animator = node.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			if (animator) {
				animator.Play(null)
			}

			for (let i = 0; i < node.numChildren; i++) {
				this.replayAllEffect(node.getChildAt(i));
			}
		}

	}

}