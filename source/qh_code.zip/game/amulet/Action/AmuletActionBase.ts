/**
* name 
*/
module amulet {
	export class AmuletActionBase {
		static get desktopMgr() {
			return AmuletDesktopMgr.Inst;
		}

		static get desktopUI() {
			return uiscript.UI_AmuletDesktopInfo.Inst;
		}
	}
}