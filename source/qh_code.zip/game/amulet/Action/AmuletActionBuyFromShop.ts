/**
* name 
*/
module amulet {
	export class AmuletActionBuyFromShop extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityBuy, onComplete?: Laya.Handler): void {
			uiscript.UI_AmuletShop.Inst.openPackage(this.desktopMgr.amuletGameData.shop.candidate_effect_list, param.id);
			uiscript.UI_AmuletShop.Inst.refreshCurrency();
			this.desktopMgr.refreshData();
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}