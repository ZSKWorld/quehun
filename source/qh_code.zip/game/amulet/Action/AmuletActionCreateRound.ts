/**
* name 
*/
module amulet {
	export class AmuletActionCreateRound extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IAmuletEventData, onComplete: Laya.Handler): void {
			this.desktopMgr.resetAutoFunc();
			this.desktopUI.refreshState(amulet.EAmuletGameState.DuringFight, false);
			this.desktopMgr.refreshData(false, this.desktopMgr.originRoundData);
			AmuletDesktopMgr.timer.once(383, this, () => {
				const hands = this.desktopMgr.originRoundData.round.hands;
				let handCards: Array<amulet.MJPai> = [];
				for (let i: number = 0; i < hands.length; i++) {
					let id = hands[i];
					handCards.push(this.desktopMgr.getDisplayMJPaiById(id));
				}
				this.desktopMgr.mainrole.NewGame(handCards, [], [], false);
				const remainCardCount = this.desktopMgr.originRoundData.round.desktop_remain || 0;
				const remainCards = this.desktopMgr.originRoundData.round.show_desktop_tiles || [];
				const lockedTiles = this.desktopMgr.originRoundData.round.locked_tile || [];
				let desktopCards: Array<amulet.MJPai> = [];
				for (let i: number = 0; i < lockedTiles.length + remainCardCount; i++) {
					desktopCards.push(amulet.MJPai.CreateEmpty());
				}
				remainCards.forEach((value) => {
					if (value.pos < remainCardCount + lockedTiles.length) {
						desktopCards[value.pos] = this.desktopMgr.getDisplayMJPaiById(value.id);
					}
				});
				this.desktopMgr.mainrole.InitDesktopPais(desktopCards, lockedTiles, false);
				AmuletDesktopMgr.timer.once(1500, this, () => {
					AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
						onComplete && onComplete.run();
					}));
				});
			})
		}
	}
}