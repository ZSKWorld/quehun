/**
* name 
*/
module amulet {
	export class AmuletActionEndingShop extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			this.desktopMgr.refreshData();
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				this.desktopUI.refreshState(EAmuletGameState.CheckBoss, false);
				onComplete && onComplete.run();
			}))
		}
	}
}