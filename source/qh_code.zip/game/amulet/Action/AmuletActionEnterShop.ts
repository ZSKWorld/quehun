/**
* name 
*/
module amulet {
	export class AmuletActionEnterShop extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			this.desktopMgr.resetAutoFunc();
			uiscript.UI_AmuletLevelResult.Inst.hide();
			this.desktopMgr.mainrole.Clear();
			this.desktopUI.refreshCurrency(uiscript.SciNum.createSciNumByStr(this.desktopMgr.amuletGameData.game.coin || '0'), false);
			this.desktopUI.refreshState(EAmuletGameState.DuringShop, false);
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}