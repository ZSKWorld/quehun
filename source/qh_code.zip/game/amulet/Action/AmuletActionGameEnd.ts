/**
* name 
*/
module amulet {
	export class AmuletActionGameEnd extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			this.desktopMgr.gameResultData = { level: this.desktopMgr.amuletGameData.game.level, reason: data.result.game_end_result.reason };
			let gameClear = data.result.game_end_result.reason == 2;
			let delay = 0;
			if (gameClear) {
				delay = 100;
				uiscript.UI_AmuletLevelResult.Inst.hide();
			}
			AmuletDesktopMgr.timer.once(delay, this, () => {
				uiscript.UI_AmuletGameResult.Inst.show();
				onComplete && onComplete.run();
			});
		}
	}
}