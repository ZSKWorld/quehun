/**
* name 
*/
module amulet {
	export class AmuletActionOperateDealTile extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler): void {
			if (this.desktopMgr.reachTarget) {
				let tile = this.desktopMgr.getDisplayMJPaiById(data.result.deal_result.tile, false);
				// app.Log.log('翻开了牌' + tile.toString());
				this.desktopMgr.mainrole.OpenDesktopLastPai(tile);
				//如果翻牌有护身符效果不需要停留，也不需要动画
				AmuletHookEffect.playImmediately(data.effected_hooks, null);
				AmuletDesktopMgr.timer.once(133, this, () => {
					onComplete && onComplete.run();
				})
				return;
			}
			this.desktopMgr.duringHuPai = false;
			if (this.desktopMgr.amuletGameData.round.ting_list) {
				uiscript.UI_AmuletTingPai.Inst.setData(this.desktopMgr.amuletGameData.round.ting_list);
			}
			if (data.result.deal_result && data.result.deal_result.tile) {
				this.desktopMgr.mainrole.RemoveDesktopLastPai();
				AmuletDesktopMgr.timer.once(300, this, () => {
					view.AudioMgr.PlayAudio(10154);
				});
				AmuletDesktopMgr.timer.once(400, this, () => {
					this.desktopMgr.mainrole.TakePai(this.desktopMgr.paiMap[data.result.deal_result.tile].Clone(), false);
					this.desktopUI.refreshLeftPai(this.desktopMgr.amuletGameData.round.desktop_remain);
					AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
						//解锁
						onComplete && onComplete.run();
						//解锁后判定是否需要自动胡牌等
						this.desktopMgr.ShowOperation(this.desktopMgr.amuletGameData.round.next_operation);
					}));
				})
			} else {
				//解锁
				onComplete && onComplete.run();
				//解锁后判定是否需要自动胡牌等
				this.desktopMgr.ShowOperation(this.desktopMgr.amuletGameData.round.next_operation);
			}

		}
	}
}