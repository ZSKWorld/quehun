/**
* name 
*/
module amulet {
	export class AmuletActionOperateDiscardTile extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler): void {
			if (this.desktopMgr.reachTarget) {
				this.desktopMgr.mainrole.PutDownDesktopPai();
				//如果翻牌有护身符效果不需要停留，也不需要动画
				AmuletHookEffect.playImmediately(data.effected_hooks, null);
				onComplete && onComplete.run();
				return;
			}
			uiscript.UI_AmuletOperation.Inst.enable = false;
			this.desktopMgr.mainrole.can_discard = false;
			let delay = 0;
			//是否需要打出弃的牌
			if (param.type == EAmuletPlayOperation.discard || param.type == EAmuletPlayOperation.forceDiscard) {
				const tile = param.tile_list;
				this.desktopMgr.mainrole.onDiscardSuccess(this.desktopMgr.getDisplayMJPaiById(tile[0]), true);
				delay += 300;
			}
			AmuletDesktopMgr.timer.once(delay, this, () => {
				AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
					onComplete && onComplete.run();
				}));
			})
		}
	}
}