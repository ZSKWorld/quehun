/**
* name 
*/
module amulet {
	export class AmuletActionOperateEndExchange extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler): void {
			uiscript.UI_AmuletOperation.Inst.enable = false;
			this.desktopMgr.mainrole.can_discard = false;
			this.desktopMgr.mainrole.endExchangeHands();
			this.desktopUI.refreshTipReplace(true);
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}