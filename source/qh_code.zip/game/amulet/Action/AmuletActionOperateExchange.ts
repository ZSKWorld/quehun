/**
* name 
*/
module amulet {
	export class AmuletActionOperateExchange extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler, fast: boolean = false): void {
			let deleteCards: Array<amulet.MJPai> = [];
			for (let i: number = 0; i < this.desktopMgr.choosedReplacePaiIds.length; i++) {
				let id = this.desktopMgr.choosedReplacePaiIds[i];
				deleteCards.push(this.desktopMgr.getDisplayMJPaiById(id));
			}
			uiscript.UI_AmuletOperation.Inst.refreshBtnReplace();
			this.desktopMgr.mainrole.onHuanPai_Remove(deleteCards, fast);
			const lastHands = param.tile_list;
			let newCards: Array<amulet.MJPai> = [];
			for (let i: number = 0; i < this.desktopMgr.amuletGameData.round.hands.length; i++) {
				if (lastHands.indexOf(this.desktopMgr.amuletGameData.round.hands[i]) == -1) {
					newCards.push(this.desktopMgr.getDisplayMJPaiById(this.desktopMgr.amuletGameData.round.hands[i]));
				}
			}
			uiscript.UI_AmuletTingPai.Inst.setData([]);
			view.AudioMgr.PlayAudio(10148);
			if (this.desktopMgr.changeTileCount == 0) {
				uiscript.UI_AmuletOperation.Inst.enable = false;
			}
			this.desktopMgr.refreshData();
			AmuletDesktopMgr.timer.once(300, this, () => {
				this.desktopMgr.mainrole.onHuanPai_Add(newCards, false);
				uiscript.UI_AmuletTingPai.Inst.setData(this.desktopMgr.amuletGameData.round.ting_list);
				AmuletDesktopMgr.timer.once(800, this, () => {
					AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
						onComplete && onComplete.run();
						if (this.desktopMgr.changeTileCount == 0) {
							this.desktopMgr.endExchangeHands();
						} else {
							this.desktopMgr.mainrole.startExchangeHands();
						}
					}));
				});
			});
		}
	}
}