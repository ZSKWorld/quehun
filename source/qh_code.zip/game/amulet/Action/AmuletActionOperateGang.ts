/**
* name 
*/
module amulet {
	export class AmuletActionOperateGang extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler): void {
			uiscript.UI_AmuletOperation.Inst.enable = false;
			this.desktopMgr.mainrole.can_discard = false;
			let delay = 0;
			if (data.result.gang_result && data.result.gang_result.new_dora) {
				this.desktopMgr.WhenDoras(data.result.gang_result.new_dora, false);
			}
			let refreshTing = false;
			if (data.value_changes.round.ting_list && data.value_changes.round.ting_list.dirty) {
				refreshTing = true;
				uiscript.UI_AmuletTingPai.Inst.setData(data.value_changes.round.ting_list.value);
			}
			//是否需要杠牌
			if (this.desktopMgr.amuletGameData.round.ming) {
				let isNeedGang = false;
				for (let index = 0; index < this.desktopMgr.amuletGameData.round.ming.length; index++) {
					let mingInfo = this.desktopMgr.amuletGameData.round.ming[index];
					//是不是新的杠牌
					if (this.desktopMgr.mainrole.isNewGang(mingInfo)) {
						isNeedGang = true;
						let ming: amulet.MJMing = new amulet.MJMing();
						ming.type = mingInfo.type;
						let ret: MJPai[] = [];
						for (let i: number = 0; i < 4; i++) {
							let _p: amulet.MJPai = this.desktopMgr.getDisplayMJPaiById(mingInfo.tile_list[i]);
							ret.push(_p);
						}
						ming.pais = ret;
						this.desktopMgr.mainrole.PlayGangSound();
						this.desktopMgr.mainrole.AddMing(ming, true);
						if (!refreshTing) {
							refreshTing = true;
							uiscript.UI_AmuletTingPai.Inst.onDiscardTile(ret[0]);
						}
					}
				}
				if (isNeedGang) delay += 300;
			}
			AmuletDesktopMgr.timer.once(delay, this, () => {
				AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
					onComplete && onComplete.run();
				}));
			})
		}
	}
}