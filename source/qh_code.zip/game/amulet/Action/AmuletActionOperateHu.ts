/**
* name 
*/
module amulet {
	export class AmuletActionOperateHu extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityOperate, onComplete?: Laya.Handler): void {
			if (this.desktopMgr.reachTarget) {
				this.desktopMgr.mainrole.DoDesktopPaiRon();
				AmuletDesktopMgr.timer.once(350, this, () => {
					this.desktopMgr.StopAction();
					uiscript.UI_AmuletHuPaiResult.Inst.show(data.result.hu_result, data.effected_hooks, true, Laya.Handler.create(this, () => {
						onComplete && onComplete.run();
						this.desktopMgr.ContinueAction(param);
					}));
				})
				return;
			}
			uiscript.UI_AmuletOperation.Inst.enable = false;
			this.desktopMgr.mainrole.can_discard = false;
			this.desktopMgr.mainprop.onHupai();
			this.desktopMgr.duringHuPai = true;
			//糊了
			const hookEffects: game.IAmuletEffectedHookData[] = data.effected_hooks || [];
			let replaceEffects = [];
			for (let i = 0; i < hookEffects.length; i++) {
				let effect: game.IAmuletEffectedHookData = hookEffects[i];
				if (effect.result.tile_replace && effect.result.tile_replace.length > 0) {
					replaceEffects.push({
						uid: effect.uid,
						id: effect.id,
						result: { tile_replace: effect.result.tile_replace }
					});
				}
				hookEffects[i].result.tile_replace = [];
			}
			// app.Log.log('replaceEffects' + JSON.stringify(replaceEffects));
			AmuletHookEffect.play(replaceEffects, Laya.Handler.create(this, () => {
				// app.Log.log('uiscript.UI_AmuletHuleshow.Inst.showZimo()');
				uiscript.UI_AmuletHuleshow.Inst.showZimo();
				AmuletDesktopMgr.timer.once(1200, this, () => {
					this.desktopMgr.StopAction();
					onComplete && onComplete.run();
					uiscript.UI_AmuletHuPaiResult.Inst.show(data.result.hu_result, hookEffects, false, Laya.Handler.create(this, () => {
						this.desktopMgr.ContinueAction(param);
					}));
				});
			}))
		}
	}
}