/**
* name 
*/
module amulet {
	export class AmuletActionOperateHuEnd extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			if (this.desktopMgr.reachTarget) {
				this.desktopMgr.mainrole.PutDownDesktopPai();
				AmuletDesktopMgr.timer.once(300, this, () => {
					onComplete && onComplete.run();
				});
				return;
			}
			let delay = 0;
			if (this.desktopMgr.mainrole.containerDesktopCards.pais.length > 0 && this.desktopMgr.mainrole.last_tile) {
				const tile = this.desktopMgr.mainrole.last_tile.val;
				this.desktopMgr.mainrole.onDiscardSuccess(tile, true);
				this.desktopMgr.mainrole.RemoveRecommend();
				delay = delay + 300;
			}
			AmuletDesktopMgr.timer.once(delay, this, () => {
				onComplete && onComplete.run();
			});
		}
	}
}