/**
* name 
*/
module amulet {
	export class AmuletActionPrepareRound extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IAmuletEventData, onComplete: Laya.Handler): void {
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				this.desktopMgr.refreshData(false);
				this.desktopMgr.mainrole.startExchangeHands();
				this.desktopMgr.ShowOperation(this.desktopMgr.amuletGameData.round.next_operation);
				onComplete && onComplete.run();
			}))
		}
	}
}