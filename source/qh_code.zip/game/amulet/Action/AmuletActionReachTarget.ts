/**
* name 
*/
module amulet {
	export class AmuletActionReachTarget extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			this.desktopMgr.reachTarget = true;
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}