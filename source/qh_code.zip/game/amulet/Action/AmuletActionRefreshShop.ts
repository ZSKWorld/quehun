/**
* name 
*/
module amulet {
	export class AmuletActionRefreshShop extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityBuy, onComplete?: Laya.Handler): void {
			uiscript.UI_AmuletShop.Inst.refresh(true);
			this.desktopMgr.refreshData();
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}