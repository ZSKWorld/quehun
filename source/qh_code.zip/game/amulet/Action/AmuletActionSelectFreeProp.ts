/**
* name 
*/
module amulet {
	export class AmuletActionSelectFreeProp extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivitySelectFreeEffect, onComplete?: Laya.Handler): void {
			uiscript.UI_AmuletProp.Inst.afterSelectPackage();
			this.desktopMgr.refreshData(false);
			AmuletDesktopMgr.timer.once(650, this, () => {
				this.desktopMgr.mainprop.addNewProp(amulet.PropCard.CreateProp(this.desktopMgr.amuletGameData.effect.effect_list[0]), true);
				onComplete && onComplete.run();
			});
			this.desktopUI.refreshState(EAmuletGameState.CheckBoss, false);
		}
	}
}