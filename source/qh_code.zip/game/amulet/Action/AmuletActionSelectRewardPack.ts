/**
* name 
*/
module amulet {
	export class AmuletActionSelectRewardPack extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivitySelectRewardPack, onComplete?: Laya.Handler): void {
			this.desktopUI.refreshPropCount();
			uiscript.UI_AmuletProp.Inst.afterSelectPackage();
			let delay = 150;
			if (param.id) {
				let selectResult = data.result.select_pack_result;
				if (selectResult.merge_type == 1) {
					let effect = this.desktopMgr.effectMap.get(selectResult.uid);
					let prop: PropCard;
					if (effect && effect.id == uiscript.UI_PropDetailCard.getPropUpgradeIdByPropId(param.id)) {
						prop = PropCard.CreateProp(effect);
					} else {
						prop = amulet.PropCard.CreateTempleteProp(selectResult.id, selectResult.badge, selectResult.uid);
					}
					// app.Log.log('升级合并')
					let oldEffect = this.desktopMgr.mainprop.isPropAlreadyHaveByUId(selectResult.uid);
					delay = oldEffect.volume != prop.volume ? 1500 : 1200;
					AmuletDesktopMgr.timer.once(650, this, () => {
						this.desktopMgr.mainprop.refreshPropByMerged(prop);
					});
				} else if (selectResult.merge_type == 2) {
					AmuletDesktopMgr.timer.once(650, this, () => {
						this.desktopMgr.mainprop.addNewProp(amulet.PropCard.CreateTempleteProp(param.id, selectResult.badge), true);
					});
					let mergedList = selectResult.merged_list || [];
					mergedList.push(-1);
					for (let i = 0; i < mergedList.length; i++) {
						AmuletDesktopMgr.timer.once(1200, this, () => {
							this.desktopMgr.mainprop.DoPropEffectById(mergedList[i], EPropEffectAniType.takeEffect);
						});
						AmuletDesktopMgr.timer.once(1600, this, () => {
							this.desktopMgr.mainprop.RemovePropById(mergedList[i], true);
						});
					}
					let effect = this.desktopMgr.effectMap.get(selectResult.uid);
					AmuletDesktopMgr.timer.once(2000, this, () => {
						this.desktopMgr.mainprop.addNewProp(amulet.PropCard.CreateProp(effect), true);
					});
					delay = 2100;
				} else if (selectResult.merge_type == 3) {
					let effect = this.desktopMgr.effectMap.get(selectResult.uid);
					if (effect) {
						let oldEffect = this.desktopMgr.mainprop.isPropAlreadyHaveByUId(selectResult.uid);
						delay = oldEffect.volume != effect.volume ? 1500 : 800;
						AmuletDesktopMgr.timer.once(650, this, () => {
							this.desktopMgr.mainprop.refreshPropByMerged(amulet.PropCard.CreateProp(effect), true);
						});
					}
				} else {
					let effect = this.desktopMgr.effectMap.get(selectResult.uid);
					if (effect) {
						AmuletDesktopMgr.timer.once(650, this, () => {
							this.desktopMgr.mainprop.addNewProp(amulet.PropCard.CreateProp(effect), true);
						});
						delay = 1200;
					}
				}
			}
			AmuletDesktopMgr.timer.once(delay, this, () => {
				AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
					if (this.desktopMgr.amuletGameData.stage == 7) {
						this.desktopUI.refreshState(EAmuletGameState.OpenRewardPackage, false);
					} else {
						this.desktopUI.refreshState(EAmuletGameState.DuringShop, false);
					}
					onComplete && onComplete.run();
				}));
			});
		}
	}
}