/**
* name 
*/
module amulet {
	export class AmuletActionSoldOutProp extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivitySellEffect, onComplete: Laya.Handler): void {
			uiscript.UI_AmuletProp.Inst.refreshBuyPopup();
			let haveCardEffect = false;
			let hookEffects = game.Tools.deepCopy(data.effected_hooks || []) as game.IAmuletEffectedHookData[];
			hookEffects.forEach((effect) => {
				if (effect.uid == param.id) {
					haveCardEffect = true;
					if (!effect.result.remove_effect) effect.result.remove_effect = [];
					effect.result.remove_effect.push(param.id);
					return;
				}
			})
			if (!haveCardEffect) {
				this.desktopMgr.mainprop.RemovePropById(param.id, true);
			}
			AmuletHookEffect.play(hookEffects, Laya.Handler.create(this, () => {
				this.desktopMgr.refreshData();
				AmuletDesktopMgr.timer.once(300, this, () => {
					this.desktopMgr.checkEffectOrder();
					onComplete && onComplete.run();
				});
			}))
			//卖出刷新商店的置灰
			if (uiscript.UI_AmuletShop.Inst.enable) uiscript.UI_AmuletShop.Inst.refreshCurrency();
		}
	}
}