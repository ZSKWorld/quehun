/**
* name 
*/
module amulet {
	export class AmuletActionSortProps extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityEffectSort, onComplete): void {
			this.desktopMgr.refreshData();
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}))
		}
	}
}