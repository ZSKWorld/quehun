/**
* name 
*/
module amulet {
	export class AmuletActionStartGame extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityStartGame, onComplete?: Laya.Handler): void {
			this.desktopMgr.refreshData(false);
			this.desktopMgr.resetAutoFunc();
			uiscript.UI_AmuletHome.Inst.hide();
			let freeEffects = data.result.new_game_result.effect.free_reward_candidates || [];
			if (freeEffects.length > 0) {
				AmuletDesktopMgr.timer.once(200, this, () => {
					uiscript.UI_AmuletProp.Inst.showSelectProp(freeEffects);
					onComplete && onComplete.run();
				});
			} else {
				onComplete && onComplete.run();
			}
		}
	}
}