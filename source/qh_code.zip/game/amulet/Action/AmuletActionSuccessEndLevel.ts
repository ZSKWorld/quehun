/**
* name 
*/
module amulet {
	export class AmuletActionSuccessEndLevel extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param, onComplete): void {
			let fakeData = game.Tools.deepCopy(data.effected_hooks || []) as game.IAmuletEffectedHookData[];  //造一份没有金币变化的假数据
			for (let i = 0; i < fakeData.length; i++) {
				let _data = fakeData[i];
				if (_data.result && _data.result.coin_modify && _data.result.coin_modify.modify != '0') {
					_data.result.coin_modify.modify = '0';
					_data.result.effect_growth = false;
				}
			}
			for (let i = 0; i < data.event_hooks.length; i++) {
				let removeEffect = data.event_hooks[i].remove_effect || [];
				fakeData.push({
					uid: null,
					id: null,
					result: { remove_effect: removeEffect } as game.IAmuletHookResult,
					type: null
				})
			}
			const nowLevelData = uiscript.UI_Activity_Amulet.amuletLevelDic.get(this.desktopMgr.nowLevel);
			if (nowLevelData && nowLevelData.next_level && nowLevelData.clear_mark) {
				this.desktopMgr.gameResultData = { level: this.desktopMgr.amuletGameData.game.level, reason: 3 };
			}
			// app.Log.log('data ====== upgrade_result' + JSON.stringify(fakeData));
			AmuletHookEffect.play(fakeData, Laya.Handler.create(this, () => {
				this.desktopMgr.checkEffectOrder(true);
				this.desktopMgr.onLevelWin();
				uiscript.UI_AmuletLevelResult.Inst.show(data, Laya.Handler.create(this, () => {
					if (nowLevelData && nowLevelData.next_level && nowLevelData.clear_mark) {
						uiscript.UI_AmuletLevelResult.Inst.hide();
						amulet.AmuletDesktopMgr.timer.once(100, this, () => {
							uiscript.UI_AmuletGameResult.Inst.show(Laya.Handler.create(this, () => {
								this.desktopMgr.ContinueAction(param);
							}));
						});
					} else {
						this.desktopMgr.ContinueAction(param);
					}
				}));
				this.desktopMgr.duringHuPai = false;
				//过关不需要打出胡的牌也不需要摸下一张牌
				onComplete && onComplete.run();
				this.desktopMgr.StopAction();
			}));
		}

	}
}