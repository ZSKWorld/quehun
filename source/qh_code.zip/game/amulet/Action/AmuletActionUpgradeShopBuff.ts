/**
* name 
*/
module amulet {
	export class AmuletActionUpgradeShopBuff extends AmuletActionBase {
		public static play(data: game.IAmuletEventData, param: game.IReqAmuletActivityUpgradeShopBuff, onComplete?: Laya.Handler): void {
			this.desktopMgr.refreshData();
			uiscript.UI_AmuletShop.Inst.refresh(false, false, param.id);
			AmuletHookEffect.play(data.effected_hooks, Laya.Handler.create(this, () => {
				onComplete && onComplete.run();
			}));
		}
	}
}