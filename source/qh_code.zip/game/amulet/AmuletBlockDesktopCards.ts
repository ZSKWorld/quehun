/**
* name 
*/
module amulet {
	export class BlockDesktopCards {
		public player: AmuletViewPlayer = null;
		public origin: Laya.Sprite3D = null;
		public pais: Array<AmuletPai3DPlane> = null;
		public unUsedPais: Array<AmuletPai3DPlane> = null;
		public openingPai: AmuletPai3DPlane;

		constructor(_origin: Laya.Sprite3D, player: AmuletViewPlayer) {
			this.origin = _origin;
			this.origin.active = false;
			this.pais = new Array<AmuletPai3DPlane>();
			this.unUsedPais = new Array<AmuletPai3DPlane>();
			this.player = player;
			this.openingPai = null;
		}

		public AddDesktopPai(val: amulet.MJPai, index: number, doAnim: boolean = true) {
			let p: AmuletPai3DPlane = this.unUsedPais.length > 0 ? this.unUsedPais.pop() : AmuletDesktopMgr.Inst.CreatePai3D().addComponent(AmuletPai3DPlane) as AmuletPai3DPlane;
			p.movement.clear();
			p.SetVal(val);
			p.OnChoosedPai();
			this.origin.parent.addChild(p.owner);
			p.owner.transform.localRotationEuler = val.id == -1 ? new Laya.Vector3(-90, 90, 90) : new Laya.Vector3(90, 90, 90);
			p.owner.transform.localPosition = this.origin.transform.localPosition.clone();
			p.owner.active = true;
			const { cx, cy } = this.getPaiPosByIndex(index);
			p.owner.transform.localPosition.x -= cx;
			p.owner.transform.localPosition.z += cy;
			//添加影子
			{
				let shadow: Laya.Sprite3D = p.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
				if (!shadow) {
					shadow = AmuletDesktopMgr.Inst.effect_shadow.clone();
					shadow.name = 'effect_shadow';
					p.effect_parent.addChild(shadow);
				}
				(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
				shadow.transform.localPosition = val.id == -1 ? new Laya.Vector3(0, 0, PAIMODEL_THICKNESS * 0.5) : new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
				shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
				shadow.transform.localRotationEuler = val.id == -1 ? new Laya.Vector3(-90, 0, 0) : new Laya.Vector3(90, 0, 0);
				shadow.active = true;
			}
			this.pais.push(p);
		}

		private getPaiPosByIndex(index: number) {
			let cx = 0;
			let cy = 0;
			if (index > 0) {
				cx = PAIMODEL_WIDTH * 1.05 * (index % 9);
				cy = PAIMODEL_HEIGHT * 1.05 * Math.floor(index / 9);
			}
			return { cx, cy };
		}

		RemoveLastPai() {
			let pai: AmuletPai3DPlane = this.pais[this.pais.length - 1];
			this.pais.splice(this.pais.length - 1, 1);
			this.unUsedPais.push(pai);
			pai.movement.clear();
			let movement = game.Movement.getMovement();
			movement.duration = 300;
			const localPos = pai.owner.transform.localPosition;
			movement.targetPosition = new Laya.Vector3(localPos.x, localPos.y - 0.04, localPos.z);
			movement.ease = Laya.Ease.backOut;

			let movement2 = game.Movement.getMovement();
			movement2.duration = 100;
			let handsCount = amulet.AmuletDesktopMgr.Inst.mainrole.hand.length;
			let posX = 0.59 - (13 - handsCount) * 0.043;
			movement2.targetPosition = new Laya.Vector3(posX, 0, -0.38);
			movement2.onEnd = Laya.Handler.create(this, () => {
				pai.owner.active = false;
			})
			pai.movement.addMovement(movement);
			pai.movement.addMovement(movement2);
			pai.movement.startMove();
		}

		/** 把所有打开的牌关上 */
		public CloseAllDesktopPai(doAnim: boolean = true) {
			if (!doAnim) {
				this.Clear();
				return;
			}
			for (let i = 0; i < this.pais.length; i++) {
				let pai = this.pais[i];
				if (pai.val.id != -1) {
					pai.val = amulet.MJPai.CreateEmpty();
					pai.movement.clear();
					let movement = game.Movement.getMovement();
					movement.duration = 133;
					const localPos = pai.owner.transform.localPosition;
					movement.targetEuler = new Laya.Vector3(-90, 90, 90);
					movement.targetPosition = new Laya.Vector3(localPos.x, localPos.y - 0.03, localPos.z);
					movement.ease = Laya.Ease.linearIn;
					//翻开的时候关闭影子（qinzhi说的）
					let shadow: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
					if (shadow) shadow.active = false;
					//立刻落下
					let movement2 = game.Movement.getMovement();
					movement2.duration = 100;
					movement2.targetPosition = new Laya.Vector3(localPos.x, localPos.y, localPos.z);
					//动画结束打开影子
					movement2.onEnd = Laya.Handler.create(this, () => {
						if (shadow) {
							shadow.transform.localPosition = new Laya.Vector3(0, 0, PAIMODEL_THICKNESS * 0.5);
							shadow.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);
							shadow.active = true;
						}
					});
					pai.movement.addMovement(movement);
					pai.movement.addMovement(movement2);
					pai.movement.startMove();
				}
			}
		}

		/** hookeffect专用的公开牌桌上的牌 */
		OpenDesktopPai(pos: number, tile: MJPai, doAnim: boolean = false) {
			let pai = this.pais[pos];
			if (!pai) return;
			pai.SetVal(tile);
			pai.OnChoosedPai();
			if (doAnim) {
				pai.movement.clear();
				let movement = game.Movement.getMovement();
				movement.duration = 133;
				const localPos = pai.owner.transform.localPosition;
				movement.targetEuler = new Laya.Vector3(90, 90, 90);
				movement.targetPosition = new Laya.Vector3(localPos.x, localPos.y - 0.03, localPos.z);
				movement.ease = Laya.Ease.linearIn;
				//翻开的时候关闭影子（qinzhi说的）
				let shadow: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
				if (shadow) shadow.active = false;
				//立刻落下
				let movement2 = game.Movement.getMovement();
				movement2.duration = 100;
				movement2.targetPosition = new Laya.Vector3(localPos.x, localPos.y, localPos.z);
				//动画结束打开影子
				movement2.onEnd = Laya.Handler.create(this, () => {
					if (shadow) {
						shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
						shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						shadow.active = true;
					}
				});
				pai.movement.addMovement(movement);
				pai.movement.addMovement(movement2);
				pai.movement.startMove();
			} else {
				pai.owner.transform.localRotationEuler = new Laya.Vector3(90, 90, 90);
				let shadow: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
				if (!shadow) {
					shadow = AmuletDesktopMgr.Inst.effect_shadow.clone();
					shadow.name = 'effect_shadow';
					pai.effect_parent.addChild(shadow);
				}
				(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
				shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
				shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
				shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
				shadow.active = true;
			}
		}

		OpenLastPai(tile: MJPai) {
			if (!this.pais || this.pais.length == 0) return;
			let pai: AmuletPai3DPlane = this.pais[this.pais.length - 1];
			this.pais.splice(this.pais.length - 1, 1);
			this.unUsedPais.push(pai);
			this.openingPai = pai;
			pai.SetVal(tile, true);
			pai.movement.clear();
			let movement = game.Movement.getMovement();
			movement.duration = 133;
			const localPos = pai.owner.transform.localPosition;
			movement.targetEuler = new Laya.Vector3(90, 90, 90);
			movement.targetPosition = new Laya.Vector3(localPos.x, localPos.y - 0.03, localPos.z);
			movement.ease = Laya.Ease.linearIn;
			//翻开的时候关闭影子（qinzhi说的）
			let shadow: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
			if (shadow) shadow.active = false;
			pai.movement.addMovement(movement);
			pai.movement.startMove();
			view.AudioMgr.PlayAudio(10153);
		}

		RefreshLockedTiles(lockTiles: number[]) {
			for (let i = 0; i < this.pais.length; i++) {
				this.pais[i].RefreshLock(lockTiles.indexOf(this.pais[i].val.id) >= 0);
			}
		}

		public desktopPaiRon() {
			let pai: AmuletPai3DPlane;
			if (this.openingPai) {
				pai = this.openingPai;
				// app.Log.log('这张牌胡了' + pai.val.toString());
			}
			if (pai && pai.movement) {
				view.AudioMgr.PlayAudio(10164);
				let hupai: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_hupai') as Laya.Sprite3D;
				if (!hupai) {
					hupai = AmuletDesktopMgr.Inst.effect_hupai.clone();
					hupai.name = 'effect_hupai';
					pai.effect_parent.addChild(hupai);
					hupai.transform.localPosition = new Laya.Vector3(0, 0, 0);
					hupai.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				}
				hupai.active = false;
				hupai.active = true;
			}
		}

		public paiMoveDown() {
			let pai: AmuletPai3DPlane;
			if (this.openingPai) {
				pai = this.openingPai;
			}
			if (pai) {
				// app.Log.log('放下了牌' + pai.val.toString());
				let movement = game.Movement.getMovement();
				movement.duration = 100;
				const localPos = pai.owner.transform.localPosition;
				movement.targetPosition = new Laya.Vector3(localPos.x, localPos.y + 0.03, localPos.z);
				//动画结束打开影子
				movement.onEnd = Laya.Handler.create(this, () => {
					let shadow: Laya.Sprite3D = pai.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D;
					if (shadow) {
						shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
						shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						shadow.active = true;
					}
				});
				pai.movement.addMovement(movement);
				if (!pai.movement.moving) {
					pai.movement.startMove();
				}
			}
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			this.openingPai = null;
			if (this.unUsedPais.length > 0) {
				for (let i: number = 0; i < this.unUsedPais.length; i++) {
					this.unUsedPais[i].owner.destroy(true);
				}
				this.unUsedPais = new Array<AmuletPai3DPlane>();
			}
			if (this.pais.length > 0) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].owner.destroy(true);
				}
				this.pais = new Array<AmuletPai3DPlane>();
			}
		}

		Clear() {
			this.openingPai = null;
			Laya.timer.clearAll(this);
			this.pais.forEach(paiPlane => {
				this.unUsedPais.push(paiPlane);
			});
			this.pais = [];
			this.unUsedPais.forEach(paiPlane => {
				paiPlane.clearMove();
				paiPlane.owner.active = false;
				if (paiPlane.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D) (paiPlane.effect_parent.getChildByName('effect_shadow') as Laya.Sprite3D).active = false;
				if (paiPlane.effect_parent.getChildByName('effect_hupai') as Laya.Sprite3D) (paiPlane.effect_parent.getChildByName('effect_hupai') as Laya.Sprite3D).active = false;
			});
		}

		public OnDoraRefresh(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshDora();
				}
			}
			if (this.unUsedPais != null) {
				for (let i: number = 0; i < this.unUsedPais.length; i++) {
					this.unUsedPais[i].RefreshDora();
				}
			}
		}

		public OnTianRefresh(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshTian();
				}
			}
			if (this.unUsedPais != null) {
				for (let i: number = 0; i < this.unUsedPais.length; i++) {
					this.unUsedPais[i].RefreshTian();
				}
			}
		}

		//目前弃用，往生说3D牌不需要变牌
		public OnPaiDisplayMapChanged(changeId: number[]) {
			for (let i: number = 0; i < this.pais.length; i++) {
				if (changeId.indexOf(this.pais[i].val.id) != -1) {
					this.pais[i].SetVal(amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(this.pais[i].val.id), false);
				}
			}
		}

		public OnChoosedPai(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].OnChoosedPai();
				}
			}
		}

	}
}