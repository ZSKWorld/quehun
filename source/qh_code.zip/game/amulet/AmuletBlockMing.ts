/**
* name 
*/
module amulet {

	export class AmuletBlockMing {
		public origin: Laya.Sprite3D = null;
		public player: AmuletViewPlayer = null;
		public xOffset: number = 0;
		public mings: Array<amulet.MJMing> = new Array<amulet.MJMing>();
		public pais: Array<AmuletPai3DPlane> = new Array<AmuletPai3DPlane>();
		public unUsedPais: Array<AmuletPai3DPlane> = new Array<AmuletPai3DPlane>();
		public hengs: Array<number> = new Array<number>(); // 每个副露横向那张牌的x值


		constructor(_origin: Laya.Sprite3D, player: AmuletViewPlayer) {
			this.origin = _origin;
			this.xOffset = 0;
			this.player = player;
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.pais.length > 0) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].owner.destroy();
				}
				this.pais = [];
			}
			if (this.unUsedPais.length > 0) {
				for (let i: number = 0; i < this.unUsedPais.length; i++) {
					this.unUsedPais[i].owner.destroy();
				}
				this.unUsedPais = [];
			}
			this.mings = [];
			this.hengs = [];
			this.xOffset = 0;
		}

		Clear() {
			Laya.timer.clearAll(this);
			this.pais.forEach(paiPlane => {
				paiPlane.clearMove();
				paiPlane.owner.active = false;
				this.unUsedPais.push(paiPlane);
			})
			this.pais = [];
			this.mings = [];
			this.hengs = [];
			this.xOffset = 0;
		}

		public AddMing(ming: amulet.MJMing, doanim: boolean = true): void {
			this.mings.push(ming);
			let _heng_x: number = 0;
			let lst: Array<AmuletPai3DPlane> = new Array<AmuletPai3DPlane>();
			for (let i = 0; i < ming.pais.length; i++) {
				let p: AmuletPai3DPlane = this.unUsedPais.length > 0 ? this.unUsedPais.pop() : AmuletDesktopMgr.Inst.CreatePai3D().addComponent(AmuletPai3DPlane) as AmuletPai3DPlane;
				p.owner.active = true;
				p.SetVal(ming.pais[i]);
				lst.push(p);
				this.pais.push(lst[i]);
				lst[i].OnChoosedPai();
				//添加影子
				{
					let shadow: Laya.Sprite3D = p.effect_parent.getChildByName('shadow') as Laya.Sprite3D;
					if (!shadow) {
						shadow = AmuletDesktopMgr.Inst.effect_shadow.clone();
						shadow.name = 'shadow';
						p.effect_parent.addChild(shadow);
					}
					(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
					shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
					shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
					shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
					shadow.active = true;
				}
			}
			let rightest_index: number = 0;
			let model_rate: number = 1.02;
			//暗杠
			rightest_index = 0;
			for (let i = 0; i < 4; i++) {
				let _index: number = i;
				let _p: AmuletPai3DPlane = lst[_index];
				// if (i == 1) {
				// 	app.Log.log('======= SetLastQiPai');
				// }
				this.origin.parent.addChild(_p.owner);
				_p.owner.transform.localPosition = this.origin.transform.localPosition.clone();
				if (i == 1 || i == 2) {
					// 中间2张
					this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
					_p.ShowUp();
					_p.owner.transform.localPosition.x -= this.xOffset;
					// _p.model.transform.localPosition.z -= (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5 * model_rate;
					_heng_x = this.xOffset;
					this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;

				} else {
					//外侧2张
					this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
					_p.owner.transform.localPosition.x -= this.xOffset;
					_p.ShowBack();
					this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
				}
			}
			this.hengs.push(_heng_x);
			//动画
			if (doanim) {
				let container: Laya.Sprite3D = new Laya.Sprite3D();
				this.origin.parent.addChild(container);
				container.transform.localPosition = lst[rightest_index].owner.transform.localPosition.clone();
				// container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
				// container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
				container.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				container.transform.localScale = new Laya.Vector3(1, 1, 1);
				let poss: Array<Laya.Vector3> = [];
				let p1: Laya.Vector3 = lst[rightest_index].owner.transform.localPosition.clone();

				for (let i: number = 0; i < lst.length; i++) {
					let p0 = lst[i].owner.transform.localPosition.clone();
					poss.push(new Laya.Vector3(p0.x - p1.x, p0.y - p1.y, p0.z - p1.z));
				}

				for (let i: number = 0; i < lst.length; i++) {
					container.addChild(lst[i].owner);
					lst[i].owner.transform.localPosition = poss[i].clone();
				}

				let pos = container.transform.position.clone();
				this.player.hand3d.transform.position = pos.clone();
				let node = this.player.hand3d.getChildAt(0).getChildByName('node_tile');
				node.addChild(container);
				container.transform.localPosition = new Laya.Vector3(0, 0, 0);
				container.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
				container.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);

				let anim = amulet.ModelAnimationController.get_anim_config('Fulu', this.player.hand_type);
				this.player.playHandAnimtion(anim);

				container.active = false;
				// app.Log.log('======= container.active = false');
				Laya.timer.once(anim.keypoint[0], this, () => {
					//关键帧0：牌倒在桌面上
					container.active = true;
					// app.Log.log('======= 关键帧0：牌倒在桌面上');
				});

				Laya.timer.once(anim.keypoint[1], this, () => {
					//关键帧1：牌脱离手
					// app.Log.log('======= 关键帧1：牌脱离手');
					try {
						this.origin.parent.addChild(container);
						container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						container.transform.position = pos;
						container.transform.localScale = new Laya.Vector3(1, 1, 1);
						for (let i: number = 0; i < lst.length; i++) {
							this.origin.parent.addChild(lst[i].owner);
							let pp: Laya.Vector3 = lst[i].owner.transform.localPosition.clone();
							pp.x += p1.x;
							pp.y += p1.y;
							pp.z += p1.z;
							lst[i].owner.transform.localPosition = pp;
						}
					} catch (e) {
						let _errorinfo: Object = {};
						_errorinfo['error'] = e.message;
						_errorinfo['stack'] = e.stack;
						_errorinfo['method'] = 'AddMing2';
						_errorinfo['ming'] = ming.toString();
						_errorinfo['class'] = 'Block_Ming';
						GameMgr.Inst.onFatalError(_errorinfo);
					}
				});

				Laya.timer.once(33, this, () => {
					try {
						if (container == null || container.destroyed) return;
						let name_effect_ming: string = 'scene/effect_mingpai_default.lh';
						let effect: game.EffectBase = new game.EffectBase(name_effect_ming);
						this.origin.parent.addChild(effect.root);
						effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
						effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
						effect.root.active = true;

						Laya.timer.frameLoop(1, effect, () => {
							if (container && !container.destroyed) {
								effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
								effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
							}
						});

						Laya.timer.once(1500, effect, () => {
							if (effect) {
								Laya.timer.clearAll(effect);
								effect.destroy();
							}
							if (container) container.destroy();
						});
					} catch (e) {
						let _errorinfo: Object = {};
						_errorinfo['error'] = e.message;
						_errorinfo['stack'] = e.stack;
						_errorinfo['method'] = 'AddMing4';
						_errorinfo['ming'] = ming.toString();
						_errorinfo['class'] = 'Block_Ming';
						GameMgr.Inst.onFatalError(_errorinfo);
					}
				});
			}
		}

		public OnDoraRefresh(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshDora();
				}
			}
		}

		public OnTianRefresh(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshTian();
				}
			}
		}

		public OnChoosedPai(): void {
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].OnChoosedPai();
				}
			}
		}

		//目前弃用，往生说3D牌不需要变牌
		public OnPaiDisplayMapChanged(changeId: number[]){
			for (let i: number = 0; i < this.pais.length; i++) {
				if(changeId.indexOf(this.pais[i].val.id) != -1){
					this.pais[i].SetVal(amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(this.pais[i].val.id), false)
				}
			}
		}
	}
}