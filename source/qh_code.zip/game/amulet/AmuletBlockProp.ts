/**
* name 
*/
module amulet {
	export const PropDisX1 = 0.092;
	export const PropDisX2 = 0.174;
	export const rightX = 0.504;
	export class BlockProp {
		public prop: AmuletViewProp = null;
		public parent: Laya.Sprite3D = null;
		public props: Array<AmuletPropPlane> = null;
		public unUsedProps: Array<AmuletPropPlane> = null;
		public dragProp: AmuletPropPlane;
		public lstIds: number[];

		constructor(parent: Laya.Sprite3D, prop: AmuletViewProp) {
			this.parent = parent;
			this.props = new Array<AmuletPropPlane>();
			this.unUsedProps = new Array<AmuletPropPlane>();
			this.prop = prop;
		}

		private getDisX(volume: number): number {
			if (volume && volume == 2) return PropDisX2;
			return PropDisX1;
		}

		public addNewProp(val: amulet.PropCard, doAnim: boolean = false) {
			let propPlane: AmuletPropPlane = this.unUsedProps.length > 0 ? this.unUsedProps.pop() : AmuletDesktopMgr.Inst.CreateProp3D().addComponent(AmuletPropPlane) as AmuletPropPlane;
			propPlane.owner.active = true;
			propPlane.transform.localPosition = new Laya.Vector3(rightX, 0.0067, -0.1);
			propPlane.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.parent.addChild(propPlane.owner);
			propPlane.setPropState(EAmuletEffectCardState.normal);
			propPlane.SetVal(val);
			propPlane.RefreshCard(!doAnim);
			propPlane.SetIndex(this.props.length);
			this.props.push(propPlane);
			propPlane.active = true;
			this.ReOrder(doAnim);
			if (doAnim) {
				propPlane.DoAmuletEffect(EPropEffectAniType.get);
			}
		}


		public onDragStart() {
			this.lstIds = [];
			for (let i: number = 0; i < this.props.length; i++) {
				this.lstIds.push(this.props[i].val.id);
			}
		}

		public onDragEnd() {
			this.ReOrder(true);
			let newlst = false;
			let newlstIds = [];
			for (let i: number = 0; i < this.props.length; i++) {
				newlstIds.push(this.props[i].val.id);
				if (this.lstIds[i] && this.lstIds[i] != this.props[i].val.id) {
					newlst = true;
				}
			}
			if (newlst) {
				const param: game.IReqAmuletActivityEffectSort = {
					activity_id: AmuletDesktopMgr.activityId,
					sorted_id: newlstIds
				}
				AmuletDesktopMgr.Inst.DoAmuletGameAction(EAmuletGameAction.SortProps, param);
			}
		}

		public onDragMove(propDrag: AmuletPropPlane) {
			let index: number = 0;
			let startX = rightX;
			for (let i = this.props.length - 1; i >= 0; i--) {
				startX -= this.getDisX(this.props[i].val.volume);
				if (propDrag.index < i) {
					if (propDrag.transform.localPosition.x + this.getDisX(propDrag.val.volume) * 0.5 > startX + this.getDisX(this.props[i].val.volume) * 0.5) {
						index = i;
						break;
					}
				}
				if (propDrag.index > i) {
					if (propDrag.transform.localPosition.x - this.getDisX(propDrag.val.volume) * 0.5 > startX + this.getDisX(this.props[i].val.volume) * 0.5) {
						index = i + 1;
						break;
					}
				}
			}
			if (index < 0) {
				index = 0;
			}
			if (index > this.props.length - 1) {
				index = this.props.length - 1;
			}
			if (propDrag.index == index) return;
			// app.Log.log('拖拽中的 index === ' + index)
			if (index < propDrag.index) {
				for (let i: number = index; i < propDrag.index; i++) {
					this.props[i].SetIndex(i + 1);
				}
				for (let i: number = propDrag.index; i > index; i--) {
					this.props[i] = this.props[i - 1];
					this.props[i].SetIndex(i);
				}
			} else {
				for (let i: number = propDrag.index; i < index; i++) {
					this.props[i] = this.props[i + 1];
					this.props[i].SetIndex(i);
				}
			}
			this.props[index] = propDrag;
			propDrag.SetIndex(index);
			this.ReOrder(true);
		}


		RemovePropById(id: number, doAnim: boolean = false) {
			let removeIndex = this.props.length - 1;
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.id == id) {
					removeIndex = i;
					// app.Log.log('RemovePropById index ===== ' + i);
					prop = this.props[i];
				}
				if (i > removeIndex) this.props[i].SetIndex(i - 1);
			}
			if (!prop) return;
			Laya.timer.clearAll(prop);
			prop.stopAnim();
			this.props.splice(removeIndex, 1);
			this.unUsedProps.push(prop);
			if (doAnim) {
				prop.DoAmuletEffect(EPropEffectAniType.sell);
				Laya.timer.once(300, prop, () => {
					prop.owner.active = false;
					this.ReOrder(doAnim);
				})
			} else {
				prop.owner.active = false;
				this.ReOrder(doAnim);
			}
		}

		DoPropEffectById(id: number, type: EPropEffectAniType) {
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.id == id) {
					// app.Log.log('DoPropEffectById index ===== ' + i);
					prop = this.props[i];
					break;
				}
			}
			if (prop) {
				Laya.timer.clearAll(prop);
				prop.stopAnim();
				prop.DoAmuletEffect(type);
			}
		}

		DoPropEffectByBadgeId(id: number, type: EPropEffectAniType) {
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.badge && this.props[i].val.badge.uid == id) {
					// app.Log.log('DoPropEffectByBadgeId index ===== ' + i);
					prop = this.props[i];
					break;
				}
			}
			if (prop) {
				Laya.timer.clearAll(prop);
				prop.stopAnim();
				prop.DoAmuletEffect(type);
			}
		}

		ReOrder(anim: boolean = false) {
			this.props.sort(AmuletPropPlane.Cmp);
			let startX = rightX;
			for (let i = this.props.length - 1; i >= 0; i--) {
				let prop = this.props[i];
				startX -= this.getDisX(prop.val.volume);
				if (prop.state != EAmuletEffectCardState.duringDrag) {
					prop.movement.clear();
					let movement = game.Movement.getMovement();
					movement.duration = 167;
					movement.targetPosition = new Laya.Vector3(startX + this.getDisX(prop.val.volume) * 0.5, 0.0067, -0.1);
					movement.ease = Laya.Ease.quadOut;
					prop.movement.addMovement(movement);
					if (anim) {
						prop.movement.startMove();
					} else {
						prop.movement.moveImmediately();
					}
				}
			}
		}

		ReOrderWithTrueData(anim: boolean = false) {
			this.props.sort((a, b) => {
				return this.lstIds.indexOf(a.val.id) - this.lstIds.indexOf(b.val.id);
			});
			let startX = rightX;
			for (let i = this.props.length - 1; i >= 0; i--) {
				let prop = this.props[i];
				startX -= this.getDisX(prop.val.volume);
				prop.SetIndex(i);
				prop.movement.clear();
				let movement = game.Movement.getMovement();
				movement.duration = 167;
				movement.targetPosition = new Laya.Vector3(startX + this.getDisX(prop.val.volume) * 0.5, 0.0067, -0.1);
				movement.ease = Laya.Ease.quadOut;
				prop.movement.addMovement(movement);
				if (anim) {
					prop.movement.startMove();
				} else {
					prop.movement.moveImmediately();
				}
			}
		}


		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.props.length > 0) {
				for (let i: number = 0; i < this.props.length; i++) {
					Laya.timer.clearAll(this.props[i]);
					this.props[i].owner.destroy(true);
				}
				this.props = new Array<AmuletPropPlane>();
			}
			if (this.unUsedProps.length > 0) {
				for (let i: number = 0; i < this.unUsedProps.length; i++) {
					Laya.timer.clearAll(this.unUsedProps[i]);
					this.unUsedProps[i].owner.destroy(true);
				}
				this.unUsedProps = new Array<AmuletPropPlane>();
			}
		}

		public Clear() {
			Laya.timer.clearAll(this);
			this.props.forEach(propPlane => {
				Laya.timer.clearAll(propPlane);
				propPlane.clearMove();
				propPlane.owner.active = false;
				this.unUsedProps.push(propPlane);
			})
			this.props = [];
		}

		/** 护身符合并 新卡掉落在旧卡位置上 */
		refreshPropByMerged(val: amulet.PropCard, doAnim: boolean = true) {
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.id == val.id) {
					// app.Log.log('refreshPropByMerged index ===== ' + i);
					prop = this.props[i];
					break;
				}
			}
			if (prop) {
				Laya.timer.clearAll(prop);
				prop.stopAnim();
				if (doAnim) {
					let effectName2;
					let delayReOrder = 0;
					if (prop.val.volume < val.volume) {
						delayReOrder = 200;
						effectName2 = EPropEffectAniType.changeBig;
					}
					if (prop.val.volume > val.volume) {
						delayReOrder = 500
						effectName2 = EPropEffectAniType.propMergeChangeSmall;
					}
					prop.RefreshAniCard(val);
					prop.DoAmuletEffect(EPropEffectAniType.levelUp);
					prop.SetVal(val);
					Laya.timer.once(300, prop, () => {
						prop.RefreshCard(false);
						Laya.timer.once(200, prop, () => {
							if (effectName2) {
								prop.stopAnim();
								prop.DoAmuletEffect(effectName2);
								Laya.timer.once(delayReOrder, prop, () => {
									this.ReOrder(true);
								});
							} else {
								this.ReOrder(true);
							}
						});
					});
				} else {
					prop.SetVal(val);
					prop.RefreshCard();
					this.ReOrder(false);
				}
			}
		}

		/** 刷新护身符印章 add，remove）*/
		refreshPropBadge(val: amulet.PropCard, doAnim: boolean = true) {
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.id == val.id) {
					prop = this.props[i];
					// app.Log.log('refreshPropBadge index ===== ' + i);
					break;
				}
			}
			if (prop) {
				Laya.timer.clearAll(prop);
				prop.stopAnim();
				if (doAnim) {
					let delay = 0;
					let effectName = val.badge ? EPropEffectAniType.getBadge : EPropEffectAniType.loseBadge;
					if (prop.val.volume < val.volume) {
						// app.Log.log('变大了');
						delay = 200;
						effectName = EPropEffectAniType.changeBig;
					}
					if (prop.val.volume > val.volume) {
						// app.Log.log('变小了');
						delay = 500;
						effectName = val.badge ? EPropEffectAniType.changeBadgeChangeSmall : EPropEffectAniType.loseBagdeChangeSmall;
					}
					prop.SetVal(val);
					if (effectName != EPropEffectAniType.loseBadge && effectName != EPropEffectAniType.loseBagdeChangeSmall) prop.RefreshCard(false);
					// app.Log.log('刷新护身符2222222222222222222222');
					app.Log.log('effectName ====== ' + effectName);
					prop.DoAmuletEffect(effectName);
					Laya.timer.once(delay, prop, () => {
						this.ReOrder(true);
					})
				} else {
					prop.SetVal(val);
					prop.RefreshCard();
					this.ReOrder(false);
				}
			}
		}


		refreshPropUnstable(val: amulet.PropCard, doAnim: boolean = true) {
			let prop: AmuletPropPlane;
			for (let i: number = 0; i < this.props.length; i++) {
				if (this.props[i].val.id == val.id) {
					// app.Log.log('refreshPrropUnstable index ===== ' + i);
					prop = this.props[i];
					break;
				}
			}
			if (prop) {
				Laya.timer.clearAll(prop);
				prop.stopAnim();
				if (doAnim) {
					prop.SetVal(val);
					prop.DoAmuletEffect(EPropEffectAniType.unstable);
					Laya.timer.once(1000, prop, () => {
						prop.RefreshCard(false);
					})
				} else {
					prop.SetVal(val);
					prop.RefreshCard();
					this.ReOrder(false);
				}
			}
		}

	}
}