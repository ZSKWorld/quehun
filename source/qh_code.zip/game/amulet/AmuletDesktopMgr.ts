/**
* name 
*/
module amulet {
	//游戏状态
	const AmuletDataKey = ['round', 'effect', 'game', 'shop', 'record']
	export enum EAmuletGameState {
		DuringFight, //战斗
		DuringShop, //商店
		CheckBoss,
		OpenRewardPackage,
	}
	//操作类型
	export enum EAmuletGameAction {
		StartGame,
		ContinueGame,
		NextLevel,
		SortProps,
		SoldOutProp,
		DoOperation,
		BuyFromShop,
		EndShopping,
		SelectFreeProp,
		RefreshShop,
		SelectPack,
		UpgradeShopBuff,
		SelectRewardPack,
	}
	//事件类型
	export enum EAmuletEventType {
		None,
		StartGame,
		SelectFreeProp,
		PrepareRound,
		ChangeHands,
		EndChangeHands,
		DealTile,
		DiscardTile,
		Hule,
		Gang,
		ReachTarget,
		SuccessEndLevel,
		PrepareShopping,
		BuyFromShop,
		SelectPack,
		LevelPackReward,
		SelectRewardPack,
		SoldOutProp,
		RefreshShop,
		UpgradeLevel,
		SortProps,
		UpgradeShopBuff,
		EndShopping,
		CreateRound,
		PrepareHu,
		HuEnd,
		GameEnd = 100,
	}
	export interface IAmuletGameResult {
		/** 1➡NotReachTarget，2➡NoNextLevel，3➡5-3 */
		reason: number;
		level: number;
	}

	export const maxDesktopCount: number = 36;
	export const PAIMODEL_HEIGHT: number = 0.0455 * 0.95 * 0.94;
	export const PAIMODEL_WIDTH: number = 0.0345 * 0.95 * 0.94;
	export const PAIMODEL_THICKNESS: number = 0.0235 * 0.95 * 0.94;
	export const PAI_COUNT: number = 136;
	export const uiYellowFilter: Array<number> = [1, 0, 0, 0, 0,
		0, 0.917, 0, 0, 0,
		0, 0, 0.663, 0, 0,
		0, 0, 0, 1, 0];
	export const BAIDA_COUNT: number = 13;


	export class AmuletDesktopMgr extends Laya.Script {
		public static Inst: AmuletDesktopMgr = null;
		public static activityId: number = 250811;

		static _timer: Laya.Timer;
		static get timer(): Laya.Timer { return this._timer ? this._timer : (this._timer = new Laya.Timer()); }

		public active: boolean = false;

		public mainCamera: Laya.Camera; //主摄像机
		public desktop3D: Laya.Sprite3D; //整个牌桌的资源
		public mainrole: AmuletViewPlayer = null; //自己控制的角色
		public mainprop: AmuletViewProp = null; //道具卡的控制

		public trans_container_effect: Laya.Sprite3D = null;
		public effect_dora3D: Laya.Sprite3D = null; //在3d模型上的dora特效
		public effectLock: Laya.Sprite3D = null; //在3d模型上的锁链
		public effect_doraPlane: Laya.Sprite3D = null; //在面片上的dora特效
		public effect_shadow: Laya.Sprite3D = null; //在模型下的影子
		public effect_hupai: Laya.Sprite3D = null; //在模型上方的胡牌特效
		public effect_recommend: Laya.Sprite3D = null; //在面片下的推荐
		public effect_huanpai: Laya.Sprite3D = null; //在面片下的推荐

		public player_effects: Object; //key: game.EView, value: item_id
		public mjp_res_name: string = '';
		public mjpb_res_name: string = '';
		public choosedReplacePaiIds: number[] = [];
		public choosedPropId: number[];
		private requestMap: Object = null;
		private actionEventMap: Object = null;

		public locking: boolean;
		public paiMap: Object = {};
		public paiTempMap: Object = {};
		public paiLibrary: Object = {};
		public paiScoreLibrary: Object = {};

		public amuletGameData: game.IAmuletGameData = null;
		public doras: Array<amulet.MJPai> = []; //外朵拉
		public tians: Array<amulet.MJPai> = []; //天牌
		public choosedPai: amulet.MJPai = null;
		public gameState: EAmuletGameState;
		public usedIds: number[] = [];
		public gameResultData: IAmuletGameResult; //存游戏结束、5-3关卡展示的数据
		public remainRoundsData: game.IAmuletEventData[][]; //存余牌翻开数据
		public effectMap: basic.Dictionary<number, game.IAmuletEffectData>;
		public badgeMap: basic.Dictionary<number, game.IAmuletEffectData>;

		public reachTarget: boolean = false;
		public duringHuPai: boolean;
		public duringPropEffect: boolean;
		public autoMoqie: boolean = false; //自动模切
		public autoHule: boolean = false; //自动胡了
		public autoLiqi: boolean = true; //自动理牌
		public isOperateHu: boolean = false;
		public isOperateGang: boolean = false;
		private audioId: number;
		private bgmId: number;

		private timerScore: Laya.Timer;
		private scoreAnimList: game.IAmuletTileScore[] = [];
		private duringScoreAnim: boolean;
		private duringSingleScoreAnim: boolean;
		private eventList: game.IAmuletEventData[] = [];
		private actionRunning: boolean = false; //正在执行action，执行完了才能执行下一个
		private actionIndex: number = 0;
		private actionStopped: boolean = false;
		public originRoundData: game.IAmuletGameData;

		constructor() {
			super();
			this.timerScore = new Laya.Timer();
			AmuletDesktopMgr.Inst = this;
			this.requestMap = {};
			this.requestMap = {
				[EAmuletGameAction.StartGame]: game.ERequest.amuletActivityStartGame,
				[EAmuletGameAction.DoOperation]: game.ERequest.amuletActivityOperate,
				[EAmuletGameAction.EndShopping]: game.ERequest.amuletActivityEndShopping,
				[EAmuletGameAction.BuyFromShop]: game.ERequest.amuletActivityBuy,
				[EAmuletGameAction.SortProps]: game.ERequest.amuletActivityEffectSort,
				[EAmuletGameAction.SoldOutProp]: game.ERequest.amuletActivitySellEffect,
				[EAmuletGameAction.RefreshShop]: game.ERequest.amuletActivityRefreshShop,
				[EAmuletGameAction.SelectFreeProp]: game.ERequest.amuletActivitySelectFreeEffect,
				[EAmuletGameAction.SelectPack]: game.ERequest.amuletActivitySelectPack,
				[EAmuletGameAction.UpgradeShopBuff]: game.ERequest.amuletActivityUpgradeShopBuff,
				[EAmuletGameAction.SelectRewardPack]: game.ERequest.amuletActivitySelectRewardPack,
				[EAmuletGameAction.NextLevel]: game.ERequest.amuletActivityUpgrade,
			};
			this.actionEventMap = {
				[EAmuletEventType.StartGame]: amulet.AmuletActionStartGame,
				[EAmuletEventType.SelectFreeProp]: amulet.AmuletActionSelectFreeProp,
				[EAmuletEventType.CreateRound]: amulet.AmuletActionCreateRound,
				[EAmuletEventType.PrepareRound]: amulet.AmuletActionPrepareRound,
				[EAmuletEventType.ChangeHands]: amulet.AmuletActionOperateExchange,
				[EAmuletEventType.EndChangeHands]: amulet.AmuletActionOperateEndExchange,
				[EAmuletEventType.DealTile]: amulet.AmuletActionOperateDealTile,
				[EAmuletEventType.DiscardTile]: amulet.AmuletActionOperateDiscardTile,
				[EAmuletEventType.Hule]: amulet.AmuletActionOperateHu,
				[EAmuletEventType.Gang]: amulet.AmuletActionOperateGang,
				[EAmuletEventType.ReachTarget]: amulet.AmuletActionReachTarget,
				[EAmuletEventType.SuccessEndLevel]: amulet.AmuletActionSuccessEndLevel,
				[EAmuletEventType.PrepareShopping]: amulet.AmuletActionEnterShop,
				[EAmuletEventType.BuyFromShop]: amulet.AmuletActionBuyFromShop,
				[EAmuletEventType.SelectPack]: amulet.AmuletActionSelectPack,
				[EAmuletEventType.LevelPackReward]: amulet.AmuletActionOpenRewardPackage,
				[EAmuletEventType.SelectRewardPack]: amulet.AmuletActionSelectRewardPack,
				[EAmuletEventType.SoldOutProp]: amulet.AmuletActionSoldOutProp,
				[EAmuletEventType.RefreshShop]: amulet.AmuletActionRefreshShop,
				[EAmuletEventType.SortProps]: amulet.AmuletActionSortProps,
				[EAmuletEventType.UpgradeShopBuff]: amulet.AmuletActionUpgradeShopBuff,
				[EAmuletEventType.EndShopping]: amulet.AmuletActionEndingShop,
				[EAmuletEventType.HuEnd]: amulet.AmuletActionOperateHuEnd,
				[EAmuletEventType.GameEnd]: amulet.AmuletActionGameEnd,
			}
			ModelAnimationController.init_data();
			app.NetAgent.addListener2Lobby('NotifyActivityChange', Laya.Handler.create(this, (msg) => {
				if (game.Scene_Amulet.Inst && game.Scene_Amulet.Inst.active) {
					if (msg.end_activities) {
						for (let i: number = 0; i < msg.end_activities.length; i++) {
							let id = msg.end_activities[i];
							if (id == AmuletDesktopMgr.activityId) {
								uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
									game.Scene_Amulet.Inst.GameEnd();
								}))
								return;
							}
						}
					}
				}
			}));
		}

		get changeTileCount(): number {
			if (!this.amuletGameData || !this.amuletGameData.round) return 0;
			let totalCount = this.amuletGameData.round.total_change_tile_count || 0;
			let usedCount = this.amuletGameData.round.change_tile_count || 0;
			return totalCount - usedCount;
		}

		get nowLevel(): number {
			if (this.amuletGameData.stage == 6) {
				if (!this.amuletGameData.game || !this.amuletGameData.game.level) {
					return 101;
				}
				return uiscript.UI_Activity_Amulet.amuletLevelDic.get(this.amuletGameData.game.level).next_level;
			} else {
				return this.amuletGameData.game.level || 0;
			}
		}

		/** 获取当前所有护身符体积 */
		public getNowPropVolume(effects?: game.IAmuletEffectData[]): number {
			let volume = 0;
			if (!effects) {
				effects = this.amuletGameData.effect.effect_list || [];
			}
			for (let i = 0; i < effects.length; i++) {
				volume += effects[i].volume;
			}
			return volume;
		}

		public get maxPropVolume(): number { return this.amuletGameData.effect.max_effect_volume || 0; }

		public getBossId(level?: number): number {
			level = level || this.nowLevel;
			let levelConfig = uiscript.UI_Activity_Amulet.amuletLevelDic.get(level);
			if (levelConfig && levelConfig.boss) {
				let bossId = 0;
				//下一个boss关卡的buff列表，当前关如果是boss关的话需要读 boss_buff_id
				if (level == this.amuletGameData.game.level) {
					if (this.amuletGameData.game && this.amuletGameData.game.boss_buff && this.amuletGameData.game.boss_buff[0]) {
						bossId = this.amuletGameData.game.boss_buff[0];
					}
				} else {
					if (this.amuletGameData.game.next_boss_buff && this.amuletGameData.game.next_boss_buff[0]) {
						bossId = this.amuletGameData.game.next_boss_buff[0];
					}
				}
				return bossId;
			}
			return 0;
		}

		//bossbuff的处理(目标分数)
		public getTargetScore(level?: number): uiscript.SciNum {
			level = level || this.nowLevel;
			let levelConfig = uiscript.UI_Activity_Amulet.amuletLevelDic.get(level);
			let score: uiscript.SciNum = uiscript.SciNum.createSciNumByStr(levelConfig.target_point);
			if (this.getBossId(level) && this.getBossId(level) == 903) {
				let bossBuff = uiscript.SciNum.createSciNumByStr(cfg.amulet.amulet_buff.get(this.getBossId(level)).args[0].toString());
				return (score.multiply(bossBuff));
			};
			return score;
		}

		//bossbuff的处理(目标分数)
		public getTargetScoreStr(level?: number): string {
			let score = this.getTargetScore(level);
			return uiscript.SciNum.getSciStr(score.toString(), 6);
		}

		public get maxChooseCount(): number {
			let operation = this.amuletGameData.round.next_operation.find((operation) => operation.type == EAmuletPlayOperation.exchange);
			if (operation) {
				if (!operation.value) return 13;
				return operation.value;
			}
			if (this.getBossId() && this.getBossId() == 901) return cfg.amulet.amulet_buff.get(901).args[0];
			return 13;
		}

		public get banedIds(): number[] {
			let ids = [];
			if (this.getBossId() && this.getBossId() == 911) { //该boss已经屏蔽
				const bossData = this.amuletGameData.effect.buff_list;
				for (let i = 0; i < bossData.length; i++) {
					if (bossData[i].id == 911 && bossData[i].store && bossData[i].store[0]) {
						ids.push(bossData[i].store[0]);
						break;
					}
				}
			}
			return ids;
		}

		public isDoraBaned(pai: MJPai) {
			// if (this.getBossId()) { //前端不处理bossbuff对宝牌魂牌的影响，仅胡牌时影响分数
			// 	if (this.getBossId() == 904) {
			// 		if (pai.type == E_MJPai.m) return true;
			// 	}
			// 	if (this.getBossId() == 905) {
			// 		if (pai.type == E_MJPai.p) return true;
			// 	}
			// 	if (this.getBossId() == 906) {
			// 		if (pai.type == E_MJPai.s) return true;
			// 	}
			// }
			return false;
		}

		getDisplayMJPaiById(id: number, useReplaced: boolean = true): MJPai {
			if (this.paiTempMap[id] && useReplaced) return this.paiTempMap[id].Clone();
			if (this.paiMap[id]) return this.paiMap[id].Clone();
			return null;
		}

		getTileScore(tile: string): string {
			let _tile = tile;
			if (tile.charAt(0) == '0') {
				_tile = '5' + tile.charAt(1);
			}
			if (this.paiScoreLibrary[_tile]) return this.paiScoreLibrary[_tile];
			return '0';
		}

		// 全量更新数据，初始化牌库
		InitGameData(msg: game.IAmuletGameData) {
			this.amuletGameData = {
				round: {}, effect: {}, game: {}, stage: 0, shop: {}, record: {}, ended: false
			} as game.IAmuletGameData;
			if (msg) {
				for (let key in msg) {
					const value = msg[key];
					const valueType = typeof value;
					if (valueType != 'function') {
						this.amuletGameData[key] = game.Tools.deepCopy(msg[key]);
					}
				}
			}
			this.InitRoundData();
			this.RefreshEffectMap();
		}

		InitRoundData() {
			if (this.amuletGameData && this.amuletGameData.round.pool && this.amuletGameData.round.pool.length > 0) {
				this.paiMap = {};
				this.paiLibrary = {};
				this.usedIds = [];
				let pool = this.amuletGameData.round.pool;
				pool.forEach((tile) => {
					let mjPai = amulet.MJPai.Create(tile);
					this.paiMap[tile.id] = mjPai;
					if (!this.paiLibrary[tile.tile]) {
						this.paiLibrary[tile.tile] = 1;
					} else {
						this.paiLibrary[tile.tile]++;
					}
				})
			}
			this.paiScoreLibrary = {};
			if (this.amuletGameData.game && this.amuletGameData.game.tile_score_map && this.amuletGameData.game.tile_score_map.length > 0) {
				for (let i = 0; i < this.amuletGameData.game.tile_score_map.length; i++) {
					let tileData = this.amuletGameData.game.tile_score_map[i];
					this.paiScoreLibrary[tileData.tile] = tileData.score || '0';
				}
			}
			this.doras = [];
			this.tians = [];
			this.RefreshTileReplace(true);
			this.RefreshPaiLibrary();
		}

		// 处理换牌信息
		RefreshTileReplace(refresh: boolean = false) {
			let tile_replace = [];
			if (this.amuletGameData.round && this.amuletGameData.round.tile_replace) {
				tile_replace = this.amuletGameData.round.tile_replace;
			}
			this.paiTempMap = {};
			let changedIds = [];
			tile_replace.forEach(tile => {
				let mjPai = amulet.MJPai.Create(tile);
				this.paiTempMap[tile.id] = mjPai;
				changedIds.push(tile.id);
			});
			if (refresh) {
				this.onDisplayPaiMapChanged(changedIds);
			}
		}


		// 处理牌库 余牌信息和牌的分数信息
		RefreshPaiLibrary() {
			let CheckUsedIds = (ids: number[]) => {
				if (!ids || ids.length == 0) return;
				for (let i = 0; i < ids.length; i++) {
					let id = ids[i];
					//算过的就不要算啦
					if (this.usedIds.indexOf(id) == -1) {
						this.usedIds.push(id);
						let mjp = this.getDisplayMJPaiById(id, false);
						if (mjp) this.paiLibrary[mjp.toString()]--;
					}
				}
			}
			if (this.amuletGameData.round) {
				CheckUsedIds(this.amuletGameData.round.used);
				CheckUsedIds(this.amuletGameData.round.used_desktop);
				CheckUsedIds(this.amuletGameData.round.hands);
				CheckUsedIds(this.amuletGameData.round.locked_tile);
			}
			let doraIds = [];
			if (this.doras) {
				doraIds = this.doras.map(dora => dora.id);
			}
			CheckUsedIds(doraIds);
			let mingIds = [];
			if (this.amuletGameData.round && this.amuletGameData.round.ming) {
				this.amuletGameData.round.ming.forEach(ming => {
					ming.tile_list.forEach(tile => mingIds.push(tile));
				});
			}
			CheckUsedIds(mingIds);
		}

		RefreshEffectMap() {
			this.effectMap = new basic.Dictionary();
			this.badgeMap = new basic.Dictionary();
			if (!this.amuletGameData.effect.effect_list) return;
			for (let i = 0; i < this.amuletGameData.effect.effect_list.length; i++) {
				let effect = this.amuletGameData.effect.effect_list[i];
				this.effectMap.set(effect.uid, effect);
				if (effect.badge) {
					this.badgeMap.set(effect.badge.uid, effect);
				}
			}
		}

		// 刷新表现
		refreshData(doAnim: boolean = true, data?: game.IAmuletGameData) {
			if (!data) data = this.amuletGameData;
			uiscript.UI_AmuletDesktopInfo.Inst.refreshCurrency(uiscript.SciNum.createSciNumByStr(data.game.coin || '0'), doAnim);
			uiscript.UI_AmuletDesktopInfo.Inst.refreshBossBlood(uiscript.SciNum.createSciNumByStr(data.round.point || '0'));
			uiscript.UI_AmuletDesktopInfo.Inst.refreshLeftPai(data.round.desktop_remain || 0);
			uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount(data.effect.effect_list || []);
			this.WhenTianPai(data.round.tian_dora || [], !doAnim);
			this.WhenDoras(data.round.dora || [], !doAnim);
		}

		//更新非全量数据, 如有护身符生效，由护身符刷新当前表现，否则直接刷新表现
		UpdateGameData(msg: game.IResAmuletEventResponse) {
			if (msg.events) {
				for (let i = 0; i < msg.events.length; i++) {
					if (msg.events[i].type == EAmuletEventType.StartGame) {
						this.InitGameData(msg.events[i].result.new_game_result);
					} else if (msg.events[i].type == EAmuletEventType.GameEnd) {
						this.amuletGameData.ended = msg.events[i].value_changes.ended;
					} else if (msg.events[i].type == EAmuletEventType.CreateRound) {
						this._updateDirtyData(msg.events[i].value_changes);
						this.originRoundData = game.Tools.deepCopy(this.amuletGameData);
					} else if (msg.events[i].type == EAmuletEventType.PrepareRound) {
						this._updateDirtyData(msg.events[i].value_changes);
						this.InitRoundData();
					} else {
						this._updateDirtyData(msg.events[i].value_changes);
					}
				}
			}
			this.paiScoreLibrary = {};
			if (this.amuletGameData.game.tile_score_map && this.amuletGameData.game.tile_score_map.length > 0) {
				for (let i = 0; i < this.amuletGameData.game.tile_score_map.length; i++) {
					let tileData = this.amuletGameData.game.tile_score_map[i];
					this.paiScoreLibrary[tileData.tile] = tileData.score || '0';
				}
			}
			this.RefreshTileReplace();
			this.RefreshPaiLibrary();
			this.RefreshEffectMap();
		}

		_updateDirtyData(msg: game.IAmuletValueChanges) {
			for (let key in msg) {
				const value = msg[key];
				if (AmuletDataKey.indexOf(key) >= 0) {
					for (let _key in value) {
						if (value[_key] && value[_key].dirty) {
							this.amuletGameData[key][_key] = game.Tools.deepCopy(value[_key].value);
						}
					}
				} else if (key == 'stage') {
					this.amuletGameData.stage = msg.stage || 0;
				}
			}
		}

		GiveUpGame(param?: any, onComplete?: Laya.Handler) {
			if (this.locking) return;
			this.locking = true;
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivityGiveup, param, (err, res: game.IResAmuletEventResponse) => {
				if (err || res['error']) {
					this.onAmuletGameError(game.ERequest.amuletActivityGiveup, err, res);
				} else {
					this.InitGameData(null);
				}
				this.locking = false;
				onComplete && onComplete.run();
			});
		}

		InitGame() {
			uiscript.UI_AmuletHome.Inst.hide();
			this.resetAutoFunc();
			this.refreshData(false);
			const stageState = this.amuletGameData.stage;
			if (stageState == 1) {
				uiscript.UI_AmuletProp.Inst.showSelectProp(this.amuletGameData.effect.free_reward_candidates);
			} else if (stageState == 7) {
				uiscript.UI_AmuletDesktopInfo.Inst.refreshState(EAmuletGameState.OpenRewardPackage, true);
			} else if (stageState == 4 || stageState == 5) {
				uiscript.UI_AmuletDesktopInfo.Inst.refreshState(EAmuletGameState.DuringShop, true);
			} else if (stageState == 2 || stageState == 3) {
				uiscript.UI_AmuletDesktopInfo.Inst.refreshState(EAmuletGameState.DuringFight, true);
				const hands = this.amuletGameData.round.hands;
				let handCards: Array<amulet.MJPai> = [];
				let maxHandsCount = stageState == 3 ? hands.length - 1 : hands.length;
				for (let i: number = 0; i < maxHandsCount; i++) {
					let id = hands[i];
					handCards.push(this.getDisplayMJPaiById(id));
				}
				this.mainrole.NewGame(handCards, [], [], true);
				if (stageState == 2) {
					this.mainrole.startExchangeHands();
				} else if (stageState == 3) {
					this.mainrole.startExchangeHands();
					this.mainrole.InitGangList(this.amuletGameData.round.ming);
					this.mainrole.endExchangeHands();
				}
				//要显示最后摸到的那张
				if (stageState == 3) this.mainrole.TakePai(this.getDisplayMJPaiById(hands[hands.length - 1]), false, false);
				const remainCardCount = this.amuletGameData.round.desktop_remain || 0;
				const remainCards = this.amuletGameData.round.show_desktop_tiles || [];
				const lockedTiles = this.amuletGameData.round.locked_tile || [];
				let desktopCards: Array<amulet.MJPai> = [];
				for (let i: number = 0; i < lockedTiles.length + remainCardCount; i++) {
					desktopCards.push(amulet.MJPai.CreateEmpty());
				}
				remainCards.forEach((value) => {
					if (value.pos < remainCardCount + lockedTiles.length) {
						desktopCards[value.pos] = this.getDisplayMJPaiById(value.id);
					}
				});
				this.mainrole.InitDesktopPais(desktopCards, lockedTiles, false);
				this.ShowOperation(this.amuletGameData.round.next_operation);
				uiscript.UI_AmuletTingPai.Inst.setData(this.amuletGameData.round.ting_list);
			} else if (stageState == 6) {
				uiscript.UI_AmuletDesktopInfo.Inst.refreshState(EAmuletGameState.CheckBoss, true);
			}
			if (this.amuletGameData.effect.effect_list && this.amuletGameData.effect.effect_list.length > 0) {
				this.mainprop.containerProp.Reset();
				this.amuletGameData.effect.effect_list.forEach((effect) => {
					this.mainprop.addNewProp(amulet.PropCard.CreateProp(effect), false);
				})
			}
		}

		// 发协议
		DoAmuletGameAction(action: EAmuletGameAction, param?: any) {
			if (this.locking) return;
			this.locking = true;
			uiscript.UI_Activity_Amulet.needFetch = true;
			app.Log.log(this.requestMap[action] + '  param === ' + JSON.stringify(param));
			app.NetAgent.sendReq2Lobby('Lobby', this.requestMap[action], param, (err, res: game.IResAmuletEventResponse) => {
				this.locking = false;
				if (err || res['error']) {
					this.onAmuletGameError(this.requestMap[action], err, res);
				} else {
					app.Log.log(this.requestMap[action] + '  res === ' + JSON.stringify(res));
					if (res && res.events && res.events.length > 0) {
						this.UpdateGameData(res);
						this.StartChainAction(res, param);
					}
				}
			});
		}

		public StartChainAction(data: game.IResAmuletEventResponse, param?: any, onComplete?: Laya.Handler) {
			app.Log.log('StartChainAction');
			this.locking = true;
			this.eventList = data.events || [];
			this.actionIndex = 0;
			this.actionStopped = false;
			AmuletDesktopMgr.timer.frameLoop(1, this, this.DoChainAction, [param, onComplete], true);
		}

		private DoChainAction(param?: any, onComplete?: Laya.Handler) {
			if (this.actionIndex >= this.eventList.length) {
				this.actionIndex = 0;
				this.eventList = [];
				AmuletDesktopMgr.timer.clear(this, this.DoChainAction);
			} else {
				if (this.actionRunning) return;
				if (this.actionStopped) return;
				let eventData = this.eventList[this.actionIndex];
				if (this.actionEventMap[eventData.type]) {
					this.actionRunning = true;
					app.Log.log(this.actionEventMap[eventData.type].name + JSON.stringify(eventData));
					this.actionEventMap[eventData.type].play(eventData, param, Laya.Handler.create(this, () => {
						this.actionIndex++;
						this.actionRunning = false;
						if (this.actionIndex >= this.eventList.length) {
							app.Log.log('做完所有event，解开locking');
							this.locking = false;
						}
					}))
				} else {
					this.actionIndex++;
				}
			}
		}

		public StopAction() {
			app.Log.log('StopAction,解开locking');
			this.actionStopped = true;
			this.locking = false;
			AmuletDesktopMgr.timer.clear(this, this.DoChainAction);
		}

		public ContinueAction(param?: any, onComplete?: Laya.Handler) {
			app.Log.log('ContinueAction, 锁上locking');
			this.actionStopped = false;
			this.locking = true;
			AmuletDesktopMgr.timer.frameLoop(1, this, this.DoChainAction, [param, onComplete], true);
		}

		public checkEffectOrder(forceRefresh: boolean = false) {
			if (!this.amuletGameData.effect.effect_list) return;
			let errorOrder = false;
			for (let i = 0; i < this.amuletGameData.effect.effect_list.length; i++) {
				if (!this.mainprop.containerProp.props[i] || this.mainprop.containerProp.props[i].val.id != this.amuletGameData.effect.effect_list[i].uid) {
					errorOrder = true;
					break;
				}
			}
			if (errorOrder || forceRefresh) {
				this.mainprop.containerProp.Reset();
				this.amuletGameData.effect.effect_list.forEach((effect) => {
					this.mainprop.addNewProp(amulet.PropCard.CreateProp(effect), false);
				})
			}
			uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount();
		}

		public onAmuletGameError(method: string, err: any, res: any) {
			if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26121 || res['error']['code'] == 26123)) {
				uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093), Laya.Handler.create(this, () => {
					this.ClearDesktop();
					uiscript.UI_AmuletHome.Inst.show();
				}))
			} else {
				uiscript.UIMgr.Inst.showNetReqError(method, err, res);
			}
		}

		public ActionRunComplete() {
			this.actionRunning = false;
		}

		public _load(owner: Laya.Sprite3D): void {
			this.desktop3D = owner;
			(this.desktop3D.getChildByName('all') as Laya.Sprite3D).active = false;
			let poss: Laya.Sprite3D = this.desktop3D.getChildByName('poss') as Laya.Sprite3D;
			this.mainrole = poss.addComponent(AmuletViewPlayer) as AmuletViewPlayer;
			this.mainrole.InitMe(this, game.Scene_Amulet.Inst.root2.getChildByName('hands') as Laya.Sprite3D, poss);
			this.mainprop = (this.desktop3D.getChildByName('item') as Laya.Sprite3D).addComponent(AmuletViewProp) as AmuletViewProp;
			{
				//effect
				this.trans_container_effect = this.desktop3D.getChildByName('effect') as Laya.Sprite3D;
				this.effect_dora3D = this.trans_container_effect.getChildByName('effect_dora') as Laya.Sprite3D;
				this.effectLock = this.trans_container_effect.getChildByName('effect_lock') as Laya.Sprite3D;
				let mat = (this.effect_dora3D.getChildAt(0) as Laya.MeshSprite3D).meshRender.material as Laya.StandardMaterial;
				mat.disableLight();
				this.effect_shadow = this.trans_container_effect.getChildByName('effect_shadow') as Laya.Sprite3D;
				this.effect_hupai = this.trans_container_effect.getChildByName('effect_hupai') as Laya.Sprite3D;
				this.effect_dora3D.active = true;
				this.effectLock.active = true;
				this.effect_shadow.active = true;
				this.effect_hupai.active = true;
			}

			this.effect_doraPlane = game.Scene_Amulet.Inst.root2.getChildByName('hands').getChildByName('effect_dora') as Laya.Sprite3D;
			this.effect_recommend = game.Scene_Amulet.Inst.root2.getChildByName('hands').getChildByName('effect_recommend') as Laya.Sprite3D;
			this.effect_huanpai = game.Scene_Amulet.Inst.root2.getChildByName('hands').getChildByName('effect_huanpai') as Laya.Sprite3D;
			this.effect_doraPlane.active = false;
			this.effect_recommend.active = false;
			this.effect_huanpai.active = false;
		}

		public initRoom(data: game.IAmuletGameData, complete: Laya.Handler) {
			this.InitGameData(data);
			this.active = true;
			let soundlist: Object = {};
			let charaInfo = uiscript.UI_Sushe.main_chara_info;
			let d_chara = cfg.item_definition.character.get(uiscript.UI_Sushe.main_character_id);

			let sounds = cfg.voice.sound.getGroup(d_chara.sound);
			for (let j: number = 0; j < sounds.length; j++) {
				if (charaInfo) {
					if (sounds[j].category == 2 && sounds[j].level_limit <= charaInfo.level) {
						let p: string = sounds[j].path + view.AudioMgr.suffix;
						if (!soundlist.hasOwnProperty(p)) soundlist[p] = 1;
					}
				}
			}
			for (var k in soundlist) {
				Laya.loader.load(k, null, null, null, 3);
			}

			this.mjp_res_name = game.GameUtility.get_view_res_name(game.EView.mjp_surface);
			if (view.DesktopMgr.en_mjp) {
				this.mjp_res_name += '_0';
			}
			this.mjpb_res_name = game.GameUtility.get_view_res_name(game.EView.mjp);
			let _effect_map: Object = {};
			let default_id: number = game.GameUtility.get_view_default_item_id(game.EView.mjp);
			_effect_map[game.EView.mjp] = default_id;
			this.player_effects = _effect_map;
			uiscript.UI_AmuletDesktopInfo.Inst.show();
			uiscript.UI_AmuletDesktopInfo.Inst.resetState();
			uiscript.UI_AmuletHome.Inst.show(false);
			uiscript.UI_AmuletTingPai.Inst.enable = true;
			uiscript.UI_AmuletFeverTime.Inst.enable = true;
			uiscript.UI_AmuletProp.Inst.enable = true;
			this.resetAutoFunc();
			this.mainrole.onInitRoom();
			this.locking = false;
			Laya.timer.frameOnce(6, this, () => {
				this.Reset();
				app.Log.log('场景init结束:' + (Laya.Stat.currentMemorySize / 1024 / 1024) + ' MB');
				if (complete) complete.run();
			});
		}

		public CreateProp3D(): Laya.Sprite3D {
			return (this.desktop3D.getChildByName('all').getChildByName('amulet') as Laya.Sprite3D).clone();
		}

		public CreatePai3D(): Laya.Sprite3D {
			let maque: Laya.MeshSprite3D = (this.desktop3D.getChildByName('all').getChildByName('mjp').getChildByName('maque') as Laya.MeshSprite3D).clone();
			let maque_outline: Laya.MeshSprite3D = (this.desktop3D.getChildByName('all').getChildByName('maque_outline') as Laya.MeshSprite3D).clone();
			//outline
			{
				let mesh2: Laya.Sprite3D = maque_outline;
				maque.addChild(mesh2);
				mesh2.transform.localPosition = new Laya.Vector3(0, 0, 0);
				mesh2.transform.localScale = new Laya.Vector3(1, 1, 1);
				mesh2.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
				let _mesh: Laya.MeshSprite3D = mesh2 as Laya.MeshSprite3D;
				let _mat: caps.Material_Outline = new caps.Material_Outline(caps.Outline.filename);
				_mat.renderQueue = 2999;
				_mat.setColor(caps.Outline.OUTLINE_COLOR, new Laya.Vector3(0.165, 0.192, 0.204));
				_mat.setNumber(caps.Outline.OUTLINE_ALPHA, 0.6);
				_mat.setNumber(caps.Outline.OUTLINE, 0.0012);
				_mesh.meshRender.sharedMaterial = _mat;
			}
			// 特效container
			let container: Laya.Sprite3D = new Laya.Sprite3D();
			container.name = 'effect';
			container.transform.localPosition = new Laya.Vector3(0, 0, 0);
			container.transform.localScale = new Laya.Vector3(1, 1, 1);
			container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
			maque.addChild(container);
			return maque;
		}

		public stopBgm() {
			if (this.audioId) {
				view.AudioMgr.StopAudio(this.audioId, 500);
				this.audioId = 0;
				this.bgmId = 0;
			}
		}

		public playBgm(audioId: number = 10331) {
			if (view.AudioMgr.musicMuted) return;
			if (this.bgmId == audioId) {
				return;
			}
			this.stopBgm();
			let audioPath = cfg.audio.audio.get(audioId).path;
			let volume = view.AudioMgr.musicVolume;
			this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume, 500);
			if (this.audioId > 0) {
				this.bgmId = audioId;
			}
		}

		public ClearAction() {
			this.actionStopped = false;
			this.eventList = [];
			this.actionRunning = false;
			this.actionIndex = 0;
		}

		public Reset(): void {
			// app.Log.log('DesktopMgr.Clear');
			this.ClearDesktop();
			this.mainrole.Reset();
			this.mainprop.Reset();
		}


		public ClearDesktop() {
			this.timerScore.clearAll(this);
			this.duringScoreAnim = false;
			this.duringSingleScoreAnim = false;
			this.scoreAnimList = [];
			AmuletHookEffect.duringAnim = false;
			uiscript.UI_AmuletProp.Inst.hide();
			AmuletDesktopMgr.timer.clearAllEx();
			Laya.timer.clearAll(this);
			this.mainrole.Clear();
			this.mainprop.Clear();
			uiscript.UI_AmuletDesktopInfo.Inst.resetState();
			uiscript.UI_AmuletOperation.Inst.enable = false;
			uiscript.UI_AmuletTingPai.Inst.reset();
			uiscript.UI_AmuletLevelResult.Inst.enable = false;
			this.mainrole.can_discard = false;
			this.choosedPai = null;
			this.choosedReplacePaiIds = [];
			this.resetAutoFunc();
			this.duringHuPai = false;
			this.duringPropEffect = false;
			this.locking = false;
			this.reachTarget = false;
			this.ClearAction();
		}

		public onLevelWin() {
			this.timerScore.clearAll(this);
			this.duringScoreAnim = false;
			this.duringSingleScoreAnim = false;
			this.scoreAnimList = [];
			uiscript.UI_AmuletProp.Inst.hide();
			uiscript.UI_AmuletOperation.Inst.enable = false;
			this.mainrole.can_discard = false;
			this.choosedPai = null;
			this.choosedReplacePaiIds = [];
			uiscript.UI_AmuletTingPai.Inst.reset();
			uiscript.UI_AmuletDesktopInfo.Inst.resetDesktopBg();
			this.resetAutoFunc();
			this.reachTarget = false;
		}


		public WhenDoras(data: number[], fast: boolean) {
			if (data == null || data == undefined || data.length == 0) return;
			let isNew = false;
			for (let i: number = 0; i < data.length; i++) {
				if (!this.doras.find((_dora) => { return _dora.id == data[i] })) {
					let dora = this.getDisplayMJPaiById(data[i]);
					this.doras.push(dora);
					isNew = true;
				}
				uiscript.UI_AmuletDesktopInfo.Inst.dorasTip.refreshDoras(this.doras);
			}
			this.RefreshPaiLibrary();
			this.mainrole.OnDoraRefresh();
			if (!fast && isNew) view.AudioMgr.PlayAudio(215);
		}

		public WhenTianPai(data: string[], fast: boolean) {
			if (data == null || data == undefined || data.length == 0) return;
			let isNew = false;
			for (let i: number = 0; i < data.length; i++) {
				let tian = MJPai.Create({
					id: -1,
					tile: data[i]
				});
				if (!this.tians.find((_tian) => { return MJPai.Distance(_tian, tian) == 0 })) {
					this.tians.push(tian);
					isNew = true;
				}
				if (uiscript.UI_AmuletCardLibrary.Inst.enable) uiscript.UI_AmuletCardLibrary.Inst.refresh();
			}
			this.mainrole.OnTianRefresh();
			// if (!fast && isNew) view.AudioMgr.PlayAudio(215);
		}


		public AddChoosedReplacePai(pai: amulet.MJPai): void {
			if (this.choosedReplacePaiIds.indexOf(pai.id) == -1) this.choosedReplacePaiIds.push(pai.id);
			uiscript.UI_AmuletOperation.Inst.refreshBtnReplace();
		}

		public RemoveChoosedReplacePai(pai: amulet.MJPai) {
			if (this.choosedReplacePaiIds.indexOf(pai.id) != -1) this.choosedReplacePaiIds.splice(this.choosedReplacePaiIds.indexOf(pai.id), 1);
			uiscript.UI_AmuletOperation.Inst.refreshBtnReplace();
		}

		public RemoveAllChoosedReplacePais() {
			this.choosedReplacePaiIds = [];
			uiscript.UI_AmuletOperation.Inst.refreshBtnReplace();
		}

		//处理可以进行的操作
		public ShowOperation(data: game.IAmuletGameOperation[]) {
			Laya.timer.clear(this, this.pendingAuto)
			if (!data || data.length == 0) {
				uiscript.UI_AmuletOperation.Inst.enable = false;
				this.mainrole.can_discard = false;
				return;
			}
			this.isOperateHu = false;
			this.isOperateGang = false;
			let canDiscard = false;
			let forceDiscard = false;
			data.forEach((operate) => {
				if (operate.type == amulet.EAmuletPlayOperation.rong) this.isOperateHu = true;
				if (operate.type == amulet.EAmuletPlayOperation.gang) this.isOperateGang = true;
				if (operate.type == amulet.EAmuletPlayOperation.discard) canDiscard = true;
				if (operate.type == amulet.EAmuletPlayOperation.forceDiscard) forceDiscard = true;
			})
			this.mainrole.RefreshRecommend();
			this.mainrole.can_discard = canDiscard;
			uiscript.UI_AmuletDesktopInfo.Inst.refreshBtnAutoMoqie();
			//强制出牌
			if (forceDiscard) {
				Laya.timer.once(300, this, () => {
					this.mainrole.DiscardLastPai(true);
				});
				uiscript.UI_AmuletOperation.Inst.enable = false;
				return;
			}
			//可以自动胡牌
			if (this.isOperateHu && this.autoHule) {
				uiscript.UI_AmuletOperation.Inst.enable = false;
				this.pendingAuto();
				return;
			}
			//可以自动切牌
			if (canDiscard && !this.isOperateGang && !this.isOperateHu) {
				if (this.autoMoqie) {
					Laya.timer.once(1000, this, this.pendingAuto);
				}
				uiscript.UI_AmuletOperation.Inst.enable = false;
				return;
			}
			uiscript.UI_AmuletOperation.Inst.show(data);
		}

		isTianPai(pai: MJPai) {
			if (this.isDoraBaned(pai)) {
				return false;
			}
			for (let i: number = 0; i < this.tians.length; i++) {
				if (MJPai.Distance(this.tians[i], pai) == 0) return true;
			}
			return false;
		}

		public setChoosedPai(pai: amulet.MJPai): void {
			let diff: boolean = false;
			if (!diff && pai && !this.choosedPai) diff = true;
			if (!diff && !pai && this.choosedPai) diff = true;
			if (!diff && pai && this.choosedPai && amulet.MJPai.Distance(this.choosedPai, pai) != 0) diff = true;
			if (diff) {
				this.choosedPai = pai ? pai.Clone() : null;
				this.mainrole.OnChoosePai();
				uiscript.UI_AmuletTingPai.Inst.onChooseTile(pai);
			}
		}

		onDisplayPaiMapChanged(changeId: number[]) {
			this.mainrole.OnPaiDisplayMapChanged(changeId);
		}

		//distinguishDora是否区分dora
		getLeftPaiCount(tile: string, distinguishDora: boolean): number {
			if (distinguishDora) {
				return this.paiLibrary[tile];
			} else {
				let tile1 = tile;
				let tile2 = '';
				if (tile.charAt(1) != 'z') {
					if (tile.charAt(0) == '0') {
						tile2 = '5' + tile.charAt(1);
					} else if (tile.charAt(0) == '5') {
						tile2 = '0' + tile.charAt(1);
					}
				}
				return this.paiLibrary[tile] + (tile2 ? this.paiLibrary[tile2] : 0);
			}
		}

		//forceDiscard强制模切，无论是不是在杠或胡牌情况，只要开了自动模切就模切 
		public pendingAuto(forceDiscard: boolean = false) {
			if (this.duringHuPai) return;
			if (this.autoMoqie && ((!this.isOperateGang && !this.isOperateHu) || forceDiscard)) {
				this.mainrole.DiscardLastPai();
				return;
			}
			if (this.autoHule && this.isOperateHu) {
				let param: game.IReqAmuletActivityOperate = {
					activity_id: AmuletDesktopMgr.activityId,
					type: amulet.EAmuletPlayOperation.rong,
				};
				this.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
			}
		}

		public endExchangeHands() {
			let param: game.IReqAmuletActivityOperate = {
				activity_id: AmuletDesktopMgr.activityId,
				type: amulet.EAmuletPlayOperation.endExchange
			};
			amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
		}

		public setAutoHule(value: boolean) {
			this.autoHule = value;
			this.pendingAuto();
		}

		public setAutoLiPai(value: boolean) {
			this.autoLiqi = value;
			if (value) {
				if (this.mainrole) {
					this.mainrole.LiPai(false, false);
				}
			}
		}
		public setAutoMoQie(value: boolean) {
			this.autoMoqie = value;
			uiscript.UI_AmuletTingPai.Inst.refreshBtnShow();
			this.pendingAuto(true);
		}

		public resetAutoFunc() {
			this.autoMoqie = false;
			this.autoHule = false;
			this.autoLiqi = true;
			uiscript.UI_AmuletDesktopInfo.Inst.resetAutoFunc();
		}

		public AddTileScore(score: game.IAmuletTileScore[]) {
			this.scoreAnimList.push(score[score.length - 1]);
			if (!this.duringScoreAnim) {
				this.duringScoreAnim = true;
				let delay = 1000;
				this.timerScore.frameLoop(1, this, () => {
					if (this.duringSingleScoreAnim) return;
					if (this.scoreAnimList.length == 0) {
						this.timerScore.clearAll(this);
						this.duringScoreAnim = false;
					} else {
						this.duringSingleScoreAnim = true;
						let score = this.scoreAnimList.splice(0, 1);
						uiscript.UI_AmuletDesktopInfo.Inst.doScoreAnim(score[0], delay);
						this.timerScore.once(delay, this, () => {
							this.duringSingleScoreAnim = false;
						})
					}
				})
			}
		}
	}
}