module amulet {
    export class AmuletHookEffect {
        public static duringAnim = false; //-- 正在播放动画，这个过程中不允许再塞入Trigger
        private static effectFuncs = [] //         -- 记录当前effect列表
        private static effectCardsIndex = 0     //  -- 当前effect列表播放到第几个了
        private static effectCardSubIndex = 0     //   -- 本card的第几个特效
        private static waitingEffectEnd = false// -- 等待当前effect播放完
        public static triggerLst = [
            { condition: AmuletHookEffect.Condition_AddDora, action: AmuletHookEffect.Action_AddDora },
            { condition: AmuletHookEffect.Condition_AddTianDora, action: AmuletHookEffect.Action_AddTianDora },
            { condition: AmuletHookEffect.Condition_RemoveEffect, action: AmuletHookEffect.Action_RemoveEffect },
            { condition: AmuletHookEffect.Condition_AddEffect, action: AmuletHookEffect.Action_AddEffect },
            { condition: AmuletHookEffect.Condition_UpgradeEffect, action: AmuletHookEffect.Action_UpgradeEffect },
            { condition: AmuletHookEffect.Condition_TransfromEffect, action: AmuletHookEffect.Action_TransfromEffect },
            { condition: AmuletHookEffect.Condition_AddCoin, action: AmuletHookEffect.Action_AddCoin },
            { condition: AmuletHookEffect.Condition_ModifyFan, action: AmuletHookEffect.Action_ModifyFan },
            { condition: AmuletHookEffect.Condition_AddFan, action: AmuletHookEffect.Action_AddFan },
            { condition: AmuletHookEffect.Condition_AddBase, action: AmuletHookEffect.Action_AddBase },
            { condition: AmuletHookEffect.Condition_TileReplace, action: AmuletHookEffect.Action_TileReplace },
            { condition: AmuletHookEffect.Condition_AddTileScore, action: AmuletHookEffect.Action_AddTileScore },
            { condition: AmuletHookEffect.Condition_OpenTile, action: AmuletHookEffect.Action_OpenTile },
            { condition: AmuletHookEffect.Condition_ForceDiscard, action: AmuletHookEffect.Action_ForceDiscard },
            { condition: AmuletHookEffect.Condition_AddBadge, action: AmuletHookEffect.Action_AddBadge },
            { condition: AmuletHookEffect.Condition_RemoveBadge, action: AmuletHookEffect.Action_RemoveBadge },
            { condition: AmuletHookEffect.Condition_CopyEffect, action: AmuletHookEffect.Action_CopyEffect },
            { condition: AmuletHookEffect.Condition_UpgradeLevel, action: AmuletHookEffect.Action_UpgradeLevel },
            { condition: AmuletHookEffect.Condition_EffectGrowth, action: AmuletHookEffect.Action_EffectGrowth },
            { condition: AmuletHookEffect.Condition_ModifyDesktop, action: AmuletHookEffect.Action_ModifyDesktop },
            { condition: AmuletHookEffect.Condition_UnstableProp, action: AmuletHookEffect.Action_UnstableProp }
        ]

        public static play(effects: game.IAmuletEffectedHookData[], onComplete: Laya.Handler): void {
            if (this.duringAnim) return;
            AmuletDesktopMgr.timer.clearAll(this);
            if (!effects || effects.length == 0) {
                onComplete && onComplete.run();
                return;
            }
            this.effectFuncs = [];
            for (let i = 0; i < effects.length; i++) {
                let effectData = effects[i];
                let effectLst = [];
                for (let j = 0; j < this.triggerLst.length; j++) {
                    if (this.triggerLst[j].condition(effectData.result)) {
                        effectLst.push(this.triggerLst[j].action);
                    }
                }
                if (effectLst.length > 0) {
                    this.effectFuncs.push({
                        card_id: effectData.uid,
                        data: effectData,
                        effectLst: effectLst
                    });
                }
            }
            if (this.effectFuncs.length == 0) {
                onComplete && onComplete.run();
                return;
            }
            this.duringAnim = true;
            this.effectCardsIndex = 1;
            this.effectCardSubIndex = 1;
            this.waitingEffectEnd = false;
            AmuletDesktopMgr.timer.frameLoop(1, this, () => {
                if (this.waitingEffectEnd) return;
                if (this.effectCardsIndex > this.effectFuncs.length) {
                    //所有effect都播放完了，可以回调了
                    this.duringAnim = false;
                    AmuletDesktopMgr.timer.clearAll(this);
                    this.effectFuncs = null;
                    this.effectCardsIndex = 0;
                    onComplete && onComplete.run();
                    return;
                }
                if (this.effectCardSubIndex > this.effectFuncs[this.effectCardsIndex - 1].effectLst.length) {
                    this.effectCardsIndex = this.effectCardsIndex + 1;
                    this.effectCardSubIndex = 1;
                    if (this.effectCardsIndex <= this.effectFuncs.length) {
                        this.waitingEffectEnd = true;
                        AmuletDesktopMgr.timer.once(500, this, () => {//卡牌和卡牌之间触发间隔30帧
                            this.waitingEffectEnd = false;
                        })
                    }
                } else {
                    // -- 播放下一个effect
                    this.waitingEffectEnd = true;
                    let data: game.IAmuletEffectedHookData = this.effectFuncs[this.effectCardsIndex - 1].data;
                    if (this.effectCardSubIndex == 1 && data.type) {
                        if (data.type == 1) {
                            AmuletDesktopMgr.Inst.mainprop.DoPropEffectById(data.uid, EPropEffectAniType.takeEffect);
                        } else if (data.type == 2) {
                            AmuletDesktopMgr.Inst.mainprop.DoPropEffectByBadgeId(data.uid, EPropEffectAniType.takeEffect);
                        }
                    }
                    this.effectFuncs[this.effectCardsIndex - 1].effectLst[this.effectCardSubIndex - 1](data, Laya.Handler.create(this, () => {
                        this.waitingEffectEnd = false;
                        this.effectCardSubIndex = this.effectCardSubIndex + 1;
                    }))
                }
            })
        }

        public static playImmediately(effects: game.IAmuletEffectedHookData[], onComplete: Laya.Handler) {
            if (this.duringAnim) {
                AmuletDesktopMgr.Inst.locking = false;
                this.duringAnim = false;
            }
            AmuletDesktopMgr.timer.clearAll(this);
            if (!effects || effects.length == 0) {
                onComplete && onComplete.run();
                return;
            }
            this.effectFuncs = [];
            for (let i = 0; i < effects.length; i++) {
                let effectData = effects[i];
                let effectLst = [];
                for (let j = 0; j < this.triggerLst.length; j++) {
                    if (this.triggerLst[j].condition(effectData.result)) {
                        effectLst.push(this.triggerLst[j].action);
                    }
                }
                this.effectFuncs.push({
                    card_id: effectData.uid,
                    data: effectData,
                    effectLst: effectLst
                })
            }
            if (this.effectFuncs.length == 0) {
                onComplete && onComplete.run();
                return;
            }
            this.effectCardsIndex = 1;
            this.effectCardSubIndex = 1;
            while (this.effectCardsIndex <= this.effectFuncs.length) {
                if (this.effectCardSubIndex > this.effectFuncs[this.effectCardsIndex - 1].effectLst.length) {
                    this.effectCardsIndex = this.effectCardsIndex + 1;
                    this.effectCardSubIndex = 1;
                } else {
                    // -- 播放下一个effect
                    let data: game.IAmuletEffectedHookData = this.effectFuncs[this.effectCardsIndex - 1].data;
                    this.effectFuncs[this.effectCardsIndex - 1].effectLst[this.effectCardSubIndex - 1](data, null, false);
                    this.effectCardSubIndex = this.effectCardSubIndex + 1;
                }
            }
            onComplete && onComplete.run();
        }

        private static Condition_AddDora(effect: game.IAmuletHookResult): boolean {
            return effect.add_dora && effect.add_dora.list && effect.add_dora.list.length > 0;
        }

        private static Action_AddDora(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let dora = data.result.add_dora.list;
            AmuletDesktopMgr.Inst.WhenDoras(dora, !doAnim);
            onComplete && onComplete.run();
        }

        private static Condition_AddTianDora(effect: game.IAmuletHookResult): boolean {
            return effect.add_tian_dora && effect.add_tian_dora.length > 0
        }

        private static Action_AddTianDora(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            AmuletDesktopMgr.Inst.WhenTianPai(data.result.add_tian_dora, !doAnim);
            onComplete && onComplete.run();
        }


        private static Condition_AddEffect(effect: game.IAmuletHookResult): boolean {
            return effect.add_effect && effect.add_effect.length > 0;
        }

        private static Action_AddEffect(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let delay = 0;
            for (let i = 0; i < data.result.add_effect.length; i++) {
                let newEffect = data.result.add_effect[i];
                let oldEffect = AmuletDesktopMgr.Inst.mainprop.isPropAlreadyHaveByUId(newEffect.uid);
                let isUpgrade = oldEffect && uiscript.UI_PropDetailCard.getPropUpgradeIdByPropId(oldEffect.effectId) == newEffect.id;
                if (isUpgrade) {
                    let isStillExist = false;
                    let _effect = AmuletDesktopMgr.Inst.effectMap.get(newEffect.uid);
                    if (_effect && newEffect.id == _effect.id) {
                        isStillExist = true;
                        AmuletDesktopMgr.Inst.mainprop.refreshPropByMerged(PropCard.CreateProp(_effect), doAnim);
                    }
                    if (!isStillExist) {
                        AmuletDesktopMgr.Inst.mainprop.refreshPropByMerged(PropCard.CreateTempleteProp(newEffect.id, newEffect.badge, newEffect.uid), doAnim);
                    }
                    delay = 600;
                    continue;
                }
                if (oldEffect && oldEffect.effectId == newEffect.id) continue;
                AmuletDesktopMgr.Inst.mainprop.addNewProp(PropCard.CreateProp(newEffect), doAnim);
                delay = 600;
            }
            uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount();
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(delay, this, () => {
                onComplete && onComplete.run();
            })
        }

        private static Condition_UpgradeEffect(effect: game.IAmuletHookResult): boolean {
            return effect.upgrade_effect && effect.upgrade_effect.length > 0;
        }

        private static Action_UpgradeEffect(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let delay = 0;
            for (let i = 0; i < data.result.upgrade_effect.length; i++) {
                let newEffect = data.result.upgrade_effect[i];
                AmuletDesktopMgr.Inst.mainprop.refreshPropByMerged(PropCard.CreateProp(newEffect), doAnim);
                delay = 600;
            }
            uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount();
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(delay, this, () => {
                onComplete && onComplete.run();
            })
        }


        private static Condition_RemoveEffect(effect: game.IAmuletHookResult): boolean {
            return effect.remove_effect && effect.remove_effect.length > 0;
        }

        private static Action_RemoveEffect(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            for (let i = 0; i < data.result.remove_effect.length; i++) {
                AmuletDesktopMgr.Inst.mainprop.RemovePropById(data.result.remove_effect[i], doAnim);
            }
            uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount();
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(400, this, () => {
                // app.Log.log('扔完了');
                onComplete && onComplete.run();
            });
        }

        private static Condition_AddCoin(effect: game.IAmuletHookResult): boolean {
            return (effect.coin_modify && effect.coin_modify.modify && effect.coin_modify.modify != '0');
        }

        private static Action_AddCoin(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let coin = uiscript.SciNum.createSciNumByStr(data.result.coin_modify.final);
            uiscript.UI_AmuletDesktopInfo.Inst.refreshCurrency(coin, doAnim);
            onComplete && onComplete.run();
        }

        private static Condition_AddFan(effect: game.IAmuletHookResult): boolean {
            return effect.modify_fan && effect.modify_fan.modify && effect.modify_fan.modify != '0';
        }

        private static Action_AddFan(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!AmuletDesktopMgr.Inst.duringHuPai || !doAnim) {
                onComplete && onComplete.run();
                return;
            }
            uiscript.UI_AmuletHuPaiResult.Inst.addFan(uiscript.SciNum.createSciNumByStr(data.result.modify_fan.modify), uiscript.SciNum.createSciNumByStr(data.result.modify_fan.final), onComplete);
        }

        private static Condition_AddBase(effect: game.IAmuletHookResult): boolean {
            return effect.modify_base && effect.modify_base.modify && effect.modify_base.modify != '0';

        }
        private static Action_AddBase(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!AmuletDesktopMgr.Inst.duringHuPai || !doAnim) {
                onComplete && onComplete.run();
                return;
            }
            uiscript.UI_AmuletHuPaiResult.Inst.addBase(uiscript.SciNum.createSciNumByStr(data.result.modify_base.modify), uiscript.SciNum.createSciNumByStr(data.result.modify_base.final), onComplete);
        }

        private static Condition_ModifyFan(effect: game.IAmuletHookResult): boolean {
            return effect.modify_fan_info && effect.modify_fan_info.length > 0;
        }

        private static Action_ModifyFan(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!AmuletDesktopMgr.Inst.duringHuPai || !doAnim) {
                onComplete && onComplete.run();
                return;
            }
            let delay = 0;
            for (let i = 0; i < data.result.modify_fan_info.length; i++) {
                let fan = data.result.modify_fan_info[i];
                AmuletDesktopMgr.timer.once(delay, this, () => {
                    uiscript.UI_AmuletHuPaiResult.Inst.modifyYiZhong(fan);
                })
                delay = delay + 100;
            }
            AmuletDesktopMgr.timer.once(delay, this, () => {
                onComplete && onComplete.run();
            })
        }

        private static Condition_TileReplace(effect: game.IAmuletHookResult): boolean {
            return effect.tile_replace && effect.tile_replace.length > 0;
        }

        private static Action_TileReplace(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let replaceIds = [];
            data.result.tile_replace.forEach((tile) => { replaceIds.push(tile.id); });
            let delay = doAnim ? 500 : 0;
            AmuletDesktopMgr.timer.once(delay, this, () => {
                AmuletDesktopMgr.Inst.onDisplayPaiMapChanged(replaceIds);
                onComplete && onComplete.run();
            })
        }

        private static Condition_AddTileScore(effect: game.IAmuletHookResult): boolean {
            return (effect.modify_tile_score && effect.modify_tile_score.length > 0);
        }

        private static Action_AddTileScore(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            let scores = data.result.modify_tile_score || [];
            if (scores.length > 0) AmuletDesktopMgr.Inst.AddTileScore(scores);
            AmuletDesktopMgr.timer.once(1000, this, () => {
                onComplete && onComplete.run();
            })
        }

        private static Condition_OpenTile(effect: game.IAmuletHookResult): boolean {
            return effect.add_show_tile && effect.add_show_tile.length > 0;
        }

        private static Action_OpenTile(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            AmuletDesktopMgr.Inst.mainrole.addOpenTiles(data.result.add_show_tile || [], doAnim);
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(250, this, () => {
                onComplete && onComplete.run();
            });
        }

        private static Condition_ForceDiscard(effect: game.IAmuletHookResult): boolean {
            return effect.force_moqie;
        }

        private static Action_ForceDiscard(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(300, this, () => { //让玩家看一眼牌再进行下一步
                onComplete && onComplete.run();
            });
        }

        private static Condition_TransfromEffect(effect: game.IAmuletHookResult): boolean {
            return effect.transform_effect && effect.transform_effect.length > 0;
        }

        private static Action_TransfromEffect(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let delay = 400;
            for (let i = 0; i < data.result.transform_effect.length; i++) {
                let transform = data.result.transform_effect[i];
                AmuletDesktopMgr.Inst.mainprop.refreshPropByMerged(PropCard.CreateTempleteProp(transform.effect_id, transform.add_result.badge, transform.uid), doAnim);
                if (transform.add_result && transform.add_result.merge_type) {
                    let addData = transform.add_result;
                    let mergeLst = addData.merged_list || [];
                    mergeLst.push(transform.uid);
                    mergeLst.forEach((mergeId) => {
                        if (mergeId == addData.uid) {
                            if (doAnim) {
                                AmuletDesktopMgr.timer.once(400, this, () => {
                                    AmuletDesktopMgr.Inst.mainprop.DoPropEffectById(mergeId, EPropEffectAniType.takeEffect);
                                });
                                delay = 800;
                            }
                            return;
                        }
                        if (doAnim) {
                            AmuletDesktopMgr.timer.once(400, this, () => {
                                AmuletDesktopMgr.Inst.mainprop.DoPropEffectById(mergeId, EPropEffectAniType.takeEffect);
                            });
                            AmuletDesktopMgr.timer.once(800, this, () => {
                                AmuletDesktopMgr.Inst.mainprop.RemovePropById(mergeId, doAnim);
                            });
                            delay = 1400;
                        } else {
                            AmuletDesktopMgr.Inst.mainprop.RemovePropById(mergeId, doAnim);
                        }
                    })
                    let addNew = () => {
                        if (AmuletDesktopMgr.Inst.mainprop.isPropAlreadyHaveByUId(addData.uid)) {
                            AmuletDesktopMgr.Inst.mainprop.refreshPropByMerged(PropCard.CreateProp(addData), doAnim);
                        } else {
                            AmuletDesktopMgr.Inst.mainprop.addNewProp(PropCard.CreateProp(addData), doAnim);
                        }
                    }
                    if (doAnim) {
                        AmuletDesktopMgr.timer.once(delay, this, addNew);
                    } else {
                        addNew();
                    }
                }

            }
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(delay + 600, this, () => {
                onComplete && onComplete.run();
            });
        }

        private static Condition_AddBadge(effect: game.IAmuletHookResult): boolean {
            return effect.add_badge && effect.add_badge.length > 0;
        }

        private static Action_AddBadge(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            data.result.add_badge.forEach((addBagde) => {
                let prop = AmuletDesktopMgr.Inst.mainprop.isPropAlreadyHaveByUId(addBagde.uid);
                if (prop) {
                    AmuletDesktopMgr.Inst.mainprop.refreshPropBadge(PropCard.CreateProp({
                        id: prop.effectId,
                        uid: prop.id,
                        store: prop.store,
                        badge: { uid: addBagde.badge_uid, id: addBagde.badge_id, store: [], random: Math.random() * 100000 }
                    }), doAnim);
                }
            })
            if (doAnim) {
                AmuletDesktopMgr.timer.once(500, this, () => {
                    onComplete && onComplete.run();
                });
            } else {
                onComplete && onComplete.run();
            }
        }

        private static Condition_RemoveBadge(effect: game.IAmuletHookResult): boolean {
            return effect.remove_badge && effect.remove_badge.length > 0;
        }

        private static Action_RemoveBadge(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            data.result.remove_badge.forEach((uid) => {
                let prop = AmuletDesktopMgr.Inst.mainprop.isPropAlreadyHaveByUId(uid);
                if (prop) {
                    AmuletDesktopMgr.Inst.mainprop.refreshPropBadge(PropCard.CreateProp({
                        id: prop.effectId,
                        uid: prop.id,
                        store: prop.store,
                        badge: null
                    }), doAnim);
                }
            })
            if (doAnim) {
                AmuletDesktopMgr.timer.once(500, this, () => {
                    onComplete && onComplete.run();
                });
            } else {
                onComplete && onComplete.run();
            }
        }

        private static Condition_CopyEffect(effect: game.IAmuletHookResult): boolean {
            return effect.copy_effect && effect.copy_effect.length > 0;
        }

        /** 复制护身符 */
        private static Action_CopyEffect(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            let delay = 0;
            for (let i = 0; i < data.result.copy_effect.length; i++) {
                let newEffect = AmuletDesktopMgr.Inst.effectMap.get(data.result.copy_effect[i].uid);
                AmuletDesktopMgr.Inst.mainprop.addNewProp(PropCard.CreateProp(newEffect), doAnim);
                delay = 600;
            }
            uiscript.UI_AmuletDesktopInfo.Inst.refreshPropCount();
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(delay, this, () => {
                onComplete && onComplete.run();
            })
        }

        /** 无视过关分数直接过关 */
        private static Condition_UpgradeLevel(effect: game.IAmuletHookResult): boolean {
            return effect.upgrade_level;
        }

        private static Action_UpgradeLevel(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(200, this, () => {
                onComplete && onComplete.run();
            });
        }

        /** 护身符成长 */
        private static Condition_EffectGrowth(effect: game.IAmuletHookResult): boolean {
            return effect.effect_growth;
        }

        private static Action_EffectGrowth(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(200, this, () => {
                onComplete && onComplete.run();
            });
        }

        /** 修改待摸牌数据 */
        private static Condition_ModifyDesktop(effect: game.IAmuletHookResult): boolean {
            return !!effect.modify_change_desktop;
        }

        private static Action_ModifyDesktop(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            const remainCardCount = data.result.modify_change_desktop.desktop_remain || 0;
            const remainCards = data.result.modify_change_desktop.show_desktop_tiles || [];
            const lockedTiles = data.result.modify_change_desktop.locked_tile || [];
            let desktopCards: Array<amulet.MJPai> = [];
            for (let i: number = 0; i < lockedTiles.length + remainCardCount; i++) {
                desktopCards.push(amulet.MJPai.CreateEmpty());
            }
            remainCards.forEach((value) => {
                if (value.pos < remainCardCount + lockedTiles.length) {
                    desktopCards[value.pos] = AmuletDesktopMgr.Inst.getDisplayMJPaiById(value.id);
                }
            });
            //不做动画就直接硬刷一下桌面所有牌
            if (!doAnim) {
                AmuletDesktopMgr.Inst.mainrole.InitDesktopPais(desktopCards, lockedTiles, false);
                onComplete && onComplete.run();
                return;
            }
            //将桌面所有牌盖上（关闭公开牌）
            AmuletDesktopMgr.Inst.mainrole.CloseAllDesktopPai(doAnim);
            //重新刷新新的公开牌
            AmuletDesktopMgr.timer.once(300, this, () => {
                desktopCards.forEach((pai, index) => {
                    if (pai.id != -1) {
                        AmuletDesktopMgr.Inst.mainrole.containerDesktopCards.OpenDesktopPai(index, pai, doAnim);
                    }
                })
            })
            //动画做完了，刷新锁链
            AmuletDesktopMgr.timer.once(600, this, () => {
                AmuletDesktopMgr.Inst.mainrole.RefreshLockedTiles(lockedTiles);
                AmuletDesktopMgr.timer.once(100, this, () => {
                    onComplete && onComplete.run();
                })
            })
        }

        /** 修改变卡数据 */
        private static Condition_UnstableProp(effect: game.IAmuletHookResult): boolean {
            return effect.hasOwnProperty('self_effect_id');
        }

        /** 修改变卡数据 */
        private static Action_UnstableProp(data: game.IAmuletEffectedHookData, onComplete: Laya.Handler, doAnim: boolean = true) {
            if (!data.uid || !AmuletDesktopMgr.Inst.effectMap.get(data.uid)) {
                onComplete && onComplete.run();
                return;
            }
            let effect = AmuletDesktopMgr.Inst.mainprop.isPropAlreadyHaveByUId(data.uid);
            effect.store = [data.result.self_effect_id.toString()];
            AmuletDesktopMgr.Inst.mainprop.refreshPropUnstable(effect, doAnim);
            if (!doAnim) {
                onComplete && onComplete.run();
                return;
            }
            AmuletDesktopMgr.timer.once(1300, this, () => {
                onComplete && onComplete.run();
            })
        }

    }
}