/**
* name 
*/
module amulet {
	export enum ERevealState {
		None = 0,
		reveal = 1, //盖住
		self = 2, // 描边可一件
	}
	const COLOR_WHITE: Laya.Vector4 = new Laya.Vector4(1, 1, 1, 1);
	const COLOR_GRAY: Laya.Vector4 = new Laya.Vector4(0.8, 0.8, 0.8, 1);
	const COLOR_YELLOW: Laya.Vector4 = new Laya.Vector4(1, 0.917, 0.663, 1);
	const COLOR_BLUE: Laya.Vector4 = new Laya.Vector4(0.615, 0.827, 0.976, 1);

	export class AmuletPai3DPlane extends game.Moveable {
		public static Cmp(a: AmuletPai3DPlane, b: AmuletPai3DPlane): number {
			let a_val: number = (a.val.numValue() * 10 + (a.val.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.val.touming ? 1 : 0);
			let b_val: number = (b.val.numValue() * 10 + (b.val.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.val.touming ? 1 : 0);
			if (a_val != b_val) return a_val - b_val;
			return a.index - b.index;
		}

		constructor() {
			super();
		}

		public val: amulet.MJPai = null;
		public owner: Laya.Sprite3D = null;
		public mesh: Laya.MeshSprite3D = null;
		public ismoqie: boolean = false; // 是否为摸切牌
		public is_open: boolean = false;
		private isDora: boolean = false;
		public effect_parent: Laya.Sprite3D = null; // 阴影鸣牌指示等需要翻转特效的父节点
		public index: number;
		public isLocked: boolean = false;

		public _load() {
			this.effect_parent = this.owner.getChildByName('effect') as Laya.Sprite3D;
			this.mesh = this.owner.getChildAt(0) as Laya.MeshSprite3D;
		}

		SetVal(_val: amulet.MJPai, need_refresh_dora: boolean = true) {
			this.val = _val;
			this.isDora = false;
			this.isLocked = false;
			if (this.mesh.meshRender.sharedMaterials.length <= 1) {
				this.mesh = this.owner as Laya.MeshSprite3D;
			}
			if (need_refresh_dora) {
				this.RefreshDora();
			}
			let texture_path: string = 'scene/Assets/Resource/mjpaimian/';
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
				texture_path += 'en_kr/';
			}
			let split = 0.7;
			let front_texture = texture_path + amulet.AmuletDesktopMgr.Inst.mjp_res_name + '/mjp.png';
			if (_val.baida) {
				front_texture = texture_path + (view.DesktopMgr.en_mjp ? 'mjpface_special_0/wanxiangxiuluo_mode/mjp.png' : 'mjpface_special/wanxiangxiuluo_mode/mjp.png');
			}
			let texture_back_path: string = 'scene/Assets/Resource/mjpai/';
			let back_texture = texture_back_path + amulet.AmuletDesktopMgr.Inst.mjpb_res_name + '/mjp.png';
			let tex: Laya.Texture2D = Laya.loader.getRes(front_texture);
			if (tex) {
				tex.mipmap = false;
			}
			let mat_cartoon_front: caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon_Pai.filename);
			mat_cartoon_front.setTexture(caps.Cartoon_Pai.TEXTURE, tex);
			mat_cartoon_front.setNumber(caps.Cartoon_Pai.SPLIT, split);
			mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
			mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
			mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR, new Laya.Vector3(1, 1, 1));
			mat_cartoon_front.setColor(caps.Cartoon_Pai.TILING_OFFSET, _val.baida ? new Laya.Vector4(1, 1, 0, 0) : _val.getTilingOffset()); //百搭牌 
			mat_cartoon_front.setNumber(caps.Cartoon_Alpha.ALPHA, 1);

			let mat_cartoon_mid: caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon_Tile_Back.filename);
			mat_cartoon_mid.setTexture(caps.Cartoon_Tile_Back.TEXTURE1, Laya.loader.getRes(back_texture));
			mat_cartoon_mid.setTexture(caps.Cartoon_Tile_Back.TEXTURE2, Laya.loader.getRes(front_texture));
			mat_cartoon_mid.setColor(caps.Cartoon_Tile_Back.TILING_OFFSET, new Laya.Vector4(1, 1, 0, 0));
			mat_cartoon_mid.setColor(caps.Cartoon_Tile_Back.TILING_OFFSET_1, _val.baida ? new Laya.Vector4(1, 1, 1, 1) : new Laya.Vector4(0.1, 1, 0.9, 0));
			mat_cartoon_mid.setNumber(caps.Cartoon.SPLIT, split);
			mat_cartoon_mid.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
			mat_cartoon_mid.setColor(caps.Cartoon.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
			mat_cartoon_mid.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
			mat_cartoon_mid.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
			this.mesh.meshRender.sharedMaterials = [mat_cartoon_mid, mat_cartoon_front];
			this.RefreshTian();
		}

		public ShowUp(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.7, 0, 0, 0.7);
			this.owner.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
		}

		public ShowBack(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0, -0.7, -0.7, 0);
			this.owner.transform.localRotationEuler = new Laya.Vector3(-90, 0, 180);
			this.effect_parent.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
		}

		public ShowRot(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.5, -0.5, 0.5, 0.5);
			this.owner.transform.localRotationEuler = new Laya.Vector3(90, -90, 0);
		}

		public ShowStand(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.5, -0.5, 0.5, 0.5);
			this.owner.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
		}

		public RefreshDora(): void {
			if (this.isDora) return;
			if (this.val.dora) this.isDora = true;
			if (!this.isDora) {
				for (let i: number = 0; i < AmuletDesktopMgr.Inst.doras.length; i++) {
					if (amulet.MJPai.DoraMet(this.val, AmuletDesktopMgr.Inst.doras[i])) {
						this.isDora = true;
						break;
					}
				}
			}
			let effect = this.owner.getChildByName('effect_dora') as Laya.Sprite3D;
			if (this.isDora) {
				if (!effect) {
					effect = AmuletDesktopMgr.Inst.effect_dora3D.clone();
					effect.name = 'effect_dora'
					this.owner.addChild(effect);
				}
				effect.transform.localPosition = new Laya.Vector3(0, 0, 0);
				effect.transform.localScale = new Laya.Vector3(1, 1, 1);
				effect.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				effect.active = false;
				effect.active = true;
				let runuv: anim.RunUV = (effect.getChildAt(0) as Laya.Sprite3D).addComponent(anim.RunUV) as anim.RunUV;
			} else {
				if (effect) effect.active = false;
			}
		}

		public RefreshLock(locked: boolean){
			this.isLocked = locked;
			this.setMeshColor(this.GetDefaultColor());
		}

		public RefreshTian(): void {
			this.setMeshColor(this.GetDefaultColor());
		}

		// 牌谱中将牌竖起来时移除dora特效
		public RemoveDora() {
			if (!this.isDora) return;
			if (this.is_open || this.val.touming) return;
			this.isDora = false;
			if (this.owner.getChildByName('effect_dora'))
				this.owner.removeChildByName('effect_dora');
		}

		public OnChoosedPai(): void {
			const pai = AmuletDesktopMgr.Inst.choosedPai;
			let color: Laya.Vector4 = new Laya.Vector4();
			//是被选中的牌
			if (pai && amulet.MJPai.Distance(pai, this.val) == 0) {
				if (this.isLocked) {
					Laya.Vector4.multiply(COLOR_GRAY, COLOR_BLUE, color);
				} else {
					color = COLOR_BLUE;
				}
			} else {
				color = this.GetDefaultColor();
			}
			this.setMeshColor(color);
		}

		private GetDefaultColor(): Laya.Vector4 {
			if (this.val && amulet.AmuletDesktopMgr.Inst.isTianPai(this.val)) {
				if (this.isLocked) {
					let vec = new Laya.Vector4();
					Laya.Vector4.multiply(COLOR_GRAY, COLOR_YELLOW, vec);
					return vec;
				}
				return COLOR_YELLOW;
			}
			if (this.isLocked) return COLOR_GRAY;
			return COLOR_WHITE;
		}

		public ResetAllTimer() {
			Laya.timer.clearAll(this);
		}


		private setMeshColor(color: Laya.Vector4) {
			if (this.mesh.meshRender.sharedMaterials.length > 1) {
				for (let mat of this.mesh.meshRender.sharedMaterials) {
					(mat as caps.BaseMaterial).setColor(caps.Cartoon.COLOR, color);
				}
			} else {
				(this.mesh.meshRender.sharedMaterial as caps.BaseMaterial).setColor(caps.Cartoon.COLOR, color);
			}
		}

		public SetIndex(index: number): void {
			if (!this.owner) {
				app.Log.log('SetIndex index:' + index + ' model不存在');
			} else if (this.owner.destroyed) {
				app.Log.log('SetIndex index:' + index + ' model已经被删除');
			} else if (!this.owner.transform) {
				app.Log.log('SetIndex index:' + index + ' model.transform不存在');
			}
			this.index = index;
		}
	}
}