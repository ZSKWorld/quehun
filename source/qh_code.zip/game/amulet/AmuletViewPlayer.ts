/**
* name 
*/
module amulet {

	interface IMouseInfo {
		inHandRange: boolean;
		index: number;
		x: number;
		y: number;
		pai: HandPaiPlane;
	}

	export enum EAmuletChoooseState { none, choosing, waiting } // 无|选择中|选择完毕
	export class AmuletViewPlayer extends Laya.Script {
		public static Inst: AmuletViewPlayer = null;

		/**用于鼠标检测的射线**/
		private ray: Laya.Ray;
		/**碰撞信息**/
		private rayCastHit: Laya.RaycastHit;
		public _choose_pai: HandPaiPlane = null;
		private _mouse_in_pai: HandPaiPlane = null;
		private _mouse_in_start_time: number = -1;
		private handModels: Array<Laya.Sprite3D> = [];
		private animHands: Array<Laya.Animator> = [];
		private handpool: Array<HandPaiPlane> = [];
		public hand: Array<HandPaiPlane> = [];
		public chooseState: EAmuletChoooseState = EAmuletChoooseState.none;
		private effect_click: Laya.Sprite3D = null;
		public can_discard: boolean = false;
		public last_tile: HandPaiPlane = null;
		private mouse_downx: number = 0;
		private mouse_downy: number = 0;
		private mouse_downed: boolean = false;
		private during_drag: boolean = false;
		private click_on_choosed: boolean = false;
		private click_choosed_time: number = 0;
		private zd: number = 0;
		private anim_id: number = 0;

		public desktop: AmuletDesktopMgr = null;
		public hand3d: Laya.Sprite3D = null;

		public containerDesktopCards: BlockDesktopCards = null;
		public containerMing: AmuletBlockMing = null;
		public pai_xuezhan_mid_zimo: amulet.MJPai = null;

		public score: number = 0;
		public duringShowDetla: boolean = false;
		private trans_liqi_position: Laya.Vector3 = null;
		private trans_liqi_scale: Laya.Vector3 = null;
		public hand_type: string = 'hand_human';
		public mingIdsList: number[];
		public xianggonged: boolean;

		constructor() {
			super();
			AmuletViewPlayer.Inst = this;
		}

		public isNewGang(mingInfo: game.IAmuletMingInfo): boolean {
			return this.mingIdsList.indexOf(mingInfo.tile_list[0]) == -1;
		}

		public InitMe(_desktop: AmuletDesktopMgr, _hand: Laya.Sprite3D, _poss: Laya.Sprite3D): void {
			this.desktop = _desktop;
			//备选牌
			let _paihai: Laya.Sprite3D = _poss.getChildByName('deck').getChildAt(0) as Laya.Sprite3D;
			let _ming: Laya.Sprite3D = _poss.getChildByName('ming').getChildAt(0) as Laya.Sprite3D;
			for (let i: number = 0; i < _ming.parent.numChildren; i++) (_ming.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			for (let i: number = 0; i < _paihai.parent.numChildren; i++) (_paihai.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			this.containerDesktopCards = new BlockDesktopCards(_paihai, this);
			this.containerMing = new AmuletBlockMing(_ming, this);
			this.hand3d = _poss.getChildByName('hand_1') as Laya.Sprite3D;
			this.hand3d.active = false;
			let pai_templete: Laya.MeshSprite3D = _hand.getChildByName('pai') as Laya.MeshSprite3D;
			this.effect_click = _hand.getChildByName('effect_dianji') as Laya.Sprite3D;
			//this.effect_click.active = false;
			_hand.active = true;
			pai_templete.active = false;
			for (let i: number = 0; i < 16; i++) {
				let pai3D: Laya.MeshSprite3D = pai_templete.clone();
				_hand.addChild(pai3D);
				pai3D.transform.localPosition = new Laya.Vector3(0, 0, 0);
				pai3D.transform.localRotation = new Laya.Quaternion(0, 0, 0, 1);
				pai3D.transform.localScale = new Laya.Vector3(1, 1, 1);
				pai3D.active = false;
				var hm: HandPaiPlane = pai3D.addComponent(HandPaiPlane) as HandPaiPlane;
				this.handpool.push(hm);
			}
			//创建一条射线
			this.ray = new Laya.Ray(new Laya.Vector3(), new Laya.Vector3());
			//创建碰撞信息
			this.rayCastHit = new Laya.RaycastHit();
			//鼠标点击事件回调onMouseDown
			Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
			Laya.stage.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
			Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMouseMove);
			Laya.stage.on(Laya.Event.MOUSE_OUT, this, this.onMouseOut);
		}

		private _AddHandPai(pai: amulet.MJPai, is_open: boolean): HandPaiPlane {
			let p: HandPaiPlane = this.handpool.pop();
			p.Reset();
			p.SetVal(pai, is_open);
			p.z = this.zd;
			this.zd -= 0.02;
			// if (amulet.AmuletDesktopMgr.Inst.is_chuanma_mode()) {
			// 	p.OnChoosedPai();
			// }
			this.hand.push(p);
			return p;
		}

		private _OnRemovePai(pai: HandPaiPlane): void {
			if (pai === this._choose_pai) {
				this._choose_pai = null;
				this.resetMouseState();
				// DesktopMgr.Inst.setChoosedPai(null);
			}
		}

		//直接删除
		private _RemovePai(pai: HandPaiPlane): void {
			for (let i: number = 0; i < this.hand.length; i++) {
				if (this.hand[i] === pai) {
					var tmp = this.hand[i];
					for (let j: number = i; j < this.hand.length - 1; j++) {
						this.hand[j] = this.hand[j + 1];
						this.hand[j].SetIndex(j, false, true);
					}
					this.hand.pop();

					this._OnRemovePai(tmp);
					tmp.Reset();
					this.handpool.push(tmp);
					break;
				}
			}

			// 删除时还原
			for (let hand of this.hand) {
				if (hand.mySelf) {
					hand.mySelf.active = true;
				}
			}
		}

		//根据牌的值删除手牌
		private _RemoveHandPai(pai: amulet.MJPai, tile_state: number, moqie: boolean = true): boolean {
			let index: number = -1;

			if (tile_state == -1 || tile_state == 1) {
				if (!moqie) {
					for (let i: number = 0; i < this.hand.length; i++) {
						if (amulet.MJPai.isSame(pai, this.hand[i].val) && this.hand[i].is_open) {
							index = i;
							break;
						}
					}
				} else {
					for (let i: number = this.hand.length - 1; i >= 0; i--) {
						if (amulet.MJPai.isSame(pai, this.hand[i].val) && this.hand[i].is_open) {
							index = i;
							break;
						}
					}
				}

			}
			if (index == -1) {
				if (tile_state == -1 || tile_state == 0) {
					if (!moqie) {
						for (let i: number = 0; i < this.hand.length; i++) {
							if (amulet.MJPai.isSame(pai, this.hand[i].val) && !this.hand[i].is_open) {
								index = i;
								break;
							}
						}
					} else {
						for (let i: number = this.hand.length - 1; i >= 0; i--) {
							if (amulet.MJPai.isSame(pai, this.hand[i].val) && !this.hand[i].is_open) {
								index = i;
								break;
							}
						}
					}
				}
			}

			if (index != -1) {
				var tmp = this.hand[index];
				for (let j: number = index; j < this.hand.length - 1; j++) {
					this.hand[j] = this.hand[j + 1];
					this.hand[j].SetIndex(j, false, true);
				}
				this.hand.pop();

				this._OnRemovePai(tmp);
				tmp.Reset();
				this.handpool.push(tmp);
				return true;
			}
			return false;
		}

		public Reset() {
			this.desktop.effectLock.active = false;
			this.mingIdsList = [];
			this.duringShowDetla = false;
			this.containerMing.Reset();
			this.containerDesktopCards.Reset();
			this.pai_xuezhan_mid_zimo = null;
			if (this.hand3d) this.hand3d.active = false;
			Laya.timer.clearAll(this);
			this.anim_id = 0;
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].Reset();
				this.handpool.push(this.hand[i]);
			}
			this.hand = [];
			this.zd = 0;
			this.chooseState = EAmuletChoooseState.none;
			this.last_tile = null;
			this.can_discard = false;
			this._choose_pai = null;
			this._mouse_in_pai = null;
			this.resetMouseState();
			Laya.timer.clearAll(this);
		}

		public Clear() {
			this.desktop.effectLock.active = false;
			this.mingIdsList = [];
			this.duringShowDetla = false;
			this.containerMing.Clear();
			this.containerDesktopCards.Clear();
			this.pai_xuezhan_mid_zimo = null;
			if (this.hand3d) this.hand3d.active = false;
			Laya.timer.clearAll(this);
			this.anim_id = 0;
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].Reset();
				this.handpool.push(this.hand[i]);
			}
			this.hand = [];
			this.zd = 0;
			this.chooseState = EAmuletChoooseState.none;
			this.last_tile = null;
			this.can_discard = false;
			this._choose_pai = null;
			this._mouse_in_pai = null;
			this.resetMouseState();
			Laya.timer.clearAll(this);
		}

		public NewGame(hand: Array<amulet.MJPai>, opened_tiles: Array<string>, opened_counts: Array<number>, fast: boolean): void {
			this.Reset();
			let _hand: Array<{ pai: amulet.MJPai, is_open: boolean }> = [];
			let open_map: Object = {};
			for (let i: number = 0; i < opened_tiles.length; i++) {
				open_map[opened_tiles[i]] = opened_counts[i];
			}
			for (let i: number = 0; i < hand.length; i++) {
				let p: any = {};
				p.pai = hand[i];
				let s_pai: string = hand[i].toString();
				if (open_map[s_pai]) {
					open_map[s_pai]--;
					p.is_open = true;
				} else {
					p.is_open = false;
				}
				_hand.push(p);
			}

			if (!fast) {
				let current_num: number = 0;
				for (let i: number = 0; i < 4; i++) {
					Laya.timer.once(i * 300, this, () => {
						for (let j: number = 0; j < 4; j++) {
							if (current_num >= _hand.length) break;
							current_num++;
							let p = this._AddHandPai(_hand[current_num - 1].pai, _hand[current_num - 1].is_open);
							p.SetIndex(current_num - 1, false, false);
							p.AnimNewTile();
						}
						view.AudioMgr.PlayAudio(216);
					});
				}
				Laya.timer.once(1200, this, () => {
					this.LiPai();
					this.last_tile = this.hand[this.hand.length - 1];
					if (this.hand.length == 14) this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
					this.pendingXiangGong(false, 'NewGame');
				});
			} else {
				_hand = _hand.sort((a, b) => {
					let a_val: number = (a.pai.numValue() * 10 + (a.pai.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.pai.touming ? 1 : 0);
					let b_val: number = (b.pai.numValue() * 10 + (b.pai.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.pai.touming ? 1 : 0);
					return a_val - b_val;
				});
				for (let i: number = 0; i < _hand.length; i++) {
					let p = this._AddHandPai(_hand[i].pai, _hand[i].is_open);
					p.SetIndex(i, i == 14, false);
				}
				this.last_tile = this.hand[this.hand.length - 1];
				// this.pendingXiangGong(false, 'ContinueGame');
			}

			Laya.timer.frameLoop(1, this, this.update);
		}

		public RecordNewGame(hand: Array<amulet.MJPai>, opened_tiles: Array<string>, opened_counts: Array<number>): void {
			this.Reset();
			let _hand: Array<{ pai: amulet.MJPai, is_open: boolean }> = []
			let open_map: Object = {};
			for (let i: number = 0; i < opened_tiles.length; i++) {
				open_map[opened_tiles[i]] = opened_counts[i];
			}
			for (let i: number = 0; i < hand.length; i++) {
				let p: any = {};
				p.pai = hand[i];
				let s_pai: string = hand[i].toString();
				if (open_map[s_pai]) {
					open_map[s_pai]--;
					p.is_open = true;
				} else {
					p.is_open = false;
				}
				_hand.push(p);
			}
			_hand = _hand.sort((a, b) => {
				let a_val: number = (a.pai.numValue() * 10 + (a.pai.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.pai.touming ? 1 : 0);
				let b_val: number = (b.pai.numValue() * 10 + (b.pai.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.pai.touming ? 1 : 0);
				return a_val - b_val;
			});

			for (let i: number = 0; i < _hand.length; i++) {
				let p = this._AddHandPai(_hand[i].pai, _hand[i].is_open);
				p.SetIndex(i, i == 13, false);
			}
			Laya.timer.frameLoop(1, this, this.update);
		}

		public TakePai(pai: amulet.MJPai, is_open: boolean, doanim: boolean = true): void {
			// app.Log.log('ViewPlayer_Me TakePai ' + pai.toString() + ' doanim:' + doanim);
			try {
				let p = this._AddHandPai(pai, is_open);
				p.SetIndex(this.hand.length - 1, true, false);
				if (doanim) p.AnimNewTile();
				this.last_tile = p;
				this.pendingXiangGong(true, 'TakePai');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'TakePai';
				_errorinfo['name'] = 'ViewPlayer_Me';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
			// app.Log.log('ViewPlayer_Me TakePai end');
		}

		public AddHand(pai: amulet.MJPai, fast: boolean = false) {
			let new_tiles: Array<HandPaiPlane> = [];
			let p: HandPaiPlane = this._AddHandPai(pai, false);
			p.AnimNewTile();
			new_tiles.push(p);
			this.LiPai(true, true);
			if (this.hand.length == 14) {
				this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
			}
			this.last_tile = this.hand[this.hand.length - 1];
		}

		public OnDiscardTile(pai: amulet.MJPai, is_open: boolean, fast: boolean, moqie: boolean = true): void {
			// app.Log.log('ViewPlayer_Me OnDiscardTile ' + pai.toString() + ' fast:' + fast);
			try {
				this._RemoveHandPai(pai, 0, moqie);
				this.LiPai(fast);
				this.last_tile = null;
				this.pendingXiangGong(false, 'OnDiscardTile');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'OnDiscardTile';
				_errorinfo['name'] = 'ViewPlayer_Me OnDiscardTile';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		//理牌
		public LiPai(fast: boolean = false, lipaichange = false, force: boolean = false): void {
			if (!lipaichange) {
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].SelectEnd();
				}
			}
			if (!this.desktop.autoLiqi && !force) return;
			this.hand.sort(HandPaiPlane.Cmp);
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].SetIndex(i, false, !fast);
			}
		}

		//副露
		public AddMing(ming: amulet.MJMing, doanim: boolean = true): void {
			// app.Log.log('ViewPlayer_Me AddMing ' + ming.toString() + ' doanim:' + doanim);
			for (let i: number = 0; i < ming.pais.length; i++) {
				this._RemoveHandPai(ming.pais[i], -1);
				this.mingIdsList.push(ming.pais[i].id);
			}
			this.containerMing.AddMing(ming, doanim);
			this.LiPai();
			this.last_tile = null;
		}


		public OnDoraRefresh(): void {
			this.containerDesktopCards.OnDoraRefresh();
			this.containerMing.OnDoraRefresh();
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].RefreshDora();
			}
		}

		public OnTianRefresh(): void {
			this.containerDesktopCards.OnTianRefresh();
			this.containerMing.OnTianRefresh();
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].RefreshTian();
			}
		}


		private isTileChoosed(tile: HandPaiPlane): boolean {
			if (this.chooseState == EAmuletChoooseState.none) return false;
			const choosedIds = AmuletDesktopMgr.Inst.choosedReplacePaiIds;
			if (choosedIds.indexOf(tile.val.id) != -1) return true;
			return false;
		}

		// 进入选牌
		public startExchangeHands() {
			this.resetMouseState();
			this.chooseState = EAmuletChoooseState.choosing;
			AmuletDesktopMgr.Inst.RemoveAllChoosedReplacePais();
			this.onHuanPai();
			this.can_discard = false;
		}

		// 退出选牌
		public endExchangeHands() {
			AmuletDesktopMgr.Inst.RemoveAllChoosedReplacePais();
			this.resetMouseState();
			this.chooseState = EAmuletChoooseState.none;
			for (let i: number = 0; i < this.hand.length; i++) {
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = 0;
				this.hand[i].mySelf.transform.localPosition = pos;
				this.hand[i].SelectEnd();
			}
		}


		// 换三张-删除手牌
		public onHuanPai_Remove(out_tiles: Array<amulet.MJPai>, fast: boolean = false) {
			for (let i: number = 0; i < out_tiles.length; i++) {
				if (!this._RemoveHandPai(out_tiles[i], 0)) {
					// app.Log.log('onHuanPai 无法删除手牌：' + out_tiles[i] + ', state:' + 0);
				}
			}
			this.LiPai(fast);
			for (let i: number = 0; i < this.hand.length; i++) {
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = 0;
				this.hand[i].mySelf.transform.localPosition = pos;
			}
		}

		// 换三张-接到牌
		public onHuanPai_Add(in_tiles: Array<amulet.MJPai>, fast: boolean = false) {
			let new_tiles: Array<HandPaiPlane> = [];
			for (let i: number = 0; i < in_tiles.length; i++) {
				let p: HandPaiPlane = this._AddHandPai(in_tiles[i], false);
				new_tiles.push(p);
			}
			this.LiPai(true, true, true);
			this.pendingXiangGong(false, 'onHuanPai_Add');
			if (this.hand.length == 14) {
				this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
			}
			if (!fast) {
				for (let i: number = 0; i < new_tiles.length; i++) {
					new_tiles[i].AnimHuanPai();
				}
			}
			this.last_tile = this.hand[this.hand.length - 1];
		}

		public DoDiscardTile(pai: HandPaiPlane): void {
			let param: game.IReqAmuletActivityOperate = {
				activity_id: AmuletDesktopMgr.activityId,
				type: this.can_discard ? EAmuletPlayOperation.discard : EAmuletPlayOperation.forceDiscard,
				tile_list: [pai.val.id]
			}
			this.desktop.DoAmuletGameAction(EAmuletGameAction.DoOperation, param);
			pai.mySelf.active = false;
			this.can_discard = false;
			this.RemoveRecommend();
		}

		public onDiscardSuccess(pai: amulet.MJPai, anim: boolean = false) {
			uiscript.UI_AmuletTingPai.Inst.onDiscardTile(pai);
			this.OnDiscardTile(pai, false, !anim);
		}

		//双击摸切
		public DiscardLastPai(force: boolean = false): boolean {
			if (!this.can_discard && !force) return;
			if (this.chooseState != EAmuletChoooseState.none) return;
			if (!this.last_tile) return;
			this.DoDiscardTile(this.last_tile);
			return true;
		}

		//============================鼠标操作=============================
		private setChoosePai(pai: HandPaiPlane, fromclick: boolean) {
			if (this._choose_pai === pai) return;
			if (this.chooseState == EAmuletChoooseState.choosing) {
				if (!pai.choosedEnabled) {
					this.click_on_choosed = false; // 取消选中状态，选中失败
					return;
				}
			}
			// if (amulet.AmuletDesktopMgr.Inst.timestoped) return;
			if (this._choose_pai && this._choose_pai != pai) {
				let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
				pos.y = this.isTileChoosed(this._choose_pai) ? 0.8 : 0;
				this._choose_pai.mySelf.transform.localPosition = pos;
				this._choose_pai = null;
			}

			if (pai.val.baida) {
				if (!this.desktop.autoLiqi) this._choose_pai = pai;  //百搭牌关闭理牌时可以拖动拖动
				AmuletDesktopMgr.Inst.setChoosedPai(null);
				return;
			}

			this._choose_pai = pai;
			let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
			pos.y = 0.8;
			this._choose_pai.mySelf.transform.localPosition = pos;
			if (fromclick) {
				pai.AddClickEffect(this.effect_click.clone());
			}
			if (this.chooseState != EAmuletChoooseState.choosing) {
				AmuletDesktopMgr.Inst.setChoosedPai(this._choose_pai.val);
			}
			view.AudioMgr.PlayAudio(204);
		}

		private resetMouseState() {
			this._mouse_in_pai = null;
			this.during_drag = false;
			this.mouse_downed = false;
			this.click_on_choosed = false;
			if (this._choose_pai) {
				let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
				pos.y = this.isTileChoosed(this._choose_pai) ? 0.8 : 0;
				this._choose_pai.mySelf.transform.localPosition = pos;
				this._choose_pai = null;
			}
			AmuletDesktopMgr.Inst.setChoosedPai(null);
		}

		private onMouseDown(): void {
			if (!this.needCheckMouse()) return;
			let mouse_info: IMouseInfo = this.getMouseInfo();
			if (mouse_info.pai) {
				if (this.chooseState != EAmuletChoooseState.none) {
					if (mouse_info.pai.valid && !mouse_info.pai.val.baida) {
						this.click_on_choosed = true;
						this.setChoosePai(mouse_info.pai, true);
					} else {
						// this.resetMouseState();
					}
				} else {
					// 普通状态下
					if (this._choose_pai === mouse_info.pai) {
						this.click_on_choosed = true;
					} else {
						this.setChoosePai(mouse_info.pai, true);
						this.click_on_choosed = false;
						this.click_choosed_time = Laya.timer.currTimer;
					}
				}
				this.mouse_downx = Laya.MouseManager.instance.mouseX;
				this.mouse_downy = Laya.MouseManager.instance.mouseY;
				this.mouse_downed = true;
			} else {
				this.resetMouseState();
			}
		}

		private onMouseMove(): void {
			if (!this.needCheckMouse()) return;
			if (this.chooseState != EAmuletChoooseState.none) return;
			if (this._choose_pai && this.mouse_downed) {
				let mx: number = Laya.MouseManager.instance.mouseX;
				let my: number = Laya.MouseManager.instance.mouseY;
				if ((mx - this.mouse_downx) * (mx - this.mouse_downx) + (my - this.mouse_downy) * (my - this.mouse_downy) > 400) {
					this.during_drag = true;
				}
			}
		}

		// 更换换三张的牌
		private ChangeChoosedTile(tile: HandPaiPlane) {
			if (this.chooseState != EAmuletChoooseState.choosing) return;
			let huan_index = AmuletDesktopMgr.Inst.choosedReplacePaiIds.indexOf(tile.val.id);
			if (huan_index < 0) {
				AmuletDesktopMgr.Inst.AddChoosedReplacePai(tile.val);
			} else {
				AmuletDesktopMgr.Inst.RemoveChoosedReplacePai(tile.val);
			}

			for (let i: number = 0; i < this.hand.length; i++) {
				let isin: boolean = this.isTileChoosed(this.hand[i]);
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = isin ? 0.8 : 0;
				this.hand[i].HuanpaiSelect(isin || AmuletDesktopMgr.Inst.choosedReplacePaiIds.length < this.desktop.maxChooseCount);
				this.hand[i].mySelf.transform.localPosition = pos;
			}
			this.onHuanPai();
		}

		public onHuanPai() {
			if (this.chooseState != EAmuletChoooseState.choosing) return;
			const choosedPais = AmuletDesktopMgr.Inst.choosedReplacePaiIds;
			for (let pai of this.hand) {
				pai.SetChooseEnable(!pai.val.baida && (choosedPais.length < this.desktop.maxChooseCount || choosedPais.indexOf(pai.val.id) != -1));
			}
		}

		private doChoosePaiAction(): void {
			if (this.chooseState != EAmuletChoooseState.none) {
				if (this.chooseState == EAmuletChoooseState.choosing) {
					this.ChangeChoosedTile(this._choose_pai);
					this.resetMouseState();
					return;
				}
			}
			if (this.can_discard) {
				if (view.DesktopMgr.click_prefer == 1) {
					uiscript.UI_AmuletDesktopInfo.Inst.recordDoubleClickTime(Laya.timer.currTimer - this.click_choosed_time);
				}
				this.DoDiscardTile(this._choose_pai);
				this.resetMouseState();
			} else {
				this.resetMouseState();
			}
		}

		private onMouseUp(): void {
			if (!this.needCheckMouse()) return;
			let mouse_info: IMouseInfo = this.getMouseInfo();
			this.mouse_downed = false;
			if (this.during_drag) {
				this.during_drag = false;
				if (this._choose_pai == null || mouse_info.inHandRange || !this._choose_pai.valid || this._choose_pai.val.baida) {
					this.resetMouseState();
				} else {
					this.doChoosePaiAction();
				}
			} else if (this.click_on_choosed) {
				if (this._choose_pai && this._choose_pai.valid && !this._choose_pai.val.baida) {
					this.doChoosePaiAction();
				}
			}
		}

		private needCheckMouse(): boolean {
			if (uiscript.UI_AmuletLevelResult.Inst.enable) return false;
			if (uiscript.UI_AmuletProp.Inst.isOpen) return false;
			if (uiscript.UI_AmuletCardLibrary.Inst.enable) return false;
			if (uiscript.UI_AmuletLeveList.Inst.enable) return false;
			if (amulet.AmuletDesktopMgr.Inst.locking) return false;
			if (amulet.AmuletDesktopMgr.Inst.duringHuPai) return false;
			if (amulet.AmuletDesktopMgr.Inst.duringPropEffect) return false;
			return true;
		}
		public onMouseOut(): void {
			this.mouse_downed = false;
			this.click_on_choosed = false;
			if (this.during_drag) {
				this.during_drag = false;
				this.resetMouseState();
			}
		}

		private readonly screen_left: number = -7.2;
		private readonly screen_right: number = 44.4;
		private readonly screen_top: number = 16.6;
		private readonly screen_bottom: number = -1.4;
		private readonly handrange_top: number = 2.5;
		private readonly handorigin_x: number = 0;
		private readonly handwidth: number = 2.55;

		private getMouseInfo(): IMouseInfo {
			let mouseX: number = Laya.MouseManager.instance.mouseX;
			let mouseY: number = Laya.MouseManager.instance.mouseY;
			let w_offset: number = 0;
			let h_offset: number = 0;
			if (Laya.Browser.width / 1920 < Laya.Browser.height / 1080) {
				h_offset = (Laya.Browser.height - Laya.Browser.width / 1920 * 1080) / 2;
			} else {
				w_offset = (Laya.Browser.width - Laya.Browser.height / 1080 * 1920) / 2;
			}

			let x: number = mouseX / (Laya.Browser.width - w_offset * 2) * (this.screen_right - this.screen_left) + this.screen_left;
			let y: number = mouseY / (Laya.Browser.height - h_offset * 2) * (this.screen_bottom - this.screen_top) + this.screen_top;
			let index: number = Math.floor((x - this.handorigin_x) / this.handwidth);
			if (index < 0) index = 0;
			if (index >= this.hand.length) index = this.hand.length - 1;

			let pai: HandPaiPlane = null;
			let pai3DId: number = -1;
			let camera: Laya.Camera = game.Scene_Amulet.Inst.camera_hand;
			let cameraPai: Laya.Camera = game.Scene_Amulet.Inst.cameraPai;
			//画参考线
			//根据鼠标屏幕2D座标修改生成射线数据 
			camera.viewportPointToRay(new Laya.Vector2(mouseX, mouseY), this.ray);
			//射线检测，最近物体碰撞器信息，最大检测距离为300米，默认检测第0层
			Laya.Physics.rayCast(this.ray, this.rayCastHit, 300);
			//如果碰撞信息中的模型不为空,删除模型
			if (this.rayCastHit.sprite3D) {
				pai = this.rayCastHit.sprite3D.getComponentByType(HandPaiPlane) as HandPaiPlane;
			}
			return {
				inHandRange: y < this.handrange_top,
				index: index,
				x: x,
				y: y,
				pai: pai,
			}
		}

		private update(): void {
			let mouse_info: IMouseInfo = this.getMouseInfo();
			if (this.during_drag) {
				if (this._choose_pai == null) {
					this.resetMouseState();
				} else {
					if (!amulet.AmuletDesktopMgr.Inst.autoLiqi && mouse_info.inHandRange && mouse_info.index != this._choose_pai.index) {
						if (mouse_info.index < this._choose_pai.index) {
							for (let i: number = mouse_info.index; i < this._choose_pai.index; i++) {
								this.hand[i].SetIndex(i + 1, false, true);
							}
							for (let i: number = this._choose_pai.index; i > mouse_info.index; i--) {
								this.hand[i] = this.hand[i - 1];
								this.hand[i].SetIndex(i, false, true);
							}
						} else {
							for (let i: number = this._choose_pai.index; i < mouse_info.index; i++) {
								this.hand[i] = this.hand[i + 1];
								this.hand[i].SetIndex(i, false, true);
							}
						}
						this.hand[mouse_info.index] = this._choose_pai;
						this._choose_pai.SetIndex(mouse_info.index, false, true);
					}
					this._choose_pai.mySelf.parent.setChildIndex(this._choose_pai.mySelf, this._choose_pai.mySelf.parent.numChildren - 1);
					this._choose_pai.mySelf.transform.localPosition = new Laya.Vector3(mouse_info.x, mouse_info.y, 0.5);
				}
			} else if (!this.mouse_downed) {
				if (this.chooseState != EAmuletChoooseState.none) return;
				if (uiscript.UI_AmuletLevelResult.Inst.enable) return;
				if (Laya.Browser.onPC && view.DesktopMgr.click_prefer == 0) {
					if (mouse_info.pai == null) {
						this.resetMouseState();
					} else {
						if (this._mouse_in_pai && this._mouse_in_pai === mouse_info.pai) {
							let t: number = Laya.timer.currTimer - this._mouse_in_start_time;
							if (t > 10) {
								this.setChoosePai(this._mouse_in_pai, false);
								this._mouse_in_pai = null;
							}
						} else {
							this._mouse_in_pai = mouse_info.pai;
							this._mouse_in_start_time = Laya.timer.currTimer;
						}
					}
				}
			}
		}

		public refreshGapType() {
			for (let i = 0; i < this.hand.length; i++) {
				this.hand[i].OnChoosedPai();
			}
		}

		public InitDesktopPais(pai: amulet.MJPai[], lockTiles: number[], doanim: boolean = true): void {
			this.containerDesktopCards.Reset();
			pai.forEach((pai, index) => {
				this.containerDesktopCards.AddDesktopPai(pai, index, doanim);
			})
			this.RefreshLockedTiles(lockTiles);
		}

		public RefreshLockedTiles(lockTiles: number[]) {
			let lockedTiles = lockTiles || [];
			let effectLock = this.desktop.effectLock;
			effectLock.active = false;
			if (lockedTiles.length == 0 || !effectLock || !effectLock.getChildAt(0) || effectLock.getChildAt(0).numChildren != 4) {
				return;
			}
			effectLock.active = true;
			let anim = (effectLock.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			anim.Play(null);
			for (let i = 1; i <= 4; i++) {
				let line = effectLock.getChildAt(0).getChildAt(4 - i) as Laya.MeshSprite3D;
				line.active = Math.ceil(lockedTiles.length / 9) >= i;
				if (line.active) {
					let mat: Laya.BaseMaterial = line.meshRender.material as Laya.BaseMaterial;
					let allLocked = Math.floor(lockedTiles.length / 9) >= i;
					mat['_MaskTex_ST'] = allLocked ? new Laya.Vector4(1, 1, -0.8807, 0) : new Laya.Vector4(1, 1, 0.1157 - 0.1107 * (lockedTiles.length % 9), 0);
				}
			}
			this.containerDesktopCards.RefreshLockedTiles(lockTiles);
		}

		public RemoveDesktopLastPai() {
			this.containerDesktopCards.RemoveLastPai();
		}

		public OpenDesktopLastPai(tile: MJPai) {
			this.containerDesktopCards.OpenLastPai(tile);
		}

		public PutDownDesktopPai() {
			this.containerDesktopCards.paiMoveDown();
		}

		public DoDesktopPaiRon() {
			this.containerDesktopCards.desktopPaiRon();
		}

		public OnChoosePai(): void {
			this.containerDesktopCards.OnChoosedPai();
			this.containerMing.OnChoosedPai();
		}

		/**  把所有打开的牌关上 */
		public CloseAllDesktopPai(doAnim: boolean = true) {
			this.containerDesktopCards.CloseAllDesktopPai(doAnim);
			this.desktop.effectLock.active = false;
		}

		public onInitRoom() {
			this.create_hand();
		}

		public create_hand() {
			this.animHands = [];
			if (this.handModels) {
				for (let i: number = 0; i < this.handModels.length; i++) {
					this.handModels[i].destroy(true);
				}
				this.handModels = [];
			}

			let _path: string = 'scene/' + this.hand_type + '.lh';
			let _handls: Laya.Sprite3D = Laya.loader.getRes(_path) as Laya.Sprite3D;
			if (_handls.getChildAt(0).getChildByName('node_liqibang').getChildByName('p')) {
				(_handls.getChildAt(0).getChildByName('node_liqibang').getChildByName('p') as Laya.Sprite3D).destroy(true);
			}
			if (_handls.getChildAt(0).getChildByName('node_tile').getChildByName('p')) {
				(_handls.getChildAt(0).getChildByName('node_tile').getChildByName('p') as Laya.Sprite3D).destroy(true);
			}
			if (_handls.getChildAt(0).getChildByName('Dum_Shadow')) {
				(_handls.getChildAt(0).getChildByName('Dum_Shadow') as Laya.Sprite3D).destroy(true);
			}

			let _hand: Laya.Sprite3D = (_handls.getChildAt(0) as Laya.Sprite3D).clone();

			this.hand3d.addChild(_hand);
			_hand.transform.localPosition = new Laya.Vector3(0, 0, 0);
			_hand.transform.localScale = new Laya.Vector3(0.9, 0.9, 0.9);
			_hand.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
			this.animHands = [_hand.getComponentByType(Laya.Animator) as Laya.Animator];
			this.handModels = [_hand];
			{
				let handmesh: Laya.SkinnedMeshSprite3D = _hand.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
				handmesh.active = false;
			}
			{
				let hand2: Laya.Sprite3D = _hand.clone();
				(hand2.getChildByName('node_liqibang') as Laya.Sprite3D).destroy(true);
				(hand2.getChildByName('node_tile') as Laya.Sprite3D).destroy(true);
				if (hand2.getChildByName('Bone021')) {
					(hand2.getChildByName('Bone021') as Laya.Sprite3D).destroy(true);
				}
				_hand.addChild(hand2);
				hand2.transform.localPosition = new Laya.Vector3(0, 0, 0);
				hand2.transform.localScale = new Laya.Vector3(1, 1, 1);
				hand2.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
				let _handmesh: Laya.SkinnedMeshSprite3D = hand2.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
				_handmesh.active = false;
				this.animHands.push(hand2.getComponentByType(Laya.Animator) as Laya.Animator);
				this.handModels.push(hand2);
			}
			this.hand3d.active = false;
			this.hand3d.transform.position = new Laya.Vector3(0, 0, 0);
		}

		public playHandAnimtion(anim: iModelAnimation) {
			this.hand3d.active = true;
			for (let i: number = 0; i < this.animHands.length; i++) {
				this.animHands[i].play(anim.name, anim.speed);
			}
			this.hand3d.transform.localScale = new Laya.Vector3(0.0001, 0.0001, 1);
			Laya.timer.frameOnce(1, this, () => {
				this.hand3d.transform.localScale = new Laya.Vector3(1, 1, 1);
			});
			this.anim_id++;
			let anim_id: number = this.anim_id;
			Laya.timer.once(anim.lifetime, this, () => {
				if (anim_id == this.anim_id) {
					this.hand3d.active = false;
				}
			});
		}

		public InitGangList(ming_list: game.IAmuletMingInfo[]) {
			this.mingIdsList = [];
			this.containerMing.Reset();
			if (!ming_list || ming_list.length == 0) return;
			ming_list.forEach((mingInfo, index) => {
				let ming: amulet.MJMing = new amulet.MJMing();
				ming.type = mingInfo.type;
				let ret = [];
				for (let i: number = 0; i < 4; i++) {
					let _p: amulet.MJPai = this.desktop.getDisplayMJPaiById(mingInfo.tile_list[i]);
					ret.push(_p);
				}
				ming.pais = ret;
				this.AddMing(ming, false);
			})
		}


		OnPaiDisplayMapChanged(changeId: number[]) {
			// 目前弃用，往生说3D牌不需要变牌
			// this.containerDesktopCards.OnPaiDisplayMapChanged(changeId);
			// this.containerMing.OnPaiDisplayMapChanged(changeId);
			for (let i: number = 0; i < this.hand.length; i++) {
				if (changeId.indexOf(this.hand[i].val.id) != -1) {
					let newMJ = this.desktop.getDisplayMJPaiById(this.hand[i].val.id);
					this.hand[i].ChangeVal(newMJ);
				}
			}
		}

		public PlayGangSound(): void {
			uiscript.UI_AmuletDesktopInfo.Inst.shout();
			view.AudioMgr.PlayCharactorSound(uiscript.UI_Sushe.main_chara_info, 'gang');
		}

		public RefreshRecommend() {
			const ting_list = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.ting_list || [];
			for (let i: number = 0; i < this.hand.length; i++) {
				let canTing = false;
				for (let j: number = 0; j < ting_list.length; j++) {
					if (ting_list[j].tile) {
						let pai = amulet.MJPai.Create({ id: -1, tile: ting_list[j].tile })
						if (amulet.MJPai.Distance(pai, this.hand[i].val) == 0) {
							canTing = true;
							this.hand[i].AddRecommendTag();
							break;
						}
					}
				}
				if (!canTing) this.hand[i].RemoveRecommendTag();
			}
		}

		public RemoveRecommend() {
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].RemoveRecommendTag();
			}
		}

		public isPaiInHand(id: number): boolean {
			for (let i: number = 0; i < this.hand.length; i++) {
				if (this.hand[i].val.id == id) return true;
			}
			return false;
		}

		private pendingXiangGong(need_discard: boolean, from: string) {
			if (this.xianggonged) return;
			let ming_count: number = this.containerMing.mings.length;
			let tile_count: number = 13 - ming_count * 3;
			if (need_discard) tile_count++;

			let index_error: boolean = false;
			for (let i: number = 0; i < this.hand.length; i++) {
				if (this.hand[i].index != i) {
					index_error = true;
					break;
				}
			}
			let hands: string = '';
			for (let i: number = 0; i < this.hand.length; i++) {
				if (i != 0) hands += ', ';
				hands += '[' + i + '|' + this.hand[i].index + ']' + ' id = ' + this.hand[i].val.id + ' value = ' + this.hand[i].val.toString();
			}

			// app.Log.log('hands: ' + hands);
			// app.Log.log('paiku: ' + JSON.stringify(amulet.AmuletDesktopMgr.Inst.amuletGameData.round.pool));

			if (this.hand.length != tile_count || index_error || this.hand.length + this.handpool.length != 16) {
				//相公了
				this.xianggonged = true;
				let _info: Object = {};
				_info['from'] = from;
				_info['need_discard'] = need_discard;
				_info['ming_count'] = this.containerMing.mings.length;
				_info['tile_count'] = tile_count;
				_info['hand_length'] = this.hand.length;
				_info['index_error'] = index_error;
				_info['hands'] = hands;
				_info['handpool_count'] = this.handpool.length;
				GameMgr.Inst.onAmuletGameHandsError(_info);
			}
		}


		public addOpenTiles(tileIds: number[], doAnim: boolean = false) {
			for (let i = 0; i < tileIds.length; i++) {
				let pai = this.desktop.amuletGameData.round.show_desktop_tiles.find(tile => tile.id == tileIds[i]);
				if (pai) {
					this.containerDesktopCards.OpenDesktopPai(pai.pos, this.desktop.getDisplayMJPaiById(pai.id), doAnim);
				}
			}
		}
	}
}