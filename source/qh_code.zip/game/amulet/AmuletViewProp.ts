/**
* name 
*/
module amulet {
	interface IMouseInfo {
		prop: AmuletPropPlane;
		pos: Laya.Vector3;
		mouseX: number;
		mouseY: number
	}
	export class AmuletViewProp extends Laya.Script {
		public static Inst: AmuletViewProp = null;

		/**用于鼠标检测的射线**/
		private ray: Laya.Ray;
		/**画矢量线的3D显示对象**/
		private phasorSprite3D: Laya.PhasorSpriter3D;
		/**碰撞信息**/
		private rayCastHits: Laya.RaycastHit[];
		private rayCastHit: Laya.RaycastHit;
		public desktop: AmuletDesktopMgr = null;
		private parent: Laya.Sprite3D;
		public containerProp: BlockProp;
		public touchProp: AmuletPropPlane = null;
		public dragProp: AmuletPropPlane = null;
		private mouse_downx: number = 0;
		private mouse_downy: number = 0;
		private mouse_downed: boolean = false;
		private duringDrag: boolean = false;
		private dragOffset: Laya.Vector3;

		constructor() {
			super();
			AmuletViewProp.Inst = this;
		}

		_load(parent: Laya.Sprite3D): void {
			this.desktop = AmuletDesktopMgr.Inst;
			this.parent = parent;
			this.containerProp = new BlockProp(parent.getChildByName('amulet') as Laya.Sprite3D, this);
			//创建一条射线
			this.ray = new Laya.Ray(new Laya.Vector3(), new Laya.Vector3());
			//创建矢量3D精灵
			this.phasorSprite3D = new Laya.PhasorSpriter3D();
			//创建碰撞信息
			this.rayCastHits = [];
			this.rayCastHit = new Laya.RaycastHit();
			//鼠标点击事件回调onMouseDown
			Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
			Laya.stage.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
			Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMouseMove);
			Laya.stage.on(Laya.Event.MOUSE_OUT, this, this.onMouseOut);
		}

		public Reset() {
			this.dragProp = null;
			this.touchProp = null;
			this.containerProp.Reset();
			this.resetMouseState();
			Laya.timer.clearAll(this);

		}

		public Clear() {
			this.dragProp = null;
			this.touchProp = null;
			this.containerProp.Clear();
			this.resetMouseState();
		}


		public onHupai() {
			this.resetMouseState();
			if (this.dragProp) {
				this.dragProp.setPropState(EAmuletEffectCardState.normal);
				this.dragProp = null;
				this.containerProp.ReOrderWithTrueData(true);
			}
			if (this.touchProp) {
				this.touchProp = null;
			}
		}

		private resetMouseState() {
			this.duringDrag = false;
			this.mouse_downed = false;
		}

		private getMouseInfo(): IMouseInfo {
			let mouseX: number = Laya.MouseManager.instance.mouseX;
			let mouseY: number = Laya.MouseManager.instance.mouseY;

			this.desktop.mainCamera.viewportPointToRay(new Laya.Vector2(mouseX, mouseY), this.ray);
			//射线检测，最近物体碰撞器信息，最大检测距离为300米，默认检测第0层
			Laya.Physics.rayCastAll(this.ray, this.rayCastHits, 3000);
			this.rayCastHits.sort((a, b) => a.distance - b.distance);
			let prop: AmuletPropPlane;
			let pos: Laya.Vector3;
			for (let i = 0; i < this.rayCastHits.length; i++) {
				let hit = this.rayCastHits[i];
				let hitGo = hit.sprite3D as Laya.MeshSprite3D;
				if (hitGo) {
					if (hitGo.name == 'desktop_bg') pos = hit.position;
					if (hitGo.name.indexOf('prop_bg') > -1 && !prop) {
						const plane = (hitGo.parent.parent.parent.parent.parent.parent as Laya.Sprite3D).getComponentByType(AmuletPropPlane) as AmuletPropPlane;
						if (plane) prop = plane;
					}
				}
			}
			return {
				prop: prop,
				pos: pos,
				mouseX: mouseX,
				mouseY: mouseY
			}
		}


		private onMouseDown(): void {
			if (!this.needCheckMouse()) return;
			let mouse_info: IMouseInfo = this.getMouseInfo();
			this.mouse_downed = true;
			if (mouse_info.prop) {
				// app.Log.log('onMouseDown set touchProp')
				this.touchProp = mouse_info.prop;
				this.mouse_downx = mouse_info.mouseX;
				this.mouse_downy = mouse_info.mouseY;
			}
		}

		private onMouseUp(): void {
			if (!this.needCheckMouse()) return;
			this.mouse_downed = false;
			if (this.duringDrag) {
				this.duringDrag = false;
				if (this.dragProp) {
					this.dragProp.setPropState(EAmuletEffectCardState.normal);
					this.dragProp = null;
					this.containerProp.onDragEnd();
				}
			} else {
				if (this.touchProp) {
					// app.Log.log('onMouseUp 有touchProp')
					this.touchProp.DoAmuletEffect(EPropEffectAniType.click);
					uiscript.UI_AmuletProp.Inst.showPropDetail(this.touchProp.val, uiscript.EAmuletPropState.normal)
				}
			}
			// app.Log.log('onMouseUp touchProp = null')
			this.touchProp = null;
			this.resetMouseState();
		}

		_update(): void {
			let mouse_info: IMouseInfo = this.getMouseInfo();
			if (this.duringDrag) {
				if (this.touchProp == null) {
					// app.Log.log('touchProp null resetMouseState');
					this.resetMouseState();
				} else {
					let _pos = new Laya.Vector3(0, 0, 0);
					Laya.Vector3.add(mouse_info.pos, this.dragOffset, _pos)
					this.dragProp.transform.position = _pos;
					this.containerProp.onDragMove(this.dragProp);
				}
			}
		}


		private onMouseMove(): void {
			if (!this.needCheckMouse()) return;
			if (this.touchProp && this.mouse_downed && !this.duringDrag) {
				let mouse_info: IMouseInfo = this.getMouseInfo();
				//有一点移动就算移动
				if (Math.abs(mouse_info.mouseX - this.mouse_downx) > 2 || Math.abs(mouse_info.mouseY - this.mouse_downy) > 2) {
					// app.Log.log('开始拖拽');
					this.containerProp.onDragStart();
					this.duringDrag = true;
					this.dragProp = this.touchProp;
					this.dragProp.setPropState(EAmuletEffectCardState.duringDrag);
					this.dragProp.clearMove();
					let cardPos = this.dragProp.transform.position;
					let _pos = new Laya.Vector3(0, 0, 0);
					Laya.Vector3.subtract(cardPos, mouse_info.pos, _pos);
					this.dragOffset = _pos;
				}
			}
		}


		private needCheckMouse(): boolean {
			if (uiscript.UI_Amulet_Debug && uiscript.UI_Amulet_Debug.Inst && uiscript.UI_Amulet_Debug.Inst.meUI.root.visible) return false;
			if (uiscript.UI_AmuletDesktopInfo.Inst.aniLock) return false;
			if (uiscript.UI_AmuletShop.Inst.locking) return false;
			if (uiscript.UI_AmuletGameResult.Inst.enable) return false;
			if (uiscript.UI_AmuletProp.Inst.isOpen) return false;
			if (uiscript.UI_AmuletCardLibrary.Inst.enable) return false;
			if (uiscript.UI_AmuletLeveList.Inst.enable) return false;
			if (uiscript.UI_AmuletLevelResult.Inst.enable) return false;
			if (uiscript.UI_PropDetailPopup.opening) return false;
			if (amulet.AmuletDesktopMgr.Inst.locking) return false;
			if (amulet.AmuletDesktopMgr.Inst.duringHuPai) return false;
			if (amulet.AmuletDesktopMgr.Inst.duringPropEffect) return false;
			return true;
		}
		public onMouseOut(): void {
			if (!this.needCheckMouse()) return;
			this.mouse_downed = false;
			if (this.duringDrag) {
				this.duringDrag = false;
				if (this.dragProp) {
					this.dragProp.setPropState(EAmuletEffectCardState.normal);
					this.dragProp = null;
					this.containerProp.onDragEnd();
				}
			}
			this.touchProp = null;
			this.resetMouseState();
		}

		RemovePropById(id: number, doAnim: boolean = false) {
			this.containerProp.RemovePropById(id, doAnim);
		}

		DoPropEffectById(id: number, type: EPropEffectAniType) {
			this.containerProp.DoPropEffectById(id, type);
		}

		DoPropEffectByBadgeId(id: number, type: EPropEffectAniType) {
			this.containerProp.DoPropEffectByBadgeId(id, type);
		}

		addNewProp(val: amulet.PropCard, doAnim: boolean = false) {
			if (doAnim) {
				Laya.timer.once(100, this, () => {
					view.AudioMgr.PlayAudio(10151);
				})
			}
			this.containerProp.addNewProp(val, doAnim);
		}

		isPropAlreadyHaveByUId(uid: number): PropCard {
			for (let i: number = 0; i < this.containerProp.props.length; i++) {
				if (this.containerProp.props[i].val.id == uid) {
					return this.containerProp.props[i].val;
				}
			}
			return null;
		}

		refreshPropByMerged(val: amulet.PropCard, doAnim: boolean = true) {
			this.containerProp.refreshPropByMerged(val, doAnim);
		}

		refreshPropBadge(val: amulet.PropCard, doAnim: boolean) {
			this.containerProp.refreshPropBadge(val, doAnim);
		}

		refreshPropUnstable(val: amulet.PropCard, doAnim: boolean) {
			this.containerProp.refreshPropUnstable(val, doAnim);
		}

		public test() {
			this.containerProp.addNewProp(amulet.PropCard.CreateProp({ id: 10, store: [], uid: 10 }));
			this.containerProp.addNewProp(amulet.PropCard.CreateProp({ id: 20, store: [], uid: 20 }));
			this.containerProp.addNewProp(amulet.PropCard.CreateProp({ id: 30, store: [], uid: 30 }));
			this.containerProp.addNewProp(amulet.PropCard.CreateProp({ id: 40, store: [], uid: 40 }));
		}

	}
}