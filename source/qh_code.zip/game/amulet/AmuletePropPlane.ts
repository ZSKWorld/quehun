/**
* name 
*/
module amulet {
	//现在没有hover的漂浮状态，直接打开详情弹窗
	export enum EAmuletEffectCardState {
		duringDrag,
		hover,
		normal
	}

	export enum EPropEffectAniType {
		takeEffect = 'fx_qingyun_kapai_chufa',
		levelUp = 'fx_qingyun_kapai_hebing_1',
		get = 'fx_qingyun_kapai_hebing_2',
		sell = 'fx_qingyun_kapai_sell',
		idle = 'fx_qingyun_kapai_idle',
		click = 'fx_qingyun_kapai_click',
		changeBig = 'fx_qingyun_kapai_getbig',
		propMergeChangeSmall = 'fx_qingyun_kapai_getsmall', //替换卡导致变小
		loseBagdeChangeSmall = 'fx_qingyun_kapai_getsmall_die', //印章消失导致变小
		changeBadgeChangeSmall = 'fx_qingyun_kapai_getsmall_sub', //替换了印章导致变小
		getBadge = 'fx_qingyun_kapai_seal',
		loseBadge = 'fx_qingyun_kapai_seal_die',
		valueUp = 'fx_qingyun_kapai_up',
		unstable = 'fx_qingyun_kapai_wenhao',
		none = ''
	}

	const COLOR_BLUE: Laya.Vector4 = new Laya.Vector4(0.2667, 0.541, 0.6235, 1);
	const COLOR_GREEN: Laya.Vector4 = new Laya.Vector4(0.25, 0.5765, 0.2353, 1);
	const COLOR_YELLOW: Laya.Vector4 = new Laya.Vector4(0.631, 0.4196, 0.349, 1);
	const COLOR_PURPLE: Laya.Vector4 = new Laya.Vector4(0.396, 0.333, 0.612, 1);
	const COLOROUTLINE: Laya.Vector4[] = [COLOR_PURPLE, COLOR_YELLOW, COLOR_BLUE, COLOR_GREEN];
	export class AmuletPropPlane extends game.Moveable {

		public static Cmp(a: AmuletPropPlane, b: AmuletPropPlane): number {
			return a.index - b.index;
		}

		public val: amulet.PropCard;
		public effectCard: Laya.Sprite3D = null;
		private meshPlus: Laya.MeshSprite3D = null;
		private meshAniPlus: Laya.MeshSprite3D = null;
		private meshBg: Laya.MeshSprite3D;
		private meshIcon: Laya.MeshSprite3D;
		private meshAniBg: Laya.MeshSprite3D;
		private meshAniIcon: Laya.MeshSprite3D;
		private meshOutline: Laya.MeshSprite3D = null;
		private meshAniOutline: Laya.MeshSprite3D = null;
		public effectAniCard: Laya.Sprite3D = null;
		public meshBadge: Laya.MeshSprite3D = null;
		public meshBadge2: Laya.MeshSprite3D = null;
		public meshAniBadge: Laya.MeshSprite3D = null;
		public state: EAmuletEffectCardState;
		public index: number;
		private anim: Catfood.CAnimator;
		private effectTakeEffect: Laya.Sprite3D;
		private effectLevelChange: Laya.Sprite3D;
		private effectUp: Laya.Sprite3D;
		private effectQuestion: Laya.Sprite3D;
		private effectQuestionSus: Laya.Sprite3D;
		private effectBadge: Laya.Sprite3D;

		constructor() {
			super();
		}

		get transform() {
			return this.owner.transform;
		}

		set active(active: boolean) {
			this.owner.active = active;
		}

		public _load(): void {
			this.owner.transform.localScale = new Laya.Vector3(0.98, 0.98, 0.98);
			let comRootProp = this.owner.getChildByName('animation').getChildByName('rotation').getChildByName('gaodu').getChildByName('1') as Laya.Sprite3D;
			this.effectCard = comRootProp.getChildByName('yushou') as Laya.Sprite3D;
			let comPartEffect = comRootProp.getChildByName('fx') as Laya.Sprite3D;
			this.meshBg = this.effectCard.getChildByName('prop_bg') as Laya.MeshSprite3D;
			this.meshIcon = this.effectCard.getChildByName('prop_icon') as Laya.MeshSprite3D;
			this.meshPlus = this.effectCard.getChildByName('up') as Laya.MeshSprite3D;
			this.meshBadge = this.effectCard.getChildByName('badge') as Laya.MeshSprite3D;
			this.meshBadge2 = this.effectCard.getChildByName('badge2') as Laya.MeshSprite3D;
			this.meshOutline = this.effectCard.getChildByName('outline') as Laya.MeshSprite3D;
			this.anim = (this.owner.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.anim.Stop();
			this.effectLevelChange = comPartEffect.getChildByName('01_1') as Laya.Sprite3D;
			this.effectTakeEffect = comPartEffect.getChildByName('chufa') as Laya.Sprite3D;
			this.effectUp = comPartEffect.getChildByName('up') as Laya.Sprite3D;
			this.effectQuestion = comPartEffect.getChildByName('wenhao') as Laya.Sprite3D;
			this.effectQuestionSus = comPartEffect.getChildByName('wenhao_sustain') as Laya.Sprite3D;
			this.effectBadge = comPartEffect.getChildByName('seal') as Laya.Sprite3D;
			this.effectAniCard = this.effectLevelChange.getChildByName('a').getChildByName('yushou') as Laya.Sprite3D;
			this.meshAniIcon = this.effectAniCard.getChildByName('prop_icon') as Laya.MeshSprite3D;
			this.meshAniBg = this.effectAniCard.getChildByName('prop_bg') as Laya.MeshSprite3D;
			this.meshAniPlus = this.effectAniCard.getChildByName('up') as Laya.MeshSprite3D;
			this.meshAniBadge = this.effectAniCard.getChildByName('badge') as Laya.MeshSprite3D;
			this.meshAniOutline = this.effectAniCard.getChildByName('outline') as Laya.MeshSprite3D;
			this.effectLevelChange.active = false;
			this.effectTakeEffect.active = false;
			this.effectUp.active = false;
			this.effectQuestion.active = false;
			this.effectQuestionSus.active = false;
			this.effectBadge.active = false;
		}

		public refreshBaned() {
			//禁止护身符的boss已经干掉了
		}

		public SetVal(value: amulet.PropCard) {
			this.val = value;
		}

		public RefreshCard(stopAnim: boolean = true) {
			let value = this.val.haveUnstable || this.val;
			// app.Log.log('刷新卡片 value =====' + JSON.stringify(value));
			this.owner.name = 'prop_' + value.id.toString();
			this.refreshBaned();
			let mat = this.meshIcon.meshRender.material as Laya.BaseMaterial;
			let mat2 = this.meshAniIcon.meshRender.material as Laya.BaseMaterial;
			const prop_path: string = 'scene/Assets/Resource/amulet/';
			let effectData = value.config;
			if (effectData) {
				let texture = prop_path + effectData.card_image + '.png';
				mat['_MainTex'] = Laya.loader.getRes(texture);
				mat2['_MainTex'] = Laya.loader.getRes(texture);
			}
			let matEffect1 = this.meshPlus.meshRender.material as Laya.StandardMaterial;
			let matEffect2 = this.meshAniPlus.meshRender.material as Laya.StandardMaterial;
			matEffect1.disableLight();
			matEffect1.diffuseTexture = Laya.loader.getRes('scene/Assets/Resource/amulet/plus.png');
			matEffect2.disableLight();
			matEffect2.diffuseTexture = Laya.loader.getRes('scene/Assets/Resource/amulet/plus.png');
			this.meshPlus.active = value.isPlus;
			this.meshAniPlus.active = value.isPlus;
			this.meshBadge.active = !!value.badgeConfig;
			this.meshBadge2.active = !!value.badgeConfig;
			this.meshAniBadge.active = !!value.badgeConfig;
			if (this.meshBadge.active) {
				let textureBadge = Laya.loader.getRes(prop_path + value.badgeConfig.badge_image + '.png');
				(this.meshBadge.meshRender.material as Laya.BaseMaterial)['_MainTex'] = textureBadge;
				(this.meshBadge2.meshRender.material as Laya.BaseMaterial)['_MainTex'] = textureBadge;
				(this.meshAniBadge.meshRender.material as Laya.BaseMaterial)['_MainTex'] = textureBadge;
			}
			(this.meshOutline.meshRender.material)['outlineColor'] = COLOROUTLINE[effectData.rarity - 1];
			(this.meshAniOutline.meshRender.material)['outlineColor'] = COLOROUTLINE[effectData.rarity - 1];
			let bgUrl = prop_path + (value.volume == 1 ? 'fu_bg' : 'fu_widen_bg');
			let textureBg = Laya.loader.getRes(bgUrl + effectData.rarity + '.jpg');
			(this.meshBg.meshRender.material as Laya.BaseMaterial)['_MainTex'] = textureBg;
			(this.meshAniBg.meshRender.material as Laya.BaseMaterial)['_MainTex'] = textureBg;
			this.effectQuestionSus.active = !!this.val.haveUnstable;
			if (stopAnim) {
				this.stopAnim();
			}
		}

		public stopAnim() {
			this.anim.Stop();
			this.DoAmuletEffect(EPropEffectAniType.idle);
			this.effectLevelChange.active = false;
			this.effectTakeEffect.active = false;
			this.effectUp.active = false;
			this.effectQuestion.active = false;
			this.effectBadge.active = false;
		}

		public RefreshAniCard(value: amulet.PropCard) {
			let mat2 = this.meshAniIcon.meshRender.material as Laya.BaseMaterial;
			const prop_path: string = 'scene/Assets/Resource/amulet/';
			let effectData = value.config;
			if (effectData) {
				let texture = prop_path + effectData.card_image + '.png';
				mat2['_MainTex'] = Laya.loader.getRes(texture);
			}
			let matEffect2 = this.meshAniPlus.meshRender.material as Laya.StandardMaterial;
			matEffect2.disableLight();
			matEffect2.diffuseTexture = Laya.loader.getRes('scene/Assets/Resource/amulet/plus.png');
			this.meshAniPlus.active = value.isPlus;
			this.meshAniBadge.active = !!value.badgeConfig;
			let bgUrl = prop_path + (value.volume == 1 ? 'fu_bg' : 'fu_widen_bg');
			(this.meshAniBg.meshRender.material as Laya.BaseMaterial)['_MainTex'] = Laya.loader.getRes(bgUrl + effectData.rarity + '.jpg');
			if (this.meshAniBadge.active) {
				(this.meshAniBadge.meshRender.material as Laya.BaseMaterial)['_MainTex'] = Laya.loader.getRes(prop_path + value.badgeConfig.badge_image + '.png');
			}
		}


		public setPropState(state: EAmuletEffectCardState, doAnim: boolean = false) {
			if (this.state == state) return;
			this.state = state;
			//选中也不上浮了只保留拖拽上浮
			const localPos = this.transform.localPosition.clone();
			let targetPos = state == EAmuletEffectCardState.duringDrag ? new Laya.Vector3(localPos.x, 0.022, localPos.z) : new Laya.Vector3(localPos.x, 0.0067, localPos.z);
			if (doAnim) {
				AmuletDesktopMgr.timer.clearAll(this);
				let start_time: number = AmuletDesktopMgr.timer.currTimer;
				AmuletDesktopMgr.timer.frameLoop(1, this, () => {
					let t: number = AmuletDesktopMgr.timer.currTimer - start_time;
					let rate: number = t / 1000;
					if (rate >= 1) {
						rate = 1;
					}
					rate = - rate * rate + 2 * rate;
					let originPos = this.transform.localPosition;
					let posY = (targetPos.y - originPos.y) * rate + originPos.y;
					this.transform.localPosition = new Laya.Vector3(originPos.x, posY, originPos.z);
					if (rate >= 1) {
						AmuletDesktopMgr.timer.clearAll(this);
					}
				});
			} else {
				this.transform.localPosition = targetPos;
			}
			if (state != EAmuletEffectCardState.duringDrag && this.meshIcon.meshRender.material.renderQueue > 3010) {
				this.dfsChangeMat(this.owner, -30);
			}
			if (state == EAmuletEffectCardState.duringDrag && this.meshIcon.meshRender.material.renderQueue < 3010) {
				this.dfsChangeMat(this.owner, 30);
			}
		}

		private dfsChangeMat(root: Laya.Sprite3D, changeValue: number) {
			if (root._childs && root._childs.length > 0) {
				for (let child of root._childs) {
					this.dfsChangeMat(child, changeValue);
				}
			}
			if ((root as Laya.MeshSprite3D).meshRender) {
				let materials = [];
				if ((root as Laya.MeshSprite3D).meshRender.materials && (root as Laya.MeshSprite3D).meshRender.materials.length > 0) {
					materials = (root as Laya.MeshSprite3D).meshRender.materials;
				}
				materials.forEach((material) => {
					let value = material.renderQueue;
					material.renderQueue = value + changeValue
				});
			}
		}


		public SetIndex(index: number): void {
			if (!this.owner) {
				app.Log.log('SetIndex index:' + index + ' model不存在');
			} else if (this.owner.destroyed) {
				app.Log.log('SetIndex index:' + index + ' model已经被删除');
			} else if (!this.owner.transform) {
				app.Log.log('SetIndex index:' + index + ' model.transform不存在');
			}
			this.index = index;
		}

		public DoAmuletEffect(type: EPropEffectAniType) {
			if (type == EPropEffectAniType.none) {
				this.stopAnim();
				return;
			}
			let typeStr = type.toString();
			let aniName = typeStr + (this.val.volume == 1 ? '' : '_big');
			if (type == EPropEffectAniType.takeEffect) {
				view.AudioMgr.PlayAudio(10163);
				this.effectTakeEffect.active = true;
				Laya.timer.once(333, this, () => {
					this.effectTakeEffect.active = false;
				})
			} else if (type == EPropEffectAniType.levelUp) {
				view.AudioMgr.PlayAudio(10163);
				this.effectAniCard.active = true;
				this.effectLevelChange.active = true;
				Laya.timer.once(440, this, () => {
					this.effectAniCard.active = false;
				});
				Laya.timer.once(1500, this, () => {
					this.effectLevelChange.active = false;
				});
			} else if (type == EPropEffectAniType.unstable) {
				view.AudioMgr.PlayAudio(10342);
				this.effectQuestion.active = true;
				Laya.timer.once(2000, this, () => {
					this.effectQuestion.active = false;
				})
			} else if (type == EPropEffectAniType.getBadge) {
				this.effectBadge.active = true;
				Laya.timer.once(333, this, () => {
					this.effectBadge.active = false;
				})
			} else if (type == EPropEffectAniType.sell || type == EPropEffectAniType.get || type == EPropEffectAniType.click || type == EPropEffectAniType.idle) { //分普通和big两个动画的
			} else if (type == EPropEffectAniType.changeBig) {
				aniName = typeStr;
				this.effectBadge.active = true;
				Laya.timer.once(333, this, () => {
					this.effectBadge.active = false;
				})
			} else {
				aniName = typeStr;
			}
			app.Log.log('播放护身符动画 aniName =====' + aniName);
			this.anim.Play(aniName);
		}
	}
}