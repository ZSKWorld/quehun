module amulet {
  export enum E_MJPai { p, m, s, z, bd };

  //麻将单牌
  export class MJPai {
    public index: number; //数字，如果是字牌的话就是东南西北白发中
    public type: E_MJPai; //类型：0.筒子,1.万字,2.条子 3.字牌，
    public dora: Boolean; //红朵拉
    public touming: boolean; // 透明牌
    public id: number = -1; // 牌id
    public isDoraOpen: boolean = true; //是不是已经翻开的dora，外dora一定为true，里dora胡牌后为true
    public baida: boolean; // 百搭牌

    public setDoraOpen(open: boolean) {
      this.isDoraOpen = open;
    }

    //是字牌
    public IsZ(): boolean {
      return this.type == E_MJPai.z;
    }

    //是老头牌
    public IsLaoTou(): boolean {
      return this.type != E_MJPai.z && (this.index == 1 || this.index == 9);
    }

    //是幺九牌
    public IsYao(): boolean {
      return this.IsZ() || this.IsLaoTou();
    }

    //是四喜牌
    public IsSiXi(): boolean {
      return this.IsZ() && this.index >= 1 && this.index <= 4;
    }

    //是三元牌
    public IsSanYan(): boolean {
      return this.IsZ() && this.index >= 5 && this.index <= 7;
    }

    public Clone(): MJPai {
      let ret: MJPai = new MJPai();
      ret.type = this.type;
      ret.index = this.index;
      ret.dora = this.dora;
      ret.id = this.id;
      ret.isDoraOpen = this.isDoraOpen;
      ret.baida = this.baida;
      return ret;
    }
    public numValue(): number {
      let v: number = 0;
      switch (this.type) {
        case E_MJPai.m: v = this.index; break;
        case E_MJPai.p: v = 10000 + this.index; break;
        case E_MJPai.s: v = 10000 * 2 + this.index; break;
        case E_MJPai.z: v = 10000 * 3 + this.index * 10; break;
      }
      return v;
    }

    public static Create(tile: game.IAmuletTile): MJPai {
      let str = tile.tile || '';
      let ret: MJPai = new MJPai();
      ret.id = tile.id || -1;
      if (str.charAt(0) == '0') {
        ret.dora = true;
        ret.index = 5;
      } else {
        ret.dora = false;
        ret.index = +str.charAt(0);
      }
      switch (str.charAt(1)) {
        case 'z': ret.type = E_MJPai.z; break;
        case 'm': ret.type = E_MJPai.m; break;
        case 's': ret.type = E_MJPai.s; break;
        case 'p': ret.type = E_MJPai.p; break;
      }

      ret.touming = str.length > 2;

      ret.baida = str == 'bd';
      str == 'bd' && (ret.type = E_MJPai.bd);

      return ret;
    }

    //随机创造一个，测试方便
    public static RandomCreate(): MJPai {
      let p: MJPai = new MJPai();
      let tr: number = Math.random();
      if (tr < 0.22) {
        p.type = E_MJPai.z;
        p.index = Math.floor(Math.random() * 7) + 1;
      }
      else {
        if (tr < 0.48) p.type = E_MJPai.p;
        else if (tr < 0.74) p.type = E_MJPai.s;
        else p.type = E_MJPai.m;
        p.index = Math.floor(Math.random() * 9) + 1;
      }
      return p;
    }

    public static CreateEmpty(): MJPai {
      let p: MJPai = new MJPai();
      return p;
    }

    public static isSame(a: MJPai, b: MJPai): boolean {
      return a.id == b.id;
    }

    public static Distance(a: MJPai, b: MJPai): number {
      return a.numValue() - b.numValue();
    }

    public static DoraMet(me: MJPai, indicator: MJPai): boolean {
      if (amulet.AmuletDesktopMgr.Inst.isDoraBaned(me)) return false;
      if (me.type != indicator.type) return false;
      let index: number = indicator.index + 1;
      if (indicator.type == E_MJPai.z) {
        if (indicator.index <= 4) {
          if (index == 5) index = 1;
        } else {
          if (index == 8) index = 5;
        }
      } else if (indicator.type == E_MJPai.s || indicator.type == E_MJPai.p) {
        if (index == 10) index = 1;
      } else {
        if (index == 10) index = 1;
        if (index == 2) index = 9;
      }
      return index == me.index;
    }

    public toString(showTouming: boolean = true): string {
      let sname: string = this.dora ? '0' : this.index.toString();
      switch (this.type) {
        case E_MJPai.m: sname += 'm'; break;
        case E_MJPai.p: sname += 'p'; break;
        case E_MJPai.s: sname += 's'; break;
        default: sname += 'z'; break;
      }
      if (showTouming && this.touming) {
        sname += 't';
      } else if (this.baida) {
        sname = 'bd';
      }
      return sname;
    }


    // 230418 新增 拆分牌后获取tilingoffset接口
    public getTilingOffset(): Laya.Vector4 {
      let index: number = 0;
      switch (this.type) {
        case amulet.E_MJPai.m: index = 0; break;
        case amulet.E_MJPai.p: index = 10; break;
        case amulet.E_MJPai.s: index = 20; break;
        default: index = 29; break;
      }
      if (!this.dora) index += this.index;
      let x: number = (6 + index % 7 * 104) / 1024;
      let y: number = (6 + Math.floor(index / 7) * 144) / 1024;
      return new Laya.Vector4(0.09765625, 0.14, x, y);
    }

    public static getBackTilingOffset(): Laya.Vector4 {
      return new Laya.Vector4(0.09765625, 0.144, 0.72, 0);
    }
  }
  export class PropCard {
    public id: number; // 牌id
    public effectId: number;
    public store: string[] = [];//成长数据
    public badge: game.IAmuletBadgeData;
    public volume: number;
    public config: lqc.Sheet_Amulet_AmuletEffect;
    public badgeConfig: lqc.Sheet_Amulet_AmuletBadge;

    public static CreateProp(msg: game.IAmuletEffectData): PropCard {
      let ret: PropCard = new PropCard();
      ret.effectId = msg.id;
      ret.id = msg.uid;
      ret.store = msg.store;
      ret.badge = msg.badge;
      ret.config = cfg.amulet.amulet_effect.get(msg.id);
      ret.volume = 1;
      if (msg.badge && msg.badge.id) {
        ret.badgeConfig = cfg.amulet.amulet_badge.get(msg.badge.id);
        ret.volume += ret.badgeConfig.volume;
      }
      if (msg.volume) ret.volume = msg.volume;
      return ret;
    }

    public static CreateTempleteProp(effectId: number, badge?: game.IAmuletBadgeData, uid: number = -1, store: string[] = []): PropCard {
      let ret: PropCard = new PropCard();
      ret.effectId = effectId;
      ret.id = uid;
      ret.store = store;
      if (badge) {
        if (typeof (badge) == 'number') {
          ret.badge = {
            id: badge,
            uid: -1,
            store: [],
            random: Math.random() * 100000
          }
        } else {
          ret.badge = badge;
        }
      }
      ret.volume = 1;
      ret.config = cfg.amulet.amulet_effect.get(effectId);
      if (ret.badge && ret.badge.id) {
        ret.badgeConfig = cfg.amulet.amulet_badge.get(ret.badge.id);
        ret.volume += ret.badgeConfig.volume;
      }
      return ret;
    }

    public static CreatePropOption(effectId: number, badgeId?: number, store: string[] = []): PropCard {
      let ret: PropCard = new PropCard();
      ret.effectId = effectId;
      ret.id = -1;
      ret.store = store;
      if (badgeId) {
        ret.badge = {
          id: badgeId,
          uid: -1,
          store: [],
          random: Math.random() * 100000
        }
      }
      ret.volume = 1;
      ret.config = cfg.amulet.amulet_effect.get(effectId);
      if (ret.badge && ret.badge.id) {
        ret.badgeConfig = cfg.amulet.amulet_badge.get(ret.badge.id);
        ret.volume += ret.badgeConfig.volume;
      }
      return ret;
    }

    public get isPlus(): boolean {
      return this.effectId % 10 == 1;
    }

    public get haveBadge(): boolean {
      return !!this.badge;
    }

    public get haveUnstable(): PropCard {
      if ((this.effectId == 2280 || this.effectId == 2281 || this.effectId == 2320 || this.effectId == 2321) && this.store) {
        let tempPropId = 0;
        let tempStore: string[] = []
        for (let i = 0; i < this.store.length; i++) {
          if (i == 0) {
            tempPropId = Number(this.store[i]);
          } else if (i < 10) {
            tempStore.push(this.store[i]);
          }
        }
        if (!tempPropId || !cfg.amulet.amulet_effect.get(tempPropId)) return null;
        let badgeId = this.badge && this.badge.id ? this.badge.id : null;
        let unstableProp = amulet.PropCard.CreatePropOption(tempPropId, badgeId, tempStore);
        return unstableProp;
      }
      return null;
    }

    public static isSame(a: PropCard, b: PropCard): boolean {
      return a.id == b.id && a.effectId == b.effectId;
    }
  }

  export enum E_Ming { shunzi, kezi, gang_ming, gang_an, babei, gang_add }; //顺子，刻子，明杠，暗杠，拔北

  //麻将副露
  export class MJMing {
    public type: E_Ming;
    public pais: Array<MJPai> = [];
    public from: Array<number> = [];

    public Clone(): MJMing {
      let ret: MJMing = new MJMing();
      ret.type = this.type;
      ret.pais = [];
      for (let i: number = 0; i < this.pais.length; i++) {
        ret.pais.push(this.pais[i].Clone());
      }
      ret.from = [];
      for (let i: number = 0; i < this.from.length; i++) {
        ret.from.push(this.from[i]);
      }
      return ret;
    }

    public toString(): string {
      let ret: string = '';
      switch (this.type) {
        case E_Ming.shunzi: ret += 'shunzi('; break;
        case E_Ming.kezi: ret += 'kezi('; break;
        case E_Ming.gang_ming: ret += 'minggang('; break;
        case E_Ming.gang_an: ret += 'angang('; break;
        case E_Ming.babei: ret += 'babei('; break;
      }
      for (let i: number = 0; i < this.pais.length; i++) {
        if (i != 0) ret += ',';
        ret += this.pais[i].toString();
      }
      ret += ')';
      return ret;
    }

    public isFulu(): boolean {
      return this.type == E_Ming.shunzi || this.type == E_Ming.kezi || this.type == E_Ming.gang_ming;
    }
  }

  export enum EAmuletPlayOperation { none, discard = 1, endExchange = 100, gang = 4, rong = 8, forceDiscard = 99, exchange = 101 }
}