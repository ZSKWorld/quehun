// /**
// * Movement用于3D物体缓动
// */
module game {
    export class Movement {
        //开始移动前的原始位置旋转缩放
        private _originPosition = new Laya.Vector3();
        private _originEuler = new Laya.Vector3();
        private _originQuat = new Laya.Quaternion();
        private _originScale = new Laya.Vector3();

        //目标位置旋转缩放，本地保存一个，不使用外部传进来的，避免造成Vector3，Quaternion数据错乱
        private _position = new Laya.Vector3();
        private _ctrlPosition1 = new Laya.Vector3();
        private _ctrlPosition2 = new Laya.Vector3();
        private _euler = new Laya.Vector3();
        private _quat = new Laya.Quaternion();
        private _scale = new Laya.Vector3();

        private _targetPosition: Laya.Vector3;
        private _targetCtrlPosition1: Laya.Vector3;
        private _targetCtrlPosition2: Laya.Vector3;
        private _targetQuat: Laya.Quaternion;
        private _targetScale: Laya.Vector3;

        private _owner: Laya.Sprite3D;
        private _time: number = 0;
        private _delay: number = 0;
        private _duration: number = 0;
        private _progress: number = 0;
        private _isPaused: boolean = false; // 新增：暂停状态标志
        // 改动1：新增速度系数（默认1=正常速度，>1加速，<1减速）
        private _speedFactor: number = 1;

        onUpdate: Laya.Handler;
        onEnd: Laya.Handler;
        onStart: Laya.Handler;
        ease: (...args: any[]) => number;
        /** 延迟执行时间， 毫秒 */
        get delay() { return this._delay; }
        set delay(v) { this._delay = Math.max(v, 0); }
        /** 持续时间，毫秒 */
        get duration() { return this._duration; }
        set duration(v) { this._duration = Math.max(v, 1); }
        get progress() { return this._progress; }
        get targetPosition() { return this._targetPosition; };
        set targetPosition(v) {
            if (v) {
                v.cloneTo(this._position);
                this._targetPosition = this._position;
            }
            else this._targetPosition = null;
        };
        /** 二阶贝塞尔曲线控制点 */
        get targetCtrlPosition1() { return this._targetCtrlPosition1; }
        set targetCtrlPosition1(v) {
            if (v) {
                v.cloneTo(this._ctrlPosition1);
                this._targetCtrlPosition1 = this._ctrlPosition1;
            } else this._targetCtrlPosition1 = null;
        }
        /** 三阶贝塞尔曲线控制点 */
        get targetCtrlPosition2() { return this._targetCtrlPosition2; }
        set targetCtrlPosition2(v) {
            if (v) {
                v.cloneTo(this._ctrlPosition2);
                this._targetCtrlPosition2 = this._ctrlPosition2;
            } else this._targetCtrlPosition2 = null;
        }
        get targetEuler() { return this._targetQuat ? this._euler : null; }
        set targetEuler(v) {
            if (v) {
                v.cloneTo(this._euler);
                const pi = Math.PI / 180;
                Laya.Quaternion.createFromYawPitchRoll(v.y * pi, v.x * pi, v.z * pi, this._quat);
                this._targetQuat = this._quat;
            } else this._targetQuat = null;
        }
        get targetQuat() { return this._targetQuat; };
        set targetQuat(v) {
            if (v) {
                v.cloneTo(this._quat);
                this._quat.getYawPitchRoll(this._euler);
                const pi = 180 / Math.PI;
                const { x, y, z } = this._euler;
                this._euler = new Laya.Vector3(y * pi, x * pi, z * pi);
                this._targetQuat = this._quat;
            } else this._targetQuat = null;
        };
        get targetScale() { return this._targetScale; };
        set targetScale(v) {
            if (v) {
                v.cloneTo(this._scale);
                this._targetScale = this._scale;
            }
            else this._targetScale = null;
        };
        get isFinished() { return this._progress >= 1; } // 改动2：进度>=1即完成（替代原_time判断）

        /** 是否暂停 */
        get isPaused() { return this._isPaused; }

        // 改动3：新增速度系数的get/set（支持实时修改）
        get speedFactor() { return this._speedFactor; }
        set speedFactor(v) { this._speedFactor = Math.max(v, 0.01); } // 最小0.01避免卡死

        startMove(owner: Laya.Sprite3D) {
            this._owner = owner;
            const { localPosition, localRotationEuler, localScale, localRotation } = this._owner.transform;
            localPosition.cloneTo(this._originPosition);
            localRotationEuler.cloneTo(this._originEuler);
            localScale.cloneTo(this._originScale);
            localRotation.cloneTo(this._originQuat);
        }

        moveImmediately(owner: Laya.Sprite3D) {
            this.startMove(owner);
            this._progress = 1; // 改动4：直接设进度为1（替代原_time）
            this.moveUpdate(1);
        }

        update() {
            if (this._isPaused) return;

            const deltaTime = Laya.timer.delta;
            if (this._delay > 0) {
                this._delay -= deltaTime;
                if (this._delay > 0) return;
            }

            if (!this.isFinished) {
                // 1. 计算线性进度的增量
                const progressDelta = (deltaTime / this._duration) * this._speedFactor;

                // 2. 更新线性内部进度记录 (0-1)
                this._progress = Math.min(Math.max(this._progress + progressDelta, 0), 1);

                // 3. 根据线性进度计算用于显示的缓动进度
                let displayProgress = this._progress;
                if (this.ease) {
                    // 注意：Laya的ease函数通常参数为 (t, b, c, d)
                    // t:当前时间, b:起始值, c:改变量, d:总时长
                    displayProgress = this.ease(this._progress * this._duration, 0, 1, this._duration);
                }

                // 4. 将缓动后的进度传给渲染逻辑
                this.moveUpdate(displayProgress);
            }
        }

        private moveUpdate(progress: number) {
            if (this.onStart) {
                this.onStart.run();
                this.onStart = null;
            }

            // --- 删掉这一行！ ---
            // this._progress = progress; 
            // ------------------

            const { _owner, onUpdate, _originPosition, _originScale, _originQuat, _targetPosition, _targetCtrlPosition1, _targetCtrlPosition2, _targetScale, _targetQuat } = this;
            const { localPosition, localScale, localRotation } = _owner.transform;

            // 使用传入的渲染进度 progress (即 eased 的值) 进行插值计算
            if (_targetPosition) {
                if (!_targetCtrlPosition1) Laya.Vector3.lerp(_originPosition, _targetPosition, progress, localPosition);
                else {
                    if (_targetCtrlPosition2)
                        Movement.cubicBezier(_originPosition, _targetCtrlPosition1, _targetCtrlPosition2, _targetPosition, progress, localPosition);
                    else
                        Movement.quardaticBezier(_originPosition, _targetCtrlPosition1, _targetPosition, progress, localPosition);
                }
            }

            _targetScale && Laya.Vector3.lerp(_originScale, _targetScale, progress, localScale);
            _targetQuat && Laya.Quaternion.slerp(_originQuat, _targetQuat, progress, localRotation);

            _targetPosition && (_owner.transform.localPosition = localPosition);
            _targetScale && (_owner.transform.localScale = localScale);
            _targetQuat && (_owner.transform.localRotation = localRotation);

            if (onUpdate) onUpdate.runWith(progress);

            // 判断完成应该基于原始进度 _progress
            if (this._progress >= 1) this.onCompleted();
        }

        private onCompleted() {
            if (this.onUpdate) {
                this.onUpdate.recover();
                this.onUpdate = null;
            }
            if (this.onEnd) {
                this.onEnd.run();
                this.onEnd.recover();
                this.onEnd = null;
            }
        }

        private reset() {
            this._time = 0; // 保留原有变量（不删除，仅重置）
            this._delay = 0;
            this._duration = 0;
            this._progress = 0;
            this._isPaused = false;
            this._speedFactor = 1; // 改动6：重置速度系数
            this._targetPosition = null;
            this._targetCtrlPosition1 = null;
            this._targetCtrlPosition2 = null;
            this._targetQuat = null;
            this._targetScale = null;
            this.onUpdate = null;
            this.onEnd = null;
            this.onStart = null;
            this.ease = null;
        }

        /** 新增：暂停动画 */
        pause() {
            this._isPaused = true;
        }

        /** 新增：恢复动画 */
        resume() {
            this._isPaused = false;
        }

        static getMovement() {
            return Laya.Pool.getItemByClass("Movement", Movement) as Movement;
        }

        static recoverMovement(movement: Movement) {
            movement.reset();
            Laya.Pool.recover("Movement", movement);
        }

        private static tempV30 = new Laya.Vector3();
        private static tempV31 = new Laya.Vector3();
        /** 二阶贝塞尔曲线 */
        static quardaticBezier(startPos: Laya.Vector3, ctrlPos: Laya.Vector3, endPos: Laya.Vector3, t: number, out: Laya.Vector3) {
            const { tempV30 } = this;
            Laya.Vector3.subtract(ctrlPos, startPos, tempV30);
            Laya.Vector3.scale(tempV30, t, tempV30);
            Laya.Vector3.add(startPos, tempV30, tempV30);

            Laya.Vector3.subtract(endPos, ctrlPos, out);
            Laya.Vector3.scale(out, t, out);
            Laya.Vector3.add(ctrlPos, out, out);

            Laya.Vector3.subtract(out, tempV30, out);
            Laya.Vector3.scale(out, t, out);
            Laya.Vector3.add(tempV30, out, out);
        }

        /** 三阶贝塞尔曲线 */
        static cubicBezier(a: Laya.Vector3, b: Laya.Vector3, c: Laya.Vector3, d: Laya.Vector3, t: number, cc: Laya.Vector3) {
            const { tempV30: aa, tempV31: bb } = this;

            Laya.Vector3.subtract(b, a, aa);
            Laya.Vector3.scale(aa, t, aa);
            Laya.Vector3.add(a, aa, aa);

            Laya.Vector3.subtract(c, b, bb);
            Laya.Vector3.scale(bb, t, bb);
            Laya.Vector3.add(b, bb, bb);

            Laya.Vector3.subtract(d, c, cc);
            Laya.Vector3.scale(cc, t, cc);
            Laya.Vector3.add(c, cc, cc);

            const bbb = cc;
            Laya.Vector3.subtract(cc, bb, bbb);
            Laya.Vector3.scale(bbb, t, bbb);
            Laya.Vector3.add(bb, bbb, bbb);

            const aaa = bb;
            Laya.Vector3.subtract(bb, aa, aaa);
            Laya.Vector3.scale(aaa, t, aaa);
            Laya.Vector3.add(aa, aaa, aaa);

            Laya.Vector3.subtract(bbb, aaa, bbb);
            Laya.Vector3.scale(bbb, t, bbb);
            Laya.Vector3.add(aaa, bbb, bbb);
        }
    }

    export class CardMovement extends Laya.Script {
        private _movements: Movement[] = [];
        private _moving: boolean = false;
        readonly owner: Laya.Sprite3D;
        get transform() { return this.owner.transform; }
        get moving() { return this._moving; }
        set speedFactor(v) {
            if (!this._moving) return;
            const movement = this._movements[0];
            movement.speedFactor = v;
        }

        addMovement(movement: Movement) {
            this._movements.push(movement);
        }

        removeMovement(movement: Movement) {
            const index = this._movements.indexOf(movement);
            index >= 0 && this._movements.splice(index, 1);
        }

        startMove() {
            this._moving = true;
            this.moveNext();
        }

        moveImmediately() {
            this._movements.forEach(v => {
                v.moveImmediately(this.owner);
                Movement.recoverMovement(v);
            });
            this.clear();
        }

        _update() {
            if (!this._moving) return;
            const movement = this._movements[0];
            movement.update();
            if (movement.isFinished) {
                Movement.recoverMovement(this._movements.shift());
                this.moveNext();
            }
        }

        clear() {
            this._moving = false;
            this._movements.forEach(Movement.recoverMovement);
            this._movements.length = 0;
        }

        pause() {
            if (!this._moving) return;
            const movement = this._movements[0];
            movement.pause();
        }

        resume() {
            if (!this._moving) return;
            const movement = this._movements[0];
            movement.resume();
        }

        private moveNext() {
            if (this._movements.length > 0)
                this._movements[0].startMove(this.owner);
            else this.clear();
        }
    }
}