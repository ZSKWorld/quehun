// /**
// * name
// */
module game {
	export class Moveable extends Laya.Script {
		readonly owner: Laya.Sprite3D;
		private _moveCurve: CardCurve;
		private _movement: CardMovement;

		get transform() { return this.owner.transform; }

		get moveCurve() {
			if (!this._moveCurve) this._moveCurve = this.owner.addComponent(CardCurve) as CardCurve;
			return this._moveCurve;
		}
		get movement() {
			if (!this._movement) this._movement = this.owner.addComponent(CardMovement) as CardMovement;
			return this._movement;
		}

		clearMove() {
			if (this._moveCurve) {
				this._moveCurve.reset();
			}
			if (this._movement) {
				this._movement.clear();
			}
		}

	}
}


