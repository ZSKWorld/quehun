module game {
    /**
     * Laya数字滚动动画组件 - 从0到目标值 先快后慢减速滚动
     * @param targetLabel Laya.Label 文本显示容器
     * @param targetNum 目标数值(如20000)
     * @param duration 总动画时长(毫秒，默认1500，越大越慢)
     * @param decimal 保留小数位数(默认0，整数)
     * @param isFormat 是否千分位格式化(默认true，如20000→20,000)
     */
    export class NumberRoller {
        // 当前滚动的数值
        private currentNum: number = 0;
        constructor() {

        }

        /**
         * 开始数字滚动动画
         */
        public startRoll(
            targetLabel: Laya.Label,
            targetNum: number,
            duration: number = 1500,
            decimal: number = 0,
            isFormat: boolean = true
        ): void {
            // 初始化数据，防止重复执行动画叠加
            this.currentNum = 0;
            targetNum = Math.max(0, targetNum); // 确保目标值非负
            const startTime = Laya.timer.currTimer; // 动画开始时间戳

            // 先清除之前的定时器，防止重复创建
            Laya.timer.clear(this, this.rollHandler);

            // 逐帧执行动画，Laya最优动画方式，60帧/秒流畅无卡顿
            Laya.timer.frameLoop(1, this, this.rollHandler, [
                targetLabel, targetNum, startTime, duration, decimal, isFormat
            ]);
        }

        /**
         * 动画核心帧处理函数 - 实现先快后慢的核心逻辑
         */
        private rollHandler(
            targetLabel: Laya.Label,
            targetNum: number,
            startTime: number,
            duration: number,
            decimal: number,
            isFormat: boolean
        ): void {
            // 计算动画执行的进度 0~1
            const now = Laya.timer.currTimer;
            let progress = (now - startTime) / duration;
            progress = Math.min(progress, 1); // 进度最大为1，防止超界

            // 核心缓动公式【先快后慢】关键所在
            // easeOutCubic 三次方减速曲线，前期数值飙升，后期缓慢趋近目标，视觉效果最佳
            const easeProgress = 1 - Math.pow(1 - progress, 3);

            // 计算当前应该显示的数值
            this.currentNum = targetNum * easeProgress;

            // 格式化数值：保留小数 + 千分位分隔
            let showNum = this.formatNumber(this.currentNum, decimal);
            showNum = isFormat ? this.addThousandSeparator(showNum) : showNum;

            // 赋值给文本组件
            targetLabel.text = showNum;

            // 动画结束，清除定时器
            if (progress >= 1) {
                Laya.timer.clear(this, this.rollHandler);
                // 强制赋值精准目标值，避免浮点误差
                const finalNum = this.formatNumber(targetNum, decimal);
                targetLabel.text = isFormat ? this.addThousandSeparator(finalNum) : finalNum;
            }
        }

        /**
         * 保留指定位数的小数
         */
        private formatNumber(num: number, decimal: number): string {
            return num.toFixed(decimal);
        }

        /**
         * 数字千分位格式化 10000 → 10,000 | 123456.78 → 123,456.78
         */
        private addThousandSeparator(numStr: string): string {
            const [integer, decimal] = numStr.split('.');
            const formatInt = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            return decimal ? `${formatInt}.${decimal}` : formatInt;
        }

        /**
         * 销毁动画，清除定时器（页面销毁时调用，防止内存泄漏）
         */
        public destroy(): void {
            Laya.timer.clear(this, this.rollHandler);
        }
    }
}