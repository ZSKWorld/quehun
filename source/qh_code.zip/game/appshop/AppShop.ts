/**
* name 
*/
module game{
	export class AppShop {

		public recover_pre_order(good_id):boolean {
			return false;
		}

		public getGoodsInfo(good_id:number): any {
			return null;
		}

		public onGameStart() {

		}

		public want2BuyItem(good_id:number, handler:Laya.Handler) {

		}

	}
}