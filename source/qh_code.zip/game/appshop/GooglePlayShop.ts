/**
* name 
*/
module game{

	export class GooglePlayShop extends AppShop {

		public static Inst:GooglePlayShop;
		private static goods_info:Object = {};
		private static current_order_id:string = '';
		private static orders:Array<{sku:string, data: any, sign:string}> = [];

		private static on_getSkuDetails(d:any) {
			this.goods_info = {};
			if (d) {
				for (let i:number = 0; i < d.length; i++) {
					let dd = d[i];
					let sku = dd['productId'];
					this.goods_info[sku] = dd;
				}
				//拿到商品列表后，拿取我之前购买的还没消耗的东西
				var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
				_c.call('getGPOwnedItems');
			}
		}

		private static on_gp_get_owneditems(d:any) {
			this.orders = [];
			if (d) {
				for (let i:number = 0; i < d.length; i++) {
					let dd = d[i];
					this.orders.push({
						sku: dd['sku'],
						data: dd['data'],
						sign: dd['sign']
					});
				}
				//上线发现有还未消耗掉的商品，就通知服务器分发一下
				for (let i:number = 0; i < this.orders.length; i++) {
					let _order = this.orders[i];
					app.NetAgent.sendReq2Lobby('Lobby', 'solveGooglePlayOrder', {
						inapp_purchase_data: JSON.stringify(_order.data),
						inapp_data_signature: _order.sign
					}, (err, res) => {
						if (err) {

						} else if (res['error']) {
							let err_code = res['error']['code'];
							if (err_code == 1901 || err_code == 1902) {
								//1901,订单未找到，先删除了，有问题手动改
								//1902,订单订单已经处理，可以正常消耗掉
								var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
								_c.call('consumeGPItem', _order.data['purchaseToken']);
							}
						} else {
							//订单处理成功，消耗gp商品
							var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
							_c.call('consumeGPItem', _order.data['purchaseToken']);
						}
					});
				}
			}
		}

		private static on_gp_buy_result(data:any, sign:string) {
			let sku:string = data['productId'];
			this.orders.push({
				sku: sku,
				data: data,
				sign: sign
			});
			app.NetAgent.sendReq2Lobby('Lobby', 'solveGooglePlayOrder', {
				inapp_purchase_data: JSON.stringify(data),
				inapp_data_signature: sign
			}, (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('solveGooglePlayOrder', err, res);
				} else {
					//订单处理成功，消耗gp商品
					var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
					_c.call('consumeGPItem', data['purchaseToken']);
				}
			});
		}

		private static on_consume_success(token:string) {
			for (let i:number = 0; i < this.orders.length; i++) {
				if (this.orders[i].data['purchaseToken'] == token) {
					this.orders[i] = this.orders[this.orders.length - 1];
					this.orders.pop();
					break;
				}
			}
		}

		private static on_failed_info(s:string) {
			if (uiscript.UIMgr.Inst) {
				uiscript.UIMgr.Inst.ShowErrorInfo(s);
			}
		}

		private static on_gp_pay_cancel() {
			if (this.current_order_id && this.current_order_id != '') {
				app.NetAgent.sendReq2Lobby('Lobby', 'cancelGooglePlayOrder', {
					order_id: this.current_order_id
				}, (err, res) => {
					if (err || res['error']) {
						uiscript.UIMgr.Inst.showNetReqError('cancelGooglePlayOrder', err, res);
					} else {

					}
				});
				this.current_order_id = '';
			}
		}

		private static on_gp_buy_error(developerPayload: string, code: number) {
			if (code == 1) {
				app.NetAgent.sendReq2Lobby('Lobby', 'cancelGooglePlayOrder', {
					order_id: developerPayload
				}, (err, res) => {
					if (err || res['error']) {
						uiscript.UIMgr.Inst.showNetReqError('cancelGooglePlayOrder', err, res);
					} else {

					}
				});
			} else {
				let error_info:string = '';
				switch(code) {
					case 2: error_info = game.Tools.strOfLocalization(2222); break;
					case 3: error_info = game.Tools.strOfLocalization(2223); break;
					case 4: error_info = game.Tools.strOfLocalization(2224); break;
					case 5:
					case 6: error_info = game.Tools.strOfLocalization(2225); break;
					case 7: error_info = game.Tools.strOfLocalization(2226); break;
				}
				if (error_info != '') {
					uiscript.UIMgr.Inst.ShowErrorInfo(error_info);
				}
			}
		}

		public inited:boolean = false;

		public constructor() {
			super();
			GooglePlayShop.Inst = this;
		}

		public recover_pre_order(good_id):boolean {
			let sku:string = '';
			let d_goods = cfg.mall.product.getGroup(10);
			for (let i:number = 0; i < d_goods.length; i++) {
				if (d_goods[i].goods_id == good_id) {
					sku = d_goods[i].product_id;
					break;
				}
			}
			if (sku == '') {
				return false;
			}
			for (let i:number = 0; i < GooglePlayShop.orders.length; i++) {
				if (GooglePlayShop.orders[i].sku == sku) {
					//若内存中有尚未删除的订单信息，重新处理一下这笔订单
					let d = GooglePlayShop.orders[i];
					app.NetAgent.sendReq2Lobby('Lobby', 'solveGooglePlayOrder', {
						inapp_purchase_data: JSON.stringify(d.data),
						inapp_data_signature: d.sign
					}, (err, res) => {
						if (err || res['error']) {
							if (res && res['error']['code'] == 1902) {
								//订单服务器已经处理了，需要消耗掉
								var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
								_c.call('consumeGPItem', d.data['purchaseToken']);
							} else {
								uiscript.UIMgr.Inst.showNetReqError('solveGooglePlayOrder', err, res);
							}
						} else {
							//订单处理成功，消耗gp商品
							var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
							_c.call('consumeGPItem', d.data['purchaseToken']);
						}
					});
					return true;
				}
			}
			return false;
		}

		public getGoodsInfo(good_id:number): any {
			let d_goods = cfg.mall.product.getGroup(10);
			let sku:string = '';
			for (let i:number = 0; i < d_goods.length; i++) {
				if (d_goods[i].goods_id == good_id) {
					sku = d_goods[i].product_id;
					break;
				}
			}
			if (sku == '') return null;
			if (GooglePlayShop.goods_info[sku]) {
				let d = GooglePlayShop.goods_info[sku];
				return {
					currency_code: d['price_currency_code'],
					price: d['price']
				};
			}
			return null;
		}

		public onGameStart() {
			let goods = cfg.mall.product.getGroup(10);
			let _sku_lst:string = '';
			if (goods) {
				for (let i:number = 0; i < goods.length; i++) {
					if (i != 0) _sku_lst += ',';
					_sku_lst += goods[i].product_id;
				}
				var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
				_c.call('gp_getSkuDetail', _sku_lst);
			}
		}

		public want2BuyItem(good_id:number, handler:Laya.Handler) {
			let sku:string = '';
			let d_goods = cfg.mall.product.getGroup(10);
			for (let i:number = 0; i < d_goods.length; i++) {
				if (d_goods[i].goods_id == good_id) {
					sku = d_goods[i].product_id;
					break;
				}
			}
			if (sku == '') {
				handler.runWith(1); //渠道商品不存在，或者未拿到商品详情
				return;
			}
			app.NetAgent.sendReq2Lobby('Lobby', 'createBillingOrder', {
				goods_id: good_id,
				payment_platform: 10,
				client_type: 1,
				account_id: GameMgr.Inst.account_id,
				client_version_string: GameMgr.Inst.getClientVersion()
			}, (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('createBillingOrder', err, res);
					handler.runWith(0);
				} else {
					let developerPayload:string = res['order_id'];
					GooglePlayShop.current_order_id = developerPayload;
					var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr"); 
					_c.call('gp_buySku', sku, developerPayload);
					handler.runWith(0);
				}
			});

		}
	}
}