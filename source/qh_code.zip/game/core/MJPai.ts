
module mjcore {
  export enum E_MJPai { p, m, s, z, bd };

  //麻将单牌
  export class MJPai {
    public index: number; //数字，如果是字牌的话就是东南西北白发中
    public type: E_MJPai; //类型： 0.筒子p,  1.万字m,  2.条子s,  3.字牌z,  4.百搭牌
    public dora: boolean; //红朵拉
    public touming: boolean; // 透明牌
    public baida: boolean; // 百搭牌

    //是字牌
    public IsZ(): boolean {
      return this.type == E_MJPai.z;
    }

    //是老头牌
    public IsLaoTou(): boolean {
      return this.type != E_MJPai.z && (this.index == 1 || this.index == 9);
    }

    //是幺九牌
    public IsYao(): boolean {
      return this.IsZ() || this.IsLaoTou();
    }

    //是四喜牌
    public IsSiXi(): boolean {
      return this.IsZ() && this.index >= 1 && this.index <= 4;
    }

    //是三元牌
    public IsSanYan(): boolean {
      return this.IsZ() && this.index >= 5 && this.index <= 7;
    }

    public Clone(): MJPai {
      let ret:MJPai = new MJPai();
      ret.type = this.type;
      ret.index = this.index;
      ret.dora = this.dora;
      return ret;
    }
    public numValue(): number {
      let v:number = 0;
      switch (this.type) {
          case E_MJPai.m: v = this.index; break;
          case E_MJPai.p: v = 10000 + this.index; break;
          case E_MJPai.s: v = 10000 * 2 + this.index; break;
          case E_MJPai.z: v = 10000 * 3 + this.index * 10; break;
      }
      return v;
    }

    public static Create(str:string): MJPai {
      let ret:MJPai = new MJPai();
      if (str.charAt(0) == '0') {
        ret.dora = true;
        ret.index = 5;
      } else {
        ret.dora = false;
        ret.index = +str.charAt(0);
      }
      switch (str.charAt(1)) {
        case 'z':ret.type = E_MJPai.z; break;
        case 'm':ret.type = E_MJPai.m; break;
        case 's':ret.type = E_MJPai.s; break;
        case 'p':ret.type = E_MJPai.p; break;
      }
     
      ret.touming = str.length > 2;
      
      ret.baida = str == 'bd';
      str == 'bd' && (ret.type = E_MJPai.bd);

      return ret;
    }


    //随机创造一个，测试方便
    public static RandomCreate(): MJPai {
      let p: MJPai = new MJPai();
      let tr: number = Math.random();
      if(tr < 0.22) {
        p.type = E_MJPai.z;
        p.index = Math.floor(Math.random()*7) + 1;
      }
      else
      {
        if(tr<0.48)p.type = E_MJPai.p;
        else if(tr<0.74)p.type = E_MJPai.s;
        else p.type = E_MJPai.m;
        p.index = Math.floor(Math.random()*9) + 1;
      }
      return p;
    }


    //判定完全相同，朵拉成分也一样, ignoreTouming表示 是否忽略透明属性
    public static isSame(a:MJPai, b:MJPai, ignoreTouming:boolean = false): boolean {
      return a.type == b.type && a.index == b.index && a.dora == b.dora && (ignoreTouming || a.touming == b.touming);
    }

    public static Distance(a:MJPai, b:MJPai): number {
      return a.numValue() - b.numValue();
    }

    public static DoraMet(me:MJPai, indicator:MJPai): boolean {
      if (me.type != indicator.type) return false;
      if (view.DesktopMgr.Inst.is_field_spell_extra_dora()) {
        if (me.index == indicator.index) {
          return true;
        }
      }

      let index:number = indicator.index + 1;
      if (view.DesktopMgr.Inst.rule_mode == view.ERuleMode.Liqi4) {
        if (indicator.type == E_MJPai.z) {
          if (indicator.index <= 4) {
            if (index == 5) index = 1;
          } else {
            if (index == 8) index = 5;
          }
        } else {
          if (index == 10) index = 1;
        }
      } else if (view.DesktopMgr.Inst.rule_mode == view.ERuleMode.Liqi3) {
        if (indicator.type == E_MJPai.z) {
          if (indicator.index <= 4) {
            if (index == 5) index = 1;
          } else {
            if (index == 8) index = 5;
          }
        } else if (indicator.type == E_MJPai.s || indicator.type == E_MJPai.p) {
          if (index == 10) index = 1;
        } else {
          if (index == 10) index = 1;
          if (index == 2) index = 9;
        }
      }
      return index == me.index;
    }

    public toString(showTouming: boolean = true): string{
      let sname: string = this.dora ? '0' : this.index.toString();
      switch (this.type) {
        case E_MJPai.m: sname += 'm'; break;
        case E_MJPai.p: sname += 'p'; break;
        case E_MJPai.s: sname += 's'; break;
        default: sname += 'z'; break;
      }
      if (showTouming && this.touming) {
        sname += 't';
      } else if (this.baida) {
        sname = 'bd';
      }
      return sname;
    }


    // 230418 新增 拆分牌后获取tilingoffset接口
    public getTilingOffset(): Laya.Vector4 {
        let index: number = 0;
				switch (this.type) {
					case mjcore.E_MJPai.m: index = 0; break;
					case mjcore.E_MJPai.p: index = 10; break;
					case mjcore.E_MJPai.s: index = 20; break;
					default: index = 29; break;
				}
				if (!this.dora) index += this.index;
				let x: number = (6 + index % 7 * 104) / 1024;
				let y: number = (6 + Math.floor(index / 7) * 144) / 1024;
        return new Laya.Vector4(0.09765625, 0.14, x, y);
    }

    public static getBackTilingOffset(): Laya.Vector4 {
        return new Laya.Vector4(0.09765625, 0.144, 0.72, 0);
    }

    public getNextCard(): MJPai { 
      let p: MJPai = new MJPai();
      p.type = this.type;
      if (this.type == E_MJPai.z) {
        p.index = this.index + 1;
        if (p.index > 7) {
          p.index = 1;
        }
        
      } else {
        p.index = this.index + 1;
        if (p.index > 9) {
          p.index = 1;
        }
      }
      return p;
    }

    public getPrevCard(): MJPai {
      let p: MJPai = new MJPai();
      p.type = this.type;
      if (this.type == E_MJPai.z) {
        p.index = this.index - 1;
        if (p.index < 1) {
          p.index = 7;
        }
      } else {
        p.index = this.index - 1;
        if (p.index < 1) {
          p.index = 9;
        }
      }
      return p;
    }
    
    public get typeName(): string {
      let sname: string = '';
      switch (this.type) {
        case E_MJPai.m: sname += 'm'; break;
        case E_MJPai.p: sname += 'p'; break;
        case E_MJPai.s: sname += 's'; break;
        default: sname += 'z'; break;
      }
      return sname;
    }
	  
  }

  //弃牌
  export class MJQiPai{
    public pai: MJPai;	//牌
    public liqi: boolean; //是否是立直牌
    public playerseat: number; //打出来的人的座位
    public inHai: boolean; //还在海里（有没有被吃碰）
  }

  export enum E_Ming { shunzi, kezi, gang_ming, gang_an, babei, gang_add }; //顺子，刻子，明杠，暗杠，拔北

  //麻将副露
  export class MJMing{
    public type: E_Ming;
    public pais: Array<MJPai> = [];
    public from: Array<number> = [];

    public Clone(): MJMing {
      let ret:MJMing = new MJMing();
      ret.type = this.type;
      ret.pais = [];
      for (let i:number = 0; i < this.pais.length; i++) {
        ret.pais.push(this.pais[i].Clone());
      }
      ret.from = [];
      for (let i:number = 0; i < this.from.length; i++) {
        ret.from.push(this.from[i]);
      }
      return ret;
    }

    public toString(): string {
      let ret:string = '';
      switch (this.type) {
        case E_Ming.shunzi: ret += 'shunzi('; break;
        case E_Ming.kezi: ret += 'kezi('; break;
        case E_Ming.gang_ming: ret += 'minggang('; break;
        case E_Ming.gang_an: ret += 'angang('; break;
        case E_Ming.babei: ret += 'babei('; break;
      }
      for (let i:number = 0; i < this.pais.length; i++) {
        if (i != 0) ret += ',';
        ret += this.pais[i].toString();
      }
      ret += ')';
      return ret;
    }

    public isFulu(): boolean {
      return this.type == E_Ming.shunzi || this.type == E_Ming.kezi || this.type == E_Ming.gang_ming;
    }
  }

  export enum E_PlayOperation { none, dapai, eat, peng, an_gang, ming_gang, add_gang, liqi, zimo, rong, jiuzhongjiupai, babei, huansanzhang, dingque, reveal, unveil, locktile, revealliqi, selecttile, po_liqi_5000, po_liqi_10000, po_tribute_choose_tile }
  export enum E_LiuJu { none, jiuzhongjiupai, sifenglianda, sigangsanle, sijializhi, sanjiahule }
  export enum E_Round_Result { liuju, shaoji, zimo, rong, fangchong, beizimo} // 回合结果：流局、烧鸡、自摸、荣胡、放铳、被别人自摸
  export enum E_Hu_Type { rong, zimo,  qianggang} // 胡类型：普通放铳， 自摸， 枪杠

  export  enum E_Dadian_Title {
    E_Dadian_Title_none,
    E_Dadian_Title_manguan,
    E_Dadian_Title_tiaoman,
    E_Dadian_Title_beiman,
    E_Dadian_Title_sanbeiman,
    E_Dadian_Title_yiman,
    E_Dadian_Title_yiman2,
    E_Dadian_Title_yiman3,
    E_Dadian_Title_yiman4,
    E_Dadian_Title_yiman5,
    E_Dadian_Title_yiman6,
    E_Dadian_Title_leijiyiman,
    E_Dadian_Title_liuman = -1 };
}

