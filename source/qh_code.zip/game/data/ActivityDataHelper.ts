/**
* UI_Activity_Spot  剧情活动 
*/
module game {
    // 以activityId为key的一组数据
    export class ActivityDataGroup {
        public activityId: number;
        public key: string;

        public updateData(data?: Object) {
            this.activityId = data['activity_id'];
            this.createData(data[this.key]);
        }
        // 创建对应数据
        public createData(infoList?: Array<Object>) {
        }
    }

    export class ActivityData {
        constructor(obj: Object) {
            this.registerData(obj);
            
        }

        public registerData(obj: Object) {
            for (let key in obj) {
                let data = obj[key];
                if (data instanceof Array) {
                    this[key] = [];
                    for (let info of data) {
                        this[key].push(info);
                    }
                }  else {
                    this[key] = data;
                }
            }
        }
    }
    export class ActivityDataHelper {
        public static map: {[key: number]: ActivityDataGroup};
        public static updateData(infos:Array<Object>) {
            this.map = {};
            for (let data of infos) {
                let group = this.createData(data);
                group.updateData(data);
                this.map[group.activityId] = group;
            }
        }

        public static createData(data: Object): ActivityDataGroup {
            let group = new ActivityDataGroup();
            return group;
        }
    }
}
