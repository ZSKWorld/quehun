/**
* UI_Activity_Spot  剧情活动 
*/
module game {
    // 以activityId为key的一组数据
    export class ActivitySpotDataGroup extends ActivityDataGroup {
        public activityId: number;
        public datas: Array<ActivitySpotData>;
        public key: string = 'spots';

        //初始化对应数据
        public createData(infoList?: Array<Object>) {
            this.datas = [];
            if (infoList) {
                for (let info of infoList) {
                    this.datas.push(new ActivitySpotData(info));
                }
            }
        }

        // 活动剧情解锁
        public add_lock_spot(unique_id: number) {
            let _data = this.getData(unique_id);
            if (_data) {
                _data.unlocked = true;
            } else {
                _data = new ActivitySpotData({ unique_id: unique_id, unlocked: true, unlocked_ending: [] });
                this.datas.push(_data);
            }
        }


        // 活动剧情结局解锁
        public add_lock_ending(unique_id: number, ending_id: number) {
            let _data = this.getData(unique_id);
            if (_data) {
                if (_data.unlocked_ending) {
                    _data.unlocked_ending.push(ending_id);
                } else {
                    _data.unlocked_ending = [ending_id];
                }
            } else {
                _data = new ActivitySpotData({ unique_id: unique_id, unlocked_ending: [ending_id] });
                this.datas.push(_data);
            }
        }

        public onSpotDataRewarded(unique_id: number) {
            let _data = this.getData(unique_id);
            if (_data) {
                _data.rewarded = true;
            } else {
                _data = new ActivitySpotData({ unique_id: unique_id, unlocked_ending: [], rewarded: true });
                this.datas.push(_data);
            }
        }

        public getData(unique_id: number): ActivitySpotData {
            for (let data of this.datas) {
                if (data.unique_id == unique_id) {
                    return data;
                }
            }
            return null;
        }
    }

    export class ActivitySpotData extends ActivityData {
        public unique_id: number;
        public rewarded: boolean;
        public unlocked_ending: Array<number>;
        public unlocked: boolean;
    }

    /**
     * 剧情活动数据管理
     */
    export class ActivitySpotDataHelper extends ActivityDataHelper {

        public static updateData(infos: Array<Object>) {
            if (!this.map) this.map = {};
            if (infos.length == 0) return;
            for (let data of infos) {
                let group = this.createData(data);
                group.updateData(data);
                this.map[group.activityId] = group;
            }
        }

        public static createData(data?: Object): ActivitySpotDataGroup {
            let group = new ActivitySpotDataGroup();
            return group;
        }

        public static getGroupData(activityId: number): ActivitySpotDataGroup {
            if (!this.map[activityId]) {
                this.map[activityId] = new ActivitySpotDataGroup();
                this.map[activityId].createData();
            }
            return this.map[activityId] as ActivitySpotDataGroup;
        }

        public static getSpotData(activityId: number, uniqueId: number): ActivitySpotData {
            let group = this.getGroupData(activityId);
            return group.getData(uniqueId);
        }
        // 活动剧情解锁
        public static add_lock_spot(activityId: number, uniqueId: number) {
            let group = this.getGroupData(activityId);
            group.add_lock_spot(uniqueId);
        }


        // 活动剧情结局解锁
        public static add_lock_ending(activityId: number, uniqueId: number, endingId: number) {
            let group = this.getGroupData(activityId);
            group.add_lock_ending(uniqueId, endingId);
        }

        public static onSpotDataRewarded(activityId: number, uniqueId: number) {
            let group = this.getGroupData(activityId);
            group.onSpotDataRewarded(uniqueId);
        }
    }
}
