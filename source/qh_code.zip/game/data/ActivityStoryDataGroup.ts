/**
* Story  剧情活动 
*/
module game {
    // 以activityId为key的一组数据
    export class ActivityStoryDataGroup extends ActivityDataGroup {
        public activityId: number;
        public datas: Array<game.IUnlockedStoryData>;
        public key: string = 'unlocked_story';

        //初始化对应数据
        public createData(infoList?: Array<IUnlockedStoryData>) {
            this.datas = [];
            if (infoList) {
                for (let info of infoList) {
                    this.datas.push(info);
                }
            }
        }

        public getData(unique_id: number): IUnlockedStoryData {
            for (let data of this.datas) {
                if (data.story_id == unique_id) {
                    return data;
                }
            }
            return null;
        }
    }


    /**
     * 剧情活动数据管理
     */
    export class ActivityStoryDataHelper extends ActivityDataHelper {

        public static updateData(infos: Array<Object>) {
            if (!this.map) this.map = {};
            if (infos.length == 0) return;
            for (let data of infos) {
                let group = this.createData(data);
                group.updateData(data);
                this.map[group.activityId] = group;
                Laya.stage.event(EventCode.ACTIVITY_SPOT_UPDATE);
            }   
        }

        public static createData(data?: Object): ActivityStoryDataGroup {
            let group = new ActivityStoryDataGroup();
            return group;
        }

        public static getGroupData(activityId: number): ActivityStoryDataGroup {
            if (!this.map[activityId]) {
                this.map[activityId] = new ActivitySpotDataGroup();
                this.map[activityId].createData();
            }
            return this.map[activityId] as ActivityStoryDataGroup;
        }

        public static getStoryData(activityId: number, uniqueId: number): IUnlockedStoryData {
            let group = this.getGroupData(activityId);
            return group.getData(uniqueId);
        }

        /**
         * 指定剧情是否可解锁
         * @param activityId 
         * @param storyId 
         * @returns 
         */
        public static isSpotCanUnlock(activityId: number, storyId: number): boolean {
            let data = this.getStoryActivityData(activityId,storyId);

            //如果有前置剧情，需要前置剧情已完成
            if (data.unlock_story) {
                //unlock_story按,分隔，里面是n个story_id，n个story_id都完成才解锁
                let storyIds = data.unlock_story.split(',');
                for (let storyId of storyIds) {
                    let info = this.getStoryData(activityId, Number(storyId));
                    if (!info) {
                        return false;
                    }
                    if (data.finish_reward && (!info.finish_rewarded || info.finish_rewarded == 0)) {
                        return false;
                    }
                    if (!info.finished_ending || info.finished_ending.length == 0) {
                        return false;
                    }

                }
            }
            //如果有解锁时间，需要到时间
            if (data.unlock_day) {
                let activityDeltaSeconds = uiscript.UI_Activity.getActivityDeltaSecondsFrom5(activityId);
                let restSeconds = data.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                if (restSeconds > 0) {
                    return false;
                }
            }
            //如果有解锁道具，需要有道具
            if (data.unlock_item) {
                let items = common.ConfigHelper.configString2Array<number>(data.unlock_item);
                for (let item of items) {
                    if (uiscript.UI_Bag.get_item_count(item[0]) < item[1]) {
                        // console.log("道具未充足", storyId, item[0], item[1], UI_Bag.get_item_count(item[0]));
                        return false;
                    }
                }
            }
            return true;
        }

        /**
         * 获取活动剧情配置数据
         * @param activityId 
         * @param storyId 
         * @returns 
         */
        public static getStoryActivityData(activityId: number, storyId: number): lqc.Sheet_Activity_StoryActivity {
            let datas = cfg.activity.story_activity.getGroup(activityId);
            for (let data of datas) {
                if (data.story_id == storyId) {
                    return data;
                }
            }
            return null;
        }
    }
    
}
