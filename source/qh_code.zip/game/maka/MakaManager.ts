module game {
    /**
     * Maka推荐操作类型
     */
    export enum EMakaOperationType {
        DEFAULT = 0,
        /**
         * 跳过
         */
        SKIP = 1,
        /**
         * 吃（前面，上家打 3s，吃345）
         */
        CHI_FRONT = 2,
        /**
         * 吃（中间，上家打 3s，吃234）
         */
        CHI_MIDDLE = 3,
        /**
         * 吃（后面，上家打 3s，吃123）
         */
        CHI_BACK = 4,
        /**
         * 碰
         */
        PENG = 5,
        /**
         * 杠
         */
        GANG = 6,
        /**
         * 胡,根据状态是【自己摸牌后】还是【别人打牌/暗杠后】，显示自摸/和
         */
        HU = 7,
        /**
         * 流局
         */
        LIUJU = 8,
        /**
         * 拔北
         */
        BABEI = 9,
        /**
         * 以普通方式出牌（非立直）
         */
        DA = 11,
        /**
         * 以立直方式出牌
         */
        LICHIDA = 12,
        /**
         * 自摸
         */
        ZIMO = 13,
    }
    /**
     * 牌谱分析状态
     */
    export enum EMakaAnalysisState {
        /**
         * 不可分析
         */
        UNANALYSIS = -1,
        /**
         * 未分析
         */
        NONE = 0,
        /**
         * 分析中
         */
        ANALYSISING = 1,
        /**
         * 分析完成
         */
        ANALYSISED = 2,
        /**
         * 分析内容过期
         */
        ANALYSIS_EXPIRED = 3,
        /**
         * 已经有详细数据了
         */
        FETCHED_DETAIL = 4,
    }

    export enum EMakaLevel {
        S_PLUS = 56,
        S = 55,
        S_MINUS = 54,
        A_PLUS = 46,
        A = 45,
        A_MINUS = 44,
        B_PLUS = 36,
        B = 35,
        B_MINUS = 34,
        C_PLUS = 26,
        C = 25,
        C_MINUS = 24,
        D_PLUS = 16,
        D = 15,
        E = 5,
    }

    /**
     * 推荐操作数据
     */
    export interface MakaOperation {
        /**
         * 操作类型
         */
        operationType: EMakaOperationType;
        /**
         * 牌值,如7s
         */
        tiles: mjcore.MJPai[];
        /**
         * 操作评分
         */
        score: number;
        /**
         * 对应对局内操作的序号
         */
        recordIndex: number;

    }

    /**
     * 操作数据
     */
    export interface MakaPredicationData {
        operations: MakaOperation[];
        /**
         * 是否执行的是推荐操作
         */
        isSame: boolean;
    }

    /**
     * 玩家数据
     */
    export interface MakaPlayer {
        seat: number;
        roundsData: MakaRoundData[];
        /**
         * 本次对局操作评分
         */
        rating: number;
    }
    /**
     * 局数据
     */
    export interface MakaRoundData {
        roundId: number;
        xunData: MakaXunData[];
        /**
         * 本局操作评分
         */
        rating: number;
    }

    /**
     * 巡数据
     */
    export interface MakaXunData {
        /**
         * 巡id
         */
        xunId: number;
        /**
         * 推荐操作数据，一个recordIndex对应一个推荐操作列表
         */
        predicationDataDic: basic.Dictionary<number, MakaPredicationData>;
        /**
         * recordIndex对应的该主视角操作
         */
        mineOperationDic: basic.Dictionary<number, MakaOperation>;
        /**
         * 是否有不同的操作
         */
        isSame: boolean;
    }

    export interface MakaAnalysisData {
        /**
         * 每个玩家的推荐操作和评分
         */
        players: MakaPlayer[];
        /**
        * 详细数据
        */
        detailData: game.ISeerReport;
    }

    /**
     * 牌谱分析数据
     */
    export class MakaData {
        /**
         * 对应牌谱uuid
         */
        uuid: string;
        /**
         * 分析数据
         */
        analysisData: MakaAnalysisData;
        /**
         * 分析过期时间
         */
        expireTime: number;

        /**
         * 分析状态
         */
        public get state(): EMakaAnalysisState {
            let currentState: EMakaAnalysisState = EMakaAnalysisState.NONE;
            if (game.MakaManager.Inst.isAnalysising(this.uuid)) {
                currentState = EMakaAnalysisState.ANALYSISING;
            }
            else if (!this.analysisData || !this.analysisData.players) {
                currentState = EMakaAnalysisState.NONE;
            } else {
                if (this.expireTime < (game.Tools.getServerTime() / 1000)) {
                    this.analysisData.detailData = null;
                    this.analysisData.players = null;
                    currentState = EMakaAnalysisState.ANALYSIS_EXPIRED;


                }
                else if (this.analysisData.detailData) {
                    currentState = EMakaAnalysisState.FETCHED_DETAIL;
                }
                else {
                    currentState = EMakaAnalysisState.ANALYSISED;
                }
            }
            return currentState;
        }


    }

    export class MakaManager {

        /**
         * 可以分析的Mode，1四人东 2 四人南 11 三人东 12 三人南
         */
        public static canAnalysisMode: Array<number> = [1, 2, 11, 12];

        /**
         * 两个操作是否一致
         * @param operation1 
         * @param operation2 
         * @returns 
         */
        public static isSame(operation1: MakaOperation, operation2: MakaOperation): boolean {
            if (operation1.operationType != operation2.operationType) {
                return false;
            }
            if (operation1.tiles == null && operation2.tiles == null) {
                return true;
            }
            if (operation1.tiles == null || operation2.tiles == null) {
                return false;
            }
            if (operation1.tiles.length != operation2.tiles.length) {
                return false;
            }
            for (let i = 0; i < operation1.tiles.length; i++) {
                const element1 = operation1.tiles[i];
                const element2 = operation2.tiles[i];
                if (element1.index != element2.index || element1.type != element2.type || element1.dora != element2.dora) {
                    return false;
                }
            }
            return true;

        }

        /**
         * 分析条件
         * 1.是否为维护模式
         * 2.是否小于限制时间
         * 3.是否包含自身
         * 4.是否为段位场/友人场/比赛场
         * 5.是否为四人东/南,或者三人东/南
         * 6.是否为可分析的标准格式
         * @param standard_rule 是否为标准的可分析牌谱
         * @param playerList 牌谱参与的所有人员
         * @param tag 标题类型 1排位赛 2友人场 3活动场 4比赛场
         * @param subtag 子标签，根据tag来 tag=1/3 就是matchmode.id，tag=2/4 就是mode.mode
         * @returns 
         */
        public static canAnalysis(tag: number, subtag: number, standard_rule: number, playerList: Array<number>, time: number): boolean {
            if (MakaManager.Inst.isMaintain) {
                return false;
            }
            //判断时间是否小于限制时间
            if (time < MakaManager.Inst.analysisLimitTime) {
                // ==DevDebug Start==
                if (!MakaManager.isDebug || MakaManager.Inst.httpErrorUuidList.indexOf(MakaManager.Inst.analysisingUuid) >= 0) {
                    // ==DevDebug End==
                    return false;
                    // ==DevDebug Start==
                }
                // ==DevDebug End==
            }
            //判断是否有自己
            let hasMyself = playerList.find(predicate => predicate == GameMgr.Inst.account_id);
            if (!hasMyself) {
                // ==DevDebug Start==
                if (!MakaManager.isDebug || MakaManager.Inst.httpErrorUuidList.indexOf(MakaManager.Inst.analysisingUuid) >= 0) {
                    // ==DevDebug End==
                    return false;
                    // ==DevDebug Start==
                }
                // ==DevDebug End==

            }
            //判断是否是段位场/友人场/比赛场，mode 1 四人东 2 四人南 11三人东 12 三人南
            if (tag == 1) {
                //判断是否是四人东/南
                let matchModeData = cfg.desktop.matchmode.get(subtag);
                if (!matchModeData) {
                    return false
                }
                if (matchModeData) {
                    if (this.canAnalysisMode.indexOf(matchModeData.mode) < 0) {
                        return false;
                    }
                }
            } else if (tag == 2 || tag == 4) {
                //友人场/比赛场
                if (this.canAnalysisMode.indexOf(subtag) < 0) {
                    return false;
                }

            } else {
                return false;
            }


            //判断是否是标准的可分析牌谱
            if (!standard_rule) {
                return false;
            }
            if (standard_rule != 1) {
                return false;
            }

            return true;
        }

        public static convertNumberToPai(value: number): mjcore.MJPai {
            let pai: mjcore.MJPai = null;
            let cardStr: string = "";
            let isDora: boolean = false;
            if (value < 20) {
                //赤5万
                if (value == 10) {
                    cardStr = 5 + "m";
                    isDora = true;
                } else {
                    cardStr = (value - 10) + "m";
                }
            }
            else if (value < 30) {
                //赤5饼
                if (value == 20) {
                    cardStr = 5 + "p";
                    isDora = true;
                } else {
                    cardStr = (value - 20) + "p";
                }
            }
            else if (value < 40) {
                //赤5条
                if (value == 30) {
                    cardStr = 5 + "s";
                    isDora = true;
                } else {
                    cardStr = (value - 30) + "s";
                }
            }
            else {
                cardStr = value - 40 + "z";
            }
            pai = mjcore.MJPai.Create(cardStr);
            pai.dora = isDora;
            return pai;
        }

        public static getOperationImg(actionType: EMakaOperationType, isBest: boolean): string {
            let resPath = "";
            switch (actionType) {
                case EMakaOperationType.SKIP:
                    resPath = "myres/mjdesktop/maka/big_skip";
                    break;
                case EMakaOperationType.CHI_FRONT:
                    resPath = "myres/mjdesktop/maka/big_chi";
                    break;
                case EMakaOperationType.CHI_MIDDLE:
                    resPath = "myres/mjdesktop/maka/big_chi";
                    break;
                case EMakaOperationType.CHI_BACK:
                    resPath = "myres/mjdesktop/maka/big_chi";
                    break;
                case EMakaOperationType.PENG:
                    resPath = "myres/mjdesktop/maka/big_peng";
                    break;
                case EMakaOperationType.GANG:
                    resPath = "myres/mjdesktop/maka/big_gang";
                    break;
                case EMakaOperationType.HU:
                    resPath = "myres/mjdesktop/maka/big_hu";
                    break;
                case EMakaOperationType.LIUJU:
                    resPath = "myres/mjdesktop/maka/big_liuju";
                    break;
                case EMakaOperationType.BABEI:
                    resPath = "myres/mjdesktop/maka/big_babei";
                    break;
                case EMakaOperationType.DA:
                    resPath = "myres/mjdesktop/maka/small_da";
                    break;
                case EMakaOperationType.LICHIDA:
                    resPath = "myres/mjdesktop/maka/small_lizhi";
                    break;
                case EMakaOperationType.ZIMO:
                    resPath = "myres/mjdesktop/maka/big_zimo";
                    break;
            }
            if (isBest) {
                resPath += "_recommend.png";
            } else {
                resPath += ".png";
            }
            return game.Tools.localUISrc(resPath);
        }


        public static get Inst(): MakaManager {
            if (!MakaManager.instance) {
                MakaManager.instance = new MakaManager();
            }
            return MakaManager.instance;
        }
        private static instance: MakaManager;

        /**
         * 分析次数
         */
        private _analysisCount: number = 0;
        /**
         * 分析次数
         */
        public get analysisCount(): number {

            return this._analysisCount - (this.analysisingUuid == "" ? 0 : 1);
        }

        public set analysisCount(value: number) {
            this._analysisCount = value;
            Laya.stage.event(EventCode.ON_MAKA_ANALYSIS_COUNT_CHANGE);
        }

        /**
         * 正在分析的牌谱uuid
         */
        private _analysisingUuid: string = "";
        /**
         * 正在分析的牌谱uuid
         */
        public get analysisingUuid(): string {
            return this._analysisingUuid;
        }

        public set analysisingUuid(value: string) {
            this._analysisingUuid = value;
            Laya.stage.event(EventCode.ON_MAKA_ANALYSIS_LIST_CHANGE, value);
        }
        /**
         * 分析数据
         */
        private _anaysisDic: basic.Dictionary<string, MakaData>;
        /**
         * 上次拉取次数的时间
         */
        public lastFetchTime: number = 0;
        private isReceiveMaintain: boolean = false;
        /**
         * 是否维护中
         */
        public get isMaintain(): boolean {
            return this.isReceiveMaintain || game.MaintainMgr.isModelMaintain(EMaintainFunctionName.MAKA);
        }
        /**
         * 在此时间之前的牌谱不可分析
         */
        public analysisLimitTime: number = 0;
        // ==DevDebug Start==
        /**
         * 是否是Debug模式
         */
        public static isDebug: boolean = true;
        /**
         * 请求错误的uuid列表
         */
        public httpErrorUuidList: string[] = [];
        // ==DevDebug End==



        public init() {
            this._anaysisDic = new basic.Dictionary<string, MakaData>();
            //获取分析次数
            this.fetchAnalysisCount();
            //获取分析列表
            this.fetchAnalysisList();
            //月卡变更监听
            Laya.stage.on(EventCode.MONTH_TICKET_CHANGE, this, this.fetchAnalysisCount);

            //分析成功监听
            app.NetAgent.addListener2Lobby(game.ENotify.NotifySeerReport, new Laya.Handler(this, (res) => {
                app.Log.log("【Maka】NotifySeerReport:" + JSON.stringify(res));
                let data = res as game.INotifySeerReport;
                this.onAnalysisComplete(data.report);
                this.analysisCount--;

            }));
            game.LobbyNetMgr.Inst.add_connect_listener(['OnRouteUseable'], this, () => {
                if (this.analysisingUuid != "") {
                    //获取分析次数
                    this.fetchAnalysisCount();
                    //获取分析列表
                    this.fetchAnalysisList();
                }
            });
        }


        /**
         * 获取剩余分析次数，在登录游戏和月卡状态改变时会刷新
         */
        public fetchAnalysisCount() {
            //如果维护，就不发送
            if (this.isMaintain) {
                return;
            }
            let reqCommon: game.IReqCommon = {};
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchSeerInfo, reqCommon, (err, res: game.IResFetchSeerInfo) => {
                app.Log.log("【Maka】fetchSeerInfo:" + JSON.stringify(res));
                if (err || res.error) {
                    if (res.error && res.error.code == MaintainMgr.maintainErrorCode) {
                        this.onReciveMaintainCode();
                    }
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchSeerInfo, err, res);
                } else {
                    this.lastFetchTime = game.Tools.getServerTime() / 1000;
                    this.analysisCount = res.remain_count;
                    this.analysisLimitTime = res.date_limit;
                }
            });
        }

        /**
         * 获取已分析（包含正在分析）的牌谱列表,目前只在登录游戏时获取一次
         */
        public fetchAnalysisList() {
            if (this.isMaintain) {
                return;
            }
            let reqCommon: game.IReqCommon = {};
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchSeerReportList, reqCommon, (err, res: game.IResFetchSeerReportList) => {
                // app.Log.log("【Maka】fetchSeerReportList:" + JSON.stringify(res));
                app.Log.log(`【Maka】fetchSeerReportList:Request:${JSON.stringify(reqCommon)},Response:${JSON.stringify(res)}`);
                if (!res) {
                    return;
                }
                if (err || res.error) {
                    if (res.error && res.error.code == MaintainMgr.maintainErrorCode) {
                        this.onReciveMaintainCode();
                    }
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchSeerReportList, err, res);
                } else {
                    this._anaysisDic.clear();
                    for (let i = 0; i < res.seer_report_list.length; i++) {
                        let data = res.seer_report_list[i];
                        if (data.state == EMakaAnalysisState.ANALYSISED) {
                            this.onAnalysisComplete(data);
                        } else {
                            this.analysisingUuid = data.uuid;
                        }
                    }
                }
            });
        }

        /**
         * 请求服务器分析牌谱
         * @param uuid 
         */
        public createAnalysisReq(uuid: string, onComplete: Laya.Handler = null) {
            let req: game.IReqCreateSeerReport = {
                uuid: uuid,
            }

            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.createSeerReport, req, (err, res: game.IResCreateSeerReport) => {
                app.Log.log("【Maka】createSeerReport-" + uuid + ":" + JSON.stringify(res));
                if (err || res.error) {
                    if (res.error && res.error.code == MaintainMgr.maintainErrorCode) {
                        this.onReciveMaintainCode();
                    }
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.createSeerReport, err, res);
                } else {
                    this.changeMakaData(res.seer_report);
                    if (res.seer_report.state == 2) {
                        this.onAnalysisComplete(res.seer_report);
                        this.analysisCount--;
                    } else {

                        this.analysisingUuid = uuid;
                    }

                }
                onComplete?.runWith([err, res]);

            });

        }

        /**
         * 获取详细分析数据
         * @param uuid 
         */
        public fetchAnalysisData(uuid: string, onComplete: Laya.Handler = null) {
            let req: game.IReqFetchSeerReport = {
                uuid: uuid,
            };
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchSeerReport, req, (err, res: game.IResFetchSeerReport) => {

                app.Log.log(`【Maka】FetchSeerReport: Request:${JSON.stringify(req)},Response:${JSON.stringify(res)}`);
                if (err || res.error) {
                    if (res.error && res.error.code == MaintainMgr.maintainErrorCode) {
                        this.onReciveMaintainCode();
                    }
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchSeerReport, err, res, Laya.Handler.create(this, () => {
                        onComplete?.runWith([err, res]);
                    }));
                } else {
                    let makaData = this._anaysisDic.get(uuid);
                    if (makaData && makaData.state == EMakaAnalysisState.ANALYSISED) {
                        makaData.analysisData.detailData = res.report;
                        Laya.stage.event(EventCode.ON_FETCH_MAKA_DETAIL_COMPLETE, uuid);
                    }
                    onComplete?.runWith([err, res]);

                }


            });
        }






        /**
         * 对应牌谱是否正在分析
         * @param uuid 
         * @returns 
         */
        public isAnalysising(uuid: string): boolean {
            return MakaManager.Inst.analysisingUuid == uuid;
        }

        private onAnalysisComplete(data: game.ISeerBrief) {
            app.Log.log("【Maka】onAnalysisComplete:" + JSON.stringify(data));
            let uuid = data.uuid;
            this.changeMakaData(data);
            if (this.analysisingUuid == uuid) {
                this.analysisingUuid = "";
            }
            Laya.stage.event(EventCode.ON_MAKA_ANALYSIS_COMPLETE, uuid);
        }


        /**
         * 获取对应等级的图片
         * @param level 
         * @returns 
         */
        public static getLevelImg(level: EMakaLevel): string {
            let resPath = "myres/bothui/maka/maka_level_" + level + ".png";
            return game.Tools.localUISrc(resPath);
        }

        public getMakaData(uuid: string): MakaData {
            return this._anaysisDic.get(uuid);
        }

        /**
         * 获取对局详细数据
         * @param uuid 
         * @returns 
         */
        public getMakaMatchDetail(uuid: string): game.ISeerReport {
            let makaData = this._anaysisDic.get(uuid);
            if (makaData) {
                return makaData.analysisData.detailData;
            }
            return null;
        }

        /**
         * 获取指定对局某个玩家的推荐操作
         * @param uuid 
         * @param seat 
         * @returns 
         */
        public getMakaPlayerData(uuid: string, seat: number): MakaPlayer {
            let makaData = this._anaysisDic.get(uuid);
            if (makaData && makaData.analysisData.players) {
                let predicate = makaData.analysisData.players.find(predicate => predicate.seat == seat);
                if (!predicate || !predicate.roundsData) {
                    return null;
                }
                return makaData.analysisData.players.find(predicate => predicate.seat == seat);
            }
            return null;
        }

        public setMakaPlayerData(uuid: string, seat: number, rounds: Array<uiscript.Round>): MakaPlayer {
            let makaData = this._anaysisDic.get(uuid);
            if (!makaData || !makaData.analysisData || !makaData.analysisData.players) {
                app.Log.log("【Maka】setMakaPlayerData error:uuid not found:" + uuid);
                return;
            }
            let localPlayerData = makaData.analysisData.players.find(predicate => predicate.seat == seat);
            if (!localPlayerData) {
                app.Log.log("【Maka】setMakaPlayerData error:seat not found:" + uuid + "," + seat);
                return;
            }
            let serverData = makaData.analysisData.detailData;
            if (!serverData) {
                app.Log.log("【Maka】setMakaPlayerData error:serverData not found:" + uuid);
                return;
            }

            let makaRoundsData: MakaRoundData[] = localPlayerData.roundsData;
            if (makaRoundsData) {
                return localPlayerData;
            }
            makaRoundsData = [];
            for (let i = 0; i < rounds.length; i++) {
                let roundIndex = i;
                let round = rounds[roundIndex];
                let makaXunsData: MakaXunData[] = [];
                //本局操作评分
                let roundScore = serverData.rounds[i].player_scores.find(predicate => predicate.seat == seat).rating;
                let makaRoundData: MakaRoundData = {
                    roundId: roundIndex,
                    xunData: makaXunsData,
                    rating: roundScore,
                }
                makaRoundsData.push(makaRoundData);
                //round里面的所有巡
                //xun里面是每巡的开始id
                let xuns = round.xun;
                //第几巡
                let xunIndex = 0;
                // 如果没有第0巡，xuns中第一个是0，如果有xuns中的第一个是第一巡的开始

                let nextStartIndex: number = 0;
                let nextXunStartIndex = xuns[nextStartIndex];
                if (nextXunStartIndex == 0) {
                    nextStartIndex++;
                    nextXunStartIndex = xuns[nextStartIndex];
                }


                let makaXunData: MakaXunData = {
                    xunId: xunIndex,
                    predicationDataDic: new basic.Dictionary<number, MakaPredicationData>(),
                    mineOperationDic: new basic.Dictionary<number, MakaOperation>(),
                    isSame: true,
                }
                makaXunsData.push(makaXunData);
                //遍历round的action
                for (let j = 0; j < round.actions.length; j++) {
                    let actionIndex = j;
                    //如果到了下一巡的开始id，就切换到下一巡
                    if (actionIndex == nextXunStartIndex) {
                        xunIndex++;
                        makaXunData = {
                            xunId: xunIndex,
                            predicationDataDic: new basic.Dictionary<number, MakaPredicationData>(),
                            mineOperationDic: new basic.Dictionary<number, MakaOperation>(),
                            isSame: true,
                        }
                        nextStartIndex++;
                        nextXunStartIndex = xuns[nextStartIndex];
                        makaXunsData.push(makaXunData);
                    }

                    let currentAction = round.actions[actionIndex];
                    let nextAction = round.actions[actionIndex + 1];
                    if (currentAction.name == "RecordDiscardTile" && currentAction.data['seat'] == seat) {
                        //如果是自己打牌的操作，不需要推荐操作
                        continue;
                    }
                    let actionHands: uiscript.ActionHands = null;
                    if (round.tilesDic.has(actionIndex)) {
                        actionHands = round.tilesDic.get(actionIndex);
                    }
                    else {
                        app.Log.log("【Maka】setMakaPlayerData error:hands not found:" + uuid + ",roundIndex:" + i + ",actionIndex," + actionIndex);
                    }

                    let index = currentAction.allIndex;
                    //找到本次操作下的该玩家所有推荐操作
                    let events = serverData.events.find(predicate => predicate.record_index == index);
                    let predicationData: MakaPredicationData = {
                        operations: [],
                        isSame: false,
                    };
                    if (events) {
                        let operations = events.recommends.find(predicate => predicate.seat == seat);
                        if (operations) {
                            //获取我的执行操作
                            let mineOperation = this.getMyAction(seat, rounds, i, actionIndex);
                            makaXunData.mineOperationDic.set(index, mineOperation);
                            let hasSame = false;
                            //找到最佳操作
                            let bestIndex = 0;
                            for (let k = 0; k < operations.predictions.length; k++) {
                                //现在服务器结果会超过3个，只取前三个即可
                                if (k >= 3) {
                                    break;
                                }
                                if (k != 0) {
                                    bestIndex = operations.predictions[k].score > operations.predictions[bestIndex].score ? k : bestIndex;
                                }
                                let makaOperation = MakaManager.convertCodeToOperation(operations.predictions[k]);
                                //判断是否是自摸，如果当前操作是自己摸牌，则是自摸
                                if (makaOperation.operationType == EMakaOperationType.HU) {

                                    if (currentAction.name == "RecordDealTile" && currentAction.data['seat'] == seat) {
                                        makaOperation.operationType = EMakaOperationType.ZIMO;
                                    }
                                }
                                makaOperation.recordIndex = index;
                                if (!makaOperation.tiles || makaOperation.tiles.length == 0) {
                                    //赋值对应的操作牌
                                    if (makaOperation.operationType >= 2 && makaOperation.operationType <= 4) {
                                        //吃
                                        makaOperation.tiles = this.getChiTiles(currentAction.data, makaOperation.operationType, actionHands.tiles);
                                        // app.Log.log(`【Maka】吃 Seat:${seat},Round:${roundIndex},ActionIndex:${actionIndex}`);
                                    } else if (makaOperation.operationType == game.EMakaOperationType.PENG) {
                                        //碰
                                        makaOperation.tiles = this.getPengTiles(currentAction.data, actionHands.tiles);
                                        // app.Log.log(`【Maka】碰 Seat:${seat},Round:${roundIndex},ActionIndex:${actionIndex}`);
                                    } else if (makaOperation.operationType == game.EMakaOperationType.GANG) {
                                        //杠
                                        //如果出现多个杠服务器却未返回的情况，上报数据
                                        let onError: Laya.Handler = Laya.Handler.create(this, () => {
                                            let errorData = {
                                                uuid: uuid,
                                                seat: seat,
                                                record_index: index
                                            }
                                            GameMgr.Inst.postInfo2Server("maka_gang_error", errorData, false);
                                        });
                                        makaOperation.tiles = this.getGangTiles(seat, currentAction, actionHands, onError);
                                        // app.Log.log(`【Maka】杠 Seat:${seat},Round:${roundIndex},ActionIndex:${actionIndex}`);
                                    }

                                }

                                predicationData.operations.push(makaOperation);

                            }
                            //检查我的操作是否与最佳操作一致
                            let bestOperation = predicationData.operations[bestIndex];
                            if (bestOperation) {
                                hasSame = MakaManager.isSame(mineOperation, bestOperation);
                                //如果我是跳过但最佳操作不是跳过，需要判断是否为强制跳过
                                if (mineOperation.operationType == EMakaOperationType.SKIP && bestOperation.operationType != EMakaOperationType.SKIP) {
                                    let isForceSkip = this.isForceSkip(nextAction, predicationData, seat);
                                    hasSame = isForceSkip;
                                }
                            }
                            predicationData.isSame = hasSame;
                            if (!hasSame) {
                                makaXunData.isSame = false;
                            }
                            makaXunData.predicationDataDic.set(index, predicationData);
                        }
                    }
                }
            }
            localPlayerData.roundsData = makaRoundsData;
            return localPlayerData;

        }

        public static convertCodeToOperation(prediction: ISeerPrediction): MakaOperation {
            let makaOperation: MakaOperation = {
                operationType: EMakaOperationType.DEFAULT,
                tiles: null,
                score: prediction.score,
                recordIndex: 0,
            };


            if (prediction.action < 10) {
                switch (prediction.action) {
                    case 1:
                        makaOperation.operationType = EMakaOperationType.SKIP;
                        break;
                    case 2:
                        makaOperation.operationType = EMakaOperationType.CHI_FRONT;
                        break;
                    case 3:
                        makaOperation.operationType = EMakaOperationType.CHI_MIDDLE;
                        break;
                    case 4:
                        makaOperation.operationType = EMakaOperationType.CHI_BACK;
                        break;
                    case 5:
                        makaOperation.operationType = EMakaOperationType.PENG;
                        break;
                    case 6:
                        makaOperation.operationType = EMakaOperationType.GANG;
                        break;
                    case 7:
                        makaOperation.operationType = EMakaOperationType.HU;
                        break;
                    case 8:
                        makaOperation.operationType = EMakaOperationType.LIUJU;
                        break;
                    case 9:
                        makaOperation.operationType = EMakaOperationType.BABEI;
                        break;
                }
            }
            else if (prediction.action < 200) {
                makaOperation.operationType = EMakaOperationType.DA;
                makaOperation.tiles = [MakaManager.convertNumberToPai(prediction.action - 100)];
            }
            else if (prediction.action < 300) {
                makaOperation.operationType = EMakaOperationType.LICHIDA;
                makaOperation.tiles = [MakaManager.convertNumberToPai(prediction.action - 200)];
            }
            else if (prediction.action < 400) {
                makaOperation.operationType = EMakaOperationType.GANG;
                makaOperation.tiles = [MakaManager.convertNumberToPai(prediction.action - 300)];
            }
            return makaOperation;
        }



        /**
         * 获取我的执行操作
         * @param roundIndex 
         * @param actionIndex 
         * @returns 
         */
        private getMyAction(seat: number, rounds: Array<uiscript.Round>, roundIndex: number, actionIndex: number): game.MakaOperation {
            let makaOperation: game.MakaOperation = {
                operationType: game.EMakaOperationType.SKIP,
                tiles: null,
                score: -1,
                recordIndex: 0
            };
            let nextOperation = rounds[roundIndex].actions[actionIndex + 1];
            let currentAction = rounds[roundIndex].actions[actionIndex];
            if (nextOperation) {
                //如果是胡牌，且胡了的信息里有我，则是胡了，否则为跳过
                if (nextOperation.name == view.ERecordType.Hu) {
                    let huleData = nextOperation.data as game.IRecordHule;
                    let hulePlayers = huleData.hules;
                    let isMeHule = false;
                    for (let i = 0; i < hulePlayers.length; i++) {
                        if (hulePlayers[i].seat == seat) {
                            isMeHule = true;
                            break;
                        }
                    }
                    if (isMeHule) {

                        makaOperation.operationType = game.EMakaOperationType.HU;
                        //如果是自己摸牌后胡牌，则是自摸
                        if (currentAction.name == "RecordDealTile" && currentAction.data['seat'] == seat) {
                            makaOperation.operationType = game.EMakaOperationType.ZIMO;
                        }
                    } else {
                        makaOperation.operationType = game.EMakaOperationType.SKIP;
                    }
                }
                else if (nextOperation.name == view.ERecordType.LiuJu) {
                    let liujuData = nextOperation.data as game.IRecordLiuJu;
                    if (liujuData.seat == seat) {
                        makaOperation.operationType = game.EMakaOperationType.LIUJU;
                    }
                }
                else {
                    //如果下一步操作不是我，则是跳过,或者下一步是我，但是是起牌
                    if (nextOperation.data['seat'] != seat) {
                        makaOperation.operationType = game.EMakaOperationType.SKIP;
                    } else if (nextOperation.name == view.ERecordType.DealTile) {
                        makaOperation.operationType = game.EMakaOperationType.SKIP;
                    }
                    else {
                        if (nextOperation.name == view.ERecordType.ChiPengGang) {
                            let data = nextOperation.data as game.IRecordChiPengGang;
                            let actionType: mjcore.E_Ming = data.type;
                            let tiles = data.tiles;
                            let froms = data.froms;
                            let pais: mjcore.MJPai[] = [];
                            //吃
                            if (actionType == mjcore.E_Ming.shunzi) {
                                let fromOther: string = "";
                                //获取用来组合吃的牌(排除不属于我的那张)
                                for (let index = 0; index < tiles.length; index++) {
                                    let from = froms[index];
                                    let tile = tiles[index];
                                    if (from == seat) {
                                        pais.push(mjcore.MJPai.Create(tile));
                                    } else {
                                        //如果Index =0 则为前，1为中，2为后
                                        fromOther = tile;
                                    }
                                }
                                //把tiles排序，然后根据fromOther的位置来判断是前中后
                                let sortedTiles = game.Tools.sortPaiStr(tiles);
                                let index = sortedTiles.indexOf(fromOther);
                                if (index == 0) {
                                    makaOperation.operationType = game.EMakaOperationType.CHI_FRONT;
                                } else if (index == 1) {
                                    makaOperation.operationType = game.EMakaOperationType.CHI_MIDDLE;
                                } else if (index == 2) {
                                    makaOperation.operationType = game.EMakaOperationType.CHI_BACK;
                                }
                                makaOperation.tiles = pais;
                            }
                            //碰
                            else if (actionType == mjcore.E_Ming.kezi) {
                                //获取用来组合碰的牌(排除不属于我的那张)
                                for (let index = 0; index < tiles.length; index++) {
                                    let from = froms[index];
                                    let tile = tiles[index];
                                    if (from == seat) {
                                        pais.push(mjcore.MJPai.Create(tile));
                                    }
                                }
                                makaOperation.operationType = game.EMakaOperationType.PENG;
                                makaOperation.tiles = pais;
                            }
                            //杠
                            else if (actionType == mjcore.E_Ming.gang_ming) {
                                //获取不属于我的那张
                                for (let index = 0; index < tiles.length; index++) {
                                    let from = froms[index];
                                    let tile = tiles[index];
                                    if (from != seat) {
                                        let pai = mjcore.MJPai.Create(tile);
                                        // pai.dora = false;
                                        pais.push(pai);
                                    }
                                }
                                makaOperation.operationType = game.EMakaOperationType.GANG;
                                makaOperation.tiles = pais;
                            }

                        } else if (nextOperation.name == view.ERecordType.DiscardTile) {
                            //打
                            let data = nextOperation.data as game.IRecordDiscardTile;
                            let tile = data.tile;
                            let pai = mjcore.MJPai.Create(tile);
                            if (data.is_liqi) {
                                makaOperation.operationType = game.EMakaOperationType.LICHIDA;
                            } else {
                                makaOperation.operationType = game.EMakaOperationType.DA;
                            }
                            makaOperation.tiles = [pai];
                        } else if (nextOperation.name == view.ERecordType.AnGangAddGang) {
                            //杠
                            let data = nextOperation.data as game.IRecordAnGangAddGang;
                            let tile = data.tiles;
                            let pai = mjcore.MJPai.Create(tile);
                            if (data.type == mjcore.E_Ming.gang_an) {
                                pai.dora = false;
                            }
                            makaOperation.operationType = game.EMakaOperationType.GANG;
                            makaOperation.tiles = [pai];
                        } else if (nextOperation.name = view.ERecordType.BaBei) {
                            makaOperation.operationType = game.EMakaOperationType.BABEI;

                        }
                    }
                }


            }
            //给tiles排序
            if (makaOperation.tiles) {
                makaOperation.tiles = game.Tools.sortPai(makaOperation.tiles);


            }

            return makaOperation;

        }


        private getChiTiles(lastAction: Object, operationType: game.EMakaOperationType, hands: mjcore.MJPai[]) {
            let tiles: Array<mjcore.MJPai> = [];
            if (!lastAction) {
                return tiles;
            }
            if (!lastAction['tile']) {
                return tiles;
            }
            let currentPai = mjcore.MJPai.Create(lastAction['tile']);
            let pai1: mjcore.MJPai = null;
            let pai2: mjcore.MJPai = null;
            if (operationType == game.EMakaOperationType.CHI_FRONT) {
                pai1 = currentPai.getNextCard();
                pai2 = pai1.getNextCard();
            }
            else if (operationType == game.EMakaOperationType.CHI_MIDDLE) {
                pai1 = currentPai.getPrevCard();
                pai2 = currentPai.getNextCard();
            }
            else if (operationType == game.EMakaOperationType.CHI_BACK) {
                pai1 = currentPai.getPrevCard();
                pai2 = pai1.getPrevCard();
            }
            pai1.dora = this.checkDora(pai1, hands);
            pai2.dora = this.checkDora(pai2, hands);
            tiles.push(pai1);
            tiles.push(pai2);
            //排序
            tiles = game.Tools.sortPai(tiles);
            return tiles;
        }



        private getPengTiles(lastAction: Object, hands: mjcore.MJPai[]): mjcore.MJPai[] {
            if (!lastAction) {
                return [];
            }
            if (!lastAction['tile']) {
                return [];
            }
            let pais: mjcore.MJPai[] = []
            let currentPai = mjcore.MJPai.Create(lastAction['tile']);
            for (let index = 0; index < hands.length; index++) {
                let pai = hands[index];
                if (pai.index == currentPai.index && pai.type == currentPai.type) {
                    pais.push(pai);
                }
            }
            //这里只需要两张牌，如果有红5，则留下红5和其中一张，否则随便留下两张
            let doraIndex = -1;
            for (let index = 0; index < pais.length; index++) {
                let pai = pais[index];
                if (pai.dora) {
                    doraIndex = index;
                    break;
                }
            }
            if (doraIndex >= 0) {
                let doraPai = pais[doraIndex];
                let otherIndex = doraIndex == 0 ? 1 : 0;
                pais = [pais[otherIndex], doraPai];
            } else {
                pais = pais.slice(0, 2);
            }

            //排序
            pais = game.Tools.sortPai(pais);
            return pais;

        }

        private getGangTiles(seat: number, currentAction: Object, hands: uiscript.ActionHands, onError: Laya.Handler): mjcore.MJPai[] {
            let tiles = [];
            let currentActionData = currentAction['data'];
            //不是我的回合，拿当前播放的牌,是我的回合或者是新回合通过手牌计算杠（如果有多个杠，则服务器会告知是哪个，如果只有一个，则自己计算）
            if (currentAction['name'] == 'RecordNewRound' || currentActionData['seat'] == seat) {
                //在自己的手牌中找到杠的牌
                let handCountDic: basic.Dictionary<string, number> = new basic.Dictionary<string, number>();
                for (let i = 0; i < hands.tiles.length; i++) {
                    let pai = hands.tiles[i];
                    let key = pai.index.toString() + pai.typeName;

                    if (handCountDic.has(key)) {
                        let currentCount = handCountDic.get(key) + 1;
                        handCountDic.set(key, currentCount);
                        if (currentCount == 4) {
                            let pai = mjcore.MJPai.Create(key);
                            tiles.push(pai);
                            break;
                        }
                    } else {
                        handCountDic.set(key, 1);
                    }

                }


                //如果没有杠，说明可能是加杠,根据明牌再进行一次上面的计算,明牌时显示手里的那张牌,如果明牌里有3张，则是加杠
                if (tiles.length == 0) {
                    for (let i = 0; i < hands.tilesMings.length; i++) {
                        let mingGroup = hands.tilesMings[i];
                        //找到明牌组里是碰，且手牌里有一张对应的牌，则是加杠
                        let isSame = true;
                        if (mingGroup.length != 3) {
                            continue;
                        }
                        let currentCheckPai = mingGroup[0];
                        for (let index = 0; index < mingGroup.length; index++) {
                            if (currentCheckPai.index != mingGroup[index].index || currentCheckPai.type != mingGroup[index].type) {
                                isSame = false;
                                break;
                            }
                        }
                        //是碰
                        if (isSame) {
                            let key = currentCheckPai.index.toString() + currentCheckPai.typeName;
                            //手牌里还有一张
                            if (handCountDic.has(key)) {
                                let pai = mjcore.MJPai.Create(key);
                                tiles.push(pai);
                            }
                        }
                    }

                    //根据tiles里的值，替换成手牌里的值
                    for (let i = 0; i < tiles.length; i++) {
                        let pai = tiles[i];
                        for (let j = 0; j < hands.tiles.length; j++) {
                            let handPai = hands.tiles[j];
                            if (pai.index == handPai.index && pai.type == handPai.type) {
                                tiles[i] = handPai.Clone();
                                break;
                            }
                        }
                    }
                }
                //如果有多个杠，则上报数据，且只取第一个
                if (tiles.length > 1) {
                    onError?.run();
                    //只取第一个
                    tiles = tiles.slice(0, 1);
                }

            } else {
                if (currentActionData && currentActionData['tile']) {
                    let currentPai = mjcore.MJPai.Create(currentActionData['tile']);
                    tiles.push(currentPai);
                }

            }
            return tiles;
        }

        /**
        * 检查是否应该显示为红5,需要主视角当前手牌里有同等值红5
        * @param pai 
        */
        private checkDora(pai: mjcore.MJPai, hands: mjcore.MJPai[]): boolean {
            if (pai.index != 5) {
                return false;
            }
            // 主视角手牌里有同等值红5
            for (let i = 0; i < hands.length; i++) {
                let handPai = hands[i];
                if (handPai.index == 5 && handPai.type == pai.type && handPai.dora) {
                    return true;
                }
            }

            return false;
        }

        /**
         * 获取指定牌谱指定玩家指定局指定巡指定recordIndex(allIndex)的推荐操作
         * @param uuid 
         * @param seat 
         * @param roundIndex 
         * @param xunIndex 
         * @param recordIndex recordIndex为AllIndex
         * @returns 
         */
        public getMakaPredication(uuid: string, seat: number, roundIndex: number, xunIndex: number, recordIndex: number): MakaPredicationData {
            let makaData = this._anaysisDic.get(uuid);
            if (makaData && makaData.analysisData.players) {
                let playerData = makaData.analysisData.players.find(predicate => predicate.seat == seat);
                if (playerData && playerData.roundsData) {
                    let roundData = playerData.roundsData.find(predicate => predicate.roundId == roundIndex);
                    if (roundData && roundData.xunData) {
                        let xunData = roundData.xunData.find(predicate => predicate.xunId == xunIndex);
                        if (xunData && xunData.predicationDataDic) {
                            let operations = xunData.predicationDataDic.get(recordIndex);
                            if (operations) {
                                return operations;
                            }
                        }
                    }
                }
            }
            return;
        }

        public checkAnalysisingExpire() {
            let now = game.Tools.getServerTime() / 1000;
            if (this.analysisingUuid == "") {
                return;
            }
            let makaData = this._anaysisDic.get(this.analysisingUuid);
            if (!makaData) {
                return;
            }
            if (makaData.expireTime < now) {
                this.analysisingUuid = "";
            }
        }

        private changeMakaData(data: game.ISeerBrief) {
            let makaData = this._anaysisDic.get(data.uuid);
            if (!this._anaysisDic.has(data.uuid)) {
                makaData = new MakaData();
                this._anaysisDic.set(data.uuid, makaData);
            }
            makaData.uuid = data.uuid;
            makaData.expireTime = data.expire_time;
            makaData.analysisData = {
                players: null,
                detailData: null,
            };
            let playerScores = data.player_scores;
            if (playerScores) {
                let players: MakaPlayer[] = [];
                for (let index = 0; index < playerScores.length; index++) {
                    let playerScore = playerScores[index];
                    players.push({
                        seat: playerScore.seat,
                        roundsData: null,
                        rating: playerScore.rating,
                    });
                }
                makaData.analysisData.players = players;
            }

        }

        private onReciveMaintainCode() {
            this.isReceiveMaintain = true;
            Laya.stage.event(EventCode.MAKA_MAINTAIN_CHANGE);
        }

        /**
         * 判断是否是强制跳过
         * 1.如果下一步是其他人和牌，且我没有和牌的预测，则是强制跳过
         * 2.如果下一步是其他人的碰，杠，且我没有和牌的预测，则是强制跳过
         */
        private isForceSkip(nextOperation: any, prediction: MakaPredicationData, seat: number): boolean {
            let isForceSkip = false;
            let hasPreditionHu = false;
            for (let i = 0; i < prediction.operations.length; i++) {
                if (prediction.operations[i].operationType == game.EMakaOperationType.HU) {
                    hasPreditionHu = true;
                    break;
                }
            }
            if (nextOperation) {
                if (nextOperation.name == view.ERecordType.Hu) {
                    let huleData = nextOperation.data as game.IRecordHule;
                    let hulePlayers = huleData.hules;
                    let isMeHule = false;
                    for (let i = 0; i < hulePlayers.length; i++) {
                        if (hulePlayers[i].seat == seat) {
                            isMeHule = true;
                            break;
                        }
                    }
                    if (!isMeHule && !hasPreditionHu) {
                        isForceSkip = true;
                    }

                } else if (nextOperation.name == view.ERecordType.ChiPengGang) {
                    //如果是别人的碰杠，且我没有和牌的预测，则是强制跳过
                    let chiPengData = nextOperation.data as game.IRecordChiPengGang;
                    //如果数据里是顺子，则是吃
                    if (chiPengData.type != mjcore.E_Ming.shunzi) {
                        if (chiPengData.seat != seat && !hasPreditionHu) {
                            isForceSkip = true;
                        }
                    }
                }
            }
            return isForceSkip;
        }

        // ==DevDebug Start==
        /**
        * 通过http请求获取其他玩家的牌谱数据
        * @param uuid 
        * @param onComplete 
        */
        public fetchOtherMakaData(uuid: string, func_response: (error, res) => void) {
            if (this.isMaintain || this.httpErrorUuidList.indexOf(uuid) >= 0) {
                func_response(new Error(`Error`), null);
                return;
            }
            let url = `http://47.111.77.111:16071/api/seer/report/${uuid}?ignore_account_id=true`
            game.LoadMgr.httpload(url, "json", false, Laya.Handler.create(this, d => {
                if (!d.success) {
                    app.Log.log("【Maka】fetchOtherMakaData Http Error:" + uuid + ",msg:" + d.msg);
                    this.httpErrorUuidList.push(uuid);
                    func_response(new Error(`Http Error`), null);
                    return;
                }
                let serverData = d.data.data;
                if (serverData) {
                    let makaDetail: game.IResFetchSeerReport = game.Tools.fixHttpJsonData(serverData, ServerType.LOBBY, game.ERequest.fetchSeerReport);
                    let accounts: number[] = serverData.accounts;
                    let playerScores: game.ISeerScore[] = [];
                    for (let i = 0; i < accounts.length; i++) {
                        let score: game.ISeerScore = {
                            seat: i,
                            rating: 5,
                        }
                        playerScores.push(score);
                    }

                    //伪造分析完毕的数据
                    let seerBrief: game.ISeerBrief = {
                        uuid: serverData.uuid,
                        expire_time: game.Tools.getServerTime() * 2,
                        player_scores: playerScores,
                        create_time: game.Tools.getServerTime(),
                        state: 2,
                    }
                    this.onAnalysisComplete(seerBrief);
                    let makaData = this._anaysisDic.get(uuid);
                    makaData.analysisData.detailData = makaDetail.report;
                    Laya.stage.event(EventCode.ON_FETCH_MAKA_DETAIL_COMPLETE, uuid);
                    func_response(null, serverData);
                } else {
                    this.httpErrorUuidList.push(uuid);
                    func_response(new Error(`Data Error`), null);
                }
            }));
        }
        // ==DevDebug End==

    }
}
