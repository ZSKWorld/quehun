/**
* name 
*/
module game{

	export enum E_LoadState { none, loading, loaded }

	export abstract class SceneBase {

		private _active:boolean = false;
		protected _load_state: E_LoadState = E_LoadState.none;
		public get active():boolean { return this._active; }
		public set active(v:boolean) { 
			if (this._active == v) return;
			this._active = v;
			if (this._active) this.onEnable();
			else this.onDisable();
		 }
		 public get load_state():E_LoadState {
			return this._load_state;
		 }

		public abstract init(data:any);

		protected abstract onEnable();

		protected abstract onDisable();
	}
}