/**
* name 
*/
module game {
    export class Scene_Activity extends SceneBase {
        public static Inst: Scene_Activity = null;
        private readonly ui_effect_list: Array<string> = [
            // 雀斗大会特效
            // 'scene/effect_simulation_logo.lh',
            // 'scene/effect_simulation_success_big.lh',
            // 'scene/effect_simulation_train_result.lh',
            // 'scene/effect_simulation_match_start_front2.lh',
            // 神驰集愿特效
            // 'scene/effect_2602_operation.lh',
            // 'scene/effect_2602_pai_star.lh',
            // mmo特效
            'scene/effect_mmo_lose.lh',
            'scene/effect_mmo_win.lh',
            'scene/effect_mmo_talent.lh',
            'scene/effect_mmo_btn1.lh',
            'scene/effect_mmo_btn2.lh',
            'scene/effect_mmo_btn3.lh',
            'scene/effect_mmo_btn4.lh',
            'scene/effect_mmo_currency.lh',
            'scene/effect_mmo_select.lh',
            'scene/effect_2604mmo_qiangduo_dianji.lh',
            'scene/effect_2604mmo_task_sg.lh',
            'scene/effect_mmo_tavern_show.lh',
            'scene/effect_mmo_member_show.lh',
            'scene/effect_mmo_cloud.lh'
        ];

        private readonly _scene_effect_list: Array<string> = [
            // 雀斗大会特效
            // 'scene/effect_simulation_bg.ls',
            // 'scene/effect_simulation_event.ls',
            // 神驰集愿特效
            // 'scene/effect_2602_bg.ls',
            // 'scene/effect_2602_bg_front.ls',
            // mmo特效
            'scene/effect_mmo_spine_effect.ls',
            'scene/effect_mmo_bg.ls',
            'scene/effect_2604mmo_equipment.ls',
            'scene/effect_mmo_tavern_bg.ls',
            'scene/effect_mmo_battle_bg.ls',
        ];
        private bgLst: Array<string> = [];
        private _mjp_textures: Array<string> = []; //麻将牌的贴图，关闭的时候要释放掉
        private mjp_default_surface_view: string = '';        //默认麻将牌的外观，如果需要额外加载默认麻将牌时使用
        private activityFinishHandler: Laya.Handler;

        public constructor() {
            super();
            Scene_Activity.Inst = this;
            this.bgLst = [];
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            // this.bgLst.push(game.Tools.localUISrc('myres/activity_simulation/background_practice_web.jpg'));
        }

        private onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == uiscript.UI_Activity_Liandong_Main.activityId) {
                        uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.QuitScene();
                        }))
                        return;
                    }
                }
            }
        }

        public init(data: any) {
        }

        protected onEnable() {
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            uiscript.UI_Invite.Inst.enable = true;
            uiscript.UIMgr.Inst.onSceneActivity_Enable();
            uiscript.UI_Activity_MMO_Result.Inst.onSceneEnable();
        }

        protected onDisable() {
            uiscript.UI_Activity_MMO_Top.stopBgm();
            view.BgmListMgr.PlayLobbyBgm();
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            uiscript.UI_Activity_MMO_Result.Inst.onSceneDisable();
            // 这几个因为特效层级问题移到的commonui里，需要手动关闭，其他的都走下面的onSceneActivity_Disable接口
            uiscript.UI_Activity_MMO_Info.Inst.enable = false;
            uiscript.UI_Activity_MMO_Confirm.Inst.enable = false;
            uiscript.UI_Activity_Rules.Inst.enable = false;
            // onSceneActivity_Disable 会关闭activity所有的ui
            uiscript.UIMgr.Inst.onSceneActivity_Disable();
            game.LoadMgr.disposeSceneRes('activity');
            this.clear();
        }

        public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
            if (game.Scene_Lobby.Inst && game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
            uiscript.UIMgr.Inst.openActivityUI(Laya.Handler.create(this, () => {
                this.loadSpecial(Laya.Handler.create(this, () => {
                    progress.runWith(0.4);
                    Laya.loader.load(this.bgLst, Laya.Handler.create(this, () => {
                        progress.runWith(0.5);
                        for (let i = 0; i < this._scene_effect_list.length; i++) {
                            EffectMgr.add_3d_resource(this._scene_effect_list[i]); // 加入effectmgr的资源管理
                        }
                        Laya.loader.create([...this._scene_effect_list], Laya.Handler.create(this, () => {
                            progress.runWith(0.7);
                            for (let i: number = 0; i < this._scene_effect_list.length; i++) {
                                let scene: Laya.Scene = Laya.loader.getRes(this._scene_effect_list[i]);
                                if (scene) {
                                    for (let i: number = 1; i < scene._childs.length; i++) {
                                        game.EffectMgr.dfsCompileShader(scene, scene._childs[i]);
                                    }
                                }
                            }
                            EffectMgr.preheat_3d_effect(this.ui_effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, () => {
                                Laya.timer.frameOnce(5, this, () => {
                                    // uiscript.UI_Activity_HF_Main.Inst.initEffect();
                                    // uiscript.UI_Activity_Marathon_Main.Inst.onInitScene();
                                    if (!uiscript.MMOData.Inst.initedBuff) uiscript.MMOData.Inst.onBuffChanged();
                                    uiscript.UI_Activity_Liandong_Main.Inst.initScene();
                                    uiscript.UI_Activity_MMO_Game.Inst.initEffect();
                                    progress.runWith(1);
                                    complete.run();
                                });
                            }), Laya.Handler.create(this, p => progress.runWith(0.7 + 0.3 * p), null, false));
                        }), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.2 * p), null, false));
                    }), Laya.Handler.create(this, p => progress.runWith(0.4 + 0.1 * p), null, false));
                }), Laya.Handler.create(this, p => progress.runWith(0.2 + p * 0.2), null, false))
            }, null, false), Laya.Handler.create(this, p => progress.runWith(p * 0.2), null, false));
        }

        //不同活动特殊
        private loadSpecial(complete?: Laya.Handler, progress?: Laya.Handler) {
            // 2602神驰集愿活动需要麻将牌面和牌背
            // this._load_my_mjp_view(complete, progress);
            progress.runWith(1);
            complete.run();
        }

        // 加载3d麻将牌的贴图资源
        // private _load_my_mjp_view(complete?: Laya.Handler, progress?: Laya.Handler) {
        //     let lst: Array<string> = [];
        //     let texture_base_path: string = 'scene/Assets/MyAssets/effect/activity/2602_shenchijiyuan/texture/';
        //     lst.push(texture_base_path + 'maque_002_1.png')
        //     lst.push(texture_base_path + 'maque_002_2.png')
        //     lst.push(texture_base_path + 'maque_001.png')
        //     this._mjp_textures = lst;
        //     Laya.loader.create(lst, complete, progress);
        // }

        // 当退出时候清除资源
        private clear() {
            // uiscript.UI_Activity_HF_Main.Inst.destroyEffect();
            // if (uiscript.UI_Activity_HF_Main.Inst.enable) uiscript.UI_Activity_HF_Main.Inst.enable = false;
            // uiscript.UI_Activity_Marathon_Main.Inst.enable = false;
            // uiscript.UI_Activity_Marathon_Game.Inst.enable = false;
            // uiscript.UI_Activity_Marathon_Result.Inst.enable = false;
            // uiscript.UI_Activity_Marathon_Main.Inst.onQuitScene();
            uiscript.UI_Activity_Liandong_Main.Inst.destroyScene();
            uiscript.UI_Activity_MMO_Game.Inst.destroyEffect();
            uiscript.UI_Activity_MMO_SpineMgr.Inst.clear();
            for (let i = 0; i < this._scene_effect_list.length; i++) {
                let url = this._scene_effect_list[i];
                let res = Laya.loader.getRes(url);
                if (res) res.destroy(true);
                EffectMgr.remove_3d_resource(this._scene_effect_list[i]);
                game.EffectMgr.force_dispose_3d_res(this._scene_effect_list[i]);
            }
        }

        QuitScene() {
            GameMgr.Inst.EnterLobby();
        }
    }
}