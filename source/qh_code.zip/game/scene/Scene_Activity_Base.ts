/**
* name 
*/
module game {
    export class Scene_Activity_Base extends SceneBase {
        public constructor() {
            super();
        }
        public _bglst: Array<string> = [];
        public bg_root: string;
        public openFuncName: string = 'openKuangduUI';
        public enableFuncName: string = 'onSceneActivity_Enable';
        public disableFuncName: string = 'onSceneActivity_Disable';
        public disposeResName: string = 'kuangdu';

        public init() {
            if (this.bg_root) {
                // this._bglst.push(game.Tools.localUISrc(this.bg_root + 'bg.jpg'));
            }
            
			
        }

        private firstInit(complete: Laya.Handler, progress: Laya.Handler) {
            // if (this._load_state == E_LoadState.loaded) {
            //     progress.runWith(1);
            //     complete.run();
            //     return;
            // }
            this._load_state = E_LoadState.loading;
            uiscript.UIMgr.Inst[this.openFuncName](Laya.Handler.create(this, () => {
                Laya.timer.frameOnce(5, this, () => {
                    this._load_state = E_LoadState.loaded;
                    progress.runWith(1);
                    complete.run();
                });
            }), Laya.Handler.create(this, p => progress.runWith(p), null, false));
        }

        public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
            cfg.audio.audio.forEach(value => {
				if (value.type == 'event') Laya.loader.load(value.path + view.AudioMgr.suffix);
			});
            progress.runWith(0);
            this.firstInit(Laya.Handler.create(this, () => {
                if (this._bglst.length == 0) {
                    progress.runWith(1);
                    complete.run();
                } else {
                    Laya.loader.load(this._bglst, Laya.Handler.create(this, () => {
                        progress.runWith(1);
                        complete.run();
                        // this.preheat_3d_effect(complete, Laya.Handler.create(this, p=>{ progress.runWith(0.8 + 0.2 * p)}, null, false));
                    }), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.5 * p), null, false));
                }
                
            }), Laya.Handler.create(this, p => progress.runWith(p * this._bglst.length == 0 ? 1 : 0.5), null, false));
        }

        protected onEnable() {
            uiscript.UIMgr.Inst[this.enableFuncName]();
            // view.BgmListMgr.PlayLobbyBgm();
        }

        
        protected onDisable() {
            this.clear();
        }

        public clear() {
            // Laya.AtlasResourceManager.instance.freeAll();
            uiscript.UIMgr.Inst[this.disableFuncName]();
            game.LoadMgr.disposeSceneRes(this.disposeResName);

            Laya.timer.clearAll(this);
            for (let data of this._bglst) {
                Laya.loader.clearTextureRes(data['url']);
            }
        }

    }
}