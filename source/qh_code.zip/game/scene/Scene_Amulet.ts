/**
* name 
*/
module game {
	export class Scene_Amulet extends SceneBase {
		public static Inst: Scene_Amulet = null;
		private static ui_effect_list: Array<string> = [
			'scene/effect_amulet_cardpackage.lh',
			'scene/effect_amulet_up.lh',
			'scene/effect_amulet_gameresult1.lh',
			'scene/effect_amulet_gameresult2.lh',
			'scene/effect_amulet_levelresult1.lh',
			'scene/effect_amulet_levelresult2.lh',
			'scene/effect_amulet_vs.lh',
			'scene/effect_amulet_strengthen.lh',
		];

		private desktop: Laya.Scene = null;
		private camera_main: Laya.Camera = null;
		private scene_path2: string = "scene/mjhandpai_amulet.ls";

		private scene_hand: Laya.Scene = null;
		public root2: Laya.Sprite3D = null;
		public camera_hand: Laya.Camera = null;
		public cameraPai: Laya.Camera = null;

		private _common_texture2d_loaded: boolean = false;
		private _desktop_model_path: string = '';
		private _desktop_model: Laya.Sprite3D;
		private _effect_list: Array<string> = [];
		private _ui_effect_list: Array<string> = [];
		private _scene_effect_list: Array<string> = [
			'scene/effect_amulet_bg.ls',
			'scene/effect_amulet_pk_bg.ls',
			'scene/effect_amulet_end_bg.ls',
			'scene/effect_amulet_hupai.ls', //这个需要卡动效立刻出，所以提前加载
			'scene/effect_amulet_fevertime_bottom.ls',
			'scene/effect_amulet_fevertime_top.ls'
		];
		private audioIds: Array<number> = [
			10153, 10164, 10163, 10342, 10151, 10154, 10148, 10337, 10155, 10338, 10339,
			10166, 10159, 10145, 10160, 10161, 10162, 10341, 10334, 10335, 10336, 10333, 10149, 10340, 10150, 10158, 10156, 10144
		];
		private audioLst: Array<string> = [];
		private _mjp_textures: Array<string> = []; //麻将牌的贴图，关闭的时候要释放掉
		private _model_list: Array<string> = [];
		private _atlas_list: Array<string> = [];
		private _ui_img_list: Array<string> = [];

		private _prop_textures: Array<string> = []; //护身符的贴图，关闭的时候要释放掉


		public constructor() {
			super();
			Scene_Amulet.Inst = this;
		}

		public init(data: any) {

		}

		protected onEnable() {
			uiscript.UI_Invite.Inst.enable = true;
			amulet.AmuletDesktopMgr.Inst.playBgm();
			uiscript.UIMgr.Inst.onSceneAmulet_Enable();
			uiscript.UI_ErrorInfo.destroyAllError();
			GameMgr.Inst.checkMouse();
		}

		protected onDisable() {
			// 重新随机麻将牌
			uiscript.UI_Sushe.randomDesktopID();
			// 麻将牌
			GameMgr.Inst.load_mjp_view();

			uiscript.UIMgr.Inst.onSceneAmulet_Disable();
			amulet.AmuletDesktopMgr.Inst.Reset();
			amulet.AmuletDesktopMgr.Inst.stopBgm();
			amulet.AmuletDesktopMgr.Inst.active = false;
			this.desktop.visible = false;
			game.LoadMgr.disposeSceneRes('amulet');
		}

		public openAmuletRoom(data: game.IAmuletGameData, complete: Laya.Handler, progress: Laya.Handler) {
			if (game.Scene_Lobby.Inst && game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
			this.load_common_texture2d(Laya.Handler.create(this, () => {
				this.load_mainscene(Laya.Handler.create(this, () => {
					this.loadSceneEffect(Laya.Handler.create(this, () => {
						this.active_common_texture2d(Laya.Handler.create(this, () => {
							app.Log.log('active_common_texture2d over');
							this._load_my_mjp_view(Laya.Handler.create(this, () => {
								app.Log.log('_load_my_mjp_view over');
								this._load_prop_view(Laya.Handler.create(this, () => {
									app.Log.log('_load_prop_view over');
									this._load_player_views(Laya.Handler.create(this, () => {
										app.Log.log('_load_player_effects over');
										amulet.AmuletDesktopMgr.Inst.active = true;
										this.desktop.visible = true;
										amulet.AmuletDesktopMgr.Inst.Reset();
										progress.runWith(1);
										complete.run();
									}), Laya.Handler.create(this, p => progress.runWith(0.8 + 0.2 * p), null, false));
								}), Laya.Handler.create(this, p => progress.runWith(0.7 + 0.1 * p), null, false));
							}), Laya.Handler.create(this, p => progress.runWith(0.6 + 0.1 * p), null, false));
						}), Laya.Handler.create(this, p => progress.runWith(0.4 + 0.2 * p), null, false));
					}), Laya.Handler.create(this, p => progress.runWith(0.3 + 0.1 * p), null, false));
				}), Laya.Handler.create(this, p => progress.runWith(0.1 + 0.2 * p), null, false));
			}), Laya.Handler.create(this, p => progress.runWith(0.1 * p), null, false));
		}

		//加载主场景，只加载一次，后面就保留下来不删除了
		private load_mainscene(complete: Laya.Handler, progress: Laya.Handler) {
			uiscript.UIMgr.Inst.openAmuletDesktopUI(Laya.Handler.create(this, () => {
				if (!this.desktop) {
					game.LoadMgr.loadRes(game.E_LoadType.scene_amulet, Laya.Handler.create(this, () => Laya.timer.frameOnce(1, this, () => {
						let scene_path: string = "scene/mjdesktop_amulet_pk.ls";
						this.desktop = Laya.loader.getRes(scene_path);
						this.desktop.ambientColor = new Laya.Vector3(0.40, 0.40, 0.40);
						this.cameraPai = this.desktop.getChildByName('main_camera') as Laya.Camera;
						uiscript.UI_AmuletDesktopInfo.Inst.addScene(this.desktop);
						var directionLight: Laya.DirectionLight = this.desktop.addChild(new Laya.DirectionLight()) as Laya.DirectionLight;
						directionLight.transform.translate(new Laya.Vector3(0, 1, 1.7));
						directionLight.color = new Laya.Vector3(0.5, 0.5, 0.5);
						directionLight.transform.localRotation = new Laya.Quaternion(0, -0.75, -0.8, 0);

						let d2 = Laya.loader.getRes(this.scene_path2);
						uiscript.UI_AmuletDesktopInfo.Inst.addScene(d2);
						this.scene_hand = d2;
						this.root2 = d2.getChildByName('root') as Laya.Sprite3D;
						this.camera_hand = d2.getChildByName('camera') as Laya.Camera;
						this.camera_hand.useOcclusionCulling = false;

						let mgr = (this.desktop.getChildByName('room') as Laya.Sprite3D).addComponent(amulet.AmuletDesktopMgr) as amulet.AmuletDesktopMgr;
						mgr.mainCamera = this.cameraPai;
						this.cameraPai.useOcclusionCulling = false;

						progress.runWith(1);
						complete.run();
					})), Laya.Handler.create(this, p => progress.runWith(0.2 + 0.8 * p), null, false));
				} else {
					progress.runWith(1);
					complete.run();
				}
			}, null, false), Laya.Handler.create(this, p => progress.runWith(p * 0.2), null, false));
		}

		//加载场景其他特效；退出场景后卸载
		private loadSceneEffect(complete: Laya.Handler, progress: Laya.Handler) {
			Laya.loader.create(this._scene_effect_list, Laya.Handler.create(this, () => {
				this._common_texture2d_loaded = true;
				if (complete) complete.run();
			}), progress);
		}

		//加载通用的麻将会用到的2d贴图，保存在内存里，可提前加载
		public load_common_texture2d(complete?: Laya.Handler, progress?: Laya.Handler) {
			if (this._common_texture2d_loaded) {
				if (progress) progress.runWith(1);
				if (complete) complete.run();
			} else {
				let lst: Array<string> = [];
				for (let i: number = 0; i < EffectMgr.d3res_map['mj_common_texture2d'].length; i++) {
					lst.push(EffectMgr.d3res_map['mj_common_texture2d'][i]);
				}
				Laya.loader.create(lst, Laya.Handler.create(this, () => {
					this._common_texture2d_loaded = true;
					if (complete) complete.run();
				}), progress, laya.d3.resource.Texture2D_caps);
			}
		}

		//激活通用麻将用2d贴图
		private active_common_texture2d(complete: Laya.Handler, progress: Laya.Handler) {
			progress.runWith(0);
			let lst: Array<string> = [];
			for (let i: number = 0; i < EffectMgr.d3res_map['mj_common_texture2d'].length; i++) {
				lst.push(EffectMgr.d3res_map['mj_common_texture2d'][i]);
			}
			let index: number = 0;
			let _recreate = () => {
				if (index >= lst.length) {
					progress.runWith(1);
					complete.run();
					return;
				}
				progress.runWith(index / lst.length);
				let _res = Laya.loader.getRes(lst[index]);
				if (_res) _res.recreateResource();
				index++;
				_recreate();
			};
			_recreate();
		}

		//删除gpu中的通用麻将2d贴图，可以重新激活
		private clearTexture_commont_texture2d() {
			let lst: Array<string> = EffectMgr.d3res_map['mj_common_texture2d'];
			for (let i: number = 0; i < lst.length; i++) {
				let __res = Laya.loader.getRes(lst[i]);
				if (__res) {
					__res.clearTexture();
				}
			}
		}

		// 加载3d麻将牌的贴图资源
		private _load_my_mjp_view(complete?: Laya.Handler, progress?: Laya.Handler) {
			let lst: Array<string> = [];
			// 获取牌背
			let mjp_name: string = game.GameUtility.get_view_res_name(EView.mjp);
			let mjp_path: string = 'scene/Assets/Resource/mjpai/';
			lst.push(mjp_path + mjp_name + '/' + 'mjp.png');
			lst.push(mjp_path + mjp_name + '/' + 'hand.png');

			// 获取牌面
			let mjp_surface_name: string = game.GameUtility.get_view_res_name(EView.mjp_surface);
			if (view.DesktopMgr.en_mjp) {
				mjp_surface_name += '_0';
			}
			let mjpm_path: string = 'scene/Assets/Resource/mjpaimian/';
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') mjpm_path += 'en_kr/';
			// 添加获取牌面
			lst.push(mjpm_path + mjp_surface_name + '/' + 'mjp.png');
			lst.push(mjpm_path + mjp_surface_name + '/' + 'hand.png');
			let specialModeUrl = 'scene/Assets/Resource/mjpaimian/';
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
				if (view.DesktopMgr.en_mjp) {
					specialModeUrl += 'en_kr/mjpface_special_0/';
				} else {
					specialModeUrl += 'en_kr/mjpface_special/';
				}
			} else {
				specialModeUrl += 'mjpface_special/';
			}
			lst.push(specialModeUrl + 'wanxiangxiuluo_mode/mjp.png');
			lst.push(specialModeUrl + 'wanxiangxiuluo_mode/hand.png');
			this._mjp_textures = lst;
			Laya.loader.create(lst, complete, progress);
		}


		// 加载护身符的贴图资源
		private _load_prop_view(complete?: Laya.Handler, progress?: Laya.Handler) {
			let lst: Array<string> = [];
			const prop_path: string = 'scene/Assets/Resource/amulet/';
			cfg.amulet.amulet_effect.forEach((value) => {
				if (!value.deprecated) {
					lst.push(prop_path + value.card_image + '.png');
				}
			});
			cfg.amulet.amulet_badge.forEach((value) => {
				if (!value.deprecated) {
					lst.push(prop_path + value.badge_image + '.png');
				}
			});
			lst.push(prop_path + 'plus.png');
			for (let i = 1; i <= 4; i++) {
				lst.push(prop_path + 'fu_bg' + i + '.jpg');
				lst.push(prop_path + 'fu_widen_bg' + i + '.jpg');
				if (i != 1) lst.push(prop_path + 'fx_qingyun_kabao_' + i + '.png');
			}
			this._prop_textures = lst;
			Laya.loader.create(lst, complete, progress);
		}

		// 加载玩家带的特殊特效预热
		private _load_player_views(complete: Laya.Handler, progress: Laya.Handler) {
			let effect_map: Object = {};
			let ui_effect_map: Object = {};
			let model_map: Object = {};
			let skin_imgs: Object = {};
			let cutin_map: Object = {};
			this.audioLst = [];

			for (let i = 0; i < this.audioIds.length; i++) {
				let audioInfo = cfg.audio.audio.get(this.audioIds[i]);
				this.audioLst.push(audioInfo.path + view.AudioMgr.suffix)
			}

			effect_map['scene/effect_mingpai_default.lh'] = 1;
			let d_character = uiscript.UI_Sushe.main_chara_info;
			let chara_skin_id: number = d_character.skin;
			model_map['scene/hand_human.lh'] = 1;

			let d_skin = cfg.item_definition.skin.get(chara_skin_id);
			skin_imgs[(d_skin.path + '/full.png')] = 1;
			if (d_skin.no_reverse) {
				skin_imgs[(d_skin.path + '/reverse/full.png')] = 1;
			}
			this._effect_list = [];
			for (let k in effect_map) {
				this._effect_list.push(k);
			}
			this._model_list = [];
			for (let k in model_map) {
				this._model_list.push(k);
				EffectMgr.add_3d_resource(k);
			}
			let _skin_list: Array<string> = [];
			for (let k in skin_imgs) {
				_skin_list.push(k);
			}

			this._ui_effect_list = [];
			for (let i: number = 0; i < Scene_Amulet.ui_effect_list.length; i++) {
				this._ui_effect_list.push(Scene_Amulet.ui_effect_list[i]);
			}
			for (let k in ui_effect_map) {
				this._ui_effect_list.push(k);
			}
			this._atlas_list = [];
			for (let k in cutin_map) {
				this._atlas_list.push(k);
			}
			this._ui_img_list = [];
			progress.runWith(0);
			game.LoadMgr.loadResImage(_skin_list, Laya.Handler.create(this, () => {
				Laya.loader.create(this._model_list, Laya.Handler.create(this, () => {
					let start_percent = this._atlas_list.length > 0 ? 0.35 : 0.3;
					let _handler = Laya.Handler.create(this, () => {
						if (this._ui_img_list.length > 0) {
							Laya.loader.load(this._ui_img_list);//随缘加载
						}
						let time = Laya.timer.currTimer;
						EffectMgr.preheat_3d_effect(this._effect_list, this.desktop, false, Laya.Handler.create(this, () => {
							EffectMgr.preheat_3d_effect(this._ui_effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, () => {
								Laya.timer.frameOnce(5, this, () => {
									complete.run();
									Laya.loader.load(this.audioLst); //各种音乐随缘下载
								});
							}), Laya.Handler.create(this, p => progress.runWith(0.65 + 0.35 * p), null, false));
						}), Laya.Handler.create(this, p => progress.runWith(start_percent + (0.65 - start_percent) * p), null, false));
					});
					if (this._atlas_list.length > 0) {
						Laya.loader.create(this._atlas_list, _handler);
					} else {
						_handler.run();
					}
				}), Laya.Handler.create(this, p => progress.runWith(0.2 + 0.1 * p), null, false));
			}), Laya.Handler.create(this, p => progress.runWith(0.2 * p), null, false));
		}

		// 当退出时候清除资源
		private _on_quit() {
			if (uiscript.UI_AmuletDesktopInfo.Inst) {
				uiscript.UI_AmuletDesktopInfo.Inst.hide();
				uiscript.UI_AmuletDesktopInfo.Inst.onQuitScene();
			}
			if (uiscript.UI_AmuletHome.Inst) {
				uiscript.UI_AmuletHome.Inst.onQuitScene();
				uiscript.UI_AmuletHome.Inst.enable = false;
			}
			if (uiscript.UI_AmuletGameResult.Inst) {
				uiscript.UI_AmuletGameResult.Inst.onQuitScene();
				uiscript.UI_AmuletGameResult.Inst.enable = false;
			}
			if (!amulet.AmuletDesktopMgr.Inst || !amulet.AmuletDesktopMgr.Inst.active) return;
			if (this._desktop_model) {
				this._desktop_model.destroy(true);
				this._desktop_model = null;
			}

			if (this._desktop_model_path) {
				let res = Laya.loader.getRes(this._desktop_model_path);
				if (res) res.destroy(true);
				EffectMgr.remove_3d_resource(this._desktop_model_path);
				this._desktop_model_path = '';
			}
			for (let i: number = 0; i < this._model_list.length; i++) {
				let src: string = this._model_list[i]['url'];

				let res = Laya.loader.getRes(src);
				if (res) res.destroy(true);
				EffectMgr.remove_3d_resource(src);
			}

			for (let i: number = 0; i < this._atlas_list.length; i++) {
				Laya.loader.clearTextureRes(this._atlas_list[i]['url']);
			}

			for (let i: number = 0; i < this._ui_img_list.length; i++) {
				if (this._ui_img_list[i]['url']) {
					Laya.loader.clearTextureRes(this._ui_img_list[i]['url']);
				} else {
					Laya.loader.clearTextureRes(this._ui_img_list[i]);
				}

			}

			this.clearTexture_commont_texture2d();
			for (let i: number = 0; i < this._mjp_textures.length; i++) {
				let res = Laya.loader.getRes(this._mjp_textures[i]['url']);
				if (res) {
					res.dispose();
				}
			}
			for (let i: number = 0; i < this._prop_textures.length; i++) {
				let res = Laya.loader.getRes(this._prop_textures[i]['url']);
				if (res) {
					res.dispose();
				}
			}
			for (let i: number = 0; i < this.audioLst.length; i++) {
				let url = this.audioLst[i];
				let res = Laya.loader.getRes(url);
				if (res) {
					res.dispose();
					Laya.Loader.clearRes(url);
				}
			}
			this.audioLst = [];
			for (let i: number = 0; i < this._scene_effect_list.length; i++) {
				let url;
				if (this._scene_effect_list[i]['url']) {
					url = this._scene_effect_list[i]['url'];
				} else {
					url = this._scene_effect_list[i];
				}
				if (url) {
					let effect = Laya.loader.getRes(url) as Laya.Scene;
					if (effect) {
						effect.destroy(true);
					}
				}
			}
		}

		public GameEnd() {
			app.Log.log('Scene_Amulet GameEnd');
			this._on_quit();
			GameMgr.Inst.ingame = false;
			GameMgr.Inst.EnterLobby();
		}
	}
}