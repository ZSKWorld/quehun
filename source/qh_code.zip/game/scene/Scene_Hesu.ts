/**
* name 
*/
module game {
    export class Scene_Hesu extends SceneBase {

        public static Inst: Scene_Hesu = null;

        public constructor() {
            super();
            this.init();
            Scene_Hesu.Inst = this;
        }
        private _bglst: Array<string> = [];

        public init() {
            let bg_root = 'myres/activity_hesu/';
            this._bglst.push(bg_root + 'bg.jpg');
            this._bglst.push(bg_root + 'bg_main.png');
            this._bglst.push(bg_root + 'page_chahuahui.png');
            this._bglst.push(bg_root + 'page_duizhanshi.png');
            this._bglst.push(bg_root + 'page_shenkan.png');
            this._bglst.push(bg_root + 'page_xiaomaibu.png');
            this._bglst.push('extendRes/items/diaoyushao_0.png');
        }

        private firstInit(complete: Laya.Handler, progress: Laya.Handler) {
            // if (this._load_state == E_LoadState.loaded) {
            //     progress.runWith(1);
            //     complete.run();
            //     return;
            // }
            this._load_state = E_LoadState.loading;
            uiscript.UIMgr.Inst.openHesuUI(Laya.Handler.create(this, () => {
                Laya.timer.frameOnce(5, this, () => {
                    this._load_state = E_LoadState.loaded;
                    progress.runWith(1);
                    complete.run();
                });
            }), Laya.Handler.create(this, p => progress.runWith(p), null, false));
        }

        public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
            progress.runWith(0);
            this.firstInit(Laya.Handler.create(this, () => {
                Laya.loader.load(this._bglst, Laya.Handler.create(this, () => {
                    progress.runWith(1);
                    complete.run();
                    // this.preheat_3d_effect(complete, Laya.Handler.create(this, p=>{ progress.runWith(0.8 + 0.2 * p)}, null, false));
                }), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.5 * p), null, false));
            }), Laya.Handler.create(this, p => progress.runWith(p * 0.5), null, false));
        }

        protected onEnable() {
            view.BgmListMgr.PlayLobbyBgm();
        }

        
        protected onDisable() {
            this.clear();
        }

        public clear() {
            Laya.AtlasResourceManager.instance.freeAll();
            game.LoadMgr.disposeSceneRes('hesu');

            Laya.timer.clearAll(this);
            for (let data of this._bglst) {
                Laya.loader.clearTextureRes(data['url']);
            }
        }

        private preheat_3d_effect(complete:Laya.Handler, progress:Laya.Handler) {
			app.Log.log('scene_hesu preheart_effect');
			EffectMgr.preheat_3d_effect(['scene/scene_hesu.ls'], FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, ()=>{
				Laya.timer.frameOnce(5, this, ()=>{
					progress.runWith(1);
					complete.run();
				});
			}), progress);
		}

    }
}