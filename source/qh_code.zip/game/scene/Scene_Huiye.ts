/**
* name 
*/
module game {
    export class Scene_Huiye extends Scene_Activity_Base {
        public static Inst: Scene_Huiye;
        public constructor() {
            super();
            this.init();
            Scene_Huiye.Inst = this;
        }
        
        public bg_root: string = 'myres/activity_huiye/';
        public openFuncName: string = 'openHuiyeUI';
        public disposeResName: string = 'huiye';

        protected onEnable() {
            super.onEnable();
            uiscript.UIMgr.Inst.onSceneActivity_Enable();
            uiscript.UI_Invite.Inst.enable = true;
        }
    }
}