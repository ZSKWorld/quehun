/**
* name 
*/
module game {
    export class Scene_Kuangdu extends SceneBase {

        public static Inst: Scene_Kuangdu = null;

        public constructor() {
            super();
            this.init();
            Scene_Kuangdu.Inst = this;
        }
        private _bglst: Array<string> = [];

        public init() {
            let bg_root = 'myres/activity_kuangdu/';
            this._bglst.push(bg_root + 'bg_view.png');
        }

        private firstInit(complete: Laya.Handler, progress: Laya.Handler) {
            // if (this._load_state == E_LoadState.loaded) {
            //     progress.runWith(1);
            //     complete.run();
            //     return;
            // }
            this._load_state = E_LoadState.loading;
            uiscript.UIMgr.Inst.openKuangduUI(Laya.Handler.create(this, () => {
                Laya.timer.frameOnce(5, this, () => {
                    this._load_state = E_LoadState.loaded;
                    progress.runWith(1);
                    complete.run();
                });
            }), Laya.Handler.create(this, p => progress.runWith(p), null, false));
        }

        public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
            progress.runWith(0);
            this.firstInit(Laya.Handler.create(this, () => {
                Laya.loader.load(this._bglst, Laya.Handler.create(this, () => {
                    progress.runWith(1);
                    complete.run();
                    // this.preheat_3d_effect(complete, Laya.Handler.create(this, p=>{ progress.runWith(0.8 + 0.2 * p)}, null, false));
                }), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.5 * p), null, false));
            }), Laya.Handler.create(this, p => progress.runWith(p * 0.5), null, false));
        }

        protected onEnable() {
            uiscript.UIMgr.Inst.onSceneKuangdu_Enable();
            view.BgmListMgr.PlayLobbyBgm();
        }

        
        protected onDisable() {
            this.clear();
        }

        public clear() {
            Laya.AtlasResourceManager.instance.freeAll();
            uiscript.UIMgr.Inst.onSceneKuangdu_Disable();
            game.LoadMgr.disposeSceneRes('kuangdu');

            Laya.timer.clearAll(this);
            for (let data of this._bglst) {
                Laya.loader.clearTextureRes(data['url']);
            }
        }

    }
}