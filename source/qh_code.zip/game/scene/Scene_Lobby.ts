/**
* name 
*/
module game {
	export class Scene_Lobby extends SceneBase {

		public static Inst: Scene_Lobby = null;
		private readonly scene_path: string = 'scene/lobby.ls';
		private readonly ui_scene_lst: string[] = [ //较大的活动背景
			// 'scene/scene_effect_niudan.ls',
			// 'scene/effect_questcrew_btns.ls',
			// 'scene/effect_questcrew_middle.ls',
			// 'scene/effect_questcrew_bg.ls'
			// 'scene/effect_snowball_pk.ls',
			// 'scene/effect_snowball_bg.ls'
		];
		private readonly ui_effect_list: Array<string> = [
			"scene/effect_get_character.lh",
			"scene/effect_get_zhuangban.lh",
			"scene/effect_heartup.lh",
			"scene/effect_heartup_favor.lh",
			"scene/effect_heartlevelup.lh",
			"scene/effect_item_shine.lh",
			"scene/effect_item_shine_big.lh",
			"scene/effect_item_shine1.lh",
			"scene/effect_item_shine_big1.lh",
			"scene/effect_shilian_tag.lh",
			"scene/effect_item_shine_ur.lh",
			"scene/effect_item_shine_big_ur.lh",
			'scene/effect_yueshiyushou.lh',
			"scene/sign_anim.lh",
			"scene/sign_bang.lh",
			"scene/sign_btn_confirm.lh",
			// ba活动
			// "scene/effect_ba_01.lh",
			// "scene/effect_ba_02.lh",
			// "scene/effect_ba_04.lh",
			// "scene/effect_ba_05.lh",
			// "scene/effect_ba_tuowei_01.lh",
			// "scene/effect_ba_tuowei_02.lh",
			// "scene/effect_ba_tuowei_04.lh",
			// "scene/effect_ba_tuowei_03.lh",
			//扭蛋特效
			// "scene/effect_niudan.lh",
			// "scene/effect_25niudan_title.lh",
			// "scene/effect_25niudan_light.lh",
			//竹云庆典特效
			// 'scene/fx_ui_zhuyun_02.lh',
			// 'scene/fx_ui_zhuyun_03.lh',
			// 'scene/fx_ui_zhuyun_04.lh',
			// 'scene/fx_ui_zhuyun_06.lh',
			//偶像大师特效
			// 'scene/effect_imas_levelup_show.lh',
			// 'scene/effect_imas_match.lh',
			// 'scene/effect_imas_twinkle_big.lh',
			// 'scene/effect_imas_twinkle_small.lh',
			// 'scene/effect_imas_upgrade.lh',
			//合成活动
			// 'scene/effect_25liaoliwu_cat.lh',
			// 'scene/effect_25liaoliwu_hecheng.lh'
			//投票
			// 'scene/effect_25vote_flash.lh',
			//射击活动
			// 'scene/effect_2511shoot_hit1.lh',
			// 'scene/effect_2511shoot_hit2.lh',
			// 'scene/effect_2511shoot_death1.lh',
			// 'scene/effect_2511shoot_death2.lh',

			// 'scene/effect_questcrew_charge.lh',
			// 'scene/effect_questcrew_star.lh',
			// 'scene/effect_questcrew_star_blue.lh',
			//bingo
			// 'scene/effect_2511bingo_achieved.lh',
			// 'scene/effect_2511bingo_rewarded.lh'

			//26dj签到
			'scene/26dj_sign_btn_receive.lh',
			'scene/26dj_sign_btn_shake.lh',
			'scene/26dj_sign_icon1_anim.lh',
			'scene/26dj_sign_icon2_anim.lh',
			'scene/26dj_sign_show.lh'
		];

		private scene_container: Laya.Sprite = null;
		private scene: Laya.Scene = null;
		private root_bg: Laya.Sprite3D = null;
		private root_origin_pos: Laya.Vector3;
		private container_effects: Laya.Sprite3D = null;
		private bg_front_plane: Laya.MeshSprite3D = null;
		private bg_front_mat: Laya.BlinnPhongMaterial = null;
		private bg_back_plane: Laya.MeshSprite3D = null;
		private bg_back_mat: Laya.BlinnPhongMaterial = null;
		// private bg_kuang: Laya.MeshSprite3D = null;
		private _current_bg: string = '';
		private _change_start_time: number = 0;
		private _during_change_bg: boolean = false;
		private _during_shake: boolean = false;
		private _shake_pos_list: Array<Laya.Vector3> = [];
		private _shake_start_time: number = 0;

		private _load_listener: Array<Laya.Handler> = [];
		private _progress_listener: Array<Laya.Handler> = [];

		private _yard_bg_id: number = 0;
		private _yard_img_url: string = '';
		private _indoor_img_url: string = '';
		private _indoor_img_url_1: string = '';

		private _current_effect: Laya.Sprite3D = null;
		private _last_effect: Laya.Sprite3D = null;
		private _effect_yinghua_path: string = 'scene/effect_lobby_yinghua.lh';
		private _effect_yinghua: Laya.Sprite3D = null;
		private _effect_yard_path: string = '';
		private _effect_yard: Laya.Sprite3D = null;
		private _sepcialImgId: number = 0; // 添加一个设置特殊背景的自增id，用来判断当前加载是否是需要的
		private _special_img_url: string = ''; // 特殊背景图路径
		private _effect_special_path: string = ''; // 特殊特效路径
		private _effect_special_pathes: string[] = [];
		private _effect_special: Laya.Sprite3D = null; // 特殊特效
		public have_send_login_beat: boolean = false;

		public backHandler: Laya.Handler; // 2024/05/24新增返回时触发
		

		private currentEffectActive: boolean = true; // 新增当前是否需要显示effect
		public get current_bg(): string { return this._current_bg; }

		public constructor() {
			super();
			Scene_Lobby.Inst = this;
		}

		public init(data: any) {
			this._load_state = E_LoadState.loading;
			let resimages: Array<string> = [];
			resimages.push('extendRes/charactor/default_girl/full.png');
			resimages.push('extendRes/charactor/default_girl/half.png');
			resimages.push('extendRes/charactor/default_girl/smallhead.png');
			resimages.push('extendRes/charactor/default_girl/bighead.png');
			resimages.push('extendRes/charactor/default_girl/waitingroom.png');
			resimages.push('extendRes/charactor/default_man/full.png');
			resimages.push('extendRes/charactor/default_man/half.png');
			resimages.push('extendRes/charactor/default_man/smallhead.png');
			resimages.push('extendRes/charactor/default_man/bighead.png');
			resimages.push('extendRes/charactor/default_man/waitingroom.png');
			resimages.push('extendRes/emo/default.png');

			let special_items: Array<number> = [302001, 302002, 302003, 302004]; //当货币的几个物品，提前加载吧，什么时候用到难说
			for (let i: number = 0; i < special_items.length; i++) {
				let d_item = cfg.item_definition.item.get(special_items[i]);
				resimages.push(d_item.icon);
				if (d_item.icon_transparent && d_item.icon_transparent != '') {
					resimages.push(d_item.icon_transparent);
				}
			}
			resimages.push('extendRes/items/default.jpg');
			cfg.level_definition.level_definition.forEach((value, index) => {
				resimages.push(value.primary_icon);
			});

			this._loadaudio();

			resimages.push('extendRes/items/gold0.png');
			resimages.push('extendRes/items/gold1.png');
			resimages.push('extendRes/items/coin0.jpg');
			resimages.push('extendRes/items/jade0.jpg');
			resimages.push('extendRes/head_frame/default.png');
			game.LoadMgr.loadResImage(resimages, Laya.Handler.create(this, () => {
				game.LoadMgr.loadRes(game.E_LoadType.common, Laya.Handler.create(this, () => {
					game.LoadMgr.loadRes(game.E_LoadType.lobby, Laya.Handler.create(this, () => Laya.timer.frameOnce(1, this, () => {

						game.EffectMgr.init(Laya.Handler.create(this, () => {
							if (GameMgr.client_type == 'en' || GameMgr.client_type == 'kr') {
								game.EffectMgr.add_3d_resource(uiscript.UI_Tanfang.scene_path);
								Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('tanfang.atlas'));
								let _scene = Laya.loader.getRes(uiscript.UI_Tanfang.scene_path);
								if (_scene) {
									_scene.destroy();
									game.EffectMgr.remove_3d_resource(uiscript.UI_Tanfang.scene_path);
								}
							}
							
							this.onProgressUpdate(1);
							Laya.timer.frameOnce(5, this, () => {
								GameMgr.Inst.addScene(this.scene_container = new Laya.Sprite());
								this.scene_container.visible = true;
								this._load_state = E_LoadState.loaded;
								for (let i: number = 0; i < this._load_listener.length; i++) {
									if (this._load_listener[i]) this._load_listener[i].run();
								}
								this._load_listener = [];
								this._progress_listener = [];
							});
						}));
					})), Laya.Handler.create(this, p => this.onProgressUpdate(0.7 + p * 0.3), null, false));
				}), Laya.Handler.create(this, p => this.onProgressUpdate(0.5 + p * 0.2), null, false));
			}), Laya.Handler.create(this, p => this.onProgressUpdate(p * 0.5), null, false));
		}

		private _loadaudio() {
			cfg.audio.audio.forEach(value => {
				if (value.type == 'lobby') Laya.loader.load(value.path + view.AudioMgr.suffix);
			});
		}

		public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
			if (this.scene) {
				progress.runWith(1);
				complete.run();
				return;
			}
			progress.runWith(0);
			Laya.loader.create(this.scene_path, Laya.Handler.create(this, () => {
				progress.runWith(0.3);

				let _bglst: Array<string> = [];
				this._indoor_img_url = 'scene/Assets/Resource/lobby/indoor.jpg';
				this._indoor_img_url_1 = 'scene/Assets/Resource/lobby/indoor_1.jpg';
				this._yard_bg_id = game.GameUtility.get_view_id(game.EView.lobby_bg);
				this._yard_img_url = `scene/Assets/Resource/lobby/${game.GameUtility.get_view_res_name(game.EView.lobby_bg)}.jpg`;
				_bglst.push(this._indoor_img_url);
				_bglst.push(this._yard_img_url);
				_bglst.push(this._indoor_img_url_1);
				FrontEffect.Inst.SetClickEffectByLobby(uiscript.UI_Config_New.disableClickEffect == 1 ? 0 : this._yard_bg_id, null);
				Laya.loader.create(_bglst, Laya.Handler.create(this, () => {
					this.scene = Laya.loader.getRes(this.scene_path);
					this.scene_container.addChild(this.scene);
					this.container_effects = this.scene.getChildByName('effects') as Laya.Sprite3D;
					this.root_bg = this.scene.getChildByName('root') as Laya.MeshSprite3D;
					this.root_origin_pos = this.root_bg.transform.localPosition.clone();
					this.bg_front_plane = this.root_bg.getChildByName('bg_front') as Laya.MeshSprite3D;
					this.bg_front_mat = this.bg_front_plane.meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
					this.bg_back_plane = this.root_bg.getChildByName('bg_back') as Laya.MeshSprite3D;
					this.bg_back_mat = this.bg_back_plane.meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
					this.bg_front_plane.active = false;
					// this.bg_kuang = this.scene.getChildByName('kuang') as Laya.MeshSprite3D;
					progress.runWith(0.6);
					this._effect_yinghua_path = this.get_effect_path(0);
					this._effect_yard_path = this.get_effect_path(this._yard_bg_id);
					let _effects: Array<string> = [this._effect_yinghua_path];
					if (this._effect_yard_path != this._effect_yinghua_path) {
						_effects.push(this._effect_yard_path);
						EffectMgr.add_3d_resource(this._effect_yard_path);
					}
					EffectMgr.add_3d_resource(this._effect_yinghua_path); // 加入effectmgr的资源管理
					for (let i = 0; i < this.ui_scene_lst.length; i++) {
						EffectMgr.add_3d_resource(this.ui_scene_lst[i]); // 加入effectmgr的资源管理
						_effects.push(this.ui_scene_lst[i]);
					}
					Laya.loader.create(_effects, Laya.Handler.create(this, () => {
						progress.runWith(0.7);
						this._effect_yinghua = Laya.loader.getRes(this._effect_yinghua_path);
						this._effect_yard = Laya.loader.getRes(this._effect_yard_path);
						this._effect_yinghua.active = false;
						this._effect_yard.active = false;
						this.container_effects.addChild(this._effect_yinghua);
						this.container_effects.addChild(this._effect_yard);
						// uiscript.UI_Lobby.Inst.preloadSkin(Laya.Handler.create(this, ()=>{
						this.initActivityScene();
						// progress.runWith(0.75);
						Laya.timer.frameOnce(8, this, () => {
							this.scene.visible = true;
							progress.runWith(0.8);
							this.preheart_effect(complete, Laya.Handler.create(this, p => { progress.runWith(0.8 + 0.2 * p) }, null, false));
						});
						// }));

					}));
				}), Laya.Handler.create(this, p => progress.runWith(0.3 + 0.3 * p), null, false));
			}), Laya.Handler.create(this, p => progress.runWith(0.3 * p), null, false));
		}

		private preheart_effect(complete: Laya.Handler, progress: Laya.Handler) {
			app.Log.log('scene_lobby preheart_effect');

			EffectMgr.preheat_3d_effect(this.ui_effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, () => {
				Laya.timer.frameOnce(5, this, () => {
					progress.runWith(1);
					complete.run();
				});
			}), progress);
		}

		protected onEnable() {
			this._during_change_bg = false;
			uiscript.UIMgr.Inst.onSceneLobby_Enable();
			if (this.scene) this.scene.visible = true;
			if (view.BgmListMgr.type != view.E_Bgm_Type.lobby || !view.BgmListMgr.playing_bgm) {
				view.BgmListMgr.PlayLobbyBgm();
			}

			this.pending_ui_jump();
			uiscript.UI_Invite.Inst.enable = true;

			Laya.timer.frameLoop(1, this, this._update, null, true);
			GameMgr.Inst.checkMouse();
		}

		//判定进入大厅时候可能会跳转到起名、友人房之类的地方
		public pending_ui_jump() {
			let bg_name: string = 'yard';
			let login_end = GameMgr.Inst.login_loading_end;
			GameMgr.Inst.login_loading_end = true;
			
			//以下为特殊情况，优先级高于其他处理
			//账户封禁
			if (uiscript.UI_Refund.is_frozen()) {
				uiscript.UI_Lobby.Inst.enable = true;
				uiscript.UI_Refund.Inst.show();
			}
			//实名制
			else if (GameMgr.client_type == 'chs' && !uiscript.UI_ShiMingRenZheng.renzhenged) {
				uiscript.UI_ShiMingRenZheng.Inst.show(Laya.Handler.create(this, () => {
					this.pending_ui_jump();
				}));
			}
			//更改昵称
			else if (!GameMgr.Inst.account_data['nickname'] || GameMgr.Inst.account_data['nickname'] == '') {
				uiscript.UI_Nickname.show();
			}
			//游戏中
			else if (GameMgr.Inst.ingame) {
				bg_name = 'indoor';
				if (!login_end) {
					GameMgr.Inst.login_loading_end = false;
				}
				game.MJNetMgr.Inst.OpenConnect(GameMgr.Inst.mj_game_token, GameMgr.Inst.mj_game_uuid, GameMgr.Inst.mj_server_location, true);
			}
			//在友人房中
			else if (uiscript.UI_WaitingRoom.Inst.inRoom) {
				bg_name = 'indoor';
				uiscript.UIMgr.Inst.ShowWaitingRoom();
			}
			//被邀请加入房间
			else if (GameMgr.Inst.beinvited_roomid != -1) {
				let beinvited_roomid: number = GameMgr.Inst.beinvited_roomid;
				GameMgr.Inst.beinvited_roomid = -1;
				app.NetAgent.sendReq2Lobby('Lobby', 'joinRoom', {
					room_id: beinvited_roomid,
					client_version_string: GameMgr.Inst.getClientVersion()
				}, (err, res) => {
					if (err || res['error']) {
						uiscript.UIMgr.Inst.showNetReqError('joinRoom', err, res);
						uiscript.UIMgr.Inst.showLobby();
					} else {
						uiscript.UI_WaitingRoom.Inst.updateData(res['room']);
						uiscript.UIMgr.Inst.ShowWaitingRoom();
					}
				});
			} else {
				//非特殊情况
				if (this.backHandler) {
					//如果需要更换大厅背景，自己调用changeBg
					this.backHandler.run();
					this.backHandler = null;
					if (!login_end && GameMgr.Inst.login_loading_end) {
						GameMgr.Inst.onLoadEnd('login', 'lobby');
					}
					GameMgr.Inst.last_game_mode_id = -1;
					return;
				}
				//通过牌谱链接进入
				if (GameMgr.Inst.outsee_paipuid != '') {
					let paipu: string = GameMgr.Inst.outsee_paipuid;
					GameMgr.Inst.outsee_paipuid = '';
					let ss: Array<string> = paipu.split('_');
					let account_id: number = 0;
					let config: number = 0;
					if (ss.length > 1) {
						if (ss[1].charAt(0) == 'a') account_id = game.Tools.decode_account_id(parseInt(ss[1].substr(1)));
						else account_id = parseInt(ss[1]);
					}
					if (ss.length > 2) {
						let n: number = parseInt(ss[2]);
						if (n) config = n;
					}
					GameMgr.Inst.checkPaiPu(ss[0], account_id, config);
				}
				//大会室
				else if (GameMgr.Inst.custom_match_id > 0) {

					bg_name = 'indoor';
					if (!uiscript.UI_Match_Room.Inst.enable) {
						uiscript.UI_Match_Room.Inst.show(GameMgr.Inst.custom_match_id);
					}
				} else if (GameMgr.Inst.in_shilian) {
					bg_name = 'indoor';
					uiscript.UI_Shilian.Inst.show();
					GameMgr.Inst.in_shilian = false;
				} else if (GameMgr.Inst.in_ab_match) {
					// uiscript.UIMgr.Inst.showLobby();
					let enter_lobby = true;
					if (uiscript.UI_Ob.Inst.enable || uiscript.UI_PaiPu.Inst.enable || uiscript.UI_Match_Room.Inst.enable) {
						enter_lobby = false;
						bg_name = 'indoor';
					}

					if (enter_lobby) {
						uiscript.UI_Lobby.Inst.enable = true;
					}
					uiscript.UI_AB_Match.Inst.show();
					GameMgr.Inst.in_ab_match = false;
				} else if (GameMgr.Inst.spot_chara_id != 0) {
					bg_name = 'indoor';
					GameMgr.Inst.spot_chara_id = 0;
					uiscript.UI_Sushe.Inst.spot_back();
				} else if (GameMgr.Inst.spot_activity_id != 0) {

					Laya.timer.frameOnce(3, this, () => {
						uiscript.UI_Lobby.Inst.enable = true;
						uiscript.UI_Activity_Spot.Inst.show();
					});

					GameMgr.Inst.spot_activity_id = 0;
				} else if (uiscript.UI_Rpg.needShow) {
					uiscript.UI_RPG_Change.Inst.openRPG(true);
				} else if (uiscript.UI_Activity_2508_Navigation.Inst && uiscript.UI_Activity_2508_Navigation.needShow) {
					uiscript.UI_Activity_2508_Navigation.Inst.show();
				} else if (GameMgr.Inst.in_activity_mode == E_Activity_State.liandong) {
					GameMgr.Inst.in_activity_mode = E_Activity_State.none;
					uiscript.UI_Activity_Liandong_Main.Inst.show();
				} else if (GameMgr.Inst.last_game_mode_id == 100) {
					Laya.timer.frameOnce(3, this, () => {
						uiscript.UI_XinShouYinDao_New.Inst.show();
						uiscript.UI_Lobby.Inst.enable = true;
					});
					GameMgr.Inst.last_game_mode_id = -1;
				} else {
					if (GameMgr.Inst.last_game_mode_id == 42) {
						uiscript.UI_Activity_JJC.Inst.show();
					}
					GameMgr.Inst.last_game_mode_id = -1;
					let enter_lobby = true;
					if (uiscript.UI_Ob.Inst.enable || uiscript.UI_PaiPu.Inst.enable || uiscript.UI_Match_Room.Inst.enable) {
						enter_lobby = false;
						bg_name = 'indoor';
					}
					if (enter_lobby) {
						uiscript.UI_Lobby.Inst.enable = true;
					}
				}
			}
			this.backHandler = null;
			this.change_bg(bg_name, true);
			if (!login_end && GameMgr.Inst.login_loading_end) {
				GameMgr.Inst.onLoadEnd('login', 'lobby');
			}
			GameMgr.Inst.last_game_mode_id = -1;
		}

		protected onDisable() {
			Laya.AtlasResourceManager.instance.freeAll();
			uiscript.UIMgr.Inst.onSceneLobby_Disable();
			if (this.scene) {
				this.scene.visible = false;
			}
			
			game.LoadMgr.disposeSceneRes('lobby');

			this._current_bg = '';
			this.bg_back_mat = null;
			this.bg_back_plane = null;
			this.bg_front_mat = null;
			this.bg_front_plane = null;
			this.scene.destroy(true);
			this.destoryActivityScene();
			if (this._effect_yard && !this._effect_yard.destroyed) {
				this._effect_yard.destroy(true);
				EffectMgr.remove_3d_resource(this._effect_yard_path);
			}
			this._effect_yard = null;
			this._effect_yard_path = '';
			if (this._effect_yinghua && !this._effect_yinghua.destroyed) {
				this._effect_yinghua.destroy(true);
				EffectMgr.remove_3d_resource(this._effect_yinghua_path);
			}
			this._effect_yinghua = null;
			this._effect_yinghua_path = '';
			this._current_effect = null;
			this.scene = null;
			this._yard_img_url = '';
			if (uiscript.UI_Activity_Sign.Inst && uiscript.UI_Activity_Sign.Inst.enable) {
				uiscript.UI_Activity_Sign.Inst.close();
			}
			// EffectMgr.dispose_3d_effect(this.ui_effect_list);
			game.EffectMgr.force_dispose_3d_res(this.scene_path);
			for (let i = 0; i < this.ui_scene_lst.length; i++) {
				EffectMgr.remove_3d_resource(this.ui_scene_lst[i]);
				// game.EffectMgr.force_dispose_3d_res(this.ui_scene_lst[i]);
			}
			this._during_change_bg = false;
			Laya.timer.clearAll(this);
		}

		initActivityScene(){
			if (uiscript.UI_Activity_Niudan.Inst) {
				uiscript.UI_Activity_Niudan.Inst.initScene();
			}
			if (uiscript.UI_Activity_Combining.Inst) {
				uiscript.UI_Activity_Combining.Inst.initScene();
			}
			if (uiscript.UI_Activity_2508_Navigation.Inst) {
				uiscript.UI_Activity_2508_Navigation.Inst.initScene();
			}
			// if (uiscript.UI_Activity_Liandong_Main.Inst) {
			// 	uiscript.UI_Activity_Liandong_Main.Inst.initScene();
			// }
			if (uiscript.UI_Activity_SnowBall_Main.Inst) {
				uiscript.UI_Activity_SnowBall_Main.Inst.initScene();
			}
		}

		destoryActivityScene(){
			if (uiscript.UI_Activity_Niudan.Inst) {
				uiscript.UI_Activity_Niudan.Inst.destroyScene();
			}
			if (uiscript.UI_Activity_Combining.Inst) {
				uiscript.UI_Activity_Combining.Inst.destroyScene();
			}
			if (uiscript.UI_Activity_2508_Navigation.Inst) {
				uiscript.UI_Activity_2508_Navigation.Inst.destroyScene();
			}
			if (uiscript.UI_Activity_SnowBall_Main.Inst) {
				uiscript.UI_Activity_SnowBall_Main.Inst.destroyScene();
			}
		}

		public addLoadListenter(complete: Laya.Handler, progress: Laya.Handler) {
			if (this._load_state == E_LoadState.loaded) {
				Laya.timer.once(500, this, () => {
					if (progress) progress.runWith(1);
					if (complete) complete.run();
				});
			} else {
				if (progress) this._progress_listener.push(progress);
				if (complete) this._load_listener.push(complete);
			}
		}

		public change_bg(name: string, fast: boolean, force: boolean = false) {
			if (name == this._current_bg && (!this._during_change_bg || !fast) && !force) return;
			let bg_img_url: string = '';
			let _effect: Laya.Sprite3D = null;
			if (name == 'indoor1') {
				bg_img_url = this._indoor_img_url_1;
				_effect = this._effect_yinghua;
			} else if (name == 'indoor') {
				bg_img_url = this._indoor_img_url;
				_effect = this._effect_yinghua;
			} else {
				bg_img_url = this._yard_img_url;
				_effect = this._effect_yard;
			}
			this._current_bg = name;
			if (!Laya.loader.getRes(bg_img_url)) {
				return;
			}
			if (this._current_effect != _effect) {
				if (this._current_effect) this._current_effect.active = false;
				this._last_effect = this._current_effect;

				this._current_effect = _effect;
			}
			if (this._current_bg == '') {
				fast = true;
			}

			if (fast) {
				this.bg_front_plane.active = false;
				this._during_change_bg = false;
				if (this._current_effect) {
					this._current_effect.active = true;
				}

				if (this._current_effect && this._current_effect.getChildAt(0).getChildByName('qianjing')) {
					for (let _child of this._current_effect.getChildAt(0)._childs) {
						_child.active = true;
						if (_child.name == 'qianjing') {
							let mat = (_child as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
							mat.albedoColor = new Laya.Vector4(1, 1, 1, 1);
						}
					}
				}
			} else {
				this.bg_front_plane.active = true;
				this.bg_front_mat.albedoTexture = this.bg_back_mat.albedoTexture;
				this.bg_front_mat.albedoColor = new Laya.Vector4(1, 1, 1, 1);
				this._during_change_bg = true;
				this._change_start_time = Laya.timer.currTimer;
				// 如果是特殊分层的特效，需要额外处理，打开静态层，关闭动态层
				if (this._last_effect && !this._last_effect.destroyed && this._last_effect.getChildAt(0).getChildByName('qianjing')) {
					this._last_effect.active = true;
					for (let _child of this._last_effect.getChildAt(0)._childs) {
						if (_child.name == 'qianjing') {
							_child.active = true;
						} else {
							_child.active = false;
						}
					}
				}

				if (this._current_effect && this._current_effect.getChildAt(0).getChildByName('qianjing')) {
					this._current_effect.active = true;
					for (let _child of this._current_effect.getChildAt(0)._childs) {
						if (_child.name == 'qianjing') {
							_child.active = true;
							let mat = (_child as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
							mat.albedoColor = new Laya.Vector4(1, 1, 1, 0);

						} else {

							_child.active = false;
						}
					}
				}
			}
			this.bg_back_mat.albedoTexture = Laya.loader.getRes(bg_img_url);
		}

		private get_effect_path(lobby_id: number): string {
			let _effect_path: string = '';
			switch (lobby_id) {
				case 307002: _effect_path = 'scene/effect_lobby_xiaritingyuan.lh'; break;
				case 307003: _effect_path = 'scene/effect_lobby_dongribeijing.lh'; break;
				case 307005: _effect_path = 'scene/effect_lobby_xiaribeijing.lh'; break;
				case 307006: _effect_path = 'scene/effect_lobby_qiuribeijing.lh'; break;
				case 307007: _effect_path = 'scene/effect_lobby_dongribeijing.lh'; break;
				case 307008: _effect_path = 'scene/effect_lobby_linjianxiari.lh'; break;
				case 307009: _effect_path = 'scene/effect_lobby_jidianyejing.lh'; break;
				case 307010: _effect_path = 'scene/effect_lobby_zhongxiaye.lh'; break;
				case 307011: _effect_path = 'scene/effect_lobby_22shengdan.lh'; break;
				case 307012: _effect_path = 'scene/effect_lobby_wuhuiting.lh'; break;
				case 307013: _effect_path = 'scene/effect_lobby_hongguang.lh'; break;
				case 307014: _effect_path = 'scene/effect_lobby_xiuqiutingyuan.lh'; break;
				case 30700001: _effect_path = 'scene/effect_lobby_jiuba.lh'; break;
				case 30700002:_effect_path = 'scene/effect_lobby_fenwoshi.lh'; break;
				case 30700003:_effect_path = 'scene/effect_lobby_gufengwoshi.lh'; break;
				case 30700005:_effect_path = 'scene/effect_lobby_dongmudaqiao.lh'; break;
				case 30700004:_effect_path = 'scene/effect_lobby_tangquan.lh'; break;
				case 30700006:_effect_path = 'scene/effect_lobby_shamo.lh'; break;
				case 30700007:_effect_path = 'scene/effect_lobby_yuanlin.lh'; break;
				default: _effect_path = 'scene/effect_lobby_yinghua.lh'; break;
			}
			return _effect_path;
		}

		public set_lobby_bg(lobby_id: number, complete?: Laya.Handler) {
			this.loadLobbyBg(lobby_id, Laya.Handler.create(this, () => { 
				lobby_id = uiscript.UI_Config_New.disableClickEffect == 1 ? 0 : lobby_id;
				this.loadClickEffect(lobby_id, complete);
			}));
		}

		/**
		 * 设置大厅背景图和配套点击特效
		 * @param lobby_id 
		 * @param complete 
		 * @returns 
		 */
		public set_lobby_bg_suit(lobby_id: number, complete?: Laya.Handler) {
			this.loadLobbyBg(lobby_id, Laya.Handler.create(this, () => {
				this.loadClickEffect(lobby_id, complete);
			}));
		}

		/**
		 * 设置大厅点击特效
		 * @param lobby_id 
		 * @param complete 
		 */
		public set_lobby_click_effect(lobby_id: number, complete?: Laya.Handler) {
			this.loadClickEffect(lobby_id, complete);
		}


		/**
		 * 加载大厅背景和大厅特效
		 * @param lobby_id 
		 * @param complete 
		 */
		private loadLobbyBg(lobby_id: number, complete?: Laya.Handler) { 
			let d_view = cfg.item_definition.view.get(lobby_id);
			let url: string = `scene/Assets/Resource/lobby/${d_view.res_name}.jpg`;
			let _effect_path: string = this.get_effect_path(lobby_id);
			if (this._yard_bg_id == lobby_id && this._yard_img_url == url) {
				if (complete) complete.run();
				return;
			}
			Laya.loader.clearTextureRes(this._yard_img_url);
			this._yard_img_url = url;
			this._yard_bg_id = lobby_id;
			if (this._effect_yard_path != this._effect_yinghua_path && this._effect_yard) {
				this._effect_yard.destroy(true);
				EffectMgr.remove_3d_resource(this._effect_yard_path);
				this._effect_yard_path = '';
				this._effect_yard = null;
			}
			Laya.loader.create(url, Laya.Handler.create(this, () => {
				Laya.loader.create(_effect_path, Laya.Handler.create(this, () => {
					EffectMgr.add_3d_resource(_effect_path);
					this._effect_yard_path = _effect_path;
					this._effect_yard = Laya.loader.getRes(_effect_path);
					if (this._effect_yard_path != this._effect_yinghua_path) this._effect_yard.active = false;
					this.container_effects.addChild(this._effect_yard);
					complete?.run();
				}));
			}));
		}

		

		private loadClickEffect(lobby_id: number, complete?: Laya.Handler) { 
			let clickPath = FrontEffect.Inst.getClickPathByLobby(lobby_id);
			if (clickPath == FrontEffect.Inst.effect_click_path) {
				if (complete) complete.run();
				return;
			}
			FrontEffect.Inst.SetClickEffectByLobby(lobby_id, Laya.Handler.create(this, ret => {
				if (this._current_bg == 'yard') {
					this.change_bg('yard', true, true);
				}
				if (complete) complete.run();
			}));
		}

		
		public set_spot_bg(bg_img_url: string) {
			if (this._current_effect) this._current_effect.active = false;
			this._current_bg = '';
			let path: string = 'scene/Assets/Resource/lobby/' + bg_img_url;

			if (!Laya.loader.getRes(path)) {
				return;
			}

			this.bg_front_plane.active = false;
			this._during_change_bg = false;
			this.bg_back_mat.albedoTexture = Laya.loader.getRes(path);
		}



		private _update() {
			if (this._during_change_bg) {
				let t: number = Laya.timer.currTimer - this._change_start_time;
				if (t >= 200) {
					this._during_change_bg = false;
					this.bg_front_plane.active = false;
					if (this._current_effect) {
						this._current_effect.active = this.currentEffectActive;
					}

					if (this._current_effect && this._current_effect.getChildAt(0).getChildByName('qianjing')) {
						let mat = (this._current_effect.getChildAt(0).getChildByName('qianjing') as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
						mat.albedoColor = new Laya.Vector4(1, 1, 1, 1);
						for (let _child of this._current_effect.getChildAt(0)._childs) {
							_child.active = true;
						}
					}
					if (this._last_effect) {
						this._last_effect.active = false;
					}
				} else {
					let r = 1 - t / 200;
					this.bg_front_mat.albedoColor = new Laya.Vector4(1, 1, 1, r);
					// 如果是特殊分层的特效，需要额外处理，打开静态层，关闭动态层
					if (this._last_effect && !this._last_effect.destroyed && this._last_effect.getChildAt(0).getChildByName('qianjing')) {
						let mat = (this._last_effect.getChildAt(0).getChildByName('qianjing') as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
						mat.albedoColor = new Laya.Vector4(1, 1, 1, r);
					}
					if (this._current_effect && this._current_effect.getChildAt(0).getChildByName('qianjing')) {
						let mat = (this._current_effect.getChildAt(0).getChildByName('qianjing') as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
						mat.albedoColor = new Laya.Vector4(1, 1, 1, 1 - r);
					}
				}
			}
			if (this._during_shake) {
				let t: number = Laya.timer.currTimer - this._shake_start_time;
				let index: number = Math.floor(t / 50);
				if (index >= 0 && index < this._shake_pos_list.length - 1) {
					let rate: number = (t - index * 50) / 50;
					let pos: Laya.Vector3 = new Laya.Vector3(0, 0, 0);
					pos.x = this._shake_pos_list[index].x * (1 - rate) + this._shake_pos_list[index + 1].x * rate;
					pos.y = this._shake_pos_list[index].y * (1 - rate) + this._shake_pos_list[index + 1].y * rate;
					pos.z = this._shake_pos_list[index].z * (1 - rate) + this._shake_pos_list[index + 1].z * rate;
					this.root_bg.transform.localPosition = pos;
				} else {
					this._during_shake = false;
					this.root_bg.transform.localPosition = this.root_origin_pos.clone();
				}
			}
		}

		private onProgressUpdate(p: number) {
			for (let i: number = 0; i < this._progress_listener.length; i++) {
				this._progress_listener[i].runWith(p);
			}
		}

		public shake() {
			this._shake_pos_list = [];
			this._during_shake = true;
			this._shake_start_time = Laya.timer.currTimer;
			for (let i: number = 0; i <= 10; i++) {
				let pos: Laya.Vector3 = this.root_origin_pos.clone();
				if (i != 10) {
					pos.x += (Math.random() - 0.5) * 2 * 0.56;
					pos.y += (Math.random() - 0.5) * 2 * 0.56;
				}
				this._shake_pos_list.push(pos);
			}
		}

		public getYardEffectState() {
			if (this._current_effect && this._current_effect.getChildAt(0).getChildByName('qianjing')) {
				let mat = (this._current_effect.getChildAt(0).getChildByName('qianjing') as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
				mat.albedoColor = new Laya.Vector4(1, 1, 1, 1);
			}
		}


		/**
		 * 跳出scene_lobby前设置返回时需要干啥，不走老的一堆特判了
		 */
		public setBackHandler(handler: Laya.Handler) {
			this.backHandler = handler;
		}

		// 硬件配置较低时会出现loading图预览错误，需要关闭scene
		public setLobbySceneVisible(visible: boolean) {
			this.scene.visible = visible;
		}


		/**
		 * 其他处使用切换特效和背景图，这里不处理图片加载，特效加载会进行处理
		 * @param bgUrl 
		 * @param effectUrl 
		 */
		public setSpecialBg(bgUrl: string, effectUrl: string, fast: boolean = false) {
			this.currentEffectActive = false;
			// this.bg_kuang.active = false;
			let _sepcialImgId = ++this._sepcialImgId;
			if (this._current_effect) this._current_effect.active = false;
			if (this._special_img_url != bgUrl) {
				this._special_img_url = bgUrl;
				let complete = Laya.Handler.create(this, ()=>{
					if (this._sepcialImgId != _sepcialImgId) return;
					if (fast) {
						if (this._current_effect) this._current_effect.active = false;
						this.bg_front_plane.active = false;
						this._during_change_bg = false;

					} else {
						this.bg_front_plane.active = true;
						this.bg_front_mat.albedoTexture = this.bg_back_mat.albedoTexture;
						this.bg_front_mat.albedoColor = new Laya.Vector4(1, 1, 1, 1);
						this._during_change_bg = true;
						this._change_start_time = Laya.timer.currTimer;
					}
					this.bg_back_mat.albedoTexture = Laya.loader.getRes(bgUrl);
				});
				if (Laya.loader.getRes(bgUrl)) {
					complete.run();
				} else {
					Laya.loader.create(bgUrl, complete);
				}
				
			}
			
			if (this._effect_special_path != effectUrl) {

				if (this._effect_special) {
					// this._effect_special.destroy(true);
					this._effect_special.active = false;
					this._effect_special_pathes.push(this._effect_special_path);
					// EffectMgr.remove_3d_resource(this._effect_special_path);
					this._effect_special_path = '';
					this._effect_special = null;

				}

				this._effect_special_path = effectUrl;
				if (effectUrl) {
					game.EffectMgr.add_3d_resource(effectUrl);
					if (!Laya.loader.getRes(effectUrl)) {
						Laya.loader.create(effectUrl, Laya.Handler.create(this, () => {
							if (effectUrl != this._effect_special_path) {
								let spr: Laya.Sprite3D = Laya.loader.getRes(effectUrl);
								if (spr) {
									if (this.currentEffectActive) {
										spr.destroy();
										EffectMgr.remove_3d_resource(effectUrl);
									} else {
										spr.active = false;
										this._effect_special_pathes.push(effectUrl);
									}
								}
								return;
							}
							this._effect_special = Laya.loader.getRes(this._effect_special_path);
							if (this._effect_special) {
								this.container_effects.addChild(this._effect_special);
							}
						}))
					} else {
						this._effect_special = Laya.loader.getRes(this._effect_special_path);
						if (this._effect_special) {
							this.container_effects.addChild(this._effect_special);
						}
					}
				}


			}
			
			if (this._effect_special) {
				this._effect_special.active = false;
				this._effect_special.active = true;
			}
		}

		public resetSpecialBg() {
			this.currentEffectActive = true;
			// this.bg_kuang.active = true;
			if (this._current_effect) this._current_effect.active = true;
			if (this._effect_special) {
				this._effect_special.destroy(true);
				EffectMgr.remove_3d_resource(this._effect_special_path);
				this._effect_special_path = '';
				this._effect_special = null;
			}
			this._effect_special_pathes.forEach(v => {
				const sp:Laya.Sprite3D = Laya.loader.getRes(v);
				if (sp) sp.destroy();
				EffectMgr.remove_3d_resource(v);
			});
			this._effect_special_pathes.length = 0;

			if (this._special_img_url) {
				Laya.loader.clearTextureRes(this._special_img_url);
				this._special_img_url = '';
				this.bg_back_mat.albedoTexture = Laya.loader.getRes(this._yard_img_url);
			}

		}

		public get lobbyId(): number { 
			return this._yard_bg_id; 
		}

		public clearJumpMark() {
			if (uiscript.UI_Activity_2508_Navigation && uiscript.UI_Activity_2508_Navigation.Inst) {
				uiscript.UI_Activity_2508_Navigation.needShow = false;
			}
		}
	}

}