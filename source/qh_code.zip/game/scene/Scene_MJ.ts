/**
* name 
*/
module game{
	interface loadErrInfo{
		currentState: number;
		myMJP: string;
		playersSkins: Array<Object>;
		playersViews: Array<Object>;
		desktop: string;

	}
	export const SpecialMJPMode = ['wanxiangxiuluo_mode'];
	export class Scene_MJ extends SceneBase {

		public static Inst:Scene_MJ = null;
		private static ui_effect_list:Array<string> = [
			'scene/effect_getstar.lh',
			'scene/effect_losestar.lh',
			'scene/effect_queshi_bang.lh',
			'scene/effect_juanzhou.lh',
			'scene/effect_yiman.lh',
			'scene/effect_yiman2.lh',
			// 'scene/effect_yuebing_white.lh'
			'scene/effect_ggsk_js.lh',
		];

		private desktop: Laya.Scene = null;
		private camera_main:Laya.Camera = null;
		private scene_path2: string = "scene/mjhandpai.ls";
		private team_name_path: string = "scene/team_name.lh";


		public scene_hand: Laya.Scene = null;
		public root2: Laya.Sprite3D = null;
		public camera_hand: Laya.Camera = null;
		
		private scene_path_effect_fullscreen: string = "scene/mjdesktop_effect_fullscreen.ls";
		private scene_effect_fullscreen: Laya.Scene = null;
		public effect_fullscreen_root: Laya.Sprite3D = null;
		public effect_fullscreen_camera: Laya.Camera = null;
		

		private _common_texture2d_loaded:boolean = false;
		private _desktop_model_path:string = '';
		private _desktop_model:Laya.Sprite3D;
		private _mjp_path:string = '';
		private _effect_list:Array<string> = [];
		private _ui_effect_list:Array<string> = [];
		private _fullscreen_effect_list: Array<string> = [];
		private _mjp_textures:Array<string> = []; //麻将牌的贴图，关闭的时候要释放掉
		private _model_list:Array<string> = [];
		private _atlas_list: Array<string> = [];
		private _ui_img_list: Array<string> = [];
		private mjp_default_surface_view: string = '';        //默认麻将牌的外观，如果需要额外加载默认麻将牌时使用
		private _special_mode_textures: Array<string> = [];

		public constructor() {
			super();
			Scene_MJ.Inst = this;
			if (GameMgr.client_language != 'chs') {
				Scene_MJ.ui_effect_list.push(`scene/effect_winlose_${GameMgr.client_language}.lh`);
			} else {
				Scene_MJ.ui_effect_list.push('scene/effect_winlose.lh');
			}
			Scene_MJ.ui_effect_list.push(`scene/effect_yiman_queding_${GameMgr.client_language}.lh`);
			Scene_MJ.ui_effect_list.push(`scene/effect_yiman_jihui_${GameMgr.client_language}.lh`);
		}

		public init(data:any) {

		}

		protected onEnable() {
			if (this.scene_effect_fullscreen) this.scene_effect_fullscreen.visible = true;
			uiscript.UI_Popout.Inst.enable = false;
			uiscript.UIMgr.Inst.onSceneMJ_Enable();
			uiscript.UI_ErrorInfo.destroyAllError();
			game.TempImageMgr.setUIEnable('Scene_MJ', true);
			GameMgr.Inst.checkMouse();
		}

		protected onDisable() {
			if (this.scene_effect_fullscreen) this.scene_effect_fullscreen.visible = false;
			game.TempImageMgr.setUIEnable('Scene_MJ', false);
			// 重新随机麻将牌
			uiscript.UI_Sushe.randomDesktopID();
			// 麻将牌
			GameMgr.Inst.load_mjp_view();
			
			uiscript.UIMgr.Inst.onSceneMJ_Disable();
			view.DesktopMgr.Inst.Reset();
        	view.DesktopMgr.Inst.active = false;
			this.desktop.visible = false;
			MJNetMgr.Inst.Close();
			game.LoadMgr.disposeSceneRes('mjdesktop');
		}

		public openMJRoom(config:game.IGameConfig, players:Array<Object>, complete:Laya.Handler, progress:Laya.Handler) {
			if (game.Scene_Lobby.Inst && game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
			if (game.Scene_Lobby.Inst) game.Scene_Lobby.Inst.clearJumpMark();
			
			let errorInfo: loadErrInfo = {
				currentState: 0,
				myMJP: game.GameUtility.get_view_res_name(EView.mjp),
				desktop: game.GameUtility.get_view_res_name(EView.desktop),
				playersViews: [],
				playersSkins: []
			};
			for (let index = 0; index < players.length; index++) {
				const player = players[index];
				if (player['views']) {
					errorInfo.playersViews.push(player['views']);
				}
				errorInfo.playersSkins.push(player['character']['skin']);
			}
			// ==DevDebug Start==
			game.GameDebug.checkUseMyView(players as any);
			// ==DevDebug End==

			let reportLoadErr = () => { 
				if (loadSuccess) {
					return;
				}
				GameMgr.Inst.postInfo2Server("match_loading_fail", errorInfo, false);
			}
			let loadSuccess: boolean = false;
			//两分钟后如果没有进入游戏，则加载失败,上报数据
			Laya.timer.once(120000, this, reportLoadErr)
			this.load_common_texture2d(config, Laya.Handler.create(this, () => {
				errorInfo.currentState = 1;
				app.Log.log('load_common_texture2d over');
				this.load_mainscene(Laya.Handler.create(this, () => {
					app.Log.log('load_mainscene over');
					errorInfo.currentState = 2;
					this.active_common_texture2d(Laya.Handler.create(this, () => {
						errorInfo.currentState = 3;
						app.Log.log('active_common_texture2d over');
						this._load_my_desktop_view(Laya.Handler.create(this, () => {
							errorInfo.currentState = 4;
							app.Log.log('_load_my_desktop_view over');
							this._load_my_mjp_view(config, Laya.Handler.create(this, () => {
								errorInfo.currentState = 5;
								app.Log.log('_load_my_mjp_view over');
								this._load_my_mjpm_view(config, Laya.Handler.create(this, ()=>{
									errorInfo.currentState = 6;
									app.Log.log('_load_my_mjpm_view over');
									this._load_player_views(config, players, Laya.Handler.create(this, ()=>{
										errorInfo.currentState = 7;
										app.Log.log('_load_player_effects over');
										loadSuccess = true;
										Laya.timer.clear(this, reportLoadErr);
										const teamName = Laya.loader.getRes(this.team_name_path) as Laya.Sprite3D;
										if (teamName) this.desktop.addChild(teamName);
										view.DesktopMgr.Inst.active = true;
										this.desktop.visible = true;
										view.DesktopMgr.Inst.Reset();
										progress.runWith(1);
										complete.run();
										if (MJNetMgr.Inst.playerreconnect) {

										} else if (!GameMgr.Inst.login_loading_end) {
											GameMgr.Inst.login_loading_end = true;
											GameMgr.Inst.onLoadEnd('login', 'game');
										} else if (view.DesktopMgr.Inst.mode == view.EMJMode.play) {
											GameMgr.Inst.onLoadEnd('match');
											if (Tools.CheckReconnectInfoNeedSend()) {
												var content = { game_uuid: GameMgr.Inst.mj_game_uuid };
												game.Tools.SendSpecialInfo(content, 'match_loading_end')
											}
										} else if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
											GameMgr.Inst.onLoadEnd('paipu');
										} else if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast) {
											GameMgr.Inst.onLoadEnd('ob');
										}
									}), Laya.Handler.create(this, p => progress.runWith(0.75 + 0.25 * p), null, false));
								}), Laya.Handler.create(this, p => progress.runWith(0.70 + 0.05 * p), null, false));
							}), Laya.Handler.create(this, p => progress.runWith(0.65 + 0.05 * p), null, false));
						}), Laya.Handler.create(this, p => progress.runWith(0.6 + 0.05 * p), null, false));
					}), Laya.Handler.create(this, p => progress.runWith(0.55 + 0.05 * p), null, false));
				}), Laya.Handler.create(this, p => progress.runWith(0.1 + 0.45 * p), null , false));
			}), Laya.Handler.create(this, p => progress.runWith(0.1 * p), null, false));
		}

		//加载主场景，只加载一次，后面就保留下来不删除了
		private load_mainscene(complete:Laya.Handler, progress:Laya.Handler) {
			uiscript.UIMgr.Inst.openMjDesktopUI(Laya.Handler.create(this, () => {
				if (!this.desktop) {
					cfg.audio.audio.forEach(value => {
						if (value.type == 'mj') Laya.loader.load(value.path + view.AudioMgr.suffix);
					});
					game.LoadMgr.loadRes(game.E_LoadType.scene_mj, Laya.Handler.create(this, () => Laya.timer.frameOnce(1, this , () => {
						let scene_path: string = "scene/mjdesktop.ls";
						if (GameMgr.client_language == 'en') scene_path = "scene/mjdesktop_en.ls";
						this.desktop = Laya.loader.getRes(scene_path);
						this.desktop.ambientColor = new Laya.Vector3(0.40, 0.40, 0.40);
						let camera:Laya.Camera = this.desktop.getChildByName('main_camera') as Laya.Camera;
						GameMgr.Inst.addScene(this.desktop);
						var directionLight: Laya.DirectionLight = this.desktop.addChild(new Laya.DirectionLight()) as Laya.DirectionLight;
						directionLight.transform.translate(new Laya.Vector3(0, 1, 1.7));
						directionLight.color = new Laya.Vector3(0.5, 0.5, 0.5);
						directionLight.transform.localRotation = new Laya.Quaternion(0,-0.75, -0.8, 0)

						let d2 = Laya.loader.getRes(this.scene_path2);
						GameMgr.Inst.addScene(d2);
						this.scene_hand = d2;
						// 特效container
						let handEffect: Laya.Sprite3D = new Laya.Sprite3D();
						handEffect.name = 'effect';
						handEffect.transform.localPosition = new Laya.Vector3(0, 0, 0);
						handEffect.transform.localScale = new Laya.Vector3(1, 1, 1);
						handEffect.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
						this.scene_hand.addChild(handEffect);
						this.root2 = d2.getChildByName('root') as Laya.Sprite3D;
						this.camera_hand = d2.getChildByName('camera') as Laya.Camera;
						this.camera_hand.useOcclusionCulling = false;

						//生成全屏特效场景
						let d3 = Laya.loader.getRes(this.scene_path_effect_fullscreen);
						GameMgr.Inst.addScene(d3);
						this.scene_effect_fullscreen = d3;
						this.effect_fullscreen_root = d3.getChildByName('container_effect') as Laya.Sprite3D;
						this.effect_fullscreen_camera = d3.getChildByName('main_camera') as Laya.Camera;

						let mgr = (this.desktop.getChildByName('room') as Laya.Sprite3D).addComponent(view.DesktopMgr) as view.DesktopMgr;
						mgr.mainCamera = camera;
						camera.useOcclusionCulling = false;

						progress.runWith(1);
						complete.run();
					})), Laya.Handler.create(this, p => progress.runWith(0.2 + 0.8 * p), null, false));
				} else {
					progress.runWith(1);
					complete.run();
				}
			}, null, false), Laya.Handler.create(this, p=>progress.runWith(p * 0.2), null, false));
		}

		//加载通用的麻将会用到的2d贴图，保存在内存里，可提前加载
		public load_common_texture2d(config: IGameConfig, complete?:Laya.Handler, progress?:Laya.Handler) {
			if (this._common_texture2d_loaded) {
				let lst = this.getSpecialModeTexture2dLst(config);
				let newLst = [];
				for (let i = 0; i < lst.length; i++) {
					if (this._special_mode_textures.indexOf(lst[i]) == -1) {
						newLst.push(lst[i]);
					}
				}
				if (newLst.length > 0) {
					this._special_mode_textures = this._special_mode_textures.concat(newLst);
					Laya.loader.create(newLst, Laya.Handler.create(this, () => {
						if (complete) complete.run();
					}), progress, laya.d3.resource.Texture2D_caps);
				} else {
					if (progress) progress.runWith(1);
					if (complete) complete.run();
				}
			} else {
				let lst:Array<string> = [];
				for (let i:number = 0; i < EffectMgr.d3res_map['mj_common_texture2d'].length; i++) {
					lst.push(EffectMgr.d3res_map['mj_common_texture2d'][i]);
				}
				this._special_mode_textures = this.getSpecialModeTexture2dLst(config);
				lst = lst.concat(this._special_mode_textures);
				Laya.loader.create(lst, Laya.Handler.create(this, ()=>{
					this._common_texture2d_loaded = true;
					if (complete) complete.run();
				}), progress, laya.d3.resource.Texture2D_caps);
			}
		}

		private getSpecialModeTexture2dLst(config: IGameConfig): string[] {
			let lst = [];
			if (config && config.mode && config.mode.detail_rule) {
				if (config.mode.detail_rule.beishuizhizhan_mode) {
					if (GameMgr.client_language == 'en') {
						lst.push('scene/Assets/Resource/table/tablemid_en/feng_beishui1.png');
						lst.push('scene/Assets/Resource/table/tablemid_en/feng_beishui2.png');
					} else {
						if (GameMgr.client_language == 'kr') {
							lst.push('scene/Assets/Resource/table/tablemid/feng_beishui1_kr.png');
							lst.push('scene/Assets/Resource/table/tablemid/feng_beishui2_kr.png');
						} else {
							lst.push('scene/Assets/Resource/table/tablemid/feng_beishui1.png');
							lst.push('scene/Assets/Resource/table/tablemid/feng_beishui2.png');
						}
					}
				}
				if (config.mode.detail_rule.amusement_switches) {
					if (config.mode.detail_rule.amusement_switches.indexOf(game.EMJGameRule.XiaKeShang) >= 0) {
						lst.push('scene/Assets/Resource/table/tablemid/xiakeshang_score.png');
					}
				}
			}
			return lst;
		}

		//激活通用麻将用2d贴图
		private active_common_texture2d(complete:Laya.Handler, progress:Laya.Handler) {
			progress.runWith(0);
			let lst:Array<string> = [];
			for (let i:number = 0; i < EffectMgr.d3res_map['mj_common_texture2d'].length; i++) {
				lst.push(EffectMgr.d3res_map['mj_common_texture2d'][i]);
			}
			lst = lst.concat(this._special_mode_textures);
			let index:number = 0;
			let _recreate = () => {
				if (index >= lst.length) {
					progress.runWith(1);
					complete.run();
					return;
				}
				progress.runWith(index / lst.length);
				let _res = Laya.loader.getRes(lst[index]);
				if (_res) _res.recreateResource();
				index ++;
				_recreate();
			};
			_recreate();
		}

		//删除gpu中的通用麻将2d贴图，可以重新激活
		private clearTexture_commont_texture2d() {
			let lst:Array<string> = EffectMgr.d3res_map['mj_common_texture2d'];
			lst = lst.concat(this._special_mode_textures);
			for (let i:number = 0; i < lst.length; i++) {
				let __res = Laya.loader.getRes(lst[i]);
				if (__res) {
					__res.clearTexture();
				}
			}
		}

		// 加载3d麻将牌的贴图资源
		private _load_my_mjp_view(config: game.IGameConfig, complete?:Laya.Handler, progress?:Laya.Handler) {
			let lst:Array<string> = [];
		
			// let desktop_res_name:string = game.GameUtility.get_view_res_name(EView.desktop);
			// if (desktop_res_name == 'tablecloth_quehunji1' && GameMgr.client_language != 'chs' && GameMgr.client_language != 'chs_t')  {
			// 	desktop_res_name += '_enjp'; 
			// }
			// if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'en') {
			// 	desktop_res_name += '_en';
			// }
			// if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'chs_t') {
			// 	desktop_res_name += '_chs_t';
			// }
			// if (desktop_res_name == 'tablecloth_21chunjie' && GameMgr.client_language != 'chs')  {
			// 	desktop_res_name += '_chs_t'; 
			// }
			// if (desktop_res_name != 'tablecloth_21fish' && desktop_res_name != 'tablecloth_22event') {
			// 	lst.push('scene/Assets/Resource/tablecloth/' + desktop_res_name + '/Table_Dif.jpg');
			// }
			// if ((desktop_res_name == 'tablecloth_official_sxz' || desktop_res_name == 'tablecloth_official_qlz') && GameMgr.client_language == 'jp') {
			// 	desktop_res_name += '_jp';
			// }
			
			// 0526添加牌背牌面拆分
			// 获取牌背
			let mjp_name:string = game.GameUtility.get_view_res_name(EView.mjp);
			let mjp_path:string = 'scene/Assets/Resource/mjpai/';
			lst.push(mjp_path + mjp_name + '/' + 'mjp.png');
			lst.push(mjp_path + mjp_name + '/' + 'hand.png');
			let isTouMingPai: boolean = config && config.mode && config.mode.detail_rule && !!config.mode.detail_rule.jiuchao_mode;
			// 获取牌面
			// 备注：透明牌模式不是用自定义牌面，只使用默认牌面
			let mjp_surface_name: string = isTouMingPai ?  'mjpface_default': game.GameUtility.get_view_res_name(game.EView.mjp_surface);
			if (view.DesktopMgr.en_mjp) {
				mjp_surface_name += '_0';
			}
			let mjpm_path: string = 'scene/Assets/Resource/mjpaimian/';
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') mjpm_path += 'en_kr/';
			// 添加获取牌面
			lst.push(mjpm_path + mjp_surface_name + '/' + 'mjp.png');
			lst.push(mjpm_path + mjp_surface_name + '/' + 'hand.png');
			lst = lst.concat(this.getSpecialModeViewUrls(config));
			this._mjp_textures = lst;
			Laya.loader.create(lst, complete, progress);
		}

		private getSpecialModeViewUrls(config: game.IGameConfig): string[] {
			let lst = [];
			if (!config || !config.mode || !config.mode.detail_rule) return lst;
			if (config.mode.detail_rule.jiuchao_mode) { // 透明牌保持老路径
				if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
					if (view.DesktopMgr.en_mjp) {
						lst.push('scene/Assets/Resource/mjpai/en_kr/toumingpai_0/mjp.png');
						lst.push('scene/Assets/Resource/mjpai/en_kr/toumingpai_0/hand_ui.png');
					} else {
						lst.push('scene/Assets/Resource/mjpai/en_kr/toumingpai/mjp.png');
						lst.push('scene/Assets/Resource/mjpai/en_kr/toumingpai/hand_ui.png');
					}
				} else {
					lst.push('scene/Assets/Resource/mjpai/toumingpai/mjp.png');
					lst.push('scene/Assets/Resource/mjpai/toumingpai/hand_ui.png');
				}

			} else {
				// 例：scene/Assets/Resource/mjpaimian/en_kr/mjpface_special_0/wanxiangxiuluo_mode/hand.png
				let specialModeUrl = 'scene/Assets/Resource/mjpaimian/';
				if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
					if (view.DesktopMgr.en_mjp) {
						specialModeUrl += 'en_kr/mjpface_special_0/';
					} else {
						specialModeUrl += 'en_kr/mjpface_special/';
					}
				} else {
					specialModeUrl += 'mjpface_special/';
				}
				SpecialMJPMode.forEach((modeName) => {
					if (config.mode.detail_rule[modeName]) {
						lst.push(specialModeUrl + modeName + '/mjp.png');
						lst.push(specialModeUrl + modeName + '/hand.png');
					}
				})
			}
			return lst;
		}

		// 加载我自己的牌桌
		private _load_my_desktop_view(complete: Laya.Handler, progress: Laya.Handler) {

			let desktop_res_name: string = game.GameUtility.get_view_res_name(EView.desktop);
			if (desktop_res_name == 'tablecloth_quehunji1' && GameMgr.client_language != 'chs' && GameMgr.client_language != 'chs_t') {
				desktop_res_name += '_enjp';
			}
			if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'en') {
				desktop_res_name += '_en';
			}
			if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'kr') {
				desktop_res_name += '_kr';
			}
			if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'chs_t') {
				desktop_res_name += '_chs_t';
			}
			if (desktop_res_name == 'tablecloth_20chunjie' && GameMgr.client_language == 'jp') {
				desktop_res_name += '_jp';
			}
			if (desktop_res_name == 'tablecloth_21chunjie' && GameMgr.client_language != 'chs') {
				desktop_res_name += '_chs_t';
			}
			if ((desktop_res_name == 'tablecloth_official_sxz' || desktop_res_name == 'tablecloth_official_qlz') && GameMgr.client_language == 'jp') {
				desktop_res_name += '_jp';
			}
			this._desktop_model_path = 'scene/' + desktop_res_name + '.lh';
			EffectMgr.add_3d_resource(this._desktop_model_path);
			Laya.loader.create(this._desktop_model_path, Laya.Handler.create(this, ()=>{
				this._desktop_model = Laya.loader.getRes(this._desktop_model_path);
				this.desktop.getChildByName('room').getChildByName('container_desktop').addChild(this._desktop_model);
				this._desktop_model.transform.localPosition = new Laya.Vector3(0, 0, 0);
				this._desktop_model.transform.localScale = new Laya.Vector3(1, 1, 1);
				this._desktop_model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				this._desktop_model.active = true;
				this._desktop_model.isStatic = true;
				if (desktop_res_name == 'tablecloth_22event') {
					let parent = this._desktop_model.getChildAt(0) as Laya.Sprite3D;
					for (let i = 1; i < 6; i++) {
						let _node = parent.getChildAt(i) as Laya.Sprite;
						for (let j = 0; j < _node._childs.length; j++) {
							if ((i ==4 && j ==4) || (i == 5 && j == 0)) {
								continue;
							}
							((_node.getChildAt(j) as Laya.MeshSprite3D).meshRender.material as Laya.StandardMaterial).disableLight();
						}
					}
				}
				progress.runWith(1);
				complete.run();
			}), progress);
		}

		// 加载玩家带的特殊特效预热
		private _load_player_views(config: game.IGameConfig, players:Array<Object>, complete:Laya.Handler, progress:Laya.Handler) {

			let fullscreen_effect_map: Object = {};
			let effect_map:Object = {};
			let ui_effect_map:Object = {};
			let model_map:Object = {};
			let skin_imgs:Object = {};
			let bgm_map:Object = {};
			let cutin_map: Object = {};

			if (config) {
				//宝牌狂热
				{				
					let dora3_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['dora3_mode']) {
						dora3_mode = true;
					} 
					if (dora3_mode) {
						ui_effect_map[`scene/effect_dora3_begin_${GameMgr.client_language}.lh`] = 1;
						ui_effect_map['scene/effect_dora3_shine.lh'] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/effect_moshi_fanbaopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//配牌open
				{				
					let peipai_open:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['begin_open_mode']) {
						peipai_open = true;
					} 
					if (peipai_open) {
						ui_effect_map[`scene/effect_peipai_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//龙之目玉
				{				
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['muyu_mode']) {
						effect_map[`scene/effect_muyu_${GameMgr.client_language}.lh`] = 1;
						for (let i:number = 0; i < 6; i++) {
							Laya.loader.create(`scene/Assets/Resource/effect/texture/muyu_shuzi_${i}.png`);
						}
						ui_effect_map[`scene/effect_muyu_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/moshi_longzhimuyu' + view.AudioMgr.suffix] = 1;
					} 
				}
				{				
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['muyu_mode']) {
						effect_map[`scene/effect_muyu_${GameMgr.client_language}.lh`] = 1;
						for (let i:number = 0; i < 6; i++) {
							Laya.loader.create(`scene/Assets/Resource/effect/texture/muyu_shuzi_${i}.png`);
						}
						ui_effect_map[`scene/effect_muyu_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/moshi_longzhimuyu' + view.AudioMgr.suffix] = 1;
					} 
				}
				{
					if (config && config['meta'] && config['meta']['mode_id'] == game.EMatchMode.shilian) {
						ui_effect_map[`scene/effect_shilian_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				{
					if (config && config['meta'] && config['meta']['mode_id'] == game.EMatchMode.hesu) {
						ui_effect_map[`scene/effect_xiuluo_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//川麻
				{				
					let chuanma_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['chuanma']) {
						chuanma_mode = true;
					} 
					if (chuanma_mode) {
						ui_effect_map[`scene/effect_chiyu_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//鹫巢
				{				
					let jiuchao_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['jiuchao_mode']) {
						jiuchao_mode = true;
					} 
					if (jiuchao_mode) {
						ui_effect_map[`scene/effect_mingjing_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//暗牌
				{				
					let anpai_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['reveal_discard']) {
						anpai_mode = true;
					} 
					if (anpai_mode) {
						ui_effect_map[`scene/effect_anye_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				// 巅峰
				{			
					let mode_id:number = 0;
					if (config && config['meta']) {
						mode_id = config['meta']['mode_id'];
					}
					let is_top_match:boolean =  false;
					if ((mode_id == 15 || mode_id == 16 || mode_id == 25 || mode_id == 26)) {
						is_top_match = true;
						let mode = 0;
						if (config['mode']) {
							mode = config['mode']['mode'];
						}
						for (let player of players) {
							let level = mode < 10 ? player['level']['id'] : player['level3']['id'];
							if (cfg.level_definition.level_definition.get(level).primary_level != 6) {
								is_top_match = false;
								break;
							}
						}
					}	
					
					if (is_top_match) {
						ui_effect_map[`scene/effect_dianfengduiju_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}

				//辉夜
				{				
					let field_spell_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['field_spell_mode']) {
						field_spell_mode = true;
					} 
					if (field_spell_mode) {
						ui_effect_map[`scene/effect_xianjing_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
						ui_effect_map[`scene/effect_huiye.lh`] = 1;
					}
				}

				//占星
				{				
					let zhanxing:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['zhanxing']) {
						zhanxing = true;
					} 
					if (zhanxing) {
						ui_effect_map[`scene/effect_zhanxing_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}

				//天命
				{				
					let tianming_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['tianming_mode']) {
						tianming_mode = true;
					} 
					if (tianming_mode) {
						ui_effect_map[`scene/effect_tianming_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//咏唱
				{				
					let anpai_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['yongchang_mode']) {
						anpai_mode = true;
					} 
					if (anpai_mode) {
						ui_effect_map[`scene/effect_yongchang_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
					}
				}
				//魂之一击
				{				
					let hunzhiyiji_mode:boolean =  false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['hunzhiyiji_mode']) {
						hunzhiyiji_mode = true;
					} 
					if (hunzhiyiji_mode) {
						// 对局开始特效
						ui_effect_map[`scene/effect_hunzhiyiji_begin_${GameMgr.client_language}.lh`] = 1;
						bgm_map['audio/audio_mj/effect_moshi_baopai' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/hunzhiyiji_countstart' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/hunzhiyiji_countdown' + view.AudioMgr.suffix] = 1;
						bgm_map['audio/audio_mj/hunzhiyiji_overload' + view.AudioMgr.suffix] = 1;
						ui_effect_map['scene/effect_hunzhijiyi_broken.lh'] = 1;
						
					}
				}
				//背水之战
				{
					let beishuizhizhan_mode: boolean = false;
					if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['beishuizhizhan_mode']) {
						beishuizhizhan_mode = true;
					}
					if (beishuizhizhan_mode) {
						// 对局开始特效
						effect_map[`scene/effect_beishuizhizhan_feng1.lh`] = 1;
						effect_map[`scene/effect_beishuizhizhan_feng2.lh`] = 1;
						effect_map[`scene/effect_beishuizhizhan_fire1.lh`] = 1;
						effect_map[`scene/effect_beishuizhizhan_fire2.lh`] = 1;
						ui_effect_map[`scene/effect_beishuizhizhan_begin_${GameMgr.client_language}.lh`] = 1;
					}
				}
				// 其他对局模式
				{
					if (config && config.mode && config.mode.detail_rule && config.mode.detail_rule.amusement_switches) {
						for (let i = 0; i < config.mode.detail_rule.amusement_switches.length; i++) {
							let mode = config.mode.detail_rule.amusement_switches[i];
							if (mode == game.EMJGameRule.XiaKeShang) {
								ui_effect_map[`scene/effect_xiakeshang_begin_${GameMgr.client_language}.lh`] = 1;
							} else if (mode == game.EMJGameRule.QiangDuoZhiZhan) {
								ui_effect_map[`scene/effect_qiangduozhizhan_begin_${GameMgr.client_language}.lh`] = 1;
								model_map['scene/tribute_tile.lh'] = 1;
							}
							//其他模式
						}
					}
				}
			}
			effect_map['scene/effect_mingpai_default.lh'] = 1;
			let mingpai_zhishi:string = game.GameUtility.get_view_res_name(EView.mingpai_zhishi);
			let _mingpai_zhishi_path = 'scene/' + mingpai_zhishi + '.lh';
			effect_map[_mingpai_zhishi_path] = 1;
			//如果是牌谱模式，则加载牌谱鸣牌特效
			// if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
			// 	let mingpai_zhishi_maka: string = game.GameUtility.get_view_res_name(EView.mingpai_zhishi_maka);
			// 	let _mingpai_zhishi_maka_path = 'scene/' + mingpai_zhishi_maka + '.lh';
			// 	effect_map[_mingpai_zhishi_maka_path] = 1;
			// }
			
			let _view_type_min:number = game.EView.liqibang as number;
			let _view_type_max:number = game.EView.mingpai_zhishi as number;
			for (let i:number = 0; i < players.length; i++) {
				let d_player = players[i];
				if (!d_player) continue;
				if (d_player['team_name'])
					model_map[this.team_name_path] = 1;
				if (!d_player['character']) continue;
				if (d_player['account_id'] != GameMgr.Inst.account_id && GameMgr.regionLimited && game.GameUtility.char_limited(d_player['character']['charid'])){
					d_player['character']['charid'] = game.GameUtility.get_default_ai_character();
					d_player['character']['skin'] = game.GameUtility.get_default_ai_skin();
					d_player['avatar_id'] = game.GameUtility.get_default_ai_skin();
				}
				let _effect_map:Object = {};
				
				let d_character = d_player['character'];
				let excel_character = cfg.item_definition.character.get(d_character['charid']);
				if (excel_character) {
					_effect_map[game.EView.hand_model] = excel_character.hand;
					if (excel_character.ur_liqi) {
						_effect_map[game.EView.lizhi_effect] = excel_character.ur_liqi;
					}
					if (excel_character.ur_ron) {
						_effect_map[game.EView.hupai_effect] = excel_character.ur_ron;
					}
				}

				if (d_player['views']) {
					if (d_player['account_id'] != GameMgr.Inst.account_id && GameMgr.regionLimited) {
						for (let j:number = d_player['views'].length - 1; j >= 0; j--) {
							let item_id:number = d_player['views'][j].item_id;
							if (item_id && cfg.item_definition.item.get(item_id).region_limit == 1) {
								d_player['views'].splice(j, 1);
							}
						}
					}
					
					for (let j:number = 0; j < d_player['views'].length; j++) {
						let slot = d_player['views'][j].slot;
						let item_id = d_player['views'][j].item_id;
						if (item_id) _effect_map[slot] = item_id;
					}
				}

				for (let j:number = _view_type_min; j <= _view_type_max; j++) {
					if (j == game.EView.head_frame || j == game.EView.desktop || j == game.EView.mjp || j == game.EView.lobby_bg || j == game.EView.mingpai_zhishi) continue;
					let id:number = game.GameUtility.get_view_default_item_id(j);
					if (_effect_map[j]) id = _effect_map[j];
					if (j == game.EView.lizhi_bgm) {
						let d_item = cfg.item_definition.item.get(id);
						if (d_item) {
							let liqi_bgm = d_item.sargs[0];
							if (liqi_bgm) bgm_map[`audio/${liqi_bgm}`] = 1;
						}
					} else {
						let d_view = cfg.item_definition.view.get(id);
						if (d_view) {
							if (j == game.EView.liqibang) {
								model_map[`scene/${d_view.res_name}.lh`] = 1;
							} else if (j == game.EView.hand_model) { 
								if (d_view.hand_version == 2) {
									for (let k = 1; k <= 4; k++) {
										model_map[`scene/${d_view.res_name}_${k}.lh`] = 1;
									}
								} else {
									model_map[`scene/${d_view.res_name}.lh`] = 1;
								}
							} else if (j == game.EView.hupai_effect ) {
								effect_map[`scene/${d_view.res_name}.lh`] = 1;
								const outfitConfig = cfg.outfit_config.ron.get(id);
								const isOldRon = (d_view.old_effect_mark && d_view.old_effect_mark == 1);
								if (outfitConfig && outfitConfig.is_fullscreen == 1 && !isOldRon) {
									fullscreen_effect_map[`scene/${d_view.res_name}_fullscreen.lh`] = 1;
								}
							} else if (j == game.EView.lizhi_effect) { 
								//立直特效有四个方向的情况
								if (d_view.seat_related && d_view.seat_related == 1) {
									for (let k = 0; k < 4; k++) {
										effect_map[`scene/${d_view.res_name}${k}.lh`] = 1;
									}
									
								} else {
									effect_map[`scene/${d_view.res_name}.lh`] = 1;
								}
								
							}
							if (d_view.audio_id) {
								let d_audio = cfg.audio.audio.get(d_view.audio_id);
								if (d_audio) {
									bgm_map[d_audio.path + view.AudioMgr.suffix] = 1;
								}
							}
						} else {
							switch(j) {
								case game.EView.liqibang: model_map['scene/liqi_default.lh'] = 1; break;
								case game.EView.hand_model: model_map['scene/hand_human.lh'] = 1; break;
								case game.EView.hupai_effect: effect_map['scene/effect_hupai_default.lh'] = 1;
								  							  bgm_map['audio/audio_mj/hupai' + view.AudioMgr.suffix] = 1;
															  break;
							}
						}
					}
				}

				if (_effect_map[game.EView.hupai_effect] == 305029) {
					// 烟花胡牌中间爆炸那个
					effect_map['scene/effect_hupai_yanhua_bang.lh'] = 1;
				}
				if (_effect_map[game.EView.hupai_effect] == 305215) {
					// 11
					skin_imgs['extendRes/charactor/xiyuansiyiyu_0/full.png'] = 1;
				}
				if (_effect_map[game.EView.hupai_effect] == 305217) {
					// 22chunjie
					effect_map['scene/ron_22chunjie_hongdi.lh'] = 1;
				}
				if (_effect_map[game.EView.lizhi_effect] == 305317) {
					// 22chunjie
					effect_map['scene/effect_liqi_22chunjie_hongdi.lh'] = 1;
				}
				let chara_skin_id:number = d_character['skin'];
				let d_skin = cfg.item_definition.skin.get(chara_skin_id);
				skin_imgs[(d_skin.path + '/full.png')] = 1;
				// skin_imgs[(d_skin.path + '/half.png')] = 1;
				if (d_skin.no_reverse) {
					skin_imgs[(d_skin.path + '/reverse/full.png')] = 1;
					// skin_imgs[(d_skin.path + '/reverse/half.png')] = 1;
				}
				let cutin_data = cfg.character.cutin.get(chara_skin_id);
				if (cutin_data) {
					if (cutin_data.type != 1) {
						let atlas_root = 'res/atlas/';
						cutin_map[(atlas_root + game.Tools.localUISrc('myres/extraCutin/' + cutin_data.atlas) + '.atlas')] = 1;
					}
					effect_map['scene/' + cutin_data.effect + '.ls'] = 1;
				}
				effect_map['scene/hucutin.ls'] = 1;
				if (view.DesktopMgr.is_yuren_type(true)) {
					for (var j = 0; j < 10; j++) {
						// 加载愚人节资源
						skin_imgs[("extendRes/charactor/yurenjie/img_" + j + '.png')] = 1;
					}
				}

				//======== 特效表情加载 ==========
				if (d_character['extra_emoji']) {
					let emojis = d_character['extra_emoji'];
					let d_emoji_table = cfg.character.emoji.getGroup(d_character['charid']);
					for (let i:number = 0; i < emojis.length; i++) {
						for (let j:number = 0; j < d_emoji_table.length; j++) {
							if (d_emoji_table[j].sub_id == emojis[i]) {
								let d = d_emoji_table[j];
								if (d.type == 2) { // 是特效
									ui_effect_map[`scene/${d.view}.lh`] = 1;
								}
							}
						}
					}
				}
			}
			this._fullscreen_effect_list = [];
			for (let k in fullscreen_effect_map) {
				this._fullscreen_effect_list.push(k);
			}
			
			this._effect_list = [];
			for (let k in effect_map) {
				this._effect_list.push(k);
			}
			this._model_list = [];
			for (let k in model_map) {
				this._model_list.push(k);
				EffectMgr.add_3d_resource(k);
			}
			let _skin_list:Array<string> = [];
			for (let k in skin_imgs) {
				_skin_list.push(k);
			}

			
			// ui_effect_map['scene/effect_yuebing_white.lh'] = 1;
			// ui_effect_map['scene/effect_guoqingmiao.lh'] = 1;
			this._ui_effect_list = [];
			for (let i:number = 0; i < Scene_MJ.ui_effect_list.length; i++) {
				this._ui_effect_list.push(Scene_MJ.ui_effect_list[i]);
			}
			for (let k in ui_effect_map) {
				this._ui_effect_list.push(k);
			}
			// 判定如果是王座间，预热魂天特效
			if (config && config['meta']) {
				let mode_id = config['meta']['mode_id'];
				if ((mode_id == 15 || mode_id == 16 || mode_id == 25 || mode_id == 26)) {
					for (let i = 1; i < 5; i++) {
						this._ui_effect_list.push('scene/effect_huntian_lv_' + i + '.lh');
					}
				}
			}
			
			this._atlas_list = [];
			for (let k in cutin_map) {
				this._atlas_list.push(k);
			}
			this._ui_img_list = [];
			if (config && config['mode'] && config['mode']['detail_rule'] && config['mode']['detail_rule']['field_spell_mode']) {
				let field_spell_var = config['mode']['detail_rule']['field_spell_mode'];
				let index = 0;
                while (field_spell_var > 0 || index < 3) {

                    this._ui_img_list.push(game.Tools.localUISrc('myres2/fieldspell/big_' + uiscript.UI_FieldSpell.card_modes[index] + (field_spell_var % 100) + '.png'));
                    field_spell_var = Math.floor(field_spell_var / 100);

                    index++;
                }
                for (let i = 0; i < 3; i++) {
                    this._ui_img_list.push(game.Tools.localUISrc('myres2/fieldspell/big_' + uiscript.UI_FieldSpell.card_modes[i] + '0.png'));
                }
			}
			progress.runWith(0);
		

			game.LoadMgr.loadResImage(_skin_list, Laya.Handler.create(this, ()=>{
				Laya.loader.create(this._model_list, Laya.Handler.create(this, ()=>{
					let start_percent = this._atlas_list.length > 0 ? 0.35 : 0.3;
					let _handler = Laya.Handler.create(this, ()=>{
						if (this._ui_img_list.length > 0) {
							Laya.loader.load(this._ui_img_list);//随缘加载
						}
						let time = Laya.timer.currTimer;
						EffectMgr.preheat_3d_effect(this._effect_list, this.desktop, false, Laya.Handler.create(this, ()=>{
							GameMgr.Inst.postNewInfo2Server('match_effect_loaded', {preheat_time: Laya.timer.currTimer - time});
							EffectMgr.preheat_3d_effect(this._fullscreen_effect_list, this.scene_effect_fullscreen, true, Laya.Handler.create(this, ()=>{
								EffectMgr.preheat_3d_effect(this._ui_effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, ()=>{
									Laya.timer.frameOnce(5, this, ()=>{
										complete.run();
										for (let k in bgm_map) {
											Laya.loader.load(k); //各种音乐随缘下载
										}
									});
								}), Laya.Handler.create(this, p => progress.runWith(0.75 + 0.25 * p), null, false));
							}), Laya.Handler.create(this, p => progress.runWith(0.65 + 0.1 * p), null, false));
						}), Laya.Handler.create(this, p => progress.runWith(start_percent + (0.65 - start_percent) * p), null, false));
					});
					
					if (this._atlas_list.length > 0) {
						Laya.loader.create(this._atlas_list, _handler);
					} else {
						_handler.run();
					}
					
				}), Laya.Handler.create(this, p=> progress.runWith(0.2 + 0.1 * p), null, false));
			}), Laya.Handler.create(this, p => progress.runWith(0.2 * p), null, false));
		}

		//加载对局使用的ui牌面（.atlas）
		private _load_my_mjpm_view(config: game.IGameConfig, complete?: Laya.Handler, progress?: Laya.Handler) {
			if(!config || !config.mode || !config.mode.detail_rule) {
				complete && complete.run();
				progress && progress.runWith(1);
				return;
			}
			let lst = [];
			// notUseCustomMJP 只能使用默认牌面不能使用自定义牌面的特殊模式
			let notUseCustomMJP = !!config.mode.detail_rule.jiuchao_mode;
			if (notUseCustomMJP) {
				let new_surface_view: string = 'mjpface_default';
				let item_surface_id: number = game.GameUtility.get_view_default_item_id(game.EView.mjp_surface);
				let d_surface_view = cfg.item_definition.view.get(item_surface_id);
				if (d_surface_view) new_surface_view = d_surface_view.res_name;
				if (view.DesktopMgr.en_mjp) {
					new_surface_view += '_0';
				}
				//如果正在使用的就是这个默认的就不用加载了
				if (GameMgr.Inst.mjp_surface_view != new_surface_view) {
					let atlas_path = 'res/atlas/';
					if (GameMgr.client_language != 'chs') atlas_path += GameMgr.client_language + '/';
					this.mjp_default_surface_view = new_surface_view;
					lst.push(atlas_path + 'myres2/mjpm/' + new_surface_view + '/ui.atlas');
				}
			}
			if (lst.length == 0) {
				complete && complete.run();
				progress && progress.runWith(1);
				return;
			}
			Laya.loader.create(lst, complete, progress);
		}

		//清理掉对局中使用的牌面
		private _unload_my_mjpm_view() {
			//如果装扮的就是这个默认的就不用卸载了
			if (this.mjp_default_surface_view == GameMgr.Inst.mjp_surface_view) {
				this.mjp_default_surface_view = '';
				return;
			}
			let atlas_path = 'res/atlas/';
			if (GameMgr.client_language != 'chs') atlas_path += GameMgr.client_language + '/';
			if (this.mjp_default_surface_view != '') {
				Laya.loader.clearRes(atlas_path + 'myres2/mjpm/' + this.mjp_default_surface_view + '/ui.atlas');
				this.mjp_default_surface_view = '';
			}
		}

		// 当退出时候清除资源
		private _on_quit() {
			if (uiscript.UI_DesktopInfo.Inst) {
				uiscript.UI_DesktopInfo.Inst.onCloseRoom();
			}
			uiscript.UI_FightBegin.hide();
			if (uiscript.UI_Win.Inst) {
				uiscript.UI_Win.Inst.enable = false;
			}
			if (uiscript.UI_ScoreChange.Inst) {
				uiscript.UI_ScoreChange.Inst.enable = false;
			}
			if (uiscript.UI_FieldSpell.Inst) {
				uiscript.UI_FieldSpell.Inst.enable = false;
			}
			if (!view.DesktopMgr.Inst || !view.DesktopMgr.Inst.active) return;
			view.DesktopMgr.Inst.Clear();
			if (this._desktop_model) {
				this._desktop_model.destroy(true);
				this._desktop_model = null;
			}
			
			if (this._desktop_model_path) {
				let res = Laya.loader.getRes(this._desktop_model_path);
				if (res) res.destroy(true);
				EffectMgr.remove_3d_resource(this._desktop_model_path);
				this._desktop_model_path = '';
			}
			
			if (uiscript.UI_Desktop_Yindao_Mode.Inst) {
				uiscript.UI_Desktop_Yindao_Mode.Inst.enable = false;
			}
			for (let i:number = 0; i < this._model_list.length; i++) {
				let src:string = this._model_list[i]['url'];
				
				let res = Laya.loader.getRes(src);
				if (res) res.destroy(true);
				EffectMgr.remove_3d_resource(src);
			}

			for (let i:number = 0; i < this._atlas_list.length; i++) {
				Laya.loader.clearTextureRes(this._atlas_list[i]['url']);
			}

			for (let i:number = 0; i < this._ui_img_list.length; i++) {
				if(this._ui_img_list[i]['url']) {
					Laya.loader.clearTextureRes(this._ui_img_list[i]['url']);
				} else {
					Laya.loader.clearTextureRes(this._ui_img_list[i]);
				}
				
			}

			this.clearTexture_commont_texture2d();
			for (let i:number = 0; i < this._mjp_textures.length; i++) {
				let res = Laya.loader.getRes(this._mjp_textures[i]['url']);
				if (res) {
					res.dispose();
				}
			}

			this._unload_my_mjpm_view();
		}

		public GameEnd() {
			app.Log.log('Scene_MJ GameEnd');
			this._on_quit();
			MJNetMgr.Inst.Close();
			GameMgr.Inst.ingame = false;
			if (GameMgr.Inst.in_kuangdu) {
				GameMgr.Inst.showKuangdu();
				GameMgr.Inst.in_kuangdu = false;
			} else if (GameMgr.Inst.in_saki) {
				GameMgr.Inst.showSaki();
				GameMgr.Inst.in_saki = false;
			} else if (GameMgr.Inst.in_huiye) {
				GameMgr.Inst.showHuiye();
				GameMgr.Inst.in_huiye = false;
			} else if (GameMgr.Inst.in_activity) {
				GameMgr.Inst.enterActivityScene();
				GameMgr.Inst.in_activity = false;
			} else {
				GameMgr.Inst.EnterLobby();
			}
			
		}

		public ForceOut() {
			app.Log.log('Scene_MJ ForceOut');
			this._on_quit();
			MJNetMgr.Inst.Close();
			GameMgr.Inst.ingame = false;
			GameMgr.Inst.EnterLobby();
		}


		public AnotherGame() {
			app.Log.log('Scene_MJ AnotherRound');
			GameMgr.Inst.ingame = false;
			this._on_quit();
			GameMgr.Inst.QuitMJ();
		}
		// ==DevDebug Start==
		public preloadEffects(items: number[], complete: Laya.Handler, progress: Laya.Handler) {
			let effect_map: Object = {};
			let fullscreen_effect_map: Object = {};
			for (let index = 0; index < items.length; index++) {
				let item_id = items[index];
				let item = cfg.item_definition.item.get(item_id);
				let d_view = cfg.item_definition.view.get(item_id);
				if (d_view) { 
					if (item.type == 2) {
						if (d_view.seat_related && d_view.seat_related == 1) {
							for (let k = 0; k < 4; k++) {
								effect_map[`scene/${d_view.res_name}${k}.lh`] = 1;
							}

						} else {
							effect_map[`scene/${d_view.res_name}.lh`] = 1;
						}
					} else if (item.type == 1 && item.id != 305215) {
						//和牌特效
						effect_map[`scene/${d_view.res_name}.lh`] = 1;
						const outfitConfig = cfg.outfit_config.ron.get(d_view.id);
						const isOldRon = (d_view.old_effect_mark && d_view.old_effect_mark == 1);
						if (outfitConfig && outfitConfig.is_fullscreen == 1 && !isOldRon) {
							fullscreen_effect_map[`scene/${d_view.res_name}_fullscreen.lh`] = 1;
						}
					}
				}
			}

			if (effect_map[game.EView.hupai_effect] == 305029) {
				// 烟花胡牌中间爆炸那个
				effect_map['scene/effect_hupai_yanhua_bang.lh'] = 1;
			}
			if (effect_map[game.EView.hupai_effect] == 305217) {
				// 22chunjie
				effect_map['scene/ron_22chunjie_hongdi.lh'] = 1;
			}
			if (effect_map[game.EView.lizhi_effect] == 305317) {
				// 22chunjie
				effect_map['scene/effect_liqi_22chunjie_hongdi.lh'] = 1;
			}
			let fullscreen_effect_list = [];
			for (let k in fullscreen_effect_map) {
				fullscreen_effect_list.push(k);
			}

			let effect_list = [];
			for (let k in effect_map) {
				effect_list.push(k);
			}
			EffectMgr.preheat_3d_effect(fullscreen_effect_list, this.scene_effect_fullscreen, true, Laya.Handler.create(this, () => {
				EffectMgr.preheat_3d_effect(effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, () => {
					Laya.timer.frameOnce(5, this, () => {
						complete.run();
					});
				}), Laya.Handler.create(this, p => progress?.runWith(0.75 + 0.25 * p), null, false));
			}), Laya.Handler.create(this, p => progress?.runWith(0.65 + 0.1 * p), null, false));
		}
		// ==DevDebug End==

		
	}
}