/**
* name 
*/
module game {
    export class Scene_Saki extends Scene_Activity_Base {

        public static Inst: Scene_Saki = null;

        public constructor() {
            super();
            this.init();
            Scene_Saki.Inst = this;
            // this._bglst.push(game.Tools.localUISrc('myres/activity_saki/bg_spot.png'));
            // this._bglst.push(game.Tools.localUISrc('myres/activity_saki/bg_match.png'));
            // this._bglst.push(game.Tools.localUISrc('myres/activity_saki/bg_task.png'));
            // this._bglst.push(game.Tools.localUISrc('myres/activity_saki/bg_reward.png'));
        }

        public openFuncName: string = 'openSakiUI';
        public disposeResName: string = 'saki';

        protected onEnable() {
            super.onEnable();
            uiscript.UI_Invite.Inst.enable = true;
        }

    }
}