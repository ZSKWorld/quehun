/**
* name 
*/
module game {
    export class Scene_Simulation extends SceneBase {
        public static Inst: Scene_Simulation = null;
        private readonly ui_effect_list: Array<string> = [
            'scene/effect_simulation_logo.lh',
            'scene/effect_simulation_success_big.lh',
            'scene/effect_simulation_train_result.lh',
            'scene/effect_simulation_match_start_front2.lh',
        ];

        private readonly _scene_effect_list: Array<string> = [
            'scene/effect_simulation_bg.ls',
            'scene/effect_simulation_event.ls',
        ];
        private bgLst: Array<string> = [];

        public constructor() {
            super();
            Scene_Simulation.Inst = this;
            this.bgLst = [];
            this.bgLst.push(game.Tools.localUISrc('myres/activity_simulation/background_practice_web.jpg'));
        }

        public init(data: any) {
        }

        protected onEnable() {
            uiscript.UI_Invite.Inst.enable = true;
            uiscript.UIMgr.Inst.onSceneActivity_Enable();
        }

        protected onDisable() {
            uiscript.UI_Activity_HF_Rules.Inst.enable = false;
            uiscript.UIMgr.Inst.onSceneActivity_Disable();
            game.LoadMgr.disposeSceneRes('amulet');
            this.clear();
        }

        public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
            if (game.Scene_Lobby.Inst && game.Scene_Lobby.Inst.active) game.Scene_Lobby.Inst.active = false;
            uiscript.UIMgr.Inst.openSimulationUI(Laya.Handler.create(this, () => {
                Laya.loader.load(this.bgLst, Laya.Handler.create(this, () => {
                    progress.runWith(0.5);
                    for (let i = 0; i < this._scene_effect_list.length; i++) {
                        EffectMgr.add_3d_resource(this._scene_effect_list[i]); // 加入effectmgr的资源管理
                    }
                    Laya.loader.create(this._scene_effect_list, Laya.Handler.create(this, () => {
                        progress.runWith(0.8);
                        EffectMgr.preheat_3d_effect(this.ui_effect_list, FrontEffect.Inst.scene_ui_effect, true, Laya.Handler.create(this, () => {
                            Laya.timer.frameOnce(5, this, () => {
                                uiscript.UI_Activity_HF_Main.Inst.initEffect();
                                progress.runWith(1);
                                complete.run();
                            });
                        }), Laya.Handler.create(this, p => progress.runWith(0.8 + 0.2 * p), null, false));
                    }), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.3 * p), null, false));
                }), Laya.Handler.create(this, p => progress.runWith(0.3 + 0.2 * p), null, false));
            }, null, false), Laya.Handler.create(this, p => progress.runWith(p * 0.3), null, false));
        }

        // 当退出时候清除资源
        private clear() {
            uiscript.UI_Activity_HF_Main.Inst.destroyEffect();
            if (uiscript.UI_Activity_HF_Main.Inst.enable) uiscript.UI_Activity_HF_Main.Inst.enable = false;
            for (let i = 0; i < this._scene_effect_list.length; i++) {
                EffectMgr.remove_3d_resource(this._scene_effect_list[i]);
                game.EffectMgr.force_dispose_3d_res(this._scene_effect_list[i]);
            }
        }

    }
}