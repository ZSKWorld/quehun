/**
* name 
*/
module game {
	enum EShaderPropertieType { number, color, texture };
	enum EEffectType { blurLight = 400, blueHeavy = 401 }; // 特殊类型
	interface IMaterialData {
		name: string, shaderName: string, defaultProperties: Array<{
			name: string,
			value: string,
			type: EShaderPropertieType
		}>, defines?: Array<string>
	}
	class BgMaterialController {
		public static Inst: BgMaterialController;
		private spotMaterialData: Array<IMaterialData>; // 使用名称的材质球
		private spotSpecialMaterialData: { [key: number]: IMaterialData } = {}; // 特殊的根据类型限制的材质球

		public interpolationID: string = '_Interpolation'; // 淡入淡出属性名

		constructor() {
			BgMaterialController.Inst = this;
			this.initMaterialData();
		}

		private initMaterialData() {
			this.spotMaterialData = [];
			// 老照片
			this.spotMaterialData.push({
				name: 'OldPhoto', shaderName: 'TextureBlend', defaultProperties: [{
					name: "_BlendTex",
					value: "OldPhotoMask.png",
					type: EShaderPropertieType.texture
				}, {
					name: "_Interpolation",
					value: "1",
					type: EShaderPropertieType.number
				}], defines: ["BLENDMODE_SCREEN"]
			});
			this.spotMaterialData.push({
				name: 'TextureBlend', shaderName: 'TextureBlend', defaultProperties: [{
					name: "_Interpolation",
					value: "1",
					type: EShaderPropertieType.number
				}]
			});
			this.spotMaterialData.push({ name: 'ColorOverlay', shaderName: 'ColorOverlay', defaultProperties: [] });
			this.spotMaterialData.push({
				name: 'ColorAdjustment', shaderName: 'ColorAdjustment', defaultProperties: [{
					name: "_Brightness",
					value: "1.23",
					type: EShaderPropertieType.number
				}, {
					name: "_Contrast",
					value: "1",
					type: EShaderPropertieType.number
				}]
			});
			this.spotMaterialData.push({
				name: 'Gau', shaderName: 'GaussianBlur', defaultProperties: [{
					name: "_Spread",
					value: "1",
					type: EShaderPropertieType.number
				}, {
					name: "_Sigma",
					value: "5",
					type: EShaderPropertieType.number
				}]
			});

			this.spotSpecialMaterialData[EEffectType.blueHeavy] = {
				name: 'Gau', shaderName: 'GaussianBlur', defaultProperties: [{
					name: "_Spread",
					value: "1.2",
					type: EShaderPropertieType.number
				}, {
					name: "_Sigma",
					value: "8",
					type: EShaderPropertieType.number
				}]
			};
			this.spotSpecialMaterialData[EEffectType.blurLight] = {
				name: 'Gau', shaderName: 'GaussianBlur', defaultProperties: [{
					name: "_Spread",
					value: "1",
					type: EShaderPropertieType.number
				}, {
					name: "_Sigma",
					value: "5",
					type: EShaderPropertieType.number
				}]
			};
			this.spotMaterialData.push({ name: 'PushPullTransition', shaderName: 'PushPullTransition', defaultProperties: [] });
			this.spotMaterialData.push({
				name: 'PushPullTransition', shaderName: 'PushPullTransition', defaultProperties: [{
					name: "_Interpolation",
					value: "0",
					type: EShaderPropertieType.number
				}, {
					name: "_Direction",
					value: "0",
					type: EShaderPropertieType.number
				}]
			});
		}
		public getMaterial(config: uiscript.IEffectConfig, path: string): { mat: caps.BaseMaterial, shaderName: string } {
			if (this.spotSpecialMaterialData[config.type]) {
				return this.createMaterialByData(this.spotSpecialMaterialData[config.type], path, config);
			}
			for (let data of this.spotMaterialData) {
				if (data.name == config.materialName) {
					return this.createMaterialByData(data, path, config);
				}
			}
		}

		// 创建材质球
		private createMaterialByData(data: IMaterialData, path: string, config?: uiscript.IEffectConfig): { mat: caps.BaseMaterial, shaderName: string } {
			let name = data.shaderName;
			let mat: caps.BaseMaterial = new caps.BaseMaterial(caps[name].filename);
			if (data.defaultProperties) {
				for (let property of data.defaultProperties) {
					if (property.type == EShaderPropertieType.number) {
						mat.setNumber(caps[name][property.name], Number(property.value));
					} else if (property.type == EShaderPropertieType.color) {
						mat.setColor(caps[name][property.name], game.Tools.HexToColor(property.value));
					} else if (property.type == EShaderPropertieType.texture) {
						let _tex = Laya.loader.getRes('scene/Assets/Resource/lobby/' + property.value);
						mat.setTexture(caps[name][property.name], _tex);
					}
				}
			}
			if (data.defines) {
				for (let define of data.defines) {
					mat.addShaderDefine(name, define);

				}
			}
			if (config.properties) {
				for (let property of config.properties) {
					if (property.type == EShaderPropertieType.number) {
						mat.setNumber(caps[name][property.name], Number(property.value));
					} else if (property.type == EShaderPropertieType.color) {
						mat.setColor(caps[name][property.name], game.Tools.HexToColor(property.value));
					} else if (property.type == EShaderPropertieType.texture) {
						let _tex = Laya.loader.getRes('scene/Assets/Resource/lobby/' + property.value);
						mat.setTexture(caps[name][property.name], _tex);
					}
				}
			}

			mat.setTexture(caps[name]['TEXTURE'], Laya.loader.getRes(path));
			return { mat, shaderName: name };
		}
	}

	export interface IMoveAnim {
		startTime: number, 
		duration: number, 
		from: Laya.Vector3, 
		to: Laya.Vector3
	}
	export class Scene_Spot extends SceneBase {

		public static Inst: Scene_Spot = null;
		// 剧情场景和大厅完全拆开，使用的背景材质球也进行区分
		private readonly scene_path: string = 'scene/spot.ls';
		public readonly scene_effect_path: string = 'scene/scene_spot_effect.ls';
		public readonly scene_effect_path_front: string = 'scene/scene_spot_effect_front.ls';
		private scene_container: Laya.Sprite = null;
		private scene: Laya.Scene = null;
		private root_bg: Laya.Sprite3D = null;
		private root_origin_pos: Laya.Vector3;
		private container_effects: Laya.Sprite3D = null;
		private bg_front_plane: Laya.MeshSprite3D = null;
		private bg_front_mat: Laya.BlinnPhongMaterial = null;
		private bg_back_plane: Laya.MeshSprite3D = null;
		private bg_back_mat: Laya.BlinnPhongMaterial = null;
		private bg_first_plane: Laya.MeshSprite3D = null; // 用于交互帧的背景
		private bg_first_mat: Laya.BlinnPhongMaterial = null; // 
		private _current_bg: string = '';
		private _during_shake: boolean = false;
		private _shake_pos_list: Array<Laya.Vector3> = [];
		private _shake_start_time: number = 0;
		private _materialController: BgMaterialController;
		private _bgShaderName: string; // 特殊shader球名
		private _duringFade: boolean;
		private _fadeInfo: { startTime: number, duration: number, from: number, to: number };
		private _during_scale: boolean = false;
		private _scaleInfo: { startTime: number, duration: number, from: number, to: number };
		private _during_move: boolean = false;
		private _moveInfoList: IMoveAnim[] = [];
		private _curMove:IMoveAnim = null;

		public get current_bg(): string { return this._current_bg; }

		public constructor() {
			super();
			Scene_Spot.Inst = this;
		}

		public init() {

		}

		private firstInit(complete: Laya.Handler, progress: Laya.Handler) {
			if (this._load_state == E_LoadState.loaded) {
				progress.runWith(1);
				complete.run();
				return;
			}
			this._materialController = new BgMaterialController();
			this._load_state = E_LoadState.loading;
			uiscript.UIMgr.Inst.openSpotUI(Laya.Handler.create(this, () => {
				Laya.timer.frameOnce(5, this, () => {
					//ui初始化化后放入ui特效场景
					uiscript.UI_Spot.Inst.initUIEffectScene();
					GameMgr.Inst.addScene(this.scene_container = new Laya.Sprite());
					this.scene_container.visible = false;
					this._load_state = E_LoadState.loaded;
					progress.runWith(1);
					complete.run();
				});
			}), Laya.Handler.create(this, p => progress.runWith(p), null, false));
		}

		public buildScene(complete: Laya.Handler, progress: Laya.Handler) {
			if (this.scene) {
				progress.runWith(1);
				complete.run();
				return;
			}
			progress.runWith(0);
			this.firstInit(Laya.Handler.create(this, () => {
				Laya.loader.create(this.scene_path, Laya.Handler.create(this, () => {
					this.scene = Laya.loader.getRes(this.scene_path);
					this.scene_container.addChild(this.scene);
					this.container_effects = this.scene.getChildByName('effects') as Laya.Sprite3D;
					this.root_bg = this.scene.getChildByName('root') as Laya.MeshSprite3D;
					this.root_origin_pos = this.root_bg.transform.localPosition.clone();
					this.bg_front_plane = this.root_bg.getChildByName('bg_front') as Laya.MeshSprite3D;
					this.bg_front_mat = this.bg_front_plane.meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
					this.bg_back_plane = this.root_bg.getChildByName('bg_back') as Laya.MeshSprite3D;
					this.bg_back_mat = this.bg_back_plane.meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
					this.bg_front_plane.active = false;

					this.bg_first_plane = this.root_bg.getChildByName('bg_first') as Laya.MeshSprite3D;
					this.bg_first_mat = this.bg_first_plane.meshRender.sharedMaterial as Laya.BlinnPhongMaterial;
					this.bg_first_plane.active = false;
					progress.runWith(0.9);
					Laya.timer.frameOnce(8, this, () => {
						this.scene.visible = true;
						progress.runWith(1);
						complete.run();
					});
				}), Laya.Handler.create(this, p => progress.runWith(0.5 + 0.4 * p), null, false));
			}), Laya.Handler.create(this, p => progress.runWith(p * 0.5), null, false));

		}

		protected onEnable() {
			this.scene_container.visible = true;
			uiscript.UIMgr.Inst.onSceneSpot_Enable();
			if (this.scene) this.scene.visible = true;
			// view.BgmListMgr.PlayLobbyBgm();

			Laya.timer.frameLoop(1, this, this._update, null, true);
		}

		protected onDisable() {
			this.scene_container.visible = false;
			this.clear();
		}

		public clear() {
			Laya.AtlasResourceManager.instance.freeAll();
			uiscript.UIMgr.Inst.onSceneSpot_Disable();
			game.LoadMgr.disposeSceneRes('spot');

			this.scene.visible = false;
			this._current_bg = '';
			this.bg_back_mat = null;
			this.bg_back_plane = null;
			this.bg_front_mat = null;
			this.bg_front_plane = null;
			this.scene.destroy(true);
			this.scene = null;

			game.EffectMgr.force_dispose_3d_res(this.scene_path);
			Laya.timer.clearAll(this);
		}

		private _update() {
			if (this._during_shake) {
				let t: number = Laya.timer.currTimer - this._shake_start_time;
				let index: number = Math.floor(t / 50);
				if (index >= 0 && index < this._shake_pos_list.length - 1) {
					let rate: number = (t - index * 50) / 50;
					let pos: Laya.Vector3 = new Laya.Vector3(0, 0, 0);
					pos.x = this._shake_pos_list[index].x * (1 - rate) + this._shake_pos_list[index + 1].x * rate;
					pos.y = this._shake_pos_list[index].y * (1 - rate) + this._shake_pos_list[index + 1].y * rate;
					pos.z = this._shake_pos_list[index].z * (1 - rate) + this._shake_pos_list[index + 1].z * rate;
					this.root_bg.transform.localPosition = pos;
				} else {
					this._during_shake = false;
					this.root_bg.transform.localPosition = this.root_origin_pos.clone();
				}
			}

			if (this._duringFade && this._fadeInfo && this._bgShaderName) {
				if (caps[this._bgShaderName][this._materialController.interpolationID]) {
					let t: number = Laya.timer.currTimer - this._fadeInfo.startTime;
					if (t >= this._fadeInfo.duration) {
						this._duringFade = false;
						(this.bg_back_plane.meshRender.sharedMaterial as caps.BaseMaterial).setNumber(caps[this._bgShaderName][this._materialController.interpolationID], this._fadeInfo.to);
					} else {
						(this.bg_back_plane.meshRender.sharedMaterial as caps.BaseMaterial).setNumber(caps[this._bgShaderName][this._materialController.interpolationID], t / this._fadeInfo.duration * (this._fadeInfo.to - this._fadeInfo.from) + this._fadeInfo.from);
					}
				}
			}

			if (this._during_scale) {
				let t: number = Laya.timer.currTimer - this._scaleInfo.startTime;
				if (t >= this._scaleInfo.duration) {
					this._during_scale = false;
					uiscript.UI_Spot.Inst.RemoveLock("play_bg_scale_anim");
					this.root_bg.transform.localScale = new Laya.Vector3(this._scaleInfo.to, this._scaleInfo.to, this._scaleInfo.to);
				} else if (t > 0) {
					let scale: number = this._scaleInfo.from + (t / this._scaleInfo.duration) * (this._scaleInfo.to - this._scaleInfo.from);
					this.root_bg.transform.localScale = new Laya.Vector3(scale, scale, scale);
				}
			}

			if (this._during_move) {
				if (this._curMove != null) {
					let t: number = Laya.timer.currTimer - this._curMove.startTime;
					if (t >= this._curMove.duration) {
						this.root_bg.transform.localPosition = this._curMove.to;
						this._curMove = null;
					} else if (t > 0) {
						let dstX: number = this._curMove.from.x + (t / this._curMove.duration) * (this._curMove.to.x - this._curMove.from.x);
						let dstY: number = this._curMove.from.y + (t / this._curMove.duration) * (this._curMove.to.y - this._curMove.from.y);
						let dstZ: number = this._curMove.from.z + (t / this._curMove.duration) * (this._curMove.to.z - this._curMove.from.z);
						this.root_bg.transform.localPosition = new Laya.Vector3(dstX, dstY, dstZ);
						console.log(t);
					}
				} else {
					if (this._moveInfoList.length > 0) {
						this._curMove = this._moveInfoList.shift();
					} else {
						this._during_move = false;
						uiscript.UI_Spot.Inst.RemoveLock("play_bg_move_anim");
					}
				}
			}
		}

		public shake() {
			this._shake_pos_list = [];
			this._during_shake = true;
			this._shake_start_time = Laya.timer.currTimer;
			for (let i: number = 0; i <= 10; i++) {
				let pos: Laya.Vector3 = this.root_origin_pos.clone();
				if (i != 10) {
					pos.x += (Math.random() - 0.5) * 2 * 0.56;
					pos.y += (Math.random() - 0.5) * 2 * 0.56;
				}
				this._shake_pos_list.push(pos);
			}
		}

		public playCamereControl(data: any, delay: number) {
			let padding = this.get_scale_padding(data.padding);
			let dstPos: Laya.Vector3 = new Laya.Vector3(this.root_origin_pos.x + padding.x, this.root_origin_pos.y + padding.y, this.root_origin_pos.z);

			let scaleTime: number = data.reverseAnim ? delay + 1000 : delay;
			let moveTime: number = data.reverseAnim ? delay : delay + 500;
			let widthOffset: number = this.bg_front_plane.transform.localScale.x * 0.15;
			let heightOffset: number = this.bg_front_plane.transform.localScale.y * 0.15;

			if (data.scaleAnim == 0) {
				this.root_bg.transform.localScale = new Laya.Vector3(1.3, 1.3, 1.3);
				this.root_bg.transform.localPosition = dstPos;
			} else if (data.scaleAnim == 1) {
				this.root_bg.transform.localScale = Laya.Vector3.ONE.clone();
				this._scaleInfo = { from: 1, to: 1.3, duration: 500, startTime: Laya.timer.currTimer + scaleTime };
				this.root_bg.transform.localPosition = this.root_origin_pos.clone();
				this._moveInfoList.push( { from: this.root_origin_pos.clone(), to: dstPos, duration: 500, startTime: Laya.timer.currTimer + scaleTime });
			} else if (data.scaleAnim == 2) {
				this.root_bg.transform.localScale = new Laya.Vector3(1.3, 1.3, 1.3);
				this._scaleInfo = { from: 1.3, to: 1, duration: 500, startTime: Laya.timer.currTimer + scaleTime };
				this.root_bg.transform.localPosition = dstPos;
				this._moveInfoList.push({ from: dstPos, to: this.root_origin_pos.clone(), duration: 500, startTime: Laya.timer.currTimer + scaleTime });
			}


			let needMove = false;
			let movePos: Laya.Vector3;
			if (data.move == 1 && padding.y >= 0) {
				movePos = new Laya.Vector3(dstPos.x, dstPos.y - heightOffset, dstPos.z);
				needMove = true;
			} else if (data.move == 2 && padding.y <= 0) {
				movePos = new Laya.Vector3(dstPos.x, dstPos.y + heightOffset, dstPos.z);
				needMove = true;
			} else if (data.move == 3 && padding.x >= 0) {
				movePos = new Laya.Vector3(dstPos.x - widthOffset, dstPos.y, dstPos.z);
				needMove = true;
			} else if (data.move == 4 && padding.x <= 0) {
				movePos = new Laya.Vector3(dstPos.x + widthOffset, dstPos.y, dstPos.z);
				needMove = true;
			}

			if(needMove){
				if(data.reverseAnim){
					this._moveInfoList.unshift({ from: dstPos, to: movePos, duration: 1000, startTime: Laya.timer.currTimer + moveTime });
				}else{
					this._moveInfoList.push({ from: dstPos, to: movePos, duration: 1000, startTime: Laya.timer.currTimer + moveTime });
				}
			}


			if (data.scaleAnim) {
				this._during_scale = true;
				uiscript.UI_Spot.Inst.AddLock("play_bg_scale_anim");
			}
			if (needMove || data.scaleAnim > 0) {
				this._during_move = true;
				uiscript.UI_Spot.Inst.AddLock("play_bg_move_anim");
			}
		}

		private get_scale_padding(type: number) {
			let widthOffset: number = this.bg_front_plane.transform.localScale.x * 0.15;
			let heightOffset: number = this.bg_front_plane.transform.localScale.y * 0.15;
			switch (type) {
				case 0: return { x: 0, y: 0 };
				case 1: return { x: -widthOffset, y: -heightOffset };
				case 2: return { x: -widthOffset, y: 0 };
				case 3: return { x: -widthOffset, y: heightOffset };
				case 4: return { x: widthOffset, y: -heightOffset };
				case 5: return { x: widthOffset, y: 0 };
				case 6: return { x: widthOffset, y: heightOffset };
				case 7: return { x: 0, y: -heightOffset };
				case 8: return { x: 0, y: heightOffset };
			}
		}

		public resetCamereControl(){
			if(!this.root_bg || !this.root_bg.transform){
				return;
			}
			this.root_bg.transform.localScale = Laya.Vector3.ONE.clone();
			this.root_bg.transform.localPosition = this.root_origin_pos.clone();
		}

		// 实现除模糊外的背景特效
		public set_spot_bg(bg_img_url: string, config?: uiscript.IEffectConfig) {
			this._current_bg = '';
			let path: string = 'scene/Assets/Resource/lobby/' + bg_img_url;

			if (!Laya.loader.getRes(path)) {
				return;
			}
			this.bg_front_plane.active = false;
			this.bg_back_mat.albedoTexture = Laya.loader.getRes(path);
			this._bgShaderName = null;
			if (config && config.type > 0) {
				let matInfo = this._materialController.getMaterial(config, path);
				if (matInfo) {
					this.bg_back_plane.meshRender.sharedMaterial = matInfo.mat;
					this._bgShaderName = matInfo.shaderName;
					return;
				}
			}
			this.reset_effect_bg();

		}

		public set_spot_bg_mat(config: uiscript.IEffectConfig) {
			this._bgShaderName = null;

			let matInfo = this._materialController.getMaterial(config, this.bg_back_mat.albedoTexture.url);
			if (matInfo) {
				this.bg_back_plane.meshRender.sharedMaterial = matInfo.mat;
				this._bgShaderName = matInfo.shaderName;
				return;
			}
			this.reset_effect_bg();
		}

		public reset_effect_bg() {
			this.bg_back_plane.meshRender.sharedMaterial = this.bg_back_mat;
			this._duringFade = false;
			this._during_move = false;
			this._during_scale = false;
			this._fadeInfo = null;
			this._scaleInfo = null;
			this._moveInfoList = [];
			this._curMove = null;
			this._bgShaderName = null;
		}

		// 播放背景fade动画
		public playFadeAnim(from: number, to: number, duration: number) {
			if (this._bgShaderName) {
				(this.bg_back_plane.meshRender.sharedMaterial as caps.BaseMaterial).setNumber(caps[this._bgShaderName][this._materialController.interpolationID], from);
			}

			this._fadeInfo = { from, to, duration: duration * 1000, startTime: Laya.timer.currTimer };
			this._duringFade = true;
		}

		// 显示最上层背景
		public setFirstBg(bg_img_url: string) {
			let path: string = 'scene/Assets/Resource/lobby/' + bg_img_url;

			if (!Laya.loader.getRes(path)) {
				return;
			}
			this.bg_first_plane.active = true;
			this.bg_first_mat.albedoTexture = Laya.loader.getRes(path);
		}

		// 关闭最上层背景
		public clearFirstBg() {
			this.bg_first_plane.active = false
		}
	}
}