/**
* name 
*/
module view {
	export class ActionAnGangAddGang extends ActionBase {

		public static play(data: any) {
			app.Log.log('ActionAnGangAddGang play data:' + JSON.stringify(data));
			let seat: number = data['seat'];
			let localPosition: number = DesktopMgr.Inst.seat2LocalPosition(seat);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			if (data['type'] == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.players[localPosition].PlaySound('act_kan');
				Laya.timer.once(500, this, () => {
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					DesktopMgr.Inst.players[localPosition].AddGang(mjcore.MJPai.Create(data['tiles']));
					DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
				});
			} else {
				let ming: mjcore.MJMing = new mjcore.MJMing();
				ming.type = mjcore.E_Ming.gang_an;
				ming.from = [seat, seat, seat, seat];
				ming.pais = this.getAngangTile(data['tiles'], seat);
				let tile_state: Array<number> = [];
				for (let i: number = 0; i < ming.pais.length; i++) tile_state.push(-1);
				Laya.timer.once(500, this, () => {
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					DesktopMgr.Inst.players[localPosition].AddMing(ming, tile_state);
					DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
				});
				DesktopMgr.Inst.players[localPosition].PlaySound('act_kan');
			}
			if (data['operation']) {
				Laya.timer.once(600, this, () => {
					ActionOperation.play(data['operation']);
				});
			}
			if (data['zhenting'] != undefined) {
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, false);
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(seat, 'emoji_5', 2000);
			DesktopMgr.Inst.mainrole.revertAllPais();
		}

		public static fastplay(data: any, usetime: number) {
			app.Log.log('ActionAnGangAddGang fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			let seat: number = data['seat'];
			let localPosition = DesktopMgr.Inst.seat2LocalPosition(seat);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			if (data['type'] == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.players[localPosition].AddGang(mjcore.MJPai.Create(data['tiles']), false);
			} else {
				let ming: mjcore.MJMing = new mjcore.MJMing();
				ming.type = mjcore.E_Ming.gang_an;
				ming.from = [seat, seat, seat, seat];
				ming.pais = this.getAngangTile(data['tiles'], seat);
				let tile_state: Array<number> = [];
				for (let i: number = 0; i < ming.pais.length; i++) tile_state.push(-1);
				DesktopMgr.Inst.players[localPosition].AddMing(ming, tile_state, false);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(500, this, () => { ActionOperation.play(data['operation'], usetime); });
			}
			if (data['zhenting'] != undefined) {
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, true);
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionAnGangAddGang record data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			let seat: number = data['seat'];
			let localPosition: number = DesktopMgr.Inst.seat2LocalPosition(seat);
			if (data['type'] == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.players[localPosition].PlaySound('act_kan');
				Laya.timer.once(500, this, () => {
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					DesktopMgr.Inst.players[localPosition].AddGang(mjcore.MJPai.Create(data['tiles']));
					DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
				});
			} else {
				let ming: mjcore.MJMing = new mjcore.MJMing();
				ming.type = mjcore.E_Ming.gang_an;
				ming.from = [seat, seat, seat, seat];
				ming.pais = this.getAngangTile(data['tiles'], seat);
				let tile_state: Array<number> = [];
				for (let i: number = 0; i < ming.pais.length; i++) tile_state.push(-1);
				Laya.timer.once(500, this, () => {
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					DesktopMgr.Inst.players[localPosition].AddMing(ming, tile_state);
					DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
				});
				DesktopMgr.Inst.players[localPosition].PlaySound('act_kan');
			}
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(seat, 'emoji_5', 2000);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i: number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
			return 1700;
		}

		public static fastrecord(data: any, usetime = -1) {
			app.Log.log('ActionAnGangAddGang fastrecord data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			let seat: number = data['seat'];
			let localPosition: number = DesktopMgr.Inst.seat2LocalPosition(seat);
			if (data['type'] == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.players[localPosition].AddGang(mjcore.MJPai.Create(data['tiles']), false);
			} else {
				let ming: mjcore.MJMing = new mjcore.MJMing();
				ming.type = mjcore.E_Ming.gang_an;
				ming.from = [seat, seat, seat, seat];
				ming.pais = this.getAngangTile(data['tiles'], seat);
				let tile_state: Array<number> = [];
				for (let i: number = 0; i < ming.pais.length; i++) tile_state.push(-1);
				DesktopMgr.Inst.players[localPosition].AddMing(ming, tile_state, false);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operations']) {
					for (let i: number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
		}

		//23.2.20 添加seat 用于天命模式
		private static getAngangTile(tile: string, seat: number): Array<mjcore.MJPai> {
			let ret: Array<mjcore.MJPai> = [];
			if (!view.DesktopMgr.Inst.is_chuanma_mode() && !DesktopMgr.Inst.is_tianming_mode() && (tile.charAt(0) == '0' || tile.charAt(0) == '5') && tile.charAt(1) != 'z') {
				let dora_count: number = 1;
				if (view.DesktopMgr.Inst.game_config) {
					let _mode = view.DesktopMgr.Inst.game_config['mode'];
					if (_mode && _mode['extendinfo']) {
						// 牌谱中可能保留着extendinfo
						let extendinfo = JSON.parse(_mode['extendinfo']);
						if (extendinfo && extendinfo['dora_count'] != null) {
							switch (extendinfo['dora_count']) {
								case 0: dora_count = 0; break;
								case 2: dora_count = 1; break;
								case 3: dora_count = 1; break;
								case 4: dora_count = tile.charAt(1) == 'p' ? 2 : 1; break;
							}
						}
					}
					if (_mode && _mode['detail_rule']) {
						// let d = _mode['detail_rule'];
						if (_mode['detail_rule'] && _mode['detail_rule']['dora_count'] != null) {
							switch (_mode['detail_rule']['dora_count']) {
								case 0: dora_count = 0; break;
								case 2: dora_count = 1; break;
								case 3: dora_count = 1; break;
								case 4: dora_count = tile.charAt(1) == 'p' ? 2 : 1; break;
							}
						}
					}
				}
				for (let i: number = 0; i < 4; i++) {
					let _p: mjcore.MJPai = mjcore.MJPai.Create(tile);
					if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
						_p.touming = i != 3;
					}
					if (i == 0) _p.dora = false;
					else _p.dora = i <= dora_count;
					ret.push(_p);
				}
			} else if (DesktopMgr.Inst.is_tianming_mode()) {
				let localPosition: number = DesktopMgr.Inst.seat2LocalPosition(seat);
				let player:ViewPlayer = DesktopMgr.Inst.players[localPosition];
				let dora_count: number = 0;
				if ((tile.charAt(0) == '0' || tile.charAt(0) == '5') && tile.charAt(1) != 'z') {
					dora_count = 1;
					if (view.DesktopMgr.Inst.game_config) {
						let _mode = view.DesktopMgr.Inst.game_config['mode'];
						if (_mode && _mode['extendinfo']) {
							// 牌谱中可能保留着extendinfo
							let extendinfo = JSON.parse(_mode['extendinfo']);
							if (extendinfo && extendinfo['dora_count'] != null) {
								switch (extendinfo['dora_count']) {
									case 0: dora_count = 0; break;
									case 2: dora_count = 1; break;
									case 3: dora_count = 1; break;
									case 4: dora_count = tile.charAt(1) == 'p' ? 2 : 1; break;
								}
							}
						}
						if (_mode && _mode['detail_rule']) {
							// let d = _mode['detail_rule'];
							if (_mode['detail_rule'] && _mode['detail_rule']['dora_count'] != null) {
								switch (_mode['detail_rule']['dora_count']) {
									case 0: dora_count = 0; break;
									case 2: dora_count = 1; break;
									case 3: dora_count = 1; break;
									case 4: dora_count = tile.charAt(1) == 'p' ? 2 : 1; break;
								}
							}
						}
					}
				}

				let _p: mjcore.MJPai = mjcore.MJPai.Create(tile);
				let tianming_count: number = 0;
				let dora_tianming_count: number = 0;
				if (localPosition == 0) {
					for (let hand of (player as ViewPlayer_Me).hand) {
						if (hand.val.numValue() == _p.numValue() && hand.val.touming) {
							
							if (hand.val.dora) {
								dora_count--;
								dora_tianming_count++;
							} else {
								tianming_count++;
							}
						}
					}
				} else {
					for (let hand of (player as ViewPlayer_Other).hand) {
						if (hand.val.numValue() == _p.numValue() && hand.val.touming) {
							
							if (hand.val.dora) {
								dora_count--;
								dora_tianming_count++;
							} else {
								tianming_count++;
							}
						}
					}
				}
				for (let i: number = 0; i < 4; i++) {
					let _p: mjcore.MJPai = mjcore.MJPai.Create(tile);
					_p.dora = false;
					_p.touming = false;
					ret.push(_p);
				}
				let sortIndex: Array<number> = [1,2,0,3];
				for (let i:number = 0; i < Math.min(dora_tianming_count + tianming_count + dora_count, 4); i++) {
					if (i < dora_tianming_count) {
						ret[sortIndex[i]].dora = true;
						ret[sortIndex[i]].touming = true;
					} else if (i < dora_tianming_count + tianming_count) {
						ret[sortIndex[i]].touming = true;
					} else {
						ret[sortIndex[i]].dora = true;
					}
				}
			} else {
				for (let i: number = 0; i < 4; i++) {
					let _p: mjcore.MJPai = mjcore.MJPai.Create(tile);
					if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
						_p.touming = i != 3;
					}
					ret.push(_p);
				}
			}
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;

			return ret;
		}
	}
}