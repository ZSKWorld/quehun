/**
* name 
*/
module view{
	export class ActionBabei extends ActionBase{
		
		public static play(data:any): void {
			app.Log.log('ActionBabei play data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create('4z');

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddBabei(pai, data['moqie'], true);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_babei');
			let is_open:boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.onBabei(pai, is_open, false);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onBabei(data['moqie'], is_open, false);
			}
			if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, false);
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
		}

		public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionBabei fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create('4z');

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddBabei(pai, data['moqie'], false);
			let is_open:boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.onBabei(pai, is_open, true);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onBabei(data['moqie'], is_open, true);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation'], usetime);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, true);
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionBabei record data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create('4z');

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddBabei(pai, data['moqie'], true);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_babei');
			let is_open:boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.onBabei(pai, is_open, false);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordBabei(pai, data['moqie'], is_open, false);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
			DesktopMgr.Inst.onTileChange();
			return 1000;
		}

		public static fastrecord(data: any, usetime:number = -1) {
			app.Log.log('ActionBabei fastrecord data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create('4z');

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddBabei(pai, data['moqie'], false);
			let is_open:boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.onBabei(pai, is_open, true);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordBabei(pai, data['moqie'], is_open, true);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
			DesktopMgr.Inst.onTileChange();
			DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
		}

	}
}