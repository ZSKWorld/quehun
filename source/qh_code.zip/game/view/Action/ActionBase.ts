/**
* name 
*/
module view{
	export class ActionBase {
		
		public static play(data:any): void {}
		public static fastplay(data:any, usetime:number): void {}
		public static record(data: any, usetime:number = 0): number { return 0 }
		public static fastrecord(data: any, usetime:number = -1): void  {}

		public static get desktopMgr(): DesktopMgr {
			return DesktopMgr.Inst;
		}
	}
}