/**
* name 
*/
module view {
	export class ActionChangeTile extends ActionBase{

		public static play(data: game.IActionChangeTile): void {
			app.Log.log('ActionChangeTile play data:' + JSON.stringify(data));
			for (let i:number = 0; i < DesktopMgr.Inst.players.length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[i];
				let pais:Array<mjcore.MJPai> = [];
				if (i == 0) {
					(p as ViewPlayer_Me).onHuanSanZhang_Remove(data['out_tiles'], data['out_tile_states'], false);
					for (let j:number = 0; j < 3; j++) pais.push(mjcore.MJPai.Create(data['out_tiles'][j]));
				} else {
					(p as ViewPlayer_Other).onHuanSanZhang_Remove();
					for (let j:number = 0; j < 3; j++) pais.push(mjcore.MJPai.Create('5z'));
				}
				
				
				p.ShowHuanSanZhang(pais, data['change_type']);
				Laya.timer.once(2500, this, ()=>{
					if (i == 0) {
						(p as ViewPlayer_Me).onHuanSanZhang_Add(data['in_tiles'], data['in_tile_states'], false);
					} else {
						(p as ViewPlayer_Other).onHuanSanZhang_Add();
					}
				});
			}
			if (uiscript.UI_HuanSanZhange.Inst.enable) uiscript.UI_HuanSanZhange.Inst.close();
			uiscript.UI_HuanSanZhange_ChangeType.Inst.show(data['change_type']);
			Laya.timer.once(2500, this, ()=>{
				if (DesktopMgr.Inst.is_dora3_mode()) {
					uiscript.UI_DesktopInfo.Inst.openDora3BeginShine();
				}
				Laya.timer.once(200, this, () => {
					if (data['doras'] && data['doras'].length > 0) {
						for (let i:number = 0; i < data['doras'].length; i++) {
							DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
							uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
						}
					} 
					for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
					if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
						let __data:Object = {tingpais: data['tingpais0'], operation: data['operation']};
						uiscript.UI_TingPai.Inst.setData0(__data);
					} else {
						let __data:Object = {tingpais: data['tingpais1']};
						uiscript.UI_TingPai.Inst.setData1(__data, false);
					}
					DesktopMgr.Inst.ActionRunComplete();
				});
				if (data['operation'] != undefined) {
					ActionOperation.play(data['operation']);
				}
			});
		}

		public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionChangeTile fastplay data:' + JSON.stringify(data));
			for (let i:number = 0; i < DesktopMgr.Inst.players.length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[i];
				if (i == 0) {
					(p as ViewPlayer_Me).onHuanSanZhang_Remove(data['out_tiles'], data['out_tile_states'], true);
					(p as ViewPlayer_Me).onHuanSanZhang_Add(data['in_tiles'], data['in_tile_states'], true);
				} else {
					(p as ViewPlayer_Other).onHuanSanZhang_Add();
					(p as ViewPlayer_Other).onHuanSanZhang_Remove();
				}
			}
			if (uiscript.UI_HuanSanZhange.Inst.enable) uiscript.UI_HuanSanZhange.Inst.close();
			if (data['doras'] && data['doras'].length > 0) {
				for (let i:number = 0; i < data['doras'].length; i++) {
					DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
					uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
				}
			} 
			for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
			if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
				let __data:Object = {tingpais: data['tingpais0'], operation: data['operation']};
				uiscript.UI_TingPai.Inst.setData0(__data);
			} else {
				let __data:Object = {tingpais: data['tingpais1']};
				uiscript.UI_TingPai.Inst.setData1(__data, false);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(100, this, ()=>{
					ActionOperation.play(data['operation'], usetime + 100);
				});
			}
		}

		public static record(data: any, usetime:number = 0): number {
			app.Log.log('ActionChangeTile record data:' + JSON.stringify(data));
			for (let i:number = 0; i < DesktopMgr.Inst.players.length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[i];
				let d_tiles = data['change_tile_infos'][DesktopMgr.Inst.localPosition2Seat(i)];
				if (i == 0) {
					(p as ViewPlayer_Me).onHuanSanZhang_Remove(d_tiles['out_tiles'], d_tiles['out_tile_states'], false);
				} else {
					(p as ViewPlayer_Other).recordHuanSanZhang_Remove(d_tiles['out_tiles'], d_tiles['out_tile_states']);
				}
				let pais:Array<mjcore.MJPai> = [];
				for (let j:number = 0; j < 3; j++) pais.push(mjcore.MJPai.Create(d_tiles['out_tiles'][j]));
				p.ShowHuanSanZhang(pais, data['change_type']);
				Laya.timer.once(2500, this, ()=>{
					if (i == 0) {
						(p as ViewPlayer_Me).onHuanSanZhang_Add(d_tiles['in_tiles'], d_tiles['in_tile_states'], false);
					} else {
						(p as ViewPlayer_Other).recordHuanSanZhang_Add(d_tiles['in_tiles'], d_tiles['in_tile_states']);
					}
				});
			}
			if (uiscript.UI_HuanSanZhange.Inst.enable) uiscript.UI_HuanSanZhange.Inst.close();
			uiscript.UI_HuanSanZhange_ChangeType.Inst.show(data['change_type']);
			Laya.timer.once(2500, this, () => {
				if (DesktopMgr.Inst.is_chuanma_mode()) {
					// 换三张在dora开之前
					let d = data['operations'][view.DesktopMgr.Inst.localPosition2Seat(view.DesktopMgr.Inst.seat)];
					if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
						if (d) {
							ActionOperation.ob(d, usetime, 1000);
						}
					}
				} else {
					if (data['doras'] && data['doras'].length > 0) {
						for (let i: number = 0; i < data['doras'].length; i++) {
							DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
							uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
						}
					} else if (data['dora'] && data['dora'] != '') {
						DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['dora']));
						uiscript.UI_DesktopInfo.Inst.setDora(0, DesktopMgr.Inst.dora[0]);
					}
					for (let i: number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
					if (data['tingpai']) {
						for (let i: number = 0; i < data['tingpai'].length; i++) {
							if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
								DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
							}
						}
					}

					if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
						if (data['operation']) {
							ActionOperation.ob(data['operation'], usetime, 1000);
						}
					}
				}
			});
			return 3000;
		}

		public static fastrecord(data: any, usetime:number = -1): void {
			for (let i:number = 0; i < DesktopMgr.Inst.players.length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[i];
				let d_tiles = data['change_tile_infos'][DesktopMgr.Inst.localPosition2Seat(i)];
				if (i == 0) {
					(p as ViewPlayer_Me).onHuanSanZhang_Remove(d_tiles['out_tiles'], d_tiles['out_tile_states'], true);
					(p as ViewPlayer_Me).onHuanSanZhang_Add(d_tiles['in_tiles'], d_tiles['in_tile_states'], true);
				} else {
					(p as ViewPlayer_Other).recordHuanSanZhang_Remove(d_tiles['out_tiles'], d_tiles['out_tile_states']);
					(p as ViewPlayer_Other).recordHuanSanZhang_Add(d_tiles['in_tiles'], d_tiles['in_tile_states']);
				}
			}
			if (uiscript.UI_HuanSanZhange.Inst.enable) uiscript.UI_HuanSanZhange.Inst.close();

			if (data['doras'] && data['doras'].length > 0) {
				for (let i:number = 0; i < data['doras'].length; i++) {
					DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
					uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
				}
			} else if (data['dora'] && data['dora'] != '') {
				DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['dora']));
				uiscript.UI_DesktopInfo.Inst.setDora(0, DesktopMgr.Inst.dora[0]);
			}
			for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
			if (data['tingpai']) {
				for (let i:number = 0; i < data['tingpai'].length; i++) {
					if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
						DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
					}
				}
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime, 1000);
				}
			}
		}
	}
}