/**
* name 
*/
module view {
	export class ActionChiPengGang extends ActionBase {

		public static play(data: any): number {
			app.Log.log('ActionChiPengGang play data:' + JSON.stringify(data));
			let duration = 500;
			let seat: number = data['seat'];
			let ming: mjcore.MJMing = new mjcore.MJMing();
			ming.type = data['type'];
			ming.from = data['froms'];
			ming.pais = [];
			let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];
			for (let i: number = 0; i < data['tiles'].length; i++) {
				let pai = mjcore.MJPai.Create(data['tiles'][i]);
				if (view.DesktopMgr.Inst.is_tianming_mode() && pai.touming) {
					if (data['froms'][i] != seat) {
						pai.touming = false;
					}
				}
				ming.pais.push(pai);
				
			}
			let tile_state = [];
			for (let i: number = 0; i < ming.pais.length; i++) {
				if (!data['tile_states'] || data['tile_states'].length <= i) {
					tile_state.push(0);
				} else {
					tile_state.push(data['tile_states'][i]);
				}
			}

			Laya.timer.once(600, this, () => {
				try {
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)].QiPaiNoPass();
					player.AddMing(ming, tile_state);
					if (ming.type == mjcore.E_Ming.gang_ming) {
						DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
					}
				} catch (e) {
					let _errorinfo: Object = {};
					_errorinfo['error'] = e.message;
					_errorinfo['stack'] = e.stack;
					_errorinfo['method'] = 'addming600';
					_errorinfo['name'] = 'ActionChiPengGang';
					GameMgr.Inst.onFatalError(_errorinfo);
				}
			});
			if (seat == DesktopMgr.Inst.seat && (ming.type == mjcore.E_Ming.gang_an || ming.type == mjcore.E_Ming.gang_ming)) {
				duration = 650;
			}
			let _emo_a: string = ''; //被的人表情
			let _emo_b: string = ''; //做的人表情
			switch (ming.type) {
				case mjcore.E_Ming.kezi:
					_emo_a = 'emoji_4';
					_emo_b = 'emoji_3';
					break;
				case mjcore.E_Ming.shunzi:
					_emo_a = 'emoji_2';
					_emo_b = 'emoji_1';
					break;
				case mjcore.E_Ming.gang_ming:
					_emo_a = 'emoji_6';
					_emo_b = 'emoji_5';
					break;
			}
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(DesktopMgr.Inst.index_player, _emo_a, 2000);
			DesktopMgr.Inst.index_player = seat;
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(DesktopMgr.Inst.index_player, _emo_b, 2000);
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) {
				ActionLiqi.play(data['liqi']);
			}
			if (data['operation']) {
				Laya.timer.once(600, this, () => {
					ActionOperation.play(data['operation']);
				});
			}
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (data['liqibang']) {
				uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			}
			let sound: string = '';
			switch (ming.type) {
				case mjcore.E_Ming.shunzi: sound = 'act_chi'; break;
				case mjcore.E_Ming.gang_ming:
				case mjcore.E_Ming.gang_an: sound = 'act_kan'; break;
				case mjcore.E_Ming.kezi: sound = 'act_pon'; break;
			}
			let origin_score = player.score;
			if (data['scores'] && data['scores'].length > 0) {
				DesktopMgr.Inst.setScores(data['scores']);
			}

			player.PlaySound(sound, player.score - origin_score);
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData0(data);
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], true);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
			}
			return duration;
		}

		public static fastplay(data: any, usetime: number): void {
			app.Log.log('ActionChiPengGang fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			let seat: number = data['seat'];
			let ming: mjcore.MJMing = new mjcore.MJMing();
			ming.type = data['type'];
			ming.from = data['froms'];
			ming.pais = [];
			for (let i: number = 0; i < data['tiles'].length; i++) {
				let pai = mjcore.MJPai.Create(data['tiles'][i]);
				if (view.DesktopMgr.Inst.is_tianming_mode() && pai.touming) {
					if (data['froms'][i] != seat) {
						pai.touming = false;
					}
				}
				ming.pais.push(pai);
				
			}
			let tile_state = [];
			for (let i: number = 0; i < ming.pais.length; i++) {
				if (!data['tile_states'] || data['tile_states'].length <= i) {
					tile_state.push(0);
				} else {
					tile_state.push(data['tile_states'][i]);
				}
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)].QiPaiNoPass();
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddMing(ming, tile_state, false);
			if (ming.type == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
			}
			
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) {
				ActionLiqi.fastplay(data['liqi'], 0);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(600, this, () => {
					ActionOperation.play(data['operation'], usetime);
				});
			}
			if (data['scores'] && data['scores'].length > 0) {
				DesktopMgr.Inst.setScores(data['scores']);
			}

			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (data['liqibang']) {
				uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			}

			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData0(data);

			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], false);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionChiPengGang record data:' + JSON.stringify(data));
			let seat: number = data['seat'];
			let ming: mjcore.MJMing = new mjcore.MJMing();
			ming.type = data['type'];
			ming.from = data['froms'];
			ming.pais = [];
			for (let i: number = 0; i < data['tiles'].length; i++) {
				let pai = mjcore.MJPai.Create(data['tiles'][i]);
				if (view.DesktopMgr.Inst.is_tianming_mode() && pai.touming) {
					if (data['froms'][i] != seat) {
						pai.touming = false;
					}
				}
				ming.pais.push(pai);
				
			}
			let tile_state = [];
			for (let i: number = 0; i < ming.pais.length; i++) {
				if (!data['tile_states'] || data['tile_states'].length <= i) {
					tile_state.push(0);
				} else {
					tile_state.push(data['tile_states'][i]);
				}
			}
			Laya.timer.once(600, this, () => {
				if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
				DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)].QiPaiNoPass();
				DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddMing(ming, tile_state);
				if (ming.type == mjcore.E_Ming.gang_ming) {
					DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
				}
			});
			

			let _emo_a: string = ''; //被的人表情
			let _emo_b: string = ''; //做的人表情
			switch (ming.type) {
				case mjcore.E_Ming.kezi:
					_emo_a = 'emoji_4';
					_emo_b = 'emoji_3';
					break;
				case mjcore.E_Ming.shunzi:
					_emo_a = 'emoji_2';
					_emo_b = 'emoji_1';
					break;
				case mjcore.E_Ming.gang_ming:
					_emo_a = 'emoji_6';
					_emo_b = 'emoji_5';
					break;
			}
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(DesktopMgr.Inst.index_player, _emo_a, 2000);
			DesktopMgr.Inst.index_player = seat;
			uiscript.UI_DesktopInfo.Inst.changeHeadEmo(DesktopMgr.Inst.index_player, _emo_b, 2000);
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) {
				ActionLiqi.record(data['liqi']);
			}
			if (data['liqibang']) {
				uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			}
			// if (data['zhenting'] != undefined && data['operation'] == undefined) {
			// 	uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
			// 	uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			// }

			let sound: string = '';
			switch (ming.type) {
				case mjcore.E_Ming.shunzi: sound = 'act_chi'; break;
				case mjcore.E_Ming.gang_ming:
				case mjcore.E_Ming.gang_an: sound = 'act_kan'; break;
				case mjcore.E_Ming.kezi: sound = 'act_pon'; break;
			}
			let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];
			let origin_score = player.score;
			if (data['scores'] && data['scores'].length > 0) {
				DesktopMgr.Inst.setScores(data['scores']);
			}

			player.PlaySound(sound, player.score - origin_score);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime, 500);
				}
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], true);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
			}
			return 1200;
		}

		public static fastrecord(data: any, usetime = -1): void {
			app.Log.log('ActionChiPengGang fastrecord data:' + JSON.stringify(data));
			let seat: number = data['seat'];
			let ming: mjcore.MJMing = new mjcore.MJMing();
			ming.type = data['type'];
			ming.from = data['froms'];
			ming.pais = [];
			for (let i: number = 0; i < data['tiles'].length; i++) {
				let pai = mjcore.MJPai.Create(data['tiles'][i]);
				if (view.DesktopMgr.Inst.is_tianming_mode() && pai.touming) {
					if (data['froms'][i] != seat) {
						pai.touming = false;
					}
				}
				ming.pais.push(pai);
				
			}
			let tile_state = [];
			for (let i: number = 0; i < ming.pais.length; i++) {
				if (!data['tile_states'] || data['tile_states'].length <= i) {
					tile_state.push(0);
				} else {
					tile_state.push(data['tile_states'][i]);
				}
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)].QiPaiNoPass();
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddMing(ming, tile_state, false);
			if (ming.type == mjcore.E_Ming.gang_ming) {
				DesktopMgr.Inst.waiting_lingshang_deal_tile = true;
			}
			if (data['scores'] && data['scores'].length > 0) {
				DesktopMgr.Inst.setScores(data['scores']);
			}
			if (data['liqibang']) {
				uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			}
			
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) {
				ActionLiqi.fastrecord(data['liqi']);
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], false);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime, 500);
				}
			}
		}

	}
}