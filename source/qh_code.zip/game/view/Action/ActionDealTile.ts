/**
* name 
*/
module view {
	export class ActionDealTile extends ActionBase {

		public static play(data: game.IActionDealTile) {
			app.Log.log('ActionDealTile play data:' + JSON.stringify(data));
			let animTime: number = 400;
			let seat: number = data['seat'];
			
			let tile: string = data['tile'];
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.removeTile(data['tile_index'], true);
				uiscript.UI_Astrology.Inst.onSelectionEnd(data['tile_index']);
			}
			DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			if (DesktopMgr.Inst.left_tile_count == 10) {
				if (!DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.seat)].already_xuezhan_hule_state) {
					DesktopMgr.Inst.addMindVoice(DesktopMgr.Inst.seat, 'ingame_remain10');
				}

				Laya.timer.once(1000, this, () => {
					DesktopMgr.Inst.playMindVoice();
				});
			}
			let is_open: boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.TakePai(mjcore.MJPai.Create(tile), is_open);
			} else {
				if (is_open || (tile && tile.indexOf('t') != -1)) {
					(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).TakePai(mjcore.MJPai.Create(tile), is_open);
				} else {
					(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).TakePai(mjcore.MJPai.Create('5z'), is_open);
				}
			}
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) ActionLiqi.play(data['liqi']);
			if (data['operation']) ActionOperation.play(data.operation);
			if (data['doras'] && data['doras'].length > 0) DesktopMgr.Inst.WhenDoras(data['doras'], false);
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData0(data);
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
				if (data['liqi'] && data['liqi']['seat'] == seat) {
					animTime += 900;
				}
			}
			Laya.timer.once(animTime, this, () => DesktopMgr.Inst.ActionRunComplete());
			
		}

		public static fastplay(data: any, usetime: number) {
			app.Log.log('ActionDealTile fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			let seat: number = data['seat'];
			let tile: string = data['tile'];
			DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			let is_open: boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.TakePai(mjcore.MJPai.Create(tile), is_open, false);
			} else {
				if (is_open || (tile && tile.indexOf('t') != -1)) {
					(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).TakePai(mjcore.MJPai.Create(tile), is_open);
				} else {
					(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).TakePai(mjcore.MJPai.Create('5z'), is_open);
				}
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.removeTile(data['tile_index'], false);
				uiscript.UI_Astrology.Inst.onSelectionEnd(data['tile_index']);
			}
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) ActionLiqi.fastplay(data['liqi'], 0);
			if (data['operation'] && usetime != -1) ActionOperation.play(data['operation'], usetime);
			if (data['doras'] && data['doras'].length > 0) DesktopMgr.Inst.WhenDoras(data['doras'], true);
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData0(data);
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionDealTile record data:' + JSON.stringify(data));
			let animTime: number = 400;
			let seat: number = data['seat'];
			
			let tile: string = data['tile'];
			DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			let is_open: boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.TakePai(mjcore.MJPai.Create(tile), is_open);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordTakePai(mjcore.MJPai.Create(tile), is_open, view.DesktopMgr.Inst.record_show_anim);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.removeTile(data['tile_index'], true);
				uiscript.UI_Astrology.Inst.onSelectionEnd(data['tile_index']);
			}
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) ActionLiqi.record(data['liqi']);
			if (data['doras'] && data['doras'].length > 0) DesktopMgr.Inst.WhenDoras(data['doras'], false);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime);
				}
			}
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
				if (data['liqi'] && data['liqi']['seat'] == seat) {
					animTime += 900;
				}
			}
			
			return animTime;
		}

		public static fastrecord(data: any, usetime = -1) {
			app.Log.log('ActionDealTile fastrecord data:' + JSON.stringify(data));
			let seat: number = data['seat'];
			let tile: string = data['tile'];
			DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			let is_open: boolean = false;
			if (data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.TakePai(mjcore.MJPai.Create(tile), is_open, false);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordTakePai(mjcore.MJPai.Create(tile), is_open);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.removeTile(data['tile_index'], false);
				uiscript.UI_Astrology.Inst.onSelectionEnd(data['tile_index']);
			}
			DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.RefreshPlayerIndicator();
			if (data['liqi']) ActionLiqi.fastrecord(data['liqi']);
			if (data['doras'] && data['doras'].length > 0) DesktopMgr.Inst.WhenDoras(data['doras'], true);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime);
				}
			}
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
		}
	}
}