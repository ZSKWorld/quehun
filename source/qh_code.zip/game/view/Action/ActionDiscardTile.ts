/**
* name 
*/
module view{
	export class ActionDiscardTile extends ActionBase{
		
		public static play(data: game.IActionDiscardTile): number {
			app.Log.log('ActionDiscardTile play data:' + JSON.stringify(data));
			let duration = 500;
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile']);
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie']);
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_FieldSpell.Inst.onDiscard(seat, liqi);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.alignTile();
			}
			if (liqi) {
				if (data.is_wliqi) {
					let sound = 'act_drich';
					if(data.liqi_type_beishuizhizhan){
						sound = 'act_drich_beishui' + data.liqi_type_beishuizhizhan;
					}
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound(sound, 0);
				} else {
					let sound = 'act_rich';
					if(data.liqi_type_beishuizhizhan){
						sound = 'act_rich_beishui' + data.liqi_type_beishuizhizhan;
					}
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound(sound, 0);
				}				
				let liqi_bgm_id:number = DesktopMgr.Inst.player_effects[seat][game.EView.lizhi_bgm];
				if (liqi_bgm_id && liqi_bgm_id != 0) {
					let bgm:string = cfg.item_definition.item.get(liqi_bgm_id).sargs[0];
					if (view.AudioMgr.lizhiMuted) {
						view.AudioMgr.PlayLiqiBgm(bgm, 300, true);
					} else {
						view.BgmListMgr.stopBgm();
						Laya.timer.once(1000, this, ()=>{
							if (DesktopMgr.Inst.gameing) {
								view.BgmListMgr.PlayMJBgm('', true);
								view.AudioMgr.PlayLiqiBgm(bgm, 300, true);
							}
						});
					}
				}
			} 

			let is_open:boolean = false;
			if (!pai.touming && data['tile_state'] && data['tile_state'] > 0) is_open = true;
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, is_open, false, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onDiscardTile(data['moqie'], data['tile'], is_open, false);
			}
			if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, false);
			// 刷新天命显示
			if (DesktopMgr.Inst.is_tianming_mode()) {
				uiscript.UI_DesktopInfo.Inst.SetTianMingRate(seat, DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].getTianMingRate(), true)
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], true);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
				if (!data['hun_zhi_yi_ji_info']['overload']) {
					// 未过载，这个人还要继续摸牌，给动画时间留一下；服务端会留1100ms，不过客户端时间会更乱一些
					if (liqi) duration = 1100;
					else duration = 600;	
				}
			}

			if (data.liqi_type_beishuizhizhan) {
				let pos = view.DesktopMgr.Inst.seat2LocalPosition(seat);
				if (pos == 0) view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(pos, data.liqi_type_beishuizhizhan, false, true);
			}

			Laya.timer.once(500, this, () => {
				if (liqi) DesktopMgr.Inst.clearMindVoice();
				else DesktopMgr.Inst.playMindVoice();
			});
			return duration;
		}

		public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionDiscardTile fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile']);
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);
			let is_open:boolean = false;
			if (!pai.touming && data['tile_state'] && data['tile_state'] > 0) is_open = true;

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], false);
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, is_open, true, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onDiscardTile(data['moqie'], data['tile'], is_open, true);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation'], usetime);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, true);
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_FieldSpell.Inst.onDiscard(seat, liqi);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.alignTile();
			}

			// 刷新天命显示
			if (DesktopMgr.Inst.is_tianming_mode()) {
				uiscript.UI_DesktopInfo.Inst.SetTianMingRate(seat, DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].getTianMingRate())
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], false);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
			if (data.liqi_type_beishuizhizhan) {
				let pos = view.DesktopMgr.Inst.seat2LocalPosition(seat);
				if (pos == 0) view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(pos, data.liqi_type_beishuizhizhan, false, false);
			}
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionDiscardTile record data:' + JSON.stringify(data));
			let duration = 500;
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile']);
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);
			let is_open:boolean = false;
			if (!pai.touming && data['tile_state'] && data['tile_state'] > 0) is_open = true;

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie']);
			if (liqi) {
				if (data.is_wliqi) {
					let sound = 'act_drich';
					if(data.liqi_type_beishuizhizhan){
						sound = 'act_drich_beishui' + data.liqi_type_beishuizhizhan;
					}
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound(sound, 0);
				} else {
					let sound = 'act_rich';
					if(data.liqi_type_beishuizhizhan){
						sound = 'act_rich_beishui' + data.liqi_type_beishuizhizhan;
					}
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound(sound, 0);
				}
				uiscript.UI_DesktopInfo.Inst.changeHeadEmo(seat, 'emoji_9', 2000);
			} 
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, is_open, false, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordDiscardTile(pai, data['moqie'], is_open, false);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}

			// 新手引导用
			if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			}

			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_FieldSpell.Inst.onDiscard(seat, liqi);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.alignTile();
			}
			// if (data['zhenting'] != undefined && data['operation'] == undefined) {
			// 	uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
			// 	uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			// }
			// 刷新天命显示
			if (DesktopMgr.Inst.is_tianming_mode()) {
				uiscript.UI_DesktopInfo.Inst.SetTianMingRate(seat, DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].getTianMingRate(), true)
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], true);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
				if (!data['hun_zhi_yi_ji_info']['overload']) {
					// 未过载，这个人还要继续摸牌，给动画时间留一下；服务端会留1100ms，不过客户端时间会更乱一些
					if (liqi) duration = 1100;
					else duration = 600;	
				}
			}
			if (data.liqi_type_beishuizhizhan) {
				let pos = view.DesktopMgr.Inst.seat2LocalPosition(seat);
				if (pos == 0) view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(pos, data.liqi_type_beishuizhizhan, false, true);
			}
			return duration;
		}

		public static fastrecord(data: any, usetime:number = -1) {
			app.Log.log('ActionDiscardTile fastrecord data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile']);
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);
			let is_open:boolean = false;
			if (!pai.touming && data['tile_state'] && data['tile_state'] > 0) is_open = true;

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], false);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, is_open, true, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordDiscardTile(pai, data['moqie'], is_open, true);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_FieldSpell.Inst.onDiscard(seat, liqi);
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.alignTile();
			}
			// 刷新天命显示
			if (DesktopMgr.Inst.is_tianming_mode()) {
				uiscript.UI_DesktopInfo.Inst.SetTianMingRate(seat, DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].getTianMingRate())
			}
			if (data['yongchang']) {
				uiscript.UI_DesktopInfo.Inst.SetYongChangRate(DesktopMgr.Inst.seat2LocalPosition(data['yongchang']['seat']), data['yongchang']['moqie_count'],data['yongchang']['moqie_bonus'],data['yongchang']['shouqie_count'], data['yongchang']['shouqie_bonus'], false);
			}
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
			if (data.liqi_type_beishuizhizhan) {
				let pos = view.DesktopMgr.Inst.seat2LocalPosition(seat);
				if (pos == 0) view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(pos, data.liqi_type_beishuizhizhan, false, false);
			}
			// if (data['zhenting'] != undefined && data['operation'] == undefined) {
			// 	uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
			// 	uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			// }
		}

	}
}