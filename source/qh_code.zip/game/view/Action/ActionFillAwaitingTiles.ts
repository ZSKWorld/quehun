/**
* ActionFillAwaitingTiles 占星模式补充牌
*/
module view{
	export class ActionFillAwaitingTiles extends ActionBase {
        public static play(msg:any) {
            let tiles = [];
            for (let tile of msg['awaiting_tiles']) {
                tiles.push(mjcore.MJPai.Create(tile));
            }
			
            let seat = msg['operation']['seat'];
            uiscript.UI_Astrology.Inst.setTiles(tiles, seat, true);
            if (seat == view.DesktopMgr.Inst.seat && (msg['operation']['time_add'] > 0 || msg['operation']['time_fixed'] > 0)) {
                Laya.timer.once(100, this, ()=>{
                    ActionOperation.play(msg['operation'], null);
                })   
            };
            if (msg['liqi']) ActionLiqi.play(msg['liqi']);
            DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
            DesktopMgr.Inst.ActionRunComplete();
            return 1000;
        }

        public static fastplay(msg:any, usetime:number) {
            let tiles = [];
            for (let tile of msg['awaiting_tiles']) {
                tiles.push(mjcore.MJPai.Create(tile));
            }
			
            let seat = msg['operation']['seat'];
            uiscript.UI_Astrology.Inst.setTiles(tiles, seat, false);
            DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
            if (msg['liqi']) ActionLiqi.fastplay(msg['liqi'], 0);
            if (msg['operation']['seat'] == view.DesktopMgr.Inst.seat && usetime != -1 && (msg['operation']['time_add'] > 0 || msg['operation']['time_fixed'] > 0)) {
                ActionOperation.play(msg['operation'], null);
            };
            return 0;
        }

        public static record(msg:any, usetime: number = 0) {
			let tiles = [];
            for (let tile of msg['awaiting_tiles']) {
                tiles.push(mjcore.MJPai.Create(tile));
            }
            if (msg['liqi']) ActionLiqi.record(msg['liqi']);
            let seat = msg['operation']['seat'];
            DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
			uiscript.UI_Astrology.Inst.setTiles(tiles, seat, true);
            if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (msg['operations']) {
					for (let i:number = 0; i < msg['operations'].length; i++) {
						ActionOperation.ob(msg['operations'][i], usetime, 450);
					}
				}
			}
            return 800;
        }

        public static fastrecord(msg:any) {
			let tiles = [];
            for (let tile of msg['awaiting_tiles']) {
                tiles.push(mjcore.MJPai.Create(tile));
            }
			if (msg['liqi']) ActionLiqi.fastrecord(msg['liqi']);
            let seat = msg['operation']['seat'];
            uiscript.UI_Astrology.Inst.setTiles(tiles, seat, false);
            DesktopMgr.Inst.index_player = seat;
			DesktopMgr.Inst.RefreshPlayerIndicator();
            return 0;
        }
    }
}