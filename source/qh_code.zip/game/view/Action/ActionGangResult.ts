/**
* name 
*/
module view {
	/**
	 * 杠有分数的模式，开杠，但游戏并未结束(分数未小于0)
	 */
	export class ActionGangResult extends ActionBase {

		public static play(data: any) {

			// app.Log.log('ActionHule play data:' + JSON.stringify(data));
			// console.log('ActionHule play data:' + JSON.stringify(data));
			let _show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			let isPaipu = DesktopMgr.Inst.mode == EMJMode.paipu;
			let isAutoPlay = isPaipu && uiscript.UI_Replay.Inst.enable && uiscript.UI_Replay.Inst.auto_play;
			let current_time: number = 0;
			let info = data['gang_infos'];
			let need_show = false;
			let scoreInfos: Array<{ title_id: number, score: number, delta: number }> = [];
			for (let i: number = 0; i < info['delta_scores'].length; i++) {
				let scoreChangeInfo = { title_id: 0, score: 0, delta: 0 };
				if (info['delta_scores'][i] > 0) {

					uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_7', -1);
					scoreChangeInfo['delta'] = info['delta_scores'][i];
					need_show = true;
					// view.DesktopMgr.Inst.onRoundEnd(i, 1);
				} else if (info['delta_scores'][i] < 0) {
					scoreChangeInfo['delta'] = info['delta_scores'][i];
					uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_8', -1);
					need_show = true;
					// view.DesktopMgr.Inst.onRoundEnd(i, 0);
				}
				scoreChangeInfo['score'] = info['old_scores'][i];
				scoreInfos.push(scoreChangeInfo);
			}
			if (need_show) {
				Laya.timer.once(200, this, () => {
					DesktopMgr.Inst.setScores(info['scores']);
				});
				if (isPaipu && !_show_anim && !isAutoPlay) {
					//2025.5.7 增加确认按钮
					uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos, Laya.Handler.create(this, () => {
						DesktopMgr.Inst.ActionRunComplete();
					}));
					DesktopMgr.Inst.mainrole.revertAllPais();
				} else {
					uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos);
					current_time += 2000;
					DesktopMgr.Inst.mainrole.revertAllPais();
					Laya.timer.once(current_time, this, () => {
						DesktopMgr.Inst.ActionRunComplete();
					});
				}
			} else {
				DesktopMgr.Inst.mainrole.revertAllPais();
				Laya.timer.once(current_time, this, () => {
					DesktopMgr.Inst.ActionRunComplete();
				});
			}
			
			
		}

		public static fastplay(data: any, usetime: number) {
			app.Log.log('ActionHule fastplay data:' + JSON.stringify(data));
			// view.BgmListMgr.stopBgm();
			let info = data['gang_infos'];
			DesktopMgr.Inst.setScores(info['scores']);
		}

		public static record(data: any): number {
			this.play(data);
			return 2000;
		}

		public static fastrecord(data: any) {
			// view.BgmListMgr.stopBgm();
			// DesktopMgr.Inst.gameing = false;
			this.fastplay(data, 1000);
			// uiscript.UIMgr.Inst.ShowWin(data, false);
		}

		public static fastrecord_xuezhan(data: any, isAnim: boolean): number {
			if (DesktopMgr.Inst.mode == EMJMode.paipu && isAnim && DesktopMgr.Inst.isHusMode()) {
				this.play(data);
				return 2000;
			}
			this.fastrecord(data);
			return 0;
		}

	}
}