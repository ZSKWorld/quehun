/**
* name 
*/
module view {
	/**
	 * 杠有分数的模式，开杠后有人分数小于0，触发对局结束
	 */
	export class ActionGangResultEnd extends ActionBase {

		public static play(data: any) {
			// app.Log.log('ActionHule play data:' + JSON.stringify(data));
			// console.log('ActionHule play data:' + JSON.stringify(data));
			let _show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			let isPaipu = DesktopMgr.Inst.mode == EMJMode.paipu;
			let current_time: number = 0;
			let info = data['gang_infos'];

			let scoreInfos: Array<{ title_id: number, score: number, delta: number }> = [];
			for (let i: number = 0; i < info['delta_scores'].length; i++) {
				let scoreChangeInfo = { title_id: 0, score: 0, delta: 0 };
				if (info['delta_scores'][i] > 0) {

					uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_7', -1);
					scoreChangeInfo['delta'] = info['delta_scores'][i];

					// view.DesktopMgr.Inst.onRoundEnd(i, 1);
				} else if (info['delta_scores'][i] < 0) {
					scoreChangeInfo['delta'] = info['delta_scores'][i];
					uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_8', -1);

					// view.DesktopMgr.Inst.onRoundEnd(i, 0);
				}
				scoreChangeInfo['score'] = info['old_scores'][i];
				scoreInfos.push(scoreChangeInfo);
			}
			Laya.timer.once(200, this, () => {
				DesktopMgr.Inst.setScores(info['scores']);
			});
			if (isPaipu && !_show_anim) {
				uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos, Laya.Handler.create(this, () => {
					DesktopMgr.Inst.ActionRunComplete();
					if (info['hules_history'] && info['hules_history'].length > 0) {
						for (let hule of info['hules_history']) {
							let seat = DesktopMgr.Inst.seat2LocalPosition(hule['seat']);
							let hands: Array<mjcore.MJPai> = [];
							for (let hand of hule['hand']) {
								hands.push(mjcore.MJPai.Create(hand));
							}
							hands = hands.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.players[seat].onXuezhanEnd(hands, false);
						}
						uiscript.UIMgr.Inst.ShowWin(info, false);

					} else {
						if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
							uiscript.UI_Replay.Inst.nextStep(true);
						} else {
							uiscript.UIMgr.Inst.ShowGameEnd();
						}
					}
				}));
				
			} else {
				uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos);

				current_time += 2000;
				if (info['hules_history'] && info['hules_history'].length > 0) {
					for (let hule of info['hules_history']) {
						let seat = DesktopMgr.Inst.seat2LocalPosition(hule['seat']);
						let hands: Array<mjcore.MJPai> = [];
						for (let hand of hule['hand']) {
							hands.push(mjcore.MJPai.Create(hand));
						}
						hands = hands.sort(mjcore.MJPai.Distance);
						DesktopMgr.Inst.players[seat].onXuezhanEnd(hands, false);
					}
					Laya.timer.once(current_time, this, () => {
						uiscript.UIMgr.Inst.ShowWin(info, false);
					});

				} else {
					Laya.timer.once(current_time, this, () => {
						if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
							uiscript.UI_Replay.Inst.nextStep(true);
						} else {
							uiscript.UIMgr.Inst.ShowGameEnd();
						}

					});
				}
				Laya.timer.once(current_time, this, () => {
					uiscript.UI_Hu_Xuezhan.Inst.close();
					DesktopMgr.Inst.ActionRunComplete();
				});
			}
			
		}

		public static fastplay(data: any, usetime: number) {
			app.Log.log('ActionHule fastplay data:' + JSON.stringify(data));
			let info = data['gang_infos'];
			if (info['hules_history'] && info['hules_history'].length > 0) {
				uiscript.UIMgr.Inst.ShowWin(info, false);
			} else {
				if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
					uiscript.UI_Replay.Inst.nextStep(true);
				} else {
					uiscript.UIMgr.Inst.ShowGameEnd();
				}
			}
		}

		public static record(data: any): number {
			this.play(data);
			return 5100;
		}

		public static fastrecord(data: any) {
			// view.BgmListMgr.stopBgm();
			// DesktopMgr.Inst.gameing = false;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			this.fastplay(data, 1000);
			// uiscript.UIMgr.Inst.ShowWin(data, false);
		}

	}
}