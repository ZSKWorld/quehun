/**
* name 
*/
module view{
	export class ActionHule extends ActionBase{
		
		public static play(data:game.IActionHule) {
			let _show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			// app.Log.log('ActionHule play data:' + JSON.stringify(data));
			// console.log('ActionHule play data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			DesktopMgr.Inst.gameing = false;
			uiscript.UI_PlayerInfo.Inst.hide();
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			let big_then_manguan:boolean = false; //高于满贯
			Laya.timer.once(100, this, ()=>{
				let infos:Array<Object> = data['hules'];
				let current_time:number = 0;
				if (infos[0]['zimo']) {
					let seat:number = infos[0]['seat'];
					let hand:Array<mjcore.MJPai> = [];
					for (let i:number = 0; i < infos[0]['hand'].length; i++) hand.push(mjcore.MJPai.Create(infos[0]['hand'][i]));
					hand = hand.sort(mjcore.MJPai.Distance);
					uiscript.UI_Huleshow.Inst.showZimo([DesktopMgr.Inst.seat2LocalPosition(seat)]);
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					current_time += 1400;
					if (_show_anim) {
						if ((infos[0]['title'] && infos[0]['title'] != '') || infos[0]['title_id']) {
							Laya.timer.once(current_time, this, () => {
								uiscript.UI_HuCutIn.show(DesktopMgr.Inst.player_datas[seat]['avatar_id']);
								big_then_manguan = true;
							});
							current_time += 2000;
						}
					}
					
					
					Laya.timer.once(current_time, this, ()=>{
						if (seat == DesktopMgr.Inst.seat) {
							DesktopMgr.Inst.mainrole.HulePrepare(hand, infos[0]['hu_tile'], infos[0]['zimo']);
						}
						DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].Hule(hand, mjcore.MJPai.Create(infos[0]['hu_tile']), infos[0]['zimo']);
					});
					if (_show_anim) {
						let effect_hupai:number = 0; // 一炮多响采用头跳规则
						let seat:number = infos[0]['seat'];
						if (seat >= 0) {
							effect_hupai = DesktopMgr.Inst.player_effects[seat][game.EView.hupai_effect];
						}
						//胡牌特效很长的情况
						current_time += 2800;
						let hupaiViewData = cfg.item_definition.view.get(effect_hupai);
						if (hupaiViewData && hupaiViewData.sargs[0]) { 
							current_time += Number(hupaiViewData.sargs[0]);
						}

					} else {
						current_time += 500;
					}

					if (seat == DesktopMgr.Inst.seat) {
						uiscript.UI_TingPai.Inst.reset();
						uiscript.UI_TingPai.Inst.setZhengting(false);
					}
				} else {
					Laya.timer.once(current_time, this, () => {
						let hules:Array<number> = [];
						for (let i:number = 0; i < infos.length; i++) {
							hules.push(DesktopMgr.Inst.seat2LocalPosition(infos[i]['seat']));
						}
						uiscript.UI_Huleshow.Inst.showRong(hules);
					});
					current_time += 1500;
					if (_show_anim) {
						for (let i:number = 0; i < infos.length; i++) {
							let seat:number = infos[i]['seat'];
							if ((infos[i]['title'] && infos[i]['title'] != '') || infos[i]['title_id']) {
								Laya.timer.once(current_time, this, ()=>{
									uiscript.UI_HuCutIn.show(DesktopMgr.Inst.player_datas[seat]['avatar_id']);
									big_then_manguan = true;
								});
								current_time += 2000;
							}
						}
					}

					for (let i:number = 0; i < infos.length; i++) {
						let seat:number = infos[i]['seat'];
						if (seat == DesktopMgr.Inst.seat) {
							let hand:Array<mjcore.MJPai> = [];
							for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
							hand = hand.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.mainrole.HulePrepare(hand, infos[i]['hu_tile'], infos[i]['zimo']);
						}
					}

					Laya.timer.once(current_time, this, () => {
						if (_show_anim) {
							let effect_hupai:number = 0; // 一炮多响采用头跳规则
							let seat:number = infos[0]['seat'];
							if (seat >= 0) {
								effect_hupai = DesktopMgr.Inst.player_effects[seat][game.EView.hupai_effect];
							}
							
							DesktopMgr.Inst.ShowHuleEffect(DesktopMgr.Inst.lastqipai, DesktopMgr.Inst.lastqipai.model.transform, effect_hupai, DesktopMgr.Inst.lastpai_seat, view.DesktopMgr.Inst.isLastPaiMingPai() ? 2 : 0);
						}
						
						for (let i:number = 0; i < infos.length; i++) {
							let hand:Array<mjcore.MJPai> = [];
							for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
							hand = hand.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(infos[i]['seat'])].Hule(hand, mjcore.MJPai.Create(infos[i]['hu_tile']), infos[i]['zimo']);
							if (infos[i]['seat'] == DesktopMgr.Inst.seat) {
								uiscript.UI_TingPai.Inst.reset();
								uiscript.UI_TingPai.Inst.setZhengting(false);
							}
						}
					});
					if (_show_anim) {
						let effect_hupai:number = 0; // 一炮多响采用头跳规则
						let seat:number = infos[0]['seat'];
						if (seat >= 0) {
							effect_hupai = DesktopMgr.Inst.player_effects[seat][game.EView.hupai_effect];
						}
						current_time += 2000;
						let hupaiViewData = cfg.item_definition.view.get(effect_hupai);
						if (hupaiViewData && hupaiViewData.sargs[0]) { 
							current_time += Number(hupaiViewData.sargs[0]);
						}
					} else {
						current_time += 600;
					}
				}

				//分数少了的人郁闷
				for (let i:number = 0; i < data['delta_scores'].length; i++) {
					if (data['delta_scores'][i] > 0) {
						uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_7', -1);
						view.DesktopMgr.Inst.onRoundEnd(i, 1);
					} else if (data['delta_scores'][i] < 0) {
						uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_8', -1);
						view.DesktopMgr.Inst.onRoundEnd(i, 0);
					}
				}


				if (data['hun_zhi_yi_ji_info']) {
					uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], true);
				}

				if (DesktopMgr.Inst.is_beishuizhizhan_mode()) {
					for (let i = 0; i < 4; i++) {
						view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(i, 0, true, true);
					}
				}
				Laya.timer.once(current_time, this, () => {
					uiscript.UIMgr.Inst.ShowWin(data, false);
					DesktopMgr.Inst.ActionRunComplete();
				});
			});
		}

		public static fastplay(data:game.IActionHule, usetime:number) {
			app.Log.log('ActionHule fastplay data:' + JSON.stringify(data));
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			DesktopMgr.Inst.gameing = false;
			uiscript.UIMgr.Inst.ShowWin(data, false);
			if (data['hun_zhi_yi_ji_info']) {
				uiscript.UI_DesktopInfo.Inst.SetHunZhiContinueDealCount(DesktopMgr.Inst.seat2LocalPosition(data['hun_zhi_yi_ji_info']['seat']), data['hun_zhi_yi_ji_info']['continue_deal_count'], data['hun_zhi_yi_ji_info']['overload'], false);
			}
			if (DesktopMgr.Inst.is_beishuizhizhan_mode()) {
				for (let i = 0; i < 4; i++) {
					view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(i, 0, true, false);
				}
			}
		}

		public static record(data:any): number {
			this.play(data);
			return 100000;
		}

		public static fastrecord(data:any) {
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			DesktopMgr.Inst.gameing = false;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			uiscript.UIMgr.Inst.ShowWin(data, false);
		}

	}
}