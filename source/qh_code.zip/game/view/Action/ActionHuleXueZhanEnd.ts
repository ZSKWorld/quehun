/**
* name 
*/
module view{
	export class ActionHuleXueZhanEnd extends ActionBase{
		
		public static play(data: game.IActionHuleXueZhanEnd) {
			let _show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			let isPaipu = DesktopMgr.Inst.mode == EMJMode.paipu;
		
			// app.Log.log('ActionHule play data:' + JSON.stringify(data));
			// console.log('ActionHule play data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			DesktopMgr.Inst.gameing = false;
			uiscript.UI_PlayerInfo.Inst.hide();
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			Laya.timer.once(100, this, ()=>{
				let infos:Array<Object> = data['hules'];
				let current_time:number = 0;
				if (data['hules_history']) { // 对于huMid的人翻开手牌
					Laya.timer.once(3000, this, ()=>{
						for (let info of data['hules_history']) {
							let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(info['seat'])];
							if (player && player.already_xuezhan_hule_state) {
								let hand = [];
								for (let j:number = 0; j < info['hand'].length; j++) hand.push(mjcore.MJPai.Create(info['hand'][j]));
								hand = hand.sort(mjcore.MJPai.Distance);
								player.onXuezhanEnd(hand, !_show_anim);
							}
						}
					});
				}
				
				if (infos[0]['zimo']) {
					let seat:number = infos[0]['seat'];
					let hand:Array<mjcore.MJPai> = [];
					for (let i:number = 0; i < infos[0]['hand'].length; i++) hand.push(mjcore.MJPai.Create(infos[0]['hand'][i]));
					hand = hand.sort(mjcore.MJPai.Distance);
					uiscript.UI_Huleshow.Inst.showZimo([DesktopMgr.Inst.seat2LocalPosition(seat)]);
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					current_time += 1400;
					
					Laya.timer.once(current_time, this, ()=>{
						if (seat == DesktopMgr.Inst.seat) {
							DesktopMgr.Inst.mainrole.HulePrepare(hand, infos[0]['hu_tile'], infos[0]['zimo']);
						}
						DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].Hule(hand, mjcore.MJPai.Create(infos[0]['hu_tile']), infos[0]['zimo']);
					});
					// if (_show_anim) {
					// 	current_time += 1500;
					// } else {
					// 	current_time += 500;
					// }
					if (isPaipu) {
						if (_show_anim) {
							current_time += 1500;
						} else {
							current_time += 500;
						}
					}

					if (seat == DesktopMgr.Inst.seat) {
						uiscript.UI_TingPai.Inst.reset();
						uiscript.UI_TingPai.Inst.setZhengting(false);
					}
				} else {
					Laya.timer.once(current_time, this, () => {
						let hules:Array<number> = [];
						for (let i:number = 0; i < infos.length; i++) {
							hules.push(DesktopMgr.Inst.seat2LocalPosition(infos[i]['seat']));
						}
						uiscript.UI_Huleshow.Inst.showRong(hules);
					});
					current_time += 1500;
				

					for (let i:number = 0; i < infos.length; i++) {
						let seat:number = infos[i]['seat'];
						if (seat == DesktopMgr.Inst.seat) {
							let hand:Array<mjcore.MJPai> = [];
							for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
							hand = hand.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.mainrole.HulePrepare(hand, infos[i]['hu_tile'], infos[i]['zimo']);
						}
					}

					Laya.timer.once(current_time, this, () => {
						if (_show_anim) {
							let effect_hupai:number = 0; // 一炮多响采用头跳规则
							let seat:number = -1;
							for (let i:number = 0; i < infos.length; i++) {
								let _seat:number = infos[i]['seat'];
								if (seat == -1) {
									seat = _seat;
								} else {
									let d0:number = DesktopMgr.Inst.seat2LocalPosition(seat);
									let d1:number = DesktopMgr.Inst.seat2LocalPosition(_seat);
									if (d0 > d1) {
										seat = _seat;
									}
								}
							}
							if (seat >= 0) {
								effect_hupai = DesktopMgr.Inst.player_effects[seat][game.EView.hupai_effect];
							}
							DesktopMgr.Inst.lastqipai.isxuezhanhu = true;
							DesktopMgr.Inst.lastqipai.OnChoosedPai();
							DesktopMgr.Inst.ShowHuleEffect(DesktopMgr.Inst.lastqipai, DesktopMgr.Inst.lastqipai.model.transform, effect_hupai, DesktopMgr.Inst.lastpai_seat, view.DesktopMgr.Inst.isLastPaiMingPai() ? 2 : 0);
						}
						
						for (let i:number = 0; i < infos.length; i++) {
							let hand:Array<mjcore.MJPai> = [];
							for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
							hand = hand.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(infos[i]['seat'])].Hule(hand, mjcore.MJPai.Create(infos[i]['hu_tile']), infos[i]['zimo']);
							if (infos[i]['seat'] == DesktopMgr.Inst.seat) {
								uiscript.UI_TingPai.Inst.reset();
								uiscript.UI_TingPai.Inst.setZhengting(false);
							}
						}
					});
					if (isPaipu) {
						current_time += _show_anim ? 2000 : 300;
					}
					// current_time += _show_anim ? 2000 : 300;
				}

				let scoreInfos:Array<{title_id:number, score:number, delta:number}> = [];
				//分数少了的人郁闷
				for (let i:number = 0; i < data['delta_scores'].length; i++) {
					let scoreChangeInfo = {title_id: 0, score: 0, delta: 0};
					if (data['delta_scores'][i] > 0) {
						uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_7', -1);
						view.DesktopMgr.Inst.onRoundEnd(i, 1);
						scoreChangeInfo['delta'] = data['delta_scores'][i];
						for (let data of infos) {
							if (data['seat'] == i) {
								scoreChangeInfo['title_id'] = data['title_id'];
								break;
							}
						}
					} else if (data['delta_scores'][i] < 0) {
						scoreChangeInfo['delta'] = data['delta_scores'][i];
						uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_8', -1);
						view.DesktopMgr.Inst.onRoundEnd(i, 0);
					}
					scoreChangeInfo['score'] = data['old_scores'][i];
					scoreInfos.push(scoreChangeInfo);
				}
				if (isPaipu && !_show_anim) {
					Laya.timer.once(current_time, this, () => {
						Laya.timer.once(200, this, () => {
							DesktopMgr.Inst.setScores(data['scores']);
						});
						//2025.5.7 增加确认按钮
						uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos, Laya.Handler.create(this, () => {
							uiscript.UIMgr.Inst.ShowWin(data, false);
							DesktopMgr.Inst.ActionRunComplete();
						}));
					});
				} else {
					Laya.timer.once(current_time, this, () => {
						Laya.timer.once(200, this, () => {
							DesktopMgr.Inst.setScores(data['scores']);
						});
						uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos);
					});

					current_time += 3000;
					Laya.timer.once(current_time, this, () => {
						uiscript.UI_Hu_Xuezhan.Inst.close();
						uiscript.UIMgr.Inst.ShowWin(data, false);
						DesktopMgr.Inst.ActionRunComplete();
					});
				}
				
			});
		}

		public static fastplay(data: game.IActionHuleXueZhanEnd, usetime:number) {
			app.Log.log('ActionHule fastplay data:' + JSON.stringify(data));
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			DesktopMgr.Inst.gameing = false;
			DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UIMgr.Inst.ShowWin(data, false);
		}

		public static record(data:any): number {
			this.play(data);
			return 100000;
		}

		public static fastrecord(data:any) {
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.resetMindVoice();
			DesktopMgr.Inst.gameing = false;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UIMgr.Inst.ShowWin(data, false);
		}

	}
}