/**
* name 
*/
module view{
	export class ActionHuleXueZhanMid extends ActionBase{
		
		public static play(data: game.IActionHuleXueZhanMid) {
			let record_show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			let isPaipu = DesktopMgr.Inst.mode == EMJMode.paipu;
			let isAutoPlay = isPaipu && uiscript.UI_Replay.Inst.enable && uiscript.UI_Replay.Inst.auto_play;
			// app.Log.log('ActionHule play data:' + JSON.stringify(data));
			// console.log('ActionHule play data:' + JSON.stringify(data));
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			if (data['zhenting'] != undefined) {
                uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
            }
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			Laya.timer.once(100, this, ()=>{
				let infos:Array<Object> = data['hules'];
				let current_time:number = 0;
				
				if (infos[0]['zimo']) {
					let seat:number = infos[0]['seat'];
					DesktopMgr.Inst.setTingpai(seat, []);
					if (record_show_anim || isPaipu) {
						uiscript.UI_Huleshow.Inst.showZimo([DesktopMgr.Inst.seat2LocalPosition(seat)]);
					}
					if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
					current_time += record_show_anim || isPaipu ? 1200 : 200;
					Laya.timer.once(current_time, this, ()=>{
						let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];
						player.onXuezhanMidHule(true, mjcore.MJPai.Create(infos[0]['hu_tile']), false);
					});
				} else {
					// if (record_show_anim) {
					let effect_hupai:number = 0; // 一炮多响采用头跳规则
					let seat:number = -1;
					let rongLst = [];
					for (let i:number = 0; i < infos.length; i++) {
						let _seat:number = infos[i]['seat'];
						DesktopMgr.Inst.setTingpai(_seat, []);
						rongLst.push(DesktopMgr.Inst.seat2LocalPosition(_seat));
						if (seat == -1) {
							seat = _seat;
						}
					}
					if (seat >= 0) {
						effect_hupai = DesktopMgr.Inst.player_effects[seat][game.EView.hupai_effect];
					}
					if (record_show_anim || isPaipu) {
						uiscript.UI_Huleshow.Inst.showRong(rongLst);
					} 
					current_time += record_show_anim || isPaipu ? 1200 : 200;
					if (record_show_anim) {
						Laya.timer.once(current_time, this, () => {
							for (let i: number = 0; i < infos.length; i++) {
								let _seat: number = infos[i]['seat'];
								DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(_seat)].onXuezhanMidHule(false, mjcore.MJPai.Create(infos[i]['hu_tile']), false);
							}
							DesktopMgr.Inst.lastqipai.isxuezhanhu = true;
							DesktopMgr.Inst.lastqipai.OnChoosedPai();
							let huType = data['liqi'] && data['liqi']['failed'] ? 3 : (view.DesktopMgr.Inst.isLastPaiMingPai() ? 2 : 0); //立直失败不要播特效里的牌动画
							DesktopMgr.Inst.ShowHuleEffect(DesktopMgr.Inst.lastqipai, DesktopMgr.Inst.lastqipai.model.transform, effect_hupai, DesktopMgr.Inst.lastpai_seat, huType);
						});
					}
					
						
				}
				// current_time += 2000;
				
				Laya.timer.once(current_time, this, ()=>{
					for (let player of DesktopMgr.Inst.players) {
						player.hideLiqi();
					}
					if (data['liqi']) {
						ActionLiqi.play(data['liqi']);
					} else {
						uiscript.UI_DesktopInfo.Inst.setLiqibang(0);
					}
					
					let scoreInfos:Array<{title_id:number, score:number, delta:number}> = [];
					for (let i:number = 0; i < data['delta_scores'].length; i++) {
						let scoreChangeInfo = {title_id: 0, score: 0, delta:0};
						if (data['delta_scores'][i] > 0) {
							// 胡了取消振听
							if (i == DesktopMgr.Inst.seat) {
								uiscript.UI_TingPai.Inst.reset();
								uiscript.UI_TingPai.Inst.setZhengting(false);
							}
							
							uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_7', -1);
							scoreChangeInfo['delta'] = data['delta_scores'][i];
							for (let data of infos) {
								if (data['seat'] == i) {
									scoreChangeInfo['title_id'] = data['title_id'];
									break;
								}
							}
							// view.DesktopMgr.Inst.onRoundEnd(i, 1);
						} else if (data['delta_scores'][i] < 0) {
							scoreChangeInfo['delta'] = data['delta_scores'][i];
							uiscript.UI_DesktopInfo.Inst.changeHeadEmo(i, 'emoji_8', -1);
							
							// view.DesktopMgr.Inst.onRoundEnd(i, 0);
						}
						scoreChangeInfo['score'] = data['old_scores'][i];
						scoreInfos.push(scoreChangeInfo);
					}
					Laya.timer.once(200, this, ()=>{
						DesktopMgr.Inst.setScores(data['scores']);
					});
					
					
					if (!isPaipu || record_show_anim || isAutoPlay) {
						uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos);
					} else {
						uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos, Laya.Handler.create(this, () => {
							DesktopMgr.Inst.ActionRunComplete();
							if (uiscript.UI_Replay.Inst.enable) {
								uiscript.UI_Replay.Inst.resetLockingTime();
							}
						}));
					}
				});
				if (!isPaipu || record_show_anim || isAutoPlay) {
					current_time += 3000;
					Laya.timer.once(current_time, this, () => {
						DesktopMgr.Inst.ActionRunComplete();
					});
				}
				
			});
		}

		public static fastplay(data: game.IActionHuleXueZhanMid, usetime:number) {
			app.Log.log('ActionHule fastplay data:' + JSON.stringify(data));
			// view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.updateLastRoundRecord(data.hules);
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
			// DesktopMgr.Inst.gameing = false;
			// uiscript.UIMgr.Inst.ShowWin(data, false);

			let infos: Array<Object> = data['hules'];
			let current_time: number = 0;
			if (data['zhenting'] != undefined) {
                uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			
			// 胡牌的盖牌，胡的牌变红
			if (infos[0]['zimo']) {
				let seat: number = infos[0]['seat'];
				DesktopMgr.Inst.setTingpai(seat, []);
				let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];
				player.onXuezhanMidHule(true, mjcore.MJPai.Create(infos[0]['hu_tile']), true);
				if (seat == DesktopMgr.Inst.seat) {
					uiscript.UI_TingPai.Inst.reset();
					uiscript.UI_TingPai.Inst.setZhengting(false);
				}
			} else {
				let seat: number = -1;
				let rongLst = [];
				for (let i: number = 0; i < infos.length; i++) {
					let _seat: number = infos[i]['seat'];
					if (seat == DesktopMgr.Inst.seat) {
						uiscript.UI_TingPai.Inst.reset();
						uiscript.UI_TingPai.Inst.setZhengting(false);
					}
					DesktopMgr.Inst.setTingpai(_seat, []);
					rongLst.push(DesktopMgr.Inst.seat2LocalPosition(_seat));
					if (seat == -1) {
						seat = _seat;
					}
				}
				// uiscript.UI_Huleshow.Inst.showRong(rongLst);
				for (let i: number = 0; i < infos.length; i++) {
					let _seat: number = infos[i]['seat'];
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(_seat)].onXuezhanMidHule(false, mjcore.MJPai.Create(infos[i]['hu_tile']), true);
				}
				DesktopMgr.Inst.lastqipai.isxuezhanhu = true;
				DesktopMgr.Inst.lastqipai.OnChoosedPai();
			}

			// 收立直棒
			for (let player of DesktopMgr.Inst.players) {
				player.hideLiqi();
			}

			// 显示当前立直棒
			if (data['liqi']) {
				ActionLiqi.fastplay(data['liqi'], 0);
			} else {
				uiscript.UI_DesktopInfo.Inst.setLiqibang(0);
			}

			DesktopMgr.Inst.setScores(data['scores']);
		}

		public static record(data:any): number {
			this.play(data);
			return 6000;
		}

		public static fastrecord(data:any) {
			// view.BgmListMgr.stopBgm();
			// DesktopMgr.Inst.gameing = false;

			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			this.fastplay(data, 1000);
			// uiscript.UIMgr.Inst.ShowWin(data, false);
		}

		public static fastrecord_xuezhan(data: any, isAnim: boolean): number {
			if (DesktopMgr.Inst.mode == EMJMode.paipu && isAnim) {
				this.play(data);
				return 4000;
			}
			this.fastrecord(data);
			return 0;
		}

	}
}