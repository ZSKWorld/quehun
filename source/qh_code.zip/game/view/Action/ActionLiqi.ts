/**
* name 
*/
module view {
	export class ActionLiqi extends ActionBase {

		public static play(data: game.ILiQiSuccess): void {
			app.Log.log('ActionLiqi play data:' + JSON.stringify(data));
			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			Laya.timer.once(300, this, () => {
				let seat: number = data['seat'];
				let score: number = data['score'];
				let localseat: number = DesktopMgr.Inst.seat2LocalPosition(seat);
				if (data['failed']) {
					DesktopMgr.Inst.players[localseat].ShowLiqiFailed();
					view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(localseat, 0, true, true);
				} else {
					DesktopMgr.Inst.players[localseat].ShowLiqi(data, true);
				}
				DesktopMgr.Inst.players[localseat].SetScore(score, DesktopMgr.Inst.mainrole.score);
				uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
				if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
					uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, true);
				}
			});
		}

		public static fastplay(data: game.ILiQiSuccess, usetime: number): void {
			app.Log.log('ActionLiqi fastplay data:' + JSON.stringify(data));
			let seat: number = data['seat'];
			let score: number = data['score'];
			let localseat: number = DesktopMgr.Inst.seat2LocalPosition(seat);
			if (data['failed']) {
				DesktopMgr.Inst.players[localseat].ShowLiqiFailed(false);
				view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(localseat, 0, true, false);
			} else {
				DesktopMgr.Inst.players[localseat].ShowLiqi(data, false);
			}
			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			DesktopMgr.Inst.players[localseat].SetScore(score, DesktopMgr.Inst.mainrole.score);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
			if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
				uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, false);
			}
		}

		public static record(data: any): number {
			app.Log.log('ActionLiqi record data:' + JSON.stringify(data));
			this.play(data);
			return 0;
		}

		public static fastrecord(data: any): void {
			app.Log.log('ActionLiqi fastrecord data:' + JSON.stringify(data));
			this.fastplay(data, 0);
		}
	}
}