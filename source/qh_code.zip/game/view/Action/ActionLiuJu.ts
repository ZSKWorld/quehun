/**
* name 
*/
module view{
	export class ActionLiuJu extends ActionBase {
		
		public static play(data: game.IActionLiuJu) {
			app.Log.log('ActionLiuJu play data:' + JSON.stringify(data));
			DesktopMgr.Inst.gameing = false;
			uiscript.UI_PlayerInfo.Inst.hide();
			let current_time:number = 0;
			if (data['liqi']) {
				current_time = 1000;
				ActionLiqi.play(data['liqi']);
			} else {
				current_time = 500;
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			//三家和了
			if (data['type'] == mjcore.E_LiuJu.sanjiahule) {
				view.BgmListMgr.stopBgm();
				let _seat = data['seat'];
				Laya.timer.once(current_time, this, () => {
					let hules:Array<number> = [];
					for (let i:number = 0; i < 4; i++) {
						if (DesktopMgr.Inst.localPosition2Seat(i) != _seat) {
							hules.push(i);
						}
					}
					uiscript.UI_Huleshow.Inst.showRong(hules);
				});
				current_time += 1500;
				Laya.timer.once(current_time, this, ()=>{
					for (let i:number = 0; i < data['allplayertiles'].length; i++) {
						if (i == _seat) continue;
						let strHand:Array<string> = data['allplayertiles'][i].split('|');
						let hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < strHand.length; j++) hand.push(mjcore.MJPai.Create(strHand[j]));
						hand = hand.sort(mjcore.MJPai.Distance);
						DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].Huangpai(true, hand, false);
					}
				});
				current_time += 1000;
				Laya.timer.once(current_time, this, () => {
					this.showEnd(data);
					DesktopMgr.Inst.ActionRunComplete();
				});
			} else {
				Laya.timer.once(current_time, this, () => {
					view.BgmListMgr.stopBgm();
					if (data['hules_history']) {
						for (let info of data['hules_history']) {
							let seat = DesktopMgr.Inst.seat2LocalPosition(info['seat']);
							let hands: Array<mjcore.MJPai> = [];
							for (let hand of info['hand']) {
								hands.push(mjcore.MJPai.Create(hand));
							}
							hands = hands.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.players[seat].onXuezhanEnd(hands, false);
						}
					}
					let delay:number = 500;
					if (data['type'] == mjcore.E_LiuJu.jiuzhongjiupai) {
						let seat:number = data['seat'];
						let tiles:Array<string> = data['tiles'];
						let hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < tiles.length; j++) hand.push(mjcore.MJPai.Create(tiles[j]));
						hand = hand.sort(mjcore.MJPai.Distance);
						DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].Huangpai(true, hand, false);
					}
					if (data['type'] == mjcore.E_LiuJu.sijializhi && data['allplayertiles'] && data['allplayertiles'].length > 0) {
						for (let i:number = 0; i < data['allplayertiles'].length; i++) {
							let strHand:Array<string> = data['allplayertiles'][i].split('|');
							let hand:Array<mjcore.MJPai> = [];
							for (let j:number = 0; j < strHand.length; j++) hand.push(mjcore.MJPai.Create(strHand[j]));
							hand = hand.sort(mjcore.MJPai.Distance);
							DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].Huangpai(true, hand, false);
						}
						delay = 1000;
					}

					Laya.timer.once(delay, this, () => {
						this.showEnd(data);
						DesktopMgr.Inst.ActionRunComplete();
					});
				});
			}
		}

		public static fastplay(data:any, usetime:number) {
			app.Log.log('ActionLiuJu fastplay data:' + JSON.stringify(data));
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.gameing = false;
			uiscript.UI_PlayerInfo.Inst.hide();
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			let current_time:number = 0;
			if (data['liqi']) {
				ActionLiqi.fastplay(data['liqi'], 0);
			}
			if (data['type'] == mjcore.E_LiuJu.jiuzhongjiupai) {
				let seat:number = data['seat'];
				let tiles:Array<string> = data['tiles'];
				let hand:Array<mjcore.MJPai> = [];
				for (let j:number = 0; j < tiles.length; j++) hand.push(mjcore.MJPai.Create(tiles[j]));
				hand = hand.sort(mjcore.MJPai.Distance);
				DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].Huangpai(true, hand, true);
			}
			if (data['type'] == mjcore.E_LiuJu.sanjiahule) {
				let seat:number = data['seat'];
				for (let i:number = 0; i < data['allplayertiles'].length; i++) {
					if (i == seat) continue;
					let strHand:Array<string> = data['allplayertiles'][i].split('|');
					let hand:Array<mjcore.MJPai> = [];
					for (let j:number = 0; j < strHand.length; j++) hand.push(mjcore.MJPai.Create(strHand[j]));
					hand = hand.sort(mjcore.MJPai.Distance);
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].Huangpai(true, hand, false);
				}
			}
			
			this.showEnd(data);
		}

		public static record(data:any):number {
			app.Log.log('ActionLiuJu record data:' + JSON.stringify(data));
			this.play(data);
			return 4000;
		}

		public static fastrecord(data:any) {
			// this.play(data);
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.gameing = false;
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			this.showEnd(data);
		}

		private static showEnd(data) {
			let func = null;
			if (DesktopMgr.Inst.xuezhan && data['hules_history'] && data['hules_history'].length > 0) {
				func = Laya.Handler.create(this, ()=>{
					uiscript.UIMgr.Inst.ShowWin(data, false);
				});
				
			}
			uiscript.UIMgr.Inst.ShowLiuJu(data, func);
		}

	}
}