/**
* name 
*/
module view{
	export class ActionLockTile extends ActionBase {
        public static play(data:any) {
			app.Log.log('ActionLockTile play data:' + JSON.stringify(data));
			let seat:number = data['seat'];
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
            let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];
            if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			}
            if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
            DesktopMgr.Inst.setScores(data['scores']);
            
            if (data['lock_state'] == 0) {
                player.RevealFailed(pai);
            } else if (data['lock_state'] == 1) {
                player.PlaySound('act_locktile');    
            }
            if (data['lock_state'] == 3) {
                player.PlaySound('act_unveil'); 
                var nowPlayer = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)];
                nowPlayer.RevealFailed(pai);
                DesktopMgr.Inst.onRevealStateChange(DesktopMgr.Inst.lastpai_seat, false);
            } else {
                DesktopMgr.Inst.onRevealStateChange(seat, false);    
            }
            DesktopMgr.Inst.ActionRunComplete();
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
            
        }

        public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionLockTile fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
            let seat:number = data['seat'];
			if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
            let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)];

            if (data['operation'] && usetime != -1) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation'], usetime);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}

            DesktopMgr.Inst.setScores(data['scores']);
            
            if (data['lock_state'] == 0) {
                player.RevealFailed(pai, false);
            }
            if (data['lock_state'] == 3) {
                var nowPlayer = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)];
                nowPlayer.RevealFailed(pai, false);
                DesktopMgr.Inst.onRevealStateChange(DesktopMgr.Inst.lastpai_seat, false);
            } else {
                DesktopMgr.Inst.onRevealStateChange(seat, false);
            }
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
            
        }

        public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionLockTile record data:' + JSON.stringify(data));
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], false);
            DesktopMgr.Inst.setScores(data['scores']);
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(data['seat'])];
            let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
            if (data['lock_state'] == 0) {
                player.RevealFailed(pai);
            } else if (data['lock_state'] == 1) {
                player.PlaySound('act_locktile');    
            }
            if (data['lock_state'] == 3) {
                player.PlaySound('act_unveil'); 
                var nowPlayer = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)];
                nowPlayer.RevealFailed(pai);
                DesktopMgr.Inst.onRevealStateChange(DesktopMgr.Inst.lastpai_seat, false);
            } else {
                DesktopMgr.Inst.onRevealStateChange(data['seat'], false);
            }
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
            //等待翻牌完毕再刷新
            Laya.timer.once(400, this, () => {
                DesktopMgr.Inst.onTileChange();
            });
            return 1000;
        }

        public static fastrecord(data:any, usetime:number = -1) {
            app.Log.log('ActionLockTile record data:' + JSON.stringify(data));
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            DesktopMgr.Inst.setScores(data['scores']);
            if (data['doras']) view.DesktopMgr.Inst.WhenDoras(data['doras'], true);
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(data['seat'])];
            let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
            if (data['lock_state'] == 0) {
                player.RevealFailed(pai, false);
            }
            if (data['lock_state'] == 3) {
                var nowPlayer = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(DesktopMgr.Inst.lastpai_seat)];
                nowPlayer.RevealFailed(pai, false);
                DesktopMgr.Inst.onRevealStateChange(DesktopMgr.Inst.lastpai_seat, false);
            } else {
                DesktopMgr.Inst.onRevealStateChange(data['seat'], false);
            }
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
            DesktopMgr.Inst.onTileChange();
        }
    }
}