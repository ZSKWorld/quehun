/**
* ActionNewCard 辉夜模式额外卡牌 
*/
module view{
	export class ActionNewCard extends ActionBase {
        public static play(msg:any) {
			app.Log.log('ActionNewCard play data:' + JSON.stringify(msg));
            let wt:number = uiscript.UI_FightBegin.hide();
            Laya.timer.once(wt + 200, this, ()=>{
                uiscript.UI_DesktopInfo.Inst.OnNewCard(msg, true)
                DesktopMgr.Inst.ActionRunComplete();
            });
            return wt + 1000;
        }

        public static fastplay(msg:any, usetime:number) {
            app.Log.log('ActionNewCard fastplay data:' + JSON.stringify(msg));
            uiscript.UI_FightBegin.hide();
            uiscript.UI_DesktopInfo.Inst.OnNewCard(msg, false);
            DesktopMgr.Inst.ActionRunComplete();
            return 0;
        }

        public static record(msg:any) {
			app.Log.log('ActionNewCard record data:' + JSON.stringify(msg));
            let wt:number = uiscript.UI_FightBegin.hide();
            if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast) {
                uiscript.UI_DesktopInfo.Inst.OnNewCard(msg, true);
                wt += 1000;
            } else {
               uiscript.UI_DesktopInfo.Inst.OnNewCard(msg, false);
            }
            DesktopMgr.Inst.ActionRunComplete();
            
            return wt;
        }

        public static fastrecord(msg:any) {
			app.Log.log('ActionNewCard fastrecord data:' + JSON.stringify(msg));
            let wt:number = uiscript.UI_FightBegin.hide();
            
            uiscript.UI_DesktopInfo.Inst.OnNewCard(msg, false);
            DesktopMgr.Inst.ActionRunComplete();
            
            return 0;
        }
    }
}