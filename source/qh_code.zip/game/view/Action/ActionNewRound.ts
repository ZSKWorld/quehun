/**
* name 
*/
module view{
	export class ActionNewRound extends ActionBase {
		
		public static play(data: game.IActionNewRound) {
			app.Log.log('ActionNewRound play data:' + JSON.stringify(data));
			if (view.BgmListMgr.type == E_Bgm_Type.mj) {
				view.BgmListMgr.PlayMJBgm(view.BgmListMgr.playing_bgm);
			} else {
				view.BgmListMgr.PlayMJBgm();
			}
			
			DesktopMgr.Inst.index_change = data['chang'];
			DesktopMgr.Inst.index_chuanma_ju = data['ju_count'];
			DesktopMgr.Inst.index_ju = data['ju'];
			DesktopMgr.Inst.index_ben = data['ben'];
			DesktopMgr.Inst.index_player = data['ju'];
			DesktopMgr.Inst.gameing = true;
			DesktopMgr.Inst.left_tile_count = 69;
			if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi4) DesktopMgr.Inst.left_tile_count = 69;
			else if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) DesktopMgr.Inst.left_tile_count = 50;
			if (data['left_tile_count']) DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_DesktopInfo.Inst.OnNewCard(null, false);
				uiscript.UI_FieldSpell.Inst.closeCardDetail();
				uiscript.UI_FieldSpell.Inst.setZhuangState(DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat);
				uiscript.UI_FieldSpell.Inst.resetCounter();
			}
			DesktopMgr.Inst.ResetSpecialModes();
			uiscript.UI_DesktopInfo.Inst.ResetSpecialModes();
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.Reset();
			}
			// 发送表情数据
			uiscript.UI_DesktopInfo.Inst.logUpEmoInfo();
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			DesktopMgr.Inst.setAutoHule(false);
			DesktopMgr.Inst.setAutoMoQie(false);
			DesktopMgr.Inst.setAutoBaBei(false);
			DesktopMgr.Inst.setAutoNoFulu(false);
			uiscript.UI_DesktopInfo.Inst.resetFunc();
			uiscript.UI_TingPai.Inst.reset();
			//uiscript.UI_DesktopInfo.Inst.setChang(this.index_change, this.index_ju, this.index_ben);
			DesktopMgr.Inst.SetChangJuShow(DesktopMgr.Inst.index_change, DesktopMgr.Inst.index_ju, DesktopMgr.Inst.index_chuanma_ju);
			uiscript.UI_DesktopInfo.Inst.setBen(DesktopMgr.Inst.index_ben);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			uiscript.UI_DesktopInfo.Inst.reset_rounds();
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			for (let i:number = 0; i < 4; i++) {
				DesktopMgr.Inst.players[i].Reset();
				DesktopMgr.Inst.players[i].setSeat(view.DesktopMgr.Inst.localPosition2Seat(i));
			}
			DesktopMgr.Inst.RefreshPlayerIndicator();
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			DesktopMgr.Inst.setScores(data['scores']);
			DesktopMgr.Inst.md5 = data['md5'];
			DesktopMgr.Inst.sha256 = data['sha256'];
			DesktopMgr.Inst.saltSha256 = data['saltSha256'];
			DesktopMgr.Inst.salt = '';
			DesktopMgr.Inst.choosed_pai = null;
			DesktopMgr.Inst.dora = [];
			DesktopMgr.Inst.lastRoundRecord = [];
			let delay:number = 0;

			if (DesktopMgr.Inst.index_change == 0 && DesktopMgr.Inst.index_ju == 0 && DesktopMgr.Inst.index_ben == 0) {
				if (DesktopMgr.Inst.is_dora3_mode() && !DesktopMgr.Inst.is_muyu_mode()) {
					uiscript.UI_DesktopInfo.Inst.openDora3BeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_peipai_open_mode()) {
					uiscript.UI_DesktopInfo.Inst.openPeipaiOpenBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_muyu_mode()) {
					uiscript.UI_DesktopInfo.Inst.openMuyuOpenBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_shilian_mode()) {
					uiscript.UI_DesktopInfo.Inst.openShilianOpenBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_xiuluo_mode()) {
					uiscript.UI_DesktopInfo.Inst.openXiuluoOpenBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_top_match()) {
					uiscript.UI_DesktopInfo.Inst.openTopMatchOpenBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_jiuchao_mode()) {
					uiscript.UI_DesktopInfo.Inst.openJiuChaoBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_reveal_mode()) {
					uiscript.UI_DesktopInfo.Inst.openAnPaiBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_zhanxing_mode()) {
					uiscript.UI_DesktopInfo.Inst.openZhanxingBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_tianming_mode()) {
					uiscript.UI_DesktopInfo.Inst.openTianmingBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_yongchang_mode()) {
					uiscript.UI_DesktopInfo.Inst.openYongchangBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_hunzhiyiji_mode()) {
					uiscript.UI_DesktopInfo.Inst.openHunzhiyijiBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_wanxiangxiuluo_mode()) {
					uiscript.UI_DesktopInfo.Inst.openWanxiangxiuluoBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_beishuizhizhan_mode()) {
					uiscript.UI_DesktopInfo.Inst.openBeishuizhizhanBeginEffect();
					delay = 1300;
				}
				if (DesktopMgr.Inst.is_speical_mode()) {
					uiscript.UI_DesktopInfo.Inst.openSpecialBeginEffect();
					delay = 1300;
				}
			}
			if (DesktopMgr.Inst.is_chuanma_mode() && DesktopMgr.Inst.index_chuanma_ju == 0) {
				uiscript.UI_DesktopInfo.Inst.openChuanmaBeginEffect();
				delay = 1300;
			}
			 
			let al:boolean = false;
			if (data['al'] != undefined && data['al'] != null) {
				al = data['al'];
			}
			if (al) {
				uiscript.UI_AL.Show();
				delay = 1300;
			}
			Laya.timer.once(delay, this, ()=>{
				let hands: Array<mjcore.MJPai> = [];
				for (let i:number = 0; i < data['tiles'].length; i++) {
					hands.push(mjcore.MJPai.Create(data['tiles'][i]));
				}
				let open_tiles:Array<string> = [];
				let open_counts:Array<number> = [];
				if (data['opens']) {
					for (let i:number = 0; i < data['opens'].length; i++) {
						if (data['opens'][i].seat == DesktopMgr.Inst.seat) {
							open_tiles = data['opens'][i].tiles;
							open_counts = data['opens'][i].count;
							break;
						}
					}
				}
				DesktopMgr.Inst.mainrole.NewGame(hands, open_tiles, open_counts, false);
				if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
				
				for(let i = 1; i < 4; i++) {
					let seat = DesktopMgr.Inst.localPosition2Seat(i);
					if (seat != -1) {
						let _open_tiles:Array<string> = [];
						let _open_counts:Array<number> = [];
						if (data['opens']) {
							for (let j:number = 0; j < data['opens'].length; j++) {
								if (data['opens'][j].seat == seat) {
									_open_tiles = data['opens'][j].tiles;
									_open_counts = data['opens'][j].count;
									break;
								}
							}
						}
						(DesktopMgr.Inst.players[i] as ViewPlayer_Other).NewGame(13 + (seat == DesktopMgr.Inst.index_ju ? 1 : 0), _open_tiles, _open_counts, false, '');
					}
				}

				if (DesktopMgr.Inst.is_huansanzhang_mode()) {
					// 换三张在dora开之前
					Laya.timer.once(1500, this, () => {
						DesktopMgr.Inst.ActionRunComplete();
						ActionOperation.play(data['operation']);
					});
				} else {
					// 普通模式
					if (DesktopMgr.Inst.is_dora3_mode()) {
						Laya.timer.once(1000, this, ()=>{
							uiscript.UI_DesktopInfo.Inst.openDora3BeginShine();
						});
					}
					if (DesktopMgr.Inst.is_tianming_mode()) {
						for (let i = 0; i < 4; i++) {
							let seat = DesktopMgr.Inst.localPosition2Seat(i);
							if (seat != -1) {
								uiscript.UI_DesktopInfo.Inst.SetTianMingRate(DesktopMgr.Inst.localPosition2Seat(i), 5);
							}
						}
					}
					if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
						uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, true);
					}
					Laya.timer.once(1200, this, () => {
						if (data['doras'] && data['doras'].length > 0) {
							for (let i:number = 0; i < data['doras'].length; i++) {
								DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
								uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
							}
						} 
						for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
						if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
							let __data:Object = {tingpais: data.tingpais0, operation: data.operation};
							uiscript.UI_TingPai.Inst.setData0(__data);
						} else {
							let __data:Object = {tingpais: data['tingpais1']};
							uiscript.UI_TingPai.Inst.setData1(__data, false);
						}
						DesktopMgr.Inst.ActionRunComplete();
					});
					if (data['operation'] != undefined) {
						// 2404.9.30 记录对局库相关：对局开始后不能马上进行对局消息上发，这边增加1.5的延时
						// 问题来源：在开局快速设置了自动拔北的情况下，ActionNewRound会触发拔北操作，这种情况下会拔北失败
						Laya.timer.once(1500, this, () => {
							ActionOperation.play(data['operation']);
						});
					}
				}

				
			});

			DesktopMgr.Inst.fetchLinks();
		}

		public static fastplay(data:any, usetime:number) {
			app.Log.log('ActionNewRound fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			DesktopMgr.Inst.ResetSpecialModes();
			uiscript.UI_DesktopInfo.Inst.ResetSpecialModes();
			DesktopMgr.Inst.index_change = data['chang'];
			DesktopMgr.Inst.index_ju = data['ju'];
			DesktopMgr.Inst.index_ben = data['ben'];
			DesktopMgr.Inst.index_player = data['ju'];
			DesktopMgr.Inst.index_chuanma_ju = data['ju_count'];
			DesktopMgr.Inst.gameing = true;
			DesktopMgr.Inst.left_tile_count = 69;
			if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi4) DesktopMgr.Inst.left_tile_count = 69;
			else if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) DesktopMgr.Inst.left_tile_count = 50;
			if (data['left_tile_count']) DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			DesktopMgr.Inst.setAutoHule(false);
			DesktopMgr.Inst.setAutoMoQie(false);
			DesktopMgr.Inst.setAutoNoFulu(false);
			DesktopMgr.Inst.setAutoBaBei(false);
			uiscript.UI_DesktopInfo.Inst.resetFunc();
			uiscript.UI_TingPai.Inst.reset();
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_DesktopInfo.Inst.OnNewCard(null, false);
				uiscript.UI_FieldSpell.Inst.setZhuangState(DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat);
				uiscript.UI_FieldSpell.Inst.resetCounter();
			}
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.Reset();
			} 
			uiscript.UI_DesktopInfo.Inst.logUpEmoInfo();
			//uiscript.UI_DesktopInfo.Inst.setChang(this.index_change, this.index_ju, this.index_ben);
			DesktopMgr.Inst.SetChangJuShow(DesktopMgr.Inst.index_change, DesktopMgr.Inst.index_ju, DesktopMgr.Inst.index_chuanma_ju);
			uiscript.UI_DesktopInfo.Inst.setBen(DesktopMgr.Inst.index_ben);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			uiscript.UI_DesktopInfo.Inst.reset_rounds();
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			for (let i:number = 0; i < 4; i++) {
				DesktopMgr.Inst.players[i].Reset();
				DesktopMgr.Inst.players[i].setSeat(view.DesktopMgr.Inst.localPosition2Seat(i));
			}
			DesktopMgr.Inst.RefreshPlayerIndicator();
			DesktopMgr.Inst.RefreshPaiLeft();
			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			DesktopMgr.Inst.setScores(data['scores']);
			DesktopMgr.Inst.md5 = data['md5'];
			DesktopMgr.Inst.sha256 = data['sha256']
			DesktopMgr.Inst.saltSha256 = data['saltSha256'];
			DesktopMgr.Inst.salt = '';
			DesktopMgr.Inst.choosed_pai = null;
			DesktopMgr.Inst.dora = [];
			DesktopMgr.Inst.lastRoundRecord = [];
			let hands: Array<mjcore.MJPai> = [];
			for (let i:number = 0; i < data['tiles'].length; i++) {
				hands.push(mjcore.MJPai.Create(data['tiles'][i]));
			}
			let open_tiles:Array<string> = [];
			let open_counts:Array<number> = [];
			if (data['opens']) {
				for (let i:number = 0; i < data['opens'].length; i++) {
					if (data['opens'][i].seat == DesktopMgr.Inst.seat) {
						open_tiles = data['opens'][i].tiles;
						open_counts = data['opens'][i].count;
						break;
					}
				}
			}
			DesktopMgr.Inst.mainrole.NewGame(hands, open_tiles, open_counts, true);
			
			for(let i = 1; i < 4; i++) {
				let seat = DesktopMgr.Inst.localPosition2Seat(i);
				if (seat != -1) {
					let _open_tiles:Array<string> = [];
					let _open_counts:Array<number> = [];
					if (data['opens']) {
						for (let j:number = 0; j < data['opens'].length; j++) {
							if (data['opens'][j].seat == seat) {
								_open_tiles = data['opens'][j].tiles;
								_open_counts = data['opens'][j].count;
								break;
							}
						}
					}
					(DesktopMgr.Inst.players[i] as ViewPlayer_Other).NewGame(13 + (seat == DesktopMgr.Inst.index_ju ? 1 : 0), _open_tiles, _open_counts, true, '');
				}
			}
			
			// if (data['dora'] && data['dora'] != '') {
			// 	DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['dora']));
			// 	uiscript.UI_DesktopInfo.Inst.setDora(0, DesktopMgr.Inst.dora[0]);
			// }
			if(DesktopMgr.Inst.is_chuanma_mode()) {
				if (data['operation'] && usetime != -1) {
					Laya.timer.once(100, this, ()=>{
						ActionOperation.play(data['operation'], usetime + 100);
					});
				}
			} else if (DesktopMgr.Inst.is_huansanzhang_mode()) {
				// 换三张在dora开之前
				if (data['operation'] && usetime != -1) {
					Laya.timer.once(100, this, ()=>{
						ActionOperation.play(data['operation'], usetime + 100);
					});
				}
			} else {
				if (DesktopMgr.Inst.is_tianming_mode()) {
					for (let i = 0; i < 4; i++) {
						let seat = DesktopMgr.Inst.localPosition2Seat(i);
						if (seat != -1) {
							uiscript.UI_DesktopInfo.Inst.SetTianMingRate(DesktopMgr.Inst.localPosition2Seat(i), 5);
						}
					}
				}
				if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
					uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, false);
				}
				if (data['doras'] && data['doras'].length > 0) {
					for (let i:number = 0; i < data['doras'].length; i++) {
						DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
						uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
					}
				} 
				for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
				if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
					let __data:Object = {tingpais: data['tingpais0'], operation: data['operation']};
					uiscript.UI_TingPai.Inst.setData0(__data);
				} else {
					let __data:Object = {tingpais: data['tingpais1']};
					uiscript.UI_TingPai.Inst.setData1(__data, true);
				}

				if (data['operation'] && usetime != -1) {
					Laya.timer.once(100, this, ()=>{
						ActionOperation.play(data['operation'], usetime + 100);
					});
				}
			}

		}

		public static record(data:any, usetime:number = 0):number {
			app.Log.log('ActionNewRound record data:' + JSON.stringify(data));
			DesktopMgr.Inst.ClearOperationShow();
			if (view.BgmListMgr.type == E_Bgm_Type.mj) {
				view.BgmListMgr.PlayMJBgm(view.BgmListMgr.playing_bgm);
			} else {
				view.BgmListMgr.PlayMJBgm();
			}
			DesktopMgr.Inst.ResetSpecialModes();
			uiscript.UI_DesktopInfo.Inst.ResetSpecialModes();
			DesktopMgr.Inst.index_change = data['chang'];
			DesktopMgr.Inst.index_ju = data['ju'];
			DesktopMgr.Inst.index_ben = data['ben'];
			DesktopMgr.Inst.index_player = data['ju'];
			DesktopMgr.Inst.index_chuanma_ju = data['ju_count'];
			DesktopMgr.Inst.gameing = true;
			DesktopMgr.Inst.left_tile_count = 69;
			if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi4) DesktopMgr.Inst.left_tile_count = 69;
			else if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) DesktopMgr.Inst.left_tile_count = 50;
			if (data['left_tile_count']) DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			DesktopMgr.Inst.tingpais = [[], [], [], []];
			uiscript.UI_TingPai.Inst.reset();
			uiscript.UI_Replay.Inst.reset();
			DesktopMgr.Inst.SetChangJuShow(DesktopMgr.Inst.index_change, DesktopMgr.Inst.index_ju, DesktopMgr.Inst.index_chuanma_ju);
			DesktopMgr.Inst.refreshSeatOnNewRound();
			uiscript.UI_DesktopInfo.Inst.setBen(DesktopMgr.Inst.index_ben);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			for (let i:number = 0; i < 4; i++) {
				DesktopMgr.Inst.players[i].setSeat(view.DesktopMgr.Inst.localPosition2Seat(i));
			}

			DesktopMgr.Inst.RefreshPlayerIndicator();
			DesktopMgr.Inst.RefreshPaiLeft();
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_DesktopInfo.Inst.OnNewCard(null, false);
				uiscript.UI_FieldSpell.Inst.closeCardDetail();
				uiscript.UI_FieldSpell.Inst.setZhuangState(DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat);
				uiscript.UI_FieldSpell.Inst.resetCounter();
			}
			
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.Reset();
			}
			DesktopMgr.Inst.choosed_pai = null;
			DesktopMgr.Inst.dora = [];
			AudioMgr.PlayAudio(216);
			for (let i:number = 0; i < 4; i++) {
				let hands: Array<mjcore.MJPai> = [];
				let st:string = 'tiles' + i.toString();
				if (data[st] && data[st].length > 0) {
					for (let j:number = 0; j < data[st].length; j++) {
						hands.push(mjcore.MJPai.Create(data[st][j]));
					}
					let _open_tiles:Array<string> = [];
					let _open_counts:Array<number> = [];
					if (data['opens']) {
						for (let j:number = 0; j < data['opens'].length; j++) {
							if (data['opens'][j].seat == i) {
								_open_tiles = data['opens'][j].tiles;
								_open_counts = data['opens'][j].count;
								break;
							}
						}
					}
					if (i == DesktopMgr.Inst.seat) DesktopMgr.Inst.mainrole.RecordNewGame(hands, _open_tiles, _open_counts);
					else (DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)] as ViewPlayer_Other).RecordNewGame(hands, _open_tiles, _open_counts);
				}
			}

			// if (DesktopMgr.Inst.index_change == 0 && DesktopMgr.Inst.index_ju == 0 && DesktopMgr.Inst.index_ben == 0) {
			// 	DesktopMgr.Inst.playGameVoice(DesktopMgr.Inst.seat, 'ingame_start');
			// }

			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			DesktopMgr.Inst.setScores(data['scores']);
			DesktopMgr.Inst.md5 = data['md5'];
			DesktopMgr.Inst.sha256 = data['sha256']
			DesktopMgr.Inst.saltSha256 = data['saltSha256'];
			DesktopMgr.Inst.salt = data['salt'];
			uiscript.UI_DesktopInfo.Inst.reset_rounds();
			
			
			if (DesktopMgr.Inst.is_huansanzhang_mode()) {
				// 换三张在dora开之前
				let d = data['operations'][view.DesktopMgr.Inst.localPosition2Seat(view.DesktopMgr.Inst.seat)];
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
					if (d) {
						ActionOperation.ob(d, usetime, 1000);
					}
				}
			} else {
				if (DesktopMgr.Inst.is_tianming_mode()) {
					for (let i = 0; i < 4; i++) {
						let seat = DesktopMgr.Inst.localPosition2Seat(i);
						if (seat != -1) {
							uiscript.UI_DesktopInfo.Inst.SetTianMingRate(DesktopMgr.Inst.localPosition2Seat(i), 5);
						}
					}
				}
				if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
					uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, true);
				}
				if (data['doras'] && data['doras'].length > 0) {
					for (let i:number = 0; i < data['doras'].length; i++) {
						DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
						uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
					}
				} else if (data['dora'] && data['dora'] != '') {
					DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['dora']));
					uiscript.UI_DesktopInfo.Inst.setDora(0, DesktopMgr.Inst.dora[0]);
				}
				for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
				if (data['tingpai']) {
					for (let i:number = 0; i < data['tingpai'].length; i++) {
						if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
							DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
						}
					}
				}
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
					if (data['operation']) {
						ActionOperation.ob(data['operation'], usetime, 1000);
					}
				}
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
				if (data['paishan']) {
					uiscript.UI_Replay.Inst.page_paishan.setTiles(data['paishan']);
					uiscript.UI_Replay.Inst.page_paishan.refresh();
				} else {
					uiscript.UI_Replay.Inst.page_paishan.setNoInfo();
				}
			}
			
			return 300; 
		}

		public static fastrecord(data:any, usetime:number = -1) {
			app.Log.log('ActionNewRound fastrecord data:' + JSON.stringify(data));
			if (view.BgmListMgr.type == E_Bgm_Type.mj) {
				view.BgmListMgr.PlayMJBgm(view.BgmListMgr.playing_bgm);
			} else {
				view.BgmListMgr.PlayMJBgm();
			}
			DesktopMgr.Inst.ResetSpecialModes();
			uiscript.UI_DesktopInfo.Inst.ResetSpecialModes();
			DesktopMgr.Inst.ClearOperationShow();
			DesktopMgr.Inst.index_change = data['chang'];
			DesktopMgr.Inst.index_ju = data['ju'];
			DesktopMgr.Inst.index_ben = data['ben'];
			DesktopMgr.Inst.index_player = data['ju'];
			DesktopMgr.Inst.index_chuanma_ju = data['ju_count'];
			DesktopMgr.Inst.gameing = true;
			DesktopMgr.Inst.left_tile_count = 69;
			if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi4) DesktopMgr.Inst.left_tile_count = 69;
			else if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) DesktopMgr.Inst.left_tile_count = 50;
			if (data['left_tile_count']) DesktopMgr.Inst.left_tile_count = data['left_tile_count'];
			DesktopMgr.Inst.waiting_lingshang_deal_tile = false;
			DesktopMgr.Inst.tingpais = [[], [], [], []];
			uiscript.UI_TingPai.Inst.reset();
			uiscript.UI_Replay.Inst.reset();
			DesktopMgr.Inst.SetChangJuShow(DesktopMgr.Inst.index_change, DesktopMgr.Inst.index_ju, DesktopMgr.Inst.index_chuanma_ju);
			DesktopMgr.Inst.refreshSeatOnNewRound();
			uiscript.UI_DesktopInfo.Inst.setBen(DesktopMgr.Inst.index_ben);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			for (let i:number = 0; i < 4; i++) {
				DesktopMgr.Inst.players[i].setSeat(DesktopMgr.Inst.localPosition2Seat(i));
			}
			if (DesktopMgr.Inst.is_field_spell_mode()) {
				uiscript.UI_DesktopInfo.Inst.OnNewCard(null, false);
				uiscript.UI_FieldSpell.Inst.setZhuangState(DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat);
				uiscript.UI_FieldSpell.Inst.resetCounter();
			}
			
			if (DesktopMgr.Inst.is_zhanxing_mode()) {
				uiscript.UI_Astrology.Inst.Reset();
			}
			DesktopMgr.Inst.RefreshPlayerIndicator();
			DesktopMgr.Inst.RefreshPaiLeft();

			DesktopMgr.Inst.choosed_pai = null;
			DesktopMgr.Inst.dora = [];
			for (let i:number = 0; i < 4; i++) {
				let hands: Array<mjcore.MJPai> = [];
				let st:string = 'tiles' + i.toString();
				if (data[st] && data[st].length > 0) {
					for (let j:number = 0; j < data[st].length; j++) {
						hands.push(mjcore.MJPai.Create(data[st][j]));
					}
					let _open_tiles:Array<string> = [];
					let _open_counts:Array<number> = [];
					if (data['opens']) {
						for (let j:number = 0; j < data['opens'].length; j++) {
							if (data['opens'][j].seat == i) {
								_open_tiles = data['opens'][j].tiles;
								_open_counts = data['opens'][j].count;
								break;
							}
						}
					}
					if (i == DesktopMgr.Inst.seat) DesktopMgr.Inst.mainrole.RecordNewGame(hands, _open_tiles, _open_counts);
					else (DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)] as ViewPlayer_Other).RecordNewGame(hands, _open_tiles, _open_counts);
				}
			}

			DesktopMgr.Inst.updateXiaKeShangInfo(data.xia_ke_shang);
			DesktopMgr.Inst.setScores(data['scores']);
			DesktopMgr.Inst.md5 = data['md5'];
			DesktopMgr.Inst.sha256 = data['sha256'];
			DesktopMgr.Inst.saltSha256 = data['saltSha256'];
			DesktopMgr.Inst.salt = data['salt'];
			uiscript.UI_DesktopInfo.Inst.reset_rounds();

			if (DesktopMgr.Inst.is_huansanzhang_mode()) {
				// 换三张在dora开之前
				let d = data['operations'][view.DesktopMgr.Inst.localPosition2Seat(view.DesktopMgr.Inst.seat)];
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
					if (d) {
						ActionOperation.ob(d, usetime, 1000);
					}
				}
			} else {
				if (DesktopMgr.Inst.is_tianming_mode()) {
					for (let i = 0; i < 4; i++) {
						let seat = DesktopMgr.Inst.localPosition2Seat(i);
						if (seat != -1) {
							uiscript.UI_DesktopInfo.Inst.SetTianMingRate(DesktopMgr.Inst.localPosition2Seat(i), 5);
						}
					}
				}
				if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
					uiscript.UI_DesktopInfo.Inst.RefreshXiaKeShangRate(data.xia_ke_shang, false);
				}
				if (data['doras'] && data['doras'].length > 0) {
					for (let i:number = 0; i < data['doras'].length; i++) {
						DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['doras'][i]));
						uiscript.UI_DesktopInfo.Inst.setDora(i, DesktopMgr.Inst.dora[i]);
					}
				} else if (data['dora'] && data['dora'] != '') {
					DesktopMgr.Inst.dora.push(mjcore.MJPai.Create(data['dora']));
					uiscript.UI_DesktopInfo.Inst.setDora(0, DesktopMgr.Inst.dora[0]);
				}
				for (let i:number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
				if (data['tingpai']) {
					for (let i:number = 0; i < data['tingpai'].length; i++) {
						if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
							DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
						}
					}
				}
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
					if (data['operation']) {
						ActionOperation.ob(data['operation'], usetime, 1000);
					}
				}
			}

			if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
				if (data['paishan']) {
					uiscript.UI_Replay.Inst.page_paishan.setTiles(data['paishan']);
					uiscript.UI_Replay.Inst.page_paishan.refresh();
				} else {
					uiscript.UI_Replay.Inst.page_paishan.setNoInfo();
				}
			}
			
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
		}

	}
}