/**
* name 
*/
module view{
	export class ActionNoTile extends ActionBase{
		
		public static play(data: game.IActionNoTile) {
			app.Log.log('ActionNotile play data:' + JSON.stringify(data));
			let waittime:number = 0;
			for (let i:number = 1; i < 4; i++) {
				let t:number = (view.DesktopMgr.Inst.players[i] as view.ViewPlayer_Other).discardcd - Laya.timer.currTimer;
				if (t > waittime) waittime = t;
			}
			waittime += 1000;
			Laya.timer.once(waittime, this, () => {
				view.BgmListMgr.stopBgm();
				let infos:Array<game.INoTilePlayerInfo> = data.players;
				DesktopMgr.Inst.gameing = false;
				uiscript.UI_PlayerInfo.Inst.hide();
				uiscript.UI_TingPai.Inst.reset();
				uiscript.UI_TingPai.Inst.setZhengting(false);
				if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, true);
				for (let i:number = 0; i < infos.length; i++) {
					let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)];
					let hand:Array<mjcore.MJPai> = [];
					for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
					hand = hand.sort(mjcore.MJPai.Distance);
					if (DesktopMgr.Inst.is_chuanma_mode()) {
						player.onChuanmaNoTile(hand, false);
					} else if (player.already_xuezhan_hule_state) {
						player.onXuezhanEnd(hand, false);
					} else {
						player.Huangpai(infos[i]['tingpai'], hand, false);
					}
				}
				Laya.timer.once(1000, this, () => {
					let need_wait = false;
					let have_taxes = false;
					let _lines:Array<string>;
					if (DesktopMgr.Inst.xuezhan || DesktopMgr.Inst.is_chuanma_mode()) {
						let haveScoreChange = false;
						
						if (data['scores'] && data['scores'].length > 0) {
							
							for (let i:number = 0; i < data['scores'].length; i++) {
								if (data['scores'][i].hasOwnProperty('delta_scores')) {
									for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['delta_scores'].length; j ++) {
										if (data['scores'][i]['delta_scores'][j] != 0) {
											haveScoreChange = true;
										}
									}
								}
								if (data['scores'][i].hasOwnProperty('taxes')) {
									for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['taxes'].length; j ++) {
										if (data['scores'][i]['taxes'][j] != 0) {
											have_taxes = true;
										}
									}
								}
							}
							_lines = data['scores'][0]['lines'];
						}
						let showWin = false;
						if (data['liujumanguan']) {
							showWin = true;
						}
						if (data['hules_history'] && data['hules_history'].length > 0) {
							showWin = true;
						}
						need_wait = !have_taxes && !haveScoreChange && !showWin;
					}
					uiscript.UI_Huleshow.Inst.showLiuJu(infos, Laya.Handler.create(this, ()=>{
						if (DesktopMgr.Inst.xuezhan || DesktopMgr.Inst.is_chuanma_mode()) {
							
							let haveScoreChange = false;
							let scoreInfos:Array<{score:number, title_id:number, delta:number}> = [];
						
							let taxScoreInfos:Array<{score:number, title_id:number, delta:number}> = [];
							if (data['scores'] && data['scores'].length > 0) {
								
								for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
									scoreInfos.push({score:view.DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].score, title_id:0, delta:0});
									taxScoreInfos.push({score:0, title_id:0, delta:0});
								}
								for (let i:number = 0; i < data['scores'].length; i++) {
									if (data['liujumanguan']) {
										scoreInfos[data['scores'][i]['seat']]['title_id'] = -1;
									}
									if (data['scores'][i].hasOwnProperty('delta_scores')) {
										for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['delta_scores'].length; j ++) {
											scoreInfos[j].delta += data['scores'][i]['delta_scores'][j];
										}
									}
									
									if (data['scores'][i].hasOwnProperty('taxes')) {
										for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['taxes'].length; j ++) {
											taxScoreInfos[j].delta += data['scores'][i]['taxes'][j];
										}
									}
								}
								if (view.DesktopMgr.Inst.is_chuanma_mode()) {
									for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
										if (scoreInfos[i].delta != 0) {
											haveScoreChange = true;
										}
										
										taxScoreInfos[i].score = scoreInfos[i].score + scoreInfos[i].delta;
									}
								} else {
									for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
										if (scoreInfos[i].delta != 0) {
											haveScoreChange = true;
										}
									}
								}
							}
							if (view.DesktopMgr.Inst.is_chuanma_mode() && have_taxes) {
								let self = this;
								let func = function () {
									let showWin = false;
									if (data['liujumanguan']) {
										showWin = true;
										uiscript.UIMgr.Inst.ShowWin(data['scores'], true);
									}
									if (data['hules_history'] && data['hules_history'].length > 0) {
										showWin = true;
										uiscript.UIMgr.Inst.ShowHistoryWin(data);
									}

									// 是否有人胡
									if (!showWin) {
										self.onXuezhanNoWinNext();
									} else {
										uiscript.UI_Hu_Xuezhan.Inst.close();
									}
								}
								
								if (haveScoreChange) {
									uiscript.UI_Huleshow.Inst.enable = false;
									uiscript.UI_Hu_Xuezhan.Inst.showTaxes(scoreInfos, taxScoreInfos, Laya.Handler.create(null, func),_lines);
								} else {
									uiscript.UI_Hu_Xuezhan.Inst.showTaxes(null, taxScoreInfos, Laya.Handler.create(null, func), _lines);
								}
								DesktopMgr.Inst.ActionRunComplete();
							} else {
								let self = this;
								let func = function () {
									let showWin = false;
									if (data['liujumanguan']) {
										showWin = true;
										uiscript.UIMgr.Inst.ShowWin(data['scores'], true);
									}
									if (data['hules_history'] && data['hules_history'].length > 0) {
										showWin = true;
										uiscript.UIMgr.Inst.ShowHistoryWin(data);
									}

									// 是否有人胡
									if (!showWin) {
										self.onXuezhanNoWinNext();
									} else {
										uiscript.UI_Hu_Xuezhan.Inst.close();
									}
								}

								if (haveScoreChange) {
									uiscript.UI_Huleshow.Inst.enable = false;
									uiscript.UI_Hu_Xuezhan.Inst.showScoreChange(scoreInfos, Laya.Handler.create(null, func), view.DesktopMgr.Inst.is_chuanma_mode(), _lines);
								} else {
									func();
								}
								DesktopMgr.Inst.ActionRunComplete();
							}
							
						} else {
							if (data['liujumanguan']) {
								uiscript.UIMgr.Inst.ShowWin(data['scores'], true);
							} else {
								let scores:Array<{old_score:number,delta:number}> = [];
								if (data['scores'] && data['scores'].length > 0) {
									for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
										scores.push({old_score: data['scores'][0]['old_scores'][i], delta: 0});
									}
									for (let i:number = 0; i < data['scores'].length; i++) {
										if (data['scores'][i].hasOwnProperty('delta_scores')) {
											for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['delta_scores'].length; j ++) {
												scores[j].delta += data['scores'][i]['delta_scores'][j];
											}
										}
									}
								} else {
									for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
										scores.push({old_score: view.DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].score, delta:0});
									}
								}
								
								uiscript.UI_ScoreChange.Inst.show(scores);
							}
							DesktopMgr.Inst.ActionRunComplete();
						}
					}), need_wait);
				});
			});
			
		}

		public static fastplay(data:any, usetime:number) {
			app.Log.log('ActionNewRound fastplay data:' + JSON.stringify(data));
			let waittime:number = 0;
			view.BgmListMgr.stopBgm();
			let infos:Array<Object> = data['players'];
			DesktopMgr.Inst.gameing = false;
			uiscript.UI_PlayerInfo.Inst.hide();
			let tings:Array<boolean> = [false,false,false,false];
			uiscript.UI_TingPai.Inst.reset();
			uiscript.UI_TingPai.Inst.setZhengting(false);
			for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
				let hand:Array<mjcore.MJPai> = [];
				for (let j:number = 0; j < infos[i]['hand'].length; j++) hand.push(mjcore.MJPai.Create(infos[i]['hand'][j]));
				hand = hand.sort(mjcore.MJPai.Distance);
				DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].Huangpai(infos[i]['tingpai'], hand, true);
				tings[DesktopMgr.Inst.seat2LocalPosition(i)] = infos[i]['tingpai'];
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			if (data['liujumanguan']) {
					uiscript.UIMgr.Inst.ShowWin(data['scores'], true);
			} else {
				let scores:Array<{old_score:number,delta:number}> = [];
				if (data['scores'] && data['scores'].length > 0) {
					for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
						scores.push({old_score: data['scores'][0]['old_scores'][i], delta: 0});
					}
					for (let i:number = 0; i < data['scores'].length; i++) {
						if (data['scores'][i].hasOwnProperty('delta_scores')) {
							for (let j:number = 0; j < DesktopMgr.Inst.player_count && j < data['scores'][i]['delta_scores'].length; j ++) {
								scores[j].delta += data['scores'][i]['delta_scores'][j];
							}
						}
					}
				} else {
					for (let i:number = 0; i < DesktopMgr.Inst.player_count; i++) {
						scores.push({old_score: view.DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(i)].score, delta:0 });
					}
				}
				
				uiscript.UI_ScoreChange.Inst.show(scores);
			}
		}

		public static record(data:any): number {
			app.Log.log('ActionNewRound record data:' + JSON.stringify(data));
			this.play(data);
			return 8000;
		}

		public static fastrecord(data:any) {
			// this.play(data);
			view.BgmListMgr.stopBgm();
			DesktopMgr.Inst.gameing = false;
			let infos:Array<Object> = [];
			for (let i:number = 0; i < data['players'].length; i++) {
				infos.push({seat: i});
			}
			if (data.muyu) DesktopMgr.Inst.onMuyuChange(data.muyu, false);
			uiscript.UI_Huleshow.Inst.showLiuJu(infos, null);
		}

		// 血战模式下，没胡的荒牌处理
		private static onXuezhanNoWinNext() {
			if (view.DesktopMgr.Inst.mode == view.EMJMode.play) {
				if (view.DesktopMgr.Inst.gameEndResult != null) {
					uiscript.UI_Huleshow.Inst.enable = false;
					uiscript.UI_Hu_Xuezhan.Inst.enable = false;
					uiscript.UIMgr.Inst.ShowGameEnd();
				} else {
					view.DesktopMgr.Inst.Reset();
					Laya.timer.once(200, this, () => {
						if (!view.DesktopMgr.Inst.timestoped) {
							app.NetAgent.sendReq2MJ('FastTest', 'confirmNewRound', { }, (err, res) => {
							});
						} else {
							view.DesktopMgr.Inst.handles_after_timerun.push(Laya.Handler.create(this, ()=>{
								app.NetAgent.sendReq2MJ('FastTest', 'confirmNewRound', { }, (err, res) => {
								});
							}));
						}
					});
					
				}
			} else if (view.DesktopMgr.Inst.mode == view.EMJMode.paipu) {
				uiscript.UI_Replay.Inst.nextStep(true);
			} else if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast) {
				let dot_count:number = 0;
				uiscript.UI_Huleshow.Inst.enable = false;
				uiscript.UI_Live_Broadcast.Inst.onScoreChangeConfirm();
			}
		}
	}
}