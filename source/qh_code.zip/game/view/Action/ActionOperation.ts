/**
* name 
*/
module view{
	export class ActionOperation extends ActionBase {

		public static play(data: game.IOptionalOperationList, usetime:number = 0) {
			// if (DesktopMgr.Inst.duringReconnect) return ;
			app.Log.log('ActionOperation play data:' + JSON.stringify(data) + ' usetime:' + usetime);
			try{
				if (data) {
					DesktopMgr.Inst.mainrole.can_discard = false;
					let oplist:Array<game.IOptionalOperation> = data['operation_list'];
					if (oplist == null || oplist.length == 0) return ;
					DesktopMgr.Inst.oplist = oplist;
					let time_fixed:number = data['time_fixed'];
					let time_add:number = data['time_add'];
					time_fixed -= usetime;
					if (time_fixed < 0) {
						time_add += time_fixed;
						time_fixed = 0;
						if (time_add < 0) time_add = 0;
					}
					app.Log.log('ActionOperation time_fixed:' + time_fixed + ' time_add:' + time_add);
					if (time_fixed + time_add >= 2000) {
						if (DesktopMgr.Inst._PendingAuto()) {
							uiscript.UI_DesktopInfo.Inst.showCountDown(time_fixed, time_add);
						}
					}
				}
			} catch(e) {
				let _errorinfo:Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'play';
				_errorinfo['name'] = 'ActionOperation';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public static ob(data:any, usetime:number = 0, delay:number = 0) {
			app.Log.log('ActionOperation ob data:' + JSON.stringify(data) + ' usetime:' + usetime);
			let seat:number = data['seat'];
			if (seat != view.DesktopMgr.Inst.seat) return;
			Laya.timer.once(delay, this, ()=>{
				let time_fixed:number = data['time_fixed'];
				let time_add:number = data['time_add'];
				usetime -= 300;
				if (usetime < 0) usetime = 0;
				time_fixed -= usetime;
				if (time_fixed < 0) {
					time_add += time_fixed;
					time_fixed = 0;
					if (time_add < 0) time_add = 0;
				}
				if (time_fixed + time_add >= 2000) {
					let needshow_chipeng:boolean = false;
					let needshow_zimoangang:boolean = false;
					let needshow_huansanzhang:boolean = false;
					let needshow_selecttile: boolean = false;
					let can_discard:boolean = false;
					let oplist = data['operation_list'];
					for (let i:number = 0; i < oplist.length; i++) {
						let op_data = oplist[i];
						let op_type = op_data['type'];
						switch(op_type) {
							case mjcore.E_PlayOperation.eat:
							case mjcore.E_PlayOperation.peng:
							case mjcore.E_PlayOperation.ming_gang:
							case mjcore.E_PlayOperation.rong:
								needshow_chipeng = true;
								break;
							case mjcore.E_PlayOperation.an_gang:
							case mjcore.E_PlayOperation.add_gang:
							case mjcore.E_PlayOperation.liqi:
							case mjcore.E_PlayOperation.zimo:
							case mjcore.E_PlayOperation.babei:
							case mjcore.E_PlayOperation.revealliqi:
							case mjcore.E_PlayOperation.reveal:
							case mjcore.E_PlayOperation.locktile:
							case mjcore.E_PlayOperation.jiuzhongjiupai:
								needshow_zimoangang = true;
								break;
							case mjcore.E_PlayOperation.huansanzhang:
								needshow_huansanzhang = true;
								break;
							case mjcore.E_PlayOperation.po_tribute_choose_tile:
								needshow_huansanzhang = true;
								break;
							case mjcore.E_PlayOperation.selecttile:
								needshow_selecttile = true;
								break;
						}
						if (op_type == mjcore.E_PlayOperation.dapai || op_type == mjcore.E_PlayOperation.liqi) {
							can_discard = true;
						}
					}

					if (needshow_zimoangang) uiscript.UIMgr.Inst.ShowLiqiZimo(oplist);
					if (needshow_chipeng) uiscript.UIMgr.Inst.ShowChipenghu(oplist);
					// if (needshow_huansanzhang) uiscript.UI_HuanSanZhange.Inst.show();
					if (needshow_chipeng || needshow_zimoangang || can_discard || needshow_huansanzhang || needshow_selecttile) {
						uiscript.UI_DesktopInfo.Inst.showCountDown(time_fixed, time_add);
					}
					
					
					if (needshow_selecttile) {
						uiscript.UI_Astrology.Inst.showSelections();
					}
				}
			});
			
		}
	}
}