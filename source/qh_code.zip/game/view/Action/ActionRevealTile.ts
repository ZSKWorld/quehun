/**
* name 
*/
module view{
	export class ActionRevealTile extends ActionBase {
        public static play(data:any): void {
			app.Log.log('ActionRevealTile play data:' + JSON.stringify(data));
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], true, seat == view.DesktopMgr.Inst.seat ? ERevealState.self : ERevealState.reveal);
			if (liqi) {
				if (data['is_wliqi']) {
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_drich_anpai');
				} else {
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_rich_anpai');
				}				
				let liqi_bgm_id:number = DesktopMgr.Inst.player_effects[seat][game.EView.lizhi_bgm];
				if (liqi_bgm_id && liqi_bgm_id != 0) {
					let bgm:string = cfg.item_definition.item.get(liqi_bgm_id).sargs[0];
					if (view.AudioMgr.lizhiMuted) {
						view.AudioMgr.PlayLiqiBgm(bgm, 300, true);
					} else {
						view.BgmListMgr.stopBgm();
						Laya.timer.once(1000, this, ()=>{
							if (DesktopMgr.Inst.gameing) {
								view.BgmListMgr.PlayMJBgm('', true);
								view.AudioMgr.PlayLiqiBgm(bgm, 300, true);
							}
						});
					}
				}
			} 

			
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, false, false, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onDiscardTile(data['moqie'], data['tile'], false, false);
			}
			if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, false);
			Laya.timer.once(500, this, () => {
				if (liqi) DesktopMgr.Inst.clearMindVoice();
				else DesktopMgr.Inst.playMindVoice();
			});
            DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			DesktopMgr.Inst.onRevealStateChange(seat, true);
		}

		public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionRevealTile fastplay data:' + JSON.stringify(data) + ' usetime:' + usetime);
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);

			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], false, seat == view.DesktopMgr.Inst.seat ? ERevealState.self : ERevealState.reveal);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, false, true, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).onDiscardTile(data['moqie'], data['tile'], false, true);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation'], usetime);
				});
			} 
			if (data['zhenting'] != undefined && data['operation'] == undefined) {
				uiscript.UI_DesktopInfo.Inst.setZhenting(data['zhenting']);
				uiscript.UI_TingPai.Inst.setZhengting(data['zhenting']);
			}
			if (seat == DesktopMgr.Inst.seat) uiscript.UI_TingPai.Inst.setData1(data, true);
            DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
			DesktopMgr.Inst.onRevealStateChange(seat, true);
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionRevealTile record data:' + JSON.stringify(data));
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'])
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);
			let state = (view.DesktopMgr.Inst.record_show_hand || seat == view.DesktopMgr.Inst.seat) ? ERevealState.self : ERevealState.reveal;
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], true, state);
			if (liqi) {
				if (data['is_wliqi']) {
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_drich_anpai');
				} else {
					DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].PlaySound('act_rich_anpai');
				}
				uiscript.UI_DesktopInfo.Inst.changeHeadEmo(seat, 'emoji_9', 2000);
			} 
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, false, false, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordDiscardTile(pai, data['moqie'], false, false);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
			DesktopMgr.Inst.onRevealStateChange(seat, true);
			return 1000;
		}

		public static fastrecord(data: any, usetime:number = -1) {
			app.Log.log('ActionRevealTile fastrecord data:' + JSON.stringify(data));
			let seat:number = data['seat'];
			let pai:mjcore.MJPai = mjcore.MJPai.Create(data['tile'] ? data['tile'] : '5z');
			let liqi:boolean = !(data['is_liqi'] == null || data['is_liqi'] == undefined || !data['is_liqi']);
			let state = (view.DesktopMgr.Inst.record_show_hand || seat == view.DesktopMgr.Inst.seat) ? ERevealState.self : ERevealState.reveal;
			DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)].AddQiPai(pai, liqi, data['moqie'], false, state);
			if (seat == DesktopMgr.Inst.seat) {
				DesktopMgr.Inst.mainrole.OnDiscardTile(pai, false, true, data['moqie']);
			} else {
				(DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(seat)] as ViewPlayer_Other).recordDiscardTile(pai, data['moqie'], false, true);
			}
			if (data['tingpais']) {
				DesktopMgr.Inst.setTingpai(data['seat'], data['tingpais']);
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            DesktopMgr.Inst.setScores(data['scores']);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
			DesktopMgr.Inst.onRevealStateChange(seat, true);
		}
    }
}