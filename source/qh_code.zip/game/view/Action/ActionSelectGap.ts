/**
* name 
*/
module view {
	export class ActionSelectGap extends ActionBase{

		public static play(data:any): void {
			app.Log.log('ActionSelectGap play data:' + JSON.stringify(data));
			for (let i:number = 0; i < data['gap_types'].length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[view.DesktopMgr.Inst.seat2LocalPosition(i)];
				p.SetGapType(data['gap_types'][i]);
			}
            uiscript.UI_DesktopInfo.Inst.setGapType(data['gap_types'], true);
			if (uiscript.UI_Dingque.Inst.enable) uiscript.UI_Dingque.Inst.close();
			
			Laya.timer.once(500, this, ()=>{
				if (DesktopMgr.Inst.is_dora3_mode()) {
					uiscript.UI_DesktopInfo.Inst.openDora3BeginShine();
				}
				Laya.timer.once(200, this, () => {
					if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
						let __data:Object = {tingpais: data['tingpais0'], operation: data['operation']};
						uiscript.UI_TingPai.Inst.setData0(__data);
					} else {
						let __data:Object = {tingpais: data['tingpais1']};
						uiscript.UI_TingPai.Inst.setData1(__data, false);
					}
					DesktopMgr.Inst.ActionRunComplete();
				});
				if (data['operation'] != undefined) {
					ActionOperation.play(data['operation']);
				}
			});
		}

		public static fastplay(data:any, usetime:number): void {
			app.Log.log('ActionChangeTile fastplay data:' + JSON.stringify(data));
			for (let i:number = 0; i < data['gap_types'].length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[view.DesktopMgr.Inst.seat2LocalPosition(i)];
				p.SetGapType(data['gap_types'][i]);
			}
            uiscript.UI_DesktopInfo.Inst.setGapType(data['gap_types']);
			if (uiscript.UI_Dingque.Inst.enable) uiscript.UI_Dingque.Inst.close();

			if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
				let __data:Object = {tingpais: data['tingpais0'], operation: data['operation']};
				uiscript.UI_TingPai.Inst.setData0(__data);
			} else {
				let __data:Object = {tingpais: data['tingpais1']};
				uiscript.UI_TingPai.Inst.setData1(__data, false);
			}
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(100, this, ()=>{
					ActionOperation.play(data['operation'], usetime + 100);
				});
			}
		}

		public static record(data: any, usetime:number = 0): number {
			app.Log.log('ActionChangeTile record data:' + JSON.stringify(data));
			for (let i:number = 0; i < data['gap_types'].length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[view.DesktopMgr.Inst.seat2LocalPosition(i)];
				p.SetGapType(data['gap_types'][i]);
			}
            uiscript.UI_DesktopInfo.Inst.setGapType(data['gap_types'], true);
			if (uiscript.UI_Dingque.Inst.enable) uiscript.UI_Dingque.Inst.close();
			Laya.timer.once(500, this, ()=>{
				if (data['tingpai']) {
					for (let i:number = 0; i < data['tingpai'].length; i++) {
						if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
							DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
						}
					}
				}
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
					if (data['operation']) {
						ActionOperation.ob(data['operation'], usetime, 1000);
					}
				}
			});
			return 1300;
		}

		public static fastrecord(data: any, usetime:number = -1): void {
			for (let i:number = 0; i < data['gap_types'].length; i++) {
				let p:ViewPlayer = DesktopMgr.Inst.players[view.DesktopMgr.Inst.seat2LocalPosition(i)];
				p.SetGapType(data['gap_types'][i]);
			}
            uiscript.UI_DesktopInfo.Inst.setGapType(data['gap_types']);
			if (uiscript.UI_Dingque.Inst.enable) uiscript.UI_Dingque.Inst.close();
			if (data['tingpai']) {
				for (let i:number = 0; i < data['tingpai'].length; i++) {
					if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
						DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
					}
				}
			}
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime, 1000);
				}
			}
		}
	}
}