/**
* name 
*/
module view {
	export class ActionSubmit extends ActionBase {

		public static play(data: game.IActionSubmit): void {
			app.Log.log('ActionSubmit play data:' + JSON.stringify(data));
			this.desktopMgr.updateRetributeState(true);
			const submitTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.submits.length; i++) {
				const submitInfo = data.submits[i];
				if (submitInfo.groups.length > 0) {
					const seat = DesktopMgr.Inst.seat2LocalPosition(submitInfo.submit_seat);
					DesktopMgr.Inst.players[seat].submitTile(submitInfo);
					submitTiles[seat] = this.handleSubmitTile(submitInfo);
				}
			}
			Laya.timer.once(500, this, () => {
				for (let i = 0; i < submitTiles.length; i++) {
					const tiles = submitTiles[i];
					if (tiles.length > 0) {
						DesktopMgr.Inst.players[i].submitHandTile(tiles);
					}
				}
				this.desktopMgr.ActionRunComplete();
			});
		}

		public static fastplay(data: any, usetime: number): void {
			app.Log.log('ActionSubmit fastplay data:' + JSON.stringify(data));
			this.desktopMgr.updateRetributeState(true);
			for (let i = 0; i < data.submits.length; i++) {
				const submitInfo = data.submits[i];
				if (submitInfo.groups.length > 0) {
					const seat = DesktopMgr.Inst.seat2LocalPosition(submitInfo.submit_seat);
					DesktopMgr.Inst.players[seat].submitTile(submitInfo, true);
					DesktopMgr.Inst.players[seat].submitHandTile(this.handleSubmitTile(submitInfo), true);
				}
			}
		}

		public static record(data: game.IRecordSubmit, usetime: number = 0): number {
			app.Log.log('ActionSubmit record data:' + JSON.stringify(data));
			this.desktopMgr.updateRetributeState(true);
			const submitTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.submits.length; i++) {
				const submitInfo = data.submits[i];
				if (submitInfo.groups.length > 0) {
					const seat = DesktopMgr.Inst.seat2LocalPosition(submitInfo.submit_seat);
					DesktopMgr.Inst.players[seat].submitTile(submitInfo);
					submitTiles[seat] = this.handleSubmitTile(submitInfo);
				}
			}
			Laya.timer.once(500, this, () => {
				for (let i = 0; i < submitTiles.length; i++) {
					const tiles = submitTiles[i];
					if (tiles.length > 0) {
						DesktopMgr.Inst.players[i].submitHandTile(tiles);
					}
				}
			});
			return 500;
		}

		public static fastrecord(data: game.IRecordSubmit, usetime: number = -1): void {
			app.Log.log('ActionSubmit fastrecord data:' + JSON.stringify(data));
			this.desktopMgr.updateRetributeState(true);
			for (let i = 0; i < data.submits.length; i++) {
				const submitInfo = data.submits[i];
				if (submitInfo.groups.length > 0) {
					const seat = DesktopMgr.Inst.seat2LocalPosition(submitInfo.submit_seat);
					DesktopMgr.Inst.players[seat].submitTile(submitInfo, true);
					DesktopMgr.Inst.players[seat].submitHandTile(this.handleSubmitTile(submitInfo), true);
				}
			}
		}

		public static handleSubmitTile(submitInfo: game.ISubmitInfo): string[] {
			let tiles = [];
			for (let i = 0; i < submitInfo.groups.length; i++) {
				let groupInfo = submitInfo.groups[i];
				for (let j = 0; j < groupInfo.count; j++) {
					let tile = '7z';
					if (groupInfo.tiles[j]) {
						tile = groupInfo.tiles[j];
					}
					tiles.push(tile);
				}
			}
			return tiles;
		}
	}
}