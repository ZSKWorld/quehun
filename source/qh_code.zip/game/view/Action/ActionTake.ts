/**
* name 
*/
module view {
	export class ActionTake extends ActionBase {

		public static play(data: game.IActionTake): void {
			app.Log.log('ActionTake play data:' + JSON.stringify(data));

			let fromDatas: game.ITakeInfo[][] = [[], [], [], []];
			let takeTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.takes.length; i++) {
				let info = data.takes[i];
				fromDatas[DesktopMgr.Inst.seat2LocalPosition(info.from_seat)].push(info);
				for (let j = 0; j < info.count; j++) {
					let tile = '7z';
					let seat = DesktopMgr.Inst.seat2LocalPosition(info.take_seat);
					if (info.tiles[j] && seat == 0) {
						tile = info.tiles[j];
					}
					takeTiles[seat].push(tile);
				}
			}
			let delay = 0;
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let fromInfos: game.ITakeInfo[] = fromDatas[i];
				if (fromInfos.length > 0) {
					this.sortTakeInfos(i, fromInfos);
					// 表演牌转移动画
					DesktopMgr.Inst.players[i].takeTile(fromInfos);
				}
			}
			delay = delay + 1800;
			Laya.timer.once(delay, this, () => {
				for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
					let tiles: string[] = takeTiles[i];
					if (tiles.length > 0) {
						DesktopMgr.Inst.players[i].takeHandTile(tiles);
					}
				}
			});
			delay = delay + 500;
			Laya.timer.once(delay, this, () => {
				if (data['operation'] != undefined) {
					ActionOperation.play(data['operation']);
				}
				for (let i: number = 0; i < 4; i++) DesktopMgr.Inst.players[i].OnDoraRefresh();
				if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
					let __data: Object = { tingpais: data['tingpais0'], operation: data['operation'] };
					uiscript.UI_TingPai.Inst.setData0(__data);
				} else {
					let __data: Object = { tingpais: data['tingpais1'] };
					uiscript.UI_TingPai.Inst.setData1(__data, false);
				}
				DesktopMgr.Inst.updateRetributeState(false);
				DesktopMgr.Inst.ActionRunComplete();
			});
		}

		public static fastplay(data: any, usetime: number): void {
			app.Log.log('ActionTake fastplay data:' + JSON.stringify(data));
			let fromDatas: game.ITakeInfo[][] = [[], [], [], []];
			let takeTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.takes.length; i++) {
				let info = data.takes[i];
				fromDatas[DesktopMgr.Inst.seat2LocalPosition(info.from_seat)].push(info);
				for (let j = 0; j < info.count; j++) {
					let tile = '7z';
					let seat = DesktopMgr.Inst.seat2LocalPosition(info.take_seat);
					if (info.tiles[j] && seat == 0) {
						tile = info.tiles[j];
					}
					takeTiles[seat].push(tile);
				}
			}
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let fromInfos: game.ITakeInfo[] = fromDatas[i];
				if (fromInfos.length > 0) {
					this.sortTakeInfos(i, fromInfos);
					// 表演牌转移动画
					DesktopMgr.Inst.players[i].takeTile(fromInfos, true);
				}
			}
			// 关闭箭头，发牌到手牌
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let tiles: string[] = takeTiles[i];
				if (tiles.length > 0) {
					DesktopMgr.Inst.players[i].takeHandTile(tiles, true);
				}
			}
			if (DesktopMgr.Inst.index_ju == DesktopMgr.Inst.seat) {
				let __data: Object = { tingpais: data['tingpais0'], operation: data['operation'] };
				uiscript.UI_TingPai.Inst.setData0(__data);
			} else {
				let __data: Object = { tingpais: data['tingpais1'] };
				uiscript.UI_TingPai.Inst.setData1(__data, false);
			}
			DesktopMgr.Inst.updateRetributeState(false);
			if (data['operation'] && usetime != -1) {
				Laya.timer.once(100, this, () => {
					ActionOperation.play(data['operation'], usetime + 100);
				});
			}
		}

		public static record(data: any, usetime: number = 0): number {
			app.Log.log('ActionTake record data:' + JSON.stringify(data));
			let fromDatas: game.ITakeInfo[][] = [[], [], [], []];
			let takeTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.takes.length; i++) {
				let info = data.takes[i];
				fromDatas[DesktopMgr.Inst.seat2LocalPosition(info.from_seat)].push(info);
				for (let j = 0; j < info.count; j++) {
					let tile = '7z';
					let seat = DesktopMgr.Inst.seat2LocalPosition(info.take_seat);
					if (info.tiles[j]) {
						tile = info.tiles[j];
					}
					takeTiles[seat].push(tile);
				}
			}
			let delay = 0;
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let fromInfos: game.ITakeInfo[] = fromDatas[i];
				if (fromInfos.length > 0) {
					this.sortTakeInfos(i, fromInfos);
					// 表演牌转移动画
					DesktopMgr.Inst.players[i].takeTile(fromInfos);
				}
			}
			delay = delay + 1800;
			Laya.timer.once(delay, this, () => {
				for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
					let tiles: string[] = takeTiles[i];
					if (tiles.length > 0) {
						DesktopMgr.Inst.players[i].takeHandTile(tiles);
					}
				}
			});
			delay = delay + 500;
			Laya.timer.once(delay, this, () => {
				if (data['tingpai']) {
					for (let i: number = 0; i < data['tingpai'].length; i++) {
						if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
							DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
						}
					}
				}
				DesktopMgr.Inst.updateRetributeState(false);
				if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
					if (data['operation']) {
						ActionOperation.ob(data['operation'], usetime, 1000);
					}
				}
			});
			return 2300;
		}

		public static fastrecord(data: any, usetime: number = -1): void {
			let fromDatas: game.ITakeInfo[][] = [[], [], [], []];
			let takeTiles: string[][] = [[], [], [], []];
			for (let i = 0; i < data.takes.length; i++) {
				let info = data.takes[i];
				fromDatas[DesktopMgr.Inst.seat2LocalPosition(info.from_seat)].push(info);
				for (let j = 0; j < info.count; j++) {
					let tile = '7z';
					let seat = DesktopMgr.Inst.seat2LocalPosition(info.take_seat);
					if (info.tiles[j]) {
						tile = info.tiles[j];
					}
					takeTiles[seat].push(tile);
				}
			}
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let fromInfos: game.ITakeInfo[] = fromDatas[i];
				if (fromInfos.length > 0) {
					this.sortTakeInfos(i, fromInfos);
					// 表演牌转移动画
					DesktopMgr.Inst.players[i].takeTile(fromInfos, true);
				}
			}
			// 关闭箭头，发牌到手牌
			for (let i = 0; i < DesktopMgr.Inst.players.length; i++) {
				let tiles: string[] = takeTiles[i];
				if (tiles.length > 0) {
					DesktopMgr.Inst.players[i].takeHandTile(tiles, true);
				}
			}
			if (data['tingpai']) {
				for (let i: number = 0; i < data['tingpai'].length; i++) {
					if (data['tingpai'][i]['seat'] != view.DesktopMgr.Inst.index_ju) {
						DesktopMgr.Inst.setTingpai(data['tingpai'][i]['seat'], data['tingpai'][i]['tingpais1']);
					}
				}
			}
			DesktopMgr.Inst.updateRetributeState(false);
			if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && usetime >= 0) {
				if (data['operation']) {
					ActionOperation.ob(data['operation'], usetime, 1000);
				}
			}
		}

		private static sortTakeInfos(seat: number, takeInfos: game.ITakeInfo[]): game.ITakeInfo[] {
			const shang = (seat - 1 + 4) % 4;
			const dui = (seat + 2) % 4;
			const xia = (seat + 1) % 4;
			const indexs = [shang, dui, xia];
			takeInfos.sort((a, b) => {
				let seatA = DesktopMgr.Inst.seat2LocalPosition(a.take_seat);
				let seatB = DesktopMgr.Inst.seat2LocalPosition(b.take_seat);
				let indexA = indexs.indexOf(seatA);
				let indexB = indexs.indexOf(seatB);
				return indexA - indexB;
			});
			return takeInfos;
		}
	}
}