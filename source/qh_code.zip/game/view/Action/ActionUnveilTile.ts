/**
* name 
*/
module view{
	export class ActionUnveilTile extends ActionBase {
        public static play(data:any): void {
            app.Log.log('ActionUnveilTile play data:' + JSON.stringify(data));
            DesktopMgr.Inst.setScores(data['scores']);
            // TODO 设置lizhibang 
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(data['seat'])];
            player.PlaySound('act_unveil');
            if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			} 
            DesktopMgr.Inst.ActionRunComplete();
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
        }

       public static fastplay(data:any, usetime:number): void {
            DesktopMgr.Inst.setScores(data['scores']);
            // TODO 设置lizhibang 
            
            if (data['operation']) {
				Laya.timer.once(500, this, ()=>{
					ActionOperation.play(data['operation']);
				});
			} 
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
        }

        public static record(data: any, usetime: number = 0): number {
            DesktopMgr.Inst.setScores(data['scores']);
            // TODO 设置lizhibang 
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(data['seat'])];
            player.PlaySound('act_unveil');
            if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
            return 500;
        }

        public static fastrecord(data: any, usetime:number = -1) {
            DesktopMgr.Inst.setScores(data['scores']);
            // TODO 设置lizhibang 
            let player = DesktopMgr.Inst.players[DesktopMgr.Inst.seat2LocalPosition(data['seat'])];
            // player.PlaySound('act_unveil');
            if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            if (view.DesktopMgr.Inst.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (data['operations']) {
					for (let i:number = 0; i < data['operations'].length; i++) {
						ActionOperation.ob(data['operations'][i], usetime, 450);
					}
				}
			}
            uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang'], false);
        }
    }
}