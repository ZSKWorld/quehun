/**
* name 
*/
module view{

	enum EMusicState { none, start, during, end }
	export enum EAudioType { none, sound, spcSound, audio, music }
	export class AudioInfo {
		constructor(audio: Laya.SoundChannel, url: string, audio_id: number, audioType: EAudioType = EAudioType.none) {
			this.audio = audio;
			this.audio_id = audio_id;
			this.audio.completeHandler = new Laya.Handler(this, this.onFinished, null, true);
			this.audioType = audioType;
		}
		public audio: Laya.SoundChannel;
		public audio_id: number; // soundmgr中的自增参数
		public complete: Laya.Handler;
		public audioType: EAudioType;

		public stop() {
			this.audio.stop();
			// Laya.SoundManager.destroySound(this.audio.url);
			// Laya.SoundManager.removeChannel(this.audio);
			this.audio = null;
		}
		public onFinished() {
			if (this.complete) {
				this.complete.run();
				this.complete.recover();
				this.complete = null;
			}
			
			AudioMgr.StopAudio(this.audio_id);
		}
	}
	export class AudioMgr {
		private static _allAudioMuted: boolean = false;
		private static _allAudioVolume: number = 1;
		private static _backAudioMuted: boolean = false;
		private static _isBackground: boolean = false; // 是否在后台
		private static _audio_id:number = 1;
		private static _audio_list: Array<AudioInfo> = [];
		

		private static _audioVolume:number = 0;
		private static _audioMuted:boolean = false;

		private static _music: Laya.SoundChannel = null;
		private static _playing_music:string = '';
		private static _playing_music_volume:number = 0;

		private static _music_volume: number = 1;
		private static _musicMuted: boolean = false;
		private static _current_music:string = '';

		private static _lizhiVolume:number = 0;
		private static _lizhiMuted:boolean = false;
		private static _current_lizhi_bgm:string = '';

		private static _music_state: EMusicState = EMusicState.none;
		private static _music_state_starttime: number = 0;
		private static _music_state_lifetime: number = 0;

		private static _character_all_volume: number = 1;
		private static _character_all_mute: boolean = false;
		private static _map_character_mute:Object = {};
		private static _map_character_volume:Object = {};

		private static _teshuyuyinVolume:number = 0;
		private static _teshuyuyinMuted:boolean = false;

		private static _bgm_light:boolean = false;

		//剧情用环境音
		private static _ambient_sound_id:number = 0;
		private static _cur_ambient_id:number = 0;
		private static _ambient_sound: Laya.SoundChannel = null;

		private static _waiting_remove_audio_list: Array<{tmp: AudioInfo, start_time: number, tween_time: number, volume: number}> = [];
		private static _waiting_show_audio_list: Array<{tmp: AudioInfo, start_time: number, tween_time: number, volume: number}> = [];
		private static _waiting_pause_audio_list: Array<{tmp: AudioInfo, start_time: number, tween_time: number, volume: number}> = [];
		private static _waiting_resume_audio_list: Array<{tmp: AudioInfo, start_time: number, tween_time: number, volume: number}> = [];

		public static get suffix():string { return '.mp3' }; // 直接干掉ogg
		
		public static get music_name(): string {
			if (!this._current_music) {
				return '';
			} else {
				let name = '';
				cfg.audio.bgm.forEach((data) => {
					if (data.path == this._current_music) {
						let itemConfig = cfg.item_definition.item.get(data.id);
						if (itemConfig) {
							name = itemConfig['name_' + GameMgr.client_language];
						} else {
							name = data['name_' + GameMgr.client_language];
						}
					}
				})
				return name;
			}
		}

		public static init() {
			// if (GameMgr.iniOSWebview || Laya.Browser.onIOS) {
			// 	Laya.SoundManager.autoStopMusic = true;
			// } else {
			// 	Laya.SoundManager.autoStopMusic = false;
			// }
			// Laya.SoundManager.autoReleaseSound = false;


			//全局音量
			let s_allaudiovolume: string = Laya.LocalStorage.getItem('allAudioVolume');
			if (!s_allaudiovolume || s_allaudiovolume == '') this._allAudioVolume = 1;
			else {
				let v: number = parseFloat(s_allaudiovolume);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				this._allAudioVolume = v;
			}

			let s_audiov:string = Laya.LocalStorage.getItem('audioVolume');
			if (!s_audiov || s_audiov == '') this._audioVolume = 0.5;
			else {
				let v:number = parseFloat(s_audiov);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				 this._audioVolume = v;
			}
			let s_musicv:string = Laya.LocalStorage.getItem('musicVolume');
			if (!s_musicv || s_musicv == '') this._music_volume = 0.5;
			else {
				let v:number = parseFloat(s_musicv);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				this._music_volume = v;
			}
			let s_yuyinv:string = Laya.LocalStorage.getItem('yuyinVolume');
			if (!s_yuyinv || s_yuyinv == '') this._character_all_volume = 0.5;
			else {
				let v:number = parseFloat(s_yuyinv);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				this._character_all_volume = v;
			}
			let s_teshuyuyinv:string = Laya.LocalStorage.getItem('teshuyuyinVolume');
			if (!s_teshuyuyinv || s_teshuyuyinv == '') this._teshuyuyinVolume = this._character_all_volume;
			else {
				let v:number = parseFloat(s_teshuyuyinv);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				this._teshuyuyinVolume = v;
			}

			///NewUITest///
			let s_lizhiv:string = Laya.LocalStorage.getItem('lizhiVolume');
			if (!s_lizhiv || s_lizhiv == '') this._lizhiVolume = 0.5;
			else {
				let v:number = parseFloat(s_lizhiv);
				if (v < 0) v = 0;
				else if (v > 1) v = 1;
				this._lizhiVolume = v;
			}
			///Finish3/28///
			let s_allaudiomute:string = Laya.LocalStorage.getItem('allAudioMute');
			if (!s_allaudiomute || s_allaudiomute == '') this._allAudioMuted = false;
			else {
				this._allAudioMuted = s_allaudiomute == 'true';
			}

			let s_backAudioMute: string = Laya.LocalStorage.getItem('backAudioMute');
			if (!s_backAudioMute || s_backAudioMute == '') this._backAudioMuted = false;
			else {
				this._backAudioMuted = s_backAudioMute == 'true';
			}

			let s_audiomute:string = Laya.LocalStorage.getItem('audioMute');
			if (!s_audiomute || s_audiomute == '') this._audioMuted = false;
			else {
				this._audioMuted = s_audiomute == 'true';
			}


			let s_musicmute:string = Laya.LocalStorage.getItem('musicMute');
			if (!s_musicmute || s_musicmute == '') this.musicMuted = false;
			else {
				this.musicMuted = s_musicmute == 'true';
			}

			///NewUITest///
			let s_lizhimute:string = Laya.LocalStorage.getItem('lizhiMute');
			if (!s_lizhimute || s_lizhimute == '') this._lizhiMuted = false;
			else {
				this._lizhiMuted = s_lizhimute == 'true';
			}
			///Finish3/28///

			let s_yuyinmute:string = Laya.LocalStorage.getItem('yuyinMute');
			if (!s_yuyinmute || s_yuyinmute == '') this._character_all_mute = false;
			else {
				this._character_all_mute = s_yuyinmute == 'true';
			}

			let s_teshuyuyinmute:string = Laya.LocalStorage.getItem('teshuyuyinMute');
			if (!s_teshuyuyinmute || s_teshuyuyinmute == '') this._teshuyuyinMuted = false;
			else {
				this._teshuyuyinMuted = s_teshuyuyinmute == 'true';
			}

			this._map_character_mute = {};
			this._map_character_volume = {};

			Laya.timer.frameLoop(1, this, this._update);

			//pc如果切换到后台，根据设置决定是否静音
			if (GameMgr.iniOSWebview || Laya.Browser.onIOS) {
				Laya.SoundManager.autoStopMusic = true;
			} else if (game.PlatformUtil.isPC()) {
				Laya.SoundManager.autoStopMusic = this._backAudioMuted;
			} else {
				Laya.SoundManager.autoStopMusic = false;
			}

			var onFocus = () => {
				if (this._backAudioMuted && game.PlatformUtil.isPC()) {
					this._isBackground = false;
				}
			};
			var onBlur = () => {
				if (this._backAudioMuted && game.PlatformUtil.isPC()) {
					this._isBackground = true;
				}
			}
			Laya.stage.on(/*laya.events.Event.BLUR*/"blur", null, onBlur);
			Laya.stage.on(/*laya.events.Event.FOCUS*/"focus", null, onFocus);
			Laya.stage.on(/*laya.events.Event.VISIBILITY_CHANGE*/"visibilitychange", null, () => {
				if (Laya.stage.isVisibility) {
					onFocus();
				} else {
					onBlur();
				}
			});
		}

		/**
		 * 播放角色语音
		 * @param character_info 
		 * @param type 
		 * @param complete 音频播放完毕回调
		 * @param targetPath 目标语音，因为type可能有多个音频，这里可以指定播放哪个音频
		 * @returns 
		 */
		public static PlayCharactorSound(character_info:any, type:string, complete?:Laya.Handler,targetPath?:string):{words:string, audio_id: number} {
			if (!character_info || !character_info.charid) {
				if (complete) complete.run();
				return;
			}
			let chara_id:number = character_info.charid;
			var d_chara = cfg.item_definition.character.get(chara_id);
			if (!d_chara) {
				if (complete) complete.run();
				return;
			}
			let level = character_info.level;
			let sounds = cfg.voice.sound.findGroup(d_chara.sound);
			let _ss:Array<number> = [];
			for (let i:number = 0; i < sounds.length; i++) {
				if (sounds[i].date_limit) {
					let date = new Date();
					let limits = sounds[i].date_limit.split('-');
					// 判定期限是否生效
					if (parseInt(limits[0]) == date.getMonth() + 1 && parseInt(limits[1]) == date.getDate()) {
						if (sounds[i].type =='lobby_limited') {
							if (type == 'lobby_playerlogin'){
								if (sounds[i].bond_limit && !character_info.is_upgraded) continue;
								if (sounds[i].level_limit > level) continue;
								_ss = [i];
								break;
							} else if (type== 'lobby_normal') {

							} else {
								continue;
							}
						} else {
							continue;
						}
						
					} else {
						continue;
					}
				} else {
					if (sounds[i].type != type) continue;
				}
				
				if (sounds[i].bond_limit && !character_info.is_upgraded) continue;
				if (sounds[i].level_limit > level) continue;
				_ss.push(i);
			}
			if (_ss.length == 0) {
				if (complete) complete.run();
				return;
			}
			else {
				let audioPath = '';
				let words = '';
				if (targetPath) {
					let soundData = sounds.find(s => s.path == targetPath);
					if (soundData) { 
						words = soundData['words_' + GameMgr.client_language];
						audioPath = soundData.path;
					}
				} else {
					let index: number = _ss[Math.floor(Math.random() * _ss.length)];
					audioPath = sounds[index].path;
					words = sounds[index]['words_' + GameMgr.client_language];
				}
				let sound_volume:number = d_chara.sound_volume;
				sound_volume *= this.getCVvolume(chara_id);
				if (this.getCVmute(chara_id)) sound_volume = 0;
				if (this._allAudioMuted || this.yuyinMuted) sound_volume = 0;
				sound_volume *= this.yuyinVolume;

				return {
					words: words,
					audio_id: this.PlaySound(audioPath, sound_volume, complete, 0, EAudioType.sound)
				};
			}		
		}

		public static PlayCharactorSound_Teshu(character_info:any, type:string, complete?:Laya.Handler):{words:string, audio_id: number} {
			let chara_id:number = character_info.charid;
			var d_chara = cfg.item_definition.character.get(chara_id);
			if (!d_chara) {
				if (complete) complete.run();
				return;
			}
			let level = character_info.level;
			let sounds = cfg.voice.sound.findGroup(d_chara.sound);
			let _ss:Array<number> = [];
			for (let i:number = 0; i < sounds.length; i++) {
				if (sounds[i].type != type) continue;
				if (sounds[i].bond_limit && !character_info.is_upgraded) continue;
				if (sounds[i].level_limit > level) continue;
				_ss.push(i);
			}
			if (_ss.length == 0) {
				if (complete) complete.run();
				return;
			}
			else {
				let index:number = _ss[Math.floor(Math.random() * _ss.length)];

				let sound_volume:number = d_chara.sound_volume;
				sound_volume *= this.getCVvolume(chara_id);
				if (this.getCVmute(chara_id)) sound_volume = 0;
				if (this._allAudioMuted || this.teshuyuyinMuted || this.yuyinMuted) sound_volume = 0;
				sound_volume *= this.teshuyuyinVolume;

				return {
					words: sounds[index]['words_' + GameMgr.client_language],
					audio_id: this.PlaySound(sounds[index].path, sound_volume, complete, 0, EAudioType.spcSound)
				};
			}		
		}

		// 剧情用角色配音
		public static PlayCharactorSoundInSpot(sound_id: number, complete?:Laya.Handler): number {
			let  sound = game.Tools.get_chara_audio_spot(sound_id);
			if (!sound) return -1;
			return this.PlaySound(sound.path, sound.volume, complete);
		}
		// 剧情用环境音
		public static PlayAmbientSoundInSpot(sound_id: number, volume:number): number {
			if (this.allAudioMuted || this.musicMuted) {
				volume = 0;
			}
			if(this._ambient_sound && sound_id == this._ambient_sound_id){				
				this._ambient_sound.volume = this.musicVolume * volume;
				return this._ambient_sound_id; 
			}
			this.StopAmbientSoundInSpot();
			let ambientInfo = cfg.audio.bgm.get(sound_id) || cfg.spot.audio_spot.get(sound_id);
			if (ambientInfo == null) {
				return -1;
			}

			this._cur_ambient_id = this.PlayLoopSound('audio/' + ambientInfo.path, this.musicVolume * volume);
			this._ambient_sound = this.GetAudioChannel(this._cur_ambient_id);
			this._ambient_sound_id = sound_id;
			return this._cur_ambient_id;
		}
		public static StopAmbientSoundInSpot() {
			if (this._ambient_sound == null) {
				return;
			}
			this.StopAudio(this._cur_ambient_id);
			this._cur_ambient_id = -1;
			this._ambient_sound_id = 0;
			this._ambient_sound = null;

		}

		public static PlaySound(audio:string, volume_fix:number, complete?:Laya.Handler, tween_time: number = 0, audioType: EAudioType = EAudioType.none, playbackRate?: number): number {
			let _id:number = this._audio_id;
			this._audio_id++;
			if (this.allAudioMuted) volume_fix = 0;
			let _s:string = this.suffix;
			let _audio: Laya.SoundChannel = Laya.SoundManager.playSound(audio + _s, 1, null, null, null, playbackRate);
			if (_audio) {				
				_audio.volume = volume_fix;
				let info = new AudioInfo(_audio, audio + _s, _id, audioType);
				info.complete = complete;
				this._audio_list.push(info);
				if (tween_time && _audio) {
					this._waiting_show_audio_list.push({tmp: info, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: volume_fix});
				}
			} else {
				return -1;
			}
			
			return _id;
		}

		public static PlayLoopSound(audio: string, volume_fix: number, tween_time: number = 0, audioType: EAudioType = EAudioType.none): number {
			let _id:number = this._audio_id;
			this._audio_id++;
			if (this.allAudioMuted) volume_fix = 0;
			let _s:string = this.suffix;
			let _audio: Laya.SoundChannel = Laya.SoundManager.playSound(audio + _s, 0);
			if (_audio) {				
				_audio.volume = volume_fix;
				let info = new AudioInfo(_audio, audio + _s, _id, audioType);
				this._audio_list.push(info);
				if (tween_time && _audio) {
					this._waiting_show_audio_list.push({tmp: info, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: volume_fix});
				}
			} else {
				return -1;
			}
			
			return _id;
		}

		public static playABBBSound(audio_a: string, audio_b: string, volume_fix: number, b_start_time: number): {a_id: number, b_id: number} {
			let audio_id = this.PlaySound(audio_a, 0);
            let loop_audio_id = this.PlayLoopSound(audio_b, 0);
            Laya.timer.once(500, this, ()=>{
                if (audio_id) {
                    let channel: Laya.SoundChannel = this.GetAudioChannel(audio_id);
                    if (channel) {
                        channel.volume = volume_fix;
                        channel.play();
                    }
                }
            });
            Laya.timer.once(500 + b_start_time, this, ()=>{
                if (loop_audio_id) {
                    let channel: Laya.SoundChannel = this.GetAudioChannel(loop_audio_id);
                    if (channel) {
                        channel.volume = volume_fix;
                        channel.play();
                    }
                }
            });
			return {a_id: audio_id, b_id: loop_audio_id};
		}

		/**
		 * 通过audio id播放有导入音效的audio
		 * @param audio_a 
		 * @param audio_b 
		 * @param volume_fix 音量
		 * @param b_start_time 第二个开始时间，不传时默认第一个结束
		 * @returns 
		 */
		public static playABBBSoundById(audio_a: number, audio_b: number, volume_fix: number | null = null, b_start_time: number|null = null): { a_id: number, b_id: number } {
			let audio_a_path = cfg.audio.audio.get(audio_a).path;
			let audio_b_path = cfg.audio.audio.get(audio_b).path;
			if (volume_fix == null) {
				volume_fix = view.AudioMgr.musicMuted || view.AudioMgr.allAudioMuted ? 0 : view.AudioMgr.musicVolume;
			}
			
			b_start_time = b_start_time == null ? cfg.audio.audio.get(audio_a).time_length : b_start_time;
			return this.playABBBSound(audio_a_path, audio_b_path, volume_fix, b_start_time);
		}


		public static PlayAudio(audioID:number, loop:number = 1, volume:number = 1, tween_time: number = 0, complete: Laya.Handler = null): number {
			if (this.allAudioMuted || this.audioMuted || this.audioVolume == 0) return -1;
			// if (window['conch']) return -1;
			let data = cfg.audio.audio.get(audioID);
			if (!data) {
				return -1;
			}
			let _id:number = this._audio_id;
			this._audio_id++;
			
			let _s:string = this.suffix;
			let _audio: Laya.SoundChannel = Laya.SoundManager.playSound(data.path + _s, loop <= 0 ? 0 : loop);
			if (_audio) {				
				_audio.volume = this.audioVolume * volume;
			} else {
				return -1;
			}
			let info = new AudioInfo(_audio, data.path + _s, _id, EAudioType.audio);
			info.complete = complete;
			this._audio_list.push(info);
			if (tween_time && _audio) {
				this._waiting_show_audio_list.push({tmp: info, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: this.audioVolume * volume});
			}
			return _id;
		}

		private static _RemoveAudio(id:number): void {
			for (let i:number = 0; i < this._audio_list.length; i++) {
				if (this._audio_list[i].audio_id == id) {
					var tmp = this._audio_list[i];
					this._audio_list[i] = this._audio_list[this._audio_list.length - 1];
					this._audio_list[this._audio_list.length - 1] = tmp;
					tmp.stop();
					this._audio_list.pop();
					break;
				}
			}
			const checkAudioLst = (lst: {
				tmp: AudioInfo;
				start_time: number;
				tween_time: number;
				volume: number;
			}[], audioId: number) => {
				for (let i: number = 0; i < lst.length; i++) {
					if (lst[i].tmp.audio_id == audioId) {
						var _tmp = lst[i];
						lst[i] = lst[lst.length - 1];
						lst[lst.length - 1] = _tmp;
						lst.pop();
						break;
					}
				}
			}
			checkAudioLst(this._waiting_remove_audio_list, id);
			checkAudioLst(this._waiting_show_audio_list, id);
			checkAudioLst(this._waiting_pause_audio_list, id);
			checkAudioLst(this._waiting_resume_audio_list, id);
		}

		public static StopAudio(id: number, tween_time: number = 0): void {
			if (tween_time == 0) {
				this._RemoveAudio(id);
			} else {
				for (let i:number = 0; i < this._audio_list.length; i++) {
					if (this._audio_list[i].audio_id == id) {
						var tmp = this._audio_list[i];
						if (tmp['audio']) {
							this._waiting_remove_audio_list.push({tmp: tmp, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: tmp.audio.volume});
						} else {
							this._RemoveAudio(id);
						}
						
						break;
					}
				}
				
			}		
		}

		public static PauseAudio(id: number, tween_time: number = 0): void {
			for (let i: number = 0; i < this._audio_list.length; i++) {
				if (this._audio_list[i].audio_id == id) {
					var tmp = this._audio_list[i];
					if (tmp.audio) {
						if (tween_time > 0) {
							this._waiting_pause_audio_list.push({ tmp: tmp, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: tmp.audio.volume });
						} else {
							tmp.audio.pause();
						}
					} else {
						this._RemoveAudio(id);
					}
					break;
				}
			}
		}

		// 返回audio id，可以判断是否成功恢复
		public static ResumeAudio(id: number, tween_time: number = 0, volume: number = 1): number {
			let audioId = 0;
			for (let i: number = 0; i < this._audio_list.length; i++) {
				if (this._audio_list[i].audio_id == id) {
					var tmp = this._audio_list[i];
					if (tmp.audio) {
						tmp.audio.resume();
						tmp.audio.volume = volume * this.getVolumeByAudioType(tmp.audioType);
						audioId = tmp.audio_id;
						if (tween_time > 0) {
							this._waiting_resume_audio_list.push({ tmp: tmp, start_time: Laya.timer.currTimer, tween_time: tween_time, volume: tmp.audio.volume });
						}
					}
					break;
				}
			}
			return audioId;
		}

		public static GetAudioChannel(id: number): Laya.SoundChannel {
			for (let i:number = 0; i < this._audio_list.length; i++) {
				if (this._audio_list[i].audio_id== id) {
					var tmp = this._audio_list[i];
					return tmp['audio'];
				}
			}
			return null;
		}
		public static PlayMusic(audio: string, tween_time: number = 1000, force: boolean = false, loop: boolean = false, isSound: boolean = false, volume: number = 1): boolean {
			if (!force && this._current_music == audio) {
				if (this._music) {
					let vol: number = 0;
					if (!this.allAudioMuted) {
						if (!this.lizhiMuted && this._current_lizhi_bgm) {
							vol = this.lizhiVolume;
						}
						if ((!this.musicMuted || force) && this._current_music) {
							vol = this.musicVolume;
						}
					}
					vol *= volume;
					this._music.volume = vol;
					this._playing_music_volume = vol;
				}
				return false;
			}

			if (!this.lizhiMuted && this._current_lizhi_bgm) {
				// 有立直bgm，不能设置背景音乐
				return false;
			}
			this._current_music = audio;
			this.onMusicChange(tween_time, force, loop, isSound, false, volume);
			return true;
		}

		public static StopMusic(tween_time:number = 1000) {
			this._current_music = '';
			this._current_lizhi_bgm = '';
			if (this._music) {
				if (tween_time <= 0) {
					this._music.stop();
					// Laya.SoundManager.removeChannel(this._music);
					// Laya.SoundManager.destroySound('audio/' + this._playing_music);
					this._music = null;
					this._music_state = EMusicState.none;
					BgmListMgr.onBgmChange('', false);
				} else {
					this._music_state = EMusicState.end;
					this._music_state_starttime = Laya.timer.currTimer;
					this._music_state_lifetime = tween_time;
				}
			}
		}

		public static PlayLiqiBgm(audio:string, tween_time:number = 1000, force:boolean = false) {
			if (!force && this._current_lizhi_bgm == audio) return;
			this._current_lizhi_bgm = audio;
			this.onMusicChange(tween_time);
			return true;
		}

		/**
		 * 在宿舍播放bgm，无视立直是否静音
		 * @param audio 
		 * @param tween_time 
		 * @returns 
		 */
		public static PlayLiqiBgmInSushe(audio: string, tween_time: number = 1000) { 
			this._current_lizhi_bgm = audio;
			this.onMusicChange(tween_time, false, false, false,true);
			return true;
		}

		///NewUITest///
		public static set lizhiVolume(rate: number) {
			rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
			this._lizhiVolume = rate;
			if (this._music && this._music_state == EMusicState.during && this._playing_music == this._current_lizhi_bgm) {
				this._playing_music_volume = rate;
			}
			Laya.LocalStorage.setItem('lizhiVolume', rate.toString());
		}

		public static get lizhiVolume(): number {
			return this._lizhiVolume * this._allAudioVolume;
		}

		public static get lizhiVolumeTrue(): number {
			return this._lizhiVolume;
		}

		
		public static setCVvolume(id:number, CVidVolume:number){
			CVidVolume = CVidVolume < 0 ? 0 : CVidVolume > 1 ? 1 : CVidVolume;
			this._map_character_volume[id] = CVidVolume;
			Laya.LocalStorage.setItem('characterVolume' + id, CVidVolume.toString());
		}

		public static getCVvolume(id:number):number {
			if(!this._map_character_volume.hasOwnProperty(id.toString())){
				let vol:string = Laya.LocalStorage.getItem('characterVolume' + id);
				if (vol && vol != '') {
					this._map_character_volume[id] = parseFloat(vol);
				} else {
					this._map_character_volume[id] = 1;
				}
			}
			return this._map_character_volume[id];
		}

		public static setCVmute(id:number, CVidMute:boolean) {
			this._map_character_mute[id] = CVidMute ? 'true' : 'false';
			Laya.LocalStorage.setItem('characterMute' + id, CVidMute ? 'true' : 'false');
		}

		public static getCVmute(id:number) {
			if(!this._map_character_mute.hasOwnProperty(id.toString())){
				let mute:string = Laya.LocalStorage.getItem('characterMute' + id);
				if (mute && mute != '') {
					this._map_character_mute[id] = mute;
				} else {
					this._map_character_mute[id] = 'false';
				} 
			}
			return this._map_character_mute[id] == 'true'; 
		}
		///Finish3/28///

		public static set allAudioVolume(rate: number) { 
			rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
			this._allAudioVolume = rate;
			Laya.LocalStorage.setItem('allAudioVolume', rate.toString());
			this.onMusicChange();
			this.musicVolume = this._music_volume; // 更新音效音量
		}

		public static get allAudioVolume(): number {
			return this._allAudioVolume;
		}

		public static set audioMuted(val:boolean) {
			this._audioMuted = val;
			Laya.LocalStorage.setItem('audioMute', val ? 'true' : 'false');
		}
		
		public static get audioMuted():boolean {
			return this._audioMuted;
		}

		public static set audioVolume(rate:number) {
			rate = rate < 0 ? 0 : rate > 1 ? 1 : rate;
			this._audioVolume = rate;
			Laya.LocalStorage.setItem('audioVolume', rate.toString());
		}

		public static get audioVolume():number {
			return this._audioVolume * this._allAudioVolume;
		}

		public static get audioVolumeTrue():number {
			return this._audioVolume;
		}

		public static set musicVolume(rate:number) {
			this._music_volume = rate;
			Laya.LocalStorage.setItem('musicVolume', rate.toString());
			if (this._music && (this._music_state == EMusicState.start || this._music_state == EMusicState.during) && this._playing_music == this._current_music) {
				this._playing_music_volume = this.musicVolume;
			}
		}
		
		public static get musicVolume():number {
			return this._music_volume * this._allAudioVolume;
		}

		public static get musicVolumeTrue():number {
			return this._music_volume;
		}

		///NewUITest///
		public static set lizhiMuted(val: boolean) {
			this._lizhiMuted = val;
			Laya.LocalStorage.setItem('lizhiMute', val ? 'true' : 'false');
			this.onMusicChange();
		}

		public static get lizhiMuted(): boolean {
			return this._lizhiMuted;
		}
		///Finish3/28///

		public static set musicMuted(val:boolean) {
			this._musicMuted = val;
			Laya.LocalStorage.setItem('musicMute', val ? 'true' : 'false');
			this.onMusicChange();
		}
		
		public static get musicMuted():boolean {
			return this._musicMuted;
		}

		public static set allAudioMuted(val:boolean) {
			this._allAudioMuted = val;
			Laya.LocalStorage.setItem('allAudioMute', val ? 'true' : 'false');
			this.onMusicChange();
		}
		
		public static get allAudioMuted(): boolean{
			return this._allAudioMuted;
		}

		/**
		 * 后台是否静音
		 */
		public static set backAudioMuted(val: boolean) {
			this._backAudioMuted = val;
			if (game.PlatformUtil.isPC()) {
				Laya.SoundManager.autoStopMusic = this._backAudioMuted;
			}
			Laya.LocalStorage.setItem('backAudioMute', val ? 'true' : 'false');
			
		}

		public static get backAudioMuted(): boolean {
			return this._backAudioMuted;
		}

		public static get yuyinVolume():number {
			return this._character_all_volume * this._allAudioVolume;
		}

		public static get yuyinVolumeTrue(): number {
			return this._character_all_volume;
		}

		public static set yuyinVolume(rate:number) {
			this._character_all_volume = rate;
			Laya.LocalStorage.setItem('yuyinVolume', rate.toString());
		}

		public static set yuyinMuted(val:boolean) {
			this._character_all_mute = val;
			Laya.LocalStorage.setItem('yuyinMute', val ? 'true' : 'false');
		}
		
		public static get yuyinMuted():boolean {
			return this._character_all_mute;
		}
		
		public static get teshuyuyinVolume():number {
			return this._teshuyuyinVolume * this._allAudioVolume;
		}

		public static get teshuyuyinVolumeTrue(): number {
			return this._teshuyuyinVolume;
		}

		public static set teshuyuyinVolume(rate:number) {
			this._teshuyuyinVolume = rate;
			Laya.LocalStorage.setItem('teshuyuyinVolume', rate.toString());
		}

		public static set teshuyuyinMuted(val:boolean) {
			this._teshuyuyinMuted = val;
			Laya.LocalStorage.setItem('teshuyuyinMute', val ? 'true' : 'false');
		}
		
		public static get teshuyuyinMuted():boolean {
			return this._teshuyuyinMuted;
		}

		public static refresh_music_volume(light:boolean) {
			if (this._music && this._music_state == EMusicState.during){
				this._bgm_light = light;
				// this._music.volume = this._bgm_light ? this.musicVolume * 0.1 : this.musicVolume;
			} 
		}

		public static onMusicChange(tween_time: number = 1000, force: boolean = false, loop: boolean = false, isSound: boolean = false, isLichiForce: boolean = false, volume: number = 1) {
			let need2play_music: string = '';
			let vol: number = 0;
			let is_lizhi: boolean = false;
			if (!this.allAudioMuted) {
				let needMuteLichi: boolean = this.lizhiMuted && !isLichiForce;
				if (need2play_music == '' && !needMuteLichi && this._current_lizhi_bgm) {
					need2play_music = this._current_lizhi_bgm;
					vol = this.lizhiVolume;
					is_lizhi = true;
				}
				if (need2play_music == '' && (!this.musicMuted || force) && this._current_music) {
					need2play_music = this._current_music;
					vol = this.musicVolume;
				}
			}
			vol *= volume;
			if (this._music && need2play_music == this._playing_music) {
				if (this._music.isStopped) {
					this._music.resume();
				}
				// 如果正在结束阶段，直接切换至播放状态
				if (this._music_state == EMusicState.end) {
					this._music_state = EMusicState.during;
					this._music.volume = this._playing_music_volume;
				}
				return;
			}
			if (this._music) {
				this._music.stop();
				Laya.SoundManager.removeChannel(this._music);
				// Laya.SoundManager.destroySound('audio/' + this._playing_music);
				this._music = null;
			}

			if (need2play_music) {
				if (is_lizhi) {
					this._music = Laya.SoundManager.playMusic('audio/' + need2play_music, 0);
					BgmListMgr.onBgmChange(need2play_music, true);
				} else if (isSound) {
					this._music = Laya.SoundManager.playMusic( need2play_music + this.suffix, 0);
					BgmListMgr.onBgmChange('', false);
				} else if (loop) {
					this._music = Laya.SoundManager.playMusic('audio/' + need2play_music, 0);
					BgmListMgr.onBgmChange('', false);
				} else {
					this._music = Laya.SoundManager.playMusic('audio/' + need2play_music, 1, Laya.Handler.create(this, ()=>{
						this._current_music = '';
						this._playing_music = '';
						if (this._music_state != EMusicState.end) {
							BgmListMgr.onBgmPlayOver();
						}
					}));
					BgmListMgr.onBgmChange(need2play_music, false);
				}
				if (this._music) {
					this._playing_music = need2play_music;
					this._playing_music_volume = vol;
					if (tween_time > 0) {
						this._music.volume = 0;
						this._music_state = EMusicState.start;
						this._music_state_starttime = Laya.timer.currTimer;
						this._music_state_lifetime = tween_time;
					} else {
						this._music_state = EMusicState.during;
						this._music.volume = this._playing_music_volume;
					}
				}
			} else {
				BgmListMgr.onBgmChange(need2play_music, false);
			}
		}

		private static _update() {
			if (this._music && this._music_state != EMusicState.none) {
				let t:number = Laya.timer.currTimer - this._music_state_starttime;
				if (this._music_state == EMusicState.start) {
					if (t >= this._music_state_lifetime) {
						this._music_state = EMusicState.during;
						this.setMusicVolume(this._playing_music_volume);
					} else {
						let r:number = t / this._music_state_lifetime;
						this.setMusicVolume(this._playing_music_volume * r);
					}
					if (this._bgm_light) this.setMusicVolume(this._music.volume * 0.1);
				} else if (this._music_state == EMusicState.end) {
					if (t >= this._music_state_lifetime) {
						this._music_state = EMusicState.none;
						this._music.stop();
						// Laya.SoundManager.removeChannel(this._music);
						// Laya.SoundManager.destroySound('audio/' + this._playing_music);
						this._music = null;
					} else {
						let r:number = t / this._music_state_lifetime;
						this.setMusicVolume(this._playing_music_volume * (1 - r));
						if (this._bgm_light) this.setMusicVolume(this._music.volume * 0.1);
					}
					
				} else {
					if (this._bgm_light) this.setMusicVolume(this._playing_music_volume * 0.1);
					else this.setMusicVolume(this._playing_music_volume);
				} 
			}

			for (let i = this._audio_list.length - 1; i >= 0; i--) {
				var tmp = this._audio_list[i];
				let isMuted = this.getMutedByAudioInfo(tmp);
				if (isMuted) {
					tmp.audio.volume = 0;
				}
			}

			for (let i = this._waiting_remove_audio_list.length - 1; i >= 0; i--) {
				let audio = this._waiting_remove_audio_list[i];
				if (Laya.timer.currTimer - audio.start_time > audio.tween_time || this.getMutedByAudioInfo(audio.tmp)) {
					this._waiting_remove_audio_list.splice(i, 1);
					this._RemoveAudio(audio.tmp.audio_id);
				} else {
					audio.tmp['audio'].volume = audio.volume * audio.volume * (1 - (Laya.timer.currTimer - audio.start_time) / audio.tween_time);
				}
			}

			for (let i = this._waiting_show_audio_list.length - 1; i >= 0; i--) {
				let audio = this._waiting_show_audio_list[i];
				if (Laya.timer.currTimer - audio.start_time > audio.tween_time) {
					this._waiting_show_audio_list.splice(i, 1);
					audio.tmp['audio'].volume = audio.volume;
				} else {
					audio.tmp['audio'].volume = audio.volume * audio.volume * (Laya.timer.currTimer - audio.start_time) / audio.tween_time;
				}
			}

			for (let i = this._waiting_pause_audio_list.length - 1; i >= 0; i--) {
				let audio = this._waiting_pause_audio_list[i];
				if (this.getMutedByAudioInfo(audio.tmp)) { // 都静音了别暂停了，remove掉直接拜拜
					this._waiting_pause_audio_list.splice(i, 1);
					this._RemoveAudio(audio.tmp.audio_id);
				} else if (Laya.timer.currTimer - audio.start_time > audio.tween_time) {
					this._waiting_pause_audio_list.splice(i, 1);
					audio.tmp['audio'].pause();
				} else {
					audio.tmp['audio'].volume = audio.volume * audio.volume * (1 - (Laya.timer.currTimer - audio.start_time) / audio.tween_time);
				}
			}

			for (let i = this._waiting_resume_audio_list.length - 1; i >= 0; i--) {
				let audio = this._waiting_resume_audio_list[i];
				if (Laya.timer.currTimer - audio.start_time > audio.tween_time) {
					this._waiting_resume_audio_list.splice(i, 1);
					audio.tmp['audio'].volume = audio.volume;
				} else {
					audio.tmp['audio'].volume = audio.volume * audio.volume * (Laya.timer.currTimer - audio.start_time) / audio.tween_time;
				}
			}
		}

		private static getMutedByAudioInfo(tmp: AudioInfo) {
			let isMuted = this.allAudioMuted ||
				(tmp.audioType == EAudioType.audio && this.audioMuted) ||
				(tmp.audioType == EAudioType.spcSound && (this.yuyinMuted || this.teshuyuyinMuted)) ||
				(tmp.audioType == EAudioType.sound && this.yuyinMuted) ||
				(tmp.audioType == EAudioType.music && this.musicMuted);
			return isMuted;
		}

		private static getVolumeByAudioType(audioType: EAudioType) {
			if (audioType == EAudioType.audio) {
				return this.audioVolume;
			} else if (audioType == EAudioType.music) {
				return this.musicVolume;
			} else if (audioType == EAudioType.sound) {
				return this.yuyinVolume;
			} else if (audioType == EAudioType.spcSound) {
				return this.teshuyuyinVolume;
			}
			return 1;
		}

		private static setMusicVolume(volume: number) {
			if (this._music) {
				this._music.volume = volume;
			}
		}

		public static resetAllConfig() {
			this.audioVolume = 0.5;
			
			this.musicVolume = 0.5;
			
			this.yuyinVolume = 0.5;
		
			this.teshuyuyinVolume = this._character_all_volume;
			

			///NewUITest///
			this.lizhiVolume = 0.5;
			
			///Finish3/28///
			this.allAudioMuted = false;
			this.backAudioMuted = false;
			this.allAudioVolume = 1;
			

			this.audioMuted = false;

			this.musicMuted = false;
			

			///NewUITest///
			this.lizhiMuted = false;
			
			///Finish3/28///

			this.yuyinMuted = false;
			

			this.teshuyuyinMuted = false;
			
			cfg.item_definition.character.forEach((value)=>{
				Laya.LocalStorage.removeItem('characterMute' + value.id);
				Laya.LocalStorage.removeItem('characterVolume' + value.id);
			});
			this._map_character_mute = {};
			this._map_character_volume = {};
		}

	}
}