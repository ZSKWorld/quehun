/**
* name 
*/
module view{

	export enum E_Bgm_Type { none, lobby, mj, lizhi , event}

	export class BgmListMgr {
		public static baned_bgm_lobby_list:Array<string> = []; //被禁掉的音乐
		public static bgm_lobby_mode:string = 'list';
		public static baned_bgm_mj_list:Array<string> = [];
		public static bgm_mj_mode:string = 'list';

		public static playing_bgm:string = '';
		public static type:E_Bgm_Type = E_Bgm_Type.none;
		
		public static get bgm_lobby_list():Array<string> {
			let lst:Array<string> = [];
			cfg.audio.bgm.forEach(x=>{
				if (x.type != 'lobby') return;
				if (x.unlock_item && uiscript.UI_Bag.get_item_count(x.unlock_item) == 0) return;
				for (let i:number = 0; i < this.baned_bgm_lobby_list.length; i++) {
					if (this.baned_bgm_lobby_list[i] == x.path) return;
				}
				lst.push(x.path);
			});
			return lst;
		}

		public static get bgm_mj_list():Array<string> {
			let lst:Array<string> = [];
			cfg.audio.bgm.forEach(x=>{
				if (x.type != 'mj') return;
				if (x.unlock_item && uiscript.UI_Bag.get_item_count(x.unlock_item) == 0) return;
				for (let i:number = 0; i < this.baned_bgm_mj_list.length; i++) {
					if (this.baned_bgm_mj_list[i] == x.path) return;
				}
				lst.push(x.path);
			});
			return lst;
		}

		public static init() {
			let s_bgm_lobby:string = Laya.LocalStorage.getItem(game.Tools.eeesss('baned_bgm_lobby_list' + GameMgr.Inst.account_id));
			this.baned_bgm_lobby_list = [];
			if (s_bgm_lobby && s_bgm_lobby != '') {
				this.baned_bgm_lobby_list = s_bgm_lobby.split(',');
			}
			this.bgm_lobby_mode = Laya.LocalStorage.getItem(game.Tools.eeesss('bgm_lobby_mode' + GameMgr.Inst.account_id));
			if (!this.bgm_lobby_mode || this.bgm_lobby_mode == '') {
				this.bgm_lobby_mode = 'list';
			}

			let s_bgm_mj:string = Laya.LocalStorage.getItem(game.Tools.eeesss('baned_bgm_mj_list' + GameMgr.Inst.account_id));
			this.baned_bgm_mj_list = [];
			if (s_bgm_mj && s_bgm_mj != '') {
				this.baned_bgm_mj_list = s_bgm_mj.split(',');
			}
			this.bgm_mj_mode = Laya.LocalStorage.getItem(game.Tools.eeesss('bgm_mj_mode' + GameMgr.Inst.account_id));
			if (!this.bgm_mj_mode || this.bgm_mj_mode == '') {
				this.bgm_mj_mode = 'list';
			}

			this.type = E_Bgm_Type.none;
			this.playing_bgm = '';
		}

		public static saveConfig() {
			let s_bgm_lobby:string = '';
			for (let i:number = 0; i < this.baned_bgm_lobby_list.length; i++) {
				if (i != 0) s_bgm_lobby += ',';
				s_bgm_lobby += this.baned_bgm_lobby_list[i];
			}
			Laya.LocalStorage.setItem(game.Tools.eeesss('baned_bgm_lobby_list' + GameMgr.Inst.account_id), s_bgm_lobby);

			let s_bgm_mj:string = '';
			for (let i:number = 0; i < this.baned_bgm_mj_list.length; i++) {
				if (i != 0) s_bgm_mj += ',';
				s_bgm_mj += this.baned_bgm_mj_list[i];
			}
			Laya.LocalStorage.setItem(game.Tools.eeesss('baned_bgm_mj_list' + GameMgr.Inst.account_id), s_bgm_mj);
		}

		public static resetAllConfig() {
			this.baned_bgm_lobby_list = [];
			Laya.LocalStorage.removeItem(game.Tools.eeesss('baned_bgm_lobby_list' + GameMgr.Inst.account_id));
			this.baned_bgm_mj_list = [];
			Laya.LocalStorage.removeItem(game.Tools.eeesss('baned_bgm_mj_list' + GameMgr.Inst.account_id));
			this.bgm_lobby_mode = 'list';
            Laya.LocalStorage.setItem(game.Tools.eeesss('bgm_lobby_mode' + GameMgr.Inst.account_id), this.bgm_lobby_mode);
            this.bgm_mj_mode = 'list';
			Laya.LocalStorage.setItem(game.Tools.eeesss('bgm_mj_mode' + GameMgr.Inst.account_id), this.bgm_mj_mode);
			// if (this.playing_bgm == '') {
				this.playing_bgm = '';
				AudioMgr.StopMusic(0);
				this.onBgmPlayOver();
			// }
		}
		
		public static stopBgm(tween:number = 1000) {
			if (this.type == E_Bgm_Type.lizhi) this.type = E_Bgm_Type.none;
			this.playing_bgm = '';
			AudioMgr.StopMusic(tween);
			// if (uiscript.UI_Config.Inst) uiscript.UI_Config.Inst.onBgmChange();
			Laya.stage.event(EventCode.ON_BGM_CHANGE);
		}

		public static onHandStop() {
			let lst = [];
			if (this.type == E_Bgm_Type.lobby) {
				lst = this.bgm_lobby_list;
			} else if (this.type == E_Bgm_Type.mj) {
				lst = this.bgm_mj_list;
			}
			if (lst.length == 0 || AudioMgr.musicMuted) {
				this.stopBgm(0);
				return;
			}
			for (let i:number = 0; i < lst.length; i++) {
				if (lst[i] != this.playing_bgm) {
					if (this.type == E_Bgm_Type.lobby) {
						this.PlayLobbyBgm(lst[i], true, 0);
					} else if (this.type == E_Bgm_Type.mj) {
						this.PlayMJBgm(lst[i], true, 0);
					}
					
					return ;
				}
			}
			this.stopBgm(0);
		}

		public static onBgmPlayOver() {
			if (this.type == E_Bgm_Type.lobby) {
				this.NextLobbyBgm();
			} else if (this.type == E_Bgm_Type.mj){
				this.NextMJBgm();
			} else if (this.type == E_Bgm_Type.event) {
				this.PlayEventBgm(this.playing_bgm, true);
			}
		}

		public static onBgmChange(bgm:string, is_liqi:boolean) {
			this.playing_bgm = bgm;
			if (is_liqi) this.type = E_Bgm_Type.lizhi;
			// if (uiscript.UI_Config.Inst) uiscript.UI_Config.Inst.onBgmChange();
			Laya.stage.event(EventCode.ON_BGM_CHANGE);
		}

		// 试听
		public static tryPlayBgm(bgm:string):boolean {
			if (this.type == E_Bgm_Type.lizhi) return false;
			// if (AudioMgr.musicMuted) return false;
			AudioMgr.PlayMusic(bgm, 1000, true);
			return true;
		}

		private static _RandNextIndex(current_index:number, total:number):number {
			if (total == 0) return -1;
			if (total == 1) return 0;
			for (let i:number = 0; i < 3; i++) {
				let d:number = Math.floor(Math.random() * total);
				if (d != current_index) return d;
			}
			return Math.floor(total);
		}

		public static findIndexInLobby(bgm:string): number {
			if (!bgm || bgm == '') return -1;
			let lst = this.bgm_lobby_list;
			for (let i:number = 0; i < lst.length; i++) {
				if (lst[i] == bgm) return i;
			}
			return -1;
		}

		public static PlayLobbyBgm(bgm:string = '', force:boolean = false, tween:number = 1000):boolean {
			if (!force && bgm != '' && bgm == this.playing_bgm) return false;
			this.type = E_Bgm_Type.lobby;
			let index = this.findIndexInLobby(bgm);
			let lst = this.bgm_lobby_list;
			if (index == -1) {
				if (lst.length == 0) {
					AudioMgr.StopMusic();
					return false;
				}
				let rand:number = Math.random();
				index = Math.floor(rand * lst.length);
			}
			AudioMgr.PlayMusic(lst[index], tween, force);
		}

		public static NextLobbyBgm():boolean {
			let lst = this.bgm_lobby_list;
			if (lst.length == 0) return false;
			let _index:number = this.findIndexInLobby(this.playing_bgm);
			if (this.bgm_lobby_mode == 'list' || _index >= 0) {
				_index = (_index + 1) % lst.length;
			} else {
				_index = this._RandNextIndex(_index, lst.length);
			}
			return this.PlayLobbyBgm(lst[_index], true, 0);
		}

		public static findIndexInMJ(bgm:string): number {
			let lst = this.bgm_mj_list;
			for (let i:number = 0; i < lst.length; i++) {
				if (lst[i] == bgm) return i;
			}
			return -1;
		}

		public static PlayMJBgm(bgm:string = '', force:boolean = false, tween:number = 1000):boolean {
			if (!force && bgm != '' && bgm == this.playing_bgm) return false;
			this.type = E_Bgm_Type.mj;
			let index = this.findIndexInMJ(bgm);
			let lst = this.bgm_mj_list;
			if (index == -1) {
				if (lst.length == 0) {
					AudioMgr.StopMusic();
					return false;
				}
				index = Math.floor(Math.random() * lst.length);
			}
			AudioMgr.PlayMusic(lst[index], tween, force);
		}

		public static NextMJBgm():boolean {
			let lst = this.bgm_mj_list;
			if (lst.length == 0) return false;
			let _index:number = this.findIndexInMJ(this.playing_bgm);
			if (this.bgm_mj_mode == 'list' || _index >= 0) {
				_index = (_index + 1) % lst.length;
			} else {
				_index = this._RandNextIndex(_index, lst.length);
			}
			return this.PlayMJBgm(lst[_index], true, 1000);
		}

		public static PlayEventBgm(bgm:string = '', force:boolean = false, tween:number = 1000, loop: boolean = false):boolean {
			if (!force && bgm != '' && bgm == this.playing_bgm) return false;
			this.type = E_Bgm_Type.event;
			AudioMgr.PlayMusic(bgm, tween, false, loop);
		}

		public static ResetBgm() {
			if (this.type == E_Bgm_Type.lizhi) return;
			let lst = [];
			if (this.type == E_Bgm_Type.lobby) {
				lst = this.bgm_lobby_list;
			} else if (this.type == E_Bgm_Type.mj) {
				lst = this.bgm_mj_list;
			}
			if (lst.length == 0 || AudioMgr.musicMuted) {
				this.stopBgm(0);
				return;
			}
			//如果说 没在播音乐  或  播的音乐和当前场景无关
			if (!this.playing_bgm || lst.indexOf(this.playing_bgm) == -1) {
				if (this.type == E_Bgm_Type.lobby) {
					this.PlayLobbyBgm(lst[0], true, 0);
				} else if (this.type == E_Bgm_Type.mj) {
					this.PlayMJBgm(lst[0], true, 0);
				}
			}
		}

	}
}