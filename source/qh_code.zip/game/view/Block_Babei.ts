/**
* name 
*/
module view{

	export class Block_Babei {
		public origin: Laya.Sprite3D = null;
		public player: ViewPlayer = null;
		public xOffset: number = 0;
		public pais: Array<ViewPai> = new Array<ViewPai>();

		private get seat():number {return this.player.seat;}

		constructor(_origin: Laya.Sprite3D, player: ViewPlayer) {
			this.origin = _origin;
			this.xOffset = 0;
			this.player = player;
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.pais.length > 0) { 
				for (let i:number = 0; i < this.pais.length; i ++) {
					this.pais[i].model.destroy();
				}
				this.pais = [];
			}
			this.xOffset = 0;
		}

		public AddBabei(pai:mjcore.MJPai, moqie:boolean, doanim:boolean = true): void {
			try {
				let _p:ViewPai = new ViewPai(pai, DesktopMgr.Inst.CreatePai3D(pai));
				this.pais.push(_p);
				if (view.DesktopMgr.Inst.showingPaopai) {
					_p.ismoqie = moqie;
					_p.ispaopai = DesktopMgr.Inst.isPaoPai(_p.val);
				}
				_p.OnChoosedPai();
				//添加影子
				{	
					let shadow:Laya.Sprite3D = pai.touming ? DesktopMgr.Inst.effect_shadow_touming.clone() : DesktopMgr.Inst.effect_shadow.clone();
					(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
					_p.effect_parent.addChild(shadow);
					shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
					shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
					shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
					shadow.active = true;
				}

				let rightest_index:number = 0;
				let model_rate:number = 1.02;

				this.origin.parent.addChild(_p.model);
				_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
				this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
				_p.ShowUp();
				_p.model.transform.localPosition.x -= this.xOffset;
				this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
				DesktopMgr.Inst.SetLastQiPai(this.player.seat, _p);

				//动画
				if (doanim) {
					let localpos:Laya.Vector3 = _p.model.transform.localPosition.clone();
					let pos:Laya.Vector3 = _p.model.transform.position.clone();
					this.player.hand3d.transform.position = pos.clone();
					let node:Laya.Sprite3D = this.player.hand3d.getChildAt(0).getChildByName('node_tile') as Laya.Sprite3D;
					node.addChild(_p.model);
					_p.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);

					_p.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
					_p.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					
					let _anim:iModelAnimation = ModelAnimationController.get_anim_config('Dapai', this.player.hand_type);
					this.player.playHandAnimtion(_anim);
					Laya.timer.once(_anim.keypoint[0], this, () => {
						AudioMgr.PlayAudio(207);
					});
					Laya.timer.once(_anim.keypoint[1], this, () => {
						if (_p && _p.model && !_p.model.destroyed) {
							this.origin.parent.addChild(_p.model);
							_p.model.transform.localScale = new Laya.Vector3(1, 1, 1);
							_p.ShowUp();
							_p.model.transform.localPosition = localpos;
						}
					});
					DesktopMgr.Inst.ActionRunComplete();
				}
			} catch (e) {
				let _errorinfo:Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'Babei';
				_errorinfo['class'] = 'Block_Babei';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public OnDoraRefresh(): void {
			if (this.pais != null) {
				for(let i:number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshDora();
				}
			}
		}

		public OnChoosedPai(): void {
			if (this.pais != null) {
				for(let i:number = 0; i < this.pais.length; i++) {
					this.pais[i].OnChoosedPai();
				}
			}
		}
	}
}