/**
* name 
*/
module view{
	export class Block_HuanSanZhang {

		private readonly CIRCLE_RADIUS:number = 0.22;
		private readonly CIRCLE_CENTER:Laya.Vector3 = new Laya.Vector3(0.01, 0.011, 0);

		private _container:Laya.Sprite3D;
		private _origin:Laya.Sprite3D;
		private _player:ViewPlayer;
		private viewpais: Array<ViewPai> = new Array<ViewPai>();
		private _anim_lifetime:number = 300;
		private _anim_starttime:number = 0;
		private _show_hand:boolean = false;

		constructor(_container: Laya.Sprite3D, player: ViewPlayer) {
			this._container = _container;
			this._origin = this._container.getChildByName('maque') as Laya.Sprite3D;
			this._player = player;
			this._container.active = false;
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.viewpais.length > 0) { 
				for (let i:number = 0; i < this.viewpais.length; i ++) {
					this.viewpais[i].model.destroy();
				}
				this.viewpais = [];
			}
			this._container.active = false;
		}

		private update_container_position(angle:number) {
			let x:number = Math.sin(angle * Math.PI / 180) * this.CIRCLE_RADIUS;
			let z:number = Math.cos(angle * Math.PI / 180) * this.CIRCLE_RADIUS;
			this._container.transform.localPosition = new Laya.Vector3(x + this.CIRCLE_CENTER.x, this.CIRCLE_CENTER.y, z + this.CIRCLE_CENTER.z);
			this._container.transform.localRotationEuler = new Laya.Vector3(this._container.transform.localRotationEuler.x, angle, 0);
		}

		private update_container_rotation(angle:number) {
			this._container.transform.localRotationEuler = new Laya.Vector3(180 - angle, this._container.transform.localRotationEuler.y, 0);
		}
		public show(pais:Array<mjcore.MJPai>, change_type:number) {
			let model_rate:number = 1.02;
			for (let i:number = 0; i < pais.length; i++) {
				let p:ViewPai = new ViewPai(pais[i], view.DesktopMgr.Inst.CreatePai3D(pais[i]));
				//添加影子
				// {
				// 	let shadow:Laya.Sprite3D = DesktopMgr.Inst.effect_shadow.clone();
				// 	p.model.addChild(shadow);
				// 	shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
				// 	shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
				// 	shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
				// 	shadow.active = false;
				// }
				this._container.addChild(p.model);
				p.model.transform.localPosition = this._origin.transform.localPosition.clone();
				p.ShowStand();
			
				p.model.transform.localPosition.x -= PAIMODEL_WIDTH * model_rate * i;
				p.model.transform.localPosition.y -= PAIMODEL_HEIGHT * model_rate * 0.5
				this.viewpais.push(p);
			}
			this._show_hand = view.DesktopMgr.Inst.mode != EMJMode.play && view.DesktopMgr.Inst.record_show_hand;
			this._container.active = true;
			let seat:number = view.DesktopMgr.Inst.seat2LocalPosition(this._player.seat);
			this.update_container_position(90 * seat);
			this.update_container_rotation(0);
			this._anim_starttime = Laya.timer.currTimer;
			Laya.timer.frameLoop(1, this, ()=>{
				this.anim_rot(change_type);
			});
			
		}

		private anim0() {
			let dt:number = Laya.timer.currTimer - this._anim_starttime;
			let seat:number = view.DesktopMgr.Inst.seat2LocalPosition(this._player.seat);
			if (dt <= 300) {
				this.update_container_position(90 * (seat + 0));
			} else if (dt <= 800) {
				let r:number = (dt - 300) / (800 - 300);
				this.update_container_position(90 * (seat + r));
			} else if (dt <= 1800) {
				this.update_container_position(90 * (seat + 1));
			} else {
				Laya.timer.clearAll(this);
				this.Reset();
			}
		}

		private anim1() {
			let dt:number = Laya.timer.currTimer - this._anim_starttime;
			let seat:number = view.DesktopMgr.Inst.seat2LocalPosition(this._player.seat);
			if (dt <= 300) {
				this.update_container_position(90 * (seat + 0));
			} else if (dt <= 800) {
				let r:number = (dt - 300) / (800 - 300);
				let x0:number = Math.sin(90 * (seat + 0) * Math.PI / 180) * this.CIRCLE_RADIUS;
				let x1:number = Math.sin(90 * (seat + 2) * Math.PI / 180) * this.CIRCLE_RADIUS;
				let z0:number = Math.cos(90 * (seat + 0) * Math.PI / 180) * this.CIRCLE_RADIUS;
				let z1:number = Math.cos(90 * (seat + 2) * Math.PI / 180) * this.CIRCLE_RADIUS;
				let x:number = x0 * (1 - r) + x1 * r;
				let z:number = z0 * (1 - r) + z1 * r;
				this._container.transform.localPosition = new Laya.Vector3(x + this.CIRCLE_CENTER.x, this.CIRCLE_CENTER.y, z + this.CIRCLE_CENTER.z);
			} else if (dt <= 1800) {
				let x:number = Math.sin(90 * (seat + 2) * Math.PI / 180) * this.CIRCLE_RADIUS;
				let z:number = Math.cos(90 * (seat + 2) * Math.PI / 180) * this.CIRCLE_RADIUS;
				this._container.transform.localPosition = new Laya.Vector3(x + this.CIRCLE_CENTER.x, this.CIRCLE_CENTER.y, z + this.CIRCLE_CENTER.z);
			} else {
				Laya.timer.clearAll(this);
				this.Reset();
			}
		}

		private anim2() {
			let dt:number = Laya.timer.currTimer - this._anim_starttime;
			let seat:number = view.DesktopMgr.Inst.seat2LocalPosition(this._player.seat);
			if (dt <= 300) {
				this.update_container_position(90 * (seat + 0));
			} else if (dt <= 800) {
				let r:number = (dt - 300) / (800 - 300);
				this.update_container_position(90 * (seat - r));
			} else if (dt <= 1800) {
				this.update_container_position(90 * (seat - 1));
			} else {
				Laya.timer.clearAll(this);
				this.Reset();
			}
		}

		private anim_rot(change_type:number) {
			let dt:number = Laya.timer.currTimer - this._anim_starttime;
			if (dt <= 500) {
			} else if(dt <= 700) {
				this.update_container_rotation((this._show_hand ? 90 : -90) * (dt - 500) / 200);
			} else {
				Laya.timer.clearAll(this);
				this.update_container_rotation(this._show_hand ? 90 : -90);
				this._anim_starttime = Laya.timer.currTimer;
				Laya.timer.frameLoop(1, this, ()=>{
					switch(change_type) {
						case 0: this.anim0(); break;
						case 1: this.anim1(); break;
						case 2: this.anim2(); break;
					}
				});
			}
		}
	}
}