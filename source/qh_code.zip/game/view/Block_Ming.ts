/**
* name 
*/
module view{

	export class Block_Ming{
		public origin: Laya.Sprite3D = null;
		public player: ViewPlayer = null;
		public xOffset: number = 0;
		public mings: Array<mjcore.MJMing> = new Array<mjcore.MJMing>();
		public pais: Array<ViewPai> = new Array<ViewPai>();
		public hengs: Array<number> = new Array<number> (); // 每个副露横向那张牌的x值

		private get seat():number {return this.player.seat;}

		constructor(_origin: Laya.Sprite3D, player: ViewPlayer) {
			this.origin = _origin;
			this.xOffset = 0;
			this.player = player;
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.pais.length > 0) { 
				for (let i:number = 0; i < this.pais.length; i ++) {
					this.pais[i].model.destroy();
				}
				this.pais = [];
			}
			this.mings = [];
			this.hengs = [];
			this.xOffset = 0;
		}

		public AddMing(ming:mjcore.MJMing, doanim:boolean = true): void {
			try {
				this.mings.push(ming);
				let _heng_x:number = 0;
				let lst: Array<ViewPai> = new Array<ViewPai>();
				for (let i = 0; i < ming.pais.length; i++) {
					lst.push(new ViewPai(ming.pais[i], DesktopMgr.Inst.CreatePai3D(ming.pais[i])));
					this.pais.push(lst[i]);
					if (view.DesktopMgr.Inst.showingPaopai) {
						lst[i].ispaopai = DesktopMgr.Inst.isPaoPai(lst[i].val);
					}
					
					lst[i].OnChoosedPai();
					//添加影子
					{
						let shadow:Laya.Sprite3D = lst[i].val.touming ? DesktopMgr.Inst.effect_shadow_touming.clone() : DesktopMgr.Inst.effect_shadow.clone();
						(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
						lst[i].effect_parent.addChild(shadow);
						shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
						shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
						shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						shadow.active = true;
					}
				}
				let rightest_index:number = 0;
				let model_rate:number = 1.02;
				if (ming.type == mjcore.E_Ming.shunzi) {
					//顺子
					let arrIndex: Array<number> = new Array<number>();
					let otherindex:number = -1;
					for (let i = 0; i < 3; i++) {
						if (ming.from[i] != this.seat) {
							otherindex = i;
						} else {
							arrIndex.push(i);
						}
					} 
					arrIndex = arrIndex.sort(function(a,b){ 
						return -mjcore.MJPai.Distance(ming.pais[a],ming.pais[b]);
					});
					if (otherindex != -1) arrIndex.push(otherindex);
					rightest_index = arrIndex[0];

					for (let i = 0; i < 3; i++) {
						let _index: number = arrIndex[i];
						let _p: ViewPai = lst[_index];
						
						this.origin.parent.addChild(_p.model);
						
						_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
						
						if (ming.from[_index] != this.seat) {
							//吃了别家
							this.xOffset += PAIMODEL_HEIGHT * 0.5 * model_rate;
							_p.ShowRot();
							_p.model.transform.localPosition.x -= this.xOffset;
							_p.model.transform.localPosition.z -= (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5;
							_heng_x = this.xOffset;
							this.xOffset += PAIMODEL_HEIGHT * 0.5 * model_rate;
							
						} else {
							if (DesktopMgr.Inst.is_tianming_mode()) {
								if (DesktopMgr.Inst.mode == EMJMode.play || !DesktopMgr.Inst.record_show_hand) {
									_p.SetTianMingYellow(this.seat == DesktopMgr.Inst.seat && _p.val.touming);
								} else {
									_p.SetTianMingYellow(_p.val.touming);
								}
							}
							//自己的牌
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
							_p.ShowUp();
							_p.model.transform.localPosition.x -= this.xOffset;
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
						}
					}
					
				} else if(ming.type == mjcore.E_Ming.kezi || ming.type == mjcore.E_Ming.gang_ming) {
					//刻子、杠子
					let arrIndex: Array<number> = new Array<number>();
					for (let i = 0; i < ming.pais.length; i++) arrIndex.push(i);
					for (let i = 0; i < ming.pais.length; i++) {
						if (ming.from[i] == this.seat) continue;
						let offset:number = 0;
						let pos_me:number = DesktopMgr.Inst.seat2LocalPosition(this.seat);
						let pos_t:number = DesktopMgr.Inst.seat2LocalPosition(ming.from[i]);
						switch((pos_t - pos_me + 4) % 4) {
							case 1: offset = 0; break;
							case 2: offset = ming.pais.length - 2; break;
							case 3: offset = ming.pais.length - 1; break;
						}

						let tmp: number = arrIndex[i];
						arrIndex[i] = arrIndex[offset];
						arrIndex[offset] = tmp;

						if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
						
							for (let j = 0; j < ming.pais.length - 1; j++) {
								// 找来自自己的非透牌
								if (!ming.pais[j].touming && j != offset) {
									let __index = -1;
									// 找出非换过位置的牌
									for (let k = ming.pais.length - 1; k > j; k--) {
										if (k != offset) {
											__index = k;
											break;
										}
									}
									if (__index != -1) {
										let _temp = arrIndex[__index];
										arrIndex[__index] = arrIndex[j];
										arrIndex[j] = _temp;
									}
								}
							}
						}
						break;
					}
					
					rightest_index = arrIndex[0];
					for (let i = 0; i < ming.pais.length; i++) {
						let _index: number = arrIndex[i];
						let _p: ViewPai = lst[_index];
						this.origin.parent.addChild(_p.model);
						_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
						if (ming.from[_index] != this.seat) {
							//别家
							this.xOffset += PAIMODEL_HEIGHT * 0.5 * model_rate;
							_p.ShowRot();
							_p.model.transform.localPosition.x -= this.xOffset;
							_p.model.transform.localPosition.z -= (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5 * model_rate;
							_heng_x = this.xOffset;
							this.xOffset += PAIMODEL_HEIGHT * 0.5 * model_rate;
						} else {
							if (DesktopMgr.Inst.is_tianming_mode()) {
								if (DesktopMgr.Inst.mode == EMJMode.play || !DesktopMgr.Inst.record_show_hand) {
									_p.SetTianMingYellow(this.seat == DesktopMgr.Inst.seat && _p.val.touming);
								} else {
									_p.SetTianMingYellow(_p.val.touming);
								}
							}
							//自己的牌
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
							_p.model.transform.localPosition.x -= this.xOffset;
							_p.ShowUp();
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
						}
					}
					// if (ming.pais.length == 4) {
					// 	let _index: number = arrIndex[3];
					// 	let _p: ViewPai = lst[_index];
					// 	this.origin.parent.addChild(_p.model);
					// 	_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
					// 	_p.ShowRot();
					// 	_p.model.transform.localPosition.x -= _heng_x;
					// 	_p.model.transform.localPosition.z = _p.model.transform.localPosition.z - (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5  * model_rate + PAIMODEL_WIDTH * model_rate;
					// }
				} else {
					//暗杠
					rightest_index = 0;
					for (let i = 0; i < 4; i++) {
						let _index: number = i;
						let _p: ViewPai = lst[_index];
						if (i == 1) {
							DesktopMgr.Inst.SetLastQiPai(this.player.seat, _p);
							app.Log.log('======= SetLastQiPai');
						}
						this.origin.parent.addChild(_p.model);
						_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
						if (DesktopMgr.Inst.is_tianming_mode()) {
							if (DesktopMgr.Inst.mode == EMJMode.play || !DesktopMgr.Inst.record_show_hand) {
								_p.SetTianMingYellow(this.seat == DesktopMgr.Inst.seat && _p.val.touming);
							} else {
								_p.SetTianMingYellow(_p.val.touming);
							}
						}
						if (i == 1 || i == 2) {
							// 中间2张
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
							_p.ShowUp();
							_p.model.transform.localPosition.x -= this.xOffset;
							// _p.model.transform.localPosition.z -= (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5 * model_rate;
							_heng_x = this.xOffset;
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
							
						} else {
							
							//外侧2张
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
							_p.model.transform.localPosition.x -= this.xOffset;
							_p.ShowBack();
							this.xOffset += PAIMODEL_WIDTH * 0.5 * model_rate;
						}
					}
				}
				this.hengs.push(_heng_x);

				//动画
				if (doanim) {
					AudioMgr.PlayAudio(209);
					let container: Laya.Sprite3D = new Laya.Sprite3D();
					this.origin.parent.addChild(container);
					container.transform.localPosition = lst[rightest_index].model.transform.localPosition.clone();
					// container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
					// container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
					container.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					container.transform.localScale = new Laya.Vector3(1, 1, 1);
					let poss:Array<Laya.Vector3> = [];
					let p1:Laya.Vector3 = lst[rightest_index].model.transform.localPosition.clone();

					for (let i:number = 0 ; i < lst.length; i++) {
						let p0 = lst[i].model.transform.localPosition.clone();
						poss.push(new Laya.Vector3(p0.x - p1.x, p0.y - p1.y, p0.z - p1.z));
					}

					for (let i:number = 0; i < lst.length; i++) {
						container.addChild(lst[i].model);
						lst[i].model.transform.localPosition = poss[i].clone();
					}

					let pos = container.transform.position.clone();
					this.player.hand3d.transform.position = pos.clone();
					let node = this.player.hand3d.getChildAt(0).getChildByName('node_tile');
					node.addChild(container);
					container.transform.localPosition = new Laya.Vector3(0, 0, 0);
					container.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
					container.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);

					let anim = view.ModelAnimationController.get_anim_config('Fulu', this.player.hand_type);
					this.player.playHandAnimtion(anim);

					container.active = false;
					// app.Log.log('======= container.active = false');
					Laya.timer.once(anim.keypoint[0], this, ()=>{
						//关键帧0：牌倒在桌面上
						container.active = true;
						// app.Log.log('======= 关键帧0：牌倒在桌面上');
					});

					Laya.timer.once(anim.keypoint[1], this, () => {
						//关键帧1：牌脱离手
						// app.Log.log('======= 关键帧1：牌脱离手');
						try {
							this.origin.parent.addChild(container);
							container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
							container.transform.position = pos;
							container.transform.localScale = new Laya.Vector3(1, 1, 1);
							for (let i:number = 0; i < lst.length; i++) {
								this.origin.parent.addChild(lst[i].model);
								let pp:Laya.Vector3 = lst[i].model.transform.localPosition.clone();
								pp.x += p1.x;
								pp.y += p1.y;
								pp.z += p1.z;
								lst[i].model.transform.localPosition = pp;
								// if (view.DesktopMgr.Inst.lastqipai === lst[i] && view.DesktopMgr.Inst.effect_pai_canchi.active) {
								// 	view.DesktopMgr.Inst.ShowChiPengEffect();
								// 	// app.Log.log("======== 关键帧1：重置effect");
								// }
							}
							DesktopMgr.Inst.ActionRunComplete();
						} catch (e) {
							let _errorinfo:Object = {};
							_errorinfo['error'] = e.message;
							_errorinfo['stack'] = e.stack;
							_errorinfo['method'] = 'AddMing2';
							_errorinfo['ming'] = ming.toString();
							_errorinfo['class'] = 'Block_Ming';
							GameMgr.Inst.onFatalError(_errorinfo);
						}
					});

					Laya.timer.once(33, this, () => {
						try {
							if (container == null || container.destroyed) return;
							let name_effect_ming:string = 'scene/effect_mingpai_default.lh'; //view.DesktopMgr.Inst.player_effects[this.player.seat]['effect_ming'];
							let effect:game.EffectBase = new game.EffectBase(name_effect_ming);
							this.origin.parent.addChild(effect.root);
							effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
							effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
							effect.root.active = true;

							Laya.timer.frameLoop(1, effect, ()=>{
								if (container && !container.destroyed) {
									effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
									effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
								}
							});
							
							Laya.timer.once(1500, effect, () => {
								if (effect) {
									Laya.timer.clearAll(effect);
									effect.destroy();
								}
								if (container) container.destroy();
							});
						}  catch (e) {
							let _errorinfo:Object = {};
							_errorinfo['error'] = e.message;
							_errorinfo['stack'] = e.stack;
							_errorinfo['method'] = 'AddMing4';
							_errorinfo['ming'] = ming.toString();
							_errorinfo['class'] = 'Block_Ming';
							GameMgr.Inst.onFatalError(_errorinfo);
						}
					});
				}
			} catch (e) {
				let _errorinfo:Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'AddMing';
				_errorinfo['ming'] = ming.toString();
				_errorinfo['class'] = 'Block_Ming';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public AddGang(pai:mjcore.MJPai, doanim:boolean = true): void {
			let model_rate:number = 1.02;
			for (let i:number = 0; i < this.mings.length; i++) {
				if (this.mings[i].type == mjcore.E_Ming.kezi && mjcore.MJPai.Distance(this.mings[i].pais[0], pai) == 0) {
					this.mings[i].type = mjcore.E_Ming.gang_ming;
					this.mings[i].pais.push(pai.Clone());
					this.mings[i].from.push(this.player.seat);
					let _p:ViewPai = new ViewPai(pai, DesktopMgr.Inst.CreatePai3D(pai));
					this.origin.parent.addChild(_p.model);
					_p.model.transform.localPosition = this.origin.transform.localPosition.clone();
					_p.ShowRot();
					_p.model.transform.localPosition.x -= this.hengs[i];
					_p.model.transform.localPosition.z = _p.model.transform.localPosition.z - (PAIMODEL_HEIGHT - PAIMODEL_WIDTH) * 0.5 * model_rate + PAIMODEL_WIDTH * model_rate;
					DesktopMgr.Inst.SetLastQiPai(this.player.seat, _p);
					if (DesktopMgr.Inst.is_tianming_mode()) {
						if (DesktopMgr.Inst.mode == EMJMode.play || !DesktopMgr.Inst.record_show_hand) {
							_p.SetTianMingYellow(this.seat == DesktopMgr.Inst.seat && _p.val.touming);
						} else {
							_p.SetTianMingYellow(_p.val.touming);
						}
					}
					this.pais.push(_p);
					if (view.DesktopMgr.Inst.showingPaopai) {
						_p.ispaopai = DesktopMgr.Inst.isPaoPai(_p.val);
					}
					_p.OnChoosedPai();
					//添加影子
					{
						let shadow:Laya.Sprite3D = _p.val.touming ? DesktopMgr.Inst.effect_shadow_touming.clone() : DesktopMgr.Inst.effect_shadow.clone();
						(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
						_p.effect_parent.addChild(shadow);
						shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
						shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
						shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						shadow.active = true;
					}

					if (doanim) {
						AudioMgr.PlayAudio(209);
						let container: Laya.Sprite3D = new Laya.Sprite3D();
						this.origin.parent.addChild(container);
						container.transform.localPosition = _p.model.transform.localPosition.clone();
						// container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
						container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
						container.transform.localScale = new Laya.Vector3(1, 1, 1);

						let poss:Laya.Vector3 = _p.model.transform.localPosition.clone();

						container.addChild(_p.model);
						_p.model.transform.localPosition = new Laya.Vector3(0,0,0);

						let pos = container.transform.position.clone();
						this.player.hand3d.transform.position = pos.clone();
						let node = this.player.hand3d.getChildAt(0).getChildByName('node_tile');
						node.addChild(container);
						container.transform.localPosition = new Laya.Vector3(0, 0, 0);
						container.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
						// container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
						container.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);

						let anim = view.ModelAnimationController.get_anim_config('Fulu', this.player.hand_type);
						this.player.playHandAnimtion(anim);

						container.active = false;
						Laya.timer.once(anim.keypoint[0], this, ()=>{
							container.active = true;
						});

						Laya.timer.once(anim.keypoint[1], this, () => {
							this.origin.parent.addChild(container);
							container.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
							container.transform.localScale = new Laya.Vector3(1, 1, 1);
							container.transform.position = pos;
							this.origin.parent.addChild(_p.model);
							_p.model.transform.localPosition = poss;
							// if (DesktopMgr.Inst.lastqipai === _p && uiscript.UI_ChiPengHu.Inst.enable) {
							// 	DesktopMgr.Inst.ShowChiPengEffect();
							// }
							DesktopMgr.Inst.ActionRunComplete();
						});


						Laya.timer.once(33, this, () => {
							if (container == null || container.destroyed) return;
							let name_effect_ming:string = 'scene/effect_mingpai_default.lh'; //view.DesktopMgr.Inst.player_effects[this.player.seat]['effect_ming'];
							let effect:game.EffectBase = new game.EffectBase(name_effect_ming);
							this.origin.parent.addChild(effect.root);
							effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
							effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
							effect.root.active = true;

							Laya.timer.frameLoop(1, effect, ()=>{
								if (container && !container.destroyed) {
									effect.root.transform.worldMatrix = container.transform.worldMatrix.clone();
									effect.root.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
								}
							});
							
							Laya.timer.once(1500, effect, () => {
								if (effect) {
									Laya.timer.clearAll(effect);
									effect.destroy();
								}
								if (container) container.destroy();
							});
						});
					}

					break;
				}
			}
		}

		public OnDoraRefresh(): void {
			if (this.pais != null) {
				for(let i:number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshDora();
				}
			}
		}

		public OnChoosedPai(): void {
			if (this.pais != null) {
				for(let i:number = 0; i < this.pais.length; i++) {
					this.pais[i].OnChoosedPai();
				}
			}
		}

		public onShowHandChange() {
			if (DesktopMgr.Inst.is_tianming_mode()) {
				for(let _p of this.pais) {
					if (DesktopMgr.Inst.mode == EMJMode.play || !DesktopMgr.Inst.record_show_hand) {
						_p.SetTianMingYellow(this.seat == DesktopMgr.Inst.seat && _p.val.touming);
					} else {
						_p.SetTianMingYellow(_p.val.touming);
					}
				}
			}
		}
	}
}