/**
* name 
*/
module view {
	interface IPaiTransform {
		/** 手立直的动作还未发生时牌的位置 */
		pos: Laya.Vector3;
	}
	export class Block_QiPai {
		public player: ViewPlayer = null;
		public origin: Laya.Sprite3D = null;
		public pais: Array<ViewPai> = null;
		public cx: number = 0;
		public cy: number = 0;
		public last_pai: ViewPai = null;
		public last_is_liqi: boolean = false;
		public after_liqi: boolean = false;
		public waiting_offset: Laya.Vector2 = new Laya.Vector2(PAIMODEL_WIDTH * 0.4, PAIMODEL_HEIGHT * 0.4);
		public xwidth: number = 0;
		private last_pai_val: mjcore.MJPai;
		private last_pai_count: number = 0; // 用来计算连续打牌的心理语音
		private dora_yuyin_played: boolean = false; // dora心理语音只在第一次出现
		private duringPaiAni: boolean = false;

		constructor(_origin: Laya.Sprite3D, player: ViewPlayer) {
			this.origin = _origin;
			this.pais = new Array<ViewPai>();
			this.player = player;
		}

		//增加新的弃牌，还没通过
		public AddQiPai(val: mjcore.MJPai, isLiqi: boolean, moqie: boolean, doanim: boolean = true, revealState: ERevealState = ERevealState.None): void {
			this.QiPaiPass();
			let p: ViewPai = new ViewPai(val, DesktopMgr.Inst.CreatePai3D(val));
			if (view.DesktopMgr.Inst.showingPaopai) {
				p.ismoqie = moqie;
				p.ispaopai = DesktopMgr.Inst.isPaoPai(p.val);
			}
			p.OnChoosedPai();
			if (revealState != ERevealState.None) {
				p.SetRevealState(revealState);
			}
			let scaleZ = revealState == ERevealState.reveal ? -1 : 1;
			let scaleX = revealState == ERevealState.reveal ? -1 : 1;
			this.origin.parent.addChild(p.model);
			// if (isLiqi) this.after_liqi = true;
			if (this.last_is_liqi && !isLiqi) isLiqi = true;
			let angle: number = Math.atan(PAIMODEL_HEIGHT / PAIMODEL_WIDTH);
			let random_angle: number = (Math.random() - 0.5) * 2 * 2;
			// random_angle = 0;
			let xwidth: number = 0;
			let dx: number = 0;
			if (!isLiqi) {
				p.model.transform.localRotationEuler = new Laya.Vector3(90, random_angle, 0);
				xwidth = Math.sqrt(PAIMODEL_HEIGHT * PAIMODEL_HEIGHT + PAIMODEL_WIDTH * PAIMODEL_WIDTH) / 2 * Math.cos(angle - Math.abs(random_angle) * 3.1415926 / 180) * 2 + PAIMODEL_WIDTH * 0.01;
				dx = (xwidth - PAIMODEL_WIDTH) / 2;
			}
			else {
				p.model.transform.localRotationEuler = new Laya.Vector3(90, -90 - random_angle, 0);
				xwidth = Math.sqrt(PAIMODEL_HEIGHT * PAIMODEL_HEIGHT + PAIMODEL_WIDTH * PAIMODEL_WIDTH) / 2 * Math.cos(90 * 3.1415926 / 180 - angle - Math.abs(random_angle) * 3.1415926 / 180) * 2 + PAIMODEL_WIDTH * 0.01;
				dx = (xwidth - PAIMODEL_WIDTH) / 2;
			}

			let rx: number = 0;
			let ry: number = 0;
			let x: number = this.cx + dx;
			let y: number = this.cy;
			if (Math.random() < 0.2) {
				rx = Math.random() * PAIMODEL_WIDTH * 0.025;
				// rx = 0;
				xwidth += rx;
				x += rx;
			}
			this.xwidth = xwidth;
			ry = (Math.random() - 0.5) * 2 * PAIMODEL_HEIGHT * 0.025;
			// ry = 0;
			y += ry;
			p.model.transform.localPosition = this.origin.transform.localPosition.clone();

			p.model.active = true;
			p.model.transform.localPosition.x += x;
			p.model.transform.localPosition.z -= y;

			if (doanim) {
				let pos: Laya.Vector3 = p.model.transform.position.clone();
				this.player.hand3d.transform.position = pos.clone();
				let node: Laya.Sprite3D = this.player.hand3d.getChildAt(0).getChildByName('node_tile') as Laya.Sprite3D;
				node.addChild(p.model);

				p.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
				p.model.transform.localRotationEuler = new Laya.Vector3(0, 0, -((isLiqi ? -90 : 0) - random_angle));
				p.model.transform.localScale = new Laya.Vector3(1.1111 * scaleX, 1.1111, 1.1111 * scaleZ);

				let anim: iModelAnimation = null;
				if (isLiqi) {
					let effect_liqi_id: number = view.DesktopMgr.Inst.player_effects[this.player.seat][game.EView.lizhi_effect];
					if (effect_liqi_id) {
						let d_view = cfg.item_definition.view.get(effect_liqi_id);
						let effect_liqi: string = '';
						//如果是4个方向的立直特效，根据位置更改特效名字，主视角是0
						if (d_view.seat_related && d_view.seat_related == 1) {
							let seat = view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat);
							effect_liqi = `scene/${d_view.res_name}${seat}.lh`;
						} else {
							effect_liqi = `scene/${d_view.res_name}.lh`;
						}
						let isShu = d_view.sargs.length < 0 || !d_view.sargs[0] || d_view.sargs[0] == 'shu';
						let animName = isShu ? 'Dapai' : 'LiQiPai';
						anim = ModelAnimationController.get_anim_config(animName, this.player.hand_type);
						Laya.timer.once(anim.keypoint[0], this, () => {
							if (!d_view.old_effect_mark) {
								this.setCommonLiqiEffect(p, { pos }, d_view);
								return;
							}
							if (isShu) {
								let _effect: game.EffectBase = new game.EffectBase(effect_liqi);
								DesktopMgr.Inst.trans_container_effect.addChild(_effect.root);
								let pos = p.model.transform.position.clone();
								pos.y = 0;
								_effect.root.transform.position = pos;
								_effect.root.active = true;
								if (effect_liqi == 'scene/effect_liqi_21winter.lh') {
									_effect.root.transform.localRotationEuler = new Laya.Vector3(0, view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
								}
								let audio_id: number = d_view.audio_id;
								if (audio_id) view.AudioMgr.PlayAudio(audio_id);
								Laya.timer.once(5000, null, () => {
									if (_effect && !_effect.destroyed) {
										Laya.timer.clearAll(_effect);
										_effect.destroy();
									}
								});
								_effect.addLoadedListener(Laya.Handler.create(this, () => {
									if (!p || !p.model || p.model.destroyed) return;
									let pai_anim = game.Tools.GetNodeByNameInChildren(_effect.root, 'pai_anim') as Laya.Sprite3D;
									if (pai_anim) {
										Laya.timer.frameOnce(1, this, () => {
											if (!p || !p.model || p.model.destroyed) return;
											let _origin_rotation = p.model.transform.rotation.clone();
											let _origin_pos = p.model.transform.worldMatrix.clone();
											pai_anim.addChild(p.model);
											p.model.transform.rotation = _origin_rotation;
											p.model.transform.worldMatrix = _origin_pos;
										});
									}
								}));
								Laya.timer.once(3000, this, () => {
									if (p && p.model && !p.model.destroyed) {
										let _origin_rotation = p.model.transform.rotation.clone();
										let _origin_pos = p.model.transform.worldMatrix.clone();
										this.origin.parent.addChild(p.model);
										p.model.transform.rotation = _origin_rotation;
										p.model.transform.worldMatrix = _origin_pos;
									}
								});
							} else {
								let _effect: game.EffectBase = new game.EffectBase(effect_liqi);
								_effect.root.transform.localRotationEuler = new Laya.Vector3(90, 180, 90);
								this.origin.parent.addChild(_effect.root);
								let audio_id: number = d_view.audio_id;
								if (audio_id > 0) view.AudioMgr.PlayAudio(audio_id);
								if (effect_liqi == 'scene/effect_liqi_xiyuansi.lh') {
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let buzhuan: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'buzhuan') as Laya.Sprite3D;
										buzhuan.transform.localRotationEuler = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
									}));
								}
								if (effect_liqi == 'scene/effect_liqi_22summer.lh') {
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let vec3 = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
										let yazi = game.Tools.GetNodeByNameInChildren(_effect.root, 'ya') as Laya.Sprite3D;
										for (let i = 0; i < 3; i++) {
											(yazi.getChildAt(i) as Laya.Sprite3D).transform.localRotationEuler = vec3;
										}
									}));
								}

								if (effect_liqi == 'scene/effect_liqi_beiyuan.lh') {
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let vec3 = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
										(game.Tools.GetNodeByNameInChildren(_effect.root, 'ci_xuanzhuan') as Laya.Sprite3D).transform.localRotationEuler = vec3;

									}));
								}
								if (effect_liqi == 'scene/effect_liqi_23ex_xueqiu.lh') {
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let buzhuan: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'GameObject') as Laya.Sprite3D;
										buzhuan.transform.localRotationEuler = new Laya.Vector3(0, 0, 180);
									}));
								}
								if (effect_liqi == 'scene/effect_liqi_23ex_liandao.lh') {
									if (view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) == 2) {
										_effect.addLoadedListener(Laya.Handler.create(this, () => {
											let anim: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'anim') as Laya.Sprite3D;
											let vec3 = new Laya.Vector3(41, 0, 0);
											anim.transform.localRotationEuler = vec3;

										}));
									}
								}

								if (effect_liqi == 'scene/effect_liqi_22chunjie.lh') {

									let _effect: game.EffectBase = new game.EffectBase('scene/effect_liqi_22chunjie_hongdi.lh');
									view.DesktopMgr.Inst.desktop3D.addChild(_effect.root);
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let hongdi: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'hongdi') as Laya.Sprite3D;

										for (let child of hongdi._childs) {
											(child as Laya.ShuriKenParticle3D).particleRender.material.renderQueue = 3001;
										}

									}));
									_effect.root.transform.position = new Laya.Vector3(0, 0, 0);
									_effect.root.active = true;
									Laya.timer.once(2500, this, () => {
										_effect.destroy();
									});

								}
								if (effect_liqi == 'scene/effect_liqi_24ba.lh') {

									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let node = game.Tools.GetNodeByNameInChildren(_effect.root, 'position') as Laya.Sprite3D;
										let anim = node.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
										anim.Play(null);
										let vec3 = new Laya.Vector3(45, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
										(game.Tools.GetNodeByNameInChildren(_effect.root, 'rot') as Laya.Sprite3D).transform.localRotationEuler = vec3;
									}));

								}
								if (effect_liqi == 'scene/effect_liqi_nanfenghua.lh') {
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										let root_nanfenghua: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'fx_liqi_073') as Laya.Sprite3D;
										let buzhuan1: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(root_nanfenghua, '002') as Laya.Sprite3D;
										let buzhuan2: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(root_nanfenghua, 'liqi_niao') as Laya.Sprite3D;
										let vec3 = new Laya.Vector3(0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
										buzhuan1.transform.localRotationEuler = vec3;
										buzhuan2.transform.localRotationEuler = vec3;
									}));
								}
								Laya.timer.frameLoop(1, _effect, () => {
									if (p && p.model && !p.model.destroyed) {
										_effect.root.transform.worldMatrix = p.model.transform.worldMatrix.clone();
									} else {
										Laya.timer.clearAll(_effect);
										_effect.destroy();
									}
								});
								Laya.timer.once(3000, null, () => {
									if (_effect && !_effect.destroyed) {
										Laya.timer.clearAll(_effect);
										_effect.destroy();
									}
								});
							}
						});
					} else {
						anim = ModelAnimationController.get_anim_config('Dapai', this.player.hand_type);
					}
				} else {
					anim = ModelAnimationController.get_anim_config('Dapai', this.player.hand_type);
				}

				this.player.playHandAnimtion(anim);
				Laya.timer.once(anim.keypoint[0], this, () => {
					AudioMgr.PlayAudio(207);
				});
				Laya.timer.once(anim.keypoint[1], this, () => {
					if (p && p.model && !p.model.destroyed) {
						this.origin.parent.addChild(p.model);
						p.model.transform.localScale = new Laya.Vector3(1 * scaleX, 1, 1 * scaleZ);
						if (!isLiqi) {
							p.model.transform.localRotationEuler = new Laya.Vector3(90, random_angle, 0);
						}
						else {
							p.model.transform.localRotationEuler = new Laya.Vector3(90, -90 - random_angle, 0);
						}
						this.last_pai.model.transform.localPosition = this.origin.transform.localPosition.clone();
						this.last_pai.model.transform.localPosition.x += x;
						this.last_pai.model.transform.localPosition.z -= y;
					}
				});
			}

			this.last_pai = p;
			this.last_is_liqi = isLiqi;
			DesktopMgr.Inst.SetLastQiPai(this.player.seat, p);

			//添加影子
			{
				let shadow: Laya.Sprite3D = val.touming ? DesktopMgr.Inst.effect_shadow_touming.clone() : DesktopMgr.Inst.effect_shadow.clone();
				(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
				p.effect_parent.addChild(shadow);
				shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
				shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
				shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
				shadow.active = true;
			}

			// 心理语音：连打同一张牌
			if ((DesktopMgr.Inst.mode == EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) || DesktopMgr.Inst.mode == EMJMode.play) {
				if (!doanim || revealState != ERevealState.None) {
					this.last_pai_val = null;
					this.last_pai_count = 0;
				} else {
					if (this.last_pai_val && mjcore.MJPai.Distance(this.last_pai_val, val) == 0) {
						this.last_pai_count++;
						if (this.last_pai_count == 3) {
							DesktopMgr.Inst.addMindVoice(this.player.seat, 'ingame_lianda');
						}
					} else {
						this.last_pai_val = val.Clone();
						this.last_pai_count = 1;
					}
					let isDora: boolean = false;
					if (val.dora) isDora = true;
					if (!isDora) {
						for (let i: number = 0; i < DesktopMgr.Inst.dora.length; i++) {
							if (mjcore.MJPai.DoraMet(val, DesktopMgr.Inst.dora[i])) {
								isDora = true;
								break;
							}
						}
					}
					let pai_v: string = val.numValue.toString();
					if (isDora && !this.dora_yuyin_played) {
						DesktopMgr.Inst.addMindVoice(this.player.seat, 'ingame_baopai');
						this.dora_yuyin_played = true;
					}
				}
			} else {
				this.last_pai_val = null;
				this.last_pai_count = 0;
			}
		}

		private setCommonLiqiEffect(pai: ViewPai, paiTransform: IPaiTransform, data: lqc.Sheet_ItemDefinition_View) { //用于2411版本之后的所有立直特效
			let effectId: string = '';
			//如果是4个方向的立直特效，根据位置更改特效名字，主视角是0
			if (data.seat_related && data.seat_related == 1) {
				let seat = view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat);
				effectId = `scene/${data.res_name}${seat}.lh`;
			} else {
				effectId = `scene/${data.res_name}.lh`;
			}
			let effect: game.EffectBase = new game.EffectBase(effectId);
			let audio_id: number = data.audio_id;
			DesktopMgr.Inst.trans_container_effect.addChild(effect.root);
			effect.root.transform.position = new Laya.Vector3(0, 0, 0);
			effect.root.active = true;
			this.duringPaiAni = false;
			effect.addLoadedListener(Laya.Handler.create(this, () => {
				if (!pai || !pai.model || pai.model.destroyed) {
					effect.destroy();
					return;
				}
				if (audio_id) view.AudioMgr.PlayAudio(audio_id);
				//显示在特效之上的麻将Queue固定为3090（使用sargs[1]字段）
				if (data.sargs[1]) {
					game.Tools.changePaiMat(pai.model, 3090, 3089, 513);
					game.Tools.dfsChangeParticleMat(effect.root);
				}
				let effectRoot = effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D; //所有立直特效分为以下三个部分
				let root_rot: Laya.Sprite3D = effectRoot.getChildByName('root_rot') as Laya.Sprite3D;  //需要控制旋转，和 牌的方向 一致
				let root_move: Laya.Sprite3D = effectRoot.getChildByName('root_move') as Laya.Sprite3D; //动画部分，永远朝向主视角
				let root_static: Laya.Sprite3D = effectRoot.getChildByName('root_static') as Laya.Sprite3D;  //静止部分：例如遮罩黑
				let root_ani: Laya.Sprite3D = effectRoot.getChildByName('root_ani') as Laya.Sprite3D;  //牌的特殊动画
				let root_maque: Laya.Sprite3D = effectRoot.getChildByName('root_maque') as Laya.Sprite3D;  //固定在牌最终停放的位置的位置
				let haveSpecialAni = root_ani && root_ani.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				let isShu = data.sargs.length < 0 || !data.sargs[0] || data.sargs[0] == 'shu';
				let _origin_worldMatrix = pai.model.transform.worldMatrix.clone();
				let _origin_pos = pai.model.transform.position.clone();
				let _origin_rotation = pai.model.transform.rotation.clone();
				root_move.transform.position = _origin_pos.clone();
				root_rot.transform.position = _origin_pos.clone();
				root_rot.transform.rotation = _origin_rotation.clone();
				if (root_maque) root_maque.transform.position = paiTransform.pos.clone();
				const paiAnimMostDelay = 2000;
				if (isShu && haveSpecialAni) { //有特殊牌动画的特效，特别特别特别少, 目前还未使用
					app.Log.log('立直特效有牌动画');
					this.duringPaiAni = true;
					root_ani.transform.position = _origin_pos.clone();
					(root_ani.getChildAt(0) as Laya.Sprite).destroyChildren();
					(root_ani.getChildAt(0) as Laya.Sprite).addChild(pai.model);
					// 清除所有其他计时器
					if (pai['ResetAllTimer']) {
						pai['ResetAllTimer']();
					}
					pai.model.transform.worldMatrix = _origin_worldMatrix.clone();
					Laya.timer.once(paiAnimMostDelay, null, () => {//重置回牌的位置
						if (pai && pai.model && !pai.model.destroyed && this.duringPaiAni) {
							this.origin.parent.addChild(pai.model);
							pai.model.transform.worldMatrix = _origin_worldMatrix.clone();
						}
						this.duringPaiAni = false;
					});
				} else { //常规立直特效
					Laya.timer.frameLoop(1, effect, () => {
						if (pai && pai.model && !pai.model.destroyed) {
							root_move.transform.position = pai.model.transform.position.clone();
							root_rot.transform.position = pai.model.transform.position.clone();
							root_rot.transform.rotation = pai.model.transform.rotation.clone();
						} else {
							Laya.timer.clearAll(effect);
							effect.destroy();
						}
					});
				}
				let localization = game.Tools.GetNodeByNameInChildren(effect.root, 'localization') as Laya.Sprite3D;
				if (localization) {
					localization._childs.forEach(v => v.active = false);
					let nodeName = GameMgr.client_language;
					if (localization.getChildByName(nodeName)) {
						(localization.getChildByName(nodeName) as Laya.Sprite3D).active = true;
					} else if (localization.getChildByName('common')) {
						(localization.getChildByName('common') as Laya.Sprite3D).active = true;
					}
				}
			}));
			Laya.timer.once(3000, null, () => {
				if (pai && pai.model && !pai.model.destroyed) {
					if (data && data.sargs[1]) {
						game.Tools.changePaiMat(pai.model, 2000, 3001, 513);
					}
				}
				Laya.timer.clearAll(effect);
				effect.destroy();
			});
		}

		// 最后一张是立直牌但是没有通过 要转回来
		public LiqiFailed(doanim: boolean = true): void {
			if (!this.last_pai) return;
			this.last_is_liqi = false;
			let xwidth: number = 0;
			let dx: number = 0;
			let angle: number = Math.atan(PAIMODEL_HEIGHT / PAIMODEL_WIDTH);
			let random_angle: number = (Math.random() - 0.5) * 2 * 2;
			let target_angle: number = random_angle;
			xwidth = Math.sqrt(PAIMODEL_HEIGHT * PAIMODEL_HEIGHT + PAIMODEL_WIDTH * PAIMODEL_WIDTH) / 2 * Math.cos(angle - Math.abs(random_angle) * 3.1415926 / 180) * 2 + PAIMODEL_WIDTH * 0.01;
			dx = (xwidth - PAIMODEL_WIDTH) / 2;

			let rx: number = 0;
			let ry: number = 0;
			let x: number = this.cx + dx;
			let y: number = this.cy;
			if (Math.random() < 0.2) {
				rx = Math.random() * PAIMODEL_WIDTH * 0.025;
				xwidth += rx;
				x += rx;
			}
			this.xwidth = xwidth;
			ry = (Math.random() - 0.5) * 2 * PAIMODEL_HEIGHT * 0.025;
			y += ry;
			let target_position: Laya.Vector3 = this.origin.transform.localPosition.clone();
			target_position.x += x;
			target_position.z -= y;
			let pai: ViewPai = this.last_pai;
			if (this.duringPaiAni) { //立直失败时牌还在做立直动画就脱离
				this.duringPaiAni = false;
				this.origin.parent.addChild(pai.model);
				pai.model.transform.localPosition = target_position;
				pai.model.transform.localRotationEuler = new Laya.Vector3(90, -90 - random_angle, 0);
			}
			if (doanim) {
				let old_position: Laya.Vector3 = pai.model.transform.localPosition.clone();
				let old_angle: number = pai.model.transform.localRotationEuler.y;
				let start_time: number = Laya.timer.currTimer;
				let anim = () => {
					let t: number = Laya.timer.currTimer - start_time;
					if (t >= 200) {
						pai.model.transform.localPosition = target_position;
						pai.model.transform.localRotationEuler = new Laya.Vector3(90, target_angle, 0);
						Laya.timer.clear(this, anim);
					} else {
						let rate: number = t / 200;
						let _position: Laya.Vector3 = new Laya.Vector3(0, 0, 0);
						let p_rate: number = (rate - 0.4) * (rate - 0.4) * 5 - 0.8;
						_position.x = target_position.x * p_rate + old_position.x * (1 - p_rate);
						_position.y = target_position.y * p_rate + old_position.y * (1 - p_rate);
						_position.z = target_position.z * p_rate + old_position.z * (1 - p_rate);
						let _angle: number = target_angle * rate + old_angle * (1 - rate);
						pai.model.transform.localPosition = _position;
						pai.model.transform.localRotationEuler = new Laya.Vector3(90, _angle, 0);
					}
				};
				Laya.timer.frameLoop(1, this, anim);
			} else {
				pai.model.transform.localPosition = target_position;
				pai.model.transform.localRotationEuler = new Laya.Vector3(90, target_angle, 0);
			}
			this.QiPaiPass();
		}

		//弃牌被通过
		public QiPaiPass(): void {
			if (this.last_pai != null) {
				this.pais.push(this.last_pai);
				if (view.DesktopMgr.Inst.xuezhan || view.DesktopMgr.Inst.is_chuanma_mode() || view.DesktopMgr.Inst.is_hunzhiyiji_mode()) {
					// 血战4排，左边6*4放完后，右边4*4
					if (this.pais.length < 24) {
						if (this.pais.length % 6 == 0) {
							//换行
							this.cx = 0;
							this.cy += PAIMODEL_HEIGHT * 1.05;
						} else {
							this.cx += this.xwidth;
						}
					} else if (this.pais.length == 24) {
						this.cx = PAIMODEL_WIDTH * 7;
						this.cy = 0;
					} else {
						if ((this.pais.length - 24) % 4 == 0) {
							this.cx = PAIMODEL_WIDTH * 7;
							this.cy += PAIMODEL_HEIGHT * 1.05;
						} else {
							this.cx += this.xwidth;
						}
					}
				} else {
					// 普通模式3排，第3排无限放
					if (this.pais.length <= 12 && this.pais.length % 6 == 0) {
						//换行
						this.cx = 0;
						this.cy += PAIMODEL_HEIGHT * 1.05;
					} else {
						this.cx += this.xwidth;
					}
				}

				this.last_pai = null;
				this.last_is_liqi = false;
			}
		}

		//弃牌不通过，被人吃碰杠
		public QiPaiNoPass(): void {
			if (this.last_pai) {
				this.last_pai.model.destroy();
			}
			this.last_pai = null;
		}

		public Reset(): void {
			Laya.timer.clearAll(this);
			if (this.pais.length > 0) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].model.destroy(true);
				}
				this.pais = new Array<ViewPai>();
			}
			this.cx = this.cy = 0;
			if (this.last_pai != null) {
				this.last_pai.model.destroy(true);
			}
			this.last_pai = null;
			this.last_is_liqi = false;
			this.after_liqi = false;
			this.last_pai_val = null;
			this.last_pai_count = 0;
			this.dora_yuyin_played = false;
		}

		public OnDoraRefresh(): void {
			if (this.last_pai != null) {
				this.last_pai.RefreshDora();
			}
			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].RefreshDora();
				}
			}
		}

		public OnChoosedPai(): void {
			if (this.last_pai != null) {
				this.last_pai.OnChoosedPai();
			}

			if (this.pais != null) {
				for (let i: number = 0; i < this.pais.length; i++) {
					this.pais[i].OnChoosedPai();
				}
			}
		}

		// 暗牌失败
		public RevealFailed(pai: mjcore.MJPai, doanim: boolean): void {
			if (this.last_pai) {
				this.last_pai.ChangeVal(pai);
				this.last_pai.PlayRevealFailedAnim(doanim);
			}
		}

		// 牌谱中切换状态时使用
		public ChangeRevealState(state: ERevealState) {
			for (let i = 0; i < this.pais.length; i++) {
				if (this.pais[i].revealState != view.ERevealState.None) {
					this.pais[i].SetRevealState(state);
				}
			}
			if (this.last_pai && this.last_pai.revealState != view.ERevealState.None) {
				this.last_pai.SetRevealState(state);
			}
		}

		// ==DevDebug Start==
		public previewLichiEffect(itemId: number, destroyDelay: number = 3000, onDestroy: Laya.Handler = null, revealState: ERevealState = ERevealState.None) {
			let isLiqi = true;
			let moqie = false;
			let doanim = true;
			let val = new mjcore.MJPai();
			this.QiPaiPass();
			let p: ViewPai = new ViewPai(val, DesktopMgr.Inst.CreatePai3D(val));
			if (view.DesktopMgr.Inst.showingPaopai) {
				p.ismoqie = moqie;
				p.ispaopai = DesktopMgr.Inst.isPaoPai(p.val);
			}
			p.OnChoosedPai();
			if (revealState != ERevealState.None) {
				p.SetRevealState(revealState);
			}
			let scaleZ = revealState == ERevealState.reveal ? -1 : 1;
			let scaleX = revealState == ERevealState.reveal ? -1 : 1;
			this.origin.parent.addChild(p.model);
			// if (isLiqi) this.after_liqi = true;
			if (this.last_is_liqi && !isLiqi) isLiqi = true;
			let angle: number = Math.atan(PAIMODEL_HEIGHT / PAIMODEL_WIDTH);
			let random_angle: number = (Math.random() - 0.5) * 2 * 2;
			// random_angle = 0;
			let xwidth: number = 0;
			let dx: number = 0;
			if (!isLiqi) {
				p.model.transform.localRotationEuler = new Laya.Vector3(90, random_angle, 0);
				xwidth = Math.sqrt(PAIMODEL_HEIGHT * PAIMODEL_HEIGHT + PAIMODEL_WIDTH * PAIMODEL_WIDTH) / 2 * Math.cos(angle - Math.abs(random_angle) * 3.1415926 / 180) * 2 + PAIMODEL_WIDTH * 0.01;
				dx = (xwidth - PAIMODEL_WIDTH) / 2;
			}
			else {
				p.model.transform.localRotationEuler = new Laya.Vector3(90, -90 - random_angle, 0);
				xwidth = Math.sqrt(PAIMODEL_HEIGHT * PAIMODEL_HEIGHT + PAIMODEL_WIDTH * PAIMODEL_WIDTH) / 2 * Math.cos(90 * 3.1415926 / 180 - angle - Math.abs(random_angle) * 3.1415926 / 180) * 2 + PAIMODEL_WIDTH * 0.01;
				dx = (xwidth - PAIMODEL_WIDTH) / 2;
			}

			let rx: number = 0;
			let ry: number = 0;
			let x: number = this.cx + dx;
			let y: number = this.cy;
			if (Math.random() < 0.2) {
				rx = Math.random() * PAIMODEL_WIDTH * 0.025;
				// rx = 0;
				xwidth += rx;
				x += rx;
			}
			this.xwidth = xwidth;
			ry = (Math.random() - 0.5) * 2 * PAIMODEL_HEIGHT * 0.025;
			// ry = 0;
			y += ry;
			p.model.transform.localPosition = this.origin.transform.localPosition.clone();

			p.model.active = true;
			p.model.transform.localPosition.x += x;
			p.model.transform.localPosition.z -= y;

			if (doanim) {
				let pos: Laya.Vector3 = p.model.transform.position.clone();
				this.player.hand3d.transform.position = pos.clone();
				let node: Laya.Sprite3D = this.player.hand3d.getChildAt(0).getChildByName('node_tile') as Laya.Sprite3D;
				node.addChild(p.model);

				p.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
				p.model.transform.localRotationEuler = new Laya.Vector3(0, 0, -((isLiqi ? -90 : 0) - random_angle));
				p.model.transform.localScale = new Laya.Vector3(1.1111 * scaleX, 1.1111, 1.1111 * scaleZ);

				let anim: iModelAnimation = null;
				//显示立直特效
				if (isLiqi) {
					let pos: Laya.Vector3 = p.model.transform.position.clone();
					let paiTransform: IPaiTransform = {pos};
					let effect_liqi_id: number = itemId;
					if (effect_liqi_id) {
						let d_view = cfg.item_definition.view.get(effect_liqi_id);
						let effect_liqi: string = '';
						//如果是4个方向的立直特效，根据位置更改特效名字，主视角是0
						if (d_view.seat_related && d_view.seat_related == 1) {
							let seat = view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat);
							effect_liqi = `scene/${d_view.res_name}${seat}.lh`;
						} else {
							effect_liqi = `scene/${d_view.res_name}.lh`;
						}
						let isShu = d_view.sargs.length < 0 || !d_view.sargs[0] || d_view.sargs[0] == 'shu';
						let animName = isShu ? 'Dapai' : 'LiQiPai';
						anim = ModelAnimationController.get_anim_config(animName, this.player.hand_type);
						Laya.timer.once(anim.keypoint[0], this, () => {
							//新特效
							if (!d_view.old_effect_mark) {
								let effect: game.EffectBase = new game.EffectBase(effect_liqi);
								let audio_id: number = d_view.audio_id;
								DesktopMgr.Inst.trans_container_effect.addChild(effect.root);
								effect.root.transform.position = new Laya.Vector3(0, 0, 0);
								effect.root.active = true;
								this.duringPaiAni = false;
								let onLoaded: Laya.Handler = Laya.Handler.create(this, () => {
									Laya.timer.once(destroyDelay, null, () => {
										if (p && p.model && !p.model.destroyed) {
											if (d_view && d_view.sargs[1]) {
												game.Tools.changePaiMat(p.model, 2000, 3001, 513);
											}
										}
										Laya.timer.clearAll(effect);
										effect.destroy();
										onDestroy?.run();
									});
								});
								effect.addLoadedListener(Laya.Handler.create(this, () => {
									if (!p || !p.model || p.model.destroyed) {
										effect.destroy();
										return;
									}
									if (audio_id) view.AudioMgr.PlayAudio(audio_id);
									//显示在特效之上的麻将Queue固定为3090（使用sargs[1]字段）
									if (d_view.sargs[1]) {
										game.Tools.changePaiMat(p.model, 3090, 3089, 513);
										game.Tools.dfsChangeParticleMat(effect.root);
									}
									let effectRoot = effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D; //所有立直特效分为以下三个部分
									let root_rot: Laya.Sprite3D = effectRoot.getChildByName('root_rot') as Laya.Sprite3D;  //需要控制旋转，和 牌的方向 一致
									let root_move: Laya.Sprite3D = effectRoot.getChildByName('root_move') as Laya.Sprite3D; //动画部分，永远朝向主视角
									let root_static: Laya.Sprite3D = effectRoot.getChildByName('root_static') as Laya.Sprite3D;  //静止部分：例如遮罩黑
									let root_ani: Laya.Sprite3D = effectRoot.getChildByName('root_ani') as Laya.Sprite3D;  //牌的特殊动画
									let root_maque: Laya.Sprite3D = effectRoot.getChildByName('root_maque') as Laya.Sprite3D;  //固定在牌最终停放的位置的位置
									let haveSpecialAni = root_ani && root_ani.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
									let isShu = d_view.sargs.length < 0 || !d_view.sargs[0] || d_view.sargs[0] == 'shu';
									let _origin_worldMatrix = p.model.transform.worldMatrix.clone();
									let _origin_pos = p.model.transform.position.clone();
									let _origin_rotation = p.model.transform.rotation.clone();
									root_move.transform.position = _origin_pos.clone();
									root_rot.transform.position = _origin_pos.clone();
									root_rot.transform.rotation = _origin_rotation.clone();
									if (root_maque) root_maque.transform.position = paiTransform.pos.clone();
									const paiAnimMostDelay = 2000;
									if (isShu && haveSpecialAni) { //有特殊牌动画的特效，特别特别特别少, 目前还未使用
										app.Log.log('立直特效有牌动画');
										this.duringPaiAni = true;
										root_ani.transform.position = _origin_pos.clone();
										(root_ani.getChildAt(0) as Laya.Sprite).destroyChildren();
										(root_ani.getChildAt(0) as Laya.Sprite).addChild(p.model);
										// 清除所有其他计时器
										if (p['ResetAllTimer']) {
											p['ResetAllTimer']();
										}
										p.model.transform.worldMatrix = _origin_worldMatrix.clone();
										Laya.timer.once(paiAnimMostDelay, null, () => {//重置回牌的位置
											if (p && p.model && !p.model.destroyed && this.duringPaiAni) {
												this.origin.parent.addChild(p.model);
												p.model.transform.worldMatrix = _origin_worldMatrix.clone();
											}
											this.duringPaiAni = false;
										});
									} else { //常规立直特效
										Laya.timer.frameLoop(1, effect, () => {
											if (p && p.model && !p.model.destroyed) {
												root_move.transform.position = p.model.transform.position.clone();
												root_rot.transform.position = p.model.transform.position.clone();
												root_rot.transform.rotation = p.model.transform.rotation.clone();
											} else {
												Laya.timer.clearAll(effect);
												effect.destroy();
											}
										});
									}
									onLoaded.run();
								}));

							} else {
								//老特效
								let _effect: game.EffectBase = new game.EffectBase(effect_liqi);
								if (isShu) {
									let onLoaded: Laya.Handler = Laya.Handler.create(this, () => {
										Laya.timer.once(destroyDelay + 2000, null, () => {
											if (_effect && !_effect.destroyed) {
												Laya.timer.clearAll(_effect);
												_effect.destroy();

											}
											onDestroy?.run();
										});
									});
									let _effect: game.EffectBase = new game.EffectBase(effect_liqi);
									DesktopMgr.Inst.trans_container_effect.addChild(_effect.root);
									let pos = p.model.transform.position.clone();
									pos.y = 0;
									_effect.root.transform.position = pos;
									_effect.root.active = true;
									if (effect_liqi == 'scene/effect_liqi_21winter.lh') {
										_effect.root.transform.localRotationEuler = new Laya.Vector3(0, view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
									}
									let audio_id: number = d_view.audio_id;
									if (audio_id) view.AudioMgr.PlayAudio(audio_id);

									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										if (!p || !p.model || p.model.destroyed) {
											onDestroy.run();
											return;
										}

										let pai_anim = game.Tools.GetNodeByNameInChildren(_effect.root, 'pai_anim') as Laya.Sprite3D;
										if (pai_anim) {
											Laya.timer.frameOnce(1, this, () => {
												if (!p || !p.model || p.model.destroyed) return;
												let _origin_rotation = p.model.transform.rotation.clone();
												let _origin_pos = p.model.transform.worldMatrix.clone();
												pai_anim.addChild(p.model);
												p.model.transform.rotation = _origin_rotation;
												p.model.transform.worldMatrix = _origin_pos;
											});
										}
										onLoaded.run();
									}));
									Laya.timer.once(3000, this, () => {
										if (p && p.model && !p.model.destroyed) {
											let _origin_rotation = p.model.transform.rotation.clone();
											let _origin_pos = p.model.transform.worldMatrix.clone();
											this.origin.parent.addChild(p.model);
											p.model.transform.rotation = _origin_rotation;
											p.model.transform.worldMatrix = _origin_pos;
										}
									});

								} else {
									let onLoaded: Laya.Handler = null;
									_effect.root.transform.localRotationEuler = new Laya.Vector3(90, 180, 90);
									this.origin.parent.addChild(_effect.root);
									let audio_id: number = d_view.audio_id;
									if (audio_id > 0) view.AudioMgr.PlayAudio(audio_id);
									if (effect_liqi == 'scene/effect_liqi_xiyuansi.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let buzhuan: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'buzhuan') as Laya.Sprite3D;
											buzhuan.transform.localRotationEuler = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
										});
									}
									if (effect_liqi == 'scene/effect_liqi_22summer.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let vec3 = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
											let yazi = game.Tools.GetNodeByNameInChildren(_effect.root, 'ya') as Laya.Sprite3D;
											for (let i = 0; i < 3; i++) {
												(yazi.getChildAt(i) as Laya.Sprite3D).transform.localRotationEuler = vec3;
											}
										});
									}

									if (effect_liqi == 'scene/effect_liqi_beiyuan.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let vec3 = new Laya.Vector3(0, 0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90);
											(game.Tools.GetNodeByNameInChildren(_effect.root, 'ci_xuanzhuan') as Laya.Sprite3D).transform.localRotationEuler = vec3;
										});
									}
									if (effect_liqi == 'scene/effect_liqi_23ex_xueqiu.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let buzhuan: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'GameObject') as Laya.Sprite3D;
											buzhuan.transform.localRotationEuler = new Laya.Vector3(0, 0, 180);
										});
									}
									if (effect_liqi == 'scene/effect_liqi_23ex_liandao.lh') {
										if (view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) == 2) {
											onLoaded = Laya.Handler.create(this, () => {
												let anim: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'anim') as Laya.Sprite3D;
												let vec3 = new Laya.Vector3(41, 0, 0);
												anim.transform.localRotationEuler = vec3;
											});
										}
									}

									if (effect_liqi == 'scene/effect_liqi_22chunjie.lh') {

										let _effect: game.EffectBase = new game.EffectBase('scene/effect_liqi_22chunjie_hongdi.lh');
										view.DesktopMgr.Inst.desktop3D.addChild(_effect.root);
										onLoaded = Laya.Handler.create(this, () => {
											let hongdi: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'hongdi') as Laya.Sprite3D;

											for (let child of hongdi._childs) {
												(child as Laya.ShuriKenParticle3D).particleRender.material.renderQueue = 3001;
											}
											_effect.root.transform.position = new Laya.Vector3(0, 0, 0);
											_effect.root.active = true;
											Laya.timer.once(2500, this, () => {
												_effect.destroy();
											});
										});

									}
									if (effect_liqi == 'scene/effect_liqi_24ba.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let node = game.Tools.GetNodeByNameInChildren(_effect.root, 'position') as Laya.Sprite3D;
											let anim = node.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
											anim.Play(null);
											let vec3 = new Laya.Vector3(45, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
											(game.Tools.GetNodeByNameInChildren(_effect.root, 'rot') as Laya.Sprite3D).transform.localRotationEuler = vec3;
										});


									}
									if (effect_liqi == 'scene/effect_liqi_nanfenghua.lh') {
										onLoaded = Laya.Handler.create(this, () => {
											let root_nanfenghua: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'fx_liqi_073') as Laya.Sprite3D;
											let buzhuan1: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(root_nanfenghua, '002') as Laya.Sprite3D;
											let buzhuan2: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(root_nanfenghua, 'liqi_niao') as Laya.Sprite3D;
											let vec3 = new Laya.Vector3(0, -view.DesktopMgr.Inst.seat2LocalPosition(this.player.seat) * 90, 0);
											buzhuan1.transform.localRotationEuler = vec3;
											buzhuan2.transform.localRotationEuler = vec3;
										});
									}
									_effect.addLoadedListener(Laya.Handler.create(this, () => {
										onLoaded?.run();
										Laya.timer.once(destroyDelay, null, () => {
											if (_effect && !_effect.destroyed) {
												Laya.timer.clearAll(_effect);
												_effect.destroy();
												onDestroy?.run();
											}

										});

									}));
									Laya.timer.frameLoop(1, _effect, () => {
										if (p && p.model && !p.model.destroyed) {
											_effect.root.transform.worldMatrix = p.model.transform.worldMatrix.clone();
										} else {
											if (_effect && !_effect.destroyed) {
												Laya.timer.clearAll(_effect);
												_effect.destroy();
												onDestroy?.run();
											}
										}
									});


								}
							}

						});
					} else {
						anim = ModelAnimationController.get_anim_config('Dapai', this.player.hand_type);
					}
				} else {
					anim = ModelAnimationController.get_anim_config('Dapai', this.player.hand_type);
				}

				this.player.playHandAnimtion(anim);
				Laya.timer.once(anim.keypoint[0], this, () => {
					AudioMgr.PlayAudio(207);
				});
				Laya.timer.once(anim.keypoint[1], this, () => {
					if (p && p.model && !p.model.destroyed) {
						this.origin.parent.addChild(p.model);
						p.model.transform.localScale = new Laya.Vector3(1 * scaleX, 1, 1 * scaleZ);
						if (!isLiqi) {
							p.model.transform.localRotationEuler = new Laya.Vector3(90, random_angle, 0);
						}
						else {
							p.model.transform.localRotationEuler = new Laya.Vector3(90, -90 - random_angle, 0);
						}
						this.last_pai.model.transform.localPosition = this.origin.transform.localPosition.clone();
						this.last_pai.model.transform.localPosition.x += x;
						this.last_pai.model.transform.localPosition.z -= y;
					}
				});
			}

			this.last_pai = p;
			this.last_is_liqi = isLiqi;
			DesktopMgr.Inst.SetLastQiPai(this.player.seat, p);

			//添加影子
			{
				let shadow: Laya.Sprite3D = val.touming ? DesktopMgr.Inst.effect_shadow_touming.clone() : DesktopMgr.Inst.effect_shadow.clone();
				(shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
				p.effect_parent.addChild(shadow);
				shadow.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
				shadow.transform.localScale = new Laya.Vector3(PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
				shadow.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
				shadow.active = true;
			}

			// 心理语音：连打同一张牌
			if ((DesktopMgr.Inst.mode == EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) || DesktopMgr.Inst.mode == EMJMode.play) {
				if (!doanim || revealState != ERevealState.None) {
					this.last_pai_val = null;
					this.last_pai_count = 0;
				} else {
					if (this.last_pai_val && mjcore.MJPai.Distance(this.last_pai_val, val) == 0) {
						this.last_pai_count++;
						if (this.last_pai_count == 3) {
							DesktopMgr.Inst.addMindVoice(this.player.seat, 'ingame_lianda');
						}
					} else {
						this.last_pai_val = val.Clone();
						this.last_pai_count = 1;
					}
					let isDora: boolean = false;
					if (val.dora) isDora = true;
					if (!isDora) {
						for (let i: number = 0; i < DesktopMgr.Inst.dora.length; i++) {
							if (mjcore.MJPai.DoraMet(val, DesktopMgr.Inst.dora[i])) {
								isDora = true;
								break;
							}
						}
					}
					let pai_v: string = val.numValue.toString();
					if (isDora && !this.dora_yuyin_played) {
						DesktopMgr.Inst.addMindVoice(this.player.seat, 'ingame_baopai');
						this.dora_yuyin_played = true;
					}
				}
			} else {
				this.last_pai_val = null;
				this.last_pai_count = 0;
			}
		}
		// ==DevDebug End==
	}
}