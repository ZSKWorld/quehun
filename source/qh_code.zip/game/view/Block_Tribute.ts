/**
* name 
*/
module view {
	const TributePosition = [
		[new Laya.Vector3(0, 0, 0.185)],
		[new Laya.Vector3(-0.071, 0, 0.185), new Laya.Vector3(0.076, 0, 0.185)],
		[new Laya.Vector3(-0.135, 0, 0.185), new Laya.Vector3(0, 0, 0.185), new Laya.Vector3(0.149, 0, 0.185)]
	]
	export class Block_Tribute {

		private _container: Laya.Sprite3D;
		private _player: ViewPlayer;
		private submitInfos: game.ISubmitGroup[] = [];
		private tributes: Laya.Sprite3D[] = []
		private anims: Catfood.CAnimator[];

		constructor(_container: Laya.Sprite3D, player: ViewPlayer) {
			this._container = _container;
			this._player = player;
			this._container.active = false;
		}

		public reset(): void {
			this._container.active = false;
			Laya.timer.clearAll(this);
			for (let i = 0; i < this.tributes.length; i++) {
				view.DesktopMgr.Inst.recycleTribute3D(this.tributes[i]);
			}
			this.submitInfos = [];
			this.tributes = [];
			this.anims = [];
		}

		public submitTile(submitInfo: game.ISubmitInfo): void {
			this.reset();
			this.submitInfos = submitInfo.groups;
		}

		public takeTile(fromInfos: game.ITakeInfo[], showHand: boolean): void {
			if (!this.CheckSubmitData(fromInfos)) {
				app.Log.log("Block_Tribute" + "TakeTile failed! checkSubmitData failed");
				return;
			}
			this._container.active = true;
			const posInfos = TributePosition[this.submitInfos.length - 1];
			this.tributes = [];
			this.anims = [];
			for (let i = 0; i < fromInfos.length; i++) {
				const info = fromInfos[i];
				const pais: mjcore.MJPai[] = [];
				const states: boolean[] = [];
				for (let j = 0; j < info.count; j++) {
					let paiStr = '7z';
					let isOpen = false;
					if (info.tiles[j] && showHand) {
						paiStr = info.tiles[j];
						isOpen = true;
					}
					const pai = mjcore.MJPai.Create(paiStr);
					pais.push(pai);
					states.push(isOpen);
				}
				const result = DesktopMgr.Inst.createTribute3D(pais, states, this._container);
				if (!result) {
					app.Log.log("Block_Tribute" + "CreateTribute3D failed!");
					return;
				}
				const tribute = result.tribute;
				this.tributes.push(tribute);
				const anim = tribute.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				this.anims.push(anim);
				// 设置位置
				const pos = posInfos[i];
				tribute.transform.localPosition = new Laya.Vector3(pos.x, pos.y, pos.z);
				tribute.transform.localRotation = new Laya.Quaternion();
				tribute.transform.localScale = new Laya.Vector3(1, 1, 1);
				tribute.active = true;

				anim.Play("submittile_maque_show");
				const { animName, arrowName } = this.GetMoveAnimName(this.submitInfos.length, info.take_seat);
				// app.Log.log("Block_Tribute" + "arrowName arrowName: " + arrowName);

				const comArrow = tribute.getChildByName("arrow") as Laya.Sprite3D;
				let targetArrow;
				comArrow._childs.forEach(arrow => {
					arrow.active = false;
					if (arrow.name == arrowName) targetArrow = arrow;
				});
				if (targetArrow) {
					// app.Log.log("Block_Tribute" + "准备播放箭头: " + arrowName);
					Laya.timer.once(500, this, () => {
						let animArrow = targetArrow.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
						targetArrow.active = true;
						animArrow.Play(null);
					});
				}
				Laya.timer.once(1500, this, () => {
					// app.Log.log("Block_Tribute" + "TakeTile animName: " + animName);
					this.anims[i].Play(animName);
				});
			}
			Laya.timer.once(1780, this, () => {
				// app.Log.log("Block_Tribute" + "reset ");
				this.reset();
			});
		}

		private CheckSubmitData(takeInfos: game.ITakeInfo[]): boolean {
			if (this.submitInfos.length != takeInfos.length) {
				// app.Log.log("Block_Tribute" + "TakeTile failed! tribute count not match takeInfos count");
				return false;
			}
			// 校验所有数据是否是submit过来的数据
			const checkData = (takeInfo: game.ITakeInfo): boolean => {
				for (let i = 0; i < this.submitInfos.length; i++) {
					const group = this.submitInfos[i];
					if (group.count == takeInfo.count) {
						let isOpen = takeInfo.tiles[takeInfo.count - 1] ? 1 : 0;
						if (isOpen == 1) isOpen = group.tiles[group.count - 1] ? 1 : 0;
						if (isOpen == 0) {
							// app.Log.log("Block_Tribute" + " 没开放 算是匹配了 ");
							return true;
						}
						let isMatched = true;
						for (let j = 0; j < takeInfo.tiles.length; j++) {
							if (group.tiles.indexOf(takeInfo.tiles[j]) == -1) {
								// app.Log.log("Block_Tribute" + "TakeTile failed!这个牌不在提交的牌里: " + takeInfo.tiles[j]);
								isMatched = false;
							}
						}
						if (isMatched) {
							// app.Log.log("Block_Tribute" + " 全部匹配 ");
							return true;
						}
					}
				}
				// app.Log.log("Block_Tribute" + " TakeTile failed!没有找到匹配的提交数据 ");
				return false;
			};
			for (let i = 0; i < takeInfos.length; i++) {
				const takeInfo = takeInfos[i];
				const isMatched = checkData(takeInfo);
				if (!isMatched) {
					return false;
				}
			}
			return true;
		}

		private GetMoveAnimName(count: number, targetSeat: number): { animName: string, arrowName: string } {
			const seat = this._player.seat;
			const shang = (seat - 1 + 4) % 4;
			const dui = (seat + 2) % 4;
			const xia = (seat + 1) % 4;
			const indexs = [shang, dui, xia];
			// app.Log.log('GetMoveAnimName' + indexs);
			// app.Log.log('GetMoveAnimName' + 'targetSeat ===== ' + targetSeat);
			let animName = '';
			let arrowName = '';
			if (targetSeat == indexs[0]) {
				animName = "submittile_maque_left_" + count.toString();
				arrowName = '01';
			} else if (targetSeat == indexs[1]) {
				animName = "submittile_maque_line";
				arrowName = '02';
			}
			else if (targetSeat == indexs[2]) {
				animName = "submittile_maque_right_" + count.toString();
				arrowName = '03';
			}
			// app.Log.log('GetMoveAnimName' + ' animName ===== ' + animName);
			return { animName, arrowName };
		}
	}
}