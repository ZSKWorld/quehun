module view {
	export enum EGameVoiceType {
		ingame_start = "ingame_start"
	}

	export enum EMindVoiceType {
		ingame_yiman = "ingame_yiman",
		ingame_beiman = "ingame_beiman",
		ingame_lianda = "ingame_lianda",
		ingame_baopai = "ingame_baopai",
		ingame_remain10 = "ingame_remain10"
	}

	export class DeskAudioMgr {
		private static _inst: DeskAudioMgr;
		public static get Inst() {
			return this._inst || (this._inst = new DeskAudioMgr());
		}
		private readonly HightLevelAudio: string[] = [
			'act_chi',
			'act_pon',
			'act_kan',
			'act_babei',
			'act_ron',
			'act_tumo',
			'act_rich',
			'act_drich',
			'gameend_jiuzhongjiupai',
			'gameend_sifenglianda',
			'gameend_sijializhi',
			'gameend_sigangliuju',
		];
		private readonly LowLevelAudio: string[] = [ //低优先级语音列表，目前和心里语音列表重合
			'ingame_yiman',
			'ingame_beiman',
			'ingame_lianda',
			'ingame_baopai',
			'ingame_remain10',
		];
		private _id = 0;
		private _curAudioId: number = -1;
		private _curCharAudioType: string = '';
		public multiRon = false;
		private constructor() { }

		// 流局
		public playSound(audio: string, volume: number) {
			if (!this.checkCanPlaySound()) return -1;
			const id = ++this._id;
			this._curAudioId = view.AudioMgr.PlaySound(audio, volume, Laya.Handler.create(this, this.onPlayEnd, [id]));
			return this._curAudioId;
		}

		public playCharSound(character_info: any, type: string, isTeSu?:boolean, complete?: Laya.Handler) {
			const canPlay = this.checkCanPlayCharSound(type);
			if (!canPlay) return;
			const id = ++this._id;
			let sound:{words:string, audio_id:number};
			if (isTeSu) {
				sound = view.AudioMgr.PlayCharactorSound_Teshu(character_info, type, Laya.Handler.create(this, () => {
					this.onPlayEnd(id);
					if (complete) complete.run();
				}));
			} else {
				sound = view.AudioMgr.PlayCharactorSound(character_info, type, Laya.Handler.create(this, this.onPlayEnd, [id]));
			}
			if (!sound) return;
			this._curAudioId = sound.audio_id;
			this._curCharAudioType = type;
			return sound;
		}

		private checkCanPlaySound() {
			if (this._curAudioId != -1) {
				view.AudioMgr.StopAudio(this._curAudioId);
				this._curAudioId = -1;
				this.clearPlayingMark();
			}
			return true;
		}

		private checkCanPlayCharSound(type: string) {
			if (this.multiRon && type == 'act_ron') return true;
			if (this._curAudioId != -1) {
				const isHight = this.HightLevelAudio.indexOf(type) > -1;
				if (!isHight) return false;
				view.AudioMgr.StopAudio(this._curAudioId);
				this._curAudioId = -1;
				this.clearPlayingMark();
			}
			return true;
		}

		private clearPlayingMark() {
			if (!this._curCharAudioType) return;
			if (view.EMindVoiceType[this._curCharAudioType]) {
				DesktopMgr.Inst.clearMindVoiceMark();
			}
			if (view.EGameVoiceType[this._curCharAudioType]) {
				DesktopMgr.Inst.resetGameVoice();
			}
			this._curCharAudioType = '';
		}

		private onPlayEnd(id: number) {
			if (id != this._id) return;
			this._curAudioId = -1;
			this._curCharAudioType = '';
		}
	}
}