/**
* name 
*/
module view {

	export const PAIMODEL_HEIGHT: number = 0.0455 * 0.95 * 0.94;
	export const PAIMODEL_WIDTH: number = 0.0345 * 0.95 * 0.94;
	export const PAIMODEL_THICKNESS: number = 0.0235 * 0.95 * 0.94;
	export const PAI_COUNT: number = 136;
	export const BAIDA_COUNT: number = 13;

	export enum ELink_State { NULL, AUTH, SYNCING, READY }
	export enum ERuleMode { Liqi4, Liqi3 } // 4麻、3麻
	export enum EMJMode { play, paipu, live_broadcast, xinshouyindao }
	export enum ERecordType {
		/**
		 * 新回合，发牌
		 */
		NewRound = "RecordNewRound",
		/**
		 * 起牌
		 */
		DealTile = "RecordDealTile",
		/**
		 * 吃，碰，杠
		 */
		ChiPengGang = "RecordChiPengGang",
		/**
		 * 打牌
		 */
		DiscardTile = "RecordDiscardTile",
		/**
		 * 暗杠，加杠
		 */
		AnGangAddGang = "RecordAnGangAddGang",
		/**
		 * 胡
		 */
		Hu = "RecordHule",
		/**
		 * 流局
		 */
		LiuJu = "RecordLiuJu",
		/**
		 * 拔北
		 */
		BaBei = "RecordBaBei",
		/**
		 * 修罗/赤羽中间胡牌
		 */
		XueZhanHuMid = "RecordHuleXueZhanMid",
		/**
		 * 修罗/赤羽胡牌
		 */
		XueZhanHuEnd = "RecordHuleXueZhanEnd",

	}

	export interface iMuYuInfo {
		seat: number;
		count: number;
		count_max: number;
		id: number;
	}

	export interface ILastRoundRecord {
		hule: boolean;
		zimo: boolean;
	}

	export class DesktopMgr extends Laya.Script {
		public static Inst: DesktopMgr = null;
		public static player_link_state: Array<ELink_State> = [ELink_State.NULL, ELink_State.NULL, ELink_State.NULL, ELink_State.NULL];

		public static click_prefer: number = 0; //点击偏好，0.单击，1.双击
		public static double_click_pass: number = 0; //过牌偏好,0.无,1.双击
		public static en_mjp: boolean = false; // 是否使用美服带角标的麻将牌
		public static bianjietishi: boolean = true; // 是否开启便捷提示
		private static _is_yuren_type: boolean = false;
		public static is_yuren_type(need_refresh: boolean = false): boolean {
			if (need_refresh) {
				let date = new Date();
				this._is_yuren_type = date.getMonth() == 3 && date.getDate() == 1;
			}
			return this._is_yuren_type;
		}

		public rule_mode: ERuleMode = ERuleMode.Liqi4;
		public mode: EMJMode = EMJMode.play;
		public active: boolean = false;
		public game_config: game.IGameConfig = null;
		public seat: number = 0; //我的位置
		public index_change: number; //场风，0=东
		public index_ju: number; //局，东1局
		public index_ben: number; //本，东1局2本
		public index_chuanma_ju: number; // 局，第X局
		public index_player: number; //当前轮到谁操作
		public left_tile_count: number; //剩余牌的数量
		public dora: Array<mjcore.MJPai> = []; //外朵拉
		public xuezhan: boolean = false; // 血战模式
		public anpai: boolean = false;
		public last_anpai_score: number = 0;

		public mainCamera: Laya.Camera; //主摄像机
		public desktop3D: Laya.Sprite3D; //整个牌桌的资源
		public players: Array<ViewPlayer> = null; //不同玩家
		public mainrole: ViewPlayer_Me = null; //自己控制的角色

		public num_left_show: Array<Laya.MeshSprite3D> = new Array<Laya.MeshSprite3D>(); //剩余牌数统计显示
		public container_other: Laya.Sprite3D = null;
		public plane_chang: Laya.MeshSprite3D = null;
		public plane_ju: Laya.MeshSprite3D = null;

		public container_other_reveal: Laya.Sprite3D = null;
		public plane_chang_reveal: Laya.MeshSprite3D = null;
		public plane_ju_reveal: Laya.MeshSprite3D = null;
		public num_left_show_reveal: Array<Laya.MeshSprite3D> = new Array<Laya.MeshSprite3D>(); //剩余牌数统计显示
		public score_reveal: Array<Laya.MeshSprite3D> = new Array<Laya.MeshSprite3D>(); //暗牌模式中间分数

		public trans_container_effect: Laya.Sprite3D = null;
		public trans_container_fullscreeen_effect: Laya.Sprite3D = null;
		public effect_pai_canchi: game.EffectBase = null;
		public effect_pai_canchi_maka: game.EffectBase = null;
		// public get effect_pai_canchi(): Laya.Sprite3D { return game.Scene_MJ.Inst.effect_pai_canchi; } //可以吃的牌的特效
		public effect_dora3D: Laya.Sprite3D = null; //在3d模型上的dora特效
		public effect_dora3D_touying: Laya.Sprite3D = null; //在3d投影的dora特效
		public effect_doraPlane: Laya.Sprite3D = null; //在面片上的dora特效
		public effect_shadow: Laya.Sprite3D = null; //在模型下的影子\
		public effect_shadow_touming: Laya.Sprite3D = null;
		public effect_recommend: Laya.Sprite3D = null; //在面片下的推荐

		public auto_hule: boolean = false; //自动胡了
		public auto_nofulu: boolean = false; //不要鸣牌
		public auto_moqie: boolean = false; //自动摸切
		public auto_babei: boolean = false; //自动拔北
		public auto_liqi: boolean = true; //自动理牌
		public emoji_switch: boolean = false; // 关闭表情

		public duringReconnect: boolean = false; // 在重连的状态下，不会进行操作

		public gameing: boolean = false;
		public lastpai_seat: number = 0;
		public lastqipai: ViewPai = null;
		public oplist: Array<game.IOptionalOperation> = [];
		public liqi_select: Array<mjcore.MJPai> = [];
		public operation_showing: boolean = false;
		public myaccountid: number = 0;
		public player_datas: Array<Object> = [];
		public player_effects: Array<Object> = []; //key: game.EView, value: item_id
		public mjp_res_name: string = '';
		public mjpb_res_name: string = '';
		public gameEndResult: game.IGameEndResult = null;
		public lastRoundRecord: ILastRoundRecord[] = [];
		public levelchangeinfo: Object = null;
		public activity_reward: Object = null; //活动奖励，暂存，游戏结束展示
		/**
		 * 徽章数据变更，
		 */
		public badgeChange: Array<Object> = null;
		public rewardinfo: Object = null;
		public choosed_pai: mjcore.MJPai = null;
		public muyu_info: iMuYuInfo = null;
		private muyu_effect: game.EffectBase = null;

		private actionList: Array<Object> = [];
		// private action_frame: number = 0;
		private action_index: number = 0;
		public current_step: number = 0;
		private actionMap: Object = null;
		public tingpais: Array<Array<mjcore.MJPai>> = [];
		private _record_show_hand: boolean = false;	// 牌谱：显示手牌
		private _ob_show_hand: boolean = false;	// 观战：显示手牌
		private _record_show_paopai: boolean = false;	// 牌谱：铳牌提示
		private _ob_show_paopai: boolean = false;	// 观战：铳牌提示
		public record_show_anim: boolean = true;		// 牌谱：显示动画
		private _ob_follow_dealer: boolean = false; // 观战：跟随庄家
		/**
		 * 听牌提示
		 */
		public isShowTingTip: boolean = false; 
		public ptchange: number = 0;
		public waiting_lingshang_deal_tile: boolean = false; //还没接岭上牌
		public md5: string = '';
		public sha256: string = '';
		public saltSha256: string = '';
		public salt: string = '';
		public paipu_config: number = 0;  //一个int，2=匿名分享的牌谱
		public ai_level: number = 1; //ai等级
		public timestoped: boolean = false; //游戏暂停
		public handles_after_timerun: Array<Laya.Handler> = []; //时间开始之后，我该有的调用

		private doactioncd: number = 0; // 下一个action可以执行的时间
		private dochain_fast: boolean = false;
		private action_running: boolean = false; //正在执行action，执行完了才能执行下一个
		public hangupCount: number = 0; //挂机次数
		public state_cache: Object = {}; //进入游戏时候的状态缓存，比如活动数据，先缓存一份，不被notify影响
		private mind_voice_seat: number = -1; // 心理语音的座位
		private mind_voice_type: string = ''; // 心理语音的类型
		private during_playing_mind_voice: boolean = false; //心理语音正在播放就不播放了
		private mind_voice_sound_id: number;
		private extraGameSoundId: number = -1;
		private isPlayedPrepareAudio: boolean = false;

		private effectBeiShuiFires: game.EffectBase[][] = []; //手牌场景里四个人的背水之战火焰特效
		public xiakeshangInfo: game.IXiaKeShangInfo;
		private tributeMove: Laya.Sprite3D;
		private tributePool: Laya.Sprite3D[];
		/**
		 * 强夺之战 进贡状态， 0表示未处于换牌中，1表示在进贡，2表示在还供
		 */
		public tributeState: number = 0;
		/**
		 * 上次滑动滚轮的时间
		 */
		public lastWheelClickTime: number = 0;
		/**
		 * 滚轮CD时间
		 */
		public wheelCd: number = 50;
		
		public get record_show_hand() {
			if (this.mode == EMJMode.paipu) {
				return this._record_show_hand;
			}
			if (this.mode == EMJMode.live_broadcast) {
				return this._ob_show_hand;
			}
			return false;
		}

		public get record_show_paopai() {
			if (this.mode == EMJMode.paipu) {
				return this._record_show_paopai;
			}
			if (this.mode == EMJMode.live_broadcast) {
				return this._ob_show_paopai;
			}
			return false;
		}

		public set record_show_hand(v: boolean) {
			if (this.mode == EMJMode.paipu) {
				this._record_show_hand = v;
				Laya.LocalStorage.setItem('record_show_hand', v ? '1' : '0');
			}
			if (this.mode == EMJMode.live_broadcast) {
				this._ob_show_hand = v;
				Laya.LocalStorage.setItem('ob_show_hand', v ? '1' : '0');
			}
		}

		public set record_show_paopai(v: boolean) {
			if (this.mode == EMJMode.paipu) {
				this._record_show_paopai = v;
				Laya.LocalStorage.setItem('record_show_paopai', v ? '1' : '0');
			}
			if (this.mode == EMJMode.live_broadcast) {
				this._ob_show_paopai = v;
				Laya.LocalStorage.setItem('ob_show_paopai', v ? '1' : '0');
			}
		}

		public get record_follow_dealer() {
			if (this.mode == EMJMode.paipu) {
				return false;
			}
			if (this.mode == EMJMode.live_broadcast) {
				return this._ob_follow_dealer;
			}
			return false;
		}

		public set record_follow_dealer(v: boolean) {
			if (this.mode == EMJMode.paipu) {
			}
			if (this.mode == EMJMode.live_broadcast) {
				this._ob_follow_dealer = v;
				Laya.LocalStorage.setItem('ob_follow_dealer', v ? '1' : '0');
			}
		}
		public field_spell: number; // 辉夜特殊模式

		public get round_id(): string { return this.index_change + '-' + this.index_ju + '-' + this.index_ben; }

		public get main_role_character_info(): Object { return this.player_datas[this.seat]['character']; }

		// 对局人数，3麻3个人，4麻4个人
		public get player_count(): number { if (this.rule_mode == ERuleMode.Liqi3) return 3; return 4; }

		/*
		 * seat 特指东1时候的风位
		 * localposition 特指以我的视角的位置，我的位置是0，下家是1，上家是3
		 */
		// 将东1局所坐的风位转化成以我视角的座位
		public seat2LocalPosition(seat: number): number {
			if (this.rule_mode == ERuleMode.Liqi3) {
				let _s: number = this.seat;
				for (let i: number = 0; i < 4; i++) {
					if (seat == _s) {
						return i;
					}
					_s++;
					if (_s >= 3) _s = -1;
				}
				return 0;
			} else {
				return (seat - this.seat + 4) % 4;
			}
		}

		// 将以我视角的座位转化成东1局所坐的风位
		public localPosition2Seat(localposition: number): number {
			if (this.rule_mode == ERuleMode.Liqi3) {
				let _s: number = this.seat;
				for (let i: number = 0; i < localposition; i++) {
					_s++;
					if (_s >= 3) _s = -1;
				}
				return _s;
			} else {
				return (this.seat + localposition) % 4;
			}
		}

		public getPlayerName(index: number, showRemarks:boolean = true): { account_id: number, nickname: string, verified: number, isRemarks?: boolean } {
			let _account_id: number = this.player_datas[index]['account_id'];
			let playerData = this.player_datas[index];
			let isRemarks = false;
			
			if (this.mode == EMJMode.paipu && uiscript.UI_Replay.Inst.hide_name) {
				//如果是账号本人，无论在哪个位置，都返回我,不使用位置而是使用Index
				// let localposition: number = this.seat2LocalPosition(index);
				if (this.myaccountid == _account_id) {
					return { account_id: _account_id, nickname: game.Tools.strOfLocalization(3076), verified: 0 , isRemarks};
				}

				switch (index) {
					case 0: return { account_id: _account_id, nickname: game.Tools.strOfLocalization(3073), verified: 0 , isRemarks};
					case 1: return { account_id: _account_id, nickname: game.Tools.strOfLocalization(3074), verified: 0 , isRemarks};
					case 2: return { account_id: _account_id, nickname: game.Tools.strOfLocalization(3075), verified: 0 , isRemarks};
					case 3: return { account_id: _account_id, nickname: game.Tools.strOfLocalization(3079), verified: 0 , isRemarks};
				}
				return { account_id: _account_id, nickname: '', verified: 0, isRemarks};
			} else {
				
				let nickname: string = this.player_datas[index]['nickname'];
				let _hide_name: boolean = false;
				if (_account_id && _account_id != GameMgr.Inst.account_id) {
					if (GameMgr.Inst.hide_nickname) {
						if (!game.Tools.is_same_zone(GameMgr.Inst.account_id, _account_id) && GameMgr.Inst.get_hide_name('other_zone')) {
							_hide_name = true;
						} else if (this.game_config && this.game_config['category'] == 4) {
							if (GameMgr.Inst.hide_match_name) _hide_name = true;
						} else if (this.game_config && this.game_config['category'] == 1) {
							_hide_name = true;
						} else if (this.mode == EMJMode.play && GameMgr.Inst.hide_desktop_name) {
							_hide_name = true;
						} else if (this.mode == EMJMode.paipu && GameMgr.Inst.hide_paipu_name) {
							_hide_name = true;
						} else if (this.mode == EMJMode.live_broadcast && GameMgr.Inst.hide_ob_name) {
							_hide_name = true;
						}
					}
				}
				if (_hide_name) {
					if (game.Tools.isAI(_account_id)) {
						return { account_id: _account_id, nickname: playerData['nickname'], verified: 0, isRemarks };
					}
					let count = 0;
					let name_index = 0;
					let char_id = this.player_datas[index]['character'] ? this.player_datas[index]['character']['charid'] : 200001;
					let _player_count = this.rule_mode == ERuleMode.Liqi4 ? 4 : 3;
					for (let i = 0; i < _player_count; i++) {
						let _player = this.player_datas[i];
						if (!_player) break;
						if (!_player['account_id'] || GameMgr.Inst.account_id == _player['account_id']) continue;
						if (i == index) {
							count++;
							name_index = count;
						} else if (char_id == (_player['character'] ? _player['character']['charid'] : 200001)) {
							count++;
						}
					}
					
					nickname = cfg.item_definition.character.get(char_id)['name_' + GameMgr.client_language];
					if (count > 1) {
						nickname += name_index;
					}
				} else {
					if (!GameMgr.Inst.hide_nickname && showRemarks) {
						const friendInfo = game.FriendMgr.find(_account_id);
						if (friendInfo && friendInfo.remark) {
							nickname = friendInfo.remark;
							isRemarks = true;
						}
					}
					if (_account_id && !game.Tools.is_same_zone(GameMgr.Inst.account_id, _account_id)) {
						if (GameMgr.Inst.nickname_replace_enable && GameMgr.Inst.nickname_replace_lst.length > 0) {
							if (GameMgr.Inst.nickname_replace_table[_account_id]) {
								nickname = GameMgr.Inst.nickname_replace_table[_account_id];
								isRemarks = false;
							} else {
								nickname = GameMgr.Inst.nickname_replace_lst[Math.floor(Math.random() * GameMgr.Inst.nickname_replace_lst.length)];
								GameMgr.Inst.nickname_replace_table[_account_id] = nickname;
								isRemarks = false;
							}
	
						} else if (app.Taboo.test(nickname) != null) {
							nickname = game.Tools.strOfLocalization(3060);
							isRemarks = false;
						}
					}
				}
				return { account_id: _account_id, nickname: nickname, verified: this.player_datas[index]['verified'], isRemarks };
			}
		}

		public setNickname(container_name: Laya.Sprite, seat: number, remarkColor:string = "#c3e2ff", originColor:string = '#ffffff', includeVIP?: boolean) {
			const nameinfo = view.DesktopMgr.Inst.getPlayerName(seat);
			let isRemarks = nameinfo.isRemarks;
			if (includeVIP) isRemarks = game.Tools.SetNickname(container_name, nameinfo, false, true, isRemarks);
			else {
				const label_nickname = container_name.getChildByName('name') as Laya.Label;
				if (label_nickname) label_nickname.text = nameinfo.nickname;
			}
			game.Tools.SetNicknameColor(container_name, isRemarks ? remarkColor : originColor);
		}

		//是否显示炮牌
		public get showingPaopai(): boolean {
			return (this.mode != EMJMode.play && this.mode != EMJMode.xinshouyindao) || this.is_yongchang_mode();
		}

		// 开启了dora3模式
		public is_dora3_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['dora3_mode']) {
				return true;
			}
			return false;
		}

		// 开启了配牌open模式
		public is_peipai_open_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['begin_open_mode']) {
				return true;
			}
			return false;
		}

		// 开启了龙之目玉模式
		public is_muyu_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['muyu_mode']) {
				return true;
			}
			return false;
		}

		// 开启了公开手牌模式
		public is_open_hand(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['open_hand']) {
				return true;
			}
			return false;
		}

		// 是否是试炼模式
		public is_shilian_mode(): boolean {
			if (this.game_config && this.game_config['meta'] && this.game_config['meta']['mode_id'] == game.EMatchMode.shilian) {
				return true;
			}
			return false;
		}

		// 是否是修罗模式
		public is_xiuluo_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['xuezhandaodi']) {
				return true;
			}
			return false;
		}

		// 是否是waxizi模式
		public is_jiuchao_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['jiuchao_mode']) {
				return true;
			}
			return false;
		}

		// 是否是暗牌模式
		public is_reveal_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['reveal_discard']) {
				return true;
			}
			return false;
		}

		public is_hesu_mode(): boolean {
			if (this.game_config && this.game_config['meta'] && this.game_config['meta']['mode_id'] == game.EMatchMode.hesu) {
				return true;
			}
			return false;
		}

		// 开启了换三张模式
		public is_huansanzhang_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['huansanzhang']) {
				return true;
			}
			return false;
		}

		public is_chuanma_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['chuanma']) {
				return true;
			}
			return false;
		}
		public is_jjc_mode(): boolean {
			if (this.game_config && this.game_config['meta'] && this.game_config['meta']['mode_id'] == game.EMatchMode.jjc) {
				return true;
			}
			return false;
		}

		/**
		 * 是否是可以胡多次的模式，如修罗，赤羽，万象修罗
		 * @returns 
		 */
		public isHusMode(): boolean { 
			return this.xuezhan || this.is_chuanma_mode();
		}



		public is_top_match(): boolean {
			let mode_id: number = 0;
			if (this.game_config && this.game_config['meta']) {
				mode_id = this.game_config['meta']['mode_id'];
			}
			if ((mode_id == 15 || mode_id == 16 || mode_id == 25 || mode_id == 26) && this.player_datas) {
				for (let player of this.player_datas) {
					let level = this.rule_mode == ERuleMode.Liqi4 ? player['level']['id'] : player['level3']['id'];
					if (cfg.level_definition.level_definition.get(level).primary_level != 6) {
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public is_yongchang_mode() {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['yongchang_mode']) {
				return true;
			}
			return false;
		}

		public is_hunzhiyiji_mode() {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['hunzhiyiji_mode']) {
				return true;
			}
			return false;
		}

		// 是否是万象修罗模式（起手一张百搭牌模式）
		public is_wanxiangxiuluo_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['wanxiangxiuluo_mode']) {
				return true;
			}
			return false;
		}

		// 是否是背水一战模式（点棒加码）
		public is_beishuizhizhan_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['beishuizhizhan_mode']) {
				return true;
			}
			return false;
		}

		public is_speical_mode(): boolean {
			if (this.game_config && this.game_config.mode && this.game_config.mode.detail_rule && this.game_config.mode.detail_rule.amusement_switches) {
				if (this.game_config.mode.detail_rule.amusement_switches.length > 0) return true;
			}
			return false;
		}

		// 是否是**指定模式
		public isTargetSpecialMode(mode: game.EMJGameRule): boolean {
			if (this.game_config && this.game_config.mode && this.game_config.mode.detail_rule && this.game_config.mode.detail_rule.amusement_switches) {
				if (this.game_config.mode.detail_rule.amusement_switches.indexOf(mode) >= 0) return true;
			}
			return false;
		}

		/**
		 * 是否是观战模式，观战模式包括牌谱和观战
		 */
		public get isObserve(){
			return this.mode == EMJMode.paipu || this.mode == EMJMode.live_broadcast;
		}

		constructor() {
			super();
			DesktopMgr.Inst = this;

			this.actionMap = {};
			this.actionMap['ActionMJStart'] = new Laya.Handler(this, (d) => {
				// console.log('ActionMJStart' + (Laya.Stat.currentMemorySize/1024/1024) + ' MB');
				let msg = d['msg'];
				app.Log.log('ActionMJStart begin');
				this.ClearOperationShow();
				GameMgr.Inst.EnterMJ();
				uiscript.UI_FightBegin.show(Laya.Handler.create(this, () => {
					uiscript.UI_Loading.Inst.close();
					this.ActionRunComplete();
				}));
				return 2000;
			}, null, false);
			this.actionMap['ActionNewRound'] = new Laya.Handler(this, (d) => {
				// console.log('ActionNewRound' + (Laya.Stat.currentMemorySize/1024/1024) + ' MB');
				app.Log.log('ActionNewRound begin');
				let msg = d['msg'];
				let fast = d['fast'];
				this.ClearOperationShow();
				uiscript.UI_Loading.Inst.close();
				GameMgr.Inst.EnterMJ();
				if (fast) {
					uiscript.UI_FightBegin.hide();
					ActionNewRound.fastplay(msg, -1);
					return 0;
				} else {
					let wt: number = uiscript.UI_FightBegin.hide();
					Laya.timer.once(wt + 200, this, () => {
						ActionNewRound.play(msg);
					});
					if (msg['al']) wt += 1300;
					if (this.is_jiuchao_mode()) wt += 150;
					return wt + 200 + 1200 + 400;
				}
			}, null, false);
			this.actionMap['ActionNewCard'] = new Laya.Handler(this, (d) => {
				app.Log.log('ActionNewCard begin');
				let msg = d['msg'];
				let fast = d['fast'];
				this.ClearOperationShow();
				uiscript.UI_Loading.Inst.close();
				GameMgr.Inst.EnterMJ();
				if (fast) {
					ActionNewCard.fastplay(msg, -1);
					return 0;
				} else {
					return ActionNewCard.play(msg);
				}
			}, null, false);
			this.actionMap['ActionDiscardTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				// this.OnDiscardTile(msg);
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionDiscardTile.fastplay(msg, -1);
					return 0;
				} else {
					let t = ActionDiscardTile.play(msg);
					Laya.timer.once(t, this, this.ActionRunComplete);
					return t;
				}
			}, null, false);
			this.actionMap['ActionDealTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionDealTile.fastplay(msg, -1);
					return 0;
				} else {
					ActionDealTile.play(msg);
					return 500;
				}
			}, null, false);
			this.actionMap['ActionChiPengGang'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionChiPengGang.fastplay(msg, -1);
					return 0;
				} else {
					
					return 600 + ActionChiPengGang.play(msg);
				}
			}, null, false);
			this.actionMap['ActionAnGangAddGang'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionAnGangAddGang.fastplay(msg, -1);
					return 0;
				} else {
					ActionAnGangAddGang.play(msg);
					return 600 + 500;
				}
			}, null, false);
			this.actionMap['ActionHule'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				// this.OnPlayerHule(msg);
				ActionHule.play(msg);
				return 5000;
			}, null, false);
			this.actionMap['ActionHuleXueZhanMid'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				// this.OnPlayerHule(msg);
				ActionHuleXueZhanMid.play(msg);
				return 1000;
			}, null, false);
			this.actionMap['ActionHuleXueZhanEnd'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				// this.OnPlayerHule(msg);
				ActionHuleXueZhanEnd.play(msg);
				return 1000;
			}, null, false);
			this.actionMap['ActionNoTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				ActionNoTile.play(msg);
				return 5000;
			}, null, false);
			this.actionMap['ActionLiuJu'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				ActionLiuJu.play(msg);
				return 5000;
			}, null, false);
			this.actionMap['ActionBaBei'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				// this.OnDiscardTile(msg);
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionBabei.fastplay(msg, -1);
					return 0;
				} else {
					ActionBabei.play(msg);
					return 1000;
				}
			}, null, false);
			this.actionMap['ActionChangeTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionChangeTile.fastplay(msg, -1);
					return 0;
				} else {
					ActionChangeTile.play(msg);
					return 3000;
				}
			}, null, false);
			this.actionMap['ActionSelectGap'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionSelectGap.fastplay(msg, -1);
					return 0;
				} else {
					ActionSelectGap.play(msg);
					return 800;
				}
			}, null, false);
			this.actionMap['ActionGangResult'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionGangResult.fastplay(msg, -1);
					return 0;
				} else {
					ActionGangResult.play(msg);
					return 1000;
				}
			}, null, false);
			this.actionMap['ActionGangResultEnd'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionGangResultEnd.fastplay(msg, -1);
					return 0;
				} else {
					ActionGangResultEnd.play(msg);
					return 2000;
				}
			}, null, false);
			this.actionMap['ActionRevealTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				// this.OnDiscardTile(msg);
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionRevealTile.fastplay(msg, -1);
					return 0;
				} else {
					ActionRevealTile.play(msg);
					Laya.timer.once(500, this, this.ActionRunComplete);
					return 500;
				}
			}, null, false);
			this.actionMap['ActionLockTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				// this.OnDiscardTile(msg);
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionLockTile.fastplay(msg, -1);
					return 0;
				} else {
					ActionLockTile.play(msg);
					return 1000;
				}
			}, null, false);
			this.actionMap['ActionUnveilTile'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				// this.OnDiscardTile(msg);
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionUnveilTile.fastplay(msg, -1);
					return 0;
				} else {
					ActionUnveilTile.play(msg);
					return 1000;
				}
			}, null, false);
			this.actionMap['ActionFillAwaitingTiles'] = new Laya.Handler(this, (d) => {
				app.Log.log('ActionFillAwaitingTiles begin');
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionFillAwaitingTiles.fastplay(msg, -1);
					return 0;
				} else {
					return ActionFillAwaitingTiles.play(msg);
				}
			}, null, false);
			this.actionMap['ActionSubmit'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionSubmit.fastplay(msg, -1);
					return 0;
				} else {
					ActionSubmit.play(msg);
					return 500;
				}
			}, null, false);
			this.actionMap['ActionTake'] = new Laya.Handler(this, (d) => {
				this.ClearOperationShow();
				let msg = d['msg'];
				let fast = d['fast'];
				if (fast) {
					ActionTake.fastplay(msg, -1);
					return 0;
				} else {
					ActionTake.play(msg);
					return 2300;
				}
			}, null, false);

			app.NetAgent.addListener2MJ('NotifyGameEndResult', Laya.Handler.create(this, (msg: game.INotifyGameEndResult) => {
				this.gameEndResult = msg.result;
				if (uiscript.UI_Hangup_Warn.Inst.enable) {
					uiscript.UI_Hangup_Warn.Inst.close();
				}
				if (this.mode == EMJMode.play) {
					uiscript.UI_Activity.need_check_activity = true;
				}
				uiscript.UI_DesktopInfo.Inst.network_delay.close_refresh();
				Laya.timer.once(10000, this, () => {
					game.MJNetMgr.Inst.Close();
				});
			}));
			app.NetAgent.addListener2MJ('ActionPrototype', Laya.Handler.create(this, (msg) => {
				app.Log.log('Receive Action: ' + JSON.stringify(msg));
				if (this.duringReconnect) {
					this.actionList.push(msg);
				} else {
					if (this.actionList.length > 0) {
						this.actionList.push(msg);
						// if (msg['name'] == 'ActionNewRound') {
						// 	if (uiscript.UI_ScoreChange.Inst.enale) uiscript.UI_ScoreChange.Inst.enale = false;
						// 	if (uiscript.UI_LiuJu.Inst.enale) uiscript.UI_LiuJu.Inst.enale = false;
						// }
					} else {
						this.actionList.push(msg);
						let t: number = this.doactioncd - Laya.timer.currTimer;
						if (t < 0) t = 0;
						this.StartChainAction(t);
					}
				}
			}));

			app.NetAgent.addListener2MJ('NotifyGameTerminate', Laya.Handler.create(this, (msg) => {
				app.Log.log('NotifyGameTerminate:' + JSON.stringify(msg));
				view.AudioMgr.StopMusic();
				if (msg.reason != 'user-manual-terminate') {
					uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(2227), Laya.Handler.create(this, () => {
						this.Reset();
						game.Scene_MJ.Inst.GameEnd();
					}));
				}
				if (uiscript.UI_VoteProgress.Inst.enable) uiscript.UI_VoteProgress.Inst.close();
			}));

			ModelAnimationController.init_data();
			app.NetAgent.addListener2MJ('NotifyGamePause', Laya.Handler.create(this, (msg) => {
				app.Log.log('NotifyGamePause:' + JSON.stringify(msg));
				let p: boolean = msg['paused'];
				this.setGameStop(p);
			}));
			app.NetAgent.addListener2MJ('NotifyGameFinishReward', Laya.Handler.create(this, msg => {
				app.Log.log('NotifyGameFinishReward: ' + JSON.stringify(msg));
				this.levelchangeinfo = msg['level_change'];
				this.rewardinfo = msg;
			}));
			app.NetAgent.addListener2MJ('NotifyActivityReward', Laya.Handler.create(this, msg => {
				app.Log.log('NotifyActivityReward: ' + JSON.stringify(msg));
				this.activity_reward = msg;
			}));
			app.NetAgent.addListener2MJ('NotifyActivityPoint', Laya.Handler.create(this, msg => {
				let lst = msg.activity_points;
				for (let i: number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.activity_id == uiscript.UI_Activity_DuanWu_Point.activity_id) {
						uiscript.UI_Activity_DuanWu_Point.point = d.point;
						uiscript.UI_Chunjie.need_refresh_rank = true;// 分数有变动需要刷新
					}
				}
			}));
			app.NetAgent.addListener2MJ('NotifyLeaderboardPoint', Laya.Handler.create(this, msg => {
				let lst = msg.leaderboard_points;
				for (let i: number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.leaderboard_id == uiscript.UI_Activity_DuanWu_Rank.activity_id) {
						uiscript.UI_Activity_DuanWu_Rank.point = d.point;
					}
				}
			}));
			app.NetAgent.addListener2Lobby('NotifyGameFinishRewardV2', Laya.Handler.create(this, msg => {
				app.Log.log('NotifyGameFinishReward: ' + JSON.stringify(msg));
				this.levelchangeinfo = msg['level_change'];
				this.rewardinfo = msg;
			}));
			app.NetAgent.addListener2Lobby('NotifyActivityRewardV2', Laya.Handler.create(this, msg => {
				app.Log.log('NotifyActivityReward: ' + JSON.stringify(msg));
				this.activity_reward = msg;
			}));
			app.NetAgent.addListener2Lobby('NotifyActivityPointV2', Laya.Handler.create(this, msg => {
				let lst = msg.activity_points;
				for (let i: number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.activity_id == uiscript.UI_Activity_DuanWu_Point.activity_id) {
						uiscript.UI_Activity_DuanWu_Point.point = d.point;
						uiscript.UI_Chunjie.need_refresh_rank = true;// 分数有变动需要刷新
					}
				}
			}));
			app.NetAgent.addListener2Lobby('NotifyLeaderboardPointV2', Laya.Handler.create(this, msg => {
				let lst = msg.leaderboard_points;
				for (let i: number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.leaderboard_id == uiscript.UI_Activity_DuanWu_Rank.activity_id) {
						uiscript.UI_Activity_DuanWu_Rank.point = d.point;
					}
				}
			}));
			app.NetAgent.addListener2MJ('PlayerLeaving', Laya.Handler.create(this, msg => {
				if (msg && msg['seat'] == this.seat) {
					uiscript.UI_Hangup_Warn.Inst.show();
				}
			}));
			Laya.stage.on(EventCode.BADGE_DATA_UPDATE, this, (changeData) => { 
				this.badgeChange = changeData;
			})
		}

		public ActionRunComplete() {
			this.action_running = false;
			if (uiscript.UI_DesktopInfo.Inst && uiscript.UI_DesktopInfo.Inst.enable) {
				uiscript.UI_DesktopInfo.Inst.freshTingCount();
			}
		}

		public onTileChange() {
			if (uiscript.UI_DesktopInfo.Inst && uiscript.UI_DesktopInfo.Inst.enable) {
				uiscript.UI_DesktopInfo.Inst.freshTingCount();
			}
		}

		public StartChainAction(waittime: number) {
			this.doactioncd = Laya.timer.currTimer + waittime;
			Laya.timer.frameLoop(1, this, this.DoChainAction, null, true);
		}

		private DoChainAction() {
			if (this.action_index >= this.actionList.length) {
				this.action_index = 0;
				this.actionList = [];
				this.dochain_fast = false;
				Laya.timer.clear(this, this.DoChainAction);
				if (this.duringReconnect) {
					app.Log.log('finishSyncGame0');
					app.NetAgent.sendReq2MJ('FastTest', 'finishSyncGame', {}, (err, res) => { });
					this.duringReconnect = false;
				}
			} else {
				if (!this.dochain_fast) {
					if (this.action_running) return;
					// if (Laya.timer.currFrame <= this.action_frame) return;
					if (Laya.timer.currTimer <= this.doactioncd - Laya.timer.delta) return;
					Laya.timer.clear(this, this.DoChainAction);
				}

				if (this.action_index == this.actionList.length - 1) {
					if (this.duringReconnect) {
						this.duringReconnect = false;
						app.Log.log('finishSyncGame1');
						app.NetAgent.sendReq2MJ('FastTest', 'finishSyncGame', {}, (err, res) => { });
					}
				}

				if (this.dochain_fast) {
					if (this.action_index + 2 < this.actionList.length) {
						this.DoMJAction(this.actionList[this.action_index++], true);
					} else {
						this.dochain_fast = false;
						this.DoMJAction(this.actionList[this.action_index++], false);
					}
				} else {
					this.dochain_fast = false;
					if (this.action_index + 4 < this.actionList.length) {
						this.dochain_fast = true;
					}
					if (this.dochain_fast) {
						Laya.timer.once(800, this, () => {
							for (let i: number = this.actionList.length - 1; i >= this.action_index; i--) {
								if (this.actionList[i]['name'] == 'ActionNewRound') {
									this.action_index = i;
									break;
								}
							}
							this.DoMJAction(this.actionList[this.action_index++], true);
						});
					} else {
						this.DoMJAction(this.actionList[this.action_index++], false);
					}
				}
			}
			// this.action_frame = Laya.timer.currFrame;
		}

		public static EnDecode(data:ArrayBuffer) {
			let masks:Array<number> = [132, 94, 78, 66, 57, 162, 31, 96, 28];
			for (let i:number = 0; i < data.byteLength; i++) {
				let m:number = ((data.byteLength ^ 23) + (i * 5) + masks[i % masks.length]) & 255;
				data[i] ^= m;
			}
			return data;
		}

		private DoMJAction(data: Object, fast: boolean) {
			if (!this.active) return;
			const MessageType: any = net.ProtobufManager.lookupType('lq.' + data['name']);
			if (!MessageType)
				throw new Error(`ERR_CANNOT_FIND_MESSAGE_TYPE, ${'lq.' + data['name']}`);
			let step: number = data['step'];
			
			let msg: any = MessageType.decode(DesktopMgr.EnDecode(data['data']));
			// let msg: any = MessageType.decode(data['data']);
			app.Log.log('DoMJAction step:' + step + ' [' + data['name'] + ']:  ' + JSON.stringify(msg) + ' fast:' + fast);
			if (step > 1 && step != this.current_step + 1) {
				app.Log.log('step 不对 强制触发全数据重连 step:' + step + ' current_step:' + this.current_step);
				this.trySyncGame();
				return;
			}
			let waittime: number = 0;
			this.current_step = step;
			if (this.actionMap.hasOwnProperty(data['name'])) {
				try {
					if (!fast) this.action_running = true;
					waittime = this.actionMap[data['name']].runWith({ msg: msg, fast: fast });
				} catch (e) {
					let _errorinfo: Object = {};
					_errorinfo['error'] = e.message;
					_errorinfo['stack'] = e.stack;
					_errorinfo['method'] = 'DoMJAction';
					_errorinfo['name'] = data['name'];
					_errorinfo['data'] = data;
					_errorinfo['step'] = step;
					GameMgr.Inst.onFatalError(_errorinfo);
					return;
				}
			} else {
				app.Log.Error('没有监听操作：' + data['name']);
			}
			if (fast) {
				this.DoChainAction();
			} else {
				Laya.timer.frameOnce(1, this, () => {
					this.StartChainAction(waittime);
				});
			}
		}

		public _load(owner: Laya.Sprite3D): void {
			this.desktop3D = owner;
			(this.desktop3D.getChildByName('all') as Laya.Sprite3D).active = false;
			let poss: Laya.Sprite3D = this.desktop3D.getChildByName('poss') as Laya.Sprite3D;
			this.players = new Array<ViewPlayer>();
			this.mainrole = (poss.getChildByName('man_' + 1) as Laya.Sprite3D).addComponent(ViewPlayer_Me) as ViewPlayer_Me;
			this.mainrole.InitMe(this, 0, game.Scene_MJ.Inst.root2.getChildByName('hands') as Laya.Sprite3D, poss);
			//全屏特效父节点初始化
			this.trans_container_fullscreeen_effect = game.Scene_MJ.Inst.effect_fullscreen_root;

			this.players.push(this.mainrole);
			for (let i: number = 2; i <= 4; i++) {
				let p: ViewPlayer = (poss.getChildByName('man_' + i) as Laya.Sprite3D).addComponent(ViewPlayer_Other) as ViewPlayer;
				p.Init(this, i - 1, poss);
				this.players.push(p);
			}

			{
				//others
				let trans_container_other: Laya.Sprite3D = this.desktop3D.getChildByName('other') as Laya.Sprite3D;
				let _trans_left: Laya.Sprite3D = trans_container_other.getChildByName('left') as Laya.Sprite3D;
				this.num_left_show.push(_trans_left.getChildByName('0') as Laya.MeshSprite3D);
				this.num_left_show.push(_trans_left.getChildByName('1') as Laya.MeshSprite3D);
				let _trans_chang: Laya.Sprite3D = trans_container_other.getChildByName('chang') as Laya.Sprite3D;
				this.container_other = trans_container_other;
				this.plane_chang = _trans_chang.getChildByName('chang') as Laya.MeshSprite3D;
				this.plane_ju = _trans_chang.getChildByName('ju') as Laya.MeshSprite3D;

				this.container_other = trans_container_other;


				this.container_other_reveal = this.desktop3D.getChildByName('other_reveal') as Laya.Sprite3D;
				let _trans_left_reveal: Laya.Sprite3D = this.container_other_reveal.getChildByName('left') as Laya.Sprite3D;
				this.num_left_show_reveal.push(_trans_left_reveal.getChildByName('0') as Laya.MeshSprite3D);
				this.num_left_show_reveal.push(_trans_left_reveal.getChildByName('1') as Laya.MeshSprite3D);
				let _trans_chang_reveal: Laya.Sprite3D = this.container_other_reveal.getChildByName('chang') as Laya.Sprite3D;
				this.plane_chang_reveal = _trans_chang_reveal.getChildByName('chang') as Laya.MeshSprite3D;
				this.plane_ju_reveal = _trans_chang_reveal.getChildByName('ju') as Laya.MeshSprite3D;
				if (GameMgr.client_language == 'kr') {
					let kr_tex_path = 'scene/Assets/Resource/table/tablemid/';
					let mat = this.plane_chang_reveal.meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'chang_kr.png');
					mat = (_trans_chang_reveal.getChildByName('juzi') as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'chang_kr.png');
				// 韩语修改文本
					mat = (_trans_left_reveal.getChildByName('left') as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'left_kr.png');
					(_trans_left_reveal.getChildByName('left') as Laya.MeshSprite3D).transform.localScale = new Laya.Vector3(0.0018, 0.0018, 0.3);
					(_trans_left_reveal.getChildByName('left') as Laya.MeshSprite3D).transform.localPosition = new Laya.Vector3(-0.00367, -0.0001, 0.00703);
					mat = this.plane_chang.meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'chang_kr.png');
					mat = (_trans_chang.getChildByName('juzi') as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'chang_kr.png');
					mat = (_trans_left.getChildByName('left') as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
					mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'left_kr.png');
					(_trans_left.getChildByName('left') as Laya.MeshSprite3D).transform.localScale = new Laya.Vector3(0.0018, 0.0018, 0.3);
					(_trans_left.getChildByName('left') as Laya.MeshSprite3D).transform.localPosition = new Laya.Vector3(-0.00367, -0.0001, 0.00703);
					
				}

				let _trans_score = this.container_other_reveal.getChildByName('score') as Laya.Sprite3D;
				for (let i = 0; i < 6; i++) {
					this.score_reveal.push(_trans_score.getChildAt(i) as Laya.MeshSprite3D);
				}

				this.SetLeftPaiShow(0);
				this.SetChangJuShow(0, 0, 0);
			}

			{
				//effect
				this.trans_container_effect = this.desktop3D.getChildByName('effect') as Laya.Sprite3D;
				this.effect_dora3D = this.trans_container_effect.getChildByName('effect_dora') as Laya.Sprite3D;
				this.effect_dora3D_touying = this.trans_container_effect.getChildByName('effect_touming_dora') as Laya.Sprite3D;
				let mat = (this.effect_dora3D.getChildAt(0) as Laya.MeshSprite3D).meshRender.material as Laya.StandardMaterial;
				mat.disableLight();
				this.effect_shadow = this.trans_container_effect.getChildByName('effect_shadow') as Laya.Sprite3D;
				this.effect_shadow_touming = this.trans_container_effect.getChildByName('effect_shadow_touming') as Laya.Sprite3D;
				this.effect_dora3D.active = true;
				this.effect_shadow.active = true;
				this.effect_shadow_touming.active = true;
				this.effect_dora3D_touying.active = true;
			}

			this.effect_doraPlane = game.Scene_MJ.Inst.root2.getChildByName('hands').getChildByName('effect_dora') as Laya.Sprite3D;
			this.effect_recommend = game.Scene_MJ.Inst.root2.getChildByName('hands').getChildByName('effect_recommend') as Laya.Sprite3D;
			this.effect_doraPlane.active = false;
			this.effect_recommend.active = false;
			let mat = (this.effect_recommend.getChildAt(0) as Laya.MeshSprite3D).meshRender.material as Laya.StandardMaterial;

			let texture_path: string = 'myres2/mjp/recommend.png';
			if (GameMgr.client_language != 'chs') {
				texture_path = GameMgr.client_language + '/' + texture_path;
			}
			// 防止图片问题导致卡死
			if (Laya.loader.getRes(texture_path)) {
				mat.diffuseTexture = Laya.loader.getRes(texture_path);
			}
			
		}

		public initRoom(game_config: game.IGameConfig, players: Array<Object>, myaccountid: number, mode: EMJMode, complete: Laya.Handler) {
			uiscript.UI_Rpg.needShow = false; // 临时，2025.8.17 yu：之后写在scene_lobby里的clearJumpMark里
			uiscript.UI_WaitingRoom.Inst.resetData();
			this.game_config = game_config;
			this.rule_mode = ERuleMode.Liqi4;
			if (game_config['mode']['mode']) {
				if (game_config['mode']['mode'] < 10) {
					this.rule_mode = ERuleMode.Liqi4;
				} else {
					this.rule_mode = ERuleMode.Liqi3;
				}
			}
			this.xuezhan = false;
			if (game_config['mode'] && game_config['mode']['detail_rule']) {
				this.xuezhan = !!game_config['mode']['detail_rule']['xuezhandaodi'] || !!game_config['mode']['detail_rule']['wanxiangxiuluo_mode'];
			}
			if (game_config['mode'] && game_config['mode']['detail_rule']) {
				this.field_spell = game_config['mode']['detail_rule']['field_spell_mode'];
			}
			if (game_config['mode'] && game_config['mode']['detail_rule'] && game_config['mode']['detail_rule']['reveal_discard']) {
				this.container_other.active = false;
				this.container_other_reveal.active = true;
				this.anpai = true;
			} else {
				this.anpai = false;
				this.container_other.active = true;
				this.container_other_reveal.active = false;
			}
			this.mode = mode;
			this.seat = -1;
			this.player_datas = players;
			this.gameEndResult = null;
			this.lastRoundRecord = [];
			this.levelchangeinfo = null;
			this.activity_reward = null;
			this.badgeChange = null;
			this.rewardinfo = null;
			this.active = true;
			this.ptchange = 0;
			this.timestoped = false;
			this.action_running = false;
			this.hangupCount = 0;
			this.handles_after_timerun = [];
			this.muyu_info = null;
			this.xiakeshangInfo = null;
			this.tributeState = 0;
			if (this.muyu_effect) {
				this.muyu_effect.destroy();
				this.muyu_effect = null;
			}
			uiscript.UI_GameStop.Inst.close();

			uiscript.UI_Replay.Inst.hide_name = false;
			this._record_show_hand = Laya.LocalStorage.getItem('record_show_hand') != '0';
			this._record_show_paopai = Laya.LocalStorage.getItem('record_show_paopai') != '0';
			this._ob_show_hand = Laya.LocalStorage.getItem('ob_show_hand') != '0';
			this._ob_show_paopai = Laya.LocalStorage.getItem('ob_show_paopai') != '0';
			this._ob_follow_dealer = Laya.LocalStorage.getItem('ob_follow_dealer') != '0';
			if (this.mode == EMJMode.paipu) {
				this.record_show_anim = Laya.LocalStorage.getItem('record_show_anim') != '0';
			} else {
				this.record_show_anim = true;
			}
			if (this.mode == EMJMode.play) {
				uiscript.UI_Invite.Inst.enable = false;
				if (game_config['category'] == 4) {
					GameMgr.Inst.custom_match_id = game_config['meta']['contest_uid'];
				}
			}
			else uiscript.UI_Invite.Inst.enable = true;
			this.myaccountid = myaccountid;
			let soundlist: Object = {};
			for (let i: number = 0; i < players.length; i++) {
				let d_skin = cfg.item_definition.skin.get(players[i]['avatar_id']);
				let d_chara = cfg.item_definition.character.get(d_skin.character_id);

				let sounds = cfg.voice.sound.getGroup(d_chara.sound);
				for (let j: number = 0; j < sounds.length; j++) {
					if (players[i]['character']) {
						if (sounds[j].category == 2 && sounds[j].level_limit <= players[i]['character']['level']) {
							let p: string = sounds[j].path + view.AudioMgr.suffix;
							if (!soundlist.hasOwnProperty(p)) soundlist[p] = 1;
						}
					}
				}
			}
			for (var k in soundlist) {
				Laya.loader.load(k, null, null, null, 3);
			}

			for (let i: number = 0; i < this.player_datas.length; i++) {
				if (this.player_datas[i]['account_id'] == myaccountid) {
					this.seat = i;
				}
			}

			// saki联动判定
			if (GameMgr.regionLimited) {
				for (let i: number = 0; i < this.player_datas.length; i++) {
					if (this.player_datas[i]['account_id'] == GameMgr.Inst.account_id) continue;
					//如果saki版权限制，需要将部分内容修改
					if (game.GameUtility.char_limited(this.player_datas[i]['character']['charid'])) {
						this.player_datas[i]['character']['charid'] = game.GameUtility.get_default_ai_character();
						this.player_datas[i]['character']['skin'] = game.GameUtility.get_default_ai_skin();
						this.player_datas[i]['avatar_id'] = game.GameUtility.get_default_ai_skin();
					}
					let views = this.player_datas[i]['views'];
					if (views) {
						for (let j: number = views.length - 1; j >= 0; j--) {
							let item_id: number = views[j].item_id;
							if (item_id && cfg.item_definition.item.get(item_id).region_limit == 1) {
								views.splice(j, 1);
							}
						}
					}
				}
			}
			if (this.seat == -1) {
				if (this.mode != EMJMode.play) {
					this.seat = 0;
				} else {
					uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2228));
					app.Log.Error(JSON.stringify(players));
					return;
				}
			}

			this.emoji_switch = false;
			if (game_config['mode'] && game_config['mode']['game_setting']) {
				this.emoji_switch = !!game_config['mode']['game_setting']['emoji_switch'];
			}
			uiscript.UI_Replay.Inst.enable = this.mode == EMJMode.paipu;
			uiscript.UI_Ob_Replay.Inst.enable = false;

			DesktopMgr.bianjietishi = true;
			if (mode == EMJMode.play) {
				if (game_config['mode'] && game_config['mode']['detail_rule']) {
					let detail_rule = game_config['mode']['detail_rule'];
					if (detail_rule['bianjietishi'] != null) {
						DesktopMgr.bianjietishi = detail_rule['bianjietishi'];
					}
				}
				if (game_config['category'] == 2 && game_config['meta']) {
					let d_desk = cfg.desktop.matchmode.get(game_config['meta']['mode_id']);
					if (d_desk && d_desk.room == 6) {
						DesktopMgr.bianjietishi = false;
					}
				}
				uiscript.UI_MJTask_Progress.record();
			}
			let is_jiuchao_mode: boolean = this.is_jiuchao_mode();
			// 获取牌面
			this.mjp_res_name = is_jiuchao_mode ?  'mjpface_default': game.GameUtility.get_view_res_name(game.EView.mjp_surface);
			if (view.DesktopMgr.en_mjp) {
				this.mjp_res_name += '_0';
			}
			
			this.mjpb_res_name = game.GameUtility.get_view_res_name(game.EView.mjp);
			this.player_effects = [];

			let _view_type_min: number = game.EView.liqibang as number;
			let _view_type_max: number = game.EView.lobby_bg as number;

			for (let i: number = 0; i < this.player_datas.length; i++) {
				let d_character = this.player_datas[i]['character'];
				let _effect_map: Object = {};
				for (let i: number = _view_type_min; i <= _view_type_max; i++) {
					let default_id: number = game.GameUtility.get_view_default_item_id(i);
					_effect_map[i as game.EView] = default_id;
				}
				if (d_character) {
					let views = this.player_datas[i]['views'];
					let excel_character = cfg.item_definition.character.get(d_character['charid']);
					if (excel_character) {
						_effect_map[game.EView.hand_model] = excel_character.hand;
					}
					if (views) {
						for (let j: number = 0; j < views.length; j++) {
							let slot: number = views[j].slot;
							let item_id: number = views[j].item_id;
							if (item_id) {
								_effect_map[slot as game.EView] = item_id;
							}
						}
					}
				} else {
					this.player_datas[i]['character'] = {
						charid: game.GameUtility.get_default_ai_character(),
						level: 0,
						exp: 0,
						views: [],
						skin: game.GameUtility.get_default_ai_skin(),
						is_upgraded: false
					};
				}
				this.player_effects.push(_effect_map);
			}

			uiscript.UI_DesktopInfo.Inst.initRoom();
			uiscript.UI_DesktopInfo.Inst.refreshSeat();
			uiscript.UI_Hangup_Warn.Inst.enable = false;

			uiscript.UI_TingPai.Inst.enable = true;
			uiscript.UI_HuanSanZhange.Inst.enable = false;
			uiscript.UI_HuanSanZhange_ChangeType.Inst.enable = false;
			uiscript.UI_Dingque.Inst.enable = false;
			if (uiscript.UI_Desktop_Yindao.Inst) {
				uiscript.UI_Desktop_Yindao.Inst.enable = false;
			}

			this.index_change = 0;
			this.index_ju = 0;
			this.index_ben = 0;
			this.index_player = 0;
			this.index_chuanma_ju = 0;
			this.gameing = true;
			this.left_tile_count = 69;
			this.duringReconnect = false;
			this.current_step = 0;
			this.action_index = 0;
			this.dochain_fast = false;
			this.actionList = [];
			this.setAutoHule(false);
			this.setAutoMoQie(false);
			this.setAutoNoFulu(false);
			this.setAutoBaBei(false);
			uiscript.UI_DesktopInfo.Inst.resetFunc();
			this.SetChangJuShow(this.index_change, this.index_ju, this.index_chuanma_ju);
			uiscript.UI_DesktopInfo.Inst.setBen(this.index_ben);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			for (let i: number = 0; i < 4; i++) {
				this.players[i].onInitRoom(this.localPosition2Seat(i));
				this.players[i].SetScore(0, 0);
				this.players[i].trans_ind.active = false;
				this.players[i].RefreshDir();
			}
			this.RefreshPaiLeft();
			this.initSpecialModeEffect();
			uiscript.UI_GameEnd.Inst.forceclose();
			uiscript.UI_RankChange.Inst.close();
			uiscript.UI_MJReward.Inst.close();
			Laya.timer.frameOnce(6, this, () => {
				this.Reset();
				app.Log.log('场景init结束：' + (Laya.Stat.currentMemorySize / 1024 / 1024) + ' MB');
				if (complete) complete.run();
			});

			this.state_cache = {};
			if (uiscript.UI_Activity.activity_is_running(uiscript.UI_Activity_DuanWu_Point.activity_id)) {
				this.state_cache['duanwu_point'] = uiscript.UI_Activity_DuanWu_Point.point;
				this.state_cache['duanwu_rank'] = uiscript.UI_Activity_DuanWu_Rank.point;
			}
			if (this.is_muyu_mode()) {
				let url: string = `scene/effect_muyu_${GameMgr.client_language}.lh`;
				this.muyu_effect = new game.EffectBase(url);
				this.muyu_effect.root.active = false;
				this.trans_container_effect.addChild(this.muyu_effect.root);
			}

			uiscript.UI_VoteCD.time_cd = 0;	// 每次进入对局，重置投票cd
			this.isPlayedPrepareAudio = false;
			this.resetGameVoice();
			this.refreshTeamName();
		}

		//替换主视角
		public changeMainbody(seat: number) {
			if (this.mode == EMJMode.play) return;
			if (!this.gameing) return;
			this.seat = seat;
			uiscript.UI_DesktopInfo.Inst.refreshSeat(true);
			for (let i: number = 0; i < 4; i++) {
				this.players[i].onInitRoom(this.localPosition2Seat(i));
				this.players[i].trans_ind.active = false;
				this.players[i].RefreshDir();
			}
			this.Reset();
			this.refreshTeamName();
			if (this.mode == EMJMode.paipu) uiscript.UI_Replay.Inst.onChangeMainBody();
			if (this.mode == EMJMode.live_broadcast) uiscript.UI_Live_Broadcast.Inst.onChangeMainbody();
			if (this.mode == EMJMode.live_broadcast) uiscript.UI_Live_Broadcast1.Inst.onChangeMainbody();
		}

		//强制触发重新刷新
		public trySyncGame() {
			this.Reset();
			this.duringReconnect = true;
			this.hangupCount = 0;
			app.NetAgent.sendReq2MJ('FastTest', 'syncGame', {
				round_id: this.round_id,
				step: 0,
			}, (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('syncGame', err, res);
					game.Scene_MJ.Inst.ForceOut();
				} else {
					app.Log.log('[syncGame2] ' + JSON.stringify(res));
					if (res['is_end']) {
						uiscript.UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2229));
						game.Scene_MJ.Inst.GameEnd();
					} else {
						this.fetchLinks();
						this.Reset();
						this.duringReconnect = true;
						this.syncGameByStep(res['game_restore']);
					}
				}
			});
		}

		//全数据重连
		public syncGameByStep(msg: any) {
			let isover: boolean = false;
			this.timestoped = false;
			this.handles_after_timerun = [];
			this.action_running = false;
			uiscript.UI_GameStop.Inst.close();
			this.hangupCount = 0;
			uiscript.UI_Hangup_Warn.Inst.enable = false;
			if (msg && msg['game_state'] === 5) { // 5是暂停
				this.timestoped = true;
			}
			GameMgr.Inst.EnterMJ();
			if (msg && msg.actions && msg.actions.length > 0) {
				this.actionList = [];
				let usetime: number = -1;
				if (msg.passed_waiting_time != null && msg.passed_waiting_time != undefined) {
					usetime = msg.passed_waiting_time * 1000;
				}
				for (let i = 0; i < msg.actions.length; i++) {
					let _action = msg.actions[i];
					let _usetime = i == msg.actions.length - 1 ? usetime : -1;
					const MessageType: any = net.ProtobufManager.lookupType('lq.' + _action.name);
					if (!MessageType)
						throw new Error(`ERR_CANNOT_FIND_MESSAGE_TYPE, ${'lq.' + _action.name}`);
					let _msg: any = MessageType.decode(_action.data);
					this.current_step = _action.step;
					try {
						switch (_action.name) {
							case 'ActionNewRound': ActionNewRound.fastplay(_msg, _usetime); break;
							case 'ActionChangeTile': ActionChangeTile.fastplay(_msg, _usetime); break;
							case 'ActionDiscardTile': ActionDiscardTile.fastplay(_msg, _usetime); break;
							case 'ActionDealTile': ActionDealTile.fastplay(_msg, _usetime); break;
							case 'ActionChiPengGang': ActionChiPengGang.fastplay(_msg, _usetime); break;
							case 'ActionAnGangAddGang': ActionAnGangAddGang.fastplay(_msg, _usetime); break;
							case 'ActionHule': ActionHule.fastplay(_msg, _usetime); isover = true; break;
							case 'ActionHuleXueZhanMid': ActionHuleXueZhanMid.fastplay(_msg, _usetime); isover = true; break;
							case 'ActionHuleXueZhanEnd': ActionHuleXueZhanEnd.fastplay(_msg, _usetime); isover = true; break;
							case 'ActionLiuJu': ActionLiuJu.fastplay(_msg, _usetime); isover = true; break;
							case 'ActionNoTile': ActionNoTile.fastplay(_msg, _usetime); isover = true; break;
							case 'ActionBaBei': ActionBabei.fastplay(_msg, _usetime); break;
							case 'ActionSelectGap': ActionSelectGap.fastplay(_msg, _usetime); break;
							case 'ActionGangResult': ActionGangResult.fastplay(_msg, _usetime); break;
							case 'ActionGangResultEnd': ActionGangResultEnd.fastplay(_msg, _usetime); break;
							case 'ActionLockTile': ActionLockTile.fastplay(_msg, _usetime); break;
							case 'ActionRevealTile': ActionRevealTile.fastplay(_msg, _usetime); break;
							case 'ActionUnveilTile': ActionUnveilTile.fastplay(_msg, _usetime); break;
							case 'ActionNewCard': ActionNewCard.fastplay(_msg, _usetime); break;
							case 'ActionFillAwaitingTiles': ActionFillAwaitingTiles.fastplay(_msg, _usetime); break;
							case 'ActionSubmit': ActionSubmit.fastplay(_msg, _usetime); break;
							case 'ActionTake': ActionTake.fastplay(_msg, _usetime); break;
						}
					} catch (e) {
						let _errorinfo: Object = {};
						_errorinfo['error'] = e.message;
						_errorinfo['stack'] = e.stack;
						_errorinfo['method'] = 'syncGameByStep';
						_errorinfo['name'] = _action.name;
						_errorinfo['data'] = _action;
						_errorinfo['step'] = i;
						GameMgr.Inst.onFatalError(_errorinfo);
						break;
					}
				}
				Laya.timer.once(1000, this, () => {
					this.duringReconnect = false;
					uiscript.UI_Loading.Inst.close();
					if (!isover) view.BgmListMgr.PlayMJBgm();
					this.DoChainAction();
				});
			} else {
				//没有列表的话代表正在结算番符，等待到下一局开始
				this.duringReconnect = false;
				if (!this.timestoped) {
					app.NetAgent.sendReq2MJ('FastTest', 'confirmNewRound', {}, (err, res) => { });
				} else {
					this.handles_after_timerun.push(Laya.Handler.create(this, () => {
						app.NetAgent.sendReq2MJ('FastTest', 'confirmNewRound', {}, (err, res) => { });
					}));
				}

			}

			app.Log.log('finishSyncGame11');
			app.NetAgent.sendReq2MJ('FastTest', 'finishSyncGame', {}, (err, res) => { });
			DesktopMgr.Inst.fetchLinks();
			if (this.timestoped) {
				uiscript.UI_GameStop.Inst.show();
			}
		}

		//设置暂停信息
		public setGameStop(p: boolean) {
			if (p == this.timestoped) return;
			this.timestoped = p;
			if (this.timestoped) {
				this.handles_after_timerun = [];
				uiscript.UI_GameStop.Inst.show();
			} else {
				uiscript.UI_GameStop.Inst.close();
				if (this.handles_after_timerun) {
					for (let i: number = 0; i < this.handles_after_timerun.length; i++) {
						this.handles_after_timerun[i].run();
					}
				}
				this.handles_after_timerun = [];
				this.hangupCount = 0;
			}
		}

		public CreatePai3D(pai: mjcore.MJPai): Laya.Sprite3D {
			let _touming = pai.touming && !this.is_tianming_mode();
			let maque: Laya.MeshSprite3D = (this.desktop3D.getChildByName('all').getChildByName('mjp').getChildByName(_touming ? 'touming' : 'maque') as Laya.MeshSprite3D).clone();
			let maque_outline: Laya.MeshSprite3D = (this.desktop3D.getChildByName('all').getChildByName('maque_outline') as Laya.MeshSprite3D).clone();
			//change to卡通
			{
				if (_touming) {
					let mesh: Laya.MeshSprite3D = maque;
					let mat_cartoon: caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
				
					let mat_transparent = new caps.Material_TouMingPai(caps.TouMingPai.filename);
					let texture_path: string = 'scene/Assets/Resource/mjpai/';
					if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
						texture_path += 'en_kr/';
					}
					texture_path += DesktopMgr.en_mjp ? 'toumingpai_0/mjp.png' : 'toumingpai/mjp.png';
					mat_transparent.setTexture(caps.TouMingPai.TEXTURE, Laya.loader.getRes(texture_path));
					mesh.meshRender.sharedMaterial = mat_transparent;
				} else {
					let mesh: Laya.MeshSprite3D = maque.getChildAt(0) as Laya.MeshSprite3D;
					
					// 例：scene/Assets/Resource/mjpaimian/en_kr/mjpface_special_0/wanxiangxiuluo_mode/hand.png
					let texture_path: string = 'scene/Assets/Resource/mjpaimian/';
					if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
						texture_path += 'en_kr/';
					}
					let split = 0.7;
					let front_texture = texture_path + this.mjp_res_name + '/mjp.png';
					if (pai.baida) {
						front_texture = texture_path + (DesktopMgr.en_mjp ? 'mjpface_special_0/wanxiangxiuluo_mode/mjp.png' : 'mjpface_special/wanxiangxiuluo_mode/mjp.png');
					}
					let texture_back_path: string = 'scene/Assets/Resource/mjpai/';
					let back_texture = texture_back_path + this.mjpb_res_name + '/mjp.png';
					let mat_cartoon_front: caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon_Pai.filename);
					let tex: Laya.Texture2D = Laya.loader.getRes(front_texture);
					if (tex) {
						tex.mipmap = false;
					}
					mat_cartoon_front.setTexture(caps.Cartoon_Pai.TEXTURE, tex);
					mat_cartoon_front.setNumber(caps.Cartoon_Pai.SPLIT, split);
					mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
					mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
					mat_cartoon_front.setColor(caps.Cartoon_Pai.COLOR, new Laya.Vector3(1, 1, 1));
					mat_cartoon_front.setColor(caps.Cartoon_Pai.TILING_OFFSET, pai.baida ? new Laya.Vector4(1, 1, 0, 0) : pai.getTilingOffset()); //百搭牌 
					mat_cartoon_front.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
					
					let mat_cartoon_mid: caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon_Tile_Back.filename);
					mat_cartoon_mid.setTexture(caps.Cartoon_Tile_Back.TEXTURE1, Laya.loader.getRes(back_texture));
					mat_cartoon_mid.setTexture(caps.Cartoon_Tile_Back.TEXTURE2, Laya.loader.getRes(front_texture));
					mat_cartoon_mid.setColor(caps.Cartoon_Tile_Back.TILING_OFFSET, new Laya.Vector4(1,1, 0, 0));
					mat_cartoon_mid.setColor(caps.Cartoon_Tile_Back.TILING_OFFSET_1, pai.baida ? new Laya.Vector4(1, 1, 1, 1) : new Laya.Vector4(0.1,1, 0.9, 0));
					mat_cartoon_mid.setNumber(caps.Cartoon.SPLIT, split);
					mat_cartoon_mid.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
					mat_cartoon_mid.setColor(caps.Cartoon.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
					mat_cartoon_mid.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
					mat_cartoon_mid.setNumber(caps.Cartoon_Alpha.ALPHA, 1);

					mesh.meshRender.sharedMaterials = [mat_cartoon_mid, mat_cartoon_front];
				
				}
			}


			//outline
			{
				let mesh2: Laya.Sprite3D = maque_outline;
				maque.addChild(mesh2);
				mesh2.transform.localPosition = new Laya.Vector3(0, 0, 0);
				mesh2.transform.localScale = new Laya.Vector3(1, 1, 1);
				mesh2.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
				let _mesh: Laya.MeshSprite3D = mesh2 as Laya.MeshSprite3D;
				let _mat: caps.Material_Outline = new caps.Material_Outline(caps.Outline.filename);
				_mat.renderQueue = 2999;
				_mat.setColor(caps.Outline.OUTLINE_COLOR, new Laya.Vector3(0.165, 0.192, 0.204));
				_mat.setNumber(caps.Outline.OUTLINE_ALPHA, 0.6);
				_mat.setNumber(caps.Outline.OUTLINE, 0.0012);
				_mesh.meshRender.sharedMaterial = _mat;
			}
			// 特效container
			let container: Laya.Sprite3D = new Laya.Sprite3D();
			container.name = 'effect';
			container.transform.localPosition = new Laya.Vector3(0, 0, 0);
			container.transform.localScale = new Laya.Vector3(1, 1, 1);
			container.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
			maque.addChild(container);

			// 透明牌其他部分
			if (_touming) {
				let touming: Laya.MeshSprite3D = (this.desktop3D.getChildByName('all').getChildByName('touming') as Laya.MeshSprite3D).clone();
				touming.name = 'touming';
				maque.addChild(touming);
				touming.transform.localPosition = new Laya.Vector3(0, 0, 0.00001);
				touming.transform.localScale = new Laya.Vector3(1, 1, 1);
				touming.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);

				let mat_twosided: caps.BaseMaterial = new caps.Material_TwoSided(caps.TwoSided.filename);

				let index: number = 0;
				switch (pai.type) {
					case mjcore.E_MJPai.m: index = 0; break;
					case mjcore.E_MJPai.p: index = 10; break;
					case mjcore.E_MJPai.s: index = 20; break;
					default: index = 29; break;
				}
				if (!pai.dora) index += pai.index;
				let tilingOffset = pai.getTilingOffset();
				let x: number = tilingOffset.z;
				let y: number = tilingOffset.w;

				let texture_path: string = 'scene/Assets/Resource/mjpai/';
				if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
					texture_path += 'en_kr/';
				}
				texture_path += DesktopMgr.en_mjp ? 'toumingpai_0/mjp.png' : 'toumingpai/mjp.png';
				mat_twosided.setTexture(caps.TwoSided.TEXTURE, Laya.loader.getRes(texture_path));
				mat_twosided.setColor(caps.TwoSided.COLOR, new Laya.Vector3(1, 1, 1));
				mat_twosided.setNumber(caps.TwoSided.OFFSET_X, x);
				mat_twosided.setNumber(caps.TwoSided.OFFSET_Y, y);
				mat_twosided.renderQueue = 3000;
				(touming.getChildByName('twosided') as Laya.MeshSprite3D).meshRender.sharedMaterial = mat_twosided;
				(touming.getChildByName('touying').getChildByName('pai') as Laya.MeshSprite3D).meshRender.sharedMaterial = mat_twosided;
				(touming.getChildByName('touying').getChildByName('bg') as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
			}

			return maque;
		}
		//计算当前玩家指示器旋转
		public RefreshPlayerIndicator(): void {
			for (let i: number = 0; i < 4; i++) {
				this.players[i].trans_ind.active = i == this.seat2LocalPosition(this.index_player);
				this.players[i].RefreshScore(this.mainrole.score);
			}
		}

		public setAutoHule(value: boolean) {
			this.auto_hule = value;
			this._PendingAuto(true);
		}

		public setAutoNoFulu(value: boolean) {
			this.auto_nofulu = value;
			this._PendingAuto(true);
		}

		public setAutoMoQie(value: boolean) {
			this.auto_moqie = value;
			this._PendingAuto(true);
		}

		public setAutoBaBei(value: boolean) {
			this.auto_babei = value;
			this._PendingAuto(true);
		}

		public setAutoLiPai(value: boolean) {
			this.auto_liqi = value;
			if (value) {
				if (this.gameing && this.mainrole) {
					this.mainrole.LiPai(false, false, true);
				}
			}
		}

		public setScoreDelta(showDelta: boolean) {
			for (let i: number = 1; i < 4; i++) {
				this.players[i].duringShowDetla = showDelta;
				this.players[i].RefreshScore(this.mainrole.score);
			}
		}


		//设置场和局的值
		public SetChangJuShow(chang: number, ju: number, chuanma: number): void {
			if (this.is_chuanma_mode()) {
				let chang_offset: Laya.Vector4 = new Laya.Vector4(0.1666, 1, 0, 0);
				if (GameMgr.client_language == 'en') {
					chang_offset = new Laya.Vector4(1, 0.2, 0, -0.8);
				}
				(this.plane_chang.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = chang_offset;
				let ju_offset: Laya.Vector4 = new Laya.Vector4(0.1, 1, chuanma * 0.1, 0);
				(this.plane_ju.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = ju_offset;
			} else {
				let chang_offset: Laya.Vector4 = new Laya.Vector4(0.166, 1, 0.166 + (chang % 4) * 0.166, 0);
				if (GameMgr.client_language == 'en') {
					chang_offset = new Laya.Vector4(1, 0.2, 0, (chang % 4 - 3) * 0.2);
				}
				(this.plane_chang.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = chang_offset;
				(this.plane_chang_reveal.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = chang_offset;
				let ju_offset: Laya.Vector4 = new Laya.Vector4(0.1, 1, ju * 0.1, 0);
				(this.plane_ju.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = ju_offset;
				(this.plane_ju_reveal.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = ju_offset;
			}

		}

		//设置剩余牌数的显示
		public SetLeftPaiShow(n: number): void {
			if (n >= 100) n = 99;
			else if (n < 0) n = 0;
			let nums: Array<number> = [n % 10, Math.floor(n / 10)];
			for (let i: number = 0; i < nums.length; i++) {
				let offset: Laya.Vector4 = new Laya.Vector4(0.1, 1, nums[i] * 0.1, 0);
				(this.num_left_show[i].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = offset;
				(this.num_left_show_reveal[i].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = offset;
			}
		}

		//刷新剩余牌数
		public RefreshPaiLeft(): void {
			this.SetLeftPaiShow(this.left_tile_count);
			if (uiscript.UI_DesktopInfo.Inst && uiscript.UI_DesktopInfo.Inst.enable) {
				uiscript.UI_DesktopInfo.Inst.freshTingCount();
			}
		}

		public Reset(): void {
			app.Log.log('DesktopMgr.Reset');
			this.operation_showing = false;
			this.oplist = [];
			Laya.timer.clearAll(ActionAnGangAddGang);
			Laya.timer.clearAll(ActionChiPengGang);
			Laya.timer.clearAll(ActionDealTile);
			Laya.timer.clearAll(ActionDiscardTile);
			Laya.timer.clearAll(ActionHule);
			Laya.timer.clearAll(ActionHuleXueZhanEnd);
			Laya.timer.clearAll(ActionHuleXueZhanMid);
			Laya.timer.clearAll(ActionLiqi);
			Laya.timer.clearAll(ActionLiuJu);
			Laya.timer.clearAll(ActionNewRound);
			Laya.timer.clearAll(ActionNoTile);
			Laya.timer.clearAll(ActionOperation);
			Laya.timer.clearAll(ActionChangeTile);
			Laya.timer.clearAll(ActionSelectGap);
			Laya.timer.clearAll(ActionGangResult);
			Laya.timer.clearAll(ActionGangResultEnd);
			Laya.timer.clearAll(ActionRevealTile);
			Laya.timer.clearAll(ActionUnveilTile);
			Laya.timer.clearAll(ActionLockTile);
			Laya.timer.clearAll(ActionNewCard);
			Laya.timer.clearAll(ActionFillAwaitingTiles);
			Laya.timer.clearAll(ActionSubmit);
			Laya.timer.clearAll(ActionTake);
			Laya.timer.clearAll(this);
			uiscript.UI_DesktopInfo.Inst.reset_rounds();
			uiscript.UI_Replay.Inst.reset();
			if (this.effect_pai_canchi) {
				this.effect_pai_canchi.destroy();
				this.effect_pai_canchi = null;
			}
			uiscript.UI_TingPai.Inst.setZhengting(false);
			for (let i: number = 0; i < 4; i++) this.players[i].Reset();
			this.tingpais = [[], [], [], []];
			this.md5 = '';
			this.current_step = -1;
			this.muyu_info = null;
			if (this.muyu_effect) {
				this.muyu_effect.root.active = false;
				Laya.timer.clearAll(this.muyu_effect);
			}
			this.mind_voice_seat = -1;
			this.mind_voice_type = '';
			this.during_playing_mind_voice = false;
			if (this.actionList.length >  0) {
				let t: number = this.doactioncd - Laya.timer.currTimer;
				if (t < 0) t = 0;
				this.StartChainAction(t);
			}
			this.ResetSpecialModes();
		}

		public ResetSpecialModes(){
			this.effectBeiShuiFires.forEach((effects) => {
				effects.forEach((effect) => {
					Laya.timer.clearAll(effect);
					effect.root.active = false;
				})
			});
			this.tributeState = 0;
		}

		public setScores(scores: Array<number>): void {
			for (let i: number = 0; i < scores.length; i++) {
				this.players[view.DesktopMgr.Inst.seat2LocalPosition(i)].SetScore(scores[i], scores[this.seat]);
			}
		}

		public _PendingAuto(force: boolean = false): boolean {
			if (this.oplist == null || this.oplist.length == 0) return false;
			try {
				let needshow_chipeng: boolean = false;
				let needshow_zimoangang: boolean = false;
				let needshow_huansanzhang: boolean = false;
				let needshow_dingque: boolean = false;
				let needshow_selecttile: boolean = false;
				let can_rong: boolean = false;
				let can_zimo: boolean = false;
				let can_discard: boolean = false;
				let can_babei: boolean = false;
				let showing: boolean = this.operation_showing;
				this.operation_showing = true;
				let ban_discard_list: Array<string> = null;
				let gap_type = 0;
				this.liqi_select = [];
				let can_anpai_auto_discard = true;
				for (let i: number = 0; i < this.oplist.length; i++) {
					let op_data = this.oplist[i];
					let op_type = op_data['type'];
					switch (op_type) {
						case mjcore.E_PlayOperation.eat:
						case mjcore.E_PlayOperation.peng:
						case mjcore.E_PlayOperation.ming_gang:
						case mjcore.E_PlayOperation.rong:
						case mjcore.E_PlayOperation.unveil:
							needshow_chipeng = true;
							break;
						case mjcore.E_PlayOperation.an_gang:
						case mjcore.E_PlayOperation.add_gang:
						case mjcore.E_PlayOperation.liqi:
						case mjcore.E_PlayOperation.zimo:
						case mjcore.E_PlayOperation.revealliqi:
						case mjcore.E_PlayOperation.reveal:
						case mjcore.E_PlayOperation.locktile:
							needshow_zimoangang = true;
						case mjcore.E_PlayOperation.jiuzhongjiupai:
							needshow_zimoangang = true;
							break;
						case mjcore.E_PlayOperation.huansanzhang:
							needshow_huansanzhang = true;
							break;
						case mjcore.E_PlayOperation.po_tribute_choose_tile:
							needshow_huansanzhang = true;
							break;
						case mjcore.E_PlayOperation.dingque:
							needshow_dingque = true;
							gap_type = op_data['gap_type'];
							break;
						case mjcore.E_PlayOperation.selecttile:
							needshow_selecttile = true;
							break;
						case mjcore.E_PlayOperation.babei:
							can_babei = true;
							break;
					}
					if (op_type == mjcore.E_PlayOperation.dapai) {
						can_discard = true;
						ban_discard_list = this.oplist[i]['combination'];
					} else if (op_type == mjcore.E_PlayOperation.liqi) {
						can_discard = true;
						this.liqi_select = [];
						for (let j: number = 0; j < this.oplist[i]['combination'].length; j++) {
							this.liqi_select.push(mjcore.MJPai.Create(this.oplist[i]['combination'][j]));
						}
					} else if (op_type == mjcore.E_PlayOperation.rong) {
						can_rong = true;
					} else if (op_type == mjcore.E_PlayOperation.zimo) {
						can_zimo = true;
					} else if (op_type == mjcore.E_PlayOperation.huansanzhang || op_type == mjcore.E_PlayOperation.po_tribute_choose_tile) {
						if (!force) {
							let change_tile_states: number[] = op_data['change_tile_states'];
							if (op_type == mjcore.E_PlayOperation.po_tribute_choose_tile) {
								change_tile_states = [];
								if (op_data['change_tiles']) {
									for (let j = 0; j < op_data['change_tiles'].length; j++) {
										change_tile_states.push(0);
									}
								}
							}
							view.DesktopMgr.Inst.mainrole.setHuanSanZhangDefaultTile(op_data['change_tiles'], change_tile_states);
						}
					}
					if (op_type != mjcore.E_PlayOperation.dapai && op_type != mjcore.E_PlayOperation.reveal) {
						can_anpai_auto_discard = false;
					}
				}
				let auto_hule: boolean = this.auto_hule;
				let auto_nofulu: boolean = this.auto_nofulu;
				let auto_moqie: boolean = this.auto_moqie;
				let auto_babei: boolean = this.auto_babei;

				// if (this.hangupCount >= 5) {
				// 	auto_nofulu = true;
				// 	auto_moqie = true;
				// }
				if (this.anpai) {
					if (can_anpai_auto_discard && auto_moqie) {
						if (this.mainrole.trans_liqi.active) {
							app.NetAgent.sendReq2MJ('FastTest', 'inputChiPengGang', {
								cancel_operation: true,
							}, (err, res) => {

							});
							return;
						}
						if (this.mainrole.last_tile != null) {
							this.Action_QiPai(this.mainrole.last_tile.val, true, true, this.mainrole.last_tile.is_open);
							return false;
						}
					}

				}
				if (auto_hule && (can_rong || can_zimo)) {
					Laya.timer.once(800, this, () => {
						if (can_rong) {
							app.NetAgent.sendReq2MJ('FastTest', 'inputChiPengGang', {
								type: mjcore.E_PlayOperation.rong,
								index: 0
							}, (err, res) => {

							});
						} else if (can_zimo) {
							app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
								type: mjcore.E_PlayOperation.zimo,
								index: 0,
							}, (err, res) => {

							});
						}
					});
					this.ClearOperationShow();
					return false;
				}
				if (needshow_dingque) {
					uiscript.UI_Dingque.Inst.show(gap_type);
				} else if (needshow_huansanzhang) {
					if (!force)
						uiscript.UI_HuanSanZhange.Inst.show();
				} else if (needshow_chipeng) {
					if (auto_nofulu && !can_rong && !can_zimo) {
						app.NetAgent.sendReq2MJ('FastTest', 'inputChiPengGang', {
							cancel_operation: true,
						}, (err, res) => {

						});
						this.ClearOperationShow();
						return false;
					} else {
						if (!showing) uiscript.UIMgr.Inst.ShowChipenghu(this.oplist);
					}
				} else {
					if (needshow_zimoangang) {
						if (!showing) uiscript.UIMgr.Inst.ShowLiqiZimo(this.oplist);
					} else if (can_babei) {
						if (auto_babei) {
							let moqie: boolean = false;
							if (this.mainrole.last_tile && this.mainrole.last_tile.val.toString() === '4z') {
								moqie = true;
							}
							app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
								type: mjcore.E_PlayOperation.babei,
								moqie: moqie,
								timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse
							}, (err, res) => {
							});
							this.ClearOperationShow();
							return false;
						} else {
							if (!showing) uiscript.UIMgr.Inst.ShowLiqiZimo(this.oplist);
						}
					}
					if (can_discard) {
						if (auto_moqie) {
							if (!uiscript.UI_LiQiZiMo.Inst.enable) {
								if (this.mainrole.last_tile != null) {
									this.Action_QiPai(this.mainrole.last_tile.val, true, true, this.mainrole.last_tile.is_open);
									return false;
								}
							}
						}
						if (!showing) {
							this.mainrole.can_discard = true;
							if (ban_discard_list && ban_discard_list.length > 0) {
								let list: Array<mjcore.MJPai> = [];
								for (let i: number = 0; i < ban_discard_list.length; i++) {
									list.push(mjcore.MJPai.Create(ban_discard_list[i]));
								}
								this.mainrole.ChiTiSelect(list);
							}
						}
					} else {
						this.mainrole.can_discard = false;
					}
				}
				if (needshow_selecttile) {
					if (auto_moqie) {
						uiscript.UI_Astrology.Inst.selectTile(0);
						return false;
					} else if (!showing) {
						uiscript.UI_Astrology.Inst.showSelections();
					}
				}
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = '_PendingAuto';
				_errorinfo['name'] = 'DesktopMgr';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
			return true;
		}

		//计时超时的回调
		public OperationTimeOut() {
			if (this.oplist == null || this.oplist.length == 0) return;
			let needshow_chipeng: boolean = false;
			let needshow_zimoangang: boolean = false;
			let can_rong: boolean = false;
			let can_zimo: boolean = false;
			let can_discard: boolean = false;
			let showing: boolean = this.operation_showing;
			this.operation_showing = true;
			let ban_discard_list: Array<string> = null;
			// this.hangupCount++;
			// if (this.hangupCount >= 5 && !uiscript.UI_Hangup_Warn.Inst.enable) {
			// 	uiscript.UI_Hangup_Warn.Inst.show();
			// }
			for (let i: number = 0; i < this.oplist.length; i++) {
				switch (this.oplist[i]['type']) {
					case mjcore.E_PlayOperation.eat:
					case mjcore.E_PlayOperation.peng:
					case mjcore.E_PlayOperation.ming_gang:
					case mjcore.E_PlayOperation.rong:
						needshow_chipeng = true;
						break;
					case mjcore.E_PlayOperation.an_gang:
					case mjcore.E_PlayOperation.add_gang:
					case mjcore.E_PlayOperation.liqi:
					case mjcore.E_PlayOperation.zimo:
					case mjcore.E_PlayOperation.babei:
						needshow_zimoangang = true;
						break;
				}

				if (this.oplist[i]['type'] == mjcore.E_PlayOperation.dapai || this.oplist[i]['type'] == mjcore.E_PlayOperation.liqi) {
					can_discard = true;
					if (this.oplist[i]['type'] == mjcore.E_PlayOperation.dapai) {
						ban_discard_list = this.oplist[i]['combination'];
					}
				}
				if (this.oplist[i]['type'] == mjcore.E_PlayOperation.rong) {
					can_rong = true;
				}
				if (this.oplist[i]['type'] == mjcore.E_PlayOperation.zimo) {
					can_zimo = true;
				}
			}
			if (needshow_chipeng) {
				if (can_rong) {
					app.NetAgent.sendReq2MJ('FastTest', 'inputChiPengGang', {
						type: mjcore.E_PlayOperation.rong,
						index: 0,
						timeuse: 1000000,
					}, (err, res) => {

					});
				} else {
					app.NetAgent.sendReq2MJ('FastTest', 'inputChiPengGang', {
						cancel_operation: true,
						timeuse: 1000000,
					}, (err, res) => {

					});
				}

				this.ClearOperationShow();
			} else {
				if (can_zimo) {
					app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
						type: mjcore.E_PlayOperation.zimo,
						index: 0,
						timeuse: 1000000,
					}, (err, res) => {

					});
				} else if (can_discard) {
					if (this.mainrole.during_liqi) {
						let index: number = -1;
						for (let i: number = 0; i < this.mainrole.hand.length; i++) {
							if (this.mainrole.hand[i].valid && !this.mainrole.hand[i].val.baida) { //立直超时了也不能丢百搭牌
								index = i;
								break;
							}
						}
						this.Action_LiQi(this.mainrole.hand[index].val, this.mainrole.hand[index] === this.mainrole.last_tile, this.mainrole.hand[index].is_open);
					} else {
						let tile: mjcore.MJPai = null;
						let moqie: boolean = false;
						let is_open: boolean = false;

						if (tile == null) {
							if (this.mainrole.last_tile && this.mainrole.last_tile.valid && !this.mainrole.last_tile.val.baida) { //打牌超时了也不能丢百搭牌
								tile = this.mainrole.last_tile.val;
								moqie = true;
								is_open = this.mainrole.last_tile.is_open;
							}
						}
						if (tile == null) {
							for (let i: number = this.mainrole.hand.length - 1; i >= 0; i--) {
								if (this.mainrole.hand[i].valid && !this.mainrole.hand[i].val.baida) { //打牌超时了也不能丢百搭牌
									tile = this.mainrole.hand[i].val;
									moqie = false;
									is_open = this.mainrole.hand[i].is_open;
									break;
								}
							}
						}
						this.Action_QiPai(tile, moqie, true, is_open);
					}
				} else if (needshow_zimoangang) {
					app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
						cancel_operation: true,
						timeuse: 1000000,
					}, (err, res) => {

					});
					this.ClearOperationShow();
				}
			}
		}

		public WhenDoOperation() {
			this.hangupCount = 0;
			this.ClearOperationShow();
		}

		public ClearOperationShow() {
			this.operation_showing = false;
			this.oplist = [];
			uiscript.UI_Huleshow.Inst.enable = false;
			uiscript.UIMgr.Inst.CloseLiuJu();
			uiscript.UIMgr.Inst.CloseWin();
			uiscript.UIMgr.Inst.CloseChipenghu();
			uiscript.UIMgr.Inst.CloseLiqiZimo();
			uiscript.UI_Hu_Xuezhan.Inst.enable = false;
			Laya.timer.clearAll(ActionOperation);
			uiscript.UI_ScoreChange.Inst.enable = false;
			this.mainrole.can_discard = false;
			uiscript.UI_DesktopInfo.Inst.closeCountDown();
		}

		// public WhenLiqiInfo(data: any) { //2025.02.25 于：这个函数没有使用过
		// 	if (data) {
		// 		Laya.timer.once(300, this, () => {
		// 			let seat: number = data['seat'];
		// 			let score: number = data['score'];
		// 			this.players[this.seat2LocalPosition(seat)].ShowLiqi();
		// 			this.players[this.seat2LocalPosition(seat)].SetScore(score, this.mainrole.score);
		// 			uiscript.UI_DesktopInfo.Inst.setLiqibang(data['liqibang']);
		// 		});
		// 	}
		// }

		public WhenDoras(data: any, fast: boolean) {
			if (data == null || data == undefined || data.length == 0 || data.length <= this.dora.length) return;
			if (data) {
				let havenew: boolean = false;
				for (let i: number = 0; i < data.length; i++) {
					if (this.dora.length > i) this.dora[i] = mjcore.MJPai.Create(data[i]);
					else this.dora.push(mjcore.MJPai.Create(data[i]));
					uiscript.UI_DesktopInfo.Inst.setDora(i, this.dora[i]);
				}
				Laya.timer.frameOnce(1, this, () => { //不知道为什么 就像延迟一下
					for (let i: number = 0; i < 4; i++) this.players[i].OnDoraRefresh();
				});
				if (!fast) view.AudioMgr.PlayAudio(215);
			}
		}

		//玩家操作：弃牌
		public Action_QiPai(pai: mjcore.MJPai, moqie: boolean, timeout: boolean, is_open: boolean): void {
			app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
				type: mjcore.E_PlayOperation.dapai,
				tile: pai.toString(),
				moqie: moqie,
				timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse,
				tile_state: is_open ? 1 : 0
			}, (err, res) => {
				if (err) {
					app.Log.Error('Action_QiPai 失败');
				} else {
					app.Log.info('Action_QiPai 成功');
					
				}
			});

			if (timeout) {
				this.ClearOperationShow();
			} else {
				this.WhenDoOperation();
			}
		}

		//玩家操作：暗牌弃牌
		public Action_AnPai(pai: mjcore.MJPai, moqie: boolean, timeout: boolean, is_open: boolean): void {
			app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
				type: mjcore.E_PlayOperation.reveal,
				tile: pai.toString(),
				moqie: moqie,
				timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse,
				tile_state: is_open ? 1 : 0
			}, (err, res) => {
				if (err) {
					app.Log.Error('Action_AnPai 失败');
				} else {
					app.Log.info('Action_AnPai 成功');
				}
			});

			if (timeout) {
				this.ClearOperationShow();
			} else {
				this.WhenDoOperation();
			}
		}

		//玩家操作：立直弃牌
		public Action_LiQi(pai: mjcore.MJPai, moqie: boolean, is_open: boolean): boolean {
			if (!this.liqi_select || this.liqi_select.length == 0) return false;
			let isok: boolean = false;
			for (let i: number = 0; i < this.liqi_select.length; i++) {
				if (mjcore.MJPai.Distance(this.liqi_select[i], pai) == 0) {
					isok = true;
					break;
				}
			}
			if (!isok) return false;
			let operateType = mjcore.E_PlayOperation.liqi;
			if (this.is_beishuizhizhan_mode() && this.mainrole.liqiOperation) {
				if (this.mainrole.liqiOperation == mjcore.E_PlayOperation.po_liqi_5000 || this.mainrole.liqiOperation == mjcore.E_PlayOperation.po_liqi_10000) {
					operateType = this.mainrole.liqiOperation;
				}
			}
			app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
				type: operateType,
				tile: pai.toString(),
				moqie: moqie,
				timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse,
				tile_state: is_open ? 1 : 0
			}, (err, res) => {
				if (err) {
					app.Log.Error('Action_LiQi 失败');
				} else {
					app.Log.info('Action_LiQi 成功');
				}
			});
			// this.ClearOperationShow();
			this.WhenDoOperation();
			return true;
		}

		//玩家操作：暗牌立直弃牌
		public Action_AnPaiLiQi(pai: mjcore.MJPai, moqie: boolean, is_open: boolean): boolean {
			if (!this.liqi_select || this.liqi_select.length == 0) return false;
			let isok: boolean = false;
			for (let i: number = 0; i < this.liqi_select.length; i++) {
				if (mjcore.MJPai.Distance(this.liqi_select[i], pai) == 0) {
					isok = true;
					break;
				}
			}
			if (!isok) return false;
			app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
				type: mjcore.E_PlayOperation.revealliqi,
				tile: pai.toString(),
				moqie: moqie,
				timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse,
				tile_state: is_open ? 1 : 0
			}, (err, res) => {
				if (err) {
					app.Log.Error('Action_LiQi 失败');
				} else {
					app.Log.info('Action_LiQi 成功');
				}
			});
			// this.ClearOperationShow();
			this.WhenDoOperation();
			return true;
		}

		// 玩家操作：换三张
		public Action_HuanSanZhange(pais: Array<string>, states: Array<number>) {
			let operateType = this.isTargetSpecialMode(game.EMJGameRule.QiangDuoZhiZhan) ? mjcore.E_PlayOperation.po_tribute_choose_tile : mjcore.E_PlayOperation.huansanzhang;
			app.NetAgent.sendReq2MJ('FastTest', 'inputOperation', {
				type: operateType,
				timeuse: uiscript.UI_DesktopInfo.Inst._timecd.timeuse,
				tile_states: states,
				change_tiles: pais,
			}, (err, res) => {
				if (err) {
					app.Log.Error('Action_HuanSanZhange 失败');
				} else {
					app.Log.info('Action_HuanSanZhange 成功');
				}
			});
			this.WhenDoOperation();
		}

		//最后一次被打出来的牌，如果被主角操作的话就会出现吃碰的特效
		public SetLastQiPai(seat: number, pai: ViewPai): void {
			this.lastqipai = pai;
			this.lastpai_seat = seat;
			if (this.effect_pai_canchi) {
				this.effect_pai_canchi.destroy();
				this.effect_pai_canchi = null;
			}
		}

		private resetPaiEffectList: Array<string> = [ 'scene/ron_23wenquan.lh']; // 胡牌修改层级的部分
		//huleType 1自摸，2胡的是别人的鸣牌，0普通胡牌,3是胡立直失败的牌
		public ShowHuleEffect(pai: HandPai3D | ViewPai, transform: laya.d3.core.Transform3D, item_id: number, seat: number, huleType: number = 0): void {
			if (pai != null && transform != null) {
				let d_view: lqc.Sheet_ItemDefinition_View;
				let outfitConfig: lqc.Sheet_OutfitConfig_Ron = null;
				let audio_id: number = 213;
				let isOldRon = true;
				let path: string = 'scene/effect_hupai_default.lh';
				let fullScreenPath = '';
				//#region 测试代码
				// let path: string = 'scene/ron_25lifu_test.lh';
				// let fullScreenPath = 'scene/ron_25lifu_test_fullscreen.lh';
				// let isOldRon = false;
				//#endregion
				
				if (item_id) {
					d_view = cfg.item_definition.view.get(item_id);
					outfitConfig = cfg.outfit_config.ron.get(item_id);
					if (d_view) {
						path = `scene/${d_view.res_name}.lh`;
						audio_id = d_view.audio_id;
						isOldRon = (d_view.old_effect_mark && d_view.old_effect_mark == 1);
					}
					if (outfitConfig && outfitConfig.is_fullscreen == 1 && !isOldRon) {
						fullScreenPath = `scene/${d_view.res_name}_fullscreen.lh`;
					}
				}
				let pos = transform.position;
				let effect: game.EffectBase = new game.EffectBase(path);
				this.trans_container_effect.addChild(effect.root);
				if (isOldRon) {
					pos.y = 0;
					effect.root.transform.position = pos;
				}
				effect.root.active = true;

				if (path == 'scene/ron_hl.lh') {
					let localPosition = this.seat2LocalPosition(seat);
					if (localPosition == 0) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					} else if (localPosition == 1) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 90, 0);
					} else if (localPosition == 2) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
					} else {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 270, 0);
					}
				} else if (path == 'scene/effect_hupai_yanhua.lh') {
					Laya.timer.once(600, this, () => {
						let _effect: game.EffectBase = new game.EffectBase('scene/effect_hupai_yanhua_bang.lh');
						this.desktop3D.addChild(_effect.root);
						_effect.root.transform.position = new Laya.Vector3(0, 0, 0);
						_effect.root.active = true;
						Laya.timer.once(2000, this, () => {
							_effect.destroy();
						});
					});
				}
				// else if (path == 'scene/ron_22chunjie.lh') {

				// 	let _effect: game.EffectBase = new game.EffectBase('scene/ron_22chunjie_hongdi.lh');
				// 	this.desktop3D.addChild(_effect.root);
				// 	_effect.addLoadedListener(Laya.Handler.create(this, () => {
				// 		let hongdi: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(_effect.root, 'hongdi') as Laya.Sprite3D;

				// 		for (let child of hongdi._childs) {
				// 			(child as Laya.ShuriKenParticle3D).particleRender.material.renderQueue = 3001;
				// 		}

				// 	}));
				// 	_effect.root.transform.position = new Laya.Vector3(0, 0, 0);
				// 	_effect.root.active = true;
				// 	Laya.timer.once(3000, this, () => {
				// 		_effect.destroy();
				// 	});

				// }
				
				let destoryed: boolean = false;
				let parent = pai.model.parent;
				let origin_rotation = pai.model.transform.rotation.clone();
				let worldpos = pai.model.transform.worldMatrix.clone();
				let doPaiAni: boolean = false;
				let doPaiAniNew: boolean = false;
				effect.addLoadedListener(Laya.Handler.create(this, () => {
					if (destoryed) return;
					// 如果牌已经销毁了，则销毁特效
					if (!pai || !pai.model || pai.model.destroyed) {
						effect.destroy();
						return;
					}
					view.AudioMgr.PlayAudio(audio_id);
					if (!isOldRon) {
						if (d_view && d_view.sargs[1]) {
							let depthTestValue = Number(d_view.sargs[1]) == 1 ? 513 : 0;
							game.Tools.changePaiMat(pai.model, 3090, 3089, depthTestValue);
							// game.Tools.dfsChangeParticleMat(effect.root);
						}
						let effectRoot = effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D; //所有胡牌特效分为以下四个部分
						let root_rot: Laya.Sprite3D = effectRoot.getChildByName('root_rot') as Laya.Sprite3D;  //需要控制旋转，和 牌的方向 一致
						let root_move: Laya.Sprite3D = effectRoot.getChildByName('root_move') as Laya.Sprite3D; //动画部分，永远朝向主视角
						let root_static: Laya.Sprite3D = effectRoot.getChildByName('root_static') as Laya.Sprite3D;  //静止部分：例如遮罩黑
						let root_ani: Laya.Sprite3D = effectRoot.getChildByName('root_ani') as Laya.Sprite3D;  //root_ani只要不是抢杠胡就播
						let root_fly: Laya.Sprite3D = effectRoot.getChildByName('root_fly') as Laya.Sprite3D;  //root_fly飞到屏幕
						let _origin_move_rot = root_move.transform.rotation.clone();
						let _origin_pos = transform.worldMatrix.clone();
						let _origin_rotation = transform.rotation.clone();
						root_move.transform.worldMatrix = _origin_pos.clone();
						root_move.transform.rotation = _origin_move_rot.clone();
						root_rot.transform.worldMatrix = _origin_pos.clone();
						root_rot.transform.rotation = _origin_rotation.clone();
						let _ani_zimo: Laya.Sprite3D = effectRoot.getChildByName('root_ani_zimo') as Laya.Sprite3D;  //root_ani_zimo只有自摸胡才播
						let haveSpecialAni = (root_ani && root_ani.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator)
							|| (_ani_zimo && _ani_zimo.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
						let doAnim = haveSpecialAni && (huleType == 1 || (huleType == 0 && !!root_ani)) //自摸胡或者非抢杠胡就播
						if (doAnim) { //有特殊牌动画的特效，特别特别特别少
							app.Log.log('胡牌特效有牌动画  huleType === ' + huleType);
							doPaiAniNew = true;
							pai.model.active = false;
							let paiTemp = DesktopMgr.Inst.CreatePai3D(pai.val);
							paiTemp.active = true;
							root_ani.transform.position = transform.position.clone();
							(root_ani.getChildAt(0) as Laya.Sprite).destroyChildren();
							(root_ani.getChildAt(0) as Laya.Sprite).addChild(paiTemp);
							paiTemp.transform.position = transform.position.clone();
							paiTemp.transform.rotation = transform.rotation.clone();
						} else {
							if (huleType == 3) {//立直失败牌会转，特效跟着牌转
								Laya.timer.frameLoop(1, effect, () => {
									if (pai && pai.model && !pai.model.destroyed && !effect.destroyed) {
										root_rot.transform.worldMatrix = pai.model.transform.worldMatrix.clone();
									} else {
										Laya.timer.clearAll(effect);
									}
								});
							}
						}
						if (root_fly) {
							let flyMove = root_fly.getChildByName('move') as Laya.Sprite3D;
							let flyPosition = root_fly.getChildByName('positon') as Laya.Sprite3D;
							let cameraAreaPos: Laya.Vector3;
							let delay: number;
							let duration: number;
							//特判起来了
							if (d_view.res_name == 'ron_25yh') {
								cameraAreaPos = new Laya.Vector3(0.04959141, -0.04958072, -0.2411938);
								delay = 50 * 1 / 60 * 1000;
								duration = 15 * 1 / 60 * 1000;
							}
							if (!cameraAreaPos) return;
							let targetPos = this.convertCameraToWorld(cameraAreaPos);
							if (flyMove) {
								flyMove.transform.position = transform.position.clone();
								let effectMovement: game.CardMovement = flyMove.getComponentByType(game.CardMovement) as game.CardMovement;
								if (!effectMovement) {
									effectMovement = flyMove.addComponent(game.CardMovement) as game.CardMovement;
								}
								effectMovement.clear();
								let movement = game.Movement.getMovement();
								movement.delay = delay;
								movement.duration = duration;
								movement.targetPosition = targetPos;
								effectMovement.addMovement(movement);
								effectMovement.startMove();
							}
							if (flyPosition) {
								flyPosition.transform.position = targetPos;
							}
						}
						return;
					}
					let root_pai_anim: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'pai') as Laya.Sprite3D;

					if (root_pai_anim && huleType == 1) {
						doPaiAni = true;
						root_pai_anim.destroyChildren();
						root_pai_anim.addChild(pai.model);
						// 清楚所有其他计时器
						if (pai['ResetAllTimer']) {
							pai['ResetAllTimer']();
						}
						pai.model.transform.rotation = origin_rotation.clone();
						pai.model.transform.worldMatrix = worldpos.clone();

						Laya.timer.once(1800, this, () => {
							if (destoryed) return;

							// let _origin_rotation = pai.model.transform.rotation.clone();
							// let _worldpos = pai.model.transform.worldMatrix.clone();
							parent.addChild(pai.model);
							pai.model.transform.rotation = origin_rotation.clone();
							pai.model.transform.worldMatrix = worldpos.clone();
						});
					}

					let root_pai_anim1: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'pai_anim') as Laya.Sprite3D;
					if (root_pai_anim1 && (huleType == 1 || huleType == 0)) {
						doPaiAni = true;
						root_pai_anim1.destroyChildren();
						root_pai_anim1.addChild(pai.model);
						// 清楚所有其他计时器
						if (pai['ResetAllTimer']) {
							pai['ResetAllTimer']();
						}
						pai.model.transform.rotation = origin_rotation.clone();
						pai.model.transform.worldMatrix = worldpos.clone();
						Laya.timer.once(1800, this, () => {
							if (destoryed) return;
							// let _origin_rotation = pai.model.transform.rotation.clone();
							// let _worldpos = pai.model.transform.worldMatrix.clone();
							parent.addChild(pai.model);
							pai.model.transform.rotation = origin_rotation.clone();
							pai.model.transform.worldMatrix = worldpos.clone();
						});
					}
					this.setSpecialHuleEffect(path, effect, pai, seat, huleType);
				}));
				let fullScreenEffect: game.EffectBase = null;
				//显示全屏特效
				if (fullScreenPath != '') {
					fullScreenEffect = new game.EffectBase(fullScreenPath);
					this.trans_container_fullscreeen_effect.addChild(fullScreenEffect.root);
					fullScreenEffect.root.active = true;
					fullScreenEffect.addLoadedListener(Laya.Handler.create(this, () => {
						if (destoryed) return;
						if (d_view.res_name == 'ron_liyang') {
							let worldPos = pai.model.transform.position.clone();
							let out = new Laya.Vector3();
							this.mainCamera.worldToViewportPoint(worldPos, out);
							// app.Log.log("屏幕坐标:  " + out.x + '  ' + out.y);
							let effectMiddle = new Laya.Point(960, 425);
							let distance = new Laya.Point(0, 0);
							if (out.x > 1160 || out.x < 660) {
								distance.x = out.x - effectMiddle.x;
							}
							if (out.y > 800 || out.y < 400) {
								distance.y = out.y - effectMiddle.y;
							}
							// app.Log.log("超出距离:  " + distance.x + '  ' + distance.y);
							let newPos = new Laya.Vector3(0, 0, 0);
							if (distance.x != 0) {
								let sign = distance.x > 0 ? 1 : -1;
								let disX = Math.abs(distance.x);
								let ratio = (disX - 200);
								if (sign < 0) {
									newPos.x = sign * (ratio * 0.2 / 960);
								}
								else {
									newPos.x = sign * (ratio * 0.3 / 960);
								}
							}
							if (distance.y != 0) {
								let sign = distance.y > 0 ? 1 : -1;
								let disY = Math.abs(distance.y);
								if (sign < 0) {
									let ratio = (disY - 25);
									newPos.y = ratio * 0.11 / 425;
									newPos.z = ratio * -0.102 / 425;
								}
								else {
									let ratio = (disY - 375);
									newPos.y = ratio * -0.07 / 655;
									newPos.z = ratio * 0.0649 / 655;
								}
							}
							let com = fullScreenEffect.root.getChildAt(0).getChildAt(0).getChildByName('root_static').getChildByName('47').getChildByName('posi') as Laya.Sprite3D;
							// app.Log.log("newPos: " + newPos.x + '  ' + newPos.y + '  ' + newPos.z);
							com.transform.localPosition = newPos;
						}
					}));
				}

				//特效销毁延迟
				let delay = 2000;
				//牌层级重置延迟
				let queueChangeDelay = delay;
				let hupaiViewData = cfg.item_definition.view.get(item_id);
				if (hupaiViewData && hupaiViewData.sargs[0]) { 
					delay += Number(hupaiViewData.sargs[0]);
					//如果是麻将在特效和其他所有牌上层sargs[1] == 2且有单独的时间配置，则使用单独的时间配置，否则延迟时间按照销毁时间执行
					if (Number(hupaiViewData.sargs[1]) == 2 && outfitConfig.queue_change_delay) {
						queueChangeDelay = outfitConfig.queue_change_delay;
					} else {
						queueChangeDelay = delay;
					}
				}

				//重置牌的渲染层级
				Laya.timer.once(queueChangeDelay, this, () => {
					if (pai && pai.model && pai.model.transform) {
						// 重置胡牌renderqueue
						if (this.resetPaiEffectList.indexOf(path) != -1 || (d_view && d_view.sargs[1])) {
							game.Tools.changePaiMat(pai.model, 2000, 3001, 513);
						}
					}
				})

				//销毁特效
				Laya.timer.once(delay, this, () => {
					destoryed = true;
					if (pai && pai.model && pai.model.transform) {
						// 重置胡牌renderqueue
						// if (this.resetPaiEffectList.indexOf(path) != -1 || (d_view && d_view.sargs[1])) {
						// 	game.Tools.changePaiMat(pai.model, 2000, 3001, 513);
						// }
						if (doPaiAni) {
							parent.addChild(pai.model);
							pai.model.transform.rotation = origin_rotation.clone();
							pai.model.transform.worldMatrix = worldpos.clone();
						}
						if (doPaiAniNew) {
							pai.model.active = true;
						}
					}
					Laya.timer.clearAll(effect);
					effect.destroy();
					//销毁全屏特效
					if (fullScreenEffect) {
						Laya.timer.clearAll(fullScreenEffect);
						fullScreenEffect.destroy();
					}
					
				});
			}

		}

		// 特殊胡牌特效
		private setSpecialHuleEffect(path: string, effect: game.EffectBase, pai: { model: Laya.Sprite3D }, seat: number, huleType: number) {
			// if (path == 'scene/ron_llx.lh') {
			// 	Laya.timer.once(1800, this, () => {
			// 		game.Tools.changePaiMat(pai.model, 3003, 3002, 513);
			// 	});
			// 	let global: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'global') as Laya.Sprite3D;
			// 	global.transform.rotation = new Laya.Quaternion(0, 0, 0, 1);
			// 	global.transform.position = new Laya.Vector3(0, 0, 0);
			// 	let _delay: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'local') as Laya.Sprite3D;
			// 	_delay.active = false;
			// 	Laya.timer.once(2000, this, ()=>{
			// 		if (_delay && !_delay.destroyed) {
			// 			for(let i = 1; i < 4; i++) {
			// 				let child = _delay.getChildAt(0).getChildAt(i) as Laya.Sprite3D;
			// 				for (let _child of child._childs) {
			// 					if (_child._childs && _child._childs.length) {
			// 						for (let __child of _child._childs) {
			// 							(__child as Laya.ShuriKenParticle3D).particleRender.material.depthTest = 0;
			// 						}
			// 					} else {
			// 						(_child as Laya.ShuriKenParticle3D).particleRender.material.depthTest = 0;
			// 					}
			// 				}
			// 			}
			// 			_delay.active = true;
			// 		}
			// 	})
			// }
			// if (path == 'scene/ron_akagi.lh') {
			// 	let heidi: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'heidi') as Laya.Sprite3D;
			// 	heidi.transform.position = new Laya.Vector3(0, 0.101, 0.718);
			// }
			if (path == 'scene/ron_22summer.lh') {
				// 设置yazi层级
				let yazi: Laya.MeshSprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'ya02') as Laya.MeshSprite3D;
				yazi.meshRender.material.depthWrite = true;
				yazi.meshRender.material.depthTest = 0;
				yazi.meshRender.material.renderQueue = 3005;
				
				
				(yazi.meshRender.material as Laya.StandardMaterial).disableLight();
			}

			// if (path == 'scene/ron_beiyuan.lh') {
			// 	let global: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'global') as Laya.Sprite3D;
			// 	global.transform.rotation = new Laya.Quaternion(0, 0, 0, 1);
			// 	global.transform.position = new Laya.Vector3(0, 0, 0);

			// 	let plane = game.Tools.GetNodeByNameInChildren(effect.root, 'plane1X1') as Laya.MeshSprite3D;
			// 	(plane.meshRender.material as Laya.StandardMaterial).disableLight();
			// 	(plane.meshRender.material as Laya.StandardMaterial).renderQueue = 3002;

			// 	let shiziguang = game.Tools.GetNodeByNameInChildren(effect.root, 'shiziguang02') as Laya.ShuriKenParticle3D;
			// 	shiziguang.particleRender.material.depthTest = 0;
			// 	shiziguang.particleRender.material.renderQueue = 3003;
			// 	for (let i = 0; i < shiziguang._childs.length; i++) {
			// 		(shiziguang.getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material.depthTest = 0;
			// 		(shiziguang.getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material.renderQueue = 3003;

			// 	}
			// 	let particle = game.Tools.GetNodeByNameInChildren(effect.root, 'suipian') as Laya.ShuriKenParticle3D;
			// 	particle.particleRender.material.depthTest = 0;
			// 	particle.particleRender.material.renderQueue = 3003;
			// 	particle = game.Tools.GetNodeByNameInChildren(effect.root, 'xuehua01') as Laya.ShuriKenParticle3D;
			// 	particle.particleRender.material.depthTest = 0;
			// 	particle.particleRender.material.renderQueue = 3003;
			// 	particle = game.Tools.GetNodeByNameInChildren(effect.root, 'xuehua02') as Laya.ShuriKenParticle3D;
			// 	particle.particleRender.material.depthTest = 0;
			// 	particle.particleRender.material.renderQueue = 3003;
			// 	particle = game.Tools.GetNodeByNameInChildren(effect.root, 'suipian01') as Laya.ShuriKenParticle3D;
			// 	particle.particleRender.material.depthTest = 0;
			// 	particle.particleRender.material.renderQueue = 3003;
			// }
			if (path == 'scene/ron_23wenquan.lh') {
				game.Tools.changePaiMat(pai.model, 3003, 3002, 513);

				let di = game.Tools.GetNodeByNameInChildren(effect.root, 'chilun') as Laya.MeshSprite3D;
				let dfsChangeMat = (root: Laya.Sprite3D)=> {
				
					if (root._childs && root._childs.length > 0) {
						for (let child of root._childs) {
							dfsChangeMat(child);
						}
						
					}
					
					if ((root as Laya.ShuriKenParticle3D).particleRender) {
						if ((root as Laya.ShuriKenParticle3D).particleRender.material.renderQueue > 3000) {
							(root as Laya.ShuriKenParticle3D).particleRender.material.depthTest = 0;
						}
						
						// (root as Laya.ShuriKenParticle3D).particleRender.material.renderQueue = (root.name == 'bao' || root.name == 'bao01') ? 3005:3002;
					}
				}
				dfsChangeMat(di);
			}
			// if (path == 'scene/ron_xiyuansi.lh') {
			// 	Laya.timer.once(1800, this, () => {
			// 		game.Tools.changePaiMat(pai.model, 3003, 3002, 513);
			// 	});
			// 	let plane = game.Tools.GetNodeByNameInChildren(effect.root, 'plane1X1') as Laya.MeshSprite3D;
			// 	(plane.meshRender.material as Laya.StandardMaterial).disableLight();
			// 	(plane.meshRender.material as Laya.StandardMaterial).renderQueue = 3002;
			// 	let image = game.LoadMgr.getResImage('extendRes/charactor/xiyuansiyiyu_0/full.png');
			// 	if (image) {
			// 		image.active();
			// 	}
			// 	(plane.meshRender.material as Laya.StandardMaterial).diffuseTexture = Laya.Texture2D.load(game.LoadMgr.getResImageSkin('extendRes/charactor/xiyuansiyiyu_0/full.png'));//Laya.Texture2D.load(url);	
			// 	let lizi: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'lizi') as Laya.Sprite3D;
			// 	for (let i = 0; i < lizi.numChildren; i++) {
			// 		((lizi.getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material).renderQueue = 3002;
			// 		((lizi.getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material).depthTest = 0;
			// 	}
			// 	let global: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'global') as Laya.Sprite3D;
			// 	global.transform.rotation = new Laya.Quaternion(0, 0, 0, 1);
			// 	global.transform.position = new Laya.Vector3(0, 0, 0);
			// 	for (let i = 0; i < 3; i++) {
			// 		((global.getChildByName('heidi01').getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material).renderQueue = 3002;
			// 	}
			// 	for (let i = 0; i < 3; i++) {
			// 		((global.getChildByName('daoguang').getChildByName('lizi').getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material).renderQueue = 3002;
			// 	}
			// 	((global.getChildByName('baodian').getChildByName('shiziguang02') as Laya.ShuriKenParticle3D).particleRender.material).renderQueue = 3002;
			// 	for (let i = 0; i < 4; i++) {
			// 		((global.getChildByName('baodian').getChildByName('shiziguang02').getChildAt(i) as Laya.ShuriKenParticle3D).particleRender.material).renderQueue = 3002;
			// 	}
			// 	for (let i = 4; i < 8; i++) {
			// 		let mat = ((global.getChildByName('quxian_amin01').getChildAt(i) as Laya.MeshSprite3D).meshRender.material as Laya.StandardMaterial);
			// 		mat.renderQueue = 3002;
			// 		mat.disableLight();
			// 	}

			// }
			// if (path == 'scene/ron_dongcheng.lh') {
			// 	// game.Tools.changePaiMat(pai.model, 3003, 3002, 0);

			// 	let global: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'budong') as Laya.Sprite3D;
			// 	global.transform.rotation = new Laya.Quaternion(0, 0, 0, 1);
			// 	global.transform.position = new Laya.Vector3(0, 0, 0);
			// 	// let lizi = global.getChildByName('eff').getChildByName('lizi') as Laya.Sprite3D;
			// 	// for (let child of lizi._childs) {
			// 	// 	child as Laya.ShuriKenParticle3D;
			// 	// 	child.particleRender.material.renderQueue = 3004;
			// 	// 	child.particleRender.material.depthTest = 0;
			// 	// }

			// 	// let hepai_lizi = global.getChildByName('eff').getChildByName('hepai').getChildByName('lizi01') as Laya.ShuriKenParticle3D;
			// 	// hepai_lizi.particleRender.material.renderQueue = 3002;
			// 	// hepai_lizi.particleRender.material.depthTest = 0;
			// 	// for (let child of hepai_lizi._childs) {
			// 	// 	child as Laya.ShuriKenParticle3D;
			// 	// 	child.particleRender.material.renderQueue = 3002;
			// 	// 	child.particleRender.material.depthTest = 0;
			// 	// }
			// 	let guangyun: Laya.ShuriKenParticle3D = game.Tools.GetNodeByNameInChildren(effect.root, 'guangyun') as Laya.ShuriKenParticle3D;
			// 	guangyun.particleRender.material.renderQueue = 3002;
			// 	guangyun.particleRender.material.depthTest = 0;
			// 	let localPosition = this.seat2LocalPosition(seat);
			// 	let dong: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'dong') as Laya.Sprite3D;
			// 	dong.transform.localRotationEuler = new Laya.Vector3(0, 90 * localPosition, 0);
			// 	let lizi = dong.getChildByName('eff').getChildByName('lizi') as Laya.Sprite3D;

			// 	let rot = pai.model.transform.localRotationEuler;
			// 	lizi.transform.localRotationEuler = new Laya.Vector3(0, -rot.y, 0);
			// }

			// if (path == 'scene/ron_nanfenghua.lh') {
			// 	game.Tools.changePaiMat(pai.model, 3053, 3052, 513);
			// 	game.Tools.dfsChangeParticleMat(effect.root);
			// 	let nanfenghuaBg: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'budong') as Laya.Sprite3D;
			// 	nanfenghuaBg.transform.position = new Laya.Vector3(0, 0, 0);
			// 	// let nanfenghuaBg1: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, '001') as Laya.Sprite3D;
			// 	// nanfenghuaBg1.transform.position = new Laya.Vector3(0, 0, 0);
			// 	// let nanfenghuaBg2: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'fx') as Laya.Sprite3D;
			// 	// nanfenghuaBg2.transform.position = new Laya.Vector3(0, 0, 0);
			// 	// let localPosition = this.seat2LocalPosition(seat);
			// 	let dong: Laya.Sprite3D = nanfenghuaBg.parent.getChildByName('002').getChildByName('glow2') as Laya.Sprite3D;
			// 	let localPosition = this.seat2LocalPosition(seat);
			// 	dong.transform.localRotationEuler = new Laya.Vector3(0, localPosition * 90 + pai.model.transform.localRotationEuler.y,);
			// }

			if (path == 'scene/ron_yly.lh') {
				let root = effect.root;
				game.Tools.dfsChangeParticleMat(root);
			}
			if (path == 'scene/ron_24chunjie.lh') {
				let localPosition = this.seat2LocalPosition(seat);
				let guangkuang: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'guangkuang') as Laya.Sprite3D;
				guangkuang.transform.localRotationEuler = new Laya.Vector3(0, 0, 90*localPosition + 90);
			}
		}

		/**
		 * 显示maka鸣牌的特效
		 */
		public ShowMakaChiPengEffect(): void {
			if (this.lastqipai.model && this.lastqipai.model.transform) {
				if (!this.effect_pai_canchi_maka) {
					this.effect_pai_canchi_maka = new game.EffectBase('scene/effect_skill_pp_mpts.lh');
					this.trans_container_effect.addChild(this.effect_pai_canchi_maka.root);
					this.effect_pai_canchi_maka.root.active = true;
					
				}
				this.effect_pai_canchi_maka.root.transform.worldMatrix = this.lastqipai.model.transform.worldMatrix.clone();
				let effect = this.effect_pai_canchi_maka;
				let pai = this.lastqipai;
				if (this.lastqipai.revealState == ERevealState.reveal) {
					let pos = this.effect_pai_canchi_maka.root.transform.localPosition.clone();
					pos.y -= PAIMODEL_THICKNESS;
					this.effect_pai_canchi_maka.root.transform.localPosition = pos;
				}

				Laya.timer.frameLoop(1, this.effect_pai_canchi_maka, () => {
					if (pai.model.activeInHierarchy && pai.model.active && (pai.model.parent as Laya.Sprite3D).active) {
						effect.root.transform.worldMatrix = pai.model.transform.worldMatrix.clone();
						if (pai.revealState == ERevealState.reveal) {
							let pos = effect.root.transform.localPosition.clone();
							pos.y -= PAIMODEL_THICKNESS;
							effect.root.transform.localPosition = pos;

						}
						this.effect_pai_canchi_maka.root.active = true;
					} else {
						this.effect_pai_canchi_maka.root.active = false;
					}
				});
			}
		}

		/**
		 * 关闭maka鸣牌的特效
		 */
		public CloseMakaChiPengEffect(): void {
			if (this.effect_pai_canchi_maka) {
				Laya.timer.clearAll(this.effect_pai_canchi_maka);
				this.effect_pai_canchi_maka.destroy();
				this.effect_pai_canchi_maka = null;
			}
		}



		//打开吃碰的特效
		public ShowChiPengEffect(): void {
			if (this.lastqipai.model && this.lastqipai.model.transform) {
				if (!this.effect_pai_canchi) {
					this.effect_pai_canchi = new game.EffectBase('scene/' + game.GameUtility.get_view_res_name(game.EView.mingpai_zhishi) + '.lh');
					this.trans_container_effect.addChild(this.effect_pai_canchi.root);
					this.effect_pai_canchi.root.active = true;
				}
				this.effect_pai_canchi.root.transform.worldMatrix = this.lastqipai.model.transform.worldMatrix.clone();
				let effect = this.effect_pai_canchi;
				let pai = this.lastqipai;
				if (this.lastqipai.revealState == ERevealState.reveal) {
					let pos = this.effect_pai_canchi.root.transform.localPosition.clone();
					pos.y -= PAIMODEL_THICKNESS;
					this.effect_pai_canchi.root.transform.localPosition = pos;
				}

				Laya.timer.frameLoop(1, this.effect_pai_canchi, () => {
					if (pai.model.activeInHierarchy && pai.model.active && (pai.model.parent as Laya.Sprite3D).active) {
						effect.root.transform.worldMatrix = pai.model.transform.worldMatrix.clone();
						if (pai.revealState == ERevealState.reveal) {
							let pos = effect.root.transform.localPosition.clone();
							pos.y -= PAIMODEL_THICKNESS;
							effect.root.transform.localPosition = pos;

						}
						this.effect_pai_canchi.root.active = true;
					} else {
						this.effect_pai_canchi.root.active = false;
					}
				});
			}
		}

		//关闭吃碰的特效
		public CloseChiPngEffect(): void {
			if (this.effect_pai_canchi) {
				Laya.timer.clearAll(this.effect_pai_canchi);
				this.effect_pai_canchi.destroy();
				this.effect_pai_canchi = null;
			}
		}

		public setChoosedPai(pai: mjcore.MJPai): void {
			let diff: boolean = false;
			if (!diff && pai && !this.choosed_pai) diff = true;
			if (!diff && !pai && this.choosed_pai) diff = true;
			if (!diff && pai && this.choosed_pai && mjcore.MJPai.Distance(this.choosed_pai, pai) != 0) diff = true;
			if (diff) {
				this.choosed_pai = pai ? pai.Clone() : null;
				if (DesktopMgr.bianjietishi) {
					for (let i: number = 0; i < 4; i++) this.players[i].OnChoosePai();
					uiscript.UI_TingPai.Inst.onChooseTile(pai);
				}
			}
		}

		//提示听牌
		public setTingpai(seat: number, _tingpais: Array<Object>) {
			
			let haveChange: boolean = false;
			let tingpais: Array<mjcore.MJPai> = [];
			let tingCount: number = 0;
			for (let i: number = 0; i < _tingpais.length; i++) {
				let pai: mjcore.MJPai = mjcore.MJPai.Create(_tingpais[i]['tile']);
				//如果显示了他人手牌
				tingCount += this.getPaiLeft(pai,this.record_show_hand);
				tingpais.push(pai);
			}
			if (this.tingpais[seat].length != tingpais.length) haveChange = true;
			for (let i: number = 0; i < tingpais.length && !haveChange; i++) {
				if (mjcore.MJPai.Distance(tingpais[i], this.tingpais[seat][i]) != 0) {
					haveChange = true;
				}
			}				
			if (haveChange) {
				//显示听牌提示
				let pos = this.seat2LocalPosition(seat);
				uiscript.UI_DesktopInfo.Inst.onSetTingPai(pos,tingpais, tingCount);
				this.tingpais[seat] = tingpais;
				this.refreshPaopai();
			}

			uiscript.UI_DesktopInfo.Inst.freshTingCount();
			
		}

		//牌谱判断炮牌
		public isPaoPai(pai: mjcore.MJPai): boolean {
			if (!this.record_show_paopai) return false;
			for (let i: number = 0; i < this.tingpais.length; i++) {
				for (let j: number = 0; j < this.tingpais[i].length; j++) {
					if (mjcore.MJPai.Distance(this.tingpais[i][j], pai) == 0) {
						return true;
					}
				}
			}
			return false;
		}

		public getPaiLeft(pai: mjcore.MJPai,knowOthers:boolean = false): number {
			let _num: number = 0;
			if (this.players) {
				for (let i: number = 0; i < 4; i++) {
					let p: ViewPlayer = this.players[i];
					if (!p) {
						continue;
					}
					for (let j: number = 0; j < p.container_babei.pais.length; j++) {
						if (mjcore.MJPai.Distance(p.container_babei.pais[j].val, pai) == 0) {
							_num++;
						}
					}
					for (let j: number = 0; j < p.container_ming.pais.length; j++) {
						if (mjcore.MJPai.Distance(p.container_ming.pais[j].val, pai) == 0) {
							_num++;
						}
					}
					for (let j: number = 0; j < p.container_qipai.pais.length; j++) {
						if (p.container_qipai.pais[j].revealState != ERevealState.reveal && mjcore.MJPai.Distance(p.container_qipai.pais[j].val, pai) == 0) {
							_num++;
						}
					}
					if (p.container_qipai.last_pai && p.container_qipai.last_pai.revealState != ERevealState.reveal) {
						if (mjcore.MJPai.Distance(p.container_qipai.last_pai.val, pai) == 0) {
							_num++;
						}
					}

					if (p.pai_xuezhan_mid_zimo) {
						if (mjcore.MJPai.Distance(p.pai_xuezhan_mid_zimo, pai) == 0) {
							_num++;
						}
					}
					let isMainRole = i == 0;
					if (knowOthers) {
						let me = p as ViewPlayer_Me;
						if (me.hand) {
							for (let i: number = 0; i < me.hand.length; i++) {
								if (mjcore.MJPai.Distance(me.hand[i].val, pai) == 0) {
									_num++;
								}
							}
						}
					} else {
						if (isMainRole) {
							let me = p as ViewPlayer_Me;
							if (me.hand) {
								for (let i: number = 0; i < me.hand.length; i++) {
									if (mjcore.MJPai.Distance(me.hand[i].val, pai) == 0) {
										_num++;
									}
								}
							}
						} else {
							let other = p as ViewPlayer_Other;
							if (other.hand) {
								for (let i: number = 0; i < other.hand.length; i++) {
									//如果是天命之战，会有4张公开牌，公开牌也需要减去
									//如果是明镜之战，会有透明牌
									if (other.hand[i].val.touming && mjcore.MJPai.Distance(other.hand[i].pai3D.val, pai) == 0) {
										_num++;
									}
								}
							}
						}
					}

				}
			}
			
			if (this.dora) {
				for (let i: number = 0; i < this.dora.length; i++) {
					if (this.dora[i] && mjcore.MJPai.Distance(this.dora[i], pai) == 0) {
						_num++;
					}
				}
			}
			let n = 4 - _num;
			return n < 0 ? 0 : n > 4 ? 4 : n;
		}

		//当前杠了多少次
		public get_gang_count(): number {
			let count: number = 0;
			for (let i: number = 0; i < this.players.length; i++) {
				let seat = this.localPosition2Seat(i);
				if (seat >= 0) {
					let lst = this.players[i].container_ming.mings;
					for (let j: number = 0; j < lst.length; j++) {
						if (lst[j].type == mjcore.E_Ming.gang_an || lst[j].type == mjcore.E_Ming.gang_ming) {
							count++;
						}
					}
				}
			}
			return count;
		}

		//当前拔北多少次
		public get_babei_count(): number {
			let count: number = 0;
			for (let i: number = 0; i < this.players.length; i++) {
				let seat = this.localPosition2Seat(i);
				if (seat >= 0) {
					count += this.players[i].container_babei.pais.length;
				}
			}
			return count;
		}

		public fetchLinks() {
			app.NetAgent.sendReq2MJ('FastTest', 'fetchGamePlayerState', {}, (err, res) => {
				if (err || res['error']) {
					uiscript.UIMgr.Inst.showNetReqError('fetchGamePlayerState', err, res);
				} else {
					app.Log.log(JSON.stringify(res));
					DesktopMgr.player_link_state = [];
					for (let i: number = 0; i < res['state_list'].length; i++) {
						DesktopMgr.player_link_state.push(res['state_list'][i]);
					}
					uiscript.UI_DesktopInfo.Inst.refreshLinks();
				}
			});
		}

		public onShowHandChange(v: boolean) {
			this.record_show_hand = v;
			if (!this.gameing) return;
			for (let i: number = 1; i < 4; i++) {
				(this.players[i] as ViewPlayer_Other).onShowHandChange(v);
			}
		}

		public onShowPaopaiChange(v: boolean) {
			this.record_show_paopai = v;
			if (!this.gameing) return;
			// this.mainrole.onShowPaopaiChange();
			// for (let i: number = 1; i < 4; i++) {
			// 	(this.players[i] as ViewPlayer_Other).onShowPaopaiChange();
			// }
			this.refreshPaopai();
			
		}

		/**
		 * 从浏览器加载是否需要显示听牌提示
		 */
		public loadLiveShowTing() {
			this.isShowTingTip = Laya.LocalStorage.getItem('recordShowTing') == '1';
		}

		public setLiveShowTing(isOpen: boolean) {
			Laya.LocalStorage.setItem('recordShowTing', isOpen ? '1' : '0');
			this.isShowTingTip = isOpen;
		}

		// result: 0-点炮或被自摸，1-胡牌，2-流局
		public onRoundEnd(seat: number, result: number) {
			let localpoition: number = view.DesktopMgr.Inst.seat2LocalPosition(seat);
			this.players[localpoition].OnRoundEnd(result);
		}

		public onMuyuChange(info: iMuYuInfo, doanim: boolean = true) {
			if (!this.is_muyu_mode()) return;
			let change_seat: boolean = false;
			if (!this.muyu_info || this.muyu_info.id != info.id) change_seat = true;
			// Laya.timer.clearAll(this.muyu_effect);
			// console.log(`muyu seat:${this.seat2LocalPosition(info.seat)}, count:${info.count}/${info.count_max}, id:${info.id}`);
			if (!this.muyu_effect || this.muyu_effect.destroyed) return;

			if (!doanim) {
				this.muyu_info = info;
				let player_seat: number = this.seat2LocalPosition(this.muyu_info.seat);
				this.muyu_effect.root.active = true;
				this.muyu_effect.root.transform.worldMatrix = this.players[player_seat].trans_muyu.transform.worldMatrix;
				this.muyu_effect.root.transform.rotation = this.players[player_seat].trans_muyu.transform.rotation.clone();
				this.muyu_effect.root.active = true;
				(this.muyu_effect.effect_root.getChildByName('muyu_xiaoshi') as Laya.Sprite3D).active = false;
				let container_chuxian: Laya.Sprite3D = this.muyu_effect.effect_root.getChildByName('muyu_chuxian') as Laya.Sprite3D;
				container_chuxian.active = true;
				(container_chuxian.getChildByName('baodian') as Laya.Sprite3D).active = false;
				let container_mianpian: Laya.Sprite3D = container_chuxian.getChildByName('mianpian') as Laya.Sprite3D;
				container_mianpian.active = true;
				(container_mianpian.getChildByName('shuzi_anim') as Laya.Sprite3D).active = false;
				let s_shuzi: Laya.MeshSprite3D = container_mianpian.getChildByName('shuzi') as Laya.MeshSprite3D;
				s_shuzi.active = true;
				let mat: Laya.BlinnPhongMaterial = s_shuzi.meshRender.material as Laya.BlinnPhongMaterial;
				mat.renderQueue = 3001;
				mat.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${info.count}.png`);
			} else {
				if (change_seat) {
					let effect_new: game.EffectBase;
					let effect_old: game.EffectBase;
					if (this.muyu_info) {
						effect_new = this.muyu_effect.clone();
						this.muyu_effect.root.parent.addChild(effect_new.root);
						effect_old = this.muyu_effect;
						this.muyu_effect = effect_new;
					} else {
						effect_new = this.muyu_effect;
					}

					// 老特效
					if (this.muyu_info) {
						// console.log("close old effect");
						(effect_old.effect_root.getChildByName('muyu_chuxian') as Laya.Sprite3D).active = false;
						let container_xiaoshi: Laya.Sprite3D = effect_old.effect_root.getChildByName('muyu_xiaoshi') as Laya.Sprite3D;
						container_xiaoshi.active = true;
						let s_shuzi: Laya.MeshSprite3D = container_xiaoshi.getChildByName('mianpian').getChildByName('shuzi') as Laya.MeshSprite3D;
						let mat: Laya.BlinnPhongMaterial = s_shuzi.meshRender.material as Laya.BlinnPhongMaterial;
						mat.renderQueue = 3001;
						mat.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${this.muyu_info.count}.png`);
						Laya.timer.once(1000, null, () => {
							effect_old.destroy();
						});
					}
					// 新特效
					effect_new.addLoadedListener(Laya.Handler.create(this, () => {
						// console.log("open new effect");
						let player_seat: number = this.seat2LocalPosition(info.seat);
						effect_new.root.transform.worldMatrix = this.players[player_seat].trans_muyu.transform.worldMatrix;
						effect_new.root.transform.rotation = this.players[player_seat].trans_muyu.transform.rotation.clone();
						effect_new.root.active = true;
						(effect_new.effect_root.getChildByName('muyu_xiaoshi') as Laya.Sprite3D).active = false;
						let container_chuxian: Laya.Sprite3D = effect_new.effect_root.getChildByName('muyu_chuxian') as Laya.Sprite3D;
						container_chuxian.active = true;
						(container_chuxian.getChildByName('baodian') as Laya.Sprite3D).active = true;
						let container_mianpian: Laya.Sprite3D = container_chuxian.getChildByName('mianpian') as Laya.Sprite3D;
						container_mianpian.active = true;
						(container_mianpian.getChildByName('shuzi_anim') as Laya.Sprite3D).active = false;
						let s_shuzi: Laya.MeshSprite3D = container_mianpian.getChildByName('shuzi') as Laya.MeshSprite3D;
						s_shuzi.active = true;
						let mat: Laya.BlinnPhongMaterial = s_shuzi.meshRender.material as Laya.BlinnPhongMaterial;
						mat.renderQueue = 3001;
						mat.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${info.count}.png`);
						view.AudioMgr.PlayAudio(246);
					}));

					this.muyu_info = info;
				} else if (info.count != this.muyu_info.count) {
					// console.log("change count:" + info.count);
					let _effect: Laya.Sprite3D = this.muyu_effect.effect_root;
					(_effect.getChildByName('muyu_xiaoshi') as Laya.Sprite3D).active = false;
					let container_chuxian: Laya.Sprite3D = _effect.getChildByName('muyu_chuxian') as Laya.Sprite3D;
					let container_mianpian: Laya.Sprite3D = container_chuxian.getChildByName('mianpian') as Laya.Sprite3D;
					(container_mianpian.getChildByName('shuzi_anim') as Laya.Sprite3D).active = false;
					let s_shuzi: Laya.MeshSprite3D = container_mianpian.getChildByName('shuzi') as Laya.MeshSprite3D;
					let s_shuzi_anim: Laya.Sprite3D = container_mianpian.getChildByName('shuzi_anim') as Laya.Sprite3D;
					let s_shuzi_up: Laya.MeshSprite3D = s_shuzi_anim.getChildByName('shuzi_up') as Laya.MeshSprite3D;
					let s_shuzi_down: Laya.MeshSprite3D = s_shuzi_anim.getChildByName('shuzi_down') as Laya.MeshSprite3D;
					Laya.timer.clearAll(s_shuzi);
					s_shuzi.active = false;
					let mat_shuzi: Laya.BlinnPhongMaterial = s_shuzi.meshRender.material as Laya.BlinnPhongMaterial;
					mat_shuzi.renderQueue = 3001;
					mat_shuzi.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${info.count}.png`);
					let mat_shuzi_up: Laya.BlinnPhongMaterial = s_shuzi_up.meshRender.material as Laya.BlinnPhongMaterial;
					mat_shuzi_up.renderQueue = 3001;
					mat_shuzi_up.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${this.muyu_info.count}.png`);
					let mat_shuzi_down: Laya.BlinnPhongMaterial = s_shuzi_down.meshRender.material as Laya.BlinnPhongMaterial;
					mat_shuzi_down.renderQueue = 3002;
					mat_shuzi_down.albedoTexture = Laya.loader.getRes(`scene/Assets/Resource/effect/texture/muyu_shuzi_${info.count}.png`);
					s_shuzi_down.active = false;
					s_shuzi_anim.active = true;
					this.muyu_info = info;
					Laya.timer.once(210, s_shuzi, () => {
						s_shuzi.active = true;
						s_shuzi_anim.active = false;
					});
				}
			}
		}

		// 获得心理语音优先级
		private getMindVoicePriority(type: string): number {
			switch (type) {
				case 'ingame_yiman': return 100;
				case 'ingame_beiman': return 90;
				case 'ingame_lianda': return 50;
				case 'ingame_baopai': return 30;
				case 'ingame_remain10': return 20;
			}
			return 0;
		}

		// 将心理语音收集起来判定优先级，等playMindVoice时再播放
		public addMindVoice(seat: number, type: string) {
			if (!this.mind_voice_type || this.getMindVoicePriority(this.mind_voice_type) < this.getMindVoicePriority(type)) {
				this.mind_voice_seat = seat;
				this.mind_voice_type = type;
			}
		}

		public playMindVoice() {
			if (!DesktopMgr.bianjietishi) return;
			if (this.gameing && (this.mode == EMJMode.play || (this.mode == EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play))) {
				if (this.mind_voice_type && !this.during_playing_mind_voice) {
					this.resetGameVoice();
					this.during_playing_mind_voice = true;
					let soundInfo = DeskAudioMgr.Inst.playCharSound(this.player_datas[this.mind_voice_seat]['character'], this.mind_voice_type, true, Laya.Handler.create(this, () => {
						this.during_playing_mind_voice = false;
					}));
					if (soundInfo) {
						this.mind_voice_sound_id = soundInfo.audio_id;
					}
				}
			}
			this.mind_voice_type = null;
			this.mind_voice_seat = -1;
		}

		public clearMindVoice() {
			this.mind_voice_type = null;
			this.mind_voice_seat = -1;
		}

		public clearMindVoiceMark(){
			this.during_playing_mind_voice = false;
		}

		// 胡了的时候关掉所有心理语音
		public resetMindVoice() {
			if (this.mind_voice_sound_id) {
				AudioMgr.StopAudio(this.mind_voice_sound_id);
				this.mind_voice_sound_id = null;
			}
			this.clearMindVoice();
		}

		public playGameVoice(seat: number, audioType: EGameVoiceType) {
			if (this.extraGameSoundId > 0) return;
			if (audioType == 'ingame_start') {
				if (this.isPlayedPrepareAudio) return;
				this.isPlayedPrepareAudio = true;
			}
			let soundInfo = DeskAudioMgr.Inst.playCharSound(this.player_datas[seat]['character'], audioType, false, Laya.Handler.create(this, () => {
				this.extraGameSoundId = -1;
			}));
			if(soundInfo) this.extraGameSoundId = soundInfo.audio_id;
		}

		public resetGameVoice() {
			if (this.extraGameSoundId > 0) {
				AudioMgr.StopAudio(this.extraGameSoundId);
			}
			this.extraGameSoundId  = -1;
		}
		
		// 获得未触发的最后N个action的name
		public getLastActionNames(n: number): Array<String> {
			let arr = [];
			let length = this.actionList.length;
			for (let i = Math.max(length - n, this.action_index); i < length; i++) {
				arr.push(this.actionList[i]['name']);
			}
			return arr;
		}

		// 检查上一张弃牌是否是鸣牌
		public isLastPaiMingPai(): boolean {
			for (let i = 0; i < this.players.length; i++) {
				for (let j: number = 0; j < this.players[i].container_ming.pais.length; j++) {
					if (this.lastqipai == this.players[i].container_ming.pais[j]) return true;
				}
			}
			return false;
		}


		public setRevealScore(count: number, anim: boolean) {

			if (!this.anpai) return;

			let num = (count * 1000).toString();
			if (count == 0) {
				for (let i = 0; i < this.score_reveal.length; i++) {
					if (i == 2) {
						this.score_reveal[i].active = true;
						let tilingOffset: Laya.Vector4 = new Laya.Vector4();
						tilingOffset.z = 0;
						tilingOffset.w = -0.9;
						tilingOffset.x = 1;
						tilingOffset.y = 0.1;
						(this.score_reveal[i].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
					} else {
						this.score_reveal[i].active = false;
					}
				}
			} else {
				let last = this.last_anpai_score.toString();
				for (let i = 0; i < this.score_reveal.length; i++) {
					if (i < num.length) {
						let lastScore: number = i < last.length ? Number(last[i]) : 0;
						if (!anim) {
							this.show_reveal_score_anim(i, Number(num[i]), Number(num[i]));
						} else {
							this.show_reveal_score_anim(i, lastScore, Number(num[i]));
						}

						// this.score_reveal[i].active = true;
						// let tilingOffset:Laya.Vector4 = new Laya.Vector4();
						// tilingOffset.z = 0;
						// tilingOffset.w = Number(num[i]) / 10;
						// tilingOffset.x = 1;
						// tilingOffset.y = 0.1;
						// (this.score_reveal[i].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
					} else {
						this.score_reveal[i].active = false;
					}
				}
			}
			this.last_anpai_score = count * 1000;
		}

		private show_reveal_score_anim(index: number, lastPT: number, nowPT: number) {
			let max_speed = 24; //最快速度
			let accelerate = 40; // 加速度 
			let min_speed = 3; // 减速时最小速度
			let elasticDist = 0.2; // 回弹距离
			let slowDist = 0.8; // 开始减速距离
			let maxShowTime = 2000; // 动画最长时间，防止意外
			let dist = nowPT - lastPT;
			this.score_reveal[index].active = true;
			if (lastPT == nowPT) {
				let tilingOffset: Laya.Vector4 = new Laya.Vector4();
				let target = lastPT / 10;
				if (target > 0.9) target -= 1;
				tilingOffset.w = -(0.9 - target);
				tilingOffset.z = 0;
				tilingOffset.x = 1;
				tilingOffset.y = 0.1;
				(this.score_reveal[index].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
				return;
			}
			dist += 10;
			if (dist <= 0) dist += 10;

			let speed = 0;
			let start_time = Laya.timer.currTimer;
			let start_time_1 = Laya.timer.currTimer;
			let offset_y = 0;
			let elasticing = false; // 回弹中
			let frameIndex = 0;
			let func = () => {
				let delta = Laya.timer.currTimer - start_time;
				let last_offset_y = offset_y;
				if (frameIndex % 9 == 0) {
					AudioMgr.PlayAudio(222);
				}
				frameIndex++;
				// 防止一直播放的保险机制
				if (Laya.timer.currTimer - start_time_1 > maxShowTime) {
					offset_y = dist;
					Laya.timer.clear(this, func);
				} else {
					if (offset_y < dist / 2 && speed < max_speed) {
						speed += accelerate * delta / 1000;
					} else if (offset_y >= dist / 2 && dist - offset_y < slowDist) {
						speed -= accelerate * delta / 1000;
						speed = Math.max(min_speed, speed);
					}
					if (elasticing) {

						offset_y -= speed * delta / 1000;
						if (offset_y < dist) {
							offset_y = dist;
							Laya.timer.clear(this, func);
						}
					} else {
						offset_y += speed * delta / 1000;
						if (offset_y > dist + elasticDist) {
							elasticing = true;
						}
					}
				}
				let tilingOffset: Laya.Vector4 = new Laya.Vector4();
				let target = (offset_y + lastPT) / 10;
				if (target > 0.9) target -= 1;
				tilingOffset.w = -(0.9 - target);
				tilingOffset.z = 0;
				tilingOffset.x = 1;
				tilingOffset.y = 0.1;
				(this.score_reveal[index].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;

				// (this.pt_counts[index].getChildAt(0) as Laya.Image).y = -(offset_y + 100) % 200 + 100;
				// (this.pt_counts[index].getChildAt(1) as Laya.Image).y = -(offset_y) % 200 + 100;
				start_time = Laya.timer.currTimer;
			}
			Laya.timer.frameLoop(1, this, func);
		}

		public onRevealStateChange(seat: number, v: boolean) {
			this.players[this.seat2LocalPosition(seat)].trans_reveal.active = v;
		}

		public is_field_spell_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['field_spell_mode']) {
				return true;
			}
			return false;
		}

		public is_field_spell_extra_dora(): boolean {
			if (!this.is_field_spell_mode() || !this.field_spell) {
				return false;
			}
			// card id 203 递归宝牌指示牌也是宝牌
			let spell_var = Math.floor(this.field_spell / 100) % 100;
			return spell_var == 3;
		}

		public is_zhanxing_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['zhanxing']) {
				return true;
			}
			return false;
		}

		public is_tianming_mode(): boolean {
			if (this.game_config && this.game_config['mode'] && this.game_config['mode']['detail_rule'] && this.game_config['mode']['detail_rule']['tianming_mode']) {
				return true;
			}
			return false;
		}

		// 新手引导接口
		public simulate_set(data:Object) {
			uiscript.UI_Replay.Inst.enable = false;
			let d_game = data['game'];
			this.SetChangJuShow(d_game['chang'], d_game['ju'], 0);
			DesktopMgr.Inst.index_change = d_game['chang'];
			DesktopMgr.Inst.index_ju = d_game['ju'];
			DesktopMgr.Inst.index_ben = 0;
			uiscript.UI_DesktopInfo.Inst.setBen(0);
			uiscript.UI_DesktopInfo.Inst.setLiqibang(0);
			this.dora = [];
			let dora:Array<string> = this.parse_tile(d_game['dora']);
			for (let i: number = 0; i < dora.length; i++) {
				if (this.dora.length > i) this.dora[i] = mjcore.MJPai.Create(dora[i]);
				else this.dora.push(mjcore.MJPai.Create(dora[i]));
				
				uiscript.UI_DesktopInfo.Inst.setDora(i, mjcore.MJPai.Create(dora[i]));
			}
			this.index_player = d_game['indexplayer'];
			this.RefreshPlayerIndicator();
			let _count = 0;
			for (let i:number = 0; i < data['accounts'].length; i++) {
				let d_player = data['accounts'][i]['game'];
				let hand:Array<string> = this.parse_tile(d_player['hand']);
				
				if (i == this.seat) {
					let player:ViewPlayer_Me = this.mainrole;
					if (this.index_player == i && d_game['action'] == 0) {
						let s_hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < hand.length - 1; j++) s_hand.push(mjcore.MJPai.Create(hand[j]));
						player.RecordNewGame(s_hand, [], []);
						player.TakePai(mjcore.MJPai.Create(hand[hand.length - 1]), false, false);
					} else {
						let s_hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < hand.length; j++) s_hand.push(mjcore.MJPai.Create(hand[j]));
						player.RecordNewGame(s_hand, [], []);
					}
					
					player.SetScore(d_player['score'], 25000);
					if (d_player['paihe']) {
						_count += d_player['paihe'].split(',').length;
						let paihe = this.parse_paihe(d_player['paihe']);
						let liqied:boolean = false;
						for (let j:number = 0; j < paihe.length; j++) {
							let _moqie:boolean = false;
							player.container_qipai.AddQiPai(paihe[j].tile, paihe[j].liqi, _moqie, false);
							player.container_qipai.QiPaiPass();
							if (paihe[j].liqi) liqied = true;
						}
					}
					if (d_player['mingpai']) {
						let mings:Array<mjcore.MJMing> = this.parse_ming(d_player['mingpai'], i);
						for (let j:number = 0; j < mings.length; j++) {
							let ming:mjcore.MJMing = mings[j];
							_count += ming.pais.length;
							if (ming.type == mjcore.E_Ming.gang_add) {
								let _m:mjcore.MJMing = new mjcore.MJMing();
								_m.type = mjcore.E_Ming.kezi;
								let _add:mjcore.MJPai = null;
								for (let k:number = 0; k < ming.pais.length; k++) {
									if (ming.from[k] == i || _add) {
										_m.pais.push(ming.pais[k]);
										_m.from.push(ming.from[k]);
									} else {
										_add = ming.pais[k];
									}
								}
								player.container_ming.AddMing(_m, false);
								player.container_ming.AddGang(_add, false);
							} else {
								player.container_ming.AddMing(ming, false);
							}
						}
					}
					
				} else {
					let player:ViewPlayer_Other = this.players[this.seat2LocalPosition(i)] as ViewPlayer_Other;
					if (this.index_player == i && d_game['action'] == 0) {
						let s_hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < hand.length - 1; j++) s_hand.push(mjcore.MJPai.Create(hand[j]));
						player.RecordNewGame(s_hand, [], []);
						player.recordTakePai(mjcore.MJPai.Create(hand[hand.length - 1]), false);
					} else {
						let s_hand:Array<mjcore.MJPai> = [];
						for (let j:number = 0; j < hand.length; j++) s_hand.push(mjcore.MJPai.Create(hand[j]));
						player.RecordNewGame(s_hand, [], []);
					}
					
			
					player.SetScore(d_player['score'], 25000);
					if (d_player['paihe']) {
						_count += d_player['paihe'].split(',').length;
						let paihe = this.parse_paihe(d_player['paihe']);
						let liqied:boolean = false;
						for (let j:number = 0; j < paihe.length; j++) {
							let _moqie:boolean = false;
							player.container_qipai.AddQiPai(paihe[j].tile, paihe[j].liqi, _moqie, false);
							player.container_qipai.QiPaiPass();
							if (paihe[j].liqi) liqied = true;
						}
					}
					if (d_player['mingpai']) {
						let mings:Array<mjcore.MJMing> = this.parse_ming(d_player['mingpai'], i);
						for (let j:number = 0; j < mings.length; j++) {
							let ming:mjcore.MJMing = mings[j];
							_count += ming.pais.length;
							if (ming.type == mjcore.E_Ming.gang_add) {
								let _m:mjcore.MJMing = new mjcore.MJMing();
								_m.type = mjcore.E_Ming.kezi;
								let _add:mjcore.MJPai = null;
								for (let k:number = 0; k < ming.pais.length; k++) {
									if (ming.from[k] == i || _add) {
										_m.pais.push(ming.pais[k]);
										_m.from.push(ming.from[k]);
									} else {
										_add = ming.pais[k];
									}
								}
								player.container_ming.AddMing(_m, false);
								player.container_ming.AddGang(_add, false);
							} else {
								player.container_ming.AddMing(ming, false);
							}
						}
					}
					
				}

				
			}

			this.SetLeftPaiShow(69 - _count);

			for (let i:number = 0; i < 4; i++) this.players[i].OnDoraRefresh();
		}

		private parse_paihe(s:string):Array<{tile:mjcore.MJPai, liqi:boolean}> {
			let lst:Array<{tile:mjcore.MJPai, liqi:boolean}> = [];
			s = s.toLowerCase();

			let deal = (ss:string, liqi:boolean) => {
				let tiles:Array<string> = this.parse_tile(ss);
				for (let j:number = 0; j < tiles.length; j++) {
					lst.push({
						tile: mjcore.MJPai.Create(tiles[j]),
						liqi: liqi
					});
				}
			};

			let ss:string = '';

			for (let i:number = 0; i < s.length; i++) {
				if (s[i] == '(') {
					deal(ss, false);
					ss = '';
				} else if (s[i] == ')') {
					deal(ss, true);
					ss = '';
				} else {
					ss += s[i];
				}
			}
			if (ss) deal(ss, false);

			return lst;
		}

		private parse_tile(s:string):Array<string> {
			s = s.toLowerCase();
			let lst:Array<string> = [];
			let nums:Array<number> = [];
			let code0:number = '0'.charCodeAt(0);
			let codea:number = 'a'.charCodeAt(0);
			for (let i:number = 0; i < s.length; i++) {
				let c:number = s.charCodeAt(i);
				let d0:number = c - code0;
				if (d0 >= 0 && d0 <= 9) nums.push(d0);
				else {
					let cc:string = s.charAt(i);
					for (let j:number = 0; j < nums.length; j++) {
						let index:number = nums[j];
						if (cc == 'z') {
							if (index >= 1 && index <= 7) lst.push(index.toString() + cc);
						} else if (cc == 'm' || cc == 's' || cc == 'p') {
							lst.push(index.toString() + cc);
						}
					}
					nums = [];
				}
			}
			return lst;
		}

		public parse_ming(s:string, seat:number):Array<mjcore.MJMing> {
			let lst:Array<mjcore.MJMing> = [];
			s = s.toLowerCase();
			let ss:Array<string> = s.split(',');
			for (let i:number = 0; i < ss.length; i++) {
				let ming:mjcore.MJMing = new mjcore.MJMing;
				let _s:string = ss[i];
				let ls:string = '';
				for (let j:number = 0; j < _s.length; j++) {
					if (_s[j] == '(') {
						let tiles:Array<string> = this.parse_tile(ls);
						for (let k:number = 0; k < tiles.length; k++) {
							ming.pais.push(mjcore.MJPai.Create(tiles[k]));
							ming.from.push(seat);
						}
						ls = '';
					} else if (_s[j] == ')') {
						let tiles:Array<string> = this.parse_tile(ls);
						let localpos:number = this.seat2LocalPosition(seat);
						let fromseat:number = seat;
						if (ming.pais.length == 0) {
							fromseat = this.localPosition2Seat((localpos + 3) % 4);
						} else if (j == _s.length - 1) {
							fromseat = this.localPosition2Seat((localpos + 1) % 4);
						} else {
							fromseat = this.localPosition2Seat((localpos + 2) % 4);
						}
						for (let k:number = 0; k < tiles.length; k++) {
							ming.pais.push(mjcore.MJPai.Create(tiles[k]));
							ming.from.push(fromseat);
						}
						ls = ''
					} else {
						ls += _s[j];
					}
				}
				if (ls && ls.length > 0) {
					let tiles:Array<string> = this.parse_tile(ls);
					for (let k:number = 0; k < tiles.length; k++) {
						ming.pais.push(mjcore.MJPai.Create(tiles[k]));
						ming.from.push(seat);
					}
					ls = '';
				}
				if (ming.pais.length == 3) {
					if (mjcore.MJPai.Distance(ming.pais[0], ming.pais[1]) == 0) {
						ming.type = mjcore.E_Ming.kezi;
					} else {
						ming.type = mjcore.E_Ming.shunzi;
					}
					lst.push(ming);
				} else if (ming.pais.length == 4) {
					let other_count:number = 0;
					for (let j:number = 0; j < ming.from.length; j++) {
						if (ming.from[j] != seat) {
							other_count++;
						}
					}
					if (other_count == 0) {
						ming.type = mjcore.E_Ming.gang_an;
						lst.push(ming);
					}
					else if (other_count == 1) {
						ming.type = mjcore.E_Ming.gang_ming;
						lst.push(ming);
					} else if (other_count == 2) {
						ming.type = mjcore.E_Ming.gang_add;
						lst.push(ming);
					}
				}
			}

			return lst;
		}

		// 再来一局
		public anotherGame() { 
			if (!this.game_config || this.game_config.category != 2 || !this.game_config.meta) 
				return;
			
			
            GameMgr.Inst.postNewInfo2Server('start_another_game', {}, false);
        
			// 清除所有操作
			this.closeAllUI();
			this.ClearOperationShow();
			
			uiscript.UI_PiPeiYuYueMJ.Inst.show(this.game_config.meta.mode_id);
		}

		public checkPaipu() {
			this.closeAllUI();
			this.ClearOperationShow();
			GameMgr.Inst.ingame = false;
			GameMgr.Inst.checkPaiPu(GameMgr.Inst.mj_game_uuid, GameMgr.Inst.account_id, 0, false);
		}

		private closeAllUI() { 
			uiscript.UI_RankChange.Inst.close();
			uiscript.UI_MJReward.Inst.close();
			if (uiscript.UI_MJ_Highlight.Inst && uiscript.UI_MJ_Highlight.Inst.enable) {
				uiscript.UI_MJ_Highlight.Inst.close();
			}
			if (uiscript.UI_MJReward_Activity.Inst && uiscript.UI_MJReward_Activity.Inst.enable) {
				uiscript.UI_MJReward_Activity.Inst.enable = false;
			}
			if (uiscript.UI_MJReward_Activity_2604dj.Inst && uiscript.UI_MJReward_Activity_2604dj.Inst.enable) {
				uiscript.UI_MJReward_Activity_2604dj.Inst.enable = false;
			}
			if (uiscript.UI_MJTask_Progress.Inst && uiscript.UI_MJTask_Progress.Inst.enable) {
				uiscript.UI_MJTask_Progress.Inst.enable = false;
			}
		}

		/**
		 * 获取本人账号的数据
		 * @returns 
		 */
		public getMineDesktopData(): Object { 
			let mineData = {};
			for (let index = 0; index < this.player_datas.length; index++) {
				if (this.player_datas[index]['account_id'] == GameMgr.Inst.account_id) {
					mineData = this.player_datas[index];
					break;
				}
			}
			return mineData;

		}

		public initSpecialModeEffect() {
			if (this.is_beishuizhizhan_mode()) {
				if (this.effectBeiShuiFires.length == 0) {
					for (let playerIndex = 0; playerIndex < 4; playerIndex++) {
						for (let i = 1; i <= 2; i++) {
							let url: string = `scene/effect_beishuizhizhan_fire${i}.lh`;
							let effectBeiShuiFire = new game.EffectBase(url);
							if (!this.effectBeiShuiFires[playerIndex]) {
								this.effectBeiShuiFires.push([]);
							}
							this.effectBeiShuiFires[playerIndex].push(effectBeiShuiFire);
							(game.Scene_MJ.Inst.scene_hand.getChildByName('effect') as Laya.Sprite3D).addChild(effectBeiShuiFire.root);
							effectBeiShuiFire.addLoadedListener(Laya.Handler.create(this, () => {
								let parent = uiscript.UI_DesktopInfo.Inst.me.getChildByName('container_player_' + playerIndex).getChildByName('hunzhi') as Laya.Sprite;
								let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(parent, new Laya.Point((playerIndex > 1 ? 1 : -1) * (parent.width / 2 + 2), parent.height / 2));
								pos.x = pos.x - 0.5;
								pos.y = 0.5 - pos.y;
								effectBeiShuiFire.root.transform.localPosition = new Laya.Vector3(pos.x * 32, pos.y * 18, 0);
								effectBeiShuiFire.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
							}))
						}
					}
				}
				this.effectBeiShuiFires.forEach((effects) => {
					effects.forEach((effect) => {
						Laya.timer.clearAll(effect);
						effect.root.active = false;
					})
				});
			} else if (this.isTargetSpecialMode(game.EMJGameRule.QiangDuoZhiZhan)) {
				let sceneTribute = Laya.loader.getRes('scene/tribute_tile.lh') as Laya.Sprite3D;
				this.tributeMove = sceneTribute.getChildAt(0) as Laya.Sprite3D;
				this.tributePool = [];
			}
		}

		Clear(){
			this.effectBeiShuiFires.forEach((effects) => {
				effects.forEach((effect) => {
					Laya.timer.clearAll(effect);
					effect.destroy();
				})
			});
			this.effectBeiShuiFires = [];
			this.players.forEach((player=>player.Clear()));
			this.resetGameVoice();
			this.teamNameTexs.forEach(v => v && v.destroy());
			this.teamNameTexs.length = 0;
		}

		// liqiType 0：普通立直，1:5000点立直，2:10000点立直
		public SetBeiShuiZhiZhanLiqi(pos: number, liqiType: number, failed: boolean = false, doAnim: boolean = true) {
			if (failed || !liqiType) {
				if (this.effectBeiShuiFires[pos]) {
					this.effectBeiShuiFires[pos].forEach((effect) => {
						effect.root.active = false;
						Laya.timer.clearAll(effect);
					})
				}
			} else {
				if (this.effectBeiShuiFires[pos] && this.effectBeiShuiFires[pos][liqiType - 1]) {
					if (!this.effectBeiShuiFires[pos][liqiType - 1].root.active) {
						let audioId = liqiType == 1 ? 10330 : 10329;
						view.AudioMgr.PlayAudio(audioId);
					}
					this.effectBeiShuiFires[pos][liqiType - 1].root.active = true;
				}
			}
		}

		updateLastRoundRecord(hules?: game.IHuleInfo[] | game.IHuInfoXueZhanMid[]) {
			let huleData = hules || [];
			if (huleData) {
				huleData.forEach((hule) => {
					this.lastRoundRecord[hule.seat] = { hule: true, zimo: hule.zimo };
				})
			}
		}

		updateXiaKeShangInfo(data: game.IXiaKeShangInfo) {
			if (this.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
				this.xiakeshangInfo = data;
            }
        }

		updateRetributeState(isSubmit: boolean) {
			if (isSubmit) {
				this.tributeState++;
				if (uiscript.UI_HuanSanZhange.Inst.enable) {
					uiscript.UI_HuanSanZhange.Inst.close();
				}
			} else if (this.tributeState == 2) {
				this.tributeState = 0;
				this.mainrole.quitReTributeState();
			}
		}

		public createTribute3D(pais: mjcore.MJPai[], states: boolean[], parent: Laya.Sprite3D): { tribute: Laya.Sprite3D, maques: ViewPai[] } | null {
			if (!pais || pais.length == 0) return null;
			let tribute: Laya.Sprite3D;
			if (this.tributePool && this.tributePool.length > 0) {
				tribute = this.tributePool[this.tributePool.length - 1];
				this.tributePool.splice(this.tributePool.length - 1, 1);
			} else {
				if (!this.tributeMove) return null;
				tribute = this.tributeMove.clone();
			}
			parent.addChild(tribute);
			let maques: ViewPai[] = [];
			for (let i = 0; i < pais.length; i++) {
				let maque = this.CreatePai3D(pais[i]);
				let p:ViewPai = new ViewPai(pais[i], maque, states[i]);
				maque.name = 'maque';
				if (pais.length == 1) {
					tribute.getChildByName('anim').getChildByName('2').addChild(maque);
				} else {
					tribute.getChildByName('anim').getChildByName((i + 1).toString()).addChild(maque);
				}
				maque.transform.localPosition = new Laya.Vector3(0, 0, 0);
				maque.transform.localRotationEuler = states[i] ? new Laya.Vector3(0, 0, 0) : new Laya.Vector3(0, 180, 0);
				maque.transform.localScale = new Laya.Vector3(1, 1, 1);
				maques.push(p);
			}
			tribute.active = true;
			return { tribute: tribute, maques: maques };
		}

		public recycleTribute3D(tribute: Laya.Sprite3D) {
			if (!tribute) return;
			tribute.active = false;
			tribute.removeSelf();
			let maqueRoot = tribute.getChildByName('anim');
			maqueRoot._childs.forEach((maqueRoot: Laya.Sprite3D) => {
				let maque = maqueRoot.getChildAt(0);
				if (maque) {
					maque.removeChildren();
					maque.destroy();
				}
			});
			this.tributePool.push(tribute);
		}

		private teamNameLabel: Laya.Label;
		private teamNameTexs: Laya.Texture2D[] = [];
		
		/** 刷新团队名 */
		private refreshTeamName() {
			const teamParent = this.desktop3D.scene.getChildByName("team_name") as Laya.Sprite3D;
			if (!teamParent) return;
			let label = this.teamNameLabel;
			if (!this.teamNameLabel) {
				label = this.teamNameLabel = new Laya.Label();
				label.color = "#314072";
				label.bold = true;
				label.font = "SimHei";
				label.fontSize = 28;
			}
			this.teamNameTexs.forEach(v => v && v.destroy());
			this.teamNameTexs.length = 0;
			const teamName = teamParent.getChildAt(0) as Laya.Sprite3D;
			const players = this.player_datas as (game.IPlayerGameView | game.IRecordGame_AccountInfo)[];
			let isTeamMode: boolean = this.game_config && this.game_config.meta && this.game_config.meta.contest_info && this.game_config.meta.contest_info.rank_type == 1;
			for (let i = 0; i < 4; i++) {
				const seat = view.DesktopMgr.Inst.localPosition2Seat(i);
				const pData = players[seat];
				const nameSeat = teamName.getChildAt(i) as Laya.MeshSprite3D;
				nameSeat.active = false;
				if (pData && pData['team_name'] && isTeamMode) {
					
					let serverName = pData['team_name'];
					//热门赛事和官方赛事忽视屏蔽字
					let isForbidden = !!app.Taboo.test(serverName);
					if (this.game_config && this.game_config.meta && this.game_config.meta.contest_info) {
						let typeList = this.game_config.meta.contest_info.type_list;
						if (typeList) {
							let zoneId = game.Tools.get_zone_id(GameMgr.Inst.account_id);
							let zoneContestType = typeList.find(v => v.zone == zoneId);
							isForbidden = !uiscript.UI_Match_Lobby.isStrNotForbbiden(zoneContestType.contest_type) && isForbidden;
						}
					}
					//名字不可以大于14个字符,中文算2个字符
					let showName: string = game.Tools.substringByCodeLength(serverName, 14);
					label.text = isForbidden ? game.Tools.strOfLocalization(25090114) : showName;
					const base64 = label.drawToCanvas(label.width, label.height, 0, 0).getCanvas().toDataURL("image/png");
					const img = new Image();
					img.src = base64;
					img.onload = () => {
						const tex = this.teamNameTexs[i] = new Laya.Texture2D(false, 1 as any, Laya.WebGLContext.RGBA, false);
						tex.onAsynLoaded("team_name_" + i + ".png", img, null);
						const nameSp = nameSeat.getChildAt(0) as Laya.MeshSprite3D;
						const nameMat = nameSp.meshRender.material;
						nameMat["_MainTex"] = tex;
						const scaleX = tex.width < 196 ? tex.width / 196 : 1;
						nameSp.transform.localScale = new Laya.Vector3(scaleX, 1, 1);
						nameSeat.active = true;
					};
				}
			}
		}
		
		/**
		* 将位置从相机空间转换到世界
		* @param cameraSpacePos 相机空间中的位置
		* @returns 世界位置
		*/
		public convertCameraToWorld(cameraSpacePos: Laya.Vector3): Laya.Vector3 {
			// 相机局部到世界
			let worldPos = new Laya.Vector3();
			Laya.Vector3.transformV3ToV3(cameraSpacePos, this.mainCamera.transform.worldMatrix, worldPos);
			return worldPos;
		}

		public refreshSeatOnNewRound() {
			if (this.record_follow_dealer) {
				if (this.mode == view.EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play && this.seat != this.index_ju) {
					this.seat = this.index_ju;
					this.refreshTeamName();
					uiscript.UI_DesktopInfo.Inst.refreshSeat(true);
					for (let i: number = 0; i < 4; i++) {
						let seat = this.localPosition2Seat(i);
						if (seat == -1) {
							this.players[i].Reset();
						}
						this.players[i].onInitRoom(seat);
					}
				}
			}
		}

		/**
		 * 检查每个玩家的牌，重置其炮牌状态
		 */
		public refreshPaopai() {
			for (let i: number = 0; i < this.players.length; i++) {
				let seat: number = this.localPosition2Seat(i);
				let player = this.players[i];
				if (seat < 0) continue;
				//弃牌区域炮牌刷新
				for (let j: number = 0; j < player.container_qipai.pais.length; j++) {
					let pai: view.ViewPai = player.container_qipai.pais[j];
					pai.ispaopai = this.isPaoPai(pai.val);
					pai.OnChoosedPai();
				}
				//明牌区域炮牌刷新
				for (let j: number = 0; j < player.container_ming.pais.length; j++) {
					let pai: view.ViewPai = player.container_ming.pais[j];
					pai.ispaopai = this.isPaoPai(pai.val);
					pai.OnChoosedPai();
				}
				//拔北区域炮牌刷新
				for (let j: number = 0; j < player.container_babei.pais.length; j++) {
					let pai: view.ViewPai = player.container_babei.pais[j];
					pai.ispaopai = this.isPaoPai(pai.val);
					pai.OnChoosedPai();
				}
				//最后一张弃牌炮牌刷新
				{
					let pai: view.ViewPai = player.container_qipai.last_pai;
					if (pai) {
						pai.ispaopai = this.isPaoPai(pai.val);
						pai.OnChoosedPai();
					}
				}
				//主视角手牌区域炮牌刷新
				if (i == 0) {
					let __player: view.ViewPlayer_Me = player as view.ViewPlayer_Me;
					for (let j: number = 0; j < __player.hand.length; j++) {
						let pai: view.HandPaiPlane = __player.hand[j];
						pai.ispaopai = this.isPaoPai(pai.val);
						pai.OnChoosedPai();
					}
				} else {
					//其他玩家手牌区域炮牌刷新,仅限牌谱打开显示手牌/透明牌时/公开牌
					let __player: view.ViewPlayer_Other = player as view.ViewPlayer_Other;
					for (let j: number = 0; j < __player.hand.length; j++) {
						let pai: view.ViewPai = __player.hand[j].pai3D;
						//2025.12.19 新增透明牌也显示炮牌效果
						if (this.record_show_hand || pai.is_open || (view.DesktopMgr.Inst.is_jiuchao_mode() && pai.val.touming)) {
							pai.ispaopai = this.isPaoPai(pai.val);
							
						} else {
							pai.ispaopai = false;
						} 
						pai.OnChoosedPai();
					}
				}
			}
		}

		// ==DevDebug Start==
		/**
		 * 预览和牌特效，位置是最后一张打牌的位置，此处是加载完毕后再进行播放和销毁
		 * @param item_id 道具id
		 * @param huleType 和牌类型
		 * @param onDestroy 播放完毕之后的回调
		 */
		public previewHule( item_id: number, huleType: number = 0, onDestroy: Laya.Handler = null, destroyDelay: number = 2000): void {
			let pai = this.lastqipai;
			
			if (pai != null) {
				let transform = pai.model.transform;
				let seat = this.lastpai_seat;
				let d_view: lqc.Sheet_ItemDefinition_View;
				let outfitConfig: lqc.Sheet_OutfitConfig_Ron = null;
				let audio_id: number = 213;
				let isOldRon = true;
				let path: string = 'scene/effect_hupai_default.lh';
				let fullScreenPath = '';

				if (item_id) {
					d_view = cfg.item_definition.view.get(item_id);
					outfitConfig = cfg.outfit_config.ron.get(item_id);
					if (d_view) {
						path = `scene/${d_view.res_name}.lh`;
						audio_id = d_view.audio_id;
						isOldRon = (d_view.old_effect_mark && d_view.old_effect_mark == 1);
					}
					if (outfitConfig && outfitConfig.is_fullscreen == 1 && !isOldRon) {
						fullScreenPath = `scene/${d_view.res_name}_fullscreen.lh`;
					}
				}
				let pos = transform.position;
				let effect: game.EffectBase = new game.EffectBase(path);
				this.trans_container_effect.addChild(effect.root);
				if (isOldRon) {
					pos.y = 0;
					effect.root.transform.position = pos;
				}
				effect.root.active = true;

				if (path == 'scene/ron_hl.lh') {
					let localPosition = this.seat2LocalPosition(seat);
					if (localPosition == 0) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					} else if (localPosition == 1) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 90, 0);
					} else if (localPosition == 2) {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
					} else {
						effect.root.transform.localRotationEuler = new Laya.Vector3(0, 270, 0);
					}
				} else if (path == 'scene/effect_hupai_yanhua.lh') {
					Laya.timer.once(600, this, () => {
						let _effect: game.EffectBase = new game.EffectBase('scene/effect_hupai_yanhua_bang.lh');
						this.desktop3D.addChild(_effect.root);
						_effect.root.transform.position = new Laya.Vector3(0, 0, 0);
						_effect.root.active = true;
						Laya.timer.once(2000, this, () => {
							_effect.destroy();
						});
					});
				}
			
				
				let destoryed: boolean = false;
				let parent = pai.model.parent;
				let origin_rotation = pai.model.transform.rotation.clone();
				let worldpos = pai.model.transform.worldMatrix.clone();
				let doPaiAni: boolean = false;
				let isEffectLoaded: boolean = false;
				let isFullScreenCompleted: boolean = false;
				let onLoaded = Laya.Handler.create(this, () => { 
					if (destoryed) return;
					if (!pai || !pai.model || pai.model.destroyed) {
						effect.destroy();
						return;
					}
					view.AudioMgr.PlayAudio(audio_id);
					if (!isOldRon) {
						if (d_view && d_view.sargs[1]) {
							let depthTestValue = Number(d_view.sargs[1]) == 1 ? 513 : 0;
							game.Tools.changePaiMat(pai.model, 3090, 3089, depthTestValue);
							// game.Tools.dfsChangeParticleMat(effect.root);
						}
						let effectRoot = effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D; //所有胡牌特效分为以下四个部分
						let _rot: Laya.Sprite3D = effectRoot.getChildByName('root_rot') as Laya.Sprite3D;  //需要控制旋转，和 牌的方向 一致
						let _move: Laya.Sprite3D = effectRoot.getChildByName('root_move') as Laya.Sprite3D; //动画部分，永远朝向主视角
						let _static: Laya.Sprite3D = effectRoot.getChildByName('root_static') as Laya.Sprite3D;  //静止部分：例如遮罩黑
						let _ani: Laya.Sprite3D = effectRoot.getChildByName('root_ani') as Laya.Sprite3D;  //root_ani只要不是抢杠胡就播
						let _origin_move_rot = _move.transform.rotation.clone();
						let _origin_pos = transform.worldMatrix.clone();
						let _origin_rotation = transform.rotation.clone();
						_move.transform.worldMatrix = _origin_pos.clone();
						_move.transform.rotation = _origin_move_rot.clone();
						_rot.transform.worldMatrix = _origin_pos.clone();
						_rot.transform.rotation = _origin_rotation.clone();
						let _ani_zimo: Laya.Sprite3D = effectRoot.getChildByName('root_ani_zimo') as Laya.Sprite3D;  //root_ani_zimo只有自摸胡才播
						let haveSpecialAni = (_ani && _ani.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator)
							|| (_ani_zimo && _ani_zimo.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
						let doAnim = haveSpecialAni && (huleType == 1 || (huleType == 0 && !!_ani)) //自摸胡或者非抢杠胡就播
						if (doAnim) { //有特殊牌动画的特效，特别特别特别少
							app.Log.log('胡牌特效有牌动画  huleType === ' + huleType);
							doPaiAni = true;
							_ani.transform.position = transform.position.clone();
							(_ani.getChildAt(0) as Laya.Sprite).destroyChildren();
							(_ani.getChildAt(0) as Laya.Sprite).addChild(pai.model);
							// 清楚所有其他计时器
							if (pai['ResetAllTimer']) {
								pai['ResetAllTimer']();
							}
							pai.model.transform.worldMatrix = worldpos.clone();
						} else {
							if (huleType == 3) {//立直失败牌会转，特效跟着牌转
								Laya.timer.frameLoop(1, effect, () => {
									if (pai && pai.model && !pai.model.destroyed && !effect.destroyed) {
										_rot.transform.worldMatrix = pai.model.transform.worldMatrix.clone();
									} else {
										Laya.timer.clearAll(effect);
									}
								});
							}
						}
					}
					else {
						// 老特效
						let root_pai_anim: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'pai') as Laya.Sprite3D;
						if (root_pai_anim && huleType == 1) {
							doPaiAni = true;
							root_pai_anim.destroyChildren();
							root_pai_anim.addChild(pai.model);
							// 清楚所有其他计时器
							if (pai['ResetAllTimer']) {
								pai['ResetAllTimer']();
							}
							pai.model.transform.rotation = origin_rotation.clone();
							pai.model.transform.worldMatrix = worldpos.clone();

							Laya.timer.once(1800, this, () => {
								if (destoryed) return;
								parent.addChild(pai.model);
								pai.model.transform.rotation = origin_rotation.clone();
								pai.model.transform.worldMatrix = worldpos.clone();
							});
						}

						let root_pai_anim1: Laya.Sprite3D = game.Tools.GetNodeByNameInChildren(effect.root, 'pai_anim') as Laya.Sprite3D;
						if (root_pai_anim1 && (huleType == 1 || huleType == 0)) {
							doPaiAni = true;
							root_pai_anim1.destroyChildren();
							root_pai_anim1.addChild(pai.model);
							// 清楚所有其他计时器
							if (pai['ResetAllTimer']) {
								pai['ResetAllTimer']();
							}
							pai.model.transform.rotation = origin_rotation.clone();
							pai.model.transform.worldMatrix = worldpos.clone();
							Laya.timer.once(1800, this, () => {
								if (destoryed) return;
								// let _origin_rotation = pai.model.transform.rotation.clone();
								// let _worldpos = pai.model.transform.worldMatrix.clone();
								parent.addChild(pai.model);
								pai.model.transform.rotation = origin_rotation.clone();
								pai.model.transform.worldMatrix = worldpos.clone();
							});
						}
						this.setSpecialHuleEffect(path, effect, pai, seat, huleType);
					}
					//特效销毁延迟
					let delay = destroyDelay;
					//牌层级重置延迟
					let queueChangeDelay = delay;
					let hupaiViewData = cfg.item_definition.view.get(item_id);
					if (hupaiViewData && hupaiViewData.sargs[0]) {
						delay += Number(hupaiViewData.sargs[0]);
						//如果是麻将在特效和其他所有牌上层sargs[1] == 2且有单独的时间配置，则使用单独的时间配置，否则延迟时间按照销毁时间执行
						if (Number(hupaiViewData.sargs[1]) == 2 && outfitConfig.queue_change_delay) {
							queueChangeDelay = outfitConfig.queue_change_delay;
						} else {
							queueChangeDelay = delay;
						}
					}

					//重置牌的渲染层级
					Laya.timer.once(queueChangeDelay, this, () => {
						if (pai && pai.model && pai.model.transform) {
							// 重置胡牌renderqueue
							if (this.resetPaiEffectList.indexOf(path) != -1 || (d_view && d_view.sargs[1])) {
								game.Tools.changePaiMat(pai.model, 2000, 3001, 513);
							}
						}
					})

					//销毁特效
					Laya.timer.once(delay, this, () => {
						destoryed = true;
						if (pai && pai.model && pai.model.transform) {
							// 重置胡牌renderqueue
							if (doPaiAni) {
								parent.addChild(pai.model);
								pai.model.transform.rotation = origin_rotation.clone();
								pai.model.transform.worldMatrix = worldpos.clone();
							}
						}
						Laya.timer.clearAll(effect);
						effect.destroy();
						//销毁全屏特效
						if (fullScreenEffect) {
							Laya.timer.clearAll(fullScreenEffect);
							fullScreenEffect.destroy();
						}
						onDestroy?.run();
					});
				});
				effect.addLoadedListener(Laya.Handler.create(this, () => { 
					isEffectLoaded = true;
					if (isFullScreenCompleted) {
						onLoaded.run();
					}
				}));
				let fullScreenEffect: game.EffectBase = null;
				//显示全屏特效
				if (fullScreenPath != '') {
					fullScreenEffect = new game.EffectBase(fullScreenPath);
					this.trans_container_fullscreeen_effect.addChild(fullScreenEffect.root);
					fullScreenEffect.root.active = true;
					fullScreenEffect.addLoadedListener(Laya.Handler.create(this, () => {
						if (destoryed) return;
						isFullScreenCompleted = true;
						if (isEffectLoaded) {
							onLoaded.run();
						}
					}));
				} else {
					isFullScreenCompleted = true;
				}

				
			}
			else {
				app.Log.log('预览和牌特效失败，牌不存在');
				onDestroy?.run();
			}

		}
		// ==DevDebug End==
	}
}