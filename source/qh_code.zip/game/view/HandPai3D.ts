/**
* name 
*/
module view {
	export class HandPai3D {

		public val: mjcore.MJPai = null;
		public model:Laya.Sprite3D = null;
		public contianer_pai: Laya.Sprite3D = null;
		public pai3D: ViewPai = null;
		public shadow: Laya.Sprite3D = null;
		public shadow_1: Laya.Sprite3D = null; // 不透的阴影
		public shadow_2: Laya.Sprite3D = null; // 透明的阴影
		public is_open: boolean = false;
		private _starttime: number = 0;
		private _lifetime: number = 150; 
		private _index: number = 0;
		private _isnew: boolean = false;
		
		private pos_x: number = 0;
		
		public get index(): number {
			return this._index;
		}

		constructor(parent:Laya.Sprite3D) {
			this.model = new Laya.Sprite3D();
			parent.addChild(this.model);
			this.model.transform.localPosition = new Laya.Vector3(0, - PAIMODEL_HEIGHT * 0.5, 0);
			this.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.model.transform.localScale = new Laya.Vector3(1, 1, 1);
			this.model.active = true;

			this.contianer_pai = new Laya.Sprite3D();
			this.model.addChild(this.contianer_pai);
			this.contianer_pai.transform.localPosition = new Laya.Vector3(0, 0, 0);
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.contianer_pai.transform.localScale = new Laya.Vector3(1, 1, 1);
			this.contianer_pai.active = true;


			//添加影子
			{
				this.shadow = DesktopMgr.Inst.effect_shadow.clone();
				this.shadow_1 = this.shadow;
				(this.shadow.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 2998;
				this.model.addChild(this.shadow);
				this.shadow.transform.localPosition = new Laya.Vector3(0, 0, 0);
				this.shadow.transform.localScale = new Laya.Vector3(1, 1, 1);
				this.shadow.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				this.shadow.active = true;
			}

			//添加影子
			{
				this.shadow_2 = DesktopMgr.Inst.effect_shadow_touming.clone();
				(this.shadow_2.getChildAt(0) as Laya.MeshSprite3D).meshRender.sharedMaterial.renderQueue = 3000;
				this.model.addChild(this.shadow_2);
				this.shadow_2.transform.localPosition = new Laya.Vector3(0, 0, 0);
				this.shadow_2.transform.localScale = new Laya.Vector3(1, 1, 1);
				this.shadow_2.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				this.shadow_2.active = false;
			}

			Laya.timer.frameLoop(1, this, this.Update);
		}

		public SetVal(val:mjcore.MJPai, is_open:boolean, need_refresh_dora: boolean = true): void {
			try {
				if (this.pai3D != null) {
					this.pai3D.model.destroy();
					this.pai3D = null;
				}
				is_open = view.DesktopMgr.Inst.is_jiuchao_mode() ? false : is_open;
				this.val = val;
				this.pai3D = new ViewPai(val, DesktopMgr.Inst.CreatePai3D(val), need_refresh_dora);
				this.contianer_pai.addChild(this.pai3D.model);
				this.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
				this.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
				this.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
				this.pai3D.model.active = true;
				this.is_open = is_open;
				this.shadow.active = false;
				this.shadow = (val.touming && !DesktopMgr.Inst.is_tianming_mode()) ? this.shadow_2 : this.shadow_1;
				this.shadow.active = true;
				this.pai3D.is_open = this.is_open;
				this.pai3D.ResetShow();
			} catch (e) {
				let _errorinfo:Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'HandPai3D';
				_errorinfo['name'] = 'SetVal';
				let extendinfo:string = '';
				if (this.pai3D) {
					extendinfo += 'pai3D';
					if (this.pai3D.model) {
						extendinfo += ' model';
						if (this.pai3D.model.transform) {
							extendinfo += ' transform';
						}
					}
				}
				if (this.contianer_pai) extendinfo += ' contianer_pai';
				_errorinfo['iinfo'] = extendinfo;
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public SetIndex(index:number, isnew:boolean, move: boolean = false): void {
			if (!this.model) {
				app.Log.Error('SetIndex index:' + index + ' model不存在');
			} else if (this.model.destroyed) {
				app.Log.Error('SetIndex index:' + index + ' model已经被删除');
			} else if (!this.model.transform) {
				app.Log.Error('SetIndex index:' + index + ' model.transform不存在');
			}
			this._isnew = isnew;
			this._index = index;
			this.pos_x = -PAIMODEL_WIDTH * (index + (isnew ? 0.5 : 0)) * 1.01;
			if (!move) {
				this.model.transform.localPosition = new Laya.Vector3(-PAIMODEL_WIDTH * (index + (isnew ? 0.5 : 0)) * 1.01, -PAIMODEL_HEIGHT*0.5, 0);
			}
			
		}

		public IsNew():boolean {
			return this._isnew;
		}
		
		public Stand(show_yinying: boolean = true): void {
			this.contianer_pai.transform.localPosition = new Laya.Vector3(0, 0, 0);
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.pai3D.model.transform.localPosition = new Laya.Vector3(0, PAIMODEL_HEIGHT * 0.5, 0);
			this.shadow.transform.localScale = new Laya.Vector3 (PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_THICKNESS * 0.53);
			this.shadow.transform.localPosition = new Laya.Vector3 (0, 0, 0);
			this.shadow.active = true;
			if (show_yinying && (this.pai3D.val.touming && !DesktopMgr.Inst.is_tianming_mode())) {
				this.pai3D.contianer_touming_touying.active = true;
			}
		}

		public FullDown(): void {
			this.contianer_pai.transform.localPosition = new Laya.Vector3(0, 0, PAIMODEL_THICKNESS * 0.5);
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(90, 0, 0);
			this.pai3D.model.transform.localPosition = new Laya.Vector3(0, PAIMODEL_HEIGHT * 0.5, -PAIMODEL_THICKNESS * 0.5);
			this.shadow.transform.localScale = new Laya.Vector3 (PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
			this.shadow.transform.localPosition = new Laya.Vector3 (0, 0, (PAIMODEL_HEIGHT + PAIMODEL_THICKNESS)  * 0.5);
			this.shadow.active = true;
			if (this.pai3D.val.touming && !DesktopMgr.Inst.is_tianming_mode()) {
				this.pai3D.contianer_touming_touying.active = false;
			}
		}

		public Cover(): void {
			this.contianer_pai.transform.localPosition = new Laya.Vector3(0, 0, -PAIMODEL_THICKNESS * 0.5);
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);
			this.pai3D.model.transform.localPosition = new Laya.Vector3(0, PAIMODEL_HEIGHT * 0.5, PAIMODEL_THICKNESS * 0.5);
			this.shadow.transform.localScale = new Laya.Vector3 (PAIMODEL_WIDTH * 0.53, 1, PAIMODEL_HEIGHT * 0.53);
			this.shadow.transform.localPosition = new Laya.Vector3 (0, 0, - (PAIMODEL_HEIGHT + PAIMODEL_THICKNESS)  * 0.5);
			this.shadow.active = true;
			if (this.pai3D.val.touming && !DesktopMgr.Inst.is_tianming_mode()) {
				this.pai3D.contianer_touming_touying.active = false;
			}
		}

		private ClearAnim() {
			Laya.timer.clear(this, this.UpdateFullDown);
			Laya.timer.clear(this, this.UpdateCover);
			Laya.timer.clear(this, this.UpdateStand);
		}
		public DoAnim_FullDown(): void {
			this.FullDown();
			this._lifetime = 120;
			this._starttime = Laya.timer.currTimer;
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.shadow.active = false;
			this.ClearAnim();
			Laya.timer.frameLoop(1, this, this.UpdateFullDown);
		}

		private UpdateFullDown() {
			let t:number = Laya.timer.currTimer - this._starttime;
			if (t >= this._lifetime) {
				this.FullDown();
				Laya.timer.clear(this, this.UpdateFullDown);
			} else {
				let rate:number = t / this._lifetime;
				this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(90 * rate * rate, 0, 0);
			}
		}
		public DoAnim_Cover(): void {
			this.Cover();
			this._lifetime = 120;
			this._starttime = Laya.timer.currTimer;
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.shadow.active = false;
			this.ClearAnim();
			Laya.timer.frameLoop(1, this, this.UpdateCover);
		}

		private UpdateCover() {
			let t:number = Laya.timer.currTimer - this._starttime;
			if (t >= this._lifetime) {
				this.Cover();
				Laya.timer.clear(this, this.UpdateCover);
			} else {
				let rate:number = t / this._lifetime;
				this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(-90 * rate * rate, 0, 0);
			}
		}
		public DoAnim_Stand(): void {
			this.Cover();
			this._lifetime = 150;
			this._starttime = Laya.timer.currTimer;
			this.shadow.active = false;
			this.ClearAnim();
			Laya.timer.frameLoop(1, this, this.UpdateStand);
		}

		private UpdateStand() {
			let t:number = Laya.timer.currTimer - this._starttime - 300;
			if (t >= this._lifetime) {
				this.Stand();
				Laya.timer.clear(this, this.UpdateStand);
			} else if (t >= 0) {
				let rate:number = t / this._lifetime;
				this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(90 * rate - 90, 0, 0);
			}
		}

		public DoAnim_CoverToFulldown():void {
			this.Cover();
			this._lifetime = 200;
			this._starttime = Laya.timer.currTimer;
			this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(-90, 0, 0);
			this.shadow.active = false;
			this.ClearAnim();
			Laya.timer.frameLoop(1, this, this.UpdateCoverToFulldown);
		}

		private UpdateCoverToFulldown() {
			let t:number = Laya.timer.currTimer - this._starttime;
			if (t >= this._lifetime) {
				this.FullDown();
				Laya.timer.clear(this, this.UpdateCoverToFulldown);
			} else {
				let rate:number = t / this._lifetime;
				this.contianer_pai.transform.localRotationEuler = new Laya.Vector3(-90 + 180 * rate * rate, 0, 0);
			}
		}

		private Update() {
			let current_pos:Laya.Vector3 = this.model.transform.localPosition;
			let distance:number = Math.abs(current_pos.x - this.pos_x);
			if (distance > 1e-5) {
				let moveSpeed:number = 0.85;
				let move_dis:number = moveSpeed * Laya.timer.delta / 1000;
				if (move_dis >= distance) {
					this.model.transform.localPosition = new Laya.Vector3(this.pos_x, -PAIMODEL_HEIGHT*0.5, 0);
				} else {
					if (this.pos_x < current_pos.x) move_dis = - move_dis;
					this.model.transform.localPosition = new Laya.Vector3(current_pos.x + move_dis, -PAIMODEL_HEIGHT*0.5, 0);
				}
			}
		}

		public ResetAllTimer() {
			Laya.timer.clearAll(this);
		}
		
		public Destory(): void {
			if (this.contianer_pai == null) return;
			Laya.timer.clearAll(this);
			this.contianer_pai.destroy(true);
			this.pai3D.model.destroy(true);
			this.shadow = null;
			this.shadow_1.destroy(true);
			this.shadow_2.destroy(true);
			this.model.destroy(true);
			this.contianer_pai = null;
			this.pai3D = null;
		}
	}
}