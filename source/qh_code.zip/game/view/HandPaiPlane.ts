/**
* name 
*/
module view{
	const COLOR_WHITE: Laya.Vector4 = new Laya.Vector4(1, 1, 1, 1);
	const COLOR_OPEN: Laya.Vector4 = new Laya.Vector4(1, 0.917, 0.663, 1);
	const COLOR_GRAY: Laya.Vector4 = new Laya.Vector4(0.6, 0.6, 0.6, 1);
	
	enum EHandPaiAnim { none, newtile, hule, huansanzhang }

	export class HandPaiPlane extends Laya.Script {

		public mySelf: Laya.Sprite3D = null;
		public bei: Laya.MeshSprite3D = null;
		public acitve: boolean = false;
		public val: mjcore.MJPai = null;
		public valid: boolean = true;
		private _clickeffect: Laya.Sprite3D = null;
		private anim:EHandPaiAnim = EHandPaiAnim.none;
		private anim_start_time:number = 0;
		private anim_life_time:number = 0;
		private isDora:boolean = false;
		public ispaopai:boolean = false; // 是否是炮牌，在牌谱状态下用
		public isGap:boolean = false; // 是否是定缺牌
		public is_open:boolean = false; // 是否被别人看到的牌
		public huansanzhangEnabled = true;//是否可以进行换三张
		public index:number = -1;
		private pos_x:number = 0;
		private _recommendeffect:Laya.Sprite3D = null;
		private _doraeffect:Laya.Sprite3D = null;
		public z:number = 0;
		private origin_mat: Laya.BlinnPhongMaterial;

		public bedraged:boolean = false;

		constructor() {
			super();
		}

		public _load (owner:Laya.Sprite3D): void{
			this.mySelf = owner;
			this.mySelf.active = false;
			(this.mySelf as Laya.MeshSprite3D).meshRender.material.depthWrite = true;
			this.bei = this.mySelf.getChildByName('bei') as Laya.MeshSprite3D;
			this.bei.transform.localPosition = new Laya.Vector3(0,0,0.002);
			this.bei.meshRender.material.depthWrite = true;
			this.origin_mat = (this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
			this.isDora = false;
			Laya.timer.frameLoop(1, this, this.Update);
		}

		public Reset(): void {
			this.val = null;
			this.valid = true;
			this.index = -1;
			this.is_open = false;
			this.isGap = false;
			this.ispaopai = false;
			this._SetColor(COLOR_WHITE);
			this.mySelf.active = false;
			this.bedraged = false;
			this.anim = EHandPaiAnim.none;
			this.mySelf.transform.localPosition = new Laya.Vector3(0, 0, 0);
			if (this._clickeffect != null) {
				this._clickeffect.destroy();
				this._clickeffect = null;
			}
			this.acitve = false;
			this.isDora = false;
			if (this._doraeffect) {
				this._doraeffect.active = false;
			}
			if (this._recommendeffect != null) {
				this._recommendeffect.destroy();
				this._recommendeffect = null;
			}
		}

		public SetVal(val:mjcore.MJPai, is_open:boolean): void {
			this.val = val;
			this.valid = true;
			is_open = val.touming ? false : is_open;
			this.is_open = is_open;
			this._SetColor(this.getColor());
			
			let x: number = val.type == mjcore.E_MJPai.z ? (val.index - 1) * 0.1 : (val.dora ? 0 : val.index * 0.1);
			let y: number = 0;
			switch (val.type) {
				case mjcore.E_MJPai.s: y = -0.75; break;
				case mjcore.E_MJPai.m: y = -0.5; break;
				case mjcore.E_MJPai.p: y = -0.25; break;
				default: y = 0; break;
			}
			
			if (val.touming && !DesktopMgr.Inst.is_tianming_mode()) {
				let mat:Laya.BlinnPhongMaterial = (this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;
				let texture_path:string = 'scene/Assets/Resource/mjpai/';
				if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') texture_path += 'en_kr/';

				if (view.DesktopMgr.en_mjp) texture_path += 'toumingpai_0/hand_ui.png'; else texture_path += 'toumingpai/hand_ui.png';
				mat.albedoTexture = Laya.loader.getRes(texture_path);
				mat.tilingOffset = new Laya.Vector4(0.1, 0.25, x, y);
				this.bei.active = false;
			} else {
				let mat: Laya.BlinnPhongMaterial = (this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial;

				let texture_path: string = 'scene/Assets/Resource/mjpaimian/';
				if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') texture_path += 'en_kr/';
				let front_texture = texture_path + DesktopMgr.Inst.mjp_res_name + '/hand.png';
				if (val.baida) {
					front_texture = texture_path + (DesktopMgr.en_mjp ? 'mjpface_special_0/wanxiangxiuluo_mode/hand.png' : 'mjpface_special/wanxiangxiuluo_mode/hand.png');
				}
				mat.albedoTexture = Laya.loader.getRes(front_texture);
				mat.tilingOffset = val.baida ? new Laya.Vector4(1, 1, 0, 0) : new Laya.Vector4(0.1, 0.25, x, y);
				this.bei.active = true;
				let bei_mat: Laya.BlinnPhongMaterial = this.bei.meshRender.material as Laya.BlinnPhongMaterial;

				let back_texture_path: string = 'scene/Assets/Resource/mjpai/';

				let back_texture = back_texture_path + DesktopMgr.Inst.mjpb_res_name + '/hand.png';

				bei_mat.albedoTexture = Laya.loader.getRes(back_texture);
				bei_mat.tilingOffset = new Laya.Vector4(0.5, 1, 0, 0);
				bei_mat.renderQueue = mat.renderQueue + 1;
			}
			
			this.mySelf.active = true;
			this.acitve = true;
			this.RefreshDora();
		}

		public LiqiSelect(pais:Array<mjcore.MJPai>) {
			if (this.mySelf.destroyed) return;
			let selected: boolean = false;
			for (let i = 0; i < pais.length; i++) {
				if (mjcore.MJPai.Distance(this.val, pais[i]) == 0) {
					selected = true;
					break;
				}
			}

			if (selected)	{
				this._SetColor(this.getColor());
				this.valid = true;
			} 
			else {
				this._SetColor(this.getGrayColor());
				this.valid = false;
			}
		}

		public ChiTiSelect(pais:Array<mjcore.MJPai>) {
			if (this.mySelf.destroyed) return;
			let selected: boolean = false;
			for (let i = 0; i < pais.length; i++) {
				if (mjcore.MJPai.Distance(this.val, pais[i]) == 0) {
					selected = true;
					break;
				}
			}

			if (selected)	{
				this._SetColor(this.getGrayColor());
				this.valid = false;
			} 
			else {
				this._SetColor(this.getColor());
				this.valid = true;
			}
		}

		public HuanSanZhangSelect(isvalid:boolean) {
			if (isvalid)	{
				this._SetColor(this.getColor());
				this.valid = true;
			} 
			else {
				this._SetColor(COLOR_GRAY);
				this.valid = false;
			}
		}

		public OnChoosedPai() {
			if (this.ispaopai) {
				this._SetColor(new Laya.Vector4(1, 0.78, 0.78, 1));
			} else if (this.isGap) {
				 this._SetColor(COLOR_GRAY);
			}else {
				this._SetColor(this.getColor());
			}
		}

		public SelectEnd() {
			if (this.mySelf.destroyed) return;
			this._SetColor(this.getColor());
			this.valid = true;
		}

		private _SetColor(color:Laya.Vector4) {
			if (this.mySelf.destroyed) return;
		
			let render: Laya.MeshRender = (this.mySelf as Laya.MeshSprite3D).meshRender;
			var material:Laya.BlinnPhongMaterial = render.material as Laya.BlinnPhongMaterial;
			material.albedoColor = color;

			(this.bei.meshRender.material as Laya.BlinnPhongMaterial).albedoColor = color;
		}

		public SetIndex(index:number, isnew:boolean, move:boolean) {
			this.index = index;
			this.pos_x = 2.55 * index + (isnew ? 0.8 : 0);
			if (!move) {
				this.mySelf.transform.localPosition = new Laya.Vector3(this.pos_x, this.mySelf.transform.localPosition.y, this.z);
			}
		}

		public AddClickEffect(effect:Laya.Sprite3D) {
			if (this._clickeffect != null) {
				this._clickeffect.destroy();
				this._clickeffect = null;
			}
			this.mySelf.addChild(effect);
			this._clickeffect = effect;
			effect.transform.localPosition = new Laya.Vector3(0, 0, 2);
			effect.active = true;
			Laya.timer.once(300, this, this.RemoveClickEffect);
		}

		public RemoveClickEffect() {
			if (this._clickeffect != null) {
				this._clickeffect.destroy();
				this._clickeffect = null;
			}
		}

		public AnimNewTile() {
			let mat:Laya.BlinnPhongMaterial = ((this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial);
			let color:Laya.Vector4 = mat.albedoColor.clone();
			color.w = 0;
			mat.albedoColor = color;
			
			let front_mat: Laya.BlinnPhongMaterial = this.bei.meshRender.material as Laya.BlinnPhongMaterial;
			let front_color:Laya.Vector4 = front_mat.albedoColor.clone();
			front_color.w = 0;
			front_mat.albedoColor = front_color;
			
			this.anim = EHandPaiAnim.newtile;
			this.anim_start_time = Laya.timer.currTimer;
			this.anim_life_time = 200;
		}

		public AnimHuanSanZhang() {
			this.anim = EHandPaiAnim.huansanzhang;
			this.anim_start_time = Laya.timer.currTimer;
			this.anim_life_time = 800;
			let pos:Laya.Vector3 = this.mySelf.transform.localPosition.clone();
			pos.y = 0.8;
			this.mySelf.transform.localPosition = pos;
		}

		public Hule() {
			this.anim = EHandPaiAnim.hule;
			this.anim_start_time = Laya.timer.currTimer;
			this.anim_life_time = 100;
		}

		public Update() {
			if (this.anim == EHandPaiAnim.newtile) {
				// 配牌时候的动画
				let t:number = Laya.timer.currTimer - this.anim_start_time;
				let pos:Laya.Vector3 = this.mySelf.transform.localPosition.clone();
				
				let mat:Laya.BlinnPhongMaterial = ((this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial);
				let front_mat: Laya.BlinnPhongMaterial = this.bei.meshRender.material as Laya.BlinnPhongMaterial;
				let front_color:Laya.Vector4 = front_mat.albedoColor.clone();
				let color:Laya.Vector4 = mat.albedoColor.clone();
				if (t >= this.anim_life_time) {
					pos.y = 0;
					this.mySelf.transform.localPosition = pos;
					color.w = 1;
					front_color.w = 1;
					front_mat.albedoColor = front_color;
					mat.albedoColor = color;
					this.anim = EHandPaiAnim.none;
				} else {
					let rate:number = t / this.anim_life_time;
					pos.y = 0.5 * (1 - rate);
					this.mySelf.transform.localPosition = pos;
					color.w = rate;
					mat.albedoColor = color;
					front_color.w = rate;
					front_mat.albedoColor = front_color;
				}
				
				
			} else if (this.anim == EHandPaiAnim.hule) {
				// 胡牌时候手牌消失动画
				let t:number = Laya.timer.currTimer - this.anim_start_time;
				
				let mat:Laya.BlinnPhongMaterial = ((this.mySelf as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial);
				let color:Laya.Vector4 = mat.albedoColor.clone();
				let front_mat: Laya.BlinnPhongMaterial = this.bei.meshRender.material as Laya.BlinnPhongMaterial;
				let front_color:Laya.Vector4 = front_mat.albedoColor.clone();

				if (t >= this.anim_life_time) {
					color.w = 0;
					mat.albedoColor = color;
					front_color.w = 0;
					front_mat.albedoColor = front_color;
					this.anim = EHandPaiAnim.none;
					this.acitve = false;
					if (this.mySelf.numChildren > 1) {
						(this.mySelf.getChildAt(1) as Laya.Sprite3D).active = false;
					}
				} else {
					let rate:number = t / this.anim_life_time;
					color.w = 1 - rate;
					mat.albedoColor = color;
					front_color.w = 1 - rate;
					front_mat.albedoColor = front_color;
				}
				
				
			} else if (this.anim == EHandPaiAnim.huansanzhang) {
				// 换三张接到换过来的牌
				let t:number = Laya.timer.currTimer - this.anim_start_time;
				let pos:Laya.Vector3 = this.mySelf.transform.localPosition.clone();
				if (t >= this.anim_life_time) {
					pos.y = 0;
					this.anim = EHandPaiAnim.none;
				} else if (t <= 500) {
					pos.y = 0.8;
				} else {
					let rate = (t - 500) / (this.anim_life_time - 500);
					pos.y = (1 - rate) * 0.8;
				}
				this.mySelf.transform.localPosition = pos;
			}

			if (!this.bedraged) {
				let current_pos:Laya.Vector3 = this.mySelf.transform.localPosition;
				let distance:number = Math.abs(current_pos.x - this.pos_x);
				if (distance > 1e-5) {
					let moveSpeed:number = 2.55 * 25;
					let move_dis:number = moveSpeed * Laya.timer.delta / 1000;
					if (move_dis >= distance) {
						this.mySelf.transform.localPosition = new Laya.Vector3(this.pos_x, this.mySelf.transform.localPosition.y, this.z);
					} else {
						if (this.pos_x < current_pos.x) move_dis = - move_dis;
						this.mySelf.transform.localPosition = new Laya.Vector3(current_pos.x + move_dis, this.mySelf.transform.localPosition.y, this.z);
					}
				}
			}

		}

		public RefreshDora(): void {
			if (!DesktopMgr.bianjietishi) return;
			if (this.isDora) return ;
			if (this.val.dora) this.isDora = true;
			if (!this.isDora) {
				for (let i:number = 0; i < DesktopMgr.Inst.dora.length; i++) {
					if (mjcore.MJPai.DoraMet(this.val ,DesktopMgr.Inst.dora[i])) {
						this.isDora = true;
						break;
					}
				}
			}
			if (this.isDora) {
				if (!this._doraeffect) {
					let effect:Laya.Sprite3D = DesktopMgr.Inst.effect_doraPlane.clone();
					this.mySelf.addChild(effect);
					effect.transform.localPosition = new Laya.Vector3(0, 0, 0);
					effect.transform.localScale = new Laya.Vector3(1, 1, 1);
					effect.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					effect.active = true;
					this._doraeffect = effect;
					let runuv:anim.RunUV = (effect.getChildAt(0) as Laya.Sprite3D).addComponent(anim.RunUV) as anim.RunUV;
				} else {
					this._doraeffect.active = true;
				}
			}
		}
		
		public AddRecommendTag() {
			if (this._recommendeffect == null) {
				let effect:Laya.Sprite3D = DesktopMgr.Inst.effect_recommend.clone();
				this._recommendeffect = effect;
				this.mySelf.addChild(effect);
				effect.transform.localPosition = new Laya.Vector3(0, 0, 0);
				effect.transform.localScale = new Laya.Vector3(1, 1, 1);
				effect.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				effect.active = true;
			}
		}
		public RemoveRecommendTag() {
			if (this._recommendeffect != null) {
				this._recommendeffect.destroy();
				this._recommendeffect = null;
			}
		}

		public SetHuanSanZhangEnable(enable:boolean) {
			this.huansanzhangEnabled = enable;
			if(enable) {
				this._SetColor(COLOR_WHITE);
			} else {
				this._SetColor(COLOR_GRAY);
			}
		}
		public static Cmp(a:HandPaiPlane, b:HandPaiPlane):number {
			let a_val:number = (a.val.numValue() * 10 + (a.val.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.val.touming ? 1 : 0);
			let b_val:number = (b.val.numValue() * 10 + (b.val.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.val.touming ? 1 : 0);
			if (a_val != b_val) return a_val - b_val;
			return a.index - b.index;
		}

		private getColor(): Laya.Vector4 {
			if ((this.is_open && !DesktopMgr.Inst.is_open_hand()) || (this.val.touming && DesktopMgr.Inst.is_tianming_mode())) {
				return COLOR_OPEN;
			} else {
				return COLOR_WHITE;
			}
		}

		private getGrayColor(): Laya.Vector4 {
			if ((this.is_open && !DesktopMgr.Inst.is_open_hand()) || (this.val.touming && DesktopMgr.Inst.is_tianming_mode())) {
				let out = new Laya.Vector4();
				Laya.Vector4.multiply(COLOR_OPEN, COLOR_GRAY, out)
				return out;
			} else {
				return COLOR_GRAY;
			}
		}
	}
}