/**
* name 
*/
module view {
	export class MJTutorialMgr {
        // 使用record接口 返回所用时间
        public static DealTile(seat: number, tile: string, left_tile_count: number, zhenting?: Array<boolean>, liqi?: Object) {
            let data = {seat: seat, tile: tile, left_tile_count: left_tile_count, zhenting, liqi};
            return ActionDealTile.play(data);
        }

        public static DiscardTile(seat: number, tile: string, is_liqi: boolean, moqie?: boolean, zhenting?: boolean, doras?: Array<string>) {
            let data = {seat: seat, tile: tile, is_liqi: is_liqi, moqie: moqie, zhenting: zhenting, doras: doras};
            if (seat == view.DesktopMgr.Inst.seat) {
                let pai = mjcore.MJPai.Create(tile);
                if (mjcore.MJPai.isSame(pai, view.DesktopMgr.Inst.mainrole.hand[view.DesktopMgr.Inst.mainrole.hand.length - 1].val)) {
                    data.moqie = true;
                }
            }
            return ActionDiscardTile.play(data);
        }

        public static ChiPengGang(seat: number, type: number, tiles: Array<string>, last_tile: string, from: number, operation: Array<Object>, zhenting: boolean) {
            let froms = [];
            if (type == mjcore.E_Ming.shunzi) {
                for (let tile of tiles) {
                    if (tile == last_tile) {
                        froms.push(from);
                    } else {
                        froms.push(seat);
                    }
                }
            } else {
                for (let i = 0; i < tiles.length; i++) {
                    if (i == tiles.length - 1) {
                        froms.push(from);
                    } else {
                        froms.push(seat);
                    }
                }
            }
            
            let data = {seat, type, tiles, froms, zhenting, operation};
            return ActionChiPengGang.record(data);
        }

        // 好像就只有暗杠？
        public static AnGangAddGang(seat: number, type: number, tiles: string, operation: Array<Object>, doras?: Array<string>, zhenting?: boolean) {
            let data = {seat, type, tiles, operation, doras, zhenting};
            return ActionAnGangAddGang.record(data);
        }

        public static Hule(hu_tile: string, hand: Array<string>, ming: Array<string>, seat: number, zimo: boolean, 
            doras: Array<string>, li_doras: Array<string>, fans: Array<number>, fu: number, delta_scores: Array<number>, old_scores: Array<number>, score: number) {
            let fan_infos = {};
            for (let fan of fans) {
                if (!fan_infos[fan]) {
                    fan_infos[fan] = 1;
                } else {
                    fan_infos[fan]++;
                }
            }
            
            let menqing = true;
            for (let ming_info of ming) {
                if (ming_info.indexOf('angang') == -1) {
                    menqing = false;
                    break;
                }
            }
            let fan_datas = [];
            let fan_count = 0;
            for (let key in fan_infos) {
                let _data = cfg.fan.fan.get(key);
                let val = (menqing ? _data.fan_menqing : _data.fan_fulu) * fan_infos[key];
                fan_count += val;
                fan_datas.push({id: key, val: val});
            }
            if (li_doras && li_doras.length > 0) {
                fan_datas.push({id: 33, val: 0});
            }
            let hu_data = {hu_tile, hand, ming, seat, zimo, doras, li_doras, fans: fan_datas, fu, count: fan_count, dadian: score, liqi: (li_doras && li_doras.length != 0) ? true : false};
            let data = {hules:[hu_data], old_scores, delta_scores, baopai: 0, gameend: {}};
            return ActionHule.record(data);
        }
    }
}