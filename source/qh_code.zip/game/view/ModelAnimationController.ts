/**
* name 
*/
module view {

	export interface iModelAnimation {
		name:string;
		type:string;
		lifetime:number;
		speed:number;
		keypoint:Array<number>;
	}

	//动作管理器
	export class ModelAnimationController {

		private static _loaded:boolean = false;
		private static _map_anim:Object = {};

		//初始化，整理表格数据
		public static init_data() {
			if (this._loaded) return;
			this._loaded = true;
			cfg.animation.animation.forEach(_value => {
				let value: iModelAnimation = game.Tools.deepCopy(_value);
				let name:string = value.name;
				let type:string = value.type;
				let anim:iModelAnimation = value;
				anim.lifetime /= anim.speed;
				if (anim.keypoint) {
					for (let i:number = 0; i < anim.keypoint.length; i++) {
						anim.keypoint[i] /= anim.speed;
					}
				}
				if (!this._map_anim.hasOwnProperty(name)) {
					this._map_anim[name] = {};
				}
				this._map_anim[name][type] = anim;
			});
		}

		//根据动作名字和模型名字获得动作配置
		public static get_anim_config(name:string, type:string):iModelAnimation {
			if (!this._map_anim[name]) return null;
			return this._map_anim[name][type];
		}
	}
}