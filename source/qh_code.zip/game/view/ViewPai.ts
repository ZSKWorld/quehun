/**
* name 
*/
module view{
	export enum ERevealState {
		None = 0,
		reveal = 1, //盖住
		self = 2, // 描边可一件
	}
	export class ViewPai {
		public val: mjcore.MJPai = null;
		public model: Laya.Sprite3D = null;
		public mesh: Laya.MeshSprite3D = null;
		public ismoqie: boolean = false; // 是否为摸切牌
		public ispaopai: boolean = false; // 是否为炮牌
		public is_open: boolean = false;
		public isxuezhanhu: boolean =  false;
		public is_gap:boolean = false;
		private isDora: boolean = false;
		public effect_parent: Laya.Sprite3D = null; // 阴影鸣牌指示等需要翻转特效的父节点
		public revealState: ERevealState = ERevealState.None; // 0 无
		public contianer_touming_touying:Laya.Sprite3D; // 透明牌的投影
		private is_tianming_yellow: boolean; // 天命模式标黄
		

		constructor(_val:mjcore.MJPai, _model: Laya.Sprite3D, need_refresh_dora: boolean = true) {
			this.val = _val;
			this.model = _model;
			this.effect_parent = this.model.getChildByName('effect') as Laya.Sprite3D;
			this.isDora = false;
			
			if (_val.touming && !DesktopMgr.Inst.is_tianming_mode()) {
				this.contianer_touming_touying = this.model.getChildByName('touming').getChildByName('touying') as Laya.Sprite3D;
				this.contianer_touming_touying.active = false;
				this.mesh = this.model as Laya.MeshSprite3D;
			} else {
				this.mesh = this.model.getChildAt(0) as Laya.MeshSprite3D;
				if (this.mesh.meshRender.sharedMaterials.length <= 1) {
					this.mesh = this.model as Laya.MeshSprite3D;
				}
			}
			if (need_refresh_dora) {
				this.RefreshDora();
			}
		}

		public SetTianMingYellow(y: boolean) {
			this.is_tianming_yellow = y;
			this.OnChoosedPai();
		}
		public ShowUp(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.7, 0, 0, 0.7);
			this.model.transform.localRotationEuler = new Laya.Vector3(90, 0, 0); 
		}

		public ShowBack(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0, -0.7, -0.7, 0);
			this.model.transform.localRotationEuler = new Laya.Vector3(-90, 0, 180);
			this.effect_parent.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
		}

		public ShowRot(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.5, -0.5, 0.5, 0.5);
			this.model.transform.localRotationEuler = new Laya.Vector3(90, -90, 0);
		}

		public ShowStand(): void {
			// this.model.transform.localRotation = new Laya.Quaternion(0.5, -0.5, 0.5, 0.5);
			this.model.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
		}

		public RefreshDora(): void {
			if (!DesktopMgr.bianjietishi) return;
			if (this.isDora) return ;
			if (this.val.dora) this.isDora = true;
			if (!this.isDora) {
				for (let i:number = 0; i < DesktopMgr.Inst.dora.length; i++) {
					if (mjcore.MJPai.DoraMet(this.val, DesktopMgr.Inst.dora[i])) {
						this.isDora = true;
						break;
					}
				}
			}
		
			if (this.isDora) {
				let effect:Laya.Sprite3D = DesktopMgr.Inst.effect_dora3D.clone();
				this.model.addChild(effect);
				effect.transform.localPosition = new Laya.Vector3(0, 0, 0);
				effect.transform.localScale = new Laya.Vector3(1, 1, 1);
				effect.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				effect.active = true;
				let runuv:anim.RunUV = (effect.getChildAt(0) as Laya.Sprite3D).addComponent(anim.RunUV) as anim.RunUV;

				if (this.contianer_touming_touying) {
					let effect1:Laya.Sprite3D = DesktopMgr.Inst.effect_dora3D_touying.clone();
					this.contianer_touming_touying.addChild(effect1);
					effect1.transform.localPosition = new Laya.Vector3(0, 0, 0);
					effect1.transform.localScale = new Laya.Vector3(1, 1, 1);
					effect1.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					effect1.active = true;
					(effect1.getChildAt(0) as Laya.Sprite3D).addComponent(anim.RunUV) as anim.RunUV;
				}
			}
		}

		// 牌谱中将牌竖起来时移除dora特效
		public RemoveDora() {
			if (!this.isDora) return;
			if (this.is_open || this.val.touming) return;
			this.isDora = false;
			if (this.model.getChildByName('effect_dora'))
				this.model.removeChildByName('effect_dora');
		}

		public ResetShow(): void {
			this.setMeshColor(this.GetDefaultColor());
			if (this.contianer_touming_touying)
				((this.contianer_touming_touying.getChildByName('bg') as Laya.MeshSprite3D).meshRender.material as Laya.BlinnPhongMaterial).albedoColor = this.GetDefaultColor();
		}

		public OnChoosedPai(): void {
			if (!DesktopMgr.bianjietishi || this.revealState == ERevealState.reveal) {
				this.ResetShow();
				return;
			}

			var pai:mjcore.MJPai = DesktopMgr.Inst.choosed_pai;
			let color:Laya.Vector4 = null; 
			if (pai == null || mjcore.MJPai.Distance(this.val, pai) != 0) {
				let alpha = this.revealState == ERevealState.self ? 0.6 : 1;
				if (this.isxuezhanhu) {
					color = new Laya.Vector4(1, 0.78, 0.78, alpha);
				} else if (this.ispaopai) {
					color = new Laya.Vector4(1, 0.78, 0.78, alpha);
				} else if (this.is_gap) {
					color = new Laya.Vector4(0.6, 0.6, 0.6, alpha);
				} else if (this.ismoqie) {
					color = new Laya.Vector4(0.8, 0.8, 0.8, alpha);
				} else {
					color = this.GetDefaultColor();
				}
			} else {
				color = new Laya.Vector4(0.615, 0.827, 0.976, 1);
			}
			this.setMeshColor(color);
			if (this.contianer_touming_touying)
				((this.contianer_touming_touying.getChildByName('bg') as Laya.MeshSprite3D).meshRender.sharedMaterial as Laya.BlinnPhongMaterial).albedoColor = color;
		}

		private GetDefaultColor(): Laya.Vector4 {
			let _yellow:boolean = false;
			let alpha = this.revealState == ERevealState.self ? 0.6 : 1;
			if (this.is_tianming_yellow) {
				_yellow = true;
			} else if (!DesktopMgr.Inst.is_open_hand()) {
				if (DesktopMgr.Inst.mode == EMJMode.live_broadcast || DesktopMgr.Inst.mode == EMJMode.paipu) {
					if (this.is_open && DesktopMgr.Inst.record_show_hand) _yellow = true;
				}
			}
			if (_yellow) return new Laya.Vector4(1, 0.917, 0.663, alpha);
			return new Laya.Vector4(1, 1, 1, alpha);
		}

		public SetRevealState(state: ERevealState) {
			if (this.revealState == state) return;
			this.revealState = state;
			let scale = this.model.transform.localScale.clone();
			let mesh:Laya.MeshSprite3D = this.mesh;
			let _now_mat: caps.BaseMaterial = mesh.meshRender.sharedMaterial as caps.BaseMaterial;
			let self_reveal: boolean =  false;
			if (state == ERevealState.None) {
               
				scale.x = Math.abs(scale.x);
				scale.z = Math.abs(scale.z);
				this.model.transform.localScale = scale;
				this.effect_parent.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			} else if (state == ERevealState.reveal) {
               
				this.effect_parent.transform.localRotationEuler = new Laya.Vector3(180, 0, 0);
				scale.z = -Math.abs(scale.z);
				scale.x = -Math.abs(scale.x);
				this.model.transform.localScale = scale;
			} else {
				self_reveal = true;
				this.effect_parent.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
				scale.z = Math.abs(scale.z);
				scale.x = Math.abs(scale.x);
				this.model.transform.localScale = scale;
			}
			if (self_reveal) {
				if (this.mesh.meshRender.sharedMaterials.length > 1) {
					let new_color: Laya.Vector4 = (this.mesh.meshRender.sharedMaterials[0] as caps.BaseMaterial).getColor(caps.Cartoon.COLOR);
					for (let mat of this.mesh.meshRender.sharedMaterials) {
						let _mat = mat as caps.BaseMaterial;
						_mat.renderQueue = 3000;
						_mat.blend = 1;
						_mat.srcBlend = 770;
						_mat.dstBlend = 771;
						_mat.setNumber(caps.Cartoon_Alpha.ALPHA, 0.6);
					}
				} else {
					let _mat = this.mesh.meshRender.sharedMaterial as caps.BaseMaterial;
					_mat.srcBlend = 770;
					_mat.dstBlend = 771;
					_mat.renderQueue = 3000;
					_mat.blend = 1;
					_mat.setNumber(caps.Cartoon_Alpha.ALPHA, 0.6);
				}
			} else {
				if (this.mesh.meshRender.sharedMaterials.length > 1) {
					let new_color: Laya.Vector4 = (this.mesh.meshRender.sharedMaterials[0] as caps.BaseMaterial).getColor(caps.Cartoon.COLOR);
					new_color.w = 1;
					for (let mat of this.mesh.meshRender.sharedMaterials) {
						let _mat = mat as caps.BaseMaterial;
						_mat.blend = 0;
						_mat.srcBlend = 1;
						_mat.dstBlend = 0;
						_mat.renderQueue = 2000;
						_mat.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
					}
				} else {
					let _mat = this.mesh.meshRender.sharedMaterial as caps.BaseMaterial;
					_mat.srcBlend = 1;
					_mat.dstBlend = 0;
					_mat.renderQueue = 2000;
					_mat.blend = 0;
					_mat.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
				}
			}
		}

		// 修改牌实际值
		public ChangeVal(pai:mjcore.MJPai) {
			if (mjcore.MJPai.isSame(pai, this.val)) return;
			this.val = pai;
			let localPos = this.model.transform.localPosition;
			let localScale = this.model.transform.localScale;
			let parent = this.model.parent;
			let localRotation = this.model.transform.localRotationEuler;
			let model = DesktopMgr.Inst.CreatePai3D(pai);
			parent.addChild(model);
			model.transform.localPosition = localPos;
			model.transform.localScale = localScale;
			model.transform.localRotationEuler = localRotation;
			model.addChild(this.effect_parent);
			this.model.destroy();
			this.model = model;
			if (pai.touming && !DesktopMgr.Inst.is_tianming_mode()) {
				this.mesh = this.model as Laya.MeshSprite3D;
			} else {
				this.mesh = this.model.getChildAt(0) as Laya.MeshSprite3D;
				if (this.mesh.meshRender.sharedMaterials.length <= 1) {
					this.mesh = this.model as Laya.MeshSprite3D;
				}
			}
			this.RefreshDora();
			this.OnChoosedPai();
		}

		// 播放翻转动画
		public PlayRevealFailedAnim(doanim:boolean = true) {
			// 隐藏阴影

			// Laya.Tween.to(this.model.transform, {localRotationEuler: rot}, 2000);
			if (!doanim || this.revealState == ERevealState.self) {
				this.SetRevealState(ERevealState.None);
				return;
			}
			if (this.revealState == ERevealState.None) return;
			view.AudioMgr.PlayAudio(265);
			this.effect_parent.active = false;
			let scale = this.model.transform.localScale.clone();
			

			let rot = this.model.transform.localRotationEuler.clone();
			this.model.transform.localRotationEuler = new Laya.Vector3(rot.x + (scale.x < 0 ? 180: 0), rot.y, rot.z + (scale.z < 0 ? 180: 0));
			rot = new Laya.Vector3(rot.x + (scale.x < 0 ? 0: 180), rot.y, rot.z + (scale.z < 0 ? 0: 180));
			scale.z = Math.abs(scale.z);
			scale.x = Math.abs(scale.x);
			this.model.transform.localScale = scale;
			
			let start_time = Laya.timer.currTimer;
			let origin_pos: Laya.Vector3 = this.model.transform.localPosition.clone();
			let anim = () => {
				if (!this.model || !this.model.transform) {
					Laya.timer.clear(this, anim);
					return;
				}
				let t: number = Laya.timer.currTimer - start_time;
				
				if (t < 90) {
					this.model.transform.localPosition = new Laya.Vector3(origin_pos.x, origin_pos.y - 0.03 * t / 90, origin_pos.z);
				} else if (t < 290) {
					this.model.transform.localPosition = new Laya.Vector3(origin_pos.x, origin_pos.y - 0.03, origin_pos.z);
					this.model.transform.localRotationEuler = new Laya.Vector3(rot.x + (290 - t) / 200 * 180, rot.y, rot.z + (290 - t) / 200 * 180);
				} else if (t < 380) {
					this.model.transform.localPosition = new Laya.Vector3(origin_pos.x, origin_pos.y - 0.03 * (380 - t) / 90, origin_pos.z);
					this.model.transform.localRotationEuler = rot;
				} else {
					this.model.transform.localRotationEuler = rot;
					Laya.timer.clear(this, anim);
					this.model.transform.localPosition = origin_pos;
					this.SetRevealState(ERevealState.None);
					this.effect_parent.active = true;
				}

			};
			Laya.timer.frameLoop(1, this, anim);
		}

		public ResetAllTimer() {
			Laya.timer.clearAll(this);
		}


		private setMeshColor(color: Laya.Vector4) {
			if (this.mesh.meshRender.sharedMaterials.length > 1) {
				for (let mat of this.mesh.meshRender.sharedMaterials) {
					(mat as caps.BaseMaterial).setColor(caps.Cartoon.COLOR, color);
				}
			} else {
				(this.mesh.meshRender.sharedMaterial as caps.BaseMaterial).setColor(caps.Cartoon.COLOR, color);
			}
		}
	}
}