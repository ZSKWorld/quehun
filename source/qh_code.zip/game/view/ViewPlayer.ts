/**
* name 
*/
module view{
	const handRenderQueue = 3700; //yu: 2411版本起约定了立直和牌特效的层级，约定手的模型为3700
	export class ViewPlayer extends Laya.Script {
		public desktop: DesktopMgr = null;
		public seat: number = 0; // -1代表没坐人，比如3麻空出来的位置
		public trans_hand: Laya.Sprite3D = null;
		public trans_ind: Laya.Sprite3D = null;
		public trans_dir: Laya.MeshSprite3D = null;
		public trans_man: Laya.Sprite3D = null;
		public trans_liqi: Laya.Sprite3D = null;
		public trans_beishui: Laya.Sprite3D = null;
		public container_score: Laya.Sprite3D = null;
		public trans_scores: Array<Laya.MeshSprite3D> = null;
		public hand3d: Laya.Sprite3D = null;
		protected handEffect3d: Laya.Sprite3D = null;
		private _hand_models: Array<Laya.Sprite3D> = [];
		private _anim_hands: Array<Laya.Animator> = [];
		public trans_muyu: Laya.Sprite3D = null;
		public trans_reveal: Laya.Sprite3D = null;
		private transTribute: Laya.Sprite3D = null;

		public container_qipai: Block_QiPai = null;
		public container_ming: Block_Ming = null;
		public container_babei: Block_Babei = null;
		public container_huansanzhang: Block_HuanSanZhang = null;
		public containerTribute: Block_Tribute = null;
		public pai_xuezhan_mid_zimo:mjcore.MJPai = null;

		public score:number = 0;
		public duringShowDetla:boolean = false;
		private anim_id:number = 0;
		private trans_liqi_position:Laya.Vector3 = null;
		private trans_liqi_scale:Laya.Vector3 = null;
		
		private liqibang:Laya.Sprite3D = null;
		private liqibang_effects:Object = {};
		private effectBeiShui: game.EffectBase[] = [];
		public already_xuezhan_hule_state:number = 0;//0 未胡，1自摸，2荣胡
		public gap_type:number = -1; 
		public hand_type:string = 'hand_human';

		constructor() {
			super();
		}

		public Init(_desktop:DesktopMgr, _seat:number, _poss:Laya.Sprite3D): void {
			this.desktop = _desktop;
			this.seat = _seat;
			let _hand:Laya.Sprite3D = _poss.getChildByName('pai_' + (_seat + 1)).getChildAt(0) as Laya.Sprite3D;
			let _paihai:Laya.Sprite3D = _poss.getChildByName('hai_' + (_seat + 1)).getChildAt(0) as Laya.Sprite3D;
			let _ming:Laya.Sprite3D = _poss.getChildByName('ming_' + (_seat + 1)).getChildAt(0) as Laya.Sprite3D;
			let _man:Laya.Sprite3D = _poss.getChildByName('man_' + (_seat + 1)) as Laya.Sprite3D;
			let _babei:Laya.Sprite3D = _poss.getChildByName('babei_' + (_seat + 1)).getChildAt(0) as Laya.Sprite3D;
			let _huansanzhang:Laya.Sprite3D = _poss.getChildByName('huansanzhang_' + (_seat + 1)) as Laya.Sprite3D;
			for (let i:number = 0; i < _hand.parent.numChildren; i++) (_hand.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			for (let i:number = 0; i < _ming.parent.numChildren; i++) (_ming.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			for (let i:number = 0; i < _paihai.parent.numChildren; i++) (_paihai.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			for (let i:number = 0; i < _babei.parent.numChildren; i++) (_babei.parent.getChildAt(i) as Laya.Sprite3D).active = false;
			for (let i:number = 0; i < _huansanzhang.numChildren; i++) (_huansanzhang.getChildAt(i) as Laya.Sprite3D).active = false;
			this.trans_hand = _hand;
			this.trans_man = _man;
			this.container_qipai = new Block_QiPai(_paihai, this);
			this.container_ming = new Block_Ming(_ming, this);
			this.container_babei = new Block_Babei(_babei, this);
			this.container_huansanzhang = new Block_HuanSanZhang(_huansanzhang, this);
			this.transTribute = new Laya.Sprite3D();
			this.transTribute.name = 'tribute_' + (_seat + 1);
			_poss.addChild(this.transTribute);
			this.transTribute.transform.localPosition = new Laya.Vector3(0, 0, 0);
			this.transTribute.transform.localRotationEuler = new Laya.Vector3(0, 90 * _seat, 0);

			this.containerTribute = new Block_Tribute(this.transTribute, this);
			this.trans_liqi = this.trans_man.getChildByName('liqi') as Laya.Sprite3D;
			this.trans_liqi.active = false;
			this.trans_liqi_position = this.trans_liqi.transform.localPosition;
			this.trans_liqi_scale = this.trans_liqi.transform.localScale;
			this.trans_dir = this.trans_man.getChildByName('dir') as Laya.MeshSprite3D;
			this.trans_beishui = this.trans_man.getChildByName('beishui') as Laya.Sprite3D;
			this.trans_ind = this.trans_man.getChildByName('ind') as Laya.MeshSprite3D;
			this.trans_muyu = this.trans_man.getChildByName('muyu') as Laya.MeshSprite3D;
			this.trans_reveal = this.trans_man.getChildByName('reveal') as Laya.MeshSprite3D;
			let container_scores:Laya.Sprite3D = this.trans_man.getChildByName('score') as Laya.Sprite3D;
			this.container_score = container_scores;
			this.trans_scores = new Array<Laya.MeshSprite3D>();
			for (let i:number = 0; i < 10; i++) {
				this.trans_scores.push(container_scores.getChildByName(i.toString()) as Laya.MeshSprite3D);
			}
			
			this.hand3d = _poss.getChildByName('hand_' + (_seat + 1).toString()) as Laya.Sprite3D;
			this.hand3d.active = false;
			this.SetScore(25000, 25000);
			this.RefreshDir();
			if (GameMgr.client_language == 'kr') {
				let kr_tex_path = 'scene/Assets/Resource/table/tablemid/';
				let mat = this.trans_dir.meshRender.material as Laya.BlinnPhongMaterial;
				mat.albedoTexture = Laya.Loader.getRes(kr_tex_path + 'feng_kr.png');
			}
		}

		public onInitRoom(seat:number) {
			this.seat = seat;
			if (this.seat != -1) {
				this.trans_man.active = true;
				this.create_liqibang();
				this.create_hand();
				this.onLiQiStateChange(false);
			} else {
				this.trans_man.active = false;
			}
			this.initSpecialModeEffect();
		}

		public initSpecialModeEffect() {
			let textureScore = Laya.loader.getRes('scene/Assets/Resource/table/tablemid/score.png');
			if (this.desktop.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
				textureScore = Laya.loader.getRes('scene/Assets/Resource/table/tablemid/xiakeshang_score.png');
			}
			for (let i = 0; i < this.trans_scores.length; i++) {
				(this.trans_scores[i].meshRender.material as Laya.BlinnPhongMaterial).albedoTexture = textureScore;
			}
			if (this.desktop.is_beishuizhizhan_mode()) {
				if (this.effectBeiShui.length == 0) {
					for (let i = 1; i <= 2; i++) {
						let url: string = `scene/effect_beishuizhizhan_feng${i}.lh`;
						let effectBeiShui = new game.EffectBase(url);
						this.effectBeiShui.push(effectBeiShui);
						this.trans_beishui.addChild(effectBeiShui.root);
					}
				}
				this.effectBeiShui.forEach((effect) => {
					effect.root.active = false;
					Laya.timer.clearAll(effect);
				});
			}
		}

		public create_liqibang() {
			if (this.liqibang) {
				this.liqibang.destroy(true);
				this.liqibang = null;
			}
			let liqibang = 'scene/liqi_default.lh';
			let liqibangResName = "";
			let liqibang_id:number = DesktopMgr.Inst.player_effects[this.seat][game.EView.liqibang];
			if (liqibang_id) {
				let d_view = cfg.item_definition.view.get(liqibang_id);
				if (d_view) {
					liqibang = `scene/${ d_view.res_name }.lh`;
					liqibangResName = d_view.res_name;
				}
			}


			this.liqibang = (Laya.loader.getRes(liqibang) as Laya.Sprite3D).clone();
			if (liqibangResName == "liqi_26dj") {
				let position = new Laya.Vector3();
				let rotation = new Laya.Quaternion();
				const seat = DesktopMgr.Inst.seat2LocalPosition(this.seat);
				if (seat == 2) {
					position = new Laya.Vector3(0, 0.00476, 0.002);
					rotation = new Laya.Quaternion(0.4436671, -0.05289306, 0.005422511, -0.894613);
				} else if (seat == 0) {
					position = new Laya.Vector3(0, 0, 0.005);
				}
				const child = this.liqibang.getChildAt(0).getChildByName("fbx_riichistick") as Laya.Sprite3D;
				child.transform.localPosition = position;
				child.transform.localRotation = rotation;
			}

			this.trans_liqi.addChild(this.liqibang);
			this.liqibang.transform.localPosition = new Laya.Vector3(0, 0, 0);
			this.liqibang.transform.localScale = new Laya.Vector3(1, 1, 1);
			this.liqibang.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
			this.liqibang.active = true;
			this.liqibang_effects = {};
			let outfitConfig = cfg.outfit_config.liqi.get(liqibang_id);
			if (outfitConfig) {
				if (outfitConfig.hide_direction) {
					let direction = this.liqibang.getChildAt(0).getChildByName('direction') as Laya.Sprite3D;
					if (direction) {
						let seats = outfitConfig.hide_direction.split(',').map(v => Number(v));
						direction.active = seats[DesktopMgr.Inst.seat2LocalPosition(this.seat)] == 1;
					}
				}
			}
			let dfs_change = (root) => {
				if (root.name == 'shadow' || root.name == 'original_obj') return;
				if (outfitConfig && outfitConfig.hide_direction && root.name == 'direction') return;
				let s_name:string = root.name;
				if (s_name.substr(0, 7) == 'effect_') {
					this.liqibang_effects[s_name.substr(7)] = root;
					return;
				}
				if (root instanceof Laya.MeshSprite3D) {
					let mesh:Laya.MeshSprite3D = root as Laya.MeshSprite3D;
					if (mesh.meshRender && mesh.meshRender.sharedMaterial) {
						let mat_cartoon:caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
						mat_cartoon.setTexture(caps.Cartoon.TEXTURE, (mesh.meshRender.material as Laya.BlinnPhongMaterial).albedoTexture);
						mat_cartoon.setNumber(caps.Cartoon.SPLIT, 0.4);
						mat_cartoon.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
						mat_cartoon.setColor(caps.Cartoon.COLOR_UNLIGHT, new Laya.Vector3(1, 1, 1));
						mat_cartoon.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
						mesh.meshRender.sharedMaterial = mat_cartoon;
					}
				}
				for (let i:number = 0; i < root.numChildren; i++) {
					dfs_change(root.getChildAt(i));
				}
			}
			if (liqibang_id != 308028) {
				dfs_change(this.liqibang.getChildAt(0));
			}
			
		}

		public create_hand() {
			let hand_type:string = '';
			let hand_id:number = DesktopMgr.Inst.player_effects[this.seat][game.EView.hand_model];
			let d_view = cfg.item_definition.view.get(hand_id);
			hand_type = d_view.res_name;
			
			this.hand_type = hand_type;

			this._anim_hands = [];
			if (this._hand_models) {
				for (let i:number = 0; i < this._hand_models.length; i++) {
					this._hand_models[i].destroy(true);
				}
				this._hand_models = [];
			}

			let _path: string = 'scene/' + hand_type + '.lh';
			if (d_view.hand_version == 2) {
				const position = DesktopMgr.Inst.seat2LocalPosition(this.seat) + 1;
				_path = `scene/${hand_type}_${position}.lh`;
			}
			let _handls:Laya.Sprite3D = Laya.loader.getRes(_path) as Laya.Sprite3D;
			if (_handls.getChildAt(0).getChildByName('node_liqibang').getChildByName('p')) {
				(_handls.getChildAt(0).getChildByName('node_liqibang').getChildByName('p') as Laya.Sprite3D).destroy(true);
			}
			if (_handls.getChildAt(0).getChildByName('node_tile').getChildByName('p')) {
				(_handls.getChildAt(0).getChildByName('node_tile').getChildByName('p') as Laya.Sprite3D).destroy(true);
			}
			const nodeEffect = _handls.getChildAt(0).getChildByName('node_effect');
			if (nodeEffect && nodeEffect.getChildByName('p'))
				nodeEffect.getChildByName('p').destroy(true);


			let _hand:Laya.Sprite3D = (_handls.getChildAt(0) as Laya.Sprite3D).clone();
			this.handEffect3d = _hand.getChildByName('node_effect') as Laya.Sprite3D;
			this.hand3d.addChild(_hand);
			_hand.transform.localPosition = new Laya.Vector3(0, 0, 0);
			_hand.transform.localScale = new Laya.Vector3(0.9, 0.9, 0.9);
			_hand.transform.localRotation = new Laya.Quaternion(0, 0, 0, 1);
			this._anim_hands = [_hand.getComponentByType(Laya.Animator) as Laya.Animator];
			this._hand_models =[_hand];
			if (!d_view.hand_version) {
				{
					let unlight_color: Laya.Vector3 = new Laya.Vector3(0.9725, 0.9137, 0.937);
					
					if (hand_type == 'hand_cat_blue') {
						unlight_color = new Laya.Vector3(216 / 255, 210 / 255, 206 / 255);
					}
					

					let handmesh:Laya.SkinnedMeshSprite3D = _hand.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
					let mat0:caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
					mat0.setTexture(caps.Cartoon.TEXTURE, (handmesh.skinnedMeshRender.sharedMaterials[0] as Laya.BlinnPhongMaterial).albedoTexture);
					mat0.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
					mat0.setColor(caps.Cartoon.COLOR_UNLIGHT, unlight_color);
					mat0.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
					mat0.setNumber(caps.Cartoon.SPLIT, 0.4);
					
					{
						let neil:Laya.SkinnedMeshSprite3D = handmesh.getChildByName('neil') as Laya.SkinnedMeshSprite3D;
						if (neil) {
							let mat2:caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
							mat2.setTexture(caps.Cartoon.TEXTURE, (neil.skinnedMeshRender.sharedMaterials[0] as Laya.BlinnPhongMaterial).albedoTexture);
							mat2.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
							mat2.setColor(caps.Cartoon.COLOR_UNLIGHT, unlight_color);
							mat2.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
							mat2.setNumber(caps.Cartoon.SPLIT, 0.4);
							neil.skinnedMeshRender.sharedMaterials = [mat2];
							neil.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
						}
						
					}

					{
						let xiuzimesh:Laya.SkinnedMeshSprite3D = _hand.getChildByName('xiuzi') as Laya.SkinnedMeshSprite3D;
						if (xiuzimesh) {
							let mat2:caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
							mat2.setTexture(caps.Cartoon.TEXTURE, (xiuzimesh.skinnedMeshRender.sharedMaterials[0] as Laya.BlinnPhongMaterial).albedoTexture);
							mat2.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1.1, 1.1, 1.1));
							mat2.setColor(caps.Cartoon.COLOR_UNLIGHT, unlight_color);
							mat2.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
							mat2.setNumber(caps.Cartoon.SPLIT, 0.4);
							xiuzimesh.skinnedMeshRender.sharedMaterials = [mat2];
							xiuzimesh.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
						}
						
					}
					if (handmesh.skinnedMeshRender.sharedMaterials.length > 2) {
						const mats = [...handmesh.skinnedMeshRender.sharedMaterials];
						mats[0] = mat0;
						handmesh.skinnedMeshRender.sharedMaterials = mats;
					}
					else if (handmesh.skinnedMeshRender.sharedMaterials.length == 2) {
						let mat1:caps.BaseMaterial = new caps.BaseMaterial(caps.Cartoon.filename);
						mat1.setTexture(caps.Cartoon.TEXTURE, (handmesh.skinnedMeshRender.sharedMaterials[1] as Laya.BlinnPhongMaterial).albedoTexture);
						mat1.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
						mat1.setColor(caps.Cartoon.COLOR_UNLIGHT, unlight_color);
						mat1.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
						mat1.setNumber(caps.Cartoon.SPLIT, 0.4);
						handmesh.skinnedMeshRender.sharedMaterials = [mat0, mat1];
						handmesh.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
						handmesh.skinnedMeshRender.sharedMaterials[1].renderQueue = handRenderQueue;
					} else {
						handmesh.skinnedMeshRender.sharedMaterials = [mat0];
						handmesh.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
					}
				}
				{
					let out_line_color:Laya.Vector3 = new Laya.Vector3(0.6823, 0.447, 0.408);
					let out_line_alpha: number = 0.6;
					//特判蓝猫手描边
					if (hand_type == 'hand_cat_blue') {
						out_line_color = new Laya.Vector3(83 / 255, 65 / 255, 63 / 255);
						out_line_alpha = 0.9;
					}
					//特判saber手描边
					if (hand_type == 'hand_saber') {
						out_line_alpha = 1;
						out_line_color = new Laya.Vector3(79 / 255, 88 / 255, 103 / 255);
					}
					let hand2: Laya.Sprite3D = _hand.clone();
					_hand.addChild(hand2);
					(hand2.getChildByName('node_liqibang') as Laya.Sprite3D).destroy(true);
					(hand2.getChildByName('node_tile') as Laya.Sprite3D).destroy(true);
					if (hand2.getChildByName('Dum_Shadow')) {
						(hand2.getChildByName('Dum_Shadow') as Laya.Sprite3D).destroy(true);
					}
					if (hand2.getChildByName('Bone021')) {
						(hand2.getChildByName('Bone021') as Laya.Sprite3D).destroy(true);
					}
					if (hand2.getChildByName('node_effect')) {
						(hand2.getChildByName('node_effect') as Laya.Sprite3D).destroy(true);
					}
					_hand.addChild(hand2);
					hand2.transform.localPosition = new Laya.Vector3(0, 0, 0);
					hand2.transform.localScale = new Laya.Vector3(1, 1, 1);
					hand2.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
					let _handmesh:Laya.SkinnedMeshSprite3D = hand2.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
					let _mat0:caps.Material_Outline = new caps.Material_Outline(caps.Outline.filename);
					_mat0.setColor(caps.Outline.OUTLINE_COLOR, out_line_color);
					_mat0.setNumber(caps.Outline.OUTLINE_ALPHA, out_line_alpha);
					_mat0.setNumber(caps.Outline.OUTLINE, 0.001);
					let _mat1:caps.Material_Outline = new caps.Material_Outline(caps.Outline.filename);
					_mat1.setColor(caps.Outline.OUTLINE_COLOR, out_line_color);
					_mat1.setNumber(caps.Outline.OUTLINE_ALPHA, out_line_alpha);
					_mat1.setNumber(caps.Outline.OUTLINE, 0.001);
					{
						let xiuzimesh:Laya.SkinnedMeshSprite3D = hand2.getChildByName('xiuzi') as Laya.SkinnedMeshSprite3D;
						if (xiuzimesh) {
							let _mat2: caps.Material_Outline = new caps.Material_Outline(caps.Outline.filename);
							if (hand_type == 'hand_akagi') {
								_mat2.setColor(caps.Outline.OUTLINE_COLOR, Laya.Vector3.ZERO);
							} else {
								_mat2.setNumber(caps.Outline.OUTLINE_ALPHA, out_line_alpha);
							}
							_mat2.setNumber(caps.Outline.OUTLINE_ALPHA, out_line_alpha);
							_mat2.setNumber(caps.Outline.OUTLINE, 0.001);
							xiuzimesh.skinnedMeshRender.sharedMaterials = [_mat2];
							xiuzimesh.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
						}
						
					}
					_handmesh.skinnedMeshRender.sharedMaterials = [_mat0, _mat1];
					_handmesh.skinnedMeshRender.sharedMaterials[0].renderQueue = handRenderQueue;
					_handmesh.skinnedMeshRender.sharedMaterials[1].renderQueue = handRenderQueue;
					
					_handmesh.skinnedMeshRender.sharedMaterials.forEach((v: caps.Material_Outline) => {
						v.depthWrite = true;
						v.depthTest = Laya.BaseMaterial.DEPTHTEST_LESS;
					});
					this._anim_hands.push(hand2.getComponentByType(Laya.Animator) as Laya.Animator);
					this._hand_models.push(hand2);
				}
			} else if(d_view.hand_version == 1 || d_view.hand_version == 2) {
				let handmesh: Laya.SkinnedMeshSprite3D = _hand.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
				handmesh.skinnedMeshRender.sharedMaterials.forEach((v: Laya.BaseMaterial) => (v.renderQueue = handRenderQueue));
				{
					let hand2: Laya.Sprite3D = _hand.clone();
					_hand.addChild(hand2);
					(hand2.getChildByName('node_liqibang') as Laya.Sprite3D).destroy(true);
					(hand2.getChildByName('node_tile') as Laya.Sprite3D).destroy(true);
					if (hand2.getChildByName('Dum_Shadow')) {
						(hand2.getChildByName('Dum_Shadow') as Laya.Sprite3D).destroy(true);
					}
					if (hand2.getChildByName('Bone021')) {
						(hand2.getChildByName('Bone021') as Laya.Sprite3D).destroy(true);
					}
					if (hand2.getChildByName('node_effect')) {
						(hand2.getChildByName('node_effect') as Laya.Sprite3D).destroy(true);
					}
					hand2.transform.localPosition = new Laya.Vector3(0, 0, 0);
					hand2.transform.localScale = new Laya.Vector3(1, 1, 1);
					hand2.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);
					let _handmesh: Laya.SkinnedMeshSprite3D = hand2.getChildByName('hand') as Laya.SkinnedMeshSprite3D;
					const materials = handmesh.skinnedMeshRender.sharedMaterials.map((v: Laya.BaseMaterial) => v.clone()) as Laya.FxBRDFMaterial[];
					materials.forEach(v => {
						v.renderQueue = handRenderQueue;
						v.depthWrite = true;
						v.depthTest = Laya.BaseMaterial.DEPTHTEST_LESS;
						v._OutlineBounds = 0.001;
						v.cull = Laya.BaseMaterial.CULL_FRONT;
					});
					_handmesh.skinnedMeshRender.sharedMaterials = materials;

					this._anim_hands.push(hand2.getComponentByType(Laya.Animator) as Laya.Animator);
					this._hand_models.push(hand2);
					handmesh.skinnedMeshRender.sharedMaterials.forEach(v => {
						v._OutlineBounds = 0;
						v.cull = Laya.BaseMaterial.CULL_BACK;
					});
				}
			}
			this.hand3d.active = true;
			this.hand3d.transform.position = new Laya.Vector3(0, 0, 0);
			// (this.hand3d.getChildAt(0).getChildByName('node_tile') as Laya.Sprite3D).transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
			// (this.hand3d.getChildAt(0).getChildByName('node_liqibang') as Laya.Sprite3D).transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
		}

		public playHandAnimtion(anim:iModelAnimation) {
			this.hand3d.active = true;
			for (let i:number = 0; i < this._anim_hands.length; i++) {
				this._anim_hands[i].play(anim.name, anim.speed);
			}
			this.hand3d.transform.localScale = new Laya.Vector3(0.0001, 0.0001, 1);
			Laya.timer.frameOnce(1, this, ()=>{
				this.hand3d.transform.localScale = new Laya.Vector3(1, 1, 1);
			});
			this.anim_id++;
			let anim_id:number = this.anim_id;
			Laya.timer.once(anim.lifetime, this, ()=>{
				if (anim_id == this.anim_id) {
					this.hand3d.active = false;
				}
			});
		}

		public setSeat(seat:number) {
			this.seat = seat;
		}

		public Reset() {
			this.duringShowDetla = false;
			this.already_xuezhan_hule_state = 0;
			this.gap_type = -1;
			this.container_ming.Reset();
			this.container_qipai.Reset();
			this.container_babei.Reset();
			this.container_huansanzhang.Reset();
			this.pai_xuezhan_mid_zimo = null;
			this.trans_liqi.active = false;
			this.effectBeiShui.forEach((effect) => {
				effect.root.active = false;
				Laya.timer.clearAll(effect);
			});
			// this.trans_muyu.active = false;
			this.trans_reveal.active = false;
			if (this.hand3d) this.hand3d.active = false;
			Laya.timer.clearAll(this);
			this.anim_id = 0;
			this.onLiQiStateChange(false);
		}

		public Clear(){
			this.effectBeiShui.forEach((effect) => {
				Laya.timer.clearAll(effect);
				effect.destroy();
			});
			this.effectBeiShui = [];
		}

		public AddQiPai(pai:mjcore.MJPai, liqi:boolean, moqie:boolean, doanim:boolean = true, revealState:ERevealState = ERevealState.None): void {
			this.container_qipai.AddQiPai(pai, liqi, moqie, doanim, revealState);
		
		}

		// ==DevDebug Start==
		public previewLichiEffect(itemId: number, destroyDelay: number = 3000, onDestroy: Laya.Handler = null, revealState: ERevealState = ERevealState.None) {
			this.container_qipai.previewLichiEffect(itemId, destroyDelay, onDestroy, revealState);
		}
		// ==DevDebug End==

		public QiPaiPass(): void {
			this.container_qipai.QiPaiPass();
		}

		public QiPaiNoPass(): void {
			this.container_qipai.QiPaiNoPass();
		}

		public RevealFailed(pai:mjcore.MJPai, doanim:boolean = true): void {
			this.container_qipai.RevealFailed(pai, doanim);
		}

		public AddMing(ming:mjcore.MJMing, tile_states:Array<number>, doanim:boolean = true): void {
			this.container_ming.AddMing(ming, doanim);
		}

		public AddGang(pai:mjcore.MJPai, doanim:boolean = true): void {
			this.container_ming.AddGang(pai, doanim);
		}

		public AddBabei(pai:mjcore.MJPai, moqie:boolean, doanim:boolean = true): void {
			this.container_babei.AddBabei(pai, moqie, doanim);
		}

		public ShowSpecialLiqi(liqiData: game.ILiQiSuccess, doAnim: boolean = false) {
			if (DesktopMgr.Inst.is_beishuizhizhan_mode()) {
				let liqiType = liqiData.liqi_type_beishuizhizhan;
				if (this.seat == -1) return;
				let tex_path = GameMgr.client_language == 'en' ? 'scene/Assets/Resource/table/tablemid_en/' : 'scene/Assets/Resource/table/tablemid/';
				let mat = this.trans_dir.meshRender.material as Laya.BlinnPhongMaterial;
				if (!liqiType) {
					mat.albedoTexture = Laya.Loader.getRes(tex_path + (GameMgr.client_language == 'kr' ? 'feng_kr.png' : 'feng.png'));
				} else {
					let texUrl = tex_path + 'feng_beishui' + liqiType + (GameMgr.client_language == 'kr' ? '_kr.png' : '.png');
					mat.albedoTexture = Laya.Loader.getRes(texUrl);
				}
				let tilingOffset: Laya.Vector4 = new Laya.Vector4();
				let index: number = 0;
				if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) {
					index = (this.seat - DesktopMgr.Inst.index_ju + 3) % 3;
				} else {
					index = (this.seat - DesktopMgr.Inst.index_ju + 4) % 4;
				}
				tilingOffset.z = 0.25 * index;
				tilingOffset.w = 0;
				tilingOffset.x = 0.25;
				tilingOffset.y = 1;
				(this.trans_dir.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
				if (liqiType && this.effectBeiShui && this.effectBeiShui[liqiType - 1] && this.effectBeiShui[liqiType - 1].loaded) {
					let effect = this.effectBeiShui[liqiType - 1];
					let effectBeishui = effect.root;
					effectBeishui.active = true;
					let aniBeishui = (effectBeishui.getChildAt(0).getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
					aniBeishui.Play('hd027_jipai_02');
					Laya.timer.once(50 / 60 * 1000, effect, () => {
						aniBeishui.Play('hd027_jipai_01');
					})
				}
				view.DesktopMgr.Inst.SetBeiShuiZhiZhanLiqi(DesktopMgr.Inst.seat2LocalPosition(this.seat), liqiData.liqi_type_beishuizhizhan, false, doAnim);
			}
		}

		public ShowLiqi(liqiData: game.ILiQiSuccess, doAnim:boolean = true): void {
			if (doAnim) {
				this.hand3d.transform.position = this.trans_liqi.transform.position.clone();
				this.trans_liqi.active = false;
				this.hand3d.active = true;

				let anim = ModelAnimationController.get_anim_config('LiZhi', this.hand_type);
				this.playHandAnimtion(anim);
				Laya.timer.once(anim.keypoint[0], this, () => {
					this.trans_liqi.active = true;
					this.trans_man.addChild(this.trans_liqi);
					this.trans_liqi.transform.localPosition = this.trans_liqi_position;
					this.trans_liqi.transform.localScale = this.trans_liqi_scale;
					this.trans_liqi.transform.localRotation = new Laya.Quaternion(0, 0, 0, 1);
					// if (this.liqibang_anim) {
					// 	this.liqibang_anim.play('win', 1);
					// }
					this.PlayLiqibangEffect('idle');
					// Laya.timer.once(2000, this, ()=>{
					// 	if (this.liqibang_anim) {
					// 		this.liqibang_anim.play('defeat', 1);
					// 	}
					// });
					this.ShowSpecialLiqi(liqiData, doAnim);
				});
			} else {
				this.trans_liqi.transform.localPosition = this.trans_liqi_position;
				this.trans_liqi.transform.localScale = this.trans_liqi_scale;
				this.trans_liqi.active = true;
				// if (this.liqibang_anim) {
				// 	this.liqibang_anim.play('idle', 1);
				// }
				this.PlayLiqibangEffect('idle');
				this.ShowSpecialLiqi(liqiData, doAnim);
			}
			this.onLiQiStateChange(true);
		}

		public ShowLiqiFailed(doanim:boolean = true): void {
			this.container_qipai.LiqiFailed(doanim);
			this.onLiQiStateChange(false);
		}

		public hideLiqi() {
			this.trans_liqi.active = false;
		}

		public SetScore(self_score:number, mainrole_score:number): void {
			this.score = self_score;
			this.RefreshScore(mainrole_score);
		}

		public RefreshDir():void {
			if (this.seat == -1) return;
			//刷新时重置一下贴图
			let tex_path = GameMgr.client_language == 'en' ? 'scene/Assets/Resource/table/tablemid_en/' : 'scene/Assets/Resource/table/tablemid/';
			let mat = this.trans_dir.meshRender.material as Laya.BlinnPhongMaterial;
			mat.albedoTexture = Laya.Loader.getRes(tex_path + (GameMgr.client_language == 'kr' ? 'feng_kr.png' : 'feng.png'));
			let tilingOffset: Laya.Vector4 = new Laya.Vector4();
			let index:number = 0;
			if (DesktopMgr.Inst.rule_mode == ERuleMode.Liqi3) {
				index = (this.seat - DesktopMgr.Inst.index_ju + 3) % 3;
			} else {
				index = (this.seat - DesktopMgr.Inst.index_ju + 4) % 4;
			}
			tilingOffset.z = 0.25 * index;
			tilingOffset.w = 0;
			tilingOffset.x = 0.25;
			tilingOffset.y = 1;
			(this.trans_dir.meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
		}

		public RefreshScore(mainrole_score:number):void {
			if (this.seat == -1) {
				this.container_score.active = false;
			} else {
				this.container_score.active = true;
				let s_score:string = '';
				let yOffset:number = 0;
				 /** 分数字体有多少种颜色，常规对局是三种 */
				let countType: number = 3;
				if (this.duringShowDetla) {
					let n = this.score - mainrole_score;
					if (n > 0) {
						s_score = '+' + n.toString();
						yOffset = -0.33333;
					} else {
						s_score = n.toString();
						yOffset = -0.66667;
					}
				} else {
					s_score = this.score.toString();
					yOffset = 0;
				}
				if (this.desktop.isTargetSpecialMode(game.EMJGameRule.XiaKeShang)) {
					countType = 6;
					let oneHeight = 1 / countType;
					if (this.duringShowDetla) {
						let n = this.score - mainrole_score;
						if (n > 0) {
							yOffset = -oneHeight * 4;
						} else {
							yOffset = -oneHeight * 5;
						}
					} else {
						yOffset = -oneHeight * 3; //这个是常规模式下的字色，也是下克上x1的字色
						//有系数才分数颜色
						if (this.desktop.xiakeshangInfo && this.desktop.xiakeshangInfo.score_coefficients && this.desktop.xiakeshangInfo.score_coefficients[this.seat]) {
							let rate = this.desktop.xiakeshangInfo.score_coefficients[this.seat];
							yOffset = -oneHeight * (4 - rate);
						}
					}
				}
				for (let i:number = 0; i < s_score.length && i < this.trans_scores.length; i++) {
					let c:string = s_score[s_score.length - i - 1];
					let xOffset:number = 0;
					switch(c) {
						case '-' : xOffset = 0; break;
						case '+' : xOffset = 1; break;
						case '0' : xOffset = 2; break;
						case '1' : xOffset = 3; break;
						case '2' : xOffset = 4; break;
						case '3' : xOffset = 5; break;
						case '4' : xOffset = 6; break;
						case '5' : xOffset = 7; break;
						case '6' : xOffset = 8; break;
						case '7' : xOffset = 9; break;
						case '8' : xOffset = 10; break;
						case '9' : xOffset = 11; break;
					}
					xOffset /= 12;
					let tilingOffset:Laya.Vector4 = new Laya.Vector4();
					tilingOffset.z = xOffset;
					tilingOffset.w = yOffset;
					tilingOffset.x = 1 / 12;
					tilingOffset.y = 1 / countType;
					(this.trans_scores[i].meshRender.material as Laya.BlinnPhongMaterial).tilingOffset = tilingOffset;
					this.trans_scores[i].active = true;
				}
				for (let i:number = s_score.length; i < this.trans_scores.length; i++) {
					this.trans_scores[i].active = false;
				}
				let _sx:number = 0.05355;
				let _sy:number = 0.01512;
				if (s_score.length <= 6) {
					let pos = this.container_score.transform.localPosition.clone();
					pos.x = (-0.5325 + (s_score.length - 1) * 0.165 / 2) * _sx;
					this.container_score.transform.localPosition = pos;
					this.container_score.transform.localScale = new Laya.Vector3(_sx, _sy, 1);
				} else {
					let pos = this.container_score.transform.localPosition.clone();
					pos.x = -0.12 * _sx;
					this.container_score.transform.localPosition = pos;
					let scaleX:number = 0.56 + (10 - s_score.length) / 4 * (1 - 0.56);
					let scaleY:number = 0.9 + (10 - s_score.length) / 4 * (1 - 0.9);
					this.container_score.transform.localScale = new Laya.Vector3(scaleX * _sx, scaleY * _sy, 1);
				}
			}
		}

		public Hule(hands:Array<mjcore.MJPai>, hupai:mjcore.MJPai, zimo:boolean) {

		}

		public Huangpai(tingpai:boolean, hands:Array<mjcore.MJPai>, fast:boolean) {

		}

		public onXuezhanMidHule(is_zimo:boolean, hupai:mjcore.MJPai, fast:boolean) {
		}

		
		public onChuanmaNoTile(hands:Array<mjcore.MJPai>, fast:boolean) {
			if (this.already_xuezhan_hule_state) {
				this.onXuezhanEnd(hands, fast);
			} else {
				this.Huangpai(true, hands, fast);
			}
		}

		public onXuezhanEnd(hands:Array<mjcore.MJPai>, fast:boolean) {
		}

		public OnDoraRefresh(): void {
			this.container_qipai.OnDoraRefresh();
			this.container_ming.OnDoraRefresh();
			this.container_babei.OnDoraRefresh();
		}
		
		public OnChoosePai(): void {
			this.container_qipai.OnChoosedPai();
			this.container_ming.OnChoosedPai();
			this.container_babei.OnChoosedPai();
		}

		public PlaySound(sound:string, score_change: number = 0): void {
			let shout:string = '';
			switch(sound) {
				case 'act_chi':shout = 'chi';break;
				case 'act_drich':shout = 'lizhi';break;
				case 'act_rich':shout = 'lizhi';break;
				case 'act_kan':shout = 'gang';break;
				case 'act_pon':shout = 'peng';break;
				case 'act_babei':shout = 'babei';break;
				case 'act_drich_anpai':shout = 'anpailizhi'; sound = 'act_drich'; break;
				case 'act_rich_anpai':shout = 'anpailizhi'; sound = 'act_rich'; break;
				case 'act_unveil':shout = 'kaipai'; score_change = -2000; break;
				case 'act_locktile':shout = 'suoding'; score_change = -4000; break;
				case 'act_reveal':shout = 'anpai';break;
				case 'act_drich_beishui1':shout = 'lizhi5000'; sound = 'act_drich'; break;
				case 'act_drich_beishui2':shout = 'lizhi10000'; sound = 'act_drich'; break;
				case 'act_rich_beishui1':shout = 'lizhi5000'; sound = 'act_rich'; break;
				case 'act_rich_beishui2':shout = 'lizhi10000'; sound = 'act_rich'; break;
			}
			if (shout != '') {
				uiscript.UI_DesktopInfo.Inst.shout(DesktopMgr.Inst.seat2LocalPosition(this.seat), shout, this.desktop.player_datas[this.seat], score_change);
			}
			DesktopMgr.Inst.resetGameVoice();
			view.DeskAudioMgr.Inst.playCharSound(this.desktop.player_datas[this.seat]['character'], sound);
			if (shout == 'kaipai' || shout == 'suoding') {
				view.AudioMgr.PlayAudio(264);
			}
		}

		// 一小局结束，result:0-输，1-胡牌，2-流局
		public OnRoundEnd(result:number) {
			if (result == 0) {
				// if (this.liqibang_anim) this.liqibang_anim.play('defeat');
				this.PlayLiqibangEffect('defeat');
			} else if (result == 1) {
				// if (this.liqibang_anim) this.liqibang_anim.play('win');
				this.PlayLiqibangEffect('win');
			}
		}

		private PlayLiqibangEffect(name:String) {
			for (let k in this.liqibang_effects) {
				this.liqibang_effects[k].active = k == name;
			}
		}

		// 显示换三张
		public ShowHuanSanZhang(pais:Array<mjcore.MJPai>, change_type:number) {
			this.container_huansanzhang.show(pais, change_type);
		}

		public SetGapType(type:number) {
			this.gap_type = type;
			this.refreshGapType();
		}

		public refreshGapType() {

		}

		public getTianMingRate(): number {
			return 0;
		}

		private onLiQiStateChange(liqi:boolean) {
			if (this.handEffect3d)
				this.handEffect3d.active = false;	//对局中骨骼动画挂载特效有问题，待后续问题修复后使用
			const player_effects = DesktopMgr.Inst.player_effects;
			const hand_id = player_effects && player_effects[this.seat] && player_effects[this.seat][game.EView.hand_model] || 0;
			if (hand_id == 30990002) { //机械猫爪
				const hand = this.hand3d.getChildAt(0).getChildByName('hand') as Laya.SkinnedMeshSprite3D;
				const mats = hand._render.sharedMaterials as Laya.BaseMaterial[];
				const matsA = mats.filter(v => v && v.name && v.name.includes("skin_a"));
				const matsB = mats.filter(v => v && v.name && v.name.includes("skin_b"));
				const newMats = [mats[0], ...(liqi ? matsA : matsB), ...(liqi ? matsB : matsA)];
				hand._render.sharedMaterials = newMats;
			}
		}

		submitTile(submitInfo: game.ISubmitInfo, fast: boolean = false): void {
			if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.QiangDuoZhiZhan)) {
				this.containerTribute.submitTile(submitInfo);
			}
		}

		takeTile(fromInfos: game.ITakeInfo[], fast: boolean = false): void {
			if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.QiangDuoZhiZhan)) {
				if (!fast) {
					let showTiles: boolean = false;
					if (DesktopMgr.Inst.mode == EMJMode.play) {
						showTiles = DesktopMgr.Inst.tributeState == 1;
					} else {
						showTiles = view.DesktopMgr.Inst.record_show_hand || DesktopMgr.Inst.tributeState == 1;
					}
					this.containerTribute.takeTile(fromInfos, showTiles);
				} else {
					this.containerTribute.reset();
				}
			}
		}

		public submitHandTile(out_tiles: Array<string>, fast: boolean = false): void {
		}
		public takeHandTile(in_tiles: Array<string>, fast: boolean = false) {
		}
	}
}