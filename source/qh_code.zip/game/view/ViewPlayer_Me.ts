/**
* name 
*/
module view {

	interface IMouseInfo {
		inHandRange: boolean;
		index: number;
		x: number;
		y: number;
		pai: HandPaiPlane;
	}

	enum EHuanSanZhangState { none, choosing, waiting } // 无|选择中|选择完毕

	export class ViewPlayer_Me extends ViewPlayer {
		public static Inst: ViewPlayer_Me = null;

		/**用于鼠标检测的射线**/
		private ray: Laya.Ray;
		/**画矢量线的3D显示对象**/
		private phasorSprite3D: Laya.PhasorSpriter3D;
		/**碰撞信息**/
		private rayCastHit: Laya.RaycastHit;
		public _choose_pai: HandPaiPlane = null;
		private _mouse_in_pai: HandPaiPlane = null;
		private _mouse_in_start_time: number = -1;

		private handpool: Array<HandPaiPlane> = [];
		public hand: Array<HandPaiPlane> = [];
		public during_liqi: boolean = false;
		public liqiOperation: mjcore.E_PlayOperation = mjcore.E_PlayOperation.liqi; //注：这个值指立直的类型，不会为空，默认就是常规liqi操作
		public during_anpai: boolean = false;
		public during_anpailiqi: boolean = false;
		// public during_huansanzhang: boolean = false;
		public huansanzhang_state: EHuanSanZhangState = EHuanSanZhangState.none;
		private effect_click: Laya.Sprite3D = null;
		public trans_hand3D: Laya.Sprite3D = null;
		public trans_hand3DCover: Laya.Sprite3D = null;
		private _hand3d: Array<HandPai3D> = [];
		public can_discard: boolean = false;
		public last_tile: HandPaiPlane = null;
		private _prediscard_index: number = -1; //提前打出去的牌
		private mouse_downx: number = 0;
		private mouse_downy: number = 0;
		private mouse_downed: boolean = false;
		private during_drag: boolean = false;
		private click_on_choosed: boolean = false;
		private click_choosed_time: number = 0;
		private zd: number = 0;

		private xianggonged: boolean = false; //已经相公了，如果检测到手牌相公了会往服务器发送日志，但是频繁发送也不好
		private huansanzhang_tile: Array<HandPaiPlane> = []; // 换三张要换出去的牌

		constructor() {
			super();
			ViewPlayer_Me.Inst = this;
		}

		public InitMe(_desktop: DesktopMgr, _seat: number, _hand: Laya.Sprite3D, _poss: Laya.Sprite3D): void {
			super.Init(_desktop, _seat, _poss);
			let pai_templete: Laya.MeshSprite3D = _hand.getChildByName('pai') as Laya.MeshSprite3D;
			this.effect_click = _hand.getChildByName('effect_dianji') as Laya.Sprite3D;
			//this.effect_click.active = false;
			_hand.active = true;
			pai_templete.active = false;
			for (let i: number = 0; i < 18; i++) {
				let pai3D: Laya.MeshSprite3D = pai_templete.clone();
				_hand.addChild(pai3D);
				pai3D.transform.localPosition = new Laya.Vector3(0, 0, 0);
				pai3D.transform.localRotation = new Laya.Quaternion(0, 0, 0, 1);
				pai3D.transform.localScale = new Laya.Vector3(1, 1, 1);
				pai3D.active = false;
				var hm: HandPaiPlane = pai3D.addComponent(HandPaiPlane) as HandPaiPlane;
				this.handpool.push(hm);
			}
			//创建一条射线
			this.ray = new Laya.Ray(new Laya.Vector3(), new Laya.Vector3());
			//创建矢量3D精灵
			this.phasorSprite3D = new Laya.PhasorSpriter3D();
			//创建碰撞信息
			this.rayCastHit = new Laya.RaycastHit();
			//鼠标点击事件回调
			Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
			Laya.stage.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
			Laya.stage.on(Laya.Event.MOUSE_MOVE, this, this.onMouseMove);
			Laya.stage.on(Laya.Event.MOUSE_OUT, this, this.onMouseOut);

			this.trans_hand3D = _poss.getChildByName('pai_1') as Laya.Sprite3D;
			(this.trans_hand3D.getChildAt(0) as Laya.Sprite3D).active = false;
			this.trans_hand3D.active = false;
			this.trans_hand3DCover = _poss.getChildByName('pai_1_cover') as Laya.Sprite3D;
			(this.trans_hand3DCover.getChildAt(0) as Laya.Sprite3D).active = false;
			this.trans_hand3DCover.active = false;
		}

		private _AddHandPai(pai: mjcore.MJPai, is_open: boolean): HandPaiPlane {
			let p: HandPaiPlane = this.handpool.pop();
			p.Reset();
			p.SetVal(pai, is_open);
			p.z = this.zd;
			this.zd -= 0.02;
			if (view.DesktopMgr.Inst.mode != view.EMJMode.play) {
				p.ispaopai = DesktopMgr.Inst.isPaoPai(p.val);
				p.OnChoosedPai();
			}
			if (view.DesktopMgr.Inst.is_chuanma_mode()) {
				p.isGap = p.val.type == this.gap_type;
				p.OnChoosedPai();
			}
			this.hand.push(p);
			return p;
		}

		private _OnRemovePai(pai: HandPaiPlane): void {
			if (pai === this._choose_pai) {
				this._choose_pai = null;
				this.resetMouseState();
				// DesktopMgr.Inst.setChoosedPai(null);
			}
		}

		//直接删除
		private _RemovePai(pai: HandPaiPlane): void {
			for (let i: number = 0; i < this.hand.length; i++) {
				if (this.hand[i] === pai) {
					var tmp = this.hand[i];
					for (let j: number = i; j < this.hand.length - 1; j++) {
						this.hand[j] = this.hand[j + 1];
						this.hand[j].SetIndex(j, false, true);
					}
					this.hand.pop();

					this._OnRemovePai(tmp);
					tmp.Reset();
					this.handpool.push(tmp);
					break;
				}
			}

			// 删除时还原
			for (let hand of this.hand) {
				if (hand.mySelf) {
					hand.mySelf.active = true;
				}
			}
		}

		//根据牌的值删除手牌
		private _RemoveHandPai(pai: mjcore.MJPai, tile_state: number, moqie: boolean = true): boolean {
			let index: number = -1;

			if (tile_state == -1 || tile_state == 1) {
				if (!moqie) {
					for (let i: number = 0; i < this.hand.length; i++) {
						if (mjcore.MJPai.isSame(pai, this.hand[i].val) && this.hand[i].is_open) {
							index = i;
							break;
						}
					}
				} else {
					for (let i: number = this.hand.length - 1; i >= 0; i--) {
						if (mjcore.MJPai.isSame(pai, this.hand[i].val) && this.hand[i].is_open) {
							index = i;
							break;
						}
					}
				}

			}
			if (index == -1) {
				if (tile_state == -1 || tile_state == 0) {
					if (!moqie) {
						for (let i: number = 0; i < this.hand.length; i++) {
							if (mjcore.MJPai.isSame(pai, this.hand[i].val) && !this.hand[i].is_open) {
								index = i;
								break;
							}
						}
					} else {
						for (let i: number = this.hand.length - 1; i >= 0; i--) {
							if (mjcore.MJPai.isSame(pai, this.hand[i].val) && !this.hand[i].is_open) {
								index = i;
								break;
							}
						}
					}
				}
			}

			if (index != -1) {
				var tmp = this.hand[index];
				for (let j: number = index; j < this.hand.length - 1; j++) {
					this.hand[j] = this.hand[j + 1];
					this.hand[j].SetIndex(j, false, true);
				}
				this.hand.pop();

				this._OnRemovePai(tmp);
				tmp.Reset();
				this.handpool.push(tmp);
				return true;
			}
			return false;
		}

		public Reset() {
			super.Reset();
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].Reset();
				this.handpool.push(this.hand[i]);
			}
			this.hand = [];
			for (let i: number = 0; i < this._hand3d.length; i++) {
				this._hand3d[i].Destory();
			}
			this._hand3d = [];
			this.zd = 0;
			this.during_liqi = false;
			this.liqiOperation = mjcore.E_PlayOperation.liqi;
			this.during_anpailiqi = false;
			this.during_anpai = false;
			this.huansanzhang_state = EHuanSanZhangState.none;
			this.trans_hand3D.active = false;
			this.trans_hand3DCover.active = false;
			this.last_tile = null;
			this.can_discard = false;
			this._choose_pai = null;
			this._mouse_in_pai = null;
			this.xianggonged = false;
			this.resetMouseState();
			Laya.timer.clearAll(this);
		}

		public NewGame(hand: Array<mjcore.MJPai>, opened_tiles: Array<string>, opened_counts: Array<number>, fast: boolean): void {

			this.Reset();
			this.RefreshDir();
			let _hand: Array<{ pai: mjcore.MJPai, is_open: boolean }> = [];
			let open_map: Object = {};
			for (let i: number = 0; i < opened_tiles.length; i++) {
				open_map[opened_tiles[i]] = opened_counts[i];
			}
			for (let i: number = 0; i < hand.length; i++) {
				let p: any = {};
				p.pai = hand[i];
				let s_pai: string = hand[i].toString();
				if (open_map[s_pai]) {
					open_map[s_pai]--;
					p.is_open = true;
				} else {
					p.is_open = false;
				}
				_hand.push(p);
			}

			if (!fast) {
				// let randhands: Array<{ pai: mjcore.MJPai, is_open: boolean }> = [];
				// for (let i: number = 0; i < _hand.length; i++) {
				// 	let pre: number = Math.floor(Math.random() * i);
				// 	randhands.push(randhands[pre]);
				// 	randhands[pre] = _hand[i];
				// }
				// if (DesktopMgr.Inst.is_tianming_mode()) {
				// 	let index = 0;
				// 	for (let i: number = 0; i < randhands.length; i++) {
				// 		if (randhands[i].pai.touming) {
				// 			let pre = randhands[index];
				// 			randhands[index] = randhands[i];
				// 			randhands[i] = pre;
				// 			index++;
				// 		}
				// 	}
				// }
				let current_num: number = 0;
				for (let i: number = 0; i < 4; i++) {
					Laya.timer.once(i * 300, this, () => {
						for (let j: number = 0; j < 4; j++) {
							if (current_num >= _hand.length) break;
							current_num++;
							let p = this._AddHandPai(_hand[current_num - 1].pai, _hand[current_num - 1].is_open);
							p.SetIndex(current_num - 1, false, false);
							p.AnimNewTile();
						}
						AudioMgr.PlayAudio(216);
					});
				}
				Laya.timer.once(1200, this, () => {
					this.LiPai();
					this.last_tile = this.hand[this.hand.length - 1];
					if (this.hand.length == 14) this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
					this.pendingXiangGong(this.hand.length == 14, 'NewGame No fast');

					this.onSpecialModeHuanSanZhang();

				});
			} else {
				_hand = _hand.sort((a, b) => {
					let a_val: number = (a.pai.numValue() * 10 + (a.pai.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.pai.touming ? 1 : 0);
					let b_val: number = (b.pai.numValue() * 10 + (b.pai.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.pai.touming ? 1 : 0);
					return a_val - b_val;
				});
				for (let i: number = 0; i < _hand.length; i++) {
					let p = this._AddHandPai(_hand[i].pai, _hand[i].is_open);
					p.SetIndex(i, i == 14, false);
				}
				this.pendingXiangGong(this.hand.length == 14, 'NewGame fast');
			}

			Laya.timer.frameLoop(1, this, this.update);
		}

		public RecordNewGame(hand: Array<mjcore.MJPai>, opened_tiles: Array<string>, opened_counts: Array<number>): void {
			this.Reset();
			this.RefreshDir();

			let _hand: Array<{ pai: mjcore.MJPai, is_open: boolean }> = []
			let open_map: Object = {};
			for (let i: number = 0; i < opened_tiles.length; i++) {
				open_map[opened_tiles[i]] = opened_counts[i];
			}
			for (let i: number = 0; i < hand.length; i++) {
				let p: any = {};
				p.pai = hand[i];
				let s_pai: string = hand[i].toString();
				if (open_map[s_pai]) {
					open_map[s_pai]--;
					p.is_open = true;
				} else {
					p.is_open = false;
				}
				_hand.push(p);
			}
			_hand = _hand.sort((a, b) => {
				let a_val: number = (a.pai.numValue() * 10 + (a.pai.dora ? 0 : 1)) * 10 + (a.is_open ? 0 : 1) + (a.pai.touming ? 1 : 0);
				let b_val: number = (b.pai.numValue() * 10 + (b.pai.dora ? 0 : 1)) * 10 + (b.is_open ? 0 : 1) + (b.pai.touming ? 1 : 0);
				return a_val - b_val;
			});

			for (let i: number = 0; i < _hand.length; i++) {
				let p = this._AddHandPai(_hand[i].pai, _hand[i].is_open);
				p.SetIndex(i, i == 13, false);
			}
			this.pendingXiangGong(this.hand.length == 14, 'RecordNewGame');
			Laya.timer.frameLoop(1, this, this.update);
		}

		public TakePai(pai: mjcore.MJPai, is_open: boolean, doanim: boolean = true): void {
			app.Log.log('ViewPlayer_Me TakePai ' + pai.toString() + ' doanim:' + doanim);
			try {
				let p = this._AddHandPai(pai, is_open);
				p.SetIndex(this.hand.length - 1, true, false);
				if (doanim) p.AnimNewTile();
				this.last_tile = p;
				this.pendingXiangGong(true, 'TakePai');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'TakePai';
				_errorinfo['name'] = 'ViewPlayer_Me';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
			app.Log.log('ViewPlayer_Me TakePai end');
		}

		public onBabei(pai: mjcore.MJPai, is_open: boolean, fast: boolean) {
			let open = false;
			for (let pai of this.hand) {
				let val: mjcore.MJPai = pai.val;
				if (val.type == 3 && val.index == 4 && pai.is_open) {
					open = true;
					break;
				}
			}
			this.OnDiscardTile(pai, open, fast);
		}

		public OnDiscardTile(pai: mjcore.MJPai, is_open: boolean, fast: boolean, moqie: boolean = true): void {
			app.Log.log('ViewPlayer_Me OnDiscardTile ' + pai.toString() + ' fast:' + fast);
			try {
				if (this._prediscard_index >= 0 && this._prediscard_index < this.hand.length) {
					let _prediscard: mjcore.MJPai = this.hand[this._prediscard_index].val;
					if (mjcore.MJPai.isSame(this.hand[this._prediscard_index].val, pai) && (pai.touming || this.hand[this._prediscard_index].is_open == is_open)) {
						for (let pai of this.hand) {
							if (pai.index == this._prediscard_index) {
								this._RemovePai(pai);
								break;
							}
						}


					} else {
						this.revertAllPais();
						this._RemoveHandPai(pai, is_open ? 1 : 0, moqie);
					}
				} else {
					this._RemoveHandPai(pai, is_open ? 1 : 0, moqie);
				}
				this.LiPai(fast);
				this.last_tile = null;
				this._prediscard_index = -1;
				this.pendingXiangGong(false, 'OnDiscardTile');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'OnDiscardTile';
				_errorinfo['name'] = 'ViewPlayer_Me OnDiscardTile';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		//加杠
		public AddGang(pai: mjcore.MJPai, doanim: boolean = true): void {
			app.Log.log('ViewPlayer_Me AddGang ' + pai.toString() + ' doanim:' + doanim);
			try {
				super.AddGang(pai, doanim);
				for (let i: number = this.hand.length - 1; i >= 0; i--) {
					if (mjcore.MJPai.isSame(pai, this.hand[i].val, true)) {
						var tmp = this.hand[i];
						for (let j: number = i; j < this.hand.length - 1; j++) {
							this.hand[j] = this.hand[j + 1];
							this.hand[j].SetIndex(j, false, true);
						}
						this.hand.pop();
						this._OnRemovePai(tmp);
						tmp.Reset();
						this.handpool.push(tmp);
						break;
					}
				}
				this.LiPai();
				this.last_tile = null;
				this.pendingXiangGong(false, 'AddGang');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'AddGang';
				_errorinfo['class'] = 'ViewPlayer_Me';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		//理牌
		public LiPai(fast: boolean = false, force: boolean = false, lipaichange = false): void {
			if (!lipaichange) {
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].SelectEnd();
				}
			}
			
			if (!force && !DesktopMgr.Inst.auto_liqi && view.DesktopMgr.Inst.mode == view.EMJMode.play) return;
			this.hand.sort(HandPaiPlane.Cmp);
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].SetIndex(i, false, !fast);
				if (view.DesktopMgr.Inst.mode != view.EMJMode.play || view.DesktopMgr.Inst.is_chuanma_mode()) {
					this.hand[i].OnChoosedPai();
				}
			}
			// this.last_tile = null;
		}

		//副露
		public AddMing(ming: mjcore.MJMing, tile_states: Array<number>, doanim: boolean = true): void {
			app.Log.log('ViewPlayer_Me AddMing ' + ming.toString() + ' doanim:' + doanim);
			try {
				for (let i: number = 0; i < ming.pais.length; i++) {
					if (ming.from[i] == this.seat) {
						this._RemoveHandPai(ming.pais[i], -1);
					}
				}
				this.container_ming.AddMing(ming, doanim);
				this.LiPai();
				this.last_tile = null;
				this.pendingXiangGong(ming.type == mjcore.E_Ming.kezi || ming.type == mjcore.E_Ming.shunzi, 'AddMing');
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'AddMing';
				_errorinfo['class'] = 'ViewPlayer_Me';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public ChiTiSelect(pais: Array<mjcore.MJPai>): void {
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].ChiTiSelect(pais);
			}
		}

		//立直选择
		public LiQiSelect(pais: Array<mjcore.MJPai>, v: boolean, operation: mjcore.E_PlayOperation = mjcore.E_PlayOperation.liqi): void {
			this.liqiOperation = operation;
			this.during_liqi = v;
			for (let i: number = 0; i < this.hand.length; i++) {
				if (v) this.hand[i].LiqiSelect(pais);
				else this.hand[i].SelectEnd();
			}
		}

		public AnPaiLiQiSelect(pais: Array<mjcore.MJPai>, v: boolean): void {
			this.during_anpailiqi = v;
			for (let i: number = 0; i < this.hand.length; i++) {
				if (v) this.hand[i].LiqiSelect(pais);
				else this.hand[i].SelectEnd();
			}
		}

		public AnPaiSelect(v: boolean) {
			if (v) {
				// 如果是立直状态 直接丢
				if (this.trans_liqi.active) {
					DesktopMgr.Inst.Action_AnPai(this.last_tile.val, true, false, this.last_tile.is_open);
					return;
				}
			}
			this.during_anpai = v;
		}
		public HulePrepare(hands: Array<mjcore.MJPai>, hupai: mjcore.MJPai, zimo: boolean) {
			app.Log.log('ViewPlayer_Me HulePrepare ' + hupai.toString() + ' zimo:' + zimo);
			try {
				uiscript.UI_DesktopInfo.Inst.setZhenting(false);
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].Hule();
				}
				let hand3d: Array<HandPai3D> = [];
				for (let i: number = 0; i < hands.length; i++) {
					let p: HandPai3D = new HandPai3D(this.trans_hand3D);
					p.SetVal(hands[i], false);
					p.SetIndex(i, false);
					p.Stand(false);
					p.pai3D.SetTianMingYellow(view.DesktopMgr.Inst.is_tianming_mode() && hands[i].touming);
					hand3d.push(p);
				}
				this._hand3d = hand3d;
				this.trans_hand3D.active = true;
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'HulePrepare';
				_errorinfo['class'] = 'ViewPlayer_Me';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public Hule(hands: Array<mjcore.MJPai>, hupai: mjcore.MJPai, zimo: boolean) {
			app.Log.log('ViewPlayer_Me Hule ' + hupai.toString() + ' zimo:' + zimo);
			if (DesktopMgr.Inst.mode != EMJMode.play && !DesktopMgr.Inst.record_show_anim) {
				let length = this._hand3d.length;
				let fulldown_time: number = 100;
				Laya.timer.once(fulldown_time, this, () => {
					if (this._hand3d.length == 0) return;
					AudioMgr.PlayAudio(223);
					for (let i: number = 0; i < length; i++) {
						this._hand3d[i].DoAnim_FullDown();
					}
					if (zimo) {
						let p: HandPai3D = new HandPai3D(this.trans_hand3D);
						p.SetVal(hupai, false);
						p.SetIndex(this._hand3d.length, true);
						this._hand3d.push(p);
						p.pai3D.SetTianMingYellow(view.DesktopMgr.Inst.is_tianming_mode() && hupai.touming);
						p.FullDown();

						if (view.DesktopMgr.Inst.xuezhan) {
							p.pai3D.isxuezhanhu = true;
							p.pai3D.OnChoosedPai();
						}
						p.shadow.active = false;
						p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.15;
					}
				});

				return;
			}
			if (zimo) {
				let p: HandPai3D = new HandPai3D(this.trans_hand3D);
				p.SetVal(hupai, false);
				p.pai3D.SetTianMingYellow(view.DesktopMgr.Inst.is_tianming_mode() && hupai.touming);
				p.SetIndex(this._hand3d.length, true);
				this._hand3d.push(p);

				p.FullDown();
				if (view.DesktopMgr.Inst.xuezhan) {
					p.pai3D.isxuezhanhu = true;
					p.pai3D.OnChoosedPai();
				}
				p.shadow.active = false;
				p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.15;
				//甩牌动画
				{
					let pos: Laya.Vector3 = p.pai3D.model.transform.position.clone();
					this.hand3d.transform.position = pos.clone();
					this.hand3d.getChildAt(0).getChildByName('node_tile').addChild(p.pai3D.model);
					p.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
					p.pai3D.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
					// p.pai3D.model.transform.localRotation = new Laya.Quaternion(0, 1, 0, 0);
					p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);

					let anim = view.ModelAnimationController.get_anim_config('Zimo', this.hand_type);
					this.playHandAnimtion(anim);
					Laya.timer.once(anim.keypoint[0], this, () => {
						view.AudioMgr.PlayAudio(227);
					});
					Laya.timer.once(anim.keypoint[1], this, () => {
						p.contianer_pai.addChild(p.pai3D.model);
						p.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
						p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
						p.FullDown();

						Laya.timer.once(100, this, () => DesktopMgr.Inst.ShowHuleEffect(p, p.pai3D.model.transform, DesktopMgr.Inst.player_effects[this.seat][game.EView.hupai_effect], this.seat, 1));


					});
				}



				// let p:HandPai3D = this._hand3d[this._hand3d.length - 1];
				// DesktopMgr.Inst.SetLastQiPai(this.seat, p.pai3D);
				// Laya.timer.once(0, this, ()=>{ p.DoAnim_FullDown(); }); 
				// Laya.timer.once(210, this, () => DesktopMgr.Inst.ShowHuleEffect(p.pai3D.model.transform.position));
			}

			let length = this._hand3d.length - (zimo ? 1 : 0);
			let fulldown_time: number = zimo ? 1100 : 200;
			Laya.timer.once(fulldown_time, this, () => {
				if (this._hand3d.length == 0) return;
				AudioMgr.PlayAudio(223);

				for (let i: number = 0; i < length; i++) {
					this._hand3d[i].DoAnim_FullDown();
				}
			});

			this.trans_hand3D.active = true;
		}

		public Huangpai(tingpai: boolean, hands: Array<mjcore.MJPai>, fast: boolean) {
			app.Log.log('ViewPlayer_Me Huangpai ' + ' tingpai:' + tingpai + ' fast:' + fast);
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			if (this.already_xuezhan_hule_state) {
				return;
			}
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].Hule();
			}

			let hand3d: Array<HandPai3D> = [];
			let parent: Laya.Sprite3D = tingpai ? this.trans_hand3D : this.trans_hand3DCover;
			for (let i: number = 0; i < this.hand.length; i++) {
				let p: HandPai3D = new HandPai3D(parent);
				p.SetVal(this.hand[i].val, false);
				p.pai3D.SetTianMingYellow(view.DesktopMgr.Inst.is_tianming_mode() && this.hand[i].val.touming);
				p.SetIndex(i, false);
				p.Stand(false);
				if (view.DesktopMgr.Inst.is_chuanma_mode()) {
					p.pai3D.is_gap = p.val.type == this.gap_type;
					p.pai3D.OnChoosedPai();
				}

				hand3d.push(p);
			}

			let length = hand3d.length;
			if (fast) {
				for (let i: number = 0; i < length; i++) {
					if (tingpai) this._hand3d[i].FullDown();
					else this._hand3d[i].Cover();
				}
			} else {
				Laya.timer.once(500, this, () => {
					for (let i: number = 0; i < length; i++) {
						if (tingpai) this._hand3d[i].DoAnim_FullDown();
						else this._hand3d[i].DoAnim_Cover();
					}
					AudioMgr.PlayAudio(223);
				});
			}

			this._hand3d = hand3d;
			parent.active = true;
		}

		public onXuezhanMidHule(is_zimo: boolean, hupai: mjcore.MJPai, fast: boolean) {
			uiscript.UI_DesktopInfo.Inst.setZhenting(false);
			if (this.already_xuezhan_hule_state) {
				return;
			}
			this.already_xuezhan_hule_state = is_zimo ? 1 : 2;

			if (is_zimo) {
				this.pai_xuezhan_mid_zimo = hupai;
			}
			let hand3d: Array<HandPai3D> = [];
			let parent: Laya.Sprite3D = this.trans_hand3DCover;
			let length1 = is_zimo ? this.hand.length - 1 : this.hand.length;
			for (let i: number = 0; i < length1; i++) {
				let p: HandPai3D = new HandPai3D(parent);
				p.SetVal(this.hand[i].val, false);
				p.SetIndex(i, false);
				p.Stand();
				hand3d.push(p);
			}
			this._hand3d = hand3d;

			for (let i: number = this.hand.length - 1; i >= 0; i--) {
				this._RemovePai(this.hand[i]);
			}
			if (fast) {

				AudioMgr.PlayAudio(223);
				if (is_zimo) {
					this.showXuezhanMidZimoEffect(hupai, fast);
				}
			} else {
				Laya.timer.once(500, this, () => {
					AudioMgr.PlayAudio(223);
					if (is_zimo) {
						this.showXuezhanMidZimoEffect(hupai, fast);
					}
				});
			}

			parent.active = true;

		}

		public showXuezhanMidZimoEffect(hupai: mjcore.MJPai, fast: boolean = false) {
			let p: HandPai3D = new HandPai3D(this.trans_hand3DCover);
			p.SetVal(hupai, false);
			p.SetIndex(this._hand3d.length, true);
			this._hand3d.push(p);
			p.pai3D.isxuezhanhu = true;
			p.pai3D.OnChoosedPai();
			let record_show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			if (fast || !record_show_anim) {
				p.FullDown();
				p.shadow.active = false;
				p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.15;
			} else {

				p.FullDown();

				p.shadow.active = false;
				p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.15;
				//甩牌动画
				{
					let pos: Laya.Vector3 = p.pai3D.model.transform.position.clone();
					this.hand3d.transform.position = pos.clone();
					this.hand3d.getChildAt(0).getChildByName('node_tile').addChild(p.pai3D.model);
					p.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
					p.pai3D.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);
					// p.pai3D.model.transform.localRotation = new Laya.Quaternion(0, 1, 0, 0);
					p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);

					let anim = view.ModelAnimationController.get_anim_config('Zimo', this.hand_type);
					this.playHandAnimtion(anim);
					Laya.timer.once(anim.keypoint[0], this, () => {
						view.AudioMgr.PlayAudio(227);
					});
					Laya.timer.once(anim.keypoint[1], this, () => {
						p.contianer_pai.addChild(p.pai3D.model);
						p.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
						p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
						p.FullDown();

						Laya.timer.once(100, this, () => DesktopMgr.Inst.ShowHuleEffect(p, p.pai3D.model.transform, DesktopMgr.Inst.player_effects[this.seat][game.EView.hupai_effect], this.seat, 1));
					});
				}
			}

		}

		public onXuezhanEnd(hands: Array<mjcore.MJPai>, fast: boolean) {
			for (let i: number = 0; i < hands.length; i++) {
				if (this._hand3d[i]) {
					this._hand3d[i].SetVal(hands[i], false);
					if (!fast) {
						this._hand3d[i].DoAnim_FullDown();
					} else {
						this._hand3d[i].FullDown();
					}
				}
			}
		}


		public OnDoraRefresh(): void {
			if (this.seat == -1) return;
			super.OnDoraRefresh();
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].RefreshDora();
			}
		}

		public DoDiscardTile(): void {
			app.Log.log('ViewPlayer_Me DoDiscardTile');
			if (this.during_anpailiqi) {
				if (!this.desktop.Action_AnPaiLiQi(this._choose_pai.val, this._choose_pai === this.last_tile, this._choose_pai.is_open)) {
					return;
				}
				this.during_anpailiqi = false;
			} else if (this.during_liqi) {
				if (!this.desktop.Action_LiQi(this._choose_pai.val, this._choose_pai === this.last_tile, this._choose_pai.is_open)) {
					return;
				}
				this.during_liqi = false;
				this.liqiOperation = mjcore.E_PlayOperation.liqi;
			} else if (this.during_anpai) {
				this.desktop.Action_AnPai(this._choose_pai.val, this._choose_pai === this.last_tile, false, this._choose_pai.is_open);
				this.during_anpai = false;
			} else {
				this.desktop.Action_QiPai(this._choose_pai.val, this._choose_pai === this.last_tile, false, this._choose_pai.is_open);
			}
			this._prediscard_index = this._choose_pai.index;
			this._choose_pai.mySelf.active = false;
			this._choose_pai = null;
			this.can_discard = false;
		}

		public onShowPaopaiChange() {
			if (!view.DesktopMgr.Inst.gameing) return;
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].ispaopai = DesktopMgr.Inst.isPaoPai(this.hand[i].val);
				this.hand[i].OnChoosedPai();
			}
		}

		private pendingXiangGong(need_discard: boolean, from: string) {
			if (this.xianggonged) return;
			try {
				let ming_count: number = this.container_ming.mings.length;
				let tile_count: number = 13 - ming_count * 3;
				if (need_discard) tile_count++;

				let index_error: boolean = false;
				for (let i: number = 0; i < this.hand.length; i++) {
					if (this.hand[i].index != i) {
						index_error = true;
						break;
					}
				}
				let hands: string = '';
				for (let i: number = 0; i < this.hand.length; i++) {
					if (i != 0) hands += ', ';
					hands += '[' + i + '|' + this.hand[i].index + ']' + this.hand[i].val.toString();
				}
				app.Log.log('hands: ' + hands);

				if (this.hand.length != tile_count || index_error || this.hand.length + this.handpool.length != 18) {
					//相公了
					this.xianggonged = true;

					let _info: Object = {};
					_info['from'] = from;
					_info['need_discard'] = need_discard;
					_info['ming_count'] = this.container_ming.mings.length;
					_info['tile_count'] = tile_count;
					_info['hand_length'] = this.hand.length;
					_info['index_error'] = index_error;
					_info['hands'] = hands;
					_info['handpool_count'] = this.handpool.length;

					GameMgr.Inst.onXiangGongError(_info);
				}
			} catch (e) {

			}
		}

		private isTileHuanSanZhange(tile: HandPaiPlane): boolean {
			if (this.huansanzhang_state == EHuanSanZhangState.none) return false;
			for (let i: number = 0; i < this.huansanzhang_tile.length; i++) {
				if (this.huansanzhang_tile[i] === tile) return true;
			}
			return false;
		}

		// 设置换三张默认的牌
		public setHuanSanZhangDefaultTile(tiles: Array<string>, states: Array<number>) {
			this.resetMouseState();
			this.huansanzhang_state = EHuanSanZhangState.choosing;
			this.huansanzhang_tile = [];
			let recommendLst: Array<number> = [];
			for (let i: number = 0; i < tiles.length; i++) {
				for (let j: number = 0; j < this.hand.length; j++) {
					if (recommendLst.indexOf(j) != -1) continue;
					if (this.hand[j].val.toString() != tiles[i]) continue;
					if ((!this.hand[j].is_open) != (states[i] == 0)) continue;
					this.hand[j].AddRecommendTag();
					recommendLst.push(j);
					break;
				}
			}
			this.onSpecialModeHuanSanZhang();
		}

		// 更换换三张的牌
		private ChangeHuanSanZhangTile(tile: HandPaiPlane) {
			if (this.huansanzhang_state != EHuanSanZhangState.choosing) return;
			let huan_index: number = -1;
			for (let i: number = 0; i < this.huansanzhang_tile.length; i++) {
				if (this.huansanzhang_tile[i] === tile) {
					huan_index = i;
					break;
				}
			}
			if (huan_index < 0) {
				// 原本没选中
				if (this.huansanzhang_tile.length >= 3) return;
				this.huansanzhang_tile.push(tile);
			} else {
				this.huansanzhang_tile[huan_index] = this.huansanzhang_tile[this.huansanzhang_tile.length - 1];
				this.huansanzhang_tile.pop();
			}
			for (let i: number = 0; i < this.hand.length; i++) {
				let isin: boolean = this.isTileHuanSanZhange(this.hand[i]);
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = isin ? 0.8 : 0;
				this.hand[i].HuanSanZhangSelect(isin || this.huansanzhang_tile.length < 3);
				this.hand[i].mySelf.transform.localPosition = pos;
			}
			this.onSpecialModeHuanSanZhang();
			uiscript.UI_HuanSanZhange.Inst.choosedCount(this.huansanzhang_tile.length);
		}

		// 操作：换三张
		public DoHuanSanZhang(): boolean {
			if (this.huansanzhang_state != EHuanSanZhangState.choosing) return false;
			if (this.huansanzhang_tile.length != 3) return false;
			let pais: Array<string> = [];
			let states: Array<number> = [];
			for (let i: number = 0; i < this.huansanzhang_tile.length; i++) {
				let p = this.huansanzhang_tile[i];
				pais.push(p.val.toString());
				states.push(p.is_open ? 1 : 0);
			}
			DesktopMgr.Inst.Action_HuanSanZhange(pais, states);
			if (DesktopMgr.Inst.isTargetSpecialMode(game.EMJGameRule.QiangDuoZhiZhan)) {
				this.huansanzhang_state = EHuanSanZhangState.none;
			} else {
				this.huansanzhang_state = EHuanSanZhangState.waiting;
			}
			this._choose_pai = null;
			return true;
		}

		// 换三张-删除手牌
		public onHuanSanZhang_Remove(out_tiles: Array<string>, out_tile_states: Array<number>, fast: boolean = false) {
			for (let i: number = 0; i < out_tiles.length; i++) {
				if (!this._RemoveHandPai(mjcore.MJPai.Create(out_tiles[i]), out_tile_states[i])) {
					app.Log.Error('onHuanSanZhang 无法删除手牌：' + out_tiles[i] + ', state:' + out_tile_states[i]);
				}
			}
			this.LiPai(fast);
			for (let pai of this.hand) {
				pai.RemoveRecommendTag();
			}
			this.huansanzhang_tile = [];
			for (let i: number = 0; i < this.hand.length; i++) {
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = 0;
				this.hand[i].mySelf.transform.localPosition = pos;
			}
		}

		// 换三张-接到牌
		public onHuanSanZhang_Add(in_tiles: Array<string>, in_tile_states: Array<number>, fast: boolean = false) {
			let new_tiles: Array<HandPaiPlane> = [];
			for (let i: number = 0; i < in_tiles.length; i++) {
				let p: HandPaiPlane = this._AddHandPai(mjcore.MJPai.Create(in_tiles[i]), in_tile_states[i] != 0);
				new_tiles.push(p);
			}
			this.LiPai(true, true);

			if (this.hand.length == 14) {
				this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
			}
			if (!fast) {
				for (let i: number = 0; i < new_tiles.length; i++) {
					new_tiles[i].AnimHuanSanZhang();
				}
				Laya.timer.once(1000, this, () => { this.huansanzhang_state = EHuanSanZhangState.none; });
			} else {
				this.huansanzhang_state = EHuanSanZhangState.none;
			}

			this.last_tile = this.hand[this.hand.length - 1];
		}

		public onSpecialModeHuanSanZhang() { //特殊模式的换三张
			if (this.huansanzhang_state != EHuanSanZhangState.choosing) return;
			if (view.DesktopMgr.Inst.is_chuanma_mode()) {
				if (!this.huansanzhang_tile || this.huansanzhang_tile.length == 0) {
					let paiCountLst = [0, 0, 0];
					for (let pai of this.hand) {
						paiCountLst[pai.val.type]++;
					}
					for (let pai of this.hand) {
						pai.SetHuanSanZhangEnable(paiCountLst[pai.val.type] >= 3);
					}
				} else {
					for (let pai of this.hand) {
						pai.SetHuanSanZhangEnable(pai.val.type == this.huansanzhang_tile[0].val.type);
					}
				}
			} else if (view.DesktopMgr.Inst.is_wanxiangxiuluo_mode()) {
				for (let pai of this.hand) {
					pai.SetHuanSanZhangEnable(!pai.val.baida);
				}
			}
		}

		public quitReTributeState(){
			this.huansanzhang_state = EHuanSanZhangState.none;
		}

		public submitHandTile(out_tiles: Array<string>, fast: boolean = false) {
			for (let i: number = 0; i < out_tiles.length; i++) {
				if (!this._RemoveHandPai(mjcore.MJPai.Create(out_tiles[i]), -1)) {
					app.Log.Error('onHuanSanZhang 无法删除手牌：' + out_tiles[i]);
				}
			}
			this.LiPai(fast);
			for (let pai of this.hand) {
				pai.RemoveRecommendTag();
			}
			this.huansanzhang_tile = [];
			for (let i: number = 0; i < this.hand.length; i++) {
				let pos: Laya.Vector3 = this.hand[i].mySelf.transform.localPosition.clone();
				pos.y = 0;
				this.hand[i].mySelf.transform.localPosition = pos;
			}
			this.last_tile = this.hand[this.hand.length - 1];
		}

		public takeHandTile(in_tiles: Array<string>, fast: boolean = false) {
			let new_tiles: Array<HandPaiPlane> = [];
			for (let i: number = 0; i < in_tiles.length; i++) {
				let p: HandPaiPlane = this._AddHandPai(mjcore.MJPai.Create(in_tiles[i]), false);
				new_tiles.push(p);
			}
			this.LiPai(true, true);
			if (this.hand.length == 14) {
				this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true, false);
			}
			if (!fast) {
				for (let i: number = 0; i < new_tiles.length; i++) {
					new_tiles[i].AnimHuanSanZhang();
				}
			}
			this.last_tile = this.hand[this.hand.length - 1];
		}

		//双击摸切
		public onDoubleClick(): boolean {
			if (!this.can_discard) return;
			if (this.during_liqi) return;
			if (this.during_anpailiqi) return;
			if (this.during_anpai) return;
			if (this.huansanzhang_state != EHuanSanZhangState.none) return;
			if (!this.last_tile) return;
			if (view.DesktopMgr.Inst.timestoped) return;
			this.desktop.Action_QiPai(this.last_tile.val, true, false, this.last_tile.is_open);
			this._prediscard_index = this.last_tile.index;//this.hand.length - 1;
			this.last_tile.mySelf.active = false;
			this._choose_pai = null;
			this.can_discard = false;
			return true;
		}

		//============================鼠标操作=============================
		private setChoosePai(pai: HandPaiPlane, fromclick: boolean) {
			if (this._choose_pai === pai) return;
			if (DesktopMgr.Inst.is_chuanma_mode() && this.huansanzhang_state == EHuanSanZhangState.choosing) {
				if (!pai.huansanzhangEnabled) {
					this.click_on_choosed = false; // 取消选中状态，选中失败
					return;
				}
			}
			// if (view.DesktopMgr.Inst.timestoped) return;
			if (this._choose_pai && this._choose_pai != pai) { //重置上一张牌的选中状态
				let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
				pos.y = this.isTileHuanSanZhange(this._choose_pai) ? 0.8 : 0;
				this._choose_pai.mySelf.transform.localPosition = pos;
				this._choose_pai = null;
			}

			if (pai.val.baida) {
				if (!this.desktop.auto_liqi) this._choose_pai = pai;  //百搭牌关闭理牌时可以拖动拖动
				DesktopMgr.Inst.setChoosedPai(null);
				return;
			}

			this._choose_pai = pai;
			let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
			pos.y = 0.8;
			this._choose_pai.mySelf.transform.localPosition = pos;
			if (fromclick) {
				pai.AddClickEffect(this.effect_click.clone());
			}
			DesktopMgr.Inst.setChoosedPai(this._choose_pai.val);
			view.AudioMgr.PlayAudio(204);
		}

		private resetMouseState() {
			this._mouse_in_pai = null;
			this.during_drag = false;
			this.mouse_downed = false;
			this.click_on_choosed = false;
			if (this._choose_pai) {
				let pos: Laya.Vector3 = this._choose_pai.mySelf.transform.localPosition.clone();
				pos.y = this.isTileHuanSanZhange(this._choose_pai) ? 0.8 : 0;
				this._choose_pai.mySelf.transform.localPosition = pos;
				this._choose_pai = null;
			}
			DesktopMgr.Inst.setChoosedPai(null);
		}

		private onMouseDown(): void {
			if (!this.needCheckMouse()) return;
			// 2026.2.5 yujiena: during_huansanzhang恒为false，没有用，注释掉下面这行
			// if (this.during_huansanzhang && view.DesktopMgr.Inst.mode != EMJMode.play) return;
			let mouse_info: IMouseInfo = this.getMouseInfo();
			if (mouse_info.pai) {
				if (this.huansanzhang_state != EHuanSanZhangState.none) {
					if (mouse_info.pai.valid && !mouse_info.pai.val.baida) {

						this.click_on_choosed = true;
						this.setChoosePai(mouse_info.pai, true);
					} else {
						// this.resetMouseState();
					}
				} else {
					// 普通状态下
					if (this._choose_pai === mouse_info.pai) {
						this.click_on_choosed = true;
					} else {
						this.setChoosePai(mouse_info.pai, true);
						this.click_on_choosed = false;
						this.click_choosed_time = Laya.timer.currTimer;
					}
				}
				this.mouse_downx = Laya.MouseManager.instance.mouseX;
				this.mouse_downy = Laya.MouseManager.instance.mouseY;
				this.mouse_downed = true;
			} else {
				this.resetMouseState();
			}
		}

		private onMouseMove(): void {
			if(!this.needCheckMouse()) return;
			if (this.huansanzhang_state != EHuanSanZhangState.none) return;
			if (view.DesktopMgr.Inst.mode != EMJMode.play || DesktopMgr.Inst.timestoped) return; //新增非对局模式不允许拖动
			if (this._choose_pai && this.mouse_downed) {
				let mx: number = Laya.MouseManager.instance.mouseX;
				let my: number = Laya.MouseManager.instance.mouseY;
				if ((mx - this.mouse_downx) * (mx - this.mouse_downx) + (my - this.mouse_downy) * (my - this.mouse_downy) > 400) {
					this.during_drag = true;
				}
			}
		}

		private doChoosePaiAction(): void {
			if (this.huansanzhang_state != EHuanSanZhangState.none) {
				if (view.DesktopMgr.Inst.mode != EMJMode.play) return;
				if (this.huansanzhang_state == EHuanSanZhangState.choosing) {
					this.ChangeHuanSanZhangTile(this._choose_pai);
					this.resetMouseState();
					return;
				}
			}
			if (this.can_discard) {
				if (DesktopMgr.click_prefer == 1) {
					uiscript.UI_DesktopInfo.Inst.recordDoubleClickTime(Laya.timer.currTimer - this.click_choosed_time);
				}
				this.DoDiscardTile();
				this.resetMouseState();
			} else {
				this.resetMouseState();
			}
		}

		private onMouseUp(): void {
			if (!this.needCheckMouse()) return;
			let mouse_info: IMouseInfo = this.getMouseInfo();
			this.mouse_downed = false;
			if (this.during_drag) {
				this.during_drag = false;
				if (this._choose_pai == null || mouse_info.inHandRange || !this._choose_pai.valid || this._choose_pai.val.baida) {
					this.resetMouseState();
				} else {
					this.doChoosePaiAction();
				}
			} else if (this.click_on_choosed) {
				if (this._choose_pai.valid && !this._choose_pai.val.baida) {
					this.doChoosePaiAction();
				}
			}
		}

		private needCheckMouse(): boolean {
			if (!view.DesktopMgr.Inst.gameing) return false;
			if (view.DesktopMgr.Inst.mode == EMJMode.play && view.DesktopMgr.Inst.timestoped) return false;
			if (view.DesktopMgr.Inst.mode == EMJMode.xinshouyindao) return false;
			if (uiscript.UI_Hangup_Warn.Inst.enable) return false;
			if (uiscript.UI_PlayerInfo.Inst.enable) return false;
			if (uiscript.UI_FieldSpell.Inst && uiscript.UI_FieldSpell.Inst.enable && uiscript.UI_FieldSpell.Inst.getRootEnable()) return false;
			if (uiscript.UI_Config_New.Inst && uiscript.UI_Config_New.Inst.enable) {
				return false;
			}
			return true;
		}
		public onMouseOut(): void {
			this.mouse_downed = false;
			this.click_on_choosed = false;
			if (this.during_drag) {
				this.during_drag = false;
				this.resetMouseState();
			}
		}

		private readonly screen_left: number = -7.2;
		private readonly screen_right: number = 44.4;
		private readonly screen_top: number = 16.6;
		private readonly screen_bottom: number = -1.4;
		private readonly handrange_top: number = 2.5;
		private readonly handorigin_x: number = 0;
		private readonly handwidth: number = 2.55;

		private getMouseInfo(): IMouseInfo {
			let mouseX: number = Laya.MouseManager.instance.mouseX;
			let mouseY: number = Laya.MouseManager.instance.mouseY;
			let w_offset: number = 0;
			let h_offset: number = 0;
			if (Laya.Browser.width / 1920 < Laya.Browser.height / 1080) {
				h_offset = (Laya.Browser.height - Laya.Browser.width / 1920 * 1080) / 2;
			} else {
				w_offset = (Laya.Browser.width - Laya.Browser.height / 1080 * 1920) / 2;
			}

			let x: number = mouseX / (Laya.Browser.width - w_offset * 2) * (this.screen_right - this.screen_left) + this.screen_left;
			let y: number = mouseY / (Laya.Browser.height - h_offset * 2) * (this.screen_bottom - this.screen_top) + this.screen_top;
			let index: number = Math.floor((x - this.handorigin_x) / this.handwidth);
			if (index < 0) index = 0;
			if (index >= this.hand.length) index = this.hand.length - 1;

			let pai: HandPaiPlane = null;
			let camera: Laya.Camera = game.Scene_MJ.Inst.camera_hand;
			//画参考线
			//根据鼠标屏幕2D座标修改生成射线数据 
			camera.viewportPointToRay(new Laya.Vector2(mouseX, mouseY), this.ray);
			//射线检测，最近物体碰撞器信息，最大检测距离为300米，默认检测第0层
			Laya.Physics.rayCast(this.ray, this.rayCastHit, 300);
			//如果碰撞信息中的模型不为空,删除模型
			if (this.rayCastHit.sprite3D) {
				pai = this.rayCastHit.sprite3D.getComponentByType(HandPaiPlane) as HandPaiPlane;
			}
			return {
				inHandRange: y < this.handrange_top,
				index: index,
				x: x,
				y: y,
				pai: pai
			}
		}

		private update(): void {
			let mouse_info: IMouseInfo = this.getMouseInfo();
			if (this.during_drag) {
				if (!view.DesktopMgr.Inst.gameing || DesktopMgr.Inst.timestoped) {
					this.resetMouseState();
				} else {
					if (this._choose_pai == null) {
						this.resetMouseState();
					} else {
						if (!view.DesktopMgr.Inst.auto_liqi && mouse_info.inHandRange && mouse_info.index != this._choose_pai.index) {
							if (mouse_info.index < this._choose_pai.index) {
								for (let i: number = mouse_info.index; i < this._choose_pai.index; i++) {
									this.hand[i].SetIndex(i + 1, false, true);
								}
								for (let i: number = this._choose_pai.index; i > mouse_info.index; i--) {
									this.hand[i] = this.hand[i - 1];
									this.hand[i].SetIndex(i, false, true);
								}
							} else {
								for (let i: number = this._choose_pai.index; i < mouse_info.index; i++) {
									this.hand[i] = this.hand[i + 1];
									this.hand[i].SetIndex(i, false, true);
								}
							}
							this.hand[mouse_info.index] = this._choose_pai;
							this._choose_pai.SetIndex(mouse_info.index, false, true);
						}
						this._choose_pai.mySelf.parent.setChildIndex(this._choose_pai.mySelf, this._choose_pai.mySelf.parent.numChildren - 1);
						this._choose_pai.mySelf.transform.localPosition = new Laya.Vector3(mouse_info.x, mouse_info.y, 0.5);
					}
				}
			} else if (!this.mouse_downed) {
				if (view.DesktopMgr.Inst.mode == EMJMode.play && view.DesktopMgr.Inst.timestoped) return;
				if (view.DesktopMgr.Inst.mode == EMJMode.xinshouyindao) return;
				if (uiscript.UI_Hangup_Warn.Inst.enable) return;
				if (uiscript.UI_PlayerInfo.Inst.enable) return;
				if (this.huansanzhang_state != EHuanSanZhangState.none) return;
				if (uiscript.UI_Config_New.Inst && uiscript.UI_Config_New.Inst.enable) {
					return;
				}
				
				if (Laya.Browser.onPC && view.DesktopMgr.click_prefer == 0 && view.DesktopMgr.Inst.gameing) {
					if (mouse_info.pai == null) {
						this.resetMouseState();
					} else {
						if (this._mouse_in_pai && this._mouse_in_pai === mouse_info.pai) {
							let t: number = Laya.timer.currTimer - this._mouse_in_start_time;
							if (t > 10) {
								this.setChoosePai(this._mouse_in_pai, false);
								this._mouse_in_pai = null;
							}
						} else {
							this._mouse_in_pai = mouse_info.pai;
							this._mouse_in_start_time = Laya.timer.currTimer;
						}
					}
				}
			}
		}

		public refreshGapType() {
			for (let i = 0; i < this.hand.length; i++) {
				this.hand[i].isGap = this.gap_type == this.hand[i].val.type;
				this.hand[i].OnChoosedPai();
			}
		}

		public RevealFailed(pai: mjcore.MJPai, doanim: boolean = true): void {
			this.container_qipai.RevealFailed(pai, doanim);
		}

		public revertAllPais() {
			if (this._prediscard_index < 0) return;
			for (let hand of this.hand) {
				if (hand.mySelf) {
					hand.mySelf.active = true;
				}
			}
		}

		public getTianMingRate(): number {
			let rate = 1;
			for (let hand of this.hand) {
				if (hand.val.touming) {
					rate++;
				}
			}
			for (let pai of this.container_ming.pais) {
				if (pai.val.touming) {
					rate++;
				}
			}
			return rate;
		}
	}
}