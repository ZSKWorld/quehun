/**
* name 
*/
module view {
	export class ViewPlayer_Other extends ViewPlayer {

		public handnum: number = 0;
		public hand: Array<HandPai3D> = null;
		public discardcd: number = 0;
		private debug_new_round_frame = -1;
		private debug_reset_frame = -1;
		private lipai_id: number = 0;

		constructor() {
			super();
		}

		public Reset(): void {
			super.Reset();
			if (this.hand != null) {
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].Destory();
				}
				this.hand = null;
			}
			Laya.timer.clearAll(this);
			this.discardcd = 0;
			this.debug_reset_frame = Laya.timer.currFrame;
		}

		public NewGame(_num: number, opened_tiles: Array<string>, opened_counts: Array<number>, fast: boolean, new_tile: string): void {
			this.Reset();
			this.RefreshDir();
			this.handnum = _num;
			this.hand = [];

			let _tiles: Array<mjcore.MJPai> = [];
			if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
				opened_counts = [];
				for (let i = 0; i < _num; i++) {
					opened_counts.push(1);
				}
			}
			if (view.DesktopMgr.Inst.is_tianming_mode()) {
				for (let i = 0; i < opened_tiles.length; i++) {
					if (opened_tiles[i]) {
						_tiles.push(mjcore.MJPai.Create(opened_tiles[i]));
					}

				}
				_tiles = _tiles.sort((a, b) => {

					let va: number = a.numValue() * 10 + (a.dora ? 0 : 1);
					let vb: number = b.numValue() * 10 + (b.dora ? 0 : 1);
					return va - vb;
				});
			} else {
				for (let i: number = 0; i < opened_counts.length; i++) {
					for (let j: number = 0; j < opened_counts[i]; j++) {
						_tiles.push(mjcore.MJPai.Create(opened_tiles[i] ? opened_tiles[i] : '5z'));
					}
				}
			}


			if (!fast) {
				let current_num: number = 0;
				for (let i: number = 0; i < 4; i++) {
					Laya.timer.once(300 * i, this, () => {
						for (let j: number = 0; j < 4; j++) {
							if (current_num >= _num) break;
							let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
							if (current_num < _tiles.length) {
								p.SetVal(_tiles[current_num], true);
							} else {
								p.SetVal(mjcore.MJPai.Create('5z'), false);
							}
							p.SetIndex(current_num, false);
							this.hand.push(p);
							p.DoAnim_Stand();
							current_num++;
						}
					});
				}
				Laya.timer.once(1200, this, () => {
					if (view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()) {
						this.LiPai(150, false);
					} else {
						this.LiPai(150, true);
					}
					if (_num == 14) this.hand[13].SetIndex(13, true);
					for (let k: number = 0; k < this.hand.length; k++) {
						if (this.hand[k].is_open) {
							this.hand[k].DoAnim_FullDown();
							this.hand[k].pai3D.OnChoosedPai();
						}
					}
				});
			} else {
				for (let i: number = 0; i < _num; i++) {
					let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
					if (i < _tiles.length) {
						p.SetVal(_tiles[i], true);
						p.FullDown();
						p.pai3D.OnChoosedPai();
					} else {
						p.SetVal(mjcore.MJPai.Create('5z'), false);
						p.Stand();
					}
					p.SetIndex(i, i == 14);
					this.hand.push(p);
				}
				this.LiPai(0, false);
			}

		}

		public RecordNewGame(pais: Array<mjcore.MJPai>, opened_tiles: Array<string>, opened_counts: Array<number>): void {
			this.Reset();
			this.RefreshDir();
			this.handnum = pais.length;
			this.hand = [];
			let _open_map = {};
			if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
				// for (let i:number = 0; i < opened_tiles.length; i++) {
				// 	_open_map[opened_tiles[i]] = opened_counts[i];
				// }
			} else {
				for (let i: number = 0; i < opened_counts.length; i++) {
					_open_map[opened_tiles[i]] = opened_counts[i];
				}
			}

			let need_sort_touming = !view.DesktopMgr.Inst.record_show_hand;
			pais = pais.sort((a, b) => {

				let va: number = a.numValue() * 10 + (a.dora ? 0 : 1);
				let vb: number = b.numValue() * 10 + (b.dora ? 0 : 1);
				if (need_sort_touming) {
					if (!a.touming) va += 10000000;
					if (!b.touming) vb += 10000000;
				}
				return va - vb;
			});
			for (let i: number = 0; i < pais.length; i++) {
				let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
				let is_open: boolean = false;
				if (_open_map[pais[i].toString()] > 0) {
					is_open = true;
					_open_map[pais[i].toString()]--;
				}
				
				
				if (view.DesktopMgr.Inst.is_tianming_mode() && pais[i].touming) {
					p.SetVal(pais[i], is_open);
					p.pai3D.SetTianMingYellow(view.DesktopMgr.Inst.record_show_hand);
					p.FullDown();
					p.pai3D.OnChoosedPai();
				} else if (view.DesktopMgr.Inst.record_show_hand || (!pais[i].touming && is_open)) {
					p.SetVal(pais[i], is_open);
					p.FullDown();
					p.pai3D.OnChoosedPai();
				}
				else {
					p.SetVal(pais[i], is_open, false);
					p.Stand();
					
					p.pai3D.ResetShow();
				}
				p.SetIndex(i, i == 13);
				this.hand.push(p);
			}
			this.debug_new_round_frame = Laya.timer.currFrame;
		}

		private _LiPai(anim: boolean = true): void {
			let need_sort_touming = view.DesktopMgr.Inst.mode == EMJMode.play;

			this.hand.sort((a: HandPai3D, b: HandPai3D) => {
				let a_val: number = a.val.numValue() * 10 + (a.val.dora ? 0 : 1);
				let b_val: number = b.val.numValue() * 10 + (b.val.dora ? 0 : 1);
				if (!a.is_open) a_val += 10000000;
				if (!b.is_open) b_val += 10000000;
				if (need_sort_touming) {
					if (!a.val.touming) a_val += 10000000;
					if (!b.val.touming) b_val += 10000000;
				}
				if (a_val != b_val) {
					return a_val - b_val;
				} else {
					return a.index - b.index;
				}

			});
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].SetIndex(i, false, anim);
				if (this.hand[i].is_open) {
					this.hand[i].FullDown();
				} else {
					this.hand[i].Stand();
				}
			}
		}

		public LiPai(delay: number, anim: boolean = true): void {
			this.lipai_id++;
			if (delay <= 0) {
				this._LiPai(anim);
			} else {
				let _id: number = this.lipai_id;
				Laya.timer.once(delay, this, () => {
					if (_id != this.lipai_id) return;
					this._LiPai(anim);
				});
			}
		}

		public onBabei(moqie: boolean, is_open: boolean, fast: boolean) {
			this.onDiscardTile(moqie, is_open ? '4z' : '', is_open, fast);
		}

		public onDiscardTile(moqie: boolean, tile: string, is_open: boolean, fast: boolean) {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other onDiscardTile ' + ' moqie:' + moqie + ' fast:' + fast);
			let mjp: mjcore.MJPai = mjcore.MJPai.Create(tile);
			if (fast) {
				this._PlayRemoveHandPai(mjp, is_open ? 1 : 0, false);
				this.LiPai(0, false);
			} else {
				let last_hand = this.hand[this.hand.length - 1];
				if (moqie && (!last_hand.is_open || last_hand.val.toString() == tile)) {
					this.hand[this.hand.length - 1].Destory();
					this.hand.pop();
				} else {
					this._PlayRemoveHandPai(mjp, is_open ? 1 : 0, true);
					this.discardcd = 1200 + Laya.timer.currTimer;
					if (view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()) {
						this.LiPai(1000, false);
					} else {
						this.LiPai(1000, true);
					}
				}
			}
		}

		//根据牌的值删除手牌
		private _RecordRemoveHandPai(pai: mjcore.MJPai, tile_state: number, left: boolean = true): void {
			let start_index: number;
			let end_index: number;
			let step: number;
			if (left) {
				start_index = 0;
				end_index = this.hand.length - 1;
				step = 1;
			} else {
				start_index = this.hand.length - 1;
				end_index = 0;
				step = -1;
			}
			if (view.DesktopMgr.Inst.is_peipai_open_mode) tile_state = -1;

			let index: number = -1;
			if (tile_state == -1 || tile_state == 1) {
				// 先从open的牌开始
				for (let i: number = start_index; i != end_index + step; i += step) {
					if (this.hand[i].is_open && mjcore.MJPai.isSame(pai, this.hand[i].val)) {
						index = i;
						break;
					}
				}
			}
			if (index == -1) {
				if (tile_state == -1 || tile_state == 0) {
					for (let i: number = start_index; i != end_index + step; i += step) {
						if (!this.hand[i].is_open && mjcore.MJPai.isSame(pai, this.hand[i].val)) {
							index = i;
							break;
						}
					}
				}
			}

			if (index != -1) {
				this.hand[index].Destory();
				for (let i: number = index; i < this.hand.length - 1; i++) {
					this.hand[i] = this.hand[i + 1];
				}
				this.hand.pop();
			}
		}

		private _RecordLiPai(fast: boolean = false): void {
			if (!this.hand) return;
			this.hand.sort((a: HandPai3D, b: HandPai3D) => {
				let a_val: number = a.val.numValue() * 10 + (a.val.dora ? 0 : 1);
				let b_val: number = b.val.numValue() * 10 + (b.val.dora ? 0 : 1);
				if (!view.DesktopMgr.Inst.record_show_hand) {
					if (!a.is_open) a_val += 10000000;
					if (!b.is_open) b_val += 10000000;

					if (!a.val.touming) a_val += 10000000;
					if (!b.val.touming) b_val += 10000000;
				}

				if (a_val != b_val) {
					return a_val - b_val;
				} else {
					return a.index - b.index;
				}
			});
			for (let i: number = 0; i < this.hand.length; i++) {
				this.hand[i].SetIndex(i, false, fast && view.DesktopMgr.Inst.record_show_anim);
				if (this.hand[i].is_open || view.DesktopMgr.Inst.record_show_hand || (DesktopMgr.Inst.is_tianming_mode() && this.hand[i].val.touming)) {
					this.hand[i].FullDown();
				} else {
					this.hand[i].Stand();
				}
			}
		}

		// record理牌
		public RecordLiPai(delay: number, anim: boolean = false): void {
			this.lipai_id++;
			if (delay <= 0) {
				this._RecordLiPai(anim);
			} else {
				let _id: number = this.lipai_id;
				Laya.timer.once(delay, this, () => {
					if (_id != this.lipai_id) return;
					this._RecordLiPai(anim);
				});
			}
		}

		public recordBabei(pai: mjcore.MJPai, moqie: boolean, is_open: boolean, fast: boolean) {
			this.recordDiscardTile(pai, moqie, is_open, fast);
		}

		public recordDiscardTile(pai: mjcore.MJPai, moqie: boolean, is_open: boolean, fast: boolean) {
			if (this.seat < 0) return;
			if (!this.hand) return; 
			if (moqie && mjcore.MJPai.isSame(pai, this.hand[this.hand.length - 1].val)) {
				this.hand[this.hand.length - 1].Destory();
				this.hand.pop();
			} else {
				this._RecordRemoveHandPai(pai, is_open ? 1 : 0);
			}
			if (view.DesktopMgr.Inst.mode == EMJMode.live_broadcast && uiscript.UI_Live_Broadcast.Inst.during_play) {
				if (fast) {
					this.RecordLiPai(0, false);
				} else {
					this.RecordLiPai(1000, !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand() || DesktopMgr.Inst.record_show_hand));
				}
			}
		}

		public SetNum(_num: number, need_sort: boolean = true): void {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other SetNum ' + ' _num:' + _num + ' _oldnum:' + this.hand.length);
			while (this.hand.length < _num) {
				let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
				p.SetVal(mjcore.MJPai.Create('5z'), false);
				p.SetIndex(this.hand.length, false);
				p.Stand();
				this.hand.push(p);
			}
			while (this.hand.length > _num) {
				this.hand[this.hand.length - 1].Destory();
				this.hand.pop();
			}
			app.Log.log('ViewPlayer_Other SetNum _chandlength:' + this.hand.length);
			if (need_sort) this.LiPai(0, false);
		}

		// 对局删除手中的牌，pai只在tile_state==-1||==1有意义, 若是不open的牌，则是随机的
		private _PlayRemoveHandPai(pai: mjcore.MJPai, tile_state: number, ignore_moqie: boolean) {
			if (view.DesktopMgr.Inst.is_peipai_open_mode) tile_state = -1;

			let index: number = -1;
			if (view.DesktopMgr.Inst.is_jiuchao_mode() && pai.touming) {
				for (let i: number = 0; i < this.hand.length; i++) {
					if (mjcore.MJPai.isSame(this.hand[i].val, pai)) {
						index = i;
						break;
					}
				}
			} else if (tile_state == -1 || tile_state == 1) {
				for (let i: number = 0; i < this.hand.length; i++) {
					if (this.hand[i].is_open && mjcore.MJPai.isSame(this.hand[i].val, pai)) {
						index = i;
						break;
					}
				}
			}
			if (index == -1) {
				if (tile_state == -1 || tile_state == 0) {
					for (let i: number = 0; i < this.hand.length; i++) {
						if (!this.hand[i].is_open && !this.hand[i].val.touming) {
							index = i;
							break;
						}
					}
					if (index != -1) {
						let rand_length: number = this.hand.length - index;
						if (ignore_moqie) rand_length--;
						index = Math.floor(Math.random() * rand_length) + index;
					}
				}
			}
			if (index != -1) {
				this.hand[index].Destory();
				for (let i: number = index; i < this.hand.length - 1; i++) {
					this.hand[i] = this.hand[i + 1];
				}
				this.hand.pop();
			}
		}

		public AddMing(ming: mjcore.MJMing, tile_states: Array<number>, doanim: boolean = true): void {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other AddMing ' + ' ming:' + ming.toString() + ' doanim:' + doanim);
			try {
				if (view.DesktopMgr.Inst.mode == view.EMJMode.play) {
					for (let i: number = 0; i < ming.pais.length; i++) {
						if (ming.from[i] == this.seat) {
							this._PlayRemoveHandPai(ming.pais[i], tile_states[i], false);
						}
					}
					this.LiPai(0, doanim && !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()));
				} else {
					for (let i: number = 0; i < ming.pais.length; i++) {
						if (ming.from[i] == this.seat) {
							this._RecordRemoveHandPai(ming.pais[i], tile_states[i]);
						}
					}
					this.RecordLiPai(0, doanim && !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand() || DesktopMgr.Inst.record_show_hand));
				}
				super.AddMing(ming, tile_states, doanim);
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'AddMing';
				_errorinfo['class'] = 'ViewPlayer_Other';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public AddGang(pai: mjcore.MJPai, doanim: boolean = true): void {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other AddGang ' + pai.toString() + ' doanim:' + doanim);
			try {
				super.AddGang(pai, doanim);
				if (DesktopMgr.Inst.mode == EMJMode.play) {
					// this.SetNum(this.hand.length - 1);
					this._PlayRemoveHandPai(pai, -1, false);
					this.LiPai(0, doanim && !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()));
				} else {
					this._RecordRemoveHandPai(pai, -1);
					this.RecordLiPai(0, doanim && !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand() || DesktopMgr.Inst.record_show_hand));
				}
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'TakePai';
				_errorinfo['class'] = 'ViewPlayer_Other';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public OnDoraRefresh(): void {
			if (this.seat < 0) return;
			super.OnDoraRefresh();
			if (DesktopMgr.Inst.mode != EMJMode.play && DesktopMgr.Inst.record_show_hand) {
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].pai3D.RefreshDora();
				}
			} else {
				for (let i: number = 0; i < this.hand.length; i++) {
					if (this.hand[i].is_open || this.hand[i].val.touming) {
						this.hand[i].pai3D.RefreshDora();
					}
				}
			}
		}

		public TakePai(pai: mjcore.MJPai, is_open: boolean): void {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other TakePai ' + pai.toString());
			try {
				this.LiPai(0, false);
				let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
				p.SetVal(pai, is_open, is_open || (view.DesktopMgr.Inst.mode != EMJMode.play && view.DesktopMgr.Inst.record_show_hand));
				p.SetIndex(this.hand.length, true);
				if (!is_open) {
					p.Stand();
					p.pai3D.ResetShow();
				}
				else {
					p.FullDown();
					p.pai3D.OnChoosedPai();
				}
				this.hand.push(p);
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'TakePai';
				_errorinfo['class'] = 'ViewPlayer_Other';
				_errorinfo['last_new_round_frame'] = this.debug_new_round_frame;
				_errorinfo['last_reset_frame'] = this.debug_reset_frame;
				_errorinfo['hand_is_null'] = (this.hand == null);
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		public recordTakePai(pai: mjcore.MJPai, is_open: boolean, anim: boolean = false): void {
			if (this.seat < 0) return;
			if (!this.hand) return;
			this.RecordLiPai(0, anim && !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand() || DesktopMgr.Inst.record_show_hand));
			let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
			p.SetVal(pai, is_open, is_open || (view.DesktopMgr.Inst.mode != EMJMode.play && view.DesktopMgr.Inst.record_show_hand));
			p.SetIndex(this.hand.length, true);
			if (view.DesktopMgr.Inst.record_show_hand || is_open) {
				p.FullDown();
				p.pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(p.pai3D.val);
				p.pai3D.is_gap = this.gap_type == p.pai3D.val.type;
				p.pai3D.OnChoosedPai();
			}
			else {
				p.Stand();
				p.pai3D.ResetShow();
			}
			if (view.DesktopMgr.Inst.is_jiuchao_mode() && pai.touming) {
				p.pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(p.pai3D.val);
				p.pai3D.OnChoosedPai();
			}
			
			this.hand.push(p);
		}

		public Hule(hands: Array<mjcore.MJPai>, hupai: mjcore.MJPai, zimo: boolean) {
			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other Hule ' + hupai.toString() + ' zimo:' + zimo);
			if (DesktopMgr.Inst.mode == EMJMode.play) {
				this.SetNum(hands.length + (zimo ? 1 : 0), !view.DesktopMgr.Inst.is_jiuchao_mode());
				if (zimo) {
					let p: HandPai3D = this.hand[this.hand.length - 1];
					p.SetVal(hupai, false);
					p.SetIndex(this.hand.length - 1, true);
					p.FullDown();
					if (view.DesktopMgr.Inst.xuezhan) {
						p.pai3D.isxuezhanhu = true;
						p.pai3D.OnChoosedPai();
					}
					p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.2;
					p.shadow.active = false;
					//甩牌动画
					{
						let pos: Laya.Vector3 = p.pai3D.model.transform.position.clone();
						this.hand3d.transform.position = pos.clone();
						this.hand3d.getChildAt(0).getChildByName('node_tile').addChild(p.pai3D.model);
						p.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
						p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
						p.pai3D.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);

						let anim = view.ModelAnimationController.get_anim_config('Zimo', this.hand_type);
						this.playHandAnimtion(anim);
						Laya.timer.once(anim.keypoint[0], this, () => {
							// 关键帧0：牌落地，放出声音
							view.AudioMgr.PlayAudio(227);
						});
						Laya.timer.once(anim.keypoint[1], this, () => {
							// 关键帧1：牌脱离手
							p.contianer_pai.addChild(p.pai3D.model);
							p.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
							p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
							p.FullDown();

							Laya.timer.once(100, this, () => DesktopMgr.Inst.ShowHuleEffect(p, p.pai3D.model.transform, DesktopMgr.Inst.player_effects[this.seat][game.EView.hupai_effect], this.seat, 1));

						});
					}


					// Laya.timer.once(0, this, ()=>{this.hand[this.hand.length - 1].DoAnim_FullDown(); }); 
					// DesktopMgr.Inst.SetLastQiPai(this.seat, this.hand[this.hand.length - 1].pai3D);
					// Laya.timer.once(210, this, () => DesktopMgr.Inst.ShowHuleEffect(this.hand[this.hand.length - 1].pai3D.model.transform.position));
				}

				let length: number = hands.length;
				let fulldown_time: number = zimo ? 1100 : 200;
				if (view.DesktopMgr.Inst.is_jiuchao_mode()) {
					hands.sort((a, b) => {
						let a_val: number = a.numValue() * 10 + (a.dora ? 0 : 1);
						let b_val: number = b.numValue() * 10 + (b.dora ? 0 : 1);
						if (!a.touming) a_val += 10000000;
						if (!b.touming) b_val += 10000000;
						if (a_val != b_val) {
							return a_val - b_val;
						} else {
							return a.index - b.index;
						}
					});
				}
				Laya.timer.once(fulldown_time, this, () => {
					AudioMgr.PlayAudio(223);
					for (let i: number = 0; i < length; i++) {
						this.hand[i].SetVal(hands[i], false);
						this.hand[i].DoAnim_FullDown();
					}
				});
			} else {
				if (!view.DesktopMgr.Inst.record_show_anim) {
					// Laya.timer.once(0, this, ()=>{this.hand[this.hand.length - 1].DoAnim_FullDown(); }); 
					DesktopMgr.Inst.SetLastQiPai(this.seat, this.hand[this.hand.length - 1].pai3D);
					let length: number = hands.length;
					let fulldown_time: number = 100;


					Laya.timer.once(fulldown_time, this, () => {
						AudioMgr.PlayAudio(223);
						if (!view.DesktopMgr.Inst.record_show_hand) {
							for (let i: number = 0; i < length; i++) {
								this.hand[i].DoAnim_FullDown();
							}
						}
						if (zimo) {
							let p: HandPai3D = this.hand[this.hand.length - 1];
							p.SetVal(hupai, false);
							p.SetIndex(this.hand.length - 1, true);
							p.FullDown();
							if (view.DesktopMgr.Inst.xuezhan) {
								p.pai3D.isxuezhanhu = true;
								p.pai3D.OnChoosedPai();
							}
						}
					});
					return;
				} else {
					if (zimo) {
						let p: HandPai3D = this.hand[this.hand.length - 1];
						p.SetVal(hupai, false);
						p.SetIndex(this.hand.length - 1, true);
						p.FullDown();
						if (view.DesktopMgr.Inst.xuezhan) {
							p.pai3D.isxuezhanhu = true;
							p.pai3D.OnChoosedPai();
						}
						p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.2;
						p.shadow.active = false;
						//甩牌动画
						{
							let pos: Laya.Vector3 = p.pai3D.model.transform.position.clone();
							this.hand3d.transform.position = pos.clone();
							this.hand3d.getChildAt(0).getChildByName('node_tile').addChild(p.pai3D.model);
							p.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
							p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
							p.pai3D.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);

							let anim = view.ModelAnimationController.get_anim_config('Zimo', this.hand_type);
							this.playHandAnimtion(anim);
							Laya.timer.once(anim.keypoint[0], this, () => {
								view.AudioMgr.PlayAudio(227);
							});
							Laya.timer.once(anim.keypoint[1], this, () => {
								p.contianer_pai.addChild(p.pai3D.model);
								p.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
								p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
								p.FullDown();
								Laya.timer.once(100, this, () => DesktopMgr.Inst.ShowHuleEffect(p, p.pai3D.model.transform, DesktopMgr.Inst.player_effects[this.seat][game.EView.hupai_effect], this.seat, 1));
							});
						}
					}
					if (view.DesktopMgr.Inst.record_show_hand) {

					} else {
						let length: number = hands.length;
						let fulldown_time: number = zimo ? 1100 : 200;
						Laya.timer.once(fulldown_time, this, () => {
							AudioMgr.PlayAudio(223);
							for (let i: number = 0; i < length; i++) {
								this.hand[i].DoAnim_FullDown();
							}
						});
					}
				}
			}
		}

		public Huangpai(tingpai: boolean, hands: Array<mjcore.MJPai>, fast: boolean) {
			if (this.already_xuezhan_hule_state) {
				return;
			}

			if (this.seat < 0) return;
			app.Log.log('ViewPlayer_Other Huangpai ' + ' tingpai:' + tingpai + ' fast:' + fast);
			if (DesktopMgr.Inst.mode == EMJMode.play) {
				if (fast) {
					if (tingpai) {
						this.SetNum(hands.length);
						for (let i: number = 0; i < hands.length; i++) {
							this.hand[i].SetVal(hands[i], false);
							this.hand[i].FullDown();
						}
					} else {
						for (let i: number = 0; i < this.hand.length; i++) {
							this.hand[i].Cover();
						}
					}
					// for (let i:number = 0; i < hands.length; i++) {
					// 	this.hand[i].SetVal(hands[i], false);
					// 	this.hand[i].DoAnim_FullDown();
					// }
				} else {
					Laya.timer.once(300, this, () => {
						AudioMgr.PlayAudio(223);
						if (tingpai) {
							this.SetNum(hands.length);
							for (let i: number = 0; i < hands.length; i++) {
								this.hand[i].SetVal(hands[i], false);
								this.hand[i].DoAnim_FullDown();
							}

							if (view.DesktopMgr.Inst.is_chuanma_mode()) {
								for (let pai of this.hand) {
									pai.pai3D.is_gap = pai.val.type == this.gap_type;
									pai.pai3D.OnChoosedPai();
								}
							}
						} else {
							for (let i: number = 0; i < this.hand.length; i++) {
								this.hand[i].DoAnim_Cover();
							}
						}
					});
				}
			} else {
				if (!DesktopMgr.Inst.record_show_hand) {
					Laya.timer.once(300, this, () => {
						AudioMgr.PlayAudio(223);
						if (tingpai) {
							// for (let i:number = 0; i < hands.length; i++) {
							// 	this.hand[i].DoAnim_FullDown();
							// }
							if (!hands || hands.length == 0) {
								for (let i: number = 0; i < this.hand.length; i++) {
									this.hand[i].DoAnim_FullDown();
								}
							} else {
								for (let i: number = 0; i < hands.length; i++) {
									this.hand[i].SetVal(hands[i], false);
									this.hand[i].DoAnim_FullDown();
								}
							}

						} else {
							for (let i: number = 0; i < this.hand.length; i++) {
								this.hand[i].DoAnim_Cover();
							}
						}
					});
				}
			}

		}

		public onXuezhanMidHule(is_zimo: boolean, hupai: mjcore.MJPai, fast: boolean) {
			if (this.already_xuezhan_hule_state) {
				return;
			}
			this.already_xuezhan_hule_state = is_zimo ? 1 : 2;
			if (this.seat < 0) return;
			if (is_zimo) {
				this.pai_xuezhan_mid_zimo = hupai;
			}
			let length = is_zimo ? this.hand.length - 1 : this.hand.length;
			if (DesktopMgr.Inst.mode == EMJMode.play) {
				if (fast) {
					for (let i: number = 0; i < length; i++) {
						this.hand[i].Cover();
					}
				} else {
					Laya.timer.once(300, this, () => {
						AudioMgr.PlayAudio(223);

						for (let i: number = 0; i < length; i++) {
							this.hand[i].DoAnim_Cover();
						}
					});
				}
			} else {
				if (!DesktopMgr.Inst.record_show_hand) {
					if (fast) {
						for (let i: number = 0; i < length; i++) {
							this.hand[i].Cover();
						}
					} else {
						Laya.timer.once(300, this, () => {
							AudioMgr.PlayAudio(223);

							for (let i: number = 0; i < length; i++) {
								this.hand[i].DoAnim_Cover();
							}

						});
					}
					
				}
			}
			if (is_zimo) {
				this.showXuezhanMidZimoEffect(hupai, fast);
			}
		}
		public showXuezhanMidZimoEffect(hupai: mjcore.MJPai, fast: boolean = false) {
			let p: HandPai3D = this.hand[this.hand.length - 1];
			p.SetVal(hupai, false);
			p.SetIndex(this.hand.length - 1, true);
			p.FullDown();
			p.model.transform.localPosition.z += PAIMODEL_HEIGHT * 0.2;
			p.shadow.active = false;
			let pai: view.ViewPai = p.pai3D;
			pai.isxuezhanhu = true;
			pai.OnChoosedPai();
			let can_see: boolean = false;
			if (view.DesktopMgr.Inst.mode == EMJMode.paipu || view.DesktopMgr.Inst.mode == EMJMode.live_broadcast) {
				can_see = view.DesktopMgr.Inst.record_show_hand;
			}
			let record_show_anim = DesktopMgr.Inst.mode == EMJMode.play || DesktopMgr.Inst.record_show_anim;
			if (fast || !record_show_anim) {
				p.FullDown();
			} else {
				//甩牌动画
				{
					let pos: Laya.Vector3 = p.pai3D.model.transform.position.clone();
					this.hand3d.transform.position = pos.clone();
					this.hand3d.getChildAt(0).getChildByName('node_tile').addChild(p.pai3D.model);
					p.pai3D.model.transform.localPosition = new Laya.Vector3(0, 0, 0);
					p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 0, 0);
					p.pai3D.model.transform.localScale = new Laya.Vector3(1.1111, 1.1111, 1.1111);

					let anim = view.ModelAnimationController.get_anim_config('Zimo', this.hand_type);
					this.playHandAnimtion(anim);
					Laya.timer.once(anim.keypoint[0], this, () => {
						// 关键帧0：牌落地，放出声音
						view.AudioMgr.PlayAudio(227);
					});
					Laya.timer.once(anim.keypoint[1], this, () => {
						// 关键帧1：牌脱离手
						p.contianer_pai.addChild(p.pai3D.model);
						p.pai3D.model.transform.localScale = new Laya.Vector3(1, 1, 1);
						p.pai3D.model.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
						p.FullDown();

						Laya.timer.once(100, this, () => DesktopMgr.Inst.ShowHuleEffect(p, p.pai3D.model.transform, DesktopMgr.Inst.player_effects[this.seat][game.EView.hupai_effect], this.seat, 1));
					});
				}
			}
		}

		public onXuezhanEnd(hands: Array<mjcore.MJPai>, fast: boolean) {
			let show_hand = DesktopMgr.Inst.mode != EMJMode.play && DesktopMgr.Inst.record_show_hand;
			if (show_hand) return;
			for (let i: number = 0; i < hands.length; i++) {
				if (this.hand[i]) {
					this.hand[i].SetVal(hands[i], false);
					if (!fast) {
						this.hand[i].DoAnim_CoverToFulldown();
					} else {
						this.hand[i].FullDown();
					}
				}
			}
		}

		public onShowHandChange(v: boolean) {
			if (this.seat < 0) return;
			if (!view.DesktopMgr.Inst.gameing) return;
			if (!this.hand) return;
			for (let i: number = 0; i < this.hand.length; i++) {
				let can_see = v || this.hand[i].is_open;
				if (can_see) {
					this.hand[i].FullDown();
					if (!this.already_xuezhan_hule_state) {
						this.hand[i].pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(this.hand[i].pai3D.val);
						this.hand[i].pai3D.is_gap = this.gap_type == this.hand[i].pai3D.val.type;
						this.hand[i].pai3D.OnChoosedPai();
						this.hand[i].pai3D.RefreshDora();

					}
				}
				else {
					if (this.already_xuezhan_hule_state) {
						// 如果是自摸
						if (this.already_xuezhan_hule_state == 1 && i == this.hand.length - 1) continue;
						this.hand[i].Cover();
					} else {
						this.hand[i].Stand();
						this.hand[i].pai3D.RemoveDora();
						this.hand[i].pai3D.ispaopai = false;
						this.hand[i].pai3D.is_gap = false;
						this.hand[i].pai3D.ResetShow();
					}

				}
				// 透明牌炮牌显示
				if (view.DesktopMgr.Inst.is_jiuchao_mode() && this.hand[i].val.touming) {
					this.hand[i].pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(this.hand[i].pai3D.val);
					this.hand[i].pai3D.OnChoosedPai();
				}
			}

			let have_open: boolean = false;
			for (let i: number = 0; i < this.hand.length; i++) {
				if (this.hand[i].is_open || (view.DesktopMgr.Inst.is_tianming_mode() && this.hand[i].val.touming)) {
					have_open = true;
					break;
				}
			}
			if (have_open || view.DesktopMgr.Inst.is_jiuchao_mode()) { // 为了保留牌谱中的摸切信息，只在有明牌的时候排序
				let need_sort_touming = view.DesktopMgr.Inst.mode == EMJMode.play || !view.DesktopMgr.Inst.record_show_hand;
				this.hand.sort((a: HandPai3D, b: HandPai3D) => {
					let a_val: number = a.val.numValue() * 10 + (a.val.dora ? 0 : 1);
					let b_val: number = b.val.numValue() * 10 + (b.val.dora ? 0 : 1);
					if (!view.DesktopMgr.Inst.record_show_hand) {
						if (!a.is_open) a_val += 10000000;
						if (!b.is_open) b_val += 10000000;
					}
					if (need_sort_touming) {
						if (!a.val.touming) a_val += 10000000;
						if (!b.val.touming) b_val += 10000000;
					}
					if (a.IsNew()) a_val += 100000000;
					if (b.IsNew()) b_val += 100000000;
					if (a_val != b_val) {
						return a_val - b_val;
					} else {
						return a.index - b.index;
					}
				});
				for (let i: number = 0; i < this.hand.length; i++) {
					this.hand[i].SetIndex(i, this.hand[i].IsNew());
					if (view.DesktopMgr.Inst.is_tianming_mode() && this.hand[i].val.touming) {
						this.hand[i].FullDown();
						this.hand[i].pai3D.SetTianMingYellow(view.DesktopMgr.Inst.record_show_hand);
					} else if (this.hand[i].is_open || view.DesktopMgr.Inst.record_show_hand) {
						this.hand[i].FullDown();
					} else {
						this.hand[i].Stand();
					}
				}
			}
			if (view.DesktopMgr.Inst.is_reveal_mode()) {
				let state = view.DesktopMgr.Inst.record_show_hand ? view.ERevealState.self : view.ERevealState.reveal;
				this.container_qipai.ChangeRevealState(state);
			}
			this.container_ming.onShowHandChange();
		}

		public onShowPaopaiChange() {
			if (this.seat < 0) return;
			if (!view.DesktopMgr.Inst.gameing) return;
			for (let i: number = 0; i < this.hand.length; i++) {
				let can_see: boolean = false;
				if (view.DesktopMgr.Inst.mode == EMJMode.paipu || view.DesktopMgr.Inst.mode == EMJMode.live_broadcast) {
					can_see = this.hand[i].is_open || view.DesktopMgr.Inst.record_show_hand;
				} else if (view.DesktopMgr.Inst.mode == EMJMode.play) {
					can_see = this.hand[i].is_open;
				}
				if (can_see) {
					this.hand[i].pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(this.hand[i].pai3D.val);
					this.hand[i].pai3D.OnChoosedPai();
				}
				else this.hand[i].pai3D.ResetShow();
			}
		}

		public OnChoosePai(): void {
			if (this.seat < 0) return;
			super.OnChoosePai();
			for (let i: number = 0; i < this.hand.length; i++) {
				let can_see: boolean = false;
				if (view.DesktopMgr.Inst.mode == EMJMode.paipu || view.DesktopMgr.Inst.mode == EMJMode.live_broadcast) {
					can_see = this.hand[i].is_open || view.DesktopMgr.Inst.record_show_hand || (DesktopMgr.Inst.is_jiuchao_mode() && this.hand[i].val.touming);
				} else if (view.DesktopMgr.Inst.mode == EMJMode.play) {
					can_see = this.hand[i].is_open || this.hand[i].val.touming;
					if (this.already_xuezhan_hule_state == 1 && i == this.hand.length - 1) {
						can_see = true;
					}
				}

				if (can_see) {
					this.hand[i].pai3D.OnChoosedPai();
				}
				else { 
					this.hand[i].pai3D.ResetShow();
				} 
			}
		}

		public submitHandTile(out_tiles: Array<string>, fast: boolean = false): void {
			if (DesktopMgr.Inst.mode == EMJMode.play) {
				for (let i: number = 0; i < out_tiles.length; i++) {
					this._PlayRemoveHandPai(null, 0, true);
				}
				this._LiPai();
			} else {
				for (let i: number = 0; i < out_tiles.length; i++) {
					this._RecordRemoveHandPai(mjcore.MJPai.Create(out_tiles[i]), -1);
				}
				this._RecordLiPai();
			}
		}

		public takeHandTile(in_tiles: Array<string>, fast: boolean = false): void {
			if (DesktopMgr.Inst.mode == EMJMode.play) {
				this.LiPai(0, !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()));
				for (let i: number = 0; i < in_tiles.length; i++) {
					let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
					p.SetVal(mjcore.MJPai.Create('5z'), false, false);
					p.SetIndex(this.hand.length, false);
					p.Stand();
					p.pai3D.ResetShow();
					this.hand.push(p);
				}
			} else {
				for (let i: number = 0; i < in_tiles.length; i++) {
					let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
					p.SetVal(mjcore.MJPai.Create(in_tiles[i]), false, fast);
					p.SetIndex(this.hand.length, false);
					if (view.DesktopMgr.Inst.record_show_hand) {
						p.FullDown();
						p.pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(p.pai3D.val);
						p.pai3D.OnChoosedPai();
					}
					else {
						p.Stand();
						p.pai3D.ResetShow();
					}
					this.hand.push(p);
				}
				this._RecordLiPai();
				if (this.hand.length == 14) {
					this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true);
				}
			}
		}

		public onHuanSanZhang_Remove(): void {
			for (let i: number = 0; i < 3; i++) {
				this._PlayRemoveHandPai(null, 0, true);
			}
			this._LiPai();
		}

		public recordHuanSanZhang_Remove(out_tiles: Array<string>, out_tile_states: Array<number>) {
			for (let i: number = 0; i < out_tiles.length; i++) {
				this._RecordRemoveHandPai(mjcore.MJPai.Create(out_tiles[i]), out_tile_states[i]);
			}
			this._RecordLiPai();
		}

		public onHuanSanZhang_Add(): void {
			this.LiPai(0, !(view.DesktopMgr.Inst.is_jiuchao_mode() || DesktopMgr.Inst.is_open_hand()));
			for (let i: number = 0; i < 3; i++) {
				let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
				p.SetVal(mjcore.MJPai.Create('5z'), false);
				p.SetIndex(this.hand.length, this.hand.length == 14);
				p.Stand();
				p.pai3D.ResetShow();
				this.hand.push(p);
			}
		}

		public recordHuanSanZhang_Add(in_tiles: Array<string>, in_tile_states: Array<number>, fast: boolean = false) {
			for (let i: number = 0; i < in_tiles.length; i++) {
				let p: HandPai3D = new HandPai3D(this.trans_hand.parent as Laya.Sprite3D);
				p.SetVal(mjcore.MJPai.Create(in_tiles[i]), in_tile_states[i] != 0);
				p.SetIndex(this.hand.length, false);
				if (view.DesktopMgr.Inst.record_show_hand || in_tile_states[i] != 0) {
					p.FullDown();
					p.pai3D.ispaopai = DesktopMgr.Inst.isPaoPai(p.pai3D.val);
					p.pai3D.OnChoosedPai();
				}
				else {
					p.Stand();
					p.pai3D.ResetShow();
				}
				this.hand.push(p);
			}
			this._RecordLiPai();
			if (this.hand.length == 14) {
				this.hand[this.hand.length - 1].SetIndex(this.hand.length - 1, true);
			}
		}

		public refreshGapType() {
			for (let i = 0; i < this.hand.length; i++) {
				if (this.hand[i].is_open || (view.DesktopMgr.Inst.record_show_hand && view.DesktopMgr.Inst.mode != view.EMJMode.play)) {
					this.hand[i].pai3D.is_gap = this.gap_type == this.hand[i].val.type;
					this.hand[i].pai3D.OnChoosedPai();
				}
			}
		}

		public getTianMingRate(): number {
			let rate = 1;
			for (let hand of this.hand) {
				if (hand.val.touming) {
					rate++;
				}
			}
			for (let pai of this.container_ming.pais) {
				if (pai.val.touming) {
					rate++;
				}
			}
			return rate;
		}
	}
}