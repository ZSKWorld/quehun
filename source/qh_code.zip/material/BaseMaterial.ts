/**
* name 
*/
module caps {
	export class BaseMaterial extends Laya.BaseMaterial {

		constructor(shader_name: string) {
			super();
			if (shader_name != '') this.setShaderName(shader_name);
		}
		public static defineList: Array<{ key: string, value: number }>;
		public setInt(shaderIndex: number, i: number): void { this._setInt(shaderIndex, i); }
		public getInt(shaderIndex: number): any { return this._getInt(shaderIndex); }

		public setNumber(shaderIndex: number, number: number): void { this._setNumber(shaderIndex, number); }
		public getNumber(shaderIndex: number): any { return this._getNumber(shaderIndex); }

		public setBool(shaderIndex: number, b: boolean): void { this._setBool(shaderIndex, b); }
		public getBool(shaderIndex: number): any { return this._getBool(shaderIndex); }

		public setVector2(shaderIndex: number, vector2: Laya.Vector2): void { this._setVector2(shaderIndex, vector2); }
		public getVector2(shaderIndex: number): any { return this._getVector2(shaderIndex); }

		public setColor(shaderIndex: number, color: any): void { this._setColor(shaderIndex, color); }
		public getColor(shaderIndex: number): any { return this._getColor(shaderIndex); }

		public setTexture(shaderIndex: number, texture: Laya.BaseTexture): void { this._setTexture(shaderIndex, texture); }
		public getTexture(shaderIndex: number): Laya.BaseTexture { return this._getTexture(shaderIndex); }

		public addShaderDefine(matName: string, name: string) {
			if (caps[matName] && caps[matName].defineList) {
				for (let define of caps[matName].defineList) {
					if (define.key == name) {
						this._addShaderDefine(define.value);
						return;
					}
				}
			}

		}
	}
}