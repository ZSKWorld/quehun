/**
* name 
*/
module caps{
	export class Material_Clip extends caps.BaseMaterial{

		constructor(shader_name:string) {
			super(shader_name);

			// this.cull = 0;
			// this.blend = 0;
			// this.srcBlend = 1;
			// this.dstBlend = 0;
			// this.alphaTest = false;
			// this.depthWrite = true;
			// this.renderQueue = 1;

			this.cull = 2;
			this.blend = 1;
			this.srcBlend = 770;
			this.dstBlend = 771;
			this.alphaTest = true;
			this.depthWrite = true;
			this.renderQueue = 2;
		}
	}
}