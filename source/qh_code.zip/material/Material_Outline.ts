/**
* name 
*/
module caps{
	export class Material_Outline extends caps.BaseMaterial {

		constructor(shader_name:string) {
			super(shader_name);

			// this.cull = BaseMaterial.CULL_FRONT;;
			// this.blend = 0;
			// this.srcBlend = 1;
			// this.dstBlend = 0;
			// this.alphaTest = false;
			// this.depthWrite = true;
			// this.renderQueue = 1;

			this.cull = BaseMaterial.CULL_FRONT;
			this.blend = 1;
			this.srcBlend = 770;
			this.dstBlend = 771;
			this.alphaTest = true;
			this.depthWrite = false;
			this.renderQueue = 3001;
		}
	}
}