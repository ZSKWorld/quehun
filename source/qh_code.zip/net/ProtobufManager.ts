// import * as protobuf from '../libs/protobuf';


module net {
  
  export class ProtobufManager {

    /**
     * load proto files
     * @param {string} baseDir top level directory
     * @returns {Promise<void>}
     */
    static loadProto(descriptor: any) {

      this.root = protobuf.Root.fromJSON(descriptor);

      this.root.resolveAll();

      console.log(`loadProto finished`);
    }

    /**
     * Looks up the reflection object at the specified path, relative to this namespace.
     * @param path Path to look up
     * @param [parentAlreadyChecked=false] Whether the parent has already been checked
     * @returns Looked up object or `null` if none could be found
     */
    static lookup(path: (string|string[]), parentAlreadyChecked?: boolean): (protobuf.ReflectionObject|null) {
      return this.root.lookup(path, parentAlreadyChecked);
    }

    /**
     * Looks up the {@link Type|type} at the specified path, relative to this namespace.
     * Besides its signature, this methods differs from {@link Namespace#lookup|lookup} in that it throws instead of returning `null`.
     * @param path Path to look up
     * @returns Looked up type
     * @throws {Error} If `path` does not point to a type
     */
    static lookupType(path: (string|string[])): protobuf.Type {
      return this.root.lookupType(path);
    }

    /**
     * Looks up the values of the {@link Enum|enum} at the specified path, relative to this namespace.
     * Besides its signature, this methods differs from {@link Namespace#lookup|lookup} in that it throws instead of returning `null`.
     * @param path Path to look up
     * @returns Looked up enum
     * @throws {Error} If `path` does not point to an enum
     */
    static lookupEnum(path: (string|string[])): any {
      return this.root.lookupEnum(path);
    }

    /**
     * Looks up the {@link Type|type} or {@link Enum|enum} at the specified path, relative to this namespace.
     * Besides its signature, this methods differs from {@link Namespace#lookup|lookup} in that it throws instead of returning `null`.
     * @param path Path to look up
     * @returns Looked up type or enum
     * @throws {Error} If `path` does not point to a type or enum
     */
    static lookupTypeOrEnum(path: (string|string[])): any {
      return this.root.lookupTypeOrEnum(path);
    }

    /**
     * Looks up the {@link Service|service} at the specified path, relative to this namespace.
     * Besides its signature, this methods differs from {@link Namespace#lookup|lookup} in that it throws instead of returning `null`.
     * @param path Path to look up
     * @returns Looked up service
     * @throws {Error} If `path` does not point to a service
     */
    static lookupService(path: (string|string[])): any {
      return this.root.lookupService(path);
    }

    static lookupMethod(path: (string|string[])): any {
      if (typeof(path) == 'string')
        path = path.split('.');

      if (path.length === 0)
        return null;

      const service = this.lookupService(path.slice(0, -1));
      if (!service)
        return null;

      const method = path[path.length - 1];
      return service.methods[method];
    }


    private static root: protobuf.Root;
  }

}
