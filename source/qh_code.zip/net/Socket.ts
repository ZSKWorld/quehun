
module net {

  export class Socket {

    constructor(service_list:Array<string>, code_error_handler:Laya.Handler) {
      this.byte_ = new Laya.Byte();
      this.byte_.endian = Laya.Byte.LITTLE_ENDIAN;

      this.socket_ = new Laya.Socket();
      this.socket_.endian = Laya.Byte.LITTLE_ENDIAN;

      this.messages_ = [];
      this.workingMessage_ = null;
      this.requestIndex_ = 0;
      this.requestClientHandle_ = new RequestClientHandle(code_error_handler, new Laya.Handler(this, delay => {
        this.network_delay = delay;
      }));

      this.handler_ = {};
      this.services_ = {};

      //注册回调
      this.socket_.on(Laya.Event.OPEN, this, this._onOpen);
      this.socket_.on(Laya.Event.MESSAGE, this, this._onReceiveMsg);
      this.socket_.on(Laya.Event.CLOSE, this, this._onClose);
      this.socket_.on(Laya.Event.ERROR, this, this._onError);

      if (service_list) {
        for (let i:number = 0; i < service_list.length; i++) {
          this._registerService(service_list[i]);
        }
      }
    }

    public connect(url: string) {
      this.socket_.connectByUrl(url);
    }

    get connected(): boolean {
      return this.socket_.connected;
    }

    private _onOpen(event: any = null): void {
      app.Log.log(`socket连接建立成功`);
      app.Log.info_net('socket open success');
      if (this.when_socket_event) this.when_socket_event.runWith(Laya.Event.OPEN);
    }

    private _onReceiveMsg(data: any = null): void {
      // console.log(`接收到数据触发函数`);

      if (!data || data.length === 0) {
        app.Log.Error(`!data || data.length === 0`);
        app.Log.info_net('error receive msg: !data || data.length === 0');
        return;
      }
      
      // app.Log.info_net('receive msg data.length:' + data.length);
      this.messages_.push(new Uint8Array(data));
      this._checkMessage();
    }

    private _onClose(e: any = null): void {
      app.Log.log(`socket关闭 e:` + e);
      app.Log.info_net(`socket关闭 e:` + JSON.stringify(e) + ', code:' + e.code + ', reason:' + e.reason + ', wasClean:' + e.wasClean);
      // console.log(e);
      if (this.when_socket_event) this.when_socket_event.runWith(Laya.Event.CLOSE);
    }
    private _onError(e: any = null): void {
      app.Log.log('socket错误 e:' + e);
      app.Log.info_net(`socket错误 e:` + JSON.stringify(e));
      // console.log(e);
      if (this.when_socket_event) this.when_socket_event.runWith(Laya.Event.ERROR);
    }

    //收到消息后，拆包循环
    private _checkMessage() {
      if (this.workingMessage_)
        return;

      if (this.messages_.length === 0)
        return;

      this.workingMessage_ = this.messages_.shift();

      this._handleMsg(this.workingMessage_);
      this.workingMessage_ = null;

      return this._checkMessage();
    }

    private _handleMsg(data: Uint8Array) {

      const header: HeaderData = {
        type: data[0]
      };

      // console.log(`handleMsg: type=${header.type}, data=${data}`);

      // handle header
      switch (header.type) {

        case HeaderType.REQUEST:
        case HeaderType.RESPONSE: {

          if (data.length < 3) {
            throw new Error(`ERR_INVALID_MESSAGE_LENGTH`);
          }

          header.reqIndex = data[1] + (data[2] << 8);
          data = data.slice(3);
          break;
        }

        case HeaderType.NOTIFY:
          data = data.slice(1);
          break;

        default:
          console.error('net', `unknown headerType: ${header.type}`);
          return;
      }

      // app.Log.info_net('socket _handleMsg0 header.type:' + header.type + ', data.length:' + data.length);

      // handle data
      switch (header.type) {

        case HeaderType.REQUEST: {
          throw new Error(`ERR_CLIENT_UNABLE_TO_HANDLE_REQUEST`);
        }

        case HeaderType.RESPONSE: {
          // console.log('net', `handle RESPONSE: index=${header.reqIndex}`);
          const wrapper = MessageWrapper.decodeRpc(data);
          return this.requestClientHandle_.emitResponse(header.reqIndex, wrapper.data);
        }

        case HeaderType.NOTIFY: {
          const message = MessageWrapper.decodeMessage(data);
          const handler = this.handler_[message.$type.fullName];
          // console.log('socket _handleMsg1 fullName:' + message.$type.fullName);
          if (!handler) {
            app.Log.Error('消息:' + message.$type.fullName + '未被监听');
            return ;
          }
          for (let i:number = 0; i < handler.length; i++) {
            try {
              handler[i].runWith(message);
            } catch(err) {
              app.Log.Error('message ' + message.$type.fullName + ' handle error info:' + err);
              if (this.code_error_handler) this.code_error_handler.runWith({method: message.$type.fullName, info: err});
            }
          }
          return ;
        }

        default:
          console.error('net', `unknown headerType: ${header.type}`);
          return;
      }
    }

    private _requestMessage(method: string, request: any, cb) {
      this.requestIndex_ = (this.requestIndex_ + 1) % 60007;
      app.Log.info_net('_requestMessage method:' + method + ', index:' + this.requestIndex_);

      this._sendRpc(method, {
        header: {
          type: HeaderType.REQUEST,
          reqIndex: this.requestIndex_
        },
        packet: request
      });
      this.requestClientHandle_.waitResponseCb(method, this.requestIndex_, cb);
    }

    private _registerService(service: string) {
      const Service = ProtobufManager.lookupService(`lq.${service}`);
      if (!Service)
        throw new Error(`ERR_SERVICE_NOT_FOUND, name=${service}`);

      const serv = Service.create((method, requestData, callback) => {
        // console.log(`method=${method.fullName}, request=${JSON.stringify(requestData)}`);
        this._requestMessage(method.fullName, requestData, callback);
      });

      this.services_[service] = serv;
    }

    private _sendMessage(message: any) {
      if (!this.socket_)
        throw new Error('ERR_SOCKET_NOT_CONNECT');

      const header = MessageWrapper.encodeHeaderData(message.header);
      const packet = MessageWrapper.encodeMessage(message.packet);

      const by: Laya.Byte = new Laya.Byte();
      by.writeArrayBuffer(header);
      by.writeArrayBuffer(packet);

      this.socket_.send(by.buffer);
      app.Log.info_net('socket _sendMessage');
    }
  
    private _sendRpc(method: string, message: any) {
      if (!this.socket_)
        throw new Error('ERR_SOCKET_NOT_CONNECT');

      const header = MessageWrapper.encodeHeaderData(message.header);
      const packet = MessageWrapper.encodeRpc(method, message.packet);

      const by: Laya.Byte = new Laya.Byte();
      by.writeArrayBuffer(header);
      by.writeArrayBuffer(packet);

      this.socket_.send(by.buffer);
      app.Log.info_net('socket _sendRpc');
    }

    public sendMessage(msg_type:string, data:any) {
      app.Log.info_net('socket sendMessage msg_type:' + msg_type);
      let protoCreator = ProtobufManager.lookupType(msg_type);
      if (protoCreator) {
        this._sendMessage({
          header: {type: HeaderType.NOTIFY},
          packet: protoCreator.create(data),
        });
      } else {
        app.Log.Error('sendMessage msg_type:' + msg_type + '未找到');
      }
    }

    public sendRequest(service_name:string, rpc_name:string, data: any, func_response: (error, res) => void) {
      app.Log.info_net('socket sendRequest service_name:' + service_name + ', rpc_name:' + rpc_name);
      // // ==DevDebug Start==
      // if (this.checkHttpRequest(service_name, rpc_name, data, func_response)) {
      //   return;
      // }
      // // ==DevDebug End==
        const _service = this.services_[service_name];
        if (!_service) {
          throw new Error(`ERR_SERVICE_NOT_FOUND, name=FastTest`);
        }
        _service[rpc_name](data, func_response);
    }

    public addMsgListener(name: string, cb: Laya.Handler) {
      if (!this.handler_[name]) this.handler_[name] = [];
      let lst = this.handler_[name];
      for (let i: number = 0; i < lst.length; i++) {
        if (lst[i] === cb) {
          return;
        }
      }
      this.handler_[name].push(cb);
      //this.handler_[name] = cb;
    }

    public removeMsgListener(name: string, cb: Laya.Handler) {
      if (!this.handler_[name]) return;
      let lst = this.handler_[name];
      let new_lst = [];
      for (let i: number = 0; i < lst.length; i++) {
        if (lst[i] !== cb) {
          new_lst.push(lst[i]);
        }
      }
      this.handler_[name] = new_lst;
    }    

    public addSocketLister(cb:Laya.Handler) {
      this.when_socket_event = cb;
    }

    public close() {
      app.Log.info_net('socket close');
      if (this.socket_) this.socket_.close();
      if (this.requestClientHandle_) this.requestClientHandle_.onClose();
    }

    //网络延时
    public getNetworkDelay():number {
      return this.network_delay;
    }

    private socket_: Laya.Socket;
    private byte_: Laya.Byte;

    private messages_: Uint8Array[];
    private workingMessage_: Uint8Array;

    private requestIndex_: number; // request index
    private requestClientHandle_: RequestClientHandle;

    private handler_: any;
    private services_: any;

    private when_socket_event: Laya.Handler;
    private code_error_handler: Laya.Handler; //当客户端trycatch出错的时候的处理
    private network_delay: number = 0; //粗略的网络延时

    // ==DevDebug Start==
    // 发协议改为发http
    private sendHttpList: Array<{service_name:string, rpc_name:string, api: string}> = [{service_name: 'Lobby', rpc_name: 'fetchGameRecordListV2', api: '/api/account/recent_games/v2'},
      { service_name: 'Lobby', rpc_name: 'fetchGameRecordList', api: '/api/account/recent_games/v0' },
      { service_name: 'Lobby', rpc_name: 'fetchNextGameRecordList', api: '/api/account/recent_games/v2/next' }];
    private baseHttpUrl: string = 'http://alb-thg20cvevppic57qzg.cn-hangzhou.alb.aliyuncs.com:8090/reader';
    private checkHttpRequest(service_name:string, rpc_name:string, data: {[key: string]: any}, func_response: (error, res) => void): boolean {
      for (let info of this.sendHttpList) {
        if (info.service_name == service_name && info.rpc_name == rpc_name) {
          let url = this.baseHttpUrl + info.api;
          // 有一些可能要特殊拼接的有需求再加
          url += '?account_id=' + GameMgr.Inst.account_id;
          if (data) {
            for (let key in data) {
              url = this.dfsCheckData(key, data[key], url);  
            }
          }
          
          game.LoadMgr.httpload(url, "json", false, Laya.Handler.create(this, d => {
						if (!d.success) {
							func_response(new Error(`TIMEOUT`), null);
            } else {
              if (d.data) {
                let res_type = '';
                let service = ProtobufManager.lookupService('lq.' + service_name);
                for (let method in service.methods) { 
                  if (method == rpc_name) { 
                    res_type = service.methods[method].responseType;
                    break;
                  }
                }
                
                let finalData = ProtobufManager.lookupType('lq.' + res_type).fromObject(d.data.data);
                func_response(null, finalData);
              } else { 
                func_response(new Error(`Data Error`), null);
              }
							
						}
					}));

          return true;
        }
      }
      return false;
    }


    // 目前只接受string,number和普通的array<number><string>，复杂的不接受
    private dfsCheckData(key: string, data: any, url: string): string {
      if (typeof data == 'object') {
        for (let _info of data) {
          url += `&${key}=${_info}`;
        }
      } else {
        url += `&${key}=${data}`;
      }
      return url;
    }
    // ==DevDebug End==
  }
}