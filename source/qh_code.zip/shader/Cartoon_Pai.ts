/**
* name 
*/
module caps{
	export class Cartoon_Pai {
		public static TEXTURE: number = 1;
		public static COLOR: number = 2;
		public static ALPHA: number = 3;
		public static TILING_OFFSET: number = 4;
		public static SPLIT: number = 10;
		public static COLOR_LIGHT: number = 30;
		public static COLOR_UNLIGHT: number = 31;

		public static get filename():string {
			return 'cartoon_pai';
		}

		public static get attributeMap():Object {
			return {
				'a_BoneIndices': Laya.VertexElementUsage.BLENDINDICES0,
				'a_BoneWeights': Laya.VertexElementUsage.BLENDWEIGHT0,
				'a_Position': Laya.VertexElementUsage.POSITION0,
				'a_Normal': Laya.VertexElementUsage.NORMAL0,
				'a_Texcoord': Laya.VertexElementUsage.TEXTURECOORDINATE0
        	};
		}

		public static get uniformMap():Object {
			return {
				'u_Bones': [Laya.SkinnedMeshSprite3D.BONES, Laya.Shader3D.PERIOD_RENDERELEMENT],
				'u_CameraPos': [Laya.BaseCamera.CAMERAPOS, Laya.Shader3D.PERIOD_CAMERA],
				'u_MvpMatrix': [Laya.Sprite3D.MVPMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_WorldMat': [Laya.Sprite3D.WORLDMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_texture': [this.TEXTURE, Laya.Shader3D.PERIOD_MATERIAL],
				'u_DirectionLight.Direction': [Laya.Scene.LIGHTDIRECTION, Laya.Shader3D.PERIOD_SCENE],
				'u_DirectionLight.Diffuse': [Laya.Scene.LIGHTDIRCOLOR, Laya.Shader3D.PERIOD_SCENE],
				'u_split':[this.SPLIT, Laya.Shader3D.PERIOD_MATERIAL],
				'u_color':[this.COLOR, Laya.Shader3D.PERIOD_MATERIAL],
				'u_alpha':[this.ALPHA, Laya.Shader3D.PERIOD_MATERIAL],
				'u_TilingOffset':[this.TILING_OFFSET, Laya.Shader3D.PERIOD_MATERIAL],
				'u_color_light':[this.COLOR_LIGHT, Laya.Shader3D.PERIOD_MATERIAL],
				'u_color_unlight':[this.COLOR_UNLIGHT, Laya.Shader3D.PERIOD_MATERIAL],
        	};
		}
	}
}