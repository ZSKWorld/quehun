/**
* name 
*/
module caps{
	export class Outline{
		public static OUTLINE: number = 1;
		public static OUTLINE_COLOR: number = 2;
		public static OUTLINE_ALPHA: number = 3;

		public static get filename():string {
			return 'outline';
		}

		public static get attributeMap():Object {
			return {
				'a_BoneIndices': Laya.VertexElementUsage.BLENDINDICES0,
				'a_BoneWeights': Laya.VertexElementUsage.BLENDWEIGHT0,
				'a_Position': Laya.VertexElementUsage.POSITION0,
				'a_Normal': Laya.VertexElementUsage.NORMAL0,
				'a_Texcoord': Laya.VertexElementUsage.TEXTURECOORDINATE0
        	};
		}

		public static get uniformMap():Object {
			return {
				'u_Bones': [Laya.SkinnedMeshSprite3D.BONES, Laya.Shader3D.PERIOD_RENDERELEMENT],
				'u_CameraPos': [Laya.BaseCamera.CAMERAPOS, Laya.Shader3D.PERIOD_CAMERA],
				'u_MvpMatrix': [Laya.Sprite3D.MVPMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_WorldMat': [Laya.Sprite3D.WORLDMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				//'u_texture': [this.TEXTURE, Laya.Shader3D.PERIOD_MATERIAL],
				'u_SpotLight.Position': [Laya.Scene.SPOTLIGHTPOS, Laya.Shader3D.PERIOD_SCENE],
				'u_DirectionLight.Diffuse': [Laya.Scene.LIGHTDIRCOLOR, Laya.Shader3D.PERIOD_SCENE],
				'u_outline':[this.OUTLINE, Laya.Shader3D.PERIOD_MATERIAL],
				'u_outline_color':[this.OUTLINE_COLOR, Laya.Shader3D.PERIOD_MATERIAL],
				'u_outline_alpha':[this.OUTLINE_ALPHA, Laya.Shader3D.PERIOD_MATERIAL],
        	};
		}
	}
}