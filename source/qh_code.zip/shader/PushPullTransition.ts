/**
* name 
*/
module caps{
	export class PushPullTransition {
		public static TEXTURE: number = 1;
        public static _SecondTex: number = 2;
		public static _Interpolation: number = 3;
		public static _Direction: number = 4;

		public static get filename():string {
			return 'pushpull_transition';
		}

		public static get attributeMap():Object {
			return {
				'a_BoneIndices': Laya.VertexElementUsage.BLENDINDICES0,
				'a_BoneWeights': Laya.VertexElementUsage.BLENDWEIGHT0,
				'a_Position': Laya.VertexElementUsage.POSITION0,
				'a_Normal': Laya.VertexElementUsage.NORMAL0,
				'a_Texcoord': Laya.VertexElementUsage.TEXTURECOORDINATE0
        	};
		}

		public static get uniformMap():Object {
			return {
				'u_Bones': [Laya.SkinnedMeshSprite3D.BONES, Laya.Shader3D.PERIOD_RENDERELEMENT],
				'u_CameraPos': [Laya.BaseCamera.CAMERAPOS, Laya.Shader3D.PERIOD_CAMERA],
				'u_MvpMatrix': [Laya.Sprite3D.MVPMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_WorldMat': [Laya.Sprite3D.WORLDMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_texture': [this.TEXTURE, Laya.Shader3D.PERIOD_MATERIAL],
				'u_DirectionLight.Direction': [Laya.Scene.LIGHTDIRECTION, Laya.Shader3D.PERIOD_SCENE],
				'u_DirectionLight.Diffuse': [Laya.Scene.LIGHTDIRCOLOR, Laya.Shader3D.PERIOD_SCENE],
				'u_SecondTex':[this._SecondTex, Laya.Shader3D.PERIOD_MATERIAL],
				'u_Interpolation':[this._Interpolation, Laya.Shader3D.PERIOD_MATERIAL],
                'u_Direction':[this._Direction, Laya.Shader3D.PERIOD_MATERIAL],
        	};
		}
	}
}