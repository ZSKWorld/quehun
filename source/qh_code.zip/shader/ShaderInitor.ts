/*
* name;
*/
module caps{
    interface shader_item {
        name:string;
        vs_loaded:boolean;
        ps_loaded:boolean;
        self_ok:boolean;
    }

    
    export class ShaderInitor{
        private _init_state: number = 0; //0:未初始化，1：正在初始化，2：初始化完成
        private _complete: Laya.Handler;
        private _items: Array<shader_item> = [];
        private _loading_num:number = 0;

        constructor() {

        }

        //过滤文件字符串中多出来的\r
        public static filterString(str:string): string {
            let s:string = '';
            let current_index:number = 0;
            while(current_index < str.length) {
                let index:number = str.indexOf('\r', current_index);
                if (index != -1) {
                    if (current_index < index) {
                        s += str.substring(current_index, index);
                    }
                    current_index = index + 1;
                } else {
                    s += str.substring(current_index, str.length);
                    break;
                }
            }
            return s;
        }

        public init(complete: Laya.Handler) {
            this._complete = complete;
            if (this._init_state == 2) {
                if (this._complete) this._complete.run();
                return ;
            }
            if (this._init_state == 0) {
                this._init_state = 1;
                this._loading_num = 0;
                //this.init_myShader();
                
                this._init(Shader_RanShao.filename, Shader_RanShao.attributeMap, Shader_RanShao.uniformMap);
                this._init(Cartoon.filename, Cartoon.attributeMap, Cartoon.uniformMap);
                this._init(Outline.filename, Outline.attributeMap, Outline.uniformMap);
                this._init(TwoSided.filename, TwoSided.attributeMap, TwoSided.uniformMap);
                this._init(TouMingPai.filename, TouMingPai.attributeMap, TouMingPai.uniformMap);
                this._init(Cartoon_Alpha.filename, Cartoon_Alpha.attributeMap, Cartoon_Alpha.uniformMap);
                this._init(Cartoon_Tile_Back.filename, Cartoon_Tile_Back.attributeMap, Cartoon_Tile_Back.uniformMap);
                this._init(Cartoon_Pai.filename, Cartoon_Pai.attributeMap, Cartoon_Pai.uniformMap);
                this._init(ColorAdjustment.filename, ColorAdjustment.attributeMap, ColorAdjustment.uniformMap);
                this._init(ColorOverlay.filename, ColorOverlay.attributeMap, ColorOverlay.uniformMap);
                this._init(TextureBlend.filename, TextureBlend.attributeMap, TextureBlend.uniformMap, TextureBlend.defineList);
                this._init(GaussianBlur.filename, GaussianBlur.attributeMap, GaussianBlur.uniformMap);
                this._init(PushPullTransition.filename, PushPullTransition.attributeMap, PushPullTransition.uniformMap);
            }
        }

        private _create_complete(shader_name: string) {
            this._loading_num--;
            if (this._loading_num == 0) {
                this._init_state = 2;
                if (this._complete) this._complete.run();
            }
        }

        private _init(shader_name:string, attributeMap:Object, uniformMap:Object, defines?: Array<{key: string, value: number}>) {
            var self = this;
            var ps:string = null;
            var vs:string = null;
            this._loading_num++;
            
            function loaded_all() {
                if (ps == null || vs == null) return;
                var shaderID: number = Laya.Shader3D.nameKey.add(shader_name);
                let compile = Laya.ShaderCompile3D.add(shaderID, vs, ps, attributeMap, uniformMap);
                if (defines) {
                    for (let define of defines) {
                        define.value = compile.registerMaterialDefine(define.key);
                    }
                }
                self._create_complete(shader_name);
            }

            var vs_path = 'shader/' + shader_name + '/' + shader_name + '.vs'
            Laya.loader.load(vs_path, Laya.Handler.create(this, () => { Laya.timer.frameOnce(1, this, () => {
                vs = ShaderInitor.filterString(Laya.loader.getRes(vs_path));
                loaded_all();
            })}));
            var ps_path = 'shader/' + shader_name + '/' + shader_name + '.ps'
            Laya.loader.load(ps_path, Laya.Handler.create(this, () => { Laya.timer.frameOnce(1, this, () => {
                ps = ShaderInitor.filterString(Laya.loader.getRes(ps_path));
                loaded_all();
            })}));
        }
    }
}