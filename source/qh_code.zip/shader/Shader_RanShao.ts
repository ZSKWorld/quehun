/**
* name 
*/
module caps{
	export class Shader_RanShao {

		public static TEXTURE1: number = 1;
		public static TEXTURE2: number = 2;
		public static TEXTURE_MASK: number = 3;
		public static ALPHA_CLIP: number = 4;
		public static BOUND: number = 5;

		public static get filename():string {
			return 'shader_ranshao';
		}

		public static get attributeMap():Object {
			return {
				'a_BoneIndices': Laya.VertexElementUsage.BLENDINDICES0,
				'a_BoneWeights': Laya.VertexElementUsage.BLENDWEIGHT0,
				'a_Position': Laya.VertexElementUsage.POSITION0,
				'a_Normal': Laya.VertexElementUsage.NORMAL0,
				'a_Texcoord': Laya.VertexElementUsage.TEXTURECOORDINATE0
        	};
		}

		public static get uniformMap():Object {
			return {
				'u_CameraPos': [Laya.BaseCamera.CAMERAPOS, Laya.Shader3D.PERIOD_CAMERA],
				'u_MvpMatrix': [Laya.Sprite3D.MVPMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_WorldMat': [Laya.Sprite3D.WORLDMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_texture1': [this.TEXTURE1, Laya.Shader3D.PERIOD_MATERIAL],
				'u_texture2': [this.TEXTURE2, Laya.Shader3D.PERIOD_MATERIAL],
				'u_texture_mask': [this.TEXTURE_MASK, Laya.Shader3D.PERIOD_MATERIAL],
				'u_alpha_clip': [this.ALPHA_CLIP, Laya.Shader3D.PERIOD_MATERIAL],
				'u_DirectionLight.Direction': [Laya.Scene.LIGHTDIRECTION, Laya.Shader3D.PERIOD_SCENE],
				'u_DirectionLight.Diffuse': [Laya.Scene.LIGHTDIRCOLOR, Laya.Shader3D.PERIOD_SCENE],
				'u_bound': [this.BOUND, Laya.Shader3D.PERIOD_MATERIAL],
        	};
		}
	}
}