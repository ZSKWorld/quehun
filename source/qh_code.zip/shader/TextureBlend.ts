/**
* name 
*/
module caps{
	export class TextureBlend {
		public static TEXTURE: number = 1;
		public static _BlendTex: number = 2;
        public static _Interpolation: number = 10;

		public static get filename():string {
			return 'texture_blend';
		}

		public static get attributeMap():Object {
			return {
				'a_BoneIndices': Laya.VertexElementUsage.BLENDINDICES0,
				'a_BoneWeights': Laya.VertexElementUsage.BLENDWEIGHT0,
				'a_Position': Laya.VertexElementUsage.POSITION0,
				'a_Texcoord': Laya.VertexElementUsage.TEXTURECOORDINATE0
        	};
		}

		public static get uniformMap():Object {
			return {
				'u_Bones': [Laya.SkinnedMeshSprite3D.BONES, Laya.Shader3D.PERIOD_RENDERELEMENT],
				'u_CameraPos': [Laya.BaseCamera.CAMERAPOS, Laya.Shader3D.PERIOD_CAMERA],
				'u_MvpMatrix': [Laya.Sprite3D.MVPMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_WorldMat': [Laya.Sprite3D.WORLDMATRIX, Laya.Shader3D.PERIOD_SPRITE],
				'u_MainTex': [this.TEXTURE, Laya.Shader3D.PERIOD_MATERIAL],
                'u_BlendTex': [this._BlendTex, Laya.Shader3D.PERIOD_MATERIAL],
                'u_Interpolation': [this._Interpolation, Laya.Shader3D.PERIOD_MATERIAL]
        	};
		}

		
        public static defineList: Array<{key: string, value: number}> = [{key: 'BLENDMODE_SCREEN', value: 0}, {key: 'BLENDMODE_OVERLAY', value: 0}];
	}
}