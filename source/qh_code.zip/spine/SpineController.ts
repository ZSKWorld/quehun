/**
* name  全新的spine控制节点，特效+多层支持,并不是sprite
*/
module CatFoodSpine {

	interface SpineAnim {
		skeleton: spine.Skeleton;
		anim: spine.AnimationState;
		bounds: { offset: spine.Vector2, size: spine.Vector2 };
		premultipliedAlpha: boolean;
		effect_map?: Object;
	}

	export enum ESpineState { none, loading, loaded, failed } // 加载状态

	export class SpineController {

		public static Inst: SpineController;
		public static spineSuffix: string = '.skel.txt';
		public static atlasSuffix: string = '.atlas.txt';

		public id: number = 0;
		
        private spines: Array<SpineSprite>;
        public root: Laya.Sprite;
        private count: number;
		public state: ESpineState = ESpineState.none;
		private path: string;
		private initAnimInfo: { anim: string, loop: boolean} = { anim: 'idle', loop: false };
		private animTime = {};
		public list_offsetX: Array<number> = []; // 整体偏移
		public list_offsetY: Array<number> = []; // 整体偏移
		public list_pX: Array<number> = []; // 放大缩小的居中点偏移
		public list_pY: Array<number> = []; // 放大缩小的居中点偏移
		public list_sx: Array<number> = [];; // 初始放大缩小
		public list_sy: Array<number> = []; // 初始放大缩小

        public offsetX: number = 695; // 整体偏移
		public offsetY: number = 610; // 整体偏移
		public pX: number = 0; // 放大缩小的居中点偏移
		public pY: number = 0; // 放大缩小的居中点偏移
		public sx: number = 0.96; // 初始放大缩小
		public sy: number = 0.96; // 初始放大缩小
		public aniAlpha: boolean = false; //透明度开关
		public calScrollRectPos: boolean = false; //spine坐标计算时候是否包含裁剪容器的scrollRect，spine在滚动列表或具有裁剪效果容器中需要打开
		public customIdleAni: string = null; // 自定义idle动画
		public animSpeed: number = null; // 时间缩放

		private scale: number = 1; // 特效scale
		private effect_offset: Laya.Point = new Laya.Point(); // 特效偏移
		private skin_data: lqc.Sheet_ItemDefinition_Skin;
		private anim_name: string;
		private effects: Array<SpineEffect>;


        private loadover_handler: Laya.Handler;

        constructor() {
            this.root = new Laya.Sprite;
            this.spines = [];
			this.effects = [];
            for (let i = 0; i < 3; i++) {
                let spine = new SpineSprite();
                this.root.addChild(spine);
                this.spines.push(spine);
            }
        }
		// 23/11/14 haitao skin_data传特效名，_scale为特效scale
		public load(path: string, skin_data: lqc.Sheet_ItemDefinition_Skin) {
			
			this.state = ESpineState.loading;
			this.path = path;
			this.skin_data = skin_data;
			let _spine_data = cfg.character.skin.get(skin_data.id);
			let count = _spine_data ? _spine_data.spine_layers : 1; // 默认为1层
            this.count = count;
			let index: number = 0;
			let max_count: number = 2 * count;
			for (let i = 0; i < 3; i++) {
				if (i < count) {
					this.spines[i].init(this, this.count == 1 ? this.path + '/spine' : this.path + '/spine_' + i);
				} else {
					this.spines[i].reset();
				}
			}
			let loadOver = () => {
				index++;
				if (this.state == ESpineState.failed) return;
				if (index == max_count) {
					if (path != this.path) {
						return; 
					}
                    for (let i = 0; i < 3; i++) {
                        if (i < count) {
                            this.spines[i].visible = true;
                        } else {
                            this.spines[i].visible = false;
                        }
                    }
					this.clearEffects();
					if (_spine_data) {
						let effect_names: Array<string> = [];
						
						for (let i = 0; i < 4; i++) {
							if (_spine_data.effects[i]) {
								let effects = _spine_data.effects[i].split(',');
								effect_names.push(_spine_data.effects[i]);
							}
						}
						let _loading_count = Math.min(2, effect_names.length);
						let _need_load_count = _loading_count;
						let all_effects: Array<Array<{name: string, sustain: boolean}>> = [];
						// 只允许显示俩,多的不管
						for (let i = 0, n = _loading_count; i < n; i++) {
							let names = effect_names[i].split(',');
							let targets: Array<string> = [];
							let effects: Array<{name: string, sustain: boolean}> = [];
							if (names[0]) {
								targets.push('scene/' + names[0] + '.lh');
								effects.push({name: 'scene/' + names[0] + '.lh', sustain: true});
							}
							if (names[1]) {
								targets.push('scene/' + names[1] + '.lh');
								effects.push({name: 'scene/' + names[1] + '.lh', sustain: false});
							}
							all_effects.push(effects);
							game.EffectMgr.preheat_3d_effect(targets, i == 0 ? SpineMgr.Inst.effect_back_parent : SpineMgr.Inst.effect_front_parent, true, Laya.Handler.create(this, () => {
								--_loading_count;
								if (!_loading_count) {
									// 仅当
									if (path == this.path && this.root.parent) {
										
										this.loadSpine();
										this.loadEffects(all_effects, this.scale);
										// this.anim = this.loadSkeleton();
										this.state = ESpineState.loaded;
										
										
										this._play(this.initAnimInfo.anim, this.initAnimInfo.loop);
									} else {
										this.state = ESpineState.failed;
									}
									if (this.loadover_handler) {
                                        this.loadover_handler.run();
                                        this.loadover_handler = null;
                                    }
									// this.event('loadover');
								}
							}))
						}
						if (_need_load_count > 0) {
							return;
						}
						
					}
					if (path == this.path) {
						this.loadSpine();
						this.state = ESpineState.loaded;
						this._play(this.initAnimInfo.anim, this.initAnimInfo.loop);
					} else {
						this.state = ESpineState.failed;
					}

					if (this.loadover_handler) {
						this.loadover_handler.run();
						this.loadover_handler = null;
					}
					

				}
			};

			let loadFailed = ()=>{
				this.state = ESpineState.failed;
			}
            if (count == 1) {
                SpineMgr.Inst.assetManager.loadBinary(this.path + "/spine" + SpineController.spineSuffix, (a, b) => {
                    loadOver();
                }, ()=>{loadFailed()});
                SpineMgr.Inst.assetManager.loadTextureAtlas(this.path + "/spine" + SpineController.atlasSuffix, (a, b) => {
                    loadOver();
                }, ()=>{loadFailed()});
            } else {
                for (let i = 0; i < count; i++) {
                    SpineMgr.Inst.assetManager.loadBinary(this.path + "/spine_" + i + SpineController.spineSuffix, (a, b) => {
                        loadOver();
                    }, ()=>{loadFailed()});
                    SpineMgr.Inst.assetManager.loadTextureAtlas(this.path + "/spine_" + i + SpineController.atlasSuffix, (a, b) => {
                        loadOver();
                    }, ()=>{loadFailed()});
                }
            }
			
		}
    
        private loadSpine() {
            for (let i = 0; i < this.spines.length; i++) {
                let spine = this.spines[i];
                if (i < this.count) {
                    spine.visible = true;
                    spine.offsetX = this.offsetX;
                    spine.offsetY =  this.offsetY;
                    spine.pX = this.pX;
                    spine.pY = this.pY;
                    spine.sx = this.sx;
					spine.sy = this.sy;
					spine.customIdleAni = this.customIdleAni;
					spine.animSpeed = this.animSpeed;
					spine.aniAlpha = this.aniAlpha;
					spine.calScrollRectPos = this.calScrollRectPos;
                    spine.loadAnim();
                } else {
                    spine.visible = false;
                }
			}
			this.loadAudio(); // 显示spine后随缘加载音效
        }

		private loadEffects(effect_names: Array<Array<{name: string, sustain: boolean}>>, _scale: number) {
			if (!this.root.parent || !this.root.parent.parent) return;
			for (let i = 0; i < effect_names.length; ++i) {
				for (let name of effect_names[i]) {
					this.effects.push(SpineMgr.Inst[i == 0 ? 'create_back_effect':'create_front_effect'](this.root.parent.parent as Laya.Sprite, name.name, this.effect_offset, _scale,  name.sustain, null));
				}
				
			}						
		}
		public onNewShow() {
			this.id++;
			let layers = [];
			if (this.skin_data) {
				let _spine_data = cfg.character.skin.get(this.skin_data.id);
				if (_spine_data) {
					for(let i = 0; i < 4; i++) {
						if (_spine_data.effects[i]) {
							layers.push(i + layers.length);
						}
					}
  				}
			}
			if (this.effects) {
				for (let effect of this.effects) {
					effect.onNewShow();
				}
			}
			SpineMgr.Inst.setActiveSpine(this, layers[0], layers[1]);
		}

		public pause() {
			if (this.state == ESpineState.loaded) {
				for (let spine of this.spines) {
					spine.pause();
				}
			}
		}

		public resume() {
			if (this.state == ESpineState.loaded) {
				for (let spine of this.spines) {
					spine.resume();
				}
			}
		}

		// 设置动画速度,如果spine已经加载到，会立刻修改动画速度
		public setAnimSpeed(speed: number) {
			this.animSpeed = speed;
			for (let spine of this.spines) {
				spine.setAnimSpeed(speed);
			}
		}

		// 播放动画, 假如没加载好就先保存下来
		public play(animationName: string, loop:boolean = false) {
			if (this.state == ESpineState.loaded) {
				this._play(animationName, loop);
			} else {
				this.initAnimInfo = { anim: animationName, loop: loop };
			}
		}

		// 播放除了idle，其他的会转到idle
		private _play(animationName: string, loop: boolean = false) {
			let isClick2 = Math.random() > 0.5;
			for (let spine of this.spines) {
				if (spine.visible) {
					spine.play(animationName, loop, isClick2);
                }
            }
			for (let effect of this.effects) {
				effect.play(animationName);
			}
		}

		// 释放模型
		public releaseModel() {
			Laya.timer.clearAll(this);
			this.clearEffects();
			
            for (let spine of this.spines) {
                spine.releaseModel();
			}

			this.state = ESpineState.none;
			this.path = '';
			// this.destroy();

		}

		// 结束动画
		public reset() {
			// this.path = '';
			Laya.timer.clearAll(this);
			for (let spine of this.spines) {
				spine.reset();	
			}
			if (this.effects) {
				for (let effect of this.effects) {
					effect.hide();	
				}
			}
			// this.calculateSetupPoseBounds(this.anim.skeleton);
		}

		// 父节点变更，特效需要做一下处理
		public onParentChange(_scale: number, _offset: Laya.Point) {
			this.scale = _scale;
			this.effect_offset = _offset;
			if (!this.effects) return;
			for (let effect of this.effects) {
				effect.target = this.root.parent.parent as Laya.Sprite;
				effect.scale = _scale;
				effect.pos_offset = _offset;
			}
		}

        public setLoadOverHandler(handler: Laya.Handler) {
            this.loadover_handler = handler;
        }

		// 更新spine数据
        public updateSpineInfo() {
            for (let i = 0; i < this.spines.length; i++) {
                let spine = this.spines[i];
                if (i < this.count) {
                    spine.visible = true;
                    spine.offsetX = this.offsetX;
                    spine.offsetY =  this.offsetY;
                    spine.pX = this.pX;
                    spine.pY = this.pY;
                    spine.sx = this.sx;
					spine.sy = this.sy;
					spine.customIdleAni = this.customIdleAni;
					spine.animSpeed = this.animSpeed;
					spine.aniAlpha = this.aniAlpha;
					spine.calScrollRectPos = this.calScrollRectPos;
                } else {
                    spine.visible = false;
                }
            }
        }

		private clearEffects() {
			for (let effect of this.effects) {
				effect.destory();
			}
			this.effects = [];
		}
		
		// spine加载完成后，随缘加载音效
		private loadAudio() {
			if (!this.skin_data) return;
			let _spine_data = cfg.character.skin.get(this.skin_data.id);
			if (!_spine_data) return;
			let _audios: Array<string> = [];
			if (_spine_data.audio_celebrate) _audios.push('audio/skin/' + _spine_data.audio_celebrate + view.AudioMgr.suffix);
			if (_spine_data.audio_idle) _audios.push('audio/skin/' + _spine_data.audio_idle + view.AudioMgr.suffix);
			if (_spine_data.audio_greeting) _audios.push('audio/skin/' + _spine_data.audio_greeting + view.AudioMgr.suffix);
			if (_spine_data.audio_click) _audios.push('audio/skin/' + _spine_data.audio_click + view.AudioMgr.suffix);
			Laya.loader.load(_audios);
		}

		public stopAudio() { 
			for (let spine of this.spines) {
				spine.stopAudio();
			}
		}
	}
}