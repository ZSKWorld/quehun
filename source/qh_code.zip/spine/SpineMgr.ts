/**
* name 
*/
module CatFoodSpine{
	export class SpineMgr {
		public static Inst:SpineMgr;
		public static scene_spine_front_path: string = 'scene/scene_spine_front_effect.ls';
		public static scene_spine_back_path: string = 'scene/scene_spine_back_effect.ls';

		public static init() {
			if (this.Inst != null) return;
			this.Inst = new SpineMgr();
			this.Inst._init();
		}

		private readonly countLimit:number = 2;
		public spineSprites:Array<{path:string, lastTime:number, spine:SpineController}> = [];
		// 存储特殊Spine的实例，key为唯一标识，value为对应的SpineController
		private specialInstances: { [key: string]: { path: string, spine: SpineController } } = {};
		public shader:spine.Shader;
		public batcher:spine.PolygonBatcher;
		public mvp:spine.Matrix4;
		public skeletonRenderer: spine.SkeletonRenderer;
		public assetManager:spine.AssetManager;
		
		// 230406 haitao 新加的特效节点
		public effect_front_parent: Laya.Scene;
		public root_front_effect: Laya.Sprite3D;

		public effect_back_parent: Laya.Scene;
		public root_back_effect: Laya.Sprite3D;


		private _init() {
			this.spineSprites = [];

			this.shader = spine.Shader.newTwoColoredTextured(Laya.WebGL.mainContext);
			this.batcher = new spine.PolygonBatcher(Laya.WebGL.mainContext);
			this.skeletonRenderer = new spine.SkeletonRenderer(Laya.WebGL.mainContext);
			this.assetManager = new spine.AssetManager(Laya.WebGL.mainContext);
			this.mvp = new spine.Matrix4();
			this.mvp.ortho2d(0, 0, 1920, 1080);

			Laya.timer.frameLoop(1, this, () => {
				SpineEffect.update();
			});
		}

		//初始化spine特效
		public initSpineEffect() {
			if (this.effect_front_parent) return;
			this.effect_front_parent = Laya.loader.getRes(SpineMgr.scene_spine_front_path);
			this.root_front_effect = this.effect_front_parent.getChildByName('root') as Laya.Sprite3D;

			this.effect_back_parent = Laya.loader.getRes(SpineMgr.scene_spine_back_path);
			this.root_back_effect = this.effect_back_parent.getChildByName('root') as Laya.Sprite3D;
			// 暂时不上
			this.effect_front_parent.visible = true;
			this.effect_back_parent.visible = true;
		}
		// improtant: 保存自己主角色的spine长时间在内存里，其他的就会被按照最不活跃的来替换
		public getSprite(path:string, skin_data: lqc.Sheet_ItemDefinition_Skin, important:boolean):SpineController {
			this.initSpineEffect();
			for (let i:number = 0; i < this.spineSprites.length; i++) {
				if (this.spineSprites[i].path == path) {
					if (this.spineSprites[i].spine.state == ESpineState.failed) {
						app.Log.log('【SpineMgr】spine load failed, release model and reload');
						this.spineSprites[i].spine.releaseModel();
						break;
					} // 加载失败的spine,释放资源，重新来过
					this.spineSprites[i].lastTime = Laya.timer.currTimer;
					this.spineSprites[i].spine.onNewShow();					
					return this.spineSprites[i].spine;
				}
			}

			
			let index:number = -1;
			if (this.spineSprites.length >= this.countLimit) {
				let startIndex:number = important || this.countLimit <= 1 ? 0 : 1; 
				let minTime:number = -1;
				for (let i:number = startIndex; i < this.spineSprites.length; i++) {
					if (minTime < 0 || this.spineSprites[i].lastTime < minTime) {
						minTime = this.spineSprites[i].lastTime;
						index = i;
					}
				}
			}

			let spine:SpineController = null;
			if (index < 0) {
				// 多加一层sprite，用来放前后层特效
				spine = new SpineController();
				index = this.spineSprites.length;
				this.spineSprites.push({
					path: path,
					lastTime: Laya.timer.currTimer,
					spine: spine
				});
			} else {
				spine = this.spineSprites[index].spine;
				spine.releaseModel();
				this.spineSprites[index].lastTime = Laya.timer.currTimer;
				this.spineSprites[index].path = path;
			}

			spine.load(path, skin_data);
			if (important && index != 0) {
				let tmp = this.spineSprites[index];
				this.spineSprites[index] = this.spineSprites[0];
				this.spineSprites[0] = tmp;
			}

			spine.onNewShow();
			return spine;
		}

		public changeSpineImportant(path:string) {
			let index = 0;
			for (let i:number = 0; i < this.spineSprites.length; i++) {
				if (this.spineSprites[i].path == path) {
					index = i;
					break;
				}
			}

			if (index != 0) {
				let tmp = this.spineSprites[index];
				this.spineSprites[index] = this.spineSprites[0];
				this.spineSprites[0] = tmp;
			}
		}

		public create_front_effect(target: Laya.Sprite, url: string, offset: Laya.Point, scale: number, sustain: boolean, complete: Laya.Handler): SpineEffect {
			let effect: SpineEffect = new SpineEffect(target, url, offset, scale, complete, sustain);
			this.root_front_effect.addChild(effect.effect.root);
			return effect;
		}

		public create_back_effect(target: Laya.Sprite, url: string, offset: Laya.Point, scale: number, sustain: boolean, complete: Laya.Handler): SpineEffect {
			let effect: SpineEffect = new SpineEffect(target, url, offset, scale, complete, sustain);
			this.root_back_effect.addChild(effect.effect.root);
			return effect;
		}
		

		// 设置当前active spine，把特效层丢过去
		public setActiveSpine(spine: SpineController, back_layer: number, front_layer: number) {
			let _parent = spine.root;
			_parent.addChild(this.effect_back_parent);
			_parent.addChild(this.effect_front_parent);
			_parent.setChildIndex(this.effect_back_parent, back_layer ? back_layer : 0);
			_parent.setChildIndex(this.effect_front_parent, front_layer ? front_layer : 0);
		}

		getSpecialSprite(key: string, path: string, skin_data: lqc.Sheet_ItemDefinition_Skin) {
			this.initSpineEffect();
			// 1. 如果这个key已经存在于特殊字典中
			if (this.specialInstances[key]) {
				const spineItem = this.specialInstances[key];
				// 如果路径不同，则需要加载新资源
				if (spineItem.path !== path) {
					spineItem.spine.releaseModel();
					spineItem.spine.load(path, skin_data);
					spineItem.path = path; // 更新路径
				}

				spineItem.spine.onNewShow();
				return spineItem.spine;
			}
			// 2. 如果这个key不存在，则创建新的实例
			else {
				const newSpine = new SpineController();
				newSpine.load(path, skin_data);

				this.specialInstances[key] = {
					path: path,
					spine: newSpine
				};;
				newSpine.onNewShow();
				return newSpine;
			}
		}


		public clearSpecialSprites(): void {
			for (const key in this.specialInstances) {
				if (this.specialInstances.hasOwnProperty(key)) {
					const item = this.specialInstances[key];
					item.spine.reset();
					item.spine.releaseModel();
					item.spine.root.removeSelf();
				}
			}
			this.specialInstances = {}; // 清空字典
		}
	}

	//不要自己创建,用FrontEffect创建，毕竟放在他下面
	export class SpineEffect {

		private static effects: Array<SpineEffect> = [];

		public static update() {
			let index: number = 0;
						for (let i: number = 0; i < this.effects.length; i++) {
				if (!this.effects[i].destoryed) {
					this.effects[i]._update();
					this.effects[index++] = this.effects[i];
				}
			}
			for (let i: number = this.effects.length - index; i > 0; i--) {
				this.effects.pop();
			}
		}

		public destoryed: boolean = false;
		public target: Laya.Sprite;
		public effect: game.EffectBase;
		public pos_offset: Laya.Point;
		private effect_offset: Laya.Vector3;
		public scale: number;
		private url: string;
		private sustain: boolean
		private complete: Laya.Handler;

		private anim_base_name: string;
		private anim: Catfood.CAnimator;
		private anim_name: string;
		private particle_systems: Array<Laya.ShurikenParticleSystem>;
		private particleSystemsMap: Object;
		private newStandardName: string = 'effect_root';
		private isNewStandard: boolean = false;

		public constructor(target: Laya.Sprite, url: string, pos_offset: Laya.Point, scale: number, complete:Laya.Handler, is_sustain: boolean) {
			this.target = target;
			this.destoryed = false;
			this.anim_base_name = url.replace('scene/', '').replace('.lh', '_');
			this.pos_offset = pos_offset;
			this.scale = scale;
			this.url = url;
			this.complete = complete;
			this.particle_systems = [];
			this.particleSystemsMap = {};
			this.sustain = is_sustain;
			this.effect = new game.EffectBase(url);
			this.effect.root.active = false;
			this.effect.addLoadedListener(Laya.Handler.create(this, this.onLoaded));
			SpineEffect.effects.push(this);
			this._update();
		}

		private _update() {
			if (this.destoryed) return;
			if (!this.target) return;
			
			
			if (this.effect && this.effect.root) {
				if (this.isNewStandard) {
					const child = this.target.getChildAt(0);
					if (!child) return;
					const target = child.getChildAt(0) as Laya.Sprite;
					if (!target) return;
					let _final_scale = 1;
					if (this.scale != 0) {
						_final_scale = this.scale * target.globalScaleX;
					} else {
						this.effect.root.transform.localScale = new Laya.Vector3(1, 1, 1);
					}
					this.effect.root.transform.localScale = new Laya.Vector3(_final_scale, _final_scale, _final_scale);
					const { x, y } = this.pos_offset;
					const pos = target.localToGlobal(this.pos_offset);
					pos.x = (pos.x / 1920 - 0.5) * game.FrontEffect.scene_width + (-this.effect_offset.x * _final_scale);
					pos.y = (0.5 - pos.y / 1080) * game.FrontEffect.scene_height + (this.effect_offset.y * _final_scale);
				
					this.effect.root.transform.localPosition = new Laya.Vector3(pos.x, pos.y, 0);
					this.pos_offset.setTo(x, y); //还原pos_offset
				} else {
					let _final_scale = 1;
					if (this.scale != 0) {
						_final_scale = this.target.scaleX * this.scale;
					} else {
						this.effect.root.transform.localScale = new Laya.Vector3(1, 1, 1);
					}
					this.effect.root.transform.localScale = new Laya.Vector3(_final_scale, _final_scale, _final_scale);
					let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(this.target, new Laya.Point(_final_scale * this.pos_offset.x, _final_scale * this.pos_offset.y));
					pos.x = pos.x - 0.5;
					pos.y = 0.5 - pos.y;
					this.effect.root.transform.localPosition = new Laya.Vector3(pos.x * game.FrontEffect.scene_width, pos.y * game.FrontEffect.scene_height, 0);
				}
			}
		}

		public destory() {
			if (this.destoryed) return;
			this.destoryed = true;
			this.effect.destroy();
			game.EffectMgr.clear_3d_resource(this.url);
		}

		private onLoaded() {
			if (this.complete) {
				this.complete.run();
				this.complete.recover();
				this.complete = null;
			}
			let anim_node_name = this.sustain ? 'sustain' : 'animation';
			if (game.Tools.GetNodeByNameInChildren(this.effect.root, this.newStandardName) as Laya.Sprite3D) {
				this.isNewStandard = true;
				anim_node_name = this.newStandardName;
			}
			if (!(game.Tools.GetNodeByNameInChildren(this.effect.root, anim_node_name) as Laya.Sprite3D)) return;
			this.anim = (game.Tools.GetNodeByNameInChildren(this.effect.root, anim_node_name) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			
			this.particle_systems = [];
			this.particleSystemsMap = {};
			this.dfsParticleSystems(this.effect.root);
			if (this.isNewStandard) {
				const effect = (this.effect.root.getChildAt(0).getChildAt(0).getChildAt(0) as Laya.Sprite3D);
				this.effect_offset = effect.transform.localPosition;
				effect.transform.localPosition = new Laya.Vector3();
			}
			this.play(this.anim_name);
			//诗乃的celebrate特效播放需要代码特殊处理
			if (this.url == "scene/shinai_1_eff_eff2.lh")
				(this.effect.root.getChildAt(0)?.getChildAt(0)?.getChildAt(0)?.getChildAt(0)?.getChildAt(0) as Laya.Sprite3D)?.addComponent(Spine_ShiNai_1);
		}

		private dfsParticleSystems(root: Laya.Sprite3D,  type:string  = '') {
			if (root instanceof Laya.ShuriKenParticle3D) {
				if(!this.isNewStandard) this.particle_systems.push(root.particleSystem);
				type = type || 'sustain';
				let arr = this.particleSystemsMap[type] || [];
				arr.push(root.particleSystem);
				this.particleSystemsMap[type] = arr;
			}
			for (let child of root._childs) {
				if (this.getTypeByName(root.name)) type = this.getTypeByName(root.name);
				this.dfsParticleSystems(child, type);
			}
		}
		public play(anim_name: string) {
			this.anim_name = anim_name;
			if (this.isNewStandard) {
				this.effect.root.active = true;
				let target_name = this.anim_base_name + (this.anim_name ? this.anim_name : 'idle');
				target_name = this.anim_name ? this.anim_name : 'idle';
				if (this.anim) {
					this.anim.Stop();
					if(this.anim.HasAnim(target_name))
						this.anim.Play(target_name);
					else
						this.anim.Play('idle'); 
				}
				this.showTargetAnimSprite(target_name);
				return;
			}
			if (this.anim) {
				let target_name = this.anim_base_name + this.anim_name;
				for (let clip of this.anim.clips) {
					if (clip.name == target_name) {
						this.effect.root.active = true;
						this.anim.Play(target_name);
						if (!this.sustain) {
							for (let system of this.particle_systems) {
								system.simulate(0, true);
								system.play();
							}
						}
						
						return;	
					}
				}
				
			}
			if (this.sustain) {
				this.effect.root.active = true;
				if (this.anim) {
					let target_name = this.anim_base_name + 'idle';
					this.anim.Play(target_name);
				}
				
			} else {
				this.effect.root.active = false;
			}
			
		}

		public hide() {
			this.effect.root.active = false;
		}

		public onNewShow() {
			this.effect.root.active = true;
		}

		
		private getTypeByName(name: string): string {
			if (name && name.indexOf('celebrate') != -1) return 'celebrate';
			if (name && name.indexOf('click') != -1) return 'click';
			if (name && name.indexOf('greeting') != -1) return 'greeting';
			if (name && name.indexOf('celebrate_idle') != -1) return 'celebrate_idle';
			if (name && name.indexOf('sustain') != -1) return 'sustain';
			if (name && name.indexOf('idle') != -1) return 'idle';
			return '';
		}

		private showTargetAnimSprite(anim: string) {
			let type = this.getTypeByName(anim);
			let effectRoot = game.Tools.GetNodeByNameInChildren(this.effect.root, 'effect_root') as Laya.Sprite3D;
			if (!effectRoot) return;
			effectRoot = effectRoot.getChildAt(0) as Laya.Sprite3D;
			for (let i = 0; i < effectRoot._childs.length; i++) {
				let com = effectRoot.getChildAt(i) as Laya.Sprite3D;
				com.active = com.name == 'sustain';
				if (com.name == type) {
					com.active = true;
					let particle_systems = this.particleSystemsMap[com.name];
					if (particle_systems) {
						for (let system of particle_systems) {
							system.simulate(0, true);
							system.play();
						}
					}
				}
			}
		}
	}
}