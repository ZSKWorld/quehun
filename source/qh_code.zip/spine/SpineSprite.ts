/**
* name 
*/
module CatFoodSpine {

	interface SpineAnim {
		skeleton: spine.Skeleton;
		anim: spine.AnimationState;
		bounds: { offset: spine.Vector2, size: spine.Vector2 };
		premultipliedAlpha: boolean;
		effect_map?: Object;
	}

	class SpineTexture {
		private _tex: Laya.Texture;
		private _gl: WebGL2RenderingContext;
		private boundUnit: number = 0;
		private useMipMaps = false;

		private get image() {
			const tex = this._tex;
			if (!tex || !tex.bitmap || tex.bitmap.destroyed) return null;
			return (tex.bitmap as Laya.WebGLImage)._image;
		}

		private get glTexture() {
			const tex = this._tex;
			if (!tex) return null;
			return tex.source;
		}

		constructor(tex: Laya.Texture, useMipMaps = false) {
			this._tex = tex;
			this.useMipMaps = useMipMaps;
			this._gl = Laya.WebGL.mainContext as any;
		}
		getImage() { return this.image; }
		setFilters(minFilter, magFilter) {
			const glTex = this.glTexture;
			if (!glTex) return;
			this.bind();
			const gl = this._gl;
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, spine.GLTexture.validateMagFilter(magFilter));
			this.useMipMaps = spine.GLTexture.usesMipMaps(minFilter);
			if (this.useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
		}
		setWraps(uWrap, vWrap) {
			const glTex = this.glTexture;
			if (!glTex) return;
			this.bind();
			const gl = this._gl;
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, uWrap);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, vWrap);
		}
		update(useMipMaps: boolean) {
			const glTex = this.glTexture;
			if (!glTex) return;
			const image = this.image;
			if (!image) return;
			this.bind();
			const gl = this._gl;
			if (spine.GLTexture.DISABLE_UNPACK_PREMULTIPLIED_ALPHA_WEBGL) gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, useMipMaps ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
			if (useMipMaps) gl.generateMipmap(gl.TEXTURE_2D);
		}
		bind(unit: number = 0) {
			const glTex = this.glTexture;
			if (!glTex) return;
			const gl = this._gl;
			this.boundUnit = unit;
			gl.activeTexture(gl.TEXTURE0 + unit);
			gl.bindTexture(gl.TEXTURE_2D, glTex);
		}
		unbind() {
			const gl = this._gl;
			gl.activeTexture(gl.TEXTURE0 + this.boundUnit);
			gl.bindTexture(gl.TEXTURE_2D, null);
		}
		dispose() {
			this._tex = null;
			this._gl = null;
			this.boundUnit = 0;
			this.useMipMaps = false;
		}
	}

	export class SpineSprite extends Laya.Sprite {

		public id: number = 0;
		private anim: SpineAnim = null;
		private controller: SpineController;
		public state: ESpineState = ESpineState.none;
		private path: string;
		private initAnim: string = 'idle';
		private animTime = {};
		public offsetX: number = 695; // 整体偏移
		public offsetY: number = 610; // 整体偏移
		public pX: number = 0; // 放大缩小的居中点偏移
		public pY: number = 0; // 放大缩小的居中点偏移
		public sx: number = 0.96; // 初始放大缩小
		public sy: number = 0.96; // 初始放大缩小
		public aniAlpha: boolean = false; //透明度开关
		public calScrollRectPos: boolean = false; //spine坐标计算时候是否包含裁剪容器的scrollRect，spine在滚动列表或具有裁剪效果容器中需要打开
		public customIdleAni: string; // 替换 默认循环idle
		public animSpeed: number = null; // 时间缩放
		
		private audio_id: number;

		constructor() {
			super();
			this.customRenderEnable = true;
		}

		// 设置初始数据
		public init(controller:SpineController, path: string) {
			this.path = path;
			this.controller = controller;
		}

		public loadAnim() {
			this.anim = this.loadSkeleton();
		}
		
		public pause() {
			if (this.anim && this.anim.anim) this.anim.anim.pause();
		}

		public resume() {
			if (this.anim && this.anim.anim) this.anim.anim.resume();
		}

		public setAnimSpeed(speed: number) {
			if (speed == null) return;
			this.animSpeed = speed;
			if (this.anim && this.anim.anim && this.anim.anim.timeScale != this.animSpeed) this.anim.anim.setTimeScale(speed);
		}

		// 播放除了idle，其他的会转到idle
		public play(animationName: string, loop:boolean = false,isClick2:boolean = false) {
			this.setAnimSpeed(this.animSpeed);
			this.stopAudio();
			if (!this.animTime[animationName]) {
				if (this.anim.anim.getCurrent(0)) {
					let lastAnimName = this.anim.anim.getCurrent(0).animation.name;
					if (lastAnimName == 'idle') return;
				}
				// app.Log.Error('animationName ==== '+ animationName);
				animationName = this.customIdleAni || 'idle';
			}
			if (!animationName) animationName = this.customIdleAni || 'idle';

			Laya.timer.clearAll(this);
			//有两个互动动作时，动画是click和click2,这里随机改到皮肤上了，因为多层皮肤各自随机的话，会出现对不上大动作的情况
			if (animationName == 'click' && this.animTime['click2']) {
				// if (Math.random() > 0.5) {
				// 	animationName = 'click2';
				// }
				if (isClick2) {
					animationName = 'click2';
				}
			}

			if (animationName == 'idle' || animationName == 'celebrate_idle' || loop) {
				this.anim.anim.setAnimation(0, animationName, true);
			} else {
				this.anim.anim.setAnimation(0, animationName, false);
				this.anim.anim.setCompleteHandler(animationName, Laya.Handler.create(this, () => {
					if (this.customIdleAni) {
						this.play(this.customIdleAni, true);
					} else if ((animationName == 'celebrate' || animationName == 'celebrate_idle') && this.animTime['celebrate_idle']) {
						this.play('celebrate_idle');
					} else {
						this.play('idle');
					}
					
				}));
			}
		}

		// 释放模型
		public releaseModel() {
			Laya.timer.clearAll(this);
			this.anim?.skeleton?.setToSetupPose();
			this.clearSlotCache();
			if (!this.controller || this.controller.state == ESpineState.loading || this.controller.state == ESpineState.failed) {
				SpineMgr.Inst.assetManager.remove(this.path + SpineController.spineSuffix);
				SpineMgr.Inst.assetManager.remove(this.path + SpineController.atlasSuffix);
			} else if (this.controller.state == ESpineState.loaded) {
				let atlas: spine.TextureAtlas = SpineMgr.Inst.assetManager.get(this.path + SpineController.atlasSuffix);
				if (atlas) {
					for (let i: number = 0; i < atlas.pages.length; i++) {
						(atlas.pages[i].texture as spine.GLTexture).dispose();
						const texDir = this.path.substring(0, this.path.lastIndexOf("/"));
						SpineMgr.Inst.assetManager.remove(texDir + '/' + atlas.pages[i].name);
					}
				}
				SpineMgr.Inst.assetManager.remove(this.path + SpineController.spineSuffix);
				SpineMgr.Inst.assetManager.remove(this.path + SpineController.atlasSuffix);
				this.anim = null;
			}
		}

		// premultipliedAlpha: true对应导出贴图里面的alpha预乘模式，false对应导出贴图里面的溢出模式，目前跟美术定的是溢出模式
		private loadSkeleton(skin: string = 'default', premultipliedAlpha: boolean = false): SpineAnim {

			var atlas = SpineMgr.Inst.assetManager.get(this.path + SpineController.atlasSuffix);
		
			var atlasLoader = new spine.AtlasAttachmentLoader(atlas);

			var SkeletonJson = new spine.SkeletonBinary(atlasLoader);

			SkeletonJson.scale = 1;
			var skeletonData = SkeletonJson.readSkeletonData(SpineMgr.Inst.assetManager.get(this.path + SpineController.spineSuffix));
			var skeleton = new spine.Skeleton(skeletonData);
			skeleton.setSkinByName(skin);
			var bounds = this.calculateSetupPoseBounds(skeleton);

			// Create an AnimationState, and set the initial animation in looping mode.
			var animationStateData = new spine.AnimationStateData(skeleton.data);
			let animList = animationStateData.skeletonData.animations;
			this.animTime = {};
			for (let i: number = 0; i < animList.length; i++) {
				this.animTime[animList[i].name] = animList[i].duration;
				for (let j: number = 0; j < animList.length; j++) {
					
					if (this.path.includes("nanfenghua")) {
						animationStateData.setMixWith(animList[i], animList[j], 0);
					} else if (this.path.includes("2604dj/enemy_10")) {
						animationStateData.setMixWith(animList[i], animList[j], 0);
					} else { 
						if (animList[i].name == 'greeting' || animList[j].name == 'greeting' || animList[j].name == 'celebrate' ||
							animList[j].name == 'celebrate_idle' || (animList[i].name == 'click2' && animList[j].name == 'idle') || (animList[i].name == 'click' && animList[j].name == 'idle')) {
							animationStateData.setMixWith(animList[i], animList[j], 0);
						} else {
							animationStateData.setMixWith(animList[i], animList[j], 0.05);
						}
						//小鸟游睡衣皮，庆祝的时候不要混合，照片素材会有暂留的问题
						if (this.path.includes("xiaoniaoyouchutian_SY/spine/")) {
							if (animList[i].name == 'celebrate' || animList[i].name == 'celebrate_idle') {
								animationStateData.setMixWith(animList[i], animList[j], 0);
							}
						}
						if (this.path.includes("huayubai_LF/spine/")) {
							if (animList[i].name == 'idle' && animList[j].name == 'click') {
								animationStateData.setMixWith(animList[i], animList[j], 0);
							}
						}
					}
					
				}
			}
			var animationState = new spine.AnimationState(animationStateData);
			let self = this;
			animationState.addListener({
				start: function (track) {
					// console.log("Animation on track " + track.trackIndex + " started");
				},
				interrupt: function (track) {
					// console.log("Animation on track " + track.trackIndex + " interrupted");
				},
				end: function (track) {
					// console.log("Animation on track " + track.trackIndex + " ended");
				},
				dispose: function (track) {
					// console.log("Animation on track " + track.trackIndex + " disposed");
				},
				complete: function (track) {
					// console.log("Animation on track " + track.trackIndex + " completed");
				},
				event: function (track, event) {
					if (event && event.data && event.data['audioPath']) {
						if (event.data['name'] == 'idle') return;
						let _path = event.data['audioPath'].substr(0, event.data['audioPath'].length - 4);
						self.audio_id = view.AudioMgr.PlaySound('audio/skin/' + _path, view.AudioMgr.audioMuted ? 0 : view.AudioMgr.audioVolume, null, 0, view.EAudioType.audio);
					}
					
				}
			})

			return {
				skeleton: skeleton,
				anim: animationState,
				bounds: bounds,
				premultipliedAlpha: premultipliedAlpha
			};
		}

		private calculateSetupPoseBounds(skeleton) {
			skeleton.setToSetupPose();
			skeleton.updateWorldTransform(2);
			var offset = new spine.Vector2();
			var size = new spine.Vector2();
			skeleton.getBounds(offset, size, []);
			return { offset: offset, size: size };
		}

		public customRender(context: Laya.RenderContext, x: number, y: number): void {
			Laya.Render._context.ctx._renderKey = 0;//打断2D合并的renderKey
			context.addRenderObject(this);
		}

		private __render() {
			var delta = Laya.timer.delta / 1000;

			// Update the MVP matrix to adjust for canvas size changes
			let _scaleX: number = this.scaleX * this.sx;
			let _scaleY: number = this.scaleY * this.sy;
			let root: Laya.Node = this;
			let alpha: number = 1;
			let _pos2: Laya.Vector2 = new Laya.Vector2(this.pX, this.pY);
			const posIncludeScrollRect = this.calScrollRectPos;
			do {
				_pos2.x = _pos2.x * root['scaleX'] + root['x'];
				_pos2.y = _pos2.y * root['scaleY'] + root['y'];

				var scroll = posIncludeScrollRect ? root['scrollRect'] : null;
				if (scroll) {
					_pos2.x -= scroll.x;
					_pos2.y -= scroll.y;
				}
				_scaleX *= root['scaleX'];
				_scaleY *= root['scaleY'];
				if (this.aniAlpha)
					alpha *= root['alpha'];
				root = root.parent;
			} while (root != Laya.stage);

			// while(root != null && root['scaleX'] && root['scaleY']) {
			// 	if (root['alpha'] != undefined) alpha *= root['alpha'] ;
			// 	_scaleX *= root['scaleX'];
			// 	_scaleY *= root['scaleY'];

			// 	root = root.parent;
			// }
			// 非常神奇的公式，但就是这样了，跟scale有关
			SpineMgr.Inst.mvp.ortho2d(-(_pos2.x - this.offsetX) / _scaleX, (_pos2.y - this.offsetY) / _scaleY, 1920 / _scaleX, 1080 / _scaleY);

			var skeleton = this.anim.skeleton;
			var anim = this.anim.anim;
			var bounds = this.anim.bounds;
			var premultipliedAlpha = this.anim.premultipliedAlpha;
			anim.update(delta);
			anim.apply(skeleton);
			skeleton.update(delta);
			skeleton.updateWorldTransform(2);
			skeleton.color = new spine.Color(1, 1, 1, alpha);

			SpineMgr.Inst.shader.bind();
			SpineMgr.Inst.shader.setUniformi(spine.Shader.SAMPLER, 0);
			SpineMgr.Inst.shader.setUniform4x4f(spine.Shader.MVP_MATRIX, SpineMgr.Inst.mvp.values);

			SpineMgr.Inst.batcher.begin(SpineMgr.Inst.shader);

			SpineMgr.Inst.skeletonRenderer.vertexEffect = null;

			SpineMgr.Inst.skeletonRenderer.premultipliedAlpha = premultipliedAlpha;
			SpineMgr.Inst.skeletonRenderer.draw(SpineMgr.Inst.batcher, skeleton);
			SpineMgr.Inst.batcher.end();

			SpineMgr.Inst.shader.unbind();
		}

		/// ISubmit
		renderSubmit() {
			if (!this.controller || this.controller.state != ESpineState.loaded) return 1;
			this.__render();

			// refresh inner cache
			Laya.Buffer._bindActive = [];
			Laya.BaseShader.activeShader = null
			Laya.BlendMode.activeBlendFunction = null;
			Laya.WebGLContext._useProgram = null;

			// // restore inner states
			let gl2 = Laya.WebGL.mainContext;
			gl2.enable(Laya.WebGLContext.BLEND);
			gl2.blendFunc(Laya.WebGLContext.ONE, Laya.WebGLContext.ONE_MINUS_SRC_ALPHA);
			// gl.blendFunc(gl.ONE, gl.ZERO);
			gl2.disable(Laya.WebGLContext.DEPTH_TEST);
			gl2.disable(Laya.WebGLContext.CULL_FACE);
			gl2.depthMask(true);
			gl2.frontFace(Laya.WebGLContext.CCW);
			return 1;
		}

		/// ISubmit
		getRenderType() {
			return Laya.Submit.TYPE_CUSTOM;
		}

		/// ISubmit
		releaseRender() {
			// console.log('releaseRender() {');
		}

		public reset() {
			Laya.timer.clearAll(this);
			this.stopAudio();
			if (this.anim && this.anim.anim) {
				this.anim.anim.setEmptyAnimations(0);
			}
			// this.calculateSetupPoseBounds(this.anim.skeleton);
		}

		public stopAudio() {
			if (this.audio_id) {
				view.AudioMgr.StopAudio(this.audio_id);
				this.audio_id = 0;
			}
		}

		public setSlotTexture(slotName: string, texture: Laya.Texture) {
			const skel = this.anim?.skeleton;
			if (!skel) return;
			const slot = skel.findSlot(slotName);
			if (!slot) return;
			
			const attachment = this.getSlotAttachment(slot, texture);
            if (!attachment) return;
			slot.setAttachment(attachment);
			attachment.updateRegion();
		}
		
		private _atlasPageCache: Record<string, spine.TextureAtlasPage> = {};
		private _attachmentCache: Record<number, (spine.RegionAttachment | spine.MeshAttachment)[]> = { 0: [], 1: [] };
		private _usingAttachCache: Record<number, (spine.RegionAttachment | spine.MeshAttachment)[]> = { 0: [], 1: [] };
		private getSlotAttachment(slot:spine.Slot, texture: Laya.Texture) {
			const attachment = slot.getAttachment();
			if (!attachment) return null;
			const isRegion = attachment instanceof spine.RegionAttachment;
			const isMesh = attachment instanceof spine.MeshAttachment;
			if (!isRegion && !isMesh) return;
			
			let newAttach: spine.RegionAttachment | spine.MeshAttachment;
			const pool = this._attachmentCache[isRegion ? 0 : 1];
			const usingPool = this._usingAttachCache[isRegion ? 0 : 1];
			if (attachment["__customAttach"]){
				pool.push(attachment);
				const index = usingPool.indexOf(attachment);
				index != -1 && usingPool.splice(index, 1);
			}

			if (pool.length > 0)
				newAttach = pool.pop();
			else {
				newAttach = attachment.copy() as any;
				newAttach["__customAttach"] = true;
			}
			
            const newRegion = this.registerTexture(texture);
			newAttach.region = newRegion;
			newAttach.width = newRegion.width;
			newAttach.height = newRegion.height;
			usingPool.push(newAttach);
			return newAttach;
		}

		private registerTexture(texture: Laya.Texture) {
			if (!texture) return null;
			const tex2d = texture.bitmap as Laya.WebGLImage;
			if (!tex2d) return null;

			const bitmapUrl = tex2d.url;
			const spineTexture = new SpineTexture(texture);
			let page = this._atlasPageCache[bitmapUrl];
			if (!page) {
				let urlFileName = bitmapUrl ? bitmapUrl.split('/').pop().split('\\').pop() : null;
				page = new spine.TextureAtlasPage(urlFileName || bitmapUrl || "texture");
				page.name = urlFileName;
				page.texture = spineTexture as any;
				page.width = tex2d.width;
				page.height = tex2d.height;
				this._atlasPageCache[bitmapUrl] = page;
			}
			const textureName = texture.url.split('/').pop().split('\\').pop();
			const region = new spine.TextureAtlasRegion(page, textureName);
			region.page = page;
			region.name = textureName;
			region.width = texture.width;
			region.height = texture.height;
			region.originalWidth = texture.sourceWidth;
			region.originalHeight = texture.sourceHeight;
			region.offsetX = texture.offsetX;
			region.offsetY = texture.offsetY;
			if (texture.uv && texture.uv.length >= 8) {
				region.u = texture.uv[0];
				region.v = texture.uv[1];
				region.u2 = texture.uv[4];
				region.v2 = texture.uv[5];
			}
			else {
				region.u = 0;
				region.v = 0;
				region.u2 = 1.0;
				region.v2 = 1.0;
			}
			region.texture = spineTexture as any;
			return region;
		}

		private clearSlotCache() {
			for (const key in this._attachmentCache) {
				const e = this._attachmentCache[key];
				if (!e) return;
				e.forEach(v => {
					const region = v.region as spine.TextureAtlasRegion;
					if (!region) return;
					const page = region.page;
					if (page) {
						page.texture?.dispose();
						page.texture = null;
						region.page = null;
					}
					region.texture?.dispose();
					region.texture = null;
					v.region = null;
				});
				e.length = 0;
			}
			for (const key in this._usingAttachCache) {
				const e = this._usingAttachCache[key];
				if (!e) return;
				e.forEach(v => {
					const region = v.region as spine.TextureAtlasRegion;
					if (!region) return;
					const page = region.page;
					if (page) {
						page.texture?.dispose();
						page.texture = null;
						region.page = null;
					}
					region.texture?.dispose();
					region.texture = null;
					v.region = null;
				});
				e.length = 0;
			}
			for (const key in this._atlasPageCache) {
				const page = this._atlasPageCache[key];
				if (!page) return;
				page.texture?.dispose();
				page.texture = null;
				delete this._atlasPageCache[key];
			}
		}
	}
}