module CatFoodSpine {
    class SpInfo {
        sp: Laya.Sprite3D;
        startTime: number;
        private _loopInfo: { showTime: number, loopTime: number };
        private _time: number = 0;
        private _started: boolean = false;
        constructor(sp: Laya.Sprite3D, startTime: number, loopInfo?: { showTime: number, loopTime: number }) {
            this.sp = sp;
            this.startTime = startTime;
            this._loopInfo = loopInfo;
        }

        update(delta: number) {
            if (!this._started) {
                this.sp.active = this._time >= this.startTime;
                this._started = this.sp.active;
                if (this._started) this._time = 0;
            } else if (this._loopInfo) {
                const { showTime, loopTime } = this._loopInfo;
                const time = this._time % (showTime + loopTime);
                this.sp.active = time < showTime;
            }
            this._time += delta;
        }

        onActiveChanged() {
            if (!this.sp || this.sp.destroyed) return;
            this.sp.active = false;
            this._time = 0;
            this._started = false;
        }
    }
    export class Spine_ShiNai_1 extends Laya.Script {
        private _times: SpInfo[];
        _load(owner: Laya.Sprite3D) {
            const child = owner.getChildAt(0) as Laya.Sprite3D;
            const sp_0 = child.getChildByName("0") as Laya.Sprite3D;
            const sp_2 = child.getChildByName("2") as Laya.Sprite3D;
            const sp_2_1 = child.getChildByName("2_1") as Laya.Sprite3D;
            const sp_2_2 = child.getChildByName("2_2") as Laya.Sprite3D;
            const sp_3 = child.getChildByName("3") as Laya.Sprite3D;
            const sp_3_1 = child.getChildByName("3_1") as Laya.Sprite3D;
            const sp_3_2 = child.getChildByName("3_2") as Laya.Sprite3D;
            const sp_4 = child.getChildByName("4") as Laya.Sprite3D;
            const sp_4_1 = child.getChildByName("4_1") as Laya.Sprite3D;
            const sp_4_2 = child.getChildByName("4_2") as Laya.Sprite3D;
            //1.startTime秒后开始显示
            //2.显示showTime秒后隐藏loopTime秒
            //3.循环第二步
            this._times = [
                new SpInfo(sp_0, 4.95 * 1000),
                new SpInfo(sp_2, 9.28 * 1000, { showTime: 2000, loopTime: 15000 }),
                new SpInfo(sp_2_1, 13.54 * 1000, { showTime: 2000, loopTime: 15000 }),
                new SpInfo(sp_2_2, 18.3 * 1000, { showTime: 2000, loopTime: 15000 }),
                new SpInfo(sp_3, 7.33 * 1000, { showTime: 2666, loopTime: 15000 }),
                new SpInfo(sp_3_1, 10.51 * 1000, { showTime: 2666, loopTime: 15000 }),
                new SpInfo(sp_3_2, 15.88 * 1000, { showTime: 2666, loopTime: 15000 }),
                new SpInfo(sp_4, 4.95 * 1000, { showTime: 2500, loopTime: 15000 }),
                new SpInfo(sp_4_1, 9.41 * 1000, { showTime: 2500, loopTime: 15000 }),
                new SpInfo(sp_4_2, 16.03 * 1000, { showTime: 2500, loopTime: 15000 }),
            ];
            this._onDisable();
        }

        _update(state: Laya.RenderState) {
            for (let i = 0, n = this._times.length; i < n; i++) {
                this._times[i].update(state.elapsedTime);
            }
        }

        private _onDisable() {
            for (let i = 0, n = this._times.length; i < n; i++) {
                this._times[i].onActiveChanged();
            }
        }
    }
}