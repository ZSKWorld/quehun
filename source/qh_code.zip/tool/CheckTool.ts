// ==DevDebug==
module tool {
    export class CheckTool {
        public static outputW: number = 1920;
        public static outputH: number = 1080;
        //动皮一键检查

        public static Inst: CheckTool = null;

        public constructor() {
            CheckTool.Inst = this;
        }

        /**
         * 单个皮肤检查所有的动画
         * @param skin 表单中skin项
         */
        private singleSkinCheck(skin) {
            this.skinAnimeCheck(skin, "idle", Laya.Handler.create(this, () => {
                Laya.timer.once(skin.idle, this, () => {
                    this.skinAnimeCheck(skin, "greeting", Laya.Handler.create(this, () => {
                        Laya.timer.once(skin.greeting, this, () => {
                            this.skinAnimeCheck(skin, "celebrate", Laya.Handler.create(this, () => {
                                Laya.timer.once(skin.celebrate, this, () => {
                                    this.skinAnimeCheck(skin, "click", Laya.Handler.create(this, () => {
                                        Laya.timer.once(skin.click, this, () => {
                                            this.skinAnimeCheck(skin, "greeting_init", Laya.Handler.create(this, () => {
                                                Laya.timer.once(skin.greeting_init, this, () => {
                                                    this.skinAnimeCheck(skin, "click2", Laya.Handler.create(this, () => {
                                                        Laya.timer.once(skin.click2, this, () => {
                                                            this.skinAnimeCheck(skin, "celebrate_idle");
                                                        })
                                                    }))
                                                })
                                            }))
                                        })
                                    }))
                                })
                            }))
                        })
                    }))
                })
            }));
        };


        /**
         * 单个皮肤单独检查动画
         * @param skin 表单中skin项
         * @param animeName 需要检查的动画名
         * @param complete 
         */
        private skinAnimeCheck(skin: any, animeName: string, complete?: Laya.Handler) {
            uiscript.UI_Lobby.Inst.setSkinForce(skin.id, animeName, Laya.Handler.create(this, () => {
                let timespan = skin[animeName] * 0.15;
                for (let i: number = 1; i <= 5; i++) {
                    Laya.timer.once(i * timespan, this, () => {
                        let htmlC = uiscript.UI_Lobby.Inst.me.drawToCanvas(Laya.stage.width, Laya.stage.height, 0, 0);
                        let todataUrl = htmlC.getCanvas().toDataURL("image/png");
                        this.sizeCompression(todataUrl, 1920, 1080, skin.id + "_" + skin['name_' + GameMgr.client_language] + "_" + animeName + "_" + i + ".png");
                    });
                }
                if (complete) {
                    complete.run();
                }
            }));
        }

        /**
         * 运行时单独皮肤全动画检查接口
         * @param id 皮肤id
         */
        public SingleSkinCheck(id: number) {
            let skin = cfg.item_definition.skin.get(id);
            if (skin && skin.spine_type) {
                this.singleSkinCheck(skin);
            }
        };



        // 运行时所有皮肤检查接口
        public AllSkinCheck() {
            let delay: number = 0;
            Laya.timer.scale = 2;
            cfg.item_definition.skin.forEach(skin => {
                if (skin.spine_type) {
                    Laya.timer.once(delay, this, () => {
                        this.singleSkinCheck(skin);
                    })
                    delay = delay + 2000 + skin.idle + skin.greeting + skin.click + skin.greeting_init + skin.click2 + skin.celebrate_idle + skin.celebrate;
                }
            });
            Laya.timer.once(delay, this, () => {
                Laya.timer.scale = 1;
            })
        }

        /**
         * 运行时单个皮肤单个动画检查
         * @param skinId 皮肤id
         * @param animeName 需要检查的动画名称
         */
        public SkinCheck(skinId: number, animeName: string) {
            let skin = cfg.item_definition.skin.get(skinId);
            if (skin && skin.spine_type) {
                this.skinAnimeCheck(skin, animeName);
            }
        }

        //和牌、立直特效一键检查
        public EffectCheck() {
            let delay: number = 0;
            let checkPai = view.DesktopMgr.Inst.lastqipai;
            let screenshotCamera = view.DesktopMgr.Inst.mainCamera;
            let fullScreenCamera = game.Scene_MJ.Inst.effect_fullscreen_camera;

            cfg.item_definition.item.forEach(item => {
                if (!(item['name_chs'] && item['name_chs'].includes('已过期')) && !(item['name_chs_t'] && item['name_chs_t'].includes('已過期'))) {
                    if (item.category == 5 && item.type == 2) {
                        Laya.timer.once(delay, this, () => {
                            view.DesktopMgr.Inst.player_effects[2][game.EView.lizhi_effect] = item.id;
                            view.DesktopMgr.Inst.players[2].AddQiPai(new mjcore.MJPai(), true, false);
                            for (let i: number = 1; i <= 5; i++) {
                                Laya.timer.once(i * 400, this, () => {
                                    this.screenCaptureWithCam([screenshotCamera, fullScreenCamera], item['name_' + GameMgr.client_language] + "_" + i + ".png", CheckTool.outputW, CheckTool.outputH);
                                });
                            }
                        });
                        delay += 2000;
                        Laya.timer.once(delay, this, () => {
                            view.DesktopMgr.Inst.players[2].QiPaiNoPass();
                        });
                    }
                    if (item.category == 5 && item.type == 1 && item.id != 305215) {
                        Laya.timer.once(delay, this, () => {
                            view.DesktopMgr.Inst.ShowHuleEffect(checkPai, checkPai.model.transform, item.id, view.DesktopMgr.Inst.lastpai_seat);
                            for (let i: number = 1; i <= 5; i++) {
                                Laya.timer.once(i * 400, this, () => {
                                    this.screenCaptureWithCam([screenshotCamera, fullScreenCamera], item['name_' + GameMgr.client_language] + "_" + i + ".png", CheckTool.outputW, CheckTool.outputH);
                                });
                            }
                        });
                        let hupaiViewData = cfg.item_definition.view.get(item.id);
                        if (hupaiViewData && hupaiViewData.sargs[0]) {
                            delay += Number(hupaiViewData.sargs[0]);
                        }
                        delay += 2000;
                    }
                }
            })
        }

        //单独立直检查
        public PlayLiqi(id: number) {
            let item = cfg.item_definition.item.get(id);
            if (!item) return;

            view.DesktopMgr.Inst.player_effects[2][game.EView.lizhi_effect] = item.id;
            view.DesktopMgr.Inst.players[2].AddQiPai(new mjcore.MJPai(), true, false);
            for (let i: number = 1; i <= 5; i++) {
                Laya.timer.once(i * 400, this, () => {
                    this.screenCaptureWithCam([view.DesktopMgr.Inst.mainCamera, game.Scene_MJ.Inst.effect_fullscreen_camera], item['name_' + GameMgr.client_language] + "_" + i + ".png", CheckTool.outputW, CheckTool.outputH);
                });
            }

            Laya.timer.once(2000, this, () => {
                view.DesktopMgr.Inst.players[2].QiPaiNoPass();
            });
        }

        //单独胡牌检查
        public PlayHupai(id: number) {
            let item = cfg.item_definition.item.get(id);
            if (!item) return;

            view.DesktopMgr.Inst.ShowHuleEffect(view.DesktopMgr.Inst.lastqipai, view.DesktopMgr.Inst.lastqipai.model.transform, item.id, view.DesktopMgr.Inst.lastpai_seat);
            for (let i: number = 1; i <= 5; i++) {
                Laya.timer.once(i * 400, this, () => {
                    this.screenCaptureWithCam([view.DesktopMgr.Inst.mainCamera, game.Scene_MJ.Inst.effect_fullscreen_camera], item['name_' + GameMgr.client_language] + "_" + i + ".png", CheckTool.outputW, CheckTool.outputH);
                });
            }
        }

        //使用rt截图
        private screenCaptureWithCam(cameras: Laya.Camera[], name: string, width: number, height: number) {
            if (cameras == null || cameras.length < 1)
                return;
            let vpwidth: number = cameras[0].viewport.width;
            let vpheight: number = cameras[0].viewport.height;

            let canvas = Laya.Browser.createElement("canvas") as HTMLCanvasElement;
            canvas.width = vpwidth;
            canvas.height = vpheight;
            let context = canvas.getContext("2d") as CanvasRenderingContext2D;

            // 为每个相机准备 RenderTexture 并设置到相机上
            let rts: Laya.RenderTexture[] = [];
            let tempCameras: Laya.Camera[] = [];
            for (let camera of cameras) {
                let rt = new Laya.RenderTexture(camera.viewport.width, camera.viewport.height);
                rts.push(rt);
                let tempCam = new Laya.Camera();
                camera.scene.addChild(tempCam);

                // 同步基本渲染参数
                tempCam.clearFlag = Laya.BaseCamera.CLEARFLAG_SOLIDCOLOR;
                tempCam.clearColor = new Laya.Vector4(0, 0, 0, 0);
                tempCam.fieldOfView = camera.fieldOfView;
                tempCam.orthographic = camera.orthographic;
                tempCam.orthographicVerticalSize = camera.orthographicVerticalSize;
                tempCam.nearPlane = camera.nearPlane;
                tempCam.farPlane = camera.farPlane;
                tempCam.viewport = new Laya.Viewport(
                    camera.viewport.x,
                    camera.viewport.y,
                    camera.viewport.width,
                    camera.viewport.height
                );
                tempCam.transform.position = camera.transform.position.clone();
                tempCam.transform.rotation = camera.transform.rotation.clone();
                tempCam.transform.localScale = camera.transform.localScale.clone();
                tempCam.clearColor = new Laya.Vector4(0, 0, 0, 0);
                tempCam.clearFlag = Laya.BaseCamera.CLEARFLAG_NONE;
                tempCam.cullingMask = camera.cullingMask;
                tempCam.renderingOrder = camera.renderingOrder;

                tempCam.renderTarget = rt;

                tempCameras.push(tempCam);
            }

            Laya.timer.frameOnce(1, this, () => {
                context.globalCompositeOperation = 'source-over';
                for (let i = 0; i < tempCameras.length; i++) {
                    let width: number = tempCameras[i].viewport.width;
                    let height: number = tempCameras[i].viewport.height
                    let pixels = rts[i].getData(0, 0, width, height);
                    let tempCanvas = Laya.Browser.createElement("canvas") as HTMLCanvasElement;
                    tempCanvas.width = width;
                    tempCanvas.height = height;
                    let tempCtx = tempCanvas.getContext("2d") as CanvasRenderingContext2D;
                    let imageData = tempCtx.createImageData(vpwidth, vpheight);
                    imageData.data.set(pixels);

                    for (let i = 0; i < imageData.data.length; i += 4) {
                        let a = imageData.data[i + 3];
                        if (a === 0) {
                            // 把纯透明像素改成完全透明的白色（避免黑底）
                            imageData.data[i] = 255;
                            imageData.data[i + 1] = 255;
                            imageData.data[i + 2] = 255;
                        }
                    }

                    tempCtx.putImageData(imageData, 0, 0);
                    context.drawImage(tempCanvas, 0, 0);

                    rts[i].destroy();
                    tempCameras[i].removeSelf();
                    tempCameras[i].destroy();
                }


                let base64Image = canvas.toDataURL("image/png");
                this.sizeCompression(base64Image, width, height, name);

                Laya.stage.repaint();
                canvas.remove();
            });
        }


        //压缩截图尺寸
        private sizeCompression(url: string, width: number, height: number, name: string) {
            let img = new Image();
            img.src = url;
            img.onload = function () {
                let canvas = document.createElement('canvas');
                let ctx = canvas.getContext('2d');
                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);
                let base64 = canvas.toDataURL('image/png');
                CheckTool.downloadFile(base64, name);
            }
        }

        /**
         * 下载文件，pc都行，手机部分
         * 测试可用浏览器：safari，iOS_Chrome
         * 测试不可用：UC，QQ浏览器，夸克
         */
        public static downloadFile(url: string, name: string) {
            let oa = document.createElement("a");
            oa.download = name;
            oa.href = url;
            document.body.appendChild(oa);
            oa.click();
            oa.remove();
        }

        /**
         * 2025.4.3 跳跳新增，因之前的特效检查方法会在特效加载之前进入下一步，所以加入了同步的特效播放方法，以及对应的新的检查方法，胡牌特效是以最后一张打出的牌为中心播放，立直特效是以指定座位为中心播放
         * 同步的立直特效和和牌特效检查方法，
         * @param lichiSeat 立直特效对应的座位，默认0是主视角
         */
        public CheckEffectsNew(lichiSeat: number = 0,isPreload: boolean = true) {
            let needCheckRonEffects: number[] = [];
            let needCheckLichiEffects: number[] = [];
            let needPreload: number[] = [];
            cfg.item_definition.item.forEach(item => {
                if (item.category == 5) {
                    //特效是否过期
                    let isExperied = item['name_' + GameMgr.client_language].includes('已过期') || item['name_' + GameMgr.client_language].includes('已過期');
                    if (!isExperied) {
                        if (item.type == 2) {
                            //立直特效
                            needCheckLichiEffects.push(item.id);
                            needPreload.push(item.id);
                        } else if (item.type == 1 && item.id != 305215) {
                            //和牌特效
                            needCheckRonEffects.push(item.id);
                            needPreload.push(item.id);
                        }
                    }
                }
            });


            //挨个播放特效，并截屏，在onDestroy中再播放下一个特效
            let checkRon = () => {
                let ronId = needCheckRonEffects.shift();
                if (!ronId) {
                    checkLichi();
                    return;
                }
                this.CheckRonEffect(ronId, Laya.Handler.create(this, () => {
                    checkRon();
                }), isPreload);

            }


            let checkLichi = () => {
                let lichiId = needCheckLichiEffects.shift();
                if (!lichiId) {
                    app.Log.log("立直/和牌特效检查完成");
                    return;
                }
                this.CheckLichiEffect(lichiId, lichiSeat, Laya.Handler.create(this, () => {
                    checkLichi();
                }), isPreload);
            }
            checkRon();



        }

        public CheckRonEffect(itemId: number, onDestroy: Laya.Handler = null, isPreload: boolean = true) {
            let item = cfg.item_definition.item.get(itemId);
            if (!item) return;
            let times = 0;
            let screenshotCamera = view.DesktopMgr.Inst.mainCamera;
            let basePicName = item['name_' + GameMgr.client_language] + "_" + itemId;
            app.Log.log("检查特效开始： " + basePicName);

            //平均500ms进行一次截图直到onDestroy
            let screenCapture = () => {
                times++;
                let picName = basePicName + "_" + times + ".png";
                this.screenCaptureWithCam([view.DesktopMgr.Inst.mainCamera, game.Scene_MJ.Inst.effect_fullscreen_camera], picName, CheckTool.outputW, CheckTool.outputH);
                // console.log("截图", item['name_' + GameMgr.client_language] + "_" + times + ".png");
            }
            let onLoaded = Laya.Handler.create(this, () => {
                Laya.timer.loop(500, this, screenCapture);
            });
            this.previewHuleEffect(itemId,Laya.Handler.create(this, () => {
                Laya.timer.clear(this, screenCapture);
                app.Log.log("检查特效结束： " + basePicName);
                if (onDestroy) {
                    onDestroy.run();
                }
            }), isPreload, onLoaded);
        }

        public CheckLichiEffect(itemId: number, seat: number = 0, onDestroy: Laya.Handler = null, isPreload: boolean = true) {
            let item = cfg.item_definition.item.get(itemId);
            if (!item) return;
            let times = 0;
            let screenshotCamera = view.DesktopMgr.Inst.mainCamera;
            let basePicName = item['name_' + GameMgr.client_language] + "_" + itemId;
            app.Log.log("检查特效开始： " + basePicName);
            //平均500ms进行一次截图直到onDestroy
            let screenCapture = () => {
                times++;
                let picName = basePicName + "_" + times + ".png";
                this.screenCaptureWithCam([view.DesktopMgr.Inst.mainCamera, game.Scene_MJ.Inst.effect_fullscreen_camera], picName, CheckTool.outputW, CheckTool.outputH);
                // console.log("截图", item['name_' + GameMgr.client_language] + "_" + times + ".png");

            }
            let onLoaded = Laya.Handler.create(this, () => {
                Laya.timer.loop(500, this, screenCapture);

            });
            this.previewLichiEffect(itemId, seat, Laya.Handler.create(this, () => {
                view.DesktopMgr.Inst.players[seat].QiPaiNoPass();
                Laya.timer.clear(this, screenCapture);
                app.Log.log("检查立直特效结束： " + basePicName);
                if (onDestroy) {
                    onDestroy.run();
                }
            }), isPreload, onLoaded);
        }

        public previewAllLichiEffect(seat: number = 0,isPreload: boolean = true) {
            let needCheckLichiEffects: number[] = [];
            cfg.item_definition.item.forEach(item => {
                if (item.category == 5) {
                    //特效是否过期
                    let isExperied = item['name_' + GameMgr.client_language].includes('已过期') || item['name_' + GameMgr.client_language].includes('已過期');
                    if (!isExperied) {
                        if (item.type == 2) {
                            //立直特效
                            needCheckLichiEffects.push(item.id);
                        }
                    }
                }
            });
            let checkLichi = () => {
                let lichiId = needCheckLichiEffects.shift();
                if (!lichiId) {
                    app.Log.log("立直特效播放完成");
                    return;
                }
                this.previewLichiEffect(lichiId, seat, Laya.Handler.create(this, () => {
                    checkLichi();
                }), isPreload);
            }
            checkLichi();
        }

        public previewAllHupaiEffect(isPreload: boolean = true) {
            let needCheckRonEffects: number[] = [];
            cfg.item_definition.item.forEach(item => {
                if (item.category == 5) {
                    //特效是否过期
                    let isExperied = item['name_' + GameMgr.client_language].includes('已过期') || item['name_' + GameMgr.client_language].includes('已過期');
                    if (!isExperied) {
                        if (item.type == 1 && item.id != 305215) {
                            //和牌特效
                            needCheckRonEffects.push(item.id);
                        }
                    }
                }
            });
            let checkRon = () => {
                let ronId = needCheckRonEffects.shift();
                if (!ronId) {
                    app.Log.log("和牌特效播放完成");
                    return;
                }
                this.previewHuleEffect(ronId, Laya.Handler.create(this, () => {
                    checkRon();
                }), isPreload);
            }
            checkRon();
        }



        /**
         * 不截图，直接播放立直特效
         * @param itemId 
         * @param onDestroy 
         * @param seat 立直特效对应的座位，默认0是主视角
         * @returns 
         */
        public previewLichiEffect(itemId: number, seat: number = 0, onDestroy: Laya.Handler = null, isPreload: boolean = true,onLoaded?:Laya.Handler) {
            let item = cfg.item_definition.item.get(itemId);
            if (!item) return;
            let onLoadComplete = () => { 
                //根据seat播放
                let player = view.DesktopMgr.Inst.players[seat];
                if (!player) return;
                view.DesktopMgr.Inst.player_effects[seat][game.EView.lizhi_effect] = itemId;
                view.DesktopMgr.Inst.players[seat].AddQiPai(new mjcore.MJPai(), true, false);
                app.Log.log('【CheckTool】previewLichiEffect itemId=' + itemId + ' seat=' + seat);
                Laya.timer.once(3000, this, () => {
                    view.DesktopMgr.Inst.players[seat].QiPaiNoPass();
                    onDestroy?.run();
                })
                onLoaded?.run();
            }
            if (!isPreload) {
                onLoadComplete();
            } else {
                game.Scene_MJ.Inst.preloadEffects([itemId], Laya.Handler.create(this, () => {
                    onLoadComplete();
                }), null);
            }
           
        }

        /**
         * 不截图，直接播放和牌特效
         * @param itemId 和牌特效id
         * @param onDestroy 
         * @returns 
         */
        public previewHuleEffect(itemId: number, onDestroy: Laya.Handler = null, isPreload: boolean = true,onLoaded?:Laya.Handler) {
            let item = cfg.item_definition.item.get(itemId);
            if (!item) return;
            let onLoadComplete = () => { 
                view.DesktopMgr.Inst.ShowHuleEffect(view.DesktopMgr.Inst.lastqipai, view.DesktopMgr.Inst.lastqipai.model.transform, itemId, view.DesktopMgr.Inst.lastpai_seat);
                //特效销毁延迟
                let delay = 2000;
                let hupaiViewData = cfg.item_definition.view.get(itemId);
                if (hupaiViewData && hupaiViewData.sargs[0]) {
                    delay += Number(hupaiViewData.sargs[0]);
                }
                Laya.timer.once(delay, this, () => {
                    onDestroy?.run();
                });
                onLoaded?.run();
            }
            if (!isPreload) {
                onLoadComplete();
            } else {
                game.Scene_MJ.Inst.preloadEffects([itemId], Laya.Handler.create(this, () => {
                    onLoadComplete();
                }), null);
            }
          
        }

    }

    new CheckTool();
}