
import View=laya.ui.View;
import Dialog=laya.ui.Dialog;
import EffectAnimation=laya.display.EffectAnimation;
module ui.amulet {
    export class amulet_bossUI extends View {
		public boss1_show:Laya.FrameAnimation;
		public boss1_idle:Laya.FrameAnimation;
		public boss2_show:Laya.FrameAnimation;
		public boss2_idle:Laya.FrameAnimation;
		public boss3_show:Laya.FrameAnimation;
		public boss3_idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("amulet/amulet_boss");

        }

    }
}

module ui.amulet {
    export class amulet_cardlibraryUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("amulet/amulet_cardlibrary");

        }

    }
}

module ui.amulet {
    export class amulet_challengeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("amulet/amulet_challenge");

        }

    }
}

module ui.amulet {
    export class amulet_desktopinfoUI extends View {
		public showBoss:Laya.FrameAnimation;
		public showShop:Laya.FrameAnimation;
		public showDesktop:Laya.FrameAnimation;
		public shake1:Laya.FrameAnimation;
		public showCard:Laya.FrameAnimation;
		public shake2:Laya.FrameAnimation;
		public shake3:Laya.FrameAnimation;
		public shake4:Laya.FrameAnimation;
		public shake5:Laya.FrameAnimation;
		public base_modify_add:Laya.FrameAnimation;
		public fan_modify_add:Laya.FrameAnimation;
		public damoVS:Laya.FrameAnimation;
		public base_modify_minus:Laya.FrameAnimation;
		public fan_modify_minus:Laya.FrameAnimation;
		public showBoss02:Laya.FrameAnimation;
		public hideBoss:Laya.FrameAnimation;
		public hideShop:Laya.FrameAnimation;
		public idleShop:Laya.FrameAnimation;
		public shop_star_idle01:Laya.FrameAnimation;
		public shop_star_idle02:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.amulet.amulet_bossUI",ui.amulet.amulet_bossUI);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("amulet/amulet_desktopinfo");

        }

    }
}

module ui.amulet {
    export class amulet_DevDebugUI extends View {
		public btn_show:Laya.Button;
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public add_amulet:Laya.Sprite;
		public input_amulet_id:Laya.TextInput;
		public input_amulet_val:Laya.TextInput;
		public btn_add_amulet:Laya.Button;
		public shop_amulet_select:Laya.Sprite;
		public input_shop_amulet:Laya.TextInput;
		public btn_shop_amulet:Laya.Button;
		public input_shop_badge:Laya.TextInput;
		public input_coin:Laya.TextInput;
		public btn_coin:Laya.Button;
		public btn_open_mountain:Laya.Button;
		public input_hands:Laya.TextInput;
		public btn_hands:Laya.Button;
		public input_paishan:Laya.TextInput;
		public btn_paishan:Laya.Button;
		public input_boss_buff:Laya.TextInput;
		public btn_boss_buff:Laya.Button;
		public input_score:Laya.TextInput;
		public btn_score:Laya.Button;
		public score_extra:Laya.TextInput;
		public input_level:Laya.TextInput;
		public btn_level:Laya.Button;
		public paiScoreName:Laya.TextInput;
		public paiScoreScore:Laya.TextInput;
		public changePaiScore:Laya.Button;
		public dora_input:Laya.TextInput;
		public dora_confirm:Laya.Button;
		public hunpai_input:Laya.TextInput;
		public hunpai_confirm:Laya.Button;
		public openoveriview:Laya.Button;
		public testscore:Laya.Sprite;
		public testscore1:Laya.TextInput;
		public testpoint:Laya.Button;
		public testscore2:Laya.TextInput;
		public testresult:Laya.Label;
		public container_score1:Laya.Sprite;
		public container_score2:Laya.Sprite;
		public container_score3:Laya.Sprite;
		public container_score4:Laya.Sprite;
		public container_score5:Laya.Sprite;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("amulet/amulet_DevDebug");

        }

    }
}

module ui.amulet {
    export class amulet_fevertimeUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("amulet/amulet_fevertime");

        }

    }
}

module ui.amulet {
    export class amulet_gameresultUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public win_show:Laya.FrameAnimation;
		public win_idle:Laya.FrameAnimation;
		public over_show:Laya.FrameAnimation;
		public star_idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("amulet/amulet_gameresult");

        }

    }
}

module ui.amulet {
    export class amulet_levellistUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("amulet/amulet_levellist");

        }

    }
}

module ui.amulet {
    export class amulet_levelresultUI extends View {
		public show:Laya.FrameAnimation;
		public lingqu:Laya.FrameAnimation;
		public bg_star:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public char_idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("amulet/amulet_levelresult");

        }

    }
}

module ui.amulet {
    export class amulet_operationUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("amulet/amulet_operation");

        }

    }
}

module ui.amulet {
    export class amulet_overviewUI extends View {
		public show_badge:Laya.FrameAnimation;
		public hide_badge:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.SpriteLocalizationPos",capsui.SpriteLocalizationPos);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("amulet/amulet_overview");

        }

    }
}

module ui.amulet {
    export class amulet_propUI extends View {
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("amulet/amulet_prop");

        }

    }
}

module ui.amulet {
    export class amulet_propsUI extends View {
		public showInShop:Laya.FrameAnimation;
		public hideInShop:Laya.FrameAnimation;
		public hideFree:Laya.FrameAnimation;
		public showFree:Laya.FrameAnimation;
		public cardShow:Laya.FrameAnimation;
		public cardHide:Laya.FrameAnimation;
		public cardSell:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.amulet.amulet_propUI",ui.amulet.amulet_propUI);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.SpriteLocalizationPos",capsui.SpriteLocalizationPos);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("amulet/amulet_props");

        }

    }
}

module ui.amulet {
    export class amulet_rankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("amulet/amulet_rank");

        }

    }
}

module ui.amulet {
    export class amulet_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("amulet/amulet_reward");

        }

    }
}

module ui.amulet {
    export class amulet_rulesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("amulet/amulet_rules");

        }

    }
}

module ui.amulet {
    export class amulet_startUI extends View {
		public show:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("amulet/amulet_start");

        }

    }
}

module ui.amulet {
    export class amulet_strengthenUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("amulet/amulet_strengthen");

        }

    }
}

module ui.amulet {
    export class amulet_tingpaiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("amulet/amulet_tingpai");

        }

    }
}

module ui.anim {
    export class alpha_inUI extends EffectAnimation {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        public static  uiView:any ={"type":"View","props":{},"child":[{"type":"Image","props":{"y":-4,"x":4,"skin":"myres/0p.png","anchorY":0.5,"anchorX":0.5},"compId":2}],"animations":[{"nodes":[{"target":2,"keyframes":{"y":[{"value":-1,"tweenMethod":"linearNone","tween":true,"target":2,"key":"y","index":0},{"value":167,"tweenMethod":"linearNone","tween":true,"target":2,"key":"y","index":14},{"value":0,"tweenMethod":"backIn","tween":true,"target":2,"key":"y","index":20}],"x":[{"value":-1,"tweenMethod":"backIn","tween":true,"target":2,"key":"x","index":0},{"value":-360,"tweenMethod":"linearNone","tween":true,"target":2,"key":"x","index":14},{"value":0,"tweenMethod":"backIn","tween":true,"target":2,"key":"x","index":20}],"scaleY":[{"value":1,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleY","index":0},{"value":0.58,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleY","index":7},{"value":2,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleY","index":20}],"scaleX":[{"value":1,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleX","index":0},{"value":0.5,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleX","index":7},{"value":2,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleX","index":20},{"value":1,"tweenMethod":"linearNone","tween":true,"target":2,"key":"scaleX","index":31}],"rotation":[{"value":0,"tweenMethod":"linearNone","tween":true,"target":2,"key":"rotation","index":0},{"value":0,"tweenMethod":"linearNone","tween":true,"target":2,"key":"rotation","index":14}],"alpha":[{"value":1,"tweenMethod":"linearNone","tween":true,"target":2,"key":"alpha","index":0},{"value":1,"tweenMethod":"backIn","tween":true,"target":2,"key":"alpha","index":20}]}}],"name":"in","id":1,"frameRate":60,"action":0},{"nodes":[{"target":2,"keyframes":{"y":[{"value":0,"tweenMethod":"linearNone","tween":true,"target":2,"key":"y","index":0}],"x":[{"value":0,"tweenMethod":"backIn","tween":true,"target":2,"key":"x","index":0},{"value":100,"tweenMethod":"linearNone","tween":true,"target":2,"key":"x","index":10}]}}],"name":"out","id":2,"frameRate":24,"action":0}]};
        constructor(){ super();this.effectData =ui.anim.alpha_inUI.uiView;}
    }
}

module ui.anim {
    export class animtestUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("anim/animtest");

        }

    }
}

module ui.both_ui {
    export class achievement_tipsUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/achievement_tips");

        }

    }
}

module ui.both_ui {
    export class bind_mail0UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/bind_mail0");

        }

    }
}

module ui.both_ui {
    export class bind_mail1UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/bind_mail1");

        }

    }
}

module ui.both_ui {
    export class bind_yostar_mailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/bind_yostar_mail");

        }

    }
}

module ui.both_ui {
    export class character_star_upUI extends View {
		public bang:Laya.FrameAnimation;
		public in:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/character_star_up");

        }

    }
}

module ui.both_ui.char_filter {
    export class char_filterUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("both_ui/char_filter/char_filter");

        }

    }
}

module ui.both_ui.config {
    export class config_line_dropdownUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_dropdown");

        }

    }
}

module ui.both_ui.config {
    export class config_line_jump_btnUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_jump_btn");

        }

    }
}

module ui.both_ui.config {
    export class config_line_part_startUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_part_start");

        }

    }
}

module ui.both_ui.config {
    export class config_line_part_start_audioUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_part_start_audio");

        }

    }
}

module ui.both_ui.config {
    export class config_line_sliderUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_slider");

        }

    }
}

module ui.both_ui.config {
    export class config_line_slider_audioUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_slider_audio");

        }

    }
}

module ui.both_ui.config {
    export class config_line_toggleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_line_toggle");

        }

    }
}

module ui.both_ui.config {
    export class config_newUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/config/config_new");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_bind_mailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_bind_mail");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_bind_mail_passwordUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_bind_mail_password");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_character_audioUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_character_audio");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_character_visibleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_character_visible");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_dropdownUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_dropdown");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_giftcodeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_giftcode");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_info");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_language_selectUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_language_select");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_lobby_audioUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("both_ui/config/config_popup_lobby_audio");

        }

    }
}

module ui.both_ui.config {
    export class config_popup_lobby_audio_runningUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/config/config_popup_lobby_audio_running");

        }

    }
}

module ui.both_ui {
    export class configUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/config");

        }

    }
}

module ui.both_ui {
    export class courseUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("both_ui/course");

        }

    }
}

module ui.both_ui {
    export class dmm_buy_popUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/dmm_buy_pop");

        }

    }
}

module ui.both_ui {
    export class dmm_kefuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/dmm_kefu");

        }

    }
}

module ui.both_ui {
    export class fly_tipsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("both_ui/fly_tips");

        }

    }
}

module ui.both_ui {
    export class game_DevDebugUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/game_DevDebug");

        }

    }
}

module ui.both_ui {
    export class getcharacterUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/getcharacter");

        }

    }
}

module ui.both_ui {
    export class getrewardUI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("both_ui/getreward");

        }

    }
}

module ui.both_ui {
    export class getreward2UI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/getreward2");

        }

    }
}

module ui.both_ui {
    export class gettitleUI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/gettitle");

        }

    }
}

module ui.both_ui {
    export class gitfcodeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/gitfcode");

        }

    }
}

module ui.both_ui {
    export class hide_name_tipUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/hide_name_tip");

        }

    }
}

module ui.both_ui {
    export class info_bigUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/info_big");

        }

    }
}

module ui.both_ui {
    export class info_midUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/info_mid");

        }

    }
}

module ui.both_ui {
    export class info_mid_scrollUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/info_mid_scroll");

        }

    }
}

module ui.both_ui {
    export class info_mid_titleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/info_mid_title");

        }

    }
}

module ui.both_ui {
    export class info_mid_title_scrollUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/info_mid_title_scroll");

        }

    }
}

module ui.both_ui {
    export class info_smallUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/info_small");

        }

    }
}

module ui.both_ui {
    export class inviteUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("both_ui/invite");

        }

    }
}

module ui.both_ui {
    export class itemdetailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/itemdetail");

        }

    }
}

module ui.both_ui {
    export class light_tipsUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("both_ui/light_tips");

        }

    }
}

module ui.both_ui.maka {
    export class maka_analysisUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public fenxi_show:Laya.FrameAnimation;
		public circle_fenxi:Laya.FrameAnimation;
		public circle_complete:Laya.FrameAnimation;
		public fenxi_hide:Laya.FrameAnimation;
		public shuzi:Laya.FrameAnimation;
		public circle_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("both_ui/maka/maka_analysis");

        }

    }
}

module ui.both_ui {
    export class mycard_pay_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/mycard_pay_info");

        }

    }
}

module ui.both_ui {
    export class need_bind_mailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/need_bind_mail");

        }

    }
}

module ui.both_ui {
    export class otherplayerinfoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);

            super.createChildren();
            this.loadUI("both_ui/otherplayerinfo");

        }

    }
}

module ui.both_ui {
    export class otherplayerinfo_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);

            super.createChildren();
            this.loadUI("both_ui/otherplayerinfo_en");

        }

    }
}

module ui.both_ui.playerinfo {
    export class playerinfo_DevDebugUI extends View {
		public btn_show:Laya.Button;
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public hepai:Laya.Sprite;
		public hepai0:Laya.TextInput;
		public hepai1:Laya.TextInput;
		public hepai2:Laya.TextInput;
		public btn_hepai:Laya.Button;
		public shunwei:Laya.Sprite;
		public rank0:Laya.TextInput;
		public rank1:Laya.TextInput;
		public rank2:Laya.TextInput;
		public rank3:Laya.TextInput;
		public btn_shunwei:Laya.Button;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/playerinfo/playerinfo_DevDebug");

        }

    }
}

module ui.both_ui.playerinfo {
    export class playerinfo_editUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("both_ui/playerinfo/playerinfo_edit");

        }

    }
}

module ui.both_ui.playerinfo {
    export class playerinfo_remarksUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/playerinfo/playerinfo_remarks");

        }

    }
}

module ui.both_ui.playerinfo {
    export class playerinfo_rootUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("both_ui/playerinfo/playerinfo_root");

        }

    }
}

module ui.both_ui {
    export class popwindowUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/popwindow");

        }

    }
}

module ui.both_ui {
    export class renameUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("both_ui/rename");

        }

    }
}

module ui.both_ui {
    export class reportUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("both_ui/report");

        }

    }
}

module ui.both_ui {
    export class report_nicknameUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/report_nickname");

        }

    }
}

module ui.both_ui {
    export class report_successUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/report_success");

        }

    }
}

module ui.both_ui {
    export class rulesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("both_ui/rules");

        }

    }
}

module ui.both_ui {
    export class rules_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("both_ui/rules_en");

        }

    }
}

module ui.both_ui {
    export class secondconfirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("both_ui/secondconfirm");

        }

    }
}

module ui.both_ui {
    export class secondconfirm_titleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("both_ui/secondconfirm_title");

        }

    }
}

module ui.both_ui {
    export class unbind_phoneUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/unbind_phone");

        }

    }
}

module ui.both_ui {
    export class unbind_yostar_mailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("both_ui/unbind_yostar_mail");

        }

    }
}

module ui.common {
    export class android_changeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/android_change");

        }

    }
}

module ui.common {
    export class bind_phone0UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/bind_phone0");

        }

    }
}

module ui.common {
    export class bind_phone1UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/bind_phone1");

        }

    }
}

module ui.common {
    export class bind_phone2UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/bind_phone2");

        }

    }
}

module ui.common {
    export class canot_create_phone_accountUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/canot_create_phone_account");

        }

    }
}

module ui.common {
    export class closeappUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/closeapp");

        }

    }
}

module ui.common {
    export class commonUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("common/common");

        }

    }
}

module ui.common {
    export class create_phone_accountUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/create_phone_account");

        }

    }
}

module ui.common {
    export class create_phone_account_successUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/create_phone_account_success");

        }

    }
}

module ui.common {
    export class disconnectUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/disconnect");

        }

    }
}

module ui.common {
    export class dmm_bgm_noticeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/dmm_bgm_notice");

        }

    }
}

module ui.common {
    export class errorinfoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/errorinfo");

        }

    }
}

module ui.common {
    export class lite_loadingUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("common/lite_loading");

        }

    }
}

module ui.common {
    export class loadingUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("common/loading");

        }

    }
}

module ui.common {
    export class loading_SDUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("common/loading_SD");

        }

    }
}

module ui.common {
    export class maintain_noticeUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/maintain_notice");

        }

    }
}

module ui.common {
    export class preventaddictionUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("common/preventaddiction");

        }

    }
}

module ui.common {
    export class reconnectUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/reconnect");

        }

    }
}

module ui.common {
    export class renzheng_krUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/renzheng_kr");

        }

    }
}

module ui.common {
    export class rollnoticeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("common/rollnotice");

        }

    }
}

module ui.common {
    export class shimingrenzhengUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/shimingrenzheng");

        }

    }
}

module ui.common {
    export class time_select_rangesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("common/time_select_ranges");

        }

    }
}

module ui.common {
    export class user_xieyiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/user_xieyi");

        }

    }
}

module ui.common {
    export class user_xieyi_dmmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/user_xieyi_dmm");

        }

    }
}

module ui.common {
    export class user_xieyi_enjpUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("common/user_xieyi_enjp");

        }

    }
}

module ui.common {
    export class user_xieyi_updateUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/user_xieyi_update");

        }

    }
}

module ui.common {
    export class videoUI extends View {
		public ani1:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("common/video");

        }

    }
}

module ui.common {
    export class yanzhengUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("common/yanzheng");

        }

    }
}

module ui.entrance {
    export class account_deletedUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/account_deleted");

        }

    }
}

module ui.entrance {
    export class account_prohibitionUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/account_prohibition");

        }

    }
}

module ui.entrance {
    export class account_prohibition_midUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/account_prohibition_mid");

        }

    }
}

module ui.entrance {
    export class add2desktopUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/add2desktop");

        }

    }
}

module ui.entrance {
    export class change_languageUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/change_language");

        }

    }
}

module ui.entrance {
    export class chooseserverUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/chooseserver");

        }

    }
}

module ui.entrance {
    export class choose_languageUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("entrance/choose_language");

        }

    }
}

module ui.entrance {
    export class choose_routeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("entrance/choose_route");

        }

    }
}

module ui.entrance {
    export class entranceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);

            super.createChildren();
            this.loadUI("entrance/entrance");

        }

    }
}

module ui.entrance {
    export class error_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/error_info");

        }

    }
}

module ui.entrance {
    export class game_tipUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("entrance/game_tip");

        }

    }
}

module ui.entrance {
    export class ios_webview_updateUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("entrance/ios_webview_update");

        }

    }
}

module ui.entrance {
    export class login_queueUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("entrance/login_queue");

        }

    }
}

module ui.entrance {
    export class mail_registUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("entrance/mail_regist");

        }

    }
}

module ui.entrance {
    export class maintenanceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/maintenance");

        }

    }
}

module ui.entrance {
    export class netRoute_DevDebugUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("entrance/netRoute_DevDebug");

        }

    }
}

module ui.entrance {
    export class remindUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("entrance/remind");

        }

    }
}

module ui.entrance {
    export class remind_newUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("entrance/remind_new");

        }

    }
}

module ui.entrance {
    export class reset_passwordUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/reset_password");

        }

    }
}

module ui.entrance {
    export class reset_password_phone2UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("entrance/reset_password_phone2");

        }

    }
}

module ui.entrance {
    export class secondconfirm_entranceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/secondconfirm_entrance");

        }

    }
}

module ui.entrance {
    export class third_bind_emailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("entrance/third_bind_email");

        }

    }
}

module ui.guide {
    export class activity_guide_chatUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("guide/activity_guide_chat");

        }

    }
}

module ui.guide {
    export class activity_guide_chat_forceUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("guide/activity_guide_chat_force");

        }

    }
}

module ui.guide {
    export class activity_guide_operationUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("guide/activity_guide_operation");

        }

    }
}

module ui.guide {
    export class activity_guide_rulesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("guide/activity_guide_rules");

        }

    }
}

module ui.huiye {
    export class huiyeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("huiye/huiye");

        }

    }
}

module ui.kuangdu {
    export class kuangduUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("kuangdu/kuangdu");

        }

    }
}

module ui.kuangdu {
    export class kuangdu_rulesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("kuangdu/kuangdu_rules");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_chatUI extends View {
		public show_chat:Laya.FrameAnimation;
		public hide_chat:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_chat");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_confirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_confirm");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_DevDebugUI extends View {
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public btn_log:Laya.Button;
		public btn_btn3:Laya.Button;
		public btn_npc:Laya.Button;
		public log_panel:Laya.Panel;
		public com_log:Laya.Sprite;
		public log:Laya.Label;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_DevDebug");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_equipmentUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public choosePart_show:Laya.FrameAnimation;
		public choosePart_hide:Laya.FrameAnimation;
		public popResult_show:Laya.FrameAnimation;
		public popResult_idle:Laya.FrameAnimation;
		public popResult_hide:Laya.FrameAnimation;
		public result_icon1_rotation:Laya.FrameAnimation;
		public btns_show1:Laya.FrameAnimation;
		public btns_hide1:Laya.FrameAnimation;
		public cancomposite_idle:Laya.FrameAnimation;
		public btns_show2:Laya.FrameAnimation;
		public btns_hide2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_equip_infoUI",ui.liandong.activity_2604dj.component.mmo_equip_infoUI);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_equipment");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_gameUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public battle:Laya.FrameAnimation;
		public prepare:Laya.FrameAnimation;
		public countdown:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_damageUI",ui.liandong.activity_2604dj.component.mmo_damageUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_hero_panelUI",ui.liandong.activity_2604dj.component.mmo_hero_panelUI);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_itemUI",ui.liandong.activity_2604dj.component.mmo_itemUI);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_game");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_info");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_jobUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_job");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_matchUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public icon_show:Laya.FrameAnimation;
		public icon_idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_match");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_page_effectUI extends View {
		public lizi:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_page_effect");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_resultUI extends View {
		public win_show:Laya.FrameAnimation;
		public win_hide:Laya.FrameAnimation;
		public lose_show:Laya.FrameAnimation;
		public lose_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_itemUI",ui.liandong.activity_2604dj.component.mmo_itemUI);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_result");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("ui.liandong.activity_2604dj.activity_2604mmo_reward_itemUI",ui.liandong.activity_2604dj.activity_2604mmo_reward_itemUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_reward");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_reward_itemUI extends View {
		public got:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_reward_item");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_selectUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_memberUI",ui.liandong.activity_2604dj.component.mmo_memberUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.NoLimitList_Heng",capsui.NoLimitList_Heng);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_select");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_spotUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_spot");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_supportUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_support");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_talentUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public templete_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_talent");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public PopBuff_show:Laya.FrameAnimation;
		public PopBuff_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_task");

        }

    }
}

module ui.liandong.activity_2604dj {
    export class activity_2604mmo_tavernUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public mark_idle:Laya.FrameAnimation;
		public friend_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_itemUI",ui.liandong.activity_2604dj.component.mmo_itemUI);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_hero_panelUI",ui.liandong.activity_2604dj.component.mmo_hero_panelUI);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/activity_2604mmo_tavern");

        }

    }
}

module ui.liandong.activity_2604dj.component {
    export class mmo_damageUI extends View {
		public hit_dmg:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/component/mmo_damage");

        }

    }
}

module ui.liandong.activity_2604dj.component {
    export class mmo_equip_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/component/mmo_equip_info");

        }

    }
}

module ui.liandong.activity_2604dj.component {
    export class mmo_hero_panelUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.liandong.activity_2604dj.component.mmo_itemUI",ui.liandong.activity_2604dj.component.mmo_itemUI);
			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/component/mmo_hero_panel");

        }

    }
}

module ui.liandong.activity_2604dj.component {
    export class mmo_itemUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("liandong/activity_2604dj/component/mmo_item");

        }

    }
}

module ui.liandong.activity_2604dj.component {
    export class mmo_memberUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CImageNumber",capsui.CImageNumber);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_itemUI",ui.liandong.activity_2604dj.component.mmo_itemUI);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_2604dj/component/mmo_member");

        }

    }
}

module ui.liandong {
    export class activity_liandong_mainUI extends View {
		public showpage:Laya.FrameAnimation;
		public hidepage:Laya.FrameAnimation;
		public showmain:Laya.FrameAnimation;
		public hidemain:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("ui.liandong.activity_2604dj.component.mmo_hero_panelUI",ui.liandong.activity_2604dj.component.mmo_hero_panelUI);
			View.regComponent("ui.liandong.activity_2604dj.activity_2604mmo_chatUI",ui.liandong.activity_2604dj.activity_2604mmo_chatUI);

            super.createChildren();
            this.loadUI("liandong/activity_liandong_main");

        }

    }
}

module ui.liandong {
    export class activity_liandong_matchUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("liandong/activity_liandong_match");

        }

    }
}

module ui.liandong {
    export class activity_liandong_signupUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/activity_liandong_signup");

        }

    }
}

module ui.liandong {
    export class activity_liandong_spotUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("liandong/activity_liandong_spot");

        }

    }
}

module ui.liandong {
    export class activity_liandong_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("liandong/activity_liandong_task");

        }

    }
}

module ui.liandong.old {
    export class liandong_mainUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("liandong/old/liandong_main");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_cardUI extends View {
		public show:Laya.FrameAnimation;
		public click:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_card");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_chatUI extends View {
		public show_chat:Laya.FrameAnimation;
		public hide_chat:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_chat");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_employeeUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_employee");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_employee_detailUI extends View {
		public assign_show:Laya.FrameAnimation;
		public assign_hide:Laya.FrameAnimation;
		public recruit:Laya.FrameAnimation;
		public roster_show:Laya.FrameAnimation;
		public roster_toggle:Laya.FrameAnimation;
		public recruit_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.liandong.yh.activity_2510questcrew_employeeUI",ui.liandong.yh.activity_2510questcrew_employeeUI);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_employee_detail");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_entrustUI extends View {
		public showbg:Laya.FrameAnimation;
		public assign_show:Laya.FrameAnimation;
		public assign_result_show:Laya.FrameAnimation;
		public assign_select:Laya.FrameAnimation;
		public assign_result:Laya.FrameAnimation;
		public hidebg:Laya.FrameAnimation;
		public select_show:Laya.FrameAnimation;
		public select_hide:Laya.FrameAnimation;
		public result_cofirm:Laya.FrameAnimation;
		public result_effects:Laya.FrameAnimation;
		public go_show:Laya.FrameAnimation;
		public go_idle:Laya.FrameAnimation;
		public go_start:Laya.FrameAnimation;
		public go_click:Laya.FrameAnimation;
		public go_click_idle:Laya.FrameAnimation;
		public go_click_cancel:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("ui.liandong.yh.activity_2510questcrew_employeeUI",ui.liandong.yh.activity_2510questcrew_employeeUI);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_entrust");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_rule");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_talentUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.liandong.yh.activity_2510questcrew_employee_detailUI",ui.liandong.yh.activity_2510questcrew_employee_detailUI);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("ui.liandong.yh.activity_2510questcrew_cardUI",ui.liandong.yh.activity_2510questcrew_cardUI);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_talent");

        }

    }
}

module ui.liandong.yh {
    export class activity_2510questcrew_tipUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("liandong/yh/activity_2510questcrew_tip");

        }

    }
}

module ui.lobby {
    export class ab_matchUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/ab_match");

        }

    }
}

module ui.lobby {
    export class ab_match_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/ab_match_en");

        }

    }
}

module ui.lobby {
    export class ab_match_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/ab_match_reward");

        }

    }
}

module ui.lobby {
    export class ab_match_scoreUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/ab_match_score");

        }

    }
}

module ui.lobby {
    export class achievementUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar_Heng",capsui.CScrollBar_Heng);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/achievement");

        }

    }
}

module ui.lobby {
    export class activityUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activity");

        }

    }
}

module ui.lobby.activitys {
    export class acitivity_fanpai_gridUI extends View {
		public task_show:Laya.FrameAnimation;
		public reward_show:Laya.FrameAnimation;
		public reward_idle:Laya.FrameAnimation;
		public reward_hide:Laya.FrameAnimation;
		public can_flip:Laya.FrameAnimation;
		public flipped_uncomplete:Laya.FrameAnimation;
		public flipped_completed:Laya.FrameAnimation;
		public flipped_rewarded:Laya.FrameAnimation;
		public task_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/acitivity_fanpai_grid");

        }

    }
}

module ui.lobby.activitys {
    export class activitybaseUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activitybase");

        }

    }
}

module ui.lobby.activitys {
    export class activity_ab_matchUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_ab_match");

        }

    }
}

module ui.lobby.activitys {
    export class activity_banner_2407_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_banner_2407_reward");

        }

    }
}

module ui.lobby.activitys {
    export class activity_banner_2407_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_banner_2407_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_banner_tag_loadingUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/activity_banner_tag_loading");

        }

    }
}

module ui.lobby.activitys {
    export class activity_dongriUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;
		public ani3:Laya.FrameAnimation;
		public ani4:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_dongri");

        }

    }
}

module ui.lobby.activitys {
    export class activity_dongrijiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_dongriji");

        }

    }
}

module ui.lobby.activitys {
    export class activity_duanwu_pointUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_duanwu_point");

        }

    }
}

module ui.lobby.activitys {
    export class activity_duanwu_rankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_duanwu_rank");

        }

    }
}

module ui.lobby.activitys {
    export class activity_entranceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_entrance");

        }

    }
}

module ui.lobby.activitys {
    export class activity_entrance_amuletUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_entrance_amulet");

        }

    }
}

module ui.lobby.activitys {
    export class activity_entrance_extraUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_entrance_extra");

        }

    }
}

module ui.lobby.activitys {
    export class activity_exchangeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_exchange");

        }

    }
}

module ui.lobby.activitys {
    export class activity_exchange_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_exchange_reward");

        }

    }
}

module ui.lobby.activitys {
    export class activity_exchange_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_exchange_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_exchange_zhongxiaUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_exchange_zhongxia");

        }

    }
}

module ui.lobby.activitys {
    export class activity_fanpaiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_fanpai");

        }

    }
}

module ui.lobby.activitys {
    export class activity_guoqing_cgUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/activity_guoqing_cg");

        }

    }
}

module ui.lobby.activitys {
    export class activity_hesuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_hesu");

        }

    }
}

module ui.lobby.activitys {
    export class activity_interval_desktopUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_interval_desktop");

        }

    }
}

module ui.lobby.activitys {
    export class activity_jiujiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_jiuji");

        }

    }
}

module ui.lobby.activitys {
    export class activity_llxUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_llx");

        }

    }
}

module ui.lobby.activitys {
    export class activity_match_entranceUI extends View {
		public loading_dot:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_match_entrance");

        }

    }
}

module ui.lobby.activitys {
    export class activity_niudanUI extends View {
		public enter:Laya.FrameAnimation;
		public open:Laya.FrameAnimation;
		public leave:Laya.FrameAnimation;
		public lizi0:Laya.FrameAnimation;
		public lizi1:Laya.FrameAnimation;
		public lizi2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_niudan");

        }

    }
}

module ui.lobby.activitys {
    export class activity_niudan_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_niudan_reward");

        }

    }
}

module ui.lobby.activitys {
    export class activity_questionairUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;
		public ani3:Laya.FrameAnimation;
		public ani4:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("Text",laya.display.Text);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_questionair");

        }

    }
}

module ui.lobby.activitys {
    export class activity_questionair_entranceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_questionair_entrance");

        }

    }
}

module ui.lobby.activitys {
    export class activity_rpg_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_rpg_reward");

        }

    }
}

module ui.lobby.activitys {
    export class activity_rpg_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_rpg_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_rpg_xiulianUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_rpg_xiulian");

        }

    }
}

module ui.lobby.activitys {
    export class activity_seven_daysUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_seven_days");

        }

    }
}

module ui.lobby.activitys {
    export class activity_sign_ylyUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_sign_yly");

        }

    }
}

module ui.lobby.activitys {
    export class activity_sns_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_sns_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_task_newyearUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_task_newyear");

        }

    }
}

module ui.lobby.activitys {
    export class activity_task_zhongxiaUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_task_zhongxia");

        }

    }
}

module ui.lobby.activitys {
    export class activity_tongbi_exchangeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_tongbi_exchange");

        }

    }
}

module ui.lobby.activitys {
    export class activity_vote_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_vote_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_vtuberUI extends View {
		public enter:Laya.FrameAnimation;
		public gift_1:Laya.FrameAnimation;
		public gift_10:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_vtuber");

        }

    }
}

module ui.lobby.activitys {
    export class activity_vtuber_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar_Heng",capsui.CScrollBar_Heng);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_vtuber_reward");

        }

    }
}

module ui.lobby.activitys {
    export class activity_vtuber_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_vtuber_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_wajueUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_wajue");

        }

    }
}

module ui.lobby.activitys {
    export class activity_wajue_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_wajue_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_wanxianggengxinUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_wanxianggengxin");

        }

    }
}

module ui.lobby.activitys {
    export class activity_wuyi_exchangeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_wuyi_exchange");

        }

    }
}

module ui.lobby.activitys {
    export class activity_wuyi_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_wuyi_task");

        }

    }
}

module ui.lobby.activitys {
    export class activity_xiari_exchangeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_xiari_exchange");

        }

    }
}

module ui.lobby.activitys {
    export class activity_xuanshangUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_xuanshang");

        }

    }
}

module ui.lobby.activitys {
    export class activity_yijidagongUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_yijidagong");

        }

    }
}

module ui.lobby.activitys {
    export class activity_yuekaUI extends View {
		public clock_shake:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_yueka");

        }

    }
}

module ui.lobby.activitys {
    export class activity_yueka_autoUI extends View {
		public show:Laya.FrameAnimation;
		public rot:Laya.FrameAnimation;
		public close:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_yueka_auto");

        }

    }
}

module ui.lobby.activitys {
    export class activity_yueka_enUI extends View {
		public clock_shake:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/activity_yueka_en");

        }

    }
}

module ui.lobby.activitys.bingo {
    export class activity_bingoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("lobby/activitys/bingo/activity_bingo");

        }

    }
}

module ui.lobby.activitys.bingo {
    export class activity_bingo_cardUI extends View {
		public reward_r1_nocomplete:Laya.FrameAnimation;
		public reward_r1_complete:Laya.FrameAnimation;
		public reward_r1_default:Laya.FrameAnimation;
		public reward_r2_nocomplete:Laya.FrameAnimation;
		public reward_r2_complete:Laya.FrameAnimation;
		public reward_r2_default:Laya.FrameAnimation;
		public reward_r3_nocomplete:Laya.FrameAnimation;
		public reward_r3_complete:Laya.FrameAnimation;
		public reward_r3_default:Laya.FrameAnimation;
		public reward_c1_nocomplete:Laya.FrameAnimation;
		public reward_c1_complete:Laya.FrameAnimation;
		public reward_c1_default:Laya.FrameAnimation;
		public reward_d1_nocomplete:Laya.FrameAnimation;
		public reward_d1_complete:Laya.FrameAnimation;
		public reward_d1_default:Laya.FrameAnimation;
		public reward_d2_nocomplete:Laya.FrameAnimation;
		public reward_d2_complete:Laya.FrameAnimation;
		public reward_d2_default:Laya.FrameAnimation;
		public reward_d3_nocomplete:Laya.FrameAnimation;
		public reward_d3_complete:Laya.FrameAnimation;
		public reward_d3_default:Laya.FrameAnimation;
		public reward_c2_nocomplete:Laya.FrameAnimation;
		public reward_c2_complete:Laya.FrameAnimation;
		public reward_c2_default:Laya.FrameAnimation;
		public reward_r1_star:Laya.FrameAnimation;
		public reward_r2_star:Laya.FrameAnimation;
		public reward_r3_star:Laya.FrameAnimation;
		public reward_c1_star:Laya.FrameAnimation;
		public reward_d1_star:Laya.FrameAnimation;
		public reward_d2_star:Laya.FrameAnimation;
		public reward_d3_star:Laya.FrameAnimation;
		public reward_c2_star:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);

            super.createChildren();
            this.loadUI("lobby/activitys/bingo/activity_bingo_card");

        }

    }
}

module ui.lobby.activitys.bingo {
    export class activity_bingo_card_gridUI extends View {
		public anim_show:Laya.FrameAnimation;
		public anim_lightup:Laya.FrameAnimation;
		public anim_cat:Laya.FrameAnimation;
		public anim_light:Laya.FrameAnimation;
		public nocomplete:Laya.FrameAnimation;
		public complete:Laya.FrameAnimation;
		public rewarded:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/bingo/activity_bingo_card_grid");

        }

    }
}

module ui.lobby.activitys.bingo {
    export class activity_bingo_card_lineUI extends View {
		public completed:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/bingo/activity_bingo_card_line");

        }

    }
}

module ui.lobby.activitys {
    export class fanpai_popoutUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activitys/fanpai_popout");

        }

    }
}

module ui.lobby.activitys {
    export class signUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activitys/sign");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidaoUI extends View {
		public animIn:Laya.FrameAnimation;
		public cloud4:Laya.FrameAnimation;
		public cloud3:Laya.FrameAnimation;
		public cloud2:Laya.FrameAnimation;
		public cloud1:Laya.FrameAnimation;
		public animOut:Laya.FrameAnimation;
		public anim_01:Laya.FrameAnimation;
		public anim_02:Laya.FrameAnimation;
		public anim_13:Laya.FrameAnimation;
		public anim_34:Laya.FrameAnimation;
		public anim_23:Laya.FrameAnimation;
		public anim_10:Laya.FrameAnimation;
		public anim_20:Laya.FrameAnimation;
		public anim_31:Laya.FrameAnimation;
		public anim_43:Laya.FrameAnimation;
		public anim_32:Laya.FrameAnimation;
		public shop:Laya.Sprite;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_bagUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public qiehuan:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_bag");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_congratUI extends View {
		public huode:Laya.FrameAnimation;
		public chengjiao:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_congrat");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_newsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_news");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public idle1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_reward");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_rule");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_shopUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public qiehuan:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_shop");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_spotUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_spot");

        }

    }
}

module ui.lobby.activity_2406_haidao {
    export class activity_2406_haidao_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2406_haidao/activity_2406_haidao_task");

        }

    }
}

module ui.lobby.activity_2408_spot {
    export class activity_2408_spotUI extends View {
		public show:Laya.FrameAnimation;
		public unlock1:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public unlock2:Laya.FrameAnimation;
		public unlock3:Laya.FrameAnimation;
		public unlock4:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);

            super.createChildren();
            this.loadUI("lobby/activity_2408_spot/activity_2408_spot");

        }

    }
}

module ui.lobby.activity_2408_spot {
    export class activity_2408_spot_buildingUI extends View {
		public show:Laya.FrameAnimation;
		public piaofu:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);

            super.createChildren();
            this.loadUI("lobby/activity_2408_spot/activity_2408_spot_building");

        }

    }
}

module ui.lobby.activity_2408_spot {
    export class activity_2408_spot_getUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2408_spot/activity_2408_spot_get");

        }

    }
}

module ui.lobby.activity_2408_spot {
    export class activity_2408_spot_noteUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/activity_2408_spot/activity_2408_spot_note");

        }

    }
}

module ui.lobby.activity_2408_spot {
    export class activity_guide_chatUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2408_spot/activity_guide_chat");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imasUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public showPage:Laya.FrameAnimation;
		public hidePage:Laya.FrameAnimation;
		public hideMain:Laya.FrameAnimation;
		public showMain:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_levelupUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public gradeShow:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_levelup");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_matchUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_match");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_reward");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_spotUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_spot");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_task");

        }

    }
}

module ui.lobby.activity_2411imas {
    export class activity_24imas_upgradeUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public levelup1:Laya.FrameAnimation;
		public icon1:Laya.FrameAnimation;
		public icon2:Laya.FrameAnimation;
		public icon3:Laya.FrameAnimation;
		public levelup2:Laya.FrameAnimation;
		public levelup3:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2411imas/activity_24imas_upgrade");

        }

    }
}

module ui.lobby.activity_2412_richman {
    export class activity_2412_richmanUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2412_richman/activity_2412_richman");

        }

    }
}

module ui.lobby.activity_2412_richman {
    export class activity_2412_richman_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2412_richman/activity_2412_richman_reward");

        }

    }
}

module ui.lobby.activity_2412_richman {
    export class activity_2412_richman_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2412_richman/activity_2412_richman_task");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24baUI extends View {
		public enter:Laya.FrameAnimation;
		public close:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_applyUI extends View {
		public apply_enter:Laya.FrameAnimation;
		public apply_close:Laya.FrameAnimation;
		public big_success_show:Laya.FrameAnimation;
		public success_show:Laya.FrameAnimation;
		public big_success_hide:Laya.FrameAnimation;
		public success_hide:Laya.FrameAnimation;
		public fail_show:Laya.FrameAnimation;
		public fail_hide:Laya.FrameAnimation;
		public apply_enter01:Laya.FrameAnimation;
		public apply_switch_R:Laya.FrameAnimation;
		public apply_switch01_R:Laya.FrameAnimation;
		public apply_switch_L:Laya.FrameAnimation;
		public apply_switch01_L:Laya.FrameAnimation;
		public apply_close01:Laya.FrameAnimation;
		public level_up_show:Laya.FrameAnimation;
		public fail2success:Laya.FrameAnimation;
		public level_up_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_apply");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_DevDebugUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_DevDebug");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_entranceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_entrance");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_levelupUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_levelup");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_matchUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_match");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_reward");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_rule");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_spotUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_spot");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_task");

        }

    }
}

module ui.lobby.activity_24ba {
    export class activity_24ba_upgradeUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/activity_24ba/activity_24ba_upgrade");

        }

    }
}

module ui.lobby.activity_24ba_sign {
    export class activity_24ba_sign_mainUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_24ba_sign/activity_24ba_sign_main");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hfUI extends View {
		public showpage:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;
		public hidepage:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public hidemain:Laya.FrameAnimation;
		public show_tb1:Laya.FrameAnimation;
		public idle_tb1:Laya.FrameAnimation;
		public show_tb2:Laya.FrameAnimation;
		public idle_tb2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hf_matchUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public show_tb:Laya.FrameAnimation;
		public idle_tb:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf_match");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hf_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf_reward");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hf_simulationUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public showstrengthen:Laya.FrameAnimation;
		public showpage:Laya.FrameAnimation;
		public show_tb:Laya.FrameAnimation;
		public idle_tb:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf_simulation");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hf_spotUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf_spot");

        }

    }
}

module ui.lobby.activity_2504hf {
    export class activity_25hf_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2504hf/activity_25hf_task");

        }

    }
}

module ui.lobby.activity_2508navigation {
    export class activity_2508navigationUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public chat_show1:Laya.FrameAnimation;
		public chat_hide1:Laya.FrameAnimation;
		public chat_show3:Laya.FrameAnimation;
		public chat_hide3:Laya.FrameAnimation;
		public chat_show2:Laya.FrameAnimation;
		public chat_hide2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2508navigation/activity_2508navigation");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_damageUI extends View {
		public hit_crit:Laya.FrameAnimation;
		public hit_dmg:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_damage");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_gameUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public combo:Laya.FrameAnimation;
		public auto:Laya.FrameAnimation;
		public speed:Laya.FrameAnimation;
		public combo_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("ui.lobby.activity_2512winter.activity_2512winter_damageUI",ui.lobby.activity_2512winter.activity_2512winter_damageUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_game");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_mainUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public tip_receive:Laya.FrameAnimation;
		public btn_reward_tip:Laya.FrameAnimation;
		public showpage:Laya.FrameAnimation;
		public hidepage:Laya.FrameAnimation;
		public completed:Laya.Image;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_main");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_resultUI extends View {
		public show:Laya.FrameAnimation;
		public win:Laya.FrameAnimation;
		public lose:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_result");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_rewardUI extends View {
		public claimed:Laya.FrameAnimation;
		public claim_1:Laya.FrameAnimation;
		public claim_2:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("ui.lobby.activity_2512winter.reward_right_itemUI",ui.lobby.activity_2512winter.reward_right_itemUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_reward");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_skillUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_skill");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("ui.lobby.activity_2512winter.task_received_itemUI",ui.lobby.activity_2512winter.task_received_itemUI);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_task");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class activity_2512winter_vsUI extends View {
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2512winter/activity_2512winter_vs");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class reward_right_itemUI extends View {
		public claimed:Laya.FrameAnimation;
		public claim_1:Laya.FrameAnimation;
		public claim_2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2512winter/reward_right_item");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class snowball_DevDebugUI extends View {
		public btn_show:Laya.Button;
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public change_now:Laya.Sprite;
		public input_now:Laya.TextInput;
		public btn_change_now:Laya.Button;
		public change_random:Laya.Sprite;
		public input_random:Laya.TextInput;
		public btn_test:Laya.Button;
		public btn_change_random:Laya.Button;
		public txt_random_test:Laya.Label;
		public log_content:Laya.Panel;
		public log_bg:Laya.Image;
		public log_parent:Laya.Sprite;
		public log:Laya.Label;
		public btn_log:Laya.Button;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2512winter/snowball_DevDebug");

        }

    }
}

module ui.lobby.activity_2512winter {
    export class task_received_itemUI extends View {
		public claimed:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2512winter/task_received_item");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_chatUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_chat");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_DevDebugUI extends View {
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public change_now:Laya.Sprite;
		public input_round:Laya.TextInput;
		public input_mode:Laya.TextInput;
		public btn_test:Laya.Button;
		public btn_log:Laya.Button;
		public testing:Laya.Label;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_DevDebug");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_gameUI extends View {
		public show:Laya.FrameAnimation;
		public pause_show:Laya.FrameAnimation;
		public pause_hide:Laya.FrameAnimation;
		public end_show:Laya.FrameAnimation;
		public end_idle:Laya.FrameAnimation;
		public time_glow:Laya.FrameAnimation;
		public fu_show:Laya.FrameAnimation;
		public fu_hide:Laya.FrameAnimation;
		public operate_show:Laya.FrameAnimation;
		public failed:Laya.FrameAnimation;
		public hand_limit:Laya.FrameAnimation;
		public fu_complete_1:Laya.FrameAnimation;
		public fu_complete_2:Laya.FrameAnimation;
		public fu_complete_3:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_game");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_mainUI extends View {
		public btn_idle:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI",ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("ui.lobby.activity_2602chunjie.activity_2602chunjie_trainUI",ui.lobby.activity_2602chunjie.activity_2602chunjie_trainUI);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_main");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_resultUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI",ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_result");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public content:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("ui.lobby.activity_2602chunjie.activity_2602chunjie_reward_itemUI",ui.lobby.activity_2602chunjie.activity_2602chunjie_reward_itemUI);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_reward");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_reward_itemUI extends View {
		public received:Laya.FrameAnimation;
		public star_idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_reward_item");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_task");

        }

    }
}

module ui.lobby.activity_2602chunjie {
    export class activity_2602chunjie_trainUI extends View {
		public idle:Laya.FrameAnimation;
		public complete:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_2602chunjie/activity_2602chunjie_train");

        }

    }
}

module ui.lobby.activity_clothes_vote {
    export class activity_clothes_voteUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public rank_show:Laya.FrameAnimation;
		public rank_hide:Laya.FrameAnimation;
		public vote_show:Laya.FrameAnimation;
		public vote_hide:Laya.FrameAnimation;
		public light0:Laya.FrameAnimation;
		public light1:Laya.FrameAnimation;
		public light2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/activity_clothes_vote/activity_clothes_vote");

        }

    }
}

module ui.lobby.activity_clothes_vote {
    export class activity_clothes_vote_rank_detailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_clothes_vote/activity_clothes_vote_rank_detail");

        }

    }
}

module ui.lobby.activity_clothes_vote {
    export class activity_clothes_vote_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/activity_clothes_vote/activity_clothes_vote_task");

        }

    }
}

module ui.lobby {
    export class activity_jjcUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_jjc");

        }

    }
}

module ui.lobby {
    export class activity_jjc_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_jjc_en");

        }

    }
}

module ui.lobby {
    export class activity_jjc_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/activity_jjc_reward");

        }

    }
}

module ui.lobby {
    export class activity_rpgUI extends View {
		public idle_yiji:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/activity_rpg");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shootUI extends View {
		public bg_loop:Laya.FrameAnimation;
		public arcade_enter:Laya.FrameAnimation;
		public arcade_hide:Laya.FrameAnimation;
		public enemy_enter:Laya.FrameAnimation;
		public enemy_idle:Laya.FrameAnimation;
		public task_enter:Laya.FrameAnimation;
		public task_hide:Laya.FrameAnimation;
		public stick_left:Laya.FrameAnimation;
		public stick_mid:Laya.FrameAnimation;
		public stick_right:Laya.FrameAnimation;
		public reward_hide:Laya.FrameAnimation;
		public reward_enter:Laya.FrameAnimation;
		public game_enter:Laya.FrameAnimation;
		public game_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButtonImage",capsui.CButtonImage);

            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shoot_bulletUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot_bullet");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shoot_monster_bigUI extends View {
		public idle:Laya.FrameAnimation;
		public hit:Laya.FrameAnimation;
		public death:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot_monster_big");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shoot_monster_midUI extends View {
		public idle:Laya.FrameAnimation;
		public hit:Laya.FrameAnimation;
		public death:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot_monster_mid");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shoot_monster_smallUI extends View {
		public hit:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public death:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot_monster_small");

        }

    }
}

module ui.lobby.activity_shoot {
    export class activity_shoot_planeUI extends View {
		public idle:Laya.FrameAnimation;
		public attack:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/activity_shoot/activity_shoot_plane");

        }

    }
}

module ui.lobby {
    export class activity_spotUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/activity_spot");

        }

    }
}

module ui.lobby {
    export class add_roomUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/add_room");

        }

    }
}

module ui.lobby {
    export class ageconfirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/ageconfirm");

        }

    }
}

module ui.lobby {
    export class agependingUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/agepending");

        }

    }
}

module ui.lobby {
    export class agepending_chsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/agepending_chs");

        }

    }
}

module ui.lobby {
    export class agesuccessUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/agesuccess");

        }

    }
}

module ui.lobby {
    export class agesuccess_chsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/agesuccess_chs");

        }

    }
}

module ui.lobby {
    export class agexianeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/agexiane");

        }

    }
}

module ui.lobby {
    export class bagUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CDropdown",capsui.CDropdown);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/bag");

        }

    }
}

module ui.lobby {
    export class camera_modeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/camera_mode");

        }

    }
}

module ui.lobby {
    export class cg_yulanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/cg_yulan");

        }

    }
}

module ui.lobby {
    export class change_nickname_confirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/change_nickname_confirm");

        }

    }
}

module ui.lobby {
    export class chang_nicknameUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/chang_nickname");

        }

    }
}

module ui.lobby {
    export class checkhuiyuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/checkhuiyu");

        }

    }
}

module ui.lobby {
    export class checkpifuquanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/checkpifuquan");

        }

    }
}

module ui.lobby {
    export class choose_timeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/choose_time");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjieUI extends View {
		public show:Laya.FrameAnimation;
		public strike:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_main_rewardUI extends View {
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_main_reward");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_miaoUI extends View {
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_miao");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_nextUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_next");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_reward");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_rule");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_task");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_tripUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_trip");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_upgradeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_upgrade");

        }

    }
}

module ui.lobby.chunjie {
    export class activity_chunjie_upgrade_resultUI extends View {
		public show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/chunjie/activity_chunjie_upgrade_result");

        }

    }
}

module ui.lobby.chunjie {
    export class worker_particleUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/chunjie/worker_particle");

        }

    }
}

module ui.lobby {
    export class chunjieUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;
		public ani3:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/chunjie");

        }

    }
}

module ui.lobby {
    export class chunjie_miaohuiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/chunjie_miaohui");

        }

    }
}

module ui.lobby {
    export class chunjie_rankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/chunjie_rank");

        }

    }
}

module ui.lobby.combining {
    export class activity_combiningUI extends View {
		public show:Laya.FrameAnimation;
		public bear_idle:Laya.FrameAnimation;
		public bear_use:Laya.FrameAnimation;
		public bear_tip:Laya.FrameAnimation;
		public char1_o:Laya.FrameAnimation;
		public char1_c:Laya.FrameAnimation;
		public char1_i:Laya.FrameAnimation;
		public char3_o:Laya.FrameAnimation;
		public char3_c:Laya.FrameAnimation;
		public char3_i:Laya.FrameAnimation;
		public char2_o:Laya.FrameAnimation;
		public char2_c:Laya.FrameAnimation;
		public char2_i:Laya.FrameAnimation;
		public bin1_tip:Laya.FrameAnimation;
		public caiban_chuxian:Laya.FrameAnimation;
		public bottle_remove:Laya.FrameAnimation;
		public bottle_over:Laya.FrameAnimation;
		public close:Laya.FrameAnimation;
		public bin2_tip:Laya.FrameAnimation;
		public char_empty_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/combining/activity_combining");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_char_otherUI extends View {
		public tishi_wancheng01:Laya.FrameAnimation;
		public item1_tip1_o:Laya.FrameAnimation;
		public tishi_cuowu01:Laya.FrameAnimation;
		public tishi_diancan01:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;
		public item1_tip1_i:Laya.FrameAnimation;
		public item1_tip1_c:Laya.FrameAnimation;
		public item2_tip1_o:Laya.FrameAnimation;
		public item2_tip2_o:Laya.FrameAnimation;
		public item2_tip1_i:Laya.FrameAnimation;
		public item2_tip2_i:Laya.FrameAnimation;
		public item2_tip1_c:Laya.FrameAnimation;
		public item2_tip2_c:Laya.FrameAnimation;
		public item1_tip2_o:Laya.FrameAnimation;
		public item1_tip2_i:Laya.FrameAnimation;
		public item1_tip2_c:Laya.FrameAnimation;
		public item1_icon1:Laya.FrameAnimation;
		public item1_icon2:Laya.FrameAnimation;
		public item2_icon1:Laya.FrameAnimation;
		public item2_icon2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_char_other");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_itemUI extends View {
		public tip0_o:Laya.FrameAnimation;
		public tip0_i:Laya.FrameAnimation;
		public tip0_c:Laya.FrameAnimation;
		public tip_drag:Laya.FrameAnimation;
		public item_show:Laya.FrameAnimation;
		public combining:Laya.FrameAnimation;
		public mouse_over:Laya.FrameAnimation;
		public mouse_remove:Laya.FrameAnimation;
		public star:Laya.FrameAnimation;
		public idle:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_item");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_menuUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_menu");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_newUI extends View {
		public show:Laya.FrameAnimation;
		public light:Laya.FrameAnimation;
		public star:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public glow_rot:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_new");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_rewardUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_reward");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_taskUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_task");

        }

    }
}

module ui.lobby.combining {
    export class activity_combining_yindaoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/combining/activity_combining_yindao");

        }

    }
}

module ui.lobby {
    export class create_roomUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/create_room");

        }

    }
}

module ui.lobby {
    export class create_room_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/create_room_rule");

        }

    }
}

module ui.lobby {
    export class delete_accountUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/delete_account");

        }

    }
}

module ui.lobby {
    export class force_updateUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/force_update");

        }

    }
}

module ui.lobby {
    export class freeze_uiUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/freeze_ui");

        }

    }
}

module ui.lobby {
    export class friendUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/friend");

        }

    }
}

module ui.lobby {
    export class get_characterUI extends View {
		public JSin:Laya.FrameAnimation;
		public JSout:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);

            super.createChildren();
            this.loadUI("lobby/get_character");

        }

    }
}

module ui.lobby {
    export class infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/info");

        }

    }
}

module ui.lobby {
    export class introduceUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/introduce");

        }

    }
}

module ui.lobby {
    export class lobbyUI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;
		public page_title_in:Laya.FrameAnimation;
		public page_title_out:Laya.FrameAnimation;
		public east_north_in1:Laya.FrameAnimation;
		public east_north_in2:Laya.FrameAnimation;
		public east_north_in4:Laya.FrameAnimation;
		public east_north_out:Laya.FrameAnimation;
		public rank_in:Laya.FrameAnimation;
		public rank_out:Laya.FrameAnimation;
		public friend_in:Laya.FrameAnimation;
		public friend_out:Laya.FrameAnimation;
		public match_in1:Laya.FrameAnimation;
		public match_in2:Laya.FrameAnimation;
		public match_in3:Laya.FrameAnimation;
		public match_in4:Laya.FrameAnimation;
		public match_out:Laya.FrameAnimation;
		public xunniup:Laya.FrameAnimation;
		public ani8:Laya.FrameAnimation;
		public match_in5:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/lobby");

        }

    }
}

module ui.lobby {
    export class lobbychatUI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("Text",laya.display.Text);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/lobbychat");

        }

    }
}

module ui.lobby {
    export class lobby_overallUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/lobby_overall");

        }

    }
}

module ui.lobby {
    export class mailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/mail");

        }

    }
}

module ui.lobby {
    export class match_lobbyUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/match_lobby");

        }

    }
}

module ui.lobby {
    export class match_roomUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/match_room");

        }

    }
}

module ui.lobby {
    export class match_room_createUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/match_room_create");

        }

    }
}

module ui.lobby {
    export class match_room_create_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/match_room_create_en");

        }

    }
}

module ui.lobby {
    export class match_room_manageUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/match_room_manage");

        }

    }
}

module ui.lobby {
    export class match_room_modifyUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/match_room_modify");

        }

    }
}

module ui.lobby {
    export class match_room_time_setiingUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/match_room_time_setiing");

        }

    }
}

module ui.lobby {
    export class match_shilianUI extends View {
		public fail_in:Laya.FrameAnimation;
		public fail_out:Laya.FrameAnimation;
		public success_in:Laya.FrameAnimation;
		public success_out:Laya.FrameAnimation;
		public s_middle2small:Laya.FrameAnimation;
		public s_small2big:Laya.FrameAnimation;
		public s_big2small:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/match_shilian");

        }

    }
}

module ui.lobby {
    export class match_ticketUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/match_ticket");

        }

    }
}

module ui.lobby.nianshou {
    export class nianshou_helpUI extends View {
		public enter:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/nianshou/nianshou_help");

        }

    }
}

module ui.lobby.nianshou {
    export class nianshou_mainUI extends View {
		public enter:Laya.FrameAnimation;
		public shicai:Laya.FrameAnimation;
		public lihui:Laya.FrameAnimation;
		public yun:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("lobby/nianshou/nianshou_main");

        }

    }
}

module ui.lobby.nianshou {
    export class nianshou_rewardsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/nianshou/nianshou_rewards");

        }

    }
}

module ui.lobby.nianshou {
    export class nianshou_send_confirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/nianshou/nianshou_send_confirm");

        }

    }
}

module ui.lobby.nianshou {
    export class nianshou_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/nianshou/nianshou_task");

        }

    }
}

module ui.lobby {
    export class nicknameUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/nickname");

        }

    }
}

module ui.lobby {
    export class number_inputUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/number_input");

        }

    }
}

module ui.lobby {
    export class obUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CDropdown",capsui.CDropdown);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/ob");

        }

    }
}

module ui.lobby {
    export class openboxUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/openbox");

        }

    }
}

module ui.lobby {
    export class openskinUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/openskin");

        }

    }
}

module ui.lobby {
    export class page_sign_chsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/page_sign_chs");

        }

    }
}

module ui.lobby {
    export class page_sign_chs_tUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/page_sign_chs_t");

        }

    }
}

module ui.lobby {
    export class page_sign_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/page_sign_en");

        }

    }
}

module ui.lobby {
    export class page_sign_jpUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/page_sign_jp");

        }

    }
}

module ui.lobby.paipu {
    export class paipu_filterUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/paipu/paipu_filter");

        }

    }
}

module ui.lobby {
    export class paipuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/paipu");

        }

    }
}

module ui.lobby.payment {
    export class buy_yueka_chsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/payment/buy_yueka_chs");

        }

    }
}

module ui.lobby.payment {
    export class buy_yueka_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/payment/buy_yueka_en");

        }

    }
}

module ui.lobby.payment {
    export class choose_method_chsUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/payment/choose_method_chs");

        }

    }
}

module ui.lobby.payment {
    export class choose_method_chs_tUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/payment/choose_method_chs_t");

        }

    }
}

module ui.lobby.payment {
    export class choose_method_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/payment/choose_method_en");

        }

    }
}

module ui.lobby.payment {
    export class creditcardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/payment/creditcard");

        }

    }
}

module ui.lobby.payment {
    export class gmoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/payment/gmo");

        }

    }
}

module ui.lobby.payment {
    export class gmo_bankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/payment/gmo_bank");

        }

    }
}

module ui.lobby.payment {
    export class loadingUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/payment/loading");

        }

    }
}

module ui.lobby.payment {
    export class wxcodeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/payment/wxcode");

        }

    }
}

module ui.lobby {
    export class pifuquan_lessUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pifuquan_less");

        }

    }
}

module ui.lobby {
    export class pipeiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pipei");

        }

    }
}

module ui.lobby {
    export class pipeichenggongUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/pipeichenggong");

        }

    }
}

module ui.lobby {
    export class pipeiyuyueUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/pipeiyuyue");

        }

    }
}

module ui.lobby {
    export class playerinfoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/playerinfo");

        }

    }
}

module ui.lobby {
    export class playerinfo_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/playerinfo_en");

        }

    }
}

module ui.lobby {
    export class pop_buy_cgUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pop_buy_cg");

        }

    }
}

module ui.lobby {
    export class pop_buy_multiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pop_buy_multi");

        }

    }
}

module ui.lobby {
    export class pop_buy_singleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pop_buy_single");

        }

    }
}

module ui.lobby {
    export class pop_rpg_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/pop_rpg_info");

        }

    }
}

module ui.lobby {
    export class rankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/rank");

        }

    }
}

module ui.lobby {
    export class rechargeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/recharge");

        }

    }
}

module ui.lobby {
    export class refundUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/refund");

        }

    }
}

module ui.lobby {
    export class role_setUI extends View {
		public in:Laya.FrameAnimation;
		public out:Laya.FrameAnimation;
		public page_title_in:Laya.FrameAnimation;
		public page_title_out:Laya.FrameAnimation;
		public east_north_in1:Laya.FrameAnimation;
		public east_north_in2:Laya.FrameAnimation;
		public east_north_in4:Laya.FrameAnimation;
		public east_north_out:Laya.FrameAnimation;
		public rank_in:Laya.FrameAnimation;
		public rank_out:Laya.FrameAnimation;
		public friend_in:Laya.FrameAnimation;
		public friend_out:Laya.FrameAnimation;
		public match_in1:Laya.FrameAnimation;
		public match_in2:Laya.FrameAnimation;
		public match_in3:Laya.FrameAnimation;
		public match_in4:Laya.FrameAnimation;
		public match_out:Laya.FrameAnimation;
		public xunniup:Laya.FrameAnimation;
		public ani8:Laya.FrameAnimation;
		public match_in5:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.CScrollBar_Heng",capsui.CScrollBar_Heng);

            super.createChildren();
            this.loadUI("lobby/role_set");

        }

    }
}

module ui.lobby {
    export class rpgUI extends View {
		public start:Laya.FrameAnimation;
		public boss:Laya.FrameAnimation;
		public win:Laya.FrameAnimation;
		public yidong:Laya.FrameAnimation;
		public shanbi:Laya.FrameAnimation;
		public shouji_guai:Laya.FrameAnimation;
		public jipo_yiji:Laya.FrameAnimation;
		public fuhuo:Laya.FrameAnimation;
		public gongji01_guai:Laya.FrameAnimation;
		public gongji02_guai:Laya.FrameAnimation;
		public gongji03_guai:Laya.FrameAnimation;
		public start_0:Laya.FrameAnimation;
		public idle_yiji:Laya.FrameAnimation;
		public idle_guai:Laya.FrameAnimation;
		public zaoyu_boss:Laya.FrameAnimation;
		public jifei:Laya.FrameAnimation;
		public shouji_yiji01:Laya.FrameAnimation;
		public gongji_yiji01:Laya.FrameAnimation;
		public jifei2:Laya.FrameAnimation;
		public yiji_win:Laya.FrameAnimation;
		public winter:Laya.FrameAnimation;
		public summer:Laya.FrameAnimation;
		public spring:Laya.FrameAnimation;
		public autumn:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("lobby/rpg");

        }

    }
}

module ui.lobby {
    export class rpg_changeUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/rpg_change");

        }

    }
}

module ui.lobby.shilian {
    export class shilianUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/shilian/shilian");

        }

    }
}

module ui.lobby.shilian {
    export class shilian_level_infoUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/shilian/shilian_level_info");

        }

    }
}

module ui.lobby.shilian {
    export class shilian_rankUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CDropdown",capsui.CDropdown);

            super.createChildren();
            this.loadUI("lobby/shilian/shilian_rank");

        }

    }
}

module ui.lobby.shilian {
    export class shilian_resultUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("lobby/shilian/shilian_result");

        }

    }
}

module ui.lobby.shilian {
    export class shilian_rewardUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/shilian/shilian_reward");

        }

    }
}

module ui.lobby.shop {
    export class shop_skin_chooseUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar_Heng",capsui.CScrollBar_Heng);

            super.createChildren();
            this.loadUI("lobby/shop/shop_skin_choose");

        }

    }
}

module ui.lobby {
    export class shopUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar_Heng",capsui.CScrollBar_Heng);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);

            super.createChildren();
            this.loadUI("lobby/shop");

        }

    }
}

module ui.lobby {
    export class shop_cg_yulanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/shop_cg_yulan");

        }

    }
}

module ui.lobby {
    export class shop_lobby_yulanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/shop_lobby_yulan");

        }

    }
}

module ui.lobby {
    export class shop_pack_detailUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("lobby/shop_pack_detail");

        }

    }
}

module ui.lobby {
    export class shop_skin_yulanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/shop_skin_yulan");

        }

    }
}

module ui.lobby {
    export class shop_special_packageUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/shop_special_package");

        }

    }
}

module ui.lobby {
    export class signUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/sign");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_DevDebugUI extends View {
		public btn_skip:Laya.Button;
		public btn_show:Laya.Button;
		public root:Laya.Sprite;
		public btn_close:Laya.Button;
		public ability1:Laya.TextInput;
		public ability2:Laya.TextInput;
		public ability3:Laya.TextInput;
		public ability4:Laya.TextInput;
		public ability5:Laya.TextInput;
		public set_ability:Laya.Button;
		public effect:Laya.TextInput;
		public set_effects:Laya.Button;
		public round:Laya.TextInput;
		public set_round:Laya.Button;
		public now_score:Laya.TextInput;
		public set_now_score:Laya.Button;
		public highest:Laya.TextInput;
		public set_highest:Laya.Button;
		public now_chara:Laya.TextInput;
		public set_chara:Laya.Button;
		public point:Laya.TextInput;
		public set_point:Laya.Button;
		public set_match_info:Laya.Button;
		public out:Laya.Button;
		public collusion:Laya.Sprite;
		public event_id:Laya.TextInput;
		public set_event:Laya.Button;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_DevDebug");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_endUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_end");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_eventUI extends View {
		public showEvent:Laya.FrameAnimation;
		public showResult3:Laya.FrameAnimation;
		public showResult2:Laya.FrameAnimation;
		public showResult1:Laya.FrameAnimation;
		public hideEvent:Laya.FrameAnimation;
		public choose:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_event");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_gameUI extends View {
		public speed:Laya.FrameAnimation;
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public shake0:Laya.FrameAnimation;
		public shake3:Laya.FrameAnimation;
		public shake2:Laya.FrameAnimation;
		public shake1:Laya.FrameAnimation;
		public show_record:Laya.FrameAnimation;
		public hide_record:Laya.FrameAnimation;
		public show_buff:Laya.FrameAnimation;
		public hide_buff:Laya.FrameAnimation;
		public pushting0:Laya.FrameAnimation;
		public pushting1:Laya.FrameAnimation;
		public pushting2:Laya.FrameAnimation;
		public pushting3:Laya.FrameAnimation;
		public matchstart:Laya.FrameAnimation;
		public shake0_show:Laya.FrameAnimation;
		public shake3_show:Laya.FrameAnimation;
		public shake2_show:Laya.FrameAnimation;
		public shake1_show:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_game");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_game_resultUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_game_result");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_game_startUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_game_start");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_recordUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_record");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_ruleUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_rule");

        }

    }
}

module ui.lobby.simulation {
    export class simulation_trainUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;
		public enter_match:Laya.FrameAnimation;
		public result3:Laya.FrameAnimation;
		public result1:Laya.FrameAnimation;
		public result2:Laya.FrameAnimation;
		public start_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.NoLimitList",capsui.NoLimitList);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/simulation/simulation_train");

        }

    }
}

module ui.lobby {
    export class skin_yulanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/skin_yulan");

        }

    }
}

module ui.lobby {
    export class snsUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/sns");

        }

    }
}

module ui.lobby.sushe {
    export class sushe_clothesUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/sushe/sushe_clothes");

        }

    }
}

module ui.lobby.sushe {
    export class sushe_dragsortUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("lobby/sushe/sushe_dragsort");

        }

    }
}

module ui.lobby.sushe {
    export class sushe_filterUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("lobby/sushe/sushe_filter");

        }

    }
}

module ui.lobby {
    export class susheUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/sushe");

        }

    }
}

module ui.lobby {
    export class sushe_selectUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);

            super.createChildren();
            this.loadUI("lobby/sushe_select");

        }

    }
}

module ui.lobby {
    export class sushe_select_enUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);

            super.createChildren();
            this.loadUI("lobby/sushe_select_en");

        }

    }
}

module ui.lobby {
    export class tanfang0UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/tanfang0");

        }

    }
}

module ui.lobby {
    export class tangfang1UI extends View {
		public WPin:Laya.FrameAnimation;
		public WPout:Laya.FrameAnimation;
		public JSin:Laya.FrameAnimation;
		public JSout:Laya.FrameAnimation;
		public XMJGin:Laya.FrameAnimation;
		public XMJGout:Laya.FrameAnimation;
		public XMin_new:Laya.FrameAnimation;
		public TreeIn:Laya.FrameAnimation;
		public TreeOut:Laya.FrameAnimation;
		public JSin2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/tangfang1");

        }

    }
}

module ui.lobby {
    export class titlebookUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/titlebook");

        }

    }
}

module ui.lobby {
    export class treasureUI extends View {
		public special_in_0:Laya.FrameAnimation;
		public special_in_1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSizeWrap",capsui.LabelLocalizationSizeWrap);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);

            super.createChildren();
            this.loadUI("lobby/treasure");

        }

    }
}

module ui.lobby {
    export class user_xieyi_rechargeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);

            super.createChildren();
            this.loadUI("lobby/user_xieyi_recharge");

        }

    }
}

module ui.lobby {
    export class visitUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);

            super.createChildren();
            this.loadUI("lobby/visit");

        }

    }
}

module ui.lobby {
    export class waitingroomUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationPosition",capsui.LabelLocalizationPosition);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);

            super.createChildren();
            this.loadUI("lobby/waitingroom");

        }

    }
}

module ui.lobby {
    export class waitobUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/waitob");

        }

    }
}

module ui.lobby {
    export class xinshouyindaoUI extends View {
		public ani1:Laya.FrameAnimation;
		public correct:Laya.FrameAnimation;
		public error:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CLoading",capsui.CLoading);

            super.createChildren();
            this.loadUI("lobby/xinshouyindao");

        }

    }
}

module ui.lobby {
    export class xinshouyindao_newUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("lobby/xinshouyindao_new");

        }

    }
}

module ui.mj.activity {
    export class activity_task_2604djUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("mj/activity/activity_task_2604dj");

        }

    }
}

module ui.mj {
    export class activity_taskUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("mj/activity_task");

        }

    }
}

module ui.mj {
    export class alUI extends View {
		public start:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/al");

        }

    }
}

module ui.mj {
    export class another_game_confirmUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/another_game_confirm");

        }

    }
}

module ui.mj {
    export class astrologyUI extends View {
		public dora:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;
		public ani3:Laya.FrameAnimation;
		public ani4:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/astrology");

        }

    }
}

module ui.mj {
    export class chipenghuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/chipenghu");

        }

    }
}

module ui.mj {
    export class cutin_beiyuanUI extends View {
		public cutin:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/cutin_beiyuan");

        }

    }
}

module ui.mj {
    export class cutin_dongchengUI extends View {
		public cutin:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/cutin_dongcheng");

        }

    }
}

module ui.mj {
    export class cutin_liyangUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/cutin_liyang");

        }

    }
}

module ui.mj {
    export class cutin_nanfengUI extends View {
		public cutin:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/cutin_nanfeng");

        }

    }
}

module ui.mj {
    export class cutin_xiyuansiUI extends View {
		public cutin:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/cutin_xiyuansi");

        }

    }
}

module ui.mj {
    export class desktopInfoUI extends View {
		public cd0:Laya.FrameAnimation;
		public cd1:Laya.FrameAnimation;
		public cd2:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("mj/desktopInfo");

        }

    }
}

module ui.mj {
    export class desktop_highlightUI extends View {
		public show:Laya.FrameAnimation;
		public ani2_0:Laya.FrameAnimation;
		public ani5_0:Laya.FrameAnimation;
		public ani2_1:Laya.FrameAnimation;
		public ani5_1:Laya.FrameAnimation;
		public ani5_2:Laya.FrameAnimation;
		public ani5_3:Laya.FrameAnimation;
		public ani5_4:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageLableSetting",capsui.LanguageLableSetting);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/desktop_highlight");

        }

    }
}

module ui.mj {
    export class desktop_yindaoUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("HTMLDivElement",laya.html.dom.HTMLDivElement);

            super.createChildren();
            this.loadUI("mj/desktop_yindao");

        }

    }
}

module ui.mj {
    export class desktop_yindao_modeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CLoading",capsui.CLoading);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/desktop_yindao_mode");

        }

    }
}

module ui.mj {
    export class dingqueUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/dingque");

        }

    }
}

module ui.mj {
    export class fieldspellUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/fieldspell");

        }

    }
}

module ui.mj {
    export class fightbeginUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/fightbegin");

        }

    }
}

module ui.mj {
    export class gameendUI extends View {
		public title_in:Laya.FrameAnimation;
		public title_out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/gameend");

        }

    }
}

module ui.mj {
    export class gamestopUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/gamestop");

        }

    }
}

module ui.mj {
    export class hangup_warnUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/hangup_warn");

        }

    }
}

module ui.mj {
    export class huansanzhangUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/huansanzhang");

        }

    }
}

module ui.mj {
    export class huansanzhang_changetypeUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/huansanzhang_changetype");

        }

    }
}

module ui.mj {
    export class huleshowUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/huleshow");

        }

    }
}

module ui.mj {
    export class hu_cutinUI extends View {
		public cutin:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/hu_cutin");

        }

    }
}

module ui.mj {
    export class hu_xuezhanUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/hu_xuezhan");

        }

    }
}

module ui.mj {
    export class info_md5UI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/info_md5");

        }

    }
}

module ui.mj {
    export class liujuUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/liuju");

        }

    }
}

module ui.mj {
    export class live_broadcastUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/live_broadcast");

        }

    }
}

module ui.mj {
    export class mj_emojiUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("mj/mj_emoji");

        }

    }
}

module ui.mj {
    export class ob_replayUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("mj/ob_replay");

        }

    }
}

module ui.mj {
    export class rankchangeUI extends View {
		public ani1:Laya.FrameAnimation;
		public ani2:Laya.FrameAnimation;
		public ani3:Laya.FrameAnimation;
		public ani0:Laya.FrameAnimation;
		public ani_jiangduan:Laya.FrameAnimation;
		public ani_sheng2xing:Laya.FrameAnimation;
		public ani_diao1xing:Laya.FrameAnimation;
		public ani_sheng3xing:Laya.FrameAnimation;
		public ani_diao2xing:Laya.FrameAnimation;
		public ani_jiangduan_0:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("Text",laya.display.Text);

            super.createChildren();
            this.loadUI("mj/rankchange");

        }

    }
}

module ui.mj {
    export class replayUI extends View {
		public show:Laya.FrameAnimation;
		public hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LanguageSpriteSetting",capsui.LanguageSpriteSetting);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.CButtonParent",capsui.CButtonParent);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("mj/replay");

        }

    }
}

module ui.mj {
    export class replay_whellUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/replay_whell");

        }

    }
}

module ui.mj {
    export class rewardprogressUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/rewardprogress");

        }

    }
}

module ui.mj {
    export class scorechangeUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/scorechange");

        }

    }
}

module ui.mj {
    export class task_progressUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButtonScale",capsui.CButtonScale);
			View.regComponent("capsui.UICopy",capsui.UICopy);

            super.createChildren();
            this.loadUI("mj/task_progress");

        }

    }
}

module ui.mj {
    export class tingpaiUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("mj/tingpai");

        }

    }
}

module ui.mj {
    export class voteUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/vote");

        }

    }
}

module ui.mj {
    export class vote_cdUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/vote_cd");

        }

    }
}

module ui.mj {
    export class vote_progressUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("mj/vote_progress");

        }

    }
}

module ui.mj {
    export class winUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);

            super.createChildren();
            this.loadUI("mj/win");

        }

    }
}

module ui.saki {
    export class sakiUI extends View {
		public ani1:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);
			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("saki/saki");

        }

    }
}

module ui.spot {
    export class spot_chooseUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);
			View.regComponent("capsui.CButton",capsui.CButton);

            super.createChildren();
            this.loadUI("spot/spot_choose");

        }

    }
}

module ui.spot {
    export class spot_endUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("spot/spot_end");

        }

    }
}

module ui.spot {
    export class spot_end_transUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("spot/spot_end_trans");

        }

    }
}

module ui.spot {
    export class spot_illustUI extends View {
		public bubble_illust_amazing:Laya.FrameAnimation;
		public bubble_illust_angry:Laya.FrameAnimation;
		public bubble_illust_attention:Laya.FrameAnimation;
		public bubble_illust_ellipsis:Laya.FrameAnimation;
		public bubble_illust_talking:Laya.FrameAnimation;
		public horizontal_shake:Laya.FrameAnimation;
		public jump_in_left:Laya.FrameAnimation;
		public jump_in_right:Laya.FrameAnimation;
		public jump_out_left:Laya.FrameAnimation;
		public jump_out_right:Laya.FrameAnimation;
		public shock:Laya.FrameAnimation;
		public squat:Laya.FrameAnimation;
		public vertical_shake_short:Laya.FrameAnimation;
		public vertical_shake_tall:Laya.FrameAnimation;
		public bubble_amazing:Laya.FrameAnimation;
		public bubble_angry:Laya.FrameAnimation;
		public bubble_attention:Laya.FrameAnimation;
		public bubble_confuse:Laya.FrameAnimation;
		public bubble_ellipsis:Laya.FrameAnimation;
		public bubble_heart:Laya.FrameAnimation;
		public bubble_heartbroken:Laya.FrameAnimation;
		public bubble_question:Laya.FrameAnimation;
		public bubble_shame:Laya.FrameAnimation;
		public bubble_shock:Laya.FrameAnimation;
		public bubble_sweat:Laya.FrameAnimation;
		public bubble_talking:Laya.FrameAnimation;
		public bubble_thinking:Laya.FrameAnimation;
		public bubble_anxious:Laya.FrameAnimation;
		public bubble_star:Laya.FrameAnimation;
		public bubble_sigh:Laya.FrameAnimation;
		public bubble_gossip:Laya.FrameAnimation;
		public bubble_stressLine:Laya.FrameAnimation;
		public bubble_humming:Laya.FrameAnimation;
		public long_shake:Laya.FrameAnimation;
		public gravity:Laya.FrameAnimation;
		public teleport_in:Laya.FrameAnimation;
		public teleport_out:Laya.FrameAnimation;
		public bubble_sleep:Laya.FrameAnimation;
		public bubble_unhappy:Laya.FrameAnimation;
		public bubble_lightbulb:Laya.FrameAnimation;
		public bubble_downtime:Laya.FrameAnimation;
		public death_out:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("spot/spot_illust");

        }

    }
}

module ui.spot {
    export class spot_logUI extends View {

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView",capsui.CScrollView);

            super.createChildren();
            this.loadUI("spot/spot_log");

        }

    }
}

module ui.spot {
    export class spot_mainUI extends View {
		public find:Laya.FrameAnimation;
		public findClose:Laya.FrameAnimation;
		public banner_show:Laya.FrameAnimation;
		public banner_hide:Laya.FrameAnimation;
		public tips_show:Laya.FrameAnimation;
		public tips_hide:Laya.FrameAnimation;

        constructor(){ super()}
        createChildren():void {
        			View.regComponent("capsui.LabelLocalizationSize",capsui.LabelLocalizationSize);
			View.regComponent("capsui.LabelLocalizationBestFit",capsui.LabelLocalizationBestFit);
			View.regComponent("capsui.CButton",capsui.CButton);
			View.regComponent("capsui.UICopy",capsui.UICopy);
			View.regComponent("capsui.CScrollView_Heng",capsui.CScrollView_Heng);
			View.regComponent("capsui.CScrollBar",capsui.CScrollBar);
			View.regComponent("capsui.LabelLocalizationLine",capsui.LabelLocalizationLine);

            super.createChildren();
            this.loadUI("spot/spot_main");

        }

    }
}

module ui.spot {
    export class spot_transUI extends View {

        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.loadUI("spot/spot_trans");

        }

    }
}
