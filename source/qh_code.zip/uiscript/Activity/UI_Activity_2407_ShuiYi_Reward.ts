/**
* name 
*/
module uiscript {



    export class UI_Activity_2407_ShuiYi_Reward extends UI_Activity_Task_Period {

        public static activity_id: number = 240702;
        public static readonly items: Array<number> = [30900042, 30900043];
        private label_count_1: Laya.Label;
        private label_count_2: Laya.Label;
        private onItemChange: Laya.Handler;
        public isLock: boolean;
        private getAllBtn: Laya.Button;
        private getAllBtnTitle: Laya.Label;
        private getAllBtnBg: Laya.Image;

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_2407_ShuiYi_Reward.activity_id)['name_' + GameMgr.client_language], "activity_banner_2407_rewardUI");
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_2407_ShuiYi_Reward.activity_id];
        }

        public onCreate() {
            super.onCreate();

            this.label_count_1 = this.head.getChildByName('count0') as Laya.Label;
            this.label_count_2 = this.head.getChildByName('count1') as Laya.Label;
            this.onItemChange = new Laya.Handler(this, () => {
                this.freshPage();
            })
            this.getAllBtn = this.root.getChildByName('btn_get_all') as Laya.Button;
            this.getAllBtn.clickHandler = new Laya.Handler(this, () => {
                this.onClickGetAll();
            });
            this.getAllBtnTitle = this.getAllBtn.getChildByName('title') as Laya.Label;
            this.getAllBtnBg = this.getAllBtn.getChildByName('bg') as Laya.Image;

        }

        public refreshCurrencyCount() {
            let item1count: number = UI_Bag.get_item_count(30900042);
            let item2count: number = UI_Bag.get_item_count(30900043);
            this.label_count_1.text = game.Tools.strOfLocalization(2212, [item1count.toString()]);
            this.label_count_2.text = game.Tools.strOfLocalization(2212, [item2count.toString()]);

        }

        public show() {
            this.enable = true;
            this.setHead(`myres2/treasurehead/2407_exchange.jpg`, 974, 185);
            this.freshPage();
        }

        public hide() {
            this.enable = false;
        }

        public onEnable(): void {
            //道具改变的时候添加监听
            for (let index = 0; index < UI_Activity_2407_ShuiYi_Reward.items.length; index++) {
                let itemId = UI_Activity_2407_ShuiYi_Reward.items[index];
                UI_Bag.add_item_listener(itemId, this.onItemChange);
            }
            Laya.stage.on(EventCode.ACTIVITY_PERIOD_TASK_GET_REWARD, this, this.onGetReward);
            Laya.stage.on(EventCode.ACTIVITY_PERIOD_TASK_GET_REWARD_FINISH, this, this.onGetRewardFinish);
            //如果活动结束了，执行activity页面的show
            // Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityEnd);改为走Page_HuoDong的统一关闭
        }

        public onDisable(): void {
            //移除监听
            for (let index = 0; index < UI_Activity_2407_ShuiYi_Reward.items.length; index++) {
                let itemId = UI_Activity_2407_ShuiYi_Reward.items[index];
                UI_Bag.remove_item_listener(itemId, this.onItemChange);
            }
            Laya.stage.off(EventCode.ACTIVITY_PERIOD_TASK_GET_REWARD, this, this.onGetReward);
            Laya.stage.off(EventCode.ACTIVITY_PERIOD_TASK_GET_REWARD_FINISH, this, this.onGetRewardFinish);
            // Laya.stage.off(EventCode.REMOVE_ACTIVITY, this, this.onActivityEnd);
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_2407_ShuiYi_Reward.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        private freshPage() {
            // console.log(JSON.stringify(UI_Activity.getPeriodTaskList(UI_Activity_2407_ShuiYi_Reward.activity_id)));
            let rewardList = UI_Activity.getPeriodTaskList(UI_Activity_2407_ShuiYi_Reward.activity_id);
            rewardList = rewardList.sort(this.sortTasks);
            this.refreshView(rewardList);
            this.refreshCurrencyCount();
            this.freshGetAllBtn();
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.getAllBtnBg.skin = shouldSetGray ? game.Tools.localUISrc("myres/pop_panel/btn_g.png") : game.Tools.localUISrc("myres/pop_panel/btn_y.png");
            this.getAllBtnTitle.color = shouldSetGray ? "#525A6B" : "#6d2e3a";
            this.getAllBtn.mouseEnabled = !shouldSetGray;
        }

        public onClickGetAll() {
            if (this.isLock) {
                return;
            }
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = UI_Activity.getPeriodTaskList(UI_Activity_2407_ShuiYi_Reward.activity_id);
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }

            if (needGetList.length == 0) return;

            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.freshPage();
                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                }
            })
        }

        
        private onGetReward() {
            this.isLock = true;
        }

        private onGetRewardFinish() {
            this.isLock = false;
            // this.freshPage();
            this.refreshCurrencyCount();
            this.freshGetAllBtn();
        }



        private sortTasks(a: BA_PreviodTaskServerData, b: BA_PreviodTaskServerData) {
            // 为每种情况分配权重
            const weightA = (a.achieved ? (a.rewarded ? 3 : 0) : 2);
            const weightB = (b.achieved ? (b.rewarded ? 3 : 0) : 2);

            // 首先比较权重
            if (weightA !== weightB) {
                return weightA - weightB;
            }

            // 如果权重相同，则按照 ID 升序排序
            return a.id - b.id;
        }

        private onActivityEnd(id: number) {
            if (id == UI_Activity_2407_ShuiYi_Reward.activity_id) {
                this.hide();
            }
        }
    }
}