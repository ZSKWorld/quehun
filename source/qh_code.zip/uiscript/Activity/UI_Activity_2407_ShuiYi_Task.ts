module uiscript {
    export class UI_Activity_2407_ShuiYi_Task extends UI_Activity_Task_New {

        public static activity_id: number = 240701;

        constructor() {
            let name: string = cfg.activity.activity.get(UI_Activity_2407_ShuiYi_Task.activity_id)['name_' + GameMgr.client_language];
            let uiName: string = "activity_banner_2407_taskUI";
            super(name, uiName);
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres2/treasurehead/2407_task.jpg`, 974, 326);
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_2407_ShuiYi_Task.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getTaskList(UI_Activity_2407_ShuiYi_Task.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_2407_ShuiYi_Task.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;
            this.refreshView(UI_Activity.getTaskList(UI_Activity_2407_ShuiYi_Task.activity_id));
        }

        public hide() {
            this.enable = false;
        }

      

        public onEnable(): void {
            super.onEnable();
            // Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityEnd);改为走Page_HuoDong的统一关闭
        }

        public onDisable(): void {
            super.onDisable();
            // Laya.stage.off(EventCode.REMOVE_ACTIVITY, this, this.onActivityEnd);
        }

        private onActivityEnd(id: number) {
            if (id == UI_Activity_2407_ShuiYi_Task.activity_id) {
                this.hide();
            }
        }
    }
}