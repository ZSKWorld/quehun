module uiscript {
    enum EChatPivot {
        left_top,
        left_bottom,
        right_top,
        right_bottom
    }
    enum EWeatherType {
        none,
        bai,
        ye,
        yu
    }

    enum ECelestialBody {
        ty,
        yl
    }
    interface IChatConfig {
        pos: Laya.Point;
        pivot: EChatPivot;
        charaId: number;
        aniName: string;
        audio: number;
    }

    let dayTime = 35000;   //日夜切换

    export class UI_Activity_2508_Navigation extends UIBase {
        public static Inst: UI_Activity_2508_Navigation = null;
        public static activityId: number = 250820;
        public static currencyId: number = 30900092;
        public static needShow: boolean = false;
        public static haveRedPoint() {
            if (UI_Activity_2508_Navigation_Task.haveRedPoint(250820)) return true;
            if (UI_Activity_2508_Navigation_Task.haveRedPoint(250821)) return true;
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2508navigation.activity_2508navigationUI);
            UI_Activity_2508_Navigation.Inst = this;
        }

        private imgBg: Laya.Image;
        private comLeftTop: Laya.Sprite;
        private comBottom: Laya.Sprite;
        private comChat: UI_Character_Chat;
        private comMiddle: Laya.Sprite;

        private imgLogo: Laya.Image;
        private btnHelp: Laya.Button;
        private btnTask: Laya.Button;
        private btnReward: Laya.Button;
        private btnReturn: Laya.Button;
        private btnAmulet: Laya.Button;
        private btnCurrency: Laya.Button;
        private btnCharas: Laya.Button[];

        public locking: boolean;
        public aniLock: boolean;
        private selectedCharaIndex: number;

        private refreshCurrencyHandler: Laya.Handler;
        private activityFinishHandler: Laya.Handler;
        private chatConfig: IChatConfig[] = [
            { pos: new Laya.Point(339, 223), pivot: EChatPivot.right_top, charaId: 200001, aniName: 'hd033_bg_role1_', audio: 0 },
            { pos: new Laya.Point(2, 700), pivot: EChatPivot.right_top, charaId: 200012, aniName: 'hd033_bg_role5_', audio: 0 },
            { pos: new Laya.Point(196, 356), pivot: EChatPivot.right_bottom, charaId: 200006, aniName: 'hd033_bg_role4_', audio: 10353 },
            { pos: new Laya.Point(1306, 519), pivot: EChatPivot.left_bottom, charaId: 200007, aniName: 'hd033_bg_role3_', audio: 0 },
            { pos: new Laya.Point(757, 281), pivot: EChatPivot.right_bottom, charaId: 20000112, aniName: 'hd033_bg_role2_', audio: 0 },
        ];
        private sceneBg: Laya.Scene;
        private effectBgBai: Laya.MeshSprite3D;
        private effectBgYe: Laya.MeshSprite3D;
        private effectBgYu: Laya.MeshSprite3D;
        private aniShip: Catfood.CAnimator;
        private aniWeather: Catfood.CAnimator;
        private aniChara: Catfood.CAnimator[];
        private aniCelestialBody: Catfood.CAnimator;
        private aniMoon: Catfood.CAnimator;
        private aniSun: Catfood.CAnimator;
        private aniShipShake: Catfood.CAnimator;
        private isRaining: boolean = false;
        private nowCelestialBody: ECelestialBody;
        private nowWeather: EWeatherType;
        private timerWeather: Laya.Timer;
        private timerChara: Laya.Timer;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniChats: Laya.FrameAnimation[][];
        private weatherAudio: number = 0;
        private waveAudio: number = 0;

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.comLeftTop = this.me.getChildByName('left_top') as Laya.Sprite;
            this.comBottom = this.me.getChildByName('bottom') as Laya.Sprite;
            this.comChat = new UI_Character_Chat(this.me.getChildByName('chat').getChildByName('chat') as Laya.Sprite);
            this.btnHelp = this.comLeftTop.getChildByName('btn_help') as Laya.Button;
            this.imgLogo = this.comLeftTop.getChildByName('logo') as Laya.Image;
            this.btnHelp.x = this.imgLogo.x + this.imgLogo.width + 33;

            this.btnTask = this.comBottom.getChildByName('btn_task') as Laya.Button;
            this.btnReward = this.comBottom.getChildByName('btn_reward') as Laya.Button;
            this.btnAmulet = this.comBottom.getChildByName('btn_amulet') as Laya.Button;
            this.comMiddle = this.me.getChildByName('middle') as Laya.Sprite;
            this.btnCharas = [];
            for (let i = 0; i < 5; i++) {
                let btn = this.comMiddle.getChildByName(i.toString()) as Laya.Button;
                this.btnCharas.push(btn);
                btn.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    if (this.aniLock) return;
                    this.clickChara(i);
                    this.refreshCharaTalk(i);
                });
            }

            this.btnReturn = this.comLeftTop.getChildByName('btn_return') as Laya.Button;
            let pageTask = new UI_Activity_2508_Navigation_Task(this.me.getChildByName('page_task') as Laya.Sprite);
            this.btnCurrency = this.me.getChildByName('currency') as Laya.Button;

            this.btnReward.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_2508_Navigation_Task.Inst.show(250821);
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_2508_Navigation_Task.Inst.show(250820);
            });
            this.btnAmulet.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (UI_PiPeiYuYue.Inst.enable) {
                    UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                    return;
                }
                if (!UI_Activity.activity_is_running(UI_Activity_Amulet.activityId)) return;
                this.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchAmuletActivityData, { activity_id: UI_Activity_Amulet.activityId }, (err, res: game.IResAmuletActivityFetchInfo) => {
                    this.locking = false;
                    if (err || res['error']) {
                        if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26121 || res['error']['code'] == 26123)) {
                            uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093));
                        } else {
                            uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchAmuletActivityData, err, res);
                        }
                    } else {
                        let data = res.data || {} as game.IActivityAmuletData;
                        app.Log.log('amuletActivityFetchInfo === res=====' + JSON.stringify(data));
                        UI_Activity_2508_Navigation.needShow = true;
                        UI_Activity_Amulet.initData(data);
                        this.hide(Laya.Handler.create(this, () => {
                            UI_Activity_Amulet.enterToPokerGame(data.game);
                        }));
                    }
                });
            });

            this.btnReturn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            });
            this.btnHelp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25083001));
            }, null, false);
            this.btnCurrency.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_ItemDetail.Inst.show(UI_Activity_2508_Navigation.currencyId);
            });

            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            this.refreshCurrencyHandler = new Laya.Handler(this, this.refreshCurrency);
            this.timerWeather = new Laya.Timer();
            this.timerChara = new Laya.Timer();
            let root = this.me as ui.lobby.activity_2508navigation.activity_2508navigationUI;
            this.aniShow = root.show;
            this.aniHide = root.hide;
            this.aniChats = [];
            for (let i = EChatPivot.left_bottom; i <= EChatPivot.right_bottom; i++) {
                let anims = [];
                anims.push(root['chat_show' + i]);
                anims.push(root['chat_hide' + i]);
                this.aniChats.push(anims);
            }
        }

        private clickChara(i: number) {
            let chatConfig = this.chatConfig[i];
            if (chatConfig.audio) {
                this.aniShipShake.Play(null);
                view.AudioMgr.PlayAudio(chatConfig.audio);
            }
            this.aniChara[i].Play(chatConfig.aniName + 'click');
            let delay = 0;
            for (let clip of this.aniChara[i].clips) {
                if (clip.name == chatConfig.aniName + 'click') {
                    delay = clip.lifeTime * 1000;
                }
            }
            Laya.timer.clearAll(this.btnCharas[i]);
            Laya.timer.once(delay, this.btnCharas[i], () => {
                this.aniChara[i].Play(chatConfig.aniName + 'default');
            })
        }

        private refreshCharaTalk(i: number = -1) {
            // app.Log.log('refreshCharaTalk')
            if (this.selectedCharaIndex >= 0) {
                // app.Log.log('打断上一次语音')
                this.hideChat(false);
                return;
            }
            if (i < 0) {
                // app.Log.log('是随机语音')
                i = Math.floor(Math.random() * this.chatConfig.length);
            }
            this.selectedCharaIndex = i;
            let chatConfig = this.chatConfig[i];
            (this.comChat.me.parent as Laya.Sprite).pos(chatConfig.pos.x, chatConfig.pos.y);
            let beginStrId = 25085010 + i * 10;
            let randomCount = 5;
            let talkTxt = game.Tools.eventStrOfLocalization(beginStrId + (Math.ceil(Math.random() * randomCount) - 1));
            this.timerChara.clearAll(this);
            this.comChat.show(talkTxt, 1, Laya.Handler.create(this, () => {
                // app.Log.log('说完了')
                this.timerChara.once(10000, this, this.hideChat);
            }, null, false));
            let charaConfig = cfg.item_definition.character.get(chatConfig.charaId);
            let txtName = this.comChat.me.getChildByName('name') as Laya.Label;
            let imgBg = this.comChat.me.getChildByName('bg') as Laya.Image;
            imgBg.skin = game.Tools.localUISrc('myres/activity_2508navigation/home_page_dialog_box_' + chatConfig.pivot + '.png');
            txtName.text = charaConfig['name_' + GameMgr.client_language];
            Laya.Tween.clearAll(this.comChat.me);
            this.aniChats.forEach((anims) => {
                anims.forEach(anim => anim.stop());
            });
            this.aniChats[chatConfig.pivot - 1][0].play(0, false);
        }

        private hideChat(force: boolean = false) {
            this.timerChara.clearAll(this);
            this.comChat.close(force);
            if (!force) {
                let chatConfig = this.chatConfig[this.selectedCharaIndex];
                Laya.Tween.clearAll(this.comChat.me);
                this.aniChats[chatConfig.pivot - 1][0].stop();
                this.aniChats[chatConfig.pivot - 1][1].play(0, false);
            }
            this.selectedCharaIndex = -1;
            if (!force) {
                // app.Log.log('10s后接下一条语音')
                this.timerChara.once(10000, this, this.refreshCharaTalk);
            }
        }

        private refreshCurrency() {
            (this.btnCurrency.getChildByName('count') as Laya.Label).text = UI_Bag.get_item_count(UI_Activity_2508_Navigation.currencyId).toString();
        }

        refreshRedPoint() {
            (this.btnTask.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_2508_Navigation_Task.haveRedPoint(250820);
            (this.btnReward.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_2508_Navigation_Task.haveRedPoint(250821);
        }

        public show() {
            UI_Activity_2508_Navigation.needShow = false;
            this.enable = true;
            this.refreshCurrency();
            this.refreshRedPoint();
            this.hideChat(true);
            this.aniShip.Play('hd033_bg_chuan_show');
            Laya.timer.once(5500, this, () => {
                this.aniShip.Play('hd033_bg_chuan_idle');
            });
            for (let i = 0; i < this.aniChara.length; i++) {
                let chatConfig = this.chatConfig[i];
                this.aniChara[i].Play(chatConfig.aniName + 'default');
            }
            this.nowWeather = EWeatherType.none;
            let nextCelestialBody = Math.random() > 0.5 ? ECelestialBody.ty : ECelestialBody.yl;
            let nextRaining = Math.random() < 0.2;
            this.refreshWeatherShow(nextCelestialBody, nextRaining, false);
            this.refreshWeather();
            if (nextRaining) {
                this.timerWeather.once(10000, this, () => {
                    this.refreshWeatherShow(this.nowCelestialBody, false, true);
                });
            }
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            });
            this.aniLock = true;
            Laya.timer.once(2000, this, () => {
                this.aniLock = false;
                this.refreshCharaTalk();
            });
            if (!Laya.LocalStorage.getItem(game.Tools.eeesss('navigation_rules' + UI_Activity_2508_Navigation.activityId + GameMgr.Inst.account_id))) {
                Laya.LocalStorage.setItem(game.Tools.eeesss('navigation_rules' + UI_Activity_2508_Navigation.activityId + GameMgr.Inst.account_id), '1');
                UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25083001));
            }
        }

        private refreshWeather() {
            this.timerWeather.clearAllEx();
            this.timerWeather.loop(dayTime, this, () => {
                let nextCelestialBody = this.nowCelestialBody == ECelestialBody.ty ? ECelestialBody.yl : ECelestialBody.ty;
                // app.Log.log('改换天气了 ===== ' + ECelestialBody[nextCelestialBody]);
                if (!this.isRaining) {
                    // app.Log.log('不下雨换天气');
                    this.refreshWeatherShow(nextCelestialBody, false, true);
                } else {
                    // app.Log.log('正在下雨，下不换');
                    this.nowCelestialBody = nextCelestialBody;
                }
                this.refreshRain();
            });
        }

        private refreshRain() {
            if (this.isRaining) {
                return;
            }
            let nextRaining = Math.random() < 0.2;
            if (!nextRaining) return;
            let rainDelay = 15000;
            let rainDuration = Math.random() < 0.5 ? 40000 : 10000;
            this.timerWeather.once(rainDelay, this, () => {
                this.refreshWeatherShow(this.nowCelestialBody, true, true);
            });
            this.timerWeather.once(rainDelay + rainDuration, this, () => {
                this.refreshWeatherShow(this.nowCelestialBody, false, true);
            });
        }

        private refreshWeatherShow(nextCelestialBody: ECelestialBody, nextRain: boolean, doAnim: boolean) {
            this.timerWeather.clearAll(this.nowWeather);
            let oldWeather = this.nowWeather;
            this.nowCelestialBody = nextCelestialBody;
            this.isRaining = nextRain;
            let newWeather: EWeatherType = nextRain ? EWeatherType.yu : (nextCelestialBody == ECelestialBody.ty ? EWeatherType.bai : EWeatherType.ye);
            this.nowWeather = newWeather;
            this.refreshAudio();
            let delayW = 0;
            let delayC = 0;
            let delayR = 0;
            let newW = EWeatherType[newWeather];
            if (doAnim && oldWeather) {
                let oldW = EWeatherType[oldWeather];
                let aniName = 'hd033_bg_tianqi_' + oldW + '_' + newW;
                // app.Log.log('WeatherName ===== ' + aniName);
                this.effectBgBai.meshRender.sharedMaterial.renderQueue = newWeather == EWeatherType.bai ? 3001 : 3000;
                this.effectBgYe.meshRender.sharedMaterial.renderQueue = newWeather == EWeatherType.ye ? 3001 : 3000;
                this.effectBgYu.meshRender.sharedMaterial.renderQueue = newWeather == EWeatherType.yu ? 3021 : 3000;
                this.aniWeather.Play(aniName);
                for (let clip of this.aniWeather.clips) {
                    if (clip.name == aniName) {
                        delayW = clip.lifeTime * 1000;
                        break;
                    }
                }
                if (newWeather != EWeatherType.yu && oldWeather != EWeatherType.yu) {
                    let aniCelestialBodyName = 'hd033_bg_' + ECelestialBody[nextCelestialBody] + '_up';
                    for (let clip of this.aniCelestialBody.clips) {
                        if (clip.name == aniCelestialBodyName) {
                            delayC = clip.lifeTime * 1000;
                            break;
                        }
                    }
                    // app.Log.log('aniCelestialBodyName ===== ' + aniCelestialBodyName);
                    this.aniCelestialBody.Play(aniCelestialBodyName);
                } else if (oldWeather != newWeather) {
                    let aniRainName = newWeather == EWeatherType.yu ? 'hd033_bg_taiyang_hide' : 'hd033_bg_taiyang_show';
                    let aniRain: Catfood.CAnimator = (oldWeather == EWeatherType.bai || newWeather == EWeatherType.bai) ? this.aniSun : this.aniMoon;
                    aniRain.Play(aniRainName);
                    for (let clip of aniRain.clips) {
                        if (clip.name == aniRainName) {
                            delayR = clip.lifeTime * 1000;
                            break;
                        }
                    }
                }
            }
            this.timerWeather.once(delayW, this.nowWeather, () => {
                // app.Log.log('WeatherName ===== ' + 'hd033_bg_tianqi_' + newW);
                this.aniWeather.Play('hd033_bg_tianqi_' + newW);
            })
            this.timerWeather.once(delayC, this.nowWeather, () => {
                // app.Log.log('aniCelestialBodyName ===== ' + 'hd033_bg_' + ECelestialBody[nextCelestialBody] + '_default');
                this.aniCelestialBody.Play('hd033_bg_' + ECelestialBody[nextCelestialBody] + '_default');
            })
            this.timerWeather.once(delayR, this.nowWeather, () => {
                let aniRainName = newWeather == EWeatherType.yu ? 'hd033_bg_taiyang_hide_default' : 'hd033_bg_taiyang_default';
                let aniRain: Catfood.CAnimator = nextCelestialBody == ECelestialBody.ty ? this.aniSun : this.aniMoon;
                // app.Log.log('aniRainName ===== ' + aniRainName);
                aniRain.Play(aniRainName);
            })
        }

        private refreshAudio() {
            if (!this.waveAudio) this.waveAudio = view.AudioMgr.PlayAudio(10351, -1, 1, 500);
            let audioId = this.nowWeather == EWeatherType.bai ? 10350 : (this.nowWeather == EWeatherType.yu ? 10352 : 0);
            if (audioId == this.weatherAudio) return;
            if (this.weatherAudio) {
                view.AudioMgr.StopAudio(this.weatherAudio, 200);
                this.weatherAudio = 0;
            }
            if (audioId) {
                this.weatherAudio = view.AudioMgr.PlayAudio(audioId, -1, 1, 200);
            }
        }

        private stopAudio(tween: number = 0) {
            if (this.weatherAudio) {
                view.AudioMgr.StopAudio(this.weatherAudio, tween);
                this.weatherAudio = 0;
            }
            if (this.waveAudio) {
                view.AudioMgr.StopAudio(this.waveAudio, tween);
                this.waveAudio = 0;
            }
        }

        public hide(onClose?: Laya.Handler) {
            if (!onClose) {
                onClose = Laya.Handler.create(this, () => {
                    UI_Lobby.Inst.enable = true;
                })
            }
            this.locking = true;
            this.aniHide.play(0, false);
            this.stopAudio(200);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
                onClose && onClose.run();
            });
        }


        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_2508_Navigation', false);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            UI_Bag.remove_item_listener(UI_Activity_2508_Navigation.currencyId, this.refreshCurrencyHandler);
            this.locking = false;
            Laya.timer.clearAll(this);
            for (let i = 0; i < this.btnCharas.length; i++) {
                Laya.timer.clearAll(this.btnCharas[i]);
            }
            this.timerWeather.clearAllEx();
            this.timerChara.clearAllEx();
            this.aniShip.Stop();
            this.aniWeather.Stop();
            this.aniShipShake.Stop();
            this.aniChats.forEach((anims) => {
                anims.forEach(anim => anim.stop());
            });
            this.stopAudio(0);
            if (!game.PlatformUtil.isPC()) {
                Laya.stage.off(/*laya.events.Event.BLUR*/"blur", this, this.stopAudio);
                Laya.stage.off(/*laya.events.Event.FOCUS*/"focus", this, this.refreshAudio);
                if (Laya.Browser.onIOS) {
                    Laya.stage.off(/*laya.events.Event.VISIBILITY_CHANGE*/"pageshow", this, this.refreshAudio);
                    Laya.stage.off(/*laya.events.Event.VISIBILITY_CHANGE*/"pagehide", this, this.stopAudio);
                } else {
                    Laya.stage.off(/*laya.events.Event.VISIBILITY_CHANGE*/"visibilitychange", this, this.onStageVisibilityChange);
                }
            }
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_2508_Navigation', true);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            UI_Bag.add_item_listener(UI_Activity_2508_Navigation.currencyId, this.refreshCurrencyHandler);
            if (!game.PlatformUtil.isPC()) {
                Laya.stage.on(/*laya.events.Event.BLUR*/"blur", this, this.stopAudio);
                Laya.stage.on(/*laya.events.Event.FOCUS*/"focus", this, this.refreshAudio);
                if (Laya.Browser.onIOS) {
                    Laya.stage.on(/*laya.events.Event.VISIBILITY_CHANGE*/"pageshow", this, this.refreshAudio);
                    Laya.stage.on(/*laya.events.Event.VISIBILITY_CHANGE*/"pagehide", this, this.stopAudio);
                } else {
                    Laya.stage.on(/*laya.events.Event.VISIBILITY_CHANGE*/"visibilitychange", this, this.onStageVisibilityChange);
                }
            }
        }

        private onStageVisibilityChange() {
            if (Laya.stage.isVisibility) {
                this.refreshAudio();
            } else {
                this.stopAudio();
            }
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_2508_Navigation.activityId) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.hide();
                        }))
                        return;
                    }
                }
            }
        }

        public initScene() {
            if (this.sceneBg) {
                return;
            }
            this.sceneBg = Laya.loader.getRes('scene/effect_navigation_bg.ls') as Laya.Scene;
            this.imgBg.addChild(this.sceneBg);
            let effectShip = this.sceneBg.getChildAt(1).getChildByName('chuan') as Laya.Sprite3D;
            this.aniShipShake = effectShip.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.aniShip = (effectShip.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            let effectWeather = (this.sceneBg.getChildAt(1).getChildAt(0).getChildAt(0).getChildByName('tianqi') as Laya.Sprite3D);
            this.aniWeather = effectWeather.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.aniCelestialBody = (this.sceneBg.getChildAt(1).getChildAt(0).getChildAt(0).getChildByName('tianqi').getChildAt(4) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.aniSun = (this.sceneBg.getChildAt(1).getChildAt(0).getChildAt(0).getChildByName('tianqi').getChildAt(4).getChildAt(0).getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.aniMoon = (this.sceneBg.getChildAt(1).getChildAt(0).getChildAt(0).getChildByName('tianqi').getChildAt(4).getChildAt(1).getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.aniChara = [];
            this.aniChara.push((effectShip.getChildAt(0).getChildAt(0).getChildByName('01').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
            this.aniChara.push((effectShip.getChildAt(0).getChildAt(0).getChildByName('05').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
            this.aniChara.push((effectShip.getChildAt(0).getChildAt(0).getChildByName('04').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
            this.aniChara.push((effectShip.getChildAt(0).getChildAt(0).getChildByName('03').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
            this.aniChara.push((effectShip.getChildAt(0).getChildAt(0).getChildByName('02').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator);
            this.effectBgBai = effectWeather.getChildAt(0).getChildByName('bg_baitian') as Laya.MeshSprite3D;
            this.effectBgYe = effectWeather.getChildAt(1).getChildByName('bg_yewan') as Laya.MeshSprite3D;
            this.effectBgYu = effectWeather.getChildAt(2).getChildByName('bg_xiayu') as Laya.MeshSprite3D;
        }

        public destroyScene() {
            this.sceneBg?.destroy();
            this.sceneBg = null;
        }

    }
}