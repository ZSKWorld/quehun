module uiscript {
    export class Navigation_TabButton {
        public me: Laya.Button;
        private selectImg: Laya.Image;
        private selectedColor: string = '#000000';
        private unselectedColor: string = '#000000';
        constructor(me: Laya.Button, selectedColor: string, unselectedColor: string) {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.selectedColor = selectedColor;
            this.unselectedColor = unselectedColor;
        }
        public onSelect() {
            this.selectImg.visible = true;
        }
        public onDeselect() {
            this.selectImg.visible = false;
        }
    }
    export class UI_Activity_2508_Navigation_Task extends UI_PopupBase {
        public static Inst: UI_Activity_2508_Navigation_Task;

        public static haveRedPoint(activityId: number): boolean {
            let _list = UI_Activity.getPeriodTaskList(activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(activityId);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private comBtns: Laya.Sprite;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabButtons: Array<Navigation_TabButton>;
        private btnGetAll: Laya.Button;
        private itemRect: UIRect = null;
        /**
        * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
        */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private onItemFreshHandler: Laya.Handler;
        private needSort: boolean = false;
        private activityId: number;

        constructor(me: Laya.Sprite) {
            super(me);
            UI_Activity_2508_Navigation_Task.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.listScrollBar = list.getChildByName("scrollbar") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick, null, false);
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
            this.initTabs();
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
        }

        private freshList(delay: number = 0) {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();
            this.locking = true;
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            let tween_config = { delay: 68, duration: 150, ease: Laya.Ease.quadInOut };
            let start_config = { alpha: 0, y_dis: 100 };
            let target_config = { alpha: 1 };
            let count = data.length > 5 ? 5 : data.length;
            let list_delay = 150 + (count - 1) * 68;
            list.me.alpha = 0;
            Laya.timer.once(delay, this, () => {
                list.me.alpha = 1;
                game.Tools.listAnim(list, count, tween_config, start_config, target_config);
            });
            Laya.timer.once(delay + list_delay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<Navigation_TabButton>();
            let tabsName = ['all', 'doing', 'achieved'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Navigation_TabButton(btn, '#fffeee', '#fffeee');
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    if (this.needSort) this.freshData();
                    tabBtn.onSelect();
                    let delay = manualSwitching ? 0 : 100;
                    this.freshList(delay);
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }


        show(activityId: number) {
            this.activityId = activityId;
            (this.root.getChildByName('bg').getChildByName('title') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2508navigation/popup_title_' + activityId + '.png');
            view.AudioMgr.PlayAudio(10354);
            super.show();
        }

        public hide() {
            super.hide();
            uiscript.UI_Activity_2508_Navigation.Inst.refreshRedPoint();
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_2508_Navigation_Task', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_2508_Navigation_Task', true);
            this.freshData();
            this.tabGroups.init();
        }


        //刷新列表数据
        private freshData() {
            this.needSort = false;
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(this.activityId);
            // app.Log.log(`UI_Activity_2508_Navigation_Task的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);
        }


        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight -= 500000; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                let taskConfig = cfg.activity.period_task.get(task.id);
                weight = - taskConfig.reward_limit_day * 100;
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Button;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let txtDesc = container.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('received') as Laya.Sprite;
            let txtUnComplete = unLockParent.getChildByName('uncomplete') as Laya.Sprite;
            let btnReceive = unLockParent.getChildByName("btn_receive") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;
            let imgProgressBar = unLockParent.getChildByName('bar').getChildByName('val') as Laya.Image;
            let txtLockedTime = lockedParent.getChildByName('locked') as Laya.Label;

            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            txtDesc.valign = isUnlock ? 'top' : 'middle';
            txtDesc.y = isUnlock ? 29 : 43;
            let progress: number = serverData.counter || 0;
            txtProgress.text = (progress > baseTaskConfigData.target ? baseTaskConfigData.target : progress) + '/' + baseTaskConfigData.target;
            imgProgressBar.scaleX = Math.min(1, Math.max(progress / baseTaskConfigData.target, 0.01));
            (container.getChildByName('bg') as Laya.Image).visible = configData.node_mark == 0;
            (container.getChildByName('bg_rare') as Laya.Image).visible = configData.node_mark != 0;
            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = !serverData.rewarded && serverData.achieved;
                txtUnComplete.visible = !serverData.rewarded && !serverData.achieved;
                imgGetted.visible = serverData.achieved && serverData.rewarded;
                if (serverData.achieved && !serverData.rewarded) {
                    //已完成未领取
                    //领取的点击事件
                    btnReceive.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) return;
                        this.locking = true;
                        app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            this.locking = false;
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                this.needSort = true;
                                serverData.rewarded = true;
                                UI_Activity.onPeriodTaskRewarded(serverData.id);
                                game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                btnReceive.visible = false;
                                imgGetted.visible = true;
                                this.freshGetAllBtn();
                            }
                        });
                    }, null, false);
                }
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(this.activityId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText1(restSeconds);
            }
            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("item") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_2508_Navigation_Task", true);
                txtCount.text = rewardCount.toString();
                itemParent.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })

            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(task.id);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(this.activityId);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private freshGetAllBtn() {
            this.btnGetAll.visible = this.haveRedPoint();
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let lst = this.sortServerData[currentSelectIndex];
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(this.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        needGetList.push(data['id']);
                    } else {
                        break;
                    }
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    allRewardList.forEach(v => {
                        if (v.achieved && !v.rewarded)
                            v.rewarded = true;
                    });
                    let rewardList = [];
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = Number(rewardStr[0]);
                        let rewardCount = Number(rewardStr[1]);
                        rewardList.push({ id: rewardId, count: rewardCount });
                    }
                    this.needSort = true;
                    this.scrollView.wantToRefreshAll();
                    this.freshGetAllBtn();
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }
    }
}