/**
* name 
*/
module uiscript{
	export class UI_Activity_Ab_Match extends UI_ActivityBase {
        public static Inst:UI_Activity_Ab_Match = null;
        //左边标题的名称
		constructor() {
			super(cfg.activity.activity.get(UI_AB_Match.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_ab_matchUI());
			UI_Activity_Ab_Match.Inst = this;
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean {
			return UI_AB_Match.is_running();
		}

		//活动是否要显示小红点
		public haveRedPoint():boolean {
			return false;
        }
        
        public need_popout():boolean {
			return true;
        }
        
        public onCreate() {
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_AB_Match.is_running()) {
                    UI_Activity.Inst.close();
                    UI_AB_Match.Inst.show();
                } else {
                    // TODO 
                }
            })
        }

        public show() {
			this.enable = true;
        }

        public hide() {
            this.enable = false;
        }
    }
}