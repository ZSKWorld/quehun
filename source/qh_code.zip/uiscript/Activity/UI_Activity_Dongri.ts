/**
* 冬日主界面
*/
module uiscript {
    class Cell {
		public me:Laya.Sprite;
		public id:number; 		   // game_point 中的id
		private pre_score:number;  // -1表示这是第一个
		private me_score:number;
		private next_score:number; // -1表示这是最后一个
		private item_id:number;
		private item_count:number;
		private point_id:number;
		
		private label_score:Laya.Label;
		private point:Laya.Image;
		private btn_reward:Laya.Button;
		private reward_shine:Laya.Sprite;
        private img_reward:Laya.Image;
        private label_bg:Laya.Sprite;
		private label_count:Laya.Label;
		private flag_getted:Laya.Sprite;
		private line_reward:Laya.Sprite;
		private container_lock:Laya.Sprite;
        private label_lock_time:Laya.Label;
		private btn_item:Laya.Sprite;
        private mask:Laya.Sprite;

		private game_score:number;
		private getted:boolean;

		public constructor(me:Laya.Sprite, point_id:number, id:number, pre_score:number, me_score:number, next_score:number, item_id:number, item_count:number) {
			this.me = me;
			this.point_id = point_id
			this.id = id;
			this.pre_score = pre_score;
			this.me_score = me_score;
			this.next_score = next_score;
			this.item_id = item_id;
			this.item_count = item_count;
			
		}

		public init() {
			this.label_score = this.me.getChildByName('score') as Laya.Label;
			this.point = this.me.getChildByName('point') as Laya.Image;
			this.btn_item = this.me.getChildByName('item') as Laya.Sprite;
			this.btn_reward = this.me.getChildByName('reward') as Laya.Button;
			this.reward_shine = this.btn_item.getChildByName('shine') as Laya.Sprite;
            this.img_reward = this.btn_item.getChildByName('item') as Laya.Image;
            this.label_bg = this.btn_item.getChildByName('labelBg') as Laya.Sprite;
			this.label_count = this.btn_item.getChildByName('count') as Laya.Label;
			this.flag_getted = this.btn_item.getChildByName('getted') as Laya.Sprite;
			this.line_reward = this.me.getChildByName('line_reward').getChildByName('value') as Laya.Sprite;

			this.container_lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.label_lock_time = this.container_lock.getChildByName('time') as Laya.Label;
            this.mask = this.me.getChildByName('bmask') as Laya.Sprite;

			if (this.next_score < 0) {
				(this.me.getChildByName('line_reward') as Laya.Sprite).visible = false;	
			}

			this.btn_reward.clickHandler = new Laya.Handler(this, ()=>{
				if (this.game_score >= this.me_score && !this.getted && !this.container_lock.visible) {
					if (UI_Activity_Dongri.Inst.locking) return;
					UI_Activity_Dongri.Inst.locking = true;
					game.Tools.setGrayDisable(this.btn_item, true);
					app.NetAgent.sendReq2Lobby('Lobby', 'gainAccumulatedPointActivityReward', {
						activity_id: UI_Activity_DuanWu_Point.activity_id,
						reward_id: this.id
					}, (err, res) => {
						UI_Activity_Dongri.Inst.locking = false;
						game.Tools.setGrayDisable(this.btn_item, false);
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('gainAccumulatedPointActivityReward', err, res);
						} else {
							UI_Activity_DuanWu_Point.onGetReward(this.id);
                            this.onGetted();
                            UI_Activity_Dongri.Inst.refreshRewardBtnState();
						}
					});
				} else {
					UI_ItemDetail.Inst.show(this.item_id);	
				}
			});

		}

		public show(game_score:number, getted:boolean, start_time:number, now_time:number) {
			this.game_score = game_score;
			this.getted = getted;
			let item_info = game.GameUtility.get_item_view(this.item_id);
			game.LoadMgr.setImgSkin(this.img_reward, item_info.icon);
            this.label_score.text = game.Tools.strOfLocalization(3739, [this.me_score.toString()]);
            
			if (this.next_score == -1) {
				this.line_reward.visible = false;
			} else {
                this.line_reward.visible = true;
                let rate = (game_score - this.me_score) / (this.next_score - this.me_score);
				

				if (rate < 0) this.line_reward.mask.width = 0;
				else {
					if (rate > 1) rate = 1;
					this.line_reward.mask.width = rate * this.line_reward.width;
				}
			}
            
		

            let d_game_point = cfg.activity.game_point.get(this.id);
            this.point.visible = d_game_point.node_mark == 2;
			if (d_game_point.node_mark == 2) {
				
				this.reward_shine.visible = false;
				this.container_lock.visible = false;
				(this.btn_item.getChildByName('snowman') as Laya.Sprite).visible = true;
				if (game_score < this.me_score) {
					this.line_reward.visible = false;
				} else {
					this.line_reward.visible = true;
				}
				this.mask.visible = false;
				(this.container_lock.getChildAt(0) as Laya.Sprite).visible = false;
				if (getted) {
					this.flag_getted.visible = true;
					this.point.visible = false;
					this.btn_item.visible = true;
					game.Tools.setGrayDisable(this.btn_item, false);
					if (this.item_count <= 1) {
						this.label_count.visible = false;
						this.label_bg.visible = false;
					} else {
						this.label_count.visible = true;
						this.label_bg.visible = true;
						this.label_count.text = this.item_count.toString();
					}
					
				} else {
					this.point.visible = true;
					this.btn_item.visible = false;
					let dt:number = now_time - start_time;
					let unlock_time:number = d_game_point.unlock_day * 24 * 3600 * 1000;
					let index = Math.floor(d_game_point.unlock_day / 4) + 1;
					this.container_lock.visible = dt < unlock_time;
					if (dt < unlock_time || game_score < this.me_score) {
						this.point.skin = game.Tools.localUISrc('myres/activity_dongri/snowman' + index +'_d.png');
					} else {
						this.point.skin = game.Tools.localUISrc('myres/activity_dongri/snowman' + index + '.png');
					}

					if (dt < unlock_time) {
						this.container_lock.visible = true;
						this.label_lock_time.text = game.Tools.strOfLocalization(4001 + Math.floor(d_game_point.unlock_day / 5));
					} else {
						this.container_lock.visible = false;
					}
				}
			} else {
				this.point.visible = false;
				(this.btn_item.getChildByName('snowman') as Laya.Sprite).visible = false;
				(this.container_lock.getChildAt(0) as Laya.Sprite).visible = true;
				if (game_score < this.me_score) {
					this.line_reward.visible = false;
					this.reward_shine.visible = false;
					this.mask.visible = true;
				} else {
					this.line_reward.visible = true;
					this.reward_shine.visible = !getted;
					this.mask.visible = false;
				}
				if (getted) {
					this.flag_getted.visible = true;
				} else {
					this.flag_getted.visible = false;
				}

				game.Tools.setGrayDisable(this.btn_item, false);

				if (this.item_count <= 1) {
					this.label_count.visible = false;
					this.label_bg.visible = false;
				} else {
					this.label_count.visible = true;
					this.label_bg.visible = true;
					this.label_count.text = this.item_count.toString();
				}
				
				let dt:number = now_time - start_time;
				let unlock_time:number = d_game_point.unlock_day * 24 * 3600 * 1000;
				if (dt < unlock_time) {
					this.container_lock.visible = true;
					this.reward_shine.visible = false;
					this.mask.visible = true;
					this.label_lock_time.text = game.Tools.strOfLocalization(4001 + Math.floor(d_game_point.unlock_day / 5));
				} else {
					this.container_lock.visible = false;
				}
			}
		}
        
		public canGet():boolean {
			return this.me_score <= this.game_score && !this.getted && !this.container_lock.visible;
		}

		private onGetted() {
			this.getted = true;
			this.flag_getted.visible = true;
			this.reward_shine.visible = false;
			if (this.point.visible) {
				this.point.visible = false;
				this.btn_item.visible = true;
				UI_Activity_Dongri.Inst.showSelectSnowMan(this.point_id / 8 - 1);
			}
			
			if (game.GameUtility.get_id_type(this.item_id) == game.EIDType.character) {
				UI_Get_Character.Inst.show(this.item_id);
			} else {
				game.Tools.showRewards({rewards: [{id: this.item_id, count: this.item_count}]}, null);
			}
			UI_Lobby.Inst.top.refreshDongriRedpoint();
		}

		public onMultiGetted():{id:number, count:number} {
			this.getted = true;
			this.flag_getted.visible = true;
			this.reward_shine.visible = false;

			if (this.point.visible) {
				this.point.visible = false;
				this.btn_item.visible = true;
				UI_Activity_Dongri.Inst.showSelectSnowMan(this.point_id / 8 - 1);
			}
			return {id: this.item_id, count: this.item_count};
		}
    }
    
	export class UI_Activity_Dongri extends UIBase {
        public static Inst:UI_Activity_Dongri;

        constructor() {
			super(new ui.lobby.activitys.activity_dongriUI());
			UI_Activity_Dongri.Inst = this;
        }
        
        //活动是否要显示小红点
		public static haveRedPoint():boolean {
			if (!cfg.activity.game_point) return false;
			if (!UI_Activity.activity_is_running(UI_Activity_DuanWu_Point.activity_id)) return false;
			let havenew:boolean = false;
			cfg.activity.game_point.forEach(d => {
				if (d.activity_id == UI_Activity_DuanWu_Point.activity_id) {
					if (d.point < UI_Activity_DuanWu_Point.point && !UI_Activity_DuanWu_Point.getted_rewards[d.id]) {
						havenew = true;
					}
				}
			});
			return havenew;
		}


        private bg:Laya.Sprite;
        private root:Laya.Sprite;
        private content:Laya.Panel;
		private label_score:Laya.Label;
        private cells:Array<Cell>;
        private left_arrow:Laya.Sprite;
        private right_arrow:Laya.Sprite;
        private snowmanParent:Laya.Sprite;
        private reward_btn:Laya.Button;
		private per_width:number;

        public locking:boolean;
        
        public onCreate() {
			this.cells = [];
            
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            let reward = this.root.getChildByName('reward') as Laya.Sprite;
			this.left_arrow = reward.getChildByName('left') as Laya.Sprite;
			this.right_arrow = reward.getChildByName('right') as Laya.Sprite;

			(this.left_arrow as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if(this.locking) return;
				this.leftBtnClick();
			});

			(this.right_arrow as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if(this.locking) return;
				this.rightBtnClick();
			});
            this.content = reward.getChildByName('content') as Laya.Panel;
            this.snowmanParent = this.root.getChildByName('snowman') as Laya.Sprite;
            for (let i = 0 ;i < this.snowmanParent.numChildren; i++) {
                let spr:Laya.Sprite = this.snowmanParent.getChildAt(i) as Laya.Sprite;
                (spr.getChildAt(3) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                    // TODO spr不倒翁运动
					(this.me as ui.lobby.activitys.activity_dongriUI)[`ani${i + 1}`].play(0, false);
                });
            }

            let bot = this.root.getChildByName('bot') as Laya.Sprite;
            this.label_score = bot.getChildByName('point') as Laya.Label;
            this.reward_btn = bot.getChildByName('receive') as Laya.Button;
			this.reward_btn.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
				let ids:Array<number> = [];
				for (let cell of this.cells) {
					if (cell.canGet()) {
						ids.push(cell.id);
					}
				}
				if (ids.length == 0) return;
				this.locking = true;
				app.NetAgent.sendReq2Lobby('Lobby', 'gainMultiPointActivityReward', {
						activity_id: UI_Activity_DuanWu_Point.activity_id,
						reward_id_list: ids
					}, (err, res) => {
						this.locking = false;
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('gainMultiPointActivityReward', err, res);
						} else {
							let rewards:Array<{id:number, count:number}> = [];
							for (let cell of this.cells) {
								if (ids.indexOf(cell.id) != -1) {
									let info = cell.onMultiGetted();
									let added = false;
									for (let reward of rewards) {
										if (reward.id == info.id) {
											reward.count += info.count;
											added = true;
											break;
										}
									}
									if (!added) {
										rewards.push(info);
									}
									UI_Activity_DuanWu_Point.onGetReward(cell.id);
									game.Tools.showRewards({rewards: rewards}, null);
								}
                            }
							UI_Lobby.Inst.top.refreshDongriRedpoint();
                            this.refreshRewardBtnState();
						}
					});
            });

			let _cell_templete:Laya.Sprite = this.content.getChildByName('cells').getChildByName('task_templete') as Laya.Sprite;
			this.cells = [];
			let datas = [];
			cfg.activity.game_point.forEach(d => {
				if (d.activity_id == UI_Activity_DuanWu_Point.activity_id) {
					datas.push(d);
				}
			});
			for (let i:number = 0; i < datas.length; i++) {
				let _cell:Laya.Sprite = null;
				if (this.cells.length == 0) {
					_cell = _cell_templete;
				} else {
					_cell = _cell_templete.scriptMap['capsui.UICopy'].getNodeClone();
				}
				this.cells.push(new Cell(_cell, datas[i].point_id, datas[i].id, i > 0 ? datas[i - 1].point : -1
					, datas[i].point, i + 1 < datas.length ? datas[i + 1].point : -1
					, datas[i].res_id, datas[i].res_count));
			}
			Laya.timer.frameOnce(6, this, ()=>{
				for (let i:number = 0; i < this.cells.length; i++) {
					this.cells[i].init();
					this.cells[i].me.x = this.cells[i].me.width * i;
				}
			});
			this.content.hScrollBarSkin = '';
			(this.content.getChildByName('cells') as Laya.Sprite).width = datas.length * _cell_templete.width - 10;
			this.per_width = _cell_templete.width;
			this.content.hScrollBar.on('change', this, ()=>{
                let rate = this.content.hScrollBar.value / this.content.hScrollBar.max;
                this.left_arrow.visible = rate > 0;
                this.right_arrow.visible = rate < 1;
			});

            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
        }
        
        public show() {
            this.locking = true;
            this.enable = true;
            UIBase.anim_alpha_in(this.bg, {}, 200);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));

            let now_time:number = game.Tools.getServerTime();
            let start_time:number = UI_Activity.getActivityStartTime(UI_Activity_DuanWu_Point.activity_id) * 1000;
            let lightCount = 0;
            let darkCount = 0;
			for (let i:number = 0; i < this.cells.length; i++) {
                let data = cfg.activity.game_point.get(this.cells[i].id);
                if (data.point <= UI_Activity_DuanWu_Point.point) {
                    if (data.node_mark == 2 && UI_Activity_DuanWu_Point.getted_rewards[data.id]) {
                        lightCount++;
                    }
                }
                
				this.cells[i].show(UI_Activity_DuanWu_Point.point
					, UI_Activity_DuanWu_Point.getted_rewards[this.cells[i].id], start_time, now_time);
			}
			this.label_score.text = UI_Activity_DuanWu_Point.point.toString();
            this.showSnowMan(lightCount, darkCount);
            this.refreshRewardBtnState();
        }
        private close() {
            this.locking = true;
            Laya.Tween.to(this.bg, {alpha: 0}, 150);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
        }

        private showSnowMan(lightCount:number, darkCount:number) {
            for (let i = 0 ;i < this.snowmanParent.numChildren; i++) {
                let spr:Laya.Sprite = this.snowmanParent.getChildAt(i) as Laya.Sprite;
				(spr.getChildAt(1) as Laya.Image).skin = game.Tools.localUISrc(`myres/activity_dongri/snowman${i + 1}_l1.png`);
                if (i < lightCount) {
                    (spr.getChildAt(3) as Laya.Sprite).visible = true;
                    
					(spr.getChildAt(0) as Laya.Sprite).visible = false;
					(spr.getChildAt(1) as Laya.Sprite).visible = true;
					(spr.getChildAt(2) as Laya.Sprite).visible = true;
                } else {
                    (spr.getChildAt(3) as Laya.Sprite).visible = false;
					(spr.getChildAt(0) as Laya.Sprite).visible = true;
					(spr.getChildAt(1) as Laya.Sprite).visible = false;
					(spr.getChildAt(2) as Laya.Sprite).visible = false;
                }
            }
        }

		public showSelectSnowMan(index:number) {
			let spr:Laya.Sprite = this.snowmanParent.getChildAt(index) as Laya.Sprite;
			 (spr.getChildAt(3) as Laya.Sprite).visible = true;
                    
			(spr.getChildAt(0) as Laya.Sprite).visible = false;
			(spr.getChildAt(1) as Laya.Sprite).visible = true;
			(spr.getChildAt(2) as Laya.Sprite).visible = true;
		}
        public refreshRewardBtnState() {
            let ids:Array<number> = [];
            for (let cell of this.cells) {
                if (cell.canGet()) {
                    ids.push(cell.id);
                }
            }
            if (ids.length == 0) {
                this.reward_btn.mouseEnabled = false;
                (this.reward_btn.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/activity_dongri/btn_received_d.png');
            } else {
                this.reward_btn.mouseEnabled = true;
                (this.reward_btn.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/activity_dongri/btn_received.png');
            }
        }

		private leftBtnClick() {
			this.content.scrollTo(this.content.hScrollBar.value - this.per_width);
		}

		private rightBtnClick() {
			this.content.scrollTo(this.content.hScrollBar.value + this.per_width);
		}
    }
}