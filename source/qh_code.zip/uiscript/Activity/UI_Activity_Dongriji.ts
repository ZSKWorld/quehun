/**
* name 
*/
module uiscript{
	export class UI_Activity_Dongriji extends UI_ActivityBase {
        public static Inst:UI_Activity_Dongriji = null;
        //左边标题的名称
		constructor() {
			super(cfg.activity.activity.get(UI_Activity_DuanWu_Point.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_dongrijiUI());
			UI_Activity_Ab_Match.Inst = this;
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean {
			return UI_Activity.activities[UI_Activity_DuanWu_Point.activity_id];
		}

		//活动是否要显示小红点
		public haveRedPoint():boolean {
			let havenew:boolean = false;
			cfg.activity.game_point.forEach(d => {
				if (d.activity_id == UI_Activity_DuanWu_Point.activity_id) {
					if (d.point < UI_Activity_DuanWu_Point.point && !UI_Activity_DuanWu_Point.getted_rewards[d.id]) {
						havenew = true;
					}
				}
			});
			return havenew;
		}

		//活动是否要弹出来
		public need_popout():boolean {return cfg.activity.activity.get(UI_Activity_DuanWu_Point.activity_id).need_popout == 1;}
        
        public onCreate() {
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.isopen()) {
                    UI_Activity.Inst.close();
                    UI_Activity_Dongri.Inst.show();
                } else {
                    // TODO 
                }
            })
        }

        public show() {
			this.enable = true;
        }

        public hide() {
            this.enable = false;
        }
    }
}