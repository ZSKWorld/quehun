/**
* name 
*/
module uiscript{

	class Cell {
		public me:Laya.Sprite;
		public id:number; 		   // game_point 中的id
		private pre_score:number;  // -1表示这是第一个
		private me_score:number;
		private next_score:number; // -1表示这是最后一个
		private item_id:number;
		private item_count:number;
		
		private label_score:Laya.Label;
		private shine_point:Laya.Image;
		private btn_reward:Laya.Button;
		private reward_shine:Laya.Sprite;
		private img_reward:Laya.Image;
		private label_count:Laya.Label;
		private flag_getted:Laya.Sprite;
		private line_down:Laya.Sprite;
		private line_up:Laya.Sprite;
		private line_reward:Laya.Sprite;
		private container_lock:Laya.Sprite;
		private label_lock_time:Laya.Label;

		private game_score:number;
		private getted:boolean;

		public constructor(me:Laya.Sprite, id:number, pre_score:number, me_score:number, next_score:number, item_id:number, item_count:number) {
			this.me = me;
			this.id = id;
			this.pre_score = pre_score;
			this.me_score = me_score;
			this.next_score = next_score;
			this.item_id = item_id;
			this.item_count = item_count;
		}

		public init() {
			this.label_score = this.me.getChildByName('score') as Laya.Label;
			this.shine_point = this.me.getChildByName('shine_point') as Laya.Image;
			this.btn_reward = this.me.getChildByName('reward') as Laya.Button;
			this.reward_shine = this.btn_reward.getChildByName('shine') as Laya.Sprite;
			this.img_reward = this.btn_reward.getChildByName('item') as Laya.Image;
			this.label_count = this.btn_reward.getChildByName('num') as Laya.Label;
			this.flag_getted = this.btn_reward.getChildByName('getted') as Laya.Sprite;
			this.line_down = this.me.getChildByName('line_down') as Laya.Sprite;
			this.line_up = this.me.getChildByName('line_up') as Laya.Sprite;
			this.line_reward = this.me.getChildByName('line_reward') as Laya.Sprite;

			this.container_lock = this.me.getChildByName('lock') as Laya.Sprite;
			this.label_lock_time = this.container_lock.getChildByName('time') as Laya.Label;

			this.btn_reward.clickHandler = new Laya.Handler(this, ()=>{
				if (this.game_score >= this.me_score && !this.getted) {
					game.Tools.setGrayDisable(this.btn_reward, true);
					app.NetAgent.sendReq2Lobby('Lobby', 'gainAccumulatedPointActivityReward', {
						activity_id: UI_Activity_DuanWu_Point.activity_id,
						reward_id: this.id
					}, (err, res) => {
						game.Tools.setGrayDisable(this.btn_reward, false);
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('gainAccumulatedPointActivityReward', err, res);
						} else {
							UI_Activity_DuanWu_Point.onGetReward(this.id);
							this.onGetted();
						}
					});
				} else {
					UI_ItemDetail.Inst.show(this.item_id);
				}
			});
		}

		public show(game_score:number, getted:boolean, start_time:number, now_time:number) {
			this.game_score = game_score;
			this.getted = getted;
			let item_info = game.GameUtility.get_item_view(this.item_id);
			game.LoadMgr.setImgSkin(this.img_reward, item_info.icon);
			this.label_score.text = this.me_score.toString();
			if (this.pre_score == -1) {
				this.line_up.visible = false;
			} else {
				this.line_up.visible = true;

				let rate = (game_score - (this.pre_score + this.me_score) / 2) / (this.me_score - this.pre_score) * 2;
				if (rate < 0) (this.line_up.getChildByName('value') as Laya.Sprite).visible = false;
				else {
					if (rate > 1) rate = 1;
					(this.line_up.getChildByName('value') as Laya.Sprite).visible = true;
					(this.line_up.getChildByName('value') as Laya.Sprite).scaleY = rate;
				}
			}
			if (this.next_score == -1) {
				this.line_down.visible = false;
			} else {
				this.line_down.visible = true;

				let rate = (game_score - this.me_score) / (this.next_score - this.me_score) * 2;
				if (rate < 0) (this.line_down.getChildByName('value') as Laya.Sprite).visible = false;
				else {
					if (rate > 1) rate = 1;
					(this.line_down.getChildByName('value') as Laya.Sprite).visible = true;
					(this.line_down.getChildByName('value') as Laya.Sprite).scaleY = rate;
				}
			}

			if (game_score < this.me_score) {
				(this.line_reward.getChildByName('value') as Laya.Sprite).visible = false;
				this.reward_shine.visible = false;
				this.shine_point.skin = game.Tools.localUISrc('myres/activity_duanwu/point_unshine.png');
				this.label_score.color = '#bababa';
			} else {
				(this.line_reward.getChildByName('value') as Laya.Sprite).visible = true;
				this.reward_shine.visible = true;
				this.shine_point.skin = game.Tools.localUISrc('myres/activity_duanwu/point_shine.png');
				this.label_score.color = '#ffd52b';
			}
			if (getted) {
				this.flag_getted.visible = true;
			} else {
				this.flag_getted.visible = false;
			}

			game.Tools.setGrayDisable(this.btn_reward, false);

			if (this.item_count <= 1) {
				this.label_count.visible = false;
			} else {
				this.label_count.visible = true;
				this.label_count.text = this.item_count.toString();
			}

			let d_game_point = cfg.activity.game_point.get(this.id);
			let dt:number = now_time - start_time;
			let unlock_time:number = d_game_point.unlock_day * 24 * 3600 * 1000;
			if (dt < unlock_time) {
				this.container_lock.visible = true;
				let timestamp:number = (start_time + unlock_time) / 1000;
				let s:string = game.Tools.time2YearMounthDate(timestamp) + ' ' + game.Tools.time2HourMinute(timestamp);
				this.label_lock_time.text = game.Tools.strOfLocalization(2825, [s]);
			} else {
				this.container_lock.visible = false;
			}
		}

		private onGetted() {
			this.getted = true;
			Laya.timer.clearAll(this);
			this.flag_getted.visible = true;
			let img_bg:Laya.Image = this.flag_getted.getChildByName('bg') as Laya.Image;
			img_bg.alpha = 0;
			Laya.Tween.to(img_bg, {alpha: 0.5}, 150);
			let img_gou:Laya.Image = this.flag_getted.getChildByName('gou') as Laya.Image;
			img_gou.scaleX = img_gou.scaleY = 0;
			img_gou.alpha = 0;
			Laya.Tween.to(img_gou, {scaleX: 1, scaleY: 1, alpha: 1}, 200, Laya.Ease.backOut);
			if (game.GameUtility.get_id_type(this.item_id) == game.EIDType.character) {
				UI_Get_Character.Inst.show(this.item_id);
			} else {
				game.Tools.showRewards({rewards: [{id: this.item_id, count: this.item_count}]}, null);
			}
			// UI_LightTips.Inst.show(game.Tools.strOfLocalization(2211));
			UI_Lobby.Inst.top.refreshRedpoint();
			UI_Activity.Inst.refresh_redpoint();
		}
	}

	export class UI_Activity_DuanWu_Point extends UI_ActivityBase {

		private static Inst:UI_Activity_DuanWu_Point;
		public static activity_id:number = 231151;
		public static point:number = 0;
		public static getted_rewards:Object;
		public static getted_rewards_count:number = 0;

		public static init(data) {
			this.point = 0;
			this.getted_rewards = {};
			this.getted_rewards_count = 0;
			if (data) {
				let lst = data.accumulated_point_list;
				for (let i:number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.activity_id == this.activity_id) {
						this.point = d.point;
						if (d.gained_reward_list) {
							for (let j:number = 0; j < d.gained_reward_list.length; j++) {
								this.getted_rewards[d.gained_reward_list[j]] = 1;
							}
							this.getted_rewards_count = d.gained_reward_list.length;
						}
					}
				}
			}

		}

		public static onGetReward(id:number) {
			if (!this.getted_rewards[id]) {
				this.getted_rewards[id] = 1;
				this.getted_rewards_count++;
				if (this.Inst && this.Inst.enable) {
					this.Inst.refreshRewardsCount();
				}
			}
		}

		//	获取今天能得到的最高分的数值
		public static max_point():number {
			let now_time:number = Laya.timer.currTimer + GameMgr.Inst.server_time_delta;
			let d_activity = UI_Activity.activities[this.activity_id];
			if (!d_activity) return 0;
            let start_time:number = d_activity.start_time * 1000;
			let day:number = Math.floor((now_time - start_time) / 24 / 3600 / 1000);
			
			let info = cfg.activity.game_point_info.get(this.activity_id);
			if (info && info.max_point_limit_day >= 0 && info.max_point_limit_day <= day) {
				return -1;
			}

			let _max_point:number = 0;
			cfg.activity.game_point.forEach(x => {
				if (x.activity_id == this.activity_id && x.unlock_day <= day) {
					_max_point = _max_point > x.point ? _max_point : x.point;
				}
			});
			return _max_point;
		}

		private content:Laya.Panel;
		private head:Laya.Image;
		private label_score:Laya.Label;
		private label_reward_count:Laya.Label;
		private cells:Array<Cell>;
		private scrollbar:capsui.CScrollBar;
		private atlas_url:string;

		private toth:number;

		constructor() {
			super(cfg.activity.activity.get(UI_Activity_DuanWu_Point.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_duanwu_pointUI());
			UI_Activity_DuanWu_Point.Inst = this;	

			this.atlas_url = 'res/atlas/';
			if (GameMgr.client_language != 'chs') {
				this.atlas_url += GameMgr.client_language + '/';
			} 
			this.atlas_url += 'myres/activity_dongri.atlas';
		}
		
		public onCreate() {
			this.cells = [];
			
			let root:Laya.Sprite = this.me.getChildByName('root') as Laya.Sprite;
			this.content = root.getChildByName('content') as Laya.Panel;
			this.head = this.content.getChildByName('head') as Laya.Image;
			this.label_score = this.head.getChildByName('score') as Laya.Label;
			this.label_reward_count = this.head.getChildByName('reward_count') as Laya.Label;

			let _cell_templete:Laya.Sprite = this.content.getChildByName('cells').getChildByName('task_templete') as Laya.Sprite;
			this.cells = [];
			let datas = [];
			cfg.activity.game_point.forEach(d => {
				if (d.activity_id == UI_Activity_DuanWu_Point.activity_id) {
					datas.push(d);
				}
			});
			for (let i:number = 0; i < datas.length; i++) {
				let _cell:Laya.Sprite = null;
				if (this.cells.length == 0) {
					_cell = _cell_templete;
				} else {
					_cell = _cell_templete.scriptMap['capsui.UICopy'].getNodeClone();
				}
				this.cells.push(new Cell(_cell, datas[i].id, i > 0 ? datas[i - 1].point : -1
					, datas[i].point, i + 1 < datas.length ? datas[i + 1].point : -1
					, datas[i].res_id, datas[i].res_count));
			}
			Laya.timer.frameOnce(6, this, ()=>{
				for (let i:number = 0; i < this.cells.length; i++) {
					this.cells[i].init();
					this.cells[i].me.y = this.cells[i].me.height * i;
				}
			});
			this.content.vScrollBarSkin = '';
			(this.content.getChildByName('cells') as Laya.Sprite).height = datas.length * _cell_templete.height;
			this.toth = (this.content.getChildByName('cells') as Laya.Sprite).y + datas.length * _cell_templete.height;

			this.scrollbar = (root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.scrollbar.init(null);
			this.content.vScrollBar.on('change', this, ()=>{
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.toth);
			});
			this.label_reward_count.x = GameMgr.client_language == 'en' ? 747 : 686;
			Laya.timer.once(2000, this, ()=>{
				if (!this.enable) {
					Laya.loader.clearTextureRes(this.atlas_url);
				}
			});
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean {return UI_Activity.activities[UI_Activity_DuanWu_Point.activity_id];}

		//活动是否要显示小红点
		public haveRedPoint():boolean {
			let havenew:boolean = false;
			cfg.activity.game_point.forEach(d => {
				if (d.activity_id == UI_Activity_DuanWu_Point.activity_id) {
					if (d.point < UI_Activity_DuanWu_Point.point && !UI_Activity_DuanWu_Point.getted_rewards[d.id]) {
						havenew = true;
					}
				}
			});
			return havenew;
		}

		//活动是否要弹出来
		public need_popout():boolean {return cfg.activity.activity.get(UI_Activity_DuanWu_Point.activity_id).need_popout == 1;}

		public show() {
			this.enable = true;
			let now_time:number = Date.now();
			let d_activity = cfg.activity.activity.get(UI_Activity_DuanWu_Point.activity_id);
			let start_time:number = game.Tools.ParseTime(d_activity.start_time);
			for (let i:number = 0; i < this.cells.length; i++) {
				this.cells[i].show(UI_Activity_DuanWu_Point.point
					, UI_Activity_DuanWu_Point.getted_rewards[this.cells[i].id], start_time, now_time);
			}
			this.label_score.text = UI_Activity_DuanWu_Point.point.toString();
			this.refreshRewardsCount();
		}

		public refreshRewardsCount() {
			this.label_reward_count.text = UI_Activity_DuanWu_Point.getted_rewards_count.toString() + '/' + this.cells.length.toString();
			
		}
		
		public hide() {
			this.enable = false;
			Laya.loader.clearTextureRes(this.atlas_url);
		}
	}
}