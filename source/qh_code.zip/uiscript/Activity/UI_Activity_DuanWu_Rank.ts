/**
* name 
*/
module uiscript{

	interface iRankData {
		 account_id:number;
		 rank:number;
		 view:iPlayerBaseView;
		 point:number;
	}

	export class UI_Activity_DuanWu_Rank extends UI_ActivityBase {

		public static activity_id:number = 1010;
		public static point:number = 0;
		public static reward_getted:boolean = false;
		public static gainable_time:number = -1;

		public static init(data) {
			this.point = 0;
			this.reward_getted = false;
			if (data) {
				let lst = data.rank_data_list;
				for (let i:number = 0; i < lst.length; i++) {
					let d = lst[i];
					if (d.leaderboard_id == this.activity_id) {
						this.point = d.point;
						this.reward_getted = d.gained_reward;
					}
				}
			}
		}

		private head:Laya.Image;
		private label_score:Laya.Label;
		private label_rank:Laya.Label;
		private label_reward:Laya.Label;
		private btn_info:Laya.Button;
		private btn_getreward:Laya.Button;
		private label_alreadyget:Laya.Sprite;
		private scrollview:capsui.CScrollView;
		private noinfo:Laya.Label;

		private last_refresh_time:number = -1;
		
		private my_rank:number = -1;
		private datas:Array<iRankData> = [];

		constructor() {
			super(cfg.activity.activity.get(UI_Activity_DuanWu_Rank.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_duanwu_rankUI());
		}

		public onCreate() {
			let root:Laya.Sprite = this.me.getChildByName('root') as Laya.Sprite;
			this.head = root.getChildByName('head') as Laya.Image;
			let container_head:Laya.Sprite = root.getChildByName('head') as Laya.Sprite;
			this.label_score = container_head.getChildByName('score') as Laya.Label;
			this.label_rank = container_head.getChildByName('rank') as Laya.Label;
			this.label_reward = container_head.getChildByName('reward') as Laya.Label;
			this.btn_info = container_head.getChildByName('what') as Laya.Button;
			this.btn_getreward = container_head.getChildByName('btn_get') as Laya.Button;
			this.label_alreadyget = container_head.getChildByName('alreadyget') as Laya.Sprite;
			this.scrollview = root.scriptMap['capsui.CScrollView'];
			this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
			this.noinfo = root.getChildByName('noinfo') as Laya.Label;

			this.label_alreadyget.visible = false;
			this.noinfo.visible = false;
			this.scrollview.reset();
			this.btn_getreward.visible = false;
			this.label_rank.text = '--';
			this.label_reward.text = '--';
			this.label_score.text = '--';

			
		}

		private render_item(cell) {
			let container:Laya.Sprite = cell.container;
			let index:number = cell.index;
			let cache_data:Object = cell.cache_data;
			let data:iRankData = this.datas[index];

			(container.getChildByName('rank') as Laya.Label).text = data.rank.toString();

			if (!cache_data.hasOwnProperty('head')) {
				cache_data['head'] = new UI_Head(container.getChildByName('head') as Laya.Sprite, 'UI_Activity_DuanWu_Rank');
			}
			if (!cache_data.hasOwnProperty('title')) {
				cache_data['title'] = new UI_PlayerTitle(container.getChildByName('title') as Laya.Sprite, 'UI_Activity_DuanWu_Rank');
			}
			//如果是自己的话 view用自己的数据
			if (data.account_id == GameMgr.Inst.account_id) {
				cache_data['head'].id = GameMgr.Inst.account_data['avatar_id'];
				cache_data['head'].set_head_frame(GameMgr.Inst.account_id, GameMgr.Inst.account_data['avatar_frame']);
				cache_data['title'].id = game.Tools.titleLocalization(data.account_id, GameMgr.Inst.account_data['title']);
				(container.getChildByName('name') as Laya.Label).text = GameMgr.Inst.account_data['nickname'];
				(container.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_duanwu/rank_cell_me.png');
			} else {
				cache_data['head'].id = data.view.avatar_id;
				cache_data['head'].id = data.view.avatar_frame;
				cache_data['title'].id = game.Tools.titleLocalization(data.account_id, data.view.title);
				(container.getChildByName('name') as Laya.Label).text = data.view.nickname;
				(container.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_duanwu/rank_cell.png');
			}
			
			(container.getChildByName('btn_see') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				UI_PlayerInfo.Inst.show({
					accountId: data.account_id
				});
			}, null, false);
			(container.getChildByName('score') as Laya.Label).text = data.point.toString();
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean {return UI_Activity.activities[UI_Activity_DuanWu_Rank.activity_id];}

		//活动是否要显示小红点
		public haveRedPoint():boolean {return !UI_Activity_DuanWu_Rank.reward_getted 
												&& UI_Activity_DuanWu_Rank.gainable_time > 0
												&& UI_Activity_DuanWu_Rank.gainable_time < Date.now() / 1000;}

		//活动是否要弹出来
		public need_popout():boolean {
			return cfg.activity.activity.get(UI_Activity_DuanWu_Rank.activity_id).need_popout == 1;
		}

		public show() {
			this.enable = true;
			game.TempImageMgr.setUIEnable('UI_Activity_DuanWu_Rank', true);
			game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/duanwu_rank.jpg');
			this.label_score.text = UI_Activity_DuanWu_Rank.point.toString();
			this.refresh_my_rank();
			
			let _now:number = Date.now() / 1000;
			let _refresh_cd:number = 60;
			let d_table = cfg.leaderboard.leaderboard.get(UI_Activity_DuanWu_Rank.activity_id);
			if (d_table) _refresh_cd = d_table.refresh_cd;
			if (_now < this.last_refresh_time + _refresh_cd && !(this.last_refresh_time < UI_Activity_DuanWu_Rank.gainable_time && _now < UI_Activity_DuanWu_Rank.gainable_time)) {
				// 本地数据ok，不需要向服务器拿数据
				this.scrollview.rate = 0;
				this.noinfo.visible = this.datas.length == 0;
			} else {
				// 本地数据过期，需要拿新数据
				this.scrollview.reset();
				this.datas = [];
				app.NetAgent.sendReq2Lobby('Lobby', 'fetchRankPointLeaderboard', {
					leaderboard_id: UI_Activity_DuanWu_Rank.activity_id
				}, (err, res) => {	
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('fetchRankPointLeaderboard', err, res);
					} else {
						this.last_refresh_time = res['last_refresh_time'];
						let items = res['items'];
						let account_id_map = {};
						if (items) {
							for (let i: number = 0; i < items.length; i++) {
								if (account_id_map[items[i].account_id]) continue;
								account_id_map[items[i].account_id] = 1;
								this.datas.push(items[i]);
							}
						}
						this.datas = this.datas.sort((a, b)=>{ return a.rank - b.rank; });
						this.scrollview.addItem(this.datas.length);
						this.noinfo.visible = this.datas.length == 0;
						for (let i:number = 0; i < this.datas.length; i++) {
							if (this.datas[i].account_id == GameMgr.Inst.account_id) {
								this.my_rank = this.datas[i].rank;
								break;
							}
						}
						this.refresh_my_rank();
					}
				});
			}
		}

		private refresh_my_rank() {
			let d_rewards = cfg.activity.rank_reward.findGroup(1010);
			let reward_index:number = -1;
			
			let str_refresh:string = `(${game.Tools.strOfLocalization(2782, [Math.floor((Date.now() / 1000 - this.last_refresh_time) / 60).toString()])})`;
			if (Date.now() > UI_Activity_DuanWu_Rank.gainable_time) str_refresh = '';
			if (this.my_rank > 0) {
				this.label_rank.text = this.my_rank.toString() + str_refresh;
				for (let i:number = d_rewards.length - 1; i >= 0; i--) {
					if (this.my_rank >= d_rewards[i].lower_rank_bound) {
						reward_index = i;
						break;
					}
				}
			} else {
				this.label_rank.text = d_rewards[d_rewards.length - 1].lower_rank_bound.toString() + '+' + str_refresh;
			}

			if (reward_index >= 0) {
				let str:string = '';
				let s_reward:string = d_rewards[reward_index].reward;
				let reward_lst:Array<string> = s_reward.split(',');
				for (let i:number = 0; i < reward_lst.length; i++) {
					let s:string = reward_lst[i];
					let d:Array<string> = s.split('-');
					if (d.length == 2) {
						let item_id:number = parseInt(d[0]);
						let count:number = parseInt(d[1]);
						let item_info = game.GameUtility.get_item_view(item_id);
						if (str != '') str += ',';
						str += `${item_info.name}x${count}`;
					}
				}
				this.label_reward.text = str;
				this.btn_getreward.visible = !UI_Activity_DuanWu_Rank.reward_getted;
				this.label_alreadyget.visible = UI_Activity_DuanWu_Rank.reward_getted;
				game.Tools.setGrayDisable(this.btn_getreward, UI_Activity_DuanWu_Rank.gainable_time > 0 && Date.now() / 1000 < UI_Activity_DuanWu_Rank.gainable_time);
				this.btn_getreward.clickHandler = Laya.Handler.create(this, ()=>{
					game.Tools.setGrayDisable(this.btn_getreward, true);
					app.NetAgent.sendReq2Lobby('Lobby', 'gainRankPointReward', {
						leaderboard_id: UI_Activity_DuanWu_Rank.activity_id,
						activity_id: UI_Activity_DuanWu_Rank.activity_id
					}, (err, res) => {
						game.Tools.setGrayDisable(this.btn_getreward, false);
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('gainRankPointReward', err, res);
						} else {
							UI_Activity_DuanWu_Rank.reward_getted = true;
							this.btn_getreward.visible = false;
							this.label_alreadyget.visible = true;
							UI_LightTips.Inst.show(game.Tools.strOfLocalization(2211));
						}
					});
				}, null, false);
			} else {
				this.label_reward.text = game.Tools.strOfLocalization(2780);
				this.btn_getreward.visible = false;
				this.label_alreadyget.visible = false;
				if (UI_Activity_DuanWu_Rank.gainable_time > 0 && Date.now() / 1000 > UI_Activity_DuanWu_Rank.gainable_time) {
					//若活动时间已过，可以领取奖励了，但是没奖励，且没领取，就向服务端自动发送领取奖励，把状态置成已领取
					if (!UI_Activity_DuanWu_Rank.reward_getted) {
						app.NetAgent.sendReq2Lobby('Lobby', 'gainRankPointReward', {
							leaderboard_id: UI_Activity_DuanWu_Rank.activity_id,
							activity_id: UI_Activity_DuanWu_Rank.activity_id
						}, (err, res) => {

						});
						UI_Activity_DuanWu_Rank.reward_getted = true;
					}
				}
				this.btn_getreward.clickHandler = null;
			}
			
		}
		
		public hide() {
			this.enable = false;
			game.TempImageMgr.setUIEnable('UI_Activity_DuanWu_Rank', false);
			let path:string = game.Tools.localUISrc('myres2/treasurehead/duanwu_rank.jpg');
			Laya.loader.clearTextureRes(path);
		}

	}
}