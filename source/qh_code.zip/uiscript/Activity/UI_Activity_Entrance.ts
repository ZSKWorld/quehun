/**
* 纯入口用，每次替换图片，活动id和按钮事件，并替换图片
*/
module uiscript {
    export class UI_Activity_Entrance extends UI_ActivityBase {
        public static Inst: UI_Activity_Entrance = null;
        public static activity_id: number = -1; // 每次修改
        public getId(): number {
            return UI_Activity_Entrance.activity_id;
        }
        //左边标题的名称
        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Entrance.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_entranceUI());
            UI_Activity_Entrance.Inst = this;
        }

        //活动是否开放中，不开放的活动不会显示
        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Entrance.activity_id];
        }

        //活动是否要显示小红点,有单独活动入口的不需要显示红点
        public haveRedPoint(): boolean {
            return false;
        }

        //活动是否要弹出来
        public need_popout(): boolean { return cfg.activity.activity.get(UI_Activity_Entrance.activity_id).need_popout == 1; }

        public onCreate() {
            // if (GameMgr.client_language == 'en') {
            //     (this.me.getChildByName('btn') as Laya.Button).width = 458;
            //     (this.me.getChildByName('btn') as Laya.Button).height = 186;
            // }
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_PiPeiYuYue.Inst.enable) {
                        UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                        return;
                    }
                    if (UI_Lobby.Inst.locking) return;
                    if (!UI_Activity.activity_is_running(UI_Activity_Entrance.activity_id)) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3944));
                        return;
                    }
                    
                    if (UI_Activity_ClothesVote.isMaintain) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093));
                        return;
                    }
                    UI_Activity.Inst.close();
                    //全屏活动关闭大厅
                    // UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                    //     UI_Activity_ClothesVote.Inst.show();
                    // }));
                    UI_Activity_Vtuber.Inst.show();
                }
            });

            // (this.me.getChildByName('btn_shop') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
            //     if (UI_PiPeiYuYue.Inst.enable) {
            //         UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
            //         return;
            //     }
            //     if (UI_Lobby.Inst.locking) return;
            //     UI_Activity.Inst.close();
            //     UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
            //         UI_Shop.Inst.show(EShopType.skin);
            //     }));
            // });

            // (this.me.getChildByName('btn_treasure') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
            //     if (UI_PiPeiYuYue.Inst.enable) {
            //         UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
            //         return;
            //     }
            //     if (UI_Lobby.Inst.locking) return;
            //     UI_Activity.Inst.close();
            //     UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
            //         UI_Treasure.Inst.show();
            //     }));
            // })
            let activityConfig = cfg.activity.activity_banner.get(UI_Activity_Entrance.activity_id);
            game.LoadMgr.setImgSkin((this.me.getChildByName('head') as Laya.Image), activityConfig.banner_big, null, 'UI_Activity_Entrance');
            // if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
            //     (this.me.getChildByName('copyright') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_entrance/copyright_en.png');
            // }
        }

        public show() {
            this.enable = true;
        }

        public hide() {
            this.enable = false;
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance', false);
        }
    }
}