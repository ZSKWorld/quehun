/**
* 青云之志专用banner入口
*/
module uiscript {
    export class UI_Activity_Entrance_Amulet extends UI_ActivityBase {
        public static Inst: UI_Activity_Entrance_Amulet = null;
        public static activity_id: number = 250811; // 每次修改
        public getId(): number {
            return UI_Activity_Entrance_Amulet.activity_id;
        }
        private locking: boolean;

        //左边标题的名称
        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Entrance_Amulet.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_entrance_amuletUI());
            UI_Activity_Entrance_Amulet.Inst = this;
        }

        private head: Laya.Image = null;

        //活动是否开放中，不开放的活动不会显示
        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Entrance_Amulet.activity_id];
        }

        //活动是否要显示小红点
        public haveRedPoint(): boolean {
            return false;
        }

        //活动是否要弹出来
        public need_popout(): boolean { return cfg.activity.activity.get(UI_Activity_Entrance_Amulet.activity_id).need_popout == 1; }

        public onCreate() {
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_Lobby.Inst.locking) return;
                    if (this.locking) return;
                    if (UI_PiPeiYuYue.Inst.enable) {
                        UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                        return;
                    }
                    this.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchAmuletActivityData, { activity_id: UI_Activity_Amulet.activityId }, (err, res: game.IResAmuletActivityFetchInfo) => {
                        this.locking = false;
                        if (err || res['error']) {
                            if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26121 || res['error']['code'] == 26123)) {
                                uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093));
                            } else {
                                uiscript.UIMgr.Inst.showNetReqError(game.ERequest.fetchAmuletActivityData, err, res);
                            }
                        } else {
                            let data = res.data || {} as game.IActivityAmuletData;
                            app.Log.log('amuletActivityFetchInfo === res=====' + JSON.stringify(data));
                            UI_Activity_Amulet.initData(data);
                            UI_Activity.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Activity_Amulet.enterToPokerGame(data.game);
                            }));
                        }
                    });
                }
            });
            this.head = this.me.getChildByName('head') as Laya.Image;
            game.LoadMgr.setImgSkin(this.head, cfg.activity.activity_banner.get(this.getId()).banner_big);
        }

        public show() {
            this.enable = true;
        }

        public hide() {
            this.enable = false;
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance_Amulet', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance_Amulet', false);
        }
    }
}