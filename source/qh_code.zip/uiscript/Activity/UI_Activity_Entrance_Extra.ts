/**
* 纯入口用，每次替换图片，活动id和按钮事件，当前活动为青云之志
*/
module uiscript {
    export class UI_Activity_Entrance_Extra extends UI_ActivityBase {
        public static Inst: UI_Activity_Entrance_Extra = null;
        public static activity_id: number = 260401; // 每次修改
        public getId(): number {
            return UI_Activity_Entrance_Extra.activity_id;
        }

        //左边标题的名称
        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Entrance_Extra.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_entrance_extraUI());
            UI_Activity_Entrance_Extra.Inst = this;
        }

        private head: Laya.Image = null;

        //活动是否开放中，不开放的活动不会显示
        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Entrance_Extra.activity_id];
        }

        //活动是否要显示小红点
        public haveRedPoint(): boolean {
            return false;
        }

        //活动是否要弹出来
        public need_popout(): boolean { return cfg.activity.activity.get(UI_Activity_Entrance_Extra.activity_id).need_popout == 1; }

        public onCreate() {
            if (GameMgr.client_type == 'en') {
                if (GameMgr.client_language == 'chs_t') {
                    (this.me.getChildByName('copyright') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_entrance_extra/copyright_en.png');
                }
                // if (GameMgr.client_language != 'kr')
                //     (this.me.getChildByName('copyright') as Laya.Image).scale(1.25, 1.25);
            }

            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_Lobby.Inst.locking) return;
                    if (UI_PiPeiYuYue.Inst.enable) {
                        UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                        return;
                    }
                    if (!UI_Activity.activity_is_running(UI_Activity_Liandong_Main.activityId)) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3944));
                        return;
                    }
                    UI_Lobby.Inst.locking = true;
                    game.MaintainMgr.fetchActivityMaintainInfo(Laya.Handler.create(this, () => {
                        UI_Lobby.Inst.locking = false;
                        if (game.MaintainMgr.isActivityMaintain(UI_Activity_Liandong_Main.activityId)) {
                            game.MaintainMgr.showMaintainTip();
                            return;
                        }
                        UI_Lobby.Inst.locking = true;
                        MMOData.Inst.fetchMMOData(
                            Laya.Handler.create(this, (isSuccess: boolean) => {
                                UI_Lobby.Inst.locking = false;
                                if (isSuccess) {
                                    UI_Activity.Inst.close();
                                    UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                        GameMgr.Inst.enterActivityScene();
                                    }));
                                }
                            }));
                    }));
                }
            });
            this.head = this.me.getChildByName('head') as Laya.Image;
            game.LoadMgr.setImgSkin(this.head, cfg.activity.activity_banner.get(this.getId()).banner_big);
            (this.me.getChildByName('btn_shop') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_PiPeiYuYue.Inst.enable) {
                    UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                    return;
                }
                if (UI_Lobby.Inst.locking) return;
                UI_Activity.Inst.close();
                UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                    UI_Shop.Inst.show(EShopType.skin);
                }));
            });

            (this.me.getChildByName('btn_treasure') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_PiPeiYuYue.Inst.enable) {
                    UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                    return;
                }
                if (UI_Lobby.Inst.locking) return;
                UI_Activity.Inst.close();
                UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                    UI_Treasure.Inst.show();
                }));
            })
        }

        public show() {
            this.enable = true;
        }

        public hide() {
            this.enable = false;
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Entrance', false);
        }
    }
}