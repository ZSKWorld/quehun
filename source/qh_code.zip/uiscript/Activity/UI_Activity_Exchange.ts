/**
* name 
*/
module uiscript{

	export class Cell {
		public me: Laya.Sprite;
		public father: UI_Activity_Exchange;

		public origin_rect: UIRect;
		public container_info:Laya.Sprite;
		public item_icon:Laya.Image;
		public item_name:Laya.Label;
		public item_count:Laya.Label;
		public btn_exchange:Laya.Button;
		public currency_icon:Laya.Image;
		public currency_count:Laya.Label;
		public left_count:Laya.Label;
		protected btn_icon:Laya.Button;
		public label_getted:Laya.Label;
		public btn_exchange10:Laya.Button;

		public id:number;
		public count:number;

		public constructor(me: Laya.Sprite, father:UI_Activity_Exchange) {
			this.me = me;
			this.father = father;
			this.me.visible = false;
			this.container_info = me.getChildByName('info') as Laya.Sprite;
			this.item_icon = this.container_info.getChildByName('item') as Laya.Image;
			this.origin_rect = UIRect.CreateFromSprite(this.item_icon);
			this.item_name = this.container_info.getChildByName('item_name') as Laya.Label;
			this.item_count = this.container_info.getChildByName('item_count') as Laya.Label;
			this.btn_exchange = this.container_info.getChildByName('btn_exchange') as Laya.Button;
			this.btn_exchange10 = this.container_info.getChildByName('btn_exchange10') as Laya.Button;
			let container_count:Laya.Sprite = this.container_info.getChildByName('count') as Laya.Sprite;
			this.currency_icon = container_count.getChildByName('icon') as Laya.Image;
			this.currency_count = container_count.getChildByName('need_count') as Laya.Label;
			this.left_count = container_count.getChildByName('left_count') as Laya.Label;
			this.btn_icon = this.container_info.getChildByName('btn_icon') as Laya.Button;
			this.btn_icon.clickHandler = Laya.Handler.create(this, () => {
				let d_activity_exchange = cfg.activity.exchange.get(this.id);
				if (d_activity_exchange) {
					UI_ItemDetail.Inst.show(d_activity_exchange.reward_id);
				}
			}, null, false);
			this.label_getted = this.container_info.getChildByName('getted') as Laya.Label;
		}

		public refresh() {
			let id = this.id;
			let d_activity_exchange = cfg.activity.exchange.get(id);

			this.container_info.visible = true;

			this.item_count.text = 'x' + d_activity_exchange.reward_count;
			let d_currency = cfg.item_definition.currency.get(d_activity_exchange.reward_id);
			if (d_currency) {
				game.LoadMgr.setImgSkin(this.item_icon, d_currency.icon_jpg);
				this.item_name.text = d_currency['name_' + GameMgr.client_language];
			}
			
			let d_item = cfg.item_definition.item.get(d_activity_exchange.reward_id);
			if (d_item) {
				game.LoadMgr.setImgSkin(this.item_icon, d_item.icon);
				this.item_name.text = d_item['name_' + GameMgr.client_language];
			}
			game.Tools.setItemIcon(this.item_icon, this.origin_rect, d_activity_exchange.reward_id);
			let d_item_consume = cfg.item_definition.item.get(d_activity_exchange.consume_id);
			let d_item_c = game.GameUtility.get_item_view(d_activity_exchange.consume_id);
			if (d_item_consume) {
				game.LoadMgr.setImgSkin(this.currency_icon, d_item_consume.icon_transparent ? d_item_consume.icon_transparent : d_item_consume.icon);
			}
			this.currency_count.text = d_activity_exchange.consume_count.toString();

			this.item_count.x = this.item_name.textField.textWidth * this.item_name.scaleX + this.item_name.x + 40;

			let count:number = this.count;
			let maxcount:number = d_activity_exchange.exchange_limit;
			if (count >= maxcount) count = 0;
			else count = maxcount - count;

			this.left_count.text = count + '/' + maxcount;
			if (GameMgr.client_language == 'en') {
				this.left_count.x = (this.left_count.parent as Laya.Sprite).width - 143;
			} else {
				this.left_count.x = (this.left_count.parent as Laya.Sprite).width - 120;
			}

			this.label_getted.visible = false;
			this.btn_exchange.visible = false;
			if (this.btn_exchange10) {
				this.item_count.x = Math.min(d_activity_exchange.reward_count == 1 ? 651 : 558, this.item_count.x);
				if (count >= 10 && UI_Bag.get_item_count(d_activity_exchange.consume_id) >= d_activity_exchange.consume_count * 10) {
					game.Tools.setGrayDisable(this.btn_exchange10, false);
					this.btn_exchange10.visible = true;
					this.btn_exchange10.clickHandler = Laya.Handler.create(this, () => {
						game.Tools.setGrayDisable(this.btn_exchange10, true);
						app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', { exchange_id: id, count: 10 }, (err, res) => {
							if (id != this.id) return;
							game.Tools.setGrayDisable(this.btn_exchange10, false);
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
							} else {
								this.count += 10;
								this.father.refreshCurrencyCount();
								Laya.timer.once(500, this, () => { this.father.refreshCurrencyCount(); });
								UI_Activity.onExchanged(id, 10);
								if (d_item && d_item.category == EItemCategory.fudai) {
									if (res['execute_reward']) {
										let rewards: Array<Object> = [];
										for (let i: number = 0; i < res['execute_reward'].length; i++) {
											rewards.push(res['execute_reward'][i]['reward']);
										}
										game.Tools.showRewards({ rewards: rewards }, null);
									}
								} else {
									let num = d_activity_exchange.reward_count * 10;
									UI_LightTips.Inst.show(game.Tools.strOfLocalization(2231, [this.item_name.text + ' x' + num]));
								}
								this.father.refreshAll();
							}
						});
					}, null, false);
				} else {
					this.btn_exchange10.visible = false;
				}
			}
			
			if (count != 0) {
				this.left_count.color = '#37b625';
				if (UI_Bag.get_item_count(d_activity_exchange.consume_id) < d_activity_exchange.consume_count) {
					this.btn_exchange.filters = [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
				} else {
					this.btn_exchange.filters = [];
				}
				this.btn_exchange.visible = true;
				this.btn_exchange.clickHandler = Laya.Handler.create(this, ()=>{
					if (UI_Bag.get_item_count(d_activity_exchange.consume_id) < d_activity_exchange.consume_count) {
						UI_Info_Small.Inst.show(game.Tools.strOfLocalization(2230, [d_item_c.name]));
					} else {
						game.Tools.setGrayDisable(this.btn_exchange, true);
						app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', {exchange_id: id}, (err, res) => {
							if (id != this.id) return;
							game.Tools.setGrayDisable(this.btn_exchange, false);
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
							} else {
								this.count++;
								this.father.refreshCurrencyCount();
								Laya.timer.once(500, this, ()=>{this.father.refreshCurrencyCount();});
								UI_Activity.onExchanged(id);
								if (d_item && d_item.category == EItemCategory.fudai) {
									if (res['execute_reward']) {
										let rewards:Array<Object> = [];
										for (let i:number = 0; i < res['execute_reward'].length; i++) {
											rewards.push(res['execute_reward'][i]['reward']);
										}
										game.Tools.showRewards({rewards: rewards}, null);
									}
								} else {
									UI_LightTips.Inst.show(game.Tools.strOfLocalization(2231, [this.item_name.text + ' ' + this.item_count.text]));
								}
								this.father.refreshAll();
								UI_Lobby.Inst.btns.refreshBagRedpoint();
							}
						});
					}
				}, null, false);
			} else {
				this.left_count.color = '#e3283c';
				this.btn_exchange.clickHandler = null;
				this.label_getted.visible = true;
				game.Tools.setGrayDisable(this.btn_exchange, true);
			}
		}

		public show(info:any) {
			this.id = info.exchange_id;
			this.count = info.count;
			this.refresh();
			this.me.visible = true;
		}
	}

	export class UI_Activity_Exchange extends UI_ActivityBase{

		protected root:Laya.Sprite;
		protected content:Laya.Panel;
		protected head:Laya.Image;
		protected cells:Array<Cell>;
		protected scrollbar:capsui.CScrollBar;

		protected total_h:number;

		//左边标题的名称
		constructor(name:string, view:Laya.View) {
			super(name, view);
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = this.root.getChildByName('content') as Laya.Panel;
			this.head = this.content.getChildByName('head') as Laya.Image;
			const task_templete = this.content.getChildByName('task_templete') as Laya.Sprite;
			task_templete.visible = false;
			this.cells = [];
			for (let i:number = 0; i < 30; i++) {
				this.cells.push(new Cell(task_templete.scriptMap['capsui.UICopy']['getNodeClone'](), this));
			}

			this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.scrollbar.init(new Laya.Handler(this, rate => {
				this.content.vScrollBar.value = this.content.vScrollBar.max * rate;
			}));
			this.content.vScrollBarSkin = '';
			this.content.vScrollBar.on('change', this, ()=>{
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.total_h);
			});
		}

		public refreshCurrencyCount() {

		}

		//刷新显示内容
		protected refreshView(datas) {
			let h:number = this.head.height + 15;
			for (let i:number = 0; i < this.cells.length; i++) {
				if (i < datas.length) {
					this.cells[i].show(datas[i]);
					this.cells[i].me.y = h;
					h += this.cells[i].me.height;
				} else {
					this.cells[i].me.visible = false;
				}
			}
			this.total_h = h;
			this.content.refresh();
			this.refreshCurrencyCount();

			this.scrollbar.reset();
			this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.total_h);
		}

		public refreshAll() {
			for (let i:number = 0; i < this.cells.length; i++) {
				if (this.cells[i].me.visible) {
					this.cells[i].refresh();
				}
			}
		}

	
	}
}