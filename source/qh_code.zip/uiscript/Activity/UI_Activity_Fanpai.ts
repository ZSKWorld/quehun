/**
* name 
*/
module uiscript {
	export interface IFanPaiTaskData {
		progress: number;
		target: number;
		state: EFanPaiTaskState;
	}

	export enum EFanPaiTaskState { //旧的state类型state0-不可领取，1-可以领取，2-已领取
		unComplete,
		canReceive,
		received
	}

	export const activityFanPaiTotalCount = 25;
	export const activityFanPaiSingleCount = 5;

	enum EGridState{
		CAN_FLIP = 0,
		FLIPPED_UNCOMPLETE = 1,
		FLIPPED_COMPLETED = 2,
		FLIPPED_REWARDED = 3
	}

	class UI_Activity_Fanpai_Grid extends UI_Component { 
		public static create(): Laya.Sprite {
			let sprite = new ui.lobby.activitys.acitivity_fanpai_gridUI();
			return sprite;
		}
		private root: Laya.Sprite;
		private animController: UI_FrameAnimationMgr<ui.lobby.activitys.acitivity_fanpai_gridUI>;
		private stateBg: Laya.Image;
		private taskContainer: Laya.Sprite;
		private taskValueProgress: Laya.Image;
		private taskCountLabel: Laya.Label;
		private taskSlideLabel: Laya.Label;
		private taskTotalLabel: Laya.Label;
		private rewardContainer: Laya.Sprite;
		private selectImage: Laya.Sprite;
		private btn: Laya.Button;
		private onClickHandler: Laya.Handler;
		private state: EGridState;
		private innerTaskId: number;

		
		public onCreate(): void {
			this.animController = new UI_FrameAnimationMgr<ui.lobby.activitys.acitivity_fanpai_gridUI>(this.me as ui.lobby.activitys.acitivity_fanpai_gridUI);
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.stateBg = this.root.getChildByName('bg') as Laya.Image;
			this.taskContainer = this.root.getChildByName('state_bg_task') as Laya.Sprite;
			let taskInfo = this.taskContainer.getChildByName('task_info').getChildByName('info') as Laya.Sprite;
			this.taskValueProgress = taskInfo.getChildByName('progress').getChildByName('va') as Laya.Image;
			this.taskCountLabel = taskInfo.getChildByName('count') as Laya.Label;
			this.taskSlideLabel = taskInfo.getChildByName('slide') as Laya.Label;
			this.taskTotalLabel = taskInfo.getChildByName('total') as Laya.Label;
			this.rewardContainer = this.root.getChildByName('state_bg_reward') as Laya.Sprite;
			this.selectImage = this.root.getChildByName('selectImg') as Laya.Sprite;
			this.btn = this.me.getChildByName('btn') as Laya.Button;
			this.btn.clickHandler = Laya.Handler.create(this, () => { 
				this.onClickHandler?.run();
			}, null, false);
			this.choosed = false;
			this.btn.on('mousedown', this, this.onMouseDown);
			this.btn.on('mouseup', this, this.onMouseUp);
			this.btn.on('mouseout', this,this.onMouseUp);
		}

		private onMouseDown(): void { 
			this.choosed = true;
		}

		private onMouseUp(): void { 
			this.choosed = false;
		}

		public set onClick(handler: Laya.Handler) { 
			this.onClickHandler = handler;
		}

		

		public get gridState(): EGridState { 
			return this.state;
		}

		public setTaskProgress(value:number,max:number) {
			this.taskCountLabel.text = value.toString();
			this.taskTotalLabel.text = max.toString();
			if (value > max) value = max;
			this.taskValueProgress.scaleX = value / max;
			//调整位置,让文本居中
			let _offset = this.taskCountLabel.trueWidth - this.taskTotalLabel.trueWidth;
			this.taskCountLabel.x = 23 + _offset / 2;
			this.taskSlideLabel.x = 14 + _offset / 2;
			this.taskTotalLabel.x = 34 + _offset / 2;
		}

		public changeGridState(state: EGridState, isDoAnim: boolean = false, onComplelte: Laya.Handler = null): void {
			if (this.state == state) { 
				onComplelte?.run();
				return;
			}
			this.state = state;
			this.animController.stopAllAnimations();
			this.root.visible = true;
			this.btn.visible = state != EGridState.FLIPPED_REWARDED;
			switch (state) {
				case EGridState.CAN_FLIP:
					this.stateBg.skin = game.Tools.localUISrc('myres/activity_fanpai/state0.png');
					this.animController.playAnim('can_flip');
					onComplelte?.run();
					break;
				case EGridState.FLIPPED_UNCOMPLETE:
					this.stateBg.skin = game.Tools.localUISrc('myres/activity_fanpai/state1.png');
					if (isDoAnim) {
						this.animController.playAnim('task_show', false, onComplelte);
					} else {
						this.animController.playAnim('flipped_uncomplete');
						onComplelte?.run();
					}
					break;
				case EGridState.FLIPPED_COMPLETED:
					this.stateBg.skin = game.Tools.localUISrc('myres/activity_fanpai/state2.png');
					this.animController.playAnim('flipped_completed');
					onComplelte?.run();
					break;
				case EGridState.FLIPPED_REWARDED:
					if (isDoAnim) {
						this.animController.playAnim('reward_hide', false, Laya.Handler.create(this, () => { 
							onComplelte?.run();
							this.root.visible = false;
						}));
					} else {
						this.animController.playAnim('flipped_rewarded');
						onComplelte?.run();
						this.root.visible = false;
					}
					break;
				default:
					break;
			}

		}

		public doShowAnim(onComplete: Laya.Handler = null): void { 
			this.animController.stopAllAnimations();
			//播放显示动画，有任务的播放任务出现的动画，有奖励的播放奖励出现的动画，其他的无动画
			if (this.state == EGridState.FLIPPED_UNCOMPLETE) { 
				this.animController.playAnim('task_show', false, onComplete);
			} else if (this.state == EGridState.FLIPPED_COMPLETED) {
				this.animController.playAnim('reward_show', false, Laya.Handler.create(this, () => { 
					onComplete?.run();
					this.animController.playAnim('reward_idle', true);
				}));
			} else {
				onComplete?.run();
			}
		}

		public set choosed(value: boolean) { 
			this.selectImage.visible = value;
		}

		public set taskId(value: number) { 
			this.innerTaskId = value;
		}

		public get taskId(): number { 
			return this.innerTaskId;
		}
		


		
		
	}

	export class UI_Activity_Fanpai extends UI_ActivityBase {

		public static Inst: UI_Activity_Fanpai = null;
		public static activity_id: number = 260190;
		private static count: number = 0;
		private static rewards: Object = {}; // id - 1
		private static task_data: Object = {}; // id - {id:number, counter:number, achieved:boolean, rewarded:boolean}
		private static last_init_time: number = -1;
		public static flip_free_task_count: number = 3;

		public static Init(need_refresh: boolean = false, check_free: boolean = false) {
			this.count = 0;
			this.rewards = {};
			this.last_init_time = Math.floor(game.Tools.getServerTime() / 1000);
			app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchActivityFlipInfo, {
				activity_id: this.activity_id
			}, (err, res) => {
				if (err || res['error']) {

				} else {
					if (res['count']) {
						this.count = res['count'];
					}
					if (res['rewards']) {
						for (let i: number = 0; i < res['rewards'].length; i++) {
							this.rewards[res['rewards'][i]] = 1;
						}
					}
					if (this.Inst && need_refresh) {
						this.Inst.refreshAll();
					}
				}
			});
			let task_id = cfg.activity.flip_info.get(this.activity_id).init_task_list
			if (check_free && !this.task_data[task_id]) {
				this.flipFreeTask(task_id);
			}
		}

		/**
		 * 请求翻牌次数信息
		 */
		public static requestCountInfo() {
			app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchActivityFlipInfo, {
				activity_id: this.activity_id
			}, (err, res) => {
				if (err || res['error']) {

				} else {
					if (res['count']) {
						this.count = res['count'];
						if (UI_Activity_Fanpai.Inst && UI_Activity_Fanpai.Inst.enable) {
							UI_Activity_Fanpai.Inst.refreshCountLabel();
						}
					}
				}
			});
		}

		public static flipFreeTask(task_id: string) {
			UI_Activity_Fanpai.flip_free_task_count--;
			if (UI_Activity_Fanpai.flip_free_task_count < 0) return;
			app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.receiveActivityFlipTask, {
				task_id: task_id
			}, (err, res) => {
				if (err || res['error']) {
					UI_Activity_Fanpai.flipFreeTask(task_id);
				} else {
					UI_Activity_Fanpai.count = res.count;
					UI_Activity_Fanpai.task_data[task_id] = {
						id: Number(task_id),
						counter: 0,
						achieved: false,
						rewarded: false
					}
				}
			});
		}
		public static need_refresh(): boolean {
			return !game.Tools.isPassedRefreshTimeServer(this.last_init_time);
		}
		public static onTaskDataUpdate(msg) {
			if (!msg) return;
			let lst = msg;
			for (let i: number = 0; i < lst.length; i++) {
				let d = lst[i];
				this.task_data[d.id.toString()] = d;
			}
		}

		public static onRewardGet(flip_task_id: number) {
			let d_flip = cfg.activity.flip_task.get(flip_task_id);
			if (d_flip.matrix_x == activityFanPaiSingleCount || d_flip.matrix_y == activityFanPaiSingleCount) {
				this.rewards[flip_task_id] = 1;
			} else {
				if (this.task_data[flip_task_id]) {
					this.task_data[flip_task_id].rewarded = true;
				}
			}
			if (UI_Activity_Fanpai.Inst && UI_Activity_Fanpai.Inst.enable) {
				
				let grid = UI_Activity_Fanpai.Inst.getMidGridByTaskId(flip_task_id);
				if (grid) { 
					UI_Activity_Fanpai.Inst.locking = true;
					grid.changeGridState(EGridState.FLIPPED_REWARDED, true, Laya.Handler.create(UI_Activity_Fanpai.Inst, () => {
						UI_Activity_Fanpai.Inst.locking = false;
						UI_Activity_Fanpai.Inst.refreshAll();
					}));
				} else {
					UI_Activity_Fanpai.Inst.refreshAll();
				}
				// if (d_flip.is_reward == 0) {
				// 	UI_Activity_Fanpai.Inst.check_cg_show();
				// }
			}
			UI_Activity.Inst.refresh_redpoint();
			UI_Lobby.Inst.top.refreshRedpoint();
			UI_Activity.Inst.freshGetAllBtn();
		}

		public static onRewardsGet(flip_task_ids: Array<number>) { 
			for (let i: number = 0; i < flip_task_ids.length; i++) {
				let flip_task_id = flip_task_ids[i];
				let d_flip = cfg.activity.flip_task.get(flip_task_id);
				if (d_flip.matrix_x == activityFanPaiSingleCount || d_flip.matrix_y == activityFanPaiSingleCount) {
					this.rewards[flip_task_id] = 1;
				} else {
					if (this.task_data[flip_task_id]) {
						this.task_data[flip_task_id].rewarded = true;
					}
				}
				
			}
			if (UI_Activity_Fanpai.Inst && UI_Activity_Fanpai.Inst.enable) {
				// UI_Activity_Fanpai.Inst.refresh();
				UI_Activity_Fanpai.Inst.doRewardsAnim(flip_task_ids, Laya.Handler.create(UI_Activity_Fanpai.Inst, () => { 
					UI_Activity_Fanpai.Inst.refreshAll();
				}));
			}
			UI_Activity.Inst.refresh_redpoint();
			UI_Lobby.Inst.top.refreshRedpoint();
			UI_Activity.Inst.freshGetAllBtn();
		}

		// state: 0-不可领取，1-可以领取，2-已领取
		public static rewardState(task_id: number): number {
			let d_table_flip = cfg.activity.flip_task.get(task_id);
			if (!d_table_flip) return 0;
			if (d_table_flip.matrix_x == activityFanPaiSingleCount && d_table_flip.matrix_y == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return 2;
				let count: number = 0;
				for (let k in this.task_data) {
					if (!this.task_data[k].achieved) break;
					count++;
				}
				if (count != activityFanPaiTotalCount) return 0;
				else return 1;
			} else if (d_table_flip.matrix_x == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return 2;
				let _mask: number = 0;
				for (let k in this.task_data) {
					if (!this.task_data[k].achieved) continue;
					let d = cfg.activity.flip_task.get(parseInt(k));
					if (d.matrix_y == d_table_flip.matrix_y) {
						_mask |= 1 << d.matrix_x;
					}
				}
				if (_mask != (1 << activityFanPaiSingleCount) - 1) {
					return 0;
				} else {
					return 1;
				}
			} else if (d_table_flip.matrix_y == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return 2;
				let _mask: number = 0;
				for (let k in this.task_data) {
					if (!this.task_data[k].achieved) continue;
					let d = cfg.activity.flip_task.get(parseInt(k));
					if (d.matrix_x == d_table_flip.matrix_x) {
						_mask |= 1 << d.matrix_y;
					}
				}
				if (_mask != (1 << activityFanPaiSingleCount) - 1) {
					return 0;
				} else {
					return 1;
				}
			} else {
				let d = this.task_data[task_id.toString()];
				if (!d) return 0;
				if (d.rewarded) return 2;
				if (d.achieved) return 1;
				return 0;
			}
		}

		public static getTaskData(task_id: number): IFanPaiTaskData {
			let d_table_flip = cfg.activity.flip_task.get(task_id);
			if (!d_table_flip) return null;
			if (d_table_flip.matrix_x == activityFanPaiSingleCount && d_table_flip.matrix_y == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return {
					progress: activityFanPaiTotalCount,
					target: activityFanPaiTotalCount,
					state: EFanPaiTaskState.received
				};
				let progress: number = 0;
				for (let k in this.task_data) {
					if (this.task_data[k].achieved) {
						progress++;
					};
				}
				return {
					progress,
					target: activityFanPaiTotalCount,
					state: progress == activityFanPaiTotalCount ? EFanPaiTaskState.canReceive : EFanPaiTaskState.unComplete
				}
			} else if (d_table_flip.matrix_x == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return {
					progress: activityFanPaiSingleCount,
					target: activityFanPaiSingleCount,
					state: EFanPaiTaskState.received
				};
				let progress: number = 0;
				for (let k in this.task_data) {
					if (!this.task_data[k].achieved) continue;
					let d = cfg.activity.flip_task.get(parseInt(k));
					if (d.matrix_y == d_table_flip.matrix_y) {
						progress++;
					}
				}
				return {
					progress,
					target: activityFanPaiSingleCount,
					state: progress == activityFanPaiSingleCount ? EFanPaiTaskState.canReceive : EFanPaiTaskState.unComplete
				}
			} else if (d_table_flip.matrix_y == activityFanPaiSingleCount) {
				if (this.rewards[task_id.toString()]) return {
					progress: activityFanPaiSingleCount,
					target: activityFanPaiSingleCount,
					state: EFanPaiTaskState.received
				};
				let progress: number = 0;
				for (let k in this.task_data) {
					if (!this.task_data[k].achieved) continue;
					let d = cfg.activity.flip_task.get(parseInt(k));
					if (d.matrix_x == d_table_flip.matrix_x) {
						progress++;
					}
				}
				return {
					progress,
					target: activityFanPaiSingleCount,
					state: progress == activityFanPaiSingleCount ? EFanPaiTaskState.canReceive : EFanPaiTaskState.unComplete
				}
			} else {
				let d = this.task_data[task_id.toString()];
				if (!d) return null;
				let state = EFanPaiTaskState.unComplete;
				if (d.rewarded) {
					state = EFanPaiTaskState.received;
				} else if (d.achieved) {
					state = EFanPaiTaskState.canReceive;
				}
				let _base_task_id = d_table_flip.base_task_id;
				let d_table_task = cfg.events.base_task.get(_base_task_id);
				let target: number = d_table_task.target;
				return {
					progress: d.counter || 0,
					target,
					state
				}
			}
		}

		private root: Laya.Sprite;
		private btns: Laya.Sprite;
		private bg: Laya.Image;

		private label_count_fan: Laya.Label;
		private btn_hs: Array<Laya.Button> = [];
		private btn_vs: Array<Laya.Button> = [];
		private btn_all: Laya.Button;
		private container_mid: Laya.Sprite;
		private btn_mids: Array<UI_Activity_Fanpai_Grid> = [];
		private btnFilpAll: Laya.Button;
		// private btn_show_cg: Laya.Button;

		private ids_mid: Object = {}; // pos-id
		private ids_h: Object = {};
		private ids_v: Object = {};
		private id_all: number;
		private locking: boolean = false;
		private showAnimTime: number = 250;
		private lastShowTime: number = 0;

		//左边标题的名称
		constructor() {
			super(cfg.activity.activity.get(UI_Activity_Fanpai.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_fanpaiUI());
			UI_Activity_Fanpai.Inst = this;
		}

		public getId(): number {
			return UI_Activity_Fanpai.activity_id;
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen(): boolean {
			return UI_Activity.activity_is_running(UI_Activity_Fanpai.activity_id);
		}

		//活动是否要显示小红点
		public haveRedPoint(): boolean {
			if (UI_Activity_Fanpai.count > 0) {
				for (let id in this.ids_mid) {
					if (!UI_Activity_Fanpai.task_data[id]) return true;
				}
			}
			for (let id in this.ids_mid) {
				if (UI_Activity_Fanpai.rewardState(this.ids_mid[id]) == 1) {
					return true
				}
			}
			for (let id in this.ids_h) {
				if (UI_Activity_Fanpai.rewardState(this.ids_h[id]) == 1) {
					return true
				}
			}
			for (let id in this.ids_v) {
				if (UI_Activity_Fanpai.rewardState(this.ids_v[id]) == 1) {
					return true
				}
			}
			if (UI_Activity_Fanpai.rewardState(this.id_all) == 1) {
				return true
			}

			return false;
		}

		public haveGetReward(): boolean { 
			for (let id in this.ids_mid) {
				if (UI_Activity_Fanpai.rewardState(this.ids_mid[id]) == 1) {
					return true;
				}
			}
			for (let id in this.ids_h) {
				if (UI_Activity_Fanpai.rewardState(this.ids_h[id]) == 1) {
					return true;
				}
			}
			for (let id in this.ids_v) {
				if (UI_Activity_Fanpai.rewardState(this.ids_v[id]) == 1) {
					return true;
				}
			}
			if (UI_Activity_Fanpai.rewardState(this.id_all) == 1) {
				return true;
			}
			return false;
		}

		//活动是否要弹出来
		public need_popout(): boolean {
			let d = cfg.activity.activity.get(UI_Activity_Fanpai.activity_id);
			if (d && d.need_popout) return true;
			return false;
		}

		public onCreate() {
			cfg.activity.flip_task.forEach(x => {
				if (x.activity_id != UI_Activity_Fanpai.activity_id) return;
				if (x.matrix_x == activityFanPaiSingleCount && x.matrix_y == activityFanPaiSingleCount) {
					this.id_all = x.id;
				} else if (x.matrix_x == activityFanPaiSingleCount) {
					this.ids_h[x.matrix_y.toString()] = x.id;
				} else if (x.matrix_y == activityFanPaiSingleCount) {
					this.ids_v[x.matrix_x.toString()] = x.id;
				} else {
					this.ids_mid[(x.matrix_y * activityFanPaiSingleCount + x.matrix_x).toString()] = x.id;
				}
			});

			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.btns = this.root.getChildByName('btns') as Laya.Panel;
			this.bg = this.root.getChildByName('bg') as Laya.Image;
			//设置头部图
			game.LoadMgr.setImgSkin(this.bg, cfg.activity.activity_banner.get(this.getId()).banner_big);
			this.label_count_fan = this.root.getChildByName('count_fan') as Laya.Label;
			// this.btn_show_cg = this.content.getChildByName('show_cg') as Laya.Button;
			// this.btn_show_cg.visible = false;
			// this.btn_show_cg.clickHandler = new Laya.Handler(this, () => {
			// 	UI_Activity_Guoping_CG.Inst.show();
			// });

			if (GameMgr.client_language == 'en') {
				this.label_count_fan.x -= 40;
			} else if (GameMgr.client_language == 'kr') {
				this.label_count_fan.x = 270;
				// this.label_count_fan.y = 443;
			}
			this.btn_hs = [];
			this.btn_vs = [];
			for (let i: number = 0; i < activityFanPaiSingleCount; i++) {
				this.btn_hs.push(this.btns.getChildByName('btn_h' + i) as Laya.Button);
				this.btn_vs.push(this.btns.getChildByName('btn_v' + i) as Laya.Button);
				this.btn_hs[i].clickHandler = new Laya.Handler(this, () => {
					if (this.locking) {
						return;
					}
					let task_id: number = this.ids_h[i.toString()];
					UI_Activity_Fanpai_Task.Inst.show(task_id, UI_Activity_Fanpai.rewardState(task_id));
				});
				this.btn_vs[i].clickHandler = new Laya.Handler(this, () => {
					if (this.locking) {
						return;
					}
					let task_id: number = this.ids_v[i.toString()];
					UI_Activity_Fanpai_Task.Inst.show(task_id, UI_Activity_Fanpai.rewardState(task_id));
				});
			}
			this.btn_all = this.btns.getChildByName('btn_all') as Laya.Button;
			this.btn_all.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) {
					return;
				}
				let task_id: number = this.id_all;
				UI_Activity_Fanpai_Task.Inst.show(task_id, UI_Activity_Fanpai.rewardState(task_id));
			});
			this.btnFilpAll = this.root.getChildByName('btn_flip_all') as Laya.Button;
			this.btnFilpAll.clickHandler = new Laya.Handler(this, this.onClickFlipAll);
			this.btn_mids = [];
			this.container_mid = this.root.getChildByName('container_mid') as Laya.Sprite;
			// let mid_templete: Laya.Button = this.container_mid.getChildByName('btn_templete') as Laya.Button;
			// mid_templete.visible = false;
			for (let i: number = 0; i < activityFanPaiSingleCount; i++) {
				for (let j: number = 0; j < activityFanPaiSingleCount; j++) {
					let sprite = new ui.lobby.activitys.acitivity_fanpai_gridUI() as Laya.Sprite;
					this.container_mid.addChild(sprite);
					sprite.visible = true;
					sprite.x = (116 + 2) * j;
					sprite.y = (116 + 2) * i;
					let grid = new UI_Activity_Fanpai_Grid(sprite);
					let task_id: number = this.ids_mid[(i * activityFanPaiSingleCount + j).toString()];
					grid.taskId = task_id;
					this.btn_mids.push(grid);
					grid.onClick = new Laya.Handler(this, () => {
						if (this.locking) return;
						if (UI_Activity_Fanpai.task_data[task_id]) {
							let count: number = 0;
							if (UI_Activity_Fanpai.task_data[task_id]) {
								count = UI_Activity_Fanpai.task_data[task_id].counter;
							}
							UI_Activity_Fanpai_Task.Inst.show(task_id, UI_Activity_Fanpai.rewardState(task_id), count);
						} else {
							if (UI_Activity_Fanpai.count <= 0) {
								UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(2849));
								UI_SecondConfirm.Inst.setBtnState(true, true);
							} else {
								UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(2848), Laya.Handler.create(this, () => {
									sprite.mouseEnabled = false;
									this.locking = true;
									app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.receiveActivityFlipTask, {
										task_id: task_id
									}, (err, res) => {
										sprite.mouseEnabled = true;
										this.locking = false;
										if (err || res['error']) {
											UIMgr.Inst.showNetReqError(game.ERequest.receiveActivityFlipTask, err, res);
										} else {
											UI_Activity_Fanpai.count = res.count;
											UI_Activity_Fanpai.task_data[task_id.toString()] = {
												id: task_id,
												counter: 0,
												achieved: false,
												rewarded: false
											}
											if (this.enable) {
												this.refreshSideGrid();
												this.refreshCountLabel()
												UI_Activity_Fanpai_Task.Inst.show(task_id, 0, 0);
												UI_Activity_Fanpai_Task.Inst.onClose = Laya.Handler.create(this, () => { 
													this.refreshMidGrid();
													grid.doShowAnim(Laya.Handler.create(this, () => {
														this.locking = false;
													}));
												});
												this.locking = true;
												
												
											}
											this.freshRedPoint();
										}
									});
								}));
								UI_SecondConfirm.Inst.setBtnState(true, true);
							}
						}
					});
					// let _bmask: Laya.Sprite = t.getChildByName('bmask') as Laya.Sprite;
					// _bmask.alpha = 0;
					// t.on('mousedown', this, () => {
					// 	_bmask.alpha = 0;
					// 	Laya.Tween.to(_bmask, { alpha: 0.5 }, 50, null, null, 0, true, true);
					// });
					// t.on('mouseup', this, () => {
					// 	Laya.Tween.to(_bmask, { alpha: 0 }, 50, null, null, 0, true, true);
					// });
					// t.on('mouseout', this, () => {
					// 	Laya.Tween.to(_bmask, { alpha: 0 }, 50, null, null, 0, true, true);
					// });
				}
			}
		}

		public show() {
			this.enable = true;
			this.refreshAll();
			this.btn_mids.forEach(mid => { 
				mid.choosed = false;
			});
			if (UI_Activity_Fanpai.need_refresh()) {
				UI_Activity_Fanpai.Init(true);
			}
			this.locking = true;
			//遍历中间的格子，播放显示动画
			for (let i: number = 0; i < this.btn_mids.length; i++) { 
				let grid: UI_Activity_Fanpai_Grid = this.btn_mids[i];
				grid.doShowAnim();
			}
			Laya.timer.once(this.showAnimTime, this, () => {
				this.locking = false;
			});


			
		}

		public refreshAll() {
			this.refreshCountLabel();
			this.refreshSideGrid();
			this.refreshMidGrid();
		}

		private refreshCountLabel() {
			this.label_count_fan.text = UI_Activity_Fanpai.count.toString();
		}

		private refreshSideGrid() {
			// 横向
			for (let i: number = 0; i < activityFanPaiSingleCount; i++) {
				let _btn: Laya.Button = this.btn_hs[i];
				let _task_id: number = this.ids_h[i];
				let _state: number = UI_Activity_Fanpai.rewardState(_task_id);
				if (_state == 2) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/getted0.png');
				} else if (_state == 1) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/get0.png');
				} else {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/look0.png');
				}
			}
			// 纵向
			for (let i: number = 0; i < activityFanPaiSingleCount; i++) {
				let _btn: Laya.Button = this.btn_vs[i];
				let _task_id: number = this.ids_v[i];
				let _state: number = UI_Activity_Fanpai.rewardState(_task_id);
				if (_state == 2) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/getted0.png');
				} else if (_state == 1) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/get0.png');
				} else {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/look0.png');
				}
			}
			// 右下角
			{
				let _btn: Laya.Button = this.btn_all;
				let _task_id: number = this.id_all;
				let _state: number = UI_Activity_Fanpai.rewardState(_task_id);
				if (_state == 2) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/getted1.png');
				} else if (_state == 1) {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/get1.png');
				} else {
					_btn.skin = game.Tools.localUISrc('myres/activity_fanpai/look1.png');
				}
			}
		}

		private refreshMidGrid() { 
			for (let y: number = 0; y < activityFanPaiSingleCount; y++) {
				for (let x: number = 0; x < activityFanPaiSingleCount; x++) {
					let pos: number = y * activityFanPaiSingleCount + x;
					let _task_id: number = this.ids_mid[pos.toString()];
					let _task_data = UI_Activity_Fanpai.task_data[_task_id.toString()];
					let midGrid: UI_Activity_Fanpai_Grid = this.btn_mids[pos];
					if (_task_data) {
						if (_task_data.rewarded) {
							midGrid.changeGridState(EGridState.FLIPPED_REWARDED);
						} else if (_task_data.achieved) {
							midGrid.changeGridState(EGridState.FLIPPED_COMPLETED);
						} else {
							let d_table_flip = cfg.activity.flip_task.get(_task_id);
							let _base_task_id = d_table_flip.base_task_id;
							let d_table_task = cfg.events.base_task.get(_base_task_id);
							let now_count: number = _task_data.counter;
							let total_count: number = d_table_task.target;
							midGrid.changeGridState(EGridState.FLIPPED_UNCOMPLETE);
							midGrid.setTaskProgress(now_count, total_count);

						}
					} else {
						midGrid.changeGridState(EGridState.CAN_FLIP);
					}
				}
			}
		}

		public hide() {
			this.enable = false;
		}

		public onEnable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Fanpai', true);
			Laya.timer.loop(1000, this, this.listenerRefresh);
		}

		public onDisable(): void {
			game.TempImageMgr.setUIEnable('UI_Activity_Fanpai', false);
			let atlas_root = 'res/atlas/';
			if (GameMgr.client_language != 'chs') {
				atlas_root += GameMgr.client_language + '/';
			}
			Laya.loader.clearTextureRes(atlas_root + 'myres/activiy_fanpai.atlas');
			Laya.timer.clearAll(this);
		
		}


		public isShowGetAll(): boolean {
			return this.haveGetReward();
		}
		
		public onClickGetAll(): void {
			if (this.locking) {
				return;
			}
			let task_ids: Array<number> = this.getAllCanComplete();
			if (task_ids.length <= 0) {
				return;
			}
			this.completeAllTasks(task_ids);
		}

		private onClickFlipAll(): void {
			if (this.locking) {
				return;
			}
			let task_ids: Array<number> = this.getAllCanFlip();
			//所有任务已翻开
			if (task_ids.length <= 0) {
				UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(26010902));
				UI_SecondConfirm.Inst.setBtnState(true, true);
				return;
			}
			//没有次数
			if (UI_Activity_Fanpai.count <= 0) {
				UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(2849));
				UI_SecondConfirm.Inst.setBtnState(true, true);
				return;
			}
			this.setGridsChoosed(task_ids, true);
			UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(26010901), Laya.Handler.create(this, () => {
				this.filpTaskBatch(task_ids);
			}),Laya.Handler.create(this, () => {
				this.setGridsChoosed(task_ids, false);
			}));
			UI_SecondConfirm.Inst.setBtnState(true, true);
		}

		/**
		 * 获取所有可以翻的任务id
		 * @returns 
		 */
		private getAllCanFlip() {
			//从上到下，从左到右，返回count个可以翻的任务id
			let task_ids: Array<number> = [];
			for (let y: number = 0; y < activityFanPaiSingleCount; y++) {
				for (let x: number = 0; x < activityFanPaiSingleCount; x++) {
					let pos: number = y * activityFanPaiSingleCount + x;
					let _task_id: number = this.ids_mid[pos.toString()];
					if (!UI_Activity_Fanpai.task_data[_task_id]) {
						task_ids.push(_task_id);
						if (task_ids.length >= UI_Activity_Fanpai.count) {
							return task_ids;
						}
					}
				}
			}
			return task_ids;
		}

		private getAllCanComplete() { 
			//返回所有可以领取的任务id
			let task_ids: Array<number> = [];

			for (let id in this.ids_mid) {
				if (UI_Activity_Fanpai.rewardState(this.ids_mid[id]) == 1) {
					task_ids.push(this.ids_mid[id]);
				}
			}
			for (let id in this.ids_h) {
				if (UI_Activity_Fanpai.rewardState(this.ids_h[id]) == 1) {
					task_ids.push(this.ids_h[id]);
				}
			}
			for (let id in this.ids_v) {
				if (UI_Activity_Fanpai.rewardState(this.ids_v[id]) == 1) {
					task_ids.push(this.ids_v[id]);
				}
			}
			if (UI_Activity_Fanpai.rewardState(this.id_all) == 1) {
				task_ids.push(this.id_all);
			}
			return task_ids;
		}

		private filpTaskBatch(task_ids: Array<number>): void { 
			if (this.locking) {
				return;
			}
			this.locking = true;
			let req: game.IReqReceiveActivityFlipTaskBatch = {
				task_list: task_ids
			}
			app.Log.log("【Fanpai】request receiveActivityFlipTaskBatch:"+JSON.stringify(req));
			app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.receiveActivityFlipTaskBatch, req, (err, res) => {
				app.Log.log("【Fanpai】response receiveActivityFlipTaskBatch:" + JSON.stringify(res));
				this.locking = false;
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError(game.ERequest.receiveActivityFlipTaskBatch, err, res);
				} else {
					UI_Activity_Fanpai.count = res.count;
					for (let i: number = 0; i < task_ids.length; i++) {
						let task_id = task_ids[i];
						UI_Activity_Fanpai.task_data[task_id.toString()] = {
							id: task_id,
							counter: 0,
							achieved: false,
							rewarded: false
						}
					}		
					if (this.enable) {
						this.refreshAll();
						//所有翻开的格子播放翻开动画
						this.locking = true;
						this.setGridsChoosed(task_ids, false);
						for (let i: number = 0; i < task_ids.length; i++) {
							let task_id = task_ids[i];
							let grid: UI_Activity_Fanpai_Grid = this.getMidGridByTaskId(task_id);
							if (grid) {
								grid.doShowAnim();
							}
							
						}
						Laya.timer.once(this.showAnimTime, this, () => {
							this.locking = false;
						});
					}
					this.freshRedPoint();
				}
			});
		}

		private completeAllTasks(task_ids: Array<number>): void { 
			if (this.locking) {
				return;
			}
			let req: game.IReqCompleteActivityFlipTaskBatch = {
				task_list: task_ids
			}
			this.locking = true;
			app.Log.log("【Fanpai】request completeActivityFlipTaskBatch:"+JSON.stringify(req));
			app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeActivityFlipTaskBatch, req, (err, res:game.IResCompleteActivityFlipTaskBatch) => {
				this.locking = false;
				app.Log.log("【Fanpai】response completeActivityFlipTaskBatch:" + JSON.stringify(res));
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError(game.ERequest.completeActivityFlipTaskBatch, err, res);
				} else {
					let rewards = [];
					for (let index = 0; index < task_ids.length; index++) {
						let _task_id = task_ids[index];
						let d = cfg.activity.flip_task.get(_task_id);
						let s_rewards: string = d.reward;
						let reward_lst: Array<string> = s_rewards.split(',');
						for (let i: number = 0; i < reward_lst.length; i++) {
							let v = reward_lst[i].split('-');
							rewards.push({
								id: parseInt(v[0]),
								count: parseInt(v[1])
							});
						}
					}
					
					game.Tools.showRewards({ rewards: rewards }, null);
					UI_Activity_Fanpai.onRewardsGet(task_ids);
				}
			});
		}

		public freshRedPoint(): void { 
			UI_Activity.Inst.refresh_redpoint();
			UI_Lobby.Inst.top.refreshRedpoint();
			UI_Activity.Inst.freshGetAllBtn();
		}

		public getMidGridByTaskId(task_id: number): UI_Activity_Fanpai_Grid {
			let grid = this.btn_mids.find((g) => {
				return g.taskId == task_id;
			});
			return grid;
		}

		public setGridsChoosed(task_ids: Array<number>, choosed: boolean): void { 
			for (let index = 0; index < task_ids.length; index++) {
				let grid = this.getMidGridByTaskId(task_ids[index]);
				if (grid) {
					grid.choosed = choosed;
				}
			}
		}


		public doRewardsAnim(taskIds: Array<number>, onComplete: Laya.Handler = null): void { 
			this.locking = true;
			let needDoAnim = false;
			for (let index = 0; index < taskIds.length; index++) {
				const taskId = taskIds[index];
				let grid = this.getMidGridByTaskId(taskId);
				if (grid) {
					needDoAnim = true;
					grid.changeGridState(EGridState.FLIPPED_REWARDED,true);
				}
			}

			if (!needDoAnim) {
				this.locking = false;
				onComplete?.run();
			} else {
				Laya.timer.once(400, this, () => {
					this.locking = false;
					onComplete?.run();
				});
			}
		}

		private listenerRefresh() {
			if (this.enable) {
				let isSameDay = game.Tools.isPassedRefreshTimeServer(this.lastShowTime);
				if (!isSameDay) {
					this.lastShowTime = Math.floor(game.Tools.getServerTime() / 1000);
					//如果过了刷新时间，要弹窗刷新页面
					UI_Activity_Fanpai.requestCountInfo();
				}
			}
		}
		
	}
}