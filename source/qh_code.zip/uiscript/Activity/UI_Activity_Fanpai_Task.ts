/**
* name 
*/
module uiscript {
	export class UI_Activity_Fanpai_Task extends UIBase {

		public static Inst: UI_Activity_Fanpai_Task;

		constructor() {
			super(new ui.lobby.activitys.fanpai_popoutUI());
			UI_Activity_Fanpai_Task.Inst = this;
		}

		private btnMask: Laya.Button;
		private root: Laya.Sprite;
		private title: Laya.Label;
		private containerItems: Laya.Sprite;
		private iconRect: UIRect;
		private btnReceive: Laya.Button;
		private txtState: Laya.Label;
		private contianerTasks: Laya.Sprite;
		private locking: boolean;
		private taskId: number;
		private rewardState: number = 0; // state: 0-不可领取， 1-可领取， 2-已领取
		private onCloseHandler: Laya.Handler;

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.title = this.root.getChildByName('title') as Laya.Label;
			this.containerItems = this.root.getChildByName('container_items') as Laya.Sprite;
			this.iconRect = UIRect.CreateFromSprite(this.containerItems.getChildAt(0).getChildAt(0).getChildByName('icon') as Laya.Sprite);
			this.btnReceive = this.root.getChildByName('btn_confirm') as Laya.Button;
			this.btnReceive.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				if (this.rewardState != 1) return;
				this.hide();
				let _task_id: number = this.taskId;
				app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeActivityFlipTask, {
					task_id: _task_id
				}, (err, res) => {
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError(game.ERequest.completeActivityFlipTask, err, res);
					} else {
						let d = cfg.activity.flip_task.get(_task_id);
						let s_rewards: string = d.reward;
						let reward_lst: Array<string> = s_rewards.split(',');
						let rewards = [];
						for (let i: number = 0; i < reward_lst.length; i++) {
							let v = reward_lst[i].split('-');
							rewards.push({
								id: parseInt(v[0]),
								count: parseInt(v[1])
							});
						}
						game.Tools.showRewards({ rewards: rewards }, null);
						UI_Activity_Fanpai.onRewardGet(_task_id);
					}
				});
			});
			this.txtState = this.root.getChildByName('state') as Laya.Label;
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.hide();
			});
			this.btnMask = this.me.getChildByName('btn_mask') as Laya.Button;
			this.btnMask.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.hide();
			});
			this.contianerTasks = this.root.getChildByName('container_task') as Laya.Sprite;
			this.title.text = game.Tools.strOfLocalization(2846);
		}

		// state: 0-不可领取， 1-可领取， 2-已领取
		public show(taskId: number, rewardState: number, taskCount: number = 0) {
			this.locking = true;
			this.root.scale(1, 1);
			this.enable = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
				this.locking = false;
			}));
			Laya.Tween.to(this.btnMask, { alpha: 0.5 }, 150, Laya.Ease.quadInOut);
			this.taskId = taskId;
			this.rewardState = rewardState;
			let d_flip_table = cfg.activity.flip_task.get(taskId);
			let txtDesc = this.contianerTasks.getChildByName('task') as Laya.Label;
			if (d_flip_table.matrix_x == activityFanPaiSingleCount || d_flip_table.matrix_y == activityFanPaiSingleCount) {
				let delta: number = 0;
				if (d_flip_table.matrix_x == activityFanPaiSingleCount) delta += 1;
				if (d_flip_table.matrix_y == activityFanPaiSingleCount) delta += 2;
				// this.title.text = game.Tools.strOfLocalization(2847);
				txtDesc.text = game.Tools.strOfLocalization(2851 + delta);
				let info = UI_Activity_Fanpai.getTaskData(taskId);
				(this.contianerTasks.getChildByName('progress') as Laya.Label).text = game.Tools.strOfLocalization(4253) + ' ' + info.progress.toString() + '/' + info.target.toString();
				(this.contianerTasks.getChildByName('bar').getChildByName('val') as Laya.Sprite).scaleX = info.progress == 0 ? 0.001 : info.progress / info.target;
			} else {
				let d_base_task = cfg.events.base_task.get(d_flip_table.base_task_id);
				txtDesc.text = d_base_task['desc_' + GameMgr.client_language];
				if (taskCount > d_base_task.target) taskCount = d_base_task.target;
				(this.contianerTasks.getChildByName('progress') as Laya.Label).text = game.Tools.strOfLocalization(4253) + ' ' + taskCount.toString() + '/' + d_base_task.target.toString();
				(this.contianerTasks.getChildByName('bar').getChildByName('val') as Laya.Sprite).scaleX = taskCount == 0 ? 0.001 : taskCount / d_base_task.target;
				// this.title.text = game.Tools.strOfLocalization(2846);
			}

			txtDesc.align = txtDesc.textField.textHeight < 50 ? 'center' : 'left';
			txtDesc.height = txtDesc.textField.textHeight > 100 ? 162 : (txtDesc.textField.textHeight > 50 ? 140 : 116);
			this.containerItems.y = txtDesc.textField.textHeight > 100 ? 83 : (txtDesc.textField.textHeight > 50 ? 107 : 130);
			this.txtState.visible = rewardState != 1;
			this.txtState.text = rewardState == 0 ? game.Tools.strOfLocalization(20042) : game.Tools.strOfLocalization(4252);
			(this.root.getChildByName('state_bg') as Laya.Image).visible = rewardState == 0;
			this.btnReceive.visible = rewardState == 1;
			{
				let s_rewards: string = d_flip_table.reward;
				let reward_lst: Array<string> = s_rewards.split(',');
				let span: Array<number> = [];
				for (let i: number = 0; i < this.containerItems.numChildren; i++) {
					let _cell: Laya.Sprite = this.containerItems.getChildAt(i) as Laya.Sprite;
					if (i < reward_lst.length) {
						let v = reward_lst[i].split('-');
						let _item_id: number = parseInt(v[0]);
						let _item_count: number = parseInt(v[1]);
						let btn: Laya.Button = _cell.getChildByName('btn') as Laya.Button;
						let lable_count: Laya.Label = btn.getChildByName('count') as Laya.Label;
						lable_count.text = _item_count.toString();
						btn.clickHandler = Laya.Handler.create(this, () => {
							UI_ItemDetail.Inst.show(_item_id);
						}, null, false);
						game.Tools.setItemIcon(btn.getChildByName('icon') as Laya.Image, this.iconRect, _item_id, 'UI_Activity_Fanpai_Task', true);
						_cell.visible = true;
						_cell.y = 147;
						i == 0 ? span.push(0) : span.push(50);
					} else {
						_cell.visible = false;
					}
				}
				game.Tools.child_align_center(this.containerItems, span);
			}
		}

		public hide() {
			this.locking = true;
			Laya.Tween.to(this.btnMask, { alpha: 0 }, 150, Laya.Ease.quadInOut);
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
				this.locking = false;
				this.enable = false;
				this.onCloseHandler?.run();
			}));
		}

		public onEnable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Fanpai_Task', true);
		}

		public onDisable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Fanpai_Task', false);
		}

		public set onClose(handler: Laya.Handler) { 
			this.onCloseHandler = handler;
		}
	}
}