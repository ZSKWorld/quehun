/**
* name 
*/
module uiscript{
	export class UI_Activity_Guoping_CG extends UIBase {

		public static Inst:UI_Activity_Guoping_CG;
        private locking:boolean = false;
		constructor() {
			super(new ui.lobby.activitys.activity_guoqing_cgUI());
			UI_Activity_Guoping_CG.Inst = this;
		}

		public onCreate() {
			game.LoadMgr.setImgSkin(this.me.getChildAt(1) as Laya.Image, 'myres/activity_fanpai/cg1.jpg');
            (this.me.getChildAt(2) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if(this.locking) return;
                this.hide();
            });
		}

		// state: 0-不可领取， 1-可领取， 2-已领取
		public show() {
			this.locking = true;
			this.enable = true;
			UIBase.anim_alpha_in(this.me, {}, 300, 0, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));

		}

		public hide() {
			this.locking = true;
			UIBase.anim_alpha_out(this.me, {}, 300, 0, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
		}

	}
}