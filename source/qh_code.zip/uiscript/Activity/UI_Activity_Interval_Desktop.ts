/**
* 纯入口用，每次替换图片，活动id和按钮事件，并替换图片
*/
module uiscript {
    export class UI_Activity_Interval_Desktop extends UI_ActivityBase {
        public static Inst: UI_Activity_Interval_Desktop = null;
        public static activity_id: number = 230143; // 每次修改
        public getId(): number {
			return UI_Activity_Interval_Desktop.activity_id;
        }

        private imgRule: Laya.Image;
        private spriteTime: Laya.Sprite;
        private labelTime: Laya.Label;
        private labelTimeEnd: Laya.Label;
        private modeId: number; // 跳转使用的id
        private showIntervalIndex: number; // 当前显示的index
        

        //左边标题的名称
        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Interval_Desktop.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_interval_desktopUI());
            UI_Activity_Interval_Desktop.Inst = this;
        }

        //活动是否开放中，不开放的活动不会显示
        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Interval_Desktop.activity_id];
        }

        //活动是否要显示小红点
        public haveRedPoint(): boolean {
            return false;
        }

        //活动是否要弹出来
        public need_popout(): boolean { return false; }

        public onCreate() {
            this.imgRule = this.me.getChildByName('img') as Laya.Image;
            this.spriteTime = this.me.getChildByName('time') as Laya.Sprite;
            this.labelTime = this.spriteTime.getChildByName('time') as Laya.Label;
            this.labelTimeEnd = this.spriteTime.getChildByName('end') as Laya.Label;
            (this.me.getChildByName('btn_rule') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_Lobby.Inst.locking) return;
                   
                    UI_Create_Room_Rule.Inst.showMatchMode(this.modeId, this.modeId);
                }

            });
                
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_Lobby.Inst.locking) return;
                    
                    let showIntervalIndex = UI_Lobby.get_activity_interval(UI_Activity_Interval_Desktop.activity_id);
                    let group = cfg.activity.activity_desktop.getGroup(UI_Activity_Interval_Desktop.activity_id);
                    for (let data of group) {
                        if (data.interval == showIntervalIndex) {
                            let desktopData = cfg.desktop.matchmode.get(data.desktop_id);
                            if (desktopData) {
                                UI_Activity.Inst.close();
                                UI_Lobby.Inst.onActivityIntervalJump(desktopData.room);
                                return;
                            }
                        }
                    }
                }

            });
            let head = this.me.getChildByName('head') as Laya.Image;
            let head_url = cfg.activity.activity_banner.get(UI_Activity_Interval_Desktop.activity_id).banner_big;
            game.LoadMgr.setImgSkin(head, head_url);
        }

        public show() {
            this.modeId = 0;
            this.enable = true;
            this.showIntervalIndex = UI_Lobby.get_activity_interval(UI_Activity_Interval_Desktop.activity_id);
            let group = cfg.activity.activity_desktop.getGroup(UI_Activity_Interval_Desktop.activity_id);
            for (let data of group) {
                if (data.interval == this.showIntervalIndex) {
                    let desktopData = cfg.desktop.matchmode.get(data.desktop_id);
                    if (desktopData) {
                        game.LoadMgr.setImgSkin(this.imgRule, desktopData.interval_image);
                        this.modeId = data.desktop_id;
                        this.refreshTime();
                        return;
                    }
                    
                }
            }

        }

        private refreshTime() { 
            let t = game.Tools.getServerTime();
			let _update_time = UI_Lobby.activity_interval_update_time;
			t = Math.ceil(t / 1000);
			t += 3 * 3600 + 3 * 24 * 3600;

			_update_time = Math.ceil(_update_time / 1000);
			_update_time += 3 * 3600 + 3 * 24 * 3600;

            if (Math.floor(_update_time / (7 * 24 * 3600)) != Math.floor(t / (7 * 24 * 3600))) {
                // 如果距离上次刷新跨周了，则直接
                this.labelTime.text = '0';
                this.labelTimeEnd.text = game.Tools.strOfLocalization(2022)
            } else { 
                t = t % (7 * 24 * 3600);
                t = 7 * 24 * 3600 - t;

                if (t < 3600) {
                    t = Math.floor(t / 60);
                    this.labelTime.text = t.toString();
                    this.labelTimeEnd.text = game.Tools.strOfLocalization(2020);
                } else if (t < 24 * 3600) {
                    t = Math.floor(t / 3600);
                    this.labelTime.text = t.toString();
                    this.labelTimeEnd.text = game.Tools.strOfLocalization(2021);
                } else {
                    t = Math.floor(t / 24 / 3600);
                    this.labelTime.text = t.toString();
                    this.labelTimeEnd.text = game.Tools.strOfLocalization(2022);
                }
            }
			game.Tools.child_align_center(this.spriteTime, [3, 3]);
        }
        public hide() {
            this.enable = false;
        }
    }
}