/**
* 复活币
*/
module uiscript {


	

	/**
	 * 复活币活动
	 */
	export class UI_Activity_Jiuji extends UI_ActivityBase {

		public static Inst: UI_Activity_Jiuji = null;
		public static has_gained: boolean = false;

		public static Init() {
			if (!GameMgr.Inst.use_fetch_info) {
				app.NetAgent.sendReq2Lobby('Lobby', 'fetchReviveCoinInfo', {}, (err, res) => {
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('fetchReviveCoinInfo', err, res);
					} else {
						this.has_gained = res['has_gained'];
					}
				});
			}

			app.NetAgent.addListener2Lobby('NotifyReviveCoinUpdate', Laya.Handler.create(this, msg => {
				this.has_gained = msg['has_gained'];
				if (this.Inst && this.Inst.enable) {
					this.Inst.refresh();
				}
			}, null, false));
		}

		// 23/12/04 新增 fetch接口
		public static onFetchSuccess(res: any) {
			if (!res['receive_coin_info']) return;
			this.has_gained = res['receive_coin_info']['has_gained'];
		}

		public root: Laya.Sprite;
		public title: Laya.Label;
		public desc: Laya.Label;
		public task: UI_Activity_TaskItem;
		private btn_cd: number = 0;
		public getId(): number {
			return 3;
		}

		constructor() {
			super(game.Tools.strOfLocalization(2232), new ui.lobby.activitys.activity_jiujiUI());
		}

		public isopen(): boolean { return true; }

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.title = this.root.getChildByName('title') as Laya.Label;
			this.desc = this.root.getChildByName('desc') as Laya.Label;
			let container_task: Laya.Sprite = this.root.getChildByName('task') as Laya.Sprite;
			this.task = new UI_Activity_TaskItem(container_task);

			this.task.getBtnClickHandler =Laya.Handler.create(this, () => {
				if (this.btn_cd > Laya.timer.currTimer) return;
				this.btn_cd = Laya.timer.currTimer + 1000;
				app.NetAgent.sendReq2Lobby('Lobby', 'gainReviveCoin', {}, (err, res) => {
					this.btn_cd = 0;
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('gainReviveCoin', err, res);
					} else {
						this.task.getBtnVisible = false;
						this.task.alreadyGetVisible = true;
						UI_Activity_Jiuji.has_gained = true;
						game.Tools.showRewards({ rewards: [{ id: 100002, count: this.task.itemCount}] }, null);
					}
				});
			}, null, false);
			if (GameMgr.client_language == 'kr') {
				this.desc.leading = 3;
			}
		}

		public show() {
			this.me.visible = true;
			this.btn_cd = 0;
			this.refresh();
		}

		public hide() {
			this.me.visible = false;
		}

		private findData(): number {
			let id: number = 0;
			cfg.events.soscoin.forEach(value => {
				if (value.level_limit <= GameMgr.Inst.account_data['level']['id']) {
					id = value.id;
				}
				if (value.level3_limit <= GameMgr.Inst.account_data['level3']['id']) {
					id = value.id;
				}
			});
			return id;
		}

		public refresh() {
			let data = cfg.events.soscoin.get(this.findData());
			if (data) {
				
				
				if (data.gold_num < 1) {
					this.desc.text = data['desc_' + GameMgr.client_language];
					this.task.infoVisible = false;
				} else {
					this.task.taskDesc = data['desc_' + GameMgr.client_language];
					this.desc.text = '';
					this.task.infoVisible = true;
					this.task.itemId = 100002;
					this.task.itemCount = data.gold_num;
					if (UI_Activity_Jiuji.has_gained) {
						this.task.getBtnVisible = false;
						this.task.alreadyGetVisible = true;
					} else if (GameMgr.Inst.account_data['gold'] < data.gold_limit) {
						//当前金额小于领取金额，可以领取
						this.task.getBtnVisible = true;
						this.task.getBtnGray = false;
						this.task.getBtnEnable = true;
						this.task.alreadyGetVisible = false;
					} else {
						//当前金额大于领取金额，不可以领取
						this.task.getBtnVisible = true;
						this.task.getBtnGray = true;
						this.task.getBtnEnable = false;
						this.task.alreadyGetVisible = false;
					}
				}
			} else {
				//当前没有达到可以领取救济金的段位
				this.desc.text = game.Tools.strOfLocalization(2233);
				this.task.infoVisible = false;
				
			}
		}

	
	}
}