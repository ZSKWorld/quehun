/**
* name 
*/
module uiscript {
    interface iFriendGiftInfo {
        account_id: number;
        info: game.iFriendInfo;
        items?: Array<{ count: number, item: number }>;
        receive_count?: number;
    }

    class Page_Update {
        public me: Laya.Sprite;
        private bmask: Laya.Sprite;
        private root: Laya.Sprite;
        private title: Laya.Label;
        private now: Laya.Label;
        private next: Laya.Label;
        private arrow: Laya.Sprite;
        private reward: Laya.Sprite;
        private reward_count: Laya.Label;
        private level_tip: Laya.Label;
        private btn_item: Laya.Button;
        private icon_item: Laya.Image;
        private tips: Laya.Sprite;

        private origin_rect: UIRect;

        private btns: Laya.Sprite; // 可以升10级显示俩按钮
        private btn: Laya.Button; // 单个按钮
        private label_btn: Laya.Label; // 按钮label
        private image_btn: Laya.Image; // 按钮图

        private item_id: number;
        private index: number;

        private state: number; // 0 可升级  1  到达锁定上线 2 到达最高等级

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.me.visible = false;
            this.bmask = this.me.getChildByName('bmask') as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.title = this.root.getChildByName('title') as Laya.Label;
            this.now = this.root.getChildByName('now') as Laya.Label;
            this.next = this.root.getChildByName('next') as Laya.Label;
            this.arrow = this.root.getChildByName('arrow') as Laya.Sprite;
            this.tips = this.root.getChildByName('tip') as Laya.Sprite;

            this.reward = this.root.getChildByName('reward') as Laya.Sprite;
            this.reward_count = this.reward.getChildByName('count') as Laya.Label;
            this.level_tip = this.reward.getChildByName('tip') as Laya.Label;
            
            this.btn_item = this.reward.getChildByName('item') as Laya.Button;
            this.icon_item = this.btn_item.getChildByName('icon') as Laya.Image;
            this.origin_rect = UIRect.CreateFromSprite(this.icon_item);
            this.btns = this.root.getChildByName('btns') as Laya.Sprite;
            this.btn = this.root.getChildByName('btn') as Laya.Button;
            this.image_btn = this.btn.getChildByName('image') as Laya.Image;
            this.label_btn = this.btn.getChildByName('text') as Laya.Label;

            let levelUp = new Laya.Handler(this, () => {
                if (UI_Activity_Miaohui.Inst.locking) return;
                this.onLevelUpBtnClick(1);
            });

            this.btn.clickHandler = levelUp;
            (this.btns.getChildByName('btn') as Laya.Button).clickHandler = levelUp;

            (this.btns.getChildByName('btn_10') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Miaohui.Inst.locking) return;
                this.onLevelUpBtnClick(10);
            });
            let btn_offset_x = (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') ? 33 : (GameMgr.client_language == 'jp' ? 15 : 0);
            let single_offset_x = (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') ? 50 : (GameMgr.client_language == 'jp' ? 15 : 0);
            for (let i = 1; i < 3; i++) {
                (this.btn.getChildAt(i) as Laya.Sprite).x -= single_offset_x;
                (this.btns.getChildByName('btn').getChildAt(i) as Laya.Sprite).x -= btn_offset_x;
                (this.btns.getChildByName('btn_10').getChildAt(i) as Laya.Sprite).x -= btn_offset_x;
            }
                
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Miaohui.Inst.locking) return;
                this.close();
            });

            this.item_id = Number(cfg.activity.upgrade_activity.get(UI_Activity_Miaohui.activity_id).consume_item.split('-')[0]);

        }

        public show(index: number) {
            this.me.visible = true;
            this.root.scale(1,1);
            this.bmask.alpha = 0;
            UI_Activity_Miaohui.Inst.locking = true;
            Laya.Tween.to(this.bmask, {alpha: 0.3}, 200);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                UI_Activity_Miaohui.Inst.locking = false;
            }))
            this.index = index;
            this.title.text = game.Tools.strOfLocalization(index + 3777);
            let group_id = UI_Activity_Miaohui.Inst.group_ids[index];
            let datas = cfg.activity.upgrade_activity_reward.getGroup(group_id);

            let _level = UI_Activity_Miaohui.getUpgradeLevel(this.index);
            this.now.text = 'Lv' + _level;

            let _item_count = UI_Bag.get_item_count(this.item_id);

            let delta_day = UI_Activity_Miaohui.getActivityDeltaDay();

            let _max_level = 0;
            let _reward_datas = cfg.activity.upgrade_activity_reward.getGroup(group_id);
            let next_reward: lqc.Sheet_Activity_UpgradeActivityReward = null;
            for (let reward_data of _reward_datas) {
                if (reward_data.unlock_day <= delta_day) {
                    _max_level = reward_data.level;
                } else {
                    break;
                }
            }
            for (let reward_data of _reward_datas) {
                if (reward_data.level > _level) {
                    next_reward = reward_data;
                    break;
                }
            }

            if (_item_count >= 10 && _max_level - _level >= 10) {
                this.btns.visible = true;
                this.btn.visible = false;
                this.next.text = 'Lv' + (_level + 10);
            } else {
                this.btns.visible = false;
                this.btn.visible = true;
                this.next.text = 'Lv' + (_level + 1);
            }
            if (_max_level - _level == 0) {
                this.state = _max_level == _reward_datas[_reward_datas.length - 1].level ? 2 : 1;
            } else {
                this.state = 0;
            }
            if (_item_count == 0 || _max_level - _level == 0) {
                this.image_btn.skin = game.Tools.localUISrc('myres/activity_miaohui/btn_update_d.png');
                this.label_btn.color = '#f2ede9';
            } else {
                this.image_btn.skin = game.Tools.localUISrc('myres/activity_miaohui/btn_update.png');
                this.label_btn.color = '#fef2d8';
            }
            if (next_reward) {
                this.reward.visible = true;
                let rewards = next_reward.reward.split('-');
                game.Tools.setItemIcon(this.icon_item, this.origin_rect, Number(rewards[0]), 'UI_Miaohui', true);
                this.reward_count.text = 'x' + rewards[1];
                this.level_tip.text = game.Tools.strOfLocalization(3780, ['' + next_reward.level]);
                game.Tools.child_align_center(this.reward, [5, 7]);
            } else {
                this.reward.visible = false;
            }
         
            if (this.state == 2) {
                this.arrow.visible = false;
                this.next.visible = false;
                this.reward.visible = false;
                this.tips.visible = true;
                this.now.x = 480 + (this.now.textField.textWidth - 141) / 2;
            } else {
                this.arrow.visible = true;
                this.next.visible = true;
                this.reward.visible = true;
                this.tips.visible = false;
                this.now.x = 348;
            }
        }

        public close(anim: boolean = true) {
            if (!anim) {
                this.me.visible = false;
                return;
            }
            
            UI_Activity_Miaohui.Inst.locking = true;
            Laya.Tween.to(this.bmask, {alpha: 0}, 200);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                UI_Activity_Miaohui.Inst.locking = false;
                this.me.visible = false;
            }));
        }

        private onLevelUpBtnClick(count: number) {
            if (this.state) {
                // 提示已达上限
                UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(this.state == 1 ? 3795 : 3802));
                return;
            } 
            if (UI_Bag.get_item_count(this.item_id) < count) {
                // 提示道具不足
                UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3794));
                return;
            }
            UI_Activity_Miaohui.Inst.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'upgradeActivityLevel', { activity_id: UI_Activity_Miaohui.activity_id, group: this.index, count: count }, (err, res) => {
                UI_Activity_Miaohui.Inst.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('upgradeActivityLevel', err, res);
                } else {
                    this.close();
                    UI_Activity_Miaohui.Inst.refreshLevelState(true);
                    UI_Activity_Miaohui.Inst.refreshItemCount();
                   
                    UI_LightTips.Inst.show(game.Tools.strOfLocalization(3804), Laya.Handler.create(this, ()=>{
                        if (res['rewards'] && res['rewards'].length > 0) {
                            let rewards = [];
                            for (let reward of res['rewards']) {
                                if (reward['replace_count'] == 0) {
                                    rewards.push(reward['reward']);
                                } else {
                                    reward['reward']['count'] -= reward['replace_count'];
                                    if (reward['reward']['count'] > 0) {
                                        rewards.push(reward['reward']);
                                    }
                                    rewards.push(reward['replace']);
                                }
                            }
                            game.Tools.showRewards({ rewards: rewards}, null);
                        }
                    }));
                    
                }
            });
        }
    }

    class Page_Confirm {
        public me: Laya.Sprite;
        public bmask: Laya.Sprite;
        public root: Laya.Sprite;
        private line: Laya.Sprite;
        private name: Laya.Label;
        private count: Laya.Label;
        private locking: boolean;
        private id: number;
        private complete: Laya.Handler;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.me.visible = false;
            this.bmask = this.me.getChildByName('blackmask') as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.line = this.root.getChildByName('line') as Laya.Sprite;
            this.name = this.line.getChildByName('name') as Laya.Label;
            this.count = this.root.getChildByName('count') as Laya.Label;

            (this.root.getChildByName('cancel') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            (this.root.getChildByName('confirm') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.onConfirmBtnClick();
            });
        }

        public show(id: number, name: string, complete: Laya.Handler) {
            this.id = id;
            this.name.text = name;
            if (GameMgr.client_language == 'kr') {
                this.name.x = - this.name.textField.textWidth / 2 + 330;
                this.name.y = -26;
                let text = this.line.getChildAt(2) as Laya.Label;
                text.x = 22;
                
            } else {
                game.Tools.child_align_center(this.line, [2, 2]);
            }
            
            this.me.visible = true;
            this.complete = complete;
            this.count.text = game.Tools.strOfLocalization(3800, ['' + (UI_Activity_Miaohui.getFriendSendCount())]);

            this.root.scale(1,1);
            this.bmask.alpha = 1;
            UI_Activity_Miaohui.Inst.locking = true;
            UIBase.anim_alpha_in(this.bmask, {}, 200);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                UI_Activity_Miaohui.Inst.locking = false;
            }))
        }

        public close(anim: boolean = true) {
            if (!anim) {
                this.me.visible = false;
                return;
            }
            
            UI_Activity_Miaohui.Inst.locking = true;
            UIBase.anim_alpha_out(this.bmask, {}, 200);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                UI_Activity_Miaohui.Inst.locking = false;
                this.me.visible = false;
            }));
        }

        private onConfirmBtnClick() {
            this.locking = true;
            // 发送协议
            app.NetAgent.sendReq2Lobby('Lobby', 'sendActivityGiftToFriend', {
                activity_id: UI_Activity_Miaohui.friend_activity_id,
                item_id: 309069,
                target_id: this.id
            }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('sendActivityGiftToFriend', err, res);
                } else {
                    // TODO 刷新显示
                    this.close();
                    if (this.complete) {
                        this.complete.run();
                    }
                }
            });
        }
    }

    class Page_Friend {
        public me: Laya.Sprite;
        private root: Laya.Sprite;
        private scrollView: capsui.CScrollView;
        private tip_parent: Laya.Sprite;
        private tips: Array<Laya.Sprite>;
        private count: Laya.Label;
        private receive_count: Laya.Label;
        private datas: Array<iFriendGiftInfo>; // 好友送礼数据
        private loading: Laya.Sprite;
        private empty: Laya.Sprite;
        private loaded_count: number = 0;
        public send_limit: number;
        private receive_limit: number;
        private locking: boolean; // 控制领奖部分

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.me.visible = false;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.scrollView = (this.root.getChildByName('scrollview') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(Laya.Handler.create(this, this.render_item, null, false));
            this.scrollView.reset();
            this.scrollView.setElastic();
            this.count = this.root.getChildByName('count') as Laya.Label;
            this.receive_count = this.root.getChildByName('receive_count') as Laya.Label;
            (this.me.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking || UI_Activity_Miaohui.Inst.locking) return;
                this.close();
            });
            this.loading = this.root.getChildByName('loading') as Laya.Sprite;
            this.empty = this.root.getChildByName('empty') as Laya.Sprite;
            let _data = cfg.activity.friend_gift_activity.get(UI_Activity_Miaohui.friend_activity_id);
            this.send_limit = _data.friend_send_limit;
            this.receive_limit = _data.friend_recv_limit;

            this.tip_parent = this.root.getChildByName('page_tip') as Laya.Sprite;
            this.tip_parent.visible = false;
            this.tips = [];
            this.tips.push(this.tip_parent.getChildByName('templete') as Laya.Sprite);
        }

        public show() {
            this.me.visible = true;
            this.empty.visible = false;
            this.root.scale(1, 1);
            UI_Activity_Miaohui.Inst.locking = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                UI_Activity_Miaohui.Inst.locking = false;
            }));
            game.TempImageMgr.setUIEnable('UI_Miaohui_Friend', true);
            this.scrollView.reset();

            this.datas = [];
            for (let friend of game.FriendMgr.friend_list) {
                this.datas.push({ account_id: friend.base.account_id, info: friend });
            }

            let send_count = UI_Activity_Miaohui.getFriendSendCount();
            this.showLoading();
            // 已达送礼上限则直接显示
            if (send_count < this.send_limit) {
                this._loadInfo();
            } else {
                this.showFriends();
            }

            // 如果有待领取，打开界面直接领取
            if (UI_Activity_Miaohui.haveFriendRedPoint()) {
                app.NetAgent.sendReq2Lobby('Lobby', 'receiveAllActivityGift', { activity_id: UI_Activity_Miaohui.friend_activity_id }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('receiveAllActivityGift', err, res);
                    } else {
                        this.onReceiveAllGifts(res['receive_gift']);
                        UI_Activity_Miaohui.Inst.refreshItemCount();
                        UI_Activity_Miaohui.Inst.refreshBtnRedpoint();
                    }
                });
            } else {
                this.onLoadFinish();
            }

            this.refreshCount();
        }

        private refreshCount() {
            let send_count = UI_Activity_Miaohui.getFriendSendCount();
            this.count.text = game.Tools.strOfLocalization(3800, [send_count + '']);
            let receive_count = UI_Activity_Miaohui.getFriendReceiveCount();
            this.receive_count.text = game.Tools.strOfLocalization(3799, [receive_count + '']);
        }
        public close() {
            this.me.visible = false;
            game.TempImageMgr.setUIEnable('UI_Miaohui_Friend', false);
        }

        // 加载数据
        private _loadInfo() {
            let account_ids: Array<number> = [];
            for (let i = 0; i < this.datas.length; i++) {
                account_ids.push(this.datas[i].account_id);
            }
            if (this.datas.length == 0) {
                this.showFriends();
            } else {
                UI_Activity_Miaohui.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'fetchFriendGiftActivityData', { activity_id: UI_Activity_Miaohui.friend_activity_id, account_list: account_ids }, (err, res) => {
                    UI_Activity_Miaohui.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('fetchFriendGiftActivityData', err, res);
                    } else {
                        for (let data of res['list']) {
                            for (let _data of this.datas) {
                                if (_data.account_id == data.account_id) {
                                    _data.items = data.items;
                                    _data.receive_count = data.receive_count;
                                    break;
                                }
                            }
                        }
                        this.showFriends();
                    }
                });
            }
            
        }

        private render_item(data: any) {
            let index: number = data.index;
            let container: Laya.Sprite = data.container;
            let _giftInfo: iFriendGiftInfo = this.datas[index];
            let _playerInfo: game.iFriendInfo = _giftInfo.info;

            let cache_data: Object = data.cache_data;

            if (!cache_data['head']) {
                cache_data['head'] = new UI_Head(container.getChildByName('head') as Laya.Sprite, 'UI_Miaohui_Friend');
            }
            cache_data['head'].id = game.GameUtility.get_limited_skin_id(_playerInfo.base.avatar_id);
            cache_data['head'].set_head_frame(_playerInfo.base.account_id, _playerInfo.base.avatar_frame);
            if (!cache_data['name']) {
                cache_data['name'] = container.getChildByName('name') as Laya.Sprite;
            }
            let btn = container.getChildByName('btn') as Laya.Button;
            if (btn.clickHandler) {
                btn.clickHandler.recover();
                btn.clickHandler = null;
            }
            btn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Miaohui.Inst.locking || this.locking) return;
                UI_Activity_Miaohui.Inst.page_confirm.show(_giftInfo.account_id, game.Tools.strWithoutForbidden(_giftInfo.info.base.nickname), Laya.Handler.create(this, () => {
                    this.scrollView.wantToRefreshAll();
                    UI_Activity_Miaohui.Inst.refreshItemCount();
                    this.refreshCount();
                    UI_LightTips.Inst.show(game.Tools.strOfLocalization(3797));
                }));
            });
            
            game.Tools.SetNickname(cache_data['name'], _playerInfo.base);
            let send_count = UI_Activity_Miaohui.getFriendSendCount();
            let send_ids = UI_Activity_Miaohui.getFriendSendIds();
            if (this.send_limit <= send_count) {
                (container.getChildByName('btn').getChildByName('image') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_miaohui/btn_help_d.png');
                (container.getChildByName('btn') as Laya.Button).mouseEnabled = false;
                (container.getChildByName('tip') as Laya.Sprite).visible = true;
                (container.getChildByName('tip') as Laya.Label).text = game.Tools.strOfLocalization(3809);
            } else if (_giftInfo.receive_count >= this.receive_limit || send_ids.indexOf(_giftInfo.account_id) != -1) {
                (container.getChildByName('btn').getChildByName('image') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_miaohui/btn_help_d.png');
                (container.getChildByName('btn') as Laya.Button).mouseEnabled = false;
                (container.getChildByName('tip') as Laya.Sprite).visible = true;
                (container.getChildByName('tip') as Laya.Label).text = game.Tools.strOfLocalization(send_ids.indexOf(_giftInfo.account_id) != -1 ? 3786 : 3785);
            } else {
                (container.getChildByName('btn').getChildByName('image') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_miaohui/btn_help.png');
                (container.getChildByName('btn') as Laya.Button).mouseEnabled = true;
                (container.getChildByName('tip') as Laya.Sprite).visible = false;
            }
        }

        private showFriends() {
            this.onLoadFinish();
            if (this.datas.length == 0) {
                this.empty.visible = true;
            }
            // 排序之后往scrollview里加
            this.datas.sort((a, b) => {
                return b.info.state.login_time - a.info.state.login_time;
            });
            let send_count = UI_Activity_Miaohui.getFriendSendCount();
            // // 如果已达上限则直接显示
            // if (send_count == this.send_limit) {
            //     this.scrollView.addItem(this.datas.length);
            //     return;
            // }
            // 区分是否可送礼
            let _datas = this.datas;
            this.datas = [];
            let send_ids = UI_Activity_Miaohui.getFriendSendIds();
            let index = 0;
            for (let _data of _datas) {
                // 无法送礼
                if (send_ids.indexOf(_data.account_id) >= 0 || _data.receive_count >= this.receive_limit) {
                    this.datas.push(_data);
                } else {
                    this.datas.splice(index, 0, _data);
                    index++;
                }
            }
            this.scrollView.addItem(this.datas.length);
        }

        private onReceiveAllGifts(infos: Array<any>) {
            if (!this.me.visible) return;
            this.tip_parent.visible = true;
            let account_ids = []; // 已经不在好友列表里的送礼信息
            for (let info of infos) {
                if (!game.FriendMgr.find(info.from_account_id)) {
                    account_ids.push(info.from_account_id);
                }
            }
            if (account_ids.length == 0) {
                let names = []
                for (let info of infos) {
                    let friend = game.FriendMgr.find(info.from_account_id);
                    names.push(friend.base.nickname);
                }
                this.showTips(names);
            } else {
                app.NetAgent.sendReq2Lobby('Lobby', 'fetchMultiAccountBrief', { account_id_list: account_ids }, (err, res) => {

                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('fetchMultiAccountBrief', err, res);
                        this.onLoadFinish();
                    } else {
                        let names = []
                        for (let info of infos) {
                            let friend = game.FriendMgr.find(info.from_account_id);
                            if (friend) {
                                names.push(friend.base.nickname);
                            } else {
                                for (let i = 0; i < res['players'].length; i++) {
                                    if (res['players'][i].account_id == info.from_account_id) {
                                        names.push(res['players'][i].nickname);
                                    }
                                }
                            }

                        }
                        this.showTips(names);
                    }
                });
            }
        }

        // 飞恭喜获得
        private showTips(names: Array<string>) {
            this.onLoadFinish();
            this.locking = true;
            for (let i = 0; i < this.tips.length; i++) {
                this.tips[i].visible = false;
            }
            this.tip_parent.visible = true;
            this.tip_parent.y = 0;
            for (let i = 0; i < names.length; i++) {
                if (!this.tips[i]) {
                    this.tips.push(this.tips[0].scriptMap['capsui.UICopy'].getNodeClone());
                    this.tips[i].y = 434 + i * 126
                }
                this.tips[i].visible = true;
                (this.tips[i].getChildByName('text') as Laya.Label).text = game.Tools.strOfLocalization(3793, [game.Tools.strWithoutForbidden(names[i])]);
                this.tips[i].alpha = 0;
                this.tips[i].x = 11;
                Laya.Tween.to(this.tips[i], { alpha: 1 }, 200, null, null, i * 150);
                Laya.Tween.to(this.tips[i], { x: 400, alpha: 0 }, 250, null, null, i * 150 + 1200);
            }
            if (names.length > 7) {
                this.tip_parent.y = -3 * 126;
                Laya.Tween.to(this.tip_parent, { y: -126 * (names.length - 4) }, names.length * 150 + 800, null, Laya.Handler.create(this, () => { this.tip_parent.visible = false; this.locking = false }), 600);
            } else {
                Laya.timer.once(names.length * 150 + 1200, this, () => {
                    this.locking = false;
                })
                this.tip_parent.y = -(names.length - 1) * 126 / 2;
            }
        }

        // 开始loading
        private showLoading() {
            this.loaded_count = 0;
            this.loading.visible = true;
            this.scrollView.me.visible = false;
        }

        // 需要好友数据和好友送礼数据都load完成
        private onLoadFinish() {
            this.loaded_count++;
            if (this.loaded_count >= 2) {
                this.loading.visible = false;
                this.scrollView.me.visible = true;
            }
        }
    }

    class Cell {
        public me: Laya.Sprite;
        public level: number;
        private item_id: number;
        private item_count: number;

        private icon_light: Laya.Sprite;
        private point: Laya.Image;
        private img_reward: Laya.Image;
        private label_bg: Laya.Sprite;
        private label_count: Laya.Label;
        public flag_getted: Laya.Sprite;
        private btn_item: Laya.Button;
        private lock: Laya.Sprite;
        private label_info: Laya.Label;
        private tip: Laya.Sprite;

        private now_level: number;
        private getted: boolean;
        private origin_rect: UIRect;
        private node_mark: number;
        private unlock_day: number;

        public constructor(me: Laya.Sprite, node_mark: number, level: number, item_id: number, item_count: number, unlock_day: number) {
            this.me = me;
            this.node_mark = node_mark;
            this.level = level;
            this.item_id = item_id;
            this.item_count = item_count;
            this.unlock_day = unlock_day;
            this.init();
        }

        public copy(cell: Cell) {
            this.level = cell.level;
            this.item_id = cell.item_id;
            this.item_count = cell.item_count;
            this.unlock_day = cell.unlock_day;
        }
        public init() {
            this.point = this.me.getChildByName('point') as Laya.Image;
            this.btn_item = this.me.getChildByName('item') as Laya.Button;
            this.icon_light = this.btn_item.getChildByName('light') as Laya.Image;
            // this.reward_shine = this.btn_item.getChildByName('shine') as Laya.Sprite;
            this.img_reward = this.btn_item.getChildByName('icon') as Laya.Image;
            this.label_bg = this.btn_item.getChildByName('bg_count') as Laya.Sprite;
            this.label_count = this.btn_item.getChildByName('count') as Laya.Label;
            this.flag_getted = this.btn_item.getChildByName('rewarded') as Laya.Sprite;
            this.label_info = this.me.getChildByName('info') as Laya.Label;
            this.lock = this.btn_item.getChildByName('lock') as Laya.Sprite;
            this.tip = this.btn_item.getChildByName('tip_receive') as Laya.Sprite;
            this.origin_rect = UIRect.CreateFromSprite(this.img_reward);

            this.btn_item.clickHandler = new Laya.Handler(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);

            });
            this.icon_light.visible = !!this.node_mark;
        }

        public show(level: number, _received_level: number) {
            this.now_level = level;
            this.getted = this.level <= _received_level;
            game.Tools.setItemIcon(this.img_reward, this.origin_rect, this.item_id, 'UI_Activity_Dongri', true);

            this.label_info.text = 'Lv' + this.level;
            let dt: number = UI_Activity_Miaohui.getActivityDeltaDay();


            if (this.getted) {
                this.flag_getted.visible = true;
                this.tip.visible = false;
            } else {
                this.tip.visible = this.now_level >= this.level;
                this.flag_getted.visible = false;
            }

            if (this.item_count <= 1) {
                this.label_count.visible = false;
                this.label_bg.visible = false;
            } else {
                this.label_count.visible = true;
                this.label_bg.visible = true;
                this.label_count.text = this.item_count.toString();
            }

            let unlock_time: number = this.unlock_day;


            if (dt < unlock_time) {
                this.lock.visible = true;
                this.label_info.text = game.Tools.strOfLocalization(3779 + this.unlock_day);
            } else {
                this.lock.visible = false;
            }

        }

        public canGet(): boolean {
            return this.level <= this.now_level && !this.getted && !this.lock.visible;
        }

        private onGetted() {
            this.getted = true;
            this.flag_getted.visible = true;
            this.lock.visible = true;
            // this.reward_shine.visible = false;
            if (game.GameUtility.get_id_type(this.item_id) == game.EIDType.character) {
                UI_Get_Character.Inst.show(this.item_id);
            } else {
                game.Tools.showRewards({ rewards: [{ id: this.item_id, count: this.item_count }] }, null);
            }
            UI_Lobby.Inst.top.refreshDongriRedpoint();
        }

        public get achieved(): boolean {
            return !this.lock.visible && this.level <= this.now_level;
        }
    }

    export class UI_Activity_Miaohui extends UIBase {

        public static Inst: UI_Activity_Miaohui = null;
        public static activity_id: number = 230101;
        public static friend_activity_id: number = 230102;
        public static task_activity_id: number = 230103;

        public static friend_gift_data: { activity_id: number, max_inbox_id: number, receive_data: { count: number, last_update_time: number }, send_data: { count: number, last_update_time: number, send_friend_id: Array<number> }, gift_inbox: Array<any> };
        public static upgrade_data: { activity_id: number, groups: Array<{ group_id: number, level: number }>, received_level: number };

        // 获得当前等级
        public static getUpgradeLevel(group_id: number) {
            if (UI_Activity_Miaohui.upgrade_data && UI_Activity_Miaohui.upgrade_data.groups) {
                for (let group of UI_Activity_Miaohui.upgrade_data.groups) {
                    if (group.group_id == group_id) {
                        return group.level;
                    }
                }
            }
            return 0;
        }

        // 更新好友送礼信息
        public static updateFriendGiftData(datas: Array<any>) {
            for (let data of datas) {
                if (data['activity_id'] == this.friend_activity_id) {
                    this.friend_gift_data = data;
                    if (UI_Activity_Miaohui.Inst && UI_Activity_Miaohui.Inst.enable) {
                        UI_Activity_Miaohui.Inst.refreshFriendState();
                    }
                    return;
                }
            }
        }

        // 更新等级信息
        public static updateUpgradeData(datas: Array<any>) {
            for (let data of datas) {
                if (data['activity_id'] == this.activity_id) {
                    this.upgrade_data = data;
                    if (UI_Activity_Miaohui.Inst && UI_Activity_Miaohui.Inst.enable) {
                        UI_Activity_Miaohui.Inst.refreshLevelState();
                    }
                    return;
                }
            }

        }

        // 获得当前是活动第几天
        public static getActivityDeltaDay(): number {
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }

        // 获得当期送礼次数
        public static getFriendSendCount(): number {
            if (!this.friend_gift_data || !this.friend_gift_data.send_data) return 0;
            if (!game.Tools.isPassedRefreshTimeServer(this.friend_gift_data.send_data.last_update_time)) return 0;
            return this.friend_gift_data.send_data.count;
        }

        // 获得当期收礼次数
        public static getFriendReceiveCount(): number {
            if (!this.friend_gift_data || !this.friend_gift_data.receive_data) return 0;
            if (!game.Tools.isPassedRefreshTimeServer(this.friend_gift_data.receive_data.last_update_time)) return 0;
            return this.friend_gift_data.receive_data.count;
        }

        // 获得当期已送礼id
        public static getFriendSendIds(): Array<number> {
            if (!this.friend_gift_data || !this.friend_gift_data.send_data) return [];
            if (!game.Tools.isPassedRefreshTimeServer(this.friend_gift_data.send_data.last_update_time)) return [];
            return this.friend_gift_data.send_data.send_friend_id;
        }

        // 是否有好友部分红点
        public static haveFriendRedPoint(): boolean {
            if (this.friend_gift_data && this.friend_gift_data.gift_inbox) {
                for (let i = 0; i < this.friend_gift_data.gift_inbox.length; i++) {
                    if (!this.friend_gift_data.gift_inbox[i].received) {
                        return true;
                    }
                }
            }
            return false;
        }

        // 是否有任务部分红点
        public static haveTaskRedPoint(): boolean {
            let datas = UI_Activity.getSegmentTaskList(UI_Activity_Miaohui.task_activity_id);
            if (!datas || !datas[0]) return false;
            let task_id = datas[0]['id'];
            let d_activity_task = cfg.activity.segment_task.get(task_id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            let max_count = d_activity_task.max_finish_count;
            if (datas[0]['reward_count'] < max_count && datas[0]['achieved_count'] > datas[0]['reward_count']) {
                return true;
            }
            return false;
        }

        // 是否有总奖励红点
        public static haveRewardRedPoint(): boolean {
            let data = cfg.activity.upgrade_activity.get(UI_Activity_Miaohui.activity_id);

            let _delta = UI_Activity_Miaohui.getActivityDeltaDay(); // 当前活动是第几天

            let _total_level = 0;
            for (let i = 0; i < 3; i++) {
                let _level = UI_Activity_Miaohui.getUpgradeLevel(i);
                _total_level += _level;
            }

            let _received_level = 0;
            if (UI_Activity_Miaohui.upgrade_data) {
                _received_level = UI_Activity_Miaohui.upgrade_data.received_level;
            }

            let _reward_datas = cfg.activity.upgrade_activity_reward.getGroup(data.total_reward_id);
            for (let _reward_data of _reward_datas) {
                if (_reward_data.unlock_day > _delta || _reward_data.level > _total_level) {
                    return false;
                } else if (_reward_data.level > _received_level) {
                    return true;
                }
            }
            return false;
        }

        // 大厅是否显示红点
        public static haveRedPoint(): boolean {
            return this.haveFriendRedPoint() || this.haveTaskRedPoint() || this.haveRewardRedPoint();
        }
        constructor() {
            super(new ui.lobby.chunjie_miaohuiUI());
            UI_Activity_Miaohui.Inst = this;
        }

        private root: Laya.Sprite;
        private black_mask: Laya.Sprite;
        private lihui: Laya.Sprite;
        public spine: CatFoodSpine.SpineController;
        private chat: UI_Character_Chat;
        private chat_id: number = 0;
        private sound_channel: Laya.SoundChannel;

        private images: Array<Laya.Image>;
        private btns: Array<Laya.Button>;

        private btn_receive: Laya.Button;
        private btn_task: Laya.Button;

        private level: Laya.Label;
        private reward_content: Laya.Panel;
        private btn_left: Laya.Button;
        private btn_right: Laya.Button;
        private lines: Array<Laya.Image>;
        private cells: Array<Cell>;
        private per_width: number;
        private highlight: Laya.Sprite;
        private cell_highlight: Cell;
        private line_highligh_l: Laya.Image;
        private line_highligh_r: Laya.Image;
        private highlight_indexs: Array<number>;

        private help_redpoint: Laya.Sprite;

        private friend_redpoint: Laya.Sprite;

        private _total_level: number;// 总等级

        // 点数相关
        private count: Laya.Label;
        private point: Laya.Label;
        private bar: Laya.Sprite;
        private label_today_count: Laya.Label;

        public page_update: Page_Update;
        public page_confirm: Page_Confirm;
        public page_friend: Page_Friend;

        public group_ids: Array<number>;
        private btn_states: Array<number> = [0, 0, 0]; // 3个按钮 可升级 已到锁定等级 已满级
        public display_id: number; // 立绘id
        // 任务相关数据
        private task_id: number;
        private ungetted_count: number;
        private task_info: { id: number, counter: number, achieved: boolean, rewarded: boolean, failed: boolean, reward_count: number, achieved_count: number };

        public locking: boolean;

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.black_mask = this.me.getChildByName('blackmask') as Laya.Sprite;
            this.page_update = new Page_Update(this.me.getChildByName('page_update') as Laya.Sprite);
            this.page_confirm = new Page_Confirm(this.me.getChildByName('page_confirm') as Laya.Sprite);
            this.page_friend = new Page_Friend(this.me.getChildByName('page_friend') as Laya.Sprite);

            let nianshou = this.root.getChildByName('nianshou') as Laya.Sprite;
            (nianshou.getChildByName('click') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.spine) {
                    this.spine.play('click');
                    // if (this.sound_channel) {
					// 	this.stopsay();
					// } else {
						this.say('click');
					// }
                }

            });
            this.lihui = nianshou.getChildByName('image') as Laya.Image;
            this.chat = new UI_Character_Chat(nianshou.getChildByName('chat') as Laya.Sprite);
            this.chat.close(true);
            this.images = [];
            this.btns = [];
            for (let i = 0; i < 3; i++) {
                this.images.push(this.root.getChildByName('images').getChildByName(i + '') as Laya.Image);
                let btn = this.root.getChildByName('btns').getChildByName('btn_' + i) as Laya.Button;
                if (GameMgr.client_language == 'en') {
                    (btn.getChildByName('info') as Laya.Sprite).y = 120;
                }
                btn.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                  
                    this.onUpdateBtnClick(i);
                });
                this.btns.push(btn);
            }

            let top = this.root.getChildByName('top') as Laya.Sprite;
            (top.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            (top.getChildByName('info') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                uiscript.UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3798));
            });

            let bot = this.root.getChildByName('bot') as Laya.Sprite;
            this.level = bot.getChildByName('level') as Laya.Label;
            this.btn_receive = bot.getChildByName('btn_receive') as Laya.Button;
            this.btn_receive.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                // TODO 可能需要判定是否有可领取
                app.NetAgent.sendReq2Lobby('Lobby', 'receiveUpgradeActivityReward', { activity_id: UI_Activity_Miaohui.activity_id }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('receiveUpgradeActivityReward', err, res);
                    } else if (res['rewards']) {
                        let rewards = [];
                        var func = (info)=>{
                            let added = false;
                            for (let reward of rewards) {
                                if (reward.id == info.id) {
                                    reward.count += info.count;
                                    added = true;
                                    break;
                                }
                            }
                            if (!added) {
                                rewards.push(info);
                            }
                        }
                        for (let reward of res['rewards']) {
                            if (reward['replace_count'] == 0) {
                                let info = reward['reward'];
                                func(info)
                                
                            } else {
                                reward['reward']['count'] -= reward['replace_count'];
                                if (reward['reward']['count'] > 0) {
                                    func(reward['reward']);
                                }
                                func(reward['replace']);
                            }
                        }
                        game.Tools.showRewards({ rewards: rewards }, null);
                        this.refreshLevelState();
                    }
                });
            });
            this.reward_content = bot.getChildByName('rewards').getChildByName('content') as Laya.Panel;
            this.reward_content.hScrollBarSkin = '';

            this.lines = [];
            this.cells = [];
            this.per_width = 127;
            this.btn_left = bot.getChildByName('rewards').getChildByName('btn_left') as Laya.Button;
            this.btn_left.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.leftBtnClick();
            });
            this.btn_right = bot.getChildByName('rewards').getChildByName('btn_right') as Laya.Button;
            this.btn_right.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.rightBtnClick();
            });

            this.friend_redpoint = bot.getChildByName('help').getChildByName('btn_help').getChildByName('redpoint') as Laya.Sprite;
            (bot.getChildByName('help').getChildByName('btn_help') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.page_friend.show(); // TODO 打开好友界面
            });
            this.help_redpoint = bot.getChildByName('help').getChildByName('btn_help').getChildByName('redpoint') as Laya.Sprite;

            this.count = bot.getChildByName('point').getChildByName('count') as Laya.Label;
            this.point = bot.getChildByName('point').getChildByName('point') as Laya.Label;
            this.bar = bot.getChildByName('point').getChildByName('bar').getChildByName('bar') as Laya.Sprite;
            this.label_today_count = bot.getChildByName('point').getChildByName('day') as Laya.Label;
            (bot.getChildByName('point').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                UI_ItemDetail.Inst.show(309069);
            });
            this.btn_task = bot.getChildByName('point').getChildByName('bar').getChildByName('btn') as Laya.Button;
            this.btn_task.clickHandler = new Laya.Handler(this, () => {
                // 打点任务领取奖励
                if (this.locking) return;
                if (this.ungetted_count <= 0) return; // TODO 可能需要有个提示？

                app.NetAgent.sendReq2Lobby('Lobby', 'completeSegmentTaskReward', { task_id: this.task_id, count: this.ungetted_count }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completeSegmentTaskReward', err, res);
                    } else {
                        let d_activity_task = cfg.activity.segment_task.get(this.task_info.id);
                        let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
                        let _data = cfg.item_definition.item.get(309069);
                        let s: string = game.Tools.strOfLocalization(2234) + (_data['name_' + GameMgr.client_language] + ' x' + this.ungetted_count);
                        UI_LightTips.Inst.show(s);
                        this.task_info.reward_count = this.task_info.achieved_count;
                        let counter = this.task_info.counter ? this.task_info.counter : 0;
                        this.point.text = counter + '/' + d_task_info.target;
                        this.bar.width = counter / d_task_info.target * 298;
                        this.ungetted_count = 0;
                        (this.btn_task.getChildByName('tip') as Laya.Sprite).visible = false;
                        (this.btn_task.getChildByName('deco') as Laya.Sprite).visible = false;
                        this.refreshItemCount();
                        game.Tools.setGrayDisable(this.btn_task, true);
                        this.label_today_count.text = game.Tools.strOfLocalization(3803, [this.task_info.reward_count + '']);
                        if (this.task_info.reward_count >= d_activity_task.max_finish_count) {
                            this.point.text = d_task_info.target + '/' + d_task_info.target;
                            this.bar.width = 298;
                        }
                        UI_Lobby.Inst.top.refreshRedpoint();
                    }
                });
            });

            this.group_ids = cfg.activity.upgrade_activity.get(UI_Activity_Miaohui.activity_id).reward_id;

            let total_reward_datas = cfg.activity.upgrade_activity_reward.getGroup(cfg.activity.upgrade_activity.get(UI_Activity_Miaohui.activity_id).total_reward_id);
            // 初始化奖励节点和线
            let _cell_templete: Laya.Sprite = this.reward_content.getChildByName('cells').getChildByName('task_templete') as Laya.Sprite;
            let _line_templete: Laya.Sprite = this.reward_content.getChildByName('line_parent').getChildByName('line') as Laya.Sprite;
            let index = 0;
            this.highlight_indexs = [];            
            for (let data of total_reward_datas) {
                let _cell: Laya.Sprite = null;
                if (this.cells.length == 0) {
                    _cell = _cell_templete;
                } else {
                    _cell = _cell_templete.scriptMap['capsui.UICopy'].getNodeClone();
                }
                _cell.x = index * this.per_width;
                let reward = data.reward.split('-');
                this.cells.push(new Cell(_cell, data.highlight, data.level, Number(reward[0]), Number(reward[1]), data.unlock_day));
                if (data.highlight) {
                    this.highlight_indexs.push(index);
                }
                if (index != 0) {
                    let _line: Laya.Sprite = null;
                    if (this.lines.length == 0) {
                        _line = _line_templete;
                    } else {
                        _line = _line_templete.scriptMap['capsui.UICopy'].getNodeClone();
                    }
                    this.lines.push(_line as Laya.Image);
                    _line.x = 107 + (index - 1) * this.per_width;
                }
                index++;
            }
            (this.reward_content.getChildByName('line_parent') as Laya.Sprite).width = this.per_width * index;
            this.reward_content.refresh();
            this.reward_content.hScrollBar.on('change', this, this._onChange);

            this.highlight = bot.getChildByName('rewards').getChildByName('highlight') as Laya.Sprite;
            this.cell_highlight = new Cell(this.highlight.getChildByName('task_templete') as Laya.Sprite, 1, 0,0,0,0);
            this.line_highligh_l = this.highlight.getChildByName('line_l') as Laya.Image;
            this.line_highligh_r = this.highlight.getChildByName('line_r') as Laya.Image;
        }

        public show() {
            let datas = UI_Activity.getSegmentTaskList(UI_Activity_Miaohui.task_activity_id);
            if (!datas || !datas[0]) {
                this.enable = false;
                return;
            }
            
            this.enable = true;
            this.root.scale(1, 1);
            this.black_mask.alpha = 1;
            UIBase.anim_alpha_in(this.black_mask, {}, 200);
            this.locking = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            // UI_Lobby.Inst.setSkinAnim(false);
            this.refreshLevelState();
            this.refreshItemCount();
            this.refreshRedpoint();
            
            this.task_id = datas[0]['id'];
            this.refresh_task(datas[0]);
            game.TempImageMgr.setUIEnable('UI_Miaohui', true);
        }

        public close() {
            UIBase.anim_alpha_out(this.black_mask, {}, 200);
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
            
            // UI_Lobby.Inst.setSkinAnim(true);
            UI_Lobby.Inst.top.refreshChunjieRedpoint();
            this.stopsay();
        }

        
        public onDisable() {
            this.display_id = -1;
            if (this.spine) {
                if (this.spine.root.parent == this.lihui) {
                    this.spine.root.visible = false;
                    this.spine.reset();
                    this.lihui.removeChild(this.spine.root);
                }
                this.spine = null;
            }
            this.page_confirm.close(false);
            this.page_friend.close();
            this.page_update.close(false);
            game.TempImageMgr.setUIEnable('UI_Miaohui', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_miaohui.atlas'));
        }

        private onUpdateBtnClick(index: number) {
            this.page_update.show(index);
        }

        private leftBtnClick() {
            this.reward_content.scrollTo(this.reward_content.hScrollBar.value - this.per_width);
        }

        private rightBtnClick() {
            this.reward_content.scrollTo(this.reward_content.hScrollBar.value + this.per_width);
        }

        private _onChange() {
            let value = this.reward_content.hScrollBar.value;
            let _index = (value + 459) / this.per_width;
            let show_index = -1; 
            for (let i = 0; i < this.highlight_indexs.length; i++) {
                if (this.highlight_indexs[i] > _index) {
                    show_index = this.highlight_indexs[i];
                    break;
                }
            }

            if (show_index < 0) {
                this.highlight.visible = false;
            } else {
                this.highlight.visible = true;
                if (this.cells[show_index - 1]) {
                    this.line_highligh_l.visible = true;
                    this.line_highligh_l.skin = game.Tools.localUISrc('myres/activity_miaohui/bar_reward' + (this.cells[show_index].achieved  ? '_l' : '') + '.png');
                } else {
                    this.line_highligh_l.visible = false;
                }
                if (this.cells[show_index + 1]) {
                    this.line_highligh_r.visible = true;
                    this.line_highligh_r.skin = game.Tools.localUISrc('myres/activity_miaohui/bar_reward' + (this.cells[show_index + 1].achieved  ? '_l' : '') + '.png');
                } else {
                    this.line_highligh_r.visible = false;
                }
                let copy_cell = this.cells[show_index];
                if (this.cell_highlight.level != copy_cell.level) {
                    this.cell_highlight.copy(copy_cell);
                     let _received_level = 0;
                    if (UI_Activity_Miaohui.upgrade_data) {
                        _received_level = UI_Activity_Miaohui.upgrade_data.received_level;
                    }
                    this.cell_highlight.show(this._total_level, _received_level);
                }
                
            }
            let hscrollbar:Laya.ScrollBar = this.reward_content.hScrollBar;
			let k:number = 1;
			let v:number = hscrollbar.value * k;
            
			let rate = v / hscrollbar.max;
			this.btn_left.visible = rate > 0.02;
            this.btn_right.visible = rate < 0.98;
        }

        // 刷新等级显示，立绘 按钮和3个按钮
        public refreshLevelState(is_upgrade: boolean = false) {
            let data = cfg.activity.upgrade_activity.get(UI_Activity_Miaohui.activity_id);

            let _delta = UI_Activity_Miaohui.getActivityDeltaDay(); // 当前活动是第几天
            for (let i = 0; i < 3; i++) {
                let _group_id = data.reward_id[i];
                let _level = UI_Activity_Miaohui.getUpgradeLevel(i); // 当前等级 
                let _max_level = 0; // 最高等级
                let _is_lock = false; // 是否还有未解锁等级
                let _display_id = 0; // 展示等级

                let _reward_datas = cfg.activity.upgrade_activity_reward.getGroup(_group_id);

                for (let reward_data of _reward_datas) {
                    if (reward_data.unlock_day <= _delta) {
                        _max_level = reward_data.level;
                    } else {
                        _is_lock = true;
                        break;
                    }
                }

                let _display_datas = cfg.activity.upgrade_activity_display.getGroup(_group_id);
                for (let display_data of _display_datas) {
                    if (display_data.level <= _level) {
                        _display_id = display_data.display;
                    } else {
                        break;
                    }
                }
                this.btn_states[i] = (_level < _max_level ? 0 : (_is_lock ? 1 : 2));
                (this.btns[i].getChildByName('redpoint') as Laya.Sprite).visible = this.btn_states[i] == 0 && UI_Bag.get_item_count(309069) > 0;
                this.images[i].skin = game.Tools.localUISrc('myres/activity_miaohui/deco_' + i + _display_id + '.png');
                // this.btns[i].filters = _level < _max_level ? [] : [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
            }

            this._total_level = 0;
            for (let i = 0; i < 3; i++) {
                let _level = UI_Activity_Miaohui.getUpgradeLevel(i);
                (this.btns[i].getChildByName('info') as Laya.Label).text = 'Lv' + _level;
                this._total_level += _level;
            }

            let _received_level = 0;
            if (UI_Activity_Miaohui.upgrade_data) {
                _received_level = UI_Activity_Miaohui.upgrade_data.received_level;
            }
            this.level.text = 'Lv' + this._total_level;
            let _display_id = 0;
            let _display_datas = cfg.activity.upgrade_activity_display.getGroup(data.total_reward_id);
            for (let display_data of _display_datas) {
                if (display_data.level <= this._total_level) {
                    _display_id = display_data.display;
                } else {
                    break;
                }
            }
            if (_display_id + 1 != this.display_id) {
                // 根据_display_id 展示不同立绘
                this.setSpine(_display_id + 1);
            } else if (is_upgrade){
                this.say('upgrade');
            }
            
            let _can_get = false;
            for (let i = 0; i < this.cells.length; i++) {
                this.cells[i].show(this._total_level, _received_level);
                if (this.cells[i].canGet()) {
                    _can_get = true;
                }
            }

            if (_can_get) {
                this.btn_receive.mouseEnabled = true;
                this.btn_receive.skin = game.Tools.localUISrc('myres/activity_miaohui/btn_receive.png');
            } else {
                this.btn_receive.mouseEnabled = false;
                this.btn_receive.skin = game.Tools.localUISrc('myres/activity_miaohui/btn_receive_d.png');
            }

            for (let i = 0; i < this.lines.length; i++) {
                this.lines[i].skin = game.Tools.localUISrc('myres/activity_miaohui/bar_reward' + (this.cells[i + 1].achieved ? '_l' : '') + '.png');
            }

            this._onChange();
            if (this.highlight.visible) {
                this.cell_highlight.show(this._total_level, _received_level);
            }
        }

        // 刷新打点相关显示
        public refresh_task(info: any) {
            this.task_info = info;
            let d_activity_task = cfg.activity.segment_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            let max_count = d_activity_task.max_finish_count;
            this.ungetted_count = 0;
            (this.btn_task.getChildByName('tip') as Laya.Sprite).visible = false;
            (this.btn_task.getChildByName('deco') as Laya.Sprite).visible = false;
            game.Tools.setGrayDisable(this.btn_task, true);
            if (info.reward_count >= max_count) {
                this.point.text = d_task_info.target + '/' + d_task_info.target;
                this.bar.width = 298 * 1;
            } else if (info.achieved_count > info.reward_count) {
                this.ungetted_count = info.achieved_count - info.reward_count;
                let show_progress = Math.min((max_count - info.reward_count) * d_task_info.target, info.counter + this.ungetted_count * d_task_info.target);
                this.point.text = show_progress + '/' + d_task_info.target;
                this.bar.width = 298 * 1;
                (this.btn_task.getChildByName('tip') as Laya.Sprite).visible = true;
                (this.btn_task.getChildByName('deco') as Laya.Sprite).visible = true;
                game.Tools.setGrayDisable(this.btn_task, false);
            } else {
                let counter = this.task_info.counter ? this.task_info.counter : 0;
                this.point.text = counter + '/' + d_task_info.target;
                this.bar.width = counter / d_task_info.target * 298;
            }
            this.label_today_count.text = game.Tools.strOfLocalization(3803, [info.reward_count + '']);
        }

        public refreshItemCount() {
            this.count.text = UI_Bag.get_item_count(309069) + '';
        }

        public refreshRedpoint() {
            this.help_redpoint.visible = UI_Activity_Miaohui.haveFriendRedPoint();
        }

        private setSpine(_display_id: number) {
            if (this.display_id == _display_id) return;
            this.display_id = _display_id;
            if (this.spine) {
                if (this.spine.root.parent == this.lihui) {
                    this.spine.root.visible = false;
                    this.spine.reset();
                    this.lihui.removeChild(this.spine.root);
                    
                }
                this.spine = null;
            }
            let important: boolean = false;
            this.spine = CatFoodSpine.SpineMgr.Inst.getSprite(game.Tools.localUISrc('extendRes/spine/NS_0' + _display_id), null, important);
            //添加到舞台
            this.lihui.addChild(this.spine.root);
            this.spine.root.visible = false;
            let id = this.spine.id;
            let setSpine = () => {
                if (!this.spine || id != this.spine.id) return;
                this.spine.root.pos(100, -140);
                this.spine.root.visible = true;
                this.lihui.scaleX = 1;
                this.spine.sx = this.spine.sy = 0.25;
                this.spine.pX = 0;
                this.spine.pY = 0;
                this.spine.offsetX = 695;
                this.spine.offsetY = 610;
                this.spine.play('idle');
                this.stopsay();
                this.say('greeting');
            }
            if (this.spine.state == CatFoodSpine.ESpineState.loaded) {
                setSpine();
            } else {
                this.spine.setLoadOverHandler(Laya.Handler.create(this, setSpine));
            }
        }

        public refreshFriendState() {
            this.friend_redpoint.visible = UI_Activity_Miaohui.haveFriendRedPoint();
        }

        public say(type:string) {
            if (this.sound_channel) return;
            let _group = cfg.voice.event.getGroup(1);
            if (type == 'click') {
                type = Math.random() < 0.5 ? 'click_1' : 'click_2';
            }
            let _data:lqc.Sheet_Voice_Event = null;
            for (let data of _group) {
                if (data.stage == (this.display_id - 1) && data.type == type) {
                    _data = data;
                    break;
                }
            }
            if (!_data) return;
            this.chat_id++;
			let chat_id = this.chat_id;
            let volume = view.AudioMgr.yuyinVolume * _data.volume_fix;
            if (view.AudioMgr.yuyinMuted) {
                volume = 0;
            }
            this.chat.show(_data['words_' + GameMgr.client_language]);
            // this.sound_channel = view.AudioMgr.PlaySound(_data.path, volume, Laya.Handler.create(this, ()=>{
            //     Laya.timer.once(500, this, ()=>{
			// 		if (this.chat_id == chat_id) {
			// 			this.stopsay();
			// 		}
			// 	});
            // }));
		}

		private stopsay() {
			// this.container_chat.visible = false;
			this.chat.close(false);
		}

        public refreshBtnRedpoint() {
            for (let i = 0; i < this.btns.length; i++) {
                 (this.btns[i].getChildByName('redpoint') as Laya.Sprite).visible = this.btn_states[i] == 0 && UI_Bag.get_item_count(309069) > 0;
            }
        }
    }
}