/**
* name 
*/
module uiscript{
	export class UI_Activity_NewYear extends UI_ActivityBase {

		private readonly activity_id:number = 1004;

		private root:Laya.Sprite;
		private content:Laya.Panel;
		private scrollbar:capsui.CScrollBar;

		private toth:number = 0;

		constructor() {
			super(cfg.activity.activity.get(1004)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_task_newyearUI());
		}

		public isopen():boolean {return UI_Activity.activities[1004];}

		public need_popout():boolean {
			let d = cfg.activity.activity.get(1004);
			if (d && d.need_popout) return true;
			return false;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = this.root.getChildByName('content') as Laya.Panel;
			this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.content.vScrollBarSkin = '';
			this.scrollbar.init(null);
			this.toth = (this.content.getChildByName('fu') as Laya.Sprite).y + (this.content.getChildByName('fu') as Laya.Sprite).height;
			this.content.vScrollBar.on('change', this, ()=>{
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.toth);
			});
		}

		public show() {
			this.enable = true;
			this.content.refresh();
			this.content.vScrollBar.value = 0;
			this.content.vScrollBar.stopScroll();
			this.scrollbar.reset();
			this.scrollbar.setVal(0, this.content.height / this.toth);
			game.LoadMgr.setImgSkin(this.root.getChildByName('content').getChildByName('head') as Laya.Image, 'myres2/treasurehead/newyear_task.jpg');
			game.LoadMgr.setImgSkin(this.content.getChildByName('denglong').getChildByName('info').getChildByName('item') as Laya.Image
				, game.GameUtility.get_item_view(309003).icon);
			game.LoadMgr.setImgSkin(this.content.getChildByName('baozhu').getChildByName('info').getChildByName('item') as Laya.Image
				, game.GameUtility.get_item_view(309004).icon);
			game.LoadMgr.setImgSkin(this.content.getChildByName('fu').getChildByName('info').getChildByName('item') as Laya.Image
				, game.GameUtility.get_item_view(309005).icon);
		}
		
		public hide() {
			this.enable = false;
		}
	}
}