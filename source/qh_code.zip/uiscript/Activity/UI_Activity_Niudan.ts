/**
* UI_Activity_Niudan  扭蛋活动 
*/
module uiscript {
    class Item_Task {
        public id: number;
        private bg: Laya.Image;
        private desc: Laya.Label;
        private progress_bar: Laya.Image;
        private progress_label: Laya.Label;
        private done: Laya.Sprite;
        private btn_receive: Laya.Button;
        private label_count: Laya.Label;
        // private gray: Laya.Sprite;
        // private receive: Laya.Sprite;
        // private count: Laya.Sprite;
        private reward_name: string;
        public me: Laya.Sprite;
        private receiveAnim: Laya.FrameAnimation;

        constructor(me: Laya.Sprite, anim: Laya.FrameAnimation) {
            this.me = me;
            this.receiveAnim = anim;
            this.bg = me.getChildAt(0) as Laya.Image;
            this.desc = me.getChildByName('desc') as Laya.Label;

            this.progress_bar = me.getChildByName('slider').getChildByName('bar') as Laya.Image;
            this.progress_label = me.getChildByName('progress') as Laya.Label;
            this.done = me.getChildByName('black_mask') as Laya.Sprite;
            this.btn_receive = me.getChildByName('btn_receive') as Laya.Button;
            this.label_count = me.getChildByName('count') as Laya.Label;

            
        }

        public set clickHandler(handler: Laya.Handler) { 
            this.btn_receive.clickHandler = handler;
        }

        public show(info: any) {
            if (!info) {
                this.btn_receive.mouseEnabled = false;
                return;
            }
            this.id = info['id'];
            let d_activity_task = UI_Activity_Task_Random.FindTaskInfo(this.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);

            if (info.rewarded) {
                this.btn_receive.visible = false;
                this.receiveAnim.stop();
                this.done.visible = true;
                this.label_count.visible = false;
                this.bg.skin = game.Tools.localUISrc('myres/activity_niudan/tag_achieved.png');
                // this.progress_bar.skin = game.Tools.localUISrc('myres/activity_niudan/bar_task_slider_done.png');
            } else {
                
                this.btn_receive.visible = info.achieved;
                this.label_count.visible = true;
                this.done.visible = false;
                this.btn_receive.mouseEnabled = info.achieved;
                // this.gray.visible = !info.achieved;
                // this.receive.visible = info.achieved;
                this.bg.skin = game.Tools.localUISrc('myres/activity_niudan/bg_item_task.png');
                if (info.achieved) {
                    this.receiveAnim.play(0, true);
                } else {
                    this.receiveAnim.stop();
                }
                
                // this.progress_bar.skin = game.Tools.localUISrc('myres/activity_niudan/bar_task_slider.png');
            }
            this.reward_name = game.GameUtility.get_item_view(d_activity_task.reward_id).name;
            this.label_count.text = '' + d_activity_task.reward_count;
            this.desc.text = d_task_info['desc_' + GameMgr.client_language];
            // if (GameMgr.client_language == 'jp') {
            //     this.desc.fontSize = 32;
            // }
            let counter: number = info.counter;
            if (!counter) counter = 0;
            if (counter > d_task_info.target) counter = d_task_info.target;
            this.progress_bar.width = counter == 0 ? 6 : 194 * counter / d_task_info.target;
            this.progress_label.text = counter.toString() + '/' + d_task_info.target.toString();
        }

        public set clickEnable(enable: boolean) { 
            this.btn_receive.mouseEnabled = enable;
        }

        public onRecived() { 
            this.btn_receive.visible = false;
            this.receiveAnim.stop();
            this.done.visible = true;
            this.label_count.visible = false;
            this.bg.skin = game.Tools.localUISrc('myres/activity_niudan/tag_achieved.png');
            let s: string = game.Tools.strOfLocalization(2234) + (this.reward_name + ' x' + this.label_count.text);
            UI_LightTips.Inst.show(s);
        }


    }
    // 球的图片信息
    interface IQiuPicInfo { fullPath: string, halfPath: string };
    // 球的数量状态
    enum EQiuCountState {high, middle, low, empty};

    export class UI_Activity_Niudan extends UIBase {
        public static Inst: UI_Activity_Niudan;
        public static activity_id: number = 250501;
        public static task_activity_id: number = 250502;
        public static gained_ids: Object = {};
        public static remain_count: number = 0;
        private static _consume_id: number;

        public static sceneMachinePath: string = 'scene/scene_effect_niudan.ls';
        public static effectMachinePath: string = 'scene/effect_niudan.lh';
        public static effectTitlePath: string = 'scene/effect_25niudan_title.lh';
        public static effectLightPath: string = 'scene/effect_25niudan_light.lh';

        private static picFullPath: string = 'scene/Assets/Resource/effect/eff_ui/activity/activity_extend/hd030/texture/';
        //彩的
        private static spQiuPicInfo: IQiuPicInfo = { fullPath: 'niudan_05.png', halfPath: 'niudan_06.png' };
        private static normalQiuInfoList: Array<IQiuPicInfo> = [
            //红的
            { fullPath: 'niudan_02.png', halfPath: 'niudan_09.png' },
            //黄的
            { fullPath: 'niudan_04.png', halfPath: 'niudan_10.png' },
            //紫的
            { fullPath: 'niudan_01.png', halfPath: 'niudan_11.png' },
            //蓝的
            { fullPath: 'niudan_03.png', halfPath: 'niudan_08.png' }
        ];

        /**
         * 获取扭蛋活动需要提前加载的列表
         */
        public static getPreloadList(): Array<string> {
            let list: Array<string> = [];
            // list.push(this.sceneMachinePath);
            list.push(this.picFullPath + this.spQiuPicInfo.halfPath);
            this.normalQiuInfoList.forEach((value)=>{
                list.push(this.picFullPath + value.halfPath); // full图 scene里会全部加载
            });
            return list;
        }

        public static get consume_id(): number {
            if (!this._consume_id) {
                let _data = cfg.activity.gacha_activity_info.get(this.activity_id);
                if (_data) {
                    this._consume_id = Number(_data.consume.split('-')[0]);
                    UI_Bag.add_item_listener(this._consume_id, new Laya.Handler(this, () => {
                        if (this.Inst) {
                            this.Inst.refreshCount();
                        }
                    }));
                }
            }
            return this._consume_id;
        }

        private static _pool_id: number;
        public static get pool_id(): number {
            if (!this._pool_id) {
                let _data = cfg.activity.gacha_activity_info.get(this.activity_id);
                if (_data) {
                    this._pool_id = _data.gacha_pool;
                }
            }
            return this._pool_id;
        }
        private static _reward_count: number;
        public static get reward_count(): number {
            if (!this._reward_count) {
                let _group = cfg.activity.gacha_pool.getGroup(this.pool_id);
                if (_group) {
                    this._reward_count = 0;
                    for (let data of _group) {
                        this._reward_count += data.count;
                    }
                }
            }
            return this._reward_count;
        }

        public static update_data(gacha_data: Array<{ activity_id: number, gained: Array<{ id: number, count: number }>, remain_count: number }>) {
            let res = null;
            for (let data of gacha_data) {
                if (data['activity_id'] == this.activity_id) {
                    res = data;
                    break;
                }
            }
            if (res) {
                this.remain_count = res.remain_count;
                this.gained_ids = {};
                for (let info of res.gained) {
                    this.gained_ids[info.id] = info.count;
                }
            } else {
                this.gained_ids = {};
                this.remain_count = 0;
            }
            if (this.Inst && this.Inst.enable) {
                this.Inst.refreshCount();
            }
        }

        public static have_redpoint(): boolean {
            if (this.remain_count == 0) return false;
            if (this.remain_count > 0 && UI_Bag.get_item_count(this.consume_id) > 0) {
                return true;
            }

            let lst = UI_Activity.getRandomTaskList(this.task_activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }

            return false;
        }

        public static onGachaResult(result_list: Array<number>) {
            for (let id of result_list) {
                if (!this.gained_ids[id]) {
                    this.gained_ids[id] = 1;
                } else {
                    this.gained_ids[id]++;
                }
            }
        }

        constructor() {
            super(new ui.lobby.activitys.activity_niudanUI());
            UI_Activity_Niudan.Inst = this;
        }

        private anim: ui.lobby.activitys.activity_niudanUI;
        private bg: Laya.Sprite;
        private top: Laya.Sprite; // 上方返回+数量
        private task: Laya.Sprite; // 左侧任务部分
        private right: Laya.Sprite; // 右侧抽奖区域
        private reward: Laya.Sprite; // 奖励部分
        private originTaskX: number;
        private originRightX: number;

        // 上方
        private label_count: Laya.Label;

        // 任务
        private item_tasks: Array<Item_Task>;

        // 抽奖
        private machineRoot: Laya.Sprite;
        private machine: Laya.Scene;
        private machineQiu: Laya.Sprite3D; //如果空了要关闭
        private rewardQiuMat: Laya.BaseMaterial; // 获得奖励时更换材质球贴图
        private machineAnim: Catfood.CAnimator;
        // private btnAnim: Catfood.CAnimator;
        private bgAnim: Catfood.CAnimator;
        private machineAnimNameBaseList: Array<string> = ['niudanji_laya_high_', 'niudanji_laya_mid_', 'niudanji_laya_low_', 'niudanji_laya_low_'];
        // private machineBtnAnimList: Array<string> = ['fx_ui_hd013_laya_button_l', 'fx_ui_hd013_laya_button_r'];
        // private remain_count: Laya.Label;
        private single_btn: Laya.Button;
        private ten_btn: Laya.Button;
        private shop: Laya.Sprite;
        private rewardAllBtn: Laya.Button;
      

        private qiuState: EQiuCountState;

        // 奖励部分
        // private reward_image: Laya.Image;
        // private half_image: Laya.Image;
        // private half_image01: Laya.Image;

        private effect: game.UIEffect;
        private effectParticles: Array<Laya.ShurikenParticleSystem>;
        private effectAnim: Catfood.CAnimator;
        private titleEffect: game.UIEffect;
        private taskLights: Array<game.UIEffect>;

        private leftCountRange: Array<number> = [70, 30, 1, 0]; // >=count为该等级显示

        public locking: boolean;

        public onCreate() {
            this.anim = this.me as ui.lobby.activitys.activity_niudanUI;
            this.bg = this.me.getChildByName('bg') as Laya.Sprite;
            this.top = this.me.getChildByName('top') as Laya.Sprite;
            this.task = this.me.getChildByName('task') as Laya.Sprite;
            this.right = this.me.getChildByName('right') as Laya.Sprite;
            // top
            this.label_count = this.top.getChildByName('count').getChildByName('count') as Laya.Label;
            (this.top.getChildByName('count').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_ItemDetail.Inst.show(UI_Activity_Niudan.consume_id);
            });

            (this.top.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            // task
            this.item_tasks = [];
            for (let i = 0; i < 3; i++) {
                let taskSprite = this.task.getChildByName('task').getChildByName('task_' + i) as Laya.Sprite;
                let index = i;
                let anim = this.anim['lizi' + index] as Laya.FrameAnimation;
                let task = new Item_Task(taskSprite, anim);
                task.clickHandler = new Laya.Handler(this, () => { 
                    if (this.locking) return;
                    let id = task.id;
                    task.clickEnable = false;
                    this.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'completeRandomActivityTask', { task_id: id }, (err, res) => {
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('completeRandomActivityTask', err, res);
                            task.clickEnable = true;
                            this.locking = false;
                        } else {
                            task.clickEnable = false;
                            //此处显示刷光
                            let lightEffect = this.taskLights[index];
                            lightEffect.effect.root.active = true;
                            Laya.timer.once(800, this, () => { 
                                lightEffect.effect.root.active = false;
                                task.onRecived();
                                UI_Activity.onTaskRewarded(id);
                                this.locking = false;
                            })
                            
                        }
                    });
                })
                this.item_tasks.push(task);
                
            }

            (this.task.getChildByName('btn_info') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Info_Mid.Inst.show(game.Tools.strOfLocalization(4601));
            });

            // 抽奖
            this.single_btn = this.right.getChildByName('machine').getChildByName('btns').getChildByName('btn_one') as Laya.Button;
            this.ten_btn = this.right.getChildByName('machine').getChildByName('btns').getChildByName('btn_ten') as Laya.Button;
            this.ten_btn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.openGacha(10);
            });

            this.single_btn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.openGacha(1);
            });


            // this.remain_count = this.right.getChildByName('left').getChildByName('count') as Laya.Label;
            let openReward = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Niudan_Reward.Inst.show();
            });
            this.rewardAllBtn = this.right.getChildByName('left').getChildByName('reward_all_btn') as Laya.Button;
            this.rewardAllBtn.clickHandler = openReward;
            


            let shopHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4471), Laya.Handler.create(this, ()=>{
                    this.close(Laya.Handler.create(this, () => { 
                        game.Scene_Lobby.Inst.change_bg('indoor', true);
                        UI_Shop.Inst.show(EShopType.skin, Laya.Handler.create(this, () => {
                            game.Scene_Lobby.Inst.change_bg('yard', true);
                            this.show();
                        }));
                    }));
                }));
                UI_SecondConfirm.Inst.setBtnState(true, true);

            })
            this.shop = this.right.getChildByName('shop') as Laya.Sprite;
            (this.shop.getChildByName('btn') as Laya.Button).clickHandler = shopHandler;
           
            this.machineRoot = this.right.getChildByName('machine').getChildByName('machine') as Laya.Sprite;
            this.reward = this.right.getChildByName('machine').getChildByName('reward') as Laya.Sprite;
            this.taskLights = [];

            let title = this.task.getChildByName('title') as Laya.Sprite;
            (title.getChildByName('title_chs') as Laya.Sprite).visible = GameMgr.client_language == 'chs' || GameMgr.client_language == 'chs_t';
            (title.getChildByName('title_en') as Laya.Sprite).visible = GameMgr.client_language == 'en';
            (title.getChildByName('title_kr') as Laya.Sprite).visible = GameMgr.client_language == 'kr';
            (title.getChildByName('title_jp') as Laya.Sprite).visible = GameMgr.client_language == 'jp';
           
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Niudan', true);
            (this.right.getChildByName('machine') as Laya.Sprite).visible = true;
        }

        public onDisable() {
            if (this.effect && !this.effect.destoryed) {
                this.effect.destory();
                this.effect = null;    
            }
            if (this.titleEffect && !this.titleEffect.destoryed) {
                this.titleEffect.destory();
                this.titleEffect = null;    
            }
            if (this.taskLights) {
                for (let i = 0; i < this.taskLights.length; i++) {
                    this.taskLights[i].destory();
                }
                this.taskLights = [];
            }
            game.TempImageMgr.setUIEnable('UI_Activity_Niudan', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_niudan.atlas'));
            (this.right.getChildByName('machine') as Laya.Sprite).visible = false;
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.initScene();
            this.initEffect();
            view.AudioMgr.PlayAudio(10169);
            this.anim.leave.stop();
            this.anim.enter.play(0, false);
            this.rewardAllBtn.mouseEnabled = false;
            this.titleEffect.effect.root.active = true;
            //等enter播放完毕后解锁
            this.anim.enter.once('complete', this, () => {
                this.locking = false;
                this.rewardAllBtn.mouseEnabled = true;
                // this.titleEffect.effect.root.active = false;
            });
            this.refreshCount();
            this.refreshRemainCount();
            this.showTasks();
            this.playMachineAnim('enter');
            this.playBgAnim('niudanji_bg_open');
        }


        public close(handler: Laya.Handler = null) {
            this.locking = true;
            this.anim.enter.stop();
            this.anim.leave.play(0, false);
            this.anim.leave.once('complete', this, () => {
                this.locking = false;
                this.enable = false;
                if (handler) {
                    handler.run();
                } else {
                    UI_Lobby.Inst.enable = true;
                }
            });
            this.playMachineAnim('out');
        }

        // 刷新道具数量
        private refreshCount() {
            let count = UI_Bag.get_item_count(UI_Activity_Niudan.consume_id);
            this.label_count.text = count + '';
            let noReward = UI_Activity_Niudan.remain_count == 0;
            (this.single_btn.getChildByName('black_mask') as Laya.Sprite).visible = count <= 0 || UI_Activity_Niudan.remain_count < 1;
            (this.ten_btn.getChildByName('black_mask') as Laya.Sprite).visible = count < 10 || UI_Activity_Niudan.remain_count < 10;

        }

        // 剩余次数
        private refreshRemainCount() {
            // this.remain_count.text = UI_Activity_Niudan.remain_count + '/' + UI_Activity_Niudan.reward_count;
            for (let i = 0; i < this.leftCountRange.length; i++) {
                if (UI_Activity_Niudan.remain_count >= this.leftCountRange[i]) {
                    this.qiuState = i;
                    break;
                }
            }
            if (this.qiuState == EQiuCountState.empty) {
                this.machineQiu.active = false;
            } else {
                this.machineQiu.active = true;
            }
        }

        private openGacha(count: number) {
            if (UI_Activity_Niudan.remain_count == 0) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3830));
                UI_SecondConfirm.Inst.setBtnState(true, true);
                return;
            }
            
            if (UI_Bag.get_item_count(UI_Activity_Niudan.consume_id) < count) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3829));
                UI_SecondConfirm.Inst.setBtnState(true, true);
                return;
            }
            
            if (UI_Activity_Niudan.remain_count < count) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3833));
                UI_SecondConfirm.Inst.setBtnState(true, true);
                return;
            }
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'openGacha', { activity_id: UI_Activity_Niudan.activity_id, count: count }, (err, res) => {

                if (err || res['error']) {
                    this.locking = false;
                    UIMgr.Inst.showNetReqError('openGacha', err, res);
                } else {
                    // UI_Activity_Niudan.onGachaResult(res['result_list']);

                    UI_Activity_Niudan.remain_count = res['remain_count'];
                    
                    this.refreshCount();
                    let rewards = [];
                    if (res['reward_items']) {
                        var func = (info) => {
                            let group = cfg.activity.gacha_pool.getGroup(UI_Activity_Niudan.pool_id);
                            let reward_str = info['id'] + '-' + info['count'];
                            let rare = 4;
                            for (let data of group) {
                                if (data.item == reward_str) {
                                    rare = data.rare;
                                    break;
                                }
                            }
                            info['bound'] = 'myres/activity_niudan/bound_' + rare + '.png';
                            info['offset_x'] = 3;
                            rewards.push(info);
                        }
                        for (let reward of res['reward_items']) {
                            let info = reward['reward'];
                            func(info)
                        }
                    }

                    let sp_rewards = [];
                    if (res['sp_reward_items']) {

                        var func = (info) => {
                            info['bound'] = 'myres/activity_niudan/bound_1.png';
                            info['offset_x'] = 3;
                            sp_rewards.push(info);

                        }
                        for (let reward of res['sp_reward_items']) {
                            let info = reward['reward'];
                            func(info)
                        }
                    }
                    let is_special = false;
                    let group = cfg.activity.gacha_pool.getGroup(UI_Activity_Niudan.pool_id);
                    let special_list: Array<number> = [];
                    for (let data of group) {
                        if (data.rare == 1) {
                            special_list.push(data.reward_id);
                        }
                    }
                    for (let id of res['result_list']) {
                        if (special_list.indexOf(id) != -1) {
                            is_special = true;
                            break;
                        }
                    }
                    this.showAnim(rewards, count == 1, is_special, sp_rewards);
                }
            });
        }

        //  播放动画  is_special,是否是特殊球， sp_rewards 特殊奖励
        private showAnim(rewards: any, is_single: boolean, is_special: boolean, sp_rewards: Array<any>) {
            let res = { rewards };
            view.AudioMgr.PlayAudio(10170);
            // this.anim.open.play(0, false);
            // 如果是非特殊球，随机一个颜色
            let qiuInfo: IQiuPicInfo;
            if (!is_special) {
                qiuInfo = UI_Activity_Niudan.normalQiuInfoList[Math.floor(Math.random() * UI_Activity_Niudan.normalQiuInfoList.length)];
            } else {
                qiuInfo = UI_Activity_Niudan.spQiuPicInfo;
            }
            // this.btnAnim.Play(this.machineBtnAnimList[is_single ? 0 : 1]);
            this.playMachineAnim('open');

            
            this.rewardQiuMat['_MainTex'] = Laya.loader.getRes(UI_Activity_Niudan.picFullPath + qiuInfo.fullPath);
            this.playEffect(qiuInfo, is_special);
            Laya.timer.once(3000, this, () => {
                this.refreshRemainCount();
                game.Tools.showRewards(res, Laya.Handler.create(this, () => {
                    if (sp_rewards && sp_rewards.length > 0) {
                        game.Tools.showRewards({ rewards: sp_rewards }, Laya.Handler.create(this, () => {
                            this.locking = false;

                        }));
                    } else {
                        this.locking = false;
                    }

                }), '', 30);
            })
            Laya.timer.once(3500, this, ()=>{
                if (this.effect) {
                    this.effect.effect.root.active = false;
                }
            })
            // this.reward.visible = true;

            // 三丽鸥版本改为特效
            // this.half_image.skin = game.Tools.localUISrc('myres/activity_niudan/tang_' + id + '.png');
            // this.reward_image.skin = game.Tools.localUISrc('myres/activity_niudan/tang_' + id + '.png');
            // this.half_image01.skin = game.Tools.localUISrc('myres/activity_niudan/tang_' + id + '_1.png');
        }


        private showTasks() {
            let list = UI_Activity.getRandomTaskList(UI_Activity_Niudan.task_activity_id);
            for (let i = 0; i < 3; i++) {
                this.item_tasks[i].show(list[i]);
            }
            // this.refreshView(UI_Activity.getRandomTaskList(UI_Activity_Niudan.task_activity_id));
        }

        // 初始化扭蛋机场景
        public initScene() {
            if (this.machine) {
                let bg = this.machine.getChildByName('root').getChildAt(0) as Laya.Sprite3D;
                bg.active = false;
                bg.active = true;
                return;
            }
            this.machine = Laya.loader.getRes(UI_Activity_Niudan.sceneMachinePath) as Laya.Scene;
            this.machineRoot.addChild(this.machine);
            this.machineQiu = this.machine.getChildByName('root').getChildAt(1).getChildAt(0).getChildByName('jq').getChildByName('jq').getChildByName('jq').getChildByName('d') as Laya.Sprite3D;
            this.rewardQiuMat = (this.machine.getChildByName('root').getChildAt(1).getChildAt(0).getChildByName('jq').getChildByName('jq').getChildByName('jq').getChildByName('jq').getChildByName('q').getChildByName('q02') as Laya.MeshSprite3D).meshRender.material;
            this.machineAnim = (this.machine.getChildByName('root').getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            // this.btnAnim = (this.machine.getChildByName('root').getChildAt(1).getChildAt(0).getChildByName('jq') as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            // this.btnAnim.Stop();
            this.bgAnim = (this.machine.getChildByName('root').getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
        }
        
        private initEffect() {
            this.effect = game.FrontEffect.Inst.create_ui_effect(this.reward, UI_Activity_Niudan.effectMachinePath, new Laya.Point(0, 0), 1);
            this.effect.effect.root.active = false;
            this.effect.effect.addLoadedListener(Laya.Handler.create(this, ()=>{
                this.onEffectLoadedEnd();
            }));
            let titleParent = this.task.getChildByName('title').getChildByName('title_effect') as Laya.Sprite;
            this.titleEffect = game.FrontEffect.Inst.create_ui_effect(titleParent, UI_Activity_Niudan.effectTitlePath, new Laya.Point(0, 0), 1);
            this.titleEffect.effect.root.active = false;

            for (let index = 0; index < this.item_tasks.length; index++) {
                let task = this.item_tasks[index];
                let light = game.FrontEffect.Inst.create_ui_effect(task.me, UI_Activity_Niudan.effectLightPath, new Laya.Point(346, 88), 1);
                light.effect.root.active = false;
                this.taskLights.push(light);
            }

        }
        
        private dfsParticleSystems(root: Laya.Sprite3D) {
            
			if (root instanceof Laya.ShuriKenParticle3D) {
				this.effectParticles.push(root.particleSystem);
			}
			for (let child of root._childs) {
				this.dfsParticleSystems(child);
			}
		}

        private playEffect(qiuInfo: IQiuPicInfo, is_special: boolean) {
            this.effect.effect.addLoadedListener(Laya.Handler.create(this, () => {
                if (!this.effectParticles) {
                    this.onEffectLoadedEnd();
                }
                let halfQiu = (this.effect.effect.root.getChildAt(0).getChildAt(0).getChildByName('Canvas').getChildByName('jq').getChildByName('qu').getChildByName('q').getChildAt(0).getChildAt(0).getChildAt(0).getChildAt(0) as Laya.MeshSprite3D)
                halfQiu.meshRender.material['_MainTex'] = Laya.loader.getRes(UI_Activity_Niudan.picFullPath + qiuInfo.halfPath);
                let sp = this.effect.effect.root.getChildAt(0).getChildAt(0).getChildByName('fx01') as Laya.Sprite3D;
                let normal = this.effect.effect.root.getChildAt(0).getChildAt(0).getChildByName('fx02') as Laya.Sprite3D;
                sp.active = is_special;
                normal.active  = !is_special;
                this.restartEffect();
            }));
        }
        
        private onEffectLoadedEnd() {
            this.effectParticles = [];
            this.effectAnim = (this.effect.effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.dfsParticleSystems(this.effect.effect.root);
        }
        private restartEffect() {
            this.effect.effect.root.active = true;
            for (let system of this.effectParticles) {
                system.simulate(0, true);
                system.play();
            }
            this.effectAnim.Play(null);
        }
        /**
         * 播放扭蛋机动画
         * @param name 动画种类
         * @param complete 动画结束回调，针对打开动画
         */
        private playMachineAnim(name: string) {
            this.machineAnim.Play(this.machineAnimNameBaseList[this.qiuState] + name);
            this.machineAnim.offAll('complete');
            if (name != 'idle' && name != 'out') {
                this.machineAnim.once('complete', this, ()=>{
                    this.playMachineAnim('idle');
                });
            }
            
        }

        private playBgAnim(name: string) {
            this.bgAnim.Play(name);
            this.bgAnim.offAll('complete');
            if (name != 'niudanji_bg_idle') {
                this.bgAnim.once('complete', this, () => {
                    Laya.timer.once(50, this, () => { 
                        this.playBgAnim('niudanji_bg_idle');
                    })
                });
            }
           
        }

        public destroyScene() {
            this.machine?.destroy();
            this.machine = null;
        }
        

    }
}