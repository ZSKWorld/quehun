/**
* UI_Activity_Niudan  扭蛋活动 
*/
module uiscript {
    // 一整行
    class Item_Reward_Parent {
        private templete: Laya.Sprite;
        private items: Array<Item_Reward>;
        private me: Laya.Sprite;


        private center_x: number = 384;
        private start_y: number = 11;
        private per_width: number = 200;
        private per_height: number = 210;

        constructor(me: Laya.Sprite, reward_ids: Array<{id: number, reward: string, count: number}>, rare: number) {
            this.me = me;
            let show_count = 5 - rare;
            let slide = this.me.getChildByName('slide') as Laya.Sprite;
            let rareImg = slide.getChildByName('level') as Laya.Image;
            rareImg.skin = game.Tools.localUISrc('myres/activity_niudan/reward_level' + show_count + '.png');
            this.items = [];
            let itemParent = this.me.getChildByName('items') as Laya.Sprite;
            this.templete = itemParent.getChildByName('item') as Laya.Sprite;
            let have_sp = false;
            if (rare == 1) {
                let data = cfg.activity.gacha_activity_info.get(UI_Activity_Niudan.activity_id);
                // 有奖励
                if (data.sp_rewards && data.sp_trigger_times <= UI_Activity_Niudan.reward_count) {
                    have_sp = true;
                }
            }
            let count = 0;
            if (have_sp) {
                let _item = count == 0 ? this.templete : this.templete.scriptMap['capsui.UICopy']['getNodeClone']();
                this.items.push(new Item_Reward(_item, null, true, rare));
                count++
            }

            for (let reward of reward_ids) {
                let _item = count == 0 ? this.templete : this.templete.scriptMap['capsui.UICopy']['getNodeClone']();
                
                this.items.push(new Item_Reward(_item, reward, false, rare));
                count++;
            }
            if (rare == 1 && GameMgr.client_language == 'en') {
                this.per_width = 220;
            }
            for (let i = 0; i < this.items.length; i++) {
                this.items[i].me.pos(count > 5 && i < 5 ?(this.center_x - this.per_width * ((5 - 1) / 2- i)) : this.center_x - this.per_width * ((count % 5 - 1) / 2 - i % 5), this.start_y + Math.floor(i / 5) * this.per_height);
            }
            this.me.height = 264 + Math.floor(count / 5) * this.per_height;
            // if (GameMgr.client_language == 'en') {
            //     (me.getChildAt(0) as Laya.Sprite).width = 350;
            //     (me.getChildAt(1) as Laya.Sprite).width = 350;
            // }
            if (!have_sp) {
                itemParent.y += 25;
            }
        }


        public refresh() {
            for (let item of this.items) {
                item.refresh();    
            }
        }


    }

    class Item_Reward {
        private total_count: number;
        private is_sp: boolean;
        private reward_id: number; // 对应gacha_pool表
        private item_id: number;

        public me: Laya.Sprite;
        private remain: Laya.Sprite;
        private label_remian: Laya.Label;
        private done: Laya.Sprite;

        constructor(me: Laya.Sprite, data: {id: number, reward: string, count: number}, is_sp: boolean, rare: number) {
            let count = 0;
            this.is_sp = is_sp;
            if (!is_sp) {
                this.total_count = data.count;
                this.reward_id = data.id;
                count = Number(data.reward.split('-')[1]);
                this.item_id = Number(data.reward.split('-')[0]);
            } else {
                this.total_count = 1;
                let __data = cfg.activity.gacha_activity_info.get(UI_Activity_Niudan.activity_id);
                this.item_id = Number(__data.sp_rewards.split('-')[0]);
                count = Number(__data.sp_rewards.split('-')[1]);
            }

            this.me = me;
            let title = me.getChildByName('title') as Laya.Image;
            if (is_sp || rare == 1) {
                title.visible = is_sp || (GameMgr.client_language != 'jp' && GameMgr.client_language != 'kr');
                title.skin = game.Tools.localUISrc(is_sp ? 'myres/activity_niudan/reward_sp.png' : 'myres/activity_niudan/reward_one.png');
            } else {
                title.visible = false;
            }
          
            let btn_item = me.getChildByName('btn') as Laya.Button;
            btn_item.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Niudan_Reward.Inst.locking) return;
                UI_ItemDetail.Inst.show(this.item_id);
            });

            this.remain = btn_item.getChildByName('remain') as Laya.Sprite;
            this.label_remian = this.remain.getChildByName('count') as Laya.Label;
            (btn_item.getChildByName('count').getChildByName('count') as Laya.Label).text = 'x' + count;
            this.done = btn_item.getChildByName('done') as Laya.Sprite;
            
            let d_currency = cfg.item_definition.currency.get(this.item_id);
            let icon = btn_item.getChildByName('icon') as Laya.Image;
            let origin_rect = UIRect.CreateFromSprite(icon);
            if (d_currency) {
                game.LoadMgr.setImgSkin(icon, d_currency.icon_jpg, null, 'UI_Activity_Niudan_Reward');
            } else {
                let d_view = game.GameUtility.get_item_view(this.item_id);
                game.LoadMgr.setImgSkin(icon, d_view.icon, null, 'UI_Activity_Niudan_Reward');
            }
            game.Tools.setItemIcon(icon, origin_rect, this.item_id);
            (btn_item.getChildByName('bound') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_niudan/bound_' + rare + '.png');
        }

        public refresh() {
            let left_count = 0;
            if (this.is_sp) {
                let data = cfg.activity.gacha_activity_info.get(UI_Activity_Niudan.activity_id);
                if (data.sp_trigger_times > (UI_Activity_Niudan.reward_count - UI_Activity_Niudan.remain_count)) {
                    left_count = 1;
                }
            } else {
                let gained_count = UI_Activity_Niudan.gained_ids[this.reward_id];
                if (!gained_count) {
                    gained_count = 0;
                }
                left_count = this.total_count - gained_count;
            }
            left_count = Math.max(0, left_count);
            // if (left_count > 0) {
                this.done.visible = left_count == 0;
                this.remain.visible = true;
                this.label_remian.text = game.Tools.strOfLocalization(3828) + left_count;
            // } else {
            //     this.done.visible = true;
            //     this.remain.visible = false;
            // }
        }
    }

    export class UI_Activity_Niudan_Reward extends UIBase {
        public static Inst: UI_Activity_Niudan_Reward;

        constructor() {
            super(new ui.lobby.activitys.activity_niudan_rewardUI());
            UI_Activity_Niudan_Reward.Inst = this;
        }

        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private remain_count: Laya.Label;
        private content: Laya.Panel;
        private scrollbar: capsui.CScrollBar;
        private reward_parent: Laya.Sprite;
        private item_rewards: Array<Item_Reward_Parent>;
        private tips: Laya.Label;
        private toth: number;
        public locking: boolean;

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, this.close);

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, this.close);

            this.remain_count = this.root.getChildByName('count').getChildByName('count') as Laya.Label;
            this.content = this.root.getChildByName('content') as Laya.Panel;
            this.content.vScrollBarSkin = '';
            this.content.vScrollBar.on('change', this, ()=>{
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.toth);
			});

            this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this.scrollbar.init(new Laya.Handler(this, (rate)=>{
                this.content.vScrollBar.value = this.content.vScrollBar.max * rate;
            }));

            // 初始化奖励列表
            this.reward_parent = this.content.getChildByName('parent') as Laya.Sprite;
            let datas = cfg.activity.gacha_pool.getGroup(UI_Activity_Niudan.pool_id);
            this.item_rewards = [];
            if (datas) {
                let _sort_datas = {};
                let max_rare = 0;
                for (let data of datas) {
                    if (!_sort_datas[data.rare]) {
                        max_rare = Math.max(data.rare, max_rare);
                        _sort_datas[data.rare] = [{id: data.reward_id, reward: data.item, count: data.count}];
                    } else {
                        _sort_datas[data.rare].push({id: data.reward_id, reward: data.item, count: data.count});
                    }
                }
                let templete = this.reward_parent.getChildByName('templete') as Laya.Sprite;
                
                let _h = 0;
                for (let i = 1; i <= max_rare; i++) {
                    if (!_sort_datas[i]) continue;
                    let _item: Laya.Sprite = templete.scriptMap['capsui.UICopy']['getNodeClone']();
                    _item.y = _h;
                    let item_reward = new Item_Reward_Parent(_item, _sort_datas[i], i);
                    _h += _item.height;
                    this.item_rewards.push(item_reward);
                }
                templete.visible = false;
                this.reward_parent.height = _h;
                this.toth = _h;
                this.content.refresh();
            } else {
                this.content.visible = false;
                this.toth = 0;
            }
        }

        public show() {
            this.enable = true;
            game.TempImageMgr.setUIEnable('UI_Activity_Niudan_Reward', true);
            this.remain_count.text = game.Tools.strOfLocalization(3817) + UI_Activity_Niudan.remain_count +'/' + UI_Activity_Niudan.reward_count;
            this.locking = true;
            this.root.scale(1,1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, {alpha: 0.5}, 200);
            for (let item of this.item_rewards) {
                item.refresh();
            }
        }

        public close() {
            if (this.locking) return;
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
                this.enable = false;
			}));
            Laya.Tween.to(this.bg, {alpha: 0}, 200);
        }

        public onDisable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Niudan_Reward', false);
		}
    }
}