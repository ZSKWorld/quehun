module uiscript {
    class TaskCell {
        public me: Laya.Sprite;

        private container_info: Laya.Sprite;
        private item_name: Laya.Label;
        private item_icon: Laya.Image;
        private task_name: Laya.Label;
        private bar_parent: Laya.Sprite;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;
        private btn_get: Laya.Button;
        private getted: Laya.Sprite;
        private lock: Laya.Sprite;
        private lock_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;
        private reward_count: number = 0;
        private father: UI_Activity_RPG_Task;

        public constructor(me: Laya.Sprite, father: UI_Activity_RPG_Task) {
            this.me = me;
            this.father = father;
            this.me.visible = false;
            this.container_info = me.getChildByName('info') as Laya.Sprite;
            this.task_name = this.container_info.getChildByName('requirement') as Laya.Label;
            let item = this.me.getChildByName('item') as Laya.Sprite;
            this.item_icon = item.getChildByName('item') as Laya.Image;
            this.item_name = item.getChildByName('item_name') as Laya.Label;
            this.bar_parent = this.container_info.getChildByName('bar') as Laya.Sprite;
            this.progress_bar = this.container_info.getChildByName('bar').getChildByName('val') as Laya.Sprite;
            this.progress_label = this.container_info.getChildByName('progress') as Laya.Label;
            this.btn_get = this.container_info.getChildByName('btn_get') as Laya.Button;
            this.getted = this.container_info.getChildByName('getted') as Laya.Sprite;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.lock_label = this.lock.getChildByName('time') as Laya.Label;
            
        }

        public show(info: any) {
            this.me.visible = true;
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);

            this.container_info.visible = true;


            if (info.rewarded) {
                this.getted.visible = true;
                this.lock.visible = false;
                this.btn_get.visible = false;
                this.bar_parent.visible =false;
                this.progress_label.visible = false;
            } else {
                this.getted.visible = false;

                if (info.achieved) {
                    this.btn_get.visible = true;
                    this.progress_label.visible = false;
                    this.bar_parent.visible = false;
                    this.setBtnGrayDisable(false);
                    this.btn_get.clickHandler = Laya.Handler.create(this, () => {
                        this.setBtnGrayDisable(true);
                        app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: id }, (err, res) => {
                            this.setBtnGrayDisable(false);
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                            } else {
                                if (this.id == id) {
                                    this.getted.visible = true;
                                    this.lock.visible = false;
                                    this.container_info.visible = true;
                                    this.btn_get.visible = false;
                                    let count = this.reward_count;

                                    let s: string = game.Tools.strOfLocalization(2234) + this.item_name.text;
                                    UI_LightTips.Inst.show(s);

                                }
                                this.father.task_rewarded(id);
                                UI_Rpg.Inst.refreshRedpoint();
                                UI_Activity.onTaskRewarded(id);
                            }
                        });
                    }, null, false);
                } else {
                    this.progress_label.visible = true;
                    this.bar_parent.visible = true;
                    this.setBtnGrayDisable(true);
                    this.btn_get.clickHandler = null;
                    this.btn_get.visible = false;

                }
            }

            this.task_name.text = d_task_info['desc_' + GameMgr.client_language];

            let reward = d_activity_task.reward.split('-');
            this.item_id = parseInt(reward[0]);


            this.reward_count = parseInt(reward[1]);
            let d_currency = cfg.item_definition.currency.get(this.item_id);
            let delta = UI_Activity_RPG_Task.getActivityDeltaDay();
            let is_lock = d_activity_task.reward_limit_day > delta;
            if (d_currency) {
                this.item_name.text = d_currency['name_' + GameMgr.client_language];
            } else {
                let d_item = cfg.item_definition.item.get(this.item_id);
                if (d_item) {
                    
                    this.item_name.text = d_item['name_' + GameMgr.client_language] + 'x' + reward[1];
                }
            }
            
           
            
            this.item_icon.skin = game.Tools.localUISrc(is_lock ? 'myres/activity_rpg/icon_skill_d.png': 'myres/activity_rpg/icon_skill_m.png');
            let counter: number = info.counter;
            if (!counter) counter = 0;
            if (counter > d_task_info.target) counter = d_task_info.target;
            this.progress_bar.scaleX = counter / d_task_info.target;
            this.progress_label.text = counter.toString() + '/' + d_task_info.target.toString();

            
            this.lock.visible = is_lock;
            this.container_info.visible = !is_lock;
            if (is_lock) {
                this.lock_label.text = game.Tools.eventStrOfLocalization(741 + d_activity_task.reward_limit_day);
            }
        }
        private setBtnGrayDisable(gray: boolean) {
            game.Tools.setGrayDisable(this.btn_get, gray);
        }

    }


    export class UI_Activity_RPG_Task extends UIBase {
        public static activity_id: number = 220813;
        public static Inst: UI_Activity_RPG_Task = null;
        public static getActivityDeltaDay(): number {
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }

        public static haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_RPG_Task.activity_id);
            let delta = UI_Activity_RPG_Task.getActivityDeltaDay();
            for (let data of lst) {
                if (!data['rewarded'] && data['achieved']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData.reward_limit_day <= delta) return true;
                }
            }
            return false;
        }

        constructor() {
            super(new ui.lobby.activitys.activity_rpg_taskUI);
            UI_Activity_RPG_Task.Inst = this;
        }

        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private scrollview: capsui.CScrollView;
        private tabs: Array<Laya.Sprite> = [];
        private empty: Laya.Sprite;

        private all_data_lst: Array<Object> = [];
        private show_data_lst: Array<Object> = [];
        private reddot: Laya.Sprite;

        private locking: boolean;

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.scrollview = this.root.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
            this.scrollview.setElastic();
            let tabs_parent = this.root.getChildByName('tabs') as Laya.Sprite;
            this.empty = this.root.getChildByName('empty') as Laya.Sprite;
            // this.reddot = tabs_parent.getChildByName('achieved').getChildByName('redpoint') as Laya.Sprite;
            for (let i = 0; i < tabs_parent.numChildren; i++) {
                this.tabs.push(tabs_parent.getChildAt(i) as Laya.Sprite);
                (tabs_parent.getChildAt(i) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    this.on_tab_btn_click(i);
                });
            }
            (this.tabs[0].getChildAt(2) as Laya.Label).text = game.Tools.eventStrOfLocalization(697);
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            (this.me.getChildAt(1) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
        }
     
        public show() {
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            Laya.Tween.to(this.bg, {alpha: 0.5}, 200);
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_RPG_Task.activity_id);
            this.all_data_lst = lst;
            this.on_tab_btn_click(0);
        }

        private close() {
            this.locking = true;
            this.bg.alpha = 0;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
            Laya.Tween.to(this.bg, {alpha: 0}, 200);
        }
        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.show_data_lst[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container, this);
            }
            cache_data['cell'].show(data);

        }

        private on_tab_btn_click(tab_index: number) {
            for (let i = 0; i < this.tabs.length; i++) {
                (this.tabs[i].getChildAt(0) as Laya.Sprite).visible = tab_index == i;
                (this.tabs[i].getChildAt(1) as Laya.Sprite).visible = tab_index != i;
                (this.tabs[i].getChildAt(2) as Laya.Label).color = tab_index == i ? '#f6e7c0' : '#ac8e6c';
            }
            let delta = UI_Activity_RPG_Task.getActivityDeltaDay();
            switch (tab_index) {
                case 0: // 全部
                    this.show_data_lst = [];
                    let _index = 0;
                    for (let data of this.all_data_lst) {
                        let cfgData = cfg.activity.period_task.get(data['id']);
                        if (cfgData.reward_limit_day <= delta) {
                            this.show_data_lst.splice(_index++, 0, data);
                        } else {
                            this.show_data_lst.push(data);
                        }
                    }
                    break;
                case 1: // 未完成
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        if (!data['rewarded'] && !data['achieved']) {
                            let cfgData = cfg.activity.period_task.get(data['id']);
                            if (cfgData.reward_limit_day <= delta) this.show_data_lst.push(data);
                        }
                    }
                    break;
                case 2: // 已完成
                    this.show_data_lst = [];
                    let index = 0;
                    for (let data of this.all_data_lst) {
                        let cfgData = cfg.activity.period_task.get(data['id']);
                        if (cfgData.reward_limit_day > delta) {

                        } else if (!data['rewarded'] && data['achieved']) {
                            this.show_data_lst.splice(index++, 0, data);
                        } else if (data['rewarded']) {
                            this.show_data_lst.push(data);
                        }
                    }
                    break;

            }
            this.empty.visible = this.show_data_lst.length == 0;
            this.scrollview.reset();
            this.scrollview.addItem(this.show_data_lst.length);
        }
        // 由于show_list与实际数据不匹配，完成任务时需要额外修改rewarded
        public task_rewarded(task_id: number) {
            for (let task of this.show_data_lst) {
                if (task['id'] == task_id) {
                    task['rewarded'] = true;
                    return;
                }
            }
        }

    }
}