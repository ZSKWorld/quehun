module uiscript {
    class Item_Buff {
        public static colors: Array<string> = ['#6f5b52', '#536150', '#505f64', '#504e64', '#615058'];
        public static def_color: string = '#FFF8E8';
        public me: Laya.Sprite;
        private btn: Laya.Button;
        private icon: Laya.Image;
        private index: number;
        private bg: Laya.Image;
        private title: Laya.Image;
        private label_level: Laya.Label;
        private label_level_info_list: Array<Laya.Label>;
        private deco_level_list: Array<Laya.Image>;
        private label_cost: Laya.Label;
        private label_enough: Laya.Label;
        private label_max: Laya.Label;
        private buff_id: number;
        private color: string;

        constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.index = index;
            this.btn = this.me.getChildByName('btn_upgrade') as Laya.Button;
            this.icon = this.btn.getChildByName('icon_skill_item') as Laya.Image;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.title = this.me.getChildByName('title') as Laya.Image;
            this.label_level = this.me.getChildByName('level') as Laya.Label;
            this.label_cost = this.me.getChildByName('label_cost') as Laya.Label;
            this.label_enough = this.me.getChildByName('label_enough') as Laya.Label;
            this.label_max = this.me.getChildByName('label_max') as Laya.Label;

            this.buff_id = UI_Activity_RPG.buff_id[index];
            this.bg.skin = game.Tools.localUISrc('myres/rpg/bg_skill_' + index + '.png');
            this.title.skin = game.Tools.localUISrc('myres/rpg/title_skill_' + index + '.png');

            this.color = Item_Buff.colors[index];
            this.label_max.color = this.color;
            this.label_enough.text = game.Tools.eventStrOfLocalization(739);
            this.label_max.text = game.Tools.eventStrOfLocalization(737);
            this.deco_level_list = [];
            this.label_level_info_list = [];
            for (let i = 1; i < 4; i++) {
                let item = this.me.getChildByName('level_' + i) as Laya.Sprite;
                this.deco_level_list.push(item.getChildAt(0) as Laya.Image);
                let label = item.getChildAt(1) as Laya.Label;
                label.text = game.Tools.eventStrOfLocalization(719 + i + 3 * index);
                this.label_level_info_list.push(label);
            }

            this.btn.clickHandler = new Laya.Handler(this, this.onBuffUpBtnClick);
        }

        public refresh() {
            let level = UI_Activity.getActivityBuffLevel(this.buff_id);
            this.label_level.text = level ? game.Tools.eventStrOfLocalization(740) + level : game.Tools.eventStrOfLocalization(736);
            for (let i = 0; i < this.deco_level_list.length; i++) {
                if ((i + 1) > level) {
                    this.label_level_info_list[i].color = this.color;
                    this.deco_level_list[i].skin = game.Tools.localUISrc('myres/activity_rpg/deco_3.png');
                } else {
                    this.label_level_info_list[i].color = Item_Buff.def_color;
                    this.deco_level_list[i].skin = game.Tools.localUISrc('myres/activity_rpg/deco_2.png');
                }
            }
            if (level == 3) {
                this.label_cost.visible = false;
                this.label_enough.visible = false;
                this.label_max.visible = true;
                this.setBtnEnable(false);
            } else {
                let lst = cfg.activity.activity_buff.getGroup(this.buff_id);
                let _cost_count = 0;
                let _cost_id = 0;
                for (let buffData of lst) {
                    if (buffData.buff_level == level + 1) {
                        _cost_count = buffData.upgrade_resource_count;
                        _cost_id = buffData.upgrade_resource_id;
                        break;
                    }
                }
                this.label_cost.visible = true;
                this.label_max.visible = false;
                this.label_cost.text = game.Tools.eventStrOfLocalization(735) + _cost_count;
                if (_cost_count <= UI_Bag.get_item_count(_cost_id)) {
                    this.label_cost.y = 142;
                    this.label_enough.visible = true;
                    this.setBtnEnable(true);
                } else {
                    this.label_cost.y = 130;
                    this.label_enough.visible = false;
                    this.setBtnEnable(false);
                }
            }
        }

        private setBtnEnable(enable: boolean) {
            // this.btn.scale(1,1);
            this.icon.skin = enable ? game.Tools.localUISrc('myres/activity_rpg/icon_skill.png') : game.Tools.localUISrc('myres/activity_rpg/icon_skill_d.png')
        }

        private onBuffUpBtnClick() {
            if (UI_Activity_RPG_Xiulian.Inst.locking) return;
            let level = UI_Activity.getActivityBuffLevel(this.buff_id);
            if (level == 3) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3660));
                return;
            }
            let lst = cfg.activity.activity_buff.getGroup(this.buff_id);
            let _cost_count = 0;
            let _cost_id = 0;
            for (let buffData of lst) {
                if (buffData.buff_level == level + 1) {
                    _cost_count = buffData.upgrade_resource_count;
                    _cost_id = buffData.upgrade_resource_id;
                    break;
                }
            }
            // 道具不足
            if (_cost_count > UI_Bag.get_item_count(_cost_id)) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.eventStrOfLocalization(738));
                return;
            }
            ;
            UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3666, [_cost_count + '', game.Tools.eventStrOfLocalization(700 + this.index)]), Laya.Handler.create(this, () => {
                UI_Activity_RPG_Xiulian.Inst.locking = true;
                this.btn.mouseEnabled = false
                app.NetAgent.sendReq2Lobby('Lobby', 'upgradeActivityBuff', { buff_id: this.buff_id }, (err, res) => {
                    this.btn.mouseEnabled = true;
                    UI_Activity_RPG_Xiulian.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('upgradeActivityBuff', err, res);
                    } else {
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(3667));
                        UI_Activity.upgradeActivityBuff(this.buff_id);
                        UI_Activity_RPG_Xiulian.Inst.refreshItems();
                        UI_Rpg.Inst.refreshRedpoint();
                        UI_Activity_RPG_Xiulian.Inst.refreshItemCount();
                    }
                });
            }));

        }
    }


    export class UI_Activity_RPG_Xiulian extends UIBase {
        public static activity_id: number = 220812;

        public static Inst: UI_Activity_RPG_Xiulian = null;

        public static getActivityDeltaDay(): number {
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }

        public static have_red_point(): boolean {
            let _count = UI_Bag.get_item_count(309041);
            for (let id of UI_Activity_RPG.buff_id) {
                let level = UI_Activity.getActivityBuffLevel(id);
                if (level < 3) {
                    let lst = cfg.activity.activity_buff.getGroup(id);
                    let _cost_count = 0;
                    for (let buffData of lst) {
                        if (buffData.buff_level == level + 1) {
                            _cost_count = buffData.upgrade_resource_count;
                            if (_count >= _cost_count) return true;
                            break;
                        }
                    }
                }
            }
            return false;
        }
        constructor() {
            super(new ui.lobby.activitys.activity_rpg_xiulianUI());
            UI_Activity_RPG_Xiulian.Inst = this;
        }

        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private items: Array<Item_Buff>;
        private scrollbar: capsui.CScrollBar;
        private content: Laya.Panel;
        private label_count: Laya.Label;
        private toth: number = 740;

        public locking: boolean;

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            (this.me.getChildAt(1) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.content = this.root.getChildByName('content') as Laya.Panel;
            this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this.scrollbar.init(null);
            this.content.vScrollBarSkin = '';
            this.content.vScrollBar.elasticDistance = 350;
            this.content.vScrollBar.elasticBackTime = 250;
            this.content.vScrollBar.on('change', this, () => {
                this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.toth);
            });
            this.items = [];
            for (let i = 0; i < 5; i++) {
                let item = new Item_Buff(this.content.getChildByName(i + '') as Laya.Sprite, i);
                this.items.push(item);
            }

            this.label_count = this.root.getChildByName('skill_point').getChildByName('count') as Laya.Label;
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 150);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.refreshItems();
            this.refreshItemCount();
        }

        public refreshItemCount() {
            let _count = UI_Bag.get_item_count(309041);
            let _data = cfg.item_definition.item.get(309041);
            this.label_count.text = _data['name_' + GameMgr.client_language] + ': ' + _count;
        }
        public close() {
            this.locking = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 150);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public refreshItems() {
            for (let item of this.items) {
                item.refresh();
            }
        }
    }
}