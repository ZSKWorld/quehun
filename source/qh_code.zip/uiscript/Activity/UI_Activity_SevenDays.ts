/**
* UI_Activity_SevenDays  新手7日 
*/
module uiscript {
    enum E_Task_Btn_Type { None = -1, Received, Jump, QA };

    class Item_Task {
        private me: Laya.Sprite;
        private icon: Laya.Image;
        private btn: Laya.Button; // 功能按钮
        private btn_icon: Laya.Image; // 按钮图标,根据功能切换
        private complete: Laya.Sprite; // 完成标记
        private progress: Laya.Label; // 进度
        private count: Laya.Label;
        private desc: Laya.Label;
        private index: number;
        private item_id: number;
        private origin_rect: UIRect;
        private data: lqc.Sheet_Activity_TaskDisplay;

        private btn_type: E_Task_Btn_Type = E_Task_Btn_Type.None;
        private btn_param: number;

        constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.index = index;
            let item = this.me.getChildByName('item') as Laya.Button;
            item.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_SevenDays.Inst.locking || this.item_id == 0) return;
                UI_ItemDetail.Inst.show(this.item_id);
            });
            this.count = item.getChildByName('count') as Laya.Label;
            this.icon = item.getChildByName('icon') as Laya.Image;
            this.icon.skin = '';
            this.complete = this.me.getChildByName('complete') as Laya.Sprite;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_SevenDays.Inst.locking) return;
                if (this.btn_type == E_Task_Btn_Type.Received) {
                    UI_Activity_SevenDays.Inst.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: this.data.period_task_id }, (err, res) => {
                        UI_Activity_SevenDays.Inst.locking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                        } else {
                            this.btn.visible = false;
                            this.complete.visible = true;
                            UI_Activity.onPeriodTaskRewarded(this.data.period_task_id);
                            let reward_id: number = 0;
                            let reward_count: number = 0;
                            let d_activity_task = cfg.activity.period_task.get(this.data.period_task_id);
                            {
                                let ss: Array<string> = d_activity_task.reward.split('-');
                                reward_id = parseInt(ss[0]);
                                reward_count = parseInt(ss[1]);
                            }
                            UI_Activity_SevenDays.Inst.page_task.refreshRedpoint();
                            let _info = game.GameUtility.get_item_view(reward_id);
                            game.Tools.showRewards({rewards: [{id: reward_id, count: reward_count}]}, Laya.Handler.create(this, ()=>{
                                UI_Activity_SevenDays.Inst.page_task.checkTotalCanReceive();
                            }));
                        }
                    });
                } else if (this.btn_type == E_Task_Btn_Type.QA) {
                    UI_Activity_SevenDays.Inst.showQA(this.data);
                } else if (this.btn_type == E_Task_Btn_Type.Jump) {
                    let period_task_data = cfg.activity.period_task.get(this.data.period_task_id);
                    let base_task_data = cfg.events.base_task.get(period_task_data.base_task_id);
                    switch(this.btn_param) {
                        case 1: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Rules.Inst.show();
                            break;
                        }
                        case 2: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Sushe.Inst.show(0);
                            }));
                            break;
                        }
                        case 3: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Shop.Inst.show();
                            }));
                            break;
                        }
                        case 4: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_PaiPu.Inst.show();
                            }));
                            break;
                        }
                        case 5: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Ob.Inst.show();
                            }));
                            break;
                        }
                        case 6: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Achievement.Inst.show();
                            }));
                            break;
                        }
                        case 11: {
                            if (UI_PiPeiYuYue.Inst.enable) {
                                UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                                return;
                            }
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Create_Room.Show();
                            }));
                            break;
                        }
                        case 12: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.setPage(ELobbyPage.rank);
                            break;
                        }
                        case 13: {
                            UI_Activity_SevenDays.Inst.close();
                            UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                                UI_Bag.Inst.show(1);
                            }));
                            break;
                        }
                    }
                }
            });
            this.btn_icon = this.btn.getChildAt(0) as Laya.Image;
            this.desc = this.me.getChildByName('desc') as Laya.Label;
            this.progress = this.me.getChildByName('progress') as Laya.Label;
            this.origin_rect = UIRect.CreateFromSprite(this.icon);
        }

        public refresh() {
            let info = UI_Activity.getPeriodTaskInfo(this.data.period_task_id);
            let period_task_data = cfg.activity.period_task.get(this.data.period_task_id);
           
            if (!period_task_data || !info) {
                this.complete.visible = false;
                this.progress.visible = false;
                this.btn.visible = false;
                return;
            }

            let base_task_data = cfg.events.base_task.get(period_task_data.base_task_id);
            game.Tools.setItemIcon(this.icon, this.origin_rect, this.item_id, 'UI_Activity_SevenDays', true);
            if (info['rewarded']) {
                this.btn.visible = false;
                this.progress.visible = false;
                this.complete.visible = true;
            } else if (info['achieved']) {
                this.btn_type = E_Task_Btn_Type.Received;
                this.btn.visible = true;
                this.progress.visible = false;
                this.complete.visible = false;
                this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_receive.png');
            } else if (this.data.task_type == 1) {
                this.btn_type = E_Task_Btn_Type.QA;
                this.btn.visible = true;
                this.progress.visible = false;
                this.complete.visible = false;
                this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_qa.png');
                this.btn_param = Number(base_task_data.param[1]);
            } else if (base_task_data.type == 81) {
                this.btn_type = E_Task_Btn_Type.Jump;
                this.btn.visible = true;
                this.progress.visible = false;
                this.complete.visible = false;
                this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_jump.png');
                this.btn_param = Number(base_task_data.param[1]);
            } else {
                if (this.data.period_task_id == 23060115) {
                    this.btn_type = E_Task_Btn_Type.Jump;
                    this.btn_param = 11;
                    this.btn.visible = true;
                    this.progress.visible = false;
                    this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_jump.png');
                } else if (this.data.period_task_id == 23060120) {
                    this.btn_type = E_Task_Btn_Type.Jump;
                    this.btn_param = 12;
                    this.btn.visible = true;
                    this.progress.visible = false;
                    this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_jump.png');
                } else if (this.data.period_task_id == 23060114) {
                    this.btn_type = E_Task_Btn_Type.Jump;
                    this.btn_param = 13;
                    this.btn.visible = true;
                    this.progress.visible = false;
                    this.btn_icon.skin = game.Tools.localUISrc('myres/activity_qiri/btn_jump.png');
                } else {
                    this.btn.visible = false;
                    this.progress.visible = true;
                }
                
                this.complete.visible = false;
                let counter: number = info['counter'];
                if (!counter) counter = 0;
                this.progress.text = counter + '/' + base_task_data.target;
            }
        }
        public setData(data: lqc.Sheet_Activity_TaskDisplay) {
            this.data = data;
            let period_task_data = cfg.activity.period_task.get(this.data.period_task_id);
            if (!period_task_data) return;
            let reward = period_task_data.reward.split('-');
            this.item_id = Number(reward[0]);
            this.count.text = reward[1];
            let base_task_data = cfg.events.base_task.get(period_task_data.base_task_id);
            this.desc.text = base_task_data['desc_' + GameMgr.client_language];
            this.refresh();
        }

        private setBtnGrayDisable(gray: boolean) {
            this.btn.mouseEnabled = gray;
        }
    }
    class Page_Task {
        private me: Laya.Sprite;
        private items: Array<Item_Task>;
        private tabs: Array<{
            btn: Laya.Button,
            img: Laya.Image,
            text: Laya.Label,
            tag: Laya.Image,
            redpoint: Laya.Sprite
        }>;
        private item_ids: Array<number>;
        private origin_rect: UIRect;
        public show_day: number = 0;
        private task_datas: Array<Array<lqc.Sheet_Activity_TaskDisplay>>; //从1-7天的任务，总任务不在这 
        private task_infos: Array<Object>; // 任务信息
        private total_task_id: number = 23060122;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.items = [];
            for (let i = 0; i < 3; i++) {
                this.items.push(new Item_Task(this.me.getChildByName('task' + i) as Laya.Sprite, i));
            }
            let tab_parent = this.me.getChildByName('tabs') as Laya.Sprite;
            this.tabs = [];
            for (let i = 0; i < 7; i++) {
                let btn = tab_parent.getChildAt(i) as Laya.Button;
                btn.clickHandler = new Laya.Handler(this, () => {
                    this.showTaskByDay(i + 1);
                });
                (btn.getChildByName('text') as Laya.Label).text = i + 1 + '';
                this.tabs.push({ btn: btn, img: btn.getChildByName('img') as Laya.Image, text: btn.getChildByName('text') as Laya.Label, 
                tag: btn.getChildByName('tag') as Laya.Image, redpoint: btn.getChildByName('redpoint') as Laya.Sprite });
            }

            let _task_data = cfg.activity.period_task.get(this.total_task_id);
            let rewards = _task_data.reward.split(',');
            this.origin_rect = UIRect.CreateFromSprite(this.me.getChildByName('total').getChildByName('item0').getChildByName('icon') as Laya.Image);
            for (let i = 0; i < 3; i++) {
                let btn = this.me.getChildByName('total').getChildByName('item' + i) as Laya.Sprite;
                if (i < rewards.length) {
                    let reward_id = Number(rewards[i].split('-')[0]);
                    (btn.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                        if (UI_Activity_SevenDays.Inst.locking) return;
                        UI_ItemDetail.Inst.show(reward_id);
                    });
                    game.Tools.setItemIcon(btn.getChildByName('icon') as Laya.Image, this.origin_rect, reward_id, 'UI_Activity_SevenDays', true);
                } else {
                    btn.visible = false;
                }
            }
            this.task_datas = [];
            let datas = cfg.activity.task_display.getGroup(UI_Activity_SevenDays.activity_id);
            for (let i = 0; i < 7; i++) {
                this.task_datas.push([]);
            }
            for (let data of datas) {
                if (data.task_serial_number != 0) {
                    this.task_datas[data.day - 1][data.task_serial_number - 1] = data;
                }
            }

            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_SevenDays.Inst.locking) return;
                UI_Activity_SevenDays.Inst.close();
            })
        }

        public show() {
            this.me.visible = true;
            let day = this.show_day;
            
            let show_day = this.refreshTabs();
            if (day == 0) {
                day = show_day ? show_day : 1;
            }
            this.showTaskByDay(day);
            this.refreshRedpoint();
            this.checkTotalCanReceive();
        }

        public hide() {
            
            this.me.visible = false;
        }


        // 返回当前应该显示哪一天
        private refreshTabs(): number {
            let day = 0;
            for (let i = 0; i < this.tabs.length; i++) {
                let info = UI_Activity.getPeriodTaskInfo(this.task_datas[i][0].period_task_id);
                let tab = this.tabs[i];
                tab.text.color = '#8d6f61';
                if (!info) {
                    tab.btn.mouseEnabled = false;
                    tab.btn.alpha = 0.6;

                    tab.tag.visible = true;
                    tab.tag.skin = game.Tools.localUISrc('myres/activity_qiri/lock.png');
                    if (!day) {
                        day = i;
                    }
                } else {
                    tab.btn.mouseEnabled = true;
                    tab.btn.alpha = 1;
                    let all_rewarded = true;
                    for (let j = 0; j < 3; j++) {
                        let _info = UI_Activity.getPeriodTaskInfo(this.task_datas[i][j].period_task_id);
                        if (!_info || !_info['rewarded']) {
                            all_rewarded = false;
                            break;
                        }

                    }
                    if (all_rewarded) {
                        tab.tag.visible = true;
                        tab.tag.skin = game.Tools.localUISrc('myres/activity_qiri/complete.png');
                    } else {
                        tab.tag.visible = false;
                        if (!day) {
                            day = i + 1;
                        }
                    }
                }
            }
            return day;
        }


        private showTaskByDay(day: number) {
            if (day != this.show_day) {
                this.tabs[day - 1].img.skin = game.Tools.localUISrc('myres/activity_qiri/btn_choosed.png');
                this.tabs[day - 1].text.color = '#d4815c';
                if (this.show_day) {
                    this.tabs[this.show_day - 1].img.skin = game.Tools.localUISrc('myres/activity_qiri/btn_unchoose.png');
                    this.tabs[this.show_day - 1].text.color = '#8d6f61';
                }

            }
            this.show_day = day;
            for (let i = 0; i < this.items.length; i++) {
                this.items[i].setData(this.task_datas[day - 1][i]);
            }
        }

        public reset() {
            if (this.show_day) {
                this.tabs[this.show_day - 1].img.skin = game.Tools.localUISrc('myres/activity_qiri/btn_unchoose.png');
                this.tabs[this.show_day - 1].text.color = '#8d6f61';
            }
            this.show_day = 0;
        }

        // 检查是否总任务是否可领取,并发送
        public checkTotalCanReceive() {
            let _info = UI_Activity.getPeriodTaskInfo(this.total_task_id);
            if (_info && _info['achieved'] && !_info['rewarded']) {
                let _task_infos = UI_Activity.getPeriodTaskList(UI_Activity_SevenDays.activity_id);
                
                for (let _task_info of _task_infos) {
                    if (_task_info['id'] != this.total_task_id && !_task_info['rewarded']) {
                        return;
                    }
                }
                UI_Activity_SevenDays.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: this.total_task_id }, (err, res) => {
                    UI_Activity_SevenDays.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        UI_Activity.onTaskRewarded(this.total_task_id);
                        let reward_id: number = 0;
                        let reward_count: number = 0;
                        let d_activity_task = cfg.activity.period_task.get(this.total_task_id);
                        let reward_strs = d_activity_task.reward.split(',');
                        let rewards: Array<{ id: number, count: number }> = [];
                        for (let reward of reward_strs) {
                            let strs = reward.split('-');
                            rewards.push({ id: Number(strs[0]), count: Number(strs[1]) });
                        }
                        game.Tools.showRewards({ rewards: rewards }, Laya.Handler.create(this, ()=>{
                            UI_Activity_SevenDays.Inst.close();
                            // TODO 隐藏大厅入口
                        }));
                        
                    }
                });
            }
        }

        public getTotalRewared(): boolean {
            let _info = UI_Activity.getPeriodTaskInfo(this.total_task_id);
            return _info && _info['rewarded'];
        }

        public refreshRedpoint() {
            for (let i = 0; i < 7; i++) {
                let _datas = this.task_datas[i];
                this.tabs[i].redpoint.visible = false;
                let complete = true;
                for (let data of _datas) {
                    let _info = UI_Activity.getPeriodTaskInfo(data.period_task_id);
                    if (_info && _info['achieved'] && !_info['rewarded']) {
                        this.tabs[i].redpoint.visible = true;
                        complete = false;
                        break;
                    } else if (!_info || !_info['achieved']) {
                        complete = false;
                    }
                }
                if (complete) {
                    this.tabs[i].tag.visible = true;
                    this.tabs[i].tag.skin = game.Tools.localUISrc('myres/activity_qiri/complete.png');
                }
            }
        }
    }

    class Page_QA {
        private me: Laya.Sprite;
        private loading: Laya.Sprite;
        private info: Laya.Sprite;
        private btns: Array<{
            btn: Laya.Button,
            rect: Laya.Image,
            correct: Laya.Sprite,
            error: Laya.Sprite
        }>;
        private image: Laya.Image;
        private tip: Laya.Label;
        private head: Laya.Image;
        private corrected: boolean;
        private btn_skip: Laya.Button;
        private data: lqc.Sheet_Activity_TaskDisplay;
        constructor(me: Laya.Sprite) {
            this.me = me;
            (this.me.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                UI_Activity_SevenDays.Inst.showTask();
            });
            this.loading = this.me.getChildByName('loading') as Laya.Sprite;
            this.info = this.me.getChildByName('info') as Laya.Sprite;
            this.btns = [];
            let btn_parent = this.info.getChildByName('buttonCrew') as Laya.Sprite;
            for (let i = 0; i < 3; i++) {
                let btn = btn_parent.getChildAt(i) as Laya.Button;
                btn.clickHandler = new Laya.Handler(this, ()=>{
                    if (this.corrected) return;
                    this.onBtnClick(i);
                });
                this.btns.push({
                    btn: btn,
                    rect: btn.getChildByName('rect') as Laya.Image,
                    correct: btn.getChildByName('correct') as Laya.Sprite,
                    error: btn.getChildByName('error') as Laya.Sprite
                })
            }

            this.image = this.info.getChildByName('image') as Laya.Image;
            this.head = this.info.getChildByName('head') as Laya.Image;
            this.tip = this.info.getChildByName('tip') as Laya.Label;
            this.btn_skip = this.info.getChildByName('btn_skip') as Laya.Button;
            this.btn_skip.clickHandler = new Laya.Handler(this, ()=>{
                UI_Activity_SevenDays.Inst.showTask();
            });
        }

        public show(data: lqc.Sheet_Activity_TaskDisplay) {
            this.data = data;
            this.me.visible = true;
            this.loading.visible = true;
            this.info.visible = false;
            this.corrected = false;
            this.btn_skip.visible = false;
            this.tip.text = game.Tools.strOfLocalization(7036);
            game.LoadMgr.setImgSkin(this.head, 'extendRes/emo/e200001/l_1.png');
            for (let btn of this.btns) {
                btn.correct.visible = false;
                btn.error.visible = false;
                btn.rect.visible = false;
            }
            //  data.q_image
            game.LoadMgr.setImgSkin(this.image, 'myres/activity_qiri/QA_' + data.day + '.png', Laya.Handler.create(this, ()=>{
                this.loading.visible = false;
                this.info.visible = true;
            }), 'UI_Activity_SevenDays');
        }

        public hide() {
            this.me.visible = false;
            game.LoadMgr.clearImgSkin(this.image);
            Laya.Loader.clearTextureRes(this.image.skin);
        }

        private onBtnClick(index: number) {
            let answer = this.data.answer;
            let correct = false;
            for (let btn of this.btns) {
                btn.correct.visible = false;
                btn.error.visible = false;
                btn.rect.visible = false;
            }
            while(answer > 0) {
                if (answer % 10 == index + 1) {
                    correct = true;
                    break;
                }
                answer = Math.floor(answer / 10);
            }
            let btn = this.btns[index];
            if (correct) {
                let _data = cfg.activity.period_task.get(this.data.period_task_id);
                let _base_task = cfg.events.base_task.get(_data.base_task_id);
                let params = [];
                for (let _param of _base_task.param) {
                    if (!_param) {
                        break;
                    }
                    params.push(Number(_param));
                }
                btn.correct.visible = true;
                btn.rect.visible = true;
                btn.rect.skin = game.Tools.localUISrc('myres/activity_qiri/rect_correct.png');
                this.tip.text = game.Tools.strOfLocalization(this.data.right_str);
                this.corrected = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: params }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('taskRequest', err, res);
                    }
                    
                });
                this.btn_skip.visible = true;
                game.LoadMgr.setImgSkin(this.head, 'extendRes/emo/e200001/l_4.png');
            } else {
                btn.error.visible = true;
                btn.rect.visible = true;
                btn.rect.skin = game.Tools.localUISrc('myres/activity_qiri/rect_error.png');
                this.tip.text = game.Tools.strOfLocalization(this.data.wrong_str);
                game.LoadMgr.setImgSkin(this.head, 'extendRes/emo/e200001/l_3.png');
            }
        }
    }

    export class UI_Activity_SevenDays extends UIBase {
        public static Inst: UI_Activity_SevenDays;
        public static activity_id: number = 230601;

        // 外部使用，检查客户端任务是否进行中
        public static check_task_doing(type: number): boolean {
            let task_id = type + 23060108;
            let info = UI_Activity.getPeriodTaskInfo(task_id);
            return info && !info['achieved'];
        }

        // 外部使用，偷偷给服务器发任务完成，发了就不管了，即使报错也是下次再发
        public static task_done(type: number) {
            if (!this.check_task_doing(type)) return;
            let task_id = type + 23060108;
            let _data = cfg.activity.period_task.get(task_id);
            let _base_task = cfg.events.base_task.get(_data.base_task_id);
            let params = [];
            for (let _param of _base_task.param) {
                if (!_param) {
                    break;
                }
                params.push(Number(_param));
            }
            app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: params }, (err, res) => {
            });
        }

        public static have_redpoint(): boolean {
            if (!UI_Activity.activity_is_running(this.activity_id)) return false;
            let task_infos = UI_Activity.getPeriodTaskList(this.activity_id);
            for (let info of task_infos) {
                if (info['achieved'] && !info['rewarded']) {
                    return true;
                }
            }
            return false;
        }

        public static activity_is_running(): boolean {
            if (!UI_Activity.activity_is_running(this.activity_id)) return false;
            let info = UI_Activity.getPeriodTaskInfo(23060122);
            if (info && info['rewarded']) return false;
            return true;
        }
        constructor() {
            super(new ui.lobby.activitys.activity_seven_daysUI());
            UI_Activity_SevenDays.Inst = this;
        }

        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private page_QA: Page_QA;
        public page_task: Page_Task;

        public locking: boolean;

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.page_QA = new Page_QA(this.root.getChildByName('qa') as Laya.Sprite);
            this.page_task = new Page_Task(this.root.getChildByName('task') as Laya.Sprite);
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_SevenDays', true);
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_SevenDays', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_qiri.atlas'));
            UI_Lobby.Inst.top.refreshQiriState();
        }

        public show() {
            this.enable = true;
            this.page_task.reset();
            this.showTask();
            this.locking = true;
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 150);
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));


        }

        public close() {
            this.locking = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 150);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public showTask() {
            if (this.locking) return;
            this.page_task.show();
            this.page_QA.hide();
        }

        public showQA(data: lqc.Sheet_Activity_TaskDisplay) {
            if (this.locking) return;
            this.page_QA.show(data);
            this.page_task.hide();
        }

        public done(): boolean {
            return this.page_task.getTotalRewared();
        }
    }
}