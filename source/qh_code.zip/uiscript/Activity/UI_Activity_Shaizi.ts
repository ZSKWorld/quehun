/**
* name 
*/
module uiscript{
	export class UI_Activity_Shaizi extends UI_ActivityBase {

		public static activity_id:number = 1060;
		public static shaizi_item_id:number = 309018;
		private static location:number = 0;
		private static finished_count:number = 0;

		public static init(data) {
			if (data.richman_data && data.richman_data.length > 0) {
				for (let i:number = 0; i < data.richman_data.length; i++) {
					if (data.richman_data[i].activity_id == UI_Activity_Shaizi.activity_id) {
						this.location = data.richman_data[i].location;
						this.finished_count = data.richman_data[i].finished_count;
						break;
					}
				}
			}
		}

		private root:Laya.Sprite;
		private label_time:Laya.Label;
		private label_next_word:Laya.Label;
		private label_next:Laya.Label;
		private label_lap:Laya.Label;
		private btn_shaizi:Laya.Button;
		private img_shaizi:Laya.Image;
		private img_shaizi_start:Laya.Image;
		private cell_templete:Laya.Sprite;
		private cells:Array<Laya.Sprite> = [];
		private label_count:Laya.Label;
		private chess:Laya.Sprite;
		
		private location_index:number = 0;
		private during_anim:boolean = false;
		private shaizi_count:number = 0;
		private qizi:game.UIEffect;

		constructor() {
			super(cfg.activity.activity.get(UI_Activity_Shaizi.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_shaiziUI());
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean { return UI_Activity.activity_is_running(UI_Activity_Shaizi.activity_id); }

		//活动是否要显示小红点
		public haveRedPoint():boolean {return false;}

		//活动是否要弹出来
		public need_popout():boolean {return false;}

		private get_cell_pos(x:number, y:number): {x:number, y:number} {
			let _x:number = 60 + x * 107;
			let _y:number = 87 + y * 107;
			return {x: _x, y: _y};
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.label_time = this.root.getChildByName('time') as Laya.Label;
			this.label_next = this.root.getChildByName('next') as Laya.Label;
			this.label_next_word = this.root.getChildByName('next_word') as Laya.Label;
			this.label_lap = this.root.getChildByName('lap') as Laya.Label;
			let container_cells = this.root.getChildByName('cells') as Laya.Sprite;
			this.cell_templete = container_cells.getChildByName('cell_templete') as Laya.Sprite;
			this.cell_templete.visible = false;
			this.cells = [];
			let map_id:number = cfg.activity.richman_info.get(UI_Activity_Shaizi.activity_id).map_id;
			let d_cells = cfg.activity.richman_map.getGroup(map_id);
			let cell_clone:capsui.UICopy = this.cell_templete.scriptMap['capsui.UICopy'];
			for (let i:number = 0; i < d_cells.length; i++) {
				this.cells.push(cell_clone.getNodeClone());
			}
			Laya.timer.once(200, this, () => {
				for (let i:number = 0; i < this.cells.length; i++) {
					let _cell:Laya.Sprite = this.cells[i];
					let pos = this.get_cell_pos(d_cells[i].pos_x, d_cells[i].pos_y);
					_cell.x = pos.x;
					_cell.y = pos.y;
					let img:Laya.Image = _cell.getChildByName('img') as Laya.Image;
					img.skin = '';
					if (d_cells[i].type == 0) {
						img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_begin.png');
					} else if (d_cells[i].type == 1) {
						switch (d_cells[i].bonus_type) {
							case 1: img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_coin.png'); break;
							case 2: img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_liwu.png'); break;
							case 3: img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_shaizi.png'); break;
							case 4: img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_baoyu.png'); break;
						}
					} else if (d_cells[i].type == 2) {
						let dx:number = d_cells[d_cells[i].param].pos_x - d_cells[i].pos_x;
						let dy:number = d_cells[d_cells[i].param].pos_y - d_cells[i].pos_y;
						if (dx != 0) {
							if (dx > 0) img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_right.png');
							else img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_left.png');
						} else {
							if (dy > 0) img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_down.png');
							else img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_up.png');
						}
					} else if (d_cells[i].type == 3) {
						img.skin = game.Tools.localUISrc('myres/activity_shaizi/cell_shaizi.png');
					}
				}
			});
			this.btn_shaizi = this.root.getChildByName('btn_shaizi') as Laya.Button;
			this.btn_shaizi.clickHandler = new Laya.Handler(this, ()=>{
				if (this.during_anim) return;
				if (UI_Bag.get_item_count(UI_Activity_Shaizi.shaizi_item_id) <= 0) return;
				this.on_click_shaizi();
			});
			this.img_shaizi = this.btn_shaizi.getChildByName('shaizi') as Laya.Image;
			this.img_shaizi_start = this.btn_shaizi.getChildByName('word') as Laya.Image;
			(this.root.getChildByName('btn_info') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3059));
			});
			this.label_count = this.root.getChildByName('count') as Laya.Label;
			this.chess = this.root.getChildByName('chess') as Laya.Sprite;
		}

		public show() {
			this.shaizi_count = UI_Bag.get_item_count(UI_Activity_Shaizi.shaizi_item_id);
			this.refresh_btn_shaizi();
			this.enable = true;
			this.chess.x = this.cells[UI_Activity_Shaizi.location].x;
			this.chess.y = this.cells[UI_Activity_Shaizi.location].y;
			this.qizi = game.FrontEffect.Inst.create_ui_effect(this.chess, 'scene/touzi_qizi.lh', new Laya.Point(54, 54), 1);
			this.chess.visible = true;
			this.qizi.effect.root.active = false;
			this.refresh();
		}

		private refresh() {
			// 时间
			{
				this.label_time.text = game.Tools.strOfLocalization(3056);
			}
			// 下次踏破奖励
			{
				let d_rewards = cfg.activity.richman_reward.getGroup(UI_Activity_Shaizi.activity_id);
				let s_rewards:string = '';
				for (let i:number = 0; i < d_rewards.length; i++) {
					if (d_rewards[i].finish_count == UI_Activity_Shaizi.finished_count + 1) {
						if (s_rewards != '') s_rewards += ',';
						s_rewards += game.GameUtility.get_item_view(d_rewards[i].resource_id).name + 'x' + d_rewards[i].resource_count;
					}
				}
				if (s_rewards == '') {
					this.label_time.y = 14;
					this.label_lap.y = 14;
					this.label_next_word.visible = false;
					this.label_next.visible = false;
				} else {
					this.label_time.y = 2;
					this.label_lap.y = 2;
					this.label_next_word.visible = true;
					this.label_next.visible = true;
					this.label_next.text = s_rewards;
					game.Tools.sprite_align_center([this.label_next_word, this.label_next], 470);
				}
				this.label_lap.text = (UI_Activity_Shaizi.finished_count + 1).toString();
				game.Tools.sprite_align_center([this.label_time, this.label_lap], 470);
			}
		}

		private refresh_btn_shaizi() {
			this.label_count.text = this.shaizi_count.toString();
			this.btn_shaizi.mouseEnabled = this.shaizi_count > 0;
			this.img_shaizi_start.visible = true;
		}

		private on_click_shaizi() {
			this.img_shaizi_start.visible = false;
			this.shaizi_count--;
			this.label_count.text = this.shaizi_count.toString();
			let data:any = null;
			this.during_anim = true;
			this.btn_shaizi.mouseEnabled = false;
			let start_time:number = Laya.timer.currTimer;
			// let func = () => {
			// 	if (Laya.timer.currTimer < start_time + 1000 || !data) {
			// 		this.img_shaizi.skin = game.Tools.localUISrc(`myres/activity_shaizi/shaizi${Math.floor(Math.random() * 6) + 1}.png`);
			// 		Laya.timer.once(100, this, ()=>{
			// 			func();
			// 		});
			// 	} else {
			// 		this.img_shaizi.skin = game.Tools.localUISrc(`myres/activity_shaizi/shaizi${data.dice}.png`);
			// 		Laya.timer.once(800, this, ()=>{
			// 			this.jump(0, data.paths);
			// 		});
			// 	}
			// };
			// func();
			UI_Freeze.Inst.Show();


			app.NetAgent.sendReq2Lobby('Lobby', 'richmanActivityNextMove', {activity_id: UI_Activity_Shaizi.activity_id}, 
			(err, res) => {
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError('richmanActivityNextMove', err, res);
					this.shaizi_count++;
					this.refresh_btn_shaizi();
					this.during_anim = false;
					UI_Freeze.Inst.Close();
				} else {
					data = res;
					let effect_touzi:game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.img_shaizi, 'scene/touzi_touzi.lh', new Laya.Point(80, 80), 1);
					this.img_shaizi.skin = '';
					Laya.timer.once(1000, this, ()=>{
						this.img_shaizi.skin = game.Tools.localUISrc(`myres/activity_shaizi/shaizi${data.dice}.png`);
					});
					Laya.timer.once(1800, this, ()=>{
						effect_touzi.destory();
						this.jump(0, data.paths);
					});
					UI_Activity_Shaizi.finished_count = res.finished_count;
				}
			});
		}

		private jump(index:number, paths:Array<{location:number, rewards?:any}>) {
			if (index >= paths.length) {
				this.during_anim = false;
				this.refresh_btn_shaizi();
				UI_Freeze.Inst.Close();
				return;
			}
			if (UI_Activity_Shaizi.location == paths[index].location) {
				if (paths[index].rewards && paths[index].rewards.length > 0) {
					let effect:game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.chess, 'scene/touzi_bang0.lh', new Laya.Point(54, 54), 1);
					Laya.timer.once(800, this, ()=>{
						let _rewards = [];
						for (let i:number = 0; i < paths[index].rewards.length; i++) {
							_rewards.push({
								id: paths[index].rewards[i].resource_id,
								count: paths[index].rewards[i].count
							});
						}
						game.Tools.showRewards({'rewards': _rewards}, Laya.Handler.create(this, ()=>{
							for (let i:number = 0; i < _rewards.length; i++) {
								if (_rewards[i].id == UI_Activity_Shaizi.shaizi_item_id) {
									this.shaizi_count += _rewards[i].count;
								}
							}
							this.jump(index + 1, paths);
							this.refresh();
						}));
					});
					Laya.timer.once(1200, this, ()=>{
						effect.destory();
					});
				} else if (index + 1 < paths.length) {
					let effect:game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.chess, 'scene/touzi_bang1.lh', new Laya.Point(54, 54), 1);
					Laya.timer.once(800, this, ()=>{
						this.jump(index + 1, paths);
					});
					Laya.timer.once(1200, this, ()=>{
						effect.destory();
					});
				} else {
					this.jump(index + 1, paths);
				}
			} else {
				let _location:number = UI_Activity_Shaizi.location;
				let _location_next:number = (_location + 1) % this.cells.length;
				this.chess.visible = false;
				this.qizi.effect.root.active = true;
				Laya.Tween.to(this.chess
					, {x: this.cells[_location_next].x, y: this.cells[_location_next].y}
					, 300
					, Laya.Ease.strongInOut
					, Laya.Handler.create(this, () => {
						UI_Activity_Shaizi.location = _location_next;
						this.chess.visible = true;
						this.qizi.effect.root.active = false;
						Laya.timer.once(100, this, () => {
							this.jump(index, paths);
						});
					}));
			}
		}
		
		public hide() {
			this.enable = false;
			if (this.qizi) {
				this.qizi.destory();
				this.qizi = null;
			}
		}
	}
}