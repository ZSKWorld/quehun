/**
* name 
*/
module uiscript {
    export class UI_Activity_Sns_Task extends UI_Activity_Task {

        public static activity_id: number = 1240;
        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Sns_Task.activity_id)['name_' + GameMgr.client_language]);
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres2/treasurehead/activity_21wansheng_task.jpg`, 974, 330);
            // (this.head.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
            //     UI_Activity.Inst.close();
            //     UI_Sns.Inst.show();
            // })
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Sns_Task.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getTaskList(UI_Activity_Sns_Task.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Sns_Task.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;
            this.refreshView(UI_Activity.getTaskList(UI_Activity_Sns_Task.activity_id));
        }

        public hide() {
            this.enable = false;
        }

        public onDisable(): void {
            super.onDisable();
            UI_Lobby.Inst.top.refreshSnsRedpoint();

        }
    }
}