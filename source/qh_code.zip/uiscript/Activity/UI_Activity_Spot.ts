/**
* UI_Activity_Spot  剧情活动 
*/
module uiscript {
    class Item_Spot {
        private btn: Laya.Button;
        private icon: Laya.Image;
        private lock_item: Laya.Sprite;
        private lock_time: Laya.Sprite;
        private lock_spot: Laya.Sprite;
        private redpoint: Laya.Sprite;
        private index: number;
        private _data: lqc.Sheet_Activity_SpotActivity;

        constructor(me: Laya.Sprite, index: number) {
            this.index = index;
            this._data = cfg.activity.spot_activity.get(UI_Activity_Spot.start_spot_id + index);
            this.btn = me.getChildByName('btn') as Laya.Button;
            this.icon = me.getChildByName('icon') as Laya.Image;
            this.btn.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Spot.Inst.locking) return;
                let _data = UI_Activity_Spot.spots[this._data.unique_id];
                if (UI_PiPeiYuYue.Inst.enable) {
					UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
					return;
				}
                if (!UI_Activity.activity_is_running(UI_Activity_Spot.activity_id)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3732));
                    return;
                }
                if (this.lock_time.visible) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3968));
                    return;
                }
                if (this.lock_spot.visible) {
                    let target = this._data.unique_id;
                    let _spot_data = cfg.activity.spot_activity.get(target);
                  
                    let first_finished = UI_Activity_Spot.spots[UI_Activity_Spot.start_spot_id] && UI_Activity_Spot.spots[UI_Activity_Spot.start_spot_id]['rewarded'] 
                            && UI_Activity_Spot.spots[UI_Activity_Spot.start_spot_id]['unlocked_ending'] && UI_Activity_Spot.spots[UI_Activity_Spot.start_spot_id]['unlocked_ending'].length > 0;
                    let need_item = false;
                    if (first_finished && (!UI_Activity_Spot.spots[target] || !UI_Activity_Spot.spots[target]['unlocked'])) {
                        need_item = true;
                    }
                    
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3969 + (first_finished && this.index < 3 ? 0 : 1) + (need_item ? 0 : 2)));
                    return;
                }
                if (!_data || !_data['unlocked']) {
                    if (this.lock_item.visible) {
                        if (UI_Bag.get_item_count(UI_Activity_Spot.item_id) == 0) {
                            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217));
                            return;
                        }
                    }
                    app.NetAgent.sendReq2Lobby('Lobby', 'unlockActivitySpot', { unique_id: this._data.unique_id }, (err, res) => {
						
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('unlockActivitySpot', err, res);
						} else {
							UI_Activity_Spot.add_lock_spot(this._data.unique_id);
                            if (this.lock_item.visible) {
                                this.lock_item.visible = false;
                                this.redpoint.visible = true;
                                this.icon.skin = game.Tools.localUISrc('myres/activity_spot/tag_play.png');
                                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3973));
                            } else {
                                UI_Activity_Spot.Inst.close();
                                UI_Lobby.Inst.stopsay();
                                GameMgr.Inst.showSpotByEvent(this._data.content_path, this._data.unique_id, Laya.Handler.create(this, ()=>{
                                    UI_Lobby.Inst.top.refreshRedpoint();
                                    GameMgr.Inst.spot_activity_id = this._data.unique_id;
                                    GameMgr.Inst.EnterLobby();
                                }));
                            }
						}
					});
                    return;
                }
                
                UI_Activity_Spot.Inst.close();
                UI_Lobby.Inst.stopsay();
                GameMgr.Inst.showSpotByEvent(this._data.content_path, this._data.unique_id, Laya.Handler.create(this, ()=>{
                    UI_Lobby.Inst.top.refreshRedpoint();
                    GameMgr.Inst.spot_activity_id = this._data.unique_id;
                    GameMgr.Inst.EnterLobby();
                }));
            });
            
            this.lock_item = me.getChildByName('lock') as Laya.Sprite;
            (this.lock_item.getChildAt(3) as Laya.Label).text = 'x1';
            if (GameMgr.client_language == 'en') {
               (this.lock_item.getChildAt(0) as Laya.Sprite).x -= 20;
               (this.lock_item.getChildAt(0) as Laya.Sprite).width += 40;
               (this.lock_item.getChildAt(2) as Laya.Sprite).x += 30;
               (this.lock_item.getChildAt(3) as Laya.Sprite).x += 30;
            }
            this.lock_time = me.getChildByName('lock_time') as Laya.Sprite;
            if (index > 0) {
                (this.lock_time.getChildByName('time') as Laya.Label).text = game.Tools.strOfLocalization(Math.floor((index - 1) / 2) + 3955);
            }
            this.lock_spot = me.getChildByName('lock_spot') as Laya.Sprite;
            this.redpoint = me.getChildByName('redpoint') as Laya.Sprite;
        }

        public refresh() {
            let _data = UI_Activity_Spot.spots[this._data.unique_id];
            let delta = UI_Activity_Spot.getActivityDeltaDay();
            this.lock_item.visible = false;
            this.lock_spot.visible = false;
            this.lock_time.visible = false;
            this.redpoint.visible = false;
            this.btn.visible = true;
            this.icon.skin = game.Tools.localUISrc('myres/activity_spot/tag_lock.png');
            if (delta < this._data.limit_day) {
                this.lock_time.visible = true;
            } else if (this._data.dep && (!UI_Activity_Spot.spots[this._data.dep] || !UI_Activity_Spot.spots[this._data.dep]['rewarded'])) {
                this.lock_spot.visible = true;
            } else if (_data && _data['unlocked']) {
                this.icon.skin = game.Tools.localUISrc('myres/activity_spot/tag_play.png');
                if (!_data || !_data['rewarded']) {
                    this.redpoint.visible = true;
                }
            } else {
                if (this._data.dep && (!UI_Activity_Spot.spots[this._data.dep] || !UI_Activity_Spot.spots[this._data.dep]['rewarded'])) {
                    this.lock_spot.visible = true;
                    return;
                }
                if (this._data.unlock_by_ending_id) {
                    if (!UI_Activity_Spot.spots[this._data.dep] || !UI_Activity_Spot.spots[this._data.dep]['unlocked_ending'] || UI_Activity_Spot.spots[this._data.dep]['unlocked_ending'].indexOf(this._data.unlock_by_ending_id) == -1) {
                       this.lock_spot.visible = true;
                       return; 
                    }
                }
                if (this._data.unlock_spot_item) {
                    let target = this.index % 2 == 0 ? (this._data.unique_id - 1) : (this._data.unique_id + 1);
                    if (UI_Activity_Spot.spots[target] && UI_Activity_Spot.spots[target]['unlocked']) {
                        this.lock_item.visible = true;
                        return;
                    }
                }
                if (!_data || !_data['rewarded']) {
                    this.redpoint.visible = true;
                }
                this.icon.skin = game.Tools.localUISrc('myres/activity_spot/tag_play.png');
            }
        }
    }

    class Item_Reward{
        private achieved: Laya.Sprite;
        private icon: Laya.Image;
        private btn: Laya.Button;
        private label_day: Laya.Label;
        private done: Laya.Sprite;
        private lock: Laya.Sprite;
        private task_id: number;
        private index: number;
        constructor(me: Laya.Sprite, index: number) {
            this.index = index;
            this.achieved = me.getChildByName('achieved') as Laya.Sprite;
            this.icon = me.getChildByName('icon') as Laya.Image;
            this.task_id = 23091201 + index;
            let _data: lqc.Sheet_Activity_PeriodTask = cfg.activity.period_task.get(23091201 + index);
            let _reward_id = Number(_data.reward.split('-')[0]);
            let _reward_count = Number(_data.reward.split('-')[1]);
            let _spr_count: Laya.Sprite = me.getChildByName('count') as Laya.Sprite;
            if (_reward_count > 1) {
                _spr_count.visible = true;
                (_spr_count.getChildByName('count') as Laya.Label).text = _reward_count + '';
            } else {
                _spr_count.visible = false;
            }
            if (game.GameUtility.get_id_type(_reward_id) == game.EIDType.currency) {
                let _currency = cfg.item_definition.currency.get(_reward_id);
                game.LoadMgr.setImgSkin(this.icon, _currency.icon_jpg, null, 'UI_Activity_Spot');
            } else {
                let _view = game.GameUtility.get_item_view(_reward_id);
                game.LoadMgr.setImgSkin(this.icon, _view.icon, null, 'UI_Activity_Spot');
            }
            
            this.btn = me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Spot.Inst.locking) return;
                UI_ItemDetail.Inst.show(_reward_id);
            });

            this.lock = me.getChildByName('lock') as Laya.Sprite;
            this.done = me.getChildByName('done') as Laya.Sprite;
            (me.getChildByName('day') as Laya.Label).text = game.Tools.strOfLocalization(3962 + index);
        }

        public refresh() {
            this.lock.visible = false;
            this.achieved.visible = false;
            this.done.visible = false;
            let _data = UI_Activity.getPeriodTaskInfo(this.task_id);
            if (_data && _data['rewarded']) {
                this.done.visible = true;
            } else if (_data && _data['achieved']) {
                this.achieved.visible = true;
            } else {
                this.lock.visible = true;
            }
        }
    }
    export class UI_Activity_Spot extends UIBase {
        public static Inst: UI_Activity_Spot;
        public static start_spot_id: number = 23091001;
        public static activity_id: number = 230910;
        public static task_activity_id: number = 230911;
        public static reward_activity_id: number = 230912;
        public static item_id: number = 30900003;
        public static spots: Object = {};
        public static update_data(infos:Array<Object>) {
            let res = null;
            for (let data of infos) {
                if (data['activity_id'] == this.activity_id) {
                    res = data;
                    break;
                }
            }
            this.spots = {};
            if (res && res['spots']) {
                for (let ending of res['spots']) {
                    let unlocked_ending: Array<number> = [];
                    if (ending['unlocked_ending']) {
                        for (let id of ending['unlocked_ending']) {
                            unlocked_ending.push(id);
                        }
                    }
                    ending['unlocked_ending'] = unlocked_ending
                    this.spots[ending['unique_id']] = ending;
                }
            }
            
        }

        public static getActivityDeltaDay(): number {
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }

        // 活动剧情解锁
        public static add_lock_spot(unique_id: number) {
            if (this.spots[unique_id]) {
                this.spots[unique_id]['unlocked'] = true;
            } else {
                this.spots[unique_id] = {unique_id: unique_id, unlocked: true, unlocked_ending: []};
            }
        }


        // 活动剧情结局解锁
        public static add_lock_ending(unique_id: number, ending_id: number) {
            if (this.spots[unique_id]) {
                if (this.spots[unique_id]['unlocked_ending']) {
                    this.spots[unique_id]['unlocked_ending'].push(ending_id);
                } else {
                    this.spots[unique_id]['unlocked_ending'] = [ending_id];
                }
            } else {
                this.spots[unique_id] = {unique_id: unique_id, unlocked_ending: [ending_id]};
            }
        }
        public static have_redpoint(): boolean {
            if (!cfg.activity.spot_activity) return false;
            let datas = UI_Activity.getSegmentTaskList(UI_Activity_Spot.task_activity_id);
            if (!datas || datas.length <= 0) return;
            if (datas[0]['achieved_count'] > datas[0]['reward_count']) {
                return true;
            }
            
            let _task_infos = UI_Activity.getPeriodTaskList(UI_Activity_Spot.reward_activity_id);
            for (let _task of _task_infos) {
                if (_task['achieved'] && !_task['rewarded']) {
                    return true;
                }
            }
            let delta = UI_Activity_Spot.getActivityDeltaDay();
            let _item_count = UI_Bag.get_item_count(this.item_id);
            for (let i = 0; i < 9; i++) {
                let _id = this.start_spot_id + i;
                let _spot_data = cfg.activity.spot_activity.get(_id);
                let _data = this.spots[_id];
                if ((_data && _data['rewarded']) || delta < _spot_data.limit_day) {
                    continue;
                }
                if (_spot_data.dep && (!UI_Activity_Spot.spots[_spot_data.dep] || !UI_Activity_Spot.spots[_spot_data.dep]['rewarded'])) {
                    continue;
                }
                if (_spot_data.unlock_by_ending_id) {
                    if (!UI_Activity_Spot.spots[_spot_data.dep] || !UI_Activity_Spot.spots[_spot_data.dep]['unlocked_ending'] || UI_Activity_Spot.spots[_spot_data.dep]['unlocked_ending'].indexOf(_spot_data.unlock_by_ending_id) == -1) {
                       continue
                    }
                }
                 if (_spot_data.unlock_spot_item) {
                    let target = i % 2 == 0 ? (_spot_data.unique_id - 1) : (_spot_data.unique_id + 1);
                    if (UI_Activity_Spot.spots[target] && UI_Activity_Spot.spots[target]['unlocked'] && _item_count == 0) {
                        continue;
                    }
                }
                return true;
            }
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_spotUI());
            UI_Activity_Spot.Inst = this;
        }

        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private items: Array<Item_Spot>;
        public locking: boolean;

        private task_bar: Laya.Sprite;
        private btn_task: Laya.Button;
        private label_task: Laya.Label;
        private task_redpoint: Laya.Sprite;
        private label_progress: Laya.Label;

        private task_id: number;
        private ungetted_count: number;
        private task_info: {id:number, counter: number, achieved: boolean, rewarded: boolean, failed:boolean, reward_count: number, achieved_count: number};

        //奖励部分
        private items_reward: Array<Item_Reward>;
        private lines: Array<Laya.Sprite>;
        private btn_receive: Laya.Button;
        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.items = [];
            let spot = this.root.getChildByName('spot') as Laya.Sprite;
            for (let i = 0; i < spot.getChildByName('items')._childs.length; i++) {
                this.items.push(new Item_Spot(spot.getChildByName('items').getChildAt(i) as Laya.Sprite, i));
            }
            // (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
            //     if (this.locking) return;
            //     this.close();
            // });
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            (this.root.getChildByName('info') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3967));
            });

            let task = this.root.getChildByName('task') as Laya.Sprite;
            this.task_bar = task.getChildByName('bar') as Laya.Sprite;
            this.btn_task = task.getChildByName('btn') as Laya.Button;
            this.label_task = task.getChildByName('count') as Laya.Label;
            this.label_progress = task.getChildByName('progress') as Laya.Label;
            this.task_redpoint = this.btn_task.getChildAt(1) as Laya.Sprite;
            this.btn_task.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (!UI_Activity.activity_is_running(UI_Activity_Spot.task_activity_id)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3732));
                    return;
                }
                if (this.ungetted_count <= 0) {
                    UI_ItemDetail.Inst.show(UI_Activity_Spot.item_id);
                    return;
                }
                
                app.NetAgent.sendReq2Lobby('Lobby', 'completeSegmentTaskReward', { task_id: this.task_id, count: this.ungetted_count }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completeSegmentTaskReward', err, res);
                    } else {
                        let d_activity_task = cfg.activity.segment_task.get(this.task_info.id);
                        let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
                        let _data = cfg.item_definition.item.get(UI_Activity_Spot.item_id);
                        let s:string = game.Tools.strOfLocalization(2234) + (_data['name_' + GameMgr.client_language] + ' x' + this.ungetted_count);
						UI_LightTips.Inst.show(s);
                        this.task_info.reward_count = this.task_info.achieved_count;
                        let counter = this.task_info.counter? this.task_info.counter : 0;
                        this.label_progress.text = counter + '/' + d_task_info.target;
                        this.task_bar.mask.width = counter / d_task_info.target * 380;
                        this.task_redpoint.visible = false;
                        this.setBtnGray(true);
                        this.ungetted_count = 0;
                        if (this.task_info.reward_count >= d_activity_task.max_finish_count) {
                            this.setBtnGray(true);
                            this.label_progress.text = d_task_info.target +'/' +d_task_info.target;
                            this.task_bar.mask.width = 380;
                        }
                        UI_Lobby.Inst.top.refreshRedpoint();
                    }
                });
            }, null, false);

            let reward = this.root.getChildByName('reward') as Laya.Sprite;
            this.lines = [];
            this.items_reward = [];
            for (let i = 0; i < 4; i++) {
                this.lines.push(reward.getChildByName('lines').getChildAt(i).getChildByName('light') as Laya.Sprite);
            }

            for (let i = 0; i < 5; i++) {
                this.items_reward.push(new Item_Reward(reward.getChildByName('items').getChildAt(i) as Laya.Sprite, i));
            }
            this.btn_receive = reward.getChildByName('btn_receive') as Laya.Button;
            this.btn_receive.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                if (!UI_Activity.activity_is_running(UI_Activity_Spot.reward_activity_id)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3732));
                    return;
                }

                let _task_infos = UI_Activity.getPeriodTaskList(UI_Activity_Spot.reward_activity_id);
                let _task_ids: Array<number> = [];
                for (let _info of _task_infos) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        _task_ids.push(_info['id'])
                    }
                }
                if (_task_ids.length > 0) {
                    this.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTaskBatch', { task_list: _task_ids }, (err, res) => {
                        this.locking = false;
                        if (err || res['error']) {;
                            UIMgr.Inst.showNetReqError('completePeriodActivityTaskBatch', err, res);
                        } else {
                            let lst = [];
                            let rewardObj = {};
                            for (let id of _task_ids) {
                                UI_Activity.onPeriodTaskRewarded(id);
                                let _data = cfg.activity.period_task.get(id);
                                let reward_item = _data.reward.split('-');
                                if (!rewardObj[Number(reward_item[0])]) {
                                    rewardObj[Number(reward_item[0])] = Number(reward_item[1]);
                                } else {
                                    rewardObj[Number(reward_item[0])] += Number(reward_item[1]);
                                }
                            }
                            
                            for (let key in rewardObj) {
                                lst.push({ id: Number(key), count: rewardObj[key] });
                            }

                            game.Tools.showRewards({ rewards: lst }, null);
                            this.refreshReward();
                            UI_Lobby.Inst.top.refreshRedpoint();
                        }
                    });
                }
            })

            UI_Bag.add_item_listener(UI_Activity_Spot.item_id, new Laya.Handler(this, ()=>{
                this.label_task.text = 'x' + UI_Bag.get_item_count(UI_Activity_Spot.item_id);
            }))
        }

        public onEnable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Spot', true);
		}

		public onDisable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Spot', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_spot.atlas'));
		}

        public show() {
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0.3;
            Laya.Tween.to(this.bg, { alpha: 1 }, 150);
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            
            for (let item of this.items) {
                item.refresh();
            }

            let datas = UI_Activity.getSegmentTaskList(UI_Activity_Spot.task_activity_id);
            if (datas.length == 0) {
                this.task_id = 23091101;
                this.refresh_task({id: this.task_id, reward_count: 0, achieved_count: 0});
            } else {
                this.task_id = datas[0]['id'];
                this.refresh_task(datas[0]);
            }
            

            this.refreshReward();

        }
        
        public refreshItem() {
            
            for (let item of this.items) {
                item.refresh();
            }
        }
        private refresh_task(info: any) {
            this.task_info = info;
            let d_activity_task = cfg.activity.segment_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            let max_count = d_activity_task.max_finish_count;
            this.ungetted_count = 0;
            this.label_task.text = 'x' + UI_Bag.get_item_count(UI_Activity_Spot.item_id);
            
            if (info.reward_count >= max_count) {
                this.task_redpoint.visible = false;
                this.setBtnGray(true);
                this.label_progress.text = d_task_info.target +'/' + d_task_info.target;
                this.task_bar.mask.width = 380 * 1;
            } else if (info.achieved_count > info.reward_count) {
                this.ungetted_count = info.achieved_count - info.reward_count;
                let show_progress = Math.min((max_count - info.reward_count) * d_task_info.target, info.counter + this.ungetted_count * d_task_info.target);
                this.label_progress.text = show_progress +'/' +d_task_info.target;
                this.task_bar.mask.width = 380 * 1;
                this.task_redpoint.visible = true;
                this.setBtnGray(false);
            } else {
                let counter = this.task_info.counter? this.task_info.counter : 0;
                this.label_progress.text = counter + '/' + d_task_info.target;
                this.task_bar.mask.width = counter / d_task_info.target * 380;
                this.task_redpoint.visible = false;
                this.setBtnGray(true);
            }
        }

        public close() {
            this.locking = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 150);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        private setBtnGray(gray: boolean) {
            // if (gray) {
            //     this.btn_task.filters = [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
            // } else {
            //     this.btn_task.filters = [];
            // }
        }

        public refreshReward() {
            for (let item of this.items_reward) {
                item.refresh();    
            }
            let _task_datas = UI_Activity.getPeriodTaskList(UI_Activity_Spot.reward_activity_id);
            for (let i = 1; i < 5; i++) {
                if (_task_datas[i] && _task_datas[i]['achieved']) {
                    this.lines[i - 1].visible = true;
                } else {
                    this.lines[i - 1].visible = false;
                }
            }
            let can_receive = false;
            for (let data of _task_datas) {
                if (data['achieved'] && !data['rewarded']) {
                    can_receive = true;
                    break;
                }
            }
            this.btn_receive.mouseEnabled = can_receive;
            this.btn_receive.skin = game.Tools.localUISrc('myres/activity_spot/' + (can_receive ? 'btn_receive.png' : 'btn_rewarded.png'));
        }
    }
}