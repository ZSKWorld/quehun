/**
* name 
*/
module uiscript{

	class TaskCell {
		public me:Laya.Sprite;

		private container_info:Laya.Sprite;
		private item_icon:Laya.Image;
		private item_name:Laya.Label;
		private item_count:Laya.Label;
		private plane_task_name:Laya.Panel;
		private task_name:Laya.Label;
		private progress_bar:Laya.Sprite;
		private progress_label:Laya.Label;
		private btn_get:Laya.Button;
		private flag_getted:Laya.Sprite;

		private id:number = 0;
		private item_id:number = 0;

		public constructor(me: Laya.Sprite) {
			this.me = me;
			this.me.visible = false;
			this.container_info = me.getChildByName('info') as Laya.Sprite;
			this.plane_task_name = this.container_info.getChildByName('container_taskname') as Laya.Panel;
			this.task_name = this.plane_task_name.getChildByName('taskname') as Laya.Label;
			this.item_icon = this.container_info.getChildByName('item') as Laya.Image;
			this.item_name = this.container_info.getChildByName('item_name') as Laya.Label;
			this.item_count = this.container_info.getChildByName('item_count') as Laya.Label;
			this.progress_bar = this.container_info.getChildByName('bar').getChildByName('val') as Laya.Sprite;
			this.progress_label = this.container_info.getChildByName('progress') as Laya.Label;
			this.btn_get = this.container_info.getChildByName('btn_get') as Laya.Button;
			this.flag_getted = this.container_info.getChildByName('alreadyget') as Laya.Sprite;
			(this.container_info.getChildByName('btn_item') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				UI_ItemDetail.Inst.show(this.item_id);
			}, null, false);
		}

		public show(info:any) {
			this.me.visible = true;
			let id = info.id;
			this.id = id;
			let d_activity_task = cfg.activity.task.get(info.id);
			let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
			
			this.container_info.visible = true;
			this.btn_get.visible = false;
			this.flag_getted.visible = false;

			if (info.rewarded) {
				this.flag_getted.visible = true;
			} else {
				this.btn_get.visible = true;
				if (info.achieved) {
					game.Tools.setGrayDisable(this.btn_get, false);
					this.btn_get.clickHandler = Laya.Handler.create(this, ()=>{
						game.Tools.setGrayDisable(this.btn_get, true);
						app.NetAgent.sendReq2Lobby('Lobby', 'completeActivityTask', { task_id: id}, (err, res) => {
							game.Tools.setGrayDisable(this.btn_get, false);
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('completeActivityTask', err, res);
							} else {
								if (this.id == id) {
									this.btn_get.visible = false;
									this.flag_getted.visible = true;
									let s:string = game.Tools.strOfLocalization(2234) + (this.item_name.text + ' ' + this.item_count.text);
									UI_LightTips.Inst.show(s);
								}
								UI_Activity.onTaskRewarded(id);
							}
						});
					}, null, false);
				} else {
					game.Tools.setGrayDisable(this.btn_get, true);
					this.btn_get.clickHandler = null;
				}
			}

			this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
			this.task_name.width = this.task_name.textField.textWidth;
			this.task_name.x = 0;
			if (this.task_name.width > this.plane_task_name.width) {
				let dx:number = this.plane_task_name.width - this.plane_task_name.width + 200;
				let start_time:number = Laya.timer.currTimer;
				let t0:number = 2000;
				let speed:number = 0.06;
				let t1:number = dx / speed;
				let t2:number = 1000;
				Laya.timer.clearAll(this);
				Laya.timer.frameLoop(1, this, () => {
					let dt:number = Laya.timer.currTimer - start_time;
					dt = dt - Math.floor(dt / (t0 + t1 + t2)) * (t0 + t1 + t2);
					if (dt <= t0) {
						this.task_name.x = 0;
					} else if (dt <= t1 + t0){
						this.task_name.x = -speed * (dt - t0);
					}
				});
			}

			this.item_id = d_activity_task.reward_id;
			this.item_count.text = 'x' + d_activity_task.reward_count;
			let d_currency = cfg.item_definition.currency.get(d_activity_task.reward_id);
			if (d_currency) {
				game.LoadMgr.setImgSkin(this.item_icon, d_currency.icon);
				this.item_name.text = d_currency['name_' + GameMgr.client_language];
			}
			let d_item = cfg.item_definition.item.get(d_activity_task.reward_id);
			if (d_item) {
				game.LoadMgr.setImgSkin(this.item_icon, d_item.icon);
				this.item_name.text = d_item['name_' + GameMgr.client_language];
			}
			this.item_count.x = this.item_name.textField.textWidth + this.item_name.x + 50;
			let counter:number = info.counter;
			if (!counter) counter = 0;
			if (counter > d_task_info.target) counter = d_task_info.target;
			this.progress_bar.scaleX = counter / d_task_info.target;
			this.progress_label.text = counter.toString() + '/' + d_task_info.target.toString();
		}

		public stop_roll() {
			Laya.timer.clearAll(this);
		}
	}

	export class UI_Activity_Task extends UI_ActivityBase{

		protected root:Laya.Sprite;
		protected content:Laya.Panel;
		protected head:Laya.Image;
		private task_templete:Laya.Sprite;
		protected task_cells:Array<TaskCell>;
		private scrollbar:Laya.Sprite;
		private scrollpoint:Laya.Sprite;

		protected head_url:string;
		protected head_width:number;
		protected head_height:number;
		protected total_h:number;

		//左边标题的名称
		constructor(name:string, uiname:string = 'activity_taskUI') {
			super(name, new ui.lobby.activitys[uiname]());
		}

		//头部图片的路径，头部图片资源的宽度和高度，会自适应到当前大小，不接受在开启状态下修改
		public setHead(head_url:string, head_width:number, head_height:number) {
			this.head_url = head_url;
			this.head_width = head_width;
			this.head_height = head_height;

			if (this.head_width != this.content.width) {
				this.head_height *= this.content.width / this.head_width;
				this.head_width = this.content.width;
			}
			this.head.width = this.head_width;
			this.head.height = this.head_height;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = this.root.getChildByName('content') as Laya.Panel;
			this.head = this.content.getChildByName('head') as Laya.Image;
			this.task_templete = this.content.getChildByName('task_templete') as Laya.Sprite;
			this.task_templete.visible = false;
			this.task_cells = [];
			for (let i:number = 0; i < 25; i++) {
				this.task_cells.push(new TaskCell(this.task_templete.scriptMap['capsui.UICopy']['getNodeClone']()));
			}

			this.scrollbar = this.root.getChildByName('scrollbar') as Laya.Sprite;
			this.scrollpoint = this.scrollbar.getChildByName('scrollpoint') as Laya.Sprite;
			this.content.vScrollBarSkin = '';
			this.content.vScrollBar.on('change', this, ()=>{
				this.refresh_scrollbar();
			});
			
		}

		//刷新显示内容
		protected refreshView(datas) {
			game.LoadMgr.setImgSkin(this.head, this.head_url);
			let h:number = this.head_height + 15;
			for (let i:number = 0; i < this.task_cells.length; i++) {
				if (i < datas.length) {
					this.task_cells[i].show(datas[i]);
					this.task_cells[i].me.y = h;
					h += this.task_cells[i].me.height;
				} else {
					this.task_cells[i].me.visible = false;
				}
			}
			this.total_h = h;
			this.content.refresh();
			this.refresh_scrollbar();
		}

		private refresh_scrollbar() {
			if (this.total_h > this.content.height) {
				let rate = this.content.vScrollBar.value / this.content.vScrollBar.max;
				this.scrollpoint.height = this.scrollbar.height * this.content.height / this.total_h;
				this.scrollpoint.y = rate * this.scrollbar.height * (1 - this.content.height / this.total_h);
				this.scrollbar.visible = true;
			} else {
				this.scrollbar.visible = false;
			}
		}

		public onDisable(): void {
			for (let i:number = 0; i < this.task_cells.length; i++) {
				this.task_cells[i].stop_roll();
			}
		}
	}
}