/**
* name 
*/
module uiscript {

	//于：2410版本UI_Activity_Task_Random已改为适配新活动面板
	export class UI_Activity_Task_Random extends UI_ActivityBase {

		private static _task_infos: Object = null;

		public static FindTaskInfo(id: number):lqc.Sheet_Activity_RandomTaskPool {
			if (!cfg.activity.random_task_pool) return null;
			if (!this._task_infos) {
				this._task_infos = {};
				cfg.activity.random_task_pool.forEach(x => {
					this._task_infos[x.task_id] = x;
				});
			}
			return this._task_infos[id];
		}

		protected root: Laya.Sprite;
		protected content: Laya.Panel;
		protected head: Laya.Image;
		private task_templete: Laya.Sprite;
		protected task_cells: Array<UI_Activity_TaskItem>;
		private scrollbar: capsui.CScrollBar;

		protected head_url: string;
		protected head_width: number;
		protected head_height: number = 288;
		protected total_h: number;

		//左边标题的名称
		constructor(name: string, uiname: string = 'activity_taskUI') {
			super(name, new ui.lobby.activitys[uiname]());
		}

		//头部图片的路径，头部图片资源的宽度和高度，会自适应到当前大小，不接受在开启状态下修改
		public setHead(head_url: string, head_width: number, head_height: number) {
			this.head_url = head_url;
			this.head_width = head_width;
			this.head_height = head_height;
			game.LoadMgr.setImgSkin(this.head, head_url);

			// if (this.head_width != this.content.width) {
			// 	this.head_height *= this.content.width / this.head_width;
			// 	this.head_width = this.content.width;
			// }
			// this.head.width = this.head_width;
			// this.head_height = this.head_height;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = this.root.getChildByName('content') as Laya.Panel;
			this.head = this.content.getChildByName('head') as Laya.Image;
			this.task_templete = this.content.getChildByName('task_templete') as Laya.Sprite;
			this.task_templete.visible = false;
			this.task_cells = [];
			for (let i: number = 0; i < 25; i++) {
				let item = this.task_templete.scriptMap['capsui.UICopy']['getNodeClone']();
				let taskItem = new UI_Activity_TaskItem(item);
				taskItem.progressRemain = true;
				this.task_cells.push(taskItem);
				this.content.addChild(item);
			}

			this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.content.vScrollBarSkin = '';
			this.scrollbar.init(new Laya.Handler(this, rate => {
				this.content.vScrollBar.value = this.content.vScrollBar.max * rate;
			}));
			this.content.vScrollBar.on('change', this, () => {
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.total_h);
			});
		}

		//刷新显示内容
		protected refreshView(datas: game.ITaskProgress[]) {
			let h: number = this.head_height + 10;
			for (let i: number = 0; i < this.task_cells.length; i++) {
				let item: UI_Activity_TaskItem = this.task_cells[i];
				if (i < datas.length) {
					const randomTaskInfo = UI_Activity_Task_Random.FindTaskInfo(datas[i].id);
					const taskInfo: ITaskInfo = {
						baseTaskId: randomTaskInfo.base_task_id,
						rewardId: randomTaskInfo.reward_id,
						rewardCount: randomTaskInfo.reward_count,
					};
					item.refresh(datas[i], taskInfo);
					item.clearGetBtnClickHandler();
					item.getBtnClickHandler = Laya.Handler.create(this, () => {
						item.getBtnEnable = false;
						app.NetAgent.sendReq2Lobby('Lobby', 'completeRandomActivityTask', { task_id: datas[i].id }, (err, res) => {
							item.getBtnEnable = true;
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('completeRandomActivityTask', err, res);
							} else {
								let d_view = game.GameUtility.get_item_view(item.itemId);
								let s: string = game.Tools.strOfLocalization(2234) + (d_view.name + ' x' + item.itemCount);
								UI_LightTips.Inst.show(s);
								datas[i].rewarded = true;
								item.refresh(datas[i], taskInfo);
							}
						});
					}, null, false);
					item.me.y = h;
					h += item.me.height;
				} else {
					item.me.visible = false;
				}
			}
			this.total_h = h;
			this.content.refresh();
			this.refresh_scrollbar();
		}

		private refresh_scrollbar() {
			this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.total_h);
		}

	}
}