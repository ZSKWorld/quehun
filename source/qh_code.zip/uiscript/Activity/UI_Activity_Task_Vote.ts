/**
* name 
*/
module uiscript {
    export class UI_Activity_Task_Vote extends UI_Activity_Task_Period {

        public static activity_id: number = 240453;
        public static yueka_task_id: number = 24045401;

        private label_count: Laya.Label;
        private pop: Laya.Sprite;
        private pop_info: Laya.Label;
        private btn_get: Laya.Button;
        private btnLabel: Laya.Label;

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Task_Vote.activity_id)['name_' + GameMgr.client_language], 'activity_vote_taskUI');
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres/activity_vote_banner/bg.jpg`, 974, 500);
            (this.head.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity.activity_is_running(UI_Activity_Vote.activity_id)) {
                    UI_Activity.Inst.close();
                    UI_Activity_Vote.Inst.show();
                } else {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3944));
                    return;
                }
                
            })
            this.label_count = this.head.getChildByName('count') as Laya.Label;
            // if (GameMgr.client_language == 'en') {
            //      this.label_count.x -= 13;
            //       this.label_count.y -= 4;
            // }

            this.pop = this.head.getChildByName('pop') as Laya.Sprite;
            this.pop_info = this.pop.getChildByName('info') as Laya.Label;
            if (GameMgr.client_language == 'en' ||  GameMgr.client_language == 'jp' ) {
                this.pop_info.fontSize = 22;
            } else if (GameMgr.client_language == 'kr') {
                this.pop_info.fontSize = 16;
            }
            this.btn_get = this.pop.getChildByName('btn') as Laya.Button;
            this.btnLabel = this.btn_get.getChildByName("title") as Laya.Label;
            this.btn_get.clickHandler = Laya.Handler.create(this, ()=>{
                let _info = UI_Activity.getPeriodTaskInfo(UI_Activity_Task_Vote.yueka_task_id);
                if (_info && !_info['achieved']) {
                    UI_Activity.Inst.jumpToActivity({key: 'jump_id', value: 'yueka'});
                    return;
                }
                game.Tools.setGrayDisable(this.btn_get, true);
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: UI_Activity_Task_Vote.yueka_task_id}, (err, res) => {
                    game.Tools.setGrayDisable(this.btn_get, false);
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        this.pop.visible = false;
                        let reward_id:number = 0;
                        let reward_count:number = 0;
                        let d_activity_task = cfg.activity.period_task.get(UI_Activity_Task_Vote.yueka_task_id);
                        {
                            let ss:Array<string> = d_activity_task.reward.split('-');
                            reward_id = parseInt(ss[0]);
                            reward_count = parseInt(ss[1]);
                        }
                        let _info = game.GameUtility.get_item_view(reward_id);
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2234) + _info.name + ' x' + reward_count);

                        UI_Activity.onTaskRewarded(UI_Activity_Task_Vote.yueka_task_id);
                    }
                });
            }, null, false);
            UI_Bag.add_item_listener(UI_Activity_Vote.item_id, new Laya.Handler(this, ()=>{
                if (this.enable) {
                    this.refreshCount();
                }
            }));
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Task_Vote.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Task_Vote.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            let _info = UI_Activity.getPeriodTaskInfo(UI_Activity_Task_Vote.yueka_task_id);
            if (_info && _info['achieved'] && !_info['rewarded']) {
                return true;
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Task_Vote.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;

            this.refreshCount();
            this.refreshPopState();
            this.refreshView(UI_Activity.getPeriodTaskList(UI_Activity_Task_Vote.activity_id));
        }

        public hide() {
            this.enable = false;
        }

        private refreshCount() {
            this.label_count.text = UI_Bag.get_item_count(UI_Activity_Vote.item_id) + '';
        }

        private refreshPopState() {
            let _info = UI_Activity.getPeriodTaskInfo(UI_Activity_Task_Vote.yueka_task_id);
            if (!_info || (_info['achieved'] && _info['rewarded'])) {
                this.pop.visible = false;
                return;
            }
            //如果达成了领取条件
            if (_info['achieved']) {
                this.pop_info.text = game.Tools.strOfLocalization(3911);
                this.btnLabel.text = game.Tools.strOfLocalization(3628);
                if (GameMgr.client_language == 'kr') {
                    this.pop_info.fontSize = 22;
                }
            } else {
                this.pop_info.text = game.Tools.strOfLocalization(3914);
                this.btnLabel.text = game.Tools.strOfLocalization(3031);
                if (GameMgr.client_language == 'kr') {
                    this.pop_info.fontSize = 16;
                }
            }
            this.pop.visible = true;
        }
    }
}