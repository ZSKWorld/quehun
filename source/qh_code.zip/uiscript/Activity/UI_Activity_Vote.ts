/**
* name 
*/
module uiscript{
    class TaskCell {
        private me: Laya.Sprite;
        private icon: Laya.Image;
        private count: Laya.Label;
        private id: number;
        private item_id: number;
        private btn_receive: Laya.Button;
        private doing: Laya.Label;
        private received: Laya.Sprite;
        private reward_count: Laya.Label;
        private reward_bg: Laya.Sprite;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.icon = me.getChildByName('btn_item').getChildByName('item') as Laya.Image;
            this.count = me.getChildByName('count') as Laya.Label;
            (me.getChildByName('btn_item') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (!this.item_id) return;
                UI_ItemDetail.Inst.show(this.item_id);
            });
            this.btn_receive = me.getChildByName('btn_receive') as Laya.Button;
            this.btn_receive.clickHandler = new Laya.Handler(this, ()=>{
                if (!this.id) return;
                let id = this.id;
                this.setBtnGrayDisable(true);
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: this.id }, (err, res) => {
                    this.setBtnGrayDisable(false);
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        this.btn_receive.visible = false;
                        this.doing.visible = false;
                        this.received.visible = true;
                        UI_Activity.onTaskRewarded(id);
                        let reward_id:number = 0;
                        let reward_count:number = 0;
                        let d_activity_task = cfg.activity.period_task.get(id);
                        {
                            let ss:Array<string> = d_activity_task.reward.split('-');
                            reward_id = parseInt(ss[0]);
                            reward_count = parseInt(ss[1]);
                        }
                        let _info = game.GameUtility.get_item_view(reward_id);
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2234) + _info.name + ' x' + reward_count);
                        Laya.timer.once(100, this, ()=>{
                            UI_Lobby.Inst.top.refreshRedpoint();
                        });
						UI_Lobby.Inst.top.refreshRedpoint();
                    }
                });
            });

            this.received = me.getChildByName('received') as Laya.Sprite;
            this.doing = me.getChildByName('doing') as Laya.Label;
            this.reward_bg = me.getChildByName('btn_item').getChildByName('text_bg') as Laya.Sprite;
            this.reward_count = me.getChildByName('btn_item').getChildByName('count') as Laya.Label;
        }

        public show(info: any) {
            if (!info) {
                this.me.visible = false;
                return;
            }
            this.me.visible = true;
            let id = info.id;
            this.id = id;
            this.setBtnGrayDisable(false);
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            let rewards = d_activity_task.reward.split('-');
            this.item_id = Number(rewards[0]);
            let type = game.GameUtility.get_id_type(this.item_id);
            if (type == game.EIDType.currency) {
                let _data = cfg.item_definition.currency.get(this.item_id)
                game.LoadMgr.setImgSkin(this.icon, _data.icon_jpg);
            } else {
                game.LoadMgr.setImgSkin(this.icon, game.GameUtility.get_item_view(this.item_id).icon);
            }
            this.reward_count.text = rewards[1];
            if (Number(rewards[1]) > 1) {
                this.reward_bg.visible = true;
                this.reward_count.visible = true;
            } else {
                this.reward_bg.visible = false;
                this.reward_count.visible = false;
            }
            
            let counter = Math.min(info.counter, d_task_info.target);
            if (GameMgr.client_language == 'en') {
                this.count.text = game.Tools.strOfLocalization(3621) + '\n' + counter + '/' + d_task_info.target;
                this.count.fontSize = 30;
            } else {
                this.count.text = game.Tools.strOfLocalization(3621) + counter + '/' + d_task_info.target;
            }
            
             if (info.rewarded) {
                this.btn_receive.visible = false;
                this.doing.visible = false;
                this.received.visible = true;
            } else if (info.achieved) {
                this.btn_receive.visible = true;
                this.doing.visible = false;
                this.received.visible = false;
            } else {
                this.btn_receive.visible = false;
                this.doing.visible = true;
                this.received.visible = false;
            }
        }

        private setBtnGrayDisable(gray: boolean) {
            game.Tools.setGrayDisable(this.btn_receive, gray);
        }

    }
	class Page_Reward {
        private scrollview:capsui.CScrollView;
        public activity_id: number = 240455;
        private task_list: Array<Object> = [];
        private label_count: Laya.Label;
        private btn_jump: Laya.Button;
        private final_task: TaskCell;

        constructor(me: Laya.Sprite) {
            this.scrollview = (me.getChildByName('content') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
			this.scrollview.reset();
            this.btn_jump = me.getChildByName('btn_jump') as Laya.Button;
            this.btn_jump.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Vote.Inst.locking) return;
                if (!UI_Activity.activity_is_running(UI_Activity_Task_Vote.activity_id)) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3638));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                UI_Activity_Vote.Inst.close();
                UI_Activity.Inst.show();
                UI_Activity.Inst.jumpToActivity({key:'activity_id', value: UI_Activity_Task_Vote.activity_id});
            });
            this.label_count = me.getChildByName('count').getChildByName('count') as Laya.Label;
            let label = me.getChildByName('count').getChildAt(1) as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.label_count.x = label.x + label.trueWidth + 5;
            }
            
            this.final_task = new TaskCell(me.getChildByName('content').getChildByName('templete') as Laya.Sprite);
        }

        public show() {
            this.task_list = UI_Activity.getPeriodTaskList(this.activity_id);
            this.scrollview.reset();
            this.scrollview.addItem(this.task_list.length - 1);
            this.final_task.show(this.task_list[this.task_list.length - 1]);
            this.label_count.text = UI_Bag.get_item_count(UI_Activity_Vote.item_id) + '';
            game.Tools.setGray(this.btn_jump, UI_Activity_Vote.get_vote_ended()); //去除置灰处理
        }

        private render_item(data) {
			let index:number = data.index;
			let container:Laya.Sprite = data.container;
            let cache_data: Object = data.cache_data;
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container);
            }
            cache_data['cell'].show(this.task_list[index]);
        }

        // 任务进度发生改变
        public refresh() {
            this.task_list = UI_Activity.getPeriodTaskList(this.activity_id);
            this.scrollview.wantToRefreshAll();
            this.final_task.show(this.task_list[this.task_list.length - 1]);
            this.label_count.text = UI_Bag.get_item_count(UI_Activity_Vote.item_id) + '';
        }
    }

    class Item_Rank {
        private unknown: Laya.Sprite;
        private skin: Laya.Image;
        private name: Laya.Label;
        private chara_name: Laya.Label;
        private dongtai: Laya.Sprite;

        constructor(me: Laya.Sprite) {
            this.unknown = me.getChildByName('unknown') as Laya.Sprite;
            this.skin = me.getChildByName('skin') as Laya.Image;
            this.name = me.getChildByName('name') as Laya.Label;
            this.chara_name = me.getChildByName('chara_name') as Laya.Label;
            this.dongtai = me.getChildByName('dongtai') as Laya.Sprite;
        }

        public refresh(id: number) {
            if (id) {
                this.unknown.visible = false;
                this.skin.visible = true;
                
                let skin = cfg.shops.goods.get(id);
                game.LoadMgr.setImgSkin(this.skin, skin.icon, null, 'UI_Activity_Vote');
                
                let _skin = cfg.item_definition.skin.get(skin.item_id);
                this.name.text = _skin['name_' + GameMgr.client_language];
                let chara = cfg.item_definition.character.get(_skin.character_id);
                this.chara_name.text = chara['name_' + GameMgr.client_language];
                if (GameMgr.client_language == "en" || GameMgr.client_language == "kr") {
                    this.name.fontSize = 24;
                    this.chara_name.fontSize = 22;
                } else {
                    this.name.fontSize = 30;
                    this.chara_name.fontSize = 28;
                }
                this.chara_name.y = this.name.trueHeight/2 + this.name.y + 7;
                this.dongtai.visible = !!_skin.spine_type;
            } else {
                this.dongtai.visible = false;
                this.unknown.visible = true;
                this.skin.visible = false;
                this.name.text = game.Tools.strOfLocalization(3616);
                this.chara_name.text = '';
            }
        }
    }
    class Page_Rank {
        public me: Laya.Sprite;
        private items: Array<Item_Rank>;
        private item_boy: Item_Rank;
        private time: Laya.Label;
        private refresh_time: number = -1;
        private refresh_boy_time: number = -1;
        constructor(me: Laya.Sprite) {
            this.me = me;
            this.items = [];
            for (let i = 0; i < 3; i++) {
                this.items.push(new Item_Rank(this.me.getChildByName('item_' + i).getChildAt(0).getChildAt(0) as Laya.Sprite));
            }
            this.item_boy = new Item_Rank(this.me.getChildByName('item_3').getChildAt(0).getChildAt(0) as Laya.Sprite);
            this.time = this.me.getChildByName('time').getChildByName('time') as Laya.Label;
            let desc = me.getChildByName('desc') as Laya.Sprite;
            let desc1: Laya.Sprite = desc.getChildByName('0') as Laya.Sprite;
            let desc2: Laya.Sprite = desc.getChildByName('1') as Laya.Sprite;
            let descLable1: Laya.Label = desc1.getChildByName('desc') as Laya.Label;
            let descLable2: Laya.Label = desc2.getChildByName('desc') as Laya.Label;
            


            // (desc.getChildByName('1') as Laya.Sprite).y = (desc.getChildByName('0').getChildByName('desc') as Laya.Label).trueHeight + 42;
            if (GameMgr.client_language == 'en') {  
                desc1.y -= 23;
            } else if (GameMgr.client_language == 'kr') {            
                desc1.y -= 10;
            }
            //根据第一个的文本内容移动第二个文本框
            desc2.y = descLable1.trueHeight + desc1.y;
        }

        public show() {
            this.me.visible = true;
            
            UI_Activity_Vote.Inst.checkVoteUpdate();
            this.refresh();
            this.refreshBoy();
        }

        public close() {
            this.me.visible = false;    
        }

        public refresh() {
            if (UI_Activity_Vote.update_time == this.refresh_time) return;
            this.refresh_time = UI_Activity_Vote.update_time;
            let _data = cfg.activity.vote_activity.get(UI_Activity_Vote.activity_id);
            if (UI_Activity_Vote.get_vote_ended()) {
                this.time.text = game.Tools.strOfLocalization(3638);
            } else if (this.refresh_time) {
                this.time.text = game.Tools.strOfLocalization(3626) + game.Tools.time2YearMounthDate(this.refresh_time, '-') + ' '
				    + game.Tools.time2HourMinute(this.refresh_time, true);
            } else {
                this.time.text = '';
            }
            if (UI_Activity_Vote.vote_rank) {
                for (let i = 0; i < this.items.length; i++) {
                    this.items[i].refresh(UI_Activity_Vote.vote_rank[i]);
                }
            } else {
                for (let i = 0; i < this.items.length; i++) {
                    this.items[i].refresh(0);
                }
            }
        }

        public refreshBoy() {
            if (UI_Activity_Vote.boy_update_time == this.refresh_boy_time) return;
            this.refresh_boy_time = UI_Activity_Vote.boy_update_time;
            let _data = cfg.activity.vote_activity.get(UI_Activity_Vote.activity_id);
            if (UI_Activity_Vote.get_vote_ended()) {
                this.time.text = game.Tools.strOfLocalization(3638);
            } else if (this.refresh_boy_time) {
                this.time.text = game.Tools.strOfLocalization(3626) + game.Tools.time2YearMounthDate(this.refresh_boy_time, '-') + ' '
				    + game.Tools.time2HourMinute(this.refresh_boy_time, true);
            } else {
                this.time.text = '';
            }
            if (UI_Activity_Vote.boy_vote_rank) {
                this.item_boy.refresh(UI_Activity_Vote.boy_vote_rank[0]);
                
            } else {
                this.item_boy.refresh(0);
            }
        
        }
    }

    class Item_Vote {
        public me: Laya.Sprite;
        private skin: Laya.Image;
        private name: Laya.Label;
        private chara_name: Laya.Label;
        private id: number;
        private count: Laya.Label;
        private dongtai: Laya.Sprite;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.skin = this.me.getChildByName('skin') as Laya.Image;
            this.name = this.me.getChildByName('name') as Laya.Label;
            this.chara_name = this.me.getChildByName('chara_name') as Laya.Label;
            (this.me.getChildByName('btn_vote') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Vote.Inst.locking) return;
                if (UI_Bag.get_item_count(UI_Activity_Vote.item_id) <= 0) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3633));
                    return;
                }
                
                let skin = cfg.shops.goods.get(this.id);
                let _skin = cfg.item_definition.skin.get(skin.item_id);
                let chara = cfg.item_definition.character.get(_skin.character_id);
                let activity_id = chara.sex == 1 ? UI_Activity_Vote.activity_id : UI_Activity_Vote.boy_activity_id;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3632, [chara['name_' + GameMgr.client_language] + '-' + _skin['name_' + GameMgr.client_language]]), Laya.Handler.create(this, ()=>{
                    UI_Activity_Vote.Inst.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'voteActivity', { activity_id: activity_id , vote: this.id}, (err, res) => {
                        UI_Activity_Vote.Inst.locking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('voteActivity', err, res);
                        } else if (res['vote_records']) {
                            
                            
                            UI_Activity_Vote.update_data(res['vote_records']);
                            UI_Activity_Vote.Inst.onVoteSuccess();
                            UI_LightTips.Inst.show(game.Tools.strOfLocalization(3634));
                                        
                            let _info_map = chara.sex == 1 ? UI_Activity_Vote.vote_count_info : UI_Activity_Vote.boy_vote_count_info;
                            this.count.text = game.Tools.strOfLocalization(3623, [((_info_map && _info_map[this.id]) ? _info_map[this.id] : 1) + '']);
                        }
                    });
                }));
                
            });
            (this.me.getChildByName('btn_zoom') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Vote.Inst.locking) return;
                UI_Activity_Vote.Inst.close();
                let goods = cfg.shops.goods.get(this.id);
                UI_Lobby.Inst.Hide(Laya.Handler.create(this, ()=>{
                    game.Scene_Lobby.Inst.change_bg('indoor', false);
                    UI_Skin_Yulan.Inst.show(goods.item_id, Laya.Handler.create(this, ()=>{
                        UI_Lobby.Inst.enable = true;
                        UI_Activity_Vote.Inst.show(1);
                    }))
                }));
            });
            this.count = this.me.getChildByName('btn_vote').getChildByName('count') as Laya.Label;
            this.dongtai = this.me.getChildByName('dongtai') as Laya.Sprite;
        }

        public show(id: number) {
            this.id = id;
            let skin = cfg.shops.goods.get(id);
            game.LoadMgr.setImgSkin(this.skin, skin.icon, null, 'UI_Activity_Vote');
            
            let _skin = cfg.item_definition.skin.get(skin.item_id);
            this.dongtai.visible = !!_skin.spine_type;
            this.name.text = _skin['name_' + GameMgr.client_language];
            // this.name.color = '#000001';
            let chara = cfg.item_definition.character.get(_skin.character_id);
            this.chara_name.text = chara['name_' + GameMgr.client_language];
            if (GameMgr.client_language == "en" ||GameMgr.client_language == "kr") {
                this.name.fontSize = 24;
                this.chara_name.fontSize = 22;
            }
            this.chara_name.y = this.name.trueHeight/2 + this.name.y + 7;
            this.count.text = game.Tools.strOfLocalization(3623, [UI_Activity_Vote.get_vote_count(id) + '']);
        }
    }
    class Page_Vote {
        public me: Laya.Sprite;
        private scrollview: capsui.CScrollView;
        private have_init = false;
        public voted: boolean = false;
        private randomSeed: number;
        private choice_info_list: Array<{id: number, sort: number}>;
        constructor(me: Laya.Sprite) {
            this.me = me;
            this.scrollview = (this.me.getChildByName('content') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item), -1, 4);
            this.scrollview.reset();
            let _data = cfg.activity.vote_activity.get(UI_Activity_Vote.activity_id);
            let _boy_data = cfg.activity.vote_activity.get(UI_Activity_Vote.boy_activity_id);
            let strs = _data.choice_id_list.split(',');
            strs = strs.concat(_boy_data.choice_id_list.split(','));
            this.randomSeed = GameMgr.Inst.account_id;
            let n = strs.length;

            let tmp = null;
            this.choice_info_list = [];
            while(n > 0) {
                let index = this.random(0, n);
                n--;
                this.choice_info_list.push({id: Number(strs[index]), sort: n - this.choice_info_list.length});
                tmp = strs[n];
                strs[n] = strs[index];
                strs[index] = tmp;
            }
            
        }

        public show() {
            this.me.visible = true;
            this.choice_info_list.sort((a, b)=>{
                let sort_a = a.sort + UI_Activity_Vote.get_vote_count(a.id) * 1000;
                let sort_b = b.sort + UI_Activity_Vote.get_vote_count(b.id) * 1000;
                return sort_b  - sort_a;
            })
            if (!this.have_init) {
                this.scrollview.addItem(this.choice_info_list.length);
                this.have_init = true;
            } else if(this.voted){
                this.scrollview.wantToRefreshAll();
            }
        }

        public close() {
            this.me.visible = false;    
        }

        private render_item(data: any) {
            let index:number = data.index;
			let container:Laya.Sprite = data.container;
            let cache_data: Object = data.cache_data;
            if (!cache_data['cell']) {
                cache_data['cell'] = new Item_Vote(container);
            }
            cache_data['cell'].show(this.choice_info_list[index].id);
        }

        private seededRandom(seed, min, max): number {  
			seed = (seed * 9301 + 49297) % 233280;  
			var rand = seed / 233280;  
			return min + rand * (max - min);  
		}

		private random(min, max): number {
			
			min = min || 0;
			max = max || 1;
			var result = Math.floor(this.seededRandom(this.randomSeed, min, max));
			this.randomSeed += Math.floor(this.seededRandom(this.randomSeed, 1, 100000));
			return result;
		}
    }

	export class UI_Activity_Vote extends UIBase{

		public static Inst: UI_Activity_Vote = null;
        public static activity_id: number = 240451;
        public static boy_activity_id: number = 240452;
        public static reward_activity_id: number = 240455;
        public static item_id: number = 309059;
        public static vote_rank: Array<number>;
        public static boy_vote_rank: Array<number>;
        public static update_time: number;
        public static boy_update_time: number;
        public static vote_count_info: Object;
        public static boy_vote_count_info: Object;

        public static get_vote_count(id: number): number {
            if (UI_Activity_Vote.vote_count_info && UI_Activity_Vote.vote_count_info[id]) {
                return UI_Activity_Vote.vote_count_info[id];
            }
            if (UI_Activity_Vote.boy_vote_count_info && UI_Activity_Vote.boy_vote_count_info[id]) {
                return UI_Activity_Vote.boy_vote_count_info[id];
            }
            return 0;
        }
        public static get final_update_time(): number {
            if (!this.update_time) return this.boy_update_time;
            if (!this.boy_update_time) return this.update_time;
            return Math.max(this.boy_update_time, this.update_time);
        }

        public static Init() {
            if (UI_Activity.activity_is_running(this.activity_id)) {
                this.fetchVoteInfo();
                this.fetchVoteBoyInfo();
            }
        }

        public static have_redpoint(): boolean {
            if (!this.get_vote_ended() && UI_Bag.get_item_count(UI_Activity_Vote.item_id) > 0) {
                return true;
            }
            let list = UI_Activity.getPeriodTaskList(this.reward_activity_id);
            for (let info of list) {
                if (info['achieved'] && !info['rewarded']) {
                    return true;
                }
            }
            return false;
        }
        public static fetchVoteInfo() {
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchVoteActivity', { activity_id: this.activity_id}, (err, res) => {
                if (res) {
                    this.vote_rank = res['vote_rank'];
                    this.update_time = res['update_time'];
                    if (this.Inst && this.Inst.enable) {
                        this.Inst.refreshRank();
                    }
                }
            });
        }

        public static fetchVoteBoyInfo() {
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchVoteActivity', { activity_id: this.boy_activity_id}, (err, res) => {
                if (res) {
                    this.boy_vote_rank = res['vote_rank'];
                    this.boy_update_time = res['update_time'];
                    if (this.Inst && this.Inst.enable) {
                        this.Inst.refreshBoyRank();
                    }
                }
            });
        }
        public static update_data(lst: Array<{activity_id: number, vote: number, count: number}>) {
            this.vote_count_info = {};
            this.boy_vote_count_info = {};
            for (let info of lst) {
                if (info.activity_id == UI_Activity_Vote.activity_id) {
                    this.vote_count_info[info.vote] = info.count;
                } else if (info.activity_id == UI_Activity_Vote.boy_activity_id) {
                    this.boy_vote_count_info[info.vote] = info.count;
                }
            }

            
        }

        public static get_vote_ended(): boolean {
            if (!cfg.activity.vote_activity) return true;
            let _data = cfg.activity.vote_activity.get(UI_Activity_Vote.activity_id);
            return game.Tools.getTimeByStr(_data.vote_end_time) < game.Tools.getServerTime();
        }
        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private page_reward: Page_Reward;
        private page_rank: Page_Rank;
        private page_vote: Page_Vote;
        private vote_redpoint: Laya.Sprite;
        private btns: Array<Laya.Button>;
        private tabs: Laya.Sprite;

        public locking: boolean;
        private freshTicketHandler: Laya.Handler;

        constructor() {
			super(new ui.lobby.activity_clothes_vote.activity_clothes_voteUI());
			UI_Activity_Vote.Inst = this;
		}

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            game.LoadMgr.setImgSkin(this.root.getChildAt(0) as Laya.Image, 'myres/activity_vote/bg.png', null, 'UI_Activity_Vote')
            // if (GameMgr.client_language == 'en') {
            //     (this.root.getChildAt(1) as Laya.Sprite).scale(0.9, 0.9);
               
            // }else if (GameMgr.client_language == 'kr') {
            //     (this.root.getChildAt(1) as Laya.Sprite).scale(1.14, 1.14);
            // }
            this.page_reward = new Page_Reward(this.root.getChildByName('page_reward') as Laya.Sprite);
            this.page_rank = new Page_Rank(this.root.getChildByName('page_rank') as Laya.Sprite);
            this.page_vote = new Page_Vote(this.root.getChildByName('page_vote') as Laya.Sprite);
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            this.tabs = this.root.getChildByName('tabs') as Laya.Sprite;
            this.btns = [];
            this.vote_redpoint = this.root.getChildByName('tabs').getChildByName('btn_1').getChildByName('redpoint') as Laya.Sprite;
            for (let i = 0; i < 2; i++) {
                let btn = this.root.getChildByName('tabs').getChildByName('btn_' + i) as Laya.Button;
              
                btn.clickHandler = new Laya.Handler(this, ()=>{
                    this.onTabBtnClick(i);
                });
                this.btns.push(btn);
            }
            
            this.freshTicketHandler = new Laya.Handler(this,this.freshVoteTickets);
        }

        public show(tab_index: number = 0) {
            this.enable = true;
            this.bg.alpha = 0;
            (this.me as ui.lobby.activity_clothes_vote.activity_clothes_voteUI).ani1.play(0, false);
          
            this.root.scale(1, 1);
            this.root.alpha = 1;
            this.locking = true;
            Laya.timer.once(300, this, ()=>{
                this.locking = false;
            })
            this.page_reward.show();
            if (UI_Activity_Vote.get_vote_ended()) {
                this.btns[1].visible = false;
                tab_index = 0;
            } else {
                this.btns[1].visible = true;
            }
            this.onTabBtnClick(tab_index);
            this.vote_redpoint.visible = UI_Bag.get_item_count(UI_Activity_Vote.item_id) > 0;
            //添加背包物品改变的监听
            UI_Bag.add_item_listener(UI_Activity_Vote.item_id,this.freshTicketHandler)
        }

        public onTabBtnClick(index: number) {
            if (index == 0) {
                this.page_rank.show();
                this.page_vote.close();
            } else {
                this.page_rank.close();
                this.page_vote.show();
            }
            for (let i = 0; i < this.btns.length; i++) {
                let btnIndex = i;
                let btn = this.btns[i];
                //选中的那个btn层级设置为最前
                if (btnIndex == index) {
                    this.tabs.setChildIndex(btn, this.tabs._childs.length-1);
                }
                
                (btn.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/activity_vote/' + (i == 0 ? 'tag_rank_' : 'tag_vote_') + (index == i ? 'l.png' : 'd.png'));
            }


        }

        public close() {
            Laya.Tween.to(this.bg, {alpha: 0}, 200);
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
            UI_Bag.remove_item_listener(UI_Activity_Vote.item_id,this.freshTicketHandler)
        }

        public checkVoteUpdate() {
            let _data = cfg.activity.vote_activity.get(UI_Activity_Vote.activity_id);
            let _t =  game.Tools.getTimeByStr(_data.vote_end_time) / 1000;
            
            if (UI_Activity_Vote.update_time < _t || !UI_Activity_Vote.get_vote_ended()) {
                 // 不是同一个小时更新
                if (Math.floor(UI_Activity_Vote.update_time / 3600) != Math.floor(game.Tools.getServerTime() / 3600 /1000)) {
                    UI_Activity_Vote.fetchVoteInfo();
                }
            }
           
            if (UI_Activity_Vote.boy_update_time < _t || !UI_Activity_Vote.get_vote_ended()) {
                if (Math.floor(UI_Activity_Vote.boy_update_time / 3600) != Math.floor(game.Tools.getServerTime() / 3600 /1000)) {
                    UI_Activity_Vote.fetchVoteBoyInfo();
                }
            }
        }

        public refreshRank() {
            this.page_rank.refresh();
        }

        public refreshBoyRank() {
            this.page_rank.refreshBoy();
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Vote', true);
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Vote', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_vote.atlas'));
        }

        public onVoteSuccess() {
            this.page_vote.voted = true;
            this.page_reward.refresh();
            this.vote_redpoint.visible = UI_Bag.get_item_count(UI_Activity_Vote.item_id) > 0;
        }

        /**
         * 刷新票的数量
         */
        private freshVoteTickets(){
            Laya.timer.frameOnce(1, this, ()=>{
                this.page_reward.refresh();
                this.vote_redpoint.visible = UI_Bag.get_item_count(UI_Activity_Vote.item_id) > 0;
                UI_Lobby.Inst.top.refreshRedpoint();
            });

        }
    }
}
