/**
* name 
*/
module uiscript {
	class Point {
		public x: number;
		public y: number;
	}

	class MineReward {
		public point: Point;
		public reward_id: number;
		public received: boolean;
	}
	export class UI_Activity_Wajue extends UI_ActivityBase {

		public static Inst: UI_Activity_Wajue = null;
		public static activity_id: number = 250702;
		public static cost_item: number = 309037;
		public static dig_point: Array<Point>;
		public static map: Array<MineReward>;

		public static updateData(obj: game.IMineActivityData[]) {
			this.dig_point = [];
			this.map = [];
			for (let _info of obj) {
				if (_info.id == this.activity_id) {
					for (let point of _info.dig_point) {
						this.dig_point.push(point);
					}
					for (let map of _info.map) {
						this.map.push(map);
					}
					break;
				}
			}
		}
		public getId(): number {
			return UI_Activity_Wajue.activity_id;
		}

		private count: UI_ImageNumber;
		private mid: Laya.Sprite;
		private mid_templete: Laya.Sprite;
		private item_parent: Laya.Sprite;
		private item_templete: Laya.Sprite;
		private line_count: number = 9;
		private choosed: Laya.Sprite;
		private btn_mids: Array<Laya.Button> = [];
		private content: Laya.Panel;
		private scrollbar: capsui.CScrollBar;
		private bg: Laya.Image;
		private choose_index: number = -1;
		private item_width: number = 104;
		private locking: boolean = false;
		private animing: boolean = false;
		private _effects: Array<game.UIEffect> = [];

		//左边标题的名称
		constructor() {
			super(cfg.activity.activity.get(UI_Activity_Wajue.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_wajueUI());
			UI_Activity_Wajue.Inst = this;
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen(): boolean {
			return UI_Activity.activity_is_running(UI_Activity_Wajue.activity_id);
		}

		//活动是否要显示小红点
		public haveRedPoint(): boolean {
			//有挖掘次数并且有可以挖掘的位置
			let remainCount = UI_Bag.get_item_count(UI_Activity_Wajue.cost_item);
			if (remainCount <= 0) return false;
			if (UI_Activity_Wajue.dig_point.length >= (this.line_count * this.line_count)) {
				return false;			
			}
			return true;
		}

		//活动是否要弹出来
		public need_popout(): boolean {
			let d = cfg.activity.activity.get(UI_Activity_Wajue.activity_id);
			if (d && d.need_popout) return true;
			return false;
		}

		public onCreate() {
			let root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = root.getChildByName('content') as Laya.Panel;
			this.bg = this.content.getChildByName('bg') as Laya.Image;
			this.scrollbar = (root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.content.vScrollBarSkin = '';
			this.scrollbar.init(new Laya.Handler(this, rate => {
				this.content.vScrollBar.value = this.content.vScrollBar.max * rate;
			}));
			this.content.vScrollBar.on('change', this, () => {
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.bg.height);
			});

			this.count = new UI_ImageNumber(this.content.getChildByName('count_fan') as Laya.Sprite);
			let count_path = [];
			for (let index = 0; index < 10; index++) {
				let path = 'myres/activity_wajue/' + index + '.png';
				count_path.push(game.Tools.localUISrc(path));
			}
			this.count.init(count_path,-4);
			this.count.align = 'center';
			this.mid = this.content.getChildByName('container_mid') as Laya.Sprite;
			this.mid_templete = this.mid.getChildAt(0) as Laya.Sprite;
			this.item_parent = this.content.getChildByName('container_item') as Laya.Sprite;
			this.item_templete = this.item_parent.getChildAt(0) as Laya.Sprite;
			this.choosed = this.content.getChildByName('choosed') as Laya.Sprite;
			this.choosed.visible = false;
			this.mid_templete.visible = false;
			this.item_templete.visible = false;
			for (let i: number = 0; i < this.line_count; i++) {
				for (let j: number = 0; j < this.line_count; j++) {
					let t: Laya.Button = this.mid_templete.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Button;
					t.visible = true;
					t.x = this.item_width * j + (this.item_width / 2);
					t.y = this.item_width * i + (this.item_width / 2);
					t.width = this.item_width + 0.5;
					t.height = this.item_width + 0.5;
					this.btn_mids.push(t);
					let index = i * this.line_count + j;
					t.clickHandler = new Laya.Handler(this, () => {
						if (this.locking || this.animing) return;
						if (UI_Bag.get_item_count(UI_Activity_Wajue.cost_item) <= 0) {
							this.locking = true;
							Laya.timer.once(300, this, () => {
								this.locking = false;
							})
							UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217));
							return;
						}
						if (this.choosed.visible && index == this.choose_index) {
							this.dig_mine();
						} else {
							this.choosed.visible = true;
							this.choosed.pos(t.x + 78, t.y + 420);
							this.choose_index = index;
						}
					});
				}
			}
			(this.content.getChildByName('cancel') as Laya.Button).clickHandler = new Laya.Handler(this, () => {

				this.choose_index = -1;
				this.choosed.visible = false;

			});
			UI_Bag.add_item_listener(UI_Activity_Wajue.cost_item, new Laya.Handler(this, () => {
				//刷新活动页面红点
				UI_Activity.Inst.refresh_redpoint();
				UI_Lobby.Inst.top.refreshRedpoint();
				if (this.enable) {
					this.count.value = UI_Bag.get_item_count(UI_Activity_Wajue.cost_item);
				}
			}));

			// if (GameMgr.client_language == 'en') {
			// 	this.count.x = 351;
			// } else if (GameMgr.client_language == 'kr') {
			// 	this.count.x = 276;
			// }
			(this.content.getChildByName('task') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) {
					return;
				}
				//检查活动是否开启
				if (!UI_Activity.activity_is_running(UI_Activity_Wajue_Task.activity_id)) {
					UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25070207));
					return;
				}
				UI_Activity.Inst.jumpToActivity({ key: 'activity_id', value: UI_Activity_Wajue_Task.activity_id });
			});
		}

		public show() {
			// game.LoadMgr.setImgSkin(this.bg, 'myres/activity_shuiyi/bg.jpg');
			game.LoadMgr.setImgSkin(this.bg, cfg.activity.activity_banner.get(this.getId()).banner_big);
			this.enable = true;
			this.choosed.visible = false;
			this.choose_index = -1;
			this.refresh();
			this.refreshPoint();
			this.content.vScrollBar.value = 0;
		}

		private refresh() {
			this.count.value = UI_Bag.get_item_count(UI_Activity_Wajue.cost_item);
			let lst = cfg.activity.mine_reward.getGroup(UI_Activity_Wajue.activity_id);
			for (let info of UI_Activity_Wajue.map) {
				let item: Laya.Sprite = this.item_parent.getChildByName(info.reward_id.toString()) as Laya.Sprite;
				if (!item) {
					item = this.createRewardItem(info, lst);
				}
				(item.getChildByName('received') as Laya.Sprite).visible = info.received;
				(item.getChildByName('item') as Laya.Image).alpha = info.received ? 0.5 : 1;
			}
		}

		private refreshPoint() {
			for (let info of UI_Activity_Wajue.dig_point) {
				let item = this.btn_mids[info.x + info.y * this.line_count];
				if (item) {
					item.visible = false;
				}
			}
		}

		public hide() {
			this.enable = false;
		}


		public onDisable(): void {
			let atlas_root = 'res/atlas/';
			if (GameMgr.client_language != 'chs') {
				atlas_root += GameMgr.client_language + '/';
			}
			Laya.loader.clearTextureRes(atlas_root + 'myres/activity_wajue.atlas');
			if (this.bg.skin) {
				Laya.loader.clearTextureRes(this.bg.skin);
				game.LoadMgr.clearImgSkin(this.bg);
			}
		}

		private dig_mine() {
			this.locking = true;
			let index = this.choose_index;
			let point: Point = { y: Math.floor(this.choose_index / this.line_count), x: this.choose_index - Math.floor(this.choose_index / this.line_count) * this.line_count };
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.digMine, {
				activity_id: UI_Activity_Wajue.activity_id,
				point: point
			}, (err, res: game.IResDigMine) => {
				if (err || res.error) {
					this.locking = false;
					UIMgr.Inst.showNetReqError('digMine', err, res);
					if (res.error) {
						this.refreshPoint();
					}
				} else {
					this.count.value = UI_Bag.get_item_count(UI_Activity_Wajue.cost_item);
					UI_Activity_Wajue.dig_point.push(point);
					let newReward: MineReward = null;
					for (let _new_map of res.map) {
						let _is_old = false;
						for (let _map of UI_Activity_Wajue.map) {
							if (_map.reward_id == _new_map.reward_id) {
								if (_map.received != _new_map.received) {
									_map.received = _new_map.received;
									newReward = _map;
								}
								_is_old = true;
								break;
							}
						}
						if (!_is_old) {
							newReward = _new_map;
							UI_Activity_Wajue.map.push(_new_map);
						}
					}
					let item = this.btn_mids[index];
					this.animing = true;


					let _effect: game.UIEffect = this.createEffect(item, 'scene/effect_25wajue_break.lh', new Laya.Point(0, 0), 1.04);
					Laya.timer.once(200, this, () => {
						item.visible = false;
						this.animing = false;
					})
					let _item = null;
					if (newReward != null) {
						_item = this.item_parent.getChildByName(newReward.reward_id.toString());
						if (!_item) {
							let lst = cfg.activity.mine_reward.getGroup(UI_Activity_Wajue.activity_id);
							_item = this.createRewardItem(newReward, lst);

						}
					}

					Laya.timer.once(700, this, () => {
						this._remove_effect(_effect);
						_effect.destory();

						if (res.reward && res.reward.length > 0) {
							if (!_item) {
								// 寻找新点错误，直接播放奖励动画
								let rewards = [];
								for (let reward of res.reward) {
									rewards.push({ id: reward.id, count: reward['count'] });
								}
								game.Tools.showRewards({ rewards: rewards }, null);
								return;
							}
							let _huode_effect: game.UIEffect = this.createEffect(_item, 'scene/effect_25wajue_light.lh', new Laya.Point(0, 0), 1.04);

							let rect: Laya.Sprite = _item.getChildByName('rect') as Laya.Sprite;
							rect.visible = true;
							let self = this;
							Laya.Tween.to(_item, { scaleX: 1.1, scaleY: 1.1 }, 120, null, Laya.Handler.create(this, () => {
								Laya.Tween.to(_item, { scaleX: 1, scaleY: 1 }, 120, null, Laya.Handler.create(this, () => {
									(_item.getChildByName('item') as Laya.Image).alpha = 0.5;
									
									
									rect.visible = false;
									let received = _item.getChildByName('received') as Laya.Sprite;
									received.visible = true;
									let spr = received.getChildAt(0) as Laya.Sprite;
									spr.scale(1.6, 1.6);

									Laya.Tween.to(spr, { scaleX: 1, scaleY: 1 }, 250, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
										this._remove_effect(_huode_effect);
										_huode_effect.destory();
										let rewards = [];
										for (let reward of res['reward']) {
											rewards.push({ id: reward['id'], count: reward['count'] });
										}
										self.locking = false;
										game.Tools.showRewards({ rewards: rewards }, null);
									}))
								}));
							}));

						} else {
							this.locking = false;
						}
						// TODO 播放活动奖励
					});

					this.choose_index = -1;

					item.mouseEnabled = false;
					this.choosed.visible = false;
					//刷新活动页面红点
					UI_Activity.Inst.refresh_redpoint();
					UI_Lobby.Inst.top.refreshRedpoint();
				}
			});
		}

		public onClose() {
			for (let i: number = 0; i < this._effects.length; i++) {
				this._effects[i].destory();
			}
			this._effects = [];
		}

		private createEffect(node: Laya.Sprite, effect_name: string, offset: Laya.Point, scale: number = 1.0): game.UIEffect { 
			let effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(node, effect_name, offset, scale);
			this._add_effect(effect);
			return effect;
		}

		private _add_effect(effect: game.UIEffect) {
			this._effects.push(effect);
		}

		private _remove_effect(effect: game.UIEffect) {
			let lst: Array<game.UIEffect> = [];
			for (let i: number = 0; i < this._effects.length; i++) {
				if (this._effects[i] !== effect) {
					lst.push(this._effects[i]);
				}
			}
			this._effects = lst;
		}

		private createRewardItem(info: MineReward, lst: Array<lqc.Sheet_Activity_MineReward>): Laya.Sprite {
			let data: lqc.Sheet_Activity_MineReward = null;
			for (let _data of lst) {
				if (_data.reward_id == info.reward_id) {
					data = _data;
					break;
				}
			}
			let t: Laya.Sprite = this.item_templete.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
			let rect = (t.getChildByName('rect') as Laya.Sprite);
			rect.visible = false;
			t.name = info.reward_id.toString();
			t.x = info.point.x * this.item_width;
			t.y = info.point.y * this.item_width;
			t.width = data.x * this.item_width;
			t.height = data.y * this.item_width;
			t.pivotX = t.width / 2;
			t.pivotY = t.height / 2;
			t.x += t.pivotX;
			t.y += t.pivotY;
			rect.width = t.width;
			rect.height = t.height;
			t.visible = true;
			let _item = t.getChildByName('item') as Laya.Image;
			let received = t.getChildByName('received') as Laya.Sprite;
			(received.getChildAt(0) as Laya.Sprite).pos(t.width / 2, t.height / 2);
			_item.skin = game.Tools.localUISrc('myres/activity_wajue/reward' + data.type + '.png');
			let bgs = t.getChildByName('bg') as Laya.Sprite;
			for (let i = 0; i < bgs.numChildren; i++) {
				let bg = bgs.getChildAt(i) as Laya.Image;
				bg.visible = Number(bg.name[0]) < data.x && Number(bg.name[1]) < data.y;
				bg.size(this.item_width + 1, this.item_width + 1);
			}
			_item.pos(t.width / 2, t.height / 2);
			_item.alpha = 1;
			received.visible = false;
			let info_btn = t.getChildByName('info_btn') as Laya.Button;
			info_btn.width = t.width;
			info_btn.height = t.height;
			info_btn.clickHandler = new Laya.Handler(this, () => {
				if (this.locking || this.animing || !info.received) {
					return;
				}
				let reward = common.ConfigHelper.configString2Array<number>(data.reward)[0][0];
				UI_ItemDetail.Inst.show(reward);
				
			});
			return t;
		}
	}
}