/**
* name 
*/
module uiscript {
    export class UI_Activity_Wajue_Task extends UI_ActivityBase {

        public static activity_id: number = 250701;
        public isLock: boolean;
        private root: Laya.Sprite;
        private head: Laya.Image;
        private task_templete: Laya.Sprite;
        private task_cells: Array<UI_Activity_TaskItem>;
        private scrollPanel: ScrollPanel;
        private head_height: number = 300;
        private lastShowTime: number = 0;
        private taskList: Array<Object> = [];

        public getId(): number {
			return UI_Activity_Wajue_Task.activity_id;
		}
       

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Wajue_Task.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_wajue_taskUI());
        }

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.scrollPanel = new ScrollPanel(this.root as Laya.Sprite);
            this.head = this.scrollPanel.content.getChildByName('head') as Laya.Image;
            this.task_templete = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.task_templete.visible = false;
            this.task_cells = [];
            for (let i: number = 0; i < 5; i++) {
                this.createTaskCell();
            }

            //设置头部图
            game.LoadMgr.setImgSkin(this.head, cfg.activity.activity_banner.get(this.getId()).banner_big);
            (this.head.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                UI_Activity.Inst.jumpToActivity({key: 'activity_id', value: UI_Activity_Wajue.activity_id});
            })
           
            
        }

        public isopen(): boolean {
            return UI_Activity.activity_is_running(this.getId());
        }

        public show() {
            this.enable = true;
            this.lastShowTime = Math.floor(game.Tools.getServerTime() / 1000);
            this.freshPage();

        }

        public hide() {
            this.enable = false;
        }

        public onEnable(): void {

        }

        public onDisable(): void {
        }

        public haveRedPoint(): boolean {
            return this.haveGetReward();
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(this.getId());
            if (d && d.need_popout) return true;
            return false;
        }

        private freshPage() {
            this.freshData();
            this.freshTaskList();
            this.scrollPanel.scrollValue = 0;
        }

        private freshData() {
            this.taskList = game.Tools.deepCopy(UI_Activity.getRandomTaskList(this.getId()));
            this.taskList = this.taskList.sort(this.sortTasks);
        }

        public isShowGetAll(): boolean {
            return this.haveGetReward();
        }

        public onClickGetAll() {
            if (this.isLock) {
                return;
            }
            //如果跨天了，则弹出提示
            if (!game.Tools.isPassedRefreshTimeServer(this.lastShowTime)) {
                this.onPassFreshTime();
                return;
            }
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = UI_Activity.getRandomTaskList(this.getId());
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }

            if (needGetList.length == 0) return;

            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeRandomActivityTaskBatch, { task_list: needGetList }, (err: game.IError, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    if (err && err.code == 2604) {
                        this.onPassFreshTime();
                    }
                    else {
                        UIMgr.Inst.showNetReqError(game.ERequest.completeRandomActivityTaskBatch, err, res);
                    }
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onRandomTaskRewarded(id);
                        let d_activity_task = UI_Activity.getRandomTaskConfig(id);

                        let rewardId = d_activity_task.reward_id;
                        let rewardCount = d_activity_task.reward_count;
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                        //刷新对应item的状态
                        let index = this.taskList.findIndex((item) => {
                            return item['id'] == id;
                        });
                        this.onClickGet(index);
                    }

                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                    UI_Activity.Inst.freshGetAllBtn();
                    UI_Activity.Inst.refresh_redpoint();
                    UI_Lobby.Inst.top.refreshRedpoint();
                }
            })
        }






        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            // 为每种情况分配权重
            const weightA = (a.achieved ? (a.rewarded ? 3 : 0) : 2);
            const weightB = (b.achieved ? (b.rewarded ? 3 : 0) : 2);

            // 首先比较权重
            if (weightA !== weightB) {
                return weightA - weightB;
            }

            // 如果权重相同，则按照 ID 升序排序
            return a.id - b.id;
        }

        private freshTaskList() {
            let h: number = this.head_height + 15;
            //如果cell不足，创建新的cell
            while (this.task_cells.length < this.taskList.length) {
                this.createTaskCell();
            }
            for (let i: number = 0; i < this.task_cells.length; i++) {
                let taskCell = this.task_cells[i];
                if (i < this.taskList.length) {
                    this.itemRender(i);
                    taskCell.me.y = h;
                    h += taskCell.me.height;
                    taskCell.visible = true;
                } else {
                    taskCell.me.visible = false;
                }
            }
            this.scrollPanel.contentHeight = h;

            this.scrollPanel.fresh();
        }



        private itemRender(index: number) {
            let taskCell = this.task_cells[index];
            let taskData = this.taskList[index] as game.ITaskProgress;
            let d_activity_task = UI_Activity.getRandomTaskConfig(taskData.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            //显示奖励信息
            let reward_id: number = d_activity_task.reward_id;
            let rewardCount: number = d_activity_task.reward_count;
            taskCell.itemId = reward_id;
            taskCell.itemCount = rewardCount;
            //显示任务描述
            taskCell.taskDesc = d_task_info['desc_' + GameMgr.client_language];
            //显示进度
            taskCell.taskProgressMax = d_task_info.target;
            taskCell.taskProgress = taskData.counter;
            taskCell.progressVisible = true;
            //显示按钮状态
            taskCell.getBtnVisible = !taskData.rewarded;
            taskCell.alreadyGetVisible = taskData.rewarded;
            taskCell.maskVisible = taskData.rewarded;
            taskCell.getBtnGray = !taskData.achieved;
            taskCell.getBtnEnable = taskData.achieved;
            taskCell.infoVisible = true;
            //领取按钮点击事件
            taskCell.getBtnClickHandler = Laya.Handler.create(this, () => {
                if (this.isLock) {
                    return;
                }
                if (!game.Tools.isPassedRefreshTimeServer(this.lastShowTime)) {
                    this.onPassFreshTime();
                    return;
                }
                this.isLock = true;
                taskCell.getBtnGray = true;
                taskCell.getBtnEnable = false;
                app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeRandomActivityTask, { task_id: taskData.id }, (err, res) => {
                    this.isLock = false;
                    if (err || res['error']) {
                        if (err && err.code == 2604) {
                            this.onPassFreshTime();
                        }
                        else {
                            UIMgr.Inst.showNetReqError(game.ERequest.completeRandomActivityTask, err, res);
                        }
                    } else {
                        this.onClickGet(index);
                        game.Tools.showRewards({ rewards: [{ id: reward_id, count: rewardCount }] }, null);
                        UI_Activity.onRandomTaskRewarded(taskData.id);
                        UI_Activity.Inst.freshGetAllBtn();
                        //刷新活动页面红点
                        UI_Activity.Inst.refresh_redpoint();
                        UI_Lobby.Inst.top.refreshRedpoint();
                    }
                });
            });
        }

        private createTaskCell(): UI_Activity_TaskItem {
            let taskCell = new UI_Activity_TaskItem(this.task_templete.scriptMap['capsui.UICopy']['getNodeClone']());
            taskCell.progressRemain = true;
            this.scrollPanel.content.addChild(taskCell.me);
            this.task_cells.push(taskCell);
            return taskCell;
        }

        private onPassFreshTime() {
            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(20211), true, Laya.Handler.create(this, () => {
                UI_Activity.Inst.refreshPage();
            }));
        }

        public haveGetReward(): boolean {
            let lst = UI_Activity.getRandomTaskList(this.getId());
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }


        /**
         * 如果点击了对应的任务，会调用这个函数去改变当前数据和UI展示
         * @param index 
         */
        private onClickGet(index: number) {
            let taskData = this.taskList[index] as game.ITaskProgress;
            taskData.rewarded = true;
            this.itemRender(index);

        }
    }
}