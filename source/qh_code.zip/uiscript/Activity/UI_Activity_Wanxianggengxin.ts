/**
* name 
*/
module uiscript{
	export class UI_Activity_Wanxianggengxin extends UI_ActivityBase {

		public static get activity_id():number { return 1078; }

		private btn:Laya.Button;
		private btn_info:Laya.Label;

		//左边标题的名称
		constructor() {
			let d = cfg.activity.activity.get(UI_Activity_Wanxianggengxin.activity_id);
			super(d['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_wanxianggengxinUI());
		}

		public onCreate() {
			this.btn = this.me.getChildByName('btn_get') as Laya.Button;
			this.btn_info = this.btn.getChildByName('info') as Laya.Label;
		}

		public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Wanxianggengxin.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Wanxianggengxin.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Wanxianggengxin.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;

			let infos = UI_Activity.getPeriodTaskList(UI_Activity_Wanxianggengxin.activity_id);
			this.btn.visible = false;
			if (!infos || infos.length <= 0) return;
			let info:any = infos[0];
			if (info.id != 1078001) return;

			let d_activity_task = cfg.activity.period_task.get(info.id);
			let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);

			this.btn.visible = true;
			if (info.rewarded) {
				this.btn.mouseEnabled = false;
				this.btn.skin = game.Tools.localUISrc('myres/wanxianggengxin/btn_gray.png');
				this.btn_info.text = game.Tools.strOfLocalization(2385);
				this.btn_info.color = '#565150';
			} else {
				if (info.achieved) {
					this.btn.mouseEnabled = true;
					this.btn.skin = game.Tools.localUISrc('myres/wanxianggengxin/btn.png');
					this.btn_info.text = game.Tools.strOfLocalization(2379);
					this.btn_info.color = '#565150';
					this.btn.clickHandler = Laya.Handler.create(this, ()=>{
						this.btn.mouseEnabled = false;
						app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', {task_id: info.id}, (err, res) => {
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
								this.btn.mouseEnabled = true;
							} else {
								this.btn.mouseEnabled = false;
								this.btn.skin = game.Tools.localUISrc('myres/wanxianggengxin/btn_gray.png');
								this.btn_info.text = game.Tools.strOfLocalization(2385);
								this.btn_info.color = '#565150';
								UI_Activity.onTaskRewarded(info.id);
								let reward_id:number = 0;
								let reward_count:number = 0;
								{
									let ss:Array<string> = d_activity_task.reward.split('-');
									reward_id = parseInt(ss[0]);
									reward_count = parseInt(ss[1]);
								}
								game.Tools.showRewards({rewards: [{id: reward_id, count: reward_count}]}, null);
							}
						});
					}, null, false);
				} else {
					this.btn.mouseEnabled = false;
					this.btn.skin = game.Tools.localUISrc('myres/wanxianggengxin/btn_gray.png');
					this.btn_info.text = game.Tools.strOfLocalization(2379);
					this.btn_info.color = '#565150';
				}
			}
        }

        public hide() {
            this.enable = false;
        }
	}
}