/**
* name 
*/
module uiscript{
	export class UI_Activity_Wuyi_Reward extends UI_Activity_Exchange {

        public static activity_id: number = 240503;
		public static readonly items: Array<number> = [30900025, 30900026, 30900027];
		private label_count_1:Laya.Label;
		private label_count_2:Laya.Label;
		private label_count_3: Laya.Label;
		private onItemChage: Laya.Handler;

		constructor() {
			super(cfg.activity.activity.get(UI_Activity_Wuyi_Reward.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_wuyi_exchangeUI());
		}

		public isopen():boolean {
			return UI_Activity.activities[UI_Activity_Wuyi_Reward.activity_id];
		}

		public onCreate() {
			super.onCreate();
			this.label_count_1 = this.head.getChildByName('count0') as Laya.Label;
			this.label_count_2 = this.head.getChildByName('count1') as Laya.Label;
			this.label_count_3 = this.head.getChildByName('count2') as Laya.Label;
			this.onItemChage = new Laya.Handler(this, () => { 
				this.refreshAll();
			})
			// if (GameMgr.client_language == 'jp') {
			// 	this.label_count_1.y -= 1;
			// 	this.label_count_2.y -= 1;
			// 	this.label_count_2.x += 3;
			// } else if (GameMgr.client_language == 'en') {
			// 	this.label_count_1.x += 10;
			// 	this.label_count_2.x += 10;
			// }
		}

		public refreshCurrencyCount() {
			this.label_count_1.text = UI_Bag.get_item_count(30900025).toString();
			this.label_count_2.text = UI_Bag.get_item_count(30900026).toString();
			this.label_count_3.text = UI_Bag.get_item_count(30900027).toString();
		}

		public show() {
			this.enable = true;
			game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/2405exchange.jpg');
			this.refreshView(UI_Activity.getExchangeList(UI_Activity_Wuyi_Reward.activity_id));
			//道具改变的时候添加监听
			for (let index = 0; index < UI_Activity_Wuyi_Reward.items.length; index++) {
				let itemId = UI_Activity_Wuyi_Reward.items[index];
				UI_Bag.add_item_listener(itemId, this.onItemChage);
				
			}

		}

		public hide() {
			//关闭页面后移除监听
			for (let index = 0; index < UI_Activity_Wuyi_Reward.items.length; index++) {
				let itemId = UI_Activity_Wuyi_Reward.items[index];
				UI_Bag.remove_item_listener(itemId, this.onItemChage);

			}
			this.enable = false;
		}

	}
}