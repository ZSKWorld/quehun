/**
* name 
*/
    module uiscript {
    export class UI_Activity_Wuyi_Task extends UI_Activity_Task {

        public static activity_id: number = 230901;

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Wuyi_Task.activity_id)['name_' + GameMgr.client_language]);
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres2/treasurehead/2309task.jpg`, 974, 326);
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Wuyi_Task.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getTaskList(UI_Activity_Wuyi_Task.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Wuyi_Task.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;
            this.refreshView(UI_Activity.getTaskList(UI_Activity_Wuyi_Task.activity_id));
        }

        public hide() {
            this.enable = false;
        }
    }
}