/**
* name 
*/
    module uiscript {
    export class UI_Activity_Wuyi_Task_Period extends UI_Activity_Task_Period {

        public static activity_id: number = 1248;

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Wuyi_Task_Period.activity_id)['name_' + GameMgr.client_language]);
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres2/treasurehead/xiyuliuguang_reward.jpg`, 974, 326);
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Wuyi_Task_Period.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Wuyi_Task_Period.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Wuyi_Task_Period.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;
            this.refreshView(UI_Activity.getPeriodTaskList(UI_Activity_Wuyi_Task_Period.activity_id));
        }

        public hide() {
            this.enable = false;
        }
    }
}