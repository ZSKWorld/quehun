/**
* name 
*/
    module uiscript {
    export class UI_Activity_Wuyi_Task_Random extends UI_Activity_Task_Random {

        public static activity_id: number = 1247;

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Wuyi_Task_Random.activity_id)['name_' + GameMgr.client_language]);
        }

        public onCreate() {
            super.onCreate();
            this.setHead(`myres2/treasurehead/xiyuliuguang_task.jpg`, 974, 326);
        }

        public isopen(): boolean {
            return UI_Activity.activities[UI_Activity_Wuyi_Task_Random.activity_id];
        }

        public haveRedPoint(): boolean {
            let lst = UI_Activity.getRandomTaskList(UI_Activity_Wuyi_Task_Random.activity_id);
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(UI_Activity_Wuyi_Task_Random.activity_id);
            if (d && d.need_popout) return true;
            return false;
        }

        public show() {
            this.enable = true;
            this.refreshView(UI_Activity.getRandomTaskList(UI_Activity_Wuyi_Task_Random.activity_id));
        }

        public hide() {
            this.enable = false;
        }
    }
}