/**
* name 
*/
module uiscript{
	export class UI_Activity_XiaRi_Exchange extends UI_Activity_Exchange {

        public static activity_id: number = 1097;

        private label_count:Laya.Label;
        private btn_parent:Laya.Sprite;
        private locking:boolean;
		constructor() {
			super(cfg.activity.activity.get(UI_Activity_XiaRi_Exchange.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_xiari_exchangeUI());
		}

		public isopen():boolean {
			return UI_Activity.activities[UI_Activity_XiaRi_Exchange.activity_id];
		}

		public onCreate() {
			super.onCreate();
            this.label_count = this.head.getChildByName('count0') as Laya.Label;
            (this.head.getChildByName('info') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3200));
                UI_Activity.Inst.jumpToActivity({key:'activity_id', value: UI_Activity_Yijidagong.activity_id});
            });
            
            (this.head.getChildByName('exchange2') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                if (UI_Bag.get_item_count(309029) < 12) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217));
                    return;
                }
                this.locking = true;
                
                app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', {exchange_id: 1097001}, (err, res) => {
                    this.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
                    } else {
                        this.refreshCurrencyCount();
                        this.refreshButtonShow();
                        UI_Get_Character.Inst.show(200015);
                        this.refreshAll();
                    }
                });
            });
            (this.head.getChildByName('exchange1') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                if (UI_Bag.get_item_count(309029) < 12) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217));
                    return;
                }
                this.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', {exchange_id: 1097002}, (err, res) => {
                    this.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
                    } else {
                        this.refreshCurrencyCount();
                        this.refreshButtonShow();
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(3216));
                        this.refreshAll();
                    }
                });
            });
			if (GameMgr.client_language == 'en') {
				this.label_count.x = 708;
			}
		}

		public refreshCurrencyCount() {
			this.label_count.text = UI_Bag.get_item_count(309029).toString();
		}

		public show() {
			this.enable = true;
            game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/activity_xiari_exchange.jpg');
            let list = UI_Activity.getExchangeList(UI_Activity_XiaRi_Exchange.activity_id);
            let showList = [];
            for(let data of list) {
                if (data['exchange_id'] != 1097001 && data['exchange_id'] != 1097002) {
                    showList.push(data);
                }
            }
            this.refreshView(showList);
            this.refreshButtonShow();
		}

		public hide() {
			this.enable = false;
        }
        
        public refreshButtonShow() {
            let char_owned:boolean = UI_Sushe.chara_owned(200015);
            (this.head.getChildByName('exchange2') as Laya.Sprite).visible = !char_owned;
            (this.head.getChildByName('exchanged2') as Laya.Sprite).visible = char_owned;

            let skin_owned:boolean = UI_Sushe.skin_owned(401503);
            (this.head.getChildByName('exchange1') as Laya.Sprite).visible = !skin_owned;
            (this.head.getChildByName('exchanged1') as Laya.Sprite).visible = skin_owned;
        }
	}
}