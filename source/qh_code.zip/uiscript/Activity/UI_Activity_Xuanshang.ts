
module uiscript {


	/**
	 * 每日悬赏任务
	 */
	export class UI_Activity_Xuanshang extends UI_ActivityBase {

		public static Inst:UI_Activity_Xuanshang;
		public static refresh_count:number = 0;
		public static datas:Array<{id:number, counter:number, achieved:boolean}> = [];
		public static max_daily_task_count:number = 0;

		public static Init() {
			this.fetchData();
			app.NetAgent.addListener2Lobby('NotifyDailyTaskUpdate', Laya.Handler.create(this, msg=>{
				this.refresh_count = msg['refresh_count'];
				this.datas = msg['progresses'];
				this.max_daily_task_count = msg['max_daily_task_count'];
				if (this.Inst && this.Inst.enable) {
					this.Inst.refresh();
				}
			}, null, false));
		}
		public static fetchData() {
			app.NetAgent.sendReq2Lobby('Lobby', 'fetchDailyTask', {}, (err, res)=>{
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError('fetchDailyTask', err, res);
				} else {
					this.refresh_count = res['refresh_count'];
					this.datas = res['progresses'];
					this.max_daily_task_count = res['max_daily_task_count'];
				}
			});
		}
		public static dataUpdate(msg) {
			for (let i:number = 0; i < msg['progresses'].length; i++) {
				let __msg = msg['progresses'][i];
				for (let j:number = 0; j < this.datas.length; j++) {
					if (this.datas[j].achieved) continue;
					if (this.datas[j].id == __msg.id) {
						if (__msg.achieved != null && __msg.achieved != undefined) {
							this.datas[j].achieved = __msg.achieved;
						}
						if (__msg.counter != null && __msg.counter != undefined) {
							this.datas[j].counter = __msg.counter;
						}
						break;
					}
				}
			}
		}

		private root:Laya.Sprite;
		private scrollview:capsui.CScrollView;
		private btn_cd:number = 0;
		private timerefresh:Laya.Label;
		private icon_time: Laya.Image;
		private content: Laya.Sprite;
		private scrollBar: Laya.Sprite;
		private empty: Laya.Sprite;
		private timeIconAdapter: common.SpriteAdapter;
		private tips:Laya.Label;
		public getId(): number {
			return 1;
		}

		constructor() {
			super(game.Tools.strOfLocalization(2235), new ui.lobby.activitys.activity_xuanshangUI());
		}
		
		public isopen():boolean {return true;}

		public onCreate() {
			this.root = this.me.getChildByName("root") as Laya.Sprite;
			this.timerefresh = this.root.getChildByName('nochange') as Laya.Label;
			this.icon_time = this.root.getChildByName('icon_time') as Laya.Image;
			this.scrollview = this.root.scriptMap['capsui.CScrollView'];
			this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
			this.scrollview.reset();
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
				(this.root.getChildAt(0) as Laya.Label).fontSize = 30;
				this.timerefresh.fontSize = 30;
			}
			this.timeIconAdapter = new common.SpriteAdapter(this.icon_time, this.timerefresh, SpriteAdapterType.RIGHT2LEFT, 4);
			this.content = this.root.getChildByName('content') as Laya.Sprite;
			this.scrollBar = this.root.getChildByName('scrollbar') as Laya.Sprite;
			this.empty = this.root.getChildByName('empty') as Laya.Sprite;
			this.tips = this.root.getChildByName('tip') as Laya.Label;

		}

		public show() {
			this.enable = true;
			this.btn_cd = 0;
			this.refresh();
		}

		private getLocalTime() {
			let t = game.Tools.getServerTime();
			t = Math.ceil(t / 1000);
			t += 3 * 3600;
			t = t % (24 * 3600);
			t = 24 * 3600 - t;
			if (t < 3600) {
				t = Math.ceil(t / 60);
				return game.Tools.strOfLocalization(2674,[t.toString()])+game.Tools.strOfLocalization(2748);
			} else {
				t = Math.ceil(t / 3600);
				return game.Tools.strOfLocalization(2674,[t.toString()])+game.Tools.strOfLocalization(2747);
			}
		}

		public hide() {
			this.enable = false;
		}

		public refresh() {
			
			this.tips.text = game.Tools.strOfLocalization((UI_Activity_Yueka.GetYuekaLeftDays() >= 0) ? 3978 : 3977);
			this.timerefresh.text = this.getLocalTime();
			this.timeIconAdapter.fresh();

			let isAllAchieved:boolean = this.isAllAchieved();
			this.scrollBar.visible = !isAllAchieved;
			this.empty.visible = isAllAchieved;
			this.content.visible = !isAllAchieved;
			if (UI_Activity_Xuanshang.datas.length != 0) {
				this.scrollview.reset();
				let count: number = UI_Activity_Xuanshang.max_daily_task_count;
				if (count < UI_Activity_Xuanshang.datas.length) {
					count = UI_Activity_Xuanshang.datas.length;
				}
				this.scrollview.addItem(count);
			}

		}

		private isAllAchieved():boolean {
			for (let i:number = 0; i < UI_Activity_Xuanshang.datas.length; i++) {
				if (!UI_Activity_Xuanshang.datas[i].achieved) {
					return false;
				}
			}
			return true;
		}

		public render_item(data) {
			let index:number = data.index;
			let container: Laya.Sprite = data.container;
			let taskItem = data.cacheData as UI_Activity_TaskItem;
			if (!taskItem) {
				taskItem = new UI_Activity_TaskItem(container);
				taskItem.progressRemain = true;
				data.cacheData = taskItem;
			}
			if (index < UI_Activity_Xuanshang.datas.length) {
				let info = UI_Activity_Xuanshang.datas[index];
				let d = cfg.events.dailyevent.get(info.id);
				if (info.achieved || !d) {
					taskItem.infoVisible = false;
					taskItem.empty = true;
					// container_info.visible = false;
					// bg_no.visible = true;
					// bg.visible = false;
				} else {
					taskItem.infoVisible = true;
					taskItem.empty = false;
					//如果可刷新次数大于0，则显示更换按钮
					taskItem.getBtnVisible = UI_Activity_Xuanshang.refresh_count > 0;
					taskItem.taskDesc = d['desc_' + GameMgr.client_language];
					taskItem.itemId = d.reward_type;
					taskItem.itemCount = d.reward_num;
					taskItem.progressVisible = true;
					taskItem.taskProgressMax = d.target;
					taskItem.taskProgress = info.counter;
					taskItem.getBtnClickHandler = new Laya.Handler(this, () => {
						if (this.btn_cd > Laya.timer.currTimer) return;
						this.btn_cd = 1000 + Laya.timer.currTimer;
						app.NetAgent.sendReq2Lobby('Lobby', 'refreshDailyTask', { task_id: info.id }, (err, res) => {
							this.btn_cd = 0;
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('refreshDailyTask', err, res);
							} else {
								UI_Activity_Xuanshang.refresh_count = res['refresh_count'];
								UI_Activity_Xuanshang.datas[index] = res['progress'];
								let dd = [];
								for (let j: number = 0; j < UI_Activity_Xuanshang.datas.length; j++) {
									if (!UI_Activity_Xuanshang.datas[j].achieved) {
										dd.push(UI_Activity_Xuanshang.datas[j]);
									}
								}
								UI_Activity_Xuanshang.datas = dd;
								this.scrollview.wantToRefreshAll();
							}
						});
					});
				}

					
			} else {
				//任务已经完成
				taskItem.infoVisible = false;
				taskItem.empty = true;
			}
		}

	}
}