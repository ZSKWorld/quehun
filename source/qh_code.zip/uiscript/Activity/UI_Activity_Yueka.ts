
module uiscript {
	/**
	 * 月卡活动
	 */
	export class UI_Activity_Yueka extends UI_ActivityBase {

		public static yueka_data: { last_pay_time: number, end_time: number } = null; // id-{id:number, last_pay_time:number, end_time:number}
		private static yueka_ui: UI_Activity_Yueka = null; // id-ui，储存不同月卡的ui界面，用来刷新用
		private static jump_id: string = 'yueka'; // 跳转使用
		public getId(): number {
			return 4;
		}

		public static Init() {
			app.NetAgent.sendReq2Lobby('Lobby', 'fetchMonthTicketInfo', {}, (err, res) => {
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError('fetchMonthTicketInfo', err, res);
				} else {
					if (res['month_ticket_info']) {
						this.yueka_data = res['month_ticket_info'];
					}
				}
			});
		}

		public static onFetchSuccess(res: any) {
			if (res['month_ticket_info'] && res['month_ticket_info']['month_ticket_info']) {
				this.yueka_data = res['month_ticket_info']['month_ticket_info'];
			}
		}

		// 获得月卡数据
		public static GetYuekaData() {
			return this.yueka_data;
		}

		// 获得月卡剩余时间，0=明天5点过期，-1=没有月卡
		public static GetYuekaLeftDays(): number {
			let d = this.yueka_data;
			if (!d) return -1;
			if (d.end_time < game.Tools.getServerTime() / 1000) return -2;
			return Math.floor((d.end_time - game.Tools.getServerTime() / 1000) / 24 / 3600);
		}

		// 购买新月卡时刷新本地数据
		public static OnBuyedYueka() {
			if (this.yueka_ui && this.yueka_ui.enable) {
				this.yueka_ui.refresh();
			}
		}

		// 更新数据
		public static updateData(data: { last_pay_time: number, end_time: number }) {
			this.yueka_data = data;
			if (this.yueka_ui && this.yueka_ui.enable) {
				this.yueka_ui.refresh();
			}
		}
		// 某个id的月卡是否现在可以领取
		public static YuekaCanGet() {
			let data = this.GetYuekaData();
			if (!data) return false;
			if (this.GetYuekaLeftDays() < 0) return false;
			return !game.Tools.isPassedRefreshTimeServer(data['last_pay_time']);
		}

		public static get need_pop_yueka(): boolean {

			return false;
		}
		private yueka_id: number = 1010;

		private container_buy: Laya.Sprite;
		private container_get: Laya.Sprite;
		private btn_get: Laya.Button;
		private img_getted: Laya.Image;
		private label_days: Laya.Label;
		private timeTip: Laya.Sprite;
		private clockShakeAnim: Laya.FrameAnimation;
		private tipWidthAdapter: common.SpriteAdapter;

		//左边标题的名称
		constructor() {
			//如果是en或者kr的繁体的话，使用文字是繁体，价格标签是美元的en界面
			super(game.Tools.strOfLocalization(2839), ((GameMgr.client_type == 'en' || GameMgr.client_type == 'kr') && GameMgr.client_language == 'chs_t') ? new ui.lobby.activitys.activity_yueka_enUI() : new ui.lobby.activitys.activity_yuekaUI());
			if (GameMgr.client_type == 'chs' || GameMgr.client_type == 'chs_t') this.yueka_id = 1010;
			else if (GameMgr.client_type == 'jp') this.yueka_id = 2010;
			else if (GameMgr.client_type == 'en') this.yueka_id = 3010;
			else if (GameMgr.client_type == 'kr') this.yueka_id = 5010;
			UI_Activity_Yueka.yueka_ui = this;
		}

		//活动是否开放中，不开放的活动不会显示
		public isopen(): boolean {
			if (game.Tools.CannotPay()) return false;
			return true;
		}

		//活动是否要显示小红点
		public haveRedPoint(): boolean {
			let s: string = Laya.LocalStorage.getItem(game.Tools.eeesss('yueka_' + GameMgr.Inst.account_id));
			if (s != '1') return true;
			return UI_Activity_Yueka.YuekaCanGet();
		}

		public get can_popout_yueka(): boolean {
			return UI_Activity_Yueka.YuekaCanGet();
		}
		//活动是否要弹出来
		public need_popout(): boolean { return false; }

		public onCreate() {
			this.container_buy = this.me.getChildByName('container_buy') as Laya.Sprite;
			(this.container_buy.getChildByName('btn_buy') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				// if ( GameMgr.client_type == 'kr' && !app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.Recharge_Xieyi_Checked)) {

				// 	UI_User_Xieyi_Recharge.Inst.show(Laya.Handler.create(this, ()=>{
				// 		UI_Recharge.on_want_2_buy(this.yueka_id);
				// 	}));
				// 	return;
				// }
				UI_Recharge.on_want_2_buy(this.yueka_id);
			});
			if (GameMgr.inDmm) {
				game.LoadMgr.setImgSkin(this.container_buy.getChildByName('img_price') as Laya.Image, 'myres/yueka/price_dmm.png');
			}

			this.container_get = this.me.getChildByName('container_get') as Laya.Sprite;
			this.btn_get = this.container_get.getChildByName('btn_get') as Laya.Button;
			this.btn_get.clickHandler = new Laya.Handler(this, () => {
				this.btn_get.mouseEnabled = false;
				app.NetAgent.sendReq2Lobby('Lobby', 'payMonthTicket', {}, (err, res) => {
					this.btn_get.mouseEnabled = true;
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('payMonthTicket', err, res);
					} else {
						game.Tools.showRewards({ rewards: [{ id: res['resource_id'], count: res['resource_count'] }] }, null);
						UI_Activity_Yueka.yueka_data.last_pay_time = game.Tools.getServerTime() / 1000;
						if (this.enable) {
							this.refresh();
						}
					}
				});
			});
			this.img_getted = this.container_get.getChildByName('getted') as Laya.Image;
			this.label_days = this.container_get.getChildByName('left_day') as Laya.Label;

			if (GameMgr.client_type == 'kr') {
				game.LoadMgr.setImgSkin(this.container_buy.getChildByName('img_price') as Laya.Image, 'myres/yueka_kr/price.png');
				game.LoadMgr.setImgSkin(this.me.getChildAt(0) as Laya.Image, 'myres/yueka_kr/bg_yueka.jpg');
				this.label_days.scale(0.75, 0.75);
			} else if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
				game.LoadMgr.setImgSkin(this.me.getChildAt(0) as Laya.Image, 'myres/yueka_en/bg_yueka.jpg');
			} else {
				game.LoadMgr.setImgSkin(this.me.getChildAt(0) as Laya.Image, 'myres/yueka/bg_yueka.jpg');
			}
			this.timeTip = this.me.getChildByName('time_tip') as Laya.Sprite;
			let timeTipText = this.timeTip.getChildByName('day') as Laya.Label;
			let timeTipBg = this.timeTip.getChildByName('bg') as Laya.Image;
			this.tipWidthAdapter = new common.SpriteAdapter(timeTipBg, timeTipText, SpriteAdapterType.WIDTH2WIDTH, -190);
			this.tipWidthAdapter.fresh();

			//如果是繁体，en,kr的话是英文界面
			if (GameMgr.client_language == 'chs_t' || GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
				this.clockShakeAnim = (this.me as ui.lobby.activitys.activity_yueka_enUI).clock_shake;
			}
			else {
				this.clockShakeAnim = (this.me as ui.lobby.activitys.activity_yuekaUI).clock_shake;
			}

		}

		public show() {
			Laya.LocalStorage.setItem(game.Tools.eeesss('yueka_' + GameMgr.Inst.account_id), '1');
			this.clockShakeAnim.play(0, false);
			this.enable = true;
			this.refresh();
			this.btn_get.mouseEnabled = true;
		}

		private leftX: number = 398;
		private rightX: number = 769;
		private centerX: number = 600;
		public refresh() {
			let data = UI_Activity_Yueka.GetYuekaData();
			if (UI_Recharge.is_payment_open()) {
				//当前开放充值，有购买有领取
				this.container_buy.visible = true;
				this.container_get.x = this.rightX;
			} else {
				//当前未开放充值，有领取无购买
				this.container_buy.visible = false;
				this.container_get.x = this.centerX;
			}
			if (data && game.Tools.getServerTime() / 1000 < data.end_time) {
				this.container_get.visible = true;
				this.container_buy.x = this.leftX;

				if (!game.Tools.isPassedRefreshTimeServer(data.last_pay_time)) {
					this.btn_get.visible = true;
					this.img_getted.visible = false;
				} else {
					this.btn_get.visible = false;
					this.img_getted.visible = true;
				}
				let cardLastDay = Math.floor((data.end_time - game.Tools.getServerTime() / 1000) / 24 / 3600);
				this.label_days.text = cardLastDay.toString();
				this.label_days.color = cardLastDay > 3 ? '#fec64f' : '#ff554C';
				this.timeTip.visible = cardLastDay <= 3;

			} else {
				this.container_buy.x = this.centerX;
				this.container_get.visible = false;
				this.timeTip.visible = false;
			}

			// if (GameMgr.client_language == 'chs' || GameMgr.client_language == 'chs_t') {
			// 	this.label_days.x = 96;
			// } else if (GameMgr.client_language == 'en') {
			// 	this.label_days.x = -8;
			// } else if (GameMgr.client_language == 'kr') {
			// 	this.label_days.x = 152;
			// } else if (GameMgr.client_language == 'jp') {
			// 	this.label_days.x = 108;
			// }
			if (GameMgr.client_language == 'kr') {
				this.label_days.x = 200;
			} else if (GameMgr.client_language == 'en') {
				this.label_days.x = 40;
			}
			UI_Activity.Inst.refresh_redpoint();
			UI_Lobby.Inst.top.refreshRedpoint();
		}

		public hide() {
			this.clockShakeAnim.gotoAndStop(0);
			this.enable = false;
		}

		public onDisable(): void {
			let atlas_root = 'res/atlas/';
			if (GameMgr.client_language != 'chs') {
				atlas_root += GameMgr.client_language + '/';
			}
			Laya.loader.clearTextureRes(atlas_root + 'myres/yueka.atlas');
		}

		public getLastTime(): number {
			let data = UI_Activity_Yueka.GetYuekaData();
			if (data) {
				return data.end_time - game.Tools.getServerTime() / 1000;
			}
			else {
				return -1;
			}

		}
	}
}