/**
* 月卡自动领取
*/
module uiscript {
    export class UI_Activity_Yueka_Auto extends UIBase {
        public static Inst: UI_Activity_Yueka_Auto = null;


        private time: Laya.Sprite;
        private label_time: Laya.Label;
        private timeTip: Laya.Sprite;
        private tipText1: Laya.Label;
        private tipLabel: Laya.Label;
        private tipText2: Laya.Label;
        private root: Laya.Sprite;
        private effect: game.UIEffect;
        private anim: Catfood.CAnimator;
        private complete: Laya.Handler;
        

        private locking: boolean;
        private waiting_handler: Laya.Handler;

        constructor() {
            super(new ui.lobby.activitys.activity_yueka_autoUI());
            UI_Activity_Yueka_Auto.Inst = this;
        }

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.timeTip = this.me.getChildByName('time_tip') as Laya.Sprite;
            this.tipText1 = this.timeTip.getChildByName('text1') as Laya.Label;
            this.tipLabel = this.timeTip.getChildByName('day') as Laya.Label;
            this.tipText2 = this.timeTip.getChildByName('text2') as Laya.Label;
            this.time = this.me.getChildByName('time') as Laya.Sprite;
            this.label_time = this.time.getChildByName('time') as Laya.Label;
            if (GameMgr.client_language == 'kr') {
                this.label_time.x = 328;
                (this.me.getChildByName('time').getChildByName('left') as Laya.Label).x -= 20;
            } else if (GameMgr.client_language == 'en') {
                let left = this.me.getChildByName('time').getChildByName('left') as Laya.Label;
                left.fontSize = 25;
                this.label_time.fontSize = 28;
                this.label_time.x = 300;
                left.x -= 20;
            }

            // (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
            //     if (this.locking) return;
            //     this.locking = true;
            //     app.NetAgent.sendReq2Lobby('Lobby', 'payMonthTicket', {}, (err, res) => {

            // 		if (err || res['error']) {
            //             this.locking = false;
            // 			UIMgr.Inst.showNetReqError('payMonthTicket', err, res);
            //             this.close();
            // 		} else {

            // 			UI_Activity_Yueka.yueka_data.last_pay_time = game.Tools.getServerTime() / 1000;
            //             if (this.anim) {
            //                 this.anim.Play('fx_ui_yueshiyushou_02');
            //                 (game.Tools.GetNodeByNameInChildren(this.effect.effect.root, '03') as Laya.Sprite3D).active = true;
            //             }
            //             (this.me as ui.lobby.activitys.activity_yueka_autoUI).show.stop();
            // 			(this.me as ui.lobby.activitys.activity_yueka_autoUI).close.play(0, false);
            //             Laya.timer.once(1100, this, ()=>{
            //                 game.Tools.showRewards({rewards: [{id: res['resource_id'], count: res['resource_count']}]}, null);
            //                 this.close();
            //             });
            // 		}
            // 	});
            // });
        }

        public show(complete?: Laya.Handler) {
            let data = UI_Activity_Yueka.GetYuekaData();
            if (!data) {
                complete && complete.run();
                return;
            }
            this.locking = true;
            this.waiting_handler = null;
            //进入后1.8s才允许播领取成功
            Laya.timer.once(1800, this, () => {
                this.locking = false;
                if (this.waiting_handler) {
                    this.waiting_handler.run();
                    this.waiting_handler = null;
                }
            });
            this.effect = game.FrontEffect.Inst.create_ui_effect(this.root, 'scene/effect_yueshiyushou.lh', new Laya.Point(0, 0), 0.92);
            this.effect.effect.addLoadedListener(Laya.Handler.create(this, () => {
                this.anim = (this.effect.effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                this.anim.Play('fx_ui_yueshiyushou_01');
            }));
            this.enable = true;
            (this.me as ui.lobby.activitys.activity_yueka_autoUI).show.play(0, false);
            (this.me as ui.lobby.activitys.activity_yueka_autoUI).rot.play(0, true);
            view.AudioMgr.PlayAudio(148);
            let lastTime = Math.floor((data.end_time - game.Tools.getServerTime() / 1000) / 24 / 3600);
            this.label_time.text = lastTime + game.Tools.strOfLocalization(4033);
            this.tipLabel.text = lastTime.toString();
            this.label_time.visible = lastTime > 3;
            this.timeTip.visible = lastTime <= 3;
            //播放提示音效
            if (lastTime<=3) {
                view.AudioMgr.PlayAudio(149);
            }
            this.complete = complete;
            // return;
            //自动领取
            app.NetAgent.sendReq2Lobby('Lobby', 'payMonthTicket', {}, (err, res) => {
                this.waiting_handler = Laya.Handler.create(this, () => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('payMonthTicket', err, res);
                        this.close();
                    } 
                    else 
                    {
                        UI_Activity_Yueka.yueka_data.last_pay_time = game.Tools.getServerTime() / 1000;
                        if (this.anim) {
                            this.anim.Play('fx_ui_yueshiyushou_02');
                            (game.Tools.GetNodeByNameInChildren(this.effect.effect.root, '03') as Laya.Sprite3D).active = true;
                        }
                        view.AudioMgr.PlayAudio(150);
                        (this.me as ui.lobby.activitys.activity_yueka_autoUI).show.stop();
                        (this.me as ui.lobby.activitys.activity_yueka_autoUI).close.play(0, false);
                        Laya.timer.once(1100, this, () => {
                            game.Tools.showRewards({ rewards: [{ id: res['resource_id'], count: res['resource_count'] }] }, null);
                            this.close();
                        });
                    }
                });
                if (!this.locking) {
                    
                    Laya.timer.clearAll(this);
                    this.waiting_handler.run();
                    this.waiting_handler = null;

                }
            });
        }

        public close() {
            if (this.anim) { this.anim.Stop(); this.anim = null };
            if (this.effect) { this.effect.destory(); this.effect = null; }
            this.enable = false;
            this.locking = false;
            this.complete && this.complete.run();
        }

        public test() {
            (this.me as ui.lobby.activitys.activity_yueka_autoUI).show.stop();
            if (this.anim) {
                this.anim.Play('fx_ui_yueshiyushou_02');
                (game.Tools.GetNodeByNameInChildren(this.effect.effect.root, '03') as Laya.Sprite3D).active = true;
            }
            (this.me as ui.lobby.activitys.activity_yueka_autoUI).close.play(0, false);
            Laya.timer.once(1300, this, () => {
                this.close();
            });
        }
    }
}