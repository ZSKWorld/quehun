/**
* name 
*/
module uiscript{
	export class UI_Christmas_Exchange extends UI_Activity_Exchange {

		private label_count_bell:Laya.Label;
		private label_count_socks:Laya.Label;

		constructor() {
			super(cfg.activity.activity.get(1002)['name'], new ui.lobby.activitys.activity_exchangeUI());
		}

		public isopen():boolean {
			return UI_Activity.activities[1002];
		}

		public onCreate() {
			super.onCreate();
			this.label_count_bell = this.head.getChildByName('count0') as Laya.Label;
			this.label_count_socks = this.head.getChildByName('count1') as Laya.Label;
		}

		public refreshCurrencyCount() {
			this.label_count_bell.text = UI_Bag.get_item_count(309001).toString();
			this.label_count_socks.text = UI_Bag.get_item_count(309002).toString();
		}

		public show() {
			this.enable = true;
			game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/christmas_reward.jpg');
			this.refreshView(UI_Activity.getExchangeList(1002));
		}

		public hide() {
			this.enable = false;
		}

	}
}