/**
* name 
*/
module uiscript{
	export class UI_Christmas_Task extends UI_Activity_Task {

		public static activity_id:number = 1001;

		constructor() {
			super(cfg.activity.activity.get(UI_Christmas_Task.activity_id)['name']);
		}

		public onCreate() {
			super.onCreate();
			this.setHead('myres2/treasurehead/christmas_task.jpg', 974, 326);
		}

		public isopen():boolean {
			return UI_Activity.activities[UI_Christmas_Task.activity_id];
		}

		public haveRedPoint():boolean {
			let lst = UI_Activity.getTaskList(UI_Christmas_Task.activity_id);
			if (lst) {
				for (let i:number = 0; i < lst.length; i++) {
					if (!lst[i]['rewarded'] && lst[i]['achieved']) {
						return true;
					}
				}
			}
			return false;
		}

		public need_popout():boolean {
			let d = cfg.activity.activity.get(UI_Christmas_Task.activity_id);
			if (d && d.need_popout) return true;
			return false;
		}

		public show() {
			this.enable = true;
			this.refreshView(UI_Activity.getTaskList(UI_Christmas_Task.activity_id));
		}

		public hide() {
			this.enable = false;
		}
	}
}