/**
* name 
*/
module uiscript{
	export class UI_Exchange_CJ2020 extends UI_Activity_Exchange {

        public static activity_id: number = 1035;

		private label_count0:Laya.Label;

		constructor() {
			super(cfg.activity.activity.get(UI_Exchange_CJ2020.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_tongbi_exchangeUI());
		}

		public isopen():boolean {
			return UI_Activity.activities[UI_Exchange_CJ2020.activity_id];
		}

		public onCreate() {
			super.onCreate();
			this.label_count0 = this.head.getChildByName('count0') as Laya.Label;
		}

		public refreshCurrencyCount() {
			this.label_count0.text = game.Tools.money2Desc(UI_Bag.get_item_count(309005));
		}

		public show() {
			this.enable = true;
			game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/activity_cj2020_exchange.jpg', null, 'UI_Exchange_CJ2020');
			this.refreshView(UI_Activity.getExchangeList(UI_Exchange_CJ2020.activity_id));
		}

		public hide() {
			this.enable = false;
		}

		public onEnable() {
			super.onEnable();
			game.TempImageMgr.setUIEnable('UI_Exchange_CJ2020', true);
		}

		public onDisable() {
			super.onDisable();
			game.TempImageMgr.setUIEnable('UI_Exchange_CJ2020', false);
		}

	}
}