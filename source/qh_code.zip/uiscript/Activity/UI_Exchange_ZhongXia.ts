module uiscript{
	export class UI_Exchange_ZhongXia extends UI_Activity_Exchange {

        public static activity_id: number = 250302;

		private label_count_1:Laya.Label;
		private label_count_2:Laya.Label;
		private label_count_3:Laya.Label;
		private label_icon_1:Laya.Image;
		private label_icon_2:Laya.Image;
		private label_icon_3:Laya.Image;

		constructor() {
			super(cfg.activity.activity.get(UI_Exchange_ZhongXia.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_exchange_zhongxiaUI());
		}

		public getId(): number {
			return UI_Exchange_ZhongXia.activity_id;
		}

		public isopen():boolean {
			return !!UI_Activity.activities[UI_Exchange_ZhongXia.activity_id];
		}

		public onCreate() {
			super.onCreate();
			//替换item的刷新方法
			this.cells.forEach(v => v.refresh = this.cellRefresh);

			this.label_count_1 = this.head.getChildByName('count0') as Laya.Label;
			this.label_count_2 = this.head.getChildByName('count1') as Laya.Label;
			this.label_count_3 = this.head.getChildByName('count2') as Laya.Label;
		
			this.label_icon_1 = this.head.getChildByName('icon0') as Laya.Image;
			this.label_icon_2 = this.head.getChildByName('icon1') as Laya.Image;
			this.label_icon_3 = this.head.getChildByName('icon2') as Laya.Image;

			this.label_icon_1.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[0]]);
			this.label_icon_2.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[1]]);
			this.label_icon_3.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[2]]);
		}

		public refreshCurrencyCount() {
			this.label_count_1.text = UI_Bag.get_item_count(30900086).toString();
			this.label_count_2.text = UI_Bag.get_item_count(30900087).toString();
			this.label_count_3.text = UI_Bag.get_item_count(30900088).toString();
		}

		public show() {
			this.enable = true;
			game.LoadMgr.setImgSkin(this.head, cfg.activity.activity_banner.get(this.getId()).banner_big);
			game.LoadMgr.setImgSkin(this.label_icon_1, cfg.item_definition.item.get(UI_Task_ZhongXia.items[0]).icon);
			game.LoadMgr.setImgSkin(this.label_icon_2, cfg.item_definition.item.get(UI_Task_ZhongXia.items[1]).icon);
			game.LoadMgr.setImgSkin(this.label_icon_3, cfg.item_definition.item.get(UI_Task_ZhongXia.items[2]).icon);
			this.refreshView();
		}

		public hide() {
			this.enable = false;
		}

		protected refreshView() {
			const data = UI_Activity.getExchangeList(UI_Exchange_ZhongXia.activity_id);
			data.sort((a, b) => {
				const tableA = cfg.activity.exchange.get(a.exchange_id);
				const tableB = cfg.activity.exchange.get(b.exchange_id);
				const exchangeOverA = tableA.exchange_limit - a.count <= 0;
				const exchangeOverB = tableB.exchange_limit - b.count <= 0;
				if (exchangeOverA == exchangeOverB) return a.exchange_id - b.exchange_id;
				else {
					if (exchangeOverA) return 1;
					else return -1;
				}
			});
			this.content.vScrollBar.value = 0;
			super.refreshView(data);
		}

		private cellRefresh() {
			const that = this as any as Cell & { container_count: Laya.Sprite, img_mask: Laya.Image };
			if (!that.container_count) {
				that.container_count = that.container_info.getChildByName('count') as Laya.Sprite;
				that.img_mask = that.me.getChildByName('black_mask') as Laya.Image;
			}
			let id = that.id;
			let d_activity_exchange = cfg.activity.exchange.get(id);

			that.container_info.visible = true;

			that.item_count.text = ' x ' + d_activity_exchange.reward_count;
			let d_currency = cfg.item_definition.currency.get(d_activity_exchange.reward_id);
			if (d_currency) {
				game.LoadMgr.setImgSkin(that.item_icon, d_currency.icon_jpg);
				that.item_name.text = d_currency['name_' + GameMgr.client_language];
			}
			
			let d_item = cfg.item_definition.item.get(d_activity_exchange.reward_id);
			if (d_item) {
				game.LoadMgr.setImgSkin(that.item_icon, d_item.icon);
				that.item_name.text = d_item['name_' + GameMgr.client_language];
			}
			game.Tools.setItemIcon(that.item_icon, that.origin_rect, d_activity_exchange.reward_id);
			let d_item_consume = cfg.item_definition.item.get(d_activity_exchange.consume_id);
			let d_item_c = game.GameUtility.get_item_view(d_activity_exchange.consume_id);
			if (d_item_consume) {
				game.LoadMgr.setImgSkin(that.currency_icon, d_item_consume.icon_transparent ? d_item_consume.icon_transparent : d_item_consume.icon);
			}
			that.currency_count.text = d_activity_exchange.consume_count.toString();

			that.item_count.x = that.item_name.textField.textWidth * that.item_name.scaleX + that.item_name.x;

			let count:number = that.count;
			let maxcount:number = d_activity_exchange.exchange_limit;
			if (count >= maxcount) count = 0;
			else count = maxcount - count;

			that.left_count.text = count + '/' + maxcount;
			// if (GameMgr.client_language == 'en') {
			// 	that.left_count.x = (that.left_count.parent as Laya.Sprite).width - 143;
			// } else {
			// 	that.left_count.x = (that.left_count.parent as Laya.Sprite).width - 120;
			// }

			if (that.btn_exchange10) {
				that.item_count.x = Math.min(d_activity_exchange.reward_count == 1 ? 651 : 558, that.item_count.x);
				if (count >= 10 && UI_Bag.get_item_count(d_activity_exchange.consume_id) >= d_activity_exchange.consume_count * 10) {
					game.Tools.setGrayDisable(that.btn_exchange10, false);
					that.btn_exchange10.visible = true;
					that.btn_exchange10.clickHandler = Laya.Handler.create(that, () => {
						game.Tools.setGrayDisable(that.btn_exchange10, true);
						app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', { exchange_id: id, count: 10 }, (err, res) => {
							if (id != that.id) return;
							game.Tools.setGrayDisable(that.btn_exchange10, false);
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
							} else {
								that.count += 10;
								that.father.refreshCurrencyCount();
								Laya.timer.once(200, that, () => {
									that.father.refreshAll();
									that.father.refreshCurrencyCount();
								});
								UI_Activity.onExchanged(id, 10);
								if (d_item && d_item.category == EItemCategory.fudai) {
									if (res['execute_reward']) {
										let rewards: Array<Object> = [];
										for (let i: number = 0; i < res['execute_reward'].length; i++) {
											rewards.push(res['execute_reward'][i]['reward']);
										}
										game.Tools.showRewards({ rewards: rewards }, null);
									}
								} else {
									let num = d_activity_exchange.reward_count * 10;
									UI_LightTips.Inst.show(game.Tools.strOfLocalization(2231, [that.item_name.text + ' x' + num]));
								}
								that.father.refreshAll();
							}
						});
					}, null, false);
				} else {
					that.btn_exchange10.visible = false;
				}
			}

			that.btn_exchange.clickHandler?.recover();
			that.btn_exchange.clickHandler = null;
			that.label_getted.visible = count == 0;
			that.btn_exchange.visible = count != 0;
			that.container_count.visible = count != 0;
			that.img_mask.visible = count == 0;
			if (count != 0) {
				var btnImage = that.btn_exchange.getChildAt(0) as Laya.Image;
				var btnLabel = btnImage.getChildAt(0) as Laya.Label;
				if (UI_Bag.get_item_count(d_activity_exchange.consume_id) < d_activity_exchange.consume_count) {
					btnImage.skin = game.Tools.localUISrc('myres/pop_panel/btn_g.png');
					btnLabel.color = '#525a6b';
					that.left_count.color = '#dd2839';
				} else {
					btnImage.skin = game.Tools.localUISrc('myres/pop_panel/btn_y.png');
					btnLabel.color = '#442334';
					that.left_count.color = '#32b254';
				}
				that.btn_exchange.clickHandler = Laya.Handler.create(that, ()=>{
					if (UI_Bag.get_item_count(d_activity_exchange.consume_id) < d_activity_exchange.consume_count) {
						UI_Info_Small.Inst.show(game.Tools.strOfLocalization(2230, [d_item_c.name]));
					} else {
						game.Tools.setGrayDisable(that.btn_exchange, true);
						app.NetAgent.sendReq2Lobby('Lobby', 'exchangeActivityItem', {exchange_id: id}, (err, res) => {
							if (id != that.id) return;
							game.Tools.setGrayDisable(that.btn_exchange, false);
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
							} else {
								that.count++;
								that.father.refreshCurrencyCount();
								Laya.timer.once(200, that, () => {
									that.father.refreshAll();
									that.father.refreshCurrencyCount();
								});
								UI_Activity.onExchanged(id);
								if (d_item && d_item.category == EItemCategory.fudai) {
									if (res['execute_reward']) {
										let rewards:Array<Object> = [];
										for (let i:number = 0; i < res['execute_reward'].length; i++) {
											rewards.push(res['execute_reward'][i]['reward']);
										}
										game.Tools.showRewards({rewards: rewards}, null);
									}
								} else {
									UI_LightTips.Inst.show(game.Tools.strOfLocalization(2231, [that.item_name.text + ' ' + that.item_count.text]));
								}
								that.father.refreshAll();
								UI_Lobby.Inst.btns.refreshBagRedpoint();
							}
						});
					}
				}, null, false);
			}
		}
	}
}