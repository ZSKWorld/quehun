/**
* name 
*/
module uiscript{
	export class UI_NewYear_Exchange extends UI_Activity_Exchange {

		private label_count_0:Laya.Label;
		private label_count_1:Laya.Label;
		private label_count_2:Laya.Label;

		constructor() {
			super(cfg.activity.activity.get(1005)['name'], new ui.lobby.activitys.activity_exchangeUI());
		}

		public isopen():boolean {
			return UI_Activity.activities[1005];
		}

		public onCreate() {
			super.onCreate();
			this.label_count_0 = this.head.getChildByName('count0') as Laya.Label;
			this.label_count_1 = this.head.getChildByName('count1') as Laya.Label;
			this.label_count_2 = this.head.getChildByName('count2') as Laya.Label;
		}

		public refreshCurrencyCount() {
			this.label_count_0.text = UI_Bag.get_item_count(309003).toString();
			this.label_count_1.text = UI_Bag.get_item_count(309004).toString();
			this.label_count_2.text = UI_Bag.get_item_count(309005).toString();
		}

		public show() {
			this.enable = true;
			game.LoadMgr.setImgSkin(this.head, 'myres2/treasurehead/newyear_reward.jpg');
			this.refreshView(UI_Activity.getExchangeList(1005));
		}

		public hide() {
			this.enable = false;
		}

	}
}