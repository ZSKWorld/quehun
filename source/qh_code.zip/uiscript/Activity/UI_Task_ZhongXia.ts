/**
* name 
*/
module uiscript{


	class Block {
		public me: Laya.Sprite;
		private info: Laya.Sprite;
		private imgItem: Laya.Image;
		private itemName: Laya.Label;
		private itemDesc1: Laya.Label;
		private itemCount: Laya.Label;
		private countMax: Laya.Label;
		private labelCount: Laya.Label;
		private infoInfo: Laya.Label;
		private btnIcon: Laya.Button;

		public constructor(me:Laya.Sprite) {
			this.me = me;
			const info = this.info = this.me.getChildByName('info') as Laya.Sprite;
			this.imgItem = info.getChildByName('item') as Laya.Image;
			this.itemName = info.getChildByName('item_name') as Laya.Label;
			this.itemDesc1 = info.getChildByName('item_desc1') as Laya.Label;
			this.itemCount = info.getChildByName('count') as Laya.Label;
			this.countMax = info.getChildByName('count_max') as Laya.Label;
			this.labelCount = info.getChildByName('label_count') as Laya.Label;
			this.infoInfo = info.getChildByName('info') as Laya.Label;
			this.btnIcon = info.getChildByName('btn_icon') as Laya.Button;
			if (GameMgr.client_language == 'en') {
				this.itemDesc1.scaleX *= 0.8;
				this.itemDesc1.scaleY *= 0.8;
				this.itemName.scaleX *= 0.8;
				this.itemName.scaleY *= 0.8;
			}
		}

		public show(item_id: number, max_count: number, desc: string): number {
			const { info, imgItem, itemName: item_name, itemDesc1: item, itemCount, countMax, labelCount, infoInfo, btnIcon } = this;
			game.LoadMgr.setImgSkin(imgItem, cfg.item_definition.item.get(item_id).icon);
			item_name.text = cfg.item_definition.item.get(item_id)['name_' + GameMgr.client_language];
			item_name.color = '#aef7ed';
			item.text = game.Tools.strOfLocalization(GameMgr.client_language == 'kr' ? 2576 : 2389);

			if (GameMgr.client_language =='jp' || GameMgr.client_language == 'kr') {
				item.x = item_name.x + item_name.textField.textWidth * item_name.scaleX + 3;
			} else {
				item_name.x = item.x + item.textField.textWidth * item.scaleX + (GameMgr.client_language =='en' ? 13 : 3);
			}
			
			itemCount.text = UI_Bag.get_item_daily_record(UI_Task_ZhongXia.limit_id, item_id).toString();
			itemCount.color = '#bfd543';
			countMax.text = '/' + max_count.toString();
			labelCount.text = game.Tools.strOfLocalization(2812) + ': ';
			infoInfo.text = desc;
			btnIcon.clickHandler?.recover();
			btnIcon.clickHandler = Laya.Handler.create(this, ()=>{
				UI_ItemDetail.Inst.show(item_id);
			}, null, false);

			let data = {};
			cfg.activity.game_task.forEach(x=>{
				if (x.activity_id == UI_Task_ZhongXia.activity_id && x.reward_id == item_id) {
					let lst:Array<number> = data[x.reward_count];
					if (!lst) {
						lst = [];
						data[x.reward_count] = lst;
					} 
					let taskId:number = x.base_task_id;
					let fanId:number = Number(cfg.events.base_task.get(taskId).param[3]);
					lst.push(cfg.fan.fan.get(fanId)['name_' + GameMgr.client_language]);
				}
			});
			let index:number = 0;
			let th:number = 146;
			let need_split = GameMgr.client_language == 'jp' || GameMgr.client_language == 'kr'; //只有jp和kr加入
			for (var k in data) {
				let cell:Laya.Sprite = info.getChildByName('cell' + index) as Laya.Sprite;
				let label_reward:Laya.Label = cell.getChildByName('reward') as Laya.Label;
				label_reward.text = cfg.item_definition.item.get(item_id)['name_' + GameMgr.client_language] + ' x' + k;
				label_reward.color = '#bfd543';
				let label_info:Laya.Label = cell.getChildByName('info') as Laya.Label;
				let s_info:string = '';
				let lst:Array<string> = data[k];
				for (let i:number = 0; i < lst.length; i++) {
					if (i != 0) s_info += UI_Task_ZhongXia.splitDot;
					if (need_split && s_info.length + lst[i].length > (GameMgr.client_language == 'en' ? 34 : 28)) {
						s_info += '\n';
						need_split = false;
					}
					s_info += lst[i];
				}
				label_info.text = s_info;
				// label_info.leading = 10;
				let h:number = label_info.textField.textHeight;
				label_info.height = h;
				label_info.y = 11;
				label_reward.y = label_info.y + h / 2;
				// label_reward.height = h;
				let line:Laya.Image = cell.getChildByName('shu') as Laya.Image;
				line.y = 7;
				cell.height = h + 22;
				line.height = cell.height - 13;
				cell.x = 31;
				cell.y = th;
				th += cell.height + 2;
				index++;
			}
			th += 25;
			(this.me.getChildByName('bg') as Laya.Sprite).height = th;
			this.me.height = th;
			return th;
		}

	}

	export class UI_Task_ZhongXia extends UI_ActivityBase {
		private static Inst: UI_Task_ZhongXia;

		public static readonly activity_id:number = 250301;
		public static readonly limit_id: number = 10016;
		public static readonly items: Array<number> = [30900086, 30900087, 30900088];

		private root:Laya.Sprite;
		private content:Laya.Panel;
		private scrollbar:capsui.CScrollBar;
		private label_icon_1:Laya.Image;
		private label_icon_2:Laya.Image;
		private label_icon_3: Laya.Image;

		private cells:Array<Block> = [];
		private toth: number = 0;
		public static splitDot: string = ",";

		constructor() {
			super(cfg.activity.activity.get(UI_Task_ZhongXia.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_task_zhongxiaUI());
			UI_Task_ZhongXia.Inst = this;
		}

		public getId(): number {
			return UI_Task_ZhongXia.activity_id;
		}

		public isopen():boolean {
			return !!UI_Activity.activities[UI_Task_ZhongXia.activity_id];
		}

		public need_popout():boolean {
			let d = cfg.activity.activity.get(UI_Task_ZhongXia.activity_id);
			if (d && d.need_popout) return true;
			return false;
		}

		public onCreate() {
			if (GameMgr.client_language == 'jp' || GameMgr.client_language == 'chs' || GameMgr.client_language == 'chs_t') {
				UI_Task_ZhongXia.splitDot = "、";
			}
			else {
				UI_Task_ZhongXia.splitDot = ",";
			}
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.content = this.root.getChildByName('content') as Laya.Panel;
			this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.content.vScrollBarSkin = '';
			this.scrollbar.init(new Laya.Handler(this, rate => {
				this.content.vScrollBar.value = this.content.vScrollBar.max * rate;
			}));
			this.scrollbar.islong = true;
			this.content.vScrollBar.on('change', this, ()=>{
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / this.toth);
			});
			this.cells = [];
			for (let i:number = 0; i < 3; i++) {
				this.cells.push(new Block(this.content.getChildByName('content' + i) as Laya.Sprite));
			}
			
			const icon = this.content.getChildByName('icon') as Laya.Sprite;
			if (GameMgr.client_language == "en") icon.x = 390;
			else if (GameMgr.client_language == "kr") icon.x = 290;
			this.label_icon_1 = icon.getChildByName('icon0') as Laya.Image;
			this.label_icon_2 = icon.getChildByName('icon1') as Laya.Image;
			this.label_icon_3 = icon.getChildByName('icon2') as Laya.Image;

			this.label_icon_1.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[0]]);
			this.label_icon_2.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[1]]);
			this.label_icon_3.on(Laya.Event.CLICK, UI_ItemDetail.Inst, UI_ItemDetail.Inst.show, [UI_Task_ZhongXia.items[2]]);
		}

		public show() {
			this.enable = true;

			game.LoadMgr.setImgSkin(this.content.getChildByName('head') as Laya.Image, cfg.activity.activity_banner.get(this.getId()).banner_big);
			game.LoadMgr.setImgSkin(this.label_icon_1, cfg.item_definition.item.get(UI_Task_ZhongXia.items[0]).icon);
			game.LoadMgr.setImgSkin(this.label_icon_2, cfg.item_definition.item.get(UI_Task_ZhongXia.items[1]).icon);
			game.LoadMgr.setImgSkin(this.label_icon_3, cfg.item_definition.item.get(UI_Task_ZhongXia.items[2]).icon);
			// let items:Array<number> = [30900025, 30900026, 30900027];
			let item_limit_id:number = UI_Task_ZhongXia.limit_id;
			let y:number = 310;
			for (let i: number = 0; i < UI_Task_ZhongXia.items.length; i++) {
				let item_id: number = UI_Task_ZhongXia.items[i];
				let max_count:number = 0;
				cfg.item_definition.source_limit.forEach(x => {
					if (x.item_id == item_id && x.id == item_limit_id) {
						max_count = x.item_limit;
					}
				});
				this.cells[i].me.y = y;
				this.cells[i].me.x = 0;
				y += this.cells[i].show(item_id, max_count, game.Tools.strOfLocalization(2813, [cfg.item_definition.item.get(item_id)['name_' + GameMgr.client_language]]));
				y += 8;
				
			}
			this.toth = y;
			this.content.refresh();
			this.content.vScrollBar.value = 0;
			this.content.vScrollBar.stopScroll();
			this.scrollbar.reset();
			this.scrollbar.setVal(0, this.content.height / this.toth);
			
			
		}
		
		public hide() {
			this.enable = false;
		}
	}
}
