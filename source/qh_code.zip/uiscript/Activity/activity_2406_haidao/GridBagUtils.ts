module uiscript {
    /**
     * 商品数据
     */
    export class GridItem {
        /**
         * 每个商品的唯一id,仅客户端
         */
        public entityId: number;
        /**
         * 道具id
         */
        public id: number;
        /**
         * 道具矩阵
         */
        public get matrix(): common.Matrix {
            return this.rotateMatrix[this.currentRotate];
        }
        /**
         * 旋转，初始是0
         */
        public get rotate(): number {
            return this.currentRotate;
        }
        public set rotate(value: number) {
            this.currentRotate = value;
        }

        private currentRotate: number;
        /**
         * 每种旋转对应的矩阵
         */
        public rotateMatrix: common.Matrix[] = new Array();
        /**
         * 道具的所占行数
         */
        public get itemCol(): number {
            return this.matrix.length;
        }



        /**
         * 道具的列数
         */
        public get itemRow(): number {
            return this.matrix[0].length;
        }


        constructor(entityId: number, itemId: number, rotate: number, rotateMatrix: common.Matrix[]) {
            this.id = itemId;
            this.entityId = entityId;
            this.currentRotate = rotate;
            this.rotateMatrix = rotateMatrix;
        }

        /**
         * 顺时针旋转当前物体
         */
        public rotateItem() {
            this.currentRotate += 1;
            if (this.currentRotate == 4) {
                this.currentRotate = 0;
            }

        }
    }


    /**
     * 格子背包
     */
    export class GridBag {
        /**
         * 背包id,服务器数据
         */
        public id: number;
        /**
         * 背包初始矩阵,读表
         */
        private initMatrix: common.Matrix;
        /**
         * 背包所有矩阵，读表
         */
        public allMatrix: common.Matrix;
        /**
         * 背包当前矩阵,不包含道具的占位，服务器数据
         */
        public currentMatrix: common.Matrix;
        /**
         * 背包当前矩阵，包含道具的占位，客户端计算
         */
        public currentItemMatrix: common.Matrix;
        /**
         * 当前在背包内的道具数据，服务器数据
         */
        public items: Array<ItemDataInBag>;
        /**
         * 所有可扩展的格子，客户端计算
         */
        private gridCanExpend: Array<Laya.Vector2>;
        /**
         * 背包配置
         */
        public bagConfig: lqc.Sheet_Activity_IslandBag;
        /**
         * 解锁格子需要消耗的道具
         */
        public unlockGridCostId: number;
        /**
         * 解锁格子需要消耗的道具数量
         */
        public unlockGridCostCount: number;
        /**
         * 解锁当前背包所需的金额
         */
        public unlockCost: number;
        /**
         * 当前背包是否解锁
         */
        public isUnlock: boolean;



        constructor(bagConfig: lqc.Sheet_Activity_IslandBag) {

            this.bagConfig = bagConfig;
            this.id = this.bagConfig.bag_id;
            this.initMatrix = GridBagUtils.Inst.convertStringToMatrix(this.bagConfig.matrix);
            this.allMatrix = GridBagUtils.Inst.convertStringToMatrix(this.bagConfig.max_matrix);

            this.items = new Array();
            let costData = common.ConfigHelper.configString2Array<number>(this.bagConfig.unlock_consume)[0];
            this.unlockGridCostId = costData[0];
            this.unlockGridCostCount = costData[1];
            if (this.bagConfig.unlock_task_id) {
                let period_task = cfg.activity.period_task.get(this.bagConfig.unlock_task_id);
                let baseTask = cfg.events.base_task.find(period_task.base_task_id);
                this.unlockCost = baseTask.target;
            }
            this.setMatrix(this.initMatrix);
            this.isUnlock = false;
        }

        /**
         * 设置当前矩阵，不带道具的
         * @param matrix 
         */
        public setMatrix(matrix: common.Matrix) {
            this.currentMatrix = matrix;
            this.getGridCanExpend();
            this.freshCurrentItemMatrix();
        }

        /**
         * 设置背包道具数据
         * @param items 道具数据
         */
        public setItemData(items: Array<ItemDataInBag>) {
            this.clearBagItem();
            this.items = items;
            this.freshCurrentItemMatrix();
        }

        public clearBagItem() {
            this.items = new Array();
        }

        /**
         * 获取哪些格子是可以扩展的
         */
        private getGridCanExpend() {
            this.gridCanExpend = new Array();
            let expendMatrix: common.Matrix = common.MatrixUtils.subtract(this.allMatrix, this.currentMatrix);
            //总行数
            var col: number = expendMatrix[0].length;
            //总列数
            var row: number = expendMatrix.length
            //如果格子里的值是-1，则可以扩展
            for (let x = 0; x < row; x++) {
                for (let y = 0; y < col; y++) {
                    let grid = expendMatrix[x][y];
                    if (grid == -1) {
                        this.gridCanExpend.push(new Laya.Vector2(x, y));
                    }
                }
            }
        }


        /**
         * 根据当前道具信息生成对应的放置了道具的矩阵，此处仅用于道具完全合规的情况
         */
        public freshCurrentItemMatrix() {
            //深度拷贝一个新数组，防止改到旧数组
            let newMatrix = game.Tools.deepCopy<common.Matrix>(this.currentMatrix);
            //遍历每一个道具
            for (let index = 0; index < this.items.length; index++) {
                let item = this.items[index];
                // console.log("放置道具", item.itemLocalData.matrix, newMatrix, item.startPosX,item.startPosY);

                //遍历道具的矩阵，将每一个是1的部分添加到背包矩阵对应的位置
                for (let x = item.startPosX; x < (item.startPosX + item.itemLocalData.itemCol); x++) {
                    for (let y = item.startPosY; y < (item.startPosY + item.itemLocalData.itemRow); y++) {
                        let itemPosX = x - item.startPosX;
                        let itemPosY = y - item.startPosY;
                        let itemGrid = item.itemLocalData.matrix[itemPosX][itemPosY];
                        if (itemGrid == 1) {
                            if (newMatrix[x][y] == 0) {
                                newMatrix[x][y] = 1;
                            }
                            else {
                                //todo 换成项目的打印
                                // console.log("出错了，该道具放不下", item.itemLocalData.matrix);
                            }
                        }
                    }
                }
            }


            this.currentItemMatrix = newMatrix;
        }

        /**
         * 根据道具数据，和起始格子，获取当前道具哪些部分不合规。
         * @param item 道具配置
         * @param startPosX 起始x坐标
         * @param startPosY 起始y坐标
         * @returns 在背包矩阵内的错误坐标数组
         */
        public isItemRight(item: GridItem, startPosX: number, startPosY: number): Laya.Vector2[] {
            let wrongPos: Laya.Vector2[] = new Array();
            let putResult = common.MatrixUtils.placeMatrix(item.matrix, this.currentItemMatrix, startPosX, startPosY);
            let overflow = putResult.overflow;
            let result = putResult.result;
            //先将超出背包的部分添加
            for (let index = 0; index < overflow.length; index++) {
                wrongPos.push(new Laya.Vector2(overflow[index][0], overflow[index][1]));
            }
            //遍历道具在背包内的格子
            for (let x = 0; x < item.itemCol; x++) {
                for (let y = 0; y < item.itemRow; y++) {
                    let posInBagX = x + startPosX;
                    let posInBagY = y + startPosX;
                    if (result[posInBagX][posInBagY] > 1) {
                        wrongPos.push(new Laya.Vector2(x, y));
                    }
                }
            }
            return wrongPos;
        }


        //添加道具（从商店拖入背包）
        public addItemInBag(item: GridItem, startPosX: number, startPosY: number) {
            let newData = new ItemDataInBag(item.id, -1, this.id, startPosX, startPosY, item);
            this.items.push(newData);
            this.freshCurrentItemMatrix();
        }

        /**
         * 获取背包里指定的item
         * @param item 
         */
        public findItem(item: GridItem): ItemDataInBag[] {
            let result = this.items.filter((v) => {
                return v.itemLocalData == item;
            })
            return result;

        }







        /**
         * 移除指定的物品
         * @param itemData 
         */
        public removeItem(itemData: ItemDataInBag) {
            game.Tools.removeFromArray(this.items, itemData);
            this.freshCurrentItemMatrix();
        }


        /**
         * 根据道具id移除物品（用于出售）,如果数量不足，则返回剩余需要移除的数量
         * @param itemId 道具id
         * @param itemCount 道具数量
         * @returns 还剩下多少个待移除
         */
        public removeItems(itemId: number, itemCount: number = 1): number {
            let removeCount = 0;
            //从末尾移除，防止index溢出
            for (let index = this.items.length - 1; index >= 0; index--) {
                let item = this.items[index];
                if (item.id == itemId) {
                    this.items.splice(index, 1);
                    removeCount++;
                    if (itemCount == removeCount) {
                        return 0;
                    }
                }
            }
            return itemCount - removeCount;
        }

        /**
         * 扩充背包
         * @param posX 
         * @param posY 
         */
        public expendBag(posX, posY) {
            let canExpand = false;
            //检测这一格是否可以扩充
            for (let index = 0; index < this.gridCanExpend.length; index++) {
                let grid = this.gridCanExpend[index];
                if (grid.x == posX && grid.y == posY) {
                    canExpand = true;
                }
                break;
            }
            if (canExpand) {
                this.currentMatrix[posX][posY] = 0;
            }
            this.getGridCanExpend();
        }


        /**
         * 背包内该坐标是否可以放置物品
         * @param posX 
         * @param posY 
         * @returns true可以放置，false不可以放置
         */
        public isGridFill(posX: number, posY: number): boolean {
            return this.currentItemMatrix[posX][posY] == 0;
        }



        /**
         * 获取背包指定id的物品
         * @param itemId 
         * @returns 
         */
        public findItems(itemId: number): ItemDataInBag[] {
            let items = this.items.filter((item) => {
                if (item.id == itemId) {
                    return item;
                }
            });
            return items;
        }

        public clone(): GridBag {
            let newBag = new GridBag(this.bagConfig);
            //复制道具数据
            let newItems = new Array<ItemDataInBag>();
            this.items.forEach((item) => {
                let newLocalData = GridBagUtils.Inst.getItem(item.id, item.itemLocalData.rotateMatrix[0]);
                newLocalData.rotate = item.itemLocalData.rotate;
                let newItem = new ItemDataInBag(item.id, item.serverId, this.id, item.startPosX, item.startPosY, newLocalData);
                newItem.serverId = item.serverId;
                newItem.price = item.price;
                newItems.push(newItem);

            });
            newBag.setItemData(newItems);
            newBag.setMatrix(game.Tools.deepCopy<common.Matrix>(this.currentMatrix));
            newBag.isUnlock = this.isUnlock;
            return newBag;
        }

        public findItemByServerId(serverId: number) {
            let items = this.items.filter((item) => {
                if (item.serverId == serverId) {
                    return item;
                }
            });
            return items;
        }

        public isGridCanExpand(posX, posY): boolean {
            for (let index = 0; index < this.gridCanExpend.length; index++) {

                if (this.gridCanExpend[index].x == posX && this.gridCanExpend[index].y == posY) {
                    return true;
                }
            }
            return false;
        }


    }

    /**
     * 道具在背包中的数据
     */
    export class ItemDataInBag {
        public id: number;
        /**
         * -1 代表并非服务器数据
         */
        public serverId: number;
        /**
         * 矩阵的0,0在背包中的x坐标
         */
        public startPosX: number;
        /**
        * 矩阵的0,0在背包中的y坐标
        */
        public startPosY: number;
        /**
         * 所在的背包id
         */
        public bagId: number;
        /**
         * 购买时花费的钱
         */
        public price: number;
        /**
         * 实体相关的数据
         */
        public itemLocalData: GridItem;

        constructor(id: number, serverId: number, bagId: number, startPosX: number, startPosY: number, itemData: GridItem) {
            this.id = id;
            this.startPosX = startPosX;
            this.startPosY = startPosY;
            this.itemLocalData = itemData;
            this.serverId = serverId;
            this.bagId = bagId;
        }
    }


    export class GridBagUtils {
        private static inst: GridBagUtils | null;
        public static get Inst(): GridBagUtils {
            if (this.inst == null) {
                this.inst = new GridBagUtils();
            }
            return this.inst;
        };
        /**
         * 用于给每个生成的道具添加唯一id
         */
        private id: number = 0;
        /**
         * 道具id-旋转数据
         */
        private matrixRotateDic: basic.Dictionary<number, common.Matrix[]> = new basic.Dictionary();
        /**
         * 道具池
         */
        private itemPool: basic.Dictionary<number, GridItem[]> = new basic.Dictionary();



        /**
         * 生成一个item
         * @param itemId itemId 
         * @returns 
         */
        public getItem(itemId: number, baseMatrix: common.Matrix): GridItem {
            if (!this.itemPool.has(itemId)) {
                this.itemPool.set(itemId, new Array());
            }
            let pool = this.itemPool.get(itemId);
            if (pool.length == 0) {
                this.createItem(itemId, baseMatrix);
            }
            let item = this.itemPool.get(itemId).pop();
            return item;
        }

        private createItem(itemId: number, baseMatrix: common.Matrix) {
            let rotateMatrix: common.Matrix[] = new Array();

            if (!this.matrixRotateDic.has(itemId)) {
                for (let index = 0; index < 4; index++) {
                    let rotateRulst = common.MatrixUtils.rotate(baseMatrix, 0, index);
                    rotateMatrix.push(rotateRulst);
                }
                this.matrixRotateDic.set(itemId, rotateMatrix);
            }
            rotateMatrix = this.matrixRotateDic.get(itemId);
            let entityId = this.getId();
            let newItem = new GridItem(entityId, itemId, 0, rotateMatrix);
            this.itemPool.get(itemId).push(newItem);
        }

        /**
         * 回收道具的对象
         * @param item 
         */
        public recycleItem(item: GridItem) {
            // this.itemPool.get(item.id).push(item);
        }

        private getId(): number {
            this.id++;
            return this.id;
        }

        /**
         * 将服务器收到的数据转成矩阵
         * @param str "4,1,0,0,0,0,0,0,0,",第一个是值矩阵的宽度,剩下的是数据
         */
        public convertStringToMatrix(str: string): common.Matrix {
            const [width, ...data] = str.split(',').map(str => parseInt(str));
            if ((data.length % width) != 0) {
                throw new Error('Invalid matrix');
            }
            let matrix: common.Matrix = new Array();
            let lineCount = data.length / width;
            for (let line = 0; line < lineCount; line++) {
                matrix[line] = new Array();
                for (let index = 0; index < width; index++) {
                    matrix[line][index] = data[index + line * width];
                }
            }
            return matrix;
        }

        /**
         * 将矩阵转成字符串
         * @param matrix 
         * @returns 
         */
        public convertMatrixToString(matrix: common.Matrix): string {
            //列数
            let row = matrix[0].length;
            //行数
            let col = matrix.length;
            let maxX = row - 1;
            let maxY = col - 1;
            let str: string = row + ",";
            for (let x = 0; x < row; x++) {
                for (let y = 0; y < col; y++) {
                    let numb = matrix[x][y];
                    str += numb.toString();
                    if (x != maxX && y != maxY) {
                        str += ",";
                    }
                }
            }
            return str;
        }

        /**
        * 获取离某个点最近的格子（限背包范围内）
        * @param gridPos 格子的中心点，世界坐标
        * @param bagPos 背包(0,0)的中心点，世界坐标
        * @param gridWidth 格子的宽高
        * @param bagWidth 背包的宽度
        * @param bagHeight 背包的高度
        * @returns 背包内对应矩阵坐标，如果为(-1,-1)
        */
        public getGridNearby(gridPos: Laya.Vector2, bagPos: Laya.Vector2, gridWidth: number, bagWidth: number = 5, bagHeight: number = 5): Laya.Vector2 {
            let posInBag: Laya.Vector2 = new Laya.Vector2(-1, -1);
            //检测中心点是否在检测范围内
            let upSide: number = bagPos.y - gridWidth / 2;
            let downSide: number = bagPos.y + (bagHeight - 1) * gridWidth + gridWidth / 2;
            let leftSide: number = bagPos.x - gridWidth / 2;
            let rightSide: number = bagPos.x + (bagWidth - 1) * gridWidth + gridWidth / 2;

            if (gridPos.x >= leftSide && gridPos.x <= rightSide) {
                if (gridPos.y >= upSide && gridPos.y <= downSide) {
                    let offsetX: number = bagPos.x - gridPos.x;
                    let offsetY: number = bagPos.y - gridPos.y;
                    posInBag.x = Math.floor(offsetX / gridWidth) + (offsetX % gridWidth) >= (gridWidth / 2) ? 1 : 0;
                    posInBag.y = Math.floor(offsetY / gridWidth) + (offsetY % gridWidth) >= (gridWidth / 2) ? 1 : 0;

                }
            }
            return posInBag;
        }

    }
}
