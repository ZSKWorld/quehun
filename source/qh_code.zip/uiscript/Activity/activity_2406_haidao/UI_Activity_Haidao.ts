enum Haidao_EventId {
    UPDATE_DATA = "update_data",
    CLICK_BAG_UPDATE = "click_bag_update",
    UNLOCK_BAG = "unlock_bag",
}

module uiscript {




    interface StageItemShopData {
        id: number;
        /**
         * 当前数量
         */
        count: number;
        /**
         * 今日价格
         */
        price: number;
        /**
         * 今日折扣
         */
        discount: number;
        /**
         * 价格是否被新闻影响 0不影响，1涨价，-1降价
         */
        isEffectByNews: number;
        itemShopConfig: lqc.Sheet_Activity_IslandShop;

    }


    export class Activity_Haidao_Stage {
        public id: number;
        /**
         * 此地区商人持有的金额
         */
        public shopMoney: number;
        /**
         * 当前商店的商品数据
         */
        public get todayShopItems(): basic.Dictionary<number, StageItemShopData> {
            return this.shopItemsDataDic.get(UI_Activity.getActivityDeltaDay(UI_Activity_Haidao.activityId));
        };

        /**
         * 当前地区的配置文件
         */
        public stageConfig: lqc.Sheet_Activity_IslandMap;
        /**
         * 当前地区是否解锁
         */
        public isStageUnlock: boolean;
        /**
         * 解锁该地区需要的花费
         */
        public unlockCount: number = 0;


        /**
         * <天数，<道具id,数据>>
         */
        private shopItemsDataDic: basic.Dictionary<number, basic.Dictionary<number, StageItemShopData>>;


        constructor(config: lqc.Sheet_Activity_IslandMap) {
            this.stageConfig = config;
            this.id = this.stageConfig.zone_id;
            if (this.stageConfig.unlock_task_id) {
                this.unlockCount = common.ConfigHelper.getPeriodTaskTarget(this.stageConfig.unlock_task_id).target;
            }
            this.shopItemsDataDic = new basic.Dictionary();
            let shopsItemConfig = cfg.activity.island_shop.getGroup(UI_Activity_Haidao.activityId);
            for (let index = 0; index < shopsItemConfig.length; index++) {
                let itemShopConfig = shopsItemConfig[index];
                let itemConfig = UI_Activity_Haidao.itemConfigDic.get(itemShopConfig.goods_id);
                //是本区域的数据
                if (itemShopConfig.zone_id == this.id) {
                    let day = itemShopConfig.day;
                    if (!this.shopItemsDataDic.has(day)) {
                        this.shopItemsDataDic.set(day, new basic.Dictionary());
                    }
                    let dayItems = this.shopItemsDataDic.get(day);

                    //计算当日的价格 基础价格*新闻影响1*新闻影响2...
                    let todayNews = UI_Activity_Haidao.newsConfigDic.get(day);
                    if (!todayNews) {
                        todayNews = new Array();
                    }

                    let newEffetcDiscount: number = 1;
                    let isEffectByNews: boolean = false;
                    for (let newsIndex = 0; newsIndex < todayNews.length; newsIndex++) {
                        let news = todayNews[newsIndex];

                        if (news.goods_id == -1) {
                            if (news.zone == this.id) {
                                newEffetcDiscount *= (news.effect / 100);
                                isEffectByNews = true;
                                continue;
                            }
                        }
                        if (news.zone == -1) {
                            if (news.goods_id == itemConfig.goods_id) {
                                newEffetcDiscount *= (news.effect / 100);
                                isEffectByNews = true;
                                continue;
                            }
                        }

                        if (news.goods_id == -1 && news.zone == -1) {
                            newEffetcDiscount *= (news.effect / 100);
                            isEffectByNews = true;
                            continue;
                        }

                        if (news.zone == this.id && news.goods_id == itemConfig.goods_id) {
                            newEffetcDiscount *= (news.effect / 100);
                            isEffectByNews = true;
                            continue;
                        }
                    }
                    //若该商品正受到海岛新闻内事件影响，则显示HOT（涨价事件）、SALE（降价事件）标识
                    let effectByNews = 0;

                    if (isEffectByNews) {
                        if (newEffetcDiscount >= 1) {
                            effectByNews = 1;
                        }
                        else {
                            effectByNews = -1;
                        }
                    }


                    //最终比率
                    let totalDiscount = itemShopConfig.discount * newEffetcDiscount;
                    //最终价格
                    let finalPrice: number = UI_Activity_Haidao.itemConfigDic.get(itemConfig.goods_id).price * totalDiscount / 100;
                    // console.log(day, itemShopConfig.goods_id);

                    let item: StageItemShopData = {
                        id: itemConfig.goods_id,
                        count: itemShopConfig.count,
                        itemShopConfig: itemShopConfig,
                        discount: totalDiscount,
                        price: finalPrice,
                        isEffectByNews: effectByNews
                    }
                    dayItems.set(itemShopConfig.goods_id, item)
                }

            }
        }

        public freshMoney(changCount: number) {
            //获取今天的金额
            this.shopMoney = this.stageConfig.currency_amount - changCount;
        }
    }

    export enum EActivityHaidaoEffect {
        soldOut,
        bagUpdate,
        pageReward
    }

    export class UI_Activity_Haidao extends UIBase {
        public static Inst: UI_Activity_Haidao = null;
        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidaoUI);
            UI_Activity_Haidao.Inst = this;
        }
        public static activityId: number = 240601;
        public static powerItemId: number = 30900028;
        public static moneyItemId: number = 30900029;
        public static activityServerData: game.IActivityIslandData;
        public static duringGuide: boolean = false;
        public static _guideShopData: any;
        public static get guideShopData() {
            if (!this._guideShopData) {
                let price = cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).guide_bottle_price;
                this._guideShopData = {
                    item: {
                        id: 1001,
                        count: 3,
                        itemShopConfig: {
                            count: 0,
                            discount: cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).sell_discount
                        },
                        discount: Math.floor(price / UI_Activity_Haidao.itemConfigDic.get(1001).price * 100),
                        price,
                        isEffectByNews: 0
                    },
                    bagCurrencyCount: 0
                }
            }
            return this._guideShopData;
        };
        public static set guideShopData(data) { this._guideShopData = data };
        public static isInit: boolean = false;

        /**
         * 商店商品数据，<地区id,<天数，数据>>
         */
        public static islandItemConfigDic: basic.Dictionary<number, basic.Dictionary<number, lqc.Sheet_Activity_IslandShop[]>>;
        /**
         * 商品数据<id,数据>
         */
        public static itemConfigDic: basic.Dictionary<number, lqc.Sheet_Activity_IslandGoods>;
        /**
         * 背包数据<id,数据>
         */
        public static bagConfigDic: basic.Dictionary<number, lqc.Sheet_Activity_IslandBag>;
        /**
         * 新闻数据<天数,数据>
         */
        public static newsConfigDic: basic.Dictionary<number, lqc.Sheet_Activity_IslandNews[]>;
        /**
         * 地区数据，<地区id,数据>
         */
        public static stageDataDic: basic.Dictionary<number, Activity_Haidao_Stage>;
        /**
         * 背包数据，<背包id,数据>
         */
        public static bagDataDic: basic.Dictionary<number, GridBag>;
        /**
         * 背包ID
         */
        public static bagIdArray: Array<number> = [101, 102, 103];
        public static bagMaxWidth: number = 5;
        public static bagMaxHeight: number = 5;
        public static sellDiscount: number = 0;
        public static colorGray: string = "#9C8781";
        public static colorRed: string = "#DF2D36";
        public static colorWhite: string = "#FFFFF7";
        public static colorBrown: string = "#766051";

        public static init() {
            if (this.isInit) {
                return;
            }
            this.isInit = true;
            //配置表数据处理
            this.islandItemConfigDic = new basic.Dictionary();
            let shopItemData = cfg.activity.island_shop.getGroup(UI_Activity_Haidao.activityId);
            for (let index = 0; index < shopItemData.length; index++) {
                let itemData = shopItemData[index];
                if (!this.islandItemConfigDic.has(itemData.zone_id)) {
                    this.islandItemConfigDic.set(itemData.zone_id, new basic.Dictionary());
                }
                let zoneData = this.islandItemConfigDic.get(itemData.zone_id);
                if (!zoneData.has(itemData.day)) {
                    zoneData.set(itemData.day, new Array());
                }
                let dayData = zoneData.get(itemData.day);
                dayData.push(itemData);
            }


            this.itemConfigDic = new basic.Dictionary();
            let items = cfg.activity.island_goods.getGroup(this.activityId);
            for (let index = 0; index < items.length; index++) {
                let item = items[index];
                this.itemConfigDic.set(item.goods_id, item);
            }



            this.newsConfigDic = new basic.Dictionary();
            let newsData = cfg.activity.island_news.getGroup(this.activityId);
            for (let index = 0; index < newsData.length; index++) {
                let news = newsData[index];
                let newsArray: Array<lqc.Sheet_Activity_IslandNews> = new Array();
                if (!this.newsConfigDic.has(news.day)) {
                    this.newsConfigDic.set(news.day, newsArray)
                }
                newsArray = this.newsConfigDic.get(news.day);
                newsArray.push(news);
            }
            //初始化区域数据
            this.stageDataDic = new basic.Dictionary();
            let stagesData = cfg.activity.island_map.getGroup(UI_Activity_Haidao.activityId);
            for (let index = 0; index < stagesData.length; index++) {
                let stageData = stagesData[index];
                let stage = new Activity_Haidao_Stage(stageData);
                stage.isStageUnlock = false;
                this.stageDataDic.set(stageData.zone_id, stage);
            }
            // console.log("处理完毕的区域数据", JSON.stringify(this.stageDataDic));
            //初始化背包数据
            this.bagDataDic = new basic.Dictionary();
            let bags = cfg.activity.island_bag.getGroup(this.activityId);
            for (let index = 0; index < bags.length; index++) {
                let bagData = bags[index];
                let bag = new GridBag(bagData);
                this.bagDataDic.set(bagData.bag_id, bag);
            }
            // console.log("处理完毕的背包数据", JSON.stringify(this.bagDataDic));
            this.sellDiscount = cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).sell_discount;

        }

        public static updateData(msg) {
            UI_Activity_Haidao.init();
            for (let data of msg) {
                if (data.activity_id == this.activityId) {
                    // console.log("收到活动数据", JSON.stringify(data));
                    this.activityServerData = data;
                    break;
                }
            }

            if (this.Inst && this.Inst.enable) {
                //todo 刷新一次界面
                UI_Activity_Haidao.Inst.onUpdateData();
            }

        }

        public static haveRedPoint(): boolean {
            if (!UI_Activity.activity_is_running(UI_Activity_Haidao.activityId)) return false;
            if (UI_Activity_Haidao_Task.haveRedPoint()) return true;
            if (UI_Activity_Haidao_Rewards.haveRedPoint()) return true;
            return false;
        }

        public ui: ui.lobby.activity_2406_haidao.activity_2406_haidaoUI;
        /**
         * 每个格子的ui宽度
         */
        public static gridWidth: number = 86;
        public static gridSpace: number = 2;
        /**
         * 顶部菜单的父物体
         */
        private topMenu: Laya.Sprite;
        /**
         * 区域按钮的父物体
         */
        private mapStages: Laya.Sprite;
        /**
         * 云的父物体
         */
        private clouds: Laya.Sprite;
        /**
         * 跳转按钮的父物体
         */
        private jumpBtns: Laya.Sprite;
        /**
         * 新闻的父物体
         */
        private news: Laya.Sprite;
        /**
         * 关闭按钮
         */
        private returnBtn: Laya.Button;
        /**
         * page页面的父物体
         */
        private pageContainer: Laya.Sprite;
        /**
         * 部分page界面的背景
         */
        private pageBg: Laya.Sprite;
        private bg: Laya.Sprite;
        private isLock: boolean = false;
        /**
         * 当前选中的地区
         */
        public get selectStageId(): number {
            return this.currentSelectStageId;
        }
        private currentSelectStageId: number;
        public currentAtStageId: number;

        private pageNews: UI_Activity_Haidao_News;
        private pageRules: UI_Activity_Haidao_Rules;
        private pageBag: UI_Activity_Haidao_Page_Bag;
        private pageShop: UI_Activity_Haidao_Page_Shop;
        private pageSpot: UI_Activity_Haidao_Spot;
        private pageReward: UI_Activity_Haidao_Rewards;
        private pageTask: UI_Activity_Haidao_Task;
        private popupLockBagTip: UI_Activity_Haidao_LockBagTip;
        private pageCongrate: UI_Activity_Haidao_Congrate;
        private stageDetail: UI_Activity_Haidao_StageDetail;
        private quitTip: UI_Activity_Haidao_QuitTip;

        private stageBtns: Array<UI_Button> = new Array();
        private stageRedPoints: Array<Laya.Image> = [];
        private spotBtn: UI_Button;
        private popup: Laya.Sprite;
        private redPointSpotLeft: Laya.Sprite;

        private moneyCountLabel: Laya.Label;
        private powerCountLabel: Laya.Label;

        private onItemFreshHandler: Laya.Handler;
        private popChar: Laya.Sprite;
        private newsDesc: Laya.HTMLDivElement;
        private btnNews: Laya.Button;
        private btnHelp: Laya.Button;
        private redPointTask: Laya.Image;
        private redPointNews: Laya.Image;
        private redPointSpot: Laya.Image;
        private redPointReward: Laya.Image;
        private redPointBag: Laya.Image;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniClouds: Laya.FrameAnimation[];

        private newsData: lqc.Sheet_Activity_IslandNews[];
        /**
         * stagedetail在每个区域时的坐标
         */
        public stageDetailPos: basic.Dictionary<number, Laya.Vector2> = new basic.Dictionary();
        public stageDetailPivot: basic.Dictionary<number, Laya.Vector2> = new basic.Dictionary();
        /**
         * popchar在每个地区的位置，
         */
        public stagePopCharPos: basic.Dictionary<number, Laya.Vector2> = new basic.Dictionary();
        private effectActivity: game.UIEffect;
        private effectBg: Laya.Scene;
        private effectAni: Catfood.CAnimator;
        private audioId: number;
        private activityFinishHandler: Laya.Handler;

        public onCreate(): void {
            UI_Activity_Haidao.init();
            this.stageDetailPos.set(0, new Laya.Vector2(650, 296));
            this.stageDetailPos.set(1, new Laya.Vector2(206, 77));
            this.stageDetailPos.set(2, new Laya.Vector2(516, 120));
            this.stageDetailPos.set(3, new Laya.Vector2(429, 492));
            this.stageDetailPos.set(4, new Laya.Vector2(524, 294));
            this.stageDetailPivot.set(0, new Laya.Vector2(900, 560));
            this.stageDetailPivot.set(1, new Laya.Vector2(900, 560));
            this.stageDetailPivot.set(2, new Laya.Vector2(986, 457));
            this.stageDetailPivot.set(3, new Laya.Vector2(500, 0));
            this.stageDetailPivot.set(4, new Laya.Vector2(0, 120));

            this.ui = this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI;
            this.topMenu = this.me.getChildByName("top_menu") as Laya.Sprite;
            this.mapStages = this.me.getChildByName("map_stages") as Laya.Sprite;
            this.clouds = this.mapStages.getChildByName("clouds") as Laya.Sprite;
            this.jumpBtns = this.me.getChildByName("jump_btns") as Laya.Sprite;
            this.news = this.me.getChildByName("news") as Laya.Sprite;
            this.pageContainer = this.me.getChildByName("container_page") as Laya.Sprite;
            this.pageBg = this.pageContainer.getChildByName("bg") as Laya.Sprite;
            this.returnBtn = this.topMenu.getChildByName("return_btn") as Laya.Button;
            this.returnBtn.clickHandler = new Laya.Handler(this, this.onClickReturn);
            this.bg = this.me.getChildByName("bg") as Laya.Sprite;
            this.moneyCountLabel = this.topMenu.getChildByName('money_count').getChildByName("value_text") as Laya.Label;

            this.powerCountLabel = this.topMenu.getChildByName('power_count').getChildByName("value_text") as Laya.Label;
            this.newsDesc = this.news.getChildByName('scroll').getChildByName('content') as Laya.HTMLDivElement;
            this.btnNews = this.news.getChildByName('news') as Laya.Button;
            this.btnNews.clickHandler = new Laya.Handler(this, this.onClickNews);
            this.btnHelp = this.topMenu.getChildByName('help_btn') as Laya.Button;
            let title = this.topMenu.getChildByName('title') as Laya.Image;
            this.btnHelp.x = title.x + title.width + 24;
            this.btnHelp.clickHandler = new Laya.Handler(this, this.onClickHelp);
            //地区详情
            let stageDetailPage: Laya.Sprite = this.me.getChildByName("pop_stage_detail") as Laya.Sprite;
            stageDetailPage.visible = false;
            this.stageDetail = new UI_Activity_Haidao_StageDetail(stageDetailPage);
            this.popup = this.me.getChildByName('popup') as Laya.Sprite;

            // let mainBg = this.bg.getChildByName("back") as Laya.Image;
            // game.LoadMgr.setImgSkin(mainBg, 'myres/activity_2406_haidao/main_activity_background.jpg');
            //初始化弹出窗口
            this.pageBag = new UI_Activity_Haidao_Page_Bag();
            this.pageContainer.addChild(this.pageBag.me);
            this.pageBag.enable = false;
            this.pageShop = new UI_Activity_Haidao_Page_Shop();
            this.pageContainer.addChild(this.pageShop.me);
            this.pageShop.enable = false;
            this.pageNews = new UI_Activity_Haidao_News();
            this.pageContainer.addChild(this.pageNews.me);
            this.pageNews.enable = false;
            this.pageRules = new UI_Activity_Haidao_Rules();
            this.pageContainer.addChild(this.pageRules.me);
            this.pageRules.enable = false;
            this.pageSpot = new UI_Activity_Haidao_Spot();
            this.pageContainer.addChild(this.pageSpot.me);
            this.pageSpot.enable = false;
            this.pageTask = new UI_Activity_Haidao_Task();
            this.pageContainer.addChild(this.pageTask.me);
            this.pageTask.enable = false;
            this.pageReward = new UI_Activity_Haidao_Rewards();
            this.pageContainer.addChild(this.pageReward.me);
            this.pageReward.enable = false;
            this.pageCongrate = new UI_Activity_Haidao_Congrate();
            this.popup.addChild(this.pageCongrate.me);
            this.pageCongrate.enable = false;
            // 背包解锁提示
            let bagLockPage: Laya.Sprite = this.me.getChildByName("popup").getChildByName("bag_lock_page") as Laya.Sprite;
            bagLockPage.visible = false;
            this.popupLockBagTip = new UI_Activity_Haidao_LockBagTip(bagLockPage);

            let quitTipPage: Laya.Sprite = this.me.getChildByName("popup").getChildByName("quit_tip_page") as Laya.Sprite;
            quitTipPage.visible = false;
            this.quitTip = new UI_Activity_Haidao_QuitTip(quitTipPage);

            //绑定点击事件
            let taskBtn = this.jumpBtns.getChildByName('task_btn') as Laya.Button;
            this.redPointTask = taskBtn.getChildByName('red_point') as Laya.Image;
            taskBtn.clickHandler = new Laya.Handler(this, this.onClickTask);
            let newsBtn = this.jumpBtns.getChildByName('news_btn') as Laya.Button;
            this.redPointNews = newsBtn.getChildByName('red_point') as Laya.Image;
            newsBtn.clickHandler = new Laya.Handler(this, this.onClickNews);
            let spotBtn = this.jumpBtns.getChildByName('spot_btn') as Laya.Button;
            this.redPointSpot = spotBtn.getChildByName('red_point') as Laya.Image;
            spotBtn.clickHandler = new Laya.Handler(this, this.onClickSpot);
            let rewardBtn = this.jumpBtns.getChildByName('reward_btn') as Laya.Button;
            this.redPointReward = rewardBtn.getChildByName('red_point') as Laya.Image;
            rewardBtn.clickHandler = new Laya.Handler(this, this.onClickReward);
            let bagBtn = this.jumpBtns.getChildByName('bag_btn') as Laya.Button;
            this.redPointBag = bagBtn.getChildByName('red_point') as Laya.Image;
            bagBtn.clickHandler = new Laya.Handler(this, this.onClickBag);

            let moneyInfoBtn = this.topMenu.getChildByName('money_count').getChildByName("info_btn") as Laya.Button;
            let powerInfoBtn = this.topMenu.getChildByName('power_count').getChildByName("info_btn") as Laya.Button;
            moneyInfoBtn.clickHandler = new Laya.Handler(this, () => {
                this.onClickItemInfo(UI_Activity_Haidao.moneyItemId);
            });
            powerInfoBtn.clickHandler = new Laya.Handler(this, () => {
                this.onClickItemInfo(UI_Activity_Haidao.powerItemId);
            });
            this.aniShow = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI).animIn;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI).animOut;
            let aniCloud2 = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI).cloud2;
            let aniCloud3 = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI).cloud3;
            let aniCloud4 = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI).cloud4;
            this.aniClouds = [null, null, aniCloud2, aniCloud3, aniCloud4];
            this.onItemFreshHandler = new Laya.Handler(this, this.freshTopInfo);
            this.initMap();
            if (GameMgr.client_language == 'jp') {
                this.newsDesc.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.newsDesc.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.newsDesc.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.newsDesc.style.font = '30px SimHei';
            } else {
                this.newsDesc.style.font = '30px NotoSansKR';
            }
            this.newsDesc.style.color = '#111C57';
            this.newsDesc.style.letterSpacing = 1;
            this.newsDesc.style.whiteSpace = 'nowrap';
            this.effectBg = Laya.loader.getRes('scene/effect_haidao_bg.ls');
            this.bg.addChild(this.effectBg);
            this.effectBg.visible = true;
            this.effectAni = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
        }


        showLockBagTipPopup(bagId: number) {
            this.popupLockBagTip.show(bagId);
        }

        setEffectActive(type: EActivityHaidaoEffect, active: boolean, pos?: Laya.Point) {
            if (this.effectActivity) {
                this.effectActivity.effect.root.active = active;
                if (type == EActivityHaidaoEffect.pageReward) {
                    this.effectActivity.pos_offset = new Laya.Point(450, 500);
                } else if (type == EActivityHaidaoEffect.soldOut) {
                    this.effectActivity.pos_offset = new Laya.Point(960, 540);
                } else if (pos) {
                    this.effectActivity.pos_offset = new Laya.Point(pos.x + 45, pos.y + 45);
                }
                this.effectActivity.effect.effect_root._childs[0]._childs.forEach((effect, index) => {
                    effect.active = false;
                    if (type == index && active) {
                        effect.active = true;
                    }
                });
            }
        }

        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
            }
        }

        private playBgm() {
            if (view.AudioMgr.musicMuted) return;
            let audioPath = cfg.audio.audio.get(10129).path;
            let volume = view.AudioMgr.musicVolume;
            this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao', true);
            this.removeEvent();
            this.bindEvent();
        }

        private bindEvent() {
            UI_Bag.add_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            UI_Bag.add_item_listener(UI_Activity_Haidao.powerItemId, this.onItemFreshHandler);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao', false);
            this.removeEvent();
            Laya.timer.clearAll(this);
            Laya.timer.clearAll(this.news);
            this.stopBgm();
            view.BgmListMgr.PlayLobbyBgm();
            if (this.pageNews.enable) this.pageNews.enable = false;
            if (this.pageBag.enable) this.pageBag.enable = false;
            if (this.pageCongrate.enable) this.pageCongrate.enable = false;
            if (this.pageReward.enable) this.pageReward.enable = false;
            if (this.pageSpot.enable) this.pageSpot.enable = false;
            if (this.pageShop.enable) this.pageShop.enable = false;
            if (this.pageTask.enable) this.pageTask.enable = false;
            if (this.pageRules.enable) this.pageRules.enable = false;

        }

        private removeEvent() {
            UI_Bag.remove_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            UI_Bag.remove_item_listener(UI_Activity_Haidao.powerItemId, this.onItemFreshHandler);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
        }

        public show(): void {
            if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.HaiDao_Yindao_Checked)) {
                UI_Activity_Yindao.Inst.show();
                UI_Activity_Haidao.duringGuide = true;
            }
            this.setCurrentStage(UI_Activity_Haidao.activityServerData.zone);
            this.visibleStageEnterBtn(true);
            this.onUpdateData();
            this.showPopupBg(false);
            this.freshTopInfo();
            this.refreshNewsDisplay();
            this.moveTo(this.currentAtStageId);
            this.enable = true;
            this.aniShow.play(0, false);
            this.isLock = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.isLock = false;
            });
            this.refreshStageCloud(false);
            this.effectAni.Play('fx_ui_activity_012_000');
            this.effectActivity = game.FrontEffect.Inst.create_ui_effect(this.me.getChildByName('com_effect') as Laya.Sprite, 'scene/effect_haidao.lh', new Laya.Point(0, 0), 1);
            this.effectActivity.effect.root.active = false;
            view.AudioMgr.PlayAudio(10133);
            view.AudioMgr.StopMusic(0);
            this.stopBgm();
            this.playBgm();
        }

        public hide(isAnim = true) {
            this.removeEvent();
            if (isAnim) {
                this.isLock = true;
                this.aniHide.play(0, false);
                UI_Lobby.Inst.enable = true;
                this.effectAni.Play('fx_ui_activity_012_000_1');
                Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                    this.isLock = false;
                    this.enable = false;
                    if (this.effectActivity) {
                        this.effectActivity.destory();
                        this.effectActivity = null;
                    }
                });
            }
            else {
                UI_Lobby.Inst.enable = true;
                this.enable = false;
            }
        }


        public removeNotifyActivityChangeListener() {
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
        }


        public onUpdateData() {
            // app.Log.log("海岛活动服务器数据" + JSON.stringify(UI_Activity_Haidao.activityServerData))
            //刷新当前每个区域的数据
            let stagesServerData = UI_Activity_Haidao.activityServerData.zones;
            for (let index = 0; index < stagesServerData.length; index++) {
                let stageServerData = stagesServerData[index];
                let stageLocalData = UI_Activity_Haidao.stageDataDic.get(stageServerData.id);
                stageLocalData.isStageUnlock = true;

                if (stageServerData.goods_records) {
                    let todayShopItems = stageLocalData.todayShopItems;
                    // console.log("今日商店商品数据", todayShopItems);

                    for (let i = 0; i < stageServerData.goods_records.length; i++) {

                        let good = stageServerData.goods_records[i];
                        if (todayShopItems.has(good.goods_id)) {
                            let shopItemData = todayShopItems.get(good.goods_id);
                            if (game.Tools.isPassedRefreshTimeServer(good.update_time)) {
                                shopItemData.count = shopItemData.itemShopConfig.count - good.count;
                            }
                            else {
                                shopItemData.count = shopItemData.itemShopConfig.count;
                            }
                        }

                    }
                }


                //设置当前持有金钱
                if (stageServerData.currency_used) {
                    if (game.Tools.isPassedRefreshTimeServer(stageServerData.currency_used.update_time)) {
                        stageLocalData.freshMoney(stageServerData.currency_used.count);
                    }
                    else {
                        stageLocalData.freshMoney(0);
                    }

                }
                else {
                    stageLocalData.freshMoney(0);
                }

            }



            //刷新当前每个背包的数据
            let bagsServerData = UI_Activity_Haidao.activityServerData.bags;
            for (let index = 0; index < bagsServerData.length; index++) {
                const bagServerData = bagsServerData[index];
                let bagData = UI_Activity_Haidao.bagDataDic.get(bagServerData.id);
                bagData.isUnlock = true;
                bagData.setMatrix(GridBagUtils.Inst.convertStringToMatrix(bagServerData.matrix));
                //处理道具数据
                if (bagServerData.items) {
                    let items: Array<ItemDataInBag> = new Array();
                    for (let itemIndex = 0; itemIndex < bagServerData.items.length; itemIndex++) {
                        let itemServerData = bagServerData.items[itemIndex];
                        let itemConfing = UI_Activity_Haidao.itemConfigDic.get(itemServerData.goods_id);
                        let baseMatrix = GridBagUtils.Inst.convertStringToMatrix(itemConfing.matrix);

                        let itemEntity = GridBagUtils.Inst.getItem(itemServerData.goods_id, baseMatrix);
                        itemEntity.rotate = itemServerData.rotate / 90;
                        let item: ItemDataInBag = new ItemDataInBag(itemServerData.goods_id, itemServerData.id, bagServerData.id, itemServerData.pos[1], itemServerData.pos[0], itemEntity);
                        item.price = itemServerData.price;
                        items.push(item);
                    }
                    bagData.setItemData(items);
                }
            }

            Laya.stage.event(Haidao_EventId.UPDATE_DATA);
            // console.log("海岛活动服务器数据后", JSON.stringify(UI_Activity_Haidao.bagDataDic));
            this.refreshRedPoints();
            this.freshStage();
            this.setCharCount(bagsServerData.length);
        }





        public showPopupBg(isVisible: boolean, isAnim: boolean = false) {
            if (isAnim && isVisible != this.pageBg.visible) {
                if (isVisible) {
                    this.pageBg.visible = true;
                    this.isLock = true;
                    UIBase.anim_alpha_in(this.pageBg, {}, 250, 0, Laya.Handler.create(this, () => {
                        this.isLock = false;
                    }));
                } else {
                    UIBase.anim_alpha_out(this.pageBg, {}, 250, 0, Laya.Handler.create(this, () => {
                        this.isLock = false;
                        this.pageBg.visible = false;
                    }));
                }
            }
            else {
                this.pageBg.alpha = 1;
                this.pageBg.visible = isVisible;
            }


        }

        /**
         * 初始化地区，显示名字和解锁状态
         */
        private initMap() {
            //初始化商店
            let shop = this.mapStages.getChildByName('shop') as Laya.Sprite;
            this.popChar = shop.getChildByName("pop_char") as Laya.Sprite;
            this.stageRedPoints = [];

            cfg.activity.island_map.forEach((config) => {
                let stageUI = shop.getChildByName('stage' + config.zone_id) as Laya.Button;
                this.stageRedPoints.push(stageUI.getChildByName('red_point') as Laya.Image);
                let newBtn = new UI_Button(stageUI);
                newBtn.title = game.Tools.strOfLocalization(config.zone_name);
                let txtStageTitle = stageUI.getChildByName('title') as Laya.Label;
                let bgWidth = txtStageTitle.textField.width > 170 ? txtStageTitle.textField.width + 60 : 234;
                (stageUI.getChildByName('up') as Laya.Image).width = bgWidth;
                (stageUI.getChildByName('gray') as Laya.Image).width = bgWidth;
                (stageUI.getChildByName('btn') as Laya.Button).width = bgWidth;
                (stageUI.getChildByName('lock') as Laya.Image).x = 117 - (bgWidth / 2) + 12;
                let enterBtn: UI_Button = new UI_Button(stageUI.getChildByName('shop_btn') as Laya.Sprite, true);
                enterBtn.setClickListener(new Laya.Handler(this, () => {
                    if (this.isLock) {
                        return;
                    }
                    UI_Activity_Haidao_Page_Shop.Inst.show();
                }));
                enterBtn.visible = false;
                newBtn["enterBtn"] = enterBtn;
                this.stageBtns.push(newBtn);
                newBtn.setClickListener(new Laya.Handler(this, () => {
                    if (this.isLock) {
                        return;
                    }
                    this.onClickStage(config.zone_id);
                }))
                this.stagePopCharPos.set(config.zone_id, new Laya.Vector2(stageUI.x, stageUI.y - 90));

            });
            // 初始化剧情
            let spotUI = this.mapStages.getChildByName('spot').getChildByName("stage_youlechang") as Laya.Sprite;
            this.redPointSpotLeft = this.mapStages.getChildByName('spot').getChildByName('redpoint') as Laya.Sprite;
            this.spotBtn = new UI_Button(spotUI, true);
            let txtSpotTitle = spotUI.getChildByName('title') as Laya.Label;
            (spotUI.getChildByName('up') as Laya.Image).width = txtSpotTitle.textField.width > 170 ? txtSpotTitle.textField.width + 60 : 234;
            (spotUI.getChildByName('btn') as Laya.Button).width = txtSpotTitle.textField.width > 170 ? txtSpotTitle.textField.width + 60 : 234;
            this.spotBtn.setClickListener(new Laya.Handler(this, () => {
                this.onClickSpot();
            }));
        }

        private freshStage() {
            for (let index = 0; index < this.stageBtns.length; index++) {
                let stage = this.stageBtns[index];
                let isLock = !UI_Activity_Haidao.stageDataDic.get(index).isStageUnlock;
                stage.grayed = isLock;
                (stage.me.getChildByName('lock') as Laya.Sprite).visible = !!isLock;
            }
        }

        public refreshStageCloud(anim: boolean = false) {
            for (let index = 0; index < this.stageBtns.length; index++) {
                let isLock = !UI_Activity_Haidao.stageDataDic.get(index).isStageUnlock;
                let cloud = this.clouds.getChildByName("cloud" + index) as Laya.Sprite;
                if (anim && !isLock && cloud.visible && this.aniClouds[index]) {
                    this.isLock = true;
                    this.aniClouds[index].play(0, false);
                    Laya.timer.once(this.aniClouds[index].count * this.aniClouds[index].interval, this, () => {
                        cloud.visible = false;
                        this.isLock = false;
                    })
                } else {
                    cloud.visible = isLock;
                }
            }
        }

        private freshTopInfo() {
            //刷新钱的数量
            let moneyCount = UI_Activity_Haidao.duringGuide ? 0 : UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId);
            this.moneyCountLabel.text = moneyCount.toString();

            //刷新体力的数量
            let powerCount = UI_Activity_Haidao.duringGuide ? 0 : UI_Bag.get_item_count(UI_Activity_Haidao.powerItemId);
            this.powerCountLabel.text = powerCount.toString();
        }

        public refreshRedPoints() {
            this.redPointSpotLeft.visible = UI_Activity_Haidao_Spot.haveRedPoint();
            this.stageRedPoints.forEach((redPoint, index) => {
                let taskId = UI_Activity_Haidao.stageDataDic.get(index).stageConfig.unlock_task_id;
                redPoint.visible = taskId && UI_Activity_Haidao_Rewards.getUnLockStateByTaskId(taskId);
            })
            this.redPointTask.visible = UI_Activity_Haidao_Task.haveRedPoint();
            //剧情按钮不加红点显示旗袍
            this.redPointSpot.visible = false;
            this.redPointNews.visible = UI_Activity_Haidao_News.haveRedPoint();
            this.redPointReward.visible = UI_Activity_Haidao_Rewards.haveRedPoint();
            this.redPointBag.visible = UI_Activity_Haidao_Page_Bag.haveRedPoint();
        }


        private onClickTask() {
            if (this.isLock) {
                return;
            }
            this.pageTask.show();
            // UI_Activity_Haidao_Task.Inst.show();
            // if (!UI_Activity.activity_is_running()) {
            //     UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3944));
            //     return;
            // }
        }

        private onClickNews() {
            if (this.isLock) {
                return;
            }
            this.pageNews.show();
        }

        private onClickSpot() {
            if (this.isLock) {
                return;
            }
            this.pageSpot.show();
        }

        private onClickReward() {
            if (this.isLock) {
                return;
            }
            this.pageReward.show();
        }

        private onClickBag() {
            if (this.isLock) {
                return;
            }

            this.pageBag.show();
        }

        private onClickStage(stageId: number) {
            if (this.isLock) {
                return;
            }

            //检测当前是否解锁,未解锁，弹出提示窗口
            if (!UI_Activity_Haidao.stageDataDic.get(stageId).isStageUnlock) {
                let stageData = UI_Activity_Haidao.stageDataDic.get(stageId);
                if (stageData.stageConfig.unlock_task_id && UI_Activity_Haidao_Rewards.getUnLockStateByTaskId(stageData.stageConfig.unlock_task_id)) {
                    UI_Activity_Haidao_Rewards.receiveRewardsByTaskId(stageData.stageConfig.unlock_task_id);
                    return;
                }
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4324, [stageData.unlockCount.toString()]));
                return;
            }
            this.visibleStageEnterBtn(false);
            this.currentSelectStageId = stageId;

            this.stageDetail.show(new Laya.Handler(this, () => {
                this.visibleStageEnterBtn(true);
            }));

        }

        private onClickHelp() {
            if (this.isLock) {
                return;
            }
            this.pageRules.show();
        }

        private onClickItemInfo(itemId: number) {
            if (this.isLock) {
                return;
            }
            UI_ItemDetail.Inst.show(itemId);
        }

        private onClickReturn() {
            if (this.isLock) {
                return;
            }
            this.hide();

        }

        public moveTo(stageId: number, onMoveFinish: Laya.Handler | null = null, isAnim: boolean = false) {
            this.visibleStageEnterBtn(false);
            let pos = this.stagePopCharPos.get(stageId);
            this.popChar.x = pos.x;
            this.popChar.y = pos.y;
            let comLine = this.mapStages.getChildByName('line') as Laya.Sprite;
            comLine._childs.forEach(child => child.visible = false);
            if (isAnim && this.currentAtStageId != stageId) {
                view.AudioMgr.PlayAudio(10132);
                this.isLock = true;
                let route = UI_Activity_Haidao.stageDataDic.get(this.currentAtStageId).stageConfig.route[stageId].split(',');
                let index = 0;
                let endFunc = () => {
                    comLine._childs.forEach(child => child.visible = false);
                    this.setCurrentStage(stageId);
                    if (onMoveFinish != null) {
                        onMoveFinish.run();
                    }
                    this.isLock = false;
                };
                let delayTimes = [0];
                while (index < route.length - 1) {
                    // let reverse = route[index] > route[index + 1];
                    let reverse = false;
                    let comLinesName = route[index] > route[index + 1] ? route[index + 1] + '' + route[index] : route[index] + '' + route[index + 1];
                    let animName = 'anim_' + route[index] + '' + route[index + 1];
                    let anim = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidaoUI)[animName];
                    anim.wrapMode = reverse ? 1 : 0;
                    let delay = anim.count * anim.interval;
                    delayTimes.push(delayTimes[delayTimes.length - 1] + delay);
                    Laya.timer.once(delayTimes[index], this, () => {
                        (comLine.getChildByName(comLinesName) as Laya.Sprite).visible = true;
                        anim.play(reverse ? anim.count : 0, false);
                    });
                    index++;
                }
                Laya.timer.once(delayTimes[delayTimes.length - 1], this, endFunc);
            }
            else {
                // this.currentAtStageId = stageId;
                this.setCurrentStage(stageId);
                this.visibleStageEnterBtn(true);
                if (onMoveFinish != null) {
                    onMoveFinish.run();
                }
            }


        }


        /**
         * 获取背包内的道具成本均价
         * @param itemId 
         * @returns 
         */
        public getItemCostInBag(itemId: number): number {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let allPrice = 0;
            let allCount = 0;
            for (let index = 0; index < keys.length; index++) {
                let bagData = UI_Activity_Haidao.bagDataDic.get(keys[index]).findItems(itemId);
                allCount += bagData.length;
                for (let itemIndex = 0; itemIndex < bagData.length; itemIndex++) {
                    let item = bagData[itemIndex];
                    allPrice += item.price;
                }
            }
            return allCount == 0 ? 0 : allPrice / allCount;
        }

        /**
         * 获取背包内的道具数量
         * @param itemId 
         * @returns 
         */
        public getItemsCountInBag(itemId: number): number {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let allCount = 0;
            for (let index = 0; index < keys.length; index++) {
                let bagData = UI_Activity_Haidao.bagDataDic.get(keys[index]).findItems(itemId);
                allCount += bagData.length;

            }
            return allCount;
        }

        public getItemsInBag(itemId: number, count: number) {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let items: ItemDataInBag[] = new Array();
            for (let index = 0; index < keys.length; index++) {
                let bagData = UI_Activity_Haidao.bagDataDic.get(keys[index]).findItems(itemId);
                bagData.forEach((item) => {
                    items.push(item);
                })
            }
            let result: ItemDataInBag[] = new Array();
            for (let index = 0; index < count; index++) {
                result.push(items[index]);
            }
            return result;
        }

        public getItemByServerId(serverId: number): ItemDataInBag {
            //遍历所有的背包
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            for (let index = 0; index < keys.length; index++) {
                let bag = UI_Activity_Haidao.bagDataDic.get(keys[index]);
                let items = bag.findItemByServerId(serverId)
                if (items.length > 0) {
                    return items[0];
                }
            }
            return null;
        }


        //控制新闻条轮播新闻
        public refreshNewsDisplay() {
            let activityDay = UI_Activity.getActivityDeltaDay(UI_Activity_Haidao.activityId);
            this.newsData = null;
            if (UI_Activity_Haidao.newsConfigDic.get(activityDay + 1)) {
                this.newsData = game.Tools.deepCopy(UI_Activity_Haidao.newsConfigDic.get(activityDay + 1)) as lqc.Sheet_Activity_IslandNews[];
            }
            this.news.visible = false;
            if (!this.newsData || UI_Activity_Haidao.duringGuide) {
                return;
            }
            this.newsData.sort(function () {
                return Math.random() - 0.5;
            });
            Laya.timer.clearAll(this.news);
            let index = 0;
            this.refreshNewsAnim(index);
            Laya.timer.loop(2 * 60 * 1000, this.news, () => {
                //如果已经不是当天的新闻了
                if (this.newsData[0] && (this.newsData[0].show_day != UI_Activity.getActivityDeltaDay(UI_Activity_Haidao.activityId))) {
                    Laya.timer.clearAll(this.news);
                    this.refreshNewsDisplay();
                } else {
                    index = index == this.newsData.length - 1 ? 0 : index + 1;
                    this.refreshNewsAnim(index);
                }
            });
        }

        //控制新闻条展示动画的
        private refreshNewsAnim(index: number) {
            Laya.Tween.clearAll(this.news);
            Laya.Tween.clearAll(this.newsDesc);
            this.news.visible = true;
            this.news.alpha = 0;
            this.news.y = 905;
            UIBase.anim_alpha_in(this.news, { y: 50 }, 150, 1000, null, Laya.Ease.quadOut);
            this.newsDesc.width = 5000;
            let color = this.newsData[index].effect > 100 ? '#df2d36' : '#4fb37c';
            this.newsDesc.innerHTML = game.Tools.ParseText(game.Tools.eventStrOfLocalization(this.newsData[index].news_desc), color);
            this.newsDesc.width = this.newsDesc.contextWidth;
            this.newsDesc.x = 570;
            let duration = this.newsDesc.width * 20;
            Laya.Tween.to(this.newsDesc, { x: -3 - this.newsDesc.width }, duration, null, Laya.Handler.create(this, () => {
                UIBase.anim_alpha_out(this.news, { y: 50 }, 150, 0, Laya.Handler.create(this, () => {
                    this.news.visible = false;
                }), Laya.Ease.quadOut);
            }), 1150);
        }

        public showQuitTip(tipMsg: string, confirmStr: string, onClickConfirm: Laya.Handler) {
            this.quitTip.show(tipMsg, confirmStr, onClickConfirm);
        }

        private setCharCount(count: number) {
            let childs = this.popChar._childs;
            for (let index = 0; index < childs.length; index++) {
                const element = childs[index];
                element.visible = index == count - 1;
            }
        }

        public showGuideNews() {
            Laya.Tween.clearAll(this.news);
            Laya.Tween.clearAll(this.newsDesc);
            this.news.visible = true;
            this.news.alpha = 1;
            this.news.y = 905;
            this.newsDesc.width = 5000;
            this.newsDesc.innerHTML = game.Tools.ParseText(game.Tools.strOfLocalization(4447), '#df2d36');
            this.newsDesc.width = this.newsDesc.contextWidth;
            let duration = this.newsDesc.width * 20;
            this.newsDesc.x = 570;
            Laya.Tween.to(this.newsDesc, { x: -3 - this.newsDesc.width }, duration);
            Laya.timer.loop(duration, this.news, () => {
                this.newsDesc.x = 570;
                Laya.Tween.to(this.newsDesc, { x: -3 - this.newsDesc.width }, duration);
            })
        }

        public refreshPreGuideState(type: E_Act_Yindao_Type) {
            switch (type) {
                case E_Act_Yindao_Type.showNewsTip: {
                    Laya.timer.clearAll(this.news);
                    this.news.visible = false;
                }
            }
        }

        public refreshGuideState(type: E_Act_Yindao_Type) {
            switch (type) {
                case E_Act_Yindao_Type.showShopGoods: {
                    this.pageShop.showGuide();
                    break;
                }
                case E_Act_Yindao_Type.showNewsTip: {
                    this.pageShop.hide();
                    this.showGuideNews();
                    //刷新钱的数量
                    let moneyCount = UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId);
                    this.moneyCountLabel.text = moneyCount.toString();
                    //刷新体力的数量
                    let powerCount = UI_Bag.get_item_count(UI_Activity_Haidao.powerItemId);
                    this.powerCountLabel.text = powerCount.toString();
                    break;
                }
            }
            this.pageShop.refreshGuideState(type);
        }

        public onGuideEnd() {
            UI_Activity_Haidao.duringGuide = false;
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.HaiDao_Yindao_Checked, 1);
            this.refreshNewsDisplay();
            this.freshTopInfo();
            this.pageRules.show();
        }

        public setCurrentStage(index: number) {
            this.currentAtStageId = index;

        }

        public visibleStageEnterBtn(visible: boolean) {
            // console.log("显示进入按钮",visible);

            for (let index = 0; index < this.stageBtns.length; index++) {
                const stageBtn = this.stageBtns[index];
                stageBtn["enterBtn"].visible = this.currentAtStageId == index && visible;
            }
        }

        public backToMain() {
            this.visibleStageEnterBtn(true);
        }


        public onActivityFinish(msg) {
            if (this.enable == false) {
                if (UI_Lobby.Inst.enable) {
                    UI_Lobby.Inst.refreshInfo();
                }
                return;
            }
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_Haidao.activityId) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            UI_Activity_Yindao.Inst.enable = false;
                            UI_Activity_Haidao_Page_Shop.Inst.hide(true);
                            this.hide(false);
                        }))
                        return;
                    }
                }
            }

        }

    }

}