enum UI_Activity_Haidao_GridState {
    EMPTY = 0,
    WRONG = 1,
    RIGHT = 2,
    LOCK_DISELECT = 3,
    LOCK_SELECT = 4,
    LOCK_DEFAULT = 5,
}
module uiscript {

    export class UI_Activity_Haidao_BagSelectTabButton extends UI_Component {
        public selectImg: Laya.Image;
        public diselectImg: Laya.Image;
        public lockImg: Laya.Image;
        public button: Laya.Button;
        public onCreate(): void {
            this.selectImg = this.me.getChildByName('select') as Laya.Image;
            this.diselectImg = this.me.getChildByName('diselect') as Laya.Image;
            this.lockImg = this.me.getChildByName('lock') as Laya.Image;
            this.button = this.me as Laya.Button;
        }

        public onSelect() {
            // console.log(this.me.name,"onSelect");
            
            this.lockImg.visible = false;
            this.selectImg.visible = true;
            this.diselectImg.visible = false;
        }

        public onDiselect() {
            // console.log(this.me.name, "onDiselect");
            this.lockImg.visible = false;
            this.selectImg.visible = false;
            this.diselectImg.visible = true;
        }

        public onLock() {
            // console.log(this.me.name, "onLock");
            this.lockImg.visible = true;
            this.selectImg.visible = false;
            this.diselectImg.visible = false;
        }



    }

    export class UI_Activity_Haidao_BagsContainer extends UI_Component {

        private resetBtn: Laya.Button;
        private mineMoney: Laya.Label;
        private moneyInfo: Laya.Button;

        private bagsData: basic.Dictionary<number, GridBag>;
        private bags: Array<UI_Activity_Haidao_Bag>;
        private bagTabGroup: UI_TabGroup_Base;

        private bagTabBtns: Array<UI_Activity_Haidao_BagSelectTabButton>;
        private currentSelectBagIndex: number;

        public get currentSelectBag(): number {
           
            return this.currentSelectBagIndex;
        }
        public onClickGrid: Laya.Handler;
        public onClickGridDown: Laya.Handler;
        public onTabChange: Laya.Handler;
        public onClickReset: Laya.Handler;
        public onCreate(): void {
            this.bags = new Array();

            this.bagTabBtns = new Array();
            for (let index = 0; index < UI_Activity_Haidao.bagIdArray.length; index++) {
                let btnIndex = index;
                let bagUI = this.me.getChildByName('bag' + btnIndex) as Laya.Sprite;
                let newBag = new UI_Activity_Haidao_Bag(bagUI);
                newBag.onGridClick = new Laya.Handler(this, () => {
                    this.onClickGrid?.run();
                });
                newBag.onGridMouseDown = new Laya.Handler(this, () => {
                    this.onClickGridDown?.run();
                });
                this.bags.push(newBag);
                let bagTab = new UI_Activity_Haidao_BagSelectTabButton(this.me.getChildByName('tabs').getChildByName('bag' + btnIndex) as Laya.Sprite);
                this.bagTabBtns.push(bagTab);
            }
            this.mineMoney = this.me.getChildByName('mine_money_count').getChildByName("value_text") as Laya.Label;
            this.resetBtn = this.me.getChildByName('reset_btn') as Laya.Button;
            this.resetBtn.clickHandler = new Laya.Handler(this, () => {
                this.onClickReset?.run();
            });
            this.moneyInfo = this.me.getChildByName('mine_money_count').getChildByName("info_btn") as Laya.Button;
            this.moneyInfo.clickHandler = new Laya.Handler(this, () => {
                UI_ItemDetail.Inst.show(UI_Activity_Haidao.moneyItemId);
            });
            // this.bagTabGroup.init();
        }

        public setData(bagsData: basic.Dictionary<number, GridBag>): void {
            let oldSelect: number = 0;
            if (this.bagTabGroup) {
                oldSelect = this.bagTabGroup.selectedIndex;
            }
            this.bagsData = bagsData;
            this.bagTabGroup = new UI_TabGroup_Base();
            this.bagTabGroup.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean = false) => {
                this.onBagTabChange(index, btn, manualSwitching);
            };
            //处理每个背包的数据
            for (let index = 0; index < this.bags.length; index++) {
                let bag = this.bags[index];
                let bagId = UI_Activity_Haidao.bagIdArray[index];
                let bagData = this.bagsData.get(bagId);
                bag.setData(bagData);
                let tabBtn = this.bagTabBtns[index];
                (tabBtn.button.getChildByName('red_point') as Laya.Image).visible = bagData.bagConfig.unlock_task_id && UI_Activity_Haidao_Rewards.getUnLockStateByTaskId(bagData.bagConfig.unlock_task_id);     
                if (bagData.isUnlock) {
                    this.bagTabGroup.AddTabButton(tabBtn.button);
                }
                else {
                    tabBtn.button.clickHandler = new Laya.Handler(this, () => {
                        if (bagData.bagConfig.unlock_task_id && UI_Activity_Haidao_Rewards.getUnLockStateByTaskId(bagData.bagConfig.unlock_task_id)) {
                            UI_Activity_Haidao_Rewards.receiveRewardsByTaskId(bagData.bagConfig.unlock_task_id)
                            return;
                        }
                        UI_Activity_Haidao.Inst.showLockBagTipPopup(bagId);
                    });
                    
                    tabBtn.onLock();
                }

            }


            this.bagTabGroup.init();
            this.bagTabGroup.selectedIndex = oldSelect;



        }

        private onBagTabChange(index: number, btn: Laya.Button, manualSwitching: boolean = false) {
            let btnName:string = btn.name;
            let trueIndex: number = 0;
            if (btnName == "bag0") {
                trueIndex = 0;
            } else if (btnName == "bag1") {
                trueIndex = 1;
            } else {
                trueIndex = 2;
            }
            let tabBtn = this.bagTabBtns[trueIndex];
            if (index == this.bagTabGroup.selectedIndex) {
                this.currentSelectBagIndex = trueIndex;
                tabBtn.onSelect();
                this.bags.forEach((v, i) => {
                    v.visible = i == trueIndex;
                })
                this.onTabChange.runWith(manualSwitching);
                
            }
            else {
                tabBtn.onDiselect();
            }
        }

        public setMoney(count: number) {
            this.mineMoney.text = count.toString();
        }

        public getBagUI(): UI_Activity_Haidao_Bag {
            return this.bags[this.currentSelectBagIndex];
        }

        public getBagUIById(id: number): UI_Activity_Haidao_Bag {
            let index = UI_Activity_Haidao.bagIdArray.indexOf(id);
            if (index != -1) {
                return this.bags[index];
            }
            return null;
        }




    }

    class UI_Grid extends UI_Component {

        private emptyImage: Laya.Image;
        private wrongImage: Laya.Image;
        private rightImage: Laya.Image;
        private lockState: Laya.Sprite;
        private selectImg: Laya.Image;
        private diselectImg: Laya.Image;
        private unlockIconImg: Laya.Image;
        private unlockPriceText: Laya.Label;
        private checkArea: Laya.Box;
        private currentState: UI_Activity_Haidao_GridState;
        public unlockPrice: number = 0;
        /**
         * 格子左上角全局坐标
         */
        public globalPos: Laya.Vector2;


        public set State(state: UI_Activity_Haidao_GridState) {
            this.currentState = state;
            this.fresh();
        }

        public get State(): UI_Activity_Haidao_GridState {
            return this.currentState;
        }

        public onCreate(): void {
            this.emptyImage = this.me.getChildByName('empty') as Laya.Image;
            this.wrongImage = this.me.getChildByName('wrong') as Laya.Image;
            this.rightImage = this.me.getChildByName('right') as Laya.Image;
            this.checkArea = this.me.getChildByName('checkArea') as Laya.Image;
            this.lockState = this.me.getChildByName('locked') as Laya.Sprite;

            this.selectImg = this.lockState.getChildByName('select') as Laya.Image;
            this.diselectImg = this.lockState.getChildByName('diselect') as Laya.Image;
            this.unlockPriceText = this.lockState.getChildByName('price') as Laya.Label;
            this.unlockIconImg = this.lockState.getChildAt(2) as Laya.Image;
            this.currentState = UI_Activity_Haidao_GridState.EMPTY;
            this.globalPos = game.Tools.posLocalToGlobal(this.me.parent as Laya.Sprite, this.me.x, this.me.y);
        }

        public setPrice(price: number) {
            this.unlockPriceText.text = price.toString();
            this.unlockPrice = price;
            this.unlockPriceText.color = price <= UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId) ? "#303D6E" : "#DF2D36";
        }

        private fresh() {
            // console.log("fresh");
            
            this.emptyImage.visible = this.currentState == UI_Activity_Haidao_GridState.EMPTY;
            this.wrongImage.visible = this.currentState == UI_Activity_Haidao_GridState.WRONG;
            this.rightImage.visible = this.currentState == UI_Activity_Haidao_GridState.RIGHT;
            this.lockState.visible = this.currentState == UI_Activity_Haidao_GridState.LOCK_SELECT || this.currentState == UI_Activity_Haidao_GridState.LOCK_DISELECT || this.currentState == UI_Activity_Haidao_GridState.LOCK_DEFAULT;;
            this.unlockIconImg.visible = this.currentState != UI_Activity_Haidao_GridState.LOCK_DEFAULT;
            this.unlockPriceText.visible = this.currentState != UI_Activity_Haidao_GridState.LOCK_DEFAULT;
            this.selectImg.visible = this.currentState == UI_Activity_Haidao_GridState.LOCK_SELECT;
            this.diselectImg.visible = this.currentState == UI_Activity_Haidao_GridState.LOCK_DISELECT || this.currentState == UI_Activity_Haidao_GridState.LOCK_DEFAULT;

        }

        public isInGrid(pos: Laya.Vector2) {
            return this.checkArea.hitTestPoint(pos.x, pos.y);
        }

    }

    export class UI_Activity_Haidao_Bag extends UI_Component {

        private gridParent: Laya.Sprite;
        private gridTemplete: Laya.Sprite;
        private bagData: GridBag;
        public bagId: number;
        private grids: UI_Grid[][];
        private itemsInBag: UI_Activity_Haidao_Item[];
        public currentSelectGrid: Laya.Vector2;
        public onGridClick: Laya.Handler;
        public onGridMouseDown: Laya.Handler;

        public onCreate(): void {
            this.grids = new Array();
            this.gridParent = this.me.getChildByName('grids') as Laya.Sprite;
            this.gridTemplete = this.gridParent.getChildByName('grid') as Laya.Sprite;
            this.gridTemplete.visible = false;
            let tempCopy = this.gridTemplete.scriptMap['capsui.UICopy'] as capsui.UICopy;
            //生成 5 * 5的格子
            for (let i = 0; i < UI_Activity_Haidao.bagMaxWidth; i++) {
                this.grids[i] = new Array();
                for (let j = 0; j < UI_Activity_Haidao.bagMaxHeight; j++) {
                    let gridUI = tempCopy.getNodeClone();
                    this.gridParent.addChild(gridUI);
                    gridUI.pos(j * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace), i * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace));
                    gridUI.name = `grid(${i},${j})`;
                    let newGrid = new UI_Grid(gridUI);
                    newGrid.State = UI_Activity_Haidao_GridState.EMPTY;
                    this.grids[i][j] = newGrid;
                    gridUI.on(Laya.Event.CLICK, this, () => {

                        this.currentSelectGrid = new Laya.Vector2(i, j);
                        this.onGridClick?.run();
                    })
                    gridUI.on(Laya.Event.MOUSE_DOWN, this, () => {
                        this.onGridMouseDown?.run();
                    })

                }

            }
            this.currentSelectGrid = new Laya.Vector2(-1, -1);
            this.itemsInBag = new Array();


        }

        public getGridPosition(x: number, y: number): Laya.Point {
            let gridUI = this.grids[x][y].me;
            return new Laya.Point(gridUI.x + (this.gridParent.x + (this.gridParent.parent as Laya.Sprite).x), gridUI.y + (this.gridParent.y + (this.gridParent.parent as Laya.Sprite).y));
        }

        public setData(bagData: GridBag) {
            this.bagData = bagData;
            this.bagId = this.bagData.id;

            this.itemsInBag = new Array();
            this.freshGrid();
        }



        private freshGrid() {
            let matrixData = this.bagData.currentMatrix;
            for (let i = 0; i < UI_Activity_Haidao.bagMaxWidth; i++) {
                for (let j = 0; j < UI_Activity_Haidao.bagMaxHeight; j++) {
                    let grid = this.grids[i][j];
                    let matrix = matrixData[i][j];
                    grid.visible = matrix == 0;
                }
            }
        }

        public onDisable(): void {
            this.currentSelectGrid = new Laya.Vector2(-1, -1);
        }



        public getGrid(x: number, y: number): UI_Grid {
            return this.grids[x][y];
        }


        /**
         * 获取某个坐标最近的格子
         * @param pos 全局坐标
         * @returns 格子的index,如果是-1,-1，则不在背包内
         */
        public getNearBy(pos: Laya.Vector2) {

            for (let i = 0; i < UI_Activity_Haidao.bagMaxWidth; i++) {
                for (let j = 0; j < UI_Activity_Haidao.bagMaxHeight; j++) {
                    let grid = this.grids[i][j];
                    if (grid.isInGrid(pos)) {
                        return new Laya.Vector2(i, j);
                    }
                    // if (grid.me.visible && grid.me.hitTestPoint(pos.x, pos.y)) {
                    //     return new Laya.Vector2(i, j);
                    // }
                }
            }
            return new Laya.Vector2(-1, -1);
        }



        public freshGridsState(effectPoses: Laya.Vector2[]) {
            for (let i = 0; i < UI_Activity_Haidao.bagMaxWidth; i++) {
                for (let j = 0; j < UI_Activity_Haidao.bagMaxHeight; j++) {
                    let grid = this.grids[i][j];
                    if (grid.me.visible) {
                        let effect = effectPoses.filter((v) => {
                            return v.x == i && v.y == j;
                        })
                        if (effect.length > 0) {
                            let martixData = this.bagData.currentItemMatrix[i][j];
                            if (martixData >= 1) {
                                grid.State = UI_Activity_Haidao_GridState.WRONG;
                                // console.log("设置格子为错误", i, j, this.bagData.currentItemMatrix);

                            }
                            else {
                                grid.State = UI_Activity_Haidao_GridState.RIGHT;
                                // console.log("设置格子为正确", i, j);
                            }
                        }
                        else {
                            grid.State = UI_Activity_Haidao_GridState.EMPTY;
                            // console.log("设置格子为空", i, j);
                        }

                    }
                }
            }
        }


        /**
         * 向背包内添加道具UI
         * @param itemUI 
         * @param posX 
         * @param posY 
         */
        public addItemUI(itemUI: UI_Activity_Haidao_Item, posX: number, posY: number) {
            itemUI.bagId = this.bagId;
            itemUI.bagPosX = posX;
            itemUI.bagPosY = posY;
            this.itemsInBag.push(itemUI);

            //如果背包里没有则添加数据，如果背包里有了，则改变数据
            let itemInBag = this.bagData.findItemByServerId(itemUI.serverId);
            if (itemUI.serverId == -1 || itemInBag.length == 0) {
                this.bagData.addItemInBag(itemUI.itemData, posX, posY);
            }
            else {
                itemInBag.forEach((v) => {
                    v.startPosX = posX;
                    v.startPosY = posY;
                    v.itemLocalData = itemUI.itemData;
                })
                this.bagData.freshCurrentItemMatrix();

            }

        }




        public removeItem(itemUI: UI_Activity_Haidao_Item) {
            // this.itemLayer.removeChild(itemUI.me);
            game.Tools.removeFromArray(this.itemsInBag, itemUI)
            let itemInBag = this.bagData.findItem(itemUI.itemData);
            this.bagData.removeItem(itemInBag[0]);
            itemUI.bagId = -1;
            // console.log("移除了道具", itemUI, "当前矩阵为", this.bagData.currentItemMatrix, itemInBag.length);
        }


        public isGridEmpty(x: number, y: number): boolean {
            //当前格子是否解锁且为空
            let isEmpty = this.bagData.currentItemMatrix[x][y] == 0;
            return isEmpty;
        }

        public isGridsEmpty(gridsIndex: Laya.Vector2[]):boolean {
           
            for (let index = 0; index < gridsIndex.length; index++) {
                const element = gridsIndex[index];
                if (!this.isGridEmpty(element.x, element.y)) {
                    return false;
                }
            }
            return true;
        }




        public showUpdate() {
            
            // console.log("showUpdate");
            
            for (let i = 0; i < UI_Activity_Haidao.bagMaxWidth; i++) {
                for (let j = 0; j < UI_Activity_Haidao.bagMaxHeight; j++) {
                    let grid = this.grids[i][j];
                    let isVisible = this.bagData.allMatrix[i][j] == 0;
                    grid.me.visible = isVisible;

                    if (grid.me.visible) {
                        let canExpand = this.bagData.isGridCanExpand(i, j);
                        if (canExpand) {
                            let canGridUpdate = this.canGridUpdate(i, j);
                            if (canGridUpdate) {
                                grid.setPrice(this.bagData.unlockGridCostCount);
                                if (this.currentSelectGrid.x == i && this.currentSelectGrid.y == j) {
                                    grid.State = UI_Activity_Haidao_GridState.LOCK_SELECT;
                                }
                                else {
                                    grid.State = UI_Activity_Haidao_GridState.LOCK_DISELECT;
                                }
                            }
                            else {
                                grid.State = UI_Activity_Haidao_GridState.LOCK_DEFAULT;
                            }


                        }
                        else {
                            grid.State = UI_Activity_Haidao_GridState.EMPTY;
                        }
                    }
                }
            }
        }


        public canGridUpdate(posX: number, posY: number): boolean {
            let canUnlock = false;
            //检测四周的格子是否解锁，只要有一个格子是不锁定的就可以解锁
            let upIndex = posX - 1;
            if (upIndex >= 0) {
                let upGrid = this.getGrid(upIndex, posY);
                if (upGrid.visible == true) {
                    if (upGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                        canUnlock = true;
                    }
                }
            }

            if (!canUnlock) {
                let downIndex = posX + 1;
                if (downIndex < UI_Activity_Haidao.bagMaxHeight) {
                    let downGrid = this.getGrid(downIndex, posY);
                    if (downGrid.visible == true) {
                        if (downGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }

            if (!canUnlock) {
                let leftIndex = posY + 1;
                if (leftIndex < UI_Activity_Haidao.bagMaxHeight) {
                    let leftGrid = this.getGrid(posX, leftIndex);
                    if (leftGrid.visible == true) {
                        if (leftGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }

            if (!canUnlock) {
                let rightIndex = posY - 1;
                if (rightIndex >= 0) {
                    let rightGrid = this.getGrid(posX, rightIndex);
                    if (rightGrid.visible == true) {
                        if (rightGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }
            return canUnlock;
        }


        public clearSelect() {
            this.currentSelectGrid = new Laya.Vector2(-1, -1);
            
        }





    }

}