module uiscript {
    //恭喜弹窗弹出类型
    export enum ECongrateType {
        getItem,
        soldout
    }

    export interface ICongrateData {
        type: ECongrateType;
        itemId?: number;
    }

    export enum ECongrateIcon {
        new_backpack_unlock_huiyeji = 70000003,
        new_backpack_unlock_wangjiro = 70000004,
        new_map_unlock_bread_house = 70000006,
        new_map_unlock_primary_school = 70000007,
        new_map_unlock_mahjong_cultural_street = 70000008,
        new_map_unlock_resort = 70000009,
    }

    export class UI_Activity_Haidao_Congrate extends UIBase {
        public static Inst: UI_Activity_Haidao_Congrate = null;
        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private txtTitle: Laya.Label;
        private txtTip: Laya.Label;
        private txtBuyTip: Laya.Label;
        private comStage: Laya.Sprite;
        // private txtStageName: Laya.Label;
        private imgChara: Laya.Image;
        private imgArea: Laya.Image;
        private btnClose: Laya.Button;
        private aniShowSold: Laya.FrameAnimation;
        private aniShowArea: Laya.FrameAnimation;
        private aniShake: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        public locking: boolean;
        private onClose: Laya.Handler;
        private rewardId: number;
        private type: ECongrateType;

        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_congratUI);
            UI_Activity_Haidao_Congrate.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('maskImg') as Laya.Image;
            this.txtTitle = this.root.getChildByName('title') as Laya.Label;
            this.txtTip = this.root.getChildByName('tip') as Laya.Label;
            this.txtBuyTip = this.root.getChildByName('buy_tip') as Laya.Label;
            this.comStage = this.root.getChildByName('stage') as Laya.Sprite;
            (this.comStage.getChildByName('stage_name') as Laya.Label).visible = false;
            (this.comStage.getChildByName('name_bg') as Laya.Image).visible = false;
            this.imgChara = this.root.getChildByName('chara') as Laya.Image;
            this.imgArea = this.comStage.getChildByName('area') as Laya.Image;
            this.btnClose = this.root.getChildByName('btn') as Laya.Button;
            this.aniShowArea = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_congratUI).huode;
            this.aniShowSold = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_congratUI).chengjiao;
            this.aniShake = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_congratUI).idle;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_congratUI).hide;
            this.btnClose.clickHandler = new Laya.Handler(this, () => {
                //策划要求，成交弹窗根本不锁，可打断出现动画直接关闭
                if (this.type == ECongrateType.soldout) {
                    this.enable = false;
                    return;
                }
                if (this.locking) return;
                this.close();
            });
        }

        //用type判断一下开哪个恭喜弹窗
        public show(type: ECongrateType, onClose?: Laya.Handler) {
            if (this.locking) return;
            this.type = type;
            this.rewardId = null;
            //想显摆一下新道具但是没有新道具就不显示了
            if (type == ECongrateType.getItem && UI_Activity_Haidao_Rewards.newUnLockItemsIds.length == 0) return;
            if (type == ECongrateType.getItem) this.rewardId = UI_Activity_Haidao_Rewards.newUnLockItemsIds[0];
            this.onClose = onClose;
            this.enable = true;
            this.locking = true;
            uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.soldOut, true);
            if (type == ECongrateType.soldout) {
                this.aniShowSold.play(0, false);
                Laya.timer.once(this.aniShowSold.count * this.aniShowSold.interval, this, () => {
                    this.aniShake.play(0, true);
                })
            } else {
                this.aniShowArea.play(0, false);
            }
            view.AudioMgr.PlayAudio(10135);
            //有特效昂不能立马关
            Laya.timer.once(1500, this, () => {
                this.locking = false;
            })
            let isArea = this.rewardId && cfg.item_definition.function_item.get(this.rewardId).type == 4;
            let isBag = this.rewardId && cfg.item_definition.function_item.get(this.rewardId).type == 3;
            this.txtTitle.visible = type != ECongrateType.soldout;
            this.txtTip.visible = type != ECongrateType.soldout;
            this.txtBuyTip.visible = type == ECongrateType.soldout;
            (this.root.getChildByName('buy_tips') as Laya.Sprite).visible = type == ECongrateType.soldout;
            this.comStage.visible = isArea;
            this.imgChara.visible = isBag;
            this.txtTitle.text = isBag ? game.Tools.strOfLocalization(4356) : game.Tools.strOfLocalization(4358);
            this.txtTip.text = isBag ? game.Tools.strOfLocalization(4357) : game.Tools.strOfLocalization(4359);
            this.txtBuyTip.text = game.Tools.strOfLocalization(4355);
            if (isArea) {
                this.imgArea.skin = game.Tools.localUISrc('myres/activity_2406_haidao/' + ECongrateIcon[this.rewardId] + '.png');
                // 不显示了
                // this.txtStageName.text = game.Tools.strOfLocalization(cfg.item_definition.function_item.get(this.rewardId).name);
            }
            if (isBag) this.imgChara.skin = game.Tools.localUISrc('myres/activity_2406_haidao/' + ECongrateIcon[this.rewardId] + '.png');
        }

        public close() {
            this.locking = true;
            if (this.rewardId) UI_Activity_Haidao_Rewards.onCheckedReward(this.rewardId);
            this.aniHide.play(0, false);
            if (this.aniShake.isPlaying) this.aniShake.stop();
            uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.soldOut, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
                this.onClose && this.onClose.run();
                this.onClose = null;
            });
        }

        onDisable() {
            Laya.timer.clearAll(this);
            uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.soldOut, false);
            if (this.aniShowSold.isPlaying) this.aniShowSold.stop();
            if (this.aniHide.isPlaying) this.aniHide.stop();
            if (this.aniShake.isPlaying) this.aniShake.stop();
            this.locking = false;
        }
    }
}