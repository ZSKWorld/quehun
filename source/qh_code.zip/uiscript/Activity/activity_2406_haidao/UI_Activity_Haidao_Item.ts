module uiscript {

    interface OldData {
        oldPos: Laya.Vector2;
        oldBagId: number;
        oldBagPos: Laya.Vector2;
        oldRotate: number;
    }

    export class UI_Activity_Haidao_Item extends UI_Component {

        private icon: Laya.Image;
        public itemData: GridItem;
        private basePath: string = "myres/activity_2406_haidao/";
        public isPay: boolean = false;
        public trueHeight: number;
        public trueWidth: number;
        /**
         * 操作前是否是从购物车创建的
         */
        public isCreateByShop: boolean = false;
        /**
         * 如果是-1，则不在背包内
         */
        public bagId: number = -1;
        public bagPosX: number = -1;
        public bagPosY: number = -1;
        public serverId: number = -1;
        public oldData: OldData = null;
        private touchGrids: Array<Laya.Sprite> = new Array();
        private backRedGrids: Array<Laya.Sprite> = new Array();
        public onItemClick: Laya.Handler;




        public onCreate(): void {
            this.icon = this.me.getChildByName('icon') as Laya.Image;
        }

        public show(itemData: GridItem, isPay: boolean) {
            this.itemData = itemData;
            this.isPay = isPay;
            let itemConfig = UI_Activity_Haidao.itemConfigDic.get(this.itemData.id);
            this.icon.skin = game.Tools.localUISrc(this.basePath + itemConfig.goods_res);
            //旋转为0时的宽高
            let initMatrix = this.itemData.rotateMatrix[0];
            this.me.width = initMatrix[0].length * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace) - UI_Activity_Haidao.gridSpace;
            this.me.height = initMatrix.length * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace) - UI_Activity_Haidao.gridSpace;
            this.me.rotation = 0;
            this.me.rotation = itemData.rotate * 90;
            // this.icon.alpha = isPay ? 1 : 0.5;
            this.freshGridLocalPos();
            this.redGridsVisible(false);

        }


        public dispose(): void {
            GridBagUtils.Inst.recycleItem(this.itemData);
            this.itemData = null;
            super.dispose();
            this.me.destroy();
        }


        public setRotate(rotate: number) {
            this.itemData.rotate = rotate;
            this.me.rotation = this.itemData.rotate * 90;
            this.freshGridLocalPos();
        }


        public rotateItem() {
            this.itemData.rotateItem();
            this.me.rotation = this.itemData.rotate * 90;
            this.freshGridLocalPos();
        }

        private freshGridLocalPos() {

            this.trueHeight = this.itemData.itemCol * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace) - UI_Activity_Haidao.gridSpace;
            this.trueWidth = this.itemData.itemRow * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace) - UI_Activity_Haidao.gridSpace;
            this.freshItemGrid();
        }

        /**
         * 获取每个格子的中心全局坐标
         */
        public getGridsGlobalPos(): Laya.Vector2[][] {
            let poses: Laya.Vector2[][] = new Array();
            //商品格子[0,0]中心的全局坐标
            let originGlobalCenterPos = new Laya.Vector2(this.leftUpPos.x + UI_Activity_Haidao.gridWidth / 2, this.leftUpPos.y + UI_Activity_Haidao.gridWidth / 2)
            for (let col = 0; col < this.itemData.itemCol; col++) {
                poses[col] = new Array();
                for (let row = 0; row < this.itemData.itemRow; row++) {
                    let posX = originGlobalCenterPos.x + row * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
                    let posY = originGlobalCenterPos.y + col * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
                    poses[col][row] = new Laya.Vector2(posX, posY);
                }
            }
            return poses;

        }

        /**
         * 获取单个格子中心的全局坐标
         * @param col 
         * @param row 
         * @returns 
         */
        public getGridGlobalPos(col, row): Laya.Vector2 {

            //商品格子[0,0]的全局坐标
            let originGlobalCenterPos = new Laya.Vector2(this.leftUpPos.x + UI_Activity_Haidao.gridWidth / 2, this.leftUpPos.y + UI_Activity_Haidao.gridWidth / 2)
            let posX = originGlobalCenterPos.x + row * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
            let posY = originGlobalCenterPos.y + col * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
            return new Laya.Vector2(posX, posY);
        }

        public get itemFillGrids(): number {
            let count: number = 0;
            for (let col = 0; col < this.itemData.itemCol; col++) {
                for (let row = 0; row < this.itemData.itemRow; row++) {
                    if (this.itemData.matrix[col][row] == 1) {
                        count++;
                    }
                }
            }
            return count;
        }

        public setIsPay(isPay: boolean) {
            this.isPay = isPay;
            // this.icon.alpha = this.isPay ? 1 : 0.5;
        }



        public saveData() {
            this.oldData = {
                oldBagId: this.bagId,
                oldPos: new Laya.Vector2(this.me.x, this.me.y),
                oldBagPos: new Laya.Vector2(this.bagPosX, this.bagPosY),
                oldRotate: this.itemData.rotate
            };

        }

        public clearSaveData() {
            this.oldData = null;
        }

        /**
         * 道具的中心点
         */
        public get itemCenterPos(): Laya.Vector2 {
            return new Laya.Vector2(this.leftUpPos.x + this.trueWidth / 2, this.leftUpPos.y + this.trueHeight / 2);
        }

        /**
         * 道具的左上角
         */
        public get leftUpPos(): Laya.Vector2 {
            if (this.itemData.rotate == 0) {
                return new Laya.Vector2(this.me.x, this.me.y);
            }
            else if (this.itemData.rotate == 1) {
                return new Laya.Vector2(this.me.x - this.trueWidth, this.me.y);
            }
            else if (this.itemData.rotate == 2) {
                return new Laya.Vector2(this.me.x - this.trueWidth, this.me.y - this.trueHeight);
            }
            else if (this.itemData.rotate == 3) {
                return new Laya.Vector2(this.me.x, this.me.y - this.trueHeight);
            }
        }


        /**
         * 通过左上角的全局坐标设置物品的坐标
         */
        public setPosByLeftUpPos(pos: Laya.Vector2) {
            if (this.itemData.rotate == 0) {
                this.me.x = pos.x;
                this.me.y = pos.y;
            }
            else if (this.itemData.rotate == 1) {
                this.me.x = pos.x + this.trueWidth;
                this.me.y = pos.y;
            }
            else if (this.itemData.rotate == 2) {
                this.me.x = pos.x + this.trueWidth;
                this.me.y = pos.y + this.trueHeight;
            }
            else if (this.itemData.rotate == 3) {
                this.me.x = pos.x;
                this.me.y = pos.y + this.trueHeight;
            }
        }

        /**
         * 通过指定格子的坐标，设置坐标
         * @param pos 该格子的全局坐标
         * @param x 该格子的行坐标
         * @param y 该格子的列坐标
         */
        public setPosByGridPos(pos: Laya.Vector2, x: number, y: number) {
            let leftUpPos = new Laya.Vector2(0, 0);
            leftUpPos.x = pos.x - x * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
            leftUpPos.y = pos.y - y * (UI_Activity_Haidao.gridWidth + UI_Activity_Haidao.gridSpace);
            this.setPosByLeftUpPos(leftUpPos);
        }

        /**
         * 通过传入商品中心点的坐标设置坐标
         * @param pos 
         */
        public setPosByCenterPos(pos: Laya.Vector2) {
            if (this.itemData.rotate == 0) {
                this.me.x = pos.x - this.trueWidth / 2;
                this.me.y = pos.y - this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 1) {
                this.me.x = pos.x + this.trueWidth / 2;
                this.me.y = pos.y - this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 2) {
                this.me.x = pos.x + this.trueWidth / 2;
                this.me.y = pos.y + this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 3) {
                this.me.x = pos.x - this.trueWidth / 2;
                this.me.y = pos.y + this.trueHeight / 2;
            }
        }


        private freshItemGrid() {
            this.clearTouchGrids();
            this.clearRedBackGrids();
            //根据左上角的全局坐标和是否占位生成88*88的格子，间隔为0，点击事件绑定在这些格子上
            let gridGlobalPos = this.getGridsGlobalPos();
            for (let col = 0; col < this.itemData.itemCol; col++) {
                for (let row = 0; row < this.itemData.itemRow; row++) {
                    let gridPos = gridGlobalPos[col][row];
                    if (this.itemData.matrix[col][row] == 1) {
                        let newImage = new Laya.Image();
                        newImage.sizeGrid = "6,6,6,6";
                        newImage.skin = game.Tools.localUISrc("myres/activity_2406_haidao/backpack_red.png");
                        newImage.width = 86;
                        newImage.height = 86;
                        newImage.anchorX = 0.5;
                        newImage.anchorY = 0.5;
                        
                        this.me.addChildAt(newImage,0);
                        //生成可以点击的格子和背景格子
                        let newBox = new Laya.Box();
                        newBox.width = 88;
                        newBox.height = 88;
                        newBox.anchorX = 0.5;
                        newBox.anchorY = 0.5;
                        this.me.addChild(newBox);
                        let localPos = this.me.globalToLocal(new Laya.Point(gridPos.x, gridPos.y));
                        newBox.x = localPos.x;
                        newBox.y = localPos.y;
                        newImage.x = localPos.x;
                        newImage.y = localPos.y;
                        newImage.visible = this.isBackGridVisible;
                        this.touchGrids.push(newBox);
                        this.backRedGrids.push(newImage);
                        newBox.on(Laya.Event.MOUSE_DOWN, this, () => {
                            this.onItemClick?.run();
                        });
                    }
                }
            }
        }

        private clearTouchGrids() {
            for (let index = 0; index < this.touchGrids.length; index++) {
                let grid = this.touchGrids[index];
                grid.destroy();
            }
            this.touchGrids = new Array();

        }

        private clearRedBackGrids() {
            for (let index = 0; index < this.backRedGrids.length; index++) {
                let grid = this.backRedGrids[index];
                grid.destroy();
            }
            this.backRedGrids = new Array();
        }

        /**
         * 根据原点坐标获取对应的左上角坐标
         */
        public originToLeftUp(originPos: Laya.Vector2): Laya.Vector2 {
            if (this.itemData.rotate == 0) {
                return new Laya.Vector2(originPos.x, originPos.y);
            }
            else if (this.itemData.rotate == 1) {
                return new Laya.Vector2(originPos.x - this.trueWidth, originPos.y);
            }
            else if (this.itemData.rotate == 2) {
                return new Laya.Vector2(originPos.x - this.trueWidth, originPos.y - this.trueHeight);
            }
            else if (this.itemData.rotate == 3) {
                return new Laya.Vector2(originPos.x, originPos.y - this.trueHeight);
            }
        }

        /**
         * 根据左上角计算原点坐标的位置
         * @param originPos 
         * @returns 
         */
        public leftUpToOrigin(originPos: Laya.Vector2): Laya.Vector2 {
            let result = new Laya.Vector2(originPos.x, originPos.y);
            if (this.itemData.rotate == 0) {
                result.x = originPos.x - this.trueWidth / 2;
                result.y = originPos.y - this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 1) {
                result.x = originPos.x + this.trueWidth / 2;
                result.y = originPos.y - this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 2) {
                result.x = originPos.x + this.trueWidth / 2;
                result.y = originPos.y + this.trueHeight / 2;
            }
            else if (this.itemData.rotate == 3) {
                result.x = originPos.x - this.trueWidth / 2;
                result.y = originPos.y + this.trueHeight / 2;
            }
            return result;
        }


        private isBackGridVisible: boolean = false;
        public redGridsVisible(isVisible: boolean) {
            this.isBackGridVisible = isVisible;
            for (let index = 0; index < this.backRedGrids.length; index++) {
                const element = this.backRedGrids[index];
                element.visible = isVisible;
            }
        }

    }

}