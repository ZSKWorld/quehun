module uiscript {
    enum EBagIconUrl {
        backpack_pop_up_window_huiyeji = 102,
        backpack_pop_up_window_wangjiro = 103
    }
    export class UI_Activity_Haidao_LockBagTip extends UIBase {
        public static Inst: UI_Activity_Haidao_LockBagTip = null;
        constructor(sprite: Laya.Sprite) {
            super(sprite);
            UI_Activity_Haidao_LockBagTip.Inst = this;
        }
        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private btnConfirm: Laya.Button;
        private txtBagName: Laya.Label;
        private txtBagDesc: Laya.HTMLDivElement;
        private imgChara: Laya.Image;
        private locking: boolean;

        public onCreate(): void {
            this.bg = this.me.getChildByName('maskImg') as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, this.onClickClose);
            this.btnConfirm = this.root.getChildByName('confirm_btn').getChildByName('btn') as Laya.Button;
            this.btnConfirm.clickHandler = new Laya.Handler(this, this.onClickClose);
            (this.root.getChildByName('pop_frame').getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, this.onClickClose);
            (this.root.getChildByName('confirm_btn').getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(4354);
            (this.root.getChildByName('pop_frame').getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(4342);
            this.txtBagDesc = this.root.getChildByName('desc') as Laya.HTMLDivElement;
            this.txtBagName = this.root.getChildByName('name') as Laya.Label;
            this.imgChara = this.root.getChildByName('chara') as Laya.Image;
            if (GameMgr.client_language == 'jp') {
                this.txtBagDesc.style.font = '36px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtBagDesc.style.font = '36px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtBagDesc.style.font = '36px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtBagDesc.style.font = '30px SimHei';
            } else {
                this.txtBagDesc.style.font = '30px kr_solmoe_1';
            }
            this.txtBagDesc.style.color = '#766051';
            this.txtBagDesc.style.leading = 10;
            this.txtBagDesc.style.letterSpacing = 1;
        }

        //传102，103，拿taskinfo判断一下还有多少解锁
        public show(bagId: number) {
            if (this.locking) return;
            this.enable = true;
            this.locking = true;
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 150);
            let bagConfig = UI_Activity_Haidao.bagDataDic.get(bagId).bagConfig;
            this.txtBagName.text = game.Tools.strOfLocalization(bagConfig.bag_name);
            let taskData: game.ITaskProgress = UI_Activity.getPeriodTaskInfo(bagConfig.unlock_task_id) as game.ITaskProgress;
            let progress = taskData.counter || 0;
            let configData = cfg.activity.period_task.get(bagConfig.unlock_task_id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let target = baseTaskConfigData.target;
            this.txtBagDesc.innerHTML = game.Tools.ParseText(game.Tools.strOfLocalization(bagConfig.bag_desc, [progress + '', '' + target]), '#df2d36');
            let imgUrl = EBagIconUrl[bagId];
            this.imgChara.skin = game.Tools.localUISrc('myres/activity_2406_haidao/' + imgUrl + '.png');
        }

        public hide() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
        }

        private onClickClose() {
            if (this.locking) {
                return;
            }
            this.hide()
        }
    }
}