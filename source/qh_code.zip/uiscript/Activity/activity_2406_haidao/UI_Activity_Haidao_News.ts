module uiscript {
    //页面枚举
    enum ENewsPage {
        today,
        yesterday
    }
    //区域图枚举
    enum ENewsArea {
        news_pier,
        news_bread_house,
        news_primary_school,
        news_culture_street,
        news_resort
    }
    export class UI_Activity_Haidao_News extends UIBase {
        public static Inst: UI_Activity_Haidao_News = null;
        public static haveRedPoint(): boolean {
            //每日首次打开显示公告，有公告的话
            const time = game.LocalStorage.getItem('HaiDaoNewsShowTime' + GameMgr.Inst.account_id) || 0;
            if (!game.Tools.isPassedRefreshTimeServer(Number(time) / 1000)) {
                return true;
            }
            return false;
        }

        public static openNews() {
            const time = game.LocalStorage.getItem('HaiDaoNewsShowTime' + GameMgr.Inst.account_id);
            if (!game.Tools.isPassedRefreshTimeServer(Number(time) / 1000)) {
                app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: [UI_Activity_Haidao.activityId] }, (err, res) => {
                });
            }
            game.LocalStorage.setItem('HaiDaoNewsShowTime' + GameMgr.Inst.account_id, game.Tools.getServerTime().toString());
            if (UI_Activity_Haidao.Inst && UI_Activity_Haidao.Inst.enable) {
                UI_Activity_Haidao.Inst.refreshRedPoints();
            }
        }
        private root: Laya.Sprite;
        private bg: Laya.Image;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private txtTitle: Laya.Label;
        private txtWeekDay: Laya.Label;
        private txtDate: Laya.Label;
        private txtDay: Laya.Label;
        private btnChangeDay: Laya.Button;

        private scrollView: capsui.CScrollView;
        public locking: boolean;
        private newsData: lqc.Sheet_Activity_IslandNews[][];
        private dayOnCreate: number = -1;
        private pageIndex: ENewsPage;

        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_newsUI);
            UI_Activity_Haidao_News.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.listContainer = this.root.getChildByName('content').getChildByName("content") as Laya.Panel;
            this.listContainer.vScrollBarSkin = '';
            this.listContainer.vScrollBar.elasticDistance = 350;
            this.listContainer.vScrollBar.elasticBackTime = 250;
            this.listScrollBar = this.root.getChildByName('content').getChildByName("scrollbar") as Laya.Sprite;
            this.scrollView = (this.root.getChildByName('content') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.txtTitle = this.root.getChildByName('pop_bg').getChildByName('stage_name') as Laya.Label;
            this.txtDate = this.root.getChildByName('pop_bg').getChildByName('date') as Laya.Label;
            this.txtDay = this.root.getChildByName('pop_bg').getChildByName('day') as Laya.Label;
            this.txtWeekDay = this.root.getChildByName('pop_bg').getChildByName('week_day') as Laya.Label;
            this.btnChangeDay = this.root.getChildByName('btn_yesterday') as Laya.Button;
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
            (this.me.getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            (this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.btnChangeDay.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.pageIndex = this.pageIndex == ENewsPage.today ? ENewsPage.yesterday : ENewsPage.today;
                this.refresh();
            })
            this.txtTitle.text = game.Tools.strOfLocalization(4363);
            this.refreshLatestNews();
            if (GameMgr.client_language == 'jp') {
                (this.btnChangeDay.getChildByName('info') as Laya.Label).fontSize = 36;
            } else if (GameMgr.client_language == 'en') {
                (this.btnChangeDay.getChildByName('info') as Laya.Label).fontSize = 30;
            }
        }

        //拿当天的新闻，一般创建时就拿了，打开页面时不是当天的就再拿一遍
        public refreshLatestNews() {
            let activityDay = UI_Activity.getActivityDeltaDay(UI_Activity_Haidao.activityId);
            if (this.dayOnCreate == activityDay) return;
            this.dayOnCreate = activityDay;
            this.newsData = [[], []];
            if (UI_Activity_Haidao.newsConfigDic.get(activityDay + 1)) this.newsData[0] = UI_Activity_Haidao.newsConfigDic.get(activityDay + 1);
            if (UI_Activity_Haidao.newsConfigDic.get(activityDay)) this.newsData[1] = UI_Activity_Haidao.newsConfigDic.get(activityDay);
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 200);
            this.refreshLatestNews();
            this.pageIndex = this.newsData[0].length > 0 ? ENewsPage.today : ENewsPage.yesterday;
            this.refresh();
            UI_Activity_Haidao_News.openNews();
        }

        //刷新新闻列表，刷新下标题日期
        refresh() {
            this.btnChangeDay.visible = this.newsData[0].length > 0 && this.newsData[1].length > 0;
            const newsData: lqc.Sheet_Activity_IslandNews[] = this.newsData[this.pageIndex];
            if (this.pageIndex == ENewsPage.today) {
                (this.btnChangeDay.getChildByName('info') as Laya.Label).text = game.Tools.strOfLocalization(4375);
                this.txtDay.text = game.Tools.strOfLocalization(4364);
            } else {
                (this.btnChangeDay.getChildByName('info') as Laya.Label).text = game.Tools.strOfLocalization(4374);
                this.txtDay.text = game.Tools.strOfLocalization(4365);
            }
            let news = newsData[0];
            // this.txtDate.text = game.Tools.strOfLocalization(news.news_date);
            this.txtDate.visible = false;
            this.txtWeekDay.text = game.Tools.strOfLocalization(4373);
            // this.txtDay.x = this.txtDate.x + this.txtDate.width;
            this.scrollView.reset();
            this.scrollView.addItem(newsData.length);
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            const newsData = this.newsData[this.pageIndex][index];
            let txtDesc = container.getChildByName("desc") as Laya.HTMLDivElement;
            let iconArea = container.getChildByName("area") as Laya.Image;
            let iconItem = container.getChildByName("item") as Laya.Image;
            let iconHot = container.getChildByName("tip_hot") as Laya.Image;
            let iconSale = container.getChildByName("tip_sale") as Laya.Image;
            if (newsData.zone >= 0) {
                iconArea.skin = game.Tools.localUISrc('myres/activity_2406_haidao/' + ENewsArea[newsData.zone] + '.png');
            } else {
                iconArea.skin = game.Tools.localUISrc('myres/activity_2406_haidao/news_bottom.png');
            }
            if (newsData.goods_id >= 0) {
                let goodsData = UI_Activity_Haidao.itemConfigDic.get(newsData.goods_id);
                iconItem.skin = game.Tools.localUISrc('myres/activity_2406_haidao/' + goodsData.goods_res);
            } else {
                iconItem.skin = '';
            }
            let hot = newsData.effect > 100;
            let color = hot ? '#df2d36' : '#4fb37c';
            iconHot.visible = hot;
            iconSale.visible = !hot;
            if (GameMgr.client_language == 'jp') {
                txtDesc.style.font = '28px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                txtDesc.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                txtDesc.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                txtDesc.style.font = '28px SimHei';
            } else {
                txtDesc.style.font = '28px NotoSansKR';
            }
            txtDesc.style.color = '#766051';
            txtDesc.style.leading = 4;
            txtDesc.style.letterSpacing = 0;
            txtDesc.innerHTML = game.Tools.ParseText(game.Tools.eventStrOfLocalization(newsData.news_desc), color);
            let height = txtDesc.contextHeight;
            txtDesc.y = 76 - height / 2;
        }
        public close() {
            this.locking = true;
            if (UI_Activity_Haidao.Inst && UI_Activity_Haidao.Inst.enable) {
                UI_Activity_Haidao.Inst.refreshRedPoints();
            }
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
        }
    }
}