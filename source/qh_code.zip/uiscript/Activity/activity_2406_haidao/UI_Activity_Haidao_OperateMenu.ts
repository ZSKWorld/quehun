module uiscript{
    export class UI_Activity_Haidao_OperateMenu extends UI_Component {
        private sellBtn: Laya.Button;
        private deleteBtn: Laya.Button;
        private rotateBtn: Laya.Button;
        private cancelBtn: Laya.Button;
        private upgradeBtn: Laya.Button;
        private handler1: Laya.Handler;
        private handler2: Laya.Handler;
        private onMouseDown: Laya.Handler;
        private coinIcon: Laya.Image;
        private coinBg: Laya.Image;
        private priceText: Laya.Label;
        private coinAdapter: common.SpriteAdapter;
        private coinBgAdapter: common.SpriteAdapter;




        public onCreate(): void {

            this.sellBtn = this.me.getChildByName('btn_sell') as Laya.Button;
            this.deleteBtn = this.me.getChildByName('btn_delete') as Laya.Button;
            this.rotateBtn = this.me.getChildByName('btn_rotation') as Laya.Button;
            this.cancelBtn = this.me.getChildByName('btn_cancel') as Laya.Button;
            this.upgradeBtn = this.me.getChildByName('btn_upgrade') as Laya.Button;
            let sellPrice = this.sellBtn.getChildByName('sell_price') as Laya.Sprite;
            this.coinIcon = sellPrice.getChildByName('coin') as Laya.Image;
            this.coinBg = sellPrice.getChildByName('bg') as Laya.Image;
            this.priceText = sellPrice.getChildByName('price_text') as Laya.Label;
            this.coinAdapter = new common.SpriteAdapter(this.coinIcon, this.priceText, SpriteAdapterType.RIGHT2LEFT, 3);
            this.coinBgAdapter = new common.SpriteAdapter(this.coinBg, this.priceText, SpriteAdapterType.WIDTH2WIDTH, -42);

            this.sellBtn.clickHandler = new Laya.Handler(this, () => {
                this.handler1 && this.handler1.run();
            });
            this.deleteBtn.clickHandler = new Laya.Handler(this, () => {
                this.handler1 && this.handler1.run();
            });
            this.upgradeBtn.clickHandler = new Laya.Handler(this, () => {
                this.handler1 && this.handler1.run();
            });
            this.rotateBtn.clickHandler = new Laya.Handler(this, () => {
                this.handler2 && this.handler2.run();
            });
            this.cancelBtn.clickHandler = new Laya.Handler(this, () => {
                this.handler2 && this.handler2.run();
            });
            this.sellBtn.on(Laya.Event.MOUSE_DOWN, this, () => {
                this.onMouseDown && this.onMouseDown.run();
            });
            this.deleteBtn.on(Laya.Event.MOUSE_DOWN, this, () => {
                this.onMouseDown && this.onMouseDown.run();
            });
            this.upgradeBtn.on(Laya.Event.MOUSE_DOWN, this, () => {
                this.onMouseDown && this.onMouseDown.run();
            });
            this.rotateBtn.on(Laya.Event.MOUSE_DOWN, this, () => {
                this.onMouseDown && this.onMouseDown.run();
            });
            this.cancelBtn.on(Laya.Event.MOUSE_DOWN, this, () => {
                this.onMouseDown && this.onMouseDown.run();
            });

        }

        /**
         * 
         * @param state 0 商店-已付款（出售，旋转）1 商店-未付款（删除，旋转） 2 背包-物品（删除，取消） 3 背包-格子（升级，取消）
         * @param handler1 第一个位置的按钮的点击事件
         * @param handler2 第二个位置的按钮的点击事件
         * @param onMouseDown 点击按钮的时候触发的事件
         */
        public show(state: number, handler1: Laya.Handler, handler2: Laya.Handler, onMouseDown: Laya.Handler,price:number = 0): void {
            this.handler1 = handler1;
            this.handler2 = handler2;
            this.onMouseDown = onMouseDown;
            this.sellBtn.visible = state == 0;
            this.deleteBtn.visible = state == 1 || state == 2;
            this.upgradeBtn.visible = state == 3;
            this.rotateBtn.visible = state == 0 || state == 1;
            this.cancelBtn.visible = state == 2 || state == 3;
            this.visible = true;
            if (state == 0) {
                this.priceText.text = price.toString();
                this.coinAdapter.fresh();
                this.coinBgAdapter.fresh();
            }
        }



    }
}
