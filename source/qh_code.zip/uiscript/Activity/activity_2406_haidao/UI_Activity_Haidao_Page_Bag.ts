module uiscript {


    export class UI_Activity_Haidao_Page_Bag extends UIBase {
        public static Inst: UI_Activity_Haidao_Page_Bag = null;
        public static haveRedPoint(): boolean {
            //背包可解锁
            for (let i = 0; i < UI_Activity_Haidao.bagIdArray.length; i++) {
                let id = UI_Activity_Haidao.bagIdArray[i];
                let config = UI_Activity_Haidao.bagDataDic.get(id).bagConfig;
                if (config && config.unlock_task_id && UI_Activity_Haidao_Rewards.getUnLockStateByTaskId(config.unlock_task_id)) {
                    return true;
                }
            }
            //背包可升级
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            for (let i = 0; i < keys.length; i++) {
                let key = keys[i];
                let bagData = UI_Activity_Haidao.bagDataDic.get(key);
                if (!common.MatrixUtils.isMatrixEqual(bagData.currentMatrix, bagData.allMatrix)) {
                    let unLockConfig = bagData.bagConfig.unlock_consume.split('-');
                    if (bagData.isUnlock && UI_Bag.get_item_count(Number(unLockConfig[0])) >= Number(unLockConfig[1])) {
                        return true;
                    }
                }
            }
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_bagUI);
            UI_Activity_Haidao_Page_Bag.Inst = this;
        }

        private isLock: boolean = false;

        /**
        * 关闭按钮
        */
        private closeBtn: Laya.Button;
        private bagsContainer: UI_Activity_Haidao_BagsContainer;

        private onItemFreshHandler: Laya.Handler;
        private operateLayer: Laya.Sprite;
        private emptyLayer: Laya.Sprite;
        private operateMenu: UI_Activity_Haidao_OperateMenu;
        private itemTemplate: capsui.UICopy;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniChange: Laya.FrameAnimation;

        private upgradeBagPage: UI_Activity_Haidao_UpgradeBag;
        private upgradeBtn: UI_Button;
        private tableBg: Laya.Image;
        /**
         * 鼠标摁下的坐标
         */
        private clickStartPos: Laya.Vector2;
        /**
         * 当前是否在执行拖拽
         */
        private isDrag: boolean;
        /**
         * 当前点击的格子的index
         */
        private clickGridIndex: number = -1;
        /**
         * 当前正在被拖拽的物体
         */
        private dragItem: UI_Activity_Haidao_Item;
        /**
         * 当前所有在显示的可操作商品
         */
        private showItems: Array<UI_Activity_Haidao_Item> = new Array();
        /**
         * 当前是否在操作任何物体（点击格子，点击商品，点击操作按钮）
         */
        public isOperate: boolean = false;
        /**
         * 当前操作的物体
         */
        private operateItem: UI_Activity_Haidao_Item;
        /**
        * 拷贝的服务器数据，
        */
        private currentBagData: basic.Dictionary<number, GridBag> = new basic.Dictionary;
        private itemDragStartPos: Laya.Vector2;
        private itemDragStartRotate: number;
        private dragOffset: Laya.Vector2;
        private isMouseDown: boolean = false;
        /**
         * 物品旧数据<serverId,数据>
         */
        private oldItemData: Array<basic.Dictionary<number, Haidao_ItemUIData>> = new Array();

        public onCreate(): void {
            let topMenu = this.me.getChildByName("top_menu") as Laya.Sprite;
            this.closeBtn = topMenu.getChildByName('return_btn') as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.bagsContainer = new UI_Activity_Haidao_BagsContainer(this.me.getChildByName("bags") as Laya.Sprite);
            this.bagsContainer.onTabChange = new Laya.Handler(this, this.onBagTabChange);
            this.bagsContainer.onClickReset = new Laya.Handler(this, this.onClickReset);
            this.onItemFreshHandler = new Laya.Handler(this, () => {
                this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
            });
            let operate = this.me.getChildByName('oprate_layer') as Laya.Sprite;
            this.operateLayer = operate.getChildByName('itemParent') as Laya.Sprite;
            this.emptyLayer = this.me.getChildByName('empty_layer') as Laya.Sprite;
            this.operateMenu = new UI_Activity_Haidao_OperateMenu(operate.getChildByName('operate_btns') as Laya.Sprite);
            this.operateMenu.visible = false;
            this.aniShow = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_bagUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_bagUI).hide;
            this.aniChange = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_bagUI).qiehuan;
            let itemUI = this.operateLayer.getChildByName('itemTemplete') as Laya.Sprite;
            itemUI.visible = false;
            this.itemTemplate = itemUI.scriptMap['capsui.UICopy'] as capsui.UICopy;
            this.upgradeBagPage = new UI_Activity_Haidao_UpgradeBag(this.me.getChildByName('popup').getChildByName("upgrade") as Laya.Sprite);
            this.upgradeBagPage.visible = false;
            this.upgradeBtn = new UI_Button(this.me.getChildByName('upgrade_btn') as Laya.Sprite, true);
            this.upgradeBtn.setClickListener(new Laya.Handler(this, () => {
                this.onClickUpgrade();
            }))
            // if (GameMgr.client_language == 'en') {
            //     (this.upgradeBtn.me.getChildByName('title') as Laya.Label).fontSize = 28;
            // }
            this.tableBg = this.me.getChildByName('table').getChildByName("wood") as Laya.Image;

        }

        private bindEvent() {
            UI_Bag.add_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            this.me.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            Laya.stage.on(Haidao_EventId.UPDATE_DATA, this, this.onFreshData);
            Laya.stage.on(Haidao_EventId.CLICK_BAG_UPDATE, this, this.saveCurrentItemData);
            Laya.stage.on(Haidao_EventId.UNLOCK_BAG, this, this.saveCurrentItemData);
        }

        private removeEvent() {
            UI_Bag.remove_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            Laya.stage.off(Haidao_EventId.UPDATE_DATA, this, this.onFreshData);
            Laya.stage.off(Haidao_EventId.CLICK_BAG_UPDATE, this, this.saveCurrentItemData);
            Laya.stage.off(Haidao_EventId.UNLOCK_BAG, this, this.saveCurrentItemData);
            this.me.off(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.off(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.off(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
        }

        public onEnable(): void {
            this.removeEvent();
            this.bindEvent();
        }

        public onDisable(): void {
            this.removeEvent();
        }

        public show() {
            this.clearSaveData();
            this.onFreshData();
            this.enable = true;
            UI_Activity_Haidao.Inst.showPopupBg(true, true);
            this.isLock = true;
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.isLock = false;
            });
            view.AudioMgr.PlayAudio(10131);
        }

        public hide() {
            UI_Activity_Haidao.Inst.showPopupBg(false, true);
            this.disposeAllItem();
            this.removeEvent();
            this.isLock = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.enable = false;
            });
        }



        private onFreshData() {
            this.freshData();
            this.freshUI();
            this.disposeAllItem();
            this.generateBagItem();
            this.bagsContainer.getBagUI().freshGridsState(new Array());
            this.upgradeBagPage.freshData();
            this.freshUpdateBagBtn();
            this.loadItemData();
            this.onBagTabChange(false);
        }

        private freshUI() {
            this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
        }

        private freshData() {

            let serverData = UI_Activity_Haidao.bagDataDic;
            this.currentBagData.clear();
            serverData.keys().forEach((v, i) => {
                let bagId = v;
                let bagData = serverData.get(bagId);
                this.currentBagData.set(bagId, bagData.clone());
            });
            this.clickGridIndex = -1;
            this.isDrag = false;
            this.dragItem = null;
            this.operateItem = null;
            //刷新背包数据
            this.bagsContainer.setData(this.currentBagData);
            // console.log("当前背包的数据是", this.currentBagData);
        }



        //切换背包页签
        private onBagTabChange(anim: boolean = false) {
            //指定背包id的物品显示
            for (let index = 0; index < this.showItems.length; index++) {
                let item = this.showItems[index];
                let bagUI = this.bagsContainer.getBagUI();
                if (item.bagId == -1) {
                    item.visible = true;
                }
                else {
                    item.visible = item.bagId == bagUI.bagId;
                }
            }
            if (anim) {
                view.AudioMgr.PlayAudio(10134);
                // 取消切换背包
                // this.isLock = true;
                // this.aniChange.play(0, false);
                // Laya.timer.once(this.aniChange.count * this.aniChange.interval, this, () => {
                //     this.isLock = false;
                // })
            }
        }

        private onClickClose() {
            if (this.isLock) {
                return;
            }
            if (this.showItems.length == 0) {
                this.hide();
                return;
            }
            //先发送整理消息
            //检测是否所有物品已经放入背包
            let isAllInBag = true;
            for (let index = 0; index < this.showItems.length; index++) {
                let itemUI = this.showItems[index];
                if (itemUI.bagId == -1) {
                    isAllInBag = false;
                    break;
                }
            }

            if (!isAllInBag) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4391), new Laya.Handler(this, () => {
                    this.hide();
                }), null, 960, 530, 4392);
                UI_SecondConfirm.Inst.setBtnState(true, true);
                return;
            }

            let tidyItems: basic.Dictionary<number, UI_Activity_Haidao_Item[]> = new basic.Dictionary();
            this.showItems.forEach((item) => {
                if (!tidyItems.get(item.bagId)) {
                    tidyItems.set(item.bagId, new Array());
                }
                tidyItems.get(item.bagId).push(item);

            })
            this.tidyBag(tidyItems, new Laya.Handler(this, (res) => {
                this.hide();
            }))

        }

        private disposeAllItem() {
            this.showItems.forEach((v, i) => {
                v.dispose();
            })
            this.showItems = new Array();
        }

        //生成背包内的物品
        private generateBagItem() {
            //生每个背包内的物品ui
            for (let index = 0; index < this.currentBagData.keys().length; index++) {
                let bagId = this.currentBagData.keys()[index];
                let bagData = this.currentBagData.get(bagId);
                let items = bagData.items;
                for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
                    let item = items[itemIndex];
                    let itemUI = this.createItemUI(item.itemLocalData, true);
                    itemUI.serverId = item.serverId;
                    this.addItemInBag(itemUI, this.bagsContainer.getBagUIById(bagId), item.startPosX, item.startPosY);
                    this.emptyLayer.addChild(itemUI.me);

                }
            }

        }

        private createItemUI(gridItem: GridItem, isPay: boolean,): UI_Activity_Haidao_Item {
            let itemUI = this.itemTemplate.getNodeClone();
            itemUI.visible = true;
            let item = new UI_Activity_Haidao_Item(itemUI);
            item.show(gridItem, isPay);
            item.onItemClick = new Laya.Handler(this, () => {
                this.isOperate = true;
                this.dragItem = item;
                this.onClickItem();
            });
            this.showItems.push(item);
            return item;
        }

        private onClickItem() {
            if (this.isLock) {
                return;
            }
            //先结算上一个的操作
            if (this.operateItem != null && this.operateItem != this.dragItem) {
                this.onOperateFinish();
            }
            if (this.operateItem == null) {
                this.onOperateStart(this.dragItem);
            }
            let item = this.dragItem;
            let handler1: Laya.Handler;
            let handler2: Laya.Handler;
            let state: number = 1;
            let onMouseDown: Laya.Handler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.isOperate = true;
            });
            //丢弃
            handler1 = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                //弹出是否确认丢弃
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4397), new Laya.Handler(this, () => {
                    this.dropItem(item.serverId, new Laya.Handler(this, () => {
                        this.operateMenu.visible = false;
                    }))
                }), null, 960, 530, 4398);
                UI_SecondConfirm.Inst.setBtnState(true, true);

            });
            //旋转
            handler2 = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.rotateCurrentOperate();
            });
            //显示影响的格子
            let effect = this.getItemEffectGrid(item);
            this.removeItemInBag(item);
            this.bagsContainer.getBagUI().freshGridsState(effect)
            this.operateMenu.show(state, handler1, handler2, onMouseDown);
            this.menuFollowItem(item);

        }


        /**
         * 旋转当前的操作物体
         */
        private rotateCurrentOperate() {

            if (this.operateItem != null) {

                //刷新格子的显示
                let bagUI = this.bagsContainer.getBagUI();
                //固定左上角的位置
                let oldLeftUp = this.operateItem.leftUpPos;
                this.operateItem.rotateItem();
                this.operateItem.setPosByLeftUpPos(oldLeftUp);
                let effectBagGrids = this.getItemEffectGrid(this.operateItem);
                bagUI.freshGridsState(effectBagGrids);

                this.menuFollowItem(this.operateItem);
            }
        }

        private onOperateStart(itemUI: UI_Activity_Haidao_Item) {

            //如果在背包内，将物品从背包内移除
            itemUI.saveData();
            this.removeItemInBag(itemUI);
            //记录操作前的状态
            this.operateItem = itemUI;
            this.operateLayer.addChild(itemUI.me);

        }

        /**
         * 当点击了其它物体或者是空白区域是被调用
         */
        private onOperateFinish() {
            if (this.operateItem != null) {
                //如果可以放到背包内，就放到背包内
                let putSuccess = this.addItemToCurrentBag(this.operateItem);
                let effectGrids = this.getItemEffectGrid(this.operateItem);
                if (!putSuccess) {
                    if (effectGrids.length != 0) {
                        //之前在空白位置返回原位置
                        if (this.operateItem.oldData.oldBagId == -1) {
                            this.operateItem.me.x = this.operateItem.oldData.oldPos.x;
                            this.operateItem.me.y = this.operateItem.oldData.oldPos.y;
                            this.operateItem.setRotate(this.operateItem.oldData.oldRotate);
                            this.operateItem.redGridsVisible(true);
                        }
                        //之前在背包中
                        else {
                            this.operateItem.setRotate(this.operateItem.oldData.oldRotate);
                            this.addItemInBag(this.operateItem, this.bagsContainer.getBagUI(), this.operateItem.oldData.oldBagPos.x, this.operateItem.oldData.oldBagPos.y);
                            this.operateItem.redGridsVisible(false);
                        }
                    }
                    // else {
                    //     this.operateItem.bagId = -1;
                    // }
                }
                this.emptyLayer.addChild(this.operateItem.me);
                this.operateItem.clearSaveData();
                this.operateItem = null;

            }

            this.bagsContainer.getBagUI().freshGridsState(new Array());


            // console.log("操作结束");
        }

        private addItemToCurrentBag(itemUI: UI_Activity_Haidao_Item): boolean {

            let bagUI = this.bagsContainer.getBagUI();
            let effectBagGrids = this.getItemEffectGrid(this.operateItem);
            let ifPutSuccess = true;
            //如果商品的格子都被放置了
            let itemGridsCount = itemUI.itemFillGrids;
            if (itemGridsCount != effectBagGrids.length) {
                // console.log("没有所有格子放置的背包内", itemGridsCount,effectBagGrids.length);
                return ifPutSuccess = false;
            }

            for (let index = 0; index < effectBagGrids.length; index++) {
                let grid = effectBagGrids[index];
                if (!bagUI.isGridEmpty(grid.x, grid.y)) {
                    ifPutSuccess = false;
                    // console.log("当前有格子不为空",grid.x, grid.y);

                    break;
                }
            }
            if (ifPutSuccess) {
                let bagGridIndex = bagUI.getNearBy(this.operateItem.getGridGlobalPos(0, 0));
                this.addItemInBag(this.operateItem, bagUI, bagGridIndex.x, bagGridIndex.y);
            }
            return ifPutSuccess;
        }

        /**
          * 将商品左上角放置在指定背包的指定格子处
          * @param itemUI 商品
          * @param bagUI 背包
          * @param posX 背包的指定格子
          * @param posY 背包的指定格子
          */
        private addItemInBag(itemUI: UI_Activity_Haidao_Item, bagUI: UI_Activity_Haidao_Bag, posX: number, posY: number) {

            //获取这个格子左上角的全局坐标
            let gridLeftPos = bagUI.getGrid(posX, posY).globalPos;
            itemUI.setPosByLeftUpPos(gridLeftPos);
            this.menuFollowItem(itemUI);
            bagUI.addItemUI(itemUI, posX, posY);
        }

        /**
         * 从背包里移除指定的道具
         * @param itemUI 
         */
        private removeItemInBag(itemUI: UI_Activity_Haidao_Item) {

            if (itemUI.bagId != -1) {
                this.bagsContainer.getBagUI().removeItem(itemUI);
            }
        }

        private menuFollowItem(itemUI: UI_Activity_Haidao_Item) {
            this.operateMenu.me.x = itemUI.itemCenterPos.x;
            this.operateMenu.me.y = itemUI.leftUpPos.y - 56;
        }

        /**
       * 获取商品的影响格子
       * @param itemUI 
       * @returns 
       */
        private getItemEffectGrid(itemUI: UI_Activity_Haidao_Item): Laya.Vector2[] {
            let gridPoses = itemUI.getGridsGlobalPos();
            let item = itemUI;
            let itemGridsData = item.itemData;
            let bagUI = this.bagsContainer.getBagUI();
            //计算该道具目前影响的所有格子
            let effectBagGrids: Laya.Vector2[] = new Array();
            for (let col = 0; col < itemGridsData.itemCol; col++) {
                for (let row = 0; row < itemGridsData.itemRow; row++) {
                    //这个格子的中心点的全局坐标
                    let gridPos: Laya.Vector2 = gridPoses[col][row];
                    //这个格子占位
                    if (itemGridsData.matrix[col][row] == 1) {
                        let bagGridIndex: Laya.Vector2 = bagUI.getNearBy(gridPos);
                        //没有最近的格子
                        if (bagGridIndex.x == -1 && bagGridIndex.y == -1) {
                            continue;
                        }
                        if (bagUI.getGrid(bagGridIndex.x, bagGridIndex.y).visible == false) {
                            continue;
                        }
                        effectBagGrids.push(bagGridIndex);
                    }
                }
            }
            return effectBagGrids;
        }

        private onMouseDown() {
            this.isMouseDown = true;
            this.clickStartPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.isDrag = false;
            Laya.timer.once(1, this, this.checkDrag);
        }



        /**
         * 如果当前没在操作任何物体，则关闭操作菜单,如果在操作则执行对应的操作
         */
        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            //拖拽的结束
            if (this.isDrag) {
                this.onDragEnd();
                this.isDrag = false;


            }
            //点击的结束
            else {

                //点击了某个格子
                if (this.clickGridIndex != -1) {

                    // this.onClickShopCarGrid();
                }
                //点击了某个道具
                else if (this.dragItem != null) {
                    // this.onClickItem();
                }

            }

            //如果当前没有在操作任何物体，则关闭操作菜单
            if (!this.isOperate) {
                this.operateMenu.visible = false;
                //Todo 检测放置状态是否正确，如果不正确，则返回操作前的状态
                // this.operateItem = null;
                this.onOperateFinish();
            }
            this.clickStartPos = new Laya.Vector2(0, 0);
            Laya.timer.clear(this, this.checkDrag);
            Laya.timer.clear(this, this.onDragMove);
            this.dragItem = null;
            this.clickGridIndex = -1;
            this.isOperate = false;

        }




        private checkDrag() {
            if (!this.isDrag) {
                if (this.clickStartPos.x != Laya.stage.mouseX || this.clickStartPos.y != Laya.stage.mouseY) {
                    this.isDrag = true;
                    this.onDragStart();
                    Laya.timer.frameLoop(1, this, this.onDragMove);
                    return;
                }
            }

            Laya.timer.once(1, this, this.checkDrag);
        }

        private onDragStart() {
            // console.log("拖拽开始");
            let mousePosX = Laya.stage.mouseX;
            let mousePosY = Laya.stage.mouseY;
            if (this.dragItem != null) {
                this.removeItemInBag(this.dragItem)
                this.itemDragStartPos = new Laya.Vector2(this.dragItem.me.x, this.dragItem.me.y);
                this.itemDragStartRotate = this.dragItem.itemData.rotate;
                this.dragOffset = new Laya.Vector2(this.dragItem.me.x - mousePosX, this.dragItem.me.y - mousePosY);
                this.dragItem.me.x = mousePosX + this.dragOffset.x;
                this.dragItem.me.y = mousePosY + this.dragOffset.y;
                this.dragItem.redGridsVisible(false);
                this.operateMenu.visible = false;
            }

        }

        private onDragMove() {
            // console.log("拖拽中");
            if (this.dragItem != null) {
                //物品跟随鼠标
                let mousePosX = Laya.stage.mouseX;
                let mousePosY = Laya.stage.mouseY;
                //加入边界检测，拖拽的时候，商品不可以超出屏幕
                //物品的左上角，物品的左上角坐标 y需要大于等于0小于等于1080-高 x>=0 x<=1920-宽
                //新的原点位置
                let newOriginPos = new Laya.Vector2(mousePosX + this.dragOffset.x, mousePosY + this.dragOffset.y);
                let newLeftUpPos = this.dragItem.originToLeftUp(newOriginPos);
                if (newLeftUpPos.x >= 0 && newLeftUpPos.x <= 1920 - this.dragItem.trueWidth) {
                    this.dragItem.me.x = mousePosX + this.dragOffset.x;
                }
                if (newLeftUpPos.y >= 0 && newLeftUpPos.y <= 1080 - this.dragItem.trueHeight) {
                    this.dragItem.me.y = mousePosY + this.dragOffset.y;
                }
                this.menuFollowItem(this.dragItem);
                //检测物品的格子数据
                let item = this.dragItem;
                let bagUI = this.bagsContainer.getBagUI();
                //计算该道具目前影响的所有格子
                let effectBagGrids = this.getItemEffectGrid(item);
                bagUI.freshGridsState(effectBagGrids);

            }
        }

        private onDragEnd() {
            // console.log("拖拽结束");
            if (this.dragItem != null) {
                this.menuFollowItem(this.dragItem);
                view.AudioMgr.PlayAudio(10136);

                let bagUI = this.bagsContainer.getBagUI();
                let effectBagGrids = this.getItemEffectGrid(this.operateItem);
                let isOnEmpty = effectBagGrids.length == 0
                if (isOnEmpty) {

                    //如果拖到了桌布的位置
                    if (this.tableBg.hitTestPoint(Laya.stage.mouseX, Laya.stage.mouseY)) {
                        this.operateItem.bagPosX = -1;
                        this.operateItem.bagPosY = -1;
                        this.operateItem.redGridsVisible(true);
                    }
                    else {
                        this.operateItem.me.x = this.itemDragStartPos.x;
                        this.operateItem.me.y = this.itemDragStartPos.y;
                        this.menuFollowItem(this.operateItem);
                    }
                    let bagUI = this.bagsContainer.getBagUI();
                    bagUI.freshGridsState(new Array());

                }
                else {
                    view.AudioMgr.PlayAudio(10136);
                    //商品完全放置了
                    if (effectBagGrids.length == this.operateItem.itemFillGrids) {
                        let itemLeftUpIndex = bagUI.getNearBy(this.operateItem.getGridGlobalPos(0, 0));
                        this.setItemToBagPos(this.operateItem, bagUI, itemLeftUpIndex.x, itemLeftUpIndex.y);
                    }
                }
            }
            if (this.dragItem != null) {
                this.operateMenu.visible = true;
                this.menuFollowItem(this.dragItem);
            }
            this.dragItem = null;
            this.itemDragStartPos = new Laya.Vector2(0, 0);
            this.itemDragStartRotate = 0;

        }

        private setItemToBagPos(itemUI: UI_Activity_Haidao_Item, bagUI: UI_Activity_Haidao_Bag, posX: number, posY: number) {
            //获取这个格子左上角的全局坐标
            let gridLeftPos = bagUI.getGrid(posX, posY).globalPos;
            itemUI.setPosByLeftUpPos(gridLeftPos);
            this.menuFollowItem(itemUI);
        }


        /**
       * 整理背包
       * @param tidyItems 
       * @param onComplete 
       */
        private tidyBag(tidyItems: basic.Dictionary<number, UI_Activity_Haidao_Item[]>, onComplete: Laya.Handler) {
            let bagsData = new Array();
            //先发送整理数据然后发送购买数据
            for (let index = 0; index < tidyItems.keys().length; index++) {
                let bagId = tidyItems.keys()[index];
                let items = tidyItems.get(bagId);
                let bagData = {
                    bag_id: bagId,
                    items: new Array(),
                    drops: new Array()
                };
                items.forEach((v) => {
                    bagData.items.push({
                        id: v.serverId,
                        pos: [v.bagPosY, v.bagPosX],
                        rotate: v.itemData.rotate * 90
                    });
                })
                bagsData.push(bagData);

            }

            let reqIslandActivityTidyBag = {
                activity_id: UI_Activity_Haidao.activityId,
                bag_data: bagsData,
            };

            // console.log("发送整理请求", JSON.stringify(reqIslandActivityTidyBag));
            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, reqIslandActivityTidyBag, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_MOVE, err, res);
                }
                else {
                    // console.log("整理成功");
                    onComplete?.runWith(res);

                }
            })
        }

        /**
         * 丢弃道具
         * @param itemUI 
         * @param onComplete 
         */
        private dropItem(itemServerId: number, onComplete: Laya.Handler) {
            this.isLock = true;
            let bagsData = new Array();

            // let dropItem = UI_Activity_Haidao.Inst.getItemByServerId(itemUI.serverId);
            //遍历每个背包
            for (let index = 0; index < UI_Activity_Haidao.bagIdArray.length; index++) {
                let bagId = UI_Activity_Haidao.bagIdArray[index];
                let bag = UI_Activity_Haidao.bagDataDic.get(bagId);
                if (!bag.isUnlock) {
                    continue;
                }
                let bagItems = bag.items;
                let bagData = {
                    bag_id: bagId,
                    items: new Array(),
                    drops: new Array()
                };

                bagItems.forEach((item) => {
                    if (item.serverId == itemServerId) {
                        //是需要丢弃的物品
                        bagData.drops.push(item.serverId);
                    }
                    else {
                        bagData.items.push({
                            id: item.serverId,
                            pos: [item.startPosY, item.startPosX],
                            rotate: item.itemLocalData.rotate * 90
                        });
                    }
                })
                bagsData.push(bagData);
            }

            let reqIslandActivityTidyBag = {
                activity_id: UI_Activity_Haidao.activityId,
                bag_data: bagsData,
            };
            // console.log("发送丢弃请求", JSON.stringify(reqIslandActivityTidyBag));
            this.saveCurrentItemData();
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, reqIslandActivityTidyBag, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, err, res);
                }
                else {
                    // console.log("丢弃成功");
                    onComplete?.runWith(res);
                }
            })
        }

        private onClickUpgrade() {
            if (this.isLock) {
                return;
            }
            if (this.isAllBagFull()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4428));
                return;
            }
            this.upgradeBagPage.show();

        }


        public showOperateMenu(state, pos: Laya.Vector2, handler1: Laya.Handler, handler2: Laya.Handler, onMouseDown: Laya.Handler) {
            this.operateMenu.show(state, handler1, handler2, onMouseDown)
            this.operateMenu.me.x = pos.x;
            this.operateMenu.me.y = pos.y - 56;
        }

        public hideOperateMenu() {
            this.operateMenu.visible = false;
        }

        public onClickReset() {
            if (this.isLock) {
                return;
            }
            this.onFreshData();
        }

        private freshUpdateBagBtn() {

            let isFull = this.isAllBagFull();
            let canUnlock = this.isBagCanUpgrade();
            (this.upgradeBtn.me.getChildByName('red_point') as Laya.Image).visible = canUnlock;
            //当背包升级满后，按钮置灰
            this.upgradeBtn.grayed = isFull;
            this.upgradeBtn.titleColor = isFull ? "#9C8781" : "#A9482B";

        }

        /**
         * 是否所有的背包已经升级满了
         */
        private isAllBagFull(): boolean {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let isFull = true;
            keys.forEach((key) => {
                let bagData = UI_Activity_Haidao.bagDataDic.get(key);
                if (bagData.isUnlock) {
                    if (!common.MatrixUtils.isMatrixEqual(bagData.currentMatrix, bagData.allMatrix)) {
                        isFull = false;
                    }
                }
            });
            return isFull;
        }

        private isBagCanUpgrade(): boolean {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let canUnlock = false;
            keys.forEach((key) => {
                let bagData = UI_Activity_Haidao.bagDataDic.get(key);
                if (bagData.isUnlock) {
                    if (!common.MatrixUtils.isMatrixEqual(bagData.currentMatrix, bagData.allMatrix)) {
                        let unLockConfig = bagData.bagConfig.unlock_consume.split('-');
                        if (UI_Bag.get_item_count(Number(unLockConfig[0])) >= Number(unLockConfig[1])) {
                            canUnlock = true;
                        }
                    }
                }

            });
            return canUnlock;
        }

        /**
        * 保存道具数据
        */
        public saveCurrentItemData() {
            let saveData: basic.Dictionary<number, Haidao_ItemUIData> = new basic.Dictionary();
            let oldData = this.showItems;
            oldData.forEach((itemUI, index) => {
                //如果已经创建了实体要保存实体数据
                if (itemUI.serverId != -1) {

                    let uiData: Haidao_ItemUIData = {
                        itemId: itemUI.itemData.id,
                        rotate: itemUI.itemData.rotate,
                        bagId: itemUI.bagId,
                        bagPosX: itemUI.bagPosX,
                        bagPosY: itemUI.bagPosY,
                        posX: itemUI.me.x,
                        posY: itemUI.me.y,
                        isShow: false
                    };
                    saveData.set(itemUI.serverId, uiData)
                }
            });
            this.oldItemData.push(saveData);

        }

        private loadItemData() {
            if (this.oldItemData.length != 0) {
                let loadData = this.oldItemData[0];
                this.oldItemData.splice(0, 1);
                for (let index = 0; index < this.showItems.length; index++) {
                    let itemUI = this.showItems[index];
                    if (itemUI.serverId != -1) {
                        if (loadData.has(itemUI.serverId)) {
                            let uiData = loadData.get(itemUI.serverId);
                            this.removeItemInBag(itemUI);
                            itemUI.setRotate(uiData.rotate);
                            //在背包中
                            if (uiData.bagId != -1) {
                                this.addItemInBag(itemUI, this.bagsContainer.getBagUIById(uiData.bagId), uiData.bagPosX, uiData.bagPosY);
                                itemUI.redGridsVisible(false);
                            }
                            //在空白处
                            else {
                                itemUI.me.x = uiData.posX;
                                itemUI.me.y = uiData.posY;
                                itemUI.redGridsVisible(true);
                                itemUI.bagId = uiData.bagId;
                                itemUI.bagPosX = uiData.bagPosX;
                                itemUI.bagPosY = uiData.bagPosY;
                            }

                        }
                    }
                };
            }
        }

        private clearSaveData() {
            this.oldItemData = new Array();
        }





    }




}