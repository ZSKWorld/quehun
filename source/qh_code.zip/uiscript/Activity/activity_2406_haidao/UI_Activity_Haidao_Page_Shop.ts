module uiscript {
    interface Haidao_BuyData {
        goods_id: number;
        pos: Array<number>;
        rotate: number;
        bag_id: number;
        price: number;
    }

    export interface Haidao_ItemUIData {
        itemId: number;
        rotate: number;
        isShow: boolean;
        bagId: number;
        bagPosX: number;
        bagPosY: number;
        posX: number;
        posY: number;
    }

    export type MsgCompleteHandler = (err, res) => {};
    class SortButton extends UI_Component {
        public clickButton: Laya.Button;
        private arrowUp: Laya.Image;
        private arrowDown: Laya.Image;
        private selectImage: Laya.Image;
        private unselectImage: Laya.Image;

        public isSelect: boolean;
        public isUp: boolean;

        public onCreate(): void {
            this.clickButton = this.me.getChildByName('btn') as Laya.Button;
            this.arrowUp = this.me.getChildByName('arrow_up') as Laya.Image;
            this.arrowDown = this.me.getChildByName('arrow_down') as Laya.Image;
            this.selectImage = this.me.getChildByName('select_bg') as Laya.Image;
            this.unselectImage = this.me.getChildByName('diselect_bg') as Laya.Image;
        }

        public changeSelect(isSelect: boolean) {
            this.isSelect = isSelect;
            this.selectImage.visible = isSelect;
            this.unselectImage.visible = !isSelect;
        }

        public changeState(isUp: boolean) {

            this.isUp = isUp;
            this.arrowUp.visible = isUp;
            this.arrowDown.visible = !isUp;
        }


    }


    class SellPopup extends UI_Component {
        private priceText: Laya.Label;
        private itemIcon: Laya.Image;
        private mineCountText: Laya.Label;
        private mineCostText: Laya.Label;
        private canGetText: Laya.Label;
        private sellTip: Laya.Label;

        private currentSellCountText: Laya.Label;
        private add1Btn: Laya.Button;
        private add5Btn: Laya.Button;
        private minus1Btn: Laya.Button;
        private minus5Btn: Laya.Button;
        private titleText: Laya.Label;

        private sellBtn: UI_Button;
        private cancelBtn: UI_Button;
        private closeBtn: Laya.Button;
        private maskCloseBtn: Laya.Button;
        private moneyIcon: Laya.Image;
        private iconAdapter: common.SpriteAdapter;
        public currentSellCount: number;
        private isLock: boolean = false;


        private itemId: number;
        private itemCost: number;
        private itemCount: number;
        private sellDiscount: number;
        private itemPrice: number;
        private basePath: string = "myres/activity_2406_haidao/"
        private sellPrice: number;


        public onCreate(): void {
            this.priceText = this.me.getChildByName("current_sellprice") as Laya.Label;
            this.mineCountText = this.me.getChildByName("own_count") as Laya.Label;
            this.mineCostText = this.me.getChildByName("current_costprice") as Laya.Label;
            this.canGetText = this.me.getChildByName("price").getChildByName("price") as Laya.Label;
            this.currentSellCountText = this.me.getChildByName("sell_count") as Laya.Label;
            this.itemIcon = this.me.getChildByName("item_icon") as Laya.Image;
            this.moneyIcon = this.me.getChildByName("price").getChildByName("icon") as Laya.Image;
            this.add1Btn = this.me.getChildByName('add_1') as Laya.Button;
            this.add5Btn = this.me.getChildByName('add_5') as Laya.Button;
            this.minus1Btn = this.me.getChildByName('minus_1') as Laya.Button;
            this.minus5Btn = this.me.getChildByName('minus_5') as Laya.Button;
            this.sellTip = this.me.getChildByName("sell_tip") as Laya.Label;
            this.sellBtn = new UI_Button(this.me.getChildByName('confirm_btn') as Laya.Sprite, true);
            this.cancelBtn = new UI_Button(this.me.getChildByName('cancel_btn') as Laya.Sprite, true);
            this.closeBtn = this.me.getChildByName('pop_frame').getChildByName('close_btn') as Laya.Button;
            this.maskCloseBtn = this.me.getChildByName('btn') as Laya.Button;
            this.titleText = this.me.getChildByName('pop_frame').getChildByName('title') as Laya.Label;

            this.sellDiscount = cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).sell_discount;
            this.iconAdapter = new common.SpriteAdapter(this.moneyIcon, this.canGetText, SpriteAdapterType.LEFT2LEFT, 40);


            this.add1Btn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.changeCurrentCount(1);
            });
            this.add5Btn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.changeCurrentCount(5);
            });
            this.minus1Btn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.changeCurrentCount(-1);
            });
            this.minus5Btn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.changeCurrentCount(-5);
            });
            this.sellBtn.setClickListener(new Laya.Handler(this, this.onClickSell));
            this.closeBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.cancelBtn.setClickListener(new Laya.Handler(this, this.onClickClose));

        }

        public show(itemId: number) {
            this.itemId = itemId;
            this.itemCost = UI_Activity_Haidao.Inst.getItemCostInBag(itemId);
            this.itemCount = UI_Activity_Haidao.Inst.getItemsCountInBag(itemId);
            let currentStageData = UI_Activity_Haidao.stageDataDic.get(UI_Activity_Haidao.Inst.currentAtStageId);
            this.itemPrice = currentStageData.todayShopItems.get(this.itemId).price;
            this.sellPrice = Math.floor(this.itemPrice * this.sellDiscount / 100);
            let itemConfig = UI_Activity_Haidao.itemConfigDic.get(this.itemId);
            this.priceText.text = game.Tools.strOfLocalization(4347, [this.sellPrice.toString()]);
            this.mineCostText.text = game.Tools.strOfLocalization(4348, [Math.floor(this.itemCost).toString()]);
            this.itemIcon.skin = game.Tools.localUISrc(this.basePath + itemConfig.icon);
            this.mineCountText.text = game.Tools.strOfLocalization(2212, [this.itemCount.toString()]);
            // this.sellTip.text = game.Tools.strOfLocalization(4349, [this.sellDiscount.toString()]);
            this.sellTip.text = "";
            this.currentSellCount = 1;
            this.currentSellCountText.text = this.currentSellCount.toString();
            this.canGetText.text = Math.floor(this.sellPrice * this.currentSellCount).toString();
            this.titleText.text = game.Tools.eventStrOfLocalization(itemConfig.goods_name);
            this.iconAdapter.fresh();
            this.visible = true;
        }


        private onClickSell() {
            if (this.isLock) {
                return;
            }


            let sellItems = UI_Activity_Haidao.Inst.getItemsInBag(this.itemId, this.currentSellCount);
            // console.log("sell item ", this.currentSellCount,sellItems);

            let sellHandler = new Laya.Handler(this, () => {
                UI_Activity_Haidao_Page_Shop.Inst.sellItem(sellItems, new Laya.Handler(this, () => {

                    this.onClickClose();
                    UI_Activity_Haidao_Congrate.Inst.show(ECongrateType.soldout);
                }));
            });

            if (this.sellPrice < this.itemCost) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4387), sellHandler);
                UI_SecondConfirm.Inst.setBtnState(true, true)
            }
            else {
                sellHandler.run();
            }


        }

        private onClickClose() {
            if (this.isLock) {
                return;
            }
            this.visible = false;

        }

        private changeCurrentCount(value: number) {

            let newValue = this.currentSellCount + value;
            if (newValue < 1) {
                newValue = 1;
            }
            if (newValue > this.itemCount) {
                newValue = this.itemCount;
            }
            this.currentSellCount = newValue;
            this.currentSellCountText.text = newValue.toString();
            this.canGetText.text = Math.floor(this.sellPrice * this.currentSellCount).toString();
            this.iconAdapter.fresh();
        }





    }

    class BuyTipPopup extends UI_Component {
        private txtTitle: Laya.Label;
        private btnConfirm: UI_Button;
        private btnCancel: UI_Button;
        private btnClose: Laya.Button;
        private btnMask: Laya.Button;
        private iconCurrency: Laya.Image;
        private txtCurrencyCount: Laya.Label;
        private txtTip1: Laya.Label;
        private txtTip2: Laya.Label;
        private isLock: boolean = false;
        private father: UI_Activity_Haidao_Page_Shop;
        private onClickBuy: Laya.Handler;
        private onClickCancel: Laya.Handler;

        constructor(com: Laya.Sprite, father: UI_Activity_Haidao_Page_Shop) {
            super(com);
            this.father = father;
        }

        public onCreate(): void {
            this.iconCurrency = this.me.getChildByName("price").getChildByName("icon") as Laya.Image;;
            this.btnConfirm = new UI_Button(this.me.getChildByName('confirm_btn') as Laya.Sprite, true);
            this.btnCancel = new UI_Button(this.me.getChildByName('cancel_btn') as Laya.Sprite, true);
            this.btnClose = this.me.getChildByName('pop_frame').getChildByName('close_btn') as Laya.Button;
            this.btnMask = this.me.getChildByName('btn') as Laya.Button;
            this.txtTitle = this.me.getChildByName('pop_frame').getChildByName('title') as Laya.Label;
            this.txtCurrencyCount = this.me.getChildByName('price').getChildByName('price') as Laya.Label;
            this.txtTip1 = this.me.getChildByName('tip1') as Laya.Label;
            this.txtTip2 = this.me.getChildByName('tip2') as Laya.Label;
            this.btnConfirm.setClickListener(new Laya.Handler(this, this.onClickBuyBtn));
            this.btnClose.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.btnMask.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.btnCancel.setClickListener(new Laya.Handler(this, this.onClickCancelBtn));
            this.txtTip1.text = game.Tools.strOfLocalization(4343);
            this.txtTip2.text = game.Tools.strOfLocalization(4344);
            this.txtTitle.text = game.Tools.strOfLocalization(4342);
            (this.me.getChildByName('confirm_btn').getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(4345);
            (this.me.getChildByName('cancel_btn').getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(4346);
        }

        public show(currencyCount: number, onClickBuy: Laya.Handler, onClickCancel: Laya.Handler, confirmStr: string = "", cancelString: string = "", tipString1: string | null = null, tipString2: string | null = null) {
            this.visible = true;
            this.txtCurrencyCount.text = "-" + currencyCount.toString();
            this.onClickBuy = onClickBuy;
            this.onClickCancel = onClickCancel;
            //如果当前的金额大于付款值，需要置灰
            let canPay = UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId) >= currencyCount

            this.btnConfirm.grayed = !canPay;
            this.btnConfirm.titleColor = !canPay ? UI_Activity_Haidao.colorGray : UI_Activity_Haidao.colorWhite;
            this.txtCurrencyCount.color = !canPay ? UI_Activity_Haidao.colorRed : UI_Activity_Haidao.colorBrown;
            this.btnConfirm.title = confirmStr == "" ? game.Tools.strOfLocalization(4345) : confirmStr;
            this.btnCancel.title = confirmStr == "" ? game.Tools.strOfLocalization(4346) : cancelString;
            this.txtTip1.text = tipString1 == null ? game.Tools.strOfLocalization(4343) : tipString1;
            this.txtTip2.text = tipString2 == null ? game.Tools.strOfLocalization(4344) : tipString2;

        }


        private onClickBuyBtn() {
            if (this.isLock) {
                return;
            }
            this.onClickBuy?.run();
            this.onClickClose();
        }

        private onClickCancelBtn() {
            if (this.isLock) {
                return;
            }
            this.onClickCancel?.run();
            this.visible = false;
        }

        private onClickClose() {
            if (this.isLock) {
                return;
            }

            this.visible = false;
        }


    }

    class ShopListItem extends UI_Component {

        public priceText: Laya.Label;
        public rateText: Laya.Label;
        public itemIcon: Laya.Image;
        public shopCountText: Laya.Label;
        public mineCountText: Laya.Label;
        public mineCostText: Laya.Label;
        public hotImage: Laya.Image;
        public saleImage: Laya.Image;
        public buyButton: Laya.Button;
        public sellButton: UI_Button;

        private hotColor: string = "#DF2D36";
        private saleColor: string = "#4FB37C";
        private basePath: string = "myres/activity_2406_haidao/"

        public onCreate(): void {
            this.priceText = this.me.getChildByName('price') as Laya.Label;
            this.rateText = this.me.getChildByName('rate') as Laya.Label;
            this.shopCountText = this.me.getChildByName('shop_count') as Laya.Label;
            this.mineCountText = this.me.getChildByName('mine_count') as Laya.Label;
            this.mineCostText = this.me.getChildByName('mine_cost') as Laya.Label;
            this.itemIcon = this.me.getChildByName('item').getChildByName("icon") as Laya.Image;
            this.hotImage = this.me.getChildByName('hot_lable') as Laya.Image;
            this.saleImage = this.me.getChildByName('sale_lable') as Laya.Image;
            this.buyButton = this.me.getChildByName('buy_btn') as Laya.Button;
            this.sellButton = new UI_Button(this.me.getChildByName('sell_btn') as Laya.Sprite, true);

        }

        public setPrice(price: number) {
            this.priceText.text = price.toString();

        }

        public setRate(rate: number) {
            let trueRate: number = rate - 100;
            let rateStr = "";
            if (trueRate > 0) {
                rateStr = game.Tools.strOfLocalization(4325, ["+" + trueRate.toString()]);
            }
            else if (trueRate < 0) {
                rateStr = game.Tools.strOfLocalization(4325, [trueRate.toString()]);
            }
            this.priceText.y = trueRate == 0 ? 72 : 52
            this.rateText.text = rateStr;
            this.rateText.color = trueRate > 0 ? this.hotColor : this.saleColor;
            this.rateText.visible = trueRate != 0;
            this.priceText.y = this.rateText.visible ? 52 : 72;
        }

        public setNewsEffect(effect: number) {
            this.hotImage.visible = effect == 1;
            this.saleImage.visible = effect == -1
        }

        public setIcon(iconName: string) {
            let path = this.basePath + iconName;
            this.itemIcon.skin = game.Tools.localUISrc(path);
        }

        public setCount(count: number) {
            this.shopCountText.text = count.toString();
        }

        public setMineCount(count: number) {
            this.mineCountText.text = count.toString();
        }

        public setMineCost(count: number) {
            let str = Math.floor(count).toString();
            if (count == 0) {
                str = game.Tools.strOfLocalization(4339);
            }
            this.mineCostText.text = str;
        }


    }

    class ShopCarGrid extends UI_Component {
        private icon: Laya.Image;
        private returnImg: Laya.Image;
        private basePath: string = "myres/activity_2406_haidao/";
        public get itemId(): number {
            if (this.carItem != null) {
                return this.carItem.itemData.id;
            }
            return -1;
        };
        public get rotation(): number {
            if (this.carItem != null) {
                return this.carItem.itemData.rotate;
            }
            return 0;
        };
        public carItem: CarItem;

        public onCreate(): void {
            this.icon = this.me.getChildByName('item') as Laya.Image;
            this.returnImg = this.me.getChildByName('back_img') as Laya.Image;
            this.carItem = null;


        }

        public setItem(carItem: CarItem) {
            this.carItem = carItem;
            let itemConfig = UI_Activity_Haidao.itemConfigDic.get(this.itemId);
            this.icon.skin = game.Tools.localUISrc(this.basePath + itemConfig.icon);
            this.icon.rotation = this.rotation * 90;
            this.icon.visible = true;
            this.icon.alpha = carItem.isShow ? 1 : 0.5;
            this.returnImg.visible = !carItem.isShow;

        }

        public clearItem() {
            this.icon.skin = "";
            this.carItem = null;
            this.icon.alpha = 1;
            this.returnImg.visible = false;
        }

        public rotate() {
            this.carItem.itemData.rotateItem();
            this.icon.rotation = this.rotation * 90;
        }




    }

    interface CarItem {
        itemData: GridItem;
        isShow: boolean;
    }





    export class UI_Activity_Haidao_Page_Shop extends UIBase {
        public static Inst: UI_Activity_Haidao_Page_Shop = null;
        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_shopUI);
            UI_Activity_Haidao_Page_Shop.Inst = this;
        }

        private isLock: boolean = false;
        /**
        * 关闭按钮
        */
        private closeBtn: Laya.Button;
        private title: Laya.Label;
        private shopMoney: Laya.Label;
        private shopMoneyInfo: Laya.Button;
        private listContainer: Laya.Sprite;
        private shopCarSprite: Laya.Sprite;
        private scrollView: capsui.CScrollView;
        private priceTipBtn: Laya.Button;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniChange: Laya.FrameAnimation;
        private buyBtn: UI_Button;
        private clearShopCarBtn: Laya.Button;
        private currentStageId: number;
        private currentStageData: Activity_Haidao_Stage;
        private showItemKeys: Array<number>;
        /**
         * 0涨幅从高到低  1涨幅从低到高  2价格从高到低 3价格从低到高
         */
        private sortWay: number = 0;
        private popSellPage: SellPopup;
        private buyTipPage: BuyTipPopup;
        private sortByDiscountBtn: SortButton;
        private sortByPriceBtn: SortButton;

        private shopCarGrids: Array<ShopCarGrid> = new Array();
        private carMaxCount: number = 4;
        private carItems: Array<CarItem> = new Array();
        /**
         * 拷贝的服务器数据，
         */
        private currentBagData: basic.Dictionary<number, GridBag> = new basic.Dictionary;
        private bagsContainer: UI_Activity_Haidao_BagsContainer;

        private onItemFreshHandler: Laya.Handler;
        private operateLayer: Laya.Sprite;
        private emptyLayer: Laya.Sprite;
        private operateMenu: UI_Activity_Haidao_OperateMenu;
        private itemTemplate: capsui.UICopy;
        private upgradeBtn: Laya.Button;
        private upgradeBagPage: UI_Activity_Haidao_UpgradeBag;
        /**
         * 鼠标摁下的坐标
         */
        private clickStartPos: Laya.Vector2;
        /**
         * 当前是否在执行拖拽
         */
        private isDrag: boolean;
        /**
         * 当前点击的商店格子的index
         */
        private clickShopGridIndex: number = -1;
        /**
         * 当前正在被拖拽的物体
         */
        private dragItem: UI_Activity_Haidao_Item;
        /**
         * 当前所有在显示的可操作商品
         */
        private showItems: Array<UI_Activity_Haidao_Item> = new Array();
        /**
         * 当前是否在操作任何物体（点击格子，点击商品，点击操作按钮）
         */
        public isOperate: boolean = false;
        /**
         * 当前操作的物体
         */
        private operateItem: UI_Activity_Haidao_Item;
        private itemDragStartPos: Laya.Vector2;
        private itemDragStartRotate: number;
        private dragOffset: Laya.Vector2;
        private isMouseDown: boolean = false;
        /**
         * 购物车旧数据，<格子Index，数据>
         */
        private oldShopData: Array<basic.Dictionary<number, Haidao_ItemUIData>> = new Array();
        /**
         * 物品旧数据<serverId,数据>
         */
        private oldItemData: Array<basic.Dictionary<number, Haidao_ItemUIData>> = new Array();
        private isClickBuy: boolean = false;

        private updateTime: number;





        public onCreate(): void {
            let topMenu = this.me.getChildByName("top_menu") as Laya.Sprite;
            this.closeBtn = topMenu.getChildByName('return_btn') as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.title = topMenu.getChildByName('title').getChildByName("title") as Laya.Label;
            this.shopMoney = this.me.getChildByName('shop_money_count').getChildByName("value_text") as Laya.Label;
            this.shopMoneyInfo = this.me.getChildByName('shop_money_count').getChildByName("info_btn") as Laya.Button;
            this.listContainer = this.me.getChildByName('content') as Laya.Sprite;
            this.aniShow = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_shopUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_shopUI).hide;
            this.aniChange = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_shopUI).qiehuan;
            this.scrollView = this.listContainer.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.shopListItemRender));
            let popupParent = this.me.getChildByName('popup') as Laya.Sprite;
            this.popSellPage = new SellPopup(popupParent.getChildByName("sell_popup") as Laya.Sprite);
            this.buyTipPage = new BuyTipPopup(popupParent.getChildByName("buy_tip_popup") as Laya.Sprite, this);
            this.sortByDiscountBtn = new SortButton(this.me.getChildByName("sort_by_discount") as Laya.Sprite);
            this.sortByPriceBtn = new SortButton(this.me.getChildByName("sort_by_price") as Laya.Sprite);
            this.sortByDiscountBtn.clickButton.clickHandler = new Laya.Handler(this, () => {
                if (this.sortByDiscountBtn.isSelect) {
                    this.sortByDiscountBtn.changeState(!this.sortByDiscountBtn.isUp);
                }
                else {
                    this.sortByDiscountBtn.changeSelect(true);
                    this.sortByPriceBtn.changeSelect(false);
                }
                this.changeSortWay();
            });

            this.sortByPriceBtn.clickButton.clickHandler = new Laya.Handler(this, () => {
                if (this.sortByPriceBtn.isSelect) {
                    this.sortByPriceBtn.changeState(!this.sortByPriceBtn.isUp);
                }
                else {
                    this.sortByDiscountBtn.changeSelect(false);
                    this.sortByPriceBtn.changeSelect(true);
                }
                this.changeSortWay();
            });

            //初始化购物车格子
            let shopCar = this.me.getChildByName('shop_car') as Laya.Sprite;
            for (let index = 0; index < this.carMaxCount; index++) {
                let grid = shopCar.getChildByName('grid' + (index + 1)) as Laya.Sprite;
                let newGrid = new ShopCarGrid(grid);
                newGrid.me.on(Laya.Event.MOUSE_DOWN, this, () => {
                    // console.log("格子", index, "MOUSE_DOWN");
                    if (this.isLock) {
                        return;
                    }
                    if (newGrid.carItem) {
                        //如果当前格子显示
                        if (newGrid.carItem.isShow) {
                            this.isOperate = true;
                            this.clickShopGridIndex = index;
                            this.onClickShopCarGrid();
                        }
                        else {
                            this.onOperateFinish();
                            newGrid.carItem.isShow = true;
                            //将物品返回购物车，通过实体id找到物体，销毁该物体
                            this.returnItemToCar(newGrid.carItem.itemData.entityId);
                        }
                    }
                });
                this.shopCarGrids.push(newGrid);
            }

            this.priceTipBtn = this.listContainer.getChildByName('title').getChildByName("title5").getChildByName("help_btn") as Laya.Button;
            this.priceTipBtn.clickHandler = new Laya.Handler(this, () => {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4337));
            });
            this.bagsContainer = new UI_Activity_Haidao_BagsContainer(this.me.getChildByName("bags") as Laya.Sprite);
            this.bagsContainer.onTabChange = new Laya.Handler(this, this.onBagTabChange);
            this.bagsContainer.onClickReset = new Laya.Handler(this, this.onClickReset);
            this.onItemFreshHandler = new Laya.Handler(this, () => {
                this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
            });
            let operate = this.me.getChildByName('oprate_layer') as Laya.Sprite;
            this.operateLayer = operate.getChildByName('itemParent') as Laya.Sprite;
            this.emptyLayer = this.me.getChildByName('empty_layer') as Laya.Sprite;
            this.operateMenu = new UI_Activity_Haidao_OperateMenu(operate.getChildByName('operate_btns') as Laya.Sprite);
            this.operateMenu.visible = false;

            let itemUI = this.operateLayer.getChildByName('itemTemplete') as Laya.Sprite;
            itemUI.visible = false;
            this.itemTemplate = itemUI.scriptMap['capsui.UICopy'] as capsui.UICopy;
            this.upgradeBtn = (this.me.getChildByName("bags") as Laya.Sprite).getChildByName('update') as Laya.Button;
            this.upgradeBtn.clickHandler = new Laya.Handler(this, () => {
                this.onClickUpgrade();
            });
            this.upgradeBagPage = new UI_Activity_Haidao_UpgradeBag(popupParent.getChildByName('upgrade') as Laya.Sprite);
            this.upgradeBagPage.visible = false;
            this.buyBtn = new UI_Button(this.me.getChildByName('pay_btn') as Laya.Sprite, true);
            this.buyBtn.setClickListener(new Laya.Handler(this, () => {
                this.onClickBuy();
            }))
            if (GameMgr.client_language == 'en') {
                (this.buyBtn.me.getChildByName('tip') as Laya.Label).fontSize = 35;
            }
            this.shopMoneyInfo.clickHandler = new Laya.Handler(this, () => {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4329));
            });
            this.shopCarSprite = this.me.getChildByName('shop_car') as Laya.Sprite;
            this.clearShopCarBtn = shopCar.getChildByName('clear_shop_btn') as Laya.Button;
            this.clearShopCarBtn.clickHandler = new Laya.Handler(this, this.onClickResetCar);
            let clearBtnBg = this.clearShopCarBtn.getChildByName('bg') as Laya.Image;
            let clearShopCarBtnText = this.clearShopCarBtn.getChildByName('price_text') as Laya.Label;
            let clearShopCarBtnAdapter = new common.SpriteAdapter(clearBtnBg, clearShopCarBtnText, SpriteAdapterType.WIDTH2WIDTH, -16);
            clearShopCarBtnAdapter.fresh();

        }




        public show() {
            this.clearSaveData();
            //初始化数据
            this.freshData();
            this.showItemKeys = this.currentStageData.todayShopItems.keys();
            //初始化商品数据
            let stageConfig = this.currentStageData.stageConfig;
            //地区名称
            this.title.text = game.Tools.strOfLocalization(stageConfig.zone_name);
            this.scrollView.reset();
            this.scrollView.addItem(this.showItemKeys.length);
            //初始化排序
            this.sortByDiscountBtn.changeSelect(true);
            this.sortByPriceBtn.changeSelect(false);
            this.sortByDiscountBtn.changeState(false);
            this.sortByPriceBtn.changeState(true);
            this.changeSortWay();
            this.onFreshData();
            UI_Activity_Haidao.Inst.showPopupBg(true, true);
            this.isMouseDown = false;
            this.operateMenu.visible = false;
            this.enable = true;
            this.isLock = true;
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.isLock = false;
            });
            view.AudioMgr.PlayAudio(10131);
        }


        public onEnable(): void {
            this.bindEvent();
        }

        private bindEvent() {
            UI_Bag.add_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            //显示背景
            this.me.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            Laya.stage.on(Haidao_EventId.UPDATE_DATA, this, this.onFreshData);
            Laya.stage.on(Haidao_EventId.CLICK_BAG_UPDATE, this, this.beforeUpdate);
            Laya.stage.on(Haidao_EventId.UNLOCK_BAG, this, this.beforeUpdate);
            Laya.timer.loop(1000, this, this.passDay);
        }


        public showGuide() {
            this.currentStageId = 1;
            this.currentStageData = UI_Activity_Haidao.stageDataDic.get(this.currentStageId);
            app.Log.log('this.currentStageData' + JSON.stringify(this.currentStageData));
            let serverData = UI_Activity_Haidao.bagDataDic;
            this.currentBagData.clear();
            serverData.keys().forEach((v, i) => {
                let bagId = v;
                let bagData = serverData.get(bagId);
                this.currentBagData.set(bagId, bagData.clone());
            });
            this.clickShopGridIndex = -1;
            this.isDrag = false;
            this.dragItem = null;
            this.operateItem = null;
            //刷新背包数据
            this.bagsContainer.setData(this.currentBagData);
            //地区名称
            this.title.text = game.Tools.strOfLocalization(4314);
            this.scrollView.reset();
            this.scrollView.addItem(1);
            //初始化排序
            this.sortByDiscountBtn.changeSelect(true);
            this.sortByPriceBtn.changeSelect(false);
            this.sortByDiscountBtn.changeState(false);
            this.sortByPriceBtn.changeState(false);
            this.shopMoney.text = this.currentStageData.shopMoney.toString();
            this.bagsContainer.setMoney(UI_Activity_Haidao.guideShopData.bagCurrencyCount);
            this.buyBtn.title = "-0";
            this.buyBtn.grayed = true;
            this.buyBtn.titleColor = "#9C8781";
            let tipText = this.buyBtn.me.getChildByName("tip") as Laya.Label;
            tipText.color = "#9C8781";
            game.Tools.setGray(this.upgradeBtn, true);
            (this.upgradeBtn.getChildByName('red_point') as Laya.Image).visible = false;
            //清理购物车
            this.clearShopCar();
            this.disposeAllItem();
            this.generateGuideBagItem();
            this.onBagTabChange(false);
            UI_Activity_Haidao.Inst.showPopupBg(true, true);
            this.enable = true;
        }

        public refreshGuideState(type: E_Act_Yindao_Type) {
            switch (type) {
                case E_Act_Yindao_Type.showGoodsTip: {
                    this.operateMenu.show(0, null, null, null, Math.floor(UI_Activity_Haidao.guideShopData.item.price * UI_Activity_Haidao.guideShopData.item.itemShopConfig.discount / 100));
                    break;
                }
                case E_Act_Yindao_Type.soldOutSuccess: {
                    this.operateMenu.visible = false;
                    UI_Activity_Haidao_Congrate.Inst.show(ECongrateType.soldout);
                    break;
                }
                case E_Act_Yindao_Type.dealCompleted: {
                    UI_Activity_Haidao_Congrate.Inst.enable = false;
                    let price = cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).guide_bottle_price;
                    UI_Activity_Haidao.guideShopData = {
                        item: {
                            id: 1001,
                            count: 0,
                            itemShopConfig: {
                                count: 3,
                                discount: cfg.activity.island_activity.get(UI_Activity_Haidao.activityId).sell_discount
                            },
                            discount: Math.floor(price / UI_Activity_Haidao.itemConfigDic.get(1001).price * 100),
                            price,
                            isEffectByNews: 0
                        },
                        bagCurrencyCount: 0
                    };
                    this.scrollView.wantToRefreshAll();
                    this.shopMoney.text = (this.currentStageData.shopMoney - Math.floor(UI_Activity_Haidao.guideShopData.item.price * UI_Activity_Haidao.guideShopData.item.itemShopConfig.discount / 100) * 3).toString();
                    this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
                    this.emptyLayer.removeChildren();
                    this.freshUpdateBagBtn();
                    break;
                }
            }
        }

        private onFreshData() {
            this.freshData();
            this.freshUI();
            //清理购物车
            this.clearShopCar();
            this.disposeAllItem();
            this.generateBagItem();

            if (!this.isClickBuy) {
                this.loadItemData();
                this.loadShopData();
            }
            else {
                this.isClickBuy = false;
            }

            this.freshUpdateBagBtn();
            this.upgradeBagPage.freshData();
            this.freshBuyButton();
            this.bagsContainer.getBagUI().freshGridsState(new Array());
            this.onBagTabChange(false);

        }

        //数据处理
        private freshData() {
            this.currentStageId = UI_Activity_Haidao.Inst.currentAtStageId;
            this.currentStageData = UI_Activity_Haidao.stageDataDic.get(this.currentStageId);
            let serverData = UI_Activity_Haidao.bagDataDic;
            this.currentBagData.clear();
            serverData.keys().forEach((v, i) => {
                let bagId = v;
                let bagData = serverData.get(bagId);
                this.currentBagData.set(bagId, bagData.clone());
            });
            this.clickShopGridIndex = -1;
            this.isDrag = false;
            this.dragItem = null;
            this.operateItem = null;
            //刷新背包数据
            this.bagsContainer.setData(this.currentBagData);
            // console.log("当前背包的数据是", this.currentBagData);


        }



        private freshUI() {
            this.shopMoney.text = this.currentStageData.shopMoney.toString();
            this.freshList();
            this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
            this.freshBuyButton();

        }

        private generateGuideBagItem() {
            //全都假的只有ui不会动背包数据
            let index = 0;
            let bagId = this.currentBagData.keys()[index];
            let bagData = this.currentBagData.get(bagId);
            let items = [];
            let baseMatrix = GridBagUtils.Inst.convertStringToMatrix(UI_Activity_Haidao.itemConfigDic.get(1001).matrix);
            let grid1 = GridBagUtils.Inst.getItem(1001, baseMatrix);
            let grid2 = GridBagUtils.Inst.getItem(1001, baseMatrix);
            grid1.rotate = 0;
            items.push(new ItemDataInBag(1001, -1, 101, 1, 1, grid1));
            grid2.rotate = 3;
            items.push(new ItemDataInBag(1001, -1, 101, 2, 2, grid2));
            items.push(new ItemDataInBag(1001, -1, 101, 3, 1, grid2));
            for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
                let item = items[itemIndex];
                let itemUI = this.createItemUI(item.itemLocalData, true);
                itemUI.serverId = item.serverId;
                let bagUI = this.bagsContainer.getBagUIById(bagId)
                let posX = item.startPosX;
                let posY = item.startPosY;
                //获取这个格子左上角的全局坐标
                let gridLeftPos = bagUI.getGrid(posX, posY).globalPos;
                itemUI.setPosByLeftUpPos(gridLeftPos);
                if (itemIndex == 0) {
                    this.menuFollowItem(itemUI);
                }
                this.emptyLayer.addChild(itemUI.me);
            }
        }

        //生成背包内的物品
        private generateBagItem() {
            //生每个背包内的物品ui
            for (let index = 0; index < this.currentBagData.keys().length; index++) {
                let bagId = this.currentBagData.keys()[index];
                let bagData = this.currentBagData.get(bagId);
                let items = bagData.items;
                for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
                    let item = items[itemIndex];
                    let itemUI = this.createItemUI(item.itemLocalData, true);
                    itemUI.serverId = item.serverId;
                    this.addItemInBag(itemUI, this.bagsContainer.getBagUIById(bagId), item.startPosX, item.startPosY);
                    this.emptyLayer.addChild(itemUI.me);

                }
            }

        }

        //切换背包页签
        private onBagTabChange(anim: boolean = false) {
            //指定背包id的物品显示
            for (let index = 0; index < this.showItems.length; index++) {
                let item = this.showItems[index];
                let bagUI = this.bagsContainer.getBagUI();
                if (item.bagId == -1) {
                    item.visible = true;
                }
                else {
                    item.visible = item.bagId == bagUI.bagId;
                }
            }
            if (anim) {
                view.AudioMgr.PlayAudio(10134);
                // 取消切换背包
                // this.isLock = true;
                // this.aniChange.play(0, false);
                // Laya.timer.once(this.aniChange.count * this.aniChange.interval, this, () => {
                //     this.isLock = false;
                // })
            }
        }


        private freshList() {
            this.scrollView.wantToRefreshAll();
            //记录当前时间
            // this.updateTime = 
            this.updateTime = Math.floor(game.Tools.getServerTime() / 1000);
        }

        private passDay() {
            if (!UI_Activity.activity_is_running(UI_Activity_Haidao.activityId)) {
                return;
            }
            if (!this.enable) {
                return;
            }
            let isPassDay = !game.Tools.isPassedRefreshTimeServer(this.updateTime);
            if (isPassDay) {
                this.updateTime = Math.floor(game.Tools.getServerTime() / 1000);
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4439), new Laya.Handler(this, () => {
                    this.saveCurrentItemData();
                    this.onFreshData();
                    this.changeSortWay();
                    if (this.operateItem != null) {
                        this.menuFollowItem(this.operateItem);
                    }
                    else {
                        this.operateMenu.visible = false;
                    }
                }));
            }
        }

        private freshShopCar() {
            let renderArray: Array<CarItem> = new Array();
            for (let index = 0; index < this.carItems.length; index++) {
                let item = this.carItems[index];
                renderArray.push(item);
            }
            for (let index = 0; index < this.shopCarGrids.length; index++) {
                let carGrid = this.shopCarGrids[index];
                if (index < renderArray.length) {
                    carGrid.setItem(renderArray[index]);
                }
                else {
                    carGrid.clearItem();
                }

            }
            this.clearShopCarBtn.visible = this.carItems.length == 0 ? false : true;
        }

        private changeSortWay() {
            if (this.sortByDiscountBtn.isSelect) {
                if (this.sortByDiscountBtn.isUp) {
                    this.sortWay = 1;
                }
                else {
                    this.sortWay = 0;
                }
            } else {
                if (this.sortByPriceBtn.isUp) {
                    this.sortWay = 3;
                }
                else {
                    this.sortWay = 2;
                }
            }

            this.showItemKeys = this.showItemKeys.sort((a, b) => {
                if (this.sortWay == 0) {
                    return this.sortItemByDiscountUp(a, b);
                }
                if (this.sortWay == 1) {
                    return this.sortItemByDiscountDown(a, b);
                }
                if (this.sortWay == 2) {
                    return this.sortItemByPriceUp(a, b);
                }
                if (this.sortWay == 3) {
                    return this.sortItemByPriceDown(a, b);
                }
            });
            this.freshList();
        }

        /**
        * 列表Item渲染的方法
        * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
        */
        private shopListItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: ShopListItem = obj.cache_data.item;
            if (!cache_data) {
                cache_data = new ShopListItem(container);
                obj.cache_data.item = cache_data;
            }
            if (UI_Activity_Haidao.duringGuide) {
                const shopData = UI_Activity_Haidao.guideShopData.item;
                const itemConfig = UI_Activity_Haidao.itemConfigDic.get(shopData.id);
                cache_data.setPrice(Math.floor(shopData.price));
                cache_data.setRate(shopData.discount);
                cache_data.setIcon(itemConfig.icon);
                //商店里有
                cache_data.setCount(shopData.itemShopConfig.count);
                cache_data.setNewsEffect(0);
                cache_data.mineCostText.text = '0';
                //当前拥有
                cache_data.setMineCount(shopData.count);
                cache_data.sellButton.grayed = shopData.count == 0;
                cache_data.sellButton.titleColor = shopData.count == 0 ? "#9C8781" : "#FFFFF7";
                cache_data.buyButton.skin = shopData.count == 0 ? game.Tools.localUISrc("myres/activity_2406_haidao/station_shopping_car_button.png") : game.Tools.localUISrc("myres/activity_2406_haidao/island_station_station_shopping_car_button.png");
                return;
            }
            let itemId = this.showItemKeys[index];
            let shopData = this.currentStageData.todayShopItems.get(itemId);
            let itemConfig = UI_Activity_Haidao.itemConfigDic.get(itemId);

            cache_data.setPrice(Math.floor(shopData.price));
            cache_data.setRate(shopData.discount);
            cache_data.setIcon(itemConfig.icon);
            let shopCount = shopData.count - this.getCountInCar(itemId);
            cache_data.setCount(shopCount);
            cache_data.setNewsEffect(shopData.isEffectByNews);
            cache_data.setMineCost(UI_Activity_Haidao.Inst.getItemCostInBag(itemId));
            let mineCount = UI_Activity_Haidao.Inst.getItemCostInBag(itemId);
            cache_data.setMineCount(UI_Activity_Haidao.Inst.getItemsCountInBag(itemId));
            cache_data.sellButton.grayed = mineCount == 0;
            cache_data.sellButton.titleColor = mineCount == 0 ? "#9C8781" : "#FFFFF7";

            cache_data.sellButton.setClickListener(new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }

                // 如果当前未持有则弹出提示框
                if (mineCount == 0) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4386));
                    return;
                }

                this.popSellPage.show(itemId);

            }))

            cache_data.buyButton.skin = shopCount == 0 ? game.Tools.localUISrc("myres/activity_2406_haidao/island_station_station_shopping_car_button.png") : game.Tools.localUISrc("myres/activity_2406_haidao/station_shopping_car_button.png");
            // 加入购物车
            cache_data.buyButton.clickHandler = new Laya.Handler(this, () => {

                if (this.isLock) {
                    return;
                }
                //商品售完
                if (shopCount == 0) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4384));
                    return;
                }
                let gridIndex = this.getEmptyGrid();
                //购物车已满
                if (gridIndex == -1) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4385));
                    return;
                }
                let newGridItem = GridBagUtils.Inst.getItem(itemId, GridBagUtils.Inst.convertStringToMatrix(itemConfig.matrix));
                this.addItemInCar(newGridItem);
            });
        }


        /**
         * 给物品列表排序 商品显示排序：涨幅由大到小
         * @param itemAId  
         * @param itemBId 
         * @returns 
         */
        private sortItemByDiscountUp(itemAId: number, itemBId: number) {
            let itemA = this.currentStageData.todayShopItems.get(itemAId);
            let itemB = this.currentStageData.todayShopItems.get(itemBId);
            let weightA: number = itemA.discount * 10000 + itemA.price;
            let weightB: number = itemB.discount * 10000 + itemB.price;
            return weightB - weightA;
        }

        private sortItemByDiscountDown(itemAId: number, itemBId: number) {
            let itemA = this.currentStageData.todayShopItems.get(itemAId);
            let itemB = this.currentStageData.todayShopItems.get(itemBId);
            let weightA: number = itemA.discount * 10000 + itemA.price;
            let weightB: number = itemB.discount * 10000 + itemB.price;
            return weightA - weightB;
        }

        /**
         * 给物品列表排序 商品显示排序：价格由大到小
         * @param itemAId  
         * @param itemBId 
         * @returns 
         */
        private sortItemByPriceUp(itemAId: number, itemBId: number) {
            let itemA = this.currentStageData.todayShopItems.get(itemAId);
            let itemB = this.currentStageData.todayShopItems.get(itemBId);
            let weightA: number = itemA.discount + itemA.price * 10000;
            let weightB: number = itemB.discount + itemB.price * 10000;
            return weightB - weightA;
        }

        private sortItemByPriceDown(itemAId: number, itemBId: number) {
            let itemA = this.currentStageData.todayShopItems.get(itemAId);
            let itemB = this.currentStageData.todayShopItems.get(itemBId);
            let weightA: number = itemA.discount + itemA.price * 10000;
            let weightB: number = itemB.discount + itemB.price * 10000;
            return weightA - weightB;
        }

        public hide(force: boolean = false) {
            if (!this.enable) {
                return;
            }
            UI_Activity_Haidao.Inst.showPopupBg(false, true);
            this.clearPage();
            this.removeEvent();
            if (force) {
                this.enable = false;
                UI_Activity_Haidao.Inst.backToMain();
                return;
            }
            
            this.isLock = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.enable = false;
                UI_Activity_Haidao.Inst.backToMain();
            });

        }


        public onDisable(): void {
            this.removeEvent();
        }

        private removeEvent() {
            UI_Bag.remove_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            Laya.stage.off(Haidao_EventId.UPDATE_DATA, this, this.onFreshData);
            Laya.stage.off(Haidao_EventId.CLICK_BAG_UPDATE, this, this.beforeUpdate);
            Laya.stage.off(Haidao_EventId.UNLOCK_BAG, this, this.beforeUpdate);
            this.me.off(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.off(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.off(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            Laya.timer.clearAll(this);
        }

        private clearPage() {
            this.disposeAllEffect();
            this.disposeAllItem();
            UI_FlyItemFactory.Inst.recycleAllFlyItem(this.coinSign);
        }



        private onClickClose() {
            if (this.isLock) {
                return;
            }
            //检测是否所有的已购买商品已经在背包内
            for (let index = 0; index < this.showItems.length; index++) {
                let item = this.showItems[index];
                if (item.serverId != -1 && item.bagId == -1) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4391), new Laya.Handler(this, () => {
                        this.hide();
                    }), null, 960, 530, 4392);
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
            }

            let needToPay: number = 0;
            //需要整理的物品
            let needToTidy = this.getNeedToTidy();
            //需要支付的物品
            let needToPayItems = this.getNeedToPay();
            let needToPayItemsData = new Array();

            let tidyItems: basic.Dictionary<number, UI_Activity_Haidao_Item[]> = new basic.Dictionary();
            for (let index = 0; index < needToPayItems.length; index++) {
                let item = needToPayItems[index];
                let itemId = item.itemData.id;
                let itemData = this.currentStageData.todayShopItems.get(itemId);
                needToPay += Math.floor(itemData.price * UI_Activity_Haidao.sellDiscount / 100);
                needToPayItemsData.push(this.convertItemUIToBuyData(item));
            }
            for (let index = 0; index < needToTidy.length; index++) {
                let item = needToTidy[index];
                if (!tidyItems.get(item.bagId)) {
                    tidyItems.set(item.bagId, new Array());
                }
                tidyItems.get(item.bagId).push(item);
            }

            //当前购物车内没有物品
            if (this.carItems.length == 0) {
                //发送整理背包的请求
                this.tidyBag(tidyItems, new Laya.Handler(this, () => {
                    this.hide();
                }))
                return;
            }



            if (needToPayItems.length == 0) {
                //购物车里有物品，但是没有物品放置
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4395), new Laya.Handler(this, () => {
                    this.tidyBag(tidyItems, new Laya.Handler(this, () => {
                        this.hide();
                    }))
                }), null, 960, 530, 4396);
                UI_SecondConfirm.Inst.setBtnState(true, true);
            }
            else {
                //购物车里有物品，且放置到了背包内
                let buyItemsHandler = new Laya.Handler(this, () => {
                    let onSendTidyFinish = () => {
                        this.buyItemsByData(needToPayItemsData, new Laya.Handler(this, () => {
                            this.hide();
                        }))
                    }
                    if (tidyItems.getCount() == 0) {
                        onSendTidyFinish();
                    }
                    else {
                        this.tidyBag(tidyItems, new Laya.Handler(this, (res) => {
                            onSendTidyFinish();
                        }))

                    }
                });
                let cancelHandler = new Laya.Handler(this, () => {
                    this.tidyBag(tidyItems, new Laya.Handler(this, (res) => {
                        this.hide();
                    }));
                });
                //如果钱不够则直接保存并退出
                if (needToPay > UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId)) {
                    cancelHandler.run();
                    return;
                }
                //购物车里的物品全部放置到了背包内，但是没结账
                if (needToPayItems.length == this.carItems.length) {
                    this.buyTipPage.show(needToPay, buyItemsHandler, cancelHandler, game.Tools.strOfLocalization(4394), game.Tools.strOfLocalization(4438), game.Tools.strOfLocalization(4393), "");
                } else {
                    //有部分物品没放置到背包内
                    this.buyTipPage.show(needToPay, buyItemsHandler, cancelHandler, game.Tools.strOfLocalization(4394), game.Tools.strOfLocalization(4438));
                }


            }


        }

        /**
         * 获取空的格子，如果值是-1，说明现在没有格子
         */
        private getEmptyGrid() {
            if (this.carItems.length == this.carMaxCount) {
                return -1;
            }
            for (let index = 0; index < this.shopCarGrids.length; index++) {
                let grid = this.shopCarGrids[index];
                if (grid.itemId == -1) {
                    return index;
                }

            }
            return -1;
        }






        private onMouseDown() {
            this.isMouseDown = true;
            this.clickStartPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.isDrag = false;
            Laya.timer.once(1, this, this.checkDrag);
        }



        /**
         * 如果当前没在操作任何物体，则关闭操作菜单,如果在操作则执行对应的操作
         */
        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            //拖拽的结束
            if (this.isDrag) {
                this.onDragEnd();
                this.isDrag = false;
            }
            //点击的结束
            else {

                //点击了某个格子
                if (this.clickShopGridIndex != -1) {

                    // this.onClickShopCarGrid();
                }
                //点击了某个道具
                else if (this.dragItem != null) {
                    // this.onClickItem();
                }

            }

            //如果当前没有在操作任何物体，则关闭操作菜单
            if (!this.isOperate) {
                this.operateMenu.visible = false;
                //Todo 检测放置状态是否正确，如果不正确，则返回操作前的状态
                // this.operateItem = null;
                this.onOperateFinish();
            }
            this.clickStartPos = new Laya.Vector2(0, 0);
            Laya.timer.clear(this, this.checkDrag);
            Laya.timer.clear(this, this.onDragMove);
            this.dragItem = null;
            this.clickShopGridIndex = -1;
            this.isOperate = false;

        }




        private checkDrag() {
            if (!this.isDrag) {
                if (this.clickStartPos.x != Laya.stage.mouseX || this.clickStartPos.y != Laya.stage.mouseY) {
                    this.isDrag = true;
                    this.onDragStart();
                    Laya.timer.frameLoop(1, this, this.onDragMove);
                    return;
                }
            }

            Laya.timer.once(1, this, this.checkDrag);
        }

        private onDragStart() {
            // console.log("拖拽开始");
            let mousePosX = Laya.stage.mouseX;
            let mousePosY = Laya.stage.mouseY;
            if (this.clickShopGridIndex != -1) {

                let grid = this.shopCarGrids[this.clickShopGridIndex];
                //拖拽购物车内的物体
                if (grid.itemId != -1) {

                    grid.carItem.isShow = false;
                    this.freshShopCar();
                    //在鼠标处生成一个新的物体
                    let itemUI = this.createItemUI(grid.carItem.itemData, false);
                    itemUI.isCreateByShop = true;
                    this.dragItem = itemUI;
                    this.onClickItem();
                    this.dragItem.setPosByCenterPos(new Laya.Vector2(mousePosX, mousePosY));
                    this.dragOffset = new Laya.Vector2(this.dragItem.me.x - mousePosX, this.dragItem.me.y - mousePosY);
                }

            }
            else if (this.dragItem != null) {
                //在拖拽背包内的道具
                this.removeItemInBag(this.dragItem)
                this.itemDragStartPos = new Laya.Vector2(this.dragItem.me.x, this.dragItem.me.y);
                this.itemDragStartRotate = this.dragItem.itemData.rotate;
                this.dragOffset = new Laya.Vector2(this.dragItem.me.x - mousePosX, this.dragItem.me.y - mousePosY);

            }
            if (this.dragItem != null) {
                this.dragItem.me.x = mousePosX + this.dragOffset.x;
                this.dragItem.me.y = mousePosY + this.dragOffset.y;
                this.dragItem.redGridsVisible(false);
                this.operateMenu.visible = false;
            }


        }

        private onDragMove() {
            // console.log("拖拽中");
            if (this.dragItem != null) {
                //物品跟随鼠标
                let mousePosX = Laya.stage.mouseX;
                let mousePosY = Laya.stage.mouseY;
                //加入边界检测，拖拽的时候，商品不可以超出屏幕
                //物品的左上角，物品的左上角坐标 y需要大于等于0小于等于1080-高 x>=0 x<=1920-宽
                //新的原点位置
                let newOriginPos = new Laya.Vector2(mousePosX + this.dragOffset.x, mousePosY + this.dragOffset.y);
                let newLeftUpPos = this.dragItem.originToLeftUp(newOriginPos);
                if (newLeftUpPos.x >= 0 && newLeftUpPos.x <= 1920 - this.dragItem.trueWidth) {
                    this.dragItem.me.x = mousePosX + this.dragOffset.x;
                }
                if (newLeftUpPos.y >= 0 && newLeftUpPos.y <= 1080 - this.dragItem.trueHeight) {
                    this.dragItem.me.y = mousePosY + this.dragOffset.y;
                }

                // this.menuFollowItem(this.dragItem);
                //检测物品的格子数据
                let item = this.dragItem;
                let bagUI = this.bagsContainer.getBagUI();
                //计算该道具目前影响的所有格子
                let effectBagGrids = this.getItemEffectGrid(item);
                bagUI.freshGridsState(effectBagGrids);
            }
        }

        private onDragEnd() {
            // console.log("拖拽结束");
            if (this.dragItem != null) {

                this.menuFollowItem(this.dragItem);
                view.AudioMgr.PlayAudio(10136);
                let item: UI_Activity_Haidao_Item = this.dragItem;
                //拖拽结束，判断鼠标是否在购物车内，如果在购物车内，则移除该物体，并且将购物车内隐藏的物体显示出来，否则将物体放置到空白层级
                let isOnShopCar = this.shopCarSprite.hitTestPoint(this.dragItem.itemCenterPos.x, this.dragItem.itemCenterPos.y);

                //放在了购物车内
                if (isOnShopCar) {
                    //商品未付款
                    if (item.serverId == -1) {
                        //拖拽起点是购物车，重新加入购物车
                        if (this.clickShopGridIndex != -1) {
                            let grid = this.shopCarGrids[this.clickShopGridIndex];
                            grid.carItem.isShow = true;
                            this.freshShopCar();

                        }
                        else {
                            let items = this.findItemInCar(item.itemData);
                            for (let index = 0; index < items.length; index++) {
                                const item = items[index];
                                item.isShow = true;
                            }
                            this.freshShopCar();
                        }
                        this.operateMenu.visible = false;
                        this.disposeItemUI(item);
                        this.operateItem = null;
                        this.dragItem = null;
                    }
                    //商品已付款,返回拖拽起点
                    else {
                        item.me.x = this.itemDragStartPos.x;
                        item.me.y = this.itemDragStartPos.y;
                        let bagUI = this.bagsContainer.getBagUI();
                        bagUI.freshGridsState(new Array());
                        this.menuFollowItem(item);
                    }

                }
                //未放到购物车内
                else {


                    let bagUI = this.bagsContainer.getBagUI();
                    let effectBagGrids = this.getItemEffectGrid(item);
                    let isOnEmpty = effectBagGrids.length == 0
                    if (isOnEmpty) {
                        item.bagPosX = -1;
                        item.bagPosY = -1;
                        //从购物车放置到空白处                        
                        if (this.clickShopGridIndex != -1) {
                            let grid = this.shopCarGrids[this.clickShopGridIndex];
                            grid.carItem.isShow = false;
                            this.freshShopCar();

                        }
                        bagUI.freshGridsState(new Array());
                        item.redGridsVisible(true);
                    }
                    else {
                        //从购物车里拖出的需要隐藏购物车的物品
                        if (this.clickShopGridIndex != -1) {
                            let grid = this.shopCarGrids[this.clickShopGridIndex];
                            grid.carItem.isShow = false;
                            this.freshShopCar();
                        }

                        //商品完全放置了则吸附
                        if (effectBagGrids.length == item.itemFillGrids) {

                            let isGridsAllEmpty = bagUI.isGridsEmpty(effectBagGrids);
                            if (isGridsAllEmpty) {
                                let itemLeftUpIndex = bagUI.getNearBy(this.operateItem.getGridGlobalPos(0, 0));
                                // this.setItemToBagPos(item, bagUI, itemLeftUpIndex.x, itemLeftUpIndex.y);
                                this.addItemInBag(item, bagUI, itemLeftUpIndex.x, itemLeftUpIndex.y)
                            }
                        }
                        item.redGridsVisible(false);
                    }

                }
            }

            this.itemDragStartPos = new Laya.Vector2(0, 0);
            this.itemDragStartRotate = 0;
            if (this.dragItem != null) {
                this.operateMenu.visible = true;
                this.menuFollowItem(this.dragItem);
                this.freshBuyButton();
            }
            this.dragItem = null;


        }


        /**
         * 获取商品的影响格子
         * @param itemUI 
         * @returns 
         */
        private getItemEffectGrid(itemUI: UI_Activity_Haidao_Item): Laya.Vector2[] {
            let gridPoses = itemUI.getGridsGlobalPos();
            let item = itemUI;
            let itemGridsData = item.itemData;
            let bagUI = this.bagsContainer.getBagUI();
            //计算该道具目前影响的所有格子
            let effectBagGrids: Laya.Vector2[] = new Array();
            for (let col = 0; col < itemGridsData.itemCol; col++) {
                for (let row = 0; row < itemGridsData.itemRow; row++) {
                    //这个格子的中心点的全局坐标
                    let gridPos: Laya.Vector2 = gridPoses[col][row];
                    //这个格子占位
                    if (itemGridsData.matrix[col][row] == 1) {
                        let bagGridIndex: Laya.Vector2 = bagUI.getNearBy(gridPos);
                        //没有最近的格子
                        if (bagGridIndex.x == -1 && bagGridIndex.y == -1) {
                            continue;
                        }
                        if (bagUI.getGrid(bagGridIndex.x, bagGridIndex.y).visible == false) {
                            continue;
                        }
                        effectBagGrids.push(bagGridIndex);
                    }
                }
            }
            return effectBagGrids;
        }

        private onOperateStart(itemUI: UI_Activity_Haidao_Item) {
            // console.log("操作开始");
            //如果在背包内，将物品从背包内移除
            itemUI.saveData();
            this.removeItemInBag(itemUI);
            //记录操作前的状态
            this.operateItem = itemUI;
            this.operateLayer.addChild(itemUI.me);
        }

        /**
         * 当点击了其它物体或者是空白区域是被调用
         */
        private onOperateFinish() {
            // console.log("操作结束");
            if (this.operateItem != null) {
                if (this.operateItem.bagId == -1) {
                    //如果可以放到背包内，就放到背包内
                    let putSuccess = this.addItemToCurrentBag(this.operateItem);
                    let effectGrids = this.getItemEffectGrid(this.operateItem);
                    //操作之前在购物车内
                    if (this.operateItem.isCreateByShop) {

                        if (putSuccess || effectGrids.length == 0) {
                            this.operateItem.isCreateByShop = false;
                            this.operateItem.redGridsVisible(effectGrids.length == 0);
                        }
                        else {
                            //从购物车拖出来没有成功放置，返回购物车
                            let items = this.findItemInCar(this.operateItem.itemData);

                            for (let index = 0; index < items.length; index++) {
                                const item = items[index];
                                item.isShow = true;
                            }
                            this.freshShopCar();
                            this.disposeItemUI(this.operateItem);
                            this.operateItem = null;
                            this.bagsContainer.getBagUI().freshGridsState(new Array());
                            this.freshBuyButton();
                            return;
                        }

                    }
                    //操作之前在空白或者背包
                    else {
                        if (!putSuccess) {
                            if (effectGrids.length != 0) {
                                //之前在空白位置返回原位置
                                if (this.operateItem.oldData.oldBagId == -1) {
                                    this.operateItem.me.x = this.operateItem.oldData.oldPos.x;
                                    this.operateItem.me.y = this.operateItem.oldData.oldPos.y;
                                    this.operateItem.setRotate(this.operateItem.oldData.oldRotate);
                                    this.operateItem.redGridsVisible(true);
                                }
                                //之前在背包中
                                else {
                                    this.operateItem.setRotate(this.operateItem.oldData.oldRotate);
                                    this.addItemInBag(this.operateItem, this.bagsContainer.getBagUI(), this.operateItem.oldData.oldBagPos.x, this.operateItem.oldData.oldBagPos.y);
                                    this.operateItem.redGridsVisible(false);
                                }
                            }
                            // else {
                            //     this.operateItem.bagId = -1;
                            // }
                        }

                    }
                    this.emptyLayer.addChild(this.operateItem.me);
                }

                this.operateItem.clearSaveData();
                this.operateItem = null;
            }

            this.bagsContainer.getBagUI().freshGridsState(new Array());
            this.freshBuyButton();


        }

        private addItemToCurrentBag(itemUI: UI_Activity_Haidao_Item): boolean {

            let bagUI = this.bagsContainer.getBagUI();
            let effectBagGrids = this.getItemEffectGrid(this.operateItem);
            //如果商品的格子都被放置了
            let itemGridsCount = itemUI.itemFillGrids;
            if (itemGridsCount != effectBagGrids.length) {
                return false;
            }

            for (let index = 0; index < effectBagGrids.length; index++) {
                let grid = effectBagGrids[index];
                if (!bagUI.isGridEmpty(grid.x, grid.y)) {
                    return false;
                }
            }
            let bagGridIndex = bagUI.getNearBy(this.operateItem.getGridGlobalPos(0, 0));
            this.addItemInBag(this.operateItem, bagUI, bagGridIndex.x, bagGridIndex.y);
            return true;
        }


        private onClickShopCarGrid() {
            let grid = this.shopCarGrids[this.clickShopGridIndex];
            if (grid.itemId != -1) {

                //操作台的操作:让格子内的物体旋转和删除购物车内的物品
                this.operateMenu.show(1, new Laya.Handler(this, () => {
                    //删除指定物品，刷新列表
                    this.removeItemInCar(grid.carItem.itemData);
                    this.operateMenu.visible = false;
                }), new Laya.Handler(this, () => {
                    //旋转购物车内的物品
                    grid.rotate();
                    //刷新背包格子状态
                }), new Laya.Handler(this, () => {
                    this.isOperate = true;
                }));
                let gridPos = game.Tools.posLocalToGlobal(grid.me.parent as Laya.Sprite, grid.me.x, grid.me.y);
                this.operateMenu.me.x = gridPos.x;
                this.operateMenu.me.y = gridPos.y - grid.me.height / 2 - 56;
            }
            else {
                this.operateMenu.visible = false;
            }
        }

        /**
          * 获取指定道具在购物车里有几个
          * @param itemId 
          * @returns 
          */
        private getCountInCar(itemId: number) {

            let items = this.carItems.filter((v) => {

                if (v.itemData.id == itemId) {
                    return v;
                }
            })
            return items.length;
        }

        private findItemInCar(gridItem: GridItem): CarItem[] {
            let items = this.carItems.filter((v, i) => {
                if (v.itemData == gridItem) {
                    return v;
                }
            });
            return items;
        }

        /**
         * 往购物车里添加道具
         * @param gridItem 
         * @param isShow 
         */
        private addItemInCar(gridItem: GridItem, isShow: boolean = true) {
            this.carItems.push({ itemData: gridItem, isShow: isShow });
            this.freshList();
            this.freshShopCar();
        }



        /**
         * 从购物车里移除道具
         * @param gridItem 
         */
        private removeItemInCar(gridItem: GridItem) {
            let items = this.findItemInCar(gridItem);
            for (let index = 0; index < items.length; index++) {
                const item = items[index];
                let indexInCar = this.carItems.indexOf(item);
                this.carItems.splice(indexInCar, 1);
            }
            this.freshList();
            this.freshShopCar();
        }

        /**
         * 清理购物车
         */
        private clearShopCar() {
            this.carItems = new Array();
            this.freshShopCar();
            this.freshList();
        }


        private freshBuyButton() {

            //需要支付的价格等同于所有放置在背包内的未支付
            let needToPayItem = this.getNeedToPay();
            let needToPay = 0;
            this.showItems.forEach((v) => {
                if (v.serverId == -1) {
                    if (v.bagId != -1) {
                        let itemId = v.itemData.id;
                        let itemData = this.currentStageData.todayShopItems.get(itemId);
                        needToPay += Math.floor(itemData.price * UI_Activity_Haidao.sellDiscount / 100);
                    }
                }
            });
            this.buyBtn.title = needToPay.toString();
            let currentHave = UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId);
            this.buyBtn.grayed = currentHave < needToPay || needToPayItem.length == 0;
            if (currentHave < needToPay) {
                this.buyBtn.titleColor = UI_Activity_Haidao.colorRed;
            }
            else if (needToPayItem.length == 0) {
                this.buyBtn.titleColor = UI_Activity_Haidao.colorGray;
            }
            else {
                this.buyBtn.titleColor = "#A9482B";
            }
            // this.buyBtn.titleColor = currentHave < needToPay || needToPayItem.length == 0 ? "#9C8781" : "#A9482B";
            let tipText = this.buyBtn.me.getChildByName("tip") as Laya.Label;
            tipText.color = currentHave < needToPay || needToPayItem.length == 0 ? "#9C8781" : "#A9482B";
        }


        /**
         * 将商品左上角放置在指定背包的指定格子处
         * @param itemUI 商品
         * @param bagUI 背包
         * @param posX 背包的指定格子
         * @param posY 背包的指定格子
         */
        private addItemInBag(itemUI: UI_Activity_Haidao_Item, bagUI: UI_Activity_Haidao_Bag, posX: number, posY: number) {

            //获取这个格子左上角的全局坐标
            let gridLeftPos = bagUI.getGrid(posX, posY).globalPos;
            itemUI.setPosByLeftUpPos(gridLeftPos);

            //将商品的0,0中心点放到对应的格子中心点
            // itemUI.me.x = gridPos.x + itemUI.trueWidth / 2;
            // itemUI.me.y = gridPos.y + itemUI.trueHeight / 2;
            this.menuFollowItem(itemUI);

            bagUI.addItemUI(itemUI, posX, posY);

            // this.freshBuyButton()
        }

        private setItemToBagPos(itemUI: UI_Activity_Haidao_Item, bagUI: UI_Activity_Haidao_Bag, posX: number, posY: number) {
            //获取这个格子左上角的全局坐标
            let gridLeftPos = bagUI.getGrid(posX, posY).globalPos;
            itemUI.setPosByLeftUpPos(gridLeftPos);
            this.menuFollowItem(itemUI);
        }



        /**
         * 从背包里移除指定的道具
         * @param itemUI 
         */
        private removeItemInBag(itemUI: UI_Activity_Haidao_Item) {

            if (itemUI.bagId != -1) {
                this.bagsContainer.getBagUIById(itemUI.bagId).removeItem(itemUI);
            }
            // this.freshBuyButton()
        }

        private onClickItem() {
            if (this.isLock) {
                return;
            }
            //先结算上一个的操作
            if (this.operateItem != null && this.operateItem != this.dragItem) {
                this.onOperateFinish();
            }
            if (this.operateItem == null) {
                this.onOperateStart(this.dragItem);
            }
            let item = this.dragItem;
            let handler1: Laya.Handler;
            let handler2: Laya.Handler;
            let state: number = 0;
            let onMouseDown: Laya.Handler = new Laya.Handler(this, () => {
                this.isOperate = true;
            });
            let sellPrice = 0;
            //如果是购物车内的物品
            if (!item.isPay) {
                state = 1;

                //删除
                handler1 = new Laya.Handler(this, () => {
                    if (this.isLock) {
                        return;
                    }
                    this.removeItemInCar(item.itemData);
                    this.removeItemInBag(item);
                    this.disposeItemUI(item);
                    this.bagsContainer.getBagUI().freshGridsState(new Array());
                    this.operateItem = null;
                    this.operateMenu.visible = false;
                    this.freshBuyButton();

                });
                //旋转
                handler2 = new Laya.Handler(this, () => {
                    if (this.isLock) {
                        return;
                    }
                    this.rotateCurrentOperate();
                });
            }
            else {
                //如果在商店收购则显示出售和旋转
                let todayShopItems = this.currentStageData.todayShopItems;
                if (todayShopItems.has(item.itemData.id)) {
                    state = 0;
                    let itemPrice = this.currentStageData.todayShopItems.get(item.itemData.id).price;
                    sellPrice = Math.floor(itemPrice * UI_Activity_Haidao.sellDiscount / 100);
                    //出售
                    handler1 = new Laya.Handler(this, () => {
                        if (this.isLock) {
                            return;
                        }
                        let startPos = item.itemCenterPos;
                        let sellHandler = new Laya.Handler(this, () => {
                            //直接发送出售消息
                            this.sellItem([UI_Activity_Haidao.Inst.getItemByServerId(item.serverId)], new Laya.Handler(this, (res) => {
                                //todo 显示出售成功特效

                                this.operateMenu.visible = false;
                                this.createSellEffect(startPos, sellPrice);
                            }));
                        });
                        //购入的价格大于出售的价格，弹出二次确认窗口
                        if (sellPrice < UI_Activity_Haidao.Inst.getItemCostInBag(item.itemData.id)) {
                            UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4387), sellHandler);
                            UI_SecondConfirm.Inst.setBtnState(true, true)
                        }
                        else {
                            sellHandler.run();
                        }



                    });
                    //旋转
                    handler2 = new Laya.Handler(this, () => {
                        if (this.isLock) {
                            return;
                        }
                        this.rotateCurrentOperate();
                    });
                }
                //商店里不收购则是删除和旋转
                else {
                    state = 1;
                    //删除
                    handler1 = new Laya.Handler(this, () => {
                        if (this.isLock) {
                            return;
                        }
                        UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4397), new Laya.Handler(this, () => {
                            this.dropItem(item.serverId, new Laya.Handler(this, () => {
                                this.operateMenu.visible = false;
                            }))
                        }), null, 960, 530, 4398);
                        UI_SecondConfirm.Inst.setBtnState(true, true);
                    });
                    //旋转
                    handler2 = new Laya.Handler(this, () => {
                        if (this.isLock) {
                            return;
                        }
                        this.rotateCurrentOperate();
                    });
                }

            }
            //显示影响的格子
            let effect = this.getItemEffectGrid(item);
            this.removeItemInBag(item);
            this.bagsContainer.getBagUI().freshGridsState(effect)
            this.operateMenu.show(state, handler1, handler2, onMouseDown, sellPrice);
            this.menuFollowItem(item);


        }

        /**
         * 旋转当前的操作物体
         */
        private rotateCurrentOperate() {

            if (this.operateItem != null) {
                this.removeItemInBag(this.operateItem);
                //刷新格子的显示
                let bagUI = this.bagsContainer.getBagUI();
                //固定左上角的位置
                let oldLeftUp = this.operateItem.leftUpPos;
                this.operateItem.rotateItem();
                this.operateItem.setPosByLeftUpPos(oldLeftUp);

                let effectBagGrids = this.getItemEffectGrid(this.operateItem);
                bagUI.freshGridsState(effectBagGrids);

                this.menuFollowItem(this.operateItem);
                if (this.operateItem.serverId == -1) {
                    this.freshShopCar();
                }
            }
        }

        private menuFollowItem(itemUI: UI_Activity_Haidao_Item) {
            // let itemPos = game.Tools.posLocalToGlobal(itemUI.me.parent as Laya.Sprite, itemUI.me.x, itemUI.me.y);
            this.operateMenu.me.x = itemUI.itemCenterPos.x;
            this.operateMenu.me.y = itemUI.leftUpPos.y - 56;
        }



        private createItemUI(gridItem: GridItem, isPay: boolean,): UI_Activity_Haidao_Item {
            let itemUI = this.itemTemplate.getNodeClone();
            itemUI.visible = true;
            let item = new UI_Activity_Haidao_Item(itemUI);
            item.show(gridItem, isPay);
            item.onItemClick = new Laya.Handler(this, () => {
                this.isOperate = true;
                this.dragItem = item;
                this.onClickItem();
            });
            this.showItems.push(item);
            return item;
        }

        private disposeItemUI(item: UI_Activity_Haidao_Item) {
            item.dispose();
            game.Tools.removeFromArray(this.showItems, item)

        }

        private disposeAllItem() {
            this.showItems.forEach((v, i) => {
                v.dispose();
            })
            this.showItems = new Array();
        }


        /**
         * 获取当前需要购买的所有Item
         */
        private getNeedToPay(): Array<UI_Activity_Haidao_Item> {
            //计算需要支付的金额
            let needToPayItems: Array<UI_Activity_Haidao_Item> = new Array();
            this.showItems.forEach((v) => {
                if (v.serverId == -1) {
                    if (v.bagId != -1) {
                        needToPayItems.push(v);
                    }
                }
            });

            return needToPayItems;
        }


        /**
         * 获取所有需要整理的Item
         * @returns 
         */
        private getNeedToTidy(): Array<UI_Activity_Haidao_Item> {
            //计算需要支付的金额
            let needToTidyItems: Array<UI_Activity_Haidao_Item> = new Array();
            this.showItems.forEach((v) => {
                if (v.serverId != -1) {
                    needToTidyItems.push(v);
                }
            });
            return needToTidyItems;
        }




        /**
         * 购买商品，需要所有已支付的物品都在格子内，未支付的物品，只购买在背包内的物品
         * @returns 
         */
        public onClickBuy() {
            if (this.isLock) {
                return;
            }
            //计算需要支付的金额
            let needToPay = 0;
            let needToPayItems = this.getNeedToPay();
            needToPayItems.forEach((v) => {
                let itemId = v.itemData.id;
                let itemData = this.currentStageData.todayShopItems.get(itemId);
                needToPay += itemData.price;
            });

            if (needToPay == 0 && needToPayItems.length == 0) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4427));
                return;
            }

            let currentHave = UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId);
            if (currentHave < needToPay) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4388));
                return;
            }

            //检测已经购买过的物品是否已经放入背包
            let isAllInBag = true;

            for (let index = 0; index < this.showItems.length; index++) {
                let itemUI = this.showItems[index];
                if (itemUI.serverId != -1 && itemUI.bagId == -1) {
                    isAllInBag = false;
                    break;
                }
            }

            if (!isAllInBag) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4389));
                return;
            }



            let tidyItems: basic.Dictionary<number, UI_Activity_Haidao_Item[]> = new basic.Dictionary();
            let buyItems: Array<Haidao_BuyData> = new Array();

            this.showItems.forEach((item) => {
                if (item.isPay) {

                    if (!tidyItems.get(item.bagId)) {
                        tidyItems.set(item.bagId, new Array());
                    }
                    tidyItems.get(item.bagId).push(item);
                }
                else {
                    if (item.bagId != -1) {
                        buyItems.push(this.convertItemUIToBuyData(item));
                    }
                }
            })



            let onSendTidyFinish = () => {
                if (buyItems.length == 0) {
                    return;
                }
                this.buyItemsByData(buyItems, new Laya.Handler(this, () => {
                    //todo 显示购买成功

                }))
            }
            //发送消息之前，保存购物车数据和物品数据两份，因为需要发送两次消息，在此保存数据的原因是防止数据后期被更改


            let newCarItem: CarItem[] = new Array();
            for (let index = 0; index < this.carItems.length; index++) {
                const element = this.carItems[index];
                let payItem = needToPayItems.filter((v) => {
                    return v.itemData.entityId == element.itemData.entityId;
                })
                if (payItem.length == 0) {
                    newCarItem.push(element);
                }
            }
            this.saveCurrentItemData();
            this.saveShopCarItemData(newCarItem);


            if (tidyItems.getCount() == 0) {
                onSendTidyFinish();
            }
            else {
                this.isClickBuy = true;
                this.tidyBag(tidyItems, new Laya.Handler(this, (res) => {
                    onSendTidyFinish();
                }))

            }


        }


        /**
         * 出售道具
         * @param itemsUI 
         * @param onComplete 
         */
        public sellItem(items: ItemDataInBag[], onComplete: Laya.Handler) {

            let reqIslandActivitySell = {
                activity_id: UI_Activity_Haidao.activityId,
                items: new Array()
            }
            let sellCanGet = 0;
            items.forEach((item) => {
                let itemPrice = this.currentStageData.todayShopItems.get(item.id).price;
                let sellPrice = Math.floor(itemPrice * UI_Activity_Haidao.sellDiscount / 100);
                reqIslandActivitySell.items.push({
                    bag_id: item.bagId,
                    id: item.serverId,
                    price: sellPrice
                })
                sellCanGet += sellPrice;
            })
            //出售之前检测商店金钱是否足够
            if (sellCanGet > this.currentStageData.shopMoney) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4383));
                return;
            }
            this.isLock = true;
            this.saveCurrentItemData();
            this.saveShopCarItemData(this.carItems);
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_SELL, reqIslandActivitySell, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_SELL, err, res);
                }
                else {
                    // UI_Activity_Haidao_Congrate.Inst.show(ECongrateType.soldout);
                    onComplete?.runWith(res);
                }
            });
        }

        /**
         * 整理背包
         * @param tidyItems 
         * @param onComplete 
         */
        private tidyBag(tidyItems: basic.Dictionary<number, UI_Activity_Haidao_Item[]>, onComplete: Laya.Handler) {
            let bagsData = new Array();
            //先发送整理数据然后发送购买数据
            for (let index = 0; index < tidyItems.keys().length; index++) {
                let bagId = tidyItems.keys()[index];
                let items = tidyItems.get(bagId);
                let bagData = {
                    bag_id: bagId,
                    items: new Array(),
                    drops: new Array()
                };
                items.forEach((v) => {
                    bagData.items.push({
                        id: v.serverId,
                        pos: [v.bagPosY, v.bagPosX],
                        rotate: v.itemData.rotate * 90
                    });
                })
                bagsData.push(bagData);

            }

            let reqIslandActivityTidyBag = {
                activity_id: UI_Activity_Haidao.activityId,
                bag_data: bagsData,
            };

            // console.log("发送整理请求", JSON.stringify(reqIslandActivityTidyBag));
            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, reqIslandActivityTidyBag, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    this.clearSaveData();
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, err, res);
                }
                else {
                    // console.log("整理成功");
                    onComplete?.runWith(res);

                }
            })
        }

        /**
         * 丢弃道具
         * @param itemUI 
         * @param onComplete 
         */
        private dropItem(itemServerId: number, onComplete: Laya.Handler) {
            this.isLock = true;
            this.saveCurrentItemData();
            this.saveShopCarItemData(this.carItems);
            let bagsData = new Array();

            // let dropItem = UI_Activity_Haidao.Inst.getItemByServerId(itemUI.serverId);
            //遍历每个背包
            for (let index = 0; index < UI_Activity_Haidao.bagIdArray.length; index++) {
                let bagId = UI_Activity_Haidao.bagIdArray[index];
                let bag = UI_Activity_Haidao.bagDataDic.get(bagId);
                if (!bag.isUnlock) {
                    continue;
                }
                let bagItems = bag.items;
                let bagData = {
                    bag_id: bagId,
                    items: new Array(),
                    drops: new Array()
                };

                bagItems.forEach((item) => {
                    if (item.serverId == itemServerId) {
                        //是需要丢弃的物品
                        bagData.drops.push(item.serverId);
                    }
                    else {
                        bagData.items.push({
                            id: item.serverId,
                            pos: [item.startPosY, item.startPosX],
                            rotate: item.itemLocalData.rotate * 90
                        });
                    }
                })
                bagsData.push(bagData);
            }

            let reqIslandActivityTidyBag = {
                activity_id: UI_Activity_Haidao.activityId,
                bag_data: bagsData,
            };
            // console.log("发送丢弃请求", JSON.stringify(reqIslandActivityTidyBag));
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, reqIslandActivityTidyBag, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    this.clearSaveData();
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_TIDY_BAG, err, res);
                }
                else {
                    // console.log("丢弃成功");
                    onComplete?.runWith(res);
                }
            })
        }



        private convertItemUIToBuyData(itemUI: UI_Activity_Haidao_Item) {
            let buyData: Haidao_BuyData = {
                goods_id: itemUI.itemData.id,
                pos: [itemUI.bagPosY, itemUI.bagPosX],
                rotate: itemUI.itemData.rotate * 90,
                bag_id: itemUI.bagId,
                price: this.currentStageData.todayShopItems.get(itemUI.itemData.id).price
            }
            return buyData;
        }

        /**
        * 购买道具
        * @param buyItems 
        * @param onComplete 
        */
        private buyItemsByData(buyItems: Array<Haidao_BuyData>, onComplete: Laya.Handler) {
            let buyItemsMsg = new Array();
            for (let index = 0; index < buyItems.length; index++) {
                let item = buyItems[index];
                buyItemsMsg.push(item);
            }
            let reqIslandActivityBuy = {
                activity_id: UI_Activity_Haidao.activityId,
                items: buyItemsMsg
            }
            // console.log("发送购买请求", UI_Activity.getActivityDeltaDay(UI_Activity_Haidao.activityId), JSON.stringify(reqIslandActivityBuy));
            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_BUY, reqIslandActivityBuy, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    this.clearSaveData();
                    UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_BUY, err, res);
                }
                else {
                    // console.log("购买成功");
                    onComplete?.runWith(res);
                    UI_Activity_Haidao_Congrate.Inst.show(ECongrateType.soldout);

                }
            })
        }

        private onClickReset() {
            if (this.isLock) {
                return;
            }
            let carData = this.carItems;
            this.onFreshData();
            this.carItems = carData;
            for (let index = 0; index < this.carItems.length; index++) {
                const item = this.carItems[index];
                item.itemData.rotate = 0;
                item.isShow = true;
            }
            this.freshShopCar();
            this.freshBuyButton();
        }



        /**
         * 重置购物车，清空购物车的所有数据
         * @returns 
         */
        private onClickResetCar() {
            if (this.isLock) {
                return;
            }
            this.carItems.forEach((item) => {
                let entity: UI_Activity_Haidao_Item = this.findItemByEntityId(item.itemData.entityId);
                if (entity != null) {
                    this.removeItemInBag(entity);
                    this.disposeItemUI(entity);
                }
            });

            this.carItems = new Array();
            this.freshShopCar();
            this.freshList();

        }

        /**
         * 将已经生成的未付款商品返回购物车
         * @param id 
         */
        private returnItemToCar(id: number) {
            let entity: UI_Activity_Haidao_Item = this.findItemByEntityId(id);
            if (entity != null) {
                this.removeItemInBag(entity);
                this.disposeItemUI(entity);
                this.freshShopCar();
            }

        }

        /**
         * 通过实体id找到对应的物体
         * @param entityId 
         * @returns 
         */
        private findItemByEntityId(entityId: number): UI_Activity_Haidao_Item {
            let items = this.showItems.filter((v) => {
                if (v.itemData.entityId == entityId) {
                    return v;
                }
            })

            return items.length == 0 ? null : items[0];
        }


        /**
         * 保存道具数据
         */
        public saveCurrentItemData() {
            let saveData: basic.Dictionary<number, Haidao_ItemUIData> = new basic.Dictionary();
            let oldData = this.showItems;
            oldData.forEach((itemUI, index) => {
                //如果已经创建了实体要保存实体数据
                if (itemUI.serverId != -1) {

                    let uiData: Haidao_ItemUIData = {
                        itemId: itemUI.itemData.id,
                        rotate: itemUI.itemData.rotate,
                        bagId: itemUI.bagId,
                        bagPosX: itemUI.bagPosX,
                        bagPosY: itemUI.bagPosY,
                        posX: itemUI.me.x,
                        posY: itemUI.me.y,
                        isShow: false
                    };
                    saveData.set(itemUI.serverId, uiData)
                }
            });
            this.oldItemData.push(saveData);

        }
        /**
                * 保存当前购物车的数据
                */
        private saveCurrentShopCarItemData() {
            this.saveShopCarItemData(this.carItems);
        }


        /**
         * 保存当前购物车的数据
         */
        private saveShopCarItemData(shopData: CarItem[]) {
            let saveData: basic.Dictionary<number, Haidao_ItemUIData> = new basic.Dictionary();
            shopData.forEach((data, index) => {
                //如果已经创建了实体要保存实体数据
                if (data.isShow == false) {
                    let itemUI = this.findItemByEntityId(data.itemData.entityId);
                    let uiData: Haidao_ItemUIData = {
                        itemId: itemUI.itemData.id,
                        rotate: itemUI.itemData.rotate,
                        bagId: itemUI.bagId,
                        bagPosX: itemUI.bagPosX,
                        bagPosY: itemUI.bagPosY,
                        posX: itemUI.me.x,
                        posY: itemUI.me.y,
                        isShow: false
                    };
                    saveData.set(index, uiData)
                }
                else {
                    let uiData: Haidao_ItemUIData = {
                        itemId: data.itemData.id,
                        rotate: data.itemData.rotate,
                        bagId: -1,
                        bagPosX: 0,
                        bagPosY: 0,
                        posX: 0,
                        posY: 0,
                        isShow: true
                    };
                    saveData.set(index, uiData)
                }
            })
            this.oldShopData.push(saveData);
            // console.log("保存商店数据",this.oldShopData);



        }

        private loadItemData() {
            if (this.oldItemData.length != 0) {
                let loadData = this.oldItemData[0];
                this.oldItemData.splice(0, 1);
                for (let index = 0; index < this.showItems.length; index++) {
                    let itemUI = this.showItems[index];
                    if (itemUI.serverId != -1) {
                        if (loadData.has(itemUI.serverId)) {
                            let uiData = loadData.get(itemUI.serverId);
                            this.removeItemInBag(itemUI);
                            itemUI.setRotate(uiData.rotate);
                            //在背包中
                            if (uiData.bagId != -1) {
                                this.addItemInBag(itemUI, this.bagsContainer.getBagUIById(uiData.bagId), uiData.bagPosX, uiData.bagPosY);
                                itemUI.redGridsVisible(false);
                            }
                            //在空白处
                            else {
                                itemUI.me.x = uiData.posX;
                                itemUI.me.y = uiData.posY;
                                itemUI.redGridsVisible(true);
                                itemUI.bagId = uiData.bagId;
                                itemUI.bagPosX = uiData.bagPosX;
                                itemUI.bagPosY = uiData.bagPosY;
                            }

                        }
                    }
                };
            }
        }


        /**
         * 读取之前的购物车数据
         */
        private loadShopData() {


            if (this.oldShopData.length != 0) {
                let loadData = this.oldShopData[0];
                // console.log("加载商店数据", loadData);
                this.oldShopData.splice(0, 1);
                for (let index = 0; index < loadData.keys().length; index++) {
                    let oldData = loadData.get(index);
                    let itemConfig = UI_Activity_Haidao.itemConfigDic.get(oldData.itemId);
                    let newGridItem = GridBagUtils.Inst.getItem(oldData.itemId, GridBagUtils.Inst.convertStringToMatrix(itemConfig.matrix));
                    newGridItem.rotate = oldData.rotate;
                    // this.carItems.push({ itemData: newGridItem, isShow: oldData.isShow });
                    this.addItemInCar(newGridItem, oldData.isShow);
                    //如果已经创建过ui,按照之前的数据，创建购物车
                    if (!oldData.isShow) {
                        let itemUI = this.createItemUI(newGridItem, false);

                        //在背包中
                        if (oldData.bagId != -1) {
                            // this.removeItemInBag(itemUI);
                            this.addItemInBag(itemUI, this.bagsContainer.getBagUIById(oldData.bagId), oldData.bagPosX, oldData.bagPosY);
                            itemUI.redGridsVisible(false);
                        }
                        //在空白处
                        else {
                            itemUI.me.x = oldData.posX;
                            itemUI.me.y = oldData.posY;
                            itemUI.redGridsVisible(true);
                        }

                    }
                }
                this.freshShopCar();
                this.freshList();
            }
        }


        private clearSaveData() {
            this.oldItemData = new Array();
            this.oldShopData = new Array();
        }

        private onClickUpgrade() {
            if (this.isLock) {
                return;
            }
            if (this.isAllBagFull()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4428));
                return;
            }
            this.upgradeBagPage.show();
        }

        private freshUpdateBagBtn() {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let isFull = true;
            let canUnlock = false;
            keys.forEach((key) => {
                let bagData = UI_Activity_Haidao.bagDataDic.get(key);
                let allBag = JSON.stringify(bagData.currentMatrix);
                let currentBag = JSON.stringify(bagData.allMatrix);
                if (allBag != currentBag) {
                    let unLockConfig = bagData.bagConfig.unlock_consume.split('-');
                    //已经解锁的背包有可升级的格子
                    if (bagData.isUnlock && UI_Bag.get_item_count(Number(unLockConfig[0])) >= Number(unLockConfig[1])) {
                        canUnlock = true;
                    }
                    isFull = false;
                }
            });

            (this.upgradeBtn.getChildByName('red_point') as Laya.Image).visible = canUnlock;
            //当背包升级满后，按钮置灰
            game.Tools.setGray(this.upgradeBtn, isFull);
        }

        /**
         * 是否所有的背包已经升级满了
         */
        private isAllBagFull(): boolean {
            let keys = UI_Activity_Haidao.bagDataDic.keys();
            let isFull = true;
            keys.forEach((key) => {
                let bagData = UI_Activity_Haidao.bagDataDic.get(key);
                if (!common.MatrixUtils.isMatrixEqual(bagData.currentMatrix, bagData.allMatrix)) {
                    isFull = false;
                }
            });
            return isFull;
        }

        public showOperateMenu(state, pos: Laya.Vector2, handler1: Laya.Handler, handler2: Laya.Handler, onMouseDown: Laya.Handler) {
            this.operateMenu.show(state, handler1, handler2, onMouseDown)
            this.operateMenu.me.x = pos.x;
            this.operateMenu.me.y = pos.y - 56;
        }

        public hideOperateMenu() {
            this.operateMenu.visible = false;
        }

        private coinSign: string = "haidao_coin";
        private coinEndPos: Laya.Vector2 = new Laya.Vector2(1377, 245);
        private coinFlyDuration: number = 400;
        private effectCoinCreate: string = "scene/effect_haidao_shop1.lh";
        private effectCoinFlyEnd: string = "scene/effect_haidao_shop2.lh";
        private sellEffects: game.UIEffect[] = new Array();

        private createSellEffect(startPos: Laya.Vector2, price: number) {
            let coinCount = Math.floor(price / 100);
            coinCount = coinCount == 0 ? 1 : Math.min(coinCount, 10);
            let coinList: UI_FlyItem[] = new Array();
            let lastUpX = true;
            let lastUpY = true;
            let range = 130;
            //todo 生成起始特效
            let effect1 = this.createEffect(this.effectCoinCreate, startPos);
            Laya.timer.once(1000, this, () => {
                this.disposeEffect(effect1)
            });
            for (let index = 0; index < coinCount; index++) {
                let currentIndex = index;
                let coin = UI_FlyItemFactory.Inst.createFlyItem(this.coinSign, Laya.Image);
                let coinImg = coin.me as Laya.Image;
                coinImg.skin = game.Tools.localUISrc("myres/activity_2406_haidao/islands.png");
                coinImg.anchorX = 0.5;
                coinImg.anchorY = 0.5;
                coinImg.width = 50;
                coinImg.height = 50;

                let randomX = Math.random() * range;
                randomX = lastUpX ? -randomX : randomX;
                lastUpX = randomX > 0;
                let randomY = Math.random() * range;
                randomY = lastUpY ? -randomY : randomY;
                lastUpY = randomY > 0;
                let coinStartPos: Laya.Vector2 = new Laya.Vector2(startPos.x + randomX, startPos.y + randomY);
                coinImg.x = startPos.x + randomX;
                coinImg.y = startPos.y + randomY;
                this.operateLayer.addChild(coinImg);
                coinList.push(coin);
                coin.doStraightMoveAnim(0, coinStartPos, this.coinEndPos, this.coinFlyDuration, new Laya.Handler(this, () => {
                    UI_FlyItemFactory.Inst.recycleFlyItem(coin);
                    if (currentIndex == 0) {
                        let effect2 = this.createEffect(this.effectCoinFlyEnd, this.coinEndPos);
                        Laya.timer.once(1000, this, () => {
                            this.disposeEffect(effect2);
                        });
                    }
                }))
            }

        }

        private createEffect(path: string, pos: Laya.Vector2): game.UIEffect {
            let effect = game.FrontEffect.Inst.create_ui_effect(this.operateLayer, path, new Laya.Point(pos.x, pos.y), 1);
            this.sellEffects.push(effect);
            return effect;
        }

        private disposeEffect(effect: game.UIEffect) {
            let result = this.sellEffects.find((v) => {
                return v == effect;
            });
            if (result != null) {
                let index = this.sellEffects.findIndex((v) => {
                    return v == effect;
                });
                this.sellEffects.splice(index, 1);
                result.destory();
            };

        }

        private disposeAllEffect() {
            this.sellEffects.forEach((effect) => {
                effect.destory();
            })
            this.sellEffects = new Array();
        }

        private beforeUpdate() {
            this.saveCurrentItemData();
            this.saveCurrentShopCarItemData();
        }




    }


}