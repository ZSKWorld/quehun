module uiscript {
    export class UI_Activity_Haidao_QuitTip extends UI_Component {
        private txtTitle: Laya.Label;
        private btnConfirm: UI_Button;
        private btnCancel: UI_Button;
        private btnClose: Laya.Button;
        private btnMask: Laya.Button;
        private txtTip1: Laya.Label;
        private isLock: boolean = false;
        private onConfirm: Laya.Handler;

        public onCreate(): void {
           
            this.btnConfirm = new UI_Button(this.me.getChildByName('confirm_btn') as Laya.Sprite, true);
            this.btnCancel = new UI_Button(this.me.getChildByName('cancel_btn') as Laya.Sprite, true);
            this.btnClose = this.me.getChildByName('pop_frame').getChildByName('close_btn') as Laya.Button;
            this.btnMask = this.me.getChildByName('btn') as Laya.Button;
            this.txtTitle = this.me.getChildByName('pop_frame').getChildByName('title') as Laya.Label;
            this.txtTip1 = this.me.getChildByName('tip1') as Laya.Label;
            this.btnConfirm.setClickListener(new Laya.Handler(this, this.onClickConfirmBtn));
            this.btnClose.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.btnMask.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.btnCancel.setClickListener(new Laya.Handler(this, this.onClickClose));



        }

        public show(tipMsg:string,confirmStr:string, onClickConfirm: Laya.Handler) {
            this.visible = true;
            this.onConfirm = onClickConfirm;
            this.txtTip1.text = tipMsg;
            this.btnConfirm.title = confirmStr;
        }


        private onClickConfirmBtn() {
            if (this.isLock) {
                return;
            }
            this.onConfirm.run();
            this.onClickClose();
        }

       

        private onClickClose() {
            if (this.isLock) {
                return;
            }
            this.visible = false;
        }
    }
}

