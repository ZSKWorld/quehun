module uiscript {
    export class Haidao_Page_Task_TabButton {
        private me: Laya.Button;
        private selectImg: Laya.Image;
        private title: Laya.Label;
        constructor(me: Laya.Button) {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
        }
        public onSelect() {
            this.selectImg.visible = true;
            this.title.color = '#fefcea';
        }
        public onDeselect() {
            this.selectImg.visible = false;
            this.title.color = '#9fa5ab';
        }
    }
    export class UI_Activity_Haidao_Rewards extends UIBase {
        public static activityId: number = 240603;
        public static activityCurrencyId: number = 240606;
        public static Inst: UI_Activity_Haidao_Rewards;
        public static lockNetwork: boolean;

        public static newUnLockItemsIds: number[] = [];
        public static pendingCongrateJump() {
            if (this.newUnLockItemsIds.length > 0) {
                if (UI_Activity_Haidao_Congrate.Inst) {
                    UI_Activity_Haidao_Congrate.Inst.show(ECongrateType.getItem, Laya.Handler.create(this, () => {
                        UI_Activity_Haidao_Rewards.pendingCongrateJump();
                    }));
                }
            }
        }

        public static onCheckedReward(rewardId: number) {
            for (let i = 0; i < this.newUnLockItemsIds.length; i++) {
                if (this.newUnLockItemsIds[i] == rewardId) {
                    this.newUnLockItemsIds.splice(i, 1);
                    break;
                }
            }
            if (UI_Activity_Haidao.Inst && UI_Activity_Haidao.Inst.enable) {
                UI_Activity_Haidao.Inst.refreshStageCloud(true);
            }
        }

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static getUnLockStateByTaskId(taskId: number) {
            let _info = UI_Activity.getPeriodTaskInfo(taskId);
            if (_info && _info['achieved'] && !_info['rewarded']) {
                let d_task = cfg.activity.period_task.get(_info['id']);
                let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                if (d_task && d_task.reward_limit_day <= delta) {
                    return true;
                }
            }
            return false;
        }

        //用区域或者背包的物品id领取这个奖励（解锁背包或者区域
        public static receiveRewardsByTaskId(taskId: number) {
            let _info = UI_Activity.getPeriodTaskInfo(taskId);
            if (!_info) return;
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            let configData = cfg.activity.period_task.get(_info['id']);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount = rewardsData[1];
            Laya.stage.event(Haidao_EventId.UNLOCK_BAG);
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: taskId }, (err, res) => {
                this.lockNetwork = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                } else {
                    UI_Activity.onPeriodTaskRewarded(taskId);
                    this.newUnLockItemsIds.push(rewardId);
                    UI_Activity_Haidao_Rewards.pendingCongrateJump();
                }
            });
        }

        private comBtns: Laya.Sprite;
        private root: Laya.Sprite;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [3668, 3670, 3669];
        private tabButtons: Array<Haidao_Page_Task_TabButton>;
        private btnGetAll: Laya.Button;
        private btnGetAllTitle: Laya.Label;
        private btnGetAllIcon: Laya.Image;
        private itemRect: UIRect = null;
        private rewardItemRect: UIRect = null;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private btnReturn: Laya.Button;
        private txtTitle: Laya.Label;
        private btnReturnTitle: Laya.Label;
        private btnCurrency: Laya.Button;
        private txtCurrency: Laya.Label;
        private txtMostCurrency: Laya.Label;
        private comBigReward: Laya.Sprite;
        private txtBigReward: Laya.Label;
        private imgBigRewardBg: Laya.Image;
        private imgBigRewardIcon: Laya.Image;
        private btnBigReward: Laya.Button;
        private bigRewardId: number;
        public locking: boolean;
        /**
         * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
         */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;

        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_rewardUI());
            UI_Activity_Haidao_Rewards.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.listScrollBar = list.getChildByName("scrollbar") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAllTitle = this.btnGetAll.getChildByName("title") as Laya.Label;
            this.btnGetAllIcon = this.btnGetAll.getChildByName("bg") as Laya.Image;
            this.btnReturn = this.me.getChildByName('left_top').getChildByName('btn_close') as Laya.Button;
            this.txtTitle = this.root.getChildByName('content_bg').getChildByName('stage_name') as Laya.Label;
            this.btnReturnTitle = this.me.getChildByName('left_top').getChildByName('title') as Laya.Label;
            this.btnCurrency = this.me.getChildByName('currency').getChildByName('info_btn') as Laya.Button;
            this.txtCurrency = this.me.getChildByName('currency').getChildByName('value_text') as Laya.Label;
            this.txtMostCurrency = this.me.getChildByName('left').getChildByName('count') as Laya.Label;
            this.comBigReward = this.me.getChildByName('left').getChildByName('big_reward') as Laya.Sprite;
            this.txtBigReward = this.comBigReward.getChildByName('target_title') as Laya.Label;
            this.imgBigRewardBg = this.comBigReward.getChildByName('bg') as Laya.Image;
            this.imgBigRewardIcon = this.comBigReward.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.btnBigReward = this.comBigReward.getChildByName('item').getChildByName('btn') as Laya.Button;
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender), 160);
            this.aniShow = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_rewardUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_rewardUI).hide;
            this.bindEvent();
            this.initTabs();
            this.txtTitle.text = game.Tools.strOfLocalization(4380);
            this.btnReturnTitle.text = game.Tools.strOfLocalization(4379);
            this.btnGetAllTitle.text = game.Tools.strOfLocalization(3878);
            (this.comEmpty.getChildAt(0) as Laya.Label).text = game.Tools.strOfLocalization(4005);
            (this.me.getChildByName('left').getChildByName('most_title') as Laya.Label).text = game.Tools.strOfLocalization(4381);
            (this.me.getChildByName('left_top').getChildByName('title_bg') as Laya.Image).width = this.btnReturnTitle.width + 177;
        }

        private bindEvent() {
            this.btnReturn.clickHandler = new Laya.Handler(this, this.onClickReturn);
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            this.btnBigReward.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_ItemDetail.Inst.show(this.bigRewardId);
            });
            this.btnCurrency.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_ItemDetail.Inst.show(UI_Activity_Haidao.moneyItemId);
            });
        }


        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList() {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<Haidao_Page_Task_TabButton>();
            let tabsName = ['all', 'achieved', 'doing'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Haidao_Page_Task_TabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.freshList();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        public show() {
            this.enable = true;
            //播放开始动画
            this.aniShow.play(0, false);
            UI_Activity_Haidao.Inst.showPopupBg(true, true);
            let delay = this.aniShow.count * this.aniShow.interval;
            this.locking = true;
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            let tween_config = { delay: 84, duration: 167, ease: Laya.Ease.backOut };
            let start_config = { alpha: 0, y_dis: 200 };
            let target_config = { alpha: 1 };
            let list_delay = game.Tools.listAnim(list, 4, tween_config, start_config, target_config);
            delay = delay > list_delay ? delay : list_delay;
            view.AudioMgr.PlayAudio(10131);
            Laya.timer.once(delay, this, () => {
                uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.pageReward, true);
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        public close() {
            //播放关闭动画
            this.locking = true;
            this.aniHide.play(0, false);
            UI_Activity_Haidao.Inst.showPopupBg(false, true);
            if (UI_Activity_Haidao.Inst && UI_Activity_Haidao.Inst.enable) {
                UI_Activity_Haidao.Inst.refreshRedPoints();
            }
            uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.pageReward, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Rewards', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Rewards', true);
            this.freshData();
            this.tabGroups.init();
            let moneyCount = UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId);
            this.txtCurrency.text = moneyCount.toString();
            let currencyTasks: game.ITaskProgress[] = UI_Activity.getPeriodTaskList(UI_Activity_Haidao_Rewards.activityCurrencyId) as game.ITaskProgress[];
            let count = currencyTasks && currencyTasks[0] && currencyTasks[0].counter ? currencyTasks[0].counter : 0;
            this.txtMostCurrency.text = count.toString();
            this.bigRewardId = 0;
            let difference = 0;
            for (let i = 0; i < this.sortServerData[1].length; i++) {
                let data = this.sortServerData[1][i];
                let configData = cfg.activity.period_task.get(data.id);
                if (configData.node_mark == 1 && !data.achieved && this.isTaskUnlock(data)) {
                    let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
                    this.bigRewardId = rewardsData[0];
                    let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
                    let nowProgress = data.counter || 0;
                    difference = baseTaskConfigData.target - nowProgress;
                    break;
                }
            }
            this.comBigReward.visible = !!this.bigRewardId;
            if (this.comBigReward.visible) {
                if (this.rewardItemRect == null) {
                    this.rewardItemRect = UIRect.CreateFromSprite(this.imgBigRewardIcon);
                }
                game.Tools.setItemIcon(this.imgBigRewardIcon, this.rewardItemRect, this.bigRewardId, "UI_Activity_Haidao_Rewards", true);
                if (GameMgr.client_language == 'en') {
                    this.txtBigReward.fontSize = 28;
                } else if (GameMgr.client_language == 'jp') {
                    this.txtBigReward.fontSize = 24;
                }
                this.txtBigReward.text = game.Tools.strOfLocalization(4382, [difference.toString()]);
                this.imgBigRewardBg.width = this.txtBigReward.width + 214;
                (this.comBigReward.getChildByName('item') as Laya.Sprite).x = this.imgBigRewardBg.x + this.imgBigRewardBg.width / 2 - 60;
                this.txtBigReward.x = this.imgBigRewardBg.x - this.imgBigRewardBg.width / 2 + 48;
            }
        }

        private onClickReturn() {
            if (this.locking) return;
            this.close();
        }

        //刷新列表数据
        private freshData() {
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_Haidao_Rewards.activityId);
            // app.Log.log(`UI_Activity_Haidao_Rewards的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);
            this.freshGetAllBtn();
        }


        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                weight = -10000; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Sprite;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let imgBg = unLockParent.getChildByName("bg") as Laya.Image;
            let imgBgLocked = lockedParent.getChildByName("bg_locked") as Laya.Image;
            let txtDesc = container.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('getted') as Laya.Image;
            let btnReceive = unLockParent.getChildByName("btn_get") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;
            let txtLockedTime = lockedParent.getChildByName('locked') as Laya.Label;

            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;

            //判断是否是大奖
            (itemParent.getChildByName('bg') as Laya.Image).visible = configData.node_mark == 0;
            (itemParent.getChildByName('bg_big') as Laya.Image).visible = configData.node_mark != 0;
            imgBg.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2406_haidao/award_list.png' : 'myres/activity_2406_haidao/award_prize_list_bottom.png');
            imgBgLocked.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2406_haidao/award_list_unlock.png' : 'myres/activity_2406_haidao/award_prize_list_bottom_unlock.png');
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = serverData.achieved && !serverData.rewarded;
                txtProgress.visible = !serverData.achieved;
                imgGetted.visible = serverData.achieved && serverData.rewarded;

                if (!serverData.achieved) {
                    let progress: number = serverData.counter || 0;
                    txtProgress.text = game.Tools.strOfLocalization(4253) + '\n' + `${progress}/${baseTaskConfigData.target}`;
                }
                else {
                    if (!serverData.rewarded) {
                        //已完成未领取
                        (btnReceive.getChildByName("title") as Laya.Label).text = game.Tools.strOfLocalization(4251);
                        //领取的点击事件
                        btnReceive.clickHandler = new Laya.Handler(this, () => {
                            if (this.locking) return;
                            this.locking = true;
                            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                                this.locking = false;
                                if (err || res['error']) {
                                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                                } else {
                                    UI_Activity.onPeriodTaskRewarded(serverData.id);
                                    let rewardData = cfg.item_definition.function_item.get(rewardId);
                                    if (rewardData && rewardData.args[0] == 240601) {
                                        UI_Activity_Haidao_Rewards.newUnLockItemsIds.push(rewardId);
                                    }
                                    game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                    this.freshData();
                                    this.scrollView.wantToRefreshAll();
                                }
                            });
                        }, null, false);
                    }
                    else {
                        //已完成已领取
                    }
                }
                itemParent.alpha = 1;
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Haidao_Rewards.activityId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText2(restSeconds);
                itemParent.alpha = 0.5;
            }

            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("icon") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                let btnItemDetail = itemParent.getChildByName("btn") as Laya.Button;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_Haidao_Rewards", true);
                txtCount.text = rewardCount.toString();
                btnItemDetail.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })
            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(task.id);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Haidao_Rewards.activityId);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAllTitle.color = shouldSetGray ? '#9c8781' : '#6c4419';
            this.btnGetAllIcon.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_2406_haidao/island_big_button_ash.png' : 'myres/activity_2406_haidao/island_big_button.png');
            this.btnGetAll.mouseEnabled = !shouldSetGray;
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Haidao_Rewards.activityId);
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Haidao_Rewards.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        needGetList.push(data['id']);
                    } else {
                        break;
                    }
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.freshData();
                    this.scrollView.wantToRefreshAll();
                    for (let key in rewardObj) {
                        let rewardData = cfg.item_definition.function_item.get(Number(key));
                        if (rewardData && rewardData.args[0] == 240601) UI_Activity_Haidao_Rewards.newUnLockItemsIds.push(Number(key));
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }

    }
}