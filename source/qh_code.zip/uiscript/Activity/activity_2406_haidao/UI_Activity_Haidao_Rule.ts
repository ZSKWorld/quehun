/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_Haidao_Rules extends UIBase {
        public static Inst: UI_Activity_Haidao_Rules;
        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_ruleUI());
            UI_Activity_Haidao_Rules.Inst = this;
        }

        private bg: Laya.Image;
        private root: Laya.Sprite;
        private img: Laya.Image;
        private btnLeft: Laya.Button;
        private btnRight: Laya.Button;
        private pageCount: number = 3;
        private pageIndex: number = 0;
        private locking: boolean;

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            this.img = this.root.getChildByName('img') as Laya.Image;
            this.btnLeft = this.root.getChildByName('btn_left') as Laya.Button;
            this.btnRight = this.root.getChildByName('btn_right') as Laya.Button;
            this.btnLeft.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.showPage(this.pageIndex - 1);
            });

            this.btnRight.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.showPage(this.pageIndex + 1);
            });
            (this.root.getChildByName('bg').getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(4123);
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, {alpha: 0.3}, 200);
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            this.showPage(0);
        }
        
        private close() {
            this.locking = true;
            Laya.Tween.to(this.bg, {alpha: 0}, 200);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.enable = false;
                this.locking = false;
                UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(4328));
            }));
        }

        private showPage(index: number) {
            if (index < 0 || index >= this.pageCount) return;
            this.pageIndex = index;
            this.btnLeft.visible = index != 0;
            this.btnRight.visible = index != this.pageCount - 1;
            (this.root.getChildByName('page') as Laya.Label).text = "(" + (index + 1) + '/3)';
            game.LoadMgr.setImgSkin(this.img, `myres/activity_2406_haidao/rule_${index + 1}.png`, null, 'UI_Activity_Haidao_Rule');
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Rule', true);
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Rule', false);
        }
    }
}