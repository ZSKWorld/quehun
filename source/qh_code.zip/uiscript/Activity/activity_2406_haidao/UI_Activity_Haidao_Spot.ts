module uiscript {
    enum ESpotLockState { none, time, task };
    class Item_Haidao_Spot {
        public me: Laya.Sprite;
        private image: Laya.Image;
        private play: Laya.Sprite;
        private playMask: Laya.Sprite;
        private lock: Laya.Sprite;
        private labelLock: Laya.Label;
        private labelName: Laya.Label;
        private btnPlay: Laya.Button;

        private data: lqc.Sheet_Activity_SpotActivity;
        private spotId: number;
        constructor(me: Laya.Sprite, data: lqc.Sheet_Activity_SpotActivity) {
            this.me = me;
            this.image = this.me.getChildByName('image') as Laya.Image;
            this.play = this.me.getChildByName('play') as Laya.Sprite;
            this.playMask = (this.play.getChildByName('bg') as Laya.Image).mask;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.labelLock = this.lock.getChildByName('text') as Laya.Label;
            this.labelName = this.me.getChildByName('name').getChildByName('name') as Laya.Label;
            this.btnPlay = this.me.getChildByName('btn_play') as Laya.Button;
            this.btnPlay.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Haidao_Spot.Inst.locking) return;
                let spotData = game.ActivitySpotDataHelper.getSpotData(UI_Activity_Haidao_Spot.activityId, this.data.unique_id);
                if (!spotData || !spotData.unlocked) {
                    UI_Activity_Haidao_Spot.Inst.locking = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'unlockActivitySpot', { unique_id: this.data.unique_id }, (err, res) => {
                        UI_Activity_Haidao_Spot.Inst.locking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('unlockActivitySpot', err, res);
                        } else {
                            game.ActivitySpotDataHelper.add_lock_spot(UI_Activity_Haidao_Spot.activityId, this.data.unique_id);
                            this.showSpot();
                        }
                    });
                    return;
                }
                this.showSpot();
            })
            this.data = data;
            this.spotId = data.unique_id;
        }

        private showSpot() {
            GameMgr.Inst.showSpotByEvent(this.data.content_path, this.data.unique_id, null, UI_Activity_Haidao_Spot.activityId, Laya.Handler.create(this, () => {
                uiscript.UI_Activity_Haidao.Inst.removeNotifyActivityChangeListener();
                UI_Activity_Haidao.Inst.stopBgm();
                game.Scene_Lobby.Inst.setBackHandler(Laya.Handler.create(this, () => {
                    this.refresh();
                    UI_Activity_Haidao.Inst.show();
                    UI_Activity_Haidao_Spot.Inst.enable = true;
                    UI_Activity_Haidao.Inst.showPopupBg(true, false);
                    if (!UI_Activity.activities[UI_Activity_Haidao.activityId]) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            UI_Activity_Haidao.Inst.hide();
                        }))
                    }
                }));
            }, null, false));
        }

        public show() {
            this.image.skin = game.Tools.localUISrc('myres/activity_2406_haidao/spot_images/' + this.data.ending_res);
            this.refresh();
        }

        public refresh() {
            let _state = this.checkLockState();
            // 先检查锁
            if (_state != ESpotLockState.none) {
                this.lock.visible = true;
                this.btnPlay.visible = false;
                this.play.visible = false;
                if (_state == ESpotLockState.time) {
                    //解锁剩余时间
                    let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Haidao_Spot.activityId, this.data.limit_day);
                    this.labelLock.text = game.Tools.getLockTimeText1(restSeconds);
                } else {
                    let data = cfg.activity.period_task.get(this.data.unlock_task_id);
                    let baseTask = cfg.events.base_task.get(data.base_task_id);
                    this.labelLock.text = baseTask['desc_' + GameMgr.client_language];
                }
                this.labelName.text = game.Tools.strOfLocalization(3616);
                (this.me.getChildByName('name').getChildAt(0) as Laya.Label).height = 60;
                this.image.visible = false;
                return;
            }
            this.lock.visible = false;
            this.btnPlay.visible = true;
            this.labelName.text = game.Tools.eventStrOfLocalization(this.data.title);
            (this.me.getChildByName('name').getChildAt(0) as Laya.Label).height = this.labelName.text.indexOf('\n') > -1 ? 96 : 60;
            let info = game.ActivitySpotDataHelper.getSpotData(UI_Activity_Haidao_Spot.activityId, this.spotId);
            if (info && info.unlocked_ending) {
                let endingList: Array<number> = [];
                for (let ending of this.data.ending_id) {
                    if (ending) {
                        endingList.push(ending);
                    } else {
                        break;
                    }
                }
                //三个结局的解锁一个就显示插图
                if (endingList.length == 1 || endingList.length == 3) {
                    if (info.unlocked_ending.indexOf(endingList[0]) == -1) {
                        // 如果未更新过相应数据，显示播放状态
                        this.play.visible = true;
                        this.playMask.visible = false;
                    } else {
                        this.play.visible = false;
                        this.playMask.visible = false;
                    }
                    this.image.visible = !this.play.visible;
                } else {
                    let index0 = info.unlocked_ending.indexOf(endingList[0]);
                    let index1 = info.unlocked_ending.indexOf(endingList[1]);
                    if (index0 != -1 && index1 != -1) {
                        this.play.visible = false;
                    } else {
                        this.play.visible = true;
                        this.playMask.visible = true;
                        (this.playMask.getChildByName('left') as Laya.Image).visible = index0 == -1;
                        (this.playMask.getChildByName('right') as Laya.Image).visible = index1 == -1;
                        //不知道为毛没刷新，设置visible关开木用，设置宽就刷新了
                        this.playMask.width = 500;
                        this.playMask.width = 480;
                    }
                    //有一个解锁就显示背景图
                    this.image.visible = index0 > -1 || index1 > -1;
                }
            } else {
                // 如果未更新过相应数据，显示播放状态
                this.play.visible = true;
                this.playMask.visible = false;
                this.image.visible = false;
            }
        }

        private checkLockState(): ESpotLockState {
            if (this.data) {
                let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Haidao_Spot.activityId);
                if (this.data.limit_day && activityDeltaTime < this.data.limit_day) {
                    return ESpotLockState.time;
                }
                if (this.data.unlock_task_id) {
                    let info: game.ITaskProgress = UI_Activity.getPeriodTaskInfo(this.data.unlock_task_id) as game.ITaskProgress;
                    if (!info || !info.achieved) {
                        return ESpotLockState.task;
                    }
                }
            }
            return ESpotLockState.none;
        }
    }
    export class UI_Activity_Haidao_Spot extends UIBase {
        public static Inst: UI_Activity_Haidao_Spot = null;
        public static start_spot_id: number = 23091001;
        public static activityId: number = 240604;
        private static _spotDatas: Array<lqc.Sheet_Activity_SpotActivity>;
        public static get spotDatas(): Array<lqc.Sheet_Activity_SpotActivity> {
            if (!this._spotDatas) {
                this._spotDatas = [];
                cfg.activity.spot_activity.forEach((value) => {
                    if (value.activity_id == UI_Activity_Haidao_Spot.activityId) {
                        this._spotDatas.push(value);
                    }
                });
            }
            return this._spotDatas;
        }
        public static haveRedPoint(): boolean {
            //可阅读的新闻
            let taskIds = [];
            let _task_infos = UI_Activity.getPeriodTaskList(UI_Activity_Haidao_Spot.activityId);
            for (let _task of _task_infos) {
                if (_task['achieved']) {
                    taskIds.push(_task['id']);
                }
            }
            for (let i = 0; i < this.spotDatas.length; i++) {
                let spotData = this.spotDatas[i];
                const _data = game.ActivitySpotDataHelper.getSpotData(UI_Activity_Haidao_Spot.activityId, spotData.unique_id);
                //到了解锁日期
                if (UI_Activity.getActivityUnLockTime(UI_Activity_Haidao_Spot.activityId, spotData.limit_day) < 0) {
                    //第一天或者解锁任务已完成
                    if (!spotData.unlock_task_id || taskIds.indexOf(spotData.unlock_task_id) >= 0) {
                        //一个结局也没看
                        if (!_data || !_data.unlocked_ending || _data.unlocked_ending.length == 0) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        private root: Laya.Sprite;
        private content: Laya.Panel;
        private listItem: Array<Item_Haidao_Spot>;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private length: number = 6; // item长度
        public locking: boolean;

        constructor() {
            super(new ui.lobby.activity_2406_haidao.activity_2406_haidao_spotUI);
            UI_Activity_Haidao_Spot.Inst = this;
        }

        public onCreate(): void {
            (this.me.getChildByName('top').getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.content = this.root.getChildByName('content') as Laya.Panel;
            this.content.hScrollBarSkin = '';
            let templete0 = this.content.getChildByName('0').getChildByName('content').getChildByName('templete') as Laya.Sprite;
            let templete1 = this.content.getChildByName('1').getChildByName('content').getChildByName('templete') as Laya.Sprite;
            let width = templete0.width - 0.5;
            this.aniShow = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_spotUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2406_haidao.activity_2406_haidao_spotUI).hide;
            this.listItem = [];
            let spotDatas: Array<lqc.Sheet_Activity_SpotActivity> = [];
            cfg.activity.spot_activity.forEach((value) => {
                if (value.activity_id == UI_Activity_Haidao_Spot.activityId) {
                    spotDatas.push(value);
                }
            });
            for (let i = 0; i < this.length; ++i) {
                let spr0: Laya.Sprite;
                let spr1: Laya.Sprite;
                if (i == 0) {
                    spr0 = templete0;
                    spr1 = templete1;
                } else {
                    spr0 = templete0.scriptMap['capsui.UICopy']['getNodeClone']();
                    spr1 = templete1.scriptMap['capsui.UICopy']['getNodeClone']();
                }
                spr0.x = width * i;
                spr1.x = width * i;
                this.listItem.push(new Item_Haidao_Spot(spr0, UI_Activity_Haidao_Spot.spotDatas[i * 2]));
                this.listItem.push(new Item_Haidao_Spot(spr1, UI_Activity_Haidao_Spot.spotDatas[i * 2 + 1]));
            }
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.content.refresh();
            this.content.hScrollBar.value = 0;
            UI_Activity_Haidao.Inst.showPopupBg(true, true);
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            });
            this.listItem.forEach((value) => {
                value.show();
            });
            view.AudioMgr.PlayAudio(10131);
        }

        public close() {
            this.locking = true;
            UI_Activity_Haidao.Inst.showPopupBg(false, true);
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Spot', true); // 控制剧情小图
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Haidao_Spot', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_2406_haidao/spot_images.atlas'));
        }
    }
}