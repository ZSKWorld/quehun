module uiscript {

    class ListItem extends UI_Component {

        public priceText: Laya.Label;
        public priceIcon: Laya.Image;
        public rateText: Laya.Label;
        public itemIcon: Laya.Image;
        public countText: Laya.Label;
        public hotImage: Laya.Image;
        public saleImage: Laya.Image;
        private priceAdapter: common.SpriteAdapter;
        private hotColor: string = "#DF2D36";
        private saleColor: string = "#4FB37C";
        private basePath: string = "myres/activity_2406_haidao/"

        public onCreate(): void {

            this.priceText = this.me.getChildByName('price').getChildByName("price_text") as Laya.Label;
            this.rateText = this.me.getChildByName('rate') as Laya.Label;
            this.countText = this.me.getChildByName('count') as Laya.Label;
            this.priceIcon = this.me.getChildByName('price').getChildByName("icon") as Laya.Image;
            this.itemIcon = this.me.getChildByName('item').getChildByName("icon") as Laya.Image;
            this.hotImage = this.me.getChildByName('hot_lable') as Laya.Image;
            this.saleImage = this.me.getChildByName('sale_lable') as Laya.Image;
            this.priceAdapter = new common.SpriteAdapter(this.priceIcon, this.priceText, SpriteAdapterType.LEFT2LEFT, 35);

        }

        public setPrice(price: number) {
            this.priceText.text = price.toString();
            this.priceAdapter.fresh();
        }

        public setRate(rate: number) {
            let trueRate: number = rate - 100;
            let rateStr = "";
            if (trueRate > 0) {
                rateStr = game.Tools.strOfLocalization(4325, ["+" + trueRate.toString()]);
            }
            else if (trueRate < 0) {
                rateStr = game.Tools.strOfLocalization(4325, [trueRate.toString()]);
            }
            this.rateText.text = rateStr;
            this.rateText.color = trueRate > 0 ? this.hotColor : this.saleColor;
            this.rateText.visible = trueRate != 0;
        }

        public setNewsEffect(effect: number) {
            this.hotImage.visible = effect == 1;
            this.saleImage.visible = effect == -1
        }

        public setIcon(iconName: string) {
            let path = this.basePath + iconName;
            this.itemIcon.skin = game.Tools.localUISrc(path);
        }

        public setCount(count: number) {
            this.countText.text = count.toString();
        }
    }

    export class UI_Activity_Haidao_StageDetail extends UIBase {
        public static Inst: UI_Activity_Haidao_StageDetail = null;
        constructor(sprite: Laya.Sprite) {
            super(sprite);
            UI_Activity_Haidao_StageDetail.Inst = this;
        }

        private isLock: boolean = false;
        /**
        * 关闭按钮
        */
        private closeBtn: Laya.Button;
        private view: Laya.Sprite;
        private stageNameText: Laya.Label;
        private currentState: Laya.Sprite;
        private lockState: Laya.Sprite;
        private listContainer: Laya.Sprite;

        private scrollView: capsui.CScrollView;
        private currentStageId: number;
        private currentStageData: Activity_Haidao_Stage;
        private showItemKeys: Array<number>;
        private moveToBtn: UI_Button;
        private shopBtn: UI_Button;
        private powerCount: Laya.Label;
        private powerIcon: Laya.Image;
        private powerIconAdapter: common.SpriteAdapter;
        private onClosePage: Laya.Handler;

        public onCreate(): void {
            this.closeBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.view = this.me.getChildByName('view') as Laya.Sprite;
            this.stageNameText = this.view.getChildByName('stage_name') as Laya.Label;
            this.listContainer = this.view.getChildByName('item_list') as Laya.Sprite;
            let state = this.view.getChildByName('state') as Laya.Sprite;
            this.currentState = state.getChildByName('current') as Laya.Sprite;
            this.lockState = state.getChildByName('locked') as Laya.Sprite;
            this.lockState.visible = false;
            this.currentState.visible = false;

            this.scrollView = this.listContainer.scriptMap['capsui.CScrollView_Heng'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));

            let goBtn = this.view.getChildByName('go_btn') as Laya.Sprite;
            this.moveToBtn = new UI_Button(goBtn, true);
            this.powerCount = goBtn.getChildByName("count") as Laya.Label;
            this.powerIcon = goBtn.getChildByName("icon") as Laya.Image;
            // this.powerIconAdapter = new common.SpriteAdapter(this.powerIcon, this.powerCount, SpriteAdapterType.LEFT2LEFT, 35);
            this.moveToBtn.setClickListener(new Laya.Handler(this, () => {
                this.onClickMoveTo();
            }));
            this.shopBtn = new UI_Button(this.view.getChildByName('shop_btn') as Laya.Sprite, true);
            this.shopBtn.setClickListener(new Laya.Handler(this, () => {
                this.onClickShop();
            }));
            let current = state.getChildByName('current') as Laya.Sprite;
            (current.getChildByName('bg') as Laya.Image).width = (current.getChildByName('text') as Laya.Label).width + 30;
        }



        public onEnable(): void {


        }

        public onDisable(): void {

        }

        public show(onClosePage: Laya.Handler = null) {
            if (this.isLock) return;
            this.onClosePage = onClosePage;
            this.currentStageId = UI_Activity_Haidao.Inst.selectStageId;
            this.currentStageData = UI_Activity_Haidao.stageDataDic.get(this.currentStageId);

            let stageConfig = this.currentStageData.stageConfig;
            //地区名称
            this.stageNameText.text = game.Tools.strOfLocalization(stageConfig.zone_name);
            //当前状态,是否是当前区域
            let isCurrent = UI_Activity_Haidao.Inst.currentAtStageId == this.currentStageId;
            this.currentState.visible = isCurrent;
            this.moveToBtn.visible = !isCurrent;
            this.shopBtn.visible = isCurrent;
            if (!isCurrent) {
                let cost = stageConfig.distance[UI_Activity_Haidao.Inst.currentAtStageId];
                this.powerCount.text = cost.toString();
                let ownPower = UI_Bag.get_item_count(UI_Activity_Haidao.powerItemId);
                let isFull = ownPower >= cost
                this.moveToBtn.grayed = !isFull;
                this.moveToBtn.titleColor = !isFull ? "#9C8781" : "#FFFFF7";
                this.powerCount.color = !isFull ? UI_Activity_Haidao.colorRed : "#FFFFF7";
                // this.moveToBtn.touchable = isFull;
                // this.powerIconAdapter.fresh();
                let moveTitle = this.moveToBtn.me.getChildByName("title") as Laya.Sprite;
                game.Tools.sprite_align_center([this.powerIcon, this.powerCount, moveTitle], 130, [2, 20]);

            }

            let viewPos = UI_Activity_Haidao.Inst.stageDetailPos.get(this.currentStageId);
            let pivot = UI_Activity_Haidao.Inst.stageDetailPivot.get(this.currentStageId);
            this.view.pivot(pivot.x, pivot.y);
            this.view.x = viewPos.x + pivot.x;
            this.view.y = viewPos.y + pivot.y;
            this.freshPage();
            this.enable = true;
            this.isLock = true;
            UIBase.anim_pop_out(this.view, Laya.Handler.create(this, () => {
                this.isLock = false;
            }));

        }

        public hide() {
            this.isLock = true;
            UIBase.anim_pop_hide(this.view, Laya.Handler.create(this, () => {
                this.isLock = false;
                this.enable = false;
            }));
        }

        private freshPage() {

            this.showItemKeys = this.currentStageData.todayShopItems.keys();
            this.showItemKeys = this.showItemKeys.sort((a, b) => {
                return this.sortItem(a, b);
            })

            this.scrollView.reset();
            this.scrollView.addItem(this.showItemKeys.length);

        }


        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: ListItem = obj.cache_data.item;
            if (!cache_data) {
                cache_data = new ListItem(container);
                obj.cache_data.item = cache_data;
            }
            let itemId = this.showItemKeys[index];
            let shopData = this.currentStageData.todayShopItems.get(itemId);
            let itemData = UI_Activity_Haidao.itemConfigDic.get(itemId);

            cache_data.setPrice(Math.floor(shopData.price));
            cache_data.setRate(shopData.discount);

            cache_data.setIcon(itemData.icon);
            cache_data.setCount(shopData.count);
            cache_data.setNewsEffect(shopData.isEffectByNews);
        }

        /**
         * 给物品列表排序 商品显示排序：涨幅由大到小（+1%在-51%前），若涨幅相同，则按商品价格由大到小排序
         * @param itemAId  
         * @param itemBId 
         * @returns 
         */
        private sortItem(itemAId: number, itemBId: number) {
            let itemA = this.currentStageData.todayShopItems.get(itemAId);
            let itemB = this.currentStageData.todayShopItems.get(itemBId);
            let weightA: number = itemA.discount * 10000 + itemA.price;
            let weightB: number = itemB.discount * 10000 + itemB.price;
            return weightB - weightA;
        }

        private onClickMoveTo() {
            if (this.isLock) {
                return;
            }
            let cost = this.currentStageData.stageConfig.distance[UI_Activity_Haidao.Inst.currentAtStageId];
            this.powerCount.text = cost.toString();
            let ownPower = UI_Bag.get_item_count(UI_Activity_Haidao.powerItemId);
            let isFull = ownPower >= cost;
            if (isFull) {
                let moveData = {
                    activity_id: UI_Activity_Haidao.activityId,
                    zone_id: this.currentStageId
                };
                this.isLock = true;
                // console.log("发送消息", ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_MOVE, moveData);

                app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_MOVE, moveData, (err, res) => {
                    this.isLock = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_MOVE, err, res);
                    }
                    else {
                        this.hide()
                        //移动成功
                        UI_Activity_Haidao.Inst.moveTo(this.currentStageId, new Laya.Handler(this, () => {
                            UI_Activity_Haidao_StageDetail.Inst.show(this.onClosePage);
                        }), true);

                    }

                })
            }
            else {
                // 显示体力不足的弹窗
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4327));
            }


        }

        private onClickShop() {
            if (this.isLock) {
                return;
            }
            this.hide();
            UI_Activity_Haidao_Page_Shop.Inst.show();
        }

        private onClickClose() {
            if (this.isLock) {
                return;
            }

            this.hide()
            this.onClosePage?.run();
        }




    }
}