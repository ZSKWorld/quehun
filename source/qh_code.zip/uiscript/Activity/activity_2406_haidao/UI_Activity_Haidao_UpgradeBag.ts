module uiscript {
    export class UI_Activity_Haidao_UpgradeBag extends UI_Component {
        private closeBtn: Laya.Button;
        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private maskCloseBtn: Laya.Button;
        private bagsContainer: UI_Activity_Haidao_BagsContainer;
        private isLock: boolean = false;
        private onItemFreshHandler: Laya.Handler;
        private currentBagData: basic.Dictionary<number, GridBag> = new basic.Dictionary();
        private isOperate: boolean = false;
        private operateMenu: UI_Activity_Haidao_OperateMenu;

        constructor(me: Laya.Sprite) {
            super(me);
        }

        public onCreate(): void {
            this.bg = this.me.getChildByName('bg_mask') as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('pop_frame').getChildByName('close_btn') as Laya.Button;
            this.maskCloseBtn = this.me.getChildByName('btn') as Laya.Button; this.closeBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, this.onClickClose);
            this.bagsContainer = new UI_Activity_Haidao_BagsContainer(this.root.getChildByName("bags") as Laya.Sprite);
            this.bagsContainer.onTabChange = new Laya.Handler(this, this.onBagTabChange);
            this.bagsContainer.onClickGrid = new Laya.Handler(this, this.onClickGrid);
            this.bagsContainer.onClickGridDown = new Laya.Handler(this, this.onGridMouseDown);

            this.onItemFreshHandler = new Laya.Handler(this, () => {
                this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
            });
            let operateLayer = this.root.getChildByName('oprate_layer') as Laya.Sprite;
            this.operateMenu = new UI_Activity_Haidao_OperateMenu(operateLayer.getChildByName('operate_btns') as Laya.Sprite);
        }

        public show() {
            this.isOperate = false;
            this.operateMenu.visible = false;
            UI_Bag.add_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            Laya.stage.on(Haidao_EventId.UPDATE_DATA, this, this.freshData);
            this.freshData();
            this.visible = true;
            this.isLock = true;
            this.root.scale(1, 1);

            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
                this.me.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
                this.me.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
                this.me.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
            }));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 150);
        }


        public hide() {
            UI_Bag.remove_item_listener(UI_Activity_Haidao.moneyItemId, this.onItemFreshHandler);
            Laya.stage.off(Haidao_EventId.UPDATE_DATA, this, this.freshData);
            this.isLock = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
                this.me.off(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
                this.me.off(Laya.Event.MOUSE_UP, this, this.onMouseUp);
                this.me.off(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
                this.visible = false;
            }));
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
        }

        public freshData() {
            let serverData = UI_Activity_Haidao.bagDataDic;
            this.currentBagData.clear();
            serverData.keys().forEach((v, i) => {
                let bagId = v;
                let bagData = serverData.get(bagId);
                this.currentBagData.set(bagId, bagData.clone());
            });
            this.bagsContainer.setData(this.currentBagData);
            this.bagsContainer.setMoney(UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId));
            this.bagsContainer.getBagUI().showUpdate();

        }

        private onClickClose() {
            if (this.isLock) {
                return;
            }
            this.hide();
        }

        private onBagTabChange() {
            this.bagsContainer.getBagUI().showUpdate();
        }

        private onGridMouseDown() {
            this.isOperate = true;
        }


        private onClickGrid() {
            if (this.isLock) {
                return;
            }
            let bagUI = this.bagsContainer.getBagUI();
            let gridIndex = bagUI.currentSelectGrid
            let gridUI = bagUI.getGrid(gridIndex.x, gridIndex.y);
            let gridUIPosition = bagUI.getGridPosition(gridIndex.x, gridIndex.y);
            // console.log("点击了格子", gridIndex.x, gridIndex.y, gridUI.State);

            if (gridUI.State == UI_Activity_Haidao_GridState.EMPTY) {
                this.hideOperateMenu();
                return;
            }

            //检测钱是否够
            if (gridUI.unlockPrice > UI_Bag.get_item_count(UI_Activity_Haidao.moneyItemId)) {
                this.hideOperateMenu();
                return;
            }
            let canUnlock = false;
            //检测四周的格子是否解锁，只要有一个格子是不锁定的就可以解锁
            let upIndex = gridIndex.x - 1;
            if (upIndex >= 0) {
                let upGrid = bagUI.getGrid(upIndex, gridIndex.y);
                if (upGrid.visible == true) {
                    if (upGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                        canUnlock = true;
                    }
                }
            }

            if (!canUnlock) {
                let downIndex = gridIndex.x + 1;
                if (downIndex < UI_Activity_Haidao.bagMaxHeight) {
                    let downGrid = bagUI.getGrid(downIndex, gridIndex.y);
                    if (downGrid.visible == true) {
                        if (downGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }

            if (!canUnlock) {
                let leftIndex = gridIndex.y + 1;
                if (leftIndex < UI_Activity_Haidao.bagMaxHeight) {
                    let leftGrid = bagUI.getGrid(gridIndex.x, leftIndex);
                    if (leftGrid.visible == true) {
                        if (leftGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }

            if (!canUnlock) {
                let rightIndex = gridIndex.y - 1;
                if (rightIndex >= 0) {
                    let rightGrid = bagUI.getGrid(gridIndex.x, rightIndex);
                    if (rightGrid.visible == true) {
                        if (rightGrid.State == UI_Activity_Haidao_GridState.EMPTY) {
                            canUnlock = true;
                        }
                    }
                }
            }


            if (!canUnlock) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4399));
                return;
            }

            let unlockGrid = new Laya.Handler(this, () => {
                let pos = [gridIndex.y, gridIndex.x];
                let reqIslandActivityUnlockBagGrid = {
                    activity_id: UI_Activity_Haidao.activityId,
                    bag_id: bagUI.bagId,
                    pos
                }
                // console.log("发送解锁请求", JSON.stringify(reqIslandActivityUnlockBagGrid));
                // this.father.saveCurrentItemData();
                Laya.stage.event(Haidao_EventId.CLICK_BAG_UPDATE);
                app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.ISLAND_ACTIVITY_UNLOCK_BAG_GRID, reqIslandActivityUnlockBagGrid, (err, res) => {
                    this.isLock = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(ProtoCode.ISLAND_ACTIVITY_MOVE, err, res);
                    }
                    else {
                        // console.log("解锁成功");
                        // onComplete?.runWith(res);
                        this.hideOperateMenu();
                        view.AudioMgr.PlayAudio(10130);
                        uiscript.UI_Activity_Haidao.Inst.setEffectActive(EActivityHaidaoEffect.bagUpdate, true, gridUIPosition);
                    }
                })

            });

            let closeMenu = new Laya.Handler(this, () => {
                this.hideOperateMenu();
            });
            let onMouseDown = new Laya.Handler(this, () => {
                // UI_Activity_Haidao_Page_Bag.Inst.hideOperateMenu();
                // this.hideOperateMenu();

            });
            let menuPos = new Laya.Vector2(gridUI.globalPos.x + UI_Activity_Haidao.gridWidth / 2, gridUI.globalPos.y);
            this.showOperateMenu(3, menuPos, unlockGrid, closeMenu, onMouseDown)
            this.bagsContainer.getBagUI().showUpdate();
        }




        public showOperateMenu(state, pos: Laya.Vector2, handler1: Laya.Handler, handler2: Laya.Handler, onMouseDown: Laya.Handler) {
            this.operateMenu.show(state, handler1, handler2, onMouseDown)
            this.operateMenu.me.x = pos.x;
            this.operateMenu.me.y = pos.y - 56;
        }

        public hideOperateMenu() {
            this.operateMenu.visible = false;
        }

        private isMouseDown: boolean;
        private onMouseDown() {
            this.isMouseDown = true;
        }

        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            if (!this.isOperate) {
                this.hideOperateMenu();
                this.bagsContainer.getBagUI().clearSelect();
                this.onBagTabChange();
            }
            this.isOperate = false;
        }


    }

}
