module uiscript {
    export class UI_Activity_Imas_Page extends UIBase {
        constructor(me: Laya.Sprite) {
            super(me);
        }

        public root: Laya.Sprite;
        private btnReturn: Laya.Button;
        private txtTitle: Laya.Label;
        public aniShow: Laya.FrameAnimation;
        public aniHide: Laya.FrameAnimation;

        public locking: boolean;

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.btnReturn = this.root.getChildByName('btn_back') as Laya.Button;
            this.txtTitle = this.root.getChildByName('bg').getChildByName('title') as Laya.Label;
            this.btnReturn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
        }

        public setTitle(str: string) {
            if (this.txtTitle) this.txtTitle.text = str;
        }

        public show(charaId: number) {
            this.enable = true;
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.locking = false;
            })
            UI_Activity_Imas_Main.Inst.showSubpageBg(charaId);
        }

        public hide() {
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.enable = false;
                this.locking = false;
            })
            UI_Activity_Imas_Main.Inst.hideSubpageBg();
            UI_Activity_Imas_Main.Inst.refreshRedPoint();
        }
    }

    export class UI_Activity_Imas_Chara extends UIBase {

        private static greetingMap: Object = {};

        private imgSkin: Laya.Image = null;
        private comChat: Laya.Sprite;
        private txtName: Laya.Label;
        private imgNameDecorate: Laya.Image;
        private imgNameBg: Laya.Image;
        private charaId: number;
        private comChara: Laya.Sprite;

        private charaInfo: any;
        private chat: UI_Character_Chat = null;

        private chatId: number = 0;
        private soundId: number = null;
        private isBig: boolean;

        constructor(me: Laya.Sprite, isBig: boolean = false) {
            super(me);
            this.isBig = isBig;
        }

        public onCreate(): void {
            // 角色 
            this.comChara = this.me.getChildByName('illust') as Laya.Sprite;
            this.imgSkin = this.comChara.getChildByName('illust') as Laya.Image;
            this.comChat = this.me.getChildByName('chat') as Laya.Sprite;
            this.comChat.visible = false;
            this.chat = new UI_Character_Chat(this.comChat);
            this.imgNameDecorate = this.comChat.getChildByName('name_decorate') as Laya.Image;
            this.imgNameBg = this.comChat.getChildByName('bg_name') as Laya.Image;
            this.txtName = this.comChat.getChildByName('name') as Laya.Label;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.soundId) {
                    this.stopsay();
                } else {
                    this.say('lobby_normal');
                }
            }, null, false);
        }

        private say(type: string) {
            this.chatId++;
            let chatId = this.chatId;
            let soundInfo = view.AudioMgr.PlayCharactorSound(this.charaInfo, type, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    if (this.chatId == chatId) {
                        this.stopsay();
                    }
                });
            }));
            if (soundInfo) {
                this.chat.show(soundInfo.words);
                this.soundId = soundInfo.audio_id;
            }
        }

        public stopsay() {
            this.chat.close(false);
            if (this.soundId) {
                view.AudioMgr.StopAudio(this.soundId);
                this.soundId = null;
            }
        }

        public showCharacter(id: number) {
            this.me.visible = true;
            this.charaId = id;
            this.charaInfo = null;
            let data = cfg.item_definition.character.get(this.charaId);
            let skinData = cfg.item_definition.skin.get(data.init_skin);
            game.LoadMgr.setImgSkin(this.imgSkin, 'myres/activity_2411imas/chara/' + this.charaId + '.png', null, 'UI_Activity_Imas_Main');
            for (let info of UI_Sushe.characters) {
                if (info.charid == this.charaId) {
                    this.charaInfo = info;
                    break;
                }
            }
            if (this.isBig) {
                //获取立绘对应的位置
                let characterPos: Laya.Image = this.comChara.getChildByName("pos_" + id) as Laya.Image;
                this.imgSkin.x = characterPos.x;
                this.imgSkin.y = characterPos.y;
            }

            if (!this.charaInfo) {
                this.charaInfo = { charid: this.charaId, level: 0, is_upgraded: false };
            }
            if (!UI_Activity_Imas_Chara.greetingMap[id]) {
                UI_Activity_Imas_Chara.greetingMap[id] = 1;
                this.say('lobby_playerlogin');
            }
            this.txtName.text = data['name_' + GameMgr.client_language];
            this.imgNameBg.width = this.txtName.trueWidth + 98;
            this.imgNameDecorate.skin = game.Tools.localUISrc('myres/activity_2411imas/deco_' + id + '.png');
        }

        public hideCharacter() {
            this.stopsay();
            this.me.visible = false;
        }

        public clearTween(){
            Laya.Tween.clearAll(this.chat.me);
        }
    }
}