module uiscript {
    enum EGradeState {
        received,
        unReceive,
        unComplete,
    }
    const maskWidth = [0, 195, 355, 510, 670, 826, 1024];
    const gradeName = ['F', 'E', 'D', 'C', 'B', 'A', 'S'];
    export class UI_Activity_Imas_LevelUp extends UIBase {
        public static Inst: UI_Activity_Imas_LevelUp;
        public static activityId: 241108;
        public static taskIds: number[] = [24110801, 24110802, 24110803, 24110804, 24110805, 24110806, 24110807]; //七个等级对应的七个任务
        public static buffMaxStrIds: number[] = [4515, 4516, 4517];

        public static needPopopOut(): boolean {
            for (let i = 1; i < this.taskIds.length; i++) {
                let _info = UI_Activity.getPeriodTaskInfo(this.taskIds[i]);
                if (_info && _info['achieved'] && !_info['rewarded']) {
                    return true;
                }
            }
            return false;
        }

        public static getNowGrade(): string {
            for (let i = this.taskIds.length - 1; i >= 0; i--) {
                let _info = UI_Activity.getPeriodTaskInfo(this.taskIds[i]);
                if (_info && _info['achieved']) {
                    return gradeName[i];
                }
            }
            return gradeName[0];
        }

        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_levelupUI());
            UI_Activity_Imas_LevelUp.Inst = this;
        }

        private btnMask: Laya.Button;
        private imgLevel1: Laya.Image;
        private imgLevel2: Laya.Image;
        private comProgress: Laya.Sprite;
        private comGrades: Laya.Sprite[];
        private mask1: Laya.Sprite;
        private mask2: Laya.Sprite;
        private imgPtNumbers: Laya.Image[];
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniGrade: Laya.FrameAnimation;
        public locking: boolean;
        private receivedIndex: number;
        private completedIndex: number;
        private nowIndex: number;

        public onCreate(): void {
            this.btnMask = this.me.getChildByName('btn_mask') as Laya.Button;
            this.imgLevel1 = this.me.getChildByName('level1') as Laya.Image;
            this.imgLevel2 = this.me.getChildByName('level2') as Laya.Image;
            this.comProgress = this.me.getChildByName('progress') as Laya.Sprite;
            this.comGrades = [];
            for (let i = 1; i < this.comProgress.numChildren; i++) {
                let grade = this.comProgress.getChildAt(i) as Laya.Sprite;
                this.comGrades.push(grade);
            }
            this.mask1 = (this.comProgress.getChildByName('progress').getChildByName('progress') as Laya.Sprite).mask as Laya.Sprite;
            this.mask2 = (this.comProgress.getChildByName('progress').getChildByName('bg') as Laya.Sprite).mask as Laya.Sprite;
            this.imgPtNumbers = []
            let comPt = this.me.getChildByName('popularity') as Laya.Sprite;
            for (let i = 0; i < comPt.numChildren; i++) {
                this.imgPtNumbers.push(comPt.getChildAt(i) as Laya.Image);
            }
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_levelupUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_levelupUI).hide;
            this.aniGrade = (this.me as ui.lobby.activity_2411imas.activity_24imas_levelupUI).gradeShow;
            this.btnMask.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
        }

        private refreshPt() {
            let chars = UI_Bag.get_item_count(UI_Activity_Imas_Main.ptId).toString();
            this.imgPtNumbers.forEach(img => img.skin = '');
            for (let i = 0; i < chars.length; i++) {
                let url = game.Tools.localUISrc('myres/activity_2411imas/number/' + chars[i] + '.png');
                if (this.imgPtNumbers[i]) {
                    this.imgPtNumbers[i].skin = url;
                    this.imgPtNumbers[i].x = i * 90 + 47;
                }
            }
        }

        doGradeAnim() {
            let delay = 0;
            while (this.nowIndex != this.completedIndex) {
                let index = this.nowIndex;
                Laya.timer.once(delay, this, () => {
                    let targetWidth1 = maskWidth[index + 1];
                    let targetWidth2 = 1024 - targetWidth1;
                    Laya.Tween.to(this.mask1, { width: targetWidth1 }, 1000, Laya.Ease.quadInOut);
                    Laya.Tween.to(this.mask2, { width: targetWidth2 }, 1000, Laya.Ease.quadInOut);
                    Laya.timer.once(800, this, () => {
                        Laya.Tween.to(this.comGrades[index + 1], { scaleX: 1.5, scaleY: 1.5 }, 100, null, Laya.Handler.create(this, () => {
                            Laya.Tween.to(this.comGrades[index + 1], { scaleX: 1, scaleY: 1 }, 100);
                        }));
                        view.AudioMgr.PlayAudio(10176);
                        let effectSmall = game.FrontEffect.Inst.create_ui_effect(this.comGrades[index + 1], 'scene/effect_imas_twinkle_small.lh', new Laya.Point(0, 0), 1);
                        Laya.timer.once(1500, effectSmall, () => {
                            effectSmall.destory();
                        });
                    })
                })
                this.nowIndex++;
                delay = delay + 1200;
            }
            Laya.timer.once(delay + 333, this, () => {
                this.aniGrade.play(0, false);
                view.AudioMgr.PlayAudio(10175);
                let effectBig = game.FrontEffect.Inst.create_ui_effect(this.imgLevel2, 'scene/effect_imas_twinkle_big.lh', new Laya.Point(0, 0), 1);
                Laya.timer.once(1500, effectBig, () => {
                    effectBig.destory();
                });
            })
            Laya.timer.once(delay + 2000, this, () => {
                this.locking = false;
            })
        }

        public show() {
            this.enable = true;
            // let taskStates = [ //测试动画用
            //     EGradeState.received,
            //     EGradeState.received,
            //     EGradeState.received,
            //     EGradeState.unReceive,
            //     EGradeState.unComplete,
            //     EGradeState.unComplete,
            //     EGradeState.unComplete,
            // ];
            let taskStates = [EGradeState.received];
            let needReceiveList = [];
            for (let i = 1; i < UI_Activity_Imas_LevelUp.taskIds.length; i++) {
                let _info = UI_Activity.getPeriodTaskInfo(UI_Activity_Imas_LevelUp.taskIds[i]);
                if (!_info) {
                    taskStates.push(EGradeState.unComplete);
                    continue;
                }
                if (_info['achieved']) {
                    if (_info['rewarded']) {
                        taskStates.push(EGradeState.received);
                    } else {
                        needReceiveList.push(UI_Activity_Imas_LevelUp.taskIds[i]);
                        taskStates.push(EGradeState.unReceive);
                    }
                } else {
                    taskStates.push(EGradeState.unComplete);
                }
            }
            this.receivedIndex = null;
            this.completedIndex = null;
            for (let index = taskStates.length - 1; index >= 0; index--) {
                if (taskStates[index] == EGradeState.unReceive && !this.completedIndex) {
                    this.completedIndex = index;
                }
                if (taskStates[index] == EGradeState.received && !this.receivedIndex) {
                    this.receivedIndex = index;
                }
            }
            this.nowIndex = this.receivedIndex;
            this.mask1.width = maskWidth[this.nowIndex];
            this.mask2.width = 1024 - this.mask1.width;
            this.imgLevel1.skin = game.Tools.localUISrc('myres/activity_2411imas/number/' + gradeName[this.receivedIndex] + '.png');
            this.imgLevel2.skin = game.Tools.localUISrc('myres/activity_2411imas/number/' + gradeName[this.completedIndex] + '.png');
            this.refreshPt();
            this.locking = true;
            view.AudioMgr.PlayAudio(10174);
            this.aniShow.gotoAndStop(0);
            let effectShow = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/effect_imas_levelup_show.lh', new Laya.Point(960, 540), 1);
            Laya.timer.once(2000, effectShow, () => {
                effectShow.destory();
            });
            Laya.timer.once(167, this, () => {
                this.aniShow.play(0, false);
                this.doGradeAnim();
                this.receiveRewards(needReceiveList);
            });
        }

        private receiveRewards(needReceiveList: number[]) {
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needReceiveList }, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    for (let id of needReceiveList) {
                        UI_Activity.onPeriodTaskRewarded(id);
                    }
                }
            });
        }

        public hide() {
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.clearAll(this);
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.enable = false;
                this.locking = false;
            })
        }
    }
}