module uiscript {

    export class UI_Activity_Imas_Main extends UIBase {
        public static Inst: UI_Activity_Imas_Main = null;
        public static activityId: number = 241101;
        public static currencyId: number = 30900078;
        public static ptId: number = 30900079;
        public static haveRedPoint() {
            if (uiscript.UI_Activity_Imas_Spot.haveRedPoint()) return true;
            if (uiscript.UI_Activity_Imas_Reward.haveRedPoint()) return true;
            if (uiscript.UI_Activity_Imas_Task.haveRedPoint()) return true;
            if (uiscript.UI_Activity_Imas_Upgrade.haveRedPoint()) return true;
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imasUI);
            UI_Activity_Imas_Main.Inst = this;
        }

        private imgBg: Laya.Image;

        private pageMain: Laya.Sprite;
        private mainChara: UI_Activity_Imas_Chara;
        private btnHelp: Laya.Button;
        private btnUpgrade: Laya.Button;
        private btnSpot: Laya.Button;
        private btnMatch: Laya.Button;
        private imgCopyright: Laya.Image;

        private comPad: Laya.Sprite;
        private imgGrade: Laya.Image;
        private imgPtNumbers: Laya.Image[];
        private comPtNumbers: Laya.Sprite;
        private btnTask: Laya.Button;
        private btnReward: Laya.Button;
        private comPages: Laya.Sprite;
        private pageChara: UI_Activity_Imas_Chara;
        private btnMask: Laya.Button;

        private btnCurrency: Laya.Button;
        private btnReturn: Laya.Button;

        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniShowPage: Laya.FrameAnimation;
        private aniHidePage: Laya.FrameAnimation;
        private aniShowMain: Laya.FrameAnimation;
        private aniHideMain: Laya.FrameAnimation;

        private pages: UI_Activity_Imas_Page[];
        private pageUpgrade: UI_Activity_Imas_Upgrade;
        public locking: boolean;
        private refreshPtHandler: Laya.Handler;
        private refreshCurrencyHandler: Laya.Handler;
        private audioId: number;
        private activityFinishHandler: Laya.Handler;
        private waitingShowYindao: boolean = false; // 首次剧情之后标记该值，下次进入打开引导
        private inMatch: boolean = false;

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.pageMain = this.me.getChildByName('main') as Laya.Sprite;
            this.mainChara = new UI_Activity_Imas_Chara(this.pageMain.getChildByName('illust') as Laya.Sprite, true);
            this.btnHelp = this.pageMain.getChildByName('left_top').getChildByName('btn_help') as Laya.Button;
            this.btnUpgrade = this.pageMain.getChildByName('bottom').getChildByName('btn_upgrade') as Laya.Button;
            this.btnSpot = this.pageMain.getChildByName('bottom').getChildByName('btn_spot') as Laya.Button;
            this.btnMatch = this.pageMain.getChildByName('bottom').getChildByName('btn_pk') as Laya.Button;
            this.imgCopyright = this.pageMain.getChildByName('bottom').getChildByName('copyright') as Laya.Image;
            this.comPad = this.pageMain.getChildByName('bottom').getChildByName('pad') as Laya.Sprite;
            this.imgGrade = this.comPad.getChildByName('grade') as Laya.Image;
            this.comPtNumbers = this.comPad.getChildByName('popularity') as Laya.Sprite;
            this.imgPtNumbers = [];
            for (let i = 0; i < this.comPtNumbers.numChildren; i++) {
                this.imgPtNumbers.push(this.comPtNumbers.getChildAt(i) as Laya.Image);
            }
            this.btnTask = this.pageMain.getChildByName('right').getChildByName('btn_task') as Laya.Button;
            this.btnReward = this.pageMain.getChildByName('right').getChildByName('btn_reward') as Laya.Button;

            this.comPages = this.me.getChildByName('pages') as Laya.Sprite;
            this.btnMask = this.comPages.getChildByName('btn_mask') as Laya.Button;
            this.pageChara = new UI_Activity_Imas_Chara(this.comPages.getChildByName('illust') as Laya.Sprite);
            this.btnReturn = this.me.getChildByName('btn_return') as Laya.Button;
            this.btnCurrency = this.me.getChildByName('currency') as Laya.Button;

            this.pages = [];
            this.pages.push(new UI_Activity_Imas_Match());
            this.pages.push(new UI_Activity_Imas_Spot());
            this.pages.push(new UI_Activity_Imas_Reward());
            this.pages.push(new UI_Activity_Imas_Task());
            this.pages.forEach((value) => {
                this.comPages.addChild(value.me);
                value.enable = false;
            });
            this.pageUpgrade = new UI_Activity_Imas_Upgrade();
            this.comPages.addChild(this.pageUpgrade.me);
            this.me.addChild((new UI_Activity_Imas_LevelUp()).me);
            this.btnCurrency.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_ItemDetail.Inst.show(UI_Activity_Imas_Main.currencyId);
            });
            this.btnMatch.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Imas_Match.Inst.show();
            });
            this.btnSpot.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Imas_Spot.Inst.show();
            });
            this.btnReward.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Imas_Reward.Inst.show();
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Imas_Task.Inst.show();
            });
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Imas_Upgrade.Inst.show();
            });
            this.btnReturn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (UI_Activity_Imas_Upgrade.Inst.enable) {
                    UI_Activity_Imas_Upgrade.Inst.hide();
                    return;
                }
                if (this.pageMain.visible) {
                    this.hide();
                } else {
                    this.pages.forEach((value) => {
                        if (value.enable) {
                            value.hide();
                        }
                    });
                }
            });
            this.btnHelp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showGuide();
            }, null, false);
            game.LoadMgr.setImgSkin(this.imgBg, 'myres/activity_2411imas/bg1.jpg', null, 'UI_Activity_Imas_Main');
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).hide;
            this.aniShowMain = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).showMain;
            this.aniHideMain = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).hideMain;
            this.aniShowPage = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).showPage;
            this.aniHidePage = (this.me as ui.lobby.activity_2411imas.activity_24imasUI).hidePage;
            this.refreshCurrencyHandler = new Laya.Handler(this, this.refreshCurrency);
            this.refreshPtHandler = new Laya.Handler(this, this.refreshPt);
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
                (this.pageMain.getChildByName('bottom').getChildByName('copyright') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2411imas/copyright2.png');
            }
            app.NetAgent.addListener2Lobby('NotifyMatchGameStart', Laya.Handler.create(this, (msg) => {
                if (this.enable) {
                    GameMgr.Inst.in_activity_mode = E_Activity_State.liandong;
                    this.inMatch = true;
                }
            }));
        }

        refreshRedPoint() {
            (this.btnSpot.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Imas_Spot.haveRedPoint();
            (this.btnUpgrade.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Imas_Upgrade.haveRedPoint();
            (this.btnTask.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Imas_Task.haveRedPoint();
            (this.btnReward.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Imas_Reward.haveRedPoint();
        }

        public showGuide() {
            let extraConfig: IRuleExtraConfig = {
                onClose: Laya.Handler.create(this, () => {
                    UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(4502), true, Laya.Handler.create(this, () => {
                        this.checkLevelUp();
                    }));
                })
            }
            UI_Liandong_Rules.Inst.show(E_Liandong_Rules_Style.Main, extraConfig);
        }

        showSpot() {
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.Imas_Yindao_Checked, 1);
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_Imas_Spot.activityId);
            const spotData = datas[0];
            GameMgr.Inst.in_activity_mode = E_Activity_State.liandong;
            GameMgr.Inst.showSpotByEvent(spotData.content_path, spotData.story_id, null, UI_Activity_Imas_Spot.activityId, Laya.Handler.create(this, () => {
                UI_Activity_Imas_Main.Inst.enable = false;
                view.AudioMgr.StopMusic(0);
            }, null, false));
        }

        private refreshCurrency() {
            (this.btnCurrency.getChildByName('count') as Laya.Label).text = UI_Bag.get_item_count(UI_Activity_Imas_Main.currencyId).toString();
        }

        private refreshPt() {
            this.imgGrade.skin = game.Tools.localUISrc('myres/activity_2411imas/number/' + UI_Activity_Imas_LevelUp.getNowGrade() + '_small.png');
            let chars = UI_Bag.get_item_count(UI_Activity_Imas_Main.ptId).toString();
            this.imgPtNumbers.forEach(img => img.skin = '');
            let startX = 322 - (chars.length * 90 / 2);
            for (let i = 0; i < chars.length; i++) {
                let url = game.Tools.localUISrc('myres/activity_2411imas/number/' + chars[i] + '.png');
                if (this.imgPtNumbers[i]) {
                    this.imgPtNumbers[i].skin = url;
                    this.imgPtNumbers[i].x = startX + i * 90 + 47;
                }
            }
        }

        public showSubpageBg(charaId: number, anim: boolean = true) {
            this.mainChara.stopsay();
            if (charaId) {
                this.pageChara.showCharacter(charaId);
                this.btnMask.visible = true;
            } else {
                this.pageChara.hideCharacter();
                this.btnMask.visible = false;
            }
            if (anim) {
                view.AudioMgr.PlayAudio(10172);
                this.locking = true;
                this.comPages.visible = true;
                this.aniShowPage.play(0, false);
                Laya.timer.once(this.aniShowPage.count * this.aniShowPage.interval, this, () => {
                    this.pageMain.visible = false;
                    this.locking = false;
                });
            } else {
                this.comPages.visible = true;
                this.pageMain.visible = false;
                this.aniShowPage.gotoAndStop(this.aniShowPage.count);
            }
        }

        public hideSubpageBg(anim: boolean = true) {
            if (anim) {
                view.AudioMgr.PlayAudio(10173);
                this.pageMain.visible = true;
                this.aniHidePage.play(0, false);
                this.locking = true;
                Laya.timer.once(this.aniHidePage.count * this.aniHidePage.interval, this, () => {
                    this.locking = false;
                    this.pageChara.hideCharacter();
                    this.comPages.visible = false;
                    this.checkLevelUp();
                });
            } else {
                this.comPages.visible = false;
                this.pageMain.visible = true;
                this.aniHidePage.gotoAndStop(this.aniHidePage.count);
                this.pageChara.hideCharacter();
            }
        }

        public show() {
            this.enable = true;
            this.refreshCurrency();
            this.refreshPt();
            if (this.inMatch) {
                this.inMatch = false;
                UI_Activity_Imas_Match.Inst.show();
                return;
            }
            this.hideSubpageBg(false);
            const charaId = 20000100 + Math.floor(Math.random() * 4);
            this.mainChara.showCharacter(charaId);
            this.mainChara.clearTween();
            this.locking = true;
            this.aniShow.gotoAndStop(0);
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            });
            this.refreshRedPoint();
            if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.Imas_Yindao_Checked)) {
                this.waitingShowYindao = true;
                this.showSpot();
                return;
            }
            if (this.waitingShowYindao) {
                this.waitingShowYindao = false;
                this.showGuide();
                return;
            }
            this.checkLevelUp();
            view.AudioMgr.PlayAudio(10177);
        }

        checkLevelUp() {
            if (UI_Activity_Imas_LevelUp.needPopopOut()) {
                UI_Activity_Imas_LevelUp.Inst.show();
            }
        }

        public hide() {
            this.locking = true;
            this.pages.forEach((value) => {
                if (value.enable) {
                    value.hide();
                }
            });
            this.aniHide.play(0, false);
            UI_Lobby.Inst.enable = true;
            this.mainChara.stopsay();
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
            }
        }

        private playBgm() {
            if (view.AudioMgr.musicMuted) return;
            let audioPath = cfg.audio.audio.get(10171).path;
            let volume = view.AudioMgr.musicVolume;
            this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Main', false);
            UI_Bag.remove_item_listener(UI_Activity_Imas_Main.ptId, this.refreshPtHandler);
            UI_Bag.remove_item_listener(UI_Activity_Imas_Main.currencyId, this.refreshCurrencyHandler);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            this.stopBgm();
            view.BgmListMgr.PlayLobbyBgm();
            this.mainChara.stopsay();
            this.hideSubpageBg(false);
            this.pages.forEach((value) => {
                value.enable = false;
            });
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Main', true);
            UI_Bag.add_item_listener(UI_Activity_Imas_Main.ptId, this.refreshPtHandler);
            UI_Bag.add_item_listener(UI_Activity_Imas_Main.currencyId, this.refreshCurrencyHandler);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            view.AudioMgr.StopMusic(0);
            this.playBgm();
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_Imas_Main.activityId) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.hide();
                        }))
                        return;
                    }
                }
            }
        }
    }
}