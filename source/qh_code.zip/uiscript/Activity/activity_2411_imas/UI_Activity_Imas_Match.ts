module uiscript {

    export class UI_Activity_Imas_Match extends UI_Activity_Imas_Page {
        public static activityId: number = 241102;
        public static Inst: UI_Activity_Imas_Match;

        private btnRules: Laya.Button;
        private txtIntroduce: Laya.Label;
        private btnMatch: Laya.Button;
        private matchingInfo: Laya.Sprite;
        private btnStopMatch: Laya.Button;
        private txtMatching: Laya.Label;

        private textAnimSpace: number = 800;
        private textAnimStartTime: number;
        private matchingStringArray: Array<string> = new Array<string>();
        private _isMatching: boolean = false;
        /**
         * 当前是否正在匹配
         */
        public get isMatching(): boolean {
            return this._isMatching;
        }

        private matchId: string = "2:51";

        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_matchUI());
            UI_Activity_Imas_Match.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            this.btnRules = this.root.getChildByName("btn_rule") as Laya.Button;
            this.txtIntroduce = this.root.getChildByName("desc") as Laya.Label;
            this.btnMatch = this.root.getChildByName("btn_match") as Laya.Button;
            this.matchingInfo = this.root.getChildByName("matching") as Laya.Sprite;
            this.btnStopMatch = this.matchingInfo.getChildByName("btn_stopmatch") as Laya.Button;
            this.txtMatching = this.matchingInfo.getChildByName("match_tip_text") as Laya.Label;
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_matchUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_matchUI).hide;
            this.initLanguageStr();
            this.bindEvent();
            this.setTitle(game.Tools.strOfLocalization(4505));
            this.txtIntroduce.text = game.Tools.strOfLocalization(4508);
        }

        private initLanguageStr() {
            let matchingStringBase = game.Tools.strOfLocalization(4511);
            this.matchingStringArray[0] = `${matchingStringBase}`;
            this.matchingStringArray[1] = `${matchingStringBase}.`;
            this.matchingStringArray[2] = `${matchingStringBase}..`;
            this.matchingStringArray[3] = `${matchingStringBase}...`;
        }

        private bindEvent() {
            this.btnRules.clickHandler = new Laya.Handler(this, this.onBtnRuleClick)
            this.btnMatch.clickHandler = new Laya.Handler(this, this.onBtnMatchClick);
            this.btnStopMatch.clickHandler = new Laya.Handler(this, this.onBtnStopMatchClick);
            //当大厅触发重连时，结束匹配并关闭页面
            game.LobbyNetMgr.Inst.add_connect_listener(['OnReconnectStarted', 'OnChangeMainRouteBegin'], this, () => {
                if (this.enable) {
                    this.closeMatchingState();
                    this.hide();
                }
            });
        }

        public show() {
            super.show(20000100);
        }

        public hide() {
            //如果在匹配中，取消匹配后再关闭页面
            if (this._isMatching) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3199), Laya.Handler.create(this, () => {
                    this.stopMatch(new Laya.Handler(this, () => {
                        this.hide();
                    }));
                }));
                return;
            }
            super.hide();
        }

        public onEnable() {
            this._isMatching = false;
            this.matchingInfo.visible = false;
            this.btnMatch.visible = true;
        }

        public onDisable(): void {
            this.closeMatchingState();
        }


        //匹配中... 的动画
        private startMatchingTextAnim() {
            this.textAnimStartTime = Laya.timer.currTimer;
            this.txtMatching.text = this.matchingStringArray[0];
            //每隔800ms播放一次动画
            Laya.timer.loop(this.textAnimSpace, this, this.matchingTextAnim);
        }

        private stopMatchingTextAnim() {
            Laya.timer.clear(this, this.matchingTextAnim);
        }

        private matchingTextAnim() {
            //当前时间差
            let timeSpace: number = Laya.timer.currTimer - this.textAnimStartTime;
            //如果时间差/800%3的值为0，则没有.,1则为1个点，以此类推
            let dotCount: number = timeSpace / 800 % 4;
            dotCount = Math.floor(dotCount);
            this.txtMatching.text = this.matchingStringArray[dotCount];
        }


        private onBtnRuleClick() {
            if (this.locking) {
                return;
            }
            uiscript.UI_Info_Big.Inst.show(game.Tools.strOfLocalization(4507));
        }

        private onBtnMatchClick() {
            if (this.locking) {
                return;
            }
            if (!this._isMatching) {
                //显示匹配中
                this.matchingInfo.visible = true;
                this.startMatchingTextAnim();
                this.startMatch();
            }
        }

        private onBtnStopMatchClick() {
            if (this.locking) {
                return;
            }
            if (this._isMatching) {
                this.stopMatch();

            }
        }

        private startMatch() {
            this._isMatching = true;
            //向服务器发送请求开始魂之一击
            let serverName: string = common.ProtoHelper.getServer(ServerType.LOBBY);
            let codeName: string = common.ProtoHelper.getCode(ProtoCode.MATCH_UNIFIED);
            view.AudioMgr.PlayAudio(10178);
            let effectShow = game.FrontEffect.Inst.create_ui_effect(this.btnMatch, 'scene/effect_imas_match.lh', new Laya.Point(0, -8), 1);
            Laya.timer.once(1000, effectShow, () => {
                effectShow.destory();
            });
            this.locking = true;
            app.NetAgent.sendReq2Lobby(serverName, codeName, {
                match_sid: this.matchId,
                client_version_string: GameMgr.Inst.getClientVersion()
            }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(codeName, err, res);
                    this.closeMatchingState();
                }
            });
        }

        private stopMatch(onStopSuccess?: Laya.Handler) {
            if (this._isMatching) {
                let serverName: string = common.ProtoHelper.getServer(ServerType.LOBBY);
                let codeName: string = common.ProtoHelper.getCode(ProtoCode.STOPMATCH_UNIFIED);
                this.locking = true;
                //向服务器发送取消魂之一击
                app.NetAgent.sendReq2Lobby(serverName, codeName, {
                    match_sid: this.matchId
                }, (err, res) => {
                    this.locking = false;
                    if (err || (res['error'] && res['error'] != 1302)) {
                        UIMgr.Inst.showNetReqError(codeName, err, res);
                    } else {
                        this.closeMatchingState();
                        onStopSuccess?.run();
                    }
                });
            }
        }

        private closeMatchingState() {
            this._isMatching = false;
            this.stopMatchingTextAnim();
            this.matchingInfo.visible = false;
        }
    }
}