module uiscript {
    export class UI_Activity_Imas_Reward extends UI_Activity_Imas_Page {
        public static activityId: number = 241105;
        public static ptId: number = 30900079;
        public static Inst: UI_Activity_Imas_Reward;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static getUnLockStateByTaskId(taskId: number) {
            let _info = UI_Activity.getPeriodTaskInfo(taskId);
            if (_info && _info['achieved'] && !_info['rewarded']) {
                let d_task = cfg.activity.period_task.get(_info['id']);
                let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                if (d_task && d_task.reward_limit_day <= delta) {
                    return true;
                }
            }
            return false;
        }
        private txtCountPt: Laya.Label;
        private comBtns: Laya.Sprite;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [20041, 20042, 20043];
        private tabButtons: Array<ImasTabButton>;
        private btnGetAll: Laya.Button;
        private btnGetAllTitle: Laya.Label;
        private btnGetAllIcon: Laya.Image;
        private itemRect: UIRect = null;
        private rewardItemRect: UIRect = null;
        public lineParent: Laya.Sprite;
        private lineTemplete: Laya.Sprite;
        private refreshPtHandler: Laya.Handler;

        /**
         * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
         */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;

        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_rewardUI());
            UI_Activity_Imas_Reward.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            let freshInfoContain = this.root.getChildByName("fresh_info") as Laya.Sprite;
            this.txtCountPt = freshInfoContain.getChildByName("count") as Laya.Label;
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.listScrollBar = list.getChildByName("scrollbar") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_get_all") as Laya.Button;
            this.btnGetAllTitle = this.btnGetAll.getChildByName("title") as Laya.Label;
            this.btnGetAllIcon = this.btnGetAll.getChildByName("icon") as Laya.Image;

            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender), 200);
            this.lineParent = this.listContainer.getChildByName('line_parent') as Laya.Sprite;
            this.lineTemplete = this.lineParent.getChildAt(0) as Laya.Sprite;

            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_rewardUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_rewardUI).hide;
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            this.initTabs();
            this.btnGetAllTitle.text = game.Tools.strOfLocalization(3878);
            (this.comEmpty.getChildAt(0) as Laya.Label).text = game.Tools.strOfLocalization(4005);
            this.refreshPtHandler = new Laya.Handler(this, this.refreshPt);
            this.lineTemplete.y = -200 + 1;
            this.lineTemplete.x = 42;
            this.lineTemplete.scaleX = -1;
            (this.lineTemplete as Laya.Image).skin = '';
        }

        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList() {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.lineParent.visible = this.tabGroups.selectedIndex == 0;
            if (this.lineParent.visible) {
                let i = 0;
                if (data.length > 0) {
                    let _info: game.ITaskProgress = data[0];
                    let configData = cfg.activity.period_task.get(_info.id);
                    let isUnlock = this.isTaskUnlock(_info);
                    let imgState = this.lineParent.getChildAt(0).getChildAt(0) as Laya.Image;
                    if (_info.achieved && isUnlock) {
                        imgState.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_reward_progress_bar_small_reward_completed'
                            : 'myres/activity_2411imas/pop_up_reward_progress_bar_reward_completed') + '.png';
                    } else {
                        imgState.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_reward_progress_bar_small_reward'
                            : 'myres/activity_2411imas/pop_up_reward_progress_bar_reward') + '.png';
                    }
                }
                for (; i < data.length - 1; i++) {
                    if (this.lineParent.numChildren <= i + 1) {
                        let _line: Laya.Sprite = this.lineTemplete.scriptMap['capsui.UICopy']['getNodeClone']();
                        this.lineParent.addChild(_line);
                        _line.y = i % 2 == 0 ? 200 * i : 200 * i + 1;
                        _line.x = i % 2 == 0 ? 50 : 42;
                        _line.scaleX = i % 2 == 0 ? 1 : -1;
                        _line.visible = true;
                    }
                    let _info: game.ITaskProgress = data[i + 1];
                    let configData = cfg.activity.period_task.get(_info.id);
                    let isUnlock = this.isTaskUnlock(_info);
                    (this.lineParent.getChildAt(i + 1) as Laya.Image).skin = game.Tools.localUISrc((_info.achieved && isUnlock) ? 'myres/activity_2411imas/pop_up_reward_progress_bar.png' : 'myres/activity_2411imas/pop_up_reward_progress.png');
                    let imgState = this.lineParent.getChildAt(i + 1).getChildAt(0) as Laya.Image;
                    if (_info.achieved && isUnlock) {
                        imgState.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_reward_progress_bar_small_reward_completed'
                            : 'myres/activity_2411imas/pop_up_reward_progress_bar_reward_completed') + '.png';
                    } else {
                        imgState.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_reward_progress_bar_small_reward'
                            : 'myres/activity_2411imas/pop_up_reward_progress_bar_reward') + '.png';
                    }
                }
                for (; i < this.lineParent.numChildren - 1; i++) {
                    (this.lineParent.getChildAt(i + 1) as Laya.Sprite).visible = false;
                }
                this.refreshProgress();
            }
            this.freshGetAllBtn();
        }

        private refreshProgress() {
            let max = -1;
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            for (let i = 0; i < data.length; i++) {
                if (data[i]['achieved'] && !data[i]['rewarded']) {
                    max = i;
                    break;
                }
                if (!data[i]['achieved']) {
                    if (max < 0) {
                        max = i - 1;
                    }
                    this.scrollView.rate = Math.min(1, max / (data.length - 3));
                    return;
                }
            }
            if (max < 0) {
                this.scrollView.rate = 1;
            } else {
                this.scrollView.rate = Math.min(1, max / (data.length - 3));
            }
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base(this, () => { return this.locking; });
            this.tabButtons = new Array<ImasTabButton>();
            let tabsName = ['all', 'achieved', 'doing'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                this.tabGroups.AddTabButton(btn);
                let tabButton = new ImasTabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.freshList();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        public show() {
            super.show(20000102);
        }

        public hide() {
            super.hide();
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Reward', false);
            UI_Bag.remove_item_listener(UI_Activity_Imas_Main.ptId, this.refreshPtHandler);
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Reward', true);
            UI_Bag.add_item_listener(UI_Activity_Imas_Main.ptId, this.refreshPtHandler);
            this.refreshPt();
            this.freshData();
            this.tabGroups.init();
            let difference = 0;
            for (let i = 0; i < this.sortServerData[1].length; i++) {
                let data = this.sortServerData[1][i];
                let configData = cfg.activity.period_task.get(data.id);
                if (configData.node_mark == 1 && !data.achieved && this.isTaskUnlock(data)) {
                    let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
                    let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
                    let nowProgress = data.counter || 0;
                    difference = baseTaskConfigData.target - nowProgress;
                    break;
                }
            }
            this.locking = true;
            Laya.timer.once(200, this, () => {
                this.locking = false;
            });
        }

        // private doLstAnim() { //什么屎代码
        //     this.locking = true;
        //     Laya.Tween.clearAll(this.btnGetAll);
        //     this.btnGetAll.alpha = 0;
        //     let list = this.scrollView;
        //     list.me.mouseEnabled = false;
        //     let animOrder = [];
        //     for (let i = 0; i < list._content.getChildAt(2)._childs.length; i++) {
        //         animOrder.push(i);
        //     }
        //     animOrder.sort((a, b) => {
        //         return (list._content.getChildAt(2).getChildAt(a) as Laya.Sprite).y - (list._content.getChildAt(2).getChildAt(b) as Laya.Sprite).y;
        //     })
        //     list.me.alpha = 1;
        //     for (let i = 0; i < animOrder.length; i++) {
        //         let com = list._content.getChildAt(2).getChildAt(animOrder[i]) as Laya.Sprite;
        //         let targetY = com.y;
        //         com.alpha = 0;
        //         com.y = targetY + 90;
        //         Laya.Tween.to(com, { alpha: 1, y: targetY }, 250, Laya.Ease.quadInOut, null, 67 * i);
        //     }
        //     let lstDelay = (animOrder.length - 1) * 67 + 250;
        //     view.AudioMgr.PlayAudio(10131);
        //     let btnDelay = Math.min(400, Math.min(this.scrollView.items.length, 4) * 67);
        //     Laya.Tween.to(this.btnGetAll, { alpha: 1 }, 167, Laya.Ease.quadInOut, null, btnDelay);
        //     Laya.timer.once(lstDelay, this, () => {
        //         list.me.mouseEnabled = true;
        //         this.locking = false;
        //     });
        //     this.lineParent.alpha = 0;
        //     Laya.Tween.to(this.lineParent, { alpha: 1 }, 167, Laya.Ease.quadInOut);
        // }

        private refreshPt() {
            this.txtCountPt.text = UI_Bag.get_item_count(UI_Activity_Imas_Main.ptId).toString();
        }

        //刷新列表数据
        private freshData() {
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_Imas_Reward.activityId);
            // app.Log.log(`UI_Activity_Imas_Reward的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return a.id - b.id;
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            achieved = achieved.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(achieved);
            this.freshGetAllBtn();
        }


        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                weight = -10000; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let isShort = this.tabGroups.selectedIndex == 0;
            let bgIndex = isShort ? '2' : '';
            let comName1 = isShort ? 'short' : 'long';
            let comName2 = isShort ? 'long' : 'short';
            let container: Laya.Sprite = obj.container.getChildByName(comName1) as Laya.Sprite;
            container.visible = true;
            (obj.container.getChildByName(comName2) as Laya.Sprite).visible = false;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let imgBg = container.getChildByName("bg") as Laya.Image;
            let itemParent = container.getChildByName("item") as Laya.Sprite;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let txtDesc = unLockParent.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('getted') as Laya.Image;
            let btnReceive = unLockParent.getChildByName("btn_get") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;
            let txtLockedTime = lockedParent.getChildByName('locked_time') as Laya.Label;
            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;

            //判断是否是大奖
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            imgBg.y = configData.node_mark == 0 ? 92 : 88;
            if (configData.node_mark == 0 || isShort) {
                imgBg.scale(1, 1);
            } else {
                imgBg.scale(1.008, 1.008);
            }

            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = serverData.achieved && !serverData.rewarded;
                txtProgress.visible = !serverData.achieved;
                imgGetted.visible = serverData.achieved && serverData.rewarded;
                (itemParent.getChildByName("grey") as Laya.Image).visible = false;
                imgBg.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_normal'
                    : 'myres/activity_2411imas/pop_up_special') + bgIndex + '.png';
                if (!serverData.achieved) {
                    let progress: number = serverData.counter || 0;
                    txtProgress.text = game.Tools.strOfLocalization(4253) + '\n' + `${progress}/${baseTaskConfigData.target}`;
                }
                else {
                    if (!serverData.rewarded) {
                        //已完成未领取
                        (btnReceive.getChildByName("title") as Laya.Label).text = game.Tools.strOfLocalization(4251);
                        //领取的点击事件
                        btnReceive.clickHandler = new Laya.Handler(this, () => {
                            if (this.locking) return;
                            this.locking = true;
                            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                                this.locking = false;
                                if (err || res['error']) {
                                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                                } else {
                                    UI_Activity.onPeriodTaskRewarded(serverData.id);
                                    game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                    this.freshData();
                                    this.scrollView.wantToRefreshAll();
                                }
                            });
                        }, null, false);
                    }
                    else {
                        //已完成已领取
                    }
                }
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Imas_Reward.activityId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText1(restSeconds);
                //已完成已领取
                imgBg.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_normal_grey'
                    : 'myres/activity_2411imas/pop_up_special_grey') + bgIndex + '.png';
                //已完成已领取
                (itemParent.getChildByName("grey") as Laya.Image).visible = true;
            }

            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("icon") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                let btnItemDetail = itemParent.getChildByName("btn") as Laya.Button;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_Imas_Reward", true);
                txtCount.text = 'x' + rewardCount.toString();
                btnItemDetail.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })
            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(task.id);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Reward.activityId);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAllTitle.color = shouldSetGray ? '#ffffff' : '#712c17';
            this.btnGetAllIcon.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_2411imas/button_dark.png' : 'myres/activity_2411imas/button_light.png');
            this.btnGetAll.mouseEnabled = !shouldSetGray;
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let lst = this.sortServerData[currentSelectIndex];
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Reward.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        needGetList.push(data['id']);
                    } else {
                        break;
                    }
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.freshData();
                    this.scrollView.wantToRefreshAll();
                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }

    }
}