module uiscript {
    class CellSpot {
        private imgBg: Laya.Image;
        private txtTitle: Laya.Label;
        private index: number;
        private imgRedPoint: Laya.Sprite;
        private btnPlay: Laya.Button;
        private txtLock: Laya.Label;
        private spotData: lqc.Sheet_Activity_StoryActivity;
        private locking: boolean;

        public constructor(me: Laya.Sprite, index: number) {
            this.imgBg = me.getChildByName('bg') as Laya.Image;
            this.txtLock = me.getChildByName('time') as Laya.Label;
            this.txtTitle = me.getChildByName('title') as Laya.Label;
            this.index = index;
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_Imas_Spot.activityId);
            this.spotData = datas[index];
            if (index == 0 && GameMgr.client_language == 'jp') {
                this.txtTitle.width = 240;
            }
            if (index == 1 && GameMgr.client_language == 'en') {
                this.txtTitle.width = 210;
            }
            this.txtTitle.text = game.Tools.eventStrOfLocalization(this.spotData.title);
            this.imgRedPoint = me.getChildByName('redpoint') as Laya.Sprite;
            this.btnPlay = me.getChildByName('play') as Laya.Button;
            this.btnPlay.clickHandler = Laya.Handler.create(this, () => {
                if (this.txtLock.visible) return;
                if (this.locking) return;
                let serverUnlockData = game.ActivityStoryDataHelper.getStoryData(UI_Activity_Imas_Spot.activityId, this.spotData.story_id);
                if (!serverUnlockData) {
                    this.locking = true;
                    let req: game.IReqStoryActivityUnlock = {
                        activity_id: UI_Activity_Imas_Spot.activityId,
                        story_id: this.spotData.story_id
                    };
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.storyActivityUnlock, req, (err, res: game.IResCommon) => {
                        this.locking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.storyActivityUnlock, err, res);
                        } else {
                            this.showSpot();
                        }
                    });
                } else {
                    this.showSpot();
                }
            }, null, false);
        }

        public setRedPoint(visible: boolean) {
            this.imgRedPoint.visible = visible;
        }

        public get isLocked(): boolean {
            return this.txtLock.visible;
        }

        public show() {
            // TODO 判定是否解锁，时间判定
            let locked = false;
            if (this.spotData.unlock_day) {
                let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_Imas_Spot.activityId);
                let restSeconds = this.spotData.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                if (restSeconds > 0) {
                    locked = true;
                }
            }
            this.btnPlay.visible = !locked;
            this.txtTitle.visible = !locked;
            if (locked) {
                this.txtLock.visible = true;
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Imas_Spot.activityId, this.spotData.unlock_day);
                this.txtLock.text = game.Tools.getLockTimeText1(restSeconds);
                this.imgBg.skin = game.Tools.localUISrc('myres/activity_2411imas/spot/spot' + (this.index + 1) + '_locked.png');
            } else {
                this.txtLock.visible = false;
                this.imgBg.skin = game.Tools.localUISrc('myres/activity_2411imas/spot/spot' + (this.index + 1) + '.png');
            }
        }

        private showSpot() {
            GameMgr.Inst.showSpotByEvent(this.spotData.content_path, this.spotData.story_id, null, UI_Activity_Imas_Spot.activityId, Laya.Handler.create(this, () => {
                UI_Activity_Imas_Main.Inst.enable = false;
                view.AudioMgr.StopMusic(0);
                game.Scene_Lobby.Inst.setBackHandler(Laya.Handler.create(this, () => {
                    UI_Activity_Imas_Main.Inst.enable = true;
                    UI_Activity_Imas_Spot.Inst.show();
                    if (!UI_Activity.activities[UI_Activity_Imas_Main.activityId]) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            UI_Activity_Imas_Main.Inst.hide();
                        }))
                    }
                }));
            }, null, false));
        }
    }

    export class UI_Activity_Imas_Spot extends UI_Activity_Imas_Page {
        public static activityId: number = 241107;
        public static Inst: UI_Activity_Imas_Spot;
        public static haveRedPoint(): boolean {
            let showIndex = Math.max(1, Number(Laya.LocalStorage.getItem(game.Tools.eeesss('imas_spot' + GameMgr.Inst.account_id))));
            for (let i = 0; i < 4; i++) {
                let datas = cfg.activity.story_activity.getGroup(UI_Activity_Imas_Spot.activityId);
                let spotData = datas[i];
                if (spotData && spotData.unlock_day) {
                    let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_Imas_Spot.activityId);
                    let restSeconds = spotData.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                    if (restSeconds <= 0 && i != 0 && showIndex <= i) {
                        return true;
                    }
                }
            }
            return false;
        }

        private cells: Array<CellSpot> = [];
        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_spotUI());
            UI_Activity_Imas_Spot.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            for (let i = 0; i < 4; i++) {
                this.cells.push(new CellSpot(this.root.getChildByName('spots').getChildByName('' + i) as Laya.Sprite, i));
            }
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_spotUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_spotUI).hide;
            this.setTitle(game.Tools.strOfLocalization(4512));
        }

        public show() {
            super.show(20000103);
            let index = 0;
            let have_lock = false;
            let show_index = Math.max(1, Number(Laya.LocalStorage.getItem(game.Tools.eeesss('imas_spot' + GameMgr.Inst.account_id))));
            for (let cell of this.cells) {
                cell.show();
                cell.setRedPoint(index != 0 && show_index <= index && !cell.isLocked);
                if (!have_lock) {
                    if (cell.isLocked) {
                        have_lock = true;
                        Laya.LocalStorage.setItem(game.Tools.eeesss('imas_spot' + GameMgr.Inst.account_id), '' + index);
                    } else if (index == 2) {
                        Laya.LocalStorage.setItem(game.Tools.eeesss('imas_spot' + GameMgr.Inst.account_id), '' + 4);
                    }
                }
                index++;
            }
        }

        public hide() {
            super.hide();
        }

        public onDisable(): void {
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_24011imas/spot.atlas'));
        }

    }
}