module uiscript {
    export class ImasTabButton {
        private me: Laya.Button;
        private selectImg: Laya.Image;
        private diselectImg: Laya.Image;
        private title: Laya.Label;
        constructor(me: Laya.Button) {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.diselectImg = this.me.getChildByName("diselect") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
        }
        public onSelect() {
            this.selectImg.visible = true;
            this.diselectImg.visible = false;
            this.title.color = '#1e2a63';
        }
        public onDeselect() {
            this.selectImg.visible = false;
            this.diselectImg.visible = true;
            this.title.color = '#b2bcd5';
        }
    }

    export class UI_Activity_Imas_Task extends UI_Activity_Imas_Page {
        public static activityId: number = 241104;
        public static Inst: UI_Activity_Imas_Task;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        if (d_task && this.getUnLockStateByTaskId(d_task.id)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static getUnLockStateByTaskId(taskId: number) {
            let taskConfig = cfg.activity.period_task.get(taskId);
            let timeString = taskConfig.accessible_days;
            let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Task.activityId);
            if (timeArray.length >= 2) {
                let minTime = timeArray[0];
                let maxTime = timeArray[1];
                if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                    return false;
                }
            }
            return true;
        }
        private freshInfo: Laya.Label;
        private freshInfoBg: Laya.Image;
        private freshInfoIcon: Laya.Image;
        private comBtns: Laya.Sprite;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [3668, 3670, 3669];
        private tabButtons: Array<ImasTabButton>;
        private btnGetAll: Laya.Button;
        private btnGetAllTitle: Laya.Label;
        private btnGetAllIcon: Laya.Image;
        private itemRect: UIRect = null;
        private rewardItemRect: UIRect = null;
        private freshInfoBgAdapter: common.SpriteAdapter;
        private freshInfoIconAdapter: common.SpriteAdapter;

        /**
         * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
         */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;

        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_taskUI());
            UI_Activity_Imas_Task.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            let freshInfoContain = this.root.getChildByName("fresh_info") as Laya.Sprite;
            this.freshInfo = freshInfoContain.getChildByName("time") as Laya.Label;
            this.freshInfoBg = freshInfoContain.getChildByName("bg") as Laya.Image;
            this.freshInfoIcon = freshInfoContain.getChildByName("icon") as Laya.Image;
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.listScrollBar = list.getChildByName("scrollbar") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_get_all") as Laya.Button;
            this.btnGetAllTitle = this.btnGetAll.getChildByName("title") as Laya.Label;
            this.btnGetAllIcon = this.btnGetAll.getChildByName("icon") as Laya.Image;

            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender), 200);
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_taskUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_taskUI).hide;
            this.initTabs();
            this.btnGetAllTitle.text = game.Tools.strOfLocalization(3878);
            (this.comEmpty.getChildAt(0) as Laya.Label).text = game.Tools.strOfLocalization(4005);
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            if (GameMgr.client_language == 'en') freshInfoContain.x = 916;
        }

        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList() {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base(this, () => { return this.locking; });
            this.tabButtons = new Array<ImasTabButton>();
            let tabsName = ['all', 'achieved', 'doing'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                this.tabGroups.AddTabButton(btn);
                let tabButton = new ImasTabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.freshList();
                    if (manualSwitching) this.doLstAnim();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        public show() {
            super.show(20000101);
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            list.me.alpha = 0;
            this.locking = true;
            Laya.Tween.clearAll(this.btnGetAll);
            this.btnGetAll.alpha = 0;
            Laya.timer.once(200, this, () => {
                this.doLstAnim();
            })
        }

        private doLstAnim() {
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            list.me.alpha = 1;
            this.locking = true;
            Laya.Tween.clearAll(this.btnGetAll);
            this.btnGetAll.alpha = 0;
            let tween_config = { delay: 67, duration: 250, ease: Laya.Ease.quadInOut };
            let start_config = { alpha: 0, y_dis: 90 };
            let target_config = { alpha: 1 };
            let lstDelay = game.Tools.listAnim(list, 4, tween_config, start_config, target_config);
            // view.AudioMgr.PlayAudio(10131);
            let btnDelay = Math.min(400, Math.min(this.scrollView.items.length, 4) * 67);
            Laya.Tween.to(this.btnGetAll, { alpha: 1 }, 167, Laya.Ease.quadInOut, null, btnDelay);
            Laya.timer.once(lstDelay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        public hide() {
            super.hide();
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Task', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Task', true);
            this.freshData();
            this.tabGroups.init();
            let difference = 0;
            for (let i = 0; i < this.sortServerData[1].length; i++) {
                let data = this.sortServerData[1][i];
                let configData = cfg.activity.period_task.get(data.id);
                if (configData.node_mark == 1 && !data.achieved && this.isTaskUnlock(data)) {
                    let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
                    let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
                    let nowProgress = data.counter || 0;
                    difference = baseTaskConfigData.target - nowProgress;
                    break;
                }
            }
        }

        //刷新列表数据
        private freshData() {
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_Imas_Task.activityId);
            // app.Log.log(`UI_Activity_Imas_Task的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //筛选应该显示的任务
            allTask = allTask.filter(task => {
                return this.isTaskUnlock(task);
            });
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);
            this.freshGetAllBtn();

            //获取本周内才能显示的任务，7天一刷新
            //当前活动进行了多少天
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Main.activityId);
            //显示刷新时间
            //一周的秒数-(当前时间-活动开始时间)%一周的秒数
            let weekSeconds = 7 * 24 * 60 * 60;
            let restTime = weekSeconds - UI_Activity.getActivityDeltaSeconds(UI_Activity_Imas_Main.activityId) % weekSeconds;
            this.freshInfo.text = UI_Activity_24ba.getFreshTimeText(restTime, activityDeltaDay >= 14);
            //使背景框和图标适配
            if (this.freshInfoBgAdapter === null || this.freshInfoBgAdapter === undefined) {
                this.freshInfoBgAdapter = new common.SpriteAdapter(this.freshInfoBg, this.freshInfo, SpriteAdapterType.WIDTH2WIDTH, -80);
            }
            this.freshInfoBgAdapter.fresh();
            if (this.freshInfoIconAdapter === null || this.freshInfoIconAdapter === undefined) {
                this.freshInfoIconAdapter = new common.SpriteAdapter(this.freshInfoIcon, this.freshInfo, SpriteAdapterType.LEFT2LEFT, 45);
            }
            this.freshInfoIconAdapter.fresh();
        }


        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                weight = -10000; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let imgBg = container.getChildByName("bg") as Laya.Image;
            let itemParent = container.getChildByName("item") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let txtDesc = unLockParent.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('getted') as Laya.Image;
            let btnReceive = unLockParent.getChildByName("btn_get") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;

            //判断是否是大奖
            imgBg.skin = game.Tools.localUISrc(configData.node_mark == 0 ? 'myres/activity_2411imas/pop_up_normal.png' : 'myres/activity_2411imas/pop_up_special.png');
            imgBg.y = configData.node_mark == 0 ? 91 : 87;
            if (configData.node_mark == 0) {
                imgBg.scale(1, 1);
            } else {
                imgBg.scale(1.008, 1.008);
            }
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            //赋值任务名称
            btnReceive.visible = serverData.achieved && !serverData.rewarded;
            txtProgress.visible = !serverData.achieved;
            imgGetted.visible = serverData.achieved && serverData.rewarded;
            (itemParent.getChildByName("grey") as Laya.Image).visible = false;

            if (!serverData.achieved) {
                let progress: number = serverData.counter || 0;
                txtProgress.text = game.Tools.strOfLocalization(4253) + '\n' + `${progress}/${baseTaskConfigData.target}`;
            }
            else {
                if (!serverData.rewarded) {
                    //已完成未领取
                    (btnReceive.getChildByName("title") as Laya.Label).text = game.Tools.strOfLocalization(4251);
                    //领取的点击事件
                    btnReceive.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) return;
                        this.locking = true;
                        app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            this.locking = false;
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                UI_Activity.onPeriodTaskRewarded(serverData.id);
                                game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                this.freshData();
                                this.scrollView.wantToRefreshAll();
                            }
                        });
                    }, null, false);
                }
                else {
                    //已完成已领取
                }
            }

            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("icon") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                let btnItemDetail = itemParent.getChildByName("btn") as Laya.Button;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_Imas_Task", true);
                txtCount.text = 'x' + rewardCount.toString();
                btnItemDetail.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })
            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            let taskConfig = cfg.activity.period_task.get(task.id);
            let timeString = taskConfig.accessible_days;
            let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Task.activityId);
            if (timeArray.length >= 2) {
                let minTime = timeArray[0];
                let maxTime = timeArray[1];
                if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                    return false;
                }
            }
            return true;
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAllTitle.color = shouldSetGray ? '#ffffff' : '#712c17';
            this.btnGetAllIcon.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_2411imas/button_dark.png' : 'myres/activity_2411imas/button_light.png');
            this.btnGetAll.mouseEnabled = !shouldSetGray;
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let lst = this.sortServerData[currentSelectIndex];
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Imas_Task.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.freshData();
                    this.scrollView.wantToRefreshAll();
                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }

    }
}