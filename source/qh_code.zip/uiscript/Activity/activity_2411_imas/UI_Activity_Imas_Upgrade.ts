module uiscript {
    class UI_ImasUpgradeCard {
        public me: Laya.Sprite;
        private father: UI_Activity_Imas_Upgrade;
        private imgBg: Laya.Image;
        private imgLevel: Laya.Image;
        private imgLevelAnim: Laya.Image;
        private txtTitle: Laya.Label;
        private txtDesc: Laya.HTMLDivElement;
        private btnUpgrade: Laya.Button;
        private txtMax: Laya.Label;
        private index: number;
        private buffId: number;
        private buffConfigs: lqc.Sheet_Activity_ActivityBuff[];
        private nextData: lqc.Sheet_Activity_ActivityBuff;
        private nowData: lqc.Sheet_Activity_ActivityBuff;
        private nowLevel: number;

        constructor(me: Laya.Sprite, father: UI_Activity_Imas_Upgrade, index: number) {
            this.me = me;
            this.father = father;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.imgLevel = this.me.getChildByName('level') as Laya.Image;
            this.imgLevelAnim = this.me.getChildByName('level_anim') as Laya.Image;
            this.txtTitle = this.me.getChildByName('title') as Laya.Label;
            this.txtDesc = this.me.getChildByName('desc') as Laya.HTMLDivElement;
            this.btnUpgrade = this.me.getChildByName('btn_upgrade') as Laya.Button;
            this.txtMax = this.me.getChildByName('max') as Laya.Label;
            this.index = index;
            this.buffId = UI_Activity_Imas_Upgrade.buffIds[index];
            this.buffConfigs = cfg.activity.activity_buff.getGroup(this.buffId);
            this.btnUpgrade.clickHandler = new Laya.Handler(this, this.onUpgradeBtnClick);
            if (GameMgr.client_language == 'jp') {
                this.txtDesc.style.font = '28px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtDesc.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtDesc.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtDesc.style.font = '28px SimHei';
            } else {
                this.txtDesc.style.font = '28px NotoSansKR';
            }
            this.txtDesc.style.color = '#1e2a63';
            this.txtDesc.style.leading = 6;
            this.txtDesc.style.letterSpacing = 0;
        }

        public refresh() {
            this.nowLevel = UI_Activity.getActivityBuffLevel(this.buffId);
            this.nowData = null;
            this.nextData = null;
            for (let data of this.buffConfigs) {
                if (data.buff_level == this.nowLevel) {
                    this.nowData = data;
                }
                if (data.buff_level == this.nowLevel + 1) {
                    this.nextData = data;
                    break;
                }
            }
            this.imgLevelAnim.skin = game.Tools.localUISrc('myres/activity_2411imas/number/upgrade_' + this.nowLevel + '.png');
            this.father.levelUpAnims[this.index].gotoAndStop(0);
            let originPercent = this.nowData ? (this.nowData.effect - 100) : 0;
            let finalPercent = this.nextData ? (this.nextData.effect - 100) : 0;
            if (GameMgr.client_language == 'en' && this.index == 1) {
                this.txtDesc.width = this.nextData ? 325 : 315;
                this.txtDesc.x = this.nextData ? 0 : 5;
            }
            if (this.nextData) {
                this.txtDesc.innerHTML = game.Tools.ParseText(game.Tools.eventStrOfLocalization(this.buffConfigs[0].effect_desc, [originPercent.toString(), finalPercent.toString()]), '#ff52e5');
            } else {
                this.txtDesc.innerHTML = game.Tools.ParseText(game.Tools.strOfLocalization(UI_Activity_Imas_Upgrade.buffMaxStrIds[this.index], [originPercent.toString()]), '#ff52e5');
            }
            this.txtTitle.text = game.Tools.eventStrOfLocalization(this.buffConfigs[0].effect_desc_2);
            this.txtDesc.y = 661 - this.txtDesc.contextHeight;
            this.refreshState();
        }

        public refreshState() {
            const currencyCount = UI_Bag.get_item_count(UI_Activity_Imas_Main.currencyId);
            let isMax = false;
            let canUpgrade = false;
            if (!this.nextData) isMax = true;
            if (this.nextData && this.nextData.upgrade_resource_count <= currencyCount) canUpgrade = true;
            this.txtMax.visible = isMax;
            this.btnUpgrade.visible = !isMax;
            this.btnUpgrade.mouseEnabled = canUpgrade;
            (this.btnUpgrade.getChildByName('can_get') as Laya.Image).visible = canUpgrade;
            (this.btnUpgrade.getChildByName('cannot_get') as Laya.Image).visible = !canUpgrade;
            (this.btnUpgrade.getChildByName('title') as Laya.Label).color = canUpgrade ? '#712c17' : '#ffffff';
            (this.btnUpgrade.getChildByName('count') as Laya.Label).color = canUpgrade ? '#712c17' : '#ff52e5';
            if (!isMax) (this.btnUpgrade.getChildByName('count') as Laya.Label).text = this.nextData.upgrade_resource_count.toString();
            this.imgBg.skin = isMax ? game.Tools.localUISrc('myres/activity_2411imas/upgrade_bottom_plate_1.png') : game.Tools.localUISrc('myres/activity_2411imas/upgrade_bottom_plate.png');
        }

        // 升级按钮点击
        public onUpgradeBtnClick() {
            if (this.father.locking) return;
            if (UI_Bag.get_item_count(UI_Activity_Imas_Main.currencyId) < this.nextData.upgrade_resource_count) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4242));
                return;
            }
            this.father.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'upgradeActivityBuff', { buff_id: this.buffId }, (err, res) => {
                this.father.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('upgradeActivityBuff', err, res);
                } else {
                    UI_Activity.upgradeActivityBuff(this.buffId);
                    this.refresh();
                    this.imgLevelAnim.skin = game.Tools.localUISrc('myres/activity_2411imas/number/upgrade_' + (this.nowLevel - 1) + '.png');
                    this.imgLevel.skin = game.Tools.localUISrc('myres/activity_2411imas/number/upgrade_' + this.nowLevel + '.png');
                    this.father.playLevelUpAnim(this.index);
                }
            });
        }
    }
    export class UI_Activity_Imas_Upgrade extends UIBase {
        public static Inst: UI_Activity_Imas_Upgrade;
        public static activityId: 241103;
        public static buffIds: number[] = [24110301, 24110302, 24110303];
        public static buffMaxStrIds: number[] = [4515, 4516, 4517];

        public static haveRedPoint(): boolean {
            let count = UI_Bag.get_item_count(UI_Activity_Imas_Main.currencyId);
            for (let buffId of this.buffIds) {
                let level = UI_Activity.getActivityBuffLevel(buffId);
                let nextData: lqc.Sheet_Activity_ActivityBuff;
                let buffDatas = cfg.activity.activity_buff.getGroup(buffId);
                for (let data of buffDatas) {
                    if (data.buff_level == level + 1) {
                        nextData = data;
                        break;
                    }
                }
                if (!nextData) continue;
                if (nextData.upgrade_resource_count <= count) return true;
            }
            return false;
        }

        constructor() {
            super(new ui.lobby.activity_2411imas.activity_24imas_upgradeUI());
            UI_Activity_Imas_Upgrade.Inst = this;
        }

        private imgBg: Laya.Image;
        private cards: UI_ImasUpgradeCard[];
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        public levelUpAnims: Laya.FrameAnimation[];
        private iconAnims: Laya.FrameAnimation[];
        public locking: boolean;
        private refreshHandler: Laya.Handler;
        private titleAdapter1: common.SpriteAdapter;
        private titleAdapter2: common.SpriteAdapter;

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.cards = [];
            this.levelUpAnims = [];
            this.iconAnims = [];
            for (let i = 1; i <= UI_Activity_Imas_Upgrade.buffIds.length; i++) {
                this.cards.push(new UI_ImasUpgradeCard(this.me.getChildByName('com' + i) as Laya.Sprite, this, i - 1));
                this.levelUpAnims.push((this.me as ui.lobby.activity_2411imas.activity_24imas_upgradeUI)['levelup' + i]);
                this.iconAnims.push((this.me as ui.lobby.activity_2411imas.activity_24imas_upgradeUI)['icon' + i]);
            }
            this.aniShow = (this.me as ui.lobby.activity_2411imas.activity_24imas_upgradeUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2411imas.activity_24imas_upgradeUI).hide;
            game.LoadMgr.setImgSkin(this.imgBg, 'myres/activity_2411imas/bg2.jpg', null, 'UI_Activity_Imas_Upgrade');
            this.refreshHandler = new Laya.Handler(this, () => {
                this.cards.forEach((card) => {
                    card.refreshState();
                });
            });
            let title = this.me.getChildByName('top').getChildByName('title') as Laya.Image;
            let star1 = this.me.getChildByName('top').getChildByName('star1') as Laya.Image;
            let star2 = this.me.getChildByName('top').getChildByName('star2') as Laya.Image;
            //使标题和星星适配
            if (this.titleAdapter1 === null || this.titleAdapter1 === undefined) {
                this.titleAdapter1 = new common.SpriteAdapter(star1, title, SpriteAdapterType.LEFT2LEFT, 72);
            }
            this.titleAdapter1.fresh();
            if (this.titleAdapter2 === null || this.titleAdapter2 === undefined) {
                this.titleAdapter2 = new common.SpriteAdapter(star2, title, SpriteAdapterType.RIGHT2RIGHT, -72);
            }
            this.titleAdapter2.fresh();
        }

        playLevelUpAnim(index: number) {
            this.locking = true;
            view.AudioMgr.PlayAudio(10179);
            this.levelUpAnims[index].play(0, false);
            this.iconAnims[index].play(0, false);
            let effectUpgrade = game.FrontEffect.Inst.create_ui_effect(this.cards[index].me, 'scene/effect_imas_upgrade.lh', new Laya.Point(150, 330), 1);
            Laya.timer.once(1000, effectUpgrade, () => {
                this.locking = false;
                effectUpgrade.destory();
            });
        }

        public show() {
            this.enable = true;
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.locking = false;
            });
            UI_Activity_Imas_Main.Inst.showSubpageBg(0, true);
        }

        public hide() {
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.enable = false;
                this.locking = false;
            })
            UI_Activity_Imas_Main.Inst.hideSubpageBg();
            UI_Activity_Imas_Main.Inst.refreshRedPoint();
        }

        public onEnable(): void {
            this.cards.forEach((card) => {
                card.refresh();
            });
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Upgrade', true);
            UI_Bag.add_item_listener(UI_Activity_Imas_Main.currencyId, this.refreshHandler);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Imas_Upgrade', false);
            UI_Bag.remove_item_listener(UI_Activity_Imas_Main.currencyId, this.refreshHandler);
        }
    }
}