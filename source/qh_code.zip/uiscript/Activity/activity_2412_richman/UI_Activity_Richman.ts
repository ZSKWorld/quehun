/**
* name 
*/
module uiscript {

    interface iBuffData {
        type: number;
        remain: number;
        effect: number;
    }

    interface iActivityRichmanData {
        activity_id: number;
        location: number;
        finished_count: number;
        chest_position: number;
        bank_save: number;
        exp: number;
        buff: Array<iBuffData>;
    }

    class ChooseDiceRed {
        public me: Laya.Sprite;

        private locking: boolean;
        private complete: Laya.Handler;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close(0);
            });
            for (let i: number = 0; i < 6; i++) {
                (this.me.getChildByName(`d${i + 1}`) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    this.close(i + 1);
                });
            }
        }

        public show(complete: Laya.Handler) {
            this.me.visible = true;
            this.locking = true;
            this.complete = complete;
            UIBase.anim_pop_out(this.me, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            UI_Activity_Richman.Inst.black_mask.show();
        }

        private close(step: number) {
            this.locking = true;
            UIBase.anim_pop_hide(this.me, Laya.Handler.create(this, () => {
                this.me.visible = false;
                this.locking = false;
                if (this.complete) this.complete.runWith(step);
            }));
            UI_Activity_Richman.Inst.black_mask.close();
        }
    }

    class BlackMask {
        public me: Laya.Sprite;

        public constructor(me: Laya.Sprite) {
            this.me = me;
        }

        public show() {
            this.me.visible = true;
            this.me.alpha = 0;
            Laya.Tween.to(this.me, { alpha: 0.5 }, 150);
        }

        public close() {
            Laya.Tween.to(this.me, { alpha: 0 }, 150, null, Laya.Handler.create(this, () => {
                this.me.visible = false;
            }));
        }
    }

    class TurnTable {
        public me: Laya.Sprite;
        private table: Laya.Sprite;
        private btn_click: Laya.Button;
        private locking: boolean;
        private target_rotation: number;
        private state: number = 0; // 0=等待转动，1=正在转动,2=转动停止等待退出
        private complete: Laya.Handler;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.table = this.me.getChildByName('table') as Laya.Sprite;
        }

        public show(target_rotation: number, complete: Laya.Handler) {
            this.target_rotation = target_rotation;
            this.complete = complete;
            this.locking = true;
            this.me.visible = true;
            this.state = 0;
            UI_Overall.Inst.show(Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (this.state == 0) this.runAnim();
                else if (this.state == 2) this.close();
            }, null, false));
            UI_Activity_Richman.Inst.black_mask.show();
            UIBase.anim_pop_out(this.me, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.table.rotation = 0;
        }

        private runAnim() {
            this.state = 1;
            let t1: number = 1;
            let t2: number = 5;
            let total_s: number = 7 * 360 + this.target_rotation;
            let v: number = 2 * total_s / (t1 + t2);
            let start_time: number = Laya.timer.currTimer;
            Laya.timer.frameLoop(1, this, () => {
                let t: number = (Laya.timer.currTimer - start_time) / 1000;

                let rot: number = 0;
                if (t < t1) {
                    rot = 0.5 * t * t * v;
                } else if (t < t1 + t2) {
                    rot = total_s - (t1 + t2 - t) / t2 * v * (t1 + t2 - t) / 2;
                } else {
                    this.state = 2;
                    Laya.timer.clearAll(this);
                    rot = total_s;
                }
                this.table.rotation = rot;
            });
        }

        public close() {
            this.locking = true;
            UI_Activity_Richman.Inst.black_mask.close();
            UIBase.anim_pop_hide(this.me, Laya.Handler.create(this, () => {
                this.me.visible = false;
                this.locking = false;
                UI_Overall.Inst.close();
                if (this.complete) this.complete.run();
            }));
        }
    }

    class RewardPage {
        public me: Laya.Sprite;
        private root: Laya.Sprite;
        private label_count: Laya.Label;
        private label_info: Laya.Label;
        private item: UI_Item_Skin;
        private locking: boolean;
        private complete: Laya.Handler;
        private itemSkin: Laya.Image;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.label_count = this.root.getChildByName('count') as Laya.Label;
            this.label_info = this.root.getChildByName('info') as Laya.Label;
            this.item = new UI_Item_Skin(this.root.getChildByName('item').getChildByName('icon') as Laya.Sprite, 'UI_Activity_Richman');
            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.itemSkin = this.root.getChildByName('item').getChildByName('icon') as Laya.Image;
        }

        public show(id: number, count: number, info: string, complete: Laya.Handler) {
            let itemskin = game.GameUtility.get_item_view_new(id);
            //如果是货币则换用jpg图片
            this.item.setSkin(itemskin.icon);
           
            this.label_count.text = itemskin.name + 'x' + count;
            this.label_info.text = info;
            this.locking = true;
            this.me.visible = true;
            this.complete = complete;
            UI_Activity_Richman.Inst.black_mask.show();
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            let h: number = this.label_info.textField.textHeight;
            this.root.height = 300 + h;
        }

        /**
         * 
         * @param id buff类型
         * @param complete 
         */
        public showBuff(id: number, complete: Laya.Handler) {
            this.item.clear();
            //获取buff对应的图标
            let buff_img = game.Tools.localUISrc(`myres/activity_yijidagong/buff_icon${id}.jpg`);
            this.itemSkin.skin = buff_img;
            this.label_count.text = "";
            this.label_info.text = game.Tools.strOfLocalization(4552 + id);
            this.locking = true;
            this.me.visible = true;
            this.complete = complete;
            UI_Activity_Richman.Inst.black_mask.show();
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            let h: number = this.label_info.textField.textHeight;
            this.root.height = 300 + h;
        }

        public close() {
            this.locking = true;
            UI_Activity_Richman.Inst.black_mask.close();
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.me.visible = false;
                if (this.complete) this.complete.run();
            }));
        }

    }

    class Root {
        public me: Laya.Sprite;
        private bg: Laya.Image;
        private label_turn_count: Laya.Label;
        private exp_bar: Laya.Sprite;
        private img_title: Laya.Image;
        public btn_dice_normal: Laya.Button;
        private label_dice_normal: Laya.Label;
        private img_dice_normal: Laya.Image;
        private btn_dice_red: Laya.Button;
        private label_dice_red: Laya.Label;
        private img_dice_red: Laya.Image;
        private container_cells: Laya.Sprite;
        private label_bank_money: Laya.Label;
        private sp_box: Laya.Sprite;
        private chess: Laya.Sprite;
        private label_coin_buff_val: Laya.Label;
        private btn_buff_info: Laya.Button;
        private buff_info: Laya.Label;
        private img_buff: Laya.Image;
        private btn_buff: Laya.Button;
        private contianer_buff_fly: Laya.Sprite;
        private closeBtn: Laya.Button;
        private rewardBtn: Laya.Button;
        private taskBtn: Laya.Button;
        private rewardRedPoint: Laya.Image;
        private taskRedPoint: Laya.Image;

        private readonly origin_pos: Laya.Vector2 = new Laya.Vector2(980, 220);
        private readonly dir_x: Laya.Vector2 = new Laya.Vector2(95, 55);
        private readonly dir_y: Laya.Vector2 = new Laya.Vector2(-95, 55);
        private readonly id_dice_normal: number = 309022;
        private readonly id_dice_red: number = 309023;
        private readonly qizi_effect_offset: Laya.Point = new Laya.Point(0, 0);
        private readonly qizi_effect_buff_offset: Laya.Point = new Laya.Point(5, 0);
        private readonly qizi_effect_debuff_offset: Laya.Point = new Laya.Point(-8, -4);

        private map_data: lqc.Sheet_Activity_RichmanMap[];
        private level_data: lqc.Sheet_Activity_RichmanLevel[];
        private run_id: number = 0; // 如果run_id不匹配就说明关闭过，不用继续执行
        public locking: boolean = false;
        private location: number = 0;
        private _effects: Array<game.UIEffect> = [];
        private _jump_yiji: game.UIEffect = null;
        private exp: number = 0;
        private bank_save: number = 0;
        private buff: iBuffData = null;
        private expBarFullWidth: number = 327;

        public set onClickReward(v: Laya.Handler) {
            this.rewardBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                v?.run();
            });
        }

        public set onClickTask(v: Laya.Handler) {
            this.taskBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                v?.run();
            });
        }

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.bg = this.me.getChildByName('bg').getChildByName("bg") as Laya.Image;
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_yijidagong/bg.jpg');
            let turnInfo = this.me.getChildByName('turn_info') as Laya.Sprite;
            //当前走的圈数
            this.label_turn_count = turnInfo.getChildByName('turn_count') as Laya.Label;

            //属性栏
            let attributeInfo = this.me.getChildByName('attribute_info') as Laya.Sprite;
            //经验
            this.exp_bar = (attributeInfo.getChildByName('exp').getChildByName('val') as Laya.Sprite);
            //等级称号
            this.img_title = attributeInfo.getChildByName('title') as Laya.Image;
            //buff内容
            this.label_coin_buff_val = attributeInfo.getChildByName('coin_buff_val') as Laya.Label;
            //buff详情按钮
            this.btn_buff = attributeInfo.getChildByName('btn_buff') as Laya.Button;
            //buff图标
            this.img_buff = this.btn_buff.getChildByName('img') as Laya.Image;
            this.btn_buff.clickHandler = new Laya.Handler(this, () => {
                this.btn_buff_info.visible = !this.btn_buff_info.visible;
            });
            this.btn_buff_info = attributeInfo.getChildByName('btn_buff_info') as Laya.Button;
            this.buff_info = this.btn_buff_info.getChildByName('info') as Laya.Label;
            this.btn_buff_info.clickHandler = new Laya.Handler(this, () => {
                this.btn_buff_info.visible = !this.btn_buff_info.visible;
            });
            this.level_data = cfg.activity.richman_level.getGroup(UI_Activity_Richman.activity_id);


            this.btn_dice_normal = this.me.getChildByName('btn_normal') as Laya.Button;
            this.btn_dice_normal.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
               
                let count: number = UI_Bag.get_item_count(this.id_dice_normal);
                if (count <= 0) {
                    //显示提示弹窗
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217), true);
                    return;
                }
                this.btn_dice_normal.mouseEnabled = false;
                this.btn_dice_red.mouseEnabled = false;
                app.NetAgent.sendReq2Lobby('Lobby', 'richmanActivityNextMove', { activity_id: UI_Activity_Richman.activity_id }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('richmanActivityNextMove', err, res);
                        this.btn_dice_normal.mouseEnabled = true;
                        this.btn_dice_red.mouseEnabled = true;
                    } else {
                        this.label_dice_normal.text = (count - 1).toString();
                        this.onMove(false, res);
                    }
                });
            });
            this.img_dice_normal = this.btn_dice_normal.getChildByName('dice') as Laya.Image;
            this.label_dice_normal = this.btn_dice_normal.getChildByName('count') as Laya.Label;
            this.btn_dice_red = this.me.getChildByName('btn_red') as Laya.Button;
            this.btn_dice_red.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                let count: number = UI_Bag.get_item_count(this.id_dice_red);
                this.btn_dice_normal.mouseEnabled = false;
                this.btn_dice_red.mouseEnabled = false;
                UI_Activity_Richman.Inst.page_dice_red.show(Laya.Handler.create(this, step => {
                    if (step) {
                        if (count <= 0) {
                            //显示错误提示
                            // UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3217));
                            //显示提示弹窗
                            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3217),true);

                            this.btn_dice_normal.mouseEnabled = true;
                            this.btn_dice_red.mouseEnabled = true;
                            return;
                        }
                        app.NetAgent.sendReq2Lobby('Lobby', 'richmanAcitivitySpecialMove', {
                            activity_id: UI_Activity_Richman.activity_id,
                            step: step
                        }, (err, res) => {
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError('richmanAcitivitySpecialMove', err, res);
                                this.btn_dice_normal.mouseEnabled = true;
                                this.btn_dice_red.mouseEnabled = true;
                            } else {
                                this.label_dice_red.text = (count - 1).toString();
                                this.onMove(true, res);
                            }
                        });
                    } else {
                        this.btn_dice_normal.mouseEnabled = true;
                        this.btn_dice_red.mouseEnabled = true;
                    }
                }));
            });
            this.img_dice_red = this.btn_dice_red.getChildByName('dice') as Laya.Image;
            this.label_dice_red = this.btn_dice_red.getChildByName('count') as Laya.Label;
            this.container_cells = this.me.getChildByName('cells') as Laya.Sprite;
            this.build_map();
            this.label_bank_money = this.me.getChildByName('bank').getChildByName('val') as Laya.Label;
            const chess_box = this.me.getChildByName('chess_box') as Laya.Sprite;
            this.sp_box = chess_box.getChildByName('box') as Laya.Sprite;
            this.chess = chess_box.getChildByName('chess') as Laya.Sprite;

            this.contianer_buff_fly = this.chess.getChildByName('buff') as Laya.Sprite;
            (this.me.getChildByName('btn_info') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                uiscript.UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(4536));
            });

            this.closeBtn = this.me.getChildByName('btn_close') as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_Richman.Inst.hide();
            });

            this.taskBtn = this.me.getChildByName('btn_task') as Laya.Button;
            this.taskRedPoint = this.taskBtn.getChildByName('red_point') as Laya.Image;
            this.rewardBtn = this.me.getChildByName('btn_reward') as Laya.Button;
            this.rewardRedPoint = this.rewardBtn.getChildByName('red_point') as Laya.Image;

            
        }

        private get_cell_position(x: number, y: number): Laya.Vector2 {
            let ret: Laya.Vector2 = new Laya.Vector2;
            ret.x = this.origin_pos.x + this.dir_x.x * x + this.dir_y.x * y;
            ret.y = this.origin_pos.y + this.dir_x.y * x + this.dir_y.y * y;
            return ret;
        }

        private set_position(s: Laya.Sprite, x: number, y: number) {
            s.x = this.origin_pos.x + this.dir_x.x * x + this.dir_y.x * y;
            s.y = this.origin_pos.y + this.dir_x.y * x + this.dir_y.y * y;
        }

        private build_map() {
            let _templete: Laya.Sprite = this.container_cells.getChildByName('templete') as Laya.Sprite;
            _templete.visible = false;
            this.map_data = cfg.activity.richman_map.getGroup(24120101);
            let _cells: Array<Laya.Sprite> = [];
            for (let i: number = 0; i < this.map_data.length; i++) {
                let c: Laya.Sprite = _templete.scriptMap['capsui.UICopy'].getNodeClone();
                _cells.push(c);
            }
            Laya.timer.frameOnce(5, this, () => {
                for (let i: number = 0; i < this.map_data.length; i++) {
                    let img: Laya.Image = _cells[i] as Laya.Image;
                    let data = this.map_data[i];
                    this.set_position(img, data.pos_x, data.pos_y);
                    img.zOrder = img.y;
                    img.skin = game.Tools.localUISrc(`myres/activity_yijidagong/cell_${data.bonus_type}.png`);
                    if (data.bonus_type == 6) {
                        let _bank: Laya.Sprite = this.me.getChildByName('bank') as Laya.Sprite;
                        _bank.x = img.x;
                        _bank.y = img.y + 40;
                    }
                }
            });
        }

        private calcu_exp(exp: number): { level: number, rate: number } {
            for (let i: number = 1; i < this.level_data.length; i++) {
                if (exp < this.level_data[i].exp) return { level: i - 1, rate: (exp - this.level_data[i - 1].exp) / (this.level_data[i].exp - this.level_data[i - 1].exp) };
            }
            return { level: this.level_data.length - 1, rate: 1 };
        }

        public onShow() {
            this.locking = false;
            this.run_id++;
            let data: iActivityRichmanData = UI_Activity_Richman.richman_data;
            if (!data) return;
            this.location = data.location;
            this.set_position(this.chess, this.map_data[this.location].pos_x, this.map_data[this.location].pos_y);
            this.set_position(this.sp_box, this.map_data[data.chest_position].pos_x, this.map_data[data.chest_position].pos_y);
            this.sp_box.visible = true;
            this.chess.visible = true;
            this.btn_buff_info.visible = false;
            this.btn_buff.visible = false;
            this.btn_dice_normal.mouseEnabled = true;
            this.img_dice_normal.visible = true;
            this.btn_dice_red.mouseEnabled = true;
            this.img_dice_red.visible = true;
            this.exp = data.exp;
            let level_info = this.calcu_exp(this.exp);
            this.exp_bar.width = this.expBarFullWidth * level_info.rate;
            this.img_title.skin = game.Tools.localUISrc(`myres/activity_yijidagong/title${level_info.level}.png`);
            this.label_coin_buff_val.text = game.Tools.strOfLocalization(4534) + `+${this.level_data[level_info.level].buff}%`;
            this.bank_save = data.bank_save;
            this.label_bank_money.text = data.bank_save.toString();
            this.contianer_buff_fly.visible = false;
            this.label_turn_count.text = game.Tools.strOfLocalization(4551) + data.finished_count.toString();
            let infoData = cfg.activity.richman_info.get(UI_Activity_Richman.activity_id);

            this.label_dice_normal.text = UI_Bag.get_item_count(this.id_dice_normal).toString();
            this.label_dice_red.text = UI_Bag.get_item_count(this.id_dice_red).toString();
            if (data.buff && data.buff.length > 0) {
                let _buff: iBuffData = data.buff[0];
                if (_buff.type == 1) { // 金币
                    if (_buff.effect == 200) {
                        this.buff_info.text = game.Tools.strOfLocalization(4530);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff3.png');
                    } else {
                        this.buff_info.text = game.Tools.strOfLocalization(4531);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff0.png');
                    }
                } else {
                    if (_buff.effect == 200) {
                        this.buff_info.text = game.Tools.strOfLocalization(4532);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff1.png');
                    } else {
                        this.buff_info.text = game.Tools.strOfLocalization(4533);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff2.png');
                    }
                }
                this.buff = _buff;
                this.btn_buff.visible = true;
            } else {
                this.btn_buff.visible = false;
                this.btn_buff_info.visible = false;
                this.buff = null;
            }

            let bgEffect = this.addEffect("scene/effect_2412winter_ui_show.lh", new Laya.Point(0, 0), 1)
            view.AudioMgr.PlayAudio(10180);
            Laya.timer.once(4000, this, () => {
                this.removeEffect(bgEffect);
            });


        }

        public onClose() {
            this.run_id++;
            Laya.timer.clearAll(this);
            for (let i: number = 0; i < this._effects.length; i++) {
                this._effects[i].destory();
            }
            this._effects = [];
            if (this._jump_yiji) {
                this._jump_yiji.destory();
                this._jump_yiji = null;
            }
        }

        public onMove(rdice: boolean, data: game.IResRichmanNextMove) {
            let _run_id: number = this.run_id;
            this.locking = true;
            if (rdice) {
                this.img_dice_red.skin = game.Tools.localUISrc(`myres/activity_yijidagong/rdice${data.dice}.png`);
                this.img_dice_red.visible = false;
                let _effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.btn_dice_red, 'scene/touzi_touzi_red.lh', new Laya.Point(20, 20), 1);
                view.AudioMgr.PlayAudio(10189);
                this._add_effect(_effect);
                Laya.timer.once(900, this, () => {
                    this.img_dice_red.visible = true;
                });
                Laya.timer.once(1300, this, () => {
                    this._remove_effect(_effect);
                    _effect.destory();
                });
            } else {
                this.img_dice_normal.skin = game.Tools.localUISrc(`myres/activity_yijidagong/dice${data.dice}.png`);
                this.img_dice_normal.visible = false;
                let _effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.btn_dice_normal, 'scene/touzi_touzi.lh', new Laya.Point(10, 0), 1.2);
                view.AudioMgr.PlayAudio(10188);
                this._add_effect(_effect);
                Laya.timer.once(900, this, () => {
                    this.img_dice_normal.visible = true;
                });
                Laya.timer.once(1300, this, () => {
                    this._remove_effect(_effect);
                    _effect.destory();
                });
            }

            let d: iActivityRichmanData = UI_Activity_Richman.richman_data;
            let old_bank: number = d.bank_save;
            d.bank_save = data.bank_save;
            d.chest_position = data.chest_position;
            d.exp = data.exp;
            d.finished_count = data.finished_count;
            d.buff = data.buff;
            d.location = data.location;
            Laya.timer.once(1500, this, () => {
                if (this.run_id != _run_id) return;
                this._move(_run_id, data, 0);
                this.bank_save = old_bank + data.bank_save_add;
                this._bank_change(old_bank, old_bank + data.bank_save_add);
            });
        }

        // 银行变动
        private _bank_change(v_origin: number, v_now: number) {
            this.label_bank_money.text = v_origin.toString();
            let _effect: game.UIEffect;
            if (v_now > v_origin) {
                _effect = game.FrontEffect.Inst.create_ui_effect(this.label_bank_money, 'scene/touzi_bank.lh', new Laya.Point(-2, 1), 1);
                view.AudioMgr.PlayAudio(10181);
                this._add_effect(_effect);
                Laya.timer.once(500, this, () => {
                    this._remove_effect(_effect);
                    if (!_effect.destoryed) _effect.destory();
                });
            }
            for (let i: number = 1; i <= 5; i++) {
                Laya.timer.once(50 * i, this, () => {
                    let r: number = i / 5;
                    let v: number = Math.floor(v_origin * (1 - r)) + Math.floor(v_now * r);
                    if (i == 5) v = v_now;
                    this.label_bank_money.text = v.toString();
                });
            }
        }

        // 跳
        private _move(run_id: number, data: game.IResRichmanNextMove, path_index: number) {
            if (run_id != this.run_id) return;
            if (path_index >= data.paths.length) {
                this._on_move_over(data);
                return;
            }
            let location_old: number = this.location;
            let location_new: number = (location_old + 1) % this.map_data.length;
            this.location = location_new;
            let pos: Laya.Vector2 = this.get_cell_position(this.map_data[location_new].pos_x, this.map_data[location_new].pos_y);
            this.chess.visible = false;
            if (!this._jump_yiji) this._jump_yiji = game.FrontEffect.Inst.create_ui_effect(this.chess, 'scene/touzi_qizi.lh', this.qizi_effect_offset, 1);
            this._jump_yiji.effect.root.active = true;
            view.AudioMgr.PlayAudio(10187);
            Laya.timer.once(60, this, () => {
                Laya.Tween.to(this.chess, { x: pos.x, y: pos.y }, 230, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                    Laya.timer.once(200, this, () => {
                        if (run_id != this.run_id) return;
                        this.chess.visible = true;
                        this._jump_yiji.effect.root.active = false;
                        if (this.location == 0) {
                            this.label_turn_count.text = game.Tools.strOfLocalization(4551) + UI_Activity_Richman.richman_data.finished_count.toString();
                            this.freshRedPoint();
                        }
                        if (location_new != data.paths[path_index].location) {
                            this._move(run_id, data, path_index);
                            return;
                        }
                        if (path_index == 0) {
                            this._pending_exp_change(run_id, data, path_index);
                        } else {
                            this._pending_chest_rewards(run_id, data, path_index);
                        }
                    });
                }));
            });
        }

        // 经验值增加
        private _pending_exp_change(run_id: number, data: any, path_index: number) {
            if (run_id != this.run_id) return;
            let _exp0: number = this.exp;
            let _exp1: number = data.exp;
            this.exp = _exp1;
            if (_exp0 == _exp1) {
                this._pending_chest_rewards(run_id, data, path_index);
            } else if (_exp0 >= _exp1) {
                let level_info = this.calcu_exp(this.exp);
                this.exp_bar.width = this.expBarFullWidth * level_info.rate;
                this.img_title.skin = game.Tools.localUISrc(`myres/activity_yijidagong/title${level_info.level}.png`);
                this.label_coin_buff_val.text = game.Tools.strOfLocalization(4534) + `+${this.level_data[level_info.level].buff}%`;
                this._pending_chest_rewards(run_id, data, path_index);
            } else {
                let level_info0 = this.calcu_exp(_exp0);
                let level_info1 = this.calcu_exp(_exp1);
                let speed: number = 2 / 1000;
                if (level_info0.level < level_info1.level) {
                    let t0 = (1 - level_info0.rate) / speed;
                    let t1 = level_info1.rate / speed;
                    Laya.Tween.to(this.exp_bar, { width: this.expBarFullWidth }, t0, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                        if (run_id != this.run_id) return;
                        let level_up: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.chess, 'scene/touzi_qizi_lvup.lh', this.qizi_effect_offset, 1);
                        view.AudioMgr.PlayAudio(10186);
                        this.exp_bar.width = 0;
                        this.img_title.skin = game.Tools.localUISrc(`myres/activity_yijidagong/title${level_info1.level}.png`);
                        this.label_coin_buff_val.text = game.Tools.strOfLocalization(4534) + `+${this.level_data[level_info1.level].buff}%`;
                        Laya.Tween.to(this.exp_bar, { width: level_info1.rate * this.expBarFullWidth }, t1, null);
                        this._add_effect(level_up);
                        Laya.timer.once(1100, this, () => {
                            if (run_id != this.run_id) return;
                            this._pending_chest_rewards(run_id, data, path_index);
                            this._remove_effect(level_up);
                            level_up.destory();
                        });
                    }));
                } else {
                    Laya.Tween.to(this.exp_bar, { width: level_info1.rate * this.expBarFullWidth }, (level_info1.rate - level_info0.rate) / speed, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                        this.exp_bar.width = level_info1.rate * this.expBarFullWidth
                        this._pending_chest_rewards(run_id, data, path_index);
                    }));
                }
            }

        }

        // 停下来的时候宝箱的奖励
        private _pending_chest_rewards(run_id: number, data: game.IResRichmanNextMove, path_index: number) {
            if (run_id != this.run_id) return;
            let path_data = data.paths[path_index];
            let rewards = path_data.rewards;
            let events = path_data.events;
            if (rewards) {
                for (let i: number = 0; i < rewards.length; i++) {
                    if (rewards[i].type == 1) {
                        let id: number = rewards[i].resource_id;
                        let count: number = rewards[i].count;
                        let angle_index: number = 0;
                        if (id >= 302005 && id <= 302012) { // 宝玉
                            angle_index = 1;
                        } else if (id == 304008) { // 贵人福袋
                            angle_index = 6;
                        } else if (id == 304009) { // 贤人福袋
                            angle_index = 3;
                        } else {	// 铜币
                            let origin_count = rewards[i].origin_count;
                            if (origin_count == 5000) {
                                angle_index = 4;
                            } else if (origin_count == 10000) {
                                angle_index = 2;
                            } else if (origin_count == 20000) {
                                angle_index = 7;
                            } else {
                                angle_index = 5;
                            }
                        }
                        let angle: number = (360 / 7 - 20) * (0.5 - Math.random()) + (angle_index - 1) * 360 / 7 + 360 / 7 / 2;
                        UI_Activity_Richman.Inst.chest_table.show(angle, Laya.Handler.create(this, () => {
                            if (this.run_id != run_id) return;
                            let _reward_info: string = game.Tools.strOfLocalization(4545);
                            if (id == 100002) {
                                let level_info = this.calcu_exp(this.exp);
                                if (level_info.level > 0) _reward_info += '\n' + game.Tools.strOfLocalization(4546 + level_info.level);
                                if (this.buff && this.buff.type == 1) _reward_info += '\n' + game.Tools.strOfLocalization(4535);
                            }
                            UI_Activity_Richman.Inst.reward_page.show(id, count, _reward_info, Laya.Handler.create(this, () => {
                                this._pending_chest_get_fly(run_id, data, path_index);
                            }));
                        }));
                        return;
                    }
                }
            }
            this._pending_events(run_id, data, path_index);
        }

        // 宝箱移动位置:获得宝箱后
        private _pending_chest_get_fly(run_id, data:game.IResRichmanNextMove, path_index) {
            if (run_id != this.run_id) return;
            let path_data = data.paths[path_index];
            let rewards = path_data.rewards;
            let events = path_data.events;
            let chest_position: number = data.chest_position;
            if (events && events.length > 0 && events[0] == 124605) {
                // 获得宝箱遇到卡维时间飞宝箱，宝箱位置随机一下
                chest_position = (this.location - Math.ceil(Math.random() * 6) + this.map_data.length) % this.map_data.length;
            }
            this.sp_box.visible = false;
            let effect_disappear: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.sp_box, 'scene/touzi_chest_disappear.lh', new Laya.Point(0, -45), 1);
            view.AudioMgr.PlayAudio(10183);
            this._add_effect(effect_disappear);
            Laya.timer.once(600, this, () => {
                if (run_id != this.run_id) return;
                this._remove_effect(effect_disappear);
                effect_disappear.destory();
                this.set_position(this.sp_box, this.map_data[chest_position].pos_x, this.map_data[chest_position].pos_y);
                let effect_appear: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.sp_box, 'scene/touzi_chest_appear.lh', new Laya.Point(0, -45), 1);
                view.AudioMgr.PlayAudio(10182);
                this._add_effect(effect_appear);
                Laya.timer.once(500, this, () => {
                    if (run_id != this.run_id) return;
                    this._remove_effect(effect_appear);
                    effect_appear.destory();
                    this.sp_box.visible = true;
                    this._pending_events(run_id, data, path_index);
                });
            });
        }

        // 停下来的时候卡维时间
        private _pending_events(run_id: number, data: any, path_index: number) {
            if (run_id != this.run_id) return;
            let path_data = data.paths[path_index];
            let rewards = path_data.rewards;
            let events = path_data.events;

            if (events && events.length > 0) {
                let event_id: number = events[0];
                let angle_index: number = 0;
                let buffId = 0;
                switch (event_id) {
                    // 铜币加倍
                    case 24120101:
                        angle_index = 4;
                        buffId = 0;
                        break;
                    //铜币减半
                    case 24120102:
                        angle_index = 1;
                        buffId = 1;
                        break;
                    //步数翻倍
                    case 24120103:
                        angle_index = 0;
                        buffId = 5;
                        buffId = 2;
                        break;
                    //步数减半
                    case 24120104:
                        angle_index = 3;
                        buffId = 3;
                        break;
                    //宝箱刷新
                    case 24120105:
                        angle_index = 5;
                        buffId = 4;
                        break;
                    //前进一步
                    case 24120106:
                        angle_index = 2;
                        buffId = 5;
                        break;
                }
                let angle: number = 40 * (0.5 - Math.random()) + angle_index * 60;
                UI_Activity_Richman.Inst.kawei_table.show(angle, Laya.Handler.create(this, () => {
                    let onClose = () => { 
                        if (event_id == 24120105) {
                            this._pending_chest_kawei_fly(run_id, data, path_index);
                            return;
                        }
                        let effect_url: string = '';
                        let buff_img: string = '';
                        let buff_info: string = '';
                        let offset = this.qizi_effect_offset;
                        let audioId = 0;
                        let effect_duration = 600;
                        if (event_id == 24120101) {
                            effect_url = 'scene/touzi_qizi_buff.lh';
                            buff_info = game.Tools.strOfLocalization(4530);
                            buff_img = game.Tools.localUISrc('myres/activity_yijidagong/buff3.png');
                            offset = this.qizi_effect_buff_offset;
                            audioId = 10184;

                        } else if (event_id == 24120102) {
                            effect_duration = 1600;
                            effect_url = 'scene/touzi_qizi_debuff.lh';
                            buff_info = game.Tools.strOfLocalization(4531);
                            buff_img = game.Tools.localUISrc('myres/activity_yijidagong/buff0.png');
                            offset = this.qizi_effect_debuff_offset;
                            audioId = 10185;
                        } else if (event_id == 24120103) {
                            effect_url = 'scene/touzi_qizi_buff.lh';
                            buff_info = game.Tools.strOfLocalization(4532);
                            buff_img = game.Tools.localUISrc('myres/activity_yijidagong/buff1.png');
                            offset = this.qizi_effect_buff_offset;
                            audioId = 10184;
                        } else if (event_id == 24120104) {
                            effect_duration = 1600;
                            effect_url = 'scene/touzi_qizi_debuff.lh';
                            buff_info = game.Tools.strOfLocalization(4533);
                            buff_img = game.Tools.localUISrc('myres/activity_yijidagong/buff2.png');
                            offset = this.qizi_effect_debuff_offset;
                            audioId = 10185;
                        }
                        if (effect_url) {
                            let effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.chess, effect_url, offset, 1);
                            view.AudioMgr.PlayAudio(audioId);
                            this._add_effect(effect);
                            Laya.timer.once(effect_duration, this, () => {
                                this._remove_effect(effect);
                                effect.destory();
                            });
                            (this.contianer_buff_fly.getChildByName('img') as Laya.Image).skin = buff_img;
                            this.img_buff.skin = buff_img;
                            this.buff_info.text = buff_info;
                            this.contianer_buff_fly.visible = true;
                            this.contianer_buff_fly.alpha = 1;
                            this.contianer_buff_fly.y = -47;
                            Laya.Tween.to(this.contianer_buff_fly, { y: -100, alpha: 0 }, 1500, null, Laya.Handler.create(this, () => {
                                this.contianer_buff_fly.visible = false;
                            }));
                            Laya.timer.once(200, this, () => {
                                this.btn_buff.visible = true;
                                this.btn_buff_info.visible = false;
                            });
                            Laya.timer.once(300, this, () => {
                                this._pending_cell_rewards(run_id, data, path_index);
                            });
                        }
                        else {
                            this._pending_cell_rewards(run_id, data, path_index);
                        }
                    }
                    //显示buff获取弹窗
                   
                    UI_Activity_Richman.Inst.reward_page.showBuff(buffId, Laya.Handler.create(this, onClose));
                    
                }));
                return;
            }
            this._pending_cell_rewards(run_id, data, path_index);
        }

        // 宝箱移动位置：卡维飞宝箱
        private _pending_chest_kawei_fly(run_id, data, path_index) {
            if (run_id != this.run_id) return;
            let path_data = data.paths[path_index];
            let rewards = path_data.rewards;
            let events = path_data.events;
            let chest_position: number = data.chest_position;
            this.sp_box.visible = false;
            let effect_disappear: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.sp_box, 'scene/touzi_chest_disappear.lh', new Laya.Point(0, -40), 1);
            view.AudioMgr.PlayAudio(10183);
            this._add_effect(effect_disappear);
            Laya.timer.once(600, this, () => {
                if (run_id != this.run_id) return;
                this._remove_effect(effect_disappear);
                effect_disappear.destory();
                this.set_position(this.sp_box, this.map_data[chest_position].pos_x, this.map_data[chest_position].pos_y);
                let effect_appear: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.sp_box, 'scene/touzi_chest_appear.lh', new Laya.Point(-3, -42), 1);
                view.AudioMgr.PlayAudio(10182);
                this._add_effect(effect_appear);
                Laya.timer.once(500, this, () => {
                    if (run_id != this.run_id) return;
                    this._remove_effect(effect_appear);
                    effect_appear.destory();
                    this.sp_box.visible = true;
                    this._pending_cell_rewards(run_id, data, path_index);
                });
            });
        }

        // 停下来的时候格子奖励
        private _pending_cell_rewards(run_id: number, data: any, path_index: number) {
            if (run_id != this.run_id) return;
            let path_data = data.paths[path_index];
            let rewards = path_data.rewards;
            let events = path_data.events;
            if (rewards) {
                for (let i: number = 0; i < rewards.length; i++) {
                    if (rewards[i].type != 1) {
                        let id: number = rewards[i].resource_id;
                        let count: number = rewards[i].count;
                        let location_type = this.map_data[this.location].bonus_type;

                        let _reward_info: string = '';
                        // if (rewards[i].type == 2) {
                        // 	_reward_info = game.Tools.strOfLocalization(3549, [String(UI_Activity_Richman.richman_data.finished_count)]);
                        // } else 
                        if (location_type == 1) {
                            let origin_count = rewards[i].origin_count;
                            if (origin_count == 2000) {
                                _reward_info = game.Tools.strOfLocalization(4540);
                            } else if (origin_count == 1000) {
                                _reward_info = game.Tools.strOfLocalization(4539);
                            } else if (origin_count == 800) {
                                _reward_info = game.Tools.strOfLocalization(4538);

                            } else {
                                _reward_info = game.Tools.strOfLocalization(4537);
                            }
                            let level_info = this.calcu_exp(this.exp);
                            if (level_info.level > 0) _reward_info += '\n' + game.Tools.strOfLocalization(4546 + level_info.level);
                            if (this.buff && this.buff.type == 1) _reward_info += '\n' + game.Tools.strOfLocalization(4535);
                        } else if (location_type == 2) {
                            _reward_info = game.Tools.strOfLocalization(4541);
                        } else if (location_type == 3) {
                            _reward_info = game.Tools.strOfLocalization(4543);
                        } else if (location_type == 4) {
                            _reward_info = game.Tools.strOfLocalization(4542);
                        } else if (location_type == 6) {
                            _reward_info = game.Tools.strOfLocalization(4544);
                            let level_info = this.calcu_exp(this.exp);
                            if (level_info.level > 0) _reward_info += '\n' + game.Tools.strOfLocalization(4546 + level_info.level);
                            if (this.buff && this.buff.type == 1) _reward_info += '\n' + game.Tools.strOfLocalization(4535);
                        }
                        if (location_type != 0) {
                            UI_Activity_Richman.Inst.reward_page.show(id, count, _reward_info, Laya.Handler.create(this, () => {
                                if ((run_id != this.run_id)) return;
                                this._move(run_id, data, path_index + 1);
                            }));
                            return;
                        }

                    }
                }
            }
            this._move(run_id, data, path_index + 1);
        }

        // 移动结算完
        private _on_move_over(data: any) {
            if (data.buff && data.buff.length > 0) {
                let _buff: iBuffData = data.buff[0];
                if (_buff.type == 1) { // 金币
                    if (_buff.effect == 200) {
                        this.buff_info.text = game.Tools.strOfLocalization(4530);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff3.png');
                    } else {
                        this.buff_info.text = game.Tools.strOfLocalization(4531);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff0.png');
                    }
                } else {
                    if (_buff.effect == 200) {
                        this.buff_info.text = game.Tools.strOfLocalization(4532);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff1.png');
                    } else {
                        this.buff_info.text = game.Tools.strOfLocalization(4533);
                        this.img_buff.skin = game.Tools.localUISrc('myres/activity_yijidagong/buff2.png');
                    }
                }
                this.btn_buff.visible = true;
                this.buff = _buff;
            } else {
                this.btn_buff.visible = false;
                this.btn_buff_info.visible = false;
                this.buff = null;
            }
            if (this.bank_save != data.bank_save) {
                this._bank_change(this.bank_save, data.bank_save);
                this.bank_save = data.bank_save;
            }
            this.btn_dice_normal.mouseEnabled = true;
            this.btn_dice_red.mouseEnabled = true;
            this.locking = false;
            this.label_dice_normal.text = UI_Bag.get_item_count(this.id_dice_normal).toString();
        }


        public addEffect(effectName: string, pos: Laya.Point, scale: number) {
            let effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(this.chess, effectName, pos, scale);
            this._add_effect(effect);
            return effect;
        }

        public removeEffect(effect: game.UIEffect) { 
            this._remove_effect(effect);
            effect.destory();
        }

        private _add_effect(effect: game.UIEffect) {
            this._effects.push(effect);
        }

        private _remove_effect(effect: game.UIEffect) {
            let lst: Array<game.UIEffect> = [];
            for (let i: number = 0; i < this._effects.length; i++) {
                if (this._effects[i] !== effect) {
                    lst.push(this._effects[i]);
                }
            }
            this._effects = lst;
        }

        public freshRedPoint() {
            this.taskRedPoint.visible = UI_Activity_Richman_Task.haveRedPoint();
            this.rewardRedPoint.visible = UI_Activity_Richman_Reward.haveRedPoint();
        }

        public freshDiceCount() { 
            this.label_dice_normal.text = UI_Bag.get_item_count(this.id_dice_normal).toString();
            this.label_dice_red.text = UI_Bag.get_item_count(this.id_dice_red).toString();
        }
    }

    export class UI_Activity_Richman extends UIBase {
        public static activity_id: number = 241201;
        public static Inst: UI_Activity_Richman;
        public static richman_data: iActivityRichmanData;
        public static diceNormalId: number = 309022;
        public static diceRedId: number = 309023; 

        public static onFetchAcitiviyData(data) {
            if (data.richman_data) {
                for (let i: number = 0; i < data.richman_data.length; i++) {
                    if (data.richman_data[i].activity_id == this.activity_id) {
                        this.richman_data = data.richman_data[i];
                        break;
                    }
                }
                //更新红点
                if (UI_Activity_Richman.Inst && UI_Activity_Richman.Inst.enable) {
                    UI_Activity_Richman.Inst.refreshRedPoints();
                }
            }
        }

        public root: Root;
        public page_dice_red: ChooseDiceRed;
        public black_mask: BlackMask;
        public kawei_table: TurnTable;
        public chest_table: TurnTable;
        public reward_page: RewardPage;
        private pageTask: UI_Activity_Richman_Task;
        private pageReward: UI_Activity_Richman_Reward;
        private diceChangeHandler: Laya.Handler;
        public isLock: boolean = false;
        private showAnim: Laya.FrameAnimation;


        constructor() {
            super(new ui.lobby.activity_2412_richman.activity_2412_richmanUI());
            UI_Activity_Richman.Inst = this;
        }



        public onCreate() {
            this.root = new Root(this.me.getChildByName('root') as Laya.Sprite);
            this.page_dice_red = new ChooseDiceRed(this.me.getChildByName('rdice') as Laya.Sprite);
            this.black_mask = new BlackMask(this.me.getChildByName('bmask') as Laya.Sprite);
            this.kawei_table = new TurnTable(this.me.getChildByName('kaweitable') as Laya.Sprite);
            this.chest_table = new TurnTable(this.me.getChildByName('chesttable') as Laya.Sprite);
            this.reward_page = new RewardPage(this.me.getChildByName('reward') as Laya.Sprite);
            this.pageTask = new UI_Activity_Richman_Task();
            this.root.me.addChild(this.pageTask.me);
            this.pageTask.me.visible = false;
            this.pageReward = new UI_Activity_Richman_Reward();
            this.root.me.addChild(this.pageReward.me);
            this.pageReward.me.visible = false;
            this.root.onClickReward = new Laya.Handler(this, () => {
                this.pageReward.show();
                this.refreshRedPoints();
            });

            this.root.onClickTask = new Laya.Handler(this, () => {
                this.pageTask.show();
                this.refreshRedPoints();
            });
            this.diceChangeHandler = new Laya.Handler(this, this.onDiceCountChange);
            this.showAnim = (this.me as ui.lobby.activity_2412_richman.activity_2412_richmanUI).ani1;
        }

        public show() {
            this.page_dice_red.me.visible = false;
            this.black_mask.me.visible = false;
            this.kawei_table.me.visible = false;
            this.chest_table.me.visible = false;
            this.reward_page.me.visible = false;
            this.root.onShow();
            this.refreshRedPoints();
            this.enable = true;
            this.isLock = true;
            this.root.locking = true;
         
            this.showAnim.play(0, false);
           
            this.showAnim.once(Laya.Event.COMPLETE, this, () => {
                this.isLock = false;
                this.root.locking = false;
                
            });
            game.TempImageMgr.setUIEnable('UI_Activity_Richman', true);
        }

        public hide() {
           
            this.enable = false;
            game.TempImageMgr.setUIEnable('UI_Activity_Richman', false);
            UI_Lobby.Inst.enable = true;
        }

        public onEnable(): void {
            //监听背包物品变化
            UI_Bag.add_item_listener(UI_Activity_Richman.diceNormalId, this.diceChangeHandler)
            UI_Bag.add_item_listener(UI_Activity_Richman.diceRedId, this.diceChangeHandler)
        }

        public onDisable(): void {
            this.root.onClose();
            //移除监听背包物品变化
            UI_Bag.remove_item_listener(UI_Activity_Richman.diceNormalId, this.diceChangeHandler)
            UI_Bag.remove_item_listener(UI_Activity_Richman.diceRedId, this.diceChangeHandler)
        }

        private onDiceCountChange() { 
            if(this.root.btn_dice_normal.mouseEnabled)
                this.root.freshDiceCount();
        }

        public refreshRedPoints() {
            this.root.freshRedPoint();
        }

        public static hasRedPoint(): boolean {
            return UI_Activity_Richman_Reward.haveRedPoint() || UI_Activity_Richman_Task.haveRedPoint();
        }

    }
}