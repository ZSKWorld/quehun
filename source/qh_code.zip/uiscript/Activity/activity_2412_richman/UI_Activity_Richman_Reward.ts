module uiscript {

    

    /**
    * 分类按钮,此部分仅用于处理ui,目的是为了不让每次onValueChange的时候重新获取相关组件的引用
    */
    class Reward_TabButton {

        private me: Laya.Button;

        private selectImg: Laya.Image;
        private deselectImg: Laya.Image;
        private title: Laya.Label;
        constructor(me: Laya.Button) {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.deselectImg = this.me.getChildByName("diselect") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
        }


        public onSelect() {

            this.selectImg.visible = true;
            this.deselectImg.visible = false;
            this.title.color = "#effcff";

        }

        public onDeselect() {
            this.selectImg.visible = false;
            this.deselectImg.visible = true;
            this.title.color = "#6090cb";
        }

    }
    export class UI_Activity_Richman_Reward extends UIBase {

       
        public static Inst: UI_Activity_Richman_Reward;
        public static activityId: number = 241203;


        constructor() {
            super(new ui.lobby.activity_2412_richman.activity_2412_richman_rewardUI());
            UI_Activity_Richman_Reward.Inst = this;
           
        }

        private root: Laya.Sprite;
        private maskCloseBtn: Laya.Button;
        private closeBtn: Laya.Button;
        private typeTabs: Laya.Sprite;
        private emptyInfo: Laya.Sprite;

        private tabGroups: UI_TabGroup_Base;
        private tabButtons: Array<Reward_TabButton>;
        private getAllButton: Laya.Button;
        private getAllButtonLabel: Laya.Label;
        private getAllButtonSkin: Laya.Image;
        /**
        * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
        */
        private serverData: Object[];

        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();

        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private locking: boolean = true;
        private itemRect: UIRect = null;
        private showAnim: Laya.FrameAnimation;
        private hideAnim: Laya.FrameAnimation;
        private bg: Laya.Sprite;

        public onCreate() {
            this.bg = this.me.getChildByName("bg") as Laya.Sprite;
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            this.maskCloseBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) {
                    return;
                }
                this.close();
            });
            this.closeBtn = this.root.getChildByName("btn_close") as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) {
                    return;
                }
                this.close();
            });
            this.typeTabs = this.root.getChildByName("tabs") as Laya.Sprite;
            
            this.emptyInfo = this.root.getChildByName("empty") as Laya.Sprite;
            this.getAllButton = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.getAllButtonLabel = this.getAllButton.getChildByName("info") as Laya.Label;
            this.getAllButtonSkin = this.getAllButton.getChildByName("bg") as Laya.Image;

            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
            this.getAllButton.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            this.initTabs();
        }


        public show() {
            this.freshData();
            this.tabGroups.init();
            this.enable = true;
            this.locking = true;
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 200);
          

        }

        public close() {
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
        }

        


        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList() {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.emptyInfo.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<Reward_TabButton>();
            for (let i = 0; i < 3; i++) {
                let btn = this.typeTabs.getChildAt(i) as Laya.Button;
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Reward_TabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.freshList();
                }
                else {
                    tabBtn.onDeselect();
                }
            };


        }

        public onEnable() {
           
        }

        public onDisable(): void {
            
        }


        //刷新列表数据
        private freshData() {
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_Richman_Reward.activityId);
            // app.Log.log(`Richman_Reward的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);

            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);

            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);

            this.freshGetAllBtn();


        }


        // 排序函数
        private sortTasks(a: BA_PreviodTaskServerData, b: BA_PreviodTaskServerData) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: BA_PreviodTaskServerData): number {
            let weight = 0;

            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
        

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Sprite;
            //赋值任务名称
            let taskInfo = container.getChildByName("desc") as Laya.Label;
            taskInfo.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            let getted = container.getChildByName("getted") as Laya.Sprite;
            let btnGet = container.getChildByName("btn_get") as Laya.Button;
            let progressLabel = container.getChildByName("progress") as Laya.Label;

            progressLabel.visible = !serverData.achieved;
            getted.visible = serverData.achieved && serverData.rewarded;
            btnGet.visible = serverData.achieved && !serverData.rewarded;


            if (!serverData.achieved) {
               

                //判断该任务是否有进度
                if (baseTaskConfigData.type == 97) {
                    //无进度
                    progressLabel.text = game.Tools.strOfLocalization(4255);
                }
                else {
                    progressLabel.text = game.Tools.strOfLocalization(4253) + '\n' + serverData.counter + '/' + baseTaskConfigData.target;
                }
            }
            else {
                if (!serverData.rewarded) {
                    //领取的点击事件
                    btnGet.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) {
                            return;
                        }
                        this.locking = true;
                        app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            this.locking = false;
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                UI_Activity.onPeriodTaskRewarded(serverData.id);
                                game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                this.freshData();
                                this.scrollView.wantToRefreshAll();
                                if (UI_Activity_Richman.Inst && UI_Activity_Richman.Inst.enable) {
                                    UI_Activity_Richman.Inst.refreshRedPoints();
                                }
                            }
                        });

                    }, null, false);

                }
                else {
                    //已完成已领取
                }
            }

            // 奖励的渲染
            if (rewardsData.length >= 2) {


                let itemImg = itemParent.getChildByName("icon") as Laya.Image;
                let itemCount = itemParent.getChildByName("item_count") as Laya.Label;
                let itemBtn = itemParent.getChildByName("info_btn") as Laya.Button;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(itemImg);
                }
                game.Tools.setItemIcon(itemImg, this.itemRect, rewardId, "UI_Activity_24ba", true);
                itemCount.text = "x" + rewardCount.toString();
                itemBtn.clickHandler = new Laya.Handler(this, () => {
                    UI_ItemDetail.Inst.show(rewardId);
                })
            }
        }

        private freshGetAllBtn() {
            if (!UI_Activity_Richman_Reward.haveRedPoint()) {
                // 按钮置灰且不能点
                this.getAllButtonLabel.color = '#ffffff';
                this.getAllButtonSkin.skin = game.Tools.localUISrc('myres/activity_yijidagong/pop_up_get_all_gray.png');
                this.getAllButton.mouseEnabled = false;
            } else {
                this.getAllButton.mouseEnabled = true;
                this.getAllButtonLabel.color = '#9a4021';
                this.getAllButtonSkin.skin = game.Tools.localUISrc('myres/activity_yijidagong/pop_up_get_all.png');
            }
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public static haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Richman_Reward.activityId);
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    return true;
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) {
                return;
            }
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData) {
                        needGetList.push(data['id']);
                    }
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            let rqs: game.IReqCompletePeriodActivityTaskBatch = { task_list: needGetList };
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTaskBatch, rqs, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.freshData();
                    this.scrollView.wantToRefreshAll();

                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                    if (UI_Activity_Richman.Inst && UI_Activity_Richman.Inst.enable) {
                        UI_Activity_Richman.Inst.refreshRedPoints();
                    }
                }
            })
        }

    }
}