module uiscript {
    class Item_Richman_Task {
        public me: Laya.Sprite;
        private imageItem: Laya.Image;
        private labelDesc: Laya.Label;
        private labelCount: Laya.Label;
        private labelProgress: Laya.Label;
        private labelProgressText: Laya.Label;
        private getted: Laya.Sprite;
        private btnGet: Laya.Button;

        private taskId: number;
        private itemId: number;
        private itemCount: number;
        private index: number;
        private target: number;
        constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.index = index;
            this.imageItem = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.labelCount = this.me.getChildByName('item').getChildByName('item_count') as Laya.Label;
            (this.me.getChildByName('item').getChildByName('info_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Richman_Task.Inst.locking) return;
                UI_ItemDetail.Inst.show(this.itemId);
            });

            this.labelDesc = this.me.getChildByName('desc') as Laya.Label;
            this.labelProgress = this.me.getChildByName('progress') as Laya.Label;
            this.labelProgressText = this.me.getChildByName('proText') as Laya.Label;
            this.getted = this.me.getChildByName('getted') as Laya.Sprite;
            this.btnGet = this.me.getChildByName('btn_get') as Laya.Button;
            this.btnGet.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Richman_Task.Inst.locking) return;
                UI_Activity_Richman_Task.Inst.sendTaskCompleteRequest(this.index, this.taskId, this.itemId, this.itemCount);
            });
        }

        public show(taskId: number) {
            if (!taskId) {
                this.me.visible = false;
                return;
            }
            this.me.visible = true;
            this.taskId = taskId;
            let _data = UI_Activity_Task_Random.FindTaskInfo(taskId);
            this.itemId = _data.reward_id;
            this.itemCount = _data.reward_count;
            let dView = game.GameUtility.get_item_view(this.itemId);
            game.LoadMgr.setImgSkin(this.imageItem, dView.icon, null, 'UI_Activity_Richman');
            this.labelCount.text = "x" + this.itemCount.toString();
            let _baseData = cfg.events.base_task.get(_data.base_task_id);
            this.labelDesc.text = _baseData['desc_' + GameMgr.client_language];
            this.target = _baseData.target;
            this.refresh();
        }

        public refresh() {
            let info = UI_Activity.getRankTaskInfo(this.taskId);
            if (!info || !info['achieved']) {
                let progress: number = info ? info['counter'] : 0;
                this.labelProgressText.visible = this.labelProgress.visible = true;
                this.btnGet.visible = false;
                this.getted.visible = false;
                this.labelProgress.text = progress + '/' + this.target;
            } else if (info['rewarded']) {
                this.labelProgressText.visible = this.labelProgress.visible = false;
                this.btnGet.visible = false;
                this.getted.visible = true;
            } else {
                this.getted.visible = false;
                this.btnGet.visible = true;
                this.labelProgressText.visible = this.labelProgress.visible = false;
            }
        }
    }

    export class UI_Activity_Richman_Task extends UIBase {
        public static Inst: UI_Activity_Richman_Task = null;
        public static activityId: number = 241202;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getRandomTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        return true;
                    }
                }
            }
            return false;
        }

        private root: Laya.Sprite;
        private bg: Laya.Image;
        private btnReceiveAll: Laya.Button;
        private bgBtn: Laya.Image;
        private labelBtn: Laya.Label;
        private listItem: Array<Item_Richman_Task>;

        private itemCount: number = 3;
        private currentTaskList: Array<game.ITaskProgress>;
        public locking: boolean;


        constructor() {
            super(new ui.lobby.activity_2412_richman.activity_2412_richman_taskUI);
            UI_Activity_Richman_Task.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            (this.me.getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            })
            this.listItem = [];
            for (let i = 0; i < this.itemCount; ++i) {
                this.listItem.push(new Item_Richman_Task(this.root.getChildByName('task').getChildAt(i) as Laya.Sprite, i));
            }
            this.btnReceiveAll = this.root.getChildByName('btn_receive_all') as Laya.Button;
            this.bgBtn = this.btnReceiveAll.getChildByName('bg') as Laya.Image;
            this.labelBtn = this.btnReceiveAll.getChildByName('info') as Laya.Label;
            (this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.btnReceiveAll.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.onReceiveAllBtnClick();
            });
         
        }

        public show() {
            this.refreshBtnState();
            this.currentTaskList = UI_Activity.getRandomTaskList(UI_Activity_Richman_Task.activityId);
            for (let i = 0; i < this.itemCount; ++i) {
                this.listItem[i].show(this.currentTaskList[i] ? this.currentTaskList[i]['id'] : 0);
            }
            this.enable = true;
            this.locking = true;
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 200);
          
            
        }

        public close() {
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
        }

        /**
         * 单领按钮
         * @param index 
         * @param id 
         * @param itemId 
         * @param itemCount 
         */
        public sendTaskCompleteRequest(index: number, id: number, itemId: number, itemCount: number) {
            if (this.isTaskDifferent()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(20211), true, Laya.Handler.create(this, () => { 
                    this.refreshAll();
                    UI_Activity_Richman.Inst.refreshRedPoints();
                }));
               
                return;
            }
            this.locking = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeRandomActivityTask, { task_id: id }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completeActivityTask, err, res);
                } else {
                    game.Tools.showRewards({ rewards: [{ id: itemId, count: itemCount }] }, null)
                    UI_Activity.onRandomTaskRewarded(id);
                    this.listItem[index].refresh();
                    this.refreshBtnState();
                    if (UI_Activity_Richman.Inst && UI_Activity_Richman.Inst.enable) {
                        UI_Activity_Richman.Inst.refreshRedPoints();
                    }
                }
            });
        }

        private refreshBtnState() {
            if (!UI_Activity_Richman_Task.haveRedPoint()) {
                // 按钮置灰且不能点
                this.labelBtn.color = '#ffffff';
                this.bgBtn.skin = game.Tools.localUISrc('myres/activity_yijidagong/pop_up_get_all_gray.png');
                this.btnReceiveAll.mouseEnabled = false;
            } else {
                this.btnReceiveAll.mouseEnabled = true;
                this.labelBtn.color = '#9a4021';
                this.bgBtn.skin = game.Tools.localUISrc('myres/activity_yijidagong/pop_up_get_all.png');
            }
        }
        private onReceiveAllBtnClick() {
            let list: Array<number> = [];
            let dataList = UI_Activity.getRandomTaskList(UI_Activity_Richman_Task.activityId);
            dataList.forEach((value) => {
                if (value['achieved'] && !value['rewarded']) {
                    list.push(value['id']);
                }
            });
            // if (list.length == 0) return;
            //判断任务列表是否有不同，如果不同则弹出提示窗口并刷新列表和红点
            if (this.isTaskDifferent()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(20211), true, Laya.Handler.create(this, () => {
                    this.refreshAll();
                    UI_Activity_Richman.Inst.refreshRedPoints();
                }));
                return;
            }
            this.locking = true;

            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completeRandomActivityTaskBatch, { task_list: list }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {

                    UIMgr.Inst.showNetReqError(game.ERequest.completeRandomActivityTaskBatch, err, res);
                } else {
                    let lst = [];
                    let rewardObj = {};
                    for (let id of list) {
                        UI_Activity.onRandomTaskRewarded(id);
                        let _data = UI_Activity_Task_Random.FindTaskInfo(id);
                        if (!_data || !_data.reward_count) continue;
                        let reward_id = _data.reward_id;
                        let reward_count = _data.reward_count;
                        if (!rewardObj[reward_id]) {
                            rewardObj[reward_id] = reward_count;
                        } else {
                            rewardObj[reward_id] += reward_count;
                        }
                    }
                    this.refreshBtnState();
                    this.refreshAll();
                    // this.jumpToCurrentIndex();
                    for (let key in rewardObj) {
                        lst.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: lst }, null);
                    if (UI_Activity_Richman.Inst && UI_Activity_Richman.Inst.enable) {
                        UI_Activity_Richman.Inst.refreshRedPoints();
                    }
                }
            })
        }

        // 刷新全部item
        private refreshAll() {
            for (let item of this.listItem) {
                item.refresh();
            }
        }

        /**
         * 当前页面的任务列表是否和服务器数据不一致
         * @returns 任务列表是否发生变化
         */
        private isTaskDifferent(): boolean { 
            let _list = UI_Activity.getRandomTaskList(UI_Activity_Richman_Task.activityId);
            if (_list.length != this.currentTaskList.length) return true;
            for (let i = 0; i < _list.length; ++i) {
                if (_list[i]['id'] != this.currentTaskList[i]['id']) return true;
            }
            return false;
        }
    }
}