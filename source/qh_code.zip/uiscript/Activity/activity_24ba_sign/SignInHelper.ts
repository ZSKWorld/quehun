module uiscript {

    class SignData {
        /**
         * 活动Id
         */
        activityId: number;
        /**
         * 签到次数
         */
        signInCount: number;
        /**
         * 上次签到的时间
         */
        signInLastTime: number;
    }

    export class SignInHelper {

        public static Inst: SignInHelper;
        /**
         * 服务器数据
         */
        private serverData;
        //是否进行了数据初始化
        private isInit = false;
        private signInDatas: Array<SignData> = new Array();


        constructor() {
            SignInHelper.Inst = this;

        }


        public init(data: any) {
            this.isInit = true;
            this.freshData(data);
            Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);
            
        }

        onActivityFinish(activityId: number) {
            let needRefresh = false;
            if (activityId == UI_Activity_Liandong_SignUp.activityId) {
                needRefresh = true;
                if (UI_Activity_Liandong_SignUp.Inst && UI_Activity_Liandong_SignUp.Inst.enable) {
                    UI_Activity_Liandong_SignUp.Inst.onActivityFinish();
                }
            }
            if (needRefresh && UI_Lobby.Inst && UI_Lobby.Inst.enable) {
                UI_Lobby.Inst.top.refresh();
            }
        }

        public freshData(data: any) {
            this.serverData = data;
        }

        /**
         * 获取对应活动的签到数量
         * @param activityId 活动ID
         * @returns 
         */
        public getSignInCount(activityId: number): number {
            if (!this.isInit) {
                return 0;
            }
            let signData = this.getSignData(activityId);
            return signData.signInCount;
        }

        /**
         * 获取对应活动的上次签到时间
         * @param activityId 活动ID
         * @returns 
         */
        public getSignInLastTime(activityId: number): number {
            if (!this.isInit) {
                return 0;
            }
            let signData = this.getSignData(activityId);
            return signData.signInLastTime;
        }

        /**
         * 设定对应活动的签到次数
         * @param activityId 活动id
         * @param count 签到次数
         */
        public setSignInCount(activityId: number, count: number) {
            if (!this.isInit) {
                return;
            }
            let signData = this.getSignData(activityId);
            signData.signInCount = count;

        }

        /**
         * 设定对应活动的上次签到时间
         * @param activityId 活动id
         * @param time 上次签到时间
         */
        public setSignInLastTime(activityId: number, time: number) {
            if (!this.isInit) {
                return;
            }
            let signData = this.getSignData(activityId);
            signData.signInLastTime = time;
        }


        /**
        * 是否需要弹出窗口
        * @param activityId 活动ID
        * @returns 
        */
        public needJump(activityId: number): boolean {
            if (!this.isInit) {
                return false;
            }
            //活动是否在进行
            if (!UI_Activity.activity_is_running(activityId)) return false;
            //表配置是否正确
            if (!cfg.activity.daily_sign) return false;
            let d_table = cfg.activity.daily_sign.getGroup(activityId);
            let signData = this.getSignData(activityId);
            //检测今日是否已经签到
            if (!d_table || signData.signInCount > d_table[d_table.length - 1].day) return false;
            //检测签到时间是否已经过了刷新时间
            let signed: boolean = game.Tools.isPassedRefreshTimeServer(signData.signInLastTime);
            return !signed;
        }

        private getSignData(activityId): SignData {
            let signData: SignData = null;
            for (let i = 0; i < this.signInDatas.length; i++) {
                let data = this.signInDatas[i];
                if (data.activityId == activityId) {
                    return data;
                }
            }
            //该活动还没有数据,添加一个活动数据
            signData = new SignData();
            signData.activityId = activityId;
            //检测服务器数据内是否有数据
            for (let i: number = 0; i < this.serverData.length; i++) {
                let data = this.serverData[i];
                if (data.activity_id == activityId) {
                    signData.signInCount = data.sign_in_count;
                    signData.signInLastTime = data.last_sign_in_time;
                    this.signInDatas.push(signData);
                    return signData;
                }
            }
            //服务器也没有数据
            signData.signInCount = 0;
            signData.signInLastTime = 0;
            this.signInDatas.push(signData);
            return signData;
        }





    }
}