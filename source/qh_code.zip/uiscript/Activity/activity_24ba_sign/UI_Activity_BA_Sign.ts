namespace uiscript {
    interface iCell {
        me: Laya.Image;
        day: Laya.Image;
        icon: Laya.Image;
        container_count: Laya.Sprite;
        count: Laya.Label;
        getted: Laya.Sprite;
        btn: Laya.Button;
    }

    export class UI_Activity_BA_Sign extends UIBase {
        public static Inst: UI_Activity_BA_Sign;
        public static activity_id: number = 240351;

        private confirmBtn: Laya.Button;
        private signBtn: Laya.Button;

        private dayLabel: Laya.Label;
        private dayLeft: Laya.Label;
        private dayRight: Laya.Label;
        private dayBg: Laya.Image;

        private copyRight1: Laya.Image;
        private copyRight2: Laya.Image;


        private locking: boolean = false;
        private cells: Array<iCell> = [];
        //特效的父物体
        private effectBase: Laya.Sprite;
        //特效的路径
        private effectPath: string = "scene/scene_24ba_sign_effect.ls";
        private effect: Laya.Scene;


        private timeAdapter1: common.SpriteAdapter;
        private timeAdapter2: common.SpriteAdapter;
        private timeAdapter3: common.SpriteAdapter;

        private showAnim: Laya.FrameAnimation;
        private hideAnim: Laya.FrameAnimation;

        private complete: Laya.Handler;

        constructor() {
            super(new ui.lobby.activity_24ba_sign.activity_24ba_sign_mainUI());
            UI_Activity_BA_Sign.Inst = this;
        }

        public onCreate(): void {

            let root = this.me.getChildByName("root") as Laya.Sprite;
            this.confirmBtn = root.getChildByName("btn_confirm") as Laya.Button;
            this.effectBase = this.confirmBtn.getChildByName("effect_parent") as Laya.Sprite;
            this.signBtn = root.getChildByName("btn_sign") as Laya.Button;
            let dayInfo = root.getChildByName("day") as Laya.Sprite;
            this.dayLabel = dayInfo.getChildByName("day") as Laya.Label;
            this.dayLeft = dayInfo.getChildByName("left") as Laya.Label;
            this.dayRight = dayInfo.getChildByName("right") as Laya.Label;
            this.dayBg = dayInfo.getChildByName("bg") as Laya.Image;

            this.copyRight1 = root.getChildByName("copyright1") as Laya.Image;
            this.copyRight2 = root.getChildByName("copyright2") as Laya.Image;

            this.showAnim = (this.me as ui.lobby.activity_24ba_sign.activity_24ba_sign_mainUI).ani1;
            this.hideAnim = (this.me as ui.lobby.activity_24ba_sign.activity_24ba_sign_mainUI).ani2;

            let cellParent = root.getChildByName("reward") as Laya.Sprite;
            let childCount = cellParent._childs.length;
            for (let index = 0; index < childCount; index++) {
                let i = index;
                let item: Laya.Sprite = cellParent.getChildByName('reward' + i) as Laya.Sprite;
                this.cells.push({
                    me: item as Laya.Image,
                    day: item.getChildByName('day_info') as Laya.Image,
                    icon: item.getChildByName('icon') as Laya.Image,
                    container_count: item.getChildByName('count') as Laya.Sprite,
                    count: item.getChildByName('count').getChildByName('count') as Laya.Label,
                    getted: item.getChildByName('done') as Laya.Sprite,
                    btn: item.getChildByName('btn') as Laya.Button
                });
            }


            this.timeAdapter1 = new common.SpriteAdapter(this.dayLabel, this.dayLeft, SpriteAdapterType.LEFT2RIGHT, -13);
            this.timeAdapter2 = new common.SpriteAdapter(this.dayRight, this.dayLabel, SpriteAdapterType.LEFT2RIGHT, -12);
            this.timeAdapter3 = new common.SpriteAdapter(this.dayBg, this.dayRight, SpriteAdapterType.RIGHTEXTEND, -28);
            this.timeAdapter1.fresh();
            this.timeAdapter2.fresh();
            this.timeAdapter3.fresh();

            //设置按钮的特效
            this.effect = Laya.loader.getRes(this.effectPath);
            root.addChild(this.effect);
            this.effect.visible = true;


            this.bindEvent();
            this.setCopyRight();
        }

        private bindEvent() {

            this.confirmBtn.clickHandler = new Laya.Handler(this, this.onClickConfirm);
            this.signBtn.clickHandler = new Laya.Handler(this, this.onClickSign);

        }

        private setCopyRight() {
            //如果是英文环境下的繁体，则版权标2显示为另一个copyright_catfood_en.png
            // console.log(`当前环境为${GameMgr.client_type},当前语言为${GameMgr.client_language}`);
            if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
                game.LoadMgr.setImgSkin(this.copyRight2, 'myres/activity_24ba_sign/copyright_catfood_en.png', null, 'UI_Activity_BA_Sign');
            }
            // if (GameMgr.client_language == 'jp') {
            //     console.log(this.copyRight1.x);
            //     this.copyRight1.x = 0;
            //     console.log(this.copyRight1.x);

            //     console.log("setCopyRight1~~~~~~~~~~~~~~~~~~~~~~~~");
            // }


        }





        public doShowAnimation(complete?: Laya.Handler) {
            this.enable = true;
            this.locking = true;
            this.freshPage();
            this.complete = complete;

            this.showAnim.play(0, false);
            Laya.timer.once(500, this, () => {
                this.locking = false;
            })
        }

        public doHideAnimation() {
            this.locking = true;
            this.showAnim.stop();
            this.hideAnim.play(0, false);
            Laya.timer.once(200, this, () => {
                this.locking = false;
                this.enable = false;
                if (this.complete) this.complete.run();
            })
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_BA_Sign', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_BA_Sign', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_24ba_sign.atlas'));
        }

        private onClickConfirm() {

            if (this.locking) {
                return;
            }
            this.doHideAnimation();
        }

        private onClickSign() {
            if (this.locking) {
                return;
            }

            //检测当前活动是否进行，如果未进行，弹出提示弹窗，并且关闭
            if (!UI_Activity.activity_is_running(UI_Activity_BA_Sign.activity_id)) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3732));
                UI_SecondConfirm.Inst.setBtnState(true, true);
                this.confirmBtn.visible = true;
                this.signBtn.visible = false;
                return;
            }

            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'doActivitySignIn', { activity_id: UI_Activity_BA_Sign.activity_id }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('doActivitySignIn', err, res);
                } else {
                    //更新本地的签到数据
                    SignInHelper.Inst.setSignInCount(UI_Activity_BA_Sign.activity_id, res.sign_in_count);
                    SignInHelper.Inst.setSignInLastTime(UI_Activity_BA_Sign.activity_id, game.Tools.getServerTime() / 1000);
                    //显示获取道具的弹窗
                    if (res.rewards && res.rewards.length > 0) {
                        let item_id: number = res.rewards[0].resource_id;
                        let count: number = res.rewards[0].count;
                        game.Tools.showRewards({ rewards: [{ id: item_id, count: count }] }, null);
                    }
                    this.freshPage();
                    let itemIndex = res.sign_in_count - 1;
                    Laya.Tween.to(this.cells[itemIndex].me, { scaleX: 1.1, scaleY: 1.1 }, 150, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
                        Laya.Tween.to(this.cells[itemIndex].me, { scaleX: 1, scaleY: 1 }, 150, Laya.Ease.strongIn);
                    }));
                }
            });
        }

        private freshPage() {
            //根据签到信息处理页面

            let signInCount = SignInHelper.Inst.getSignInCount(UI_Activity_BA_Sign.activity_id);
            let signInLastTime = SignInHelper.Inst.getSignInLastTime(UI_Activity_BA_Sign.activity_id);
            // 判断今日是否签到
            let signed: boolean = game.Tools.isPassedRefreshTimeServer(signInLastTime);
            //签到奖励，通用
            let signConfig = cfg.activity.daily_sign.getGroup(UI_Activity_BA_Sign.activity_id);
            if (!signConfig) return;
            if (signInCount > signConfig[signConfig.length - 1].day) {
                signed = true;
            }

            //根据是否签到显示对应的按钮
            this.confirmBtn.visible = signed;
            this.signBtn.visible = !signed;
            this.effect.visible = true;
            //获取当前签到日期
            this.dayLabel.text = signInCount.toString();
            for (let i: number = 0; i < this.cells.length; i++) {
                let c: iCell = this.cells[i];
                if (i < signConfig.length) {
                    //如果是货币的话
                    if (game.GameUtility.get_id_type(signConfig[i].reward_id) == game.EIDType.currency) {
                        let d_currency = cfg.item_definition.currency.get(signConfig[i].reward_id);
                        game.LoadMgr.setImgSkin(c.icon, d_currency.icon_jpg, null, 'UI_Activity_BA_Sign');
                    } else {
                        game.LoadMgr.setImgSkin(c.icon, game.GameUtility.get_item_view(signConfig[i].reward_id).icon, null, 'UI_Activity_BA_Sign');
                    }
                    c.count.text = 'x' + signConfig[i].reward_count.toString();
                    if (signConfig[i].day < signInCount) {
                        c.getted.visible = true;
                    } else {
                        c.getted.visible = false;
                    }
                    c.btn.clickHandler = Laya.Handler.create(this, () => {
                        if (this.locking) return;
                        UI_ItemDetail.Inst.show(signConfig[i].reward_id);
                    }, null, false);
                }
            }


        }




    }
}