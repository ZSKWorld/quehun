module uiscript {
    export class UI_Activity_HF_Page extends UIBase {
        constructor(me: Laya.Sprite) {
            super(me);
        }

        public root: Laya.Sprite;
        private btnReturn: Laya.Button;
        private txtTitle: Laya.Label;
        public aniShow: Laya.FrameAnimation;
        public aniHide: Laya.FrameAnimation;
        public charaId: number;

        public locking: boolean;

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.btnReturn = this.root.getChildByName('btn_back') as Laya.Button;
            this.txtTitle = this.root.getChildByName('bg').getChildByName('title') as Laya.Label;
            this.btnReturn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
        }

        public setTitle(str: string) {
            if (this.txtTitle) this.txtTitle.text = str;
        }

        public show(doAnim: boolean = true) {
            this.enable = true;
            if (doAnim) {
                this.aniShow.play(0, false);
                this.locking = true;
                Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                    this.locking = false;
                })
            } else {
                this.aniShow.gotoAndStop(this.aniShow.count);
            }
            UI_Activity_HF_Main.Inst.showSubpageBg(this.charaId, doAnim);
        }

        public hide(onClose?: Laya.Handler) {
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.enable = false;
                this.locking = false;
                onClose && onClose.run();
            })
            UI_Activity_HF_Main.Inst.hideSubpageBg();
            UI_Activity_HF_Main.Inst.refreshRedPoint();
        }
    }

    export class UI_Activity_HF_Chara extends UIBase {

        private static greetingMap: Object = {};

        private imgSkin: Laya.Image;
        private comChat: Laya.Sprite;
        private txtName: Laya.Label;
        private charaId: number;
        private comChara: Laya.Sprite;

        private charaInfo: any;
        private chat: UI_Character_Chat = null;

        private chatId: number = 0;
        private soundId: number = null;

        constructor(me: Laya.Sprite) {
            super(me);
        }

        public onCreate(): void {
            // 角色 
            this.comChara = this.me.getChildByName('illust') as Laya.Sprite;
            this.imgSkin = this.comChara.getChildByName('illust') as Laya.Image;
            this.comChat = this.me.getChildByName('chat') as Laya.Sprite;
            this.comChat.visible = false;
            this.chat = new UI_Character_Chat(this.comChat, false, 0);
            this.txtName = this.comChat.getChildByName('name') as Laya.Label;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.soundId) {
                    this.stopsay();
                } else {
                    this.say('lobby_normal');
                }
            }, null, false);
        }

        private say(type: string) {
            this.chatId++;
            let chatId = this.chatId;
            let soundInfo = view.AudioMgr.PlayCharactorSound(this.charaInfo, type, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    if (this.chatId == chatId) {
                        this.stopsay();
                    }
                });
            }));
            if (soundInfo) {
                this.chat.show(soundInfo.words);
                this.soundId = soundInfo.audio_id;
            }
        }

        public stopsay() {
            this.chat.close(false);
            if (this.soundId) {
                view.AudioMgr.StopAudio(this.soundId);
                this.soundId = null;
            }
        }

        public showCharacter(id: number) {
            this.me.visible = true;
            this.charaId = id;
            this.charaInfo = null;
            let data = cfg.item_definition.character.get(this.charaId);
            let skinConfig = cfg.item_definition.skin.get(data.init_skin);
            game.LoadMgr.setImgSkin(this.imgSkin, skinConfig.path + '/full.png', null, 'UI_Activity_HF_Main');
            for (let info of UI_Sushe.characters) {
                if (info.charid == this.charaId) {
                    this.charaInfo = info;
                    break;
                }
            }
            //获取立绘对应的位置
            let characterPos: Laya.Image = this.comChara.getChildByName("pos_" + id) as Laya.Image;
            this.imgSkin.x = characterPos.x;
            this.imgSkin.y = characterPos.y;

            if (!this.charaInfo) {
                this.charaInfo = { charid: this.charaId, level: 0, is_upgraded: false };
            }
            if (!UI_Activity_HF_Chara.greetingMap[id]) {
                UI_Activity_HF_Chara.greetingMap[id] = 1;
                this.say('lobby_playerlogin');
            }
            this.txtName.text = data['name_' + GameMgr.client_language];
        }

        public hideCharacter() {
            this.stopsay();
            this.me.visible = false;
        }

        public clearTween() {
            Laya.Tween.clearAll(this.chat.me);
        }
    }
}