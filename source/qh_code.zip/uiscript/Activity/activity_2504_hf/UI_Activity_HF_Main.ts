module uiscript {
    enum EHFPageName {
        simulation,
        match,
        spot,
        reward,
        task
    }
    export class UI_Activity_HF_Main extends UIBase {
        public static Inst: UI_Activity_HF_Main = null;
        public static activityId: number = 250401;
        public static currencyId: number = 30900078;
        public static ptId: number = 30900079;
        public static haveRedPoint() {
            if (uiscript.UI_Activity_HF_Spot.haveRedPoint()) return true;
            if (uiscript.UI_Activity_HF_Reward.haveRedPoint()) return true;
            if (uiscript.UI_Activity_HF_Task.haveRedPoint()) return true;
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2504hf.activity_25hfUI);
            UI_Activity_HF_Main.Inst = this;
        }

        private imgBg: Laya.Image;

        private pageMain: Laya.Sprite;
        private mainChara: UI_Activity_HF_Chara;
        private btnHelp: Laya.Button;
        private btnSpot: Laya.Button;
        private btnMatch: Laya.Button;
        private btnSimulation: Laya.Button;
        private imgCopyright: Laya.Image;
        private comMiddle: Laya.Sprite;

        private btnTask: Laya.Button;
        private btnReward: Laya.Button;
        private comPages: Laya.Sprite;
        private pageChara: UI_Activity_HF_Chara;
        private btnMask: Laya.Button;

        private btnReturn: Laya.Button;

        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniShowPage: Laya.FrameAnimation;
        private aniHidePage: Laya.FrameAnimation;
        private aniHideMain: Laya.FrameAnimation;
        private aniDeco1Show: Laya.FrameAnimation;
        private aniDeco1Loop: Laya.FrameAnimation;
        private aniDeco2Show: Laya.FrameAnimation;
        private aniDeco2Loop: Laya.FrameAnimation;
        private effectLogo: game.UIEffect;
        private effectBg: Laya.Scene;
        private effectMain: Laya.Sprite3D;
        private aniEffect: Catfood.CAnimator;

        private pages: UI_Activity_HF_Page[];
        private pageSimulation: UI_Simulation_Main;
        public locking: boolean;
        private audioId: number = 0;
        private bgmId: number = 0;
        private activityFinishHandler: Laya.Handler;
        private waitingShowYindao: boolean = false; // 首次剧情之后标记该值，下次进入打开引导
        private inMatch: boolean = false;
        public inSpot: boolean = false;

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.pageMain = this.me.getChildByName('main') as Laya.Sprite;
            this.comMiddle = this.pageMain.getChildByName('middle') as Laya.Sprite;
            this.mainChara = new UI_Activity_HF_Chara(this.pageMain.getChildByName('illust') as Laya.Sprite);
            this.btnHelp = this.pageMain.getChildByName('right').getChildByName('btn_help') as Laya.Button;
            this.btnSpot = this.pageMain.getChildByName('right').getChildByName('btn_spot') as Laya.Button;
            this.btnMatch = this.pageMain.getChildByName('bottom').getChildByName('btn_pk') as Laya.Button;
            this.btnSimulation = this.pageMain.getChildByName('bottom').getChildByName('btn_simulation') as Laya.Button;
            this.imgCopyright = this.pageMain.getChildByName('bottom').getChildByName('copyright') as Laya.Image;
            this.btnTask = this.pageMain.getChildByName('right').getChildByName('btn_task') as Laya.Button;
            this.btnReward = this.pageMain.getChildByName('right').getChildByName('btn_reward') as Laya.Button;

            this.comPages = this.me.getChildByName('pages') as Laya.Sprite;
            this.btnMask = this.comPages.getChildByName('btn_mask') as Laya.Button;
            this.pageChara = new UI_Activity_HF_Chara(this.comPages.getChildByName('illust') as Laya.Sprite);
            this.btnReturn = this.pageMain.getChildByName('btn_return') as Laya.Button;
            let comGame = this.me.getChildByName('match') as Laya.Sprite;
            this.pageSimulation = new UI_Simulation_Main(comGame);
            this.pages = [];
            this.pages.push(new UI_Activity_HF_Simulation());
            this.pages.push(new UI_Activity_HF_Match());
            this.pages.push(new UI_Activity_HF_Spot());
            this.pages.push(new UI_Activity_HF_Reward());
            this.pages.push(new UI_Activity_HF_Task());
            this.pages.forEach((value) => {
                this.comPages.addChild(value.me);
                value.enable = false;
            });
            this.btnMatch.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(EHFPageName.match, true);
            });
            this.btnSimulation.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (SimulationData.Inst.needFetch) {
                    SimulationData.Inst.fetchActivityInfo(Laya.Handler.create(this, () => {
                        this.showPage(EHFPageName.simulation, true);
                    }));
                } else {
                    this.showPage(EHFPageName.simulation, true);
                }
            });
            this.btnSpot.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(EHFPageName.spot, true);
            });
            this.btnReward.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(EHFPageName.reward, true);
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(EHFPageName.task, true);
            });
            this.btnReturn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.pageMain.visible) {
                    this.hide();
                } else {
                    this.pages.forEach((value) => {
                        if (value.enable) {
                            value.hide();
                        }
                    });
                }
            });
            this.btnHelp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showGuide();
            }, null, false);
            this.aniShow = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).hide;
            this.aniShowPage = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).showpage;
            this.aniHidePage = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).hidepage;
            this.aniHideMain = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).hidemain;
            this.aniDeco1Show = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).show_tb1;
            this.aniDeco1Loop = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).idle_tb1;
            this.aniDeco2Show = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).show_tb2;
            this.aniDeco2Loop = (this.me as ui.lobby.activity_2504hf.activity_25hfUI).idle_tb2;
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            if (GameMgr.client_type == 'en' && GameMgr.client_language == 'chs_t') {
                (this.pageMain.getChildByName('bottom').getChildByName('copyright') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_simulation/copyright_en.png');
            }
            if (GameMgr.client_type == 'en' || GameMgr.client_type == 'kr') {
                (this.pageMain.getChildByName('bottom').getChildByName('copyright') as Laya.Image).scale(1.33, 1.33);
            }
            app.NetAgent.addListener2Lobby('NotifyMatchGameStart', Laya.Handler.create(this, (msg) => {
                if (this.enable) {
                    GameMgr.Inst.in_activity = true;
                    this.inMatch = true;
                }
            }));
            game.LoadMgr.setImgSkin(this.btnMask.getChildAt(0) as Laya.Image, 'myres/activity_simulation/universal_cover.png', null, 'UI_Activity_HF_Main');
            let txtTime = this.pageMain.getChildByName('middle').getChildByName('time') as Laya.Label;
            (this.pageMain.getChildByName('middle').getChildByName('right') as Laya.Image).x = txtTime.x + txtTime.trueWidth / 2 + 40;
            (this.pageMain.getChildByName('middle').getChildByName('left') as Laya.Image).x = txtTime.x - txtTime.trueWidth / 2 - 40;
        }

        refreshRedPoint() {
            (this.btnSpot.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_HF_Spot.haveRedPoint();
            (this.btnTask.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_HF_Task.haveRedPoint();
            (this.btnReward.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_HF_Reward.haveRedPoint();
        }

        public showGuide() {
            UI_Liandong_Rules.Inst.show(E_Liandong_Rules_Style.Main);
        }

        showSpot() {
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.HF_Yindao_Checked, 1);
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_HF_Spot.activityId);
            const spotData = datas[0];
            GameMgr.Inst.showSpotByEvent(spotData.content_path, spotData.story_id, Laya.Handler.create(this, () => {
                if (UI_Activity.activities[UI_Activity_HF_Main.activityId]) {
                    GameMgr.Inst.enterActivityScene();
                } else {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437));
                    GameMgr.Inst.EnterLobby();
                }
            }), UI_Activity_HF_Spot.activityId, Laya.Handler.create(this, () => {
                UI_Activity_HF_Main.Inst.enable = false;
                view.AudioMgr.StopMusic(0);
            }, null, false));
        }

        showPage(page: EHFPageName, doAnim: boolean = true) {
            this.aniShow.stop();
            this.aniHideMain.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHideMain.count * this.aniHideMain.interval, this, () => {
                this.locking = false;
                if (page == EHFPageName.match) UI_Activity_HF_Match.Inst.show();
                if (page == EHFPageName.simulation) UI_Activity_HF_Simulation.Inst.show();
                if (page == EHFPageName.reward) UI_Activity_HF_Reward.Inst.show();
                if (page == EHFPageName.task) UI_Activity_HF_Task.Inst.show();
                if (page == EHFPageName.spot) UI_Activity_HF_Spot.Inst.show();
            })
        }

        public showSubpageBg(charaId: number, anim: boolean = true) {
            this.aniHideMain.gotoAndStop(this.aniHideMain.count);
            this.mainChara.stopsay();
            if (charaId) {
                this.pageChara.showCharacter(charaId);
                this.btnMask.visible = true;
            } else {
                this.pageChara.hideCharacter();
                this.btnMask.visible = false;
            }
            if (anim) {
                view.AudioMgr.PlayAudio(10316);
                this.locking = true;
                this.comPages.visible = true;
                this.aniShowPage.play(0, false);
                Laya.timer.once(this.aniShowPage.count * this.aniShowPage.interval, this, () => {
                    this.pageMain.visible = false;
                    this.locking = false;
                });
            } else {
                this.comPages.visible = true;
                this.pageMain.visible = false;
                this.aniShowPage.gotoAndStop(this.aniShowPage.count);
            }
        }

        public hideSubpageBg(anim: boolean = true) {
            if (anim) {
                // view.AudioMgr.PlayAudio(10173);
                this.pageMain.visible = true;
                this.aniHidePage.play(0, false);
                this.locking = true;
                Laya.timer.once(this.aniHidePage.count * this.aniHidePage.interval, this, () => {
                    this.locking = false;
                    this.pageChara.hideCharacter();
                    this.comPages.visible = false;
                });
            } else {
                this.comPages.visible = false;
                this.pageMain.visible = true;
                this.aniHidePage.gotoAndStop(this.aniHidePage.count);
                this.pageChara.hideCharacter();
            }
        }

        public show() {
            this.enable = true;
            this.effectMain.active = true;
            this.aniEffect.Play('bg_eff');
            this.refreshBtnAnim();
            view.AudioMgr.StopMusic(0);
            this.playBgm();
            if (this.inMatch) {
                this.inMatch = false;
                UI_Activity_HF_Match.Inst.show();
                return;
            }
            if (this.inSpot) {
                this.inSpot = false;
                UI_Activity_HF_Spot.Inst.show();
                return;
            }
            this.hideSubpageBg(false);
            const charaId = 20000108 + Math.floor(Math.random() * 4);
            this.mainChara.showCharacter(charaId);
            this.locking = true;
            this.aniShow.gotoAndStop(0);
            this.aniShow.play(0, false);
            Laya.timer.once(1000, this, () => {
                this.locking = false;
            });
            this.refreshRedPoint();
            if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.HF_Yindao_Checked)) {
                this.waitingShowYindao = true;
                this.showSpot();
                return;
            }
            if (this.waitingShowYindao) {
                this.waitingShowYindao = false;
                this.showGuide();
                return;
            }
            this.effectLogo = game.FrontEffect.Inst.create_ui_effect(this.comMiddle, 'scene/effect_simulation_logo.lh', new Laya.Point(500, 310), 1);
            view.AudioMgr.PlayAudio(10315);
        }

        public hide() {
            this.locking = true;
            this.pages.forEach((value) => {
                if (value.enable) {
                    value.hide();
                }
            });
            this.aniHide.play(0, false);
            this.mainChara.stopsay();
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                GameMgr.Inst.EnterLobby();
                this.locking = false;
                this.enable = false;
            });
        }

        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
                this.bgmId = 0;
            }
        }

        public playBgm(audioId: number = 10313) {
            if (view.AudioMgr.musicMuted) return;
            if (this.bgmId == audioId) {
                return;
            }
            this.stopBgm();
            let audioPath = cfg.audio.audio.get(audioId).path;
            let volume = view.AudioMgr.musicVolume;
            this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);
            if (this.audioId > 0) {
                this.bgmId = audioId;
            }
        }

        private refreshBtnAnim() {
            this.aniDeco1Show.play(0, false);
            this.aniDeco2Show.play(0, false);
            Laya.timer.once(this.aniDeco1Show.count * this.aniDeco1Show.interval, this, () => {
                this.aniDeco1Loop.play(0, true);
            });
            Laya.timer.once(this.aniDeco2Show.count * this.aniDeco2Show.interval, this, () => {
                this.aniDeco2Loop.play(0, true);
            })
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_HF_Main', false);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            this.stopBgm();
            this.mainChara.stopsay();
            this.hideSubpageBg(false);
            this.pages.forEach((value) => {
                value.enable = false;
            });
            this.pageSimulation.enable = false;
            if (this.effectLogo) {
                this.effectLogo.destory();
                this.effectLogo = null;
            }
            this.effectBg.visible = false;
            Laya.timer.clearAll(this);
            this.aniDeco1Show.stop();
            this.aniDeco2Show.stop();
            this.aniDeco1Loop.stop();
            this.aniDeco2Loop.stop();
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_HF_Main', true);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            this.pageSimulation.enable = false;
            this.effectBg.visible = true;
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_HF_Main.activityId) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.hide();
                        }))
                        return;
                    }
                }
            }
        }

        setBg(url: string) {
            this.imgBg.skin = game.Tools.localUISrc(url);
        }

        enterMatch() {
            this.pages.forEach((value) => {
                value.enable = false;
            });
            this.comPages.visible = false;
            this.effectMain.active = false;
            this.pageChara.stopsay();
        }

        quitMatch() {
            UI_Simulation_Main.Inst.enable = false;
            UI_Activity_HF_Simulation.Inst.show();
            this.effectMain.active = true;
            this.playBgm();
        }

        initEffect() {
            this.effectBg = Laya.loader.getRes('scene/effect_simulation_bg.ls');
            if (this.effectBg._childs != null) {
                for (let i: number = 1; i < this.effectBg._childs.length; i++) {
                    game.EffectMgr.dfsCompileShader(this.effectBg, this.effectBg._childs[i]);
                }
            }
            this.imgBg.addChild(this.effectBg);
            this.effectBg.visible = false;
            this.effectMain = this.effectBg.getChildByName('main') as Laya.Sprite3D;
            this.aniEffect = (this.effectMain.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            UI_Simulation_Train.Inst.initEffect(this.effectBg);
            UI_Simulation_Match.Inst.initEffect(this.effectBg);
            UI_Simulation_Game_End.Inst.initEffect(this.effectBg);
            UI_Simulation_Event.Inst.initEffect();
            UI_Simulation_Match_Start.Inst.initEffect(this.effectBg);
        }

        destroyEffect() {
            this.effectBg.destroy(true);
            UI_Simulation_Event.Inst.destroyEffect();
            UI_Simulation_Match_Start.Inst.destroyEffect();
        }
    }
}