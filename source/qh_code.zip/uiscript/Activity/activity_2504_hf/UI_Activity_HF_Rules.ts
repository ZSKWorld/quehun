/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_HF_Rules extends UI_PopupBase {
        public static Inst: UI_Activity_HF_Rules;
        constructor() {
            super(new ui.lobby.simulation.simulation_ruleUI());
            UI_Activity_HF_Rules.Inst = this;
        }

        private bg: Laya.Button;
        private rootBg: Laya.Image;
        private img: Laya.Image;
        private btnLeft: Laya.Button;
        private btnRight: Laya.Button;
        private comTitle: Laya.Sprite;
        private txtEventTitle: Laya.Label;
        private txtPage: Laya.Label;
        private onClose: Laya.Handler;
        private pageCount: number = 4;
        private pageIndex: number = 0;

        public onCreate() {
            super.onCreate();
            this.outClose = false;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.comTitle = this.root.getChildByName('title') as Laya.Sprite;
            this.txtEventTitle = this.comTitle.getChildByName('title') as Laya.Label;
            this.txtPage = this.root.getChildByName('page') as Laya.Label;
            this.bg = this.me.getChildByName('btn_mask') as Laya.Button;
            this.rootBg = this.root.getChildByName('bg') as Laya.Image;
            this.img = this.root.getChildByName('img') as Laya.Image;
            this.btnLeft = this.root.getChildByName('btn_left') as Laya.Button;
            this.btnRight = this.root.getChildByName('btn_right') as Laya.Button;
            this.btnLeft.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(this.pageIndex - 1);
            });
            this.btnRight.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(this.pageIndex + 1);
            });
            let imgBg = this.bg.getChildAt(0) as Laya.Image;
            game.LoadMgr.setImgSkin(imgBg, 'myres/activity_simulation/universal_cover.png', null, 'UI_Activity_HF_Main');
            this.bg.alpha = 1;
        }

        public show(onClose: Laya.Handler) {
            this.locking = true;
            this.enable = true;
            this.me.alpha = 0;
            Laya.Tween.to(this.me, { alpha: 1 }, 150, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.onClose = onClose;
            this.showPage(0);
        }

        public hide() {
            this.locking = true;
            Laya.Tween.to(this.me, { alpha: 0 }, 150, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                this.onClose && this.onClose.run();
                this.locking = false;
                this.enable = false;
            }));
        }

        private showPage(index: number) {
            if (index < 0 || index >= this.pageCount) return;
            this.pageIndex = index;
            this.btnLeft.visible = index != 0;
            this.btnRight.visible = index != this.pageCount - 1;
            this.setCloseBtnVisible(index == this.pageCount - 1);
            game.LoadMgr.setImgSkin(this.img, `myres/activity_simulation/${index + 1}.png`, null, 'UI_Activity_HF_Rules');
            this.txtEventTitle.text = game.Tools.strOfLocalization(25040520 + index);
            (this.comTitle.getChildByName('right') as Laya.Image).x = 368 + this.txtEventTitle.trueWidth / 2 + 40;
            (this.comTitle.getChildByName('left') as Laya.Image).x = 368 - this.txtEventTitle.trueWidth / 2 - 40;
            this.txtPage.text = '(' + (index + 1) + '/' + this.pageCount + ')';
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_HF_Rules', false);

        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_HF_Rules', true);
        }

    }
}