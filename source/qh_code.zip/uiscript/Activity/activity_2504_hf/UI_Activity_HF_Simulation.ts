/**
* name 
*/
module uiscript {
	enum ESimulationHomePage {
		none,
		home,
		strengthen,
		rank
	}
	export class UI_Activity_HF_Simulation extends UI_Activity_HF_Page {
		public static Inst: UI_Activity_HF_Simulation = null;
		private btnHelp: Laya.Button;
		private haveOldGameRecord: boolean;
		public locking: boolean;
		private enterTime: string;
		private tabButtons: Array<HF_TabButton>;
		private btnStart: Laya.Button;
		private btnRestart: Laya.Button;
		private comStrengthen: UI_Simulation_Strengthen;
		private comHome: Laya.Sprite;
		private aniShowStrengthen: Laya.FrameAnimation;
		private aniShowMain: Laya.FrameAnimation;
		private aniDecoShow: Laya.FrameAnimation;
		private aniDecoIdle: Laya.FrameAnimation;
		private pageIndex: ESimulationHomePage = ESimulationHomePage.none;

		constructor() {
			super(new ui.lobby.activity_2504hf.activity_25hf_simulationUI());
			UI_Activity_HF_Simulation.Inst = this;
		}

		public onCreate() {
			super.onCreate();
			this.comHome = this.root.getChildByName('home') as Laya.Sprite;
			this.comStrengthen = new UI_Simulation_Strengthen(this.root.getChildByName('strengthen') as Laya.Sprite);
			this.btnHelp = this.root.getChildByName('help') as Laya.Button;

			this.btnStart = this.comHome.getChildByName('start') as Laya.Button;
			this.btnRestart = this.comHome.getChildByName('restart') as Laya.Button;
			this.tabButtons = [];
			let tabName = ['home', 'strengthen'];
			for (let i = 0; i < tabName.length; i++) {
				let btn = this.root.getChildByName('tabs').getChildByName(tabName[i]) as Laya.Button;
				this.tabButtons.push(new HF_TabButton(btn, '#ffffff', '#fffcea'));
				btn.clickHandler = new Laya.Handler(this, () => {
					if (this.locking) return;
					this.onTabSelected(i + 1, true);
				}, null, false);
			}
			this._initFunc();
			this.aniShow = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).show;
			this.aniHide = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).hide;
			this.aniShowStrengthen = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).showstrengthen;
			this.aniShowMain = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).showpage;
			this.aniDecoShow = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).show_tb;
			this.aniDecoIdle = (this.me as ui.lobby.activity_2504hf.activity_25hf_simulationUI).idle_tb;
			this.charaId = 20000110;
		}


		private _initFunc() {
			this.btnStart.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.enterToGame();
				if (this.haveOldGameRecord) {
					UI_Simulation_Main.Inst.startGame();
				} else {
					SimulationData.Inst.startSeason();
				}
			}, null, false);
			this.btnRestart.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20003), Laya.Handler.create(this, () => {
					SimulationData.Inst.giveUp();
				}));
				UI_SecondConfirm.Inst.setBtnState(true, true);
			}, null, false);
			this.btnHelp.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_Activity_HF_Rules.Inst.show(Laya.Handler.create(this, () => {
					UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25040022));
				}));
			}, null, false);
			SimulationData.Inst.on(ESimulationEvent.GiveUp, this, this.refreshStartBtn);
		}

		private onTabSelected(i: ESimulationHomePage, doAnim: boolean = false) {
			if (this.pageIndex == i) return;
			this.pageIndex = i;
			this.comStrengthen.hide();
			this.comHome.visible = false;
			if (i == ESimulationHomePage.home) {
				this.comHome.visible = true;
				if (doAnim) this.aniShowMain.play(0, false);
				this.aniDecoShow.play(0, false);
				Laya.timer.once(this.aniDecoShow.count * this.aniDecoShow.interval, this, () => {
					this.aniDecoShow.stop();
					this.aniDecoIdle.play(0, true);
				})
			} else if (i == ESimulationHomePage.strengthen) {
				Laya.timer.clearAll(this);
				this.aniDecoShow.stop();
				this.aniDecoIdle.stop();
				this.comStrengthen.show();
				if (doAnim) this.aniShowStrengthen.play(0, false);
			}
			this.tabButtons.forEach((btn, index) => {
				if (i - 1 == index) {
					btn.onSelect();
				} else {
					btn.onDeselect();
				}
			})
		}

		public refreshRedPoint() {
			(this.tabButtons[ESimulationHomePage.strengthen - 1].me.getChildByName('red_point') as Laya.Image).visible = UI_Simulation_Strengthen.haveRedPoint();
		}

		public enterToGame() {
			if (this.enterTime && game.Tools.isPassedRefreshTimeServer(Number(this.enterTime) / 1000)) return;
			game.LocalStorage.setItem('activityEveryDay' + UI_Simulation_Main.activityId + GameMgr.Inst.account_id, game.Tools.getServerTime().toString());
			this.enterTime = game.Tools.getServerTime().toString();
			app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: [UI_Simulation_Main.activityId] }, (err, res) => {
			});
		}

		public showGuide() {
			let extraConfig: IRuleExtraConfig = {
				onClose: Laya.Handler.create(this, () => {
					UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25040022));
					game.LocalStorage.setItem('activityGuide' + UI_Simulation_Main.activityId + GameMgr.Inst.account_id, game.Tools.getServerTime().toString());
				})
			}
			UI_Liandong_Rules.Inst.show(E_Liandong_Rules_Style.Main, extraConfig);
		}

		public show(doAnim: boolean = true) {
			super.show(doAnim);
			this.pageIndex = ESimulationHomePage.none;
			this.enterTime = game.LocalStorage.getItem('activityEveryDay' + UI_Simulation_Main.activityId + GameMgr.Inst.account_id);
			this.refreshRedPoint();
			this.refreshStartBtn();
			this.onTabSelected(ESimulationHomePage.home);
		}

		refreshStartBtn() {
			this.haveOldGameRecord = !!SimulationData.Inst.nowStage && !SimulationData.Inst.gameEndData;
			this.btnRestart.visible = this.haveOldGameRecord;
			(this.btnStart.getChildByName('title') as Laya.Label).text = this.haveOldGameRecord ? game.Tools.strOfLocalization(20002) : game.Tools.strOfLocalization(20001);
		}


		hide(onClose: Laya.Handler) {
			if (this.comStrengthen.isChanged) {
				this.comStrengthen.checkChanged(Laya.Handler.create(this, () => {
					super.hide(onClose);
				}));
			} else {
				super.hide(onClose);
			}
		}

		public onDisable(): void {
			this.aniDecoShow.stop();
			this.aniDecoIdle.stop();
			Laya.timer.clearAll(this);
			this.comStrengthen.enable = false;
		}

	}
}