module uiscript {
    class CellSpot {
        private imgBg: Laya.Image;
        private txtSpotTitle: Laya.Label;
        private txtTitle: Laya.Label;
        private imgRedPoint: Laya.Sprite;
        private comPlay: Laya.Sprite;
        private btnPlay: Laya.Button;
        private comLock: Laya.Sprite;
        private txtLock: Laya.Label;
        private spotData: lqc.Sheet_Activity_StoryActivity;
        private locking: boolean;

        public constructor(me: Laya.Sprite, data: lqc.Sheet_Activity_StoryActivity) {
            this.imgBg = me.getChildByName('bg') as Laya.Image;
            this.comLock = me.getChildByName('locked') as Laya.Sprite;
            this.txtLock = this.comLock.getChildByName('time') as Laya.Label;
            this.txtSpotTitle = me.getChildByName('spot_title') as Laya.Label;
            this.txtTitle = me.getChildByName('title') as Laya.Label;
            this.imgRedPoint = me.getChildByName('redpoint') as Laya.Sprite;
            this.comPlay = me.getChildByName('play') as Laya.Sprite;
            this.btnPlay = this.comPlay.getChildByName('play') as Laya.Button;
            this.spotData = data;
            this.txtTitle.text = game.Tools.eventStrOfLocalization(this.spotData.subtitle_title);
            this.btnPlay.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                let serverUnlockData = game.ActivityStoryDataHelper.getStoryData(UI_Activity_HF_Spot.activityId, this.spotData.story_id);
                if (!serverUnlockData) {
                    this.locking = true;
                    let req: game.IReqStoryActivityUnlock = {
                        activity_id: UI_Activity_HF_Spot.activityId,
                        story_id: this.spotData.story_id
                    };
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.storyActivityUnlock, req, (err, res: game.IResCommon) => {
                        this.locking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.storyActivityUnlock, err, res);
                        } else {
                            this.showSpot();
                        }
                    });
                } else {
                    this.showSpot();
                }
            }, null, false);
        }

        public setRedPoint(visible: boolean) {
            this.imgRedPoint.visible = visible;
        }

        public get isLocked(): boolean {
            return this.comLock.visible;
        }

        public show() {
            if (!this.spotData) return;
            // TODO 判定是否解锁，时间判定
            let locked = false;
            if (this.spotData.unlock_day) {
                let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_HF_Spot.activityId);
                let restSeconds = this.spotData.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                if (restSeconds > 0) {
                    locked = true;
                }
            }
            this.comPlay.visible = !locked;
            this.comLock.visible = locked;
            if (locked) {
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_HF_Spot.activityId, this.spotData.unlock_day);
                this.txtLock.text = game.Tools.getLockTimeText1(restSeconds);
            }
            this.txtSpotTitle.text = locked ? game.Tools.strOfLocalization(25040515) : game.Tools.eventStrOfLocalization(this.spotData.title);
        }

        private showSpot() {
            GameMgr.Inst.showSpotByEvent(this.spotData.content_path, this.spotData.story_id, Laya.Handler.create(this, () => {
                if (UI_Activity.activities[UI_Activity_HF_Main.activityId]) {
                    GameMgr.Inst.enterActivityScene();
                    UI_Activity_HF_Main.Inst.inSpot = true;
                } else {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437));
                    GameMgr.Inst.EnterLobby();
                }
            }), UI_Activity_HF_Spot.activityId, Laya.Handler.create(this, () => {
                UI_Activity_HF_Main.Inst.enable = false;
                view.AudioMgr.StopMusic(0);
            }, null, false));
        }
    }

    export class UI_Activity_HF_Spot extends UI_Activity_HF_Page {
        public static activityId: number = 250405;
        public static Inst: UI_Activity_HF_Spot;
        public static haveRedPoint(): boolean {
            let showIndex = Math.max(1, Number(Laya.LocalStorage.getItem(game.Tools.eeesss('25hf_spot' + GameMgr.Inst.account_id))));
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_HF_Spot.activityId);
            for (let i = 0; i < datas.length; i++) {
                let spotData = datas[i];
                if (spotData && spotData.unlock_day) {
                    let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_HF_Spot.activityId);
                    let restSeconds = spotData.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                    if (restSeconds <= 0 && i != 0 && showIndex <= i) {
                        return true;
                    }
                }
            }
            return false;
        }

        private cells: Array<CellSpot> = [];
        constructor() {
            super(new ui.lobby.activity_2504hf.activity_25hf_spotUI());
            UI_Activity_HF_Spot.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_HF_Spot.activityId);
            let comSpot = this.root.getChildByName('spots') as Laya.Sprite;
            comSpot._childs.forEach((child, index) => {
                child.visible = index < datas.length
            })
            for (let i = 0; i < datas.length; i++) {
                this.cells.push(new CellSpot(comSpot.getChildByName('' + i) as Laya.Sprite, datas[i]));
            }
            this.aniShow = (this.me as ui.lobby.activity_2504hf.activity_25hf_spotUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2504hf.activity_25hf_spotUI).hide;
            this.charaId = 20000111;
        }

        public show(doAnim: boolean = true) {
            super.show(doAnim);
            let index = 0;
            let have_lock = false;
            let show_index = Math.max(1, Number(Laya.LocalStorage.getItem(game.Tools.eeesss('25hf_spot' + GameMgr.Inst.account_id))));
            let datas = cfg.activity.story_activity.getGroup(UI_Activity_HF_Spot.activityId);
            for (let cell of this.cells) {
                cell.show();
                cell.setRedPoint(index != 0 && show_index <= index && !cell.isLocked);
                if (!have_lock) {
                    if (cell.isLocked) {
                        have_lock = true;
                        Laya.LocalStorage.setItem(game.Tools.eeesss('25hf_spot' + GameMgr.Inst.account_id), '' + index);
                    } else if (index == (datas.length - 1)) {
                        Laya.LocalStorage.setItem(game.Tools.eeesss('25hf_spot' + GameMgr.Inst.account_id), '' + datas.length);
                    }
                }
                index++;
            }
        }

        public hide() {
            super.hide();
        }

    }
}