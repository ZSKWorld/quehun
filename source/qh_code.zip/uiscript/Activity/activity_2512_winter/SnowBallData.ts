module uiscript {
    export const enum SnowBallDataEvent {
        GameStart = "GameStart",
        RoundStart = "RoundStart",
        RoundEnd = "RoundEnd",
        DoAction = "DoAction",
        UpdateState = "UpdateState",
        PrepareEnd = "PrepareEnd"
    }

    export enum ESnowBallPlayerType {
        player = 0,
        boss = 1,
    }

    export interface IActivitySnowballAttackedInfo {
        /** 雪球id */
        ball_id: number;
        /** 轨道 */
        track: number;
        /** 伤害 */
        damage: number;
        /** 是否暴击 */
        critical: boolean;
    }

    export interface IActivitySnowballThrowInfo {
        /** 雪球id */
        ball_id: number;
        /** 是否暴击 */
        critical: boolean;
        /** 轨道 */
        track: number;
        damage: number;
        active: boolean;
    }

    export interface IActivitySnowballCDInfo {
        track: number;
        value: number;
    }

    export interface IActivitySnowballPlayerState {
        mp_change?: number;
        hp_change?: number;
    }

    export interface IActivitySnowballBallActionInfo {
        track: number;
        /** 相撞的雪球信息 */
        balls_id: number[];
        /** 如果是暴击，则第二个雪球不消失 */
        isCrit: boolean;
    }

    export interface IActivitySnowballWaveInfo {
        track: number;
        /** 操作序号 */
        operateIndex: number;
        cd: number;
    }

    export enum ESnowBallEventType {
        mp = 0,
        wave = 1,
        hit = 2,
        throw = 3,
        offset = 4,
    }

    export interface IActivitySnowballEvent {
        tick: number;
        /** 0: 蓝量变化 1-击中目标 2-发射雪球 3-雪球相撞  */
        type: ESnowBallEventType;
        player?: ESnowBallPlayerType;
        /** 受击信息 */
        player_attacked?: IActivitySnowballAttackedInfo;
        /** 操作信息 */
        throw_action?: IActivitySnowballThrowInfo;
        /** 雪球信息 */
        ball_action?: IActivitySnowballBallActionInfo;
        state_change?: IActivitySnowballPlayerState;
        wave_action?: IActivitySnowballWaveInfo;
    }

    export interface ISnowBallWeaponInfo {
        fly_time: number;
        damage: number;
        mp_consume: number;
        cd: number;
        count: number;
        track: number;
        locked: boolean;
    }

    export enum ESBFlyState {
        fly,
        start,
        offset,
        hit,
        break
    }

    export interface ISnowBallFlyItem {
        id: number;
        /** 初始tick */
        init_tick: number;
        /** 方向 1：向玩家 2：向boss */
        target: ESnowBallPlayerType;
        /** 0：继续飞行 1: 开始飞行 2:飞行中途碰撞抵消 3：飞到目标碰撞消失 */
        state: ESBFlyState;
        /** 轨道 */
        track: number; //轨道低中高1, 2, 3
        active: boolean;
        crit: boolean;
    }

    export interface ISnowBallPlayerState {
        hp: number;
        mp: number;
    }

    export interface ISnowBallTickInfo {
        tick: number;
        fly_item_list: ISnowBallFlyItem[];
        /** 1-玩家 2-boss */
        players: ISnowBallPlayerState[];
        events: IActivitySnowballEvent[];
        skillCD: number[]
    }

    export interface ISnowBallOffsetInfo {
        ballId: number;
        initTick: number;
    }

    export enum ESnowBallResultType {
        none,
        playerWin,
        bossWin,
        timeOut,
        allDie
    }

    export class SnowBallData extends Laya.EventDispatcher {
        private static _inst: SnowBallData;
        static get Inst() { return this._inst || (this._inst = new SnowBallData()); }

        public activityId: number = 251201;
        public baseConfig: lqc.Sheet_Snowball_SnowballActivity;
        public roundConfig: basic.Dictionary<number, lqc.Sheet_Snowball_SnowballMonsterGroup>;
        public attackConfig: basic.Dictionary<number, lqc.Sheet_Snowball_SnowballAttackGroup>;
        public buffConfig: basic.Dictionary<number, lqc.Sheet_Snowball_PlayerSnowballBuff>;
        public rewardData: { rewarded_level: number[], finished_level: number[] } = { rewarded_level: [], finished_level: [] };
        public upgradeData: lqc.Sheet_Snowball_PlayerSnowballBuff[] = [];
        public weaponInfo: ISnowBallWeaponInfo[] = [];
        public inited: boolean = false;
        public currencyId: number;

        public oneTickTime: number = 1 / 30;
        public ticks: number = 0;
        public nowLevel: number = 1;
        public tickInfo: ISnowBallTickInfo;
        public initStates: ISnowBallPlayerState[];
        public battleId: string;
        public nowTick: number;
        public ballUID: number = 0;
        public operateIndex: number = 0;
        public events: IActivitySnowballEvent[];
        public nextIndex: number;
        public nowTickTime: number;
        public stopTime: number;
        public costTime: number;
        public isEnd: boolean;
        public random: SnowballRandom;
        public comboCount: number = 0;
        public tempComboCount: number = 0;
        private nextBall: number = 0;
        public passGameCount: number = 0;

        public timer: Laya.Timer;
        public tweenMgr: UI_TweenManager;
        private _speed: number = 1;
        private _autoAttack: boolean = false;
        private tickDelay: number = 0;
        private isPause: boolean = false;
        private trueMP: number;

        private playerAction: game.IActivitySnowballPlayerAction[] = [];// 结束游戏后校验用
        private extraData: game.IReqSnowballActivityFinishBattle_BattleFinishedDebug[] = [];// 结束游戏后debug校验用

        public gaming: boolean;
        public locking: boolean;
        public lockNetwork: boolean;
        public resultType: ESnowBallResultType;

        constructor() {
            super();
            if (!cfg.snowball || !cfg.snowball.snowball_activity) return;
            this.inited = true;
            this.baseConfig = cfg.snowball.snowball_activity.get(this.activityId);
            this.oneTickTime = 1 / this.baseConfig.tick;
            this.currencyId = this.baseConfig.skill_item;
            this.roundConfig = new basic.Dictionary();
            let monster_group = cfg.snowball.snowball_monster_group.getGroup(this.baseConfig.monster_group);
            monster_group.forEach((value) => {
                this.roundConfig.set(value.level, value);
            });
            this.attackConfig = new basic.Dictionary();
            let attack_group = cfg.snowball.snowball_attack_group.getGroup(this.baseConfig.player_attack_group);
            attack_group.forEach((value) => {
                this.attackConfig.set(value.track, value);
            });
            this.buffConfig = new basic.Dictionary();
            let buff_group = cfg.snowball.player_snowball_buff.getGroup(this.activityId);
            buff_group.forEach((value) => {
                this.buffConfig.set(value.buff_id, value);
            })
            this.ticks = this.baseConfig.tick;
            this.timer = new Laya.Timer();
            this.tweenMgr = new UI_TweenManager();
            this._autoAttack = !!game.LocalStorage.getItem('snowballAuto' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id);
            this._speed = 1;
            const localStorage = game.LocalStorage.getItem('snowballSpeed' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id);
            if (localStorage && localStorage == '0.5') {
                this._speed = 0.5;
            }
        }

        set speed(speed: number) {
            this.pause();
            this._speed = speed;
            this.resume();
            game.LocalStorage.setItem('snowballSpeed' + SnowBallData.Inst.activityId + GameMgr.Inst.account_id, speed == 1 ? '1' : '0.5');
        }

        get speed(): number {
            return this._speed;
        }

        set autoAttack(v: boolean) {
            this._autoAttack = v;
            if (v) this.nextBall = 0;
            game.LocalStorage.setItem('snowballAuto' + SnowBallData.Inst.activityId + GameMgr.Inst.account_id, v ? '1' : '')
        }

        get autoAttack(): boolean {
            return this._autoAttack;
        }


        public get highestLevel() {
            let level = 0;
            if (this.rewardData.finished_level.length > 0) {
                level = Math.max(level, this.rewardData.finished_level[this.rewardData.finished_level.length - 1]);
            }
            return level;
        }

        public pause() {
            if (!this.gaming) return;
            if (this.isEnd) return;
            this.tickDelay = this.oneTickTime - (this.currTimer - this.nowTickTime) / this.speed;
            this.isPause = true;
            this.stopTime = Laya.timer.currTimer;
            this.timer.clearAll(this);
            this.tweenMgr.pauseAllTweens();
            SnowBallEffectMgr.Inst.refreshAnim(true);
        }

        public resume() {
            if (!this.gaming) return;
            if (this.isEnd) return;
            if (!this.isPause) return;
            this.isPause = false;
            if (this.nowTick == 0) {
                this.processingData();
            } else {
                let delay = Laya.timer.currTimer - this.stopTime;
                this.stopTime = 0;
                this.costTime += delay;
                this.tweenMgr.resumeAllTweens();
                SnowBallEffectMgr.Inst.refreshAnim(false);
                this.timer.once(this.tickDelay * this.speed, this, () => {
                    this.refreshNowTick();
                    this.processingData();
                })
            }
        }

        public get currTimer(): number {
            let stop = 0;
            if (this.isPause) {
                stop = this.timer.currTimer - this.stopTime;
            }
            return this.timer.currTimer - this.costTime - stop;
        }

        public get nowTime(): number {
            let baseTick = this.ticks;
            let roundTime = this.nowLevelConfig.round_time / baseTick;
            let dura = Math.floor(this.nowTick / baseTick);
            return roundTime - dura;
        }

        public get leftMoney(): number {
            let count = UI_Bag.get_item_count(this.currencyId);
            let buffIds = [0, 0, 0, 0];
            for (let i = 0; i < this.upgradeData.length; i++) {
                buffIds[this.upgradeData[i].type] = this.upgradeData[i].buff_id;
            }
            cfg.snowball.player_snowball_buff.forEach(config => {
                let buffId = buffIds[config.type];
                if (buffId && buffId >= config.buff_id) {
                    count -= config.price;
                }
            })
            return count;
        }

        public getPlayerMaxHP(player: ESnowBallPlayerType): number {
            return this.initStates[player].hp;
        }

        public initData(datas: game.IActivitySnowballData[]) {
            if (!this.inited) return;
            this.nowLevel = this.roundConfig.keys()[0];
            this.passGameCount = 0;
            this.comboCount = 0;
            if (datas) {
                for (let i: number = 0; i < datas.length; i++) {
                    let msg = datas[i];
                    if (msg.activity_id == this.activityId) {
                        if (msg.level) this.nowLevel = msg.level;
                        this.updateUpgradeData(msg.upgrade);
                        this.updateRewardData(msg.rewarded_level, msg.finished_level);
                        this.passGameCount = msg.level_finished_count || 0;
                        this.comboCount = msg.player_combo || 0;
                        break;
                    }
                }
            }
        }

        public updateData(data: game.IActivitySnowballValueChanges) {
            if (data.level && data.level.dirty) {
                this.nowLevel = data.level.value;
            }
            this.updateRewardByChanges(data);
            if (data.upgrade && data.upgrade.dirty) {
                this.updateUpgradeData(data.upgrade.value);
            }
            if (data.level_finished_count && data.level_finished_count.dirty) {
                this.passGameCount = data.level_finished_count.value || 0;
            }
            if (data.player_combo && data.player_combo.dirty) {
                this.comboCount = data.player_combo.value || 0;
            }
        }

        public updateUpgradeData(data: game.IActivitySnowballUpgrade[]) {
            this.upgradeData = [];
            if (data) {
                for (let i = 0; i < data.length; i++) {
                    this.upgradeData.push(this.buffConfig.get(data[i].id));
                }
            }
            this.refreshData();
        }

        refreshData() {
            this.weaponInfo = [];
            for (let i = 0; i < 3; i++) {
                let base = this.attackConfig.get(i);
                this.weaponInfo.push({
                    fly_time: base.flight_time,
                    damage: base.atk,
                    mp_consume: base.mp_consume,
                    cd: base.cd,
                    count: 1,
                    track: i,
                    locked: true
                });
            }
            this.upgradeData.sort((a, b) => { return a.buff_id - b.buff_id; });
            for (let i = 0; i < this.upgradeData.length; i++) {
                let buffConfig = this.upgradeData[i];
                let type = buffConfig.type;
                if (type < 3) {
                    let effect = cfg.snowball.snowball_attack_level.get(buffConfig.effect);
                    if (this.weaponInfo[type]) {
                        this.weaponInfo[type].mp_consume -= effect.mp_buff;
                        this.weaponInfo[type].cd -= effect.cd_buff;
                        this.weaponInfo[type].count += effect.snowball_count;
                        this.weaponInfo[type].locked = false;
                    }
                }
            }
        }

        get nowLevelConfig() {
            return this.roundConfig.get(this.nowLevel);
        }

        sortEvents() {
            this.events.sort((a, b) => {
                if (a.tick != b.tick) return a.tick - b.tick;
                if (a.type != b.type) return a.type - b.type;
                if (a.player != b.player) return a.player - b.player;
                if (a.type == ESnowBallEventType.hit) {
                    return a.player_attacked.track - b.player_attacked.track; // 数值小的在前
                } else if (a.type == ESnowBallEventType.wave) {
                    return a.wave_action.operateIndex - b.wave_action.operateIndex; // 操作先的在前
                }
                return 0;
            });
        }

        prepareThrow(track: number): boolean {
            let weaponInfo = this.weaponInfo[track];
            if (weaponInfo.locked) return false;
            if (weaponInfo.mp_consume > this.trueMP) return false;
            if (this.nowTick >= this.nowLevelConfig.round_time) return false;
            this.trueMP -= weaponInfo.mp_consume;
            let tick = this.nowTick + 1;
            let operateIndex = this.operateIndex++;
            let eventWave: IActivitySnowballEvent = {
                tick: tick,
                type: ESnowBallEventType.wave,
                player: ESnowBallPlayerType.player,
                state_change: {
                    mp_change: 0 - weaponInfo.mp_consume,
                },
                wave_action: {
                    track,
                    cd: weaponInfo.cd,
                    operateIndex
                }
            }
            this.events.push(eventWave);
            const critical = this.random.randomInt(0, 100) < this.baseConfig.player_luk;
            let count = weaponInfo.count;
            for (let i = 0; i < count; i++) {
                this.throwSnowball(track, tick + i * this.baseConfig.attack_interval + this.baseConfig.player_attack_delay, critical, i == 0);
            }
            this.playerAction.push({
                track: track,
                tick: tick
            });
            return true;
        }

        throwSnowball(track: number, tick: number, critical: boolean, firstBall: boolean) {
            let weaponInfo = this.weaponInfo[track];
            let damage = critical ? weaponInfo.damage * this.baseConfig.critical_hit : weaponInfo.damage;
            let offsetInfos: ISnowBallOffsetInfo[] = [];
            //判断当前场上的球能否撞到
            for (let i = 0; i < this.tickInfo.fly_item_list.length; i++) {
                let item = this.tickInfo.fly_item_list[i];
                if (item.active && item.target == ESnowBallPlayerType.player && item.track == track && ((item.state == ESBFlyState.fly || item.state == ESBFlyState.start))) {
                    if (item.init_tick + weaponInfo.fly_time > tick) {
                        this.tickInfo.fly_item_list[i].active = false;
                        let offsetInfo = {
                            ballId: item.id,
                            initTick: item.init_tick
                        }
                        offsetInfos.push(offsetInfo);
                        if (!critical) break;
                    }
                }
            }
            //判断未来的球能否撞到
            if (offsetInfos.length == 0 || critical) {
                for (let i = 0; i < this.events.length; i++) {
                    let event = this.events[i];
                    if (event.tick > this.nowTick && event.type == ESnowBallEventType.throw && event.player == ESnowBallPlayerType.boss && event.throw_action.track == track && event.throw_action.active) {
                        if (tick + weaponInfo.fly_time > event.tick) {
                            this.events[i].throw_action.active = false;
                            let offsetInfo = {
                                ballId: event.throw_action.ball_id,
                                initTick: event.tick
                            }
                            offsetInfos.push(offsetInfo);
                            if (!critical) break;
                        }
                    }
                }
            }
            //能撞到把对方的伤害事件干掉
            if (offsetInfos.length > 0) {
                for (let j = 0; j < offsetInfos.length; j++) {
                    let offsetInfo = offsetInfos[j];
                    for (let i = 0; i < this.events.length; i++) {
                        let event = this.events[i];
                        if (event.type == ESnowBallEventType.hit && event.player_attacked.ball_id == offsetInfo.ballId) {
                            this.events.splice(i, 1);
                            break;
                        }
                    }
                }
            }
            this.ballUID++;
            let ballId: number = this.ballUID;
            let eventThrow: IActivitySnowballEvent = {
                tick: tick,
                type: ESnowBallEventType.throw,
                player: ESnowBallPlayerType.player,
                throw_action: {
                    ball_id: ballId,
                    critical,
                    track,
                    damage: damage,
                    active: offsetInfos.length == 0 || critical,
                }
            }
            this.events.push(eventThrow);
            if (offsetInfos.length > 0) {
                for (let j = 0; j < offsetInfos.length; j++) {
                    let offsetInfo = offsetInfos[j];
                    let lastTick = Math.max(offsetInfo.initTick, tick);
                    let offsetTick = Math.floor(lastTick + (weaponInfo.fly_time - Math.abs(offsetInfo.initTick - tick)) / 2);
                    let eventOffset: IActivitySnowballEvent = {
                        tick: offsetTick,
                        type: ESnowBallEventType.offset,
                        ball_action: {
                            track: weaponInfo.track,
                            balls_id: [offsetInfo.ballId, ballId],
                            isCrit: critical
                        }
                    }
                    this.events.push(eventOffset);
                }
            }
            if (offsetInfos.length == 0 || critical) {
                let eventHit: IActivitySnowballEvent = {
                    tick: tick + weaponInfo.fly_time,
                    type: ESnowBallEventType.hit,
                    player: ESnowBallPlayerType.boss,
                    player_attacked: {
                        ball_id: ballId,
                        track: weaponInfo.track,
                        damage: damage,
                        critical
                    },
                    state_change: {
                        hp_change: 0 - damage
                    }
                }
                this.events.push(eventHit);
            }
            this.sortEvents();
        }

        public dealBossAction(actions: game.ISnowballActivityBossAction[]) {
            for (let i = 0; i < actions.length; i++) {
                let bossAction = actions[i];
                if (bossAction.type == 1) {
                    let operateIndex = this.operateIndex++;
                    let eventWave: IActivitySnowballEvent = {
                        tick: bossAction.tick,
                        type: ESnowBallEventType.wave,
                        player: ESnowBallPlayerType.boss,
                        state_change: {
                            mp_change: 0 - bossAction.mp_consume_info.mp_consume,
                        },
                        wave_action: {
                            track: bossAction.track,
                            cd: 0,
                            operateIndex
                        }
                    }
                    this.events.push(eventWave);
                } else {
                    this.ballUID++;
                    let ballId = this.ballUID;
                    let eventThrow: IActivitySnowballEvent = {
                        tick: bossAction.tick,
                        type: ESnowBallEventType.throw,
                        player: ESnowBallPlayerType.boss,
                        throw_action: {
                            ball_id: ballId,
                            critical: false,
                            track: bossAction.track,
                            damage: bossAction.attack_info.damage,
                            active: true,
                        }
                    }
                    this.events.push(eventThrow);
                    let flyTime = this.attackConfig.get(bossAction.track).flight_time;
                    let eventHit: IActivitySnowballEvent = {
                        tick: bossAction.tick + flyTime,
                        type: ESnowBallEventType.hit,
                        player: ESnowBallPlayerType.player,
                        player_attacked: {
                            ball_id: ballId,
                            track: bossAction.track,
                            damage: bossAction.attack_info.damage,
                            critical: false
                        },
                        state_change: {
                            hp_change: 0 - bossAction.attack_info.damage
                        }
                    }
                    this.events.push(eventHit);
                }

            }
        }

        public dealMPAction() {
            let tick = 1;
            let roundConfig = this.nowLevelConfig;
            let baseConfig = this.baseConfig;
            while (tick <= roundConfig.round_time) {
                tick += baseConfig.mp_recover;
                for (let i = ESnowBallPlayerType.player; i <= ESnowBallPlayerType.boss; i++) {
                    let eventMP: IActivitySnowballEvent = {
                        tick: tick,
                        type: ESnowBallEventType.mp,
                        player: i,
                        state_change: {
                            mp_change: 1
                        }
                    }
                    this.events.push(eventMP);
                }
            }
        }


        public processingData() {
            if (this.isPause) return;
            if (this.isEnd) return;
            this.timer.loop(this.oneTickTime * 1000 * this.speed, this, this.refreshNowTick);
        }

        public refreshNowTick() {
            if (!this.tickInfo) return;
            this.nowTick++;
            this.nowTickTime = this.currTimer;
            if (this.nowTick <= this.nowLevelConfig.round_time) {
                this.tickInfo = game.Tools.deepCopy(this.tickInfo);
                this.tickInfo.tick = this.nowTick;
                this.tickInfo.events = [];
                let flyItems: ISnowBallFlyItem[] = [];
                for (let i = 0; i < this.tickInfo.fly_item_list.length; i++) {
                    if (this.tickInfo.fly_item_list[i].state != ESBFlyState.offset && this.tickInfo.fly_item_list[i].state != ESBFlyState.hit) {
                        this.tickInfo.fly_item_list[i].state = ESBFlyState.fly;
                        flyItems.push(this.tickInfo.fly_item_list[i]);
                    }
                }
                for (let i = 0; i < this.tickInfo.skillCD.length; i++) {
                    if (this.tickInfo.skillCD[i] > 0) {
                        this.tickInfo.skillCD[i]--;
                    }
                }
                for (let i = this.nextIndex; i < this.events.length; i++) {
                    let event = this.events[i];
                    if (event.tick == this.nowTick) {
                        this.checkEvent(event, flyItems);
                    } else if (event.tick > this.nowTick) {
                        this.nextIndex = i;
                        break;
                    }
                }
                if (this.tickInfo.events.length > 0) {
                    this.event(SnowBallDataEvent.DoAction, this.tickInfo);
                }
                this.event(SnowBallDataEvent.UpdateState, this.tickInfo);
            }
            this.trueMP = this.tickInfo.players[ESnowBallPlayerType.player].mp;
            let result = ESnowBallResultType.none;
            for (let i = 0; i < this.tickInfo.players.length; i++) {
                if (this.tickInfo.players[i].hp <= 0) {
                    if (result == ESnowBallResultType.none) {
                        result = i == ESnowBallPlayerType.boss ? ESnowBallResultType.playerWin : ESnowBallResultType.bossWin;
                    } else {
                        result = ESnowBallResultType.allDie;
                        break;
                    }
                }
            }
            if (result == ESnowBallResultType.none && this.nowTick > this.nowLevelConfig.round_time) {
                result = ESnowBallResultType.timeOut;
            }
            if (result != ESnowBallResultType.none) {
                this.resultType = result;
                this.isEnd = true;
                this.timer.clearAllEx();
                let isWin = result == ESnowBallResultType.playerWin;
                if (!isWin) this.autoAttack = false;
                this.event(SnowBallDataEvent.PrepareEnd);
                this.lockNetwork = true;
                let param: game.IReqSnowballActivityFinishBattle = {
                    activity_id: this.activityId,
                    battle_id: this.battleId,
                    result: isWin ? 1 : 2,
                    player_action: this.playerAction
                };
                // ==DevDebug Start==
                param.check_infos_debug = this.extraData;
                // ==DevDebug End==
                app.Log.log(game.ERequest.snowballActivityFinishBattle + ' req ==== ' + JSON.stringify(param));
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityFinishBattle, param, (err, res: game.IResSnowballActivityFinishBattle) => {
                    this.lockNetwork = false;
                    if (err || res['error']) {
                        this.event(SnowBallDataEvent.RoundEnd, [ESnowBallResultType.bossWin, this.nowLevel]);
                        this.onGameError(game.ERequest.snowballActivityStartBattle, err, res);
                    } else {
                        app.Log.log(game.ERequest.snowballActivityFinishBattle + ' res ==== ' + JSON.stringify(res));
                        this.event(SnowBallDataEvent.RoundEnd, [result, this.nowLevel]);
                        this.updateData(res.changes);
                    }
                });
                return;
            }
            if (this.autoAttack) {
                for (let i = 0; i < this.weaponInfo.length; i++) {
                    if (this.tickInfo.skillCD[this.nextBall] == 0) {
                        let throwSuccess = this.prepareThrow(this.nextBall);
                        if (throwSuccess) {
                            this.nextBall++;
                            if (!this.weaponInfo[this.nextBall]) this.nextBall = 0;
                        } else {
                            break;
                        }
                    } else {
                        break;
                    }
                }
                if (this.weaponInfo[this.nextBall].locked) this.nextBall = 0;
            }
        }

        public checkEvent(event: IActivitySnowballEvent, flyItems: ISnowBallFlyItem[]) {
            this.tickInfo.events.push(event);
            for (let j = 0; j < flyItems.length; j++) {
                if (event.type == ESnowBallEventType.offset) {
                    for (let i = 0; i < event.ball_action.balls_id.length; i++) {
                        if (i == 0 || !event.ball_action.isCrit) {
                            if (flyItems[j].id == event.ball_action.balls_id[i]) {
                                flyItems[j].state = ESBFlyState.offset;
                                break;
                            }
                        }
                    }
                } else if (event.type == ESnowBallEventType.hit) {
                    if (flyItems[j].id == event.player_attacked.ball_id) {
                        flyItems[j].state = ESBFlyState.hit;
                    }
                }
            }
            if (event.type == ESnowBallEventType.hit) {
                if (event.player == ESnowBallPlayerType.boss) this.tempComboCount++;
                if (event.player == ESnowBallPlayerType.player) this.tempComboCount = 0;
            } else if (event.type == ESnowBallEventType.throw) {
                if (!this.isEnd) {
                    flyItems.push({
                        id: event.throw_action.ball_id,
                        active: event.throw_action.active,
                        init_tick: event.tick,
                        target: event.player == ESnowBallPlayerType.boss ? ESnowBallPlayerType.player : ESnowBallPlayerType.boss,
                        state: ESBFlyState.start,
                        track: event.throw_action.track,
                        crit: event.throw_action.critical
                    })
                }

            } else if (event.type == ESnowBallEventType.offset) {
                this.extraData.push({
                    type: 2,
                    hit_info: {
                        tick: this.tickInfo.tick,
                        track: event.ball_action.track,
                        critical: event.ball_action.isCrit ? 1 : 0
                    }
                });
            } else if (event.type == ESnowBallEventType.wave) {
                if (event.player == ESnowBallPlayerType.player) this.tickInfo.skillCD[event.wave_action.track] += event.wave_action.cd;
            }
            this.tickInfo.fly_item_list = flyItems;
            if (event.state_change) {
                if (!this.isEnd && event.state_change.hp_change) {
                    let beforeValue = this.tickInfo.players[event.player].hp;
                    this.tickInfo.players[event.player].hp += event.state_change.hp_change;
                    if (this.tickInfo.players[event.player].hp < 0) {
                        this.tickInfo.players[event.player].hp = 0;
                    }
                    let afterValue = this.tickInfo.players[event.player].hp;
                    this.extraData.push({
                        type: 1,
                        hp_change_info: {
                            before: beforeValue,
                            after: afterValue,
                            tick: this.tickInfo.tick,
                            unit: event.player + 1,
                            track: event.player_attacked.track
                        }
                    });
                }
                if (event.state_change.mp_change) {
                    let beforeValue = this.tickInfo.players[event.player].mp;
                    this.tickInfo.players[event.player].mp += event.state_change.mp_change;
                    if (this.tickInfo.players[event.player].mp > this.initStates[event.player].mp) {
                        this.tickInfo.players[event.player].mp = this.initStates[event.player].mp;
                    }
                    let afterValue = this.tickInfo.players[event.player].mp;
                    if (afterValue < beforeValue) {
                        this.extraData.push({
                            type: 3,
                            mp_change_info: {
                                before: beforeValue,
                                after: afterValue,
                                tick: this.tickInfo.tick,
                                unit: event.player + 1,
                                track: event.wave_action.track
                            }
                        });
                    }
                }
            }
        }

        playGame(fromHome: boolean = false) {
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            const param: game.IReqSnowballActivityStartBattle = {
                activity_id: this.activityId,
            }
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityStartBattle, param, (err, res: game.IResSnowballActivityStartBattle) => {
                this.lockNetwork = false;
                if (err || res['error']) {
                    this.onGameError(game.ERequest.snowballActivityStartBattle, err, res);
                } else {
                    app.Log.log(game.ERequest.snowballActivityStartBattle + ' res ==== ' + JSON.stringify(res));
                    this.initNewRoundData(res, fromHome);
                }
            });
        }


        initNewRoundData(res: game.IResSnowballActivityStartBattle, fromHome: boolean) {
            this.reset();
            this.tempComboCount = this.comboCount;
            this.gaming = true;
            this.random = new SnowballRandom(res.random_seed);
            this.battleId = res.battle_id;
            if (res.player_state) {
                for (let i = 0; i < res.player_state.length; i++) {
                    let player = res.player_state[i];
                    let state: ISnowBallPlayerState = {
                        mp: player.mp || 0,
                        hp: player.hp || 0,
                    }
                    this.initStates[player.player - 1] = state;
                }
            }
            this.tickInfo = {
                tick: 0,
                fly_item_list: [],
                players: [...this.initStates],
                events: [],
                skillCD: [0, 0, 0]
            };
            this.trueMP = this.initStates[ESnowBallPlayerType.player].mp;
            let bossAction = game.Tools.deepCopy(res.boss_action || []) as game.ISnowballActivityBossAction[];
            this.dealBossAction(bossAction);
            this.dealMPAction();
            this.sortEvents();
            if (fromHome) {
                this.event(SnowBallDataEvent.GameStart, res);
            } else {
                this.event(SnowBallDataEvent.RoundStart, res);
            }
            let doSpineDelay = !fromHome && this.resultType == ESnowBallResultType.playerWin;
            let delay = doSpineDelay ? this.nowLevelConfig.enter_delay * this.oneTickTime * 1000 : 200;
            delay += (this.nowLevelConfig.type == 1 ? 85 / 60 * 1000 : 0);
            this.locking = true;
            this.timer.once(delay, this, () => {
                this.locking = false;
                this.processingData();
            })
        }

        updateRewardByChanges(data: { rewarded_level: game.IUInt32ArrayDirty, finished_level: game.IUInt32ArrayDirty }) {
            if (!data) return;
            this.updateRewardData(
                data.rewarded_level && data.rewarded_level.dirty ? data.rewarded_level.value : null,
                data.finished_level && data.finished_level.dirty ? data.finished_level.value : null,
            );
        }

        updateRewardData(rewarded_level: number[], finished_level: number[]) {
            if (rewarded_level) {
                this.rewardData.rewarded_level = [...rewarded_level];
            }
            if (finished_level) {
                this.rewardData.finished_level = [...finished_level];
                this.rewardData.finished_level.sort(((a, b) => a - b));
            }
        }

        reset() {
            this.timer.clearAllEx();
            this.lockNetwork = false;
            this.locking = false;
            this.tickInfo = null;
            this.initStates = [{ mp: 0, hp: 0 }, { mp: 0, hp: 0 }];
            this.battleId = '';
            this.nowTick = 0;
            this.ballUID = 0;
            this.operateIndex = 0;
            this.events = [];
            this.nextIndex = 0;
            this.nowTickTime = 0;
            this.stopTime = 0;
            this.costTime = 0;
            this.isEnd = false;
            this.random = null;
            this.tweenMgr.clearAllTweens();
            this.isPause = false;
            this.nextBall = 0;
            this.playerAction = [];
            this.tickDelay = 0;
            this.trueMP = 0;
            this.extraData = [];
            this.gaming = false;
        }

        public onGameError(method: string, err: any, res: any) {
            if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26123)) {
                uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093), Laya.Handler.create(this, () => {
                    SnowBallData.Inst.reset();
                    if (UI_Activity_SnowBall_Result.Inst.enable) {
                        UI_Activity_SnowBall_Result.Inst.hide();
                    }
                    if (UI_Activity_SnowBall_Game.Inst.enable) {
                        UI_Activity_SnowBall_Game.Inst.hide();
                    }
                    UI_Activity_SnowBall_Main.Inst.hide();
                }));
            } else {
                uiscript.UIMgr.Inst.showNetReqError(method, err, res);
            }
        }

        //#region reward相关
        /** 已通关的最大关卡 */
        get finishedMaxLevel() {
            const finished_level = this.rewardData.finished_level;
            return finished_level[finished_level.length - 1] || 0;
        }

        get haveUnrecivedReward() {
            const { roundConfig } = SnowBallData.Inst;
            const keys = roundConfig.keys().sort((a, b) => a - b);
            for (const e of keys) {
                const cfg = roundConfig.get(e);
                if (cfg.reward) {
                    const state = SnowBallData.Inst.getRewardState(cfg);
                    if (state != 1) return true;
                }
            }
            return false;
        }

        /** 获取奖励剩余解锁时间 */
        getRewardUnlockRest(data: lqc.Sheet_Snowball_SnowballMonsterGroup) {
            return UI_Activity.getActivityUnLockTime(this.activityId, data.unlock_day);
        }

        /** 奖励状态， -1:不可领取，0:可领取，1:已领取 */
        getRewardState(data: lqc.Sheet_Snowball_SnowballMonsterGroup): -1 | 0 | 1 {
            const { rewarded_level, finished_level } = this.rewardData;
            const fi = finished_level.indexOf(data.level);
            if (fi < 0) return -1;
            const ri = rewarded_level.indexOf(data.level);
            return ri < 0 ? 0 : 1;
        }
        //#endregion
    }

    const a = 1664525;
    const c = 1013904223;
    const m = Math.pow(2, 32);

    export class SnowballRandom {
        constructor(seed: number) {
            this.seed_ = parseFloat('0.' + Math.sin(seed).toString().slice(6));
            this.state_ = Math.floor(this.seed_ * m);
        }

        randomInt(min: number, max: number) {
            this.state_ = (a * this.state_ + c) % m;
            const randomFloat = this.state_ / m;
            const randomInt = Math.floor(randomFloat * (max - min + 1)) + min;
            return randomInt;
        }

        randomByWeight<T>(candidates: T[], getWeight: (candidate: T, index: number) => number): T | null {
            if (!candidates || candidates.length === 0)
                return null;

            const weights = candidates.map(getWeight);
            const sum = weights.reduce((p, c) => p + c, 0);
            let rand = this.randomInt(1, sum);
            for (let i = 0; i < weights.length; i++) {
                if (rand <= weights[i])
                    return candidates[i];
                rand -= weights[i];
            }
            return null;
        }

        private seed_: number;
        private state_: number;
    }
}