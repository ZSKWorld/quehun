// ==DevDebug==
module uiscript {
	export class UI_Activity_SnowBall_Debug extends UIBase {
		public static Inst: UI_Activity_SnowBall_Debug;

		public get meUI(): ui.lobby.activity_2512winter.snowball_DevDebugUI {
			return this.me as ui.lobby.activity_2512winter.snowball_DevDebugUI;
		}

		constructor() {
			super(new ui.lobby.activity_2512winter.snowball_DevDebugUI());
			UI_Activity_SnowBall_Debug.Inst = this;
		}
		private txtLog: string = '';
		public logHistory: string[] = [];
		private attackStats: any;
		private ballOwnerMap: any;
		private tempData: game.IResSnowballActivityStartBattle;

		onCreate() {
			this.meUI.btn_log.clickHandler = new Laya.Handler(this, () => {
				this.meUI.log_content.visible = !this.meUI.log_content.visible;
				if (this.meUI.log_content.visible) {
					this.meUI.btn_log.label = '关闭log';
				} else {
					this.meUI.btn_log.label = '打开log';
				}
			});
			this.meUI.btn_show.clickHandler = new Laya.Handler(this, () => {
				if (UI_Activity_SnowBall_Game.Inst.locking) return;
				this.meUI.root.visible = true;
				SnowBallData.Inst.pause();
				this.meUI.input_now.text = SnowBallData.Inst.nowLevel.toString();
				this.meUI.input_random.text = this.tempData ? this.tempData.random_seed.toString() : '';
				if (this.tempData) {
					this.refreshTest(this.tempData.boss_action, this.tempData.random_seed);
				} else {
					this.meUI.txt_random_test.text = '';
				}
			});
			this.meUI.btn_log.label = '打开log';
			this.meUI.log_content.visible = false;
			this.meUI.root.visible = false;
			this.meUI.btn_close.clickHandler = new Laya.Handler(this, () => {
				this.meUI.root.visible = false;
				SnowBallData.Inst.resume();
			});
			this.meUI.btn_change_now.clickHandler = new Laya.Handler(this, this.ChangeNow);
			this.meUI.btn_test.clickHandler = new Laya.Handler(this, this.TestRandom);
			this.meUI.btn_change_random.clickHandler = new Laya.Handler(this, this.ChangeRandom);
			SnowBallData.Inst.on(SnowBallDataEvent.RoundStart, this, this.roundStart);
			SnowBallData.Inst.on(SnowBallDataEvent.GameStart, this, this.roundStart);
			SnowBallData.Inst.on(SnowBallDataEvent.RoundEnd, this, this.roundEnd);
			SnowBallData.Inst.on(SnowBallDataEvent.DoAction, this, this.doAction);
		}

		private refreshTest(data: game.ISnowballActivityBossAction[], randomSeed: number) {
			let str = '';
			for (let i = 0; i < data.length; i++) {
				if (data[i].type == 1) {
					str += 'tick = ' + data[i].tick + ' : ';
					str += 'boss准备在第 ' + data[i].track + ' 轨道攻击';
					str += '\n';
				} else if (data[i].type == 2) {
					str += 'tick = ' + data[i].tick + ' : ';
					str += 'boss在第 ' + data[i].track + ' 轨道扔出了雪球，伤害为 ' + data[i].attack_info.damage;
					str += '\n';
				}
			}
			str += '\n';
			str += '玩家的暴击随机值为';
			str += '\n';
			let random = new SnowballRandom(randomSeed);
			for (var i = 0; i < 50; i++) {
				const value = random.randomInt(0, 100);
				const critical = value < uiscript.SnowBallData.Inst.baseConfig.player_luk;
				str += ' i === ' + i + ' value =====  ' + value + '  是否暴击 ' + critical;
				str += '\n';
			}
			this.meUI.txt_random_test.text = str;
		}

		public backHome() {
			this.meUI.log_content.visible = false;
			this.meUI.btn_log.label = '打开log';
		}

		private roundStart(res) {
			this.tempData = game.Tools.deepCopy(res);
			if (this.txtLog) {
				this.logHistory.push(this.txtLog);
			}
			// 初始化统计数据（建议在类初始化时执行一次）
			if (!this.attackStats) {
				this.attackStats = {
					player: {
						throw: [],       // 扔出的球ID
						hit: [],   // 成功击中对方的球ID
						hitted: [], // 被对方击中的球ID
						offset: []      // 碰撞抵消的球ID
					},
					boss: {
						throw: [],
						hit: [],
						hitted: [],
						offset: []
					}
				};
				this.ballOwnerMap = {}; // 记录每个球的所有者（玩家/boss）
			}
			this.txtLog = '回合开始  对局唯一id ==== ' + SnowBallData.Inst.battleId;
			this.txtLog += '\n';
			this.refreshLog();
		}

		private doAction(tickInfo: ISnowBallTickInfo) {
			let txt = '';
			for (let i = 0; i < tickInfo.events.length; i++) {
				let event = tickInfo.events[i];
				let currentPlayer = event.player == ESnowBallPlayerType.player ? '玩家' : 'boss';
				let player = currentPlayer === '玩家' ? 'player' : 'boss';
				let opponent = currentPlayer === '玩家' ? 'boss' : 'player';

				if (event.type == ESnowBallEventType.wave) {
					txt += 'tick = ' + tickInfo.tick + " : ";
					txt += currentPlayer + ' 发动了攻击，雪球级别为 ' + (event.wave_action.track);
					txt += '\n';
				}
				// 处理扔出事件（记录发出的球）
				else if (event.type == ESnowBallEventType.throw) {
					const ballId = event.throw_action.ball_id;
					txt += 'tick = ' + tickInfo.tick + " : ";
					txt += currentPlayer + ' 扔出了 ' + (event.throw_action.critical ? '暴击' : '非暴击') + '  轨道为 ' + (event.throw_action.track) + '的雪球 ' + ballId;
					txt += '\n';
					// 记录球的所有者和发出记录
					this.ballOwnerMap[ballId] = player;
					this.attackStats[player].throw.push(ballId);
				}
				// 处理击中事件（记录打到/被打到的球）
				else if (event.type == ESnowBallEventType.hit) {
					const ballId = event.player_attacked.ball_id;
					txt += 'tick = ' + tickInfo.tick + " : ";
					txt += currentPlayer + ' 收到了 ' + (event.player_attacked.critical ? '暴击' : '非暴击') + ' 伤害为 ' + event.player_attacked.damage + ' ，轨道为 ' + (event.player_attacked.track) + ' 的雪球 ' + ballId;
					txt += '\n';
					// 被击中方记录"被对方打到"，攻击方记录"打到对方"
					this.attackStats[player].hitted.push(ballId);
					this.attackStats[opponent].hit.push(ballId);
				}
				// 处理碰撞事件（记录被抵消的球）
				else if (event.type == ESnowBallEventType.offset) {
					const ball1 = event.ball_action.balls_id[0];
					const ball2 = event.ball_action.balls_id[1];
					// 修复原代码的拼接错误（逗号改加号）
					txt += 'tick = ' + tickInfo.tick + " : ";
					txt += '两球碰撞 id分别为 ' + ball1 + ' 和 ' + ball2 + "  " + (event.ball_action.isCrit ? ball2 + ' 为暴击球，不会消失' : '');
					txt += '\n';
					// 记录两个球的抵消状态（根据所有者归属）
					const owner1 = this.ballOwnerMap[ball1] || '未知';
					const owner2 = this.ballOwnerMap[ball2] || '未知';
					if (owner1 !== '未知') this.attackStats[owner1].offset.push(ball1);
					if (owner2 !== '未知') this.attackStats[owner2].offset.push(ball2);
				}
			}
			if (!txt) return;
			this.txtLog += txt;
			this.refreshLog();
		}

		private roundEnd() {
			let summary = '\n===== 攻击总结 =====\n';
			// 玩家总结
			summary += '玩家：\n';
			summary += `  发出: ${this.attackStats.player.throw.join(', ')}\n`;
			summary += `  打到对方: ${this.attackStats.player.hit.join(', ')}\n`;
			summary += `  被对方打到: ${this.attackStats.player.hitted.join(', ')}\n`;
			summary += `  被抵消: ${this.attackStats.player.offset.join(', ')}\n`;
			// Boss总结
			summary += 'boss：\n';
			summary += `  发出: ${this.attackStats.boss.throw.join(', ')}\n`;
			summary += `  打到对方: ${this.attackStats.boss.hit.join(', ')}\n`;
			summary += `  被对方打到: ${this.attackStats.boss.hitted.join(', ')}\n`;
			summary += `  被抵消: ${this.attackStats.boss.offset.join(', ')}\n`;
			this.txtLog += summary;
			this.refreshLog();
		}

		private refreshLog() {
			this.meUI.log.text = this.txtLog;
			this.meUI.log_parent.height = this.meUI.log.trueHeight;
			this.meUI.log_bg.height = this.meUI.log.trueHeight;
			this.meUI.log_content.height = Math.min(this.meUI.log_bg.height, 800);
			this.meUI.log_content.scrollTo(0, this.meUI.log_parent.height);
		}

		private Close() {
			this.meUI.root.visible = false;
		}


		private ChangeNow() {
			let txt = this.meUI.input_now.text;
			let targetLevel = Number(txt);
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityFetchDebug, {
				activity_id: SnowBallData.Inst.activityId
			}, (err, res: game.IResSnowballActivityFetchDebug) => {
				if (err || res['error']) {
					app.Log.Error('snowballActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('snowballActivityFetchDebug', err, res);
				} else {
					if (!res || !res.snowball_activity) {
						UIMgr.Inst.ShowErrorInfo('没有活动数据，可能是活动未开始，不能修改数据');
						return;
					}
					let msg = game.Tools.deepCopy(res.snowball_activity) as game.IActivitySnowballData;
					msg.level = targetLevel;
					if (!msg.finished_level) msg.finished_level = [];
					if (msg.finished_level.indexOf(targetLevel) == -1) {
						msg.finished_level = SnowBallData.Inst.roundConfig.keys().filter((value) => {
							return value < targetLevel;
						})
					}
					if (!msg.finish_records) msg.finish_records = [];
					if (!msg.finish_records.find(v => v.id == targetLevel)) {
						SnowBallData.Inst.roundConfig.keys().forEach((value) => {
							if (value < targetLevel) {
								msg.finish_records.push({ id: value, time: game.Tools.getServerTime() });
							}
						})
					}

					const param: game.IReqSnowballActivityDebug = {
						snowball_activity: msg,
					}
					app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityDebug, param, (err, res: game.IResCommon) => {
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError(game.ERequest.snowballActivityStartBattle, err, res);
						} else {
							SnowBallData.Inst.initData([msg]);
							this.Close();
							SnowBallData.Inst.reset();
							UI_Activity_SnowBall_Main.Inst.backToHome();
						}
					});
				}
			});
		}

		private TestRandom() {
			let txt = this.meUI.input_random.text;
			if (txt == '') {
				UIMgr.Inst.ShowErrorInfo('没填随机值');
				return;
			}
			let randomValue = Number(txt);
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityStartBattle, {
				activity_id: SnowBallData.Inst.activityId,
				random_seed_debug: randomValue
			}, (err, res: game.IResSnowballActivityStartBattle) => {
				if (err || res['error']) {
					app.Log.Error('snowballActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('snowballActivityFetchDebug', err, res);
				} else {
					this.refreshTest(res.boss_action, randomValue);
					this.tempData = game.Tools.deepCopy(res);
				}
			});
		}

		ChangeRandom() {
			if (!this.tempData) {
				UIMgr.Inst.ShowErrorInfo('当前随机值未向服务端请求boss序列');
				return;
			}
			this.Close();
			SnowBallData.Inst.reset();
			UI_Activity_SnowBall_Main.Inst.backToHome();
			SnowBallData.Inst.initNewRoundData(this.tempData, true);
		}

	}
}