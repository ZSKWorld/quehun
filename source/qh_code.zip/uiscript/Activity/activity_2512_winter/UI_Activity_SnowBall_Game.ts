module uiscript {
    class UI_Damage {
        public me: Laya.Sprite;
        private father: UI_Player_Item;
        private aniHit: Laya.FrameAnimation;
        private aniCrit: Laya.FrameAnimation;
        private comDamage: Laya.Sprite;
        private imgDamageBg: Laya.Sprite;
        private comDamageValue: Laya.Sprite;
        private comAnim: Laya.Sprite;
        private imgsDamage: Laya.Image[];
        private imgsAnim: Laya.Image[];

        constructor(me: Laya.Sprite, father: UI_Player_Item) {
            this.me = me;
            this.father = father;
            this.comDamage = this.me.getChildByName('damage') as Laya.Sprite;
            let aniRoot = this.comDamage as ui.lobby.activity_2512winter.activity_2512winter_damageUI;
            this.aniHit = aniRoot.hit_dmg;
            this.aniCrit = aniRoot.hit_crit;
            this.imgDamageBg = this.comDamage.getChildAt(0).getChildByName('bg') as Laya.Image;
            this.comDamageValue = this.comDamage.getChildAt(0).getChildByName('anim').getChildByName('value') as Laya.Sprite;
            this.comAnim = this.comDamage.getChildAt(0).getChildByName('anim').getChildByName('anim') as Laya.Sprite;
            this.imgsDamage = [];
            this.imgsAnim = [];
            for (let i = 0; i < 2; i++) {
                this.imgsDamage.push(this.comDamageValue.getChildByName('num' + i) as Laya.Image);
                this.imgsAnim.push(this.comAnim.getChildByName('num' + i) as Laya.Image);
            }
        }

        public show(value: number, critical: boolean) {
            this.imgDamageBg.visible = critical;
            this.comDamage.visible = true;
            this.refreshDamage(value);
            let anim = critical ? this.aniCrit : this.aniHit;
            anim.play(0, false);
            Laya.timer.once(anim.count * anim.interval, this, () => {
                this.clear(true);
            })
        }

        private refreshDamage(value: number) {
            let valueStr = value.toString();
            this.comDamageValue.x = value < 10 ? 0 : -30;
            this.comAnim.x = value < 10 ? 0 : -30;
            this.comAnim.filters = [new Laya.ColorFilter([
                0, 0, 0, 0, 255,
                0, 0, 0, 0, 255,
                0, 0, 0, 0, 255,
                0, 0, 0, 1, 0])];
            for (let i = 0; i < this.imgsDamage.length; i++) {
                let img = this.imgsDamage[i];
                let imgAnim = this.imgsAnim[i];
                img.visible = false;
                imgAnim.visible = false;
                if (valueStr[i]) {
                    img.visible = true;
                    imgAnim.visible = true;
                    img.skin = game.Tools.localUISrc('myres/activity_2512winter/font/hit_' + valueStr[i] + '.png')
                    imgAnim.skin = game.Tools.localUISrc('myres/activity_2512winter/font/hit_' + valueStr[i] + '.png')
                }
            }
        }

        public clear(remove: boolean) {
            this.comDamage.visible = false;
            this.aniHit.stop();
            this.aniCrit.stop();
            if (remove) this.father.removeDamage(this);
        }
    }
    class UI_Player_Item extends UIBase {
        public spine: UI_SnowBall_Spine;
        private comState: Laya.Sprite;
        private playerGrade: Laya.Sprite;
        private txtName: Laya.Label;
        private comHP: Laya.Sprite;
        private imgHP: Laya.Image;
        private imgHPAnim: Laya.Image;
        private imgMP: Laya.Image;
        private txtHP: Laya.Label;
        private txtMP: Laya.Label;
        private imgHead: Laya.Image;

        private playerType: ESnowBallPlayerType;
        private name: string = '';
        private nowMP: number;
        private lastMPTime: number;
        private hpTweenerId: number;
        private nowHP: number;
        private comArea: Laya.Sprite;
        private templeteDamage: capsui.UICopy;
        private damages: UI_Damage[];
        private unUseDamage: UI_Damage[];

        constructor(me: Laya.Sprite, spine: UI_SnowBall_Spine, playerType: ESnowBallPlayerType) {
            super(me);
            this.spine = spine
            this.playerType = playerType;
            this.comState = this.me.getChildByName('state') as Laya.Sprite;
            if (this.playerType == ESnowBallPlayerType.player) {
                this.playerGrade = (this.comState.getChildByName('level') as Laya.Image).mask;
            }
            this.txtName = this.comState.getChildByName('name') as Laya.Label;
            this.imgHead = this.comState.getChildByName('head') as Laya.Image;
            let comValue = this.comState.getChildByName('value') as Laya.Sprite;
            this.comHP = comValue.getChildByName('hp') as Laya.Sprite;
            this.imgHPAnim = this.comHP.getChildByName('hp_anim') as Laya.Image;
            this.imgHP = this.comHP.getChildByName('hp') as Laya.Image;
            this.imgMP = comValue.getChildByName('mp').getChildByName('mp') as Laya.Image;
            this.txtHP = comValue.getChildByName('hp_value') as Laya.Label;
            this.txtMP = comValue.getChildByName('mp_value') as Laya.Label;
            this.comArea = this.me.getChildByName('pos').getChildByName('area') as Laya.Sprite;
            let com = this.me.getChildByName('damage') as Laya.Sprite;
            com.visible = false;
            this.templeteDamage = (com).scriptMap['capsui.UICopy'];
            this.unUseDamage = [];
            this.damages = [];
        }

        public show(state: ISnowBallPlayerState) {
            this.reset();
            this.enable = true;
            this.name = this.playerType == ESnowBallPlayerType.player ? SnowBallData.Inst.baseConfig.player_id : SnowBallData.Inst.nowLevelConfig.boss_id;
            this.refreshHPShow(state.hp, false);
            this.refreshMPShow(state.mp);
            this.imgHead.skin = game.Tools.localUISrc('myres/activity_2512winter/chara/enter_' + this.name + '.png');
            if (this.playerType == ESnowBallPlayerType.player) {
                game.Tools.SetNickname(this.comState.getChildByName('nickname') as Laya.Sprite, GameMgr.Inst.account_data);
                this.txtName.text = (this.comState.getChildByName('nickname').getChildByName('name') as Laya.Label).text;
            } else {
                this.txtName.text = game.Tools.eventStrOfLocalization(SnowBallData.Inst.nowLevelConfig.name_str_id);
            }
            if (this.playerGrade) {
                let hpBuff = SnowBallData.Inst.upgradeData.find(skill => skill.type == 3);
                if (hpBuff) {
                    this.playerGrade.height = hpBuff.level < 4 ? 21 * hpBuff.level : 93;
                }
            }
            if (this.playerType == ESnowBallPlayerType.player) {
                this.spine.playAnim(ESnowBallSpineAnim.Idle);
            } else {
                this.comArea.y = 0 - SnowBallData.Inst.nowLevelConfig.monster_height;
            }
        }

        public refreshSpine() {
            this.spine.show(this.name);
        }

        public refresh(tickInfo: ISnowBallTickInfo) {
            let playerState = tickInfo.players[this.playerType];
            // app.Log.Error((this.playerType == ESBPlayerType.boss ? 'boss' : '玩家') + ' 的血量为 ' + playerState.hp + ' 蓝量为 ' + playerState.mp);
            if (this.nowHP != playerState.hp) this.refreshHPShow(playerState.hp, true);
            let updateMP = false;
            for (let i = 0; i < tickInfo.events.length; i++) {
                let event = tickInfo.events[i];
                if (event.player == this.playerType) {
                    if (event.type == ESnowBallEventType.mp) { //此tick有恢复事件，可以保证mp是整数且数值正确，可以更新一下nowMP
                        updateMP = true;
                        this.nowMP = playerState.mp;
                        this.lastMPTime = SnowBallData.Inst.currTimer;
                    } else if (event.type == ESnowBallEventType.hit) {
                        this.spine.playAnim(ESnowBallSpineAnim.Hit);
                        this.showDamage(event.player_attacked.damage, event.player_attacked.critical);
                    } else if (event.type == ESnowBallEventType.wave) {
                        this.spine.playAnim(ESnowBallSpineAnim.Attack);
                        if (!updateMP) this.nowMP += event.state_change.mp_change; //有扣蓝，立刻扣掉
                    }
                }
            }
            if (tickInfo.tick == 1) {
                this.nowMP = playerState.mp;
                this.lastMPTime = SnowBallData.Inst.currTimer;
            }
            this.refreshMPResume();
        }

        private showDamage(value: number, critical: boolean) {
            let item: UI_Damage;
            if (this.unUseDamage.length > 0) {
                item = this.unUseDamage.pop();
            } else {
                let ui = this.templeteDamage.getNodeClone();
                item = new UI_Damage(ui, this);
                this.comArea.addChild(ui);
            }
            this.damages.push(item);
            item.me.pivot(item.me.width / 2, item.me.height / 2);
            item.me.pos(Math.random() * this.comArea.width, Math.random() * this.comArea.height);
            item.show(value, critical);
        }

        public removeDamage(item: UI_Damage) {
            this.unUseDamage.push(item);
            if (this.damages.indexOf(item) != -1) {
                this.damages.splice(this.damages.indexOf(item), 1);
            }
        }

        public refreshMPResume() {
            let oneMS = 1 / (SnowBallData.Inst.baseConfig.mp_recover / SnowBallData.Inst.ticks) / 1000;
            SnowBallData.Inst.timer.frameLoop(1, this, () => {
                let delay = SnowBallData.Inst.currTimer - this.lastMPTime;
                this.lastMPTime = SnowBallData.Inst.currTimer;
                if (delay == 0 || this.nowMP > SnowBallData.Inst.baseConfig.mp) return;
                this.nowMP += delay * oneMS / SnowBallData.Inst.speed;
                if (this.nowMP > SnowBallData.Inst.baseConfig.mp) this.nowMP = SnowBallData.Inst.baseConfig.mp;
                this.refreshMPShow(this.nowMP);
            });
        }

        public refreshHPShow(hp: number, doAnim: boolean) {
            this.nowHP = hp;
            this.clearHPTweener();
            let rate = this.playerType == ESnowBallPlayerType.player ? 1 : -1;
            let maxHP = SnowBallData.Inst.getPlayerMaxHP(this.playerType);
            let targetX = (1 - hp / maxHP) * 486 * rate;
            this.imgHP.x = targetX;
            this.txtHP.text = hp + '/' + maxHP;
            if (doAnim) {
                this.hpTweenerId = SnowBallData.Inst.tweenMgr.addTweenTo(this.imgHPAnim, { x: targetX }, 200, null, null, 200);
            } else {
                this.imgHPAnim.x = targetX;
            }
        }

        public refreshMPShow(mp: number) {
            let maxMP = SnowBallData.Inst.baseConfig.mp;
            this.txtMP.text = Math.floor(mp) + '/' + maxMP;
            let rate = this.playerType == ESnowBallPlayerType.player ? 1 : -1;
            this.imgMP.x = (1 - mp / maxMP) * 486 * rate;
        }

        public onDisable() {
            this.reset();
        }

        public clearHPTweener() {
            Laya.Tween.clearAll(this.imgHPAnim);
            if (this.hpTweenerId) SnowBallData.Inst.tweenMgr.removeTweener(this.hpTweenerId);
            this.hpTweenerId = 0;
        }

        public reset() {
            this.damages.forEach(item => item.clear(false));
            this.unUseDamage = [...this.damages];
            this.damages = [];
            this.clearHPTweener();
            SnowBallData.Inst.timer.clearAll(this);
        }
    }

    class UI_Ability_Item extends UIBase {
        private father: UI_Activity_SnowBall_Game;
        private track: number;
        private imgBg: Laya.Image;
        private imgStars: Laya.Image[];
        private comMP: Laya.Sprite;
        private imgMPBg: Laya.Image;
        private imgMP: Laya.Image[];
        private txtCD: Laya.Label;
        private imgIcon: Laya.Image;
        private comMask: Laya.Sprite;
        private comMaskGraphics: Laya.Graphics;
        private btn: Laya.Button;
        private config: ISnowBallWeaponInfo;
        private nowProgress: number;
        private lastTime: number;
        private buffConfig: lqc.Sheet_Snowball_PlayerSnowballBuff;

        constructor(me: Laya.Sprite, track: number, father: UI_Activity_SnowBall_Game) {
            super(me);
            this.track = track;
            this.father = father;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            let comStar = this.me.getChildByName('stars') as Laya.Sprite;
            this.imgStars = comStar._childs;
            this.comMP = this.me.getChildByName('grade') as Laya.Sprite;
            this.imgMPBg = this.comMP.getChildByName('bg') as Laya.Image;
            this.imgMP = [];
            for (let i = 0; i < 2; i++) {
                let img = this.comMP.getChildByName('grade' + i) as Laya.Image;
                this.imgMP.push(img);
            }
            this.comMP.getChildByName('grade') as Laya.Image;
            this.imgIcon = this.me.getChildByName('icon') as Laya.Image;
            this.comMask = this.me.getChildByName('gray') as Laya.Sprite;
            this.txtCD = this.me.getChildByName('cd') as Laya.Label;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = Laya.Handler.create(this, () => {
                if (SnowBallData.Inst.locking) return;
                if (SnowBallData.Inst.isEnd) return;
                if (this.father.locking) return;
                SnowBallData.Inst.autoAttack = false;
                this.father.refreshBtn();
                let throwSuccess = SnowBallData.Inst.prepareThrow(this.track);
                if (!throwSuccess) return;
                this.btn.mouseEnabled = false;
            }, null, false);
            this.comMaskGraphics = (this.comMask.mask).graphics;
            this.comMaskGraphics.clear();
            this.comMaskGraphics.drawPie(92, 92, 125, 0, 210, '#000000');
        }

        show(state: ISnowBallPlayerState) {
            this.buffConfig = SnowBallData.Inst.upgradeData.find(data => data.type == this.track);
            if (!this.buffConfig) {
                this.enable = false;
                return;
            } else {
                this.enable = true;
            }
            this.comMask.visible = false;
            this.txtCD.visible = false;
            this.config = SnowBallData.Inst.weaponInfo[this.track];
            this.refreshGray(state.mp);
            this.clearMask();
        }

        public refresh(tickInfo: ISnowBallTickInfo) {
            if (!this.buffConfig) return;
            let event = tickInfo.events.find(event => event.player == ESnowBallPlayerType.player && event.state_change && event.state_change.mp_change);
            if (event) this.refreshGray(tickInfo.players[ESnowBallPlayerType.player].mp);
            this.refreshCD(tickInfo.skillCD[this.track]);
        }

        private refreshGray(nowMP: number) {
            let isGray = nowMP < this.config.mp_consume;
            this.me.mouseEnabled = !isGray;
            this.imgBg.skin = game.Tools.localUISrc(isGray ? 'myres/activity_2512winter/combat_interface_weapon_base.png' : 'myres/activity_2512winter/combat_interface_weapon_base_1.png');
            this.imgMPBg.skin = game.Tools.localUISrc(isGray ? 'myres/activity_2512winter/weapon_level_bg.png' : 'myres/activity_2512winter/weapon_level_bg_gray.png');
            let mp = this.config.mp_consume;
            this.imgMP[0].x = mp >= 10 ? 2 : 9;
            let mpStr = mp.toString();
            for (let i = 0; i < this.imgMP.length; i++) {
                if (mpStr[i]) {
                    this.imgMP[i].visible = true;
                    this.imgMP[i].skin = game.Tools.localUISrc('myres/activity_2512winter/font/' + (isGray ? 'mp2_' : 'mp1_') + mpStr[i] + '.png');
                } else {
                    this.imgMP[i].visible = false;
                }
            }
            this.imgIcon.skin = game.Tools.localUISrc('myres/activity_2512winter/weapon_' + (this.track + 1) + (isGray ? '_gray' : '') + '.png');
            this.imgStars.forEach((img, index) => {
                if (isGray) {
                    img.skin = game.Tools.localUISrc(index < this.buffConfig.level ? 'myres/activity_2512winter/weapon_level_star2.png' : 'myres/activity_2512winter/weapon_level_star1.png');
                } else {
                    img.skin = game.Tools.localUISrc(index < this.buffConfig.level ? 'myres/activity_2512winter/weapon_level_star2_gray.png' : 'myres/activity_2512winter/weapon_level_star1_gray.png');
                }
            });
        }

        private refreshCD(cd: number) {
            if (cd == 0) {
                this.clearMask();
                return;
            }
            const oneMS = 1 / (this.config.cd / SnowBallData.Inst.ticks) / 1000;
            this.nowProgress = 1 - cd / this.config.cd;
            this.lastTime = SnowBallData.Inst.currTimer;
            this.refreshMask();
            SnowBallData.Inst.timer.clearAll(this);
            SnowBallData.Inst.timer.frameLoop(1, this, () => {
                let delay = SnowBallData.Inst.currTimer - this.lastTime;
                if (delay == 0) return;
                this.lastTime = SnowBallData.Inst.currTimer;
                this.nowProgress += delay * oneMS / SnowBallData.Inst.speed;
                this.refreshMask();
            });
        }

        private refreshMask() {
            if (this.nowProgress >= 1) {
                this.clearMask();
                return;
            }
            const cd = this.config.cd;
            this.comMaskGraphics.clear();
            this.comMaskGraphics.drawPie(92, 92, 125, 0, (1 - this.nowProgress) * 360, '#000000');
            this.btn.mouseEnabled = false;
            this.comMask.visible = true;
            this.txtCD.visible = true;
            this.txtCD.text = Math.ceil((cd - this.nowProgress * cd) / SnowBallData.Inst.ticks).toString();
        }

        private clearMask() {
            SnowBallData.Inst.timer.clearAll(this);
            this.nowProgress = 360;
            this.comMask.visible = false;
            this.txtCD.visible = false;
            this.btn.mouseEnabled = true;
        }

        public reset() {
            this.clearMask();
        }
    }

    export class FlyingItem {
        private me: Laya.Sprite;
        private father: UI_Activity_SnowBall_Game;
        private flying: boolean = false;
        public flyingData: ISnowBallFlyItem;
        private effect: Laya.Sprite3D;

        constructor(me: Laya.Sprite, father: UI_Activity_SnowBall_Game) {
            this.me = me;
            this.father = father;
        }

        public refreshState(data: ISnowBallFlyItem, forceBreak: boolean = false) {
            if (data.state == ESBFlyState.fly && this.flying && !forceBreak) return;
            this.flyingData = game.Tools.deepCopy(data);
            if (data.state == ESBFlyState.hit || data.state == ESBFlyState.offset || forceBreak) {
                this.flying = false;
                if (this.effect && (data.state != ESBFlyState.offset || data.target == ESnowBallPlayerType.boss || forceBreak)) {
                    SnowBallEffectMgr.Inst.showHit(this.effect, data.state == ESBFlyState.hit && data.crit);
                }
                this.remove();
                return;
            }
            if (data.state == ESBFlyState.start) {
                this.effect = SnowBallEffectMgr.Inst.showBall(data.track, data.target, data.crit);
                this.me.visible = true;
                this.flying = true;
            }
        }

        public remove() {
            if (this.effect) {
                SnowBallEffectMgr.Inst.hideEffect(this.effect, this.flyingData.track, this.flyingData.crit);
                this.effect = null;
            }
            this.me.visible = false;
            this.flyingData = null;
            this.flying = false;
            this.father.removeFlyingItem(this);
        }
    }

    export class UI_Activity_SnowBall_Game extends UIBase {
        public static Inst: UI_Activity_SnowBall_Game = null;
        public static activityId: number = 251201;
        private boss: UI_Player_Item;
        private player: UI_Player_Item;
        private comAbility: Laya.Sprite;
        private abilitys: UI_Ability_Item[];
        private btnAuto: Laya.Button;
        private btnSpeed: Laya.Button;
        private comRound: Laya.Sprite;
        private comLevel: Laya.Sprite;
        private comCD: Laya.Sprite;
        private imgCDs: Laya.Image[];
        private imgLevels: Laya.Image[];
        private levelConfig: lqc.Sheet_Snowball_SnowballMonsterGroup;
        private comPK: Laya.Sprite;
        private comBalls: Laya.Sprite;
        private templeteUI: capsui.UICopy;
        private comCombo: Laya.Sprite;
        private imgComboBg: Laya.Image;
        private comComboValue: Laya.Sprite;
        private imgComboTemplete: capsui.UICopy;
        private imgsCombo: Laya.Image[];
        private flyingItems: FlyingItem[] = [];
        private unUsedflyingItems: FlyingItem[] = [];
        private nowTime: number = 0;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniShowCombo: Laya.FrameAnimation;
        private aniHideCombo: Laya.FrameAnimation;
        private aniSpeed: Laya.FrameAnimation;
        private aniAuto: Laya.FrameAnimation;
        public locking: boolean;
        private posAbilitys: Laya.Point[] = [];

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_gameUI);
            UI_Activity_SnowBall_Game.Inst = this;
        }

        public onCreate(): void {
            this.boss = new UI_Player_Item(this.me.getChildByName('boss') as Laya.Sprite, UI_Activity_SnowBall_Main.Inst.boss, ESnowBallPlayerType.boss);
            this.player = new UI_Player_Item(this.me.getChildByName('player') as Laya.Sprite, UI_Activity_SnowBall_Main.Inst.player, ESnowBallPlayerType.player);

            this.comCombo = this.me.getChildByName('player').getChildByName('combo') as Laya.Sprite;
            this.imgComboBg = this.comCombo.getChildByName('bg') as Laya.Image;
            this.comComboValue = this.comCombo.getChildByName('value') as Laya.Sprite;
            let templete = this.comComboValue.getChildByName('templete') as Laya.Image;
            this.imgComboTemplete = templete.scriptMap["capsui.UICopy"] as capsui.UICopy;
            this.imgsCombo = [templete];
            this.comAbility = this.me.getChildByName('abilitys') as Laya.Sprite;
            this.abilitys = [];
            for (let i = 2; i >= 0; i--) {
                let item = this.comAbility.getChildAt(i) as Laya.Sprite;
                this.posAbilitys.push(new Laya.Point(item.x, item.y));
                this.abilitys.push(new UI_Ability_Item(item, i, this));
            }
            this.btnAuto = this.me.getChildByName('btn_auto') as Laya.Button;
            this.btnSpeed = this.me.getChildByName('btn_speed') as Laya.Button;

            this.comRound = this.me.getChildByName('round') as Laya.Sprite;
            this.comLevel = this.comRound.getChildByName('now_level') as Laya.Sprite;
            this.imgLevels = this.comLevel._childs;
            this.imgLevels.forEach(img => img.visible = false);

            this.comCD = this.comRound.getChildByName('countdown') as Laya.Sprite;
            this.imgCDs = [];
            for (let i = 0; i < 4; i++) {
                this.imgCDs.push(this.comCD.getChildAt(i) as Laya.Image);
            }

            this.comPK = this.me.getChildByName('pk') as Laya.Button;
            this.comBalls = this.comPK.getChildByName('balls') as Laya.Sprite;
            let templeteBall = (this.comPK.getChildByName('templete') as Laya.Sprite);
            templeteBall.visible = false;
            this.templeteUI = templeteBall.scriptMap['capsui.UICopy'];

            this.btnAuto.clickHandler = Laya.Handler.create(this, () => {
                SnowBallData.Inst.autoAttack = !SnowBallData.Inst.autoAttack;
                this.refreshBtn();
            }, null, false);

            this.btnSpeed.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                SnowBallData.Inst.speed = SnowBallData.Inst.speed == 1 ? 0.5 : 1;
                this.refreshBtn();
            }, null, false);

            let aniRoot = this.me as ui.lobby.activity_2512winter.activity_2512winter_gameUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
            this.aniShowCombo = aniRoot.combo;
            this.aniHideCombo = aniRoot.combo_hide;
            this.aniSpeed = aniRoot.speed;
            this.aniAuto = aniRoot.auto;
            this.btnSpeed.visible = false;
        }

        private showCombo() {
            if (!this.comCombo) return;
            this.comCombo.visible = true;
            this.aniHideCombo.stop();
            this.aniShowCombo.play(0, false);
            let value = SnowBallData.Inst.tempComboCount;
            let valueStr = value.toString();
            this.comComboValue.width = valueStr.length * 70;
            this.comComboValue.pivotX = this.comComboValue.width / 2;
            this.comComboValue.x = 108 - this.comComboValue.pivotX;
            this.imgComboBg.width = this.comComboValue.width + 257;
            for (let i = 0; i < valueStr.length; i++) {
                let str = valueStr[i];
                let img = this.imgsCombo[i];
                if (!img) {
                    img = this.imgComboTemplete.getNodeClone() as Laya.Image;
                    this.comComboValue.addChild(img);
                    this.imgsCombo.push(img);
                }
                img.x = 70 * i;
                img.visible = true;
                img.skin = game.Tools.localUISrc('myres/activity_2512winter/font/hit_' + str + '.png');
            }
            if (valueStr.length < this.imgsCombo.length) {
                for (let i = valueStr.length; i < this.imgsCombo.length; i++) {
                    this.imgsCombo[i].visible = false;
                }
            }
        }

        public hideCombo() {
            if (!this.comCombo.visible) return;
            if (this.aniHideCombo.isPlaying) return;
            this.aniShowCombo.stop();
            this.aniHideCombo.play(0, false);
            this.aniHideCombo.once('complete', this, () => {
                this.comCombo.visible = false;
            });
        }


        updateState(data: ISnowBallTickInfo) {
            this.locking = false;
            this.boss.refresh(data);
            this.player.refresh(data);
            this.abilitys.forEach(ability => ability.refresh(data));
            this.refreshCDShow();
        }

        public onEliminate(data: ISnowBallTickInfo) {
            // app.Log.log(JSON.stringify(data));
            let offsetballs = [];
            let throwMark = false;
            let throwCritMark = false;
            let breakMark = false;
            let breakCritMark = false;
            for (let i = 0; i < data.events.length; i++) {
                let event = data.events[i];
                if (event.type == ESnowBallEventType.hit) {
                    if (event.player == ESnowBallPlayerType.boss) {
                        this.showCombo();
                    } else {
                        this.hideCombo();
                    }
                    if (event.player_attacked.critical) {
                        breakCritMark = true;
                    } else {
                        breakMark = true;
                    }
                } else if (event.type == ESnowBallEventType.offset) {
                    if (event.ball_action.isCrit) {
                        //如果是被暴击抵消，这个球必碎
                        offsetballs.push(event.ball_action.balls_id[0]);
                    }
                    breakMark = true;
                } else if (event.type == ESnowBallEventType.throw) {
                    if (event.throw_action.critical) {
                        throwCritMark = true;
                    } {
                        throwMark = true;
                    }
                }
            }
            if (throwMark) view.AudioMgr.PlayAudio(10372);
            if (throwCritMark) view.AudioMgr.PlayAudio(10373);
            if (breakMark) view.AudioMgr.PlayAudio(10374);
            if (breakCritMark) view.AudioMgr.PlayAudio(10375);
            if (data.fly_item_list && data.fly_item_list.length > 0) {
                data.fly_item_list.forEach((value) => {
                    let flyingItem: FlyingItem = this.flyingItems.find((v: FlyingItem) => v.flyingData.id == value.id);
                    if (!flyingItem) {
                        if (this.unUsedflyingItems.length > 0) {
                            flyingItem = this.unUsedflyingItems.pop();
                        } else {
                            let item = this.templeteUI.getNodeClone();
                            this.comBalls.addChild(item);
                            flyingItem = new FlyingItem(item, this);
                        }
                        this.flyingItems.push(flyingItem);
                    }
                    flyingItem.refreshState(value, offsetballs.indexOf(value.id) >= 0);
                })
            }

        }

        startRound(fromHome: boolean = false) {
            this.locking = true;
            this.reset();
            this.refreshBtn();
            this.refreshRound();
            let states = SnowBallData.Inst.initStates;
            this.showPlayer(states);
            this.refreshCDShow();
            let index = 0;
            this.abilitys.forEach(ability => {
                ability.show(states[ESnowBallPlayerType.player]);
                if (ability.enable) {
                    let pos = this.posAbilitys[index];
                    if (pos) {
                        ability.me.pos(pos.x, pos.y);
                    }
                    index++;
                }
            });
            let doSpineDelay = !fromHome && SnowBallData.Inst.resultType == ESnowBallResultType.playerWin;
            let delay = 0;
            if (SnowBallData.Inst.nowLevelConfig.type == 1) {
                SnowBallData.Inst.timer.once((fromHome ? 200 : 0), this, () => {
                    UI_Activity_SnowBall_VS.Inst.show();
                });
                delay = doSpineDelay ? 85 / 60 * 1000 : 0;
            }
            SnowBallData.Inst.timer.once(delay, this, () => {
                this.boss.refreshSpine();
            });
        }

        prepareEnd() {
            this.refreshBtn();
            if (this.flyingItems.length > 0) {
                view.AudioMgr.PlayAudio(10374);
            }
            while (this.flyingItems.length > 0) {
                let item = this.flyingItems.pop();
                item.refreshState(item.flyingData, true);
            }
        }

        endRound(result: ESnowBallResultType, level: number) {
            this.locking = true;
            if (result == ESnowBallResultType.playerWin) {
                view.AudioMgr.PlayAudio(10377);
                SnowBallEffectMgr.Inst.showKO();
            }
            let bossAnim: ESnowBallSpineAnim;
            let playerAnim: ESnowBallSpineAnim;
            if (result == ESnowBallResultType.allDie) {
                bossAnim = ESnowBallSpineAnim.Die;
                playerAnim = ESnowBallSpineAnim.Die;
            } else if (result == ESnowBallResultType.playerWin) {
                bossAnim = ESnowBallSpineAnim.Die;
                playerAnim = ESnowBallSpineAnim.Win;
            } else if (result == ESnowBallResultType.bossWin) {
                bossAnim = ESnowBallSpineAnim.Win;
                playerAnim = ESnowBallSpineAnim.Die;
            }
            SnowBallData.Inst.timer.once(700, this, () => {
                if (bossAnim) {
                    this.boss.spine.playAnim(bossAnim);
                    if (bossAnim == ESnowBallSpineAnim.Die) {
                        let levelConfig = SnowBallData.Inst.roundConfig.get(level);
                        let pos = game.UIEffect.getTargetPos(this.boss.me, new Laya.Point(levelConfig.dead_offset, 0));
                        SnowBallEffectMgr.Inst.showDie(levelConfig.type == 1, new Laya.Vector3(-pos.x, -3.5, pos.z));
                    }
                }
                if (playerAnim) this.player.spine.playAnim(playerAnim);
                this.hideCombo();
                let delay = bossAnim || playerAnim ? 1000 : 0;
                SnowBallData.Inst.timer.once(delay, this, () => {
                    UI_Activity_SnowBall_Result.Inst.show(result, level);
                });
            });
        }

        public show() {
            this.enable = true;
            this.startRound(true);
            this.aniShow.play(0, false);
        }

        refreshBtn() {
            if (SnowBallData.Inst.speed == 1) {
                this.aniSpeed.stop();
            } else if (!this.aniSpeed.isPlaying) {
                this.aniSpeed.play(0, true);
            }
            if (!SnowBallData.Inst.autoAttack) {
                this.aniAuto.stop();
            } else if (!this.aniAuto.isPlaying) {
                this.aniAuto.play(0, true);
            }
            this.btnSpeed.skin = game.Tools.localUISrc(SnowBallData.Inst.speed == 1 ? 'myres/activity_2512winter/button_double_speed_1.png' : 'myres/activity_2512winter/button_double_speed.png');
            (this.btnSpeed.getChildAt(0) as Laya.Image).visible = SnowBallData.Inst.speed != 1;
            this.btnAuto.skin = game.Tools.localUISrc(SnowBallData.Inst.autoAttack ? 'myres/activity_2512winter/button_automatic.png' : 'myres/activity_2512winter/button_automatic_1.png');
            (this.btnAuto.getChildAt(0) as Laya.Image).visible = SnowBallData.Inst.autoAttack;
        }

        showPlayer(states: ISnowBallPlayerState[]) {
            this.boss.show(states[ESnowBallPlayerType.boss]);
            this.player.show(states[ESnowBallPlayerType.player]);
        }

        public refreshRound() {
            let haveFinished = SnowBallData.Inst.passGameCount > 0;
            this.levelConfig = SnowBallData.Inst.nowLevelConfig;
            let levelName = (haveFinished ? 'o' : '') + this.levelConfig.chapters;
            this.imgLevels.forEach((img, index) => {
                img.visible = false;
                if (levelName[index]) {
                    img.skin = game.Tools.localUISrc('myres/activity_2512winter/font/fight_' + levelName[index] + '.png');
                    img.x = 21 * index;
                    img.visible = true;
                }
            });
            if (haveFinished) this.imgLevels[0].x = -4;
            this.comLevel.x = 80 - levelName.length * 21 / 2;

        }

        refreshCDShow() {
            let time = SnowBallData.Inst.nowTime;
            if (time == this.nowTime) return;
            this.nowTime = time;
            let timeStr = time.toString() + 's';
            this.comCD.x = 83 - timeStr.length * 40 / 2;
            this.imgCDs.forEach((img, index) => {
                img.visible = false;
                if (timeStr[index]) {
                    img.skin = game.Tools.localUISrc('myres/activity_2512winter/font/cd_' + timeStr[index] + '.png');
                    img.visible = true;
                    img.x = index * 40;
                }
            });
        }

        public removeFlyingItem(item: FlyingItem) {
            this.unUsedflyingItems.push(item);
            if (this.flyingItems.indexOf(item) != -1) {
                this.flyingItems.splice(this.flyingItems.indexOf(item), 1);
            }
        }

        public hide() {
            this.locking = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            })
        }
        public onEnable(): void {
            SnowBallData.Inst.on(SnowBallDataEvent.DoAction, this, this.onEliminate);
            SnowBallData.Inst.on(SnowBallDataEvent.UpdateState, this, this.updateState);
            SnowBallData.Inst.on(SnowBallDataEvent.RoundStart, this, this.startRound, [false]);
            SnowBallData.Inst.on(SnowBallDataEvent.RoundEnd, this, this.endRound);
            SnowBallData.Inst.on(SnowBallDataEvent.PrepareEnd, this, this.prepareEnd);
        }

        public onDisable(): void {
            this.reset();
            SnowBallData.Inst.off(SnowBallDataEvent.DoAction, this, this.onEliminate);
            SnowBallData.Inst.off(SnowBallDataEvent.UpdateState, this, this.updateState);
            SnowBallData.Inst.off(SnowBallDataEvent.RoundStart, this, this.startRound);
            SnowBallData.Inst.off(SnowBallDataEvent.RoundEnd, this, this.endRound);
            SnowBallData.Inst.off(SnowBallDataEvent.PrepareEnd, this, this.prepareEnd);
        }

        public reset(): void {
            this.nowTime = 0;
            this.abilitys.forEach((ability) => ability.reset());
            this.player.reset();
            this.boss.reset();
            this.flyingItems.forEach((item) => item.remove());
            this.unUsedflyingItems.forEach((item) => item.remove());
            this.flyingItems = [];
            this.unUsedflyingItems = [];
            SnowBallData.Inst.timer.clearAll(this);
            this.comBalls._childs.forEach((value: Laya.Sprite) => {
                value.removeSelf();
                value.destroy();
            });
            SnowBallEffectMgr.Inst.clear();
            this.comCombo.visible = false;
            this.aniShowCombo.stop();
            this.aniHideCombo.stop();
            this.aniShow.stop();
            this.aniHide.stop();
            this.locking = false;
        }

    }
}