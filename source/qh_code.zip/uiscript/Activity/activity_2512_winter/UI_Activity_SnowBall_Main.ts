module uiscript {

    export enum ESnowBallSpineAnim {
        Attack = "attack",
        Die = "die",
        Enter = "enter",
        Hit = "hit",
        Idle = "idle",
        Win = "win",
    }

    export class UI_SnowBall_Spine {
        private me: Laya.Sprite;
        private illust: Laya.Sprite;
        private spine: CatFoodSpine.SpineController;
        private spineSprite: CatFoodSpine.SpineSprite;
        private btnClick: Laya.Button;
        private btnClickBig: Laya.Button;
        private name: string = '';
        private type: ESnowBallPlayerType;
        private config: lqc.Sheet_Snowball_SnowballActivity | lqc.Sheet_Snowball_SnowballMonsterGroup;
        private audioIds: number[] = [];
        private locking: boolean;

        constructor(me: Laya.Sprite, type: ESnowBallPlayerType) {
            this.me = me;
            this.type = type;
            this.illust = this.me.getChildByName('illust') as Laya.Sprite;
            this.btnClick = this.me.getChildByName('btn') as Laya.Button;
            this.btnClickBig = this.me.getChildByName('btn1') as Laya.Button;
            this.btnClick.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (SnowBallData.Inst.gaming) return;
                this.playAnim(ESnowBallSpineAnim.Hit);

            });
            if (this.btnClickBig) {
                this.btnClickBig.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    if (SnowBallData.Inst.gaming) return;
                    this.playAnim(ESnowBallSpineAnim.Hit);
                });
            }
        }

        public show(name: string) {
            if (this.name == name && this.spine) {
                this.spine.root.visible = true;
                this.spine.play(ESnowBallSpineAnim.Idle);
                return;
            }
            this.config = this.type == ESnowBallPlayerType.boss ? SnowBallData.Inst.nowLevelConfig : SnowBallData.Inst.baseConfig;
            if (this.type == ESnowBallPlayerType.boss || !this.spine) {
                this.refreshSpine(name);
            }
            if (this.type == ESnowBallPlayerType.boss) {
                this.btnClick.visible = this.config['type'] != 1;
                this.btnClickBig.visible = this.config['type'] == 1;
            }
        }

        public refreshSpine(name: string) {
            this.name = name;
            this.spine = CatFoodSpine.SpineMgr.Inst.getSpecialSprite("snowball" + this.type, game.Tools.localUISrc('extendRes/spine/2512dongri/' + name), { id: 0 } as any);
            this.spine.root.visible = true;
            this.spineSprite = this.spine['spines'][0];

            this.spine.root.pos(0, 0);
            (this.spine.root as Laya.Sprite).visible = true;
            this.spine.onParentChange(1, new Laya.Point(0, 0)); //以0.966为基准
            this.spine.pX = 0;
            this.spine.pY = 0;
            this.spine.offsetX = 0;
            this.spine.offsetY = 1080;
            this.spine.sx = this.spine.sy = 1;
            this.spine.aniAlpha = true;
            this.spine.updateSpineInfo();
            this.illust.addChild(this.spine.root);
            this.playAnim(ESnowBallSpineAnim.Enter);
        }

        public playAnim(animName: ESnowBallSpineAnim) {
            if (!this.spine) return;
            if (this.config['audio_' + animName]) {
                let audioId = view.AudioMgr.PlaySound(this.config['audio_' + animName], view.AudioMgr.audioVolume, Laya.Handler.create(this, () => {
                    let index = this.audioIds.indexOf(audioId);
                    if (index >= 0) this.audioIds.splice(index, 1);
                }), 0, view.EAudioType.audio);
                this.audioIds.push(audioId);
            }
            this.spine.play(animName);
            if (animName == ESnowBallSpineAnim.Die && this.name != SnowBallData.Inst.baseConfig.player_id) {
                this.spineSprite['anim'].anim.setCompleteHandler(animName, Laya.Handler.create(this, () => {
                    this.spine.root.visible = false;
                }));
            }
            if (animName == ESnowBallSpineAnim.Enter) {
                this.locking = true;
                let delay = this.type == ESnowBallPlayerType.player ? 2000 : (this.config as lqc.Sheet_Snowball_SnowballMonsterGroup).enter_delay * SnowBallData.Inst.oneTickTime * 1000;
                Laya.timer.once(delay, this, () => {
                    this.locking = false;
                });
            }
        }

        clear() {
            for (let i = 0; i < this.audioIds.length; i++) {
                view.AudioMgr.StopAudio(this.audioIds[i]);
            }
            this.audioIds = [];
            if (!this.spine) return;
            this.spine.reset();
            this.spine = null;
        }
    }

    export class UI_Activity_SnowBall_Main extends UIBase {
        public static Inst: UI_Activity_SnowBall_Main = null;
        public static activityId: number = 251201;
        public static currencyId: number = 30900096;
        public static needShow: boolean = false;
        public static haveRedPoint() {
            if (UI_Activity_SnowBall_Reward.haveRedPoint()) return true;
            if (SnowBallData.Inst.haveUnrecivedReward && UI_Activity_SnowBall_Task.haveRedPoint()) return true;
            // if (UI_Activity_SnowBall_Upgrade.haveRedPoint()) return true;
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_mainUI);
            UI_Activity_SnowBall_Main.Inst = this;
        }

        public comBg: Laya.Sprite;
        private imgBg: Laya.Image;
        private comFight: Laya.Sprite;
        private comMain: Laya.Sprite;
        private comPopup: Laya.Sprite;
        private comTop: Laya.Sprite;
        private comBottom: Laya.Sprite;
        private comMiddle: Laya.Sprite;

        private imgLogo: Laya.Image;
        private comCompleted: Laya.Sprite;
        private btnPlay: Laya.Button;
        private comLevel: Laya.Label;
        private txtLevel: Laya.Label;

        private btnTask: Laya.Button;
        private comReward: Laya.Sprite;
        private btnReward: Laya.Button;
        private imgTipReceive: Laya.Image;
        private btnRewardTip: Laya.Button;
        private btnRewardItem: Laya.Sprite;
        private btnUpgrade: Laya.Button;
        private rewardItemRect: UIRect;


        private btnReturn: Laya.Button;
        private btnMute: Laya.Button;
        private btnHelp: Laya.Button;

        private pageGame: UI_Activity_SnowBall_Game;
        private pageVS: UI_Activity_SnowBall_VS;
        private pageResult: UI_Activity_SnowBall_Result;
        private pageReward: UI_Activity_SnowBall_Reward;
        private pageTask: UI_Activity_SnowBall_Task;
        private pageUpgrade: UI_Activity_SnowBall_Upgrade;

        public boss: UI_SnowBall_Spine;
        public player: UI_SnowBall_Spine;

        private bgmMuted: boolean = false;
        private audioId: number = 0;
        public locking: boolean;
        private activityFinishHandler: Laya.Handler;
        private effectBg: Laya.Scene;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private btnTipAnim = false;
        private aniShowPage: Laya.FrameAnimation;
        private aniHidePage: Laya.FrameAnimation;
        private yindaoChecked: number;

        public onCreate(): void {
            this.comBg = this.me.getChildByName('bg') as Laya.Sprite;
            this.imgBg = this.comBg.getChildByName('bg') as Laya.Image;
            this.comFight = this.me.getChildByName('fight') as Laya.Sprite;
            this.comMain = this.me.getChildByName('main') as Laya.Sprite;
            this.comPopup = this.me.getChildByName('popup') as Laya.Sprite;
            this.comTop = this.me.getChildByName('top') as Laya.Sprite;
            this.comBottom = this.comMain.getChildByName('bottom') as Laya.Sprite;
            this.comMiddle = this.comMain.getChildByName('middle') as Laya.Sprite;
            this.imgLogo = this.comMiddle.getChildByName('logo') as Laya.Image;
            this.btnHelp = this.comTop.getChildByName('btn_help') as Laya.Button;
            this.btnReturn = this.comTop.getChildByName('btn_return') as Laya.Button;
            this.btnMute = this.comTop.getChildByName('btn_mute') as Laya.Button;

            this.comReward = this.comBottom.getChildByName('reward') as Laya.Sprite;
            this.imgTipReceive = this.comReward.getChildByName('tip_receive') as Laya.Image;
            this.btnReward = this.comReward.getChildByName('btn_reward') as Laya.Button;
            this.btnRewardTip = this.comReward.getChildByName('btn_reward_tip') as Laya.Button;
            this.btnTask = this.comBottom.getChildByName('btn_task') as Laya.Button;
            this.btnUpgrade = this.comBottom.getChildByName('btn_upgrade') as Laya.Button;
            let comPlay = this.comMiddle.getChildByName('start') as Laya.Sprite;
            this.comCompleted = (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).completed as Laya.Sprite;
            this.comLevel = comPlay.getChildByName('now_level') as Laya.Label;
            this.txtLevel = this.comLevel.getChildByName('now_level') as Laya.Label;
            this.btnPlay = comPlay.getChildByName('btn_start') as Laya.Button;
            this.pageGame = new UI_Activity_SnowBall_Game();
            this.comFight.getChildByName('ui').addChild(this.pageGame.me);
            this.pageReward = new UI_Activity_SnowBall_Reward();
            this.pageTask = new UI_Activity_SnowBall_Task();
            this.pageUpgrade = new UI_Activity_SnowBall_Upgrade();
            this.comPopup.addChild(this.pageReward.me);
            this.comPopup.addChild(this.pageTask.me);
            this.comPopup.addChild(this.pageUpgrade.me);
            this.pageVS = new UI_Activity_SnowBall_VS();
            this.pageResult = new UI_Activity_SnowBall_Result();
            this.comPopup.addChild(this.pageVS.me);
            this.comPopup.addChild(this.pageResult.me);
            this.player = new UI_SnowBall_Spine(this.comFight.getChildByName('ui').getChildByName('player') as Laya.Sprite, ESnowBallPlayerType.player);
            this.boss = new UI_SnowBall_Spine(this.comFight.getChildByName('ui').getChildByName('boss') as Laya.Sprite, ESnowBallPlayerType.boss);

            this.btnReward.clickHandler = this.btnRewardTip.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_SnowBall_Reward.Inst.show();
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_SnowBall_Task.Inst.show();
            });
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_SnowBall_Upgrade.Inst.show();
            });
            this.btnMute.clickHandler = new Laya.Handler(this, () => {
                this.bgmMuted = !this.bgmMuted;
                Laya.LocalStorage.setItem('activityMuted' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id, (this.bgmMuted ? '1' : '0'));
                this.refreshBgm();
            }, null, false);

            this.btnReturn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.pageGame.locking) return;
                if (this.pageGame.enable) {
                    SnowBallData.Inst.pause();
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(25120113), Laya.Handler.create(this, () => {
                        SnowBallData.Inst.reset();
                        this.backToHome();
                    }), Laya.Handler.create(this, () => {
                        SnowBallData.Inst.resume();
                    }), 960, 530, 25120114, 25120115);
                    return;
                }
                this.hide();
            });
            this.btnHelp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.pageGame.locking) return;
                this.showRules();
            }, null, false);
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            // game.LoadMgr.setImgSkin(this.imgBg, 'myres/activity_2512winter/bg.jpg', null, 'UI_Activity_SnowBall_Main');

            this.btnPlay.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                let level = SnowBallData.Inst.nowLevelConfig;
                if (level.level == 1 && SnowBallData.Inst.passGameCount == 1) {
                    let playTip = Laya.LocalStorage.getItem('playTipAfterSuccess' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id);
                    if (!playTip) {
                        Laya.LocalStorage.setItem('playTipAfterSuccess' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id, '1');
                        UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(25120130), Laya.Handler.create(this, () => {
                            SnowBallData.Inst.playGame(true);
                        }));
                        return;
                    }
                }
                SnowBallData.Inst.playGame(true);
            });
            this.aniShow = (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).hide;
            this.aniShowPage = (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).showpage;
            this.aniHidePage = (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).hidepage;
            let muteCache = Laya.LocalStorage.getItem('activityMuted' + UI_Activity_SnowBall_Main.activityId + GameMgr.Inst.account_id);
            this.bgmMuted = muteCache && muteCache == '1';
            if (GameMgr.client_language == 'kr') {
                const rewardTip = this.btnRewardTip.getChildByName('tip') as Laya.Label;
                let labelSize: capsui.LabelLocalizationSize = rewardTip.scriptMap['capsui.LabelLocalizationSize'];
                labelSize.change_width(125);
            }
            // ==DevDebug Start==
            let debugUI = new UI_Activity_SnowBall_Debug();
            this.me.addChild(debugUI.me);
            Laya.timer.frameOnce(5, this, () => {
                debugUI.enable = true;
            });
            // ==DevDebug End==
        }
        private showRules() {
            let onClose: Laya.Handler = null;
            if (this.pageGame.enable) {
                SnowBallData.Inst.pause();
                onClose = Laya.Handler.create(this, () => {
                    SnowBallData.Inst.resume();
                })
            }
            let extraConfig: IRuleExtraConfig = {
                onClose: Laya.Handler.create(this, () => {
                    UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25120101), true, onClose);
                })
            }
            UI_Activity_Rules.Inst.show(extraConfig)
            view.AudioMgr.PlayAudio(10380);
        }

        backToHome() {
            this.locking = true;
            this.pageGame.hide();
            this.aniHidePage.play(0, false);
            Laya.timer.once(this.aniHidePage.count * this.aniHidePage.interval, this, () => {
                this.comMain.visible = true;
                this.refresh();
                view.AudioMgr.PlayAudio(10371);
                this.aniShow.play(0, false);
                Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                    this.locking = false;
                });
            });
        }

        startGame() {
            this.locking = true;
            this.aniHide.play(0, false);
            if (this.pageReward.enable) this.pageReward.close();
            if (this.pageReward.enable) this.pageReward.close();
            if (this.pageUpgrade.enable) this.pageUpgrade.hide();
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.comMain.visible = false;
                this.aniShowPage.play(0, false);
                this.pageGame.show();
            })
        }


        refreshRedPoint() {
            (this.btnTask.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_SnowBall_Task.haveRedPoint();
            // (this.btnReward.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_SnowBall_Reward.haveRedPoint();
            (this.btnUpgrade.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_SnowBall_Upgrade.haveRedPoint();
        }

        public show() {
            view.AudioMgr.StopMusic(0);
            this.refreshBgm();
            this.enable = true;
            this.refresh();
            this.player.playAnim(ESnowBallSpineAnim.Enter);
            this.boss.playAnim(ESnowBallSpineAnim.Enter);
            this.locking = true;
            view.AudioMgr.PlayAudio(10371);
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            });
            if (!this.yindaoChecked) {
                let checked = app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.SnowBall_Yindao_Checked);
                this.yindaoChecked = 1;
                if (!checked) {
                    app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.SnowBall_Yindao_Checked, 1);
                    this.showRules();
                }
            }
        }


        public refresh() {
            this.comCompleted.visible = SnowBallData.Inst.passGameCount > 0;
            let levelConfig = SnowBallData.Inst.nowLevelConfig;
            if (this.comCompleted.visible) {
                this.txtLevel.text = game.Tools.strOfLocalization(25120105, [(SnowBallData.Inst.passGameCount + 1).toString(), levelConfig.chapters]);
            } else {
                this.txtLevel.text = game.Tools.strOfLocalization(25120102, [levelConfig.chapters]);
            }
            this.refreshRedPoint();
            this.refreshNextReward();
            this.player.show(SnowBallData.Inst.baseConfig.player_id);
            this.boss.show(SnowBallData.Inst.nowLevelConfig.boss_id);
        }


        public hide(onClose?: Laya.Handler) {
            this.locking = true;
            this.aniHide.play(0, false);
            UI_Lobby.Inst.enable = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
            }
        }

        public refreshBgm(audioId: number = 10370) {
            (this.btnMute.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(this.bgmMuted ? 'myres/activity_2512winter/button_sound.png' : 'myres/activity_2512winter/button_sound_1.png')
            if (this.bgmMuted || view.AudioMgr.musicMuted) {
                this.stopBgm();
                return;
            }
            let audioPath = cfg.audio.audio.get(audioId).path;
            let volume = view.AudioMgr.musicVolume;
            this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);
        }

        public onDisable(): void {
            this.player.clear();
            this.boss.clear();
            SnowBallData.Inst.off(SnowBallDataEvent.GameStart, this, this.startGame);
            this.btnTipAnim = false;
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Main', false);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            this.locking = false;
            Laya.timer.clearAll(this);
            this.stopBgm();
            view.BgmListMgr.PlayLobbyBgm();
            SnowBallData.Inst.reset();
            this.pageGame.enable = false;
            this.pageReward.enable = false;
            this.pageTask.enable = false;
            this.pageUpgrade.enable = false;
            this.pageVS.enable = false;
            this.pageResult.enable = false;
            this.comMain.visible = true;
        }

        public onEnable() {
            SnowBallData.Inst.reset();
            SnowBallData.Inst.on(SnowBallDataEvent.GameStart, this, this.startGame);
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Main', true);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_SnowBall_Main.activityId) {
                        SnowBallData.Inst.pause();
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.hide();
                        }))
                        return;
                    }
                }
            }
        }

        refreshNextReward() {
            const { highestLevel, roundConfig } = SnowBallData.Inst;
            let leftLevel = -1, lastFinishedId = 0;
            let bigRewardCfg: lqc.Sheet_Snowball_SnowballMonsterGroup;
            let smallRewardCfg: lqc.Sheet_Snowball_SnowballMonsterGroup;
            const keys = roundConfig.keys().sort((a, b) => a - b);
            for (const e of keys) {
                const cfg = roundConfig.get(e);
                const unlock_rest = SnowBallData.Inst.getRewardUnlockRest(cfg);
                if (unlock_rest <= 0 && cfg.level <= highestLevel) {
                    lastFinishedId = cfg.level;
                }
                if (cfg.reward) {
                    const state = SnowBallData.Inst.getRewardState(cfg);
                    if (cfg.node_mark) {
                        
                    } else {
                        if (!smallRewardCfg && unlock_rest <= 0 && state == 0) smallRewardCfg = cfg;
                    }
                }
            }
            const spLevels:lqc.Sheet_Snowball_SnowballMonsterGroup[] = [];
            for (const e of keys) {
                const cfg = roundConfig.get(e);
                if (cfg.node_mark == 1)
                    spLevels.push(cfg);
            }
            for (let i = 0; i < spLevels.length; i++) {
                const data = spLevels[i];
                const unlock_rest = SnowBallData.Inst.getRewardUnlockRest(data);
                const state = SnowBallData.Inst.getRewardState(data);
                if (unlock_rest <= 0 && state == 0) {
                    bigRewardCfg = data;
                    leftLevel = 0;
                    break;
                }
                if (data.level > lastFinishedId) {
                    bigRewardCfg = data
                    leftLevel = data.level - lastFinishedId;
                    break;
                }
            }

            if (bigRewardCfg) {
                Laya.timer.clearAll(this.btnRewardTip);
                if (!this.btnTipAnim) {
                    this.btnTipAnim = true;
                    this.btnRewardTip.visible = false;
                    Laya.timer.frameOnce(11, this.btnRewardTip, () => {
                        this.btnRewardTip.visible = true;
                        (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).btn_reward_tip.play(0, false);
                    });
                } else
                    this.btnRewardTip.visible = true;
                const rewardTip = this.btnRewardTip.getChildByName('tip') as Laya.Label;
                const btnItem = this.btnRewardTip.getChildByName('item') as Laya.Button;
                const bg = this.btnRewardTip.getChildByName('bg') as Laya.Image;
                const rewardItem = btnItem.getChildByName('item') as Laya.Image;
                if (leftLevel == 0) {
                    bg.skin = game.Tools.localUISrc('myres/activity_2512winter/btn_reward_popup_bg2.png');
                    rewardTip.text = game.Tools.strOfLocalization(25120106);
                } else {
                    bg.skin = game.Tools.localUISrc('myres/activity_2512winter/btn_reward_popup_bg1.png');
                    rewardTip.text = game.Tools.strOfLocalization(25120103, [leftLevel.toString()]);
                }

                const [rewardId] = common.ConfigHelper.configString2Array<number>(bigRewardCfg.reward)[0];
                if (!this.rewardItemRect)
                    this.rewardItemRect = UIRect.CreateFromSprite(rewardItem);
                game.Tools.setItemIcon(rewardItem, this.rewardItemRect, rewardId, "UI_Activity_SnowBall_Main", true);
            } else {
                this.btnRewardTip.visible = false;
            }
            if (smallRewardCfg) {
                this.imgTipReceive.visible = true;
                (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).tip_receive.play(0, true);
            } else {
                this.imgTipReceive.visible = false;
                (this.me as ui.lobby.activity_2512winter.activity_2512winter_mainUI).tip_receive.stop();
            }
        }

        public initScene() {
            SnowBallEffectMgr.Inst.init(this.comFight.getChildByName('scene') as Laya.Sprite);
            this.effectBg = Laya.loader.getRes('scene/effect_snowball_bg.ls');
            this.imgBg.addChild(this.effectBg);
        }

        public destroyScene() {
            SnowBallEffectMgr.Inst.destory();
            if (this.effectBg) {
                this.effectBg.destroy();
                this.effectBg = null;
            }
            CatFoodSpine.SpineMgr.Inst.clearSpecialSprites();
        }
    }

    enum EEffectName {
        ball1 = 'ball1',
        ball2 = 'ball2',
        ball3 = 'ball3',
        ball1_crit = 'ball1_crit',
        ball2_crit = 'ball2_crit',
        ball3_crit = 'ball3_crit',
        hit = 'hit',
        hit_crit = 'hit_crit',
    }


    export class SnowBallEffectMgr {
        private static _inst: SnowBallEffectMgr;
        private effectScene: Laya.Scene;
        private container: Laya.Sprite;
        private durations: number[];
        private effectKO: Laya.Sprite3D;
        private effectDieS: Laya.Sprite3D;
        private effectDieL: Laya.Sprite3D;
        private unUsedEffect: { [key: string]: Laya.Sprite3D[] };
        private usingEffect: { [key: string]: Laya.Sprite3D[] };
        private originEffect: { [key: string]: Laya.Sprite3D[] };
        private ballKeys: string[] = [EEffectName.ball1, EEffectName.ball1_crit, EEffectName.ball2, EEffectName.ball2_crit, EEffectName.ball3, EEffectName.ball3_crit];

        static get Inst() {
            if (!this._inst) this._inst = new SnowBallEffectMgr();
            return this._inst;
        }
        private constructor() {
        }

        refreshAnim(pause: boolean) {
            this.ballKeys.forEach((key, index) => {
                let balls = this.usingEffect[key];
                if (balls && balls.length > 0) {
                    balls.forEach((ball) => {
                        let anim = ball.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                        if (anim) {
                            if (pause) anim.Pause();
                            else anim.Resume();
                        }
                    })
                }
            });
        }

        initEffect() {
            this.originEffect = {};
            this.usingEffect = {};
            this.unUsedEffect = {};
            this.effectScene = Laya.loader.getRes('scene/effect_snowball_pk.ls');
            if (this.effectScene._childs != null) {
                for (let i: number = 1; i < this.effectScene._childs.length; i++) {
                    game.EffectMgr.dfsCompileShader(this.effectScene, this.effectScene._childs[i]);
                }
            }
            let hit1 = this.effectScene.getChildByName("2512_dxz_hit1") as Laya.Sprite3D;
            let hit1_crit = this.effectScene.getChildByName("2512_dxz_hit1_crit") as Laya.Sprite3D;
            hit1.active = false;
            hit1_crit.active = false;
            this.originEffect[EEffectName.hit] = [hit1];
            this.originEffect[EEffectName.hit_crit] = [hit1_crit];
            this.durations = [];
            let names = ['a', 'b', 'c'];
            for (let i = 0; i < 3; i++) {
                let name = '2512_dxz_dandao_' + names[i];
                let balls = [[], []];
                for (let j = 1; j <= 3; j++) {
                    let ball = this.effectScene.getChildByName(name + j) as Laya.Sprite3D;
                    ball.active = false;
                    balls[0].push(ball);
                    let anim = ball.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                    let duration = anim.GetDurationByAnimName();
                    if (j == 1) this.durations.push(duration);

                    let critBall = this.effectScene.getChildByName(name + j + '_crit') as Laya.Sprite3D;
                    critBall.active = false;
                    balls[1].push(critBall);
                }
                this.originEffect[EEffectName['ball' + (i + 1)]] = balls[0];
                this.originEffect[EEffectName['ball' + (i + 1) + '_crit']] = balls[1];
            }
            this.effectKO = this.effectScene.getChildByName('ko') as Laya.Sprite3D;
            this.effectKO.active = false;
            this.effectDieS = this.effectScene.getChildByName('die').getChildByName('die_s') as Laya.Sprite3D;
            this.effectDieL = this.effectScene.getChildByName('die').getChildByName('die_l') as Laya.Sprite3D;
            this.effectDieS.active = false;
            this.effectDieL.active = false;
        }

        init(container: Laya.Sprite) {
            this.initEffect();
            this.container = container;
            container.addChild(this.effectScene);
        }

        newEffect(effectName: string): Laya.Sprite3D {
            let effect;
            if (!this.originEffect[effectName]) return null;
            let randomIndex = Math.floor(Math.random() * this.originEffect[effectName].length);
            randomIndex = Math.min(this.originEffect[effectName].length - 1, randomIndex);
            if (this.unUsedEffect[effectName] && this.unUsedEffect[effectName].length > 0) {
                effect = this.unUsedEffect[effectName].pop();
            } else {
                effect = this.originEffect[effectName][randomIndex].clone();
            }
            this.effectScene.addChild(effect);
            if (!this.usingEffect[effectName]) this.usingEffect[effectName] = [];
            this.usingEffect[effectName].push(effect);
            effect.active = true;
            return effect;
        }

        showBall(track: number, target: ESnowBallPlayerType, crit: boolean): Laya.Sprite3D {
            let effectName = 'ball' + (track + 1) + (crit ? '_crit' : '');
            let effect: Laya.Sprite3D = this.newEffect(effectName);
            if (!effect) return null;
            effect.transform.localScale = new Laya.Vector3((target == ESnowBallPlayerType.player ? -1 : 1), 1, 1);
            let anim = effect.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            anim.EnableAdvancedFeatures(true);
            anim.SetSpeed(1 / SnowBallData.Inst.speed);
            anim.Play(null);
            return effect;
        }

        /** 显示发散粒子特效 */
        showHit(ball: Laya.Sprite3D, isCrit: boolean) {
            let effectName = 'hit' + (isCrit ? '_crit' : '');
            let effect: Laya.Sprite3D = this.newEffect(effectName);
            if (!effect) return null;
            let pos = (ball.getChildByName('2') as Laya.Sprite3D).transform.position.clone();
            effect.transform.position = pos;
            Laya.timer.once(800, effect, () => {
                this.hideEffect(effect, -1, isCrit);
            })
        }

        hideEffect(effect: Laya.Sprite3D, track: number = -1, isCrit: boolean = false) {
            effect.active = false;
            effect.removeSelf();
            let effectName;
            if (track >= 0) {
                effectName = 'ball' + (track + 1) + (isCrit ? '_crit' : '');
            } else {
                effectName = 'hit' + (isCrit ? '_crit' : '');
            }
            if (!this.unUsedEffect[effectName]) this.unUsedEffect[effectName] = [];
            this.unUsedEffect[effectName].push(effect);
            if (this.usingEffect[effectName] && this.usingEffect[effectName].indexOf(effect) != -1) {
                this.usingEffect[effectName].splice(this.usingEffect[effectName].indexOf(effect), 1);
            }
        }

        showKO() {
            this.effectKO.active = true;
        }

        showDie(isBig: boolean, pos: Laya.Vector3) {
            let effect = isBig ? this.effectDieL : this.effectDieS;
            effect.active = true;
            effect.transform.localPosition = pos;
        }

        /** 清理 */
        clear() {
            for (let key in this.usingEffect) {
                this.usingEffect[key].forEach(v => {
                    Laya.timer.clearAll(v);
                    v.removeSelf();
                    v.destroy();
                })
            }
            for (let key in this.unUsedEffect) {
                this.unUsedEffect[key].forEach(v => {
                    v.destroy();
                })
            }
            this.unUsedEffect = {};
            this.usingEffect = {};
            this.effectKO.active = false;
            this.effectDieS.active = false;
            this.effectDieL.active = false;
        }

        destory() {
            this.clear();
            if (this.effectScene) {
                this.effectScene.removeSelf();
                this.effectScene.destroy();
            }
            this.effectScene = null;
        }
    }
}