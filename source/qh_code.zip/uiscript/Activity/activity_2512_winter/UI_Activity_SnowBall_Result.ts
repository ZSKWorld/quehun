module uiscript {

    export class UI_Activity_SnowBall_Result extends UIBase {
        public static Inst: UI_Activity_SnowBall_Result = null;
        public static activityId: number = 251001;

        private comWin: Laya.Sprite;
        private comLose: Laya.Sprite;
        private btnAgain: Laya.Button;
        private btnHome: Laya.Button;
        private imgChara: Laya.Image;
        private comResult: Laya.Sprite;
        private comComplete: Laya.Sprite;
        private imgTitle: Laya.Image;
        private comLevel: Laya.Sprite;
        private btnUpgrade: Laya.Button;
        private txtTipContinue: Laya.Label;
        private comDeco: Laya.Sprite;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniWin: Laya.FrameAnimation;
        private aniLose: Laya.FrameAnimation;

        private result: ESnowBallResultType;
        private locking: boolean;

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_resultUI);
            UI_Activity_SnowBall_Result.Inst = this;
        }

        public onCreate(): void {
            this.comWin = this.me.getChildByName('win') as Laya.Sprite;
            this.comLose = this.me.getChildByName('lose') as Laya.Sprite;
            this.btnAgain = this.me.getChildByName('btn_again') as Laya.Button;
            this.btnHome = this.me.getChildByName('btn_home') as Laya.Button;
            this.imgChara = this.me.getChildByName('chara') as Laya.Image;
            this.comResult = this.me.getChildByName('result') as Laya.Sprite;
            this.comComplete = this.me.getChildByName('completed') as Laya.Sprite;
            this.imgTitle = this.comResult.getChildByName('title') as Laya.Image
            this.comLevel = this.comResult.getChildByName('level') as Laya.Sprite;
            this.btnUpgrade = this.comLose.getChildByName('btn_jump') as Laya.Button;
            this.txtTipContinue = this.me.getChildByName('tip_continue') as Laya.Label;
            this.comDeco = this.me.getChildByName('deco') as Laya.Sprite;

            this.btnAgain.clickHandler = new Laya.Handler(this, this.continueGame);
            this.btnHome.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                SnowBallData.Inst.reset();
                this.hide();
                UI_Activity_SnowBall_Main.Inst.backToHome();
            });
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                SnowBallData.Inst.reset();
                this.hide(Laya.Handler.create(this, () => {
                    UI_Activity_SnowBall_Upgrade.Inst.show();
                }));
                UI_Activity_SnowBall_Main.Inst.backToHome();
            });
            let aniRoot = this.me as ui.lobby.activity_2512winter.activity_2512winter_resultUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
            this.aniWin = aniRoot.win;
            this.aniLose = aniRoot.lose;
        }

        public show(result: ESnowBallResultType, level: number) {
            this.result = result;
            this.enable = true;
            let isWin = result == ESnowBallResultType.playerWin;
            this.comDeco.visible = isWin;
            this.comWin.visible = isWin;
            this.comLose.visible = !isWin;
            let levelConfig = SnowBallData.Inst.roundConfig.get(level);
            let completed = levelConfig.next_level < level && isWin; //是否是最后一关
            this.comResult.visible = !completed;
            this.comComplete.visible = completed;
            this.btnAgain.visible = !completed;
            this.btnHome.x = completed ? 961 : 728;
            this.txtTipContinue.text = '';
            if (completed) {
            } else {
                this.comResult.y = !isWin ? 374 : 412;
                this.imgTitle.skin = game.Tools.localUISrc(!isWin ? 'myres/activity_2512winter/pop_up_window_failure_word.png' : 'myres/activity_2512winter/pop_up_window_pass_word.png');
                let levelName = levelConfig.chapters;
                this.comLevel._childs.forEach((value, index) => {
                    value.visible = false;
                    if (levelName[index]) {
                        value.visible = true;
                        value.x = index * 84;
                        value.skin = game.Tools.localUISrc('myres/activity_2512winter/font/level_' + levelName[index] + '.png');
                    }
                });
                (this.btnAgain.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(isWin ? 25120108 : 25120112);
                if (isWin) {
                    this.txtTipContinue.text = game.Tools.strOfLocalization(25120109, ['3']);
                    let cd = 3;
                    Laya.timer.loop(1000, this, () => {
                        cd--;
                        this.txtTipContinue.text = game.Tools.strOfLocalization(25120109, [cd.toString()]);
                        if (cd == 0) {
                            Laya.timer.clearAll(this);
                            this.continueGame();
                        }
                    })
                }
            }
            this.imgChara.skin = game.Tools.localUISrc(!isWin ? 'myres/activity_2512winter/pop_up_window_pass_level_failed_linlang.png' : 'myres/activity_2512winter/pop_up_window_passed_successfully_linlang.png');
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            })
            if (result == ESnowBallResultType.playerWin) {
                this.aniWin.play(0, false);
                view.AudioMgr.PlayAudio(10378);
            } else {
                this.aniLose.play(0, false);
                view.AudioMgr.PlayAudio(10379);
            }
        }

        public continueGame() {
            if (this.locking) return;
            this.hide(Laya.Handler.create(this, () => {
                SnowBallData.Inst.playGame();
            }));
        }

        public hide(onClose?: Laya.Handler) {
            Laya.timer.clearAll(this);
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.enable = false;
                this.locking = false;
                onClose?.run();
            })
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            this.locking = false;
            this.aniShow.stop();
            this.aniHide.stop();
            this.aniWin.stop();
            this.aniLose.stop();
        }

    }
}