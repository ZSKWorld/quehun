module uiscript {
    export class Winter_TabButton {
        public me: Laya.Button;
        private selectImg: Laya.Image;
        private title: Laya.Label;
        private selectedColor: string = '#ffe1ba';
        private unselectedColor: string = '#848ec9';
        constructor(me: Laya.Button, selectedColor: string = '#ffe1ba', unselectedColor: string = '#848ec9') {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
            this.selectedColor = selectedColor;
            this.unselectedColor = unselectedColor;
        }
        public onSelect() {
            this.selectImg.visible = true;
            this.title.color = this.selectedColor;
        }
        public onDeselect() {
            this.selectImg.visible = false;
            this.title.color = this.unselectedColor;
        }
    }
    export class UI_Activity_SnowBall_Reward extends UIBase {
        public static Inst: UI_Activity_SnowBall_Reward;
        public static activityId: number = 251203;

        public static haveRedPoint() {
            if (!UI_Activity_SnowBall_Reward.Inst) return false;
            return UI_Activity_SnowBall_Reward.Inst.getAllCanRewardLevel().length > 0;
        }

        private root: Laya.Sprite;
        private btnClose: Laya.Button;
        private btnGetAll: Laya.Button;
        private itemRect: UIRect = null;
        private rewardData: lqc.Sheet_Snowball_SnowballMonsterGroup[];
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private locking: boolean = false;

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_rewardUI());
            UI_Activity_SnowBall_Reward.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            const groupId = cfg.snowball.snowball_activity.get(UI_Activity_SnowBall_Main.activityId).monster_group;
            this.rewardData = cfg.snowball.snowball_monster_group.getGroup(groupId).filter(v => !!v.reward);

            this.btnClose = this.me.getChildByName("btn_close") as Laya.Button;
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            const btnBack = this.root.getChildByName('btn_back') as Laya.Button;
            this.btnClose.clickHandler = btnBack.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick, null, false);
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
        }

        public show() {
            this.freshList();
            this.enable = true;
            (this.me as ui.lobby.activity_2512winter.activity_2512winter_rewardUI).show.play(0, false);
            view.AudioMgr.PlayAudio(10380);
        }

        public close() {
            this.locking = true;
            const ani = (this.me as ui.lobby.activity_2512winter.activity_2512winter_rewardUI).hide;
            ani.play(0, false);
            Laya.timer.once(ani.count * ani.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Reward', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Reward', true);
        }

        private freshList() {
            this.freshGetAllBtn();
            this.scrollView.reset();
            const valueCount = this.rewardData.length;
            this.scrollView.addItem(valueCount);
            const rewardLevels = this.getAllCanRewardLevel();
            let index = 0;
            if (rewardLevels.length > 0) {
                index = this.rewardData.findIndex(v => v.level == rewardLevels[0]);
            } else {
                index = this.rewardData.findIndex(v => SnowBallData.Inst.getRewardState(v) == 0);
                if (index == -1)
                    index = this.rewardData.findIndex(v => v.level == SnowBallData.Inst.highestLevel);
            }
            this.scrollView._content.vScrollBar.value = (index / valueCount) * 177 * valueCount;
            this.doLstAnim(100);
        }

        private doLstAnim(delay: number = 0) {
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            this.locking = true;
            list.me.visible = false;
            Laya.timer.once(delay, this, () => {
                list.me.visible = true;
                let lstDelay = this.listAnim();
                Laya.timer.once(lstDelay, this, () => {
                    list.me.mouseEnabled = true;
                    this.locking = false;
                });
            })
        }

        private listAnim(): number {
            if (this.scrollView.items.length == 0) return 0;
            let move_count = 0;
            const items = [...this.scrollView.items].sort((a, b) => a.container.y - b.container.y);
            let index = 0;
            items.forEach((value) => {
                if (value.container.visible) {
                    let com = value.container.getChildByName("content").getChildByName("right") as Laya.Sprite;
                    move_count++;
                    com.x = com.x + 350;
                    com.alpha = 0;
                    Laya.Tween.clearAll(this);
                    Laya.Tween.to(com, { alpha: 1 }, 8 / 60 * 1000, Laya.Ease.quadInOut, null, index * 34);
                    Laya.Tween.to(com, { x: 218 }, 8 / 60 * 1000, Laya.Ease.linearInOut, Laya.Handler.create(this, () => {
                        Laya.Tween.to(com, { x: 226 }, 7 / 60 * 1000, Laya.Ease.quadInOut);
                    }), index * 34);
                    index++;
                }
            });
            return (move_count - 1) * 34 + 250;
        }

        private getAllCanRewardLevel() {
            const levels: number[] = [];
            for (let i = 0; i < this.rewardData.length; i++) {
                const element = this.rewardData[i];
                const rewardState = SnowBallData.Inst.getRewardState(element);
                const unlockRest = SnowBallData.Inst.getRewardUnlockRest(element);
                if (unlockRest <= 0 && rewardState == 0) {
                    levels.push(element.level);
                }
            }
            return levels;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            container.zOrder = index;

            const content = container.getChildByName("content") as Laya.Sprite;
            const line = content.getChildByName("line") as Laya.Image;
            const icon = content.getChildByName("icon") as Laya.Button;
            const battle = content.getChildByName("battle") as Laya.Image;
            const right = content.getChildByName("right") as ui.lobby.activity_2512winter.reward_right_itemUI;

            const bg = right.getChildByName("bg") as Laya.Image;
            const level = right.getChildByName("level") as Laya.Label;
            const levelBg = right.getChildByName("bg2") as Laya.Image;
            const desc = right.getChildByName("desc") as Laya.Label;
            const lock = right.getChildByName("lock") as Laya.Sprite;

            const itemParent = right.getChildByName("item") as Laya.Button;
            const itemEffect1 = itemParent.getChildByName("effect_1") as Laya.Sprite;
            const itemEffect2 = itemParent.getChildByName("effect_2") as Laya.Sprite;
            const itemIcon = itemParent.getChildByName("item") as Laya.Image;
            const itemCount = itemParent.getChildByName("count") as Laya.Label;
            const itemBorder = itemParent.getChildByName("border") as Laya.Image;
            const itemGotBg = itemParent.getChildByName("got_bg") as Laya.Image;
            const itemGot = itemParent.getChildByName("got") as Laya.Image;

            const data = this.rewardData[index];
            const indent = index % 2 != 0;
            const unlockRest = SnowBallData.Inst.getRewardUnlockRest(data);
            const isUnlock = unlockRest <= 0;
            const rewardState = SnowBallData.Inst.getRewardState(data);
            const canReward = isUnlock && rewardState == 0;
            const gotReward = rewardState == 1;
            const isBoss = data.type == 1;
            const curIsNowLevel = SnowBallData.Inst.nowLevel == data.level;

            content.x = indent ? 77 : 0;
            line.visible = index < this.rewardData.length - 1;
            line.rotation = indent ? 24 : -24;
            line.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (data.level <= SnowBallData.Inst.highestLevel ? "pop_up_window_award_solid_line.png" : "pop_up_window_award_dotted_line.png"));
            icon.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (canReward ? "icon_3_treasure_chest.png" : (gotReward ? "icon_3_treasure_chest_opened.png" : (isBoss ? "icon_2_snowman_red.png" : "icon_1_snowman.png"))));
            battle.visible = curIsNowLevel;
            level.text = data.chapters;
            levelBg.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (isUnlock ? "pop_up_window_bonus_level_numbers_bottom_1.png" : "pop_up_window_bonus_level_numbers_bottom.png"));
            desc.text = game.Tools.strOfLocalization(canReward ? 25120129 : (gotReward ? 25120127 : 25120128), canReward || gotReward ? null : [data.chapters]);
            bg.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (data.node_mark ? "pop_up_window_low_reward_2.png" : "pop_up_window_low_reward.png"));

            lock.visible = !isUnlock;
            if (!isUnlock) {
                const lockBg = lock.getChildByName("lockBg") as Laya.Image;
                const lockIcon = lock.getChildByName("lock") as Laya.Image;
                const lockTxt = lock.getChildByName("lockTxt") as Laya.Label;
                lockTxt.text = game.Tools.getLockTimeText1(unlockRest);
                const txtW = lockTxt.textField.textWidth;
                lockBg.width = txtW + 90;
                lockBg.x = lockTxt.x - txtW - 63;
                lockIcon.x = lockBg.x + 19;
            }

            itemEffect1.visible = canReward;
            itemEffect2.visible = canReward;
            if (canReward) {
                right.claim_1.play(0, true);
                right.claim_2.play(0, true);
            }
            if (this.itemRect == null) this.itemRect = UIRect.CreateFromSprite(itemIcon);
            const [rewardId, rewardCount] = common.ConfigHelper.configString2Array<number>(data.reward)[0];
            game.Tools.setItemIcon(itemIcon, this.itemRect, rewardId, "UI_Activity_SnowBall_Reward", true);
            itemCount.text = rewardCount.toString();
            itemBorder.visible = canReward;
            itemGotBg.visible = isUnlock && gotReward;
            itemGot.visible = isUnlock && gotReward;
            icon.clickHandler && icon.clickHandler.recover();
            icon.clickHandler = null;
            const afterReward = Laya.Handler.create(this, res => {
                this.locking = true;
                itemEffect1.visible = false;
                itemEffect2.visible = false;
                right.claim_1.stop();
                right.claim_2.stop();
                itemGotBg.visible = true;
                itemGot.visible = true;
                right.claimed.play(0, false);
                Laya.timer.once(right.claimed.count * right.claimed.interval, this, () => {
                    this.afterReqRewards(res);
                    this.locking = false;
                });
            });
            if (canReward) {
                icon.clickHandler = Laya.Handler.create(this, () => {
                    if (this.locking) return;
                    this.reqRewards([data.level], afterReward);
                }, null, false);
            }
            itemParent.clickHandler && itemParent.clickHandler.recover();
            itemParent.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (canReward) {
                    this.reqRewards([data.level], afterReward);
                } else {
                    UI_ItemDetail.Inst.show(rewardId);
                }
            }, null, false);
        }

        private freshGetAllBtn() {
            let shouldSetGray = !UI_Activity_SnowBall_Reward.haveRedPoint();
            this.btnGetAll.mouseEnabled = !shouldSetGray;
            this.btnGetAll.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (shouldSetGray ? "get_button.png" : "get_button_1.png"));
            (this.btnGetAll.getChildByName('title') as Laya.Label).color = shouldSetGray ? '#e0e0e3' : '#ffe1ba';
        }


        private onGetAllBtnClick() {
            const levels = this.getAllCanRewardLevel();
            this.reqRewards(levels, Laya.Handler.create(this, res => {
                this.locking = true;
                let lockTime = 0;
                this.scrollView.items.forEach((value, index: number) => {
                    const content = value.container.getChildByName("content") as Laya.Sprite;
                    const right = content.getChildByName("right") as ui.lobby.activity_2512winter.reward_right_itemUI;
                    const itemParent = right.getChildByName("item") as Laya.Button;
                    const itemEffect1 = itemParent.getChildByName("effect_1") as Laya.Sprite;
                    const itemEffect2 = itemParent.getChildByName("effect_2") as Laya.Sprite;
                    const itemGotBg = itemParent.getChildByName("got_bg") as Laya.Image;
                    const itemGot = itemParent.getChildByName("got") as Laya.Image;
                    if (itemEffect1.visible) {
                        itemEffect1.visible = false;
                        itemEffect2.visible = false;
                        right.claim_1.stop();
                        right.claim_2.stop();
                        itemGotBg.visible = true;
                        itemGot.visible = true;
                        right.claimed.play(0, false);
                        lockTime = right.claimed.count * right.claimed.interval;
                    }
                });
                Laya.timer.once(lockTime, this, () => {
                    this.afterReqRewards(res);
                    this.locking = false;
                });
            }));
        }

        private reqRewards(levels: number[], cb: Laya.Handler) {
            if (this.locking) return;
            if (!levels || levels.length == 0) return;
            this.locking = true;
            const param: game.IReqSnowballActivityReceiveReward = {
                activity_id: SnowBallData.Inst.activityId,
                level: levels
            };
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityReceiveReward, param, (err, res: game.IResSnowballActivityReceiveReward) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.snowballActivityReceiveReward, err, res);
                } else {
                    cb.runWith(res);
                }
            })
        }

        private afterReqRewards(res: game.IResSnowballActivityReceiveReward) {
            let rewards = [];
            for (let reward of res.rewards) {
                if (reward['replace_count'] == 0) {
                    rewards.push(reward['reward']);
                } else {
                    reward['reward']['count'] -= reward['replace_count'];
                    if (reward['reward']['count'] > 0) {
                        rewards.push(reward['reward']);
                    }
                    rewards.push(reward['replace']);
                }
            }
            game.Tools.showRewards({ rewards }, null);
            SnowBallData.Inst.updateRewardByChanges(res.changes);
            this.scrollView.wantToRefreshAll();
            this.freshGetAllBtn();
            UI_Activity_SnowBall_Main.Inst.refreshNextReward();
        }
    }
}