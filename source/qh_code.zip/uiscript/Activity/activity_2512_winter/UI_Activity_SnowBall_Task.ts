module uiscript {

    export class UI_Activity_SnowBall_Task extends UIBase {
        public static Inst: UI_Activity_SnowBall_Task;
        public static activityId: number = 251202;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        if (d_task && this.getUnLockStateByTaskId(d_task.id)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static getUnLockStateByTaskId(taskId: number) {
            let taskConfig = cfg.activity.period_task.get(taskId);
            let timeString = taskConfig.accessible_days;
            let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(this.activityId);
            if (timeArray.length >= 2) {
                let minTime = timeArray[0];
                let maxTime = timeArray[1];
                if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                    return false;
                }
            }
            return true;
        }
        private root: Laya.Sprite;
        private btnClose:Laya.Button;
        private comBtns: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabButtons: Array<HF_TabButton>;
        private btnGetAll: Laya.Button;
        private btnGetAllTitle: Laya.Label;
        private txtCount: Laya.Label;
        private freshInfo: Laya.Label;
        private btnGetAllIcon: Laya.Image;
        private itemRect: UIRect = null;

        /**
         * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
         */
        private serverData: game.ITaskProgress[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private needSort: boolean = false;
        private locking: boolean = false;

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_taskUI());
            UI_Activity_SnowBall_Task.Inst = this;
        }

        public onCreate() {
            super.onCreate();
            this.btnClose = this.me.getChildByName("btn_close") as Laya.Button;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            const btnBack = this.root.getChildByName('btn_back') as Laya.Button;
            this.btnClose.clickHandler = btnBack.clickHandler = new Laya.Handler(this, () => {
                if(this.locking) return;
                this.close();
            });
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAllTitle = this.btnGetAll.getChildByName("title") as Laya.Label;
            this.btnGetAllIcon = this.btnGetAll.getChildByName("icon") as Laya.Image;
            this.txtCount = this.root.getChildByName("count") as Laya.Label;
            this.freshInfo = this.root.getChildByName("refreshTime") as Laya.Label;

            const btnCurrency = this.root.getChildByName('btn_currency') as Laya.Button;
            btnCurrency.clickHandler = new Laya.Handler(this, () => {
                UI_ItemDetail.Inst.show(SnowBallData.Inst.currencyId);
            });

            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender), 200);
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            this.initTabs();
        }

        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList(delay: number = 0) {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();
            this.doLstAnim(delay);
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base(this, () => { return this.locking; });
            this.tabButtons = new Array<HF_TabButton>();
            let tabsName = ['all', 'doing', 'achieved'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                this.tabGroups.AddTabButton(btn);
                let tabButton = new HF_TabButton(btn, '#ffe1ba', '#848ec9');
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    if (this.needSort) this.freshData();
                    let delay = manualSwitching ? 0 : 100;
                    tabBtn.onSelect();
                    this.freshList(delay);
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        public show() {
            this.freshData();
            this.tabGroups.init();
            this.enable = true;
            (this.me as ui.lobby.activity_2512winter.activity_2512winter_taskUI).show.play(0, false);
            view.AudioMgr.PlayAudio(10380);
        }

        public close() {
            this.locking = true;
            const ani = (this.me as ui.lobby.activity_2512winter.activity_2512winter_taskUI).hide;
            ani.play(0, false);
            Laya.timer.once(ani.count * ani.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        private refreshCurrency() {
            this.txtCount.text = SnowBallData.Inst.leftMoney.toString();
        }

        private doLstAnim(delay: number) {
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            this.locking = true;
            list.me.visible = false;
            Laya.timer.once(delay, this, () => {
                list.me.visible = true;
                let lstDelay = this.listAnim();
                Laya.timer.once(lstDelay, this, () => {
                    list.me.mouseEnabled = true;
                    this.locking = false;
                });
            })
        }

        private listAnim(): number {
            if (this.scrollView.items.length == 0) return 0;
            let move_count = 0;
            this.scrollView.items.forEach((value, index: number) => {
                let com = value.container;
                if (index < 5) {
                    move_count++;
                    com.x = com.x + 350;
                    com.alpha = 0;
                    Laya.Tween.clearAll(this);
                    Laya.Tween.to(com, { alpha: 1 }, 8 / 60 * 1000, Laya.Ease.quadInOut, null, index * 34);
                    Laya.Tween.to(com, { x: -8 }, 8 / 60 * 1000, Laya.Ease.linearInOut, Laya.Handler.create(this, () => {
                        Laya.Tween.to(com, { x: 0 }, 7 / 60 * 1000, Laya.Ease.quadInOut);
                    }), index * 34);
                } else {
                    com.alpha = 1;
                }
            });
            return (move_count - 1) * 34 + 250;
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Task', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_Task', true);
        }

        //刷新列表数据
        private freshData() {
            this.needSort = false;
            this.sortServerData.length = 0;
            //获取总列表
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_SnowBall_Task.activityId) as any;
            // app.Log.log(`UI_Activity_SnowBall_Task的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item)
            //筛选应该显示的任务
            allTask = allTask.filter(task => {
                return this.isTaskUnlock(task);
            });
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);
            this.freshGetAllBtn();

            // //获取本周内才能显示的任务，7天一刷新
            // //当前活动进行了多少天
            // let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_SnowBall_Task.activityId);
            // //显示刷新时间
            // //一周的秒数-(当前时间-活动开始时间)%一周的秒数
            // let weekSeconds = 7 * 24 * 60 * 60;
            // let restTime1 = weekSeconds - UI_Activity.getActivityDeltaSeconds(UI_Activity_SnowBall_Task.activityId) % weekSeconds;
            // this.freshInfo.text = UI_Activity_24ba.getFreshTimeText(restTime1, activityDeltaDay >= 21);

            const refreshTime = 7 * 24 * 60 * 60;
            const deltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_SnowBall_Task.activityId);
            const leftRefreshSeconds = refreshTime - deltaSeconds % refreshTime;
            const leftTime = UI_Activity.getActivityEndLeftTime(UI_Activity_SnowBall_Task.activityId);
            const restTime = leftRefreshSeconds >= leftTime ? leftTime : leftRefreshSeconds;
            this.freshInfo.text = UI_Activity_24ba.getFreshTimeText(restTime, leftRefreshSeconds >= leftTime);
            Laya.timer.clear(this, this.refreshOnRestTime);
            if(restTime > 0)
                Laya.timer.once(restTime * 1000, this, this.refreshOnRestTime);
        }

        private refreshOnRestTime() {
            this.freshData();
            this.freshList();
        }

        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                weight = -10000; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Button;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let itemBg = container.getChildByName('bg') as Laya.Image;

            let txtDesc = unLockParent.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('received') as ui.lobby.activity_2512winter.task_received_itemUI;
            let txtUnComplete = unLockParent.getChildByName('uncomplete') as Laya.Label;
            let btnReceive = unLockParent.getChildByName("btn_receive") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;
            let imgProgressBar = unLockParent.getChildByName('bar') as Laya.Image;
            let txtLockedTime = lockedParent.getChildByName('locked') as Laya.Label;

            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            let progress: number = serverData.counter || 0;
            txtProgress.text = (progress > baseTaskConfigData.target ? baseTaskConfigData.target : progress) + '/' + baseTaskConfigData.target;
            imgProgressBar.scaleX = Math.min(Math.max(progress / baseTaskConfigData.target, 0.01), 1);
            itemBg.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (configData.node_mark ? "pop_up_window_low_reward_2.png" : "pop_up_window_mission_bottom.png"));
            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = !serverData.rewarded && serverData.achieved;
                txtUnComplete.visible = !serverData.rewarded && !serverData.achieved;
                let btnText = btnReceive.getChildAt(0) as Laya.Label;
                btnText.text = game.Tools.strOfLocalization(4251);
                imgGetted.visible = serverData.achieved && serverData.rewarded;
                if (serverData.achieved && !serverData.rewarded) {
                    //已完成未领取
                    //领取的点击事件
                    btnReceive.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) return;
                        this.locking = true;
                        app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            if (err || res['error']) {
                                this.locking = false;
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                btnReceive.visible = false;
                                imgGetted.visible = true;
                                imgGetted.claimed.play(0, false);
                                Laya.timer.once(imgGetted.claimed.count * imgGetted.claimed.interval, this, () => {
                                    this.locking = false;
                                    this.needSort = true;
                                    serverData.rewarded = true;
                                    UI_Activity.onPeriodTaskRewarded(serverData.id);
                                    game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                    btnReceive.visible = false;
                                    imgGetted.visible = true;
                                    this.freshGetAllBtn();
                                });
                            }
                        });
                    }, null, false);
                }
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_SnowBall_Task.activityId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText1(restSeconds);
            }
            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("item") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_SnowBall_Task", true);
                txtCount.text = rewardCount.toString();
                itemParent.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })

            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            let taskConfig = cfg.activity.period_task.get(task.id);
            let timeString = taskConfig.accessible_days;
            let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_SnowBall_Task.activityId);
            if (timeArray.length >= 2) {
                let minTime = timeArray[0];
                let maxTime = timeArray[1];
                if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                    return false;
                }
            }
            return true;
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAll.mouseEnabled = !shouldSetGray;
            this.btnGetAllIcon.skin = game.Tools.localUISrc("myres/activity_2512winter/" + (shouldSetGray ? 'get_button.png' : 'get_button_1.png'));
            this.btnGetAllTitle.color = shouldSetGray ? '#e0e0e3' : '#ffe1ba';
            this.refreshCurrency();
            UI_Activity_SnowBall_Main.Inst.refreshRedPoint();
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let lst = this.sortServerData[currentSelectIndex];
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }


        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_SnowBall_Task.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let lockTime = 0;
                    this.locking = true;
                    this.scrollView.items.forEach((value, index: number) => {
                        let unLockParent = value.container.getChildByName("unlock") as Laya.Sprite;
                        let btnReceive = unLockParent.getChildByName("btn_receive") as Laya.Button;
                        let imgGetted = unLockParent.getChildByName('received') as ui.lobby.activity_2512winter.task_received_itemUI;
                        if (btnReceive.visible) {
                            btnReceive.visible = false;
                            imgGetted.visible = true;
                            imgGetted.claimed.play(0, false);
                            lockTime = imgGetted.claimed.count * imgGetted.claimed.interval;
                        }
                    });
                    Laya.timer.once(lockTime, this, () => {
                        this.locking = false;
                        allRewardList.forEach(v => {
                            if (v.achieved && !v.rewarded)
                                v.rewarded = true;
                        });
                        let rewardList = [];
                        for (let id of needGetList) {
                            //更新服务端奖励数据
                            UI_Activity.onPeriodTaskRewarded(id);
                            let taskConfigData = cfg.activity.period_task.get(id);
                            if (!taskConfigData.reward) {
                                continue;
                            }
                            let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                            let rewardId = rewardStr[0];
                            let rewardCount = Number(rewardStr[1]);
                            rewardList.push({ id: rewardId, count: rewardCount });
                        }
                        this.needSort = true;
                        this.scrollView.wantToRefreshAll();
                        this.freshGetAllBtn();
                        game.Tools.showRewards({ rewards: rewardList }, null, null);
                    });
                }
            })
        }

    }
}