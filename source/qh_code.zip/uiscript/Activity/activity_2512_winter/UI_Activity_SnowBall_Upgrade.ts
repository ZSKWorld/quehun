module uiscript {

    class UI_Upgrade_Item {
        private me: Laya.Sprite;
        private type: number;
        private father: UI_Activity_SnowBall_Upgrade;
        private txtName: Laya.Label;
        private comLevel: Laya.Sprite;
        private txtDesc: Laya.HTMLDivElement;
        private imgMax: Laya.Image;
        private btnUpgrade: Laya.Button;
        private comLock: Laya.Sprite;
        private comMask: Laya.Sprite;
        private txtTip: Laya.Label;
        public baseConfig: lqc.Sheet_Snowball_PlayerSnowballBuff;
        private locking: boolean;

        constructor(me: Laya.Sprite, father: UI_Activity_SnowBall_Upgrade, type: number) {
            this.me = me;
            this.type = type;
            this.father = father;
            this.txtName = this.me.getChildByName('name') as Laya.Label;
            this.comLevel = this.me.getChildByName('level') as Laya.Sprite;
            this.txtDesc = this.me.getChildByName('desc') as Laya.HTMLDivElement;
            this.imgMax = this.me.getChildByName('max') as Laya.Image;
            this.btnUpgrade = this.me.getChildByName('btn_upgrade') as Laya.Button;
            this.comLock = this.me.getChildByName('lock') as Laya.Sprite;
            this.comMask = this.comLock.getChildByName('gray') as Laya.Sprite;
            this.txtTip = this.comLock.getChildByName('tip') as Laya.Label;
            if (GameMgr.client_language == 'jp') {
                this.txtDesc.style.font = '28px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtDesc.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtDesc.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtDesc.style.font = '28px SimHei';
            } else {
                this.txtDesc.style.font = '28px NotoSansKR';
            }
            this.txtDesc.style.color = '#524d97';
            this.txtDesc.style.leading = 6;
            this.txtDesc.style.letterSpacing = 0;
            this.txtDesc.style.align = 'center';
            cfg.snowball.player_snowball_buff.forEach((value) => {
                if (value.type == this.type && value.level == 1) {
                    this.baseConfig = value;
                    return;
                }
            });
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showEffect();
                this.father.upgrade(this.type);
            })
        }

        private showEffect() {
            let effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(
                this.me, 'scene/effect_snowball_upgrade.lh', new Laya.Point(154, 341), 1);
            this.locking = true;
            Laya.timer.once(40 / 60 * 1000, effect, () => {
                effect.destory();
                this.locking = false;
            })
        }

        public refresh(config?: lqc.Sheet_Snowball_PlayerSnowballBuff) {
            let lockedBuff = !config;
            config = config || this.baseConfig;
            this.txtName.text = this.type < 3 ? game.Tools.strOfLocalization(SnowBallData.Inst.attackConfig.get(config.type).snowball_name_str) : game.Tools.strOfLocalization(25120117);
            let level = config.level;
            this.comLevel._childs.forEach((img, index) => {
                if (this.type < 3) {
                    img.skin = game.Tools.localUISrc(index < level ? 'myres/activity_2512winter/pop_up_window_upgrade_star_blue.png' : 'myres/activity_2512winter/pop_up_window_upgrade_star_gray.png');
                } else {
                    img.skin = game.Tools.localUISrc(index < level ? 'myres/activity_2512winter/pop_up_window_upgrade_star_yellow.png' : 'myres/activity_2512winter/pop_up_window_upgrade_star_gray.png');
                }
            })
            let nextConfig: lqc.Sheet_Snowball_PlayerSnowballBuff;
            if (!lockedBuff) {
                if (config && config.next_level_id) {
                    nextConfig = SnowBallData.Inst.buffConfig.get(config.next_level_id);
                }
                let isMax = !nextConfig;
                let locked = (nextConfig && nextConfig.unlock > SnowBallData.Inst.highestLevel);
                this.comLock.visible = locked;
                this.comMask.visible = false;
                if (this.comLock.visible) {
                    let lockedLevel = nextConfig.unlock;
                    let levelName = SnowBallData.Inst.roundConfig.get(lockedLevel).chapters;
                    this.txtTip.text = game.Tools.strOfLocalization(25120122, [levelName]);
                    this.txtTip.color = '#aba0d4';
                }
                this.imgMax.visible = isMax;
                this.btnUpgrade.visible = !isMax && !locked;
                if (this.btnUpgrade.visible) {
                    (this.btnUpgrade.getChildByName('count') as Laya.Label).text = nextConfig.price.toString();
                    let canBuy = SnowBallData.Inst.leftMoney >= nextConfig.price;
                    this.btnUpgrade.mouseEnabled = canBuy;
                    (this.btnUpgrade.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(canBuy ? 'myres/activity_2512winter/pop_up_window_button.png' : 'myres/activity_2512winter/pop_up_window_button_gray.png');
                    (this.btnUpgrade.getChildByName('count') as Laya.Label).color = canBuy ? '#fff9f2' : '#f53a5d';
                }
            } else {
                this.btnUpgrade.visible = false;
                this.imgMax.visible = false;
                this.comLock.visible = true;
                this.comMask.visible = true;
                let lockedLevel = config.unlock;
                if (lockedLevel) {
                    let levelName = SnowBallData.Inst.roundConfig.get(lockedLevel).chapters;
                    this.txtTip.text = game.Tools.strOfLocalization(25120122, [levelName]);
                    this.txtTip.color = '#e0dbf5';
                }
            }
            let baseValues: number[] = [];
            let descIds = this.type < 3 ? [25120123, 25120124, 25120125] : [25120126];
            if (this.type < 3) {
                baseValues.push(1);
                let attackConfig = SnowBallData.Inst.attackConfig.get(this.type);
                baseValues.push(attackConfig.mp_consume);
                baseValues.push(attackConfig.cd);
            } else {
                baseValues = [SnowBallData.Inst.baseConfig.hp];
            }
            let nowValues = [];
            let nextValues = [];
            if (this.type < 3) {
                let nowBuff = cfg.snowball.snowball_attack_level.get(config.effect);
                nowValues.push(baseValues[0] + nowBuff.snowball_count);
                nowValues.push(baseValues[1] - nowBuff.mp_buff);
                nowValues.push(Math.floor((baseValues[2] - nowBuff.cd_buff) / SnowBallData.Inst.ticks) + 's');
                if (nextConfig) {
                    let nextBuff = cfg.snowball.snowball_attack_level.get(nextConfig.effect);
                    nextValues.push(baseValues[0] + nextBuff.snowball_count);
                    nextValues.push(baseValues[1] - nextBuff.mp_buff);
                    nextValues.push(Math.floor((baseValues[2] - nextBuff.cd_buff) / SnowBallData.Inst.ticks) + 's');
                }
            } else {
                nowValues = [baseValues[0] + config.effect];
                if (nextConfig) nextValues = [baseValues[0] + nextConfig.effect];
            }
            let desc = '';
            for (let i = 0; i < descIds.length; i++) {
                desc += game.Tools.strOfLocalization(descIds[i]);
                desc += nowValues[i];
                if (nextValues[i]) {
                    desc += game.Tools.strOfLocalization(4265);
                    desc += (nowValues[i] == nextValues[i] ? nextValues[i] : '[tag]' + nextValues[i] + '[/tag]');
                }
                desc += '\n';
            }
            this.txtDesc.innerHTML = game.Tools.ParseText(desc, '#0dccf5');
        }
    }

    export class UI_Activity_SnowBall_Upgrade extends UIBase {
        public static Inst: UI_Activity_SnowBall_Upgrade = null;
        public static activityId: number = 251001;

        public static haveRedPoint(): boolean {
            let data = SnowBallData.Inst.upgradeData;
            for (let i = 0; i < data.length; i++) {
                let nextLevel = data[i].next_level_id;
                if (nextLevel) {
                    let nextConfig = SnowBallData.Inst.buffConfig.get(nextLevel);
                    if (nextConfig.unlock <= SnowBallData.Inst.highestLevel && SnowBallData.Inst.leftMoney >= nextConfig.price) {
                        return true;
                    }
                }
            }
            return false;
        }

        private root: Laya.Sprite;
        private btnClose: Laya.Button;
        private btnReset: Laya.Button;
        private btnCurrency: Laya.Button;
        private locking: boolean = false;
        private upgradeData: lqc.Sheet_Snowball_PlayerSnowballBuff[];
        private items: UI_Upgrade_Item[];
        private isChanged: boolean;
        private cacheData: game.IActivitySnowballUpgrade[] = [];
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_skillUI);
            UI_Activity_SnowBall_Upgrade.Inst = this;
        }

        public onCreate(): void {
            this.btnClose = this.me.getChildByName("btn_close") as Laya.Button;
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            const btnBack = this.root.getChildByName('btn_back') as Laya.Button;
            let comItems = this.root.getChildByName('items') as Laya.Sprite;
            this.items = [];
            for (let i = 0; i < 3; i++) {
                this.items.push(new UI_Upgrade_Item(comItems.getChildByName('skill' + (i + 1)) as Laya.Sprite, this, i));
            }
            this.items.push(new UI_Upgrade_Item(comItems.getChildByName('role') as Laya.Sprite, this, 3));
            this.btnClose.clickHandler = btnBack.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.isChanged) {
                    this.sendReqUpgrade(Laya.Handler.create(this, this.hide));
                } else {
                    this.hide();
                }
            });
            this.btnReset = this.root.getChildByName('btn_reset') as Laya.Button;
            this.btnCurrency = this.root.getChildByName('btn_currency') as Laya.Button;
            this.btnCurrency.clickHandler = new Laya.Handler(this, () => {
                UI_ItemDetail.Inst.show(SnowBallData.Inst.currencyId);
            });
            this.btnReset.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(25120131), Laya.Handler.create(this, () => {
                    this.isChanged = true;
                    let upgrade: game.IActivitySnowballUpgrade[] = [];
                    for (let i = 0; i < this.items.length; i++) {
                        let config = this.items[i].baseConfig;
                        if (config.unlock <= SnowBallData.Inst.highestLevel) {
                            upgrade.push({
                                id: config.buff_id
                            })
                        }
                    }
                    let changes: game.IActivitySnowballValueChanges = {
                        upgrade: {
                            dirty: true,
                            value: upgrade
                        }
                    } as game.IActivitySnowballValueChanges;
                    SnowBallData.Inst.updateData(changes);
                    this.refresh();
                }));
            });

            let aniRoot = this.me as ui.lobby.activity_2512winter.activity_2512winter_skillUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
            this.btnClose.alpha = 0.5;
        }

        public upgrade(type: number) {
            if (this.locking) return;
            this.isChanged = true;
            let upgrade: game.IActivitySnowballUpgrade[] = [];
            for (let i = 0; i < this.upgradeData.length; i++) {
                let config = this.upgradeData[i];
                if (config.type == type) {
                    upgrade.push({
                        id: config.next_level_id
                    })
                } else {
                    upgrade.push({
                        id: config.buff_id
                    })
                }
            }
            let changes: game.IActivitySnowballValueChanges = {
                upgrade: {
                    dirty: true,
                    value: upgrade
                }
            } as game.IActivitySnowballValueChanges;
            SnowBallData.Inst.updateData(changes);
            this.refresh();
            this.locking = true;
            Laya.timer.once(600, this, () => {
                this.locking = false;
                UI_LightTips.Inst.show(game.Tools.strOfLocalization(20048));
            });
        }

        public refresh() {
            this.upgradeData = SnowBallData.Inst.upgradeData;
            for (let i = 0; i < this.items.length; i++) {
                let data = this.upgradeData.find(data => data.type == i);
                this.items[i].refresh(data);
            }
            (this.btnCurrency.getChildByName('count') as Laya.Label).text = SnowBallData.Inst.leftMoney.toString();
            let canReset = SnowBallData.Inst.leftMoney != UI_Bag.get_item_count(SnowBallData.Inst.currencyId);
            this.btnReset.mouseEnabled = canReset;
            (this.btnReset.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(canReset ? 'myres/activity_2512winter/pop_up_window_upgrade_button.png' : 'myres/activity_2512winter/pop_up_window_upgrade_button_gray.png');
            (this.btnReset.getChildByName('title') as Laya.Label).color = canReset ? '#872b19' : '#e0dbf5';
            UI_Activity_SnowBall_Main.Inst.refreshRedPoint();
        }

        public show() {
            this.cacheData = [];
            for (let i = 0; i < SnowBallData.Inst.upgradeData.length; i++) {
                let config = SnowBallData.Inst.upgradeData[i];
                this.cacheData.push({ id: config.buff_id });
            }
            this.refresh();
            this.enable = true;
            this.locking = true;
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            });
            view.AudioMgr.PlayAudio(10380);
        }

        public hide() {
            this.locking = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public sendReqUpgrade(onComplete: Laya.Handler) {
            this.isChanged = false;
            let param: game.IReqSnowballActivityUpgrade = {
                activity_id: SnowBallData.Inst.activityId,
                upgrade: []
            }
            for (let i = 0; i < this.upgradeData.length; i++) {
                let config = this.upgradeData[i];
                param.upgrade.push({ id: config.buff_id });
            }
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.snowballActivityUpgrade, param, (err, res: game.IResSnowballActivityUpgrade) => {
                this.locking = false;
                if (err || res['error']) {
                    let changes: game.IActivitySnowballValueChanges = {
                        upgrade: {
                            dirty: true,
                            value: this.cacheData
                        }
                    } as game.IActivitySnowballValueChanges;
                    SnowBallData.Inst.updateData(changes);
                    SnowBallData.Inst.onGameError(game.ERequest.snowballActivityStartBattle, err, res);
                }
                onComplete.run();
            });
        }
    }
}