module uiscript {

    class UI_SnowBall_Player {
        private me: Laya.Sprite;
        private comChara: Laya.Sprite;
        private imgChara: Laya.Image;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.comChara = this.me.getChildByName('chara') as Laya.Sprite;
            this.imgChara = this.comChara.getChildByName('chara') as Laya.Image;
        }

        refresh(name: string) {
            game.LoadMgr.setImgSkin(this.imgChara, 'myres/activity_2512winter/chara/' + name + '.png', null, 'UI_Activity_SnowBall_VS');
        }
    }

    export class UI_Activity_SnowBall_VS extends UIBase {
        public static Inst: UI_Activity_SnowBall_VS = null;
        public static activityId: number = 251001;
        private comLevel: Laya.Sprite;
        private comPlayer: UI_SnowBall_Player;
        private comBoss: UI_SnowBall_Player;
        private aniShow: Laya.FrameAnimation;
        private txtName: Laya.Label;
        private imgNameBg: Laya.Image;

        constructor() {
            super(new ui.lobby.activity_2512winter.activity_2512winter_vsUI);
            UI_Activity_SnowBall_VS.Inst = this;
        }

        public onCreate(): void {
            this.comLevel = this.me.getChildByName('bg').getChildByName('level') as Laya.Sprite;
            let comChara = this.me.getChildByName('chara') as Laya.Sprite;
            this.comPlayer = new UI_SnowBall_Player(comChara.getChildByName('right') as Laya.Sprite);
            this.comBoss = new UI_SnowBall_Player(comChara.getChildByName('left') as Laya.Sprite);
            this.comLevel._childs.forEach(img => img.visible = false);
            let comBossName = comChara.getChildByName('left').getChildByName('boss_name') as Laya.Sprite;
            this.txtName = comBossName.getChildByName('name') as Laya.Label;
            this.imgNameBg = comBossName.getChildByName('bg') as Laya.Image;
            let aniRoot = this.me as ui.lobby.activity_2512winter.activity_2512winter_vsUI;
            this.aniShow = aniRoot.show;
        }


        public show() {
            this.enable = true;
            let levelConfig = SnowBallData.Inst.nowLevelConfig;
            this.txtName.text = game.Tools.eventStrOfLocalization(SnowBallData.Inst.nowLevelConfig.name_str_id);
            this.imgNameBg.width = this.txtName.trueWidth + 129;
            let levelName = levelConfig.chapters;
            let startX = -levelName.length * 84 / 2;
            this.comLevel._childs.forEach((img, index) => {
                img.visible = false;
                if (levelName[index]) {
                    img.visible = true;
                    img.skin = game.Tools.localUISrc('myres/activity_2512winter/font/level_' + levelName[index] + '.png');
                    img.x = startX + 84 * index;
                }
            });
            this.comPlayer.refresh(SnowBallData.Inst.baseConfig.player_id);
            this.comBoss.refresh(levelConfig.boss_id);
            this.aniShow.play(0, false);
            SnowBallData.Inst.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.hide();
            });
            view.AudioMgr.PlayAudio(10376);
        }

        public hide() {
            this.enable = false;
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_VS', false);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_SnowBall_VS', false);
        }
    }
}