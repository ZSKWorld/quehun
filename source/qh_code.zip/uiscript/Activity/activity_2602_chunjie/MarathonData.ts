module uiscript {
    /**
     *  核心常量定义
     */
    export const MarathonConstant = {
        // 一面墙有多少张牌
        WALL_TILE_COUNT: 7,
        // 手牌最大数量
        MAX_HAND_TILES: 7,
        // 最小牌墙数量
        MIN_WALL_COUNT: 3,
        // 牌墙移动速度（基础）
        BASE_WALL_SPEED: 0.00008,
        // 牌墙间隔时间（tick）
        WALL_INTERVAL_TIME: 153,
        // 角色移动步长
        CHARA_MOVE_STEP: 0.0475,
        // 角色移动区域
        CHARA_MOVE_AREA: new Laya.Vector2(-0.16, 0.125),
        // 角色spine移动区域
        CHARA_SPINE_MOVE_AREA: new Laya.Vector2(745, 65),
        // 角色spine移动步长
        CHARA_SPINE_MOVE_STEP: 110,
        // 角色移动单步时间
        CHARA_STEP_TIME: 10,
        // 牌墙初始位置
        WALL_START_X: -0.78,
        // 牌墙目标位置
        WALL_TARGET_X: 0.8,
        // 第一面牌墙的初始位置
        WALL_FIRST_START_X: -0.189,
        // 牌墙间隔
        WALL_INTERVAL: 0.409,
        // 天气切换延迟（毫秒）
        WEATHER_DELAY: [8000, 3000, 8000],
        // 天气切换时长
        WEATHER_CHANGE_DURATION: 600,
        // FeverTime结束delay
        FEVER_TIME_ANIM_DELAY: 600,
        // 随机道具生成区域宽度
        RANDOM_ITEM_AREA: 4,
        // 道具单位间隔
        RANDOM_ITEM_INTERVAL: 0.05,
        // 每面墙多少米
        RANDOM_ITEM_RATIO: 10,
        // 容忍时长
        tick_extra_base: 12
    };

    /**
     * 事件枚举
     */
    export enum EMarathonEvent {
        PREPARE_START = "MarathonPrepareStart",
        GAME_START = "MarathonGameStart",
        GAME_END = "MarathonGameEnd",
        ADD_HANDS = "MarathonAddHands",
        NEW_WALL = "MarathonNewWall",
        GAME_UPDATE = "MarathonGameUpdate",
        PAUSE_GAME = "MarathonPauseGame",
        RESUME_GAME = "MarathonResumeGame",
        CHANGE_SPEED = "MarathonChangeSpeed",
        ENTER_FEVER_TIME = "MarathonEnterFeverTime",
        QUIT_FEVER_TIME = "MarathonQuitFeverTime",
        DO_OPERATION = "MarathonDoOperation",
        GAME_ERROR = "MarathonGameError"
    }
    /**
     * 牌墙信息接口
     */
    export interface IMarathonWallInfo {
        round: number;
        isFever: boolean;
        tiles: string[];
        items: IMarathonWallItem[];
    }

    export interface IMarathonOperation {
        /** 0表示消除，1表示道具 */
        type: number;
        consume?: {
            type: MarathonHandsCombinationType;
            tiles: string[];
        },
        item?: MarathonItemType;
        reward: {
            point: number;
            time: number;
        };
    }

    export interface IMarathonCheckData extends game.IActivityMarathonCheckData {
        operation: IMarathonOperation;
    }

    export interface IMarathonRecord extends game.IMarathonGameRecord {
        new_time: boolean;
        new_distance: boolean;
        new_point: boolean;
        originTrain: number;
        originTrainGrade: number;
        addTrain: number;
    }
    export enum EMarathonResult {
        TimeOut = 0,
        HandsOut = 1,
    }
    /**
     * 数据层：游戏核心数据管理
     */
    export class MarathonData extends Laya.EventDispatcher {
        private static _instance: MarathonData;
        public static get Inst(): MarathonData {
            return this._instance || (this._instance = new MarathonData());
        }
        // 定义麻将牌的【标准排序权重表】，顺序就是最终要的排序结果，固定死规则
        private static paiOrder = [
            '1m', '2m', '3m', '4m', '5m', '6m', '7m', '8m', '9m',
            '1p', '2p', '3p', '4p', '5p', '6p', '7p', '8p', '9p',
            '1s', '2s', '3s', '4s', '5s', '6s', '7s', '8s', '9s',
            '1z', '2z', '3z', '4z', '5z', '6z', '7z'
        ];
        public static sortPai(pais: string[]): string[] {
            // 排序核心逻辑
            return pais.sort((a, b) => {
                // 获取当前牌在权重表中的索引，索引越小越靠前
                const indexA = this.paiOrder.indexOf(a);
                const indexB = this.paiOrder.indexOf(b);
                // 兼容异常值：如果传入非标准牌（比如10m/8z），会排到最后面
                return (indexA === -1 ? 99 : indexA) - (indexB === -1 ? 99 : indexB);
            });
        }

        public static findPaiInsertIndex(sortedPais: string[], targetPai: string): number {
            // 获取牌的排序权重（和排序方法逻辑一致，非法牌权重99，排最后）
            const getWeight = (pai: string) => {
                const idx = this.paiOrder.indexOf(pai);
                return idx === -1 ? 99 : idx;
            };
            // 核心需求：倒序遍历，找到【最后一个】和目标牌相同的元素，返回它的索引+1
            for (let i = sortedPais.length - 1; i >= 0; i--) {
                if (sortedPais[i] === targetPai) {
                    return i + 1;
                }
            }
            // 没有相同牌时：找到第一个权重比目标牌大的元素的索引，就是插入位置
            const targetWeight = getWeight(targetPai);
            for (let i = 0; i < sortedPais.length; i++) {
                const currWeight = getWeight(sortedPais[i]);
                if (currWeight > targetWeight) {
                    return i;
                }
            }
            // 兜底：目标牌权重比所有牌都大，插入到数组最后
            return sortedPais.length;
        }

        public static canEliminate(hands: string[], tile: string): boolean {
            const parsed = MarathonUtility.parseHands([...hands], tile);
            return !!parsed;
        }


        // 活动ID
        public inited: boolean = false;
        public activityId: number = 260201;
        public activityConfig: lqc.Sheet_Marathon_MarathonInfo;
        private wallConfigs: basic.Dictionary<number, lqc.Sheet_Marathon_MarathonWallGroup>;
        public tileBaseWeight: Map<string, number>;
        public tileFeverWeight: Map<string, number>;

        // 游戏状态
        public gaming: boolean = false;
        public duringFeverTime: boolean = false;
        public pauseIndex: number = 0;
        // 速度控制
        private _speed: number = 1;
        // 时间相关
        public timer: Laya.Timer;
        private startTime: number = 0;
        private costTime: number = 0;
        private stopTime: number = 0;
        // 网络锁
        public lockNetwork: boolean = false;
        public locking: boolean = false;
        // 游戏数据
        public hands: string[] = [];
        public feverTiles: string[] = []; // 福牌
        public feverTempTile: string = null; // 临时福牌
        public wallInfos: IMarathonWallInfo[] = [];
        private lastUpdateTime: number = 0;
        public nowScore: number = 0;
        public feverTimeRemain: number = 0; //feverTime剩余时间，单位毫秒
        public normalTimeRemain: number = 0; //normalTime剩余时间，单位毫秒
        public checkData: IMarathonCheckData[] = [];
        public gameRecord: IMarathonRecord;
        public highestRecord: game.IMarathonGameRecord;
        private raceId: string = '';
        private simulation: MarathonRaceSimulation;
        private cacheItems: { round: number, items: MarathonItemType[] };
        private lastRoundTime: number = 0;
        private lastRound: number = 0;
        // 牌墙缓存
        private wallGroups: IMarathonWallGeneratorResult[] = [];
        // 缓动管理器
        private prepareStart: boolean = false;

        private constructor() {
            super();
            if (!cfg.marathon || !cfg.marathon.marathon_info) return;
            this.inited = true;
            this.activityConfig = cfg.marathon.marathon_info.get(this.activityId);
            this.wallConfigs = new basic.Dictionary<number, lqc.Sheet_Marathon_MarathonWallGroup>();
            cfg.marathon.marathon_wall_group.forEach((item) => {
                this.wallConfigs.set(item.lower, item);
            });
            this.tileBaseWeight = new Map<string, number>();
            this.tileFeverWeight = new Map<string, number>();
            cfg.marathon.marathon_tile_group.forEach((item) => {
                this.tileBaseWeight.set(item.tile, item.weight);
                this.tileFeverWeight.set(item.tile, item.fever_weight);
            });
            this.timer = new Laya.Timer();
            this.highestRecord = {
                point: 0,
                distance: 0,
                used_tick: 0
            };
            this.reset();
        }

        public getTimeByTick(tick: number): number {
            return tick / this.activityConfig.tick * 1000;
        }

        public getSecMsecByTime(time: number): string {
            time = Math.max(0, time);
            const seconds = Math.floor(time / 1000);
            const msPart = time % 1000;
            const twoDigitsSeconds = seconds.toString().padStart(2, '0');
            const msTwoDigits = Math.floor(msPart / 10).toString().padStart(2, '0');
            return `${twoDigitsSeconds}.${msTwoDigits}`;
        }

        public getMinMsecByTime(time: number): string {
            time = Math.max(0, time);

            const totalSeconds = Math.floor(time / 1000);
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;

            const msPart = time % 1000;
            const msTwoDigits = Math.floor(msPart / 10).toString().padStart(2, '0');

            const twoDigitsMinutes = minutes.toString().padStart(2, '0');
            const twoDigitsSeconds = seconds.toString().padStart(2, '0');

            return `${twoDigitsMinutes}:${twoDigitsSeconds}.${msTwoDigits}`;
        }

        getWall(round: number): lqc.Sheet_Marathon_MarathonWallGroup {
            const values = this.wallConfigs.values();
            for (let i = 0; i < values.length; i++) {
                const value = values[i];
                if (round <= value.upper) {
                    return value;
                } else if (value.upper == 0) {
                    return value;
                }
            }
        }

        getItemWeightMap(round: number) {
            const wall = this.getWall(round);
            const itemGroup = cfg.marathon.marathon_item_group.getGroup(wall.item_group_id);
            const weightMap = new Map<number, number>();
            for (const item of itemGroup) {
                weightMap.set(item.type, item.weight);
            }
            return weightMap;
        }

        getReward(type: number) {
            const rewardGroup = cfg.marathon.marathon_reward.getGroup(this.activityConfig.reward_group);
            const reward = rewardGroup.find(g => g.type === type);
            if (!reward)
                return null;

            return reward;
        }

        // 速度属性（带事件派发）
        public set speed(v: number) {
            if (v == this._speed) return;
            this._speed = v;
            this.event(EMarathonEvent.CHANGE_SPEED, v);
        }

        public get speed(): number {
            return this._speed;
        }

        public get timeRemain(): number {
            if (this.duringFeverTime) return this.feverTimeRemain;
            return this.normalTimeRemain;
        }

        // 当前游戏时长
        public get currentTime(): number {
            if (!this.gaming) return 0;
            let stopTimeOffset = 0;
            if (this.isPause) {
                stopTimeOffset = this.timer.currTimer - this.stopTime;
            }
            return this.timer.currTimer - this.costTime - stopTimeOffset - this.startTime;
        }

        // 当前游戏时间
        public get currTimer(): number {
            let stopTimeOffset = 0;
            if (this.isPause) {
                stopTimeOffset = this.timer.currTimer - this.stopTime;
            }
            return this.timer.currTimer - this.costTime - stopTimeOffset;
        }

        public get consumedFeverTiles(): string[] {
            return this.simulation ? this.simulation.consumedFeverTiles : [];
        }

        isFeverTile(tile: string): boolean {
            return this.feverTiles.indexOf(tile) != -1;
        }

        isFeverTileConsumed(tile: string): boolean {
            return this.simulation.consumedFeverTiles.indexOf(tile) != -1;
        }

        get trueDistance(): number {
            let distance = this.lastRound * MarathonConstant.RANDOM_ITEM_RATIO;
            let nextWall = this.wallInfos.find(wall => wall.round == this.lastRound + 1);
            let extraTime = (this.currentTime - this.lastRoundTime) / 1000 * this.activityConfig.tick;
            const realSpeed = this.duringFeverTime ? this.activityConfig.fever_speed : nextWall ? this.getWall(nextWall.round).speed : 0;
            if (realSpeed) distance += MarathonConstant.RANDOM_ITEM_RATIO * (extraTime / realSpeed); // 增加跑步距离
            return distance;
        }

        public initData(datas: game.IActivityMarathonData[]) {
            if (!this.inited) return;
            this.highestRecord = {
                point: 0,
                distance: 0,
                used_tick: 0
            };
            if (datas) {
                for (let i: number = 0; i < datas.length; i++) {
                    let msg = datas[i];
                    if (msg.activity_id == this.activityId) {
                        this.updateRecord(msg.highest_record);
                        break;
                    }
                }
            }
        }

        public updateRecord(data: game.IMarathonGameRecord) {
            this.highestRecord.distance = data.distance || 0;
            this.highestRecord.point = data.point || 0;
            this.highestRecord.used_tick = data.used_tick || 0;
        }


        /**
         * 初始化本轮数据
         */
        public initRoundData(res: game.IResMarathonActivityStartRace): void {
            this.reset();
            this.prepareStart = true;
            this.raceId = res.race_id;
            this.simulation = new MarathonRaceSimulation(this.activityId, this.activityConfig.start_time, res.random_seed);
            this.updateRaceData();
            this.updateRaceTime();
            this.updateRaceDistance(0);
            this.event(EMarathonEvent.PREPARE_START);
            this.refreshWall();
        }

        public updateRaceData(): void {
            this.simulation.updateWallData();
            this.wallGroups = this.simulation.walls;
            this.feverTiles = this.simulation.feverTiles;
            this.nowScore = this.simulation.point;
        }

        public updateRaceTime() {
            this.normalTimeRemain = this.getTimeByTick(this.simulation.remainTicks);
            this.lastUpdateTime = this.currentTime;
        }

        public updateRaceDistance(round: number) {
            this.lastRound = round;
            this.lastRoundTime = this.currentTime;
        }

        /**
         * 开始游戏
         */
        public startGame(): void {
            if (!this.prepareStart) return;
            this.prepareStart = false;
            this.gaming = true;
            this.startTime = this.timer.currTimer;
            this.costTime = 0;
            this.event(EMarathonEvent.GAME_START);
            this.startGameUpdateTimer();
        }

        public get isPause(): boolean {
            return this.pauseIndex > 0;
        }

        /**
         * 暂停游戏
         */
        public pauseGame(): void {
            if (!this.gaming) return;
            this.pauseIndex++;
            if (this.pauseIndex > 1) return;
            this.stopTime = Laya.timer.currTimer;
            this.event(EMarathonEvent.PAUSE_GAME);
        }

        /**
         * 恢复游戏
         */
        public resumeGame(): void {
            if (!this.gaming) return;
            this.pauseIndex--;
            if (this.pauseIndex > 0) return;
            const delay = Laya.timer.currTimer - this.stopTime;
            this.costTime += delay;
            this.stopTime = 0;
            this.event(EMarathonEvent.RESUME_GAME);
        }

        /**
         * 刷新牌墙（保证至少有最小数量的牌墙）
         */
        public refreshWall(): void {
            for (let i = 0; i < this.wallGroups.length; i++) {
                if (this.wallInfos.findIndex(wall => wall.round == this.wallGroups[i].round) == -1) {
                    this.createNewWall(this.wallGroups[i]);
                }
            }
            this.refreshSpeed();
        }

        /**
         * 创建新牌墙
         */
        private createNewWall(tileGroup: IMarathonWallGeneratorResult): boolean {
            let tiles: string[] = [];
            if (this.duringFeverTime && !tileGroup.isFeverTime) {
                for (let i = 0; i < MarathonConstant.WALL_TILE_COUNT; i++) {
                    tiles.push(this.feverTempTile);
                }
            } else {
                tiles = [...tileGroup.wall];
            }
            const isFever = this.duringFeverTime || tileGroup.isFeverTime;
            const wallInfo: IMarathonWallInfo = {
                round: tileGroup.round,
                isFever,
                tiles,
                items: tileGroup.items,
            };
            this.wallInfos.push(wallInfo);
            this.event(EMarathonEvent.NEW_WALL, wallInfo);
            return true;
        }

        /**
         * 进入狂热时间
         */
        public enterFeverTime(): void {
            this.duringFeverTime = true;
            this.feverTimeRemain = this.getTimeByTick(this.activityConfig.fever_speed * this.activityConfig.fever_time_duration);
            // 更新现有牌墙为狂热牌墙
            this.wallInfos.forEach(wall => {
                wall.isFever = true;
                const wallInfo = this.wallGroups.find(wg => wg.round == wall.round);
                if (wallInfo) wall.tiles = [...wallInfo.wall];
                wall.items = [...wallInfo.items];
            });
            this.feverTempTile = this.wallInfos[0].tiles[0];
            this.event(EMarathonEvent.ENTER_FEVER_TIME, [this.wallInfos]);
        }

        /**
         * 退出狂热时间
         */
        public quitFeverTime(): void {
            this.duringFeverTime = false;
            this.feverTimeRemain = 0;
            for (let i = 0; i < this.wallInfos.length; i++) {
                const wall = this.wallInfos[i];
                const wallInfo = this.wallGroups.find(wg => wg.round == wall.round);
                if (wallInfo) {
                    wall.isFever = wallInfo.isFeverTime;
                    wall.items = wallInfo.items;
                    if (wallInfo) wall.tiles = [...wallInfo.wall];
                }
            }
            this.event(EMarathonEvent.QUIT_FEVER_TIME, [this.wallInfos]);
        }

        refreshSpeed(): void {
            if (this.duringFeverTime) {
                this.speed = MarathonConstant.WALL_INTERVAL_TIME / this.activityConfig.fever_speed;
            } else {
                this.speed = this.wallInfos.length > 0 ? MarathonConstant.WALL_INTERVAL_TIME / this.getWall(this.wallInfos[0].round).speed : 1;
            }
        }

        /**
         * 收集麻将牌到手牌
         */
        public collectWall(tile: string, duration: number, force: boolean = false): void {
            // 移除牌墙并添加到手牌
            const wallInfo = this.wallInfos.shift();
            if (!wallInfo || wallInfo.tiles.indexOf(tile) == -1) {
                this.event(EMarathonEvent.GAME_ERROR, JSON.stringify({ error: 'Collect tile error', tile, wallInfo }));
                return;
            }
            const items = this.cacheItems && this.cacheItems.round == wallInfo.round ? this.cacheItems.items : [];
            // 处理手牌消除逻辑
            const checkData = this.simulation.collect(tile.toString(), items);
            this.cacheItems = null;
            if (checkData) {
                this.checkData.push(checkData);
            }
            const operateTiles = checkData && checkData.operation ? checkData.operation.consume.tiles : [];
            if (tile) {
                this.event(EMarathonEvent.ADD_HANDS, [this.hands.concat(tile), [...operateTiles], duration]);
            }
            // app.Log.log('所剩手牌 ====' + JSON.stringify(this.simulation.hands.map(v => v.toString())));
            // 检查游戏失败条件
            if (this.simulation.hands.length > MarathonConstant.MAX_HAND_TILES) {
                this.gameOver(EMarathonResult.HandsOut);
            } else if (this.simulation.remainTicks <= 0) {
                this.gameOver(EMarathonResult.TimeOut);
            } else {
                if (checkData.operation) {
                    this.event(EMarathonEvent.DO_OPERATION, checkData.operation);
                }
                this.hands = this.simulation.hands;
                this.updateRaceData();
                if (force) {
                    this.updateRaceTime();
                } else if (checkData.operation && checkData.operation.type == 0) {
                    if (checkData.operation.reward.time) this.normalTimeRemain += this.getTimeByTick(checkData.operation.reward.time);
                    if (checkData.operation.reward.point) this.nowScore += checkData.operation.reward.point;
                }
                // 检查是否需要刷新狂热时间状态
                if (this.simulation.isInFever() != this.duringFeverTime) {
                    if (this.simulation.isInFever()) {
                        this.enterFeverTime();
                    } else {
                        this.quitFeverTime();
                    }
                }
                this.refreshWall();
            }
        }

        public collectItem(type: MarathonItemType, round: number): void {
            if (this.cacheItems && this.cacheItems.round == round) {
                this.cacheItems.items.push(type);
            } else {
                this.cacheItems = {
                    round,
                    items: [type]
                }
            }
            // 道具奖励映射表（道具类型 -> 奖励类型）
            const itemRewardMap = {
                [MarathonItemType.Point]: MarathonRewardType.PointItem,
                [MarathonItemType.Time]: MarathonRewardType.TimeItem,
            };
            const reward = this.getReward(itemRewardMap[type]);
            if (reward.time) this.normalTimeRemain += this.getTimeByTick(reward.time);
            if (reward.point) this.nowScore += reward.point;
            this.event(EMarathonEvent.DO_OPERATION, {
                type: 1,
                item: type,
                reward: reward
            });
        }

        /**
         * 游戏结束
         */
        public gameOver(result: EMarathonResult): void {
            this.pauseGame();
            this.gaming = false;
            this.gameRecord = {
                point: this.simulation.point,
                used_tick: this.simulation.usedTick,
                distance: Number(this.simulation.distance.toFixed(0)),
                new_time: this.simulation.usedTick > this.highestRecord.used_tick,
                new_distance: this.simulation.distance > this.highestRecord.distance,
                new_point: this.simulation.point > this.highestRecord.point,
                originTrain: UI_Bag.get_item_count(UI_Activity_Marathon_Main.trainId),
                addTrain: 0,
                originTrainGrade: UI_Marathon_Train.nowGrade
            };
            this.requestEndGame(result);
        }

        /**
         * 开始场景移动定时器
         */
        private startGameUpdateTimer(): void {
            this.event(EMarathonEvent.GAME_UPDATE);
            this.timer.frameLoop(1, this, () => {
                if (!this.gaming || this.isPause) return;
                const duration = this.currentTime - this.lastUpdateTime;
                if (this.duringFeverTime) {
                    this.feverTimeRemain -= duration;
                } else {
                    this.normalTimeRemain -= duration;
                }
                this.lastUpdateTime = this.currentTime;
                this.event(EMarathonEvent.GAME_UPDATE);
                if (this.normalTimeRemain <= 0) this.checkGameState();
            });
        }

        checkGameState(): void {
            const isEnd = this.simulation.checkGameEnd();
            if (isEnd) {
                const items = this.cacheItems && this.cacheItems.items ? this.cacheItems.items : [];
                let collect = this.simulation.collect('', items);
                if (collect) {
                    this.checkData.push(collect);
                }
                this.gameOver(EMarathonResult.TimeOut);
            }
        }

        /**
         * 重置游戏数据
         */
        public reset(): void {
            this.gaming = false;
            this.duringFeverTime = false;
            this.pauseIndex = 0;
            this._speed = 1;
            this.costTime = 0;
            this.stopTime = 0;
            this.lockNetwork = false;
            this.locking = false;
            this.prepareStart = false;
            this.startTime = 0;
            this.normalTimeRemain = 0;
            this.nowScore = 0;
            this.lastUpdateTime = 0;
            this.lastRoundTime = 0;
            this.lastRound = 0;

            this.hands = [];
            this.feverTiles = [];
            this.wallInfos = [];
            this.wallGroups = [];
            this.checkData = [];
            this.simulation = null;
            this.feverTempTile = null;
            this.raceId = '';
            this.gameRecord = {
                point: 0,
                used_tick: 0,
                distance: 0,
                new_time: false,
                new_distance: false,
                new_point: false,
                originTrain: 0,
                originTrainGrade: 0,
                addTrain: 0
            };
            this.cacheItems = null;
            this.timer.clearAllEx();
        }

        /**
         * 发起游戏开始请求
         */
        public requestStartGame(callback?: Laya.Handler): void {
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            const param: game.IReqMarathonActivityStartRace = {
                activity_id: this.activityId,
            };
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.marathonActivityStartRace, param, (err, res: game.IResMarathonActivityStartRace) => {
                this.lockNetwork = false;
                callback?.run();
                if (err || res['error']) {
                    this.onGameError(game.ERequest.marathonActivityStartRace, err, res);
                } else {
                    app.Log.log(`${game.ERequest.marathonActivityStartRace} res ==== ${JSON.stringify(res)}`);
                    this.initRoundData(res);
                }
            });
        }

        public requestEndGame(result: EMarathonResult): void {
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            const param: game.IReqMarathonActivityFinishRace = {
                activity_id: this.activityId,
                race_data: this.checkData,
                record: this.gameRecord,
                race_id: this.raceId,
            };
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.marathonActivityFinishRace, param, (err, res: game.IResMarathonActivityFinishRace) => {
                this.lockNetwork = false;
                if (err || res['error']) {
                    this.onGameError(game.ERequest.marathonActivityFinishRace, err, res);
                    let data = {};
                    if (res && res.error && res.error.json_param) {
                        app.Log.Error(`${game.ERequest.marathonActivityFinishRace} res ==== ${res.error.json_param}`);
                        data = res.error.json_param;
                    }
                    this.event(EMarathonEvent.GAME_ERROR, data);
                } else {
                    app.Log.log(`${game.ERequest.marathonActivityFinishRace} res ==== ${JSON.stringify(res)}`);
                    if (res.rewards && res.rewards.length > 0) {
                        for (let i = 0; i < res.rewards.length; i++) {
                            if (res.rewards[i].reward.id == UI_Activity_Marathon_Main.trainId) {
                                this.gameRecord.addTrain = res.rewards[i].reward.count;
                            }
                        }
                    }
                    this.updateRecord(res.highest_record);
                    this.event(EMarathonEvent.GAME_END, result);
                }
            });
        }


        public onGameError(method: string, err: any, res: any) {
            if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26123)) {
                uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093), Laya.Handler.create(this, () => {
                    UI_Activity_Marathon_Main.Inst.hide();
                }));
            } else {
                uiscript.UIMgr.Inst.showNetReqError(method, err, res);
            }
        }

    }
}