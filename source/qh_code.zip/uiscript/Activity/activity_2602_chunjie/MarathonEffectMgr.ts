module uiscript {
	/**
	 * 麻将牌动画类型
	 */
	export enum EPaiAnim {
		KICK = "maque_kick",
		INIT = "maque_init",
	}

	enum EMarathonWeather {
		DAY = 'day',
		DUSK = 'dusk',
		NIGHT = 'night',
	}
	/**
	 * 控制层：特效管理器（表现层核心）
	 */
	export class MarathonEffectMgr {
		private static _instance: MarathonEffectMgr;
		public static get Inst(): MarathonEffectMgr {
			return this._instance || (this._instance = new MarathonEffectMgr());
		}

		// 资源名称
		public mjpResName: string;
		public mjpbResName: string;
		// 资源引用
		private effectScene: Laya.Scene;
		private effectSceneFront: Laya.Scene;
		private container: Laya.Sprite;
		private containerFront: Laya.Sprite;
		private rootScene: Laya.Sprite3D;
		private rootSceneFront: Laya.Sprite3D;
		private rootUI: Laya.Sprite3D;
		private effectBg: Laya.Sprite3D;
		private effectNormal: Laya.Sprite3D;
		private effectFever: Laya.Sprite3D;
		private effectSky: Laya.MeshSprite3D;
		private effectRoof: Laya.MeshSprite3D;
		private originWall: Laya.Sprite3D;
		private rootMove: Laya.Sprite3D;
		private rootMoveFront: Laya.Sprite3D;
		private rootPaiFront: Laya.Sprite3D;
		private effectCountDown: Laya.Sprite3D;
		private tempMaque: Laya.Sprite3D; // 临时麻将对象，用于播放牌被吃掉的动画

		// 动画组件
		private weatherAnimator: Catfood.CAnimator;
		private feverSkyAnimator: Catfood.CAnimator;
		private feverAnimator: Catfood.CAnimator;
		private normalAnimator: Catfood.CAnimator;
		private skyAnimator: Catfood.CAnimator[];
		private countDownAnimator: Catfood.CAnimator;

		// 游戏对象
		private character: MarathonCharaMgr;
		private runningWalls: MarathonWall[] = [];
		private poolWalls: MarathonWall[] = []; // 牌墙对象池
		private runningPais: MarathonPai[] = [];
		private poolPais: MarathonPai[] = []; // 牌对象池

		// 状态管理
		private currentWeather: EMarathonWeather;
		private currentWallId: number = 0;
		private timer: Laya.Timer;

		private constructor() {
			this.timer = new Laya.Timer();
		}

		/**
		 * 初始化事件监听
		 */
		private initEventListeners(): void {
			const data = MarathonData.Inst;
			data.on(EMarathonEvent.GAME_START, this, this.onGameStart);
			data.on(EMarathonEvent.NEW_WALL, this, this.createWall);
			data.on(EMarathonEvent.PAUSE_GAME, this, this.onPause);
			data.on(EMarathonEvent.RESUME_GAME, this, this.onResume);
			data.on(EMarathonEvent.CHANGE_SPEED, this, this.onSpeedChange);
			data.on(EMarathonEvent.ENTER_FEVER_TIME, this, this.onEnterFeverTime);
			data.on(EMarathonEvent.QUIT_FEVER_TIME, this, this.onQuitFeverTime);
			data.on(EMarathonEvent.PREPARE_START, this, this.prepareStartGame);
			data.on(EMarathonEvent.GAME_END, this, this.onGameEnd);
		}

		/**
		 * 初始化特效管理器
		 */
		public init(container: Laya.Sprite, containerFront: Laya.Sprite): void {
			this.container = container;
			this.containerFront = containerFront;
			this.initEventListeners();
			this.loadEffectResources();
			this.initEffectObjects();
			this.initCharacter();
		}

		/**
		 * 加载特效资源
		 */
		private loadEffectResources(): void {
			// 加载麻将资源名称
			this.mjpResName = game.GameUtility.get_view_res_name(game.EView.mjp_surface);
			if (view.DesktopMgr.en_mjp) {
				this.mjpResName += '_0';
			}
			this.mjpbResName = game.GameUtility.get_view_res_name(game.EView.mjp);

			// 加载场景
			this.effectScene = Laya.loader.getRes('scene/effect_2602_bg.ls');
			this.effectSceneFront = Laya.loader.getRes('scene/effect_2602_bg_front.ls');
			if (this.effectScene._childs) {
				this.effectScene._childs.forEach(child => {
					game.EffectMgr.dfsCompileShader(this.effectScene, child);
				});
			}
			if (this.effectSceneFront._childs) {
				this.effectSceneFront._childs.forEach(child => {
					game.EffectMgr.dfsCompileShader(this.effectSceneFront, child);
				});
			}
			let comScene = this.container.getChildByName('scene') as Laya.Sprite;
			comScene.addChild(this.effectScene);
			this.containerFront.addChild(this.effectSceneFront);
		}

		/**
		 * 初始化特效对象
		 */
		private initEffectObjects(): void {
			this.rootScene = this.effectScene.getChildByName('root_scene') as Laya.Sprite3D;
			this.rootSceneFront = this.effectSceneFront.getChildByName('root_scene') as Laya.Sprite3D;
			this.rootUI = this.effectSceneFront.getChildByName('root_ui') as Laya.Sprite3D;
			this.effectBg = this.rootScene.getChildByName('scene') as Laya.Sprite3D;
			this.effectNormal = this.rootScene.getChildByName('scene').getChildByName('normal') as Laya.Sprite3D;
			this.effectFever = this.rootScene.getChildByName('scene').getChildByName('fever_time') as Laya.Sprite3D;
			this.effectFever.active = false;

			this.originWall = this.rootScene.getChildByName('pai') as Laya.Sprite3D;
			this.originWall.active = false;

			this.rootMove = this.rootScene.getChildByName('root_move') as Laya.Sprite3D;
			this.rootMoveFront = this.rootSceneFront.getChildByName('root_move') as Laya.Sprite3D;
			this.rootPaiFront = this.rootMoveFront.getChildByName('pai') as Laya.Sprite3D;
			this.tempMaque = this.rootPaiFront.getChildByName('maque_temp') as Laya.Sprite3D;
			this.tempMaque.active = false;
			this.effectRoof = this.effectNormal.getChildByName('speed').getChildByName('roof') as Laya.MeshSprite3D;
			// 初始化动画组件
			this.weatherAnimator = this.effectNormal.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.weatherAnimator.EnableAdvancedFeatures(true);
			this.feverSkyAnimator = this.effectFever.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.feverSkyAnimator.EnableAdvancedFeatures(true);
			this.feverAnimator = (this.effectFever.getChildByName('speed') as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.normalAnimator = (this.effectNormal.getChildByName('speed') as Laya.Sprite3D)
				.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.normalAnimator.EnableAdvancedFeatures(true);
			this.feverAnimator.EnableAdvancedFeatures(true);
			this.effectSky = this.effectNormal.getChildByName('sky') as Laya.MeshSprite3D;
			this.skyAnimator = [];
			for (let i = 0; i < this.effectSky._childs.length; i++) {
				const skyPart = this.effectSky._childs[i] as Laya.MeshSprite3D;
				const animator = skyPart.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				if (animator) {
					animator.EnableAdvancedFeatures(true);
					this.skyAnimator.push(animator);
				}
			}
			this.effectCountDown = this.rootUI.getChildByName('countdown') as Laya.Sprite3D;
			this.countDownAnimator = this.effectCountDown.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			game.Tools.checkEffectLocalization(this.effectCountDown);
		}

		beginSceneMove(): void {
			const speed = MarathonData.Inst.speed;
			this.normalAnimator.SetSpeed(speed);
			this.normalAnimator.Resume();
			this.skyAnimator.forEach(animator => {
				animator.SetSpeed(speed);
				animator.Resume();
			});
			this.feverAnimator.Resume();
			this.feverSkyAnimator.Resume();
		}

		stopSceneMove(): void {
			this.normalAnimator.Pause();
			this.skyAnimator.forEach(animator => {
				animator.Pause();
			});
			this.feverAnimator.Pause();
			this.feverSkyAnimator.Pause();
		}


		initCharacter() {
			// 初始化角色
			const charaNode = this.rootScene.getChildByName('role') as Laya.Sprite3D;
			const charaNodeFront = this.rootSceneFront.getChildByName('role') as Laya.Sprite3D;
			this.character = new MarathonCharaMgr(this.container.getChildByName('illust') as Laya.Sprite, charaNode, charaNodeFront);
		}

		prepareStartGame() {
			this.reset();
			this.stopSceneMove();
			this.character.startGame();
			this.refreshWeather();
			this.effectCountDown.active = true;
			this.countDownAnimator.Play('countdown');
			const animDuration = this.countDownAnimator.GetDurationByAnimName('countdown') * 1000;
			const lastTime = MarathonData.Inst.currTimer;
			MarathonData.Inst.timer.frameLoop(1, this, () => {
				const delay = MarathonData.Inst.currTimer - lastTime;
				if (delay > animDuration) {
					this.effectCountDown.active = false;
					MarathonData.Inst.startGame();
				}
			});
			view.AudioMgr.PlayAudio(10383);
		}

		/**
		 * 游戏开始回调
		 */

		private onGameStart(): void {
			this.moveNextWall();
			this.beginSceneMove();
			// this.scheduleWeatherChange();
		}

		private onGameEnd() {
			this.character.endGame();
		}

		/**
		 * 创建牌墙
		 */
		private createWall(wallInfo: IMarathonWallInfo): void {
			let wall: MarathonWall;

			// 对象池复用
			if (this.poolWalls.length > 0) {
				wall = this.poolWalls.pop()!;
			} else {
				const wallNode = this.originWall.clone() as Laya.Sprite3D;
				wall = wallNode.addComponent(MarathonWall) as MarathonWall;
				this.rootMove.addChild(wall.owner);
			}
			this.runningWalls.push(wall);
			wall.setWallInfo(wallInfo, true);
		}

		/**
		 * 移动下一个牌墙
		 */
		public moveNextWall(): void {
			this.currentWallId++;
			const targetWall = this.runningWalls.find(w => w.wallInfo.round === this.currentWallId);
			if (targetWall) {
				targetWall.startMove();
			}
		}

		/**
		 * 移除牌墙（回收至对象池）
		 */
		public recycleWall(wall: MarathonWall): void {
			const index = this.runningWalls.indexOf(wall);
			if (index >= 0) {
				this.runningWalls.splice(index, 1);
			}

			wall.reset();
			this.poolWalls.push(wall);
		}

		/**
		 * 收集麻将牌
		 */
		public collectTile(wall: MarathonWall, isAccurate: boolean = false): void {
			const tileIndex = this.character.currentIndex;
			const matrix = wall.collectTileByIndex(tileIndex);
			const tile = wall.wallInfo.tiles[tileIndex];
			let duration = 0;
			if (matrix && tile) {
				let pai: MarathonPai;
				if (this.poolPais.length > 0) {
					pai = this.poolPais.pop()!;
				} else {
					const paiNode = this.tempMaque.clone() as Laya.Sprite3D;
					pai = paiNode.addComponent(MarathonPai) as MarathonPai;
					this.rootPaiFront.addChild(pai.owner);
				}
				pai.owner.active = true;
				pai.transform.worldMatrix = matrix;
				pai.setTileValue(tile);
				const targetPos = MarathonPai.getPaiTargetPos(MarathonData.Inst.hands, tile);
				duration = MarathonPai.getKickDurationByDistance(Laya.Vector3.distance(pai.transform.localPosition, targetPos));
				pai.playAnim(EPaiAnim.KICK, targetPos, Laya.Handler.create(this, () => {
					this.recyclePai(pai);
				}));
				this.runningPais.push(pai);
			}
			MarathonData.Inst.collectWall(tile, duration * 1000, isAccurate);
		}

		public getCharaIndex(): number {
			return this.character.currentIndex;
		}

		/**
		 * 移除动画麻将牌（回收至对象池）
		 */
		public recyclePai(pai: MarathonPai): void {
			const index = this.runningPais.indexOf(pai);
			if (index >= 0) {
				this.runningPais.splice(index, 1);
			}

			pai.reset();
			this.poolPais.push(pai);
		}

		public collectItem(itemInfo: IMarathonWallItem, round: number): boolean {
			const tileIndex = this.character.currentIndex;
			if (itemInfo.y === tileIndex) {
				view.AudioMgr.PlayAudio(10387);
				this.character.showCollectEffect();
				MarathonData.Inst.collectItem(itemInfo.type, round);
				return true;
			}
			return false;
		}

		/**
		 * 移动角色
		 */
		public moveCharacter(direction: number, doAnim: boolean = true): void {
			this.character.move(direction, doAnim);
		}

		/**
		 * 调度天气切换
		 */
		private scheduleWeatherChange(): void {
			const weatherTypes = [EMarathonWeather.DAY, EMarathonWeather.DUSK, EMarathonWeather.NIGHT];
			const delay = MarathonConstant.WEATHER_DELAY[weatherTypes.indexOf(this.currentWeather)];
			this.timer.once(delay, this, () => {
				this.animateWeatherChange();
			});
		}

		/**
		 * 动画切换天气
		 */
		private animateWeatherChange(): void {
			// 切换到下一个天气
			const weatherTypes = [EMarathonWeather.DAY, EMarathonWeather.DUSK, EMarathonWeather.NIGHT];
			const currentIdx = weatherTypes.indexOf(this.currentWeather);
			const nextIdx = (currentIdx + 1) % weatherTypes.length;
			const nextWeather = weatherTypes[nextIdx];

			const lastWeather = this.currentWeather;
			this.currentWeather = nextWeather;
			const animName = `weather_${lastWeather}_${nextWeather}`;
			this.weatherAnimator.Play(animName);
			const delay = this.weatherAnimator.GetDurationByAnimName(animName) * 1000;
			this.timer.once(delay, this, () => {
				this.weatherAnimator.Play(`weather_${nextWeather}`);
				this.scheduleWeatherChange();
			});
		}

		private refreshWeather(): void {
			const WEATHER_LIST = [
				EMarathonWeather.DAY,
				EMarathonWeather.DUSK,
				EMarathonWeather.NIGHT
			];
			const randomIndex = Math.floor(Math.random() * WEATHER_LIST.length);
			let weather = WEATHER_LIST[randomIndex];
			this.weatherAnimator.Play('weather_' + weather);
			this.currentWeather = weather;
		}

		/**
		 * 进入狂热时间
		 */
		private onEnterFeverTime(wallInfos: IMarathonWallInfo[]): void {
			// 显示狂热特效
			this.effectFever.active = true;
			this.feverAnimator.Play(null);
			MarathonData.Inst.pauseGame();

			// 更新现有牌墙
			wallInfos.forEach(wallInfo => {
				const wall = this.runningWalls.find(w => w.wallInfo.round == wallInfo.round);
				if (wall) {
					wall.setWallInfo(wallInfo);
				}
			});
			// 延迟恢复游戏
			Laya.timer.once(MarathonConstant.FEVER_TIME_ANIM_DELAY, this, () => {
				MarathonData.Inst.resumeGame();
			});
			this.feverSkyAnimator.Play('fever_time_show');
			this.feverSkyAnimator.offAll(Laya.Event.COMPLETE);
			this.feverSkyAnimator.once(Laya.Event.COMPLETE, this, () => {
				this.feverSkyAnimator.Play('fever_time_idle');
			});
		}

		/**
		 * 退出狂热时间
		 */
		private onQuitFeverTime(wallInfos: IMarathonWallInfo[]): void {
			// 更新现有牌墙
			wallInfos.forEach(wallInfo => {
				const wall = this.runningWalls.find(w => w.wallInfo.round == wallInfo.round);
				if (wall) {
					wall.setWallInfo(wallInfo);
				}
			});
			this.feverSkyAnimator.Play('fever_time_hide');
			this.feverSkyAnimator.offAll(Laya.Event.COMPLETE);
			this.feverSkyAnimator.once(Laya.Event.COMPLETE, this, () => {
				this.effectFever.active = false;
				this.feverSkyAnimator.Stop();
				this.feverAnimator.Stop();
			});
			this.character.run();
		}

		/**
		 * 暂停游戏
		 */
		private onPause(): void {
			this.weatherAnimator.Pause();
			this.timer.scale = 0;
			this.runningWalls.forEach(wall => wall.pauseMove());
			this.character.stop();
			this.stopSceneMove();
		}

		/**
		 * 恢复游戏
		 */
		private onResume(): void {
			this.weatherAnimator.Resume();
			this.timer.scale = 1;
			this.runningWalls.forEach(wall => wall.resumeMove());
			this.character.run();
			this.beginSceneMove();
		}

		/**
		 * 速度变化
		 */
		private onSpeedChange(speed: number): void {
			this.runningWalls.forEach(wall => wall.setSpeedFactor(speed));
			this.normalAnimator.SetSpeed(speed);
			this.skyAnimator.forEach(animator => {
				animator.SetSpeed(speed);
			});
		}

		charaMoveIn() {
			this.character.moveIn();
		}

		/**
		 * 重置特效管理器
		 */
		public reset(): void {
			// 回收所有牌墙
			this.runningWalls.forEach(wall => {
				wall.reset();
				this.poolWalls.push(wall);
			});
			this.runningWalls = [];
			this.runningPais.forEach(pai => {
				pai.reset();
				this.poolPais.push(pai);
			});
			this.runningPais = [];
			// 重置角色和动画
			this.character.reset();
			this.feverSkyAnimator.Stop();
			this.feverAnimator.Stop();
			this.countDownAnimator.Stop();
			this.effectFever.active = false;
			this.effectCountDown.active = false;
			MarathonData.Inst.timer.clearAll(this);
			this.weatherAnimator.Stop();
			this.timer.clearAll(this);
			Laya.timer.clearAll(this);
			this.timer.scale = 1;
			this.currentWeather = null;

			// 重置状态
			this.currentWallId = 0;
		}

		/**
		 * 销毁特效管理器
		 */
		public destroy(): void {
			this.reset();
			this.poolWalls.forEach(wall => wall.destroy());
			this.poolWalls = [];
			this.poolPais.forEach(pai => pai.destroy());
			this.poolPais = [];
			this.character.destroy();
			this.character = null;
			if (this.effectScene) {
				this.effectScene.removeSelf();
				this.effectScene.destroy();
				this.effectScene = null;
			}
			this.container = null;
			// 移除事件监听
			MarathonData.Inst.offAll();
		}
	}

	export enum EMarathonSpineState {
		SPEED1 = "speed1",
		SPEED2 = "speed2",
		SPEED_HIGH = "speed_high",
		END = "end",
		IDLE = "idle",
	}

	export class MarathonCharaMgr {
		private me: Laya.Sprite;
		private effectTrail: Laya.Sprite3D;
		private effectCollect: Laya.Sprite3D;
		private effectChara: MarathonCharaEffect;
		private effectCharaFront: MarathonCharaEffect;
		private rootSpine: Laya.Sprite;
		private illust: Laya.Sprite;
		private spine: CatFoodSpine.SpineController;
		private spineSprite: CatFoodSpine.SpineSprite;
		private targetIndex: number = 3;
		private locking: boolean;

		constructor(me: Laya.Sprite, effectRoot: Laya.Sprite3D, effectRootFront: Laya.Sprite3D) {
			this.me = me;
			this.illust = this.me.getChildByName('illust') as Laya.Sprite;
			this.rootSpine = this.illust.getChildByName('spine') as Laya.Sprite;
			this.effectChara = effectRoot.addComponent(MarathonCharaEffect) as MarathonCharaEffect;
			this.effectCharaFront = effectRootFront.addComponent(MarathonCharaEffect) as MarathonCharaEffect;
			this.effectTrail = effectRoot.getChildByName('root_center').getChildByName('role_trail') as Laya.Sprite3D;
			this.effectTrail.active = false;
			this.effectCollect = effectRootFront.getChildByName('root_center').getChildByName('item_pick') as Laya.Sprite3D;
			this.effectCollect.active = false;
			this.initSpine();
		}

		private initSpine() {
			this.spine = CatFoodSpine.SpineMgr.Inst.getSpecialSprite("marathon", game.Tools.localUISrc('extendRes/spine/2602chunjie/character'), { id: 0 } as any);
			this.spine.root.visible = true;
			this.spineSprite = this.spine['spines'][0];

			this.spine.root.pos(0, 0);
			(this.spine.root as Laya.Sprite).visible = true;
			this.spine.onParentChange(1, new Laya.Point(0, 0));
			this.spine.pX = 0;
			this.spine.pY = 0;
			this.spine.offsetX = 0;
			this.spine.offsetY = 1080;
			this.spine.sx = this.spine.sy = 1;
			this.spine.aniAlpha = true;
			this.spine.updateSpineInfo();
			this.rootSpine.addChild(this.spine.root);
			this.spine.play(EMarathonSpineState.IDLE, true);
		}

		moveIn() {
			this.effectChara.moveIn(this.targetIndex);
		}

		public startGame() {
			this.spine.play(EMarathonSpineState.SPEED1, true);
			this.effectChara.initPos(this.targetIndex);
			this.effectCharaFront.initPos(this.targetIndex);
		}

		public endGame() {
			this.spine.play(EMarathonSpineState.END, false);
		}

		/**
		 * 获取当前选中的麻将索引
		 */
		public get currentIndex(): number {
			const posZ = this.illust.y;
			let index = 0;
			for (let i = 1; i < MarathonConstant.MAX_HAND_TILES; i++) {
				const threshold = MarathonConstant.CHARA_SPINE_MOVE_AREA.x -
					MarathonConstant.CHARA_SPINE_MOVE_STEP * i + (MarathonConstant.CHARA_SPINE_MOVE_STEP / 2);
				if (posZ < threshold) {
					index = i;
				} else {
					break;
				}
			}
			return index;
		}

		public move(direction: number, doAnim: boolean = true) {
			let newIndex = doAnim ? this.targetIndex + direction : direction;
			if (newIndex < 0 || newIndex >= MarathonConstant.MAX_HAND_TILES) return;
			this.targetIndex = newIndex;
			this.effectChara.move(newIndex, doAnim);
			this.effectCharaFront.move(newIndex, doAnim);
			let targetY = MarathonConstant.CHARA_SPINE_MOVE_AREA.x -
				MarathonConstant.CHARA_SPINE_MOVE_STEP * this.targetIndex;
			const distance = Math.abs(targetY - this.illust.y);
			const duration = distance / MarathonConstant.CHARA_SPINE_MOVE_STEP * MarathonConstant.CHARA_STEP_TIME;
			Laya.Tween.clearAll(this.illust);
			if (doAnim) {
				Laya.Tween.to(this.illust, { y: targetY }, duration, Laya.Ease.linearNone);
			} else {
				this.illust.y = targetY;
			}
		}

		showCollectEffect() {
			this.effectCollect.active = false;
			this.effectCollect.active = true;
		}

		public stop() {
			this.spine.play(EMarathonSpineState.IDLE, true);
		}

		public run() {
			if (MarathonData.Inst.duringFeverTime) {
				this.spine.play(EMarathonSpineState.SPEED_HIGH, true);
				this.effectTrail.active = true;
			} else {
				this.spine.play(EMarathonSpineState.SPEED1, true);
				this.effectTrail.active = false;
			}
		}

		public reset() {
			this.targetIndex = 3;
			let targetY = MarathonConstant.CHARA_SPINE_MOVE_AREA.x -
				MarathonConstant.CHARA_SPINE_MOVE_STEP * this.targetIndex;
			this.illust.y = targetY;
			this.spine.play(EMarathonSpineState.IDLE);
			this.effectTrail.active = false;
			this.effectCollect.active = false;
			this.effectChara.reset();
		}

		public destroy() {
			this.reset();
			this.spine.reset();
			this.spine = null;
			CatFoodSpine.SpineMgr.Inst.clearSpecialSprites();
		}
	}

	/**
	 * 角色组件
	 */
	export class MarathonCharaEffect extends game.Moveable {
		_load(): void {
			const rootCenter = this.owner.getChildByName('root_center') as Laya.Sprite3D;
		}

		/**
		 * 开始游戏
		 */
		public initPos(targetIndex: number): void {
			this.movement.clear();
			const targetZ = MarathonConstant.CHARA_MOVE_AREA.x + targetIndex * MarathonConstant.CHARA_MOVE_STEP;
			this.owner.transform.localPosition = new Laya.Vector3(0.259, 0, targetZ);
		}

		/**
		 * 移动角色
		 */
		public move(targetIndex: number, doAnim: boolean = true): void {
			const targetZ = MarathonConstant.CHARA_MOVE_AREA.x + targetIndex * MarathonConstant.CHARA_MOVE_STEP;
			const targetPos = new Laya.Vector3(0.259, 0, targetZ);

			// 计算移动时长
			const startZ = this.owner.transform.localPosition.z;
			const distance = Math.abs(startZ - targetZ);
			const duration = distance / MarathonConstant.CHARA_MOVE_STEP * MarathonConstant.CHARA_STEP_TIME;

			// 执行移动
			this.movement.clear();
			const movement = game.Movement.getMovement();
			movement.duration = duration;
			movement.targetPosition = targetPos;
			this.movement.addMovement(movement);
			if (doAnim) {
				this.movement.startMove();
			} else {
				this.movement.moveImmediately();
			}
		}

		moveIn(targetIndex: number): void {
			const targetZ = MarathonConstant.CHARA_MOVE_AREA.x + targetIndex * MarathonConstant.CHARA_MOVE_STEP;
			const targetPos = new Laya.Vector3(0.259, 0, targetZ);
			const startPos = new Laya.Vector3(0.372, 0, targetZ);
			this.owner.transform.localPosition = startPos;
			// 0.11313
			const duration = 500;
			// 执行移动
			this.movement.clear();
			const movement = game.Movement.getMovement();
			movement.duration = duration;
			movement.targetPosition = targetPos;
			this.movement.addMovement(movement);
			this.movement.startMove();
		}
		/**
		 * 重置角色
		 */
		public reset(): void {
			Laya.timer.clearAll(this);
			this.movement.clear();
		}
	}

	/**
	 * 牌墙组件
	 */
	export class MarathonWall extends game.Moveable {
		public wallInfo: IMarathonWallInfo;
		private tiles: MarathonPai[] = [];
		private tipEffect: Laya.Sprite3D;
		private isListening: boolean = false;
		private isCollected: boolean = false;
		private effectItems: Laya.Sprite3D;
		private items: MarathonItem[] = [];
		private runingItems: MarathonItem[] = [];
		private roundLabel: Laya.Label;
		private roundTex: Laya.Texture2D;
		private isAccurate: boolean = false;

		_load(): void {
			// 初始化麻将牌
			const paiRoot = this.owner.getChildByName('pai') as Laya.Sprite3D;
			paiRoot._childs.forEach((child, index) => {
				const paiNode = child as Laya.Sprite3D;
				let pai = paiNode.getComponentByType(MarathonPai) as MarathonPai;
				if (!pai) {
					pai = paiNode.addComponent(MarathonPai) as MarathonPai;
				}
				pai.index = index;
				this.tiles.push(pai);
			});

			// 初始化提示特效
			this.tipEffect = this.owner.getChildByName('tip') as Laya.Sprite3D;
			this.tipEffect.active = false;
			this.effectItems = this.owner.getChildByName('items') as Laya.Sprite3D;
			this.items = [];
			const itemName = ['item_clock', 'item_radish'];
			for (let i = 0; i < 2; i++) {
				const child = this.effectItems.getChildByName(itemName[i]) as Laya.Sprite3D;
				const item: MarathonItem = child.addComponent(MarathonItem) as MarathonItem;
				this.items.push(item);
				item.reset();
			}
		}

		/**
		 * 设置牌墙信息
		 */
		public setWallInfo(wallInfo: IMarathonWallInfo, isNewWall: boolean = false): void {
			this.wallInfo = wallInfo;
			// 更新麻将牌
			this.tiles.forEach((pai, index) => {
				const tile = wallInfo.tiles[index] || "";
				pai.setTileValue(tile, isNewWall);
			});
			if (isNewWall) this.prefreshStartPos();
			this.runingItems.forEach(item => item.reset());
			this.runingItems = [];
			for (let i = 0; i < wallInfo.items.length; i++) {
				const itemInfo = wallInfo.items[i];
				const item = this.items[itemInfo.type - 1];
				if (item) {
					item.show(itemInfo, wallInfo.round);
				}
				this.runingItems.push(item);
			}
		}

		private prefreshStartPos() {
			this.owner.active = true;
			let posX = MarathonConstant.WALL_START_X;
			if (this.wallInfo.round == 1) {
				posX = MarathonConstant.WALL_FIRST_START_X;
			} else if (this.wallInfo.round == 2) {
				posX = MarathonConstant.WALL_FIRST_START_X - MarathonConstant.WALL_INTERVAL;
			}
			this.transform.localPosition = new Laya.Vector3(posX, 0, 0);
		}

		/**
		 * 开始移动
		 */
		public startMove(): void {
			this.isListening = true;
			this.isCollected = false;
			this.isAccurate = true;

			// 计算移动时长
			const posX = this.transform.localPosition.x;
			const distance = MarathonConstant.WALL_TARGET_X - posX;
			const duration = distance / MarathonConstant.BASE_WALL_SPEED;

			// 创建移动动画
			this.movement.clear();
			const movement = game.Movement.getMovement();
			movement.duration = duration;
			movement.targetPosition = new Laya.Vector3(MarathonConstant.WALL_TARGET_X, 0, 0);
			movement.speedFactor = MarathonData.Inst.speed;

			// 移动更新回调
			movement.onUpdate = Laya.Handler.create(this, (progress: number) => {
				const pos = this.transform.localPosition.x;
				// 触发下一个牌墙移动
				if (pos >= MarathonConstant.WALL_START_X + MarathonConstant.WALL_INTERVAL && this.isListening) {
					this.isListening = false;
					MarathonEffectMgr.Inst.moveNextWall();
				}
				// 收集麻将牌
				if (!this.isCollected) {
					if (pos >= 0.22 && pos < 0.22 + 0.05) {
						if (this.isAccurate) {
							MarathonData.Inst.updateRaceDistance(this.wallInfo.round);
						}
						const index = MarathonEffectMgr.Inst.getCharaIndex();
						if (this.wallInfo.tiles[index]) {
							this.isCollected = true;
							MarathonEffectMgr.Inst.collectTile(this, this.isAccurate);
						}
						this.isAccurate = false;
					}
					if (pos >= 0.22 + 0.05) {
						this.isCollected = true;
						MarathonEffectMgr.Inst.collectTile(this);
					}
				}
				this.runingItems.forEach(item => item.checkCollect());
			}, null, false);

			// 移动结束回调
			movement.onEnd = Laya.Handler.create(this, () => {
				this.owner.active = false;
				Laya.timer.once(500, this, () => {
					MarathonEffectMgr.Inst.recycleWall(this);
				});
			});

			this.movement.addMovement(movement);
			this.movement.startMove();
		}

		/**
		 * 踢掉指定索引的麻将
		 */
		public collectTileByIndex(index: number): Laya.Matrix4x4 {
			const pai = this.tiles[index];
			if (pai) {
				pai.owner.active = false;
				return pai.transform.worldMatrix.clone();
			}
			return null;
		}

		/**
		 * 设置速度系数
		 */
		public setSpeedFactor(factor: number): void {
			this.movement.speedFactor = factor;
		}

		/**
		 * 暂停移动
		 */
		public pauseMove(): void {
			this.movement.pause();
		}

		/**
		 * 恢复移动
		 */
		public resumeMove(): void {
			this.movement.resume();
		}

		/**
		 * 重置牌墙
		 */
		public reset(): void {
			this.tipEffect.active = false;
			this.owner.active = false;
			this.movement.clear();
			Laya.timer.clearAll(this);
			this.tiles.forEach(pai => pai.reset());
			this.runingItems.forEach(item => item.reset());
			this.runingItems = [];
		}

		destroy() {
			this.owner.removeSelf();
			this.owner.destroy();
		}
	}

	class MarathonItem extends game.Moveable {
		private round: number;
		private itemInfo: IMarathonWallItem;
		private isCollected: boolean = false;
		private animator: Catfood.CAnimator;

		_load(): void {
			this.animator = this.owner.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
		}

		show(itemInfo: IMarathonWallItem, round: number): void {
			this.round = round;
			this.itemInfo = itemInfo;
			this.owner.active = true;
			this.isCollected = false;
			const startX = MarathonConstant.WALL_INTERVAL / 2 + MarathonConstant.RANDOM_ITEM_AREA * MarathonConstant.RANDOM_ITEM_INTERVAL / 2;
			const posX = startX - itemInfo.x * MarathonConstant.RANDOM_ITEM_INTERVAL;
			const posZ = MarathonConstant.CHARA_MOVE_AREA.x + itemInfo.y * MarathonConstant.CHARA_MOVE_STEP - 0.01;
			this.owner.transform.localPosition = new Laya.Vector3(posX, 0, posZ);
			this.animator.Play(null);
		}

		checkCollect() {
			const pos = this.transform.position.clone();
			if ((pos.x >= 0.22 && pos.x <= 0.22 + 0.055) && !this.isCollected) {
				let collected = MarathonEffectMgr.Inst.collectItem(this.itemInfo, this.round);
				if (collected) {
					this.isCollected = true;
					this.reset();
				}
			}
		}

		reset(): void {
			this.animator.Stop();
			this.owner.active = false;
			Laya.timer.clearAll(this);
		}

	}

	/**
	 * 麻将牌组件
	 */
	export class MarathonPai extends game.Moveable {
		public static KICK_STANDARD_DURATION_MIN: number = 0.2;
		public static KICK_STANDARD_DURATION_MAX: number = 0.35;
		public static KICK_STANDARD_DISTANCE_MIN: number = 0.11748;
		public static KICK_STANDARD_DISTANCE_MAX: number = 0.35948;
		public static getKickDurationByDistance(distance: number): number {
			const Remap = (value: number, inputMin: number, inputMax: number, outputMin: number, outputMax: number) => {
				if (Math.abs(inputMax - inputMin) < 0.0001) return outputMin;
				return outputMin + (value - inputMin) * (outputMax - outputMin) / (inputMax - inputMin);
			}
			const totalDuration = Remap(distance, this.KICK_STANDARD_DISTANCE_MIN, this.KICK_STANDARD_DISTANCE_MAX, this.KICK_STANDARD_DURATION_MIN, this.KICK_STANDARD_DURATION_MAX);
			return totalDuration;
		}
		public static getPaiTargetPos(hands: string[], tile: string): Laya.Vector3 {
			const targetIndex = hands.length >= MarathonConstant.MAX_HAND_TILES ? 3 : MarathonData.findPaiInsertIndex(hands, tile);
			let canEliminate = MarathonData.canEliminate(hands, tile);
			const targetPos = canEliminate ? new Laya.Vector3(-0.12 + 0.04 * targetIndex, -0.06, 0) : new Laya.Vector3(-0.12 + 0.04 * targetIndex, -0.008, 0);
			return targetPos;
		}

		public index: number = 0;
		public val: string = null;

		private rootRot: Laya.Sprite3D; //偏移用的
		private rootNode: Laya.Sprite3D; //显示根节点，内置动画根节点
		private animator: Catfood.CAnimator;
		private outlineNode: Laya.MeshSprite3D;
		private mjpNode: Laya.MeshSprite3D;
		private mesh: Laya.MeshSprite3D;
		private collectEffect1: Laya.Sprite3D;
		private collectEffect2: Laya.Sprite3D;

		// 状态
		private isFu: boolean = false;

		_load(): void {
			this.rootRot = this.owner.getChildByName('maque') as Laya.Sprite3D;
			this.rootNode = this.rootRot.getChildByName('maque') as Laya.Sprite3D;
			this.collectEffect1 = this.rootNode.getChildByName('fx') as Laya.Sprite3D;
			this.collectEffect2 = this.rootNode.getChildByName('fx2') as Laya.Sprite3D;
			this.mesh = this.rootNode.getChildAt(0) as Laya.MeshSprite3D;
			this.animator = this.rootNode.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			this.animator.EnableAdvancedFeatures(true);
			this.initMahjongNode();
		}

		/**
		 * 初始化麻将节点
		 */
		private initMahjongNode(): void {
			// 创建轮廓材质
			this.outlineNode = this.rootNode.getChildByName('maque_outline') as Laya.MeshSprite3D;
			this.mjpNode = this.rootNode.getChildByName('mjp_new') as Laya.MeshSprite3D;
			this.mjpNode.addChild(this.outlineNode);

			this.outlineNode.transform.localPosition = new Laya.Vector3(0, 0, 0);
			this.outlineNode.transform.scale = new Laya.Vector3(1, 1, 1);
			this.outlineNode.transform.localRotation = new Laya.Quaternion(0, 0, 0, 0);

			// 设置轮廓材质
			const outlineMat = new caps.Material_Outline(caps.Outline.filename);
			outlineMat.renderQueue = 3001;
			outlineMat.setColor(caps.Outline.OUTLINE_COLOR, new Laya.Vector3(0.2078, 0.2078, 0.2078));
			outlineMat.setNumber(caps.Outline.OUTLINE_ALPHA, 0.6);
			outlineMat.setNumber(caps.Outline.OUTLINE, 0.0012);
			this.outlineNode.meshRender.sharedMaterial = outlineMat;
		}

		/**
		 * 设置麻将值
		 */
		public setTileValue(tile: string, refreshRandom: boolean = false): void {
			this.val = tile;
			if (!tile) {
				this.owner.active = false;
				return;
			}
			this.owner.active = true;
			this.isFu = MarathonData.Inst.isFeverTile(tile);
			// 加载纹理
			const texturePath = 'scene/Assets/MyAssets/effect/activity/2602_shenchijiyuan/texture/'
			const frontTexture = Laya.loader.getRes(texturePath + (this.isFu ? 'maque_002_2.png' : 'maque_002_1.png'));
			if (frontTexture) frontTexture.mipmap = false;

			// 创建正面材质
			const frontMat = new caps.BaseMaterial(caps.Cartoon_Pai.filename);
			frontMat.setTexture(caps.Cartoon_Pai.TEXTURE, frontTexture);
			frontMat.setNumber(caps.Cartoon_Pai.SPLIT, 0.7);
			frontMat.setColor(caps.Cartoon_Pai.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
			frontMat.setColor(caps.Cartoon_Pai.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
			frontMat.setColor(caps.Cartoon_Pai.COLOR, new Laya.Vector3(1, 1, 1));
			frontMat.setColor(
				caps.Cartoon_Pai.TILING_OFFSET,
				this.getTilingOffset(tile)
			);
			frontMat.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
			frontMat.renderQueue = 2999;

			// 创建背面材质
			const backMat = new caps.BaseMaterial(caps.Cartoon_Tile_Back.filename);
			backMat.setTexture(caps.Cartoon_Tile_Back.TEXTURE1, Laya.loader.getRes(texturePath + 'maque_001.png'));
			backMat.setTexture(caps.Cartoon_Tile_Back.TEXTURE2, frontTexture);
			backMat.setColor(caps.Cartoon_Tile_Back.TILING_OFFSET, new Laya.Vector4(1, 1, 0, 0));
			backMat.setColor(
				caps.Cartoon_Tile_Back.TILING_OFFSET_1,
				new Laya.Vector4(0.1, 1, 0.9, 0)
			);
			backMat.setNumber(caps.Cartoon.SPLIT, 0.7);
			backMat.setColor(caps.Cartoon.COLOR_LIGHT, new Laya.Vector3(1, 1, 1));
			backMat.setColor(caps.Cartoon.COLOR_UNLIGHT, new Laya.Vector3(0.788, 0.788, 0.8235));
			backMat.setColor(caps.Cartoon.COLOR, new Laya.Vector3(1, 1, 1));
			backMat.setNumber(caps.Cartoon_Alpha.ALPHA, 1);
			backMat.renderQueue = 2999;

			// 设置材质
			this.mesh.meshRender.sharedMaterials = [backMat, frontMat];

			if (refreshRandom) {
				let random_angle: number = (Math.random() - 0.5) * 2 * 2;
				this.mjpNode.transform.localRotationEuler = new Laya.Vector3(0, 0, random_angle);
			}

			// 播放初始化动画
			this.playAnim(EPaiAnim.INIT);
		}

		public getTilingOffset(str: string): Laya.Vector4 {
			let tileIndex = +str.charAt(0);
			let tileType;
			switch (str.charAt(1)) {
				case 'z': tileType = 3; break;
				case 'm': tileType = 1; break;
				case 's': tileType = 2; break;
				case 'p': tileType = 0; break;
			}

			let index: number = 0;
			switch (tileType) {
				case 1: index = 0; break;
				case 0: index = 10; break;
				case 2: index = 20; break;
				default: index = 29; break;
			}
			index += tileIndex;
			let x: number = (6 + index % 7 * 104) / 1024;
			let y: number = (6 + Math.floor(index / 7) * 144) / 1024;
			return new Laya.Vector4(0.09765625, 0.14, x, y);
		}

		/**
		 * 播放动画
		 */
		public playAnim(anim: EPaiAnim, targetPos?: Laya.Vector3, onComplete?: Laya.Handler): void {
			Laya.timer.clearAll(this);
			this.animator.Stop();
			this.animator.Play(anim);
			this.rootNode.active = true;
			this.collectEffect1.active = (anim === EPaiAnim.KICK);
			this.collectEffect2.active = (anim === EPaiAnim.KICK);
			// 踢牌动画结束处理
			if (anim === EPaiAnim.KICK) {
				const startPos = this.owner.transform.localPosition.clone();
				const distance = Laya.Vector3.distance(startPos, targetPos);

				const totalDuration = MarathonPai.getKickDurationByDistance(distance);
				const rateDis = totalDuration / MarathonPai.KICK_STANDARD_DURATION_MIN;
				this.animator.SetSpeed(1 / rateDis);
				const y_values: number[] = [0, -0.0009016991, -0.001395941, -0.001401067, -0.0008348227, 0.0003845096, 0.002339005, 0.005110562, 0.008781135, 0.01343268, 0.01914716, 0.02600646, 0.03409266, 0.04348761, 0.05420989, 0.06581223, 0.07817161, 0.09126347, 0.1050634, 0.1195468, 0.134689, 0.1504657, 0.1668524, 0.1838242, 0.2013569, 0.2194259, 0.2380067, 0.2570746, 0.2766052, 0.296574, 0.3169564, 0.3377278, 0.3588639, 0.38034, 0.4021314, 0.424214, 0.4465629, 0.4691538, 0.491962, 0.514963, 0.5381324, 0.5614455, 0.5848778, 0.6084048, 0.6320021, 0.655645, 0.679309, 0.7029696, 0.7266022, 0.7501823, 0.7736855, 0.7970871, 0.8203626, 0.8434874, 0.8664373, 0.8891874, 0.9117132, 0.9339905, 0.9559944, 0.9777006];
				const targetFrameRate: number = 60;
				const subPos = new Laya.Vector3(targetPos.x - startPos.x, targetPos.y - startPos.y, targetPos.z - startPos.z);

				let startTime = Laya.timer.currTimer;
				Laya.timer.frameLoop(1, this, () => {
					let passTime = (Laya.timer.currTimer - startTime) / 1000;
					const rate = Math.min(passTime / totalDuration, 1);

					let currentFrame = Math.floor(rate * targetFrameRate);
					// 边界保护，防止越界
					if (currentFrame < 0) currentFrame = 0;
					if (currentFrame >= targetFrameRate) currentFrame = targetFrameRate - 1;

					const finalX = rate * subPos.x + startPos.x;
					const finalY = y_values[currentFrame] * subPos.y + startPos.y;
					const finalZ = rate * subPos.z + startPos.z;
					this.owner.transform.localPosition = new Laya.Vector3(finalX, finalY, finalZ);

					if (rate >= 1) {
						Laya.timer.clearAll(this);
						this.owner.active = false;
						onComplete?.run();
					}
				});
			} else {
				onComplete?.run();
			}
		}

		/**
		 * 重置麻将牌
		 */
		public reset(): void {
			this.owner.active = false;
			Laya.timer.clearAll(this);
			this.animator.Stop();
			this.rootNode.active = true;
			this.collectEffect1.active = false;
			this.collectEffect2.active = false;
			this.isFu = false;
		}

		destroy() {
			this.owner.removeSelf();
			this.owner.destroy();
		}

	}
}