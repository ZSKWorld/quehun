// ==DevDebug==
module uiscript {

	export enum MarathonTestMode {
		None,
		ProGamer,
		TimeOut,
		LieFlat,
	}
	export class UI_Activity_Marathon_Debug extends UIBase {
		public static Inst: UI_Activity_Marathon_Debug;

		public get meUI(): ui.lobby.activity_2602chunjie.activity_2602chunjie_DevDebugUI {
			return this.me as ui.lobby.activity_2602chunjie.activity_2602chunjie_DevDebugUI;
		}

		constructor() {
			super(new ui.lobby.activity_2602chunjie.activity_2602chunjie_DevDebugUI());
			UI_Activity_Marathon_Debug.Inst = this;
		}
		private logData: any[] = [];
		private roundCount: number = 0;
		private testMode: MarathonTestMode = MarathonTestMode.ProGamer;
		private testing: boolean = false;
		private nextOperate: {
			round: number;
			itemIndex: number;
			tileIndex: number;
		}
		private testInOrder: boolean = false;

		onCreate() {
			this.meUI.btn_test.clickHandler = new Laya.Handler(this, () => {
				this.close();
				this.roundCount = this.meUI.input_round.text ? parseInt(this.meUI.input_round.text) : 0;
				let mode = parseInt(this.meUI.input_mode.text);
				this.testMode = MarathonTestMode[mode] ? mode : MarathonTestMode.ProGamer;
				this.testInOrder = mode == 4;
				this.startTest();
				UI_Activity_Marathon_Game.Inst.me.offAll(Laya.Event.CLICK);
				Laya.timer.frameOnce(1, this, () => {
					UI_Activity_Marathon_Game.Inst.me.on(Laya.Event.CLICK, this, (e) => {
						if (this.testing) {
							this.clearListeners();
							this.refreshTestTip();
						}
					});
				});
			});
			this.meUI.root.visible = false;
			(this.meUI.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, this.close);
			(this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.meUI.root.visible) {
					this.meUI.root.visible = false;
				} else {
					this.meUI.root.visible = true;
				}
			});

			this.refreshTestTip();
			this.meUI.btn_log.clickHandler = new Laya.Handler(this, () => {
				this.exportToJson();
			});
		}

		private refreshTestTip() {
			this.meUI.testing.visible = this.testing;
		}


		// 关闭
		private close() {
			this.meUI.root.visible = false;
		}

		private clearListeners() {
			this.testing = false;
			MarathonData.Inst.off(EMarathonEvent.GAME_START, this, this.onGameStart);
			MarathonData.Inst.off(EMarathonEvent.ADD_HANDS, this, this.checkNextWall);
			MarathonData.Inst.off(EMarathonEvent.ENTER_FEVER_TIME, this, this.checkNextWall);
			MarathonData.Inst.off(EMarathonEvent.QUIT_FEVER_TIME, this, this.checkNextWall);
			MarathonData.Inst.off(EMarathonEvent.DO_OPERATION, this, this.doOperation);
			MarathonData.Inst.off(EMarathonEvent.GAME_END, this, this.onGameEnd);
			MarathonData.Inst.off(EMarathonEvent.GAME_ERROR, this, this.addError);
			Laya.timer.clearAll(this);
		}

		private startTest() {
			uiscript.UI_Activity_Marathon_Game.Inst.reset();
			MarathonData.Inst.reset();
			MarathonEffectMgr.Inst.reset();
			uiscript.UI_Activity_Marathon_Result.Inst.hide();
			this.roundCount--;
			this.testing = true;
			this.refreshTestTip();
			MarathonData.Inst.on(EMarathonEvent.GAME_START, this, this.onGameStart);
			MarathonData.Inst.on(EMarathonEvent.ADD_HANDS, this, this.checkNextWall);
			MarathonData.Inst.on(EMarathonEvent.ENTER_FEVER_TIME, this, this.checkNextWall);
			MarathonData.Inst.on(EMarathonEvent.QUIT_FEVER_TIME, this, this.checkNextWall);
			MarathonData.Inst.on(EMarathonEvent.DO_OPERATION, this, this.doOperation);
			MarathonData.Inst.on(EMarathonEvent.GAME_END, this, this.onGameEnd);
			MarathonData.Inst.on(EMarathonEvent.GAME_ERROR, this, this.addError);
			MarathonData.Inst.requestStartGame();
			Laya.timer.loop(10 * 60 * 60 * 1000, this, () => {
				if (!this.testing) return;
				GameMgr.Inst.randomUpdateMouse();
			})
		}

		onGameStart() {
			this.nextOperate = {
				round: 1,
				itemIndex: -1,
				tileIndex: 0,
			}
			this.checkNextWall();
		}

		onGameEnd() {
			if (this.roundCount > 0) {
				if (this.testInOrder) this.testMode = MarathonTestMode[this.testMode + 1] ? this.testMode + 1 : MarathonTestMode.ProGamer;
				Laya.timer.once(4000, this, this.startTest);
			} else {
				this.clearListeners();
				this.refreshTestTip();
			}
		}

		doOperation(operation: IMarathonOperation) {
			if (operation.item) {
				MarathonEffectMgr.Inst.moveCharacter(this.nextOperate.tileIndex, false);
			}
		}

		checkNextWall() {
			Laya.timer.once(100, this, () => {
				let wall = MarathonData.Inst.wallInfos[0];
				this.nextOperate.round = wall.round;
				this.nextOperate.itemIndex = -1;
				let walls = MarathonData.Inst.wallInfos.map(w => w.tiles);
				let tile;
				if (this.testMode == MarathonTestMode.ProGamer) {
					if (wall.items && wall.items.length > 0) {
						this.nextOperate.itemIndex = wall.items[0].y;
					}
					let robot = new MahjongRobot();
					tile = robot.findBestPick(
						MarathonData.Inst.hands,
						MarathonData.Inst.feverTiles,
						MarathonData.Inst.consumedFeverTiles,
						walls,
						wall.round
					);
				} else if (this.testMode == MarathonTestMode.TimeOut) {
					let robot = new MahjongTimeoutRobot();
					tile = robot.findBestPick(
						MarathonData.Inst.hands,
						MarathonData.Inst.feverTiles,
						walls
					);
				} else {
					let index = Math.floor(Math.random() * wall.tiles.length);
					tile = wall.tiles[index];
				}
				this.nextOperate.tileIndex = wall.tiles.indexOf(tile);
				let target = this.nextOperate.itemIndex >= 0 ? this.nextOperate.itemIndex : this.nextOperate.tileIndex;
				MarathonEffectMgr.Inst.moveCharacter(target, false);
			});
		}


		public requestTest(value?: number, tiles: string[] = []): void {
			let res: game.IResMarathonActivityStartRace = {
				error: null,
				race_id: '12345',
				random_seed: value || Math.ceil(Math.random() * 10000),
			};
			let simulation = new MarathonRaceSimulation(MarathonData.Inst.activityId, MarathonData.Inst.activityConfig.start_time, res.random_seed);
			while (simulation.hands.length <= MarathonConstant.MAX_HAND_TILES && simulation.remainTicks > 0) {
				simulation.updateWallData();
				const wall = simulation.walls[0];
				// const random = Math.floor(Math.random() * wall.wall.length);
				const random = 0;
				let tile = tiles[wall.round - 1] != null ? tiles[wall.round - 1] : wall.wall[random];
				let collect = simulation.collect(tile, wall.items.map(i => i.type));
				if (!collect) break;
			}
			const param: game.IReqMarathonActivityTest = {
				activity_id: MarathonData.Inst.activityId,
				wall_tests: simulation.wall_tests,
			};
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.marathonActivityTest, param, (err, res: game.IResMarathonActivityTest) => {
				if (err || res['error']) {
					UIMgr.Inst.showNetReqError(game.ERequest.marathonActivityTest, err, res);
					if (res && res.error && res.error.json_param) {
						app.Log.Error(`${game.ERequest.marathonActivityFinishRace} res ==== ${res.error.json_param}`);
					}
				} else {
					app.Log.log(`${game.ERequest.marathonActivityTest} res ==== ${JSON.stringify(res)}`);
				}
			});
		}

		addError(error: string = 'unknown error') {
			if (error) this.logData.push(JSON.parse(error));
			Laya.timer.clearAll(this);
			this.onGameEnd();
		}


		/** 导出并下载 log.json */
		public exportToJson() {
			if (this.logData.length === 0) {
				UIMgr.Inst.ShowErrorInfo('本次登录后的测试没有产生错误，无法导出日志');
				return;
			}

			const content = JSON.stringify(this.logData, null, 4);
			const blob = new Blob([content], { type: "application/json" });
			const url = URL.createObjectURL(blob);

			// 创建一个隐藏的下载链接
			const a = document.createElement("a");
			a.href = url;
			a.download = `marathon_error_${Date.now()}.json`;
			a.click();

			// 释放内存
			URL.revokeObjectURL(url);
		}

	}


	type Mahjong = string;

	interface EliminationResult {
		score: number;
		remainingHand: Mahjong[];
		eliminatedCount: number;
		luckyEliminatedCount: number; // 这个值在当前模式下越低越好
	}

	class MahjongTimeoutRobot {
		private readonly MAX_HAND = 7;

		/**
		 * @param hand 当前手牌
		 * @param luckyCards 当前福牌（需要躲避的牌）
		 * @param walls 牌墙数组 [wall1, wall2, wall3]
		 */
		public findBestPick(
			hand: Mahjong[],
			luckyCards: Mahjong[],
			walls: Array<Mahjong[]>
		): string {
			const luckySet = new Set(luckyCards);
			let maxScore = -Infinity;
			let bestSelection = walls[0][0];

			for (const card of walls[0]) {
				const res = this.simulatePick(hand, card, luckySet);
				// 死关判定
				if (res.remainingHand.length > this.MAX_HAND) continue;

				// --- 厌恶逻辑权重计算 ---
				let currentStepValue = 0;

				// 1. 绝对惩罚：如果捡了福牌，扣巨分
				if (luckySet.has(card)) {
					currentStepValue -= 100000;
				}

				// 2. 绝对惩罚：如果消掉了福牌（加时了），扣巨分
				if (res.luckyEliminatedCount > 0) {
					currentStepValue -= 500000;
				}

				// 3. 生存奖励：普通消除（不含福牌）是好事，能腾空间
				const pureElimination = res.eliminatedCount - res.luckyEliminatedCount;
				currentStepValue += pureElimination * 10000;

				// 4. 空间奖励：手牌越少，越不容易因为“被迫捡福牌”而自杀
				currentStepValue += (this.MAX_HAND - res.remainingHand.length) * 5000;

				// 递归搜索未来：确保后两步也不会被迫碰到福牌
				const futureValue = this.calculateFutureValue(
					res.remainingHand,
					luckySet,
					walls.slice(1),
					1
				);

				const totalPathValue = currentStepValue + futureValue;

				if (totalPathValue > maxScore) {
					maxScore = totalPathValue;
					bestSelection = card;
				}
			}

			return bestSelection;
		}

		private calculateFutureValue(
			hand: Mahjong[],
			luckySet: Set<string>,
			remainingWalls: Array<Mahjong[]>,
			depth: number
		): number {
			if (remainingWalls.length === 0) return 0;

			let bestFutureScore = -Infinity;
			let canSurvive = false;

			for (const card of remainingWalls[0]) {
				const res = this.simulatePick(hand, card, luckySet);
				if (res.remainingHand.length > this.MAX_HAND) continue;
				canSurvive = true;

				// 逻辑与上面一致：避开福牌，追求普通消除
				let stepValue = 0;
				if (luckySet.has(card)) stepValue -= 100000;
				if (res.luckyEliminatedCount > 0) stepValue -= 500000;
				stepValue += (res.eliminatedCount - res.luckyEliminatedCount) * 10000;
				stepValue += (this.MAX_HAND - res.remainingHand.length) * 5000;

				const nextVal = this.calculateFutureValue(
					res.remainingHand,
					luckySet,
					remainingWalls.slice(1),
					depth + 1
				);

				// 衰减系数，越远的未来权重越低
				const total = stepValue + nextVal * 0.8;
				if (total > bestFutureScore) bestFutureScore = total;
			}

			// 依然要保证不死，因为我们要的是“超时结束”而不是“死关结束”
			return canSurvive ? bestFutureScore : -2000000;
		}

		// --- 消除引擎 (完全不改变规则，只改变数据统计) ---

		private simulatePick(hand: Mahjong[], newCard: Mahjong, luckySet: Set<string>): EliminationResult {
			let currentHand = [...hand, newCard];
			let luckyEliminatedCount = 0;
			const startLen = currentHand.length;

			let found = true;
			while (found) {
				found = false;
				// 碰
				const pung = this.getPung(currentHand, luckySet);
				if (pung) {
					currentHand = pung.remainingHand;
					if (pung.isLucky) luckyEliminatedCount += 3;
					found = true;
					continue;
				}
				// 吃
				const chow = this.getChow(currentHand, luckySet);
				if (chow) {
					currentHand = chow.remainingHand;
					luckyEliminatedCount += chow.luckyCount;
					found = true;
					continue;
				}
			}

			return {
				score: 0, // 模式2不计分
				remainingHand: currentHand,
				eliminatedCount: startLen - currentHand.length,
				luckyEliminatedCount
			};
		}

		private getPung(hand: Mahjong[], luckySet: Set<string>) {
			const counts: Record<string, number> = {};
			for (const c of hand) counts[c] = (counts[c] || 0) + 1;
			for (const card in counts) {
				if (counts[card] >= 3) {
					const isLucky = luckySet.has(card);
					const remainingHand = [];
					let removed = 0;
					for (const c of hand) {
						if (c === card && removed < 3) removed++;
						else remainingHand.push(c);
					}
					return { remainingHand, isLucky, card };
				}
			}
			return null;
		}

		private getChow(hand: Mahjong[], luckySet: Set<string>) {
			const suits = ['p', 's', 'm'];
			for (const suit of suits) {
				const suitCards = hand.filter(c => c.endsWith(suit));
				if (suitCards.length < 3) continue;
				const nums = Array.from(new Set(suitCards.map(c => parseInt(c[0])))).sort((a, b) => a - b);
				for (let len = 5; len >= 3; len--) {
					for (let i = 0; i <= nums.length - len; i++) {
						const sub = nums.slice(i, i + len);
						let isSeq = true;
						for (let j = 0; j < len - 1; j++) if (sub[j + 1] !== sub[j] + 1) { isSeq = false; break; }
						if (isSeq) {
							let luckyCount = 0;
							const remainingHand = [...hand];
							for (const n of sub) {
								const c = `${n}${suit}`;
								if (luckySet.has(c)) luckyCount++;
								remainingHand.splice(remainingHand.indexOf(c), 1);
							}
							return { remainingHand, luckyCount };
						}
					}
				}
			}
			return null;
		}
	}


	interface EliminationResult {
		score: number;
		remainingHand: Mahjong[];
		eliminatedCount: number;
		luckyEliminatedCount: number;
		eliminatedTypes: Set<string>;
	}

	class MahjongRobot {
		private readonly MAX_HAND = 7;

		public findBestPick(
			hand: Mahjong[],
			luckyCards: Mahjong[],
			clearedLuckyTypes: Mahjong[],
			walls: Array<Mahjong[]>,
			wallIndex: number
		): string {
			const luckySet = new Set(luckyCards);
			// 判断是否进入“枯竭期” (200面墙之后)
			const isDryPhase = wallIndex > 200;

			let maxScore = -Infinity;
			let bestSelection = walls[0][0];

			for (const card of walls[0]) {
				const res = this.simulatePick(hand, card, luckySet);
				if (res.remainingHand.length > this.MAX_HAND) continue;

				const newClears = [...res.eliminatedTypes].filter(t => !clearedLuckyTypes.includes(t));
				const isCycleReset = (clearedLuckyTypes.length + newClears.length) >= 3;

				// --- 阶段性权重计算 ---
				let currentStepValue = 0;

				if (!isDryPhase) {
					// 【红利期逻辑】: 狂热收集福牌，追求刷新
					currentStepValue += res.luckyEliminatedCount * 100000;
					if (isCycleReset) currentStepValue += 500000;
					currentStepValue += (res.eliminatedCount - res.luckyEliminatedCount) * 10000;
					if (luckySet.has(card)) currentStepValue += 50000; // 极高意愿捡福牌
					currentStepValue += (this.MAX_HAND - res.remainingHand.length) * 5000;
				} else {
					// 【枯竭期逻辑】: 福牌不再刷新，生存和腾挪第一
					// 如果能消掉福牌依然给分，但不再为了捡福牌而占位置
					currentStepValue += res.luckyEliminatedCount * 50000;
					currentStepValue += res.eliminatedCount * 20000; // 提高普通消除权重
					currentStepValue += (this.MAX_HAND - res.remainingHand.length) * 15000; // 空间奖金翻倍

					// 惩罚: 如果手里还攥着目前无法消除的单张福牌，扣分防止卡关
					const unreachableLuckyCount = res.remainingHand.filter(c => luckySet.has(c)).length;
					currentStepValue -= unreachableLuckyCount * 5000;
				}

				// 递归预测未来
				const futureValue = this.calculateFutureValue(
					res.remainingHand,
					luckySet,
					isCycleReset ? [] : [...clearedLuckyTypes, ...newClears],
					walls.slice(1),
					1,
					isDryPhase
				);

				const totalPathValue = currentStepValue + futureValue;

				if (totalPathValue > maxScore) {
					maxScore = totalPathValue;
					bestSelection = card;
				}
			}

			return bestSelection;
		}

		private calculateFutureValue(
			hand: Mahjong[],
			luckySet: Set<string>,
			alreadyCleared: Mahjong[],
			remainingWalls: Array<Mahjong[]>,
			depth: number,
			isDryPhase: boolean
		): number {
			if (remainingWalls.length === 0) return 0;

			let bestFutureScore = -Infinity;
			let canSurvive = false;

			for (const card of remainingWalls[0]) {
				const res = this.simulatePick(hand, card, luckySet);
				if (res.remainingHand.length > this.MAX_HAND) continue;
				canSurvive = true;

				const newClears = [...res.eliminatedTypes].filter(t => !alreadyCleared.includes(t));
				const isCycleReset = (alreadyCleared.length + newClears.length) >= 3;

				let stepValue = 0;
				if (!isDryPhase) {
					stepValue = (res.luckyEliminatedCount * 100000) +
						(isCycleReset ? 500000 : 0) +
						(res.eliminatedCount * 10000) +
						(luckySet.has(card) ? 50000 : 0);
				} else {
					// 枯竭期未来评估：侧重于消除一切东西
					stepValue = (res.luckyEliminatedCount * 50000) +
						(res.eliminatedCount * 30000) +
						((this.MAX_HAND - res.remainingHand.length) * 10000);
				}

				const nextVal = this.calculateFutureValue(
					res.remainingHand,
					luckySet,
					isCycleReset ? [] : [...alreadyCleared, ...newClears],
					remainingWalls.slice(1),
					depth + 1,
					isDryPhase
				);

				const total = stepValue + nextVal;
				if (total > bestFutureScore) bestFutureScore = total;
			}

			// 哪怕生存期也要严防死关。枯竭期死关惩罚力度更大。
			return canSurvive ? bestFutureScore : (isDryPhase ? -2000000 : -1000000);
		}

		// --- 模拟消除引擎 (保持之前版本的高效率逻辑) ---

		private simulatePick(hand: Mahjong[], newCard: Mahjong, luckySet: Set<string>): EliminationResult {
			let currentHand = [...hand, newCard];
			let totalScore = 0;
			let luckyEliminatedCount = 0;
			let eliminatedTypes = new Set<string>();
			const startLen = currentHand.length;

			let found = true;
			while (found) {
				found = false;
				// 1. 尝试碰
				const pung = this.getPung(currentHand, luckySet);
				if (pung) {
					totalScore += pung.score;
					currentHand = pung.remainingHand;
					if (pung.isLucky) {
						luckyEliminatedCount += 3;
						eliminatedTypes.add(pung.card);
					}
					found = true;
					continue;
				}
				// 2. 尝试吃
				const chow = this.getChow(currentHand, luckySet);
				if (chow) {
					totalScore += chow.score;
					currentHand = chow.remainingHand;
					luckyEliminatedCount += chow.luckyCount;
					chow.luckyTypes.forEach(t => eliminatedTypes.add(t));
					found = true;
					continue;
				}
			}

			return {
				score: totalScore,
				remainingHand: currentHand,
				eliminatedCount: startLen - currentHand.length,
				luckyEliminatedCount,
				eliminatedTypes
			};
		}

		private getPung(hand: Mahjong[], luckySet: Set<string>) {
			const counts: Record<string, number> = {};
			for (const c of hand) counts[c] = (counts[c] || 0) + 1;
			for (const card in counts) {
				if (counts[card] >= 3) {
					const isLucky = luckySet.has(card);
					const remainingHand = [];
					let removed = 0;
					for (const c of hand) {
						if (c === card && removed < 3) removed++;
						else remainingHand.push(c);
					}
					return { score: 450 + (isLucky ? 600 : 0), remainingHand, isLucky, card };
				}
			}
			return null;
		}

		private getChow(hand: Mahjong[], luckySet: Set<string>) {
			const suits = ['p', 's', 'm'];
			for (const suit of suits) {
				const suitCards = hand.filter(c => c.endsWith(suit));
				if (suitCards.length < 3) continue;
				const nums = Array.from(new Set(suitCards.map(c => parseInt(c[0])))).sort((a, b) => a - b);
				for (let len = 5; len >= 3; len--) {
					for (let i = 0; i <= nums.length - len; i++) {
						const sub = nums.slice(i, i + len);
						let isSeq = true;
						for (let j = 0; j < len - 1; j++) if (sub[j + 1] !== sub[j] + 1) { isSeq = false; break; }
						if (isSeq) {
							let luckyCount = 0;
							let luckyTypes = new Set<string>();
							const remainingHand = [...hand];
							for (const n of sub) {
								const c = `${n}${suit}`;
								if (luckySet.has(c)) { luckyCount++; luckyTypes.add(c); }
								remainingHand.splice(remainingHand.indexOf(c), 1);
							}
							return { score: len * 100 + luckyCount * 200, remainingHand, luckyCount, luckyTypes };
						}
					}
				}
			}
			return null;
		}
	}

	// type Mahjong = string;

	// interface EliminationResult {
	// 	score: number;
	// 	remainingHand: Mahjong[];
	// 	eliminatedCount: number;
	// 	luckyEliminatedCount: number; // 本次消除了几张福牌
	// 	eliminatedTypes: Set<string>;
	// }

	// class MahjongRobot {
	// 	private readonly MAX_HAND = 7;

	// 	public findBestPick(
	// 		hand: Mahjong[],
	// 		luckyCards: Mahjong[],
	// 		clearedLuckyTypes: Mahjong[],
	// 		walls: Array<Mahjong[]>,
	// 		wallIndex: number
	// 	): string {
	// 		const luckySet = new Set(luckyCards);
	// 		let maxScore = -Infinity;
	// 		let bestSelection = walls[0][0];

	// 		for (const card of walls[0]) {
	// 			const res = this.simulatePick(hand, card, luckySet);
	// 			// 死关判定
	// 			if (res.remainingHand.length > this.MAX_HAND) continue;

	// 			// 1. 计算第一步的“福牌价值”
	// 			const newClears = [...res.eliminatedTypes].filter(t => !clearedLuckyTypes.includes(t));
	// 			const isCycleReset = (clearedLuckyTypes.length + newClears.length) >= 3;

	// 			// --- 动态权重分配 ---
	// 			let currentStepValue = 0;

	// 			// A. 消除福牌：每张福牌消除给 100,000 分 (极高优先级)
	// 			currentStepValue += res.luckyEliminatedCount * 100000;

	// 			// B. 刷新奖励：触发刷新给 500,000 分 (至高无上)
	// 			if (isCycleReset) currentStepValue += 500000;

	// 			// C. 普通消除：每张给 10000 分 (基础生存)
	// 			currentStepValue += (res.eliminatedCount - res.luckyEliminatedCount) * 10000;

	// 			// D. 捡到福牌（哪怕没消）：给 50000 分 (确保不漏掉福牌)
	// 			if (luckySet.has(card)) currentStepValue += 50000;

	// 			// E. 空间奖金：保持手牌在 3-4 张时最舒服
	// 			currentStepValue += (this.MAX_HAND - res.remainingHand.length) * 5000;

	// 			// 2. 递归搜索未来 (深度视 walls.length 而定)
	// 			const futureValue = this.calculateFutureValue(
	// 				res.remainingHand,
	// 				luckySet,
	// 				isCycleReset ? [] : [...clearedLuckyTypes, ...newClears],
	// 				walls.slice(1),
	// 				1
	// 			);

	// 			const totalPathValue = currentStepValue + futureValue;

	// 			if (totalPathValue > maxScore) {
	// 				maxScore = totalPathValue;
	// 				bestSelection = card;
	// 			}
	// 		}

	// 		return bestSelection;
	// 	}

	// 	private calculateFutureValue(
	// 		hand: Mahjong[],
	// 		luckySet: Set<string>,
	// 		alreadyCleared: Mahjong[],
	// 		remainingWalls: Array<Mahjong[]>,
	// 		depth: number
	// 	): number {
	// 		if (remainingWalls.length === 0) return 0;

	// 		let bestFutureScore = -Infinity;
	// 		const currentWall = remainingWalls[0];
	// 		let canSurvive = false;

	// 		for (const card of currentWall) {
	// 			const res = this.simulatePick(hand, card, luckySet);
	// 			if (res.remainingHand.length > this.MAX_HAND) continue;
	// 			canSurvive = true;

	// 			const newClears = [...res.eliminatedTypes].filter(t => !alreadyCleared.includes(t));
	// 			const isCycleReset = (alreadyCleared.length + newClears.length) >= 3;

	// 			// 未来收益计算 (逻辑同上)
	// 			let stepValue = (res.luckyEliminatedCount * 100000) +
	// 				(isCycleReset ? 500000 : 0) +
	// 				(res.eliminatedCount * 10000) +
	// 				(luckySet.has(card) ? 50000 : 0);

	// 			// 递归
	// 			const nextVal = this.calculateFutureValue(
	// 				res.remainingHand,
	// 				luckySet,
	// 				isCycleReset ? [] : [...alreadyCleared, ...newClears],
	// 				remainingWalls.slice(1),
	// 				depth + 1
	// 			);

	// 			const total = stepValue + nextVal;
	// 			if (total > bestFutureScore) bestFutureScore = total;
	// 		}

	// 		return canSurvive ? bestFutureScore : -1000000; // 必死则扣巨分
	// 	}

	// 	// --- 模拟消除引擎 (针对福牌优化) ---

	// 	private simulatePick(hand: Mahjong[], newCard: Mahjong, luckySet: Set<string>): EliminationResult {
	// 		let currentHand = [...hand, newCard];
	// 		let totalScore = 0;
	// 		let luckyEliminatedCount = 0;
	// 		let eliminatedTypes = new Set<string>();
	// 		const startLen = currentHand.length;

	// 		let found = true;
	// 		while (found) {
	// 			found = false;
	// 			// 碰和吃的逻辑中，需要统计福牌数量
	// 			// 1. 碰
	// 			const pung = this.getPung(currentHand, luckySet);
	// 			if (pung) {
	// 				totalScore += pung.score;
	// 				currentHand = pung.remainingHand;
	// 				if (pung.isLucky) {
	// 					luckyEliminatedCount += 3;
	// 					eliminatedTypes.add(pung.card);
	// 				}
	// 				found = true;
	// 				continue;
	// 			}
	// 			// 2. 吃
	// 			const chow = this.getChow(currentHand, luckySet);
	// 			if (chow) {
	// 				totalScore += chow.score;
	// 				currentHand = chow.remainingHand;
	// 				luckyEliminatedCount += chow.luckyCount;
	// 				chow.luckyTypes.forEach(t => eliminatedTypes.add(t));
	// 				found = true;
	// 				continue;
	// 			}
	// 		}

	// 		return {
	// 			score: totalScore,
	// 			remainingHand: currentHand,
	// 			eliminatedCount: startLen - currentHand.length,
	// 			luckyEliminatedCount,
	// 			eliminatedTypes
	// 		};
	// 	}

	// 	private getPung(hand: Mahjong[], luckySet: Set<string>) {
	// 		const counts: Record<string, number> = {};
	// 		for (const c of hand) counts[c] = (counts[c] || 0) + 1;
	// 		for (const card in counts) {
	// 			if (counts[card] >= 3) {
	// 				const isLucky = luckySet.has(card);
	// 				const remainingHand = [];
	// 				let removed = 0;
	// 				for (const c of hand) {
	// 					if (c === card && removed < 3) removed++;
	// 					else remainingHand.push(c);
	// 				}
	// 				return { score: 450 + (isLucky ? 600 : 0), remainingHand, isLucky, card };
	// 			}
	// 		}
	// 		return null;
	// 	}

	// 	private getChow(hand: Mahjong[], luckySet: Set<string>) {
	// 		const suits = ['p', 's', 'm'];
	// 		for (const suit of suits) {
	// 			const suitCards = hand.filter(c => c.endsWith(suit));
	// 			if (suitCards.length < 3) continue;
	// 			const nums = Array.from(new Set(suitCards.map(c => parseInt(c[0])))).sort((a, b) => a - b);
	// 			for (let len = 5; len >= 3; len--) {
	// 				for (let i = 0; i <= nums.length - len; i++) {
	// 					const sub = nums.slice(i, i + len);
	// 					let isSeq = true;
	// 					for (let j = 0; j < len - 1; j++) if (sub[j + 1] !== sub[j] + 1) { isSeq = false; break; }
	// 					if (isSeq) {
	// 						let luckyCount = 0;
	// 						let luckyTypes = new Set<string>();
	// 						const remainingHand = [...hand];
	// 						for (const n of sub) {
	// 							const c = `${n}${suit}`;
	// 							if (luckySet.has(c)) { luckyCount++; luckyTypes.add(c); }
	// 							remainingHand.splice(remainingHand.indexOf(c), 1);
	// 						}
	// 						return { score: len * 100 + luckyCount * 200, remainingHand, luckyCount, luckyTypes };
	// 					}
	// 				}
	// 			}
	// 		}
	// 		return null;
	// 	}
	// }

}