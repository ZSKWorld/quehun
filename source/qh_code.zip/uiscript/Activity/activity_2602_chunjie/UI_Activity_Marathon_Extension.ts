module uiscript {
    export class UI_Marathon_FuTile {
        private me: Laya.Sprite;
        private tile: UI_Marathon_MJP;
        private complete: Laya.Sprite;
        private imgComplete1: Laya.Image;
        private imgComplete2: Laya.Image;
        private aniComplete: Laya.FrameAnimation;
        constructor(me: Laya.Sprite, aniComplete: Laya.FrameAnimation) {
            this.me = me;
            this.aniComplete = aniComplete;
            this.tile = new UI_Marathon_MJP(this.me.getChildByName('tile') as Laya.Sprite);
            this.complete = this.me.getChildByName('complete') as Laya.Sprite;
            this.imgComplete1 = this.complete.getChildByName('bg') as Laya.Image;
            this.imgComplete2 = this.complete.getChildByName('fg') as Laya.Image;
        }

        refresh(tile: string, isComplete: boolean = false) {
            this.tile.refresh(tile, true);
            const doAnim = isComplete && !this.complete.visible;
            this.complete.visible = isComplete;
            if (doAnim) {
                this.aniComplete.play(0, false);
            }
        }

        reset() {
            this.tile.reset();
            this.complete.visible = false;
            this.aniComplete.stop();
        }
    }

    export class UI_Marathon_MJP {
        private me: Laya.Sprite;
        private imgFront: Laya.Image;
        private imgBei: Laya.Image;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.imgFront = this.me.getChildByName('font') as Laya.Image;
            this.imgBei = this.me.getChildByName('bei') as Laya.Image;
        }

        refresh(pai: string, isFever: boolean = false, doAnim: boolean = false) {
            this.me.visible = true;
            this.imgFront.skin = pai != '5z' ? game.Tools.localUISrc(`myres/activity_2602chunjie/tiles/${pai}.png`) : '';
            this.refreshFeverTile(isFever);
        }

        refreshFeverTile(isFever: boolean) {
            this.imgBei.skin = isFever ? game.Tools.localUISrc('myres/activity_2602chunjie/tiles/bg_fu.png') : game.Tools.localUISrc('myres/activity_2602chunjie/tiles/bg.png');
        }

        reset() {
            this.me.visible = false;
        }
    }

    export class UI_Marathon_HandTile {
        public me: Laya.Sprite;
        private tile: UI_Marathon_MJP;
        public value: string = '';
        private isTemp: boolean = false;
        private imgRed: Laya.Image;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.tile = new UI_Marathon_MJP(this.me);
            this.imgRed = this.me.getChildByName('red') as Laya.Image;
        }

        refresh(pai: string, isFever: boolean = false, doAnim: boolean = false, isTemp: boolean = false, delay: number = 0) {
            this.value = pai;
            this.isTemp = isTemp;
            this.me.visible = true;
            this.tile.refresh(pai, isFever);
            Laya.Tween.clearAll(this.me);
            if (doAnim) {
                this.me.alpha = 0;
                Laya.timer.once(delay, this, () => {
                    this.me.alpha = 1;
                })
            }
        }

        refreshFeverTile(isFever: boolean) {
            if (!this.isTemp) {
                this.tile.refreshFeverTile(isFever);
            }
        }

        refreshRedTip(show: boolean) {
            this.imgRed.visible = show;
        }

        hide(doAnim: boolean = false) {
            if (doAnim) {
                Laya.Tween.clearAll(this.me);
                UIBase.anim_pop_hide(this.me, Laya.Handler.create(this, () => {
                    this.tile.reset();
                }));
            } else {
                this.tile.reset();
            }
        }

        reset() {
            this.imgRed.visible = false;
            Laya.timer.clearAll(this);
            this.isTemp = false;
            this.value = '';
            this.me.alpha = 1;
            this.me.visible = false;
            this.tile.reset();
        }
    }

    export enum EMarathonVoiveType {
        greeting = 'greeting',
        click = 'click',
        finish_work = 'finish_work',
        upgrade = 'upgrade',
    }


    export class UI_Marathon_Chara extends UIBase {
        private imgSkin: Laya.Image;
        private comChat: ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI;
        private txtName: Laya.Label;
        private charaId: number;
        private comChara: Laya.Sprite;

        private charaInfo: any;
        private chat: UI_Character_Chat = null;

        private chatId: number = 0;
        private soundId: number = null;
        private aniChatShow: Laya.FrameAnimation;
        private aniChatHide: Laya.FrameAnimation;
        private imgUrl: string = '';
        private imgTag: string = '';
        private voiceGroup: basic.Dictionary<number, basic.Dictionary<string, lqc.Sheet_Voice_Event>>;

        constructor(me: Laya.Sprite, imgUrl?: string, imgTag?: string) {
            super(me);
            this.imgUrl = imgUrl;
            this.imgTag = imgTag;
        }

        public onCreate(): void {
            // 角色 
            this.comChara = this.me.getChildByName('illust') as Laya.Sprite;
            this.imgSkin = this.comChara.getChildByName('illust') as Laya.Image;
            this.comChat = this.me.getChildByName('chat') as ui.lobby.activity_2602chunjie.activity_2602chunjie_chatUI;
            this.aniChatShow = this.comChat.show as Laya.FrameAnimation;
            this.aniChatHide = this.comChat.hide as Laya.FrameAnimation;
            this.chat = new UI_Character_Chat(this.comChat.getChildByName('chat') as Laya.Sprite, false, 0);
            this.txtName = this.comChat.getChildByName('chat').getChildByName('name') as Laya.Label;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.soundId) {
                    this.stopsay();
                } else {
                    this.say(EMarathonVoiveType.click);
                }
            }, null, false);
            let voices = cfg.voice.event.getGroup(4);
            this.voiceGroup = new basic.Dictionary<number, basic.Dictionary<string, lqc.Sheet_Voice_Event>>();
            voices.forEach(voice => {
                if (!this.voiceGroup.get(voice.stage)) {
                    this.voiceGroup.set(voice.stage, new basic.Dictionary<string, lqc.Sheet_Voice_Event>());
                }
                let voiceType = this.voiceGroup.get(voice.stage);
                voiceType.set(voice.type, voice);
                this.voiceGroup.set(voice.stage, voiceType);
            });
            game.LoadMgr.setImgSkin(this.imgSkin, this.imgUrl + 200001 + '.png', null, this.imgTag);
        }

        public say(type: EMarathonVoiveType) {
            this.chatId++;
            let chatId = this.chatId;
            let grade = UI_Marathon_Train.nowGrade;
            if (type == EMarathonVoiveType.upgrade) {
                grade = grade - 1;
            }
            let groups = this.voiceGroup.get(grade);
            let audioType: string = type;
            if (type == EMarathonVoiveType.click) {
                audioType += '_' + (Math.random() > 0.5 ? '1' : '2');
            }
            const data = groups ? groups.get(audioType) : null;
            if (!data) return;
            const volume = view.AudioMgr.yuyinVolume * data.volume_fix;
            this.soundId = view.AudioMgr.PlaySound(data.path, volume, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    if (this.chatId == chatId) {
                        this.stopsay();
                    }
                });
            }), 0, view.EAudioType.sound);
            if (this.soundId) {
                this.chat.show(data['words_' + GameMgr.client_language]);
                if (this.aniChatShow) {
                    this.clearTween();
                    this.aniChatShow.play(0, false);
                }
            }
        }

        public stopsay() {
            Laya.timer.clearAll(this);
            this.chat.close(false);
            if (this.aniChatHide) {
                this.clearTween();
                this.aniChatHide.play(0, false);
            }
            if (this.soundId) {
                view.AudioMgr.StopAudio(this.soundId);
                this.soundId = null;
            }
        }

        public showCharacter(id: number) {
            this.enable = true;
            this.charaId = id;
            this.charaInfo = null;
            for (let info of UI_Sushe.characters) {
                if (info.charid == this.charaId) {
                    this.charaInfo = info;
                    break;
                }
            }
            if (!this.charaInfo) {
                this.charaInfo = { charid: this.charaId, level: 0, is_upgraded: false };
            }
            this.chat.close(true);
        }

        public hideCharacter() {
            this.enable = false;
            this.stopsay();
        }

        public clearTween() {
            Laya.Tween.clearAll(this.chat.me);
            this.aniChatHide?.stop();
            this.aniChatShow?.stop();
        }
    }

}