module uiscript {

    export class UI_Activity_Marathon_Game extends UIBase {
        public static Inst: UI_Activity_Marathon_Game = null;
        public static bgmMuted: boolean = false;
        private comBg: Laya.Sprite;
        private comFrontBg: Laya.Sprite;
        private comScene: Laya.Sprite;
        private imgBg: Laya.Sprite;

        private comTop: Laya.Sprite;
        private btnPause: Laya.Button;
        private btnMute: Laya.Button;
        private comCarrot: Laya.Sprite;
        private txtCarrotCount: Laya.Label;
        private comAddCarrot: Laya.Sprite;
        private imgAddCarrot: Laya.Image;
        private txtAddCarrot: Laya.Label;
        private comTime: Laya.Sprite;
        private txtTime: Laya.Label;
        private imgTimeGlow: Laya.Image;
        private comAddTime: Laya.Sprite;
        private imgAddTime: Laya.Image;
        private txtAddTime: Laya.Label;
        private tipFeverTime: Laya.Sprite;
        private comDistance: Laya.Sprite;
        private txtDistance: Laya.Label;

        private comBtns: Laya.Sprite;
        private btnUp: Laya.Button;
        private btnDown: Laya.Button;

        private comBottom: Laya.Sprite;
        private comFeverTiles: Laya.Sprite;
        private feverTiles: UI_Marathon_FuTile[];
        private comOperation: Laya.Sprite;
        private comOperateTiles: Laya.Sprite;
        private operateTiles: UI_Marathon_MJP[];
        private imgOperateBg: Laya.Image;
        private imgOperate: Laya.Image;
        private txtOperateTime: Laya.Label;
        private txtOperateCarrot: Laya.Label;
        private comHands: Laya.Sprite;
        private hands: UI_Marathon_HandTile[];

        private comPopup: Laya.Sprite;
        private comPopupBg: Laya.Sprite;
        private comPause: Laya.Sprite;
        private comEnd: Laya.Sprite;

        private btnGiveUp: Laya.Button;
        private btnContinue: Laya.Button;
        private btnRestart: Laya.Button;

        private comAddChara: Laya.Sprite;
        private imgAddChara: Laya.Image;
        private txtAddChara: Laya.Label;

        private aniShow: Laya.FrameAnimation;
        private aniOperation: Laya.FrameAnimation;
        private aniTimeGlow: Laya.FrameAnimation;
        private aniShowPause: Laya.FrameAnimation;
        private aniHidePause: Laya.FrameAnimation;
        private aniShowEnd: Laya.FrameAnimation;
        private aniIdleEnd: Laya.FrameAnimation;
        private aniFailed: Laya.FrameAnimation;
        private aniHandLimit: Laya.FrameAnimation;
        private aniShowFeverTile: Laya.FrameAnimation;
        private effectOperation: game.UIEffect;
        private effectPaiStar: game.UIEffect;

        private locking: boolean;
        private activityFinishHandler: Laya.Handler;
        private isBackGround: boolean = false;
        private audioId: number = 0;
        private audioFeverId: number = 0;

        constructor() {
            super(new ui.lobby.activity_2602chunjie.activity_2602chunjie_gameUI);
            UI_Activity_Marathon_Game.Inst = this;
        }

        public onCreate(): void {
            this.comBg = this.me.getChildByName('bg') as Laya.Sprite;
            this.comFrontBg = this.me.getChildByName('front_scene') as Laya.Sprite;
            this.comScene = this.comBg.getChildByName('scene') as Laya.Sprite;
            this.comTop = this.me.getChildByName('top') as Laya.Sprite;
            this.comBtns = this.me.getChildByName('btns') as Laya.Sprite;
            this.comBottom = this.me.getChildByName('bottom') as Laya.Sprite;
            this.comPopup = this.me.getChildByName('popup') as Laya.Sprite;

            this.btnPause = this.comTop.getChildByName('btn_pause') as Laya.Button;
            this.btnMute = this.comTop.getChildByName('btn_mute') as Laya.Button;
            this.comCarrot = this.comTop.getChildByName('carrot') as Laya.Sprite;
            this.txtCarrotCount = this.comCarrot.getChildByName('count') as Laya.Label;
            this.comAddCarrot = this.comCarrot.getChildByName('add') as Laya.Sprite;
            this.txtAddCarrot = this.comAddCarrot.getChildByName('value') as Laya.Label;
            this.imgAddCarrot = this.comAddCarrot.getChildByName('bg') as Laya.Image;

            this.comTime = this.comTop.getChildByName('time') as Laya.Sprite;
            this.txtTime = this.comTime.getChildByName('time') as Laya.Label;
            this.imgTimeGlow = this.comTime.getChildByName('glow') as Laya.Image;
            this.comAddTime = this.comTime.getChildByName('add') as Laya.Sprite;
            this.txtAddTime = this.comAddTime.getChildByName('value') as Laya.Label;
            this.imgAddTime = this.comAddTime.getChildByName('bg') as Laya.Image;
            this.tipFeverTime = this.comTime.getChildByName('fever_time') as Laya.Sprite;
            this.comDistance = this.comTop.getChildByName('distance') as Laya.Sprite;
            this.txtDistance = this.comDistance.getChildByName('distance') as Laya.Label;

            this.comPopupBg = this.comPopup.getChildByName('bg') as Laya.Sprite;
            this.comEnd = this.comPopup.getChildByName('end') as Laya.Sprite;
            this.comPause = this.comPopup.getChildByName('pause') as Laya.Sprite;

            this.comFeverTiles = this.comBottom.getChildByName('fu') as Laya.Sprite;
            const comTiles = this.comFeverTiles.getChildByName('tiles') as Laya.Sprite;
            const aniRoot = this.me as ui.lobby.activity_2602chunjie.activity_2602chunjie_gameUI;
            this.feverTiles = [];
            for (let i = 0; i < comTiles._childs.length; i++) {
                this.feverTiles.push(new UI_Marathon_FuTile(comTiles._childs[i] as Laya.Sprite, aniRoot['fu_complete_' + (i + 1)]));
            }
            this.comOperation = this.comBottom.getChildByName('operate') as Laya.Sprite;
            this.imgOperateBg = this.comOperation.getChildByName('bg') as Laya.Image;
            this.imgOperate = this.comOperation.getChildByName('operation') as Laya.Image;
            this.txtOperateTime = this.comOperation.getChildByName('time') as Laya.Label;
            this.txtOperateCarrot = this.comOperation.getChildByName('carrot') as Laya.Label;
            this.operateTiles = [];
            this.comOperateTiles = this.comOperation.getChildByName('tiles').getChildAt(0) as Laya.Sprite;
            for (let i = 0; i < this.comOperateTiles._childs.length; i++) {
                this.operateTiles.push(new UI_Marathon_MJP(this.comOperateTiles._childs[i] as Laya.Sprite));
            }
            this.hands = [];
            this.comHands = this.comBottom.getChildByName('hands') as Laya.Sprite;
            for (let i = 0; i <= MarathonConstant.MAX_HAND_TILES; i++) {
                this.hands.push(new UI_Marathon_HandTile(this.comHands._childs[i]));
            }

            this.btnGiveUp = this.comPause.getChildByName('btn_giveup') as Laya.Button;
            this.btnContinue = this.comPause.getChildByName('btn_continue') as Laya.Button;
            this.btnRestart = this.comPause.getChildByName('btn_restart') as Laya.Button;

            this.btnUp = this.comBtns.getChildByName('btn_up') as Laya.Button;
            this.btnDown = this.comBtns.getChildByName('btn_down') as Laya.Button;

            this.comAddChara = this.comBg.getChildByName('illust').getChildByName('illust').getChildByName('add') as Laya.Sprite;
            this.imgAddChara = this.comAddChara.getChildByName('bg') as Laya.Image;
            this.txtAddChara = this.comAddChara.getChildByName('value') as Laya.Label;

            this.btnUp.clickHandler = new Laya.Handler(this, this.moveCharacter, [1]);
            this.btnDown.clickHandler = new Laya.Handler(this, this.moveCharacter, [-1]);
            this.btnPause.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPause();
            });
            this.btnGiveUp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                MarathonData.Inst.pauseGame();
                this.hide(Laya.Handler.create(this, () => {
                    UI_Activity_Marathon_Main.Inst.show();
                }));
            });
            this.btnContinue.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hidePause(Laya.Handler.create(this, () => {
                    MarathonData.Inst.resumeGame();
                }));
            });
            this.btnRestart.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hidePause(Laya.Handler.create(this, () => {
                    this.requestStartGame();
                }));
            });
            this.comEnd.visible = false;
            this.comPause.visible = false;
            this.comPopupBg.visible = false;
            Laya.stage.on(laya.events.Event.KEY_DOWN, this, e => {
                if (this.locking) return;
                if (e['keyCode'] == Laya.Keyboard.ESCAPE) {
                    if (this.comPause.visible) {
                        this.hidePause(Laya.Handler.create(this, () => {
                            MarathonData.Inst.resumeGame();
                        }));
                    } else {
                        this.showPause();
                    }
                } else if (e['keyCode'] == Laya.Keyboard.UP || e['keyCode'] == Laya.Keyboard.W) { //上
                    this.simulateClick(this.btnUp, true);
                    this.moveCharacter(1);
                } else if (e['keyCode'] == Laya.Keyboard.DOWN || e['keyCode'] == Laya.Keyboard.S) { //下
                    this.simulateClick(this.btnDown, true);
                    this.moveCharacter(-1);
                }
            });
            Laya.stage.on(laya.events.Event.KEY_UP, this, e => {
                if (e['keyCode'] == Laya.Keyboard.UP || e['keyCode'] == Laya.Keyboard.W) { //上
                    this.simulateClick(this.btnUp, false);
                } else if (e['keyCode'] == Laya.Keyboard.DOWN || e['keyCode'] == Laya.Keyboard.S) { //下
                    this.simulateClick(this.btnDown, false);
                }
            });

            this.aniShow = aniRoot.show;
            this.aniHidePause = aniRoot.pause_hide;
            this.aniShowPause = aniRoot.pause_show;
            this.aniTimeGlow = aniRoot.time_glow;
            this.aniOperation = aniRoot.operate_show;
            this.aniShowEnd = aniRoot.end_show;
            this.aniIdleEnd = aniRoot.end_idle;
            this.aniFailed = aniRoot.failed;
            this.aniHandLimit = aniRoot.hand_limit;
            this.aniShowFeverTile = aniRoot.fu_show;
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });
            this.btnMute.clickHandler = new Laya.Handler(this, () => {
                this.changeMuteState();
                this.refreshMuteBtn();
            }, null, false);
            Laya.stage.on(/*laya.events.Event.VISIBILITY_CHANGE*/"visibilitychange", null, () => {
                if (Laya.stage.isVisibility) {
                    this.isBackGround = false;
                } else {
                    this.isBackGround = true;
                }
                this.checkIsBackGround();
            });
            UI_Activity_Marathon_Game.bgmMuted = game.LocalStorage.getActivityMute(UI_Activity_Marathon_Main.activityId);
        }

        private simulateClick(btn: Laya.Button, mouseDown: boolean) {
            let CButton = btn.scriptMap['capsui.CButton'] as capsui.CButton;
            if (mouseDown) {
                CButton.OnMouseDown();
            } else {
                CButton.OnMouseUp();
            }
        }

        private checkIsBackGround() {
            if (!this.isBackGround) return;
            if (!MarathonData.Inst.gaming) return;
            if (!this.comPause.visible) this.showPause();
        }

        private refreshMuteBtn() {
            (this.btnMute.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(UI_Activity_Marathon_Game.bgmMuted ? 'myres/activity_2602chunjie/home_btn_sound_off.png' : 'myres/activity_2602chunjie/home_btn_sound_on.png')
        }

        moveCharacter(direction: number) {
            if (this.locking) return;
            if (MarathonData.Inst.isPause) return;
            if (!MarathonData.Inst.gaming) return;
            MarathonEffectMgr.Inst.moveCharacter(direction);
        }

        requestStartGame() {
            this.locking = true;
            MarathonData.Inst.requestStartGame(Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        prepareStartGame() {
            this.reset();
            this.refreshFeverTiles(true);
            this.refreshTime();
            this.refreshCarrot();
            this.refreshDistance();
        }

        onGameStart() {
            this.checkIsBackGround();
            this.refreshBgm();
        }

        onGameEnd(result: EMarathonResult) {
            view.AudioMgr.PlayAudio(10388);
            this.locking = true;
            let delay = result == EMarathonResult.HandsOut ? 1000 : 500;
            Laya.timer.once(delay, this, () => {
                this.stopBgm();
                this.comEnd.visible = true;
                this.comPopupBg.visible = true;
                this.aniShowEnd.play(0, false);
                this.aniIdleEnd.play(0, true);
                Laya.timer.once(1333, this, () => {
                    this.locking = false;
                    this.aniIdleEnd.stop();
                    this.aniShowEnd.stop();
                    this.comEnd.visible = false;
                    this.comPopupBg.visible = false;
                    UI_Activity_Marathon_Result.Inst.show();
                });
            });
        }

        refreshFeverTiles(isNew: boolean = false) {
            if (isNew) this.aniShowFeverTile.play(0, false);
            const feverTiles = MarathonData.Inst.feverTiles || [];
            this.feverTiles.forEach((tile, index) => {
                if (feverTiles[index]) {
                    tile.refresh(feverTiles[index], MarathonData.Inst.isFeverTileConsumed(feverTiles[index]));
                } else {
                    tile.reset();
                }
            });
            this.hands.forEach(hand => {
                if (hand.value) {
                    hand.refreshFeverTile(MarathonData.Inst.isFeverTile(hand.value));
                }
            });
        }

        onGameUpdate() {
            this.refreshTime();
            this.refreshCarrot();
            this.refreshDistance();
        }

        refreshTime() {
            const timeRemain = MarathonData.Inst.timeRemain;
            this.txtTime.text = MarathonData.Inst.getMinMsecByTime(timeRemain);
            let color = '#ffffff';
            let timeBg = '';
            if (MarathonData.Inst.duringFeverTime) {
                color = '#ffde5c';
                timeBg = 'myres/activity_2602chunjie/game_countdown_bg_speed';
            } else if (timeRemain <= 10000) {
                color = "#fe2f25";
                timeBg = 'myres/activity_2602chunjie/game_countdown_bg_finish';
            }
            this.imgTimeGlow.skin = timeBg ? game.Tools.localUISrc(timeBg + '.png') : '';
            this.txtTime.color = color;
            if (timeBg) {
                if (!this.aniTimeGlow.isPlaying) this.aniTimeGlow.play(0, true);
            } else {
                if (this.aniTimeGlow.isPlaying) this.aniTimeGlow.stop();
            }
        }

        refreshCarrot() {
            this.txtCarrotCount.text = MarathonData.Inst.nowScore.toString();
        }

        refreshDistance() {
            this.txtDistance.text = MarathonData.Inst.trueDistance.toFixed(0) + 'm';
        }

        showPause() {
            if (!MarathonData.Inst.gaming) return;
            MarathonData.Inst.pauseGame();
            this.locking = true;
            this.comPause.visible = true;
            this.comPopupBg.visible = true;
            this.aniShowPause.play(0, false);
            Laya.timer.once(this.aniShowPause.interval * this.aniShowPause.count, this, () => {
                this.locking = false;
            });
            this.pauseBgm();
        }

        hidePause(callback?: Laya.Handler) {
            this.locking = true;
            this.aniHidePause.play(0, false);
            Laya.timer.once(this.aniHidePause.interval * this.aniHidePause.count, this, () => {
                this.locking = false;
                this.comPause.visible = false;
                this.comPopupBg.visible = false;
                callback?.run();
                this.checkIsBackGround();
            });
            this.resumeBgm();
        }

        public refreshHands(tiles: string[] = []) {
            for (let i = 0; i < this.hands.length; i++) {
                const tile = tiles[i];
                if (tile) {
                    this.hands[i].refresh(tile, MarathonData.Inst.isFeverTile(tile), false);
                } else {
                    this.hands[i].reset();
                }
            }
        }

        private refreshHandsTip(show: boolean) {
            for (let i = 0; i < this.hands.length; i++) {
                if (this.hands[i].value) {
                    this.hands[i].refreshRedTip(show);
                }
            }
            if (show) {
                this.aniHandLimit.play(0, true);
            } else {
                this.aniHandLimit.stop();
            }
        }

        public onAddHands(tiles: string[] = [], operateTiles: string[], delay: number) {
            let operateIndex = [];
            let tileSorted = [...tiles];
            let isOutRange = tileSorted.length > MarathonConstant.MAX_HAND_TILES;
            let targetIndex = tiles.length - 1;
            if (!isOutRange) {
                MarathonData.sortPai(tileSorted);
                this.refreshHands(tileSorted);
                targetIndex = MarathonData.findPaiInsertIndex(tileSorted, tiles[tiles.length - 1]) - 1;
                this.hands[targetIndex].reset();
            }
            for (let i = 0; i < tileSorted.length; i++) {
                const tile = tileSorted[i];
                let isTemp = false;
                if (operateTiles && operateTiles.includes(tile)) {
                    operateIndex.push(i);
                    operateTiles.splice(operateTiles.indexOf(tile), 1);
                    isTemp = true;
                }
                if (this.hands[i]) {
                    if (!isOutRange || operateIndex.length == 0) {
                        if (isTemp || tile != this.hands[i].value) {
                            this.hands[i].refresh(tile, MarathonData.Inst.isFeverTile(tile), tile != this.hands[i].value, isTemp, delay);
                        }
                    }
                }
            }
            if (!isOutRange) {
                Laya.timer.once(delay, this, () => {
                    if (this.effectPaiStar && this.effectPaiStar.effect.loaded) {
                        this.effectPaiStar.pos_offset = new Laya.Point(targetIndex * 114, 0);
                        this.effectPaiStar.effect.root.active = false;
                        this.effectPaiStar.effect.root.active = true;
                    }
                });
            }
            if (operateIndex.length > 0) {
                Laya.timer.once(delay + 150, this, () => {
                    this.refreshHands(MarathonData.Inst.hands);
                    this.refreshHandsTip(false);
                });
            } else {
                if (tileSorted.length >= MarathonConstant.MAX_HAND_TILES) {
                    Laya.timer.once(delay, this, () => {
                        if (tileSorted.length == MarathonConstant.MAX_HAND_TILES) {//排满了，播红光提示
                            this.refreshHandsTip(MarathonData.Inst.hands.length >= MarathonConstant.MAX_HAND_TILES);
                        } else {//排超出来了，播抖动动画，准备结束了
                            this.aniFailed.play(0, false);
                        }
                    });
                }
            }
            this.refreshFeverTiles();
            const audioId = (MarathonData.Inst.isFeverTile(tiles[tiles.length - 1])) ? 10385 : 10384;
            view.AudioMgr.PlayAudio(audioId);
        }

        enterFeverTime() {
            this.tipFeverTime.visible = true;
            if (this.audioId) {
                view.AudioMgr.PauseAudio(this.audioId);
            }
            this.refreshBgm();
        }

        quitFeverTime() {
            this.tipFeverTime.visible = false;
            this.refreshFeverTiles(true);
            if (this.audioFeverId) {
                view.AudioMgr.StopAudio(this.audioFeverId, 500);
                this.audioFeverId = 0;
            }
            if (this.audioId) {
                this.audioId = view.AudioMgr.ResumeAudio(this.audioId, 500);
            }
            if (!this.audioId) this.refreshBgm();
        }

        doOperation(operation: IMarathonOperation) {
            if (operation.type === 0 && operation.consume) {
                this.comOperation.visible = false;
                Laya.timer.once(500, this, () => {
                    this.comOperation.visible = true;
                    this.aniOperation.play(0, false);
                    Laya.timer.once(250, this, () => {
                        if (this.effectOperation && this.effectOperation.effect.loaded) {
                            this.effectOperation.effect.root.active = false;
                            this.effectOperation.effect.root.active = true;
                        }
                    });
                    view.AudioMgr.PlayAudio(10386);
                });
                const tiles: mjcore.MJPai[] = operation.consume.tiles.map(t => mjcore.MJPai.Create(t)).sort(mjcore.MJPai.Distance);
                this.comOperateTiles.x = 0;
                this.comOperateTiles.scale(1, 1);
                this.operateTiles.forEach((tile, index) => {
                    if (tiles && tiles[index]) {
                        const tileStr = tiles[index].toString(false);
                        tile.refresh(tileStr, MarathonData.Inst.isFeverTile(tileStr));
                    } else {
                        tile.reset();
                    }
                });
                if (tiles.length > 3) {
                    this.comOperateTiles.x = -10;
                    const scale = 209 / (tiles.length * 63.8);
                    this.comOperateTiles.scale(scale, scale);
                }
                this.imgOperateBg.skin = game.Tools.localUISrc('myres/activity_2602chunjie/game_tip_operation_bg_' + operation.consume.type + '.png');
                this.imgOperate.skin = game.Tools.localUISrc('myres/activity_2602chunjie/game_tip_operation_' + operation.consume.type + '.png');
                this.txtOperateCarrot.text = '+' + (operation.reward?.point || 0);
                const time = MarathonData.Inst.getTimeByTick(operation.reward.time);
                const timeStr = MarathonData.Inst.getSecMsecByTime(time);
                this.txtOperateTime.text = '+' + timeStr;
            }
            if (!operation.reward) return;
            if (operation.reward.point) {
                this.txtAddCarrot.text = '+' + operation.reward.point;
                this.imgAddCarrot.width = this.txtAddCarrot.trueWidth + 38;
                this.comAddCarrot.y = 56;
                this.showAddBubble(this.comAddCarrot);
                if (operation.type === 1) {
                    this.txtAddChara.text = '+' + operation.reward.point;
                    this.imgAddChara.width = this.txtAddChara.trueWidth + 38;
                    this.comAddChara.y = -182;
                    this.showAddBubble(this.comAddChara);
                }
            }
            if (operation.reward.time) {
                const time = MarathonData.Inst.getTimeByTick(operation.reward.time);
                const timeStr = MarathonData.Inst.getSecMsecByTime(time);
                this.txtAddTime.text = '+' + timeStr;
                this.imgAddTime.width = this.txtAddTime.trueWidth + 38;
                this.comAddTime.y = 55;
                this.showAddBubble(this.comAddTime);
                if (operation.type === 1) {
                    this.txtAddChara.text = '+' + timeStr;
                    this.imgAddChara.width = this.txtAddChara.trueWidth + 38;
                    this.comAddChara.y = -182;
                    this.showAddBubble(this.comAddChara);
                }
            }
        }

        public showAddBubble(com: Laya.Sprite) {
            com.visible = true;
            Laya.Tween.clearAll(com);
            UIBase.anim_alpha_in(com, { y: 50 }, 150, 0, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    UIBase.anim_alpha_out(com, { y: -50 }, 0, 0, Laya.Handler.create(this, () => {
                        com.visible = false;
                    }));
                });
            }), Laya.Ease.quadInOut);
        }


        public show() {
            this.enable = true;
            this.refreshMuteBtn();
            this.prepareStartGame();
            this.locking = true;
            this.aniShow.play(0, false);
            const duration = this.aniShow.interval * this.aniShow.count;
            MarathonEffectMgr.Inst.charaMoveIn();
            Laya.timer.once(duration, this, () => {
                this.locking = false;
            });
            view.AudioMgr.StopMusic(0);
        }

        public hide(callback?: Laya.Handler) {
            this.enable = false;
            callback?.run();
        }

        onGameError() {
            MarathonData.Inst.pauseGame();
            this.hide(Laya.Handler.create(this, () => {
                UI_Activity_Marathon_Main.Inst.show();
            }));
        }

        private pauseBgm() {
            if (this.audioFeverId) {
                view.AudioMgr.PauseAudio(this.audioFeverId, 200);
            } else if (this.audioId) {
                view.AudioMgr.PauseAudio(this.audioId, 200);
            }
        }

        private resumeBgm() {
            if (this.audioFeverId) {
                view.AudioMgr.ResumeAudio(this.audioFeverId, 200);
            } else if (this.audioId) {
                view.AudioMgr.ResumeAudio(this.audioId, 200);
            }
        }

        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
            }
            if (this.audioFeverId) {
                view.AudioMgr.StopAudio(this.audioFeverId);
                this.audioFeverId = 0;
            }
        }

        public changeMuteState() {
            UI_Activity_Marathon_Game.bgmMuted = !UI_Activity_Marathon_Game.bgmMuted;
            game.LocalStorage.setActivityMute(UI_Activity_Marathon_Main.activityId, UI_Activity_Marathon_Game.bgmMuted);
            if (MarathonData.Inst.gaming) {
                this.refreshBgm();
            }
        }

        public refreshBgm() {
            if (UI_Activity_Marathon_Game.bgmMuted || view.AudioMgr.musicMuted) {
                this.stopBgm();
                return;
            }
            if (MarathonData.Inst.duringFeverTime) {
                let audioPath = cfg.audio.audio.get(10382).path;
                let volume = view.AudioMgr.musicVolume;
                this.audioFeverId = view.AudioMgr.PlayLoopSound(audioPath, volume, 0, view.EAudioType.music);
            } else {
                let audioPath = cfg.audio.audio.get(10381).path;
                let volume = view.AudioMgr.musicVolume;
                this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume, 300, view.EAudioType.music);
            }
        }

        public onEnable(): void {
            MarathonData.Inst.on(EMarathonEvent.ADD_HANDS, this, this.onAddHands);
            MarathonData.Inst.on(EMarathonEvent.PREPARE_START, this, this.prepareStartGame);
            MarathonData.Inst.on(EMarathonEvent.GAME_START, this, this.onGameStart);
            MarathonData.Inst.on(EMarathonEvent.GAME_END, this, this.onGameEnd);
            MarathonData.Inst.on(EMarathonEvent.GAME_UPDATE, this, this.onGameUpdate);
            MarathonData.Inst.on(EMarathonEvent.ENTER_FEVER_TIME, this, this.enterFeverTime);
            MarathonData.Inst.on(EMarathonEvent.QUIT_FEVER_TIME, this, this.quitFeverTime);
            MarathonData.Inst.on(EMarathonEvent.DO_OPERATION, this, this.doOperation);
            MarathonData.Inst.on(EMarathonEvent.GAME_ERROR, this, this.onGameError);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
        }

        public onDisable(): void {
            MarathonData.Inst.off(EMarathonEvent.ADD_HANDS, this, this.onAddHands);
            MarathonData.Inst.off(EMarathonEvent.PREPARE_START, this, this.prepareStartGame);
            MarathonData.Inst.off(EMarathonEvent.GAME_START, this, this.onGameStart);
            MarathonData.Inst.off(EMarathonEvent.GAME_END, this, this.onGameEnd);
            MarathonData.Inst.off(EMarathonEvent.GAME_UPDATE, this, this.onGameUpdate);
            MarathonData.Inst.off(EMarathonEvent.ENTER_FEVER_TIME, this, this.enterFeverTime);
            MarathonData.Inst.off(EMarathonEvent.QUIT_FEVER_TIME, this, this.quitFeverTime);
            MarathonData.Inst.off(EMarathonEvent.DO_OPERATION, this, this.doOperation);
            MarathonData.Inst.off(EMarathonEvent.GAME_ERROR, this, this.onGameError);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            this.reset();
            MarathonData.Inst.reset();
            MarathonEffectMgr.Inst.reset();
            if (!UI_Activity_Marathon_Game.bgmMuted) {
                view.BgmListMgr.PlayLobbyBgm();
            }
        }

        public reset() {
            this.locking = false;
            Laya.timer.clearAll(this);
            Laya.timer.clearAll(this.txtTime);
            Laya.Tween.clearAll(this.comAddTime);
            Laya.Tween.clearAll(this.comAddCarrot);
            Laya.Tween.clearAll(this.comAddChara);
            this.comOperation.visible = false;
            this.comAddTime.visible = false;
            this.comAddCarrot.visible = false;
            this.comAddChara.visible = false;
            this.comPopupBg.visible = false;
            this.comEnd.visible = false;
            this.comPause.visible = false;
            this.tipFeverTime.visible = false;
            this.hands.forEach((pai) => {
                pai.reset();
            });
            this.aniFailed.gotoAndStop(0);
            this.aniHandLimit.stop();
            if (this.effectOperation && this.effectOperation.effect.loaded) {
                this.effectOperation.effect.root.active = false;
            }
            this.stopBgm();
        }

        initEffect() {
            MarathonEffectMgr.Inst.init(this.comBg, this.comFrontBg);
            this.effectOperation = game.FrontEffect.Inst.create_ui_effect(this.comOperation, 'scene/effect_2602_operation.lh', new Laya.Point(260, 50), 1);
            this.effectOperation.effect.addLoadedListener(Laya.Handler.create(this, () => {
                this.effectOperation.effect.root.active = false;
            }));
            this.effectPaiStar = game.FrontEffect.Inst.create_ui_effect(this.hands[0].me, 'scene/effect_2602_pai_star.lh', new Laya.Point(0, 0), 1);
            this.effectPaiStar.effect.addLoadedListener(Laya.Handler.create(this, () => {
                this.effectPaiStar.effect.root.active = false;
            }));
        }

        destroyEffect() {
            MarathonEffectMgr.Inst.destroy();
            this.effectOperation?.destory();
            this.effectPaiStar?.destory();
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_Marathon_Main.activityId) {
                        Laya.timer.clearAll(this);
                        MarathonData.Inst.pauseGame();
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            game.Scene_Activity.Inst.QuitScene();
                        }))
                        return;
                    }
                }
            }
        }
    }
}