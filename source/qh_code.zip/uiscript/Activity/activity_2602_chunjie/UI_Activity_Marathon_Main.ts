module uiscript {
    enum EMarathonCheckMark {
        none = 0,
        guide1 = 1,
        guide2 = 2,
        maxLevel = 3
    }
    export class UI_Activity_Marathon_Main extends UIBase {
        public static Inst: UI_Activity_Marathon_Main = null;
        public static activityId: number = 260201;
        public static carrotId: number = 30900098;
        public static trainId: number = 30900099;
        public static haveRedPoint() {
            if (UI_Activity_Marathon_Reward.haveRedPoint()) return true;
            if (UI_Marathon_Train.haveRedPoint()) return true;
            if (UI_Marathon_Train.isAllCompleted() && UI_Activity_Marathon_Reward.isAllCompleted()) return false;
            if (UI_Activity_Marathon_Task.haveRedPoint()) return true;
            return false;
        }
        constructor() {
            super(new ui.lobby.activity_2602chunjie.activity_2602chunjie_mainUI);
            UI_Activity_Marathon_Main.Inst = this;
        }

        public comBg: Laya.Sprite;
        private comMain: Laya.Sprite;
        private comPopup: Laya.Sprite;
        private comTop: Laya.Sprite;
        private comChara: Laya.Sprite;
        private comInfo: Laya.Sprite;

        private btnPlay: Laya.Button;

        private btnTask: Laya.Button;
        private comReward: Laya.Sprite;
        private btnReward: Laya.Button;
        private txtTotalCarrot: Laya.Label;
        private comRecord: Laya.Sprite;
        private txtMaxTime: Laya.Label;
        private txtMaxDistance: Laya.Label;
        private txtMaxCarrot: Laya.Label;

        private btnReturn: Laya.Button;
        private btnMute: Laya.Button;
        private btnHelp: Laya.Button;

        private chara: UI_Marathon_Chara;
        private pageReward: UI_Activity_Marathon_Reward;
        private pageTask: UI_Activity_Marathon_Task;
        private comTrain: UI_Marathon_Train;
        private comSpot: UI_Marathon_Spot;
        private btnSpot: Laya.Button;

        public locking: boolean;
        private checkedMark: EMarathonCheckMark;
        private activityFinishHandler: Laya.Handler;

        private effectBg: Laya.Scene;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniIdle: Laya.FrameAnimation;
        private refreshCarrotHandler: Laya.Handler;
        private refreshTrainHandler: Laya.Handler;
        private needGreeting: boolean = true;
        private needUpgrade: boolean = false;

        public onCreate(): void {
            this.comBg = this.me.getChildByName('bg') as Laya.Sprite;
            this.comMain = this.me.getChildByName('main') as Laya.Sprite;
            this.comPopup = this.me.getChildByName('popup') as Laya.Sprite;
            this.comTop = this.comMain.getChildByName('top') as Laya.Sprite;
            this.comInfo = this.comMain.getChildByName('info') as Laya.Sprite;
            this.btnHelp = this.comTop.getChildByName('btn_help') as Laya.Button;
            this.btnReturn = this.comTop.getChildByName('btn_return') as Laya.Button;
            this.btnMute = this.comTop.getChildByName('btn_mute') as Laya.Button;

            this.comReward = this.comInfo.getChildByName('reward') as Laya.Sprite;
            this.txtTotalCarrot = this.comReward.getChildByName('count') as Laya.Label;
            this.btnReward = this.comReward.getChildByName('btn_reward') as Laya.Button;
            this.btnTask = this.comInfo.getChildByName('btn_task') as Laya.Button;
            this.btnPlay = this.comInfo.getChildByName('btn_start') as Laya.Button;
            this.comRecord = this.comInfo.getChildByName('bg').getChildByName('record').getChildByName('record') as Laya.Sprite;
            this.txtMaxCarrot = this.comRecord.getChildByName('carrot').getChildByName('value') as Laya.Label;
            this.txtMaxDistance = this.comRecord.getChildByName('distance').getChildByName('value') as Laya.Label;
            this.txtMaxTime = this.comRecord.getChildByName('time').getChildByName('value') as Laya.Label;

            this.comChara = this.comMain.getChildByName('illust') as Laya.Sprite;
            this.chara = new UI_Marathon_Chara(this.comChara, 'myres/activity_2602chunjie/illust_', 'UI_Activity_Marathon_Main');
            let comTrain = this.comMain.getChildByName('train') as Laya.Sprite;
            this.comTrain = new UI_Marathon_Train(comTrain, this);
            this.comSpot = new UI_Marathon_Spot(this.comMain.getChildByName('spot') as Laya.Sprite, this);
            this.btnSpot = this.comChara.getChildByName('btn_spot') as Laya.Button;
            this.btnSpot.clickHandler = new Laya.Handler(this, () => {
                this.chara.stopsay();
                this.comSpot.onClickSpotBtn();
            });
            this.btnSpot.on(Laya.Event.CLICK, this, (e: Laya.Event) => {
                e.stopPropagation();
                this.closeTrainDetail();
            });
            this.btnReward.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                view.AudioMgr.PlayAudio(10380);
                UI_Activity_Marathon_Reward.Inst.show();
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                view.AudioMgr.PlayAudio(10380);
                UI_Activity_Marathon_Task.Inst.show();
            });
            this.btnMute.clickHandler = new Laya.Handler(this, () => {
                UI_Activity_Marathon_Game.bgmMuted = !UI_Activity_Marathon_Game.bgmMuted;
                this.refreshMuteBtn();
                this.refreshBgm();
            }, null, false);

            this.btnReturn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            });
            this.btnHelp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showRules();
            }, null, false);
            this.activityFinishHandler = new Laya.Handler(this, msg => {
                this.onActivityFinish(msg);
            });

            this.btnPlay.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.locking = true;
                MarathonData.Inst.requestStartGame(Laya.Handler.create(this, () => {
                    this.locking = false;
                }));
            });
            this.pageReward = new UI_Activity_Marathon_Reward();
            this.pageTask = new UI_Activity_Marathon_Task();
            this.comPopup.addChild(this.pageReward.me);
            this.comPopup.addChild(this.pageTask.me);
            const aniRoot = this.me as ui.lobby.activity_2602chunjie.activity_2602chunjie_mainUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
            this.aniIdle = aniRoot.idle;
            this.refreshCarrotHandler = new Laya.Handler(this, this.refreshCarrot);
            this.refreshTrainHandler = new Laya.Handler(this, () => {
                if (this.pageTask.enable) return;
                Laya.timer.once(50, this, () => {
                    this.refreshTrainTask();
                });
            });
            this.me.on(Laya.Event.CLICK, this, () => {
                this.closeSpotDetail();
                this.closeTrainDetail();
            });
        }

        closeSpotDetail() {
            this.comSpot.closeDetail();
        }

        closeTrainDetail() {
            this.comTrain.closeDetail();
        }

        private refreshMuteBtn() {
            (this.btnMute.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(UI_Activity_Marathon_Game.bgmMuted ? 'myres/activity_2602chunjie/home_btn_sound_off.png' : 'myres/activity_2602chunjie/home_btn_sound_on.png')
        }

        private showRules() {
            let onClose: Laya.Handler = null;
            let extraConfig: IRuleExtraConfig = {
                onClose: Laya.Handler.create(this, () => {
                    UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(26022002), true, onClose);
                })
            }
            UI_Activity_Rules.Inst.show(extraConfig);
            view.AudioMgr.PlayAudio(10380);
        }

        prepareStartGame() {
            this.hide(Laya.Handler.create(this, () => {
                UI_Activity_Marathon_Game.Inst.show();
            }))
        }


        refreshRedPoint() {
            (this.btnTask.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Marathon_Task.haveRedPoint();
            (this.btnReward.getChildByName('redpoint') as Laya.Image).visible = UI_Activity_Marathon_Reward.haveRedPoint();
        }

        public show(): void {
            this.chara.showCharacter(200001);
            if (this.needGreeting) this.chara.say(EMarathonVoiveType.greeting);
            else if (this.needUpgrade) this.chara.say(EMarathonVoiveType.upgrade);
            this.needGreeting = false;
            this.needUpgrade = false;
            this.enable = true;
            this.refresh();
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.aniIdle.play(0, true);
                this.locking = false;
            });
            if (!this.checkedMark) {
                this.checkedMark = app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.Marathon_2602_Checked);
            }
            if (this.checkedMark == 0) {
                this.updateCheckedMark(1);
                this.showSpot(0);
            } else if (this.checkedMark == 1) {
                this.updateCheckedMark(2);
                this.showRules();
            } else if (this.checkedMark == 2) {
                if (UI_Marathon_Train.isAllCompleted()) {
                    this.updateCheckedMark(3);
                    this.needUpgrade = true;
                    this.showSpot(1);
                }
            }
        }

        updateCheckedMark(value: number) {
            this.checkedMark = value;
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.Marathon_2602_Checked, value);
        }

        showSpot(index: number) {
            const activitySpotId = 260205;
            let datas = cfg.activity.story_activity.getGroup(activitySpotId);
            const spotData = datas[index];
            GameMgr.Inst.showSpotByEvent(spotData.content_path, spotData.story_id, Laya.Handler.create(this, () => {
                view.AudioMgr.StopMusic(0);
                view.BgmListMgr.PlayLobbyBgm();
                if (UI_Activity.activities[UI_Activity_Marathon_Main.activityId]) {
                    GameMgr.Inst.enterActivityScene();
                } else {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437));
                    GameMgr.Inst.EnterLobby();
                }
            }), activitySpotId, Laya.Handler.create(this, () => {
                UI_Activity_Marathon_Main.Inst.enable = false;
                view.AudioMgr.StopMusic(0);
            }, null, false));
        }


        public refresh() {
            this.refreshMuteBtn();
            this.refreshRedPoint();
            this.refreshCarrot();
            this.refreshTrainTask(false);
            this.comSpot.refresh();
            const record = MarathonData.Inst.highestRecord;
            this.txtMaxCarrot.text = record.point.toString();
            this.txtMaxDistance.text = record.distance + 'm';
            const time = MarathonData.Inst.getTimeByTick(record.used_tick);
            const timeStr = MarathonData.Inst.getMinMsecByTime(time);
            this.txtMaxTime.text = timeStr;
        }

        refreshCarrot() {
            this.txtTotalCarrot.text = UI_Bag.get_item_count(UI_Activity_Marathon_Main.carrotId).toString();
        }

        refreshTrainTask(showUpgrade: boolean = true) {
            const isUpgraded = this.comTrain.refresh();
            if (isUpgraded && showUpgrade) {
                const isMaxGrade = UI_Marathon_Train.nowGrade == 5;
                if (isMaxGrade) {
                    this.updateCheckedMark(3);
                    this.needUpgrade = true;
                    this.showSpot(1);
                } else {
                    this.chara.stopsay();
                    this.chara.say(EMarathonVoiveType.upgrade);
                }
            }
        }

        public hide(onClose?: Laya.Handler) {
            this.locking = true;
            this.aniIdle.stop();
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.locking = false;
                this.enable = false;
                if (onClose) {
                    onClose.run();
                } else {
                    game.Scene_Activity.Inst.QuitScene();
                }
            });
        }

        public onDisable(): void {
            this.aniIdle.stop();
            this.chara.hideCharacter();
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Main', false);
            app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            UI_Bag.remove_item_listener(UI_Activity_Marathon_Main.trainId, this.refreshTrainHandler);
            UI_Bag.remove_item_listener(UI_Activity_Marathon_Main.carrotId, this.refreshCarrotHandler);
            this.locking = false;
            Laya.timer.clearAll(this);
            this.comTrain.hide();
            this.pageReward.hide();
            this.pageTask.hide();
            MarathonData.Inst.off(EMarathonEvent.PREPARE_START, this, this.prepareStartGame);
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Main', true);
            app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);
            MarathonData.Inst.on(EMarathonEvent.PREPARE_START, this, this.prepareStartGame);
            UI_Bag.add_item_listener(UI_Activity_Marathon_Main.carrotId, this.refreshCarrotHandler);
            UI_Bag.add_item_listener(UI_Activity_Marathon_Main.trainId, this.refreshTrainHandler);
        }

        public onActivityFinish(msg) {
            if (msg.end_activities) {
                for (let i: number = 0; i < msg.end_activities.length; i++) {
                    let id = msg.end_activities[i];
                    if (id == UI_Activity_Marathon_Main.activityId) {
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                            this.hide();
                        }))
                        return;
                    }
                }
            }
        }

        refreshBgm() {
            if (UI_Activity_Marathon_Game.bgmMuted) {
                view.AudioMgr.StopMusic(0);
            } else {
                view.BgmListMgr.PlayLobbyBgm();
            }
        }

        onInitScene() {
            if (UI_Activity_Marathon_Game.bgmMuted) {
                view.AudioMgr.StopMusic(0);
            }
            UI_Activity_Marathon_Game.Inst.initEffect();
        }

        onQuitScene() {
            if (UI_Activity_Marathon_Game.bgmMuted) {
                view.BgmListMgr.PlayLobbyBgm();
            }
            UI_Activity_Marathon_Game.Inst.destroyEffect();
        }

    }

    class UI_Marathon_Spot extends UIBase {
        private father: UI_Activity_Marathon_Main;
        private comPupup: Laya.Sprite;
        private comSpotBtns: Laya.Button[];
        private isOpen: boolean = false;

        constructor(me: Laya.Sprite, father: UI_Activity_Marathon_Main) {
            super(me);
            this.father = father;
        }

        onCreate() {
            this.comPupup = this.me.getChildByName('popup') as Laya.Sprite;
            this.comSpotBtns = [];
            for (let i = 0; i < 2; i++) {
                const btn = this.comPupup.getChildByName('spot' + i) as Laya.Button;
                this.comSpotBtns.push(btn);
                btn.clickHandler = new Laya.Handler(this, () => {
                    if (i == 0 || UI_Marathon_Train.isAllCompleted()) {
                        this.father.showSpot(i);
                    } else {
                        UI_Info_Small.Inst.show(game.Tools.strOfLocalization(26022030));
                    }
                });
            }
            this.father.me.on(Laya.Event.CLICK, this, this.closeDetail);
            this.comPupup.on(Laya.Event.CLICK, this, (e: Laya.Event) => {
                e.stopPropagation();
            });
        }

        refresh() {
            this.enable = true;
            let datas = cfg.activity.story_activity.getGroup(260205);
            for (let i = 0; i < this.comSpotBtns.length; i++) {
                const spotData = datas[i];
                let txtTitle = this.comSpotBtns[i].getChildByName('title') as Laya.Label;
                txtTitle.text = game.Tools.eventStrOfLocalization(spotData.title);
                const locked = i == 1 && !UI_Marathon_Train.isAllCompleted();
                txtTitle.color = locked ? '#c9cfd1' : '#ffe09c';
                this.comSpotBtns[i].skin = game.Tools.localUISrc(locked ? 'myres/activity_2602chunjie/home_spot_bg_locked.png' : 'myres/activity_2602chunjie/home_spot_bg.png');
            }
            this.comPupup.visible = false;
            Laya.Tween.clearAll(this.comPupup);
        }

        onClickSpotBtn() {
            if (this.isOpen) {
                this.closeDetail();
                return;
            }
            this.showSpotPopup();
        }

        showSpotPopup() {
            this.isOpen = true;
            this.comPupup.visible = true;
            Laya.Tween.clearAll(this.comPupup);
            this.comPupup.scale(1, 1);
            UIBase.anim_pop_out(this.comPupup, null);
        }

        closeDetail() {
            this.isOpen = false;
            Laya.Tween.clearAll(this.comPupup);
            UIBase.anim_pop_hide(this.comPupup, Laya.Handler.create(this, () => {
                this.comPupup.visible = false;
            }));
        }
    }

}