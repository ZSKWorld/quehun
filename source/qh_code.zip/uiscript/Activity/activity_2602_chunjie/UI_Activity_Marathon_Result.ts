module uiscript {
    export class UI_Activity_Marathon_Result extends UIBase {
        public static Inst: UI_Activity_Marathon_Result = null;
        public static haveRedPoint() {
            return false;
        }

        private root: Laya.Sprite;
        private comProgress: Laya.Sprite;
        private txtProgress: Laya.HTMLDivElement;
        private comAddProgress: Laya.Sprite;
        private txtAddProgress: Laya.Label;
        private imgAddProgress: Laya.Image;

        private comRecord: Laya.Sprite;
        private comTimeRecord: Laya.Sprite;
        private txtTime: Laya.Label
        private imgTimeRecordNew: Laya.Image;
        private comDistanceRecord: Laya.Sprite;
        private txtDistance: Laya.Label;
        private imgDistanceRecordNew: Laya.Image;

        private comCarrot: Laya.Sprite;
        private txtCarrot: Laya.Label;
        private imgCarrotRecordNew: Laya.Image;

        private btnAgain: Laya.Button;
        private btnConfirm: Laya.Button;

        private comChara: Laya.Sprite;
        private chara: UI_Marathon_Chara;
        private locking: boolean;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private numberRoller: game.NumberRoller;

        constructor() {
            super(new ui.lobby.activity_2602chunjie.activity_2602chunjie_resultUI);
            UI_Activity_Marathon_Result.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.comProgress = this.root.getChildByName('progress') as Laya.Sprite;
            this.txtProgress = this.comProgress.getChildByName('value') as Laya.HTMLDivElement;
            this.comAddProgress = this.comProgress.getChildByName('add') as Laya.Sprite;
            this.imgAddProgress = this.comAddProgress.getChildByName('bg') as Laya.Image;
            this.txtAddProgress = this.comAddProgress.getChildByName('value') as Laya.Label;

            this.comRecord = this.root.getChildByName('record') as Laya.Sprite;
            this.comTimeRecord = this.comRecord.getChildByName('time') as Laya.Sprite;
            this.txtTime = this.comTimeRecord.getChildByName('value') as Laya.Label;
            this.imgTimeRecordNew = this.comTimeRecord.getChildByName('new') as Laya.Image;
            this.comDistanceRecord = this.comRecord.getChildByName('distance') as Laya.Sprite;
            this.txtDistance = this.comDistanceRecord.getChildByName('value') as Laya.Label;
            this.imgDistanceRecordNew = this.comDistanceRecord.getChildByName('new') as Laya.Image;

            this.comCarrot = this.root.getChildByName('carrot') as Laya.Sprite;
            this.txtCarrot = this.comCarrot.getChildByName('count') as Laya.Label;
            this.imgCarrotRecordNew = this.comCarrot.getChildByName('new') as Laya.Image;

            this.comChara = this.root.getChildByName('illust') as Laya.Sprite;
            this.chara = new UI_Marathon_Chara(this.comChara, 'myres/activity_2602chunjie/illust_', 'UI_Activity_Marathon_Result');

            this.btnAgain = this.root.getChildByName('btn_again') as Laya.Button;
            this.btnAgain.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide(Laya.Handler.create(this, () => {
                    UI_Activity_Marathon_Game.Inst.requestStartGame();
                }));
            });
            this.btnConfirm = this.root.getChildByName('btn_confirm') as Laya.Button;
            this.btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide(Laya.Handler.create(this, () => {
                    UI_Activity_Marathon_Game.Inst.hide(Laya.Handler.create(this, () => {
                        UI_Activity_Marathon_Main.Inst.show();
                    }));
                }));
            });
            const aniRoot = this.me as ui.lobby.activity_2602chunjie.activity_2602chunjie_resultUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
            if (GameMgr.client_language == 'jp') {
                this.txtProgress.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtProgress.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtProgress.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtProgress.style.font = '30px SimHei';
            } else {
                this.txtProgress.style.font = '30px NotoSansKR';
            }
            this.txtProgress.style.color = '#a27a50';
            this.txtProgress.style.leading = 0;
            this.txtProgress.style.letterSpacing = 0;
            this.numberRoller = new game.NumberRoller();
        }

        public show(): void {
            this.enable = true;
            this.chara.showCharacter(200001);
            const record = MarathonData.Inst.gameRecord;
            const voiceType = record.originTrainGrade < UI_Marathon_Train.nowGrade ? EMarathonVoiveType.upgrade : EMarathonVoiveType.finish_work;
            this.chara.say(voiceType);
            this.numberRoller.startRoll(this.txtCarrot, record.point, 1500, 0, false);
            this.txtDistance.text = record.distance + 'm';
            const time = MarathonData.Inst.getTimeByTick(record.used_tick);
            const timeStr = MarathonData.Inst.getMinMsecByTime(time);
            this.txtTime.text = timeStr;
            this.imgTimeRecordNew.visible = record.new_time;
            this.imgDistanceRecordNew.visible = record.new_distance;
            this.imgCarrotRecordNew.visible = record.new_point;
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.locking = false;
            });
            this.refreshTrainValue(record.originTrain);
            // 没加训练度或者已经满了就不显示了
            if (record.addTrain <= 0 || record.originTrain >= UI_Marathon_Train.targetValue) {
                this.comAddProgress.visible = false;
                return;
            }
            this.txtAddProgress.text = '+' + record.addTrain;
            this.imgAddProgress.width = this.txtAddProgress.trueWidth + 38;
            this.comAddProgress.y = 85;
            this.comAddProgress.visible = true;
            Laya.Tween.clearAll(this.comAddProgress);
            UIBase.anim_alpha_in(this.comAddProgress, { y: 50 }, 150, 500, Laya.Handler.create(this, () => {
                Laya.timer.once(1000, this, () => {
                    UIBase.anim_alpha_out(this.comAddProgress, { y: -50 }, 0, 0, Laya.Handler.create(this, () => {
                        this.refreshTrainValue(record.originTrain + record.addTrain);
                        this.comAddProgress.visible = false;
                    }));
                });
            }), Laya.Ease.quadInOut);
        }

        public refreshTrainValue(value: number) {
            let nowValue = Math.min(value, UI_Marathon_Train.targetValue);
            let str = game.Tools.strOfLocalization(26022008, ['[tag]' + nowValue + '[/tag]', UI_Marathon_Train.targetValue.toString()]);
            this.txtProgress.innerHTML = game.Tools.ParseText(str, '#303548');
        }

        public hide(callback?: Laya.Handler): void {
            this.chara.stopsay();
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.locking = false;
                this.enable = false;
                this.chara.hideCharacter();
                callback?.run();
            });
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Result', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Result', false);
        }

    }
}