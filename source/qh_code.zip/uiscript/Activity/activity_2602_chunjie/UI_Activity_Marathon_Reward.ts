module uiscript {
    class UI_Reward_Item {
        private me: Laya.Sprite;
        private father: UI_Activity_Marathon_Reward;
        private itemParent: Laya.Button;
        private lockedParent: Laya.Sprite;
        private unLockParent: Laya.Sprite;
        private imgGetted: Laya.Sprite;
        private txtUnComplete: Laya.Sprite
        private btnReceive: Laya.Button;
        private txtLockedTime: Laya.Label;
        private comCarrot: Laya.Sprite;
        private txtCarrot: Laya.Label;
        private aniStar: Laya.FrameAnimation;
        private aniReceive: Laya.FrameAnimation;
        private imgItem: Laya.Image;
        private txtCount: Laya.Label
        private comStar: Laya.Sprite;
        private itemRect: UIRect = null;
        private serverData: game.ITaskProgress;
        private rewardsData: { id: number, count: number };
        private isRare: boolean = false;

        constructor(container: Laya.Sprite, father: UI_Activity_Marathon_Reward, isRare: boolean = false) {
            this.me = container;
            this.father = father;
            this.isRare = isRare;
            this.itemParent = container.getChildByName("item") as Laya.Button;
            this.lockedParent = container.getChildByName("locked") as Laya.Sprite;
            this.unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            this.imgGetted = this.unLockParent.getChildByName('received') as Laya.Sprite;
            this.txtUnComplete = this.unLockParent.getChildByName('uncomplete') as Laya.Sprite;
            this.btnReceive = this.unLockParent.getChildByName("btn_receive") as Laya.Button;
            this.txtLockedTime = this.lockedParent.getChildByName('locked') as Laya.Label;
            this.comCarrot = container.getChildByName('carrot') as Laya.Sprite;
            this.txtCarrot = this.comCarrot.getChildByName('count') as Laya.Label;
            this.aniStar = (container as ui.lobby.activity_2602chunjie.activity_2602chunjie_reward_itemUI).star_idle;
            this.aniReceive = (container as ui.lobby.activity_2602chunjie.activity_2602chunjie_reward_itemUI).received;
            this.imgItem = this.itemParent.getChildByName("item") as Laya.Image;
            this.txtCount = this.itemParent.getChildByName("count") as Laya.Label;
            this.comStar = this.itemParent.getChildByName("star") as Laya.Sprite;
            //已完成未领取
            //领取的点击事件
            this.btnReceive.clickHandler = new Laya.Handler(this, () => {
                if (this.father.locking) return;
                this.father.locking = true;
                let rewardId: number = this.rewardsData.id;
                let rewardCount: number = this.rewardsData.count;
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: this.serverData.id }, (err, res) => {
                    this.father.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                    } else {
                        this.serverData.rewarded = true;
                        this.father.task_rewarded(this.serverData.id);
                        UI_Activity.onPeriodTaskRewarded(this.serverData.id);
                        game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                        this.btnReceive.visible = false;
                        this.imgGetted.visible = true;
                        this.aniReceive.play(0, false);
                        (this.itemParent.getChildByName("star") as Laya.Sprite).visible = false;
                        this.aniStar.stop();
                        this.father.freshGetAllBtn();
                        if (this.isRare) {
                            this.father.refreshAll();
                        }
                    }
                });
            }, null, false);
            this.itemParent.clickHandler = new Laya.Handler(this, () => {
                if (this.father.locking) return;
                UI_ItemDetail.Inst.show(this.rewardsData.id);
            });
        }

        refresh(serverData: game.ITaskProgress) {
            this.serverData = serverData;
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            const rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            this.rewardsData = { id: rewardsData[0], count: rewardsData[1] };
            //设置上锁的信息
            let isUnlock = this.father.isTaskUnlock(serverData);
            this.lockedParent.visible = !isUnlock;
            this.unLockParent.visible = isUnlock;
            this.txtCarrot.text = baseTaskConfigData.target.toString();
            this.comCarrot.width = this.txtCarrot.trueWidth + 46;
            this.comCarrot.x = 146 - this.comCarrot.width / 2;
            (this.me.getChildByName('bg') as Laya.Image).visible = configData.node_mark == 0;
            (this.me.getChildByName('bg_rare') as Laya.Image).visible = configData.node_mark != 0;
            if (isUnlock) {
                //赋值任务名称
                this.btnReceive.visible = !serverData.rewarded && serverData.achieved;
                this.txtUnComplete.visible = !serverData.rewarded && !serverData.achieved;
                this.imgGetted.visible = serverData.achieved && serverData.rewarded;
                if (this.imgGetted.visible && this.father.receiveMarkLst.indexOf(serverData.id) > -1) {
                    this.aniReceive.play(0, false);
                    this.father.receiveMarkLst.splice(this.father.receiveMarkLst.indexOf(serverData.id), 1);
                } else {
                    this.aniReceive.gotoAndStop(this.aniReceive.count);
                }
                this.btnReceive.mouseEnabled = serverData.achieved && !serverData.rewarded;
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Marathon_Reward.activityId, configData.reward_limit_day);
                this.txtLockedTime.text = game.Tools.getLockTimeText1(restSeconds);
            }
            // 奖励的渲染
            if (this.rewardsData) {
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(this.imgItem);
                }
                this.comStar.visible = isUnlock && this.btnReceive.visible;
                if (this.comStar.visible) {
                    this.aniStar.play(0, true);
                } else {
                    this.aniStar.stop();
                }
                game.Tools.setItemIcon(this.imgItem, this.itemRect, this.rewardsData.id, "UI_Activity_Marathon_Reward", true);
                this.txtCount.text = this.rewardsData.count.toString();
            }
        }


    }
    export class UI_Activity_Marathon_Reward extends UI_PopupBase {
        public static Inst: UI_Activity_Marathon_Reward;
        public static activityId: number = 260204;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                        if (d_task) {
                            if (d_task.accessible_days) {
                                if (this.getUnLockStateByTaskId(d_task, this.activityId)) return true;
                            } else {
                                if (d_task.reward_limit_day <= delta) return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        public static getUnLockStateByTaskId(taskConfig: lqc.Sheet_Activity_PeriodTask, activityId: number) {
            let timeString = taskConfig.accessible_days;
            let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
            let activityDeltaDay = UI_Activity.getActivityDeltaDay(activityId);
            if (timeArray.length >= 2) {
                let minTime = timeArray[0];
                let maxTime = timeArray[1];
                if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                    return false;
                }
            }
            return true;
        }

        public static isAllCompleted(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (!_info['achieved']) {
                        return false;
                    }
                }
            }
            return true;
        }

        private listContainer: Laya.Panel;
        private btnGetAll: Laya.Button;
        /**
        * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
        */
        private serverData: Object[];
        /**
         * 已经排序过的数据
         */
        private sortServerData: Array<game.ITaskProgress> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView_Heng;
        private txtCarrot: Laya.Label;
        private activityId: number = 260204;
        public receiveMarkLst: number[] = []; //需要展示的已完成未领取的任务id列表,当点击领取时如果这个任务在列表里则展示这个任务的领取动画
        private rareItem: UI_Reward_Item = null;
        private rareItemData: game.ITaskProgress = null;
        private comRare: Laya.Sprite;

        constructor() {
            super(new ui.lobby.activity_2602chunjie.activity_2602chunjie_rewardUI());
            UI_Activity_Marathon_Reward.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.maskAlpha = 1;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            let list = this.root.getChildByName("content").getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick, null, false);
            this.scrollView = list.scriptMap['capsui.CScrollView_Heng'] as capsui.CScrollView_Heng;
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
            this.txtCarrot = this.root.getChildByName('carrot').getChildByName('count') as Laya.Label;
            this.comRare = this.root.getChildByName("content").getChildByName("rare") as Laya.Sprite;
            this.rareItem = new UI_Reward_Item(this.comRare.getChildByName("root") as Laya.Sprite, this, true);
            this.listContainer.hScrollBar.on('change', this, this.refreshRateItem);
            (this.root.getChildByName('carrot').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(UI_Activity_Marathon_Main.carrotId);
            }, null, false);
        }

        private refreshRateItem(force: boolean = false) {
            let scrollX = this.listContainer.hScrollBar.value;
            let nowIndex = Math.floor((scrollX + 1320) / (294));
            let nextRare = this.getNextRareLevel(nowIndex);
            if (nextRare) {
                if (!this.rareItemData || this.rareItemData.id != this.sortServerData[nextRare].id || force) {
                    this.comRare.visible = true;
                    this.rareItemData = this.sortServerData[nextRare];
                    this.rareItem.refresh(this.rareItemData);
                }
            } else {
                this.comRare.visible = false;
                this.rareItemData = null;
            }
        }

        private freshList(delay: number = 0) {
            let data = this.sortServerData;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();
            const index = Math.max(this.getNextReceiveLevel(), 0);
            this.scrollView.content.hScrollBar.value = (index / data.length) * 294 * data.length;
            this.scrollView.wantToRefreshAll();
            this.locking = true;
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            let tween_config = { delay: 68, duration: 150, ease: Laya.Ease.quadInOut };
            let start_config = { alpha: 0, x_dis: 100 };
            let target_config = { alpha: 1 };
            list.me.alpha = 0;
            let items = list.getItemsInView().map(v => v.container);
            let list_delay = 150 + (items.length - 1) * 68;
            Laya.timer.once(delay, this, () => {
                list.me.alpha = 1;
                game.Tools.listSpritesAnim(items, tween_config, start_config, target_config);
            });
            Laya.timer.once(delay + list_delay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        private getNextReceiveLevel(): number {
            const levels: number[] = [];
            for (let i = 0; i < this.sortServerData.length; i++) {
                const element = this.sortServerData[i];
                if (!element.rewarded) {
                    return i;
                }
                if (!element.achieved) {
                    return i;
                }
            }
            return 0;
        }

        private getNextRareLevel(startIndex: number = 0): number {
            for (let i = startIndex; i < this.sortServerData.length; i++) {
                const element = this.sortServerData[i];
                let configData = cfg.activity.period_task.get(element.id);
                if (configData.node_mark != 0) {
                    return i;
                }
            }
            return 0;
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Reward', false);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_Activity_Marathon_Reward', true);
            this.freshData();
            this.freshList(100);
            this.refreshRateItem();
        }

        //刷新列表数据
        private freshData() {
            this.receiveMarkLst.length = 0;
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(this.activityId);
            // app.Log.log(`UI_Activity_2508_Navigation_Task的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress);
            //排序
            allTask = allTask.sort((a, b) => {
                return a.id - b.id;
            });
            this.sortServerData = allTask;
            this.txtCarrot.text = UI_Bag.get_item_count(UI_Activity_Marathon_Main.carrotId).toString();
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container.getChildAt(0) as Laya.Sprite;
            let index: number = obj.index;
            let serverData = this.sortServerData[index];
            let cache_data: any = obj.cache_data;
            if (!cache_data['item']) {
                cache_data['item'] = new UI_Reward_Item(container, this);
            }
            cache_data['item'].refresh(serverData);
        }

        public isTaskUnlock(task: game.ITaskProgress): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(task.id);
            if (taskConfig.accessible_days) {
                let timeString = taskConfig.accessible_days;
                let timeArray = common.ConfigHelper.configString2Array<number>(timeString)[0];
                let activityDeltaDay = UI_Activity.getActivityDeltaDay(UI_Activity_Marathon_Reward.activityId);
                if (timeArray.length >= 2) {
                    let minTime = timeArray[0];
                    let maxTime = timeArray[1];
                    if (activityDeltaDay < minTime || activityDeltaDay > maxTime) {
                        return false;
                    }
                }
                return true;
            } else {
                //到哪天才能领取
                let timeLimit = taskConfig.reward_limit_day;
                let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Marathon_Reward.activityId);
                if (activityDeltaTime < timeLimit) {
                    return false;
                }
                return true;
            }
        }

        // 由于show_list与实际数据不匹配，完成任务时需要额外修改rewarded
        public task_rewarded(task_id: number) {
            for (let task of this.sortServerData) {
                if (task['id'] == task_id) {
                    task['rewarded'] = true;
                    return;
                }
            }
        }

        public freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAll.mouseEnabled = !shouldSetGray;
            this.btnGetAll.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_2602chunjie/popup_btn1_grayed.png' : 'myres/activity_2602chunjie/popup_btn1.png');
            (this.btnGetAll.getChildByName('title') as Laya.Label).color = shouldSetGray ? '#5a6a71' : '#633d2d';
            UI_Activity_Marathon_Main.Inst.refreshRedPoint();
        }

        public refreshAll() {
            this.scrollView.wantToRefreshAll();
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let lst = this.sortServerData;
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }

        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(this.activityId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData;
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        needGetList.push(data['id']);
                    } else {
                        break;
                    }
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    allRewardList.forEach(v => {
                        if (v.achieved && !v.rewarded)
                            v.rewarded = true;
                    });
                    let rewardList = [];
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = Number(rewardStr[0]);
                        let rewardCount = Number(rewardStr[1]);
                        rewardList.push({ id: rewardId, count: rewardCount });
                    }
                    this.receiveMarkLst = needGetList;
                    this.scrollView.wantToRefreshAll();
                    this.freshGetAllBtn();
                    this.refreshRateItem(true);
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }
    }
}