module uiscript {
    interface IMarathonTrainInfo extends game.ITaskProgress {
        target: number;
        reward: {
            id: number;
            count: number;
        }[];
    }
    class UI_TrainItem {
        private me: ui.lobby.activity_2602chunjie.activity_2602chunjie_trainUI;
        private father: UI_Marathon_Train;
        private comFinished: Laya.Sprite;
        private comReceived: Laya.Sprite;
        private txtValue: Laya.Label;
        private imgIcon: Laya.Image;
        private btnDetail: Laya.Button;
        public aniFinish: Laya.FrameAnimation;
        private aniReceive: Laya.FrameAnimation;
        private task: IMarathonTrainInfo;
        private index: number;

        constructor(me: ui.lobby.activity_2602chunjie.activity_2602chunjie_trainUI, father: UI_Marathon_Train, index: number) {
            this.me = me;
            this.father = father;
            this.index = index;
            const comReward = this.me.getChildByName('reward') as Laya.Sprite;
            this.comReceived = comReward.getChildByName('received') as Laya.Sprite;
            this.imgIcon = comReward.getChildByName('icon') as Laya.Image;
            this.btnDetail = comReward.getChildByName('btn') as Laya.Button;
            this.txtValue = this.me.getChildByName('value') as Laya.Label;
            this.btnDetail.clickHandler = new Laya.Handler(this, () => {
                this.father.onClickTask(this.index);
            });
            this.btnDetail.on(Laya.Event.CLICK, this, (e: Laya.Event) => {
                e.stopPropagation();
                UI_Activity_Marathon_Main.Inst.closeSpotDetail();
            });
            this.comFinished = comReward.getChildByName('finished') as Laya.Sprite;
            this.aniFinish = this.me.idle;
            this.aniReceive = this.me.complete;
        }

        refresh(task: IMarathonTrainInfo, doAnim: boolean = false) {
            if (!task) return;
            this.task = task;
            this.me.visible = true;
            this.comFinished.visible = task.achieved && !task.rewarded;
            this.comReceived.visible = task.rewarded;
            this.txtValue.text = task.target.toString();
            if (this.comFinished.visible) {
                this.aniFinish.play(this.father.getAnimProgress(), true);
            } else {
                this.aniFinish.stop();
            }
            if (this.comReceived.visible) {
                if (doAnim) this.aniReceive.play(0, false);
                else this.aniReceive.gotoAndStop(this.aniReceive.count);
            }
        }

        reset() {
            this.me.visible = false;
            this.aniFinish.stop();
            this.aniReceive.stop();
        }

    }

    export class UI_Marathon_Train extends UIBase {
        public static Inst: UI_Marathon_Train = null;
        public static activityId: number = 260203;
        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                        if (d_task) {
                            if (d_task.reward_limit_day <= delta) return true;
                        }
                    }
                }
            }
            return false;
        }

        public static isAllCompleted(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (!_info['achieved']) {
                        return false;
                    }
                }
            }
            return true;
        }

        public static get targetValue(): number {
            let _list = UI_Activity.getPeriodTaskList(this.activityId) as game.ITaskProgress[];
            _list.sort((a, b) => {
                return a.id - b.id;
            });
            if (_list && _list.length > 0) {
                let lastTask = _list[_list.length - 1];
                let d_task = cfg.activity.period_task.get(lastTask.id);
                if (d_task && d_task.base_task_id) {
                    let baseTask = cfg.events.base_task.get(d_task.base_task_id);
                    if (baseTask) {
                        return baseTask.target;
                    }
                }
            }
            return 0;
        }

        public static get nowGrade(): number {
            let _list = UI_Activity.getPeriodTaskList(this.activityId) as game.ITaskProgress[];
            _list.sort((a, b) => {
                return a.id - b.id;
            });
            for (let i = 0; i < _list.length; i++) {
                if (!_list[i]['achieved']) {
                    return i;
                }
            }
            return _list.length;
        }
        private father: UI_Activity_Marathon_Main;
        private comItems: Laya.Sprite;
        private comTrain: Laya.Sprite;
        private comProgress: Laya.Sprite;
        private items: UI_TrainItem[];
        private txtTrainValue: Laya.HTMLDivElement;
        private imgProgress: Laya.Image;
        private comDetail: Laya.Sprite;
        private locking: boolean;
        private showIndex: number = -1;
        private tasks: IMarathonTrainInfo[];
        private itemRect: UIRect;
        private imgRewardBg: Laya.Image;
        private rewards: Laya.Button[];
        private lastValue: number = -1;

        constructor(me: Laya.Sprite, father: UI_Activity_Marathon_Main) {
            super(me);
            UI_Marathon_Train.Inst = this;
            this.father = father;
            this.comItems = this.me.getChildByName('items') as Laya.Sprite;
            this.items = [];
            for (let i = 0; i < this.comItems._childs.length; i++) {
                let com = this.comItems._childs[i].getChildAt(0);
                let item = new UI_TrainItem(com, this, i);
                this.items.push(item);
            }
            this.comProgress = this.me.getChildByName('progress') as Laya.Sprite;
            this.comDetail = this.me.getChildByName('detail') as Laya.Sprite;
            this.comDetail.on(Laya.Event.CLICK, this, (e: Laya.Event) => {
                e.stopPropagation();
            });
            this.comDetail.visible = false;
            this.comTrain = this.me.getChildByName('train') as Laya.Sprite;
            this.txtTrainValue = this.comTrain.getChildByName('value') as Laya.HTMLDivElement;
            this.imgProgress = this.comProgress.getChildByName('progress') as Laya.Image;
            this.imgRewardBg = this.comDetail.getChildByName('bg') as Laya.Image;
            for (let i = 0; i < 2; i++) {
                const reward = this.imgRewardBg.getChildByName(`item${i}`) as Laya.Button;
                reward.visible = false;
                this.rewards = this.rewards || [];
                this.rewards.push(reward);
            }
            if (GameMgr.client_language == 'jp') {
                this.txtTrainValue.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtTrainValue.style.font = '30px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtTrainValue.style.font = '30px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtTrainValue.style.font = '30px SimHei';
            } else {
                this.txtTrainValue.style.font = '30px NotoSansKR';
            }
            this.txtTrainValue.style.color = '#a27a50';
            this.txtTrainValue.style.leading = 0;
            this.txtTrainValue.style.letterSpacing = 0;
        }

        // 对齐待领取动画，不要乱七八糟的播放
        getAnimProgress(): number {
            for (let item of this.items) {
                let ani = item.aniFinish;
                if (ani && ani.isPlaying && ani.index > 0) {
                    return ani.index;
                }
            }
            return 0;
        }

        onClickTask(index: number) {
            if (this.locking) return;
            if (!this.tasks || !this.tasks[index]) return;
            if (this.tasks[index].achieved && !this.tasks[index].rewarded) {
                if (this.locking) return;
                this.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: this.tasks[index].id }, (err, res) => {
                    this.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                    } else {
                        this.tasks[index].rewarded = true;
                        UI_Activity.onPeriodTaskRewarded(this.tasks[index].id);
                        game.Tools.showRewards({ rewards: this.tasks[index].reward }, null);
                        this.items[index].refresh(this.tasks[index], true);
                    }
                });
            } else {
                if (index == this.showIndex) {
                    this.closeDetail();
                    return;
                }
                this.showIndex = index;
                this.refreshDetail(this.tasks[index]);
                Laya.Tween.clearAll(this.comDetail);
                this.comDetail.visible = true;
                this.comDetail.alpha = 1;
                this.comDetail.scale(1, 1);
                this.comDetail.x = 386 + 120 * index;
                UIBase.anim_pop_out(this.comDetail, null);
            }
        }

        refreshDetail(task: IMarathonTrainInfo) {
            for (let i = 0; i < this.rewards.length; i++) {
                const itemParent = this.rewards[i];
                if (i < task.reward.length) {
                    itemParent.visible = true;
                    const rewardId = task.reward[i].id;
                    const rewardCount = task.reward[i].count;
                    itemParent.x = 62 + 96 * i;
                    let imgItem = itemParent.getChildByName("item") as Laya.Image;
                    let txtCount = itemParent.getChildByName("count") as Laya.Label;
                    let comReceived = itemParent.getChildByName("received") as Laya.Sprite;
                    if (this.itemRect == null) {
                        this.itemRect = UIRect.CreateFromSprite(imgItem);
                    }
                    comReceived.visible = task.rewarded;
                    game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_Activity_Marathon_Main", true);
                    txtCount.text = rewardCount.toString();
                    itemParent.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) return;
                        UI_ItemDetail.Inst.show(rewardId);
                    })
                } else {
                    itemParent.visible = false;
                }
            }
            this.imgRewardBg.width = 28 + 96 * task.reward.length;
        }

        closeDetail() {
            if (this.showIndex == -1) return;
            this.showIndex = -1;
            Laya.Tween.clearAll(this.comDetail);
            UIBase.anim_pop_hide(this.comDetail, Laya.Handler.create(this, () => {
                this.comDetail.visible = false;
            }));
        }

        refreshData() {
            const tasks = UI_Activity.getPeriodTaskList(UI_Marathon_Train.activityId);
            this.tasks = tasks.map((item: game.ITaskProgress) => {
                let taskConfig = cfg.activity.period_task.get(item['id']);
                let baseTaskConfig = cfg.events.base_task.get(taskConfig.base_task_id);
                let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfig.reward);
                let rewards: {
                    id: number;
                    count: number;
                }[] = rewardStr.map(rewardStr => {
                    return { id: Number(rewardStr[0]), count: Number(rewardStr[1]) };
                });
                return {
                    id: item.id,
                    counter: item.counter,
                    achieved: item.achieved,
                    rewarded: item.rewarded,
                    failed: item.failed,
                    rewarded_time: item.rewarded_time,
                    target: baseTaskConfig.target,
                    reward: rewards
                }
            });
            this.tasks.sort((a, b) => {
                return a.id - b.id;
            });
        }

        refresh(): boolean {
            let completeState: boolean[];
            let lastGrade = 0;
            if (this.tasks && this.tasks.length > 0) {
                for (let i = 0; i < this.items.length; i++) {
                    this.items[i].refresh(this.tasks[i]);
                }
                for (let i = 0; i < this.tasks.length; i++) {
                    if (!this.tasks[i]['achieved']) {
                        lastGrade = i;
                        break;
                    }
                }
                completeState = this.tasks.map(task => task.achieved);
            }
            this.refreshData();
            let isUpgrade = UI_Marathon_Train.nowGrade > lastGrade;
            if (!this.tasks || this.tasks.length != 5) return false;
            this.enable = true;
            let targetValue = this.items.length > 0 ? this.tasks[this.tasks.length - 1].target : 0;
            const nowValue = Math.min(UI_Bag.get_item_count(UI_Activity_Marathon_Main.trainId), targetValue);
            const doAnim = this.lastValue >= 0 && this.lastValue != nowValue;
            const lastValue = this.lastValue;
            this.lastValue = nowValue;
            let str = game.Tools.strOfLocalization(26022008, ['[tag]' + nowValue + '[/tag]', targetValue.toString()]);
            this.txtTrainValue.innerHTML = game.Tools.ParseText(str, '#303548');
            let duration = 0;
            if (doAnim) {
                duration = 500 * (nowValue - lastValue) / this.tasks[0].target;
                const startTime = Laya.timer.currTimer;
                let value = lastValue;
                Laya.timer.frameLoop(1, this, () => {
                    if (value < nowValue) {
                        value = lastValue + (nowValue - lastValue) * (Laya.timer.currTimer - startTime) / duration;
                        this.imgProgress.width = this.getProgressWidth(value);
                        for (let i = 0; i < this.items.length; i++) {
                            if (value >= this.tasks[i].target && completeState[i] != this.tasks[i].achieved) {
                                this.items[i].refresh(this.tasks[i]);
                                completeState[i] = this.tasks[i].achieved;
                            }
                        }
                    } else {
                        Laya.timer.clearAll(this);
                        this.imgProgress.width = this.getProgressWidth(nowValue);
                    }
                });
            } else {
                for (let i = 0; i < this.items.length; i++) {
                    this.items[i].refresh(this.tasks[i]);
                }
                this.imgProgress.width = this.getProgressWidth(nowValue);
            }
            return doAnim && isUpgrade;
        }


        getProgressWidth(value: number): number {
            let width = 0;
            let lastProgress = 0;
            const gradeWidth = [85, 49, 49, 49, 49];
            for (let i = 0; i < this.tasks.length; i++) {
                const target = this.tasks[i].target;
                if (value >= target) {
                    width = 156 + 120 * i;
                    lastProgress = target;
                } else {
                    width += (value - lastProgress) / (target - lastProgress) * gradeWidth[i];
                    break;
                }
            }
            return Math.min(Math.max(width, 4), this.comProgress.width);
        }

        public hide(): void {
            for (let item of this.items) {
                item.reset();
            }
        }
    }
}