module uiscript {
  // 为了避免大 int 发生精度问题，减少 a c m 的取值
  const a = 110351;
  const c = 12345;
  const m = 2 ** 16 - 1;

  export class LGCRandom {
    constructor(seed: number) {
      this.seed_ = seed;
      this.state_ = this.seed_ % m;
    }

    jumpTo(n: number) {
      const [A, C] = this.powerLCGPair(n);
      this.state_ = (this.mulMod(A, this.seed_) + C) % m;
    }

    next() {
      this.state_ = (a * this.state_ + c) % m;
    }

    randomFloat() {
      this.next();
      const randomFloat = this.state_ / m;
      return randomFloat - Math.trunc(randomFloat);
    }

    randomInt(min: number, max: number) {
      this.next();
      const randomFloat = this.state_ / m;
      const randomInt = Math.floor(randomFloat * (max - min + 1)) + min;
      return randomInt;
    }

    randomByWeight<T>(candidates: T[], getWeight: (candidate: T, index: number) => number): T | null {
      if (!candidates || candidates.length === 0)
        return null;

      const weights = candidates.map(getWeight);
      const sum = weights.reduce((p, c) => p + c, 0);
      let rand = this.randomInt(1, sum);
      for (let i = 0; i < weights.length; i++) {
        if (rand <= weights[i])
          return candidates[i];
        rand -= weights[i];
      }
      return null;
    }

    private mulMod(x: number, y: number): number {
      let a1 = x % m;
      let b1 = y % m;
      let r = 0;
      while (b1 > 0) {
        if (b1 & 1) r = (r + a1) % m;
        a1 = (a1 + a1) % m;
        b1 = Math.floor(b1 / 2);
      }
      return r;
    }

    private powerLCGPair(n: number): [number, number] {
      let resultA = 1 % m;
      let resultC = 0;
      let baseA = a % m;
      let baseC = c % m;
      let power = n;
      while (power > 0) {
        if (power & 1) {
          const newResultC = (this.mulMod(baseA, resultC) + baseC) % m;
          resultA = this.mulMod(resultA, baseA);
          resultC = newResultC;
        }
        const newBaseC = (this.mulMod(baseA, baseC) + baseC) % m;
        baseA = this.mulMod(baseA, baseA);
        baseC = newBaseC;
        power = Math.floor(power / 2);
      }
      return [resultA, resultC];
    }

    get state() {
      return this.state_;
    }

    get seed() {
      return this.seed_;
    }

    private seed_: number;
    private state_: number;
  }

}
