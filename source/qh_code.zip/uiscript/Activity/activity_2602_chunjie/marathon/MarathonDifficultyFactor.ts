module uiscript {
  export interface IMarathonWallDifficultyFactorParams {
    mustFeverCount: number; // 必定出现福牌次数
    finishHandsCheckRate: number; // 出现能完成手牌中搭子的牌的概率（如手中有一对，则再给一张相同的牌），如果没有能完成的搭子，则直接降级到 strongHandsCheck
    strongHandsCheckRate: number; // 出现能和手牌组成搭子的牌的概率（强搭子，必定是数字相邻或者相同，只会对单张/对子生效）
    weakHandsCheckRate: number; // 出现能和手牌组成搭子的牌的概率（弱搭子，形成嵌张，只会对单张/对子生效）
    finalMode: number; // 最终模式，禁止福牌与道具，所有牌全随机
  }

  export enum MarathonCheckLevel {
    Finish = 1,
    Strong = 2,
    Weak = 3,
    None = 99,
  }

  export class MarathonDifficultyFactor {
    constructor(params: IMarathonWallDifficultyFactorParams, random: LGCRandom) {
      this.mustFeverCount_ = params.mustFeverCount;
      this.finishHandsCheckRate_ = params.finishHandsCheckRate;
      this.strongHandsCheckRate_ = params.strongHandsCheckRate;
      this.weakHandsCheckRate_ = params.weakHandsCheckRate;
      this.finalMode_ = params.finalMode;

      this.random_ = random;
    }

    generateMustFeverTiles(feverTiles: string[]) {
      if (this.finalMode_)
        return [];
      const result: string[] = [];

      while (result.length < this.mustFeverCount_) {
        const tile = this.random_.randomByWeight(feverTiles, () => 1);
        if (!tile)
          throw new Error('random fever tile failed, return null');
        result.push(tile);
      }

      return result;
    }

    getCheckLevel() {
      const isFinish = this.random_.randomInt(0, 100) < this.finishHandsCheckRate_;
      if (isFinish)
        return MarathonCheckLevel.Finish;

      const isStrong = this.random_.randomInt(0, 100) < this.strongHandsCheckRate_;
      if (isStrong)
        return MarathonCheckLevel.Strong;

      const isWeak = this.random_.randomInt(0, 100) < this.weakHandsCheckRate_;
      if (isWeak)
        return MarathonCheckLevel.Weak;

      return MarathonCheckLevel.None;
    }

    // 重写后的generateHandsCheckTile方法（移除Set<string>）
    generateHandsCheckTile(hands: string[], level: MarathonCheckLevel) {
      if (!hands || !hands.length || this.finalMode_)
        return [];

      const splitHands = MarathonUtility.splitHands(hands);

      // 替换Set为数组，使用数组去重逻辑
      let finishTiles: string[] = [];
      // 处理pair中的tile
      for (const tile of splitHands.pair) {
        if (!finishTiles.includes(tile)) {
          finishTiles.push(tile);
        }
      }

      // 处理partial中的waiting tile
      for (const { waiting } of splitHands.partial) {
        for (const tile of waiting) {
          if (!finishTiles.includes(tile)) {
            finishTiles.push(tile);
          }
        }
      }

      if (level <= MarathonCheckLevel.Finish && finishTiles.length > 0) {
        return finishTiles.sort();
      }

      // 替换Set为数组，存储strongTile
      let strongTile: string[] = [];
      // 合并single和pair数组并遍历
      const combinedTiles = [...splitHands.single, ...splitHands.pair];
      for (const tile of combinedTiles) {
        // 如果不在finishTiles中则添加
        if (!finishTiles.includes(tile) && !strongTile.includes(tile)) {
          strongTile.push(tile);
        }

        const preTile = MarathonUtility.getPreTile(tile);
        const nextTile = MarathonUtility.getNextTile(tile);

        // 处理前置tile
        if (preTile && !finishTiles.includes(preTile) && !strongTile.includes(preTile)) {
          strongTile.push(preTile);
        }

        // 处理后置tile
        if (nextTile && !finishTiles.includes(nextTile) && !strongTile.includes(nextTile)) {
          strongTile.push(nextTile);
        }
      }

      if (level <= MarathonCheckLevel.Strong && strongTile.length > 0) {
        return strongTile.sort();
      }

      // 替换Set为数组，存储weakTile
      let weakTile: string[] = [];
      for (const tile of combinedTiles) {
        const preTile = MarathonUtility.getPreTile(tile);
        const nextTile = MarathonUtility.getNextTile(tile);

        // 处理前前tile
        if (preTile) {
          const prePreTile = MarathonUtility.getPreTile(preTile);
          if (prePreTile && !finishTiles.includes(prePreTile) && !strongTile.includes(prePreTile) && !weakTile.includes(prePreTile)) {
            weakTile.push(prePreTile);
          }
        }

        // 处理后后tile
        if (nextTile) {
          const nextNextTile = MarathonUtility.getNextTile(nextTile);
          if (nextNextTile && !finishTiles.includes(nextNextTile) && !strongTile.includes(nextNextTile) && !weakTile.includes(nextNextTile)) {
            weakTile.push(nextNextTile);
          }
        }
      }

      if (level <= MarathonCheckLevel.Weak) {
        return weakTile.sort();
      }

      return [];
    }

    private mustFeverCount_: number;
    private finishHandsCheckRate_: number;
    private strongHandsCheckRate_: number;
    private weakHandsCheckRate_: number;
    private finalMode_: number;

    private random_: LGCRandom;
  }

}

