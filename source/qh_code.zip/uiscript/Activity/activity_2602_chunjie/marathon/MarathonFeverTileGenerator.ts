module uiscript {
  const FeverTileCount = 3; // 同一个批次有几张福牌

  export class MarathonFeverTileGenerator {
    constructor(seed: number, count: number) {
      this.random_ = new LGCRandom(seed);
      this.count_ = count;
    }

    generateFeverTile(weightMap: Map<string, number>) {
      // 保留原逻辑：将 Map 转换为 {tile, weight} 数组
      const candidate: { tile: string; weight: number }[] = [];
      weightMap.forEach((weight, tile) => {
        candidate.push({ tile, weight });
      });


      this.random_.jumpTo(this.count_ * FeverTileCount);

      // 替换 Set<string> 为 string[]，用数组实现去重
      const result: string[] = [];
      // 循环条件：数组长度 < 目标数量（等价于原 Set.size < FeverTileCount）
      while (result.length < FeverTileCount) {
        // 权重回调：已存在的 tile 权重置为 0（等价于原 result.has(t.tile)）
        const ret = this.random_.randomByWeight(candidate, (t) =>
          result.includes(t.tile) ? 0 : t.weight
        );
        if (!ret)
          throw new Error('random fever tile failed');

        // 双重保险：确保不会重复添加（与原 Set.add 逻辑一致）
        if (!result.includes(ret.tile)) {
          result.push(ret.tile);
        }
      }

      // 原代码返回 [...result]（Set 转数组），现在直接返回数组即可
      return result;
    }

    private random_: LGCRandom;
    private count_: number; // 第几轮福牌
  }
}
