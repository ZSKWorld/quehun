module uiscript {

    export interface IMarathonActivityRaceData {
        id: string;
        random_seed: number;
        start_time: number;
    }

    export enum MarathonRewardType {
        Straight = 1,
        Pair = 2,
        Fever = 3,
        PointItem = 4,
        TimeItem = 5,
    }

    export interface IMarathonActivityHandsConsumedResult {
        type: MarathonHandsCombinationType;
        tiles: string[];
    }

    /**
     * 马拉松竞赛模拟类，负责管理马拉松游戏的核心逻辑，包括回合推进、手牌管理、 Fever 状态、分数计算等
     */
    export class MarathonRaceSimulation {
        /**
         * 构造函数，初始化马拉松竞赛模拟的基础状态
         * @param activityId - 活动ID，用于关联活动配置
         * @param remainTicks - 初始剩余时间（ ticks 为时间单位）
         * @param seed - 随机种子，用于保证随机生成逻辑的一致性
         */
        constructor(activityId: number, remainTicks: number, seed: number) {
            this.seed_ = seed;                 // 随机种子
            this.activityId_ = activityId;     // 活动ID
            this.hands_ = [];                  // 当前持有的手牌列表（字符串形式）
            this.feverStartRounds_ = [];       // 记录所有Fever状态开始的回合
            this.round_ = 1;                   // 当前回合数，从1开始
            this.point_ = 0;                   // 累计分数
            this.usedTicks_ = 0;               // 已使用的时间（ticks）
            this.consumedFeverTiles_ = [];     // 已消耗的Fever牌列表

            this.walls_ = [];                  // 墙列表，存储生成的墙数据
            this.remainTicks_ = remainTicks;   // 剩余时间（ticks）
            this.distance_ = 0;                 // 已经跑的距离
            this.wall_tests = [];
            this.seedRandom_ = new LGCRandom(seed); // 用于生成随机数的随机数生成器实例
        }

        /**
         * 获取当前墙列表的深拷贝，防止外部直接修改内部状态
         * @returns 墙列表的深拷贝，类型为IMarathonWallGeneratorResult[]
         */
        get walls(): IMarathonWallGeneratorResult[] {
            return [...this.walls_];
        }

        /**
         * 获取当前手牌列表，转换为MJPai实例列表返回
         * @returns 手牌的MJPai实例列表
         */
        get hands(): string[] {
            return [...this.hands_];
        }

        /**
         * 获取Fever牌列表，转换为MJPai实例列表返回
         * @returns Fever牌的MJPai实例列表
         */
        get feverTiles(): string[] {
            return [...this.feverTiles_];
        }

        /**
         * 获取已消耗的Fever牌列表（根据当前是否在Fever状态返回不同结果）
         * - 若处于Fever状态，返回当前Fever牌列表
         * - 否则返回已消耗的Fever牌列表
         * @returns 已消耗Fever牌的MJPai实例列表
         */
        get consumedFeverTiles(): string[] {
            if (this.isInFever()) {
                return this.feverTiles;
            }
            return [...this.consumedFeverTiles_];
        }

        /**
         * 生成新的墙数据（最多维持3个墙），用于推进游戏流程
         * @returns 新生成的墙列表
         */
        updateWallData() {
            // 获取Fever牌权重和基础墙牌权重配置
            const feverWeight = MarathonData.Inst.tileFeverWeight;
            const wallWeight = MarathonData.Inst.tileBaseWeight;

            // 生成Fever牌列表
            const feverTilesGenerator = new MarathonFeverTileGenerator(this.seed_, this.feverCount_);
            this.feverTiles_ = feverTilesGenerator.generateFeverTile(feverWeight);

            // 确保墙列表数量不超过3个，不足则补充生成
            while (this.walls_.length < 3) {
                const targetRound = this.round_ + this.walls_.length; // 目标回合（当前回合 + 已有墙数量）
                const wallCfg = MarathonData.Inst.getWall(targetRound); // 获取目标回合的墙配置

                // 构建难度因子参数（用于控制墙的生成难度）
                const difficultyFactor: IMarathonWallDifficultyFactorParams = {
                    mustFeverCount: wallCfg.must_fever_count,         // 必须包含的Fever牌数量
                    finishHandsCheckRate: wallCfg.finish_hands_check, // 完成手牌检查率
                    strongHandsCheckRate: wallCfg.strong_hands_check, // 强手牌检查率
                    weakHandsCheckRate: wallCfg.weak_hands_check,     // 弱手牌检查率
                    finalMode: wallCfg.final_mode,                      // 是否禁止Fever牌
                };
                // 获取目标回合的道具权重配置
                const itemWeight = MarathonData.Inst.getItemWeightMap(targetRound);

                // 生成新墙并添加到墙列表
                const wall = new MarathonWallGenerator({
                    seedRandom: this.seedRandom_,
                    round: targetRound,
                    feverStartRound: this.feverStartRound_,
                    feverTiles: this.feverTiles_,
                    hands: this.hands_,

                    tileWeightMap: wallWeight,
                    itemRate: wallCfg.item_rate,
                    itemWeightMap: itemWeight,
                }, difficultyFactor);
                this.walls_.push(wall.generate());
                let info = this.walls_[this.walls_.length - 1];
                this.wall_tests.push({
                    seed: this.seed_,
                    round: targetRound,
                    fever_count: this.feverCount_,
                    fever_start_round: this.feverStartRound_,
                    hands: [...this.hands_],
                    id: targetRound,
                    wall: info.wall,
                });
            }
        }

        /**
         * 处理踢牌操作，包括消耗墙、计算奖励、更新状态等核心逻辑
         * @param tile - 踢出的牌（字符串形式）
         * @param items - 使用的道具列表
         * @returns 操作是否成功
         */
        collect(tile: string, items: MarathonItemType[]): IMarathonCheckData {
            // 取出当前墙（若没有则操作失败）
            const currentWall = this.walls_.shift();
            if (!currentWall)
                return null;

            const activity = MarathonData.Inst.activityConfig; // 获取活动配置
            const isInFever = this.isInFever(); // 判断当前是否处于Fever状态

            // 处理使用的道具，计算道具奖励（分数和时间）
            for (const item of items) {
                // 检查道具是否在当前墙中存在
                const index = currentWall.items.findIndex(i => i.type === item);
                if (index < 0)
                    return null;

                // 道具奖励映射表（道具类型 -> 奖励类型）
                const itemRewardMap = {
                    [MarathonItemType.Point]: MarathonRewardType.PointItem,
                    [MarathonItemType.Time]: MarathonRewardType.TimeItem,
                };

                // 计算并添加道具奖励
                const reward = MarathonData.Inst.getReward(itemRewardMap[item]);
                if (reward.point) {
                    this.point_ += reward.point;
                }
                if (reward.time) {
                    this.remainTicks_ += reward.time;
                }
            }

            // 获取当前回合的墙配置
            const wallCfg = MarathonData.Inst.getWall(this.round_);
            // 计算奖励倍率（Fever状态使用活动配置的倍率，否则使用墙配置的速度倍率）
            const bonus = isInFever ? activity.fever_time_bonus : wallCfg.speed_bonus;
            let operation: IMarathonOperation;
            // 计算当前回合消耗的时间（Fever状态使用活动配置速度，否则使用墙配置速度）
            const realSpeed = isInFever ? activity.fever_speed : wallCfg.speed;
            if (this.remainTicks_ >= realSpeed) {
                if (tile) {
                    // 添加手牌并检查是否形成可消耗的组合（如对子、顺子等）
                    const consumed = this.addHands(tile);
                    if (consumed) {
                        const consumeTiles = [tile, ...consumed.tiles];
                        // 计算并添加手牌组合奖励
                        const reward = this.getConsumedHandsReward(consumed);
                        if (reward) {
                            let point = Math.floor(reward.point * consumeTiles.length * bonus / 100);
                            let time = 0;
                            this.point_ += point;
                            // 非Fever状态下添加时间奖励
                            if (!isInFever) {
                                time = reward.time * consumeTiles.length;
                                this.remainTicks_ += time;
                            }
                            operation = {
                                type: 0,
                                consume: {
                                    type: consumed.type,
                                    tiles: consumeTiles,
                                },
                                reward: {
                                    point,
                                    time,
                                }
                            };
                        }

                        // 处理Fever牌消耗逻辑
                        for (const tile of consumeTiles) {
                            if (this.feverTiles_.includes(tile)) {
                                // 计算并添加Fever牌奖励
                                const reward = MarathonData.Inst.getReward(MarathonRewardType.Fever);
                                const point = Math.floor(reward.point * bonus / 100);
                                this.point_ += point;
                                operation.reward.point += point;
                                if (!isInFever) {
                                    this.remainTicks_ += reward.time;
                                    operation.reward.time += reward.time;
                                    // 记录已消耗的Fever牌（去重）
                                    if (this.consumedFeverTiles_.indexOf(tile) < 0) {
                                        this.consumedFeverTiles_.push(tile);
                                    }
                                }
                            }
                        }

                        // 若所有Fever牌都已消耗，触发新的Fever状态
                        if (this.consumedFeverTiles_.length === this.feverTiles_.length) {
                            this.feverStartRounds_.push(this.round_); // 记录Fever开始回合
                            this.consumedFeverTiles_ = []; // 重置已消耗Fever牌列表
                            this.walls_ = []; // 清空墙列表（后续会重新生成）
                        }
                    }

                }
                const speed = isInFever ? 0 : wallCfg.speed;
                this.remainTicks_ -= speed; // 减少剩余时间
                this.usedTicks_ += realSpeed;   // 增加已使用时间
                this.distance_ += MarathonConstant.RANDOM_ITEM_RATIO; // 增加跑步距离
            } else {
                const realSpeed = isInFever ? activity.fever_speed : wallCfg.speed;
                this.distance_ += MarathonConstant.RANDOM_ITEM_RATIO * (this.remainTicks_ / realSpeed); // 增加跑步距离
                this.usedTicks_ += this.remainTicks_;
                this.remainTicks_ = 0;
            }

            const checkData: IMarathonCheckData = {
                round: this.round,
                item: items,
                tick: this.remainTicks_,
                tile: tile,
                point: this.point_,
                operation: operation,
                time_end: this.remainTicks_ <= 0 ? 1 : 0,
            };
            // 推进到下一回合
            this.round_++;
            return checkData;
        }

        checkGameEnd(): boolean {
            const currentWall = this.walls_[0];
            if (!currentWall) return true;
            const isInFever = this.isInFever(); // 判断当前是否处于Fever状态
            if (isInFever) return false;
            const wallCfg = MarathonData.Inst.getWall(this.round_);
            const extraTick = MarathonConstant.tick_extra_base * wallCfg.speed / 90;
            if (this.remainTicks_ < wallCfg.speed + extraTick) return true;
            return false;
        }

        /**
         * 获取当前累计分数
         */
        get point() {
            return this.point_;
        }

        /**
         * 获取当前剩余时间（ticks）
         */
        get remainTicks() {
            return this.remainTicks_;
        }

        /**
        * 获取已经跑的距离（米）
        */
        get distance() {
            return this.distance_;
        }


        /**
         * 获取已使用的时间（ticks）
         */
        get usedTick() {
            return this.usedTicks_;
        }

        /**
         * 获取当前回合数
         */
        get round() {
            return this.round_;
        }

        /**
         * 判断当前是否处于Fever状态
         * @returns 是否处于Fever状态（true为是，false为否）
         */
        isInFever() {
            const activity = MarathonData.Inst.activityConfig;
            // Fever状态判断逻辑：存在最近的Fever开始回合，且当前回合未超过Fever持续时长
            const isInFever = this.feverStartRound_ && this.feverStartRound_ + activity.fever_time_duration >= this.round_;
            return isInFever;
        }

        /**
         * 根据手牌组合类型获取对应的奖励配置
         * @param consumed - 消耗的手牌组合结果
         * @returns 奖励配置
         */
        private getConsumedHandsReward(consumed: IMarathonActivityHandsConsumedResult) {
            switch (consumed.type) {
                case MarathonHandsCombinationType.Pair: // 对子类型
                    return MarathonData.Inst.getReward(MarathonRewardType.Pair);
                case MarathonHandsCombinationType.Straight: // 顺子类型
                    return MarathonData.Inst.getReward(MarathonRewardType.Straight);
                default:
                    return null;
            }
        }

        /**
         * 添加手牌并检查是否能形成可消耗的组合（如对子、顺子等）
         * @param tile - 要添加的牌
         * @returns 若形成可消耗组合，返回组合信息；否则返回null
         */
        private addHands(tile: string) {
            // 解析当前手牌+新牌是否能形成可消耗组合
            const parsed = MarathonUtility.parseHands(this.hands_, tile);
            if (!parsed) {
                // 无法形成组合，将牌添加到手牌列表
                this.hands_.push(tile);
                MarathonData.sortPai(this.hands_);
                return null;
            }
            // 形成组合，从手牌中移除组合包含的牌
            for (const t of parsed.tiles) {
                const index = this.hands_.indexOf(t);
                this.hands_.splice(index, 1);
            }
            return parsed;
        }

        /**
         * 获取最近一次Fever状态开始的回合（私有属性访问器）
         */
        private get feverStartRound_() {
            if (!this.feverStartRounds_.length)
                return 0;
            return this.feverStartRounds_[this.feverStartRounds_.length - 1];
        }

        /**
         * 获取Fever状态的累计次数（私有属性访问器）
         * - 若当前处于Fever状态，返回次数-1（排除当前未结束的Fever）
         * - 否则返回总次数
         */
        private get feverCount_() {
            const isInFever = this.isInFever();
            return isInFever ? this.feverStartRounds_.length - 1 : this.feverStartRounds_.length;
        }

        // 私有属性定义
        private seed_: number;               // 随机种子
        private activityId_: number;         // 活动ID
        private round_: number;              // 当前回合数
        private hands_: string[];            // 当前手牌列表（字符串形式）
        private feverTiles_: string[];       // Fever牌列表（字符串形式）
        private feverStartRounds_: number[]; // Fever状态开始回合记录
        private walls_: IMarathonWallGeneratorResult[]; // 墙列表
        private consumedFeverTiles_: string[]; // 已消耗的Fever牌列表
        private usedTicks_: number;          // 已使用时间（ticks）
        private point_: number;              // 累计分数
        private remainTicks_: number;        // 剩余时间（ticks）
        private distance_: number;            // 已经跑的距离
        private seedRandom_: LGCRandom;     // 用于生成随机数的随机数生成器实例
        public wall_tests: game.IReqMarathonActivityTest_MarathonWallTest[] = [];
    }
}
