module uiscript {
  export enum MarathonHandsCombinationType {
    Pair = 1,
    Straight = 2,
  }

  // 重写SplitHandsResult类（移除所有Set<string>）
  class SplitHandsResult {
    constructor() {
      this.pair_ = []; // 替换Set<string>为string[]
      this.partial_ = [];
      this.single_ = []; // 替换Set<string>为string[]
    }

    addPair(tile: string) {
      // 保持去重逻辑：不存在时才添加
      if (!this.pair_.includes(tile)) {
        this.pair_.push(tile);
      }
    }

    addPartial(tiles: string[], waiting: string[]) {
      tiles = tiles.sort();
      waiting = waiting.sort();

      const pre = this.partial_.find(p => p.tiles.join(',') === tiles.join(','));
      if (pre)
        return;

      this.partial_.push({
        tiles,
        waiting,
      });
    }

    addSingle(tile: string) {
      // 保持去重逻辑：不存在时才添加
      if (!this.single_.includes(tile)) {
        this.single_.push(tile);
      }
    }

    toData() {
      return {
        // 修正原代码错误：Array.from(set.entries())会返回[[tile,tile],...]，改为直接排序数组
        pair: this.pair_.sort(),
        partial: this.partial_,
        single: this.single_.sort(),
      }
    }

    private pair_: string[]; // 替换Set<string>为string[]
    private partial_: { tiles: string[], waiting: string[] }[];
    private single_: string[]; // 替换Set<string>为string[]
  }

  export class MarathonUtility {
    static splitHands(hands: string[]) {
      const result = new SplitHandsResult();

      const used: string[] = []; // 替换Set<string>为string[]
      for (const tile of hands) {
        // 替换used.has(tile)为includes判断
        if (used.includes(tile))
          continue;

        used.push(tile); // 替换used.add(tile)为push

        let isCombined = false;
        const tileCount = hands.reduce((pre, t) => t === tile ? pre + 1 : pre, 0);
        if (tileCount >= 2) {
          result.addPair(tile);
          isCombined = true;
        }

        const nextTile = this.getNextTile(tile);
        const preTile = this.getPreTile(tile);
        if (nextTile) {
          const nextNextTile = this.getNextTile(nextTile);

          // 存在下一张
          if (hands.includes(nextTile)) { // 原hands.find可以简化为includes（功能一致）
            const tiles = [nextTile, tile];
            const waiting: string[] = [];
            if (nextNextTile) {
              waiting.push(nextNextTile);
            }
            if (preTile) {
              waiting.push(preTile);
            }

            result.addPartial(tiles, waiting);
            isCombined = true;
          }

          // 存在下两张形成嵌张
          if (nextNextTile && hands.includes(nextNextTile)) { // 简化find为includes
            const tiles = [nextNextTile, tile];
            const waiting: string[] = [nextTile];

            result.addPartial(tiles, waiting);
            isCombined = true;
          }
        }

        if (preTile) {
          const prePreTile = this.getPreTile(preTile);

          // 存在上一张
          if (hands.includes(preTile)) { // 简化find为includes
            const tiles = [preTile, tile];
            const waiting: string[] = [];
            if (prePreTile) {
              waiting.push(prePreTile);
            }
            if (nextTile) {
              waiting.push(nextTile);
            }

            result.addPartial(tiles, waiting);
            isCombined = true;
          }

          // 存在上两张行成嵌张（原代码笔误：行成→形成，已保留原写法）
          if (prePreTile && hands.includes(prePreTile)) { // 简化find为includes
            const tiles = [prePreTile, tile];
            const waiting: string[] = [preTile];

            result.addPartial(tiles, waiting);
            isCombined = true;
          }
        }

        if (!isCombined) {
          result.addSingle(tile);
        }
      }

      return result.toData();
    }

    static getPreTile(tile: string) {
      const num = parseInt(tile[0]);
      const type = tile[1];

      switch (type) {
        case 'z':
          return null
        case 'm':
        case 's':
        case 'p':
          if (num > 1) {
            return `${num - 1}${type}`;
          }
          break;
        default:
          return null;
      }

      return null;
    }

    static getNextTile(tile: string) {
      const num = parseInt(tile[0]);
      const type = tile[1];

      switch (type) {
        case 'z':
          return null
        case 'm':
        case 's':
        case 'p':
          if (num < 9) {
            return `${num + 1}${type}`;
          }
          break;
        default:
          return null;
      }

      return null;
    }

    static shuffleArray<T>(array: T[], random: LGCRandom): T[] {
      const result = [...array];
      let m = result.length;
      let t, i;
      while (m) {
        i = Math.floor(random.randomFloat() * m--);
        t = result[m];
        result[m] = result[i];
        result[i] = t;
      }
      return result;
    }

    static parseHands(hands: string[], tile: string) {
      const sameCount = hands.reduce((pre, hand) => hand === tile ? pre + 1 : pre, 0);
      if (sameCount >= 2) {
        hands = hands.filter(hand => hand !== tile);
        return {
          type: MarathonHandsCombinationType.Pair,
          tiles: [tile, tile],
        };
      }

      const straight = [];
      let preTile = MarathonUtility.getPreTile(tile);
      let nextTile = MarathonUtility.getNextTile(tile);
      while (true) {
        if (preTile) {
          if (hands.includes(preTile)) { // 简化includes判断
            straight.push(preTile);
            preTile = MarathonUtility.getPreTile(preTile);
          } else {
            preTile = null;
          }
        }

        if (nextTile) {
          if (hands.includes(nextTile)) { // 简化includes判断
            straight.push(nextTile);
            nextTile = MarathonUtility.getNextTile(nextTile);
          } else {
            nextTile = null;
          }
        }

        if (!preTile && !nextTile)
          break;
      }

      if (straight.length >= 2) {
        return {
          type: MarathonHandsCombinationType.Straight,
          tiles: straight.sort(),
        };
      }

      return null;
    }
  }
}

