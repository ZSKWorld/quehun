module uiscript {

  export enum MarathonItemType {
    Time = 1,
    Point = 2,
  }

  export interface IMarathonWallGeneratorParams {
    seedRandom: LGCRandom; // 用于生成随机数的随机数生成器实例
    round: number;
    feverTiles: string[];
    feverStartRound: number;
    hands: string[];

    tileWeightMap: Map<string, number>;

    itemRate: number;
    itemWeightMap: Map<number, number>;
  }

  export interface IMarathonWallGeneratorResult {
    wallSeed: number;
    isFeverTime: boolean;
    wall: string[];
    mustFeverTile?: string[];
    check_level?: number;
    checkCandidateTiles?: string[];
    checkFinalTile?: string | null;
    beforeShuffleTiles?: string[];
    items: IMarathonWallItem[];
    round: number;
  }

  export interface IMarathonWallItem {
    type: MarathonItemType; // 对应 marathon.xlsx.marathon_item_group.type
    x: number; // 列，0开始
    y: number; // 行，0开始
  }

  export class MarathonWallGenerator {
    constructor(params: IMarathonWallGeneratorParams, difficultyFactor: IMarathonWallDifficultyFactorParams) {
      this.seedRandom_ = params.seedRandom;
      this.round_ = params.round;
      this.feverStartRound_ = params.feverStartRound;
      this.feverTiles_ = params.feverTiles;
      this.hands_ = params.hands;
      this.tileWeightMap_ = params.tileWeightMap;
      this.itemRate_ = params.itemRate;
      this.itemWeightMap_ = params.itemWeightMap;
      this.roundConfig_ = MarathonData.Inst.getWall(this.round_);

      const wallSeed = this.generateWallSeed();
      this.wallRandom_ = new LGCRandom(wallSeed);
      this.difficultyFactor_ = new MarathonDifficultyFactor(difficultyFactor, this.wallRandom_);
    }

    // 会提供步骤中所有值
    generate(): IMarathonWallGeneratorResult {
      // 处于 fever 状态
      const activity = MarathonData.Inst.activityConfig;
      if (this.feverStartRound_ && this.feverStartRound_ + activity.fever_time_duration >= this.round_) {
        this.seedRandom_.jumpTo(this.feverStartRound_);
        const feverTile = this.seedRandom_.randomByWeight(this.feverTiles_, () => 1);
        return {
          wallSeed: this.wallRandom_.seed,
          isFeverTime: true,
          wall: new Array(MarathonConstant.WALL_TILE_COUNT).fill(feverTile),
          items: [{
            x: this.wallRandom_.randomInt(0, 4),
            y: this.wallRandom_.randomInt(0, activity.wall_tile_count - 1),
            type: activity.fever_item_type,
          }],
          round: this.round_,
        };
      }

      const items: IMarathonWallItem[] = [];
      if (this.round_ !== 1 && this.itemRate_ > this.wallRandom_.randomInt(0, 100)) {
        const candidate: {
          type: number;
          weight: number;
        }[] = [];
        this.itemWeightMap_.forEach((weight, type) => {
          candidate.push({ type, weight });
        });
        const ret = this.wallRandom_.randomByWeight(candidate, (c) => c.weight);
        if (ret) {
          items.push({
            x: this.wallRandom_.randomInt(0, MarathonConstant.RANDOM_ITEM_AREA),
            y: this.wallRandom_.randomInt(0, MarathonConstant.WALL_TILE_COUNT - 1),
            type: ret.type,
          });
        }
      }

      const mustTile: string[] = [];

      // step_value: must_fever_tiles
      const mustFeverTiles = this.difficultyFactor_.generateMustFeverTiles(this.feverTiles_);
      for (const tile of mustFeverTiles) {
        mustTile.push(tile);
      }

      // step_value: check_level
      const checkLevel = this.difficultyFactor_.getCheckLevel();

      // step_value: check_candidate_tiles
      const handsCheckTiles = this.difficultyFactor_.generateHandsCheckTile(this.hands_, checkLevel);

      // step_value: check_final_tile
      const selectedTile = this.wallRandom_.randomByWeight(handsCheckTiles, () => 1);
      if (selectedTile) {
        mustTile.push(selectedTile);
      }
      // step_value: before_shuffle_tiles
      const emptyCount = activity.wall_empty_pos.filter(p => !!p).length;
      const realWallCount = MarathonConstant.WALL_TILE_COUNT - emptyCount;
      const wall = [...mustTile.slice(0, realWallCount)];
      while (wall.length < realWallCount) {
        const tile = this.randomWallTile(wall);
        wall.push(tile);
      }
      const shuffledWall = MarathonUtility.shuffleArray(wall, this.wallRandom_);
      for (const pos of activity.wall_empty_pos) {
        shuffledWall.splice(pos, 0, '');
      }
      return {
        wallSeed: this.wallRandom_.seed,
        isFeverTime: false,
        mustFeverTile: mustFeverTiles,
        check_level: checkLevel,
        checkCandidateTiles: handsCheckTiles,
        checkFinalTile: selectedTile,
        beforeShuffleTiles: wall,
        wall: shuffledWall,
        items,
        round: this.round_,
      };
    }

    private randomWallTile(wall: string[]) {
      const nearFeverTile = new Set<string>();
      const wallCfg = MarathonData.Inst.getWall(this.round_);

      for (const tile of this.feverTiles_) {
        const nextTile = MarathonUtility.getNextTile(tile);
        if (nextTile) {
          nearFeverTile.add(nextTile);

          const nextNextTile = MarathonUtility.getNextTile(nextTile);
          if (nextNextTile)
            nearFeverTile.add(nextNextTile);
        }

        const preTile = MarathonUtility.getPreTile(tile);
        if (preTile) {
          nearFeverTile.add(preTile);

          const prePreTile = MarathonUtility.getPreTile(preTile);
          if (prePreTile)
            nearFeverTile.add(prePreTile);
        }
      }

      for (const tile of this.feverTiles_) {
        nearFeverTile.delete(tile);
      }

      const candidates = Array.from(this.tileWeightMap_.entries()).map(([tile, weight]) => {
        if (wallCfg.final_mode) {
          return {
            tile,
            weight: this.feverTiles_.includes(tile) ? 0 : weight,
          };
        }

        if (this.feverTiles_.includes(tile)) {
          weight += this.roundConfig_.fever_weight_addition;
        }

        if (nearFeverTile.has(tile)) {
          weight += this.roundConfig_.near_fever_weight_addition;
        }

        const tileCount = wall.reduce((pre, t) => t === tile ? pre + 1 : pre, 0);
        if (tileCount >= MarathonData.Inst.activityConfig.wall_max_same_tile) {
          weight = 0;
        }

        return {
          tile,
          weight,
        };
      });

      const resultTile = this.wallRandom_.randomByWeight(candidates, c => c.weight);
      if (!resultTile)
        throw new Error('random wall tile failed');

      return resultTile.tile;
    }

    private generateWallSeed() {
      this.seedRandom_.jumpTo(this.round_);
      return this.seedRandom_.randomInt(0, 100000);
    }

    private seedRandom_: LGCRandom;
    private round_: number;
    private feverStartRound_: number;
    private feverTiles_: string[];
    private hands_: string[];
    private tileWeightMap_: Map<string, number>;
    private itemRate_: number;
    private itemWeightMap_: Map<number, number>;

    private wallRandom_: LGCRandom;
    private difficultyFactor_: MarathonDifficultyFactor;
    private roundConfig_: lqc.Sheet_Marathon_MarathonWallGroup;
  }

}
