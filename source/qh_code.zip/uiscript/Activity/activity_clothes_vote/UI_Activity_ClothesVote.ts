module uiscript {



    class Page_Rank extends UI_Component {
        private rankDetailBtn: Laya.Button;
        private femaleRanks: Array<Page_Rank_Item>;
        private maleRanks: Array<Page_Rank_Item>;
        private maleRankIndex: number = 3;
        private rankHotProgress: Page_Rank_HotProgress;
        private freshTime: Laya.Sprite;
        public onCreate(): void {
            this.rankDetailBtn = this.me.getChildByName('rank_detail_btn') as Laya.Button;
            this.rankDetailBtn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_ClothesVote.Inst.isLocking) {
                    return;
                }
                UI_Activity_ClothesVote_Rank_Detail.Inst.show();
            });
            this.femaleRanks = [];
            this.maleRanks = [];
            this.maleRankIndex = 3;
            let ranks: Laya.Sprite = this.me.getChildByName('ranks') as Laya.Sprite;
            for (let i = 0; i < 4; i++) {
                let rankSprite = ranks.getChildByName('item_' + i) as Laya.Sprite;
                let item = new Page_Rank_Item(rankSprite);
                if (i == this.maleRankIndex) {
                    this.maleRanks.push(item);
                } else {
                    this.femaleRanks.push(item);
                }
            }
            this.freshTime = this.me.getChildByName('fresh_time') as Laya.Sprite;
            game.Tools.child_align_center(this.freshTime, [10]);
            this.rankHotProgress = new Page_Rank_HotProgress(this.me.getChildByName('hot_progress') as Laya.Sprite);
            

        }

        public setFemaleRank(rankData: game.IResFetchVoteActivity_VoteRankData, index: number) {
            if (index < 0 || index >= this.femaleRanks.length) return;
            let item = this.femaleRanks[index];
            if (rankData) {
                item.setSkin(rankData.id);
            } else {
                item.setSkin(-1);
            }
        }

        public setMaleRank(rankData: game.IResFetchVoteActivity_VoteRankData, index: number) {
            if (index < 0 || index >= this.maleRanks.length) return;
            let item = this.maleRanks[index];
            if (rankData) {
                item.setSkin(rankData.id);
            } else {
                item.setSkin(-1);
            }

        }

        public set currentHotProgress(value: number) {
            this.rankHotProgress.currentProgress = value;
        }

        public show() {
            this.visible = true;
            
        }

        public hide() {
            this.visible = false;
        }

        public static haveRedPoint(): boolean {
            // 检查是否有可领取的奖励
            if (!UI_Activity.activity_is_running(UI_Activity_ClothesVote.voteProgressRewardActivityId)) {
                return false;
            }
            return UI_Activity_ClothesVote.canReceiveHotProgressRewards.length > 0;
        }

        public fresh() { 
            this.freshTime.visible = !UI_Activity_ClothesVote.get_vote_ended();
        }


        
    }

    class Page_Rank_Item extends UI_Component {
        private unknown: Laya.Sprite;
        private skin: Laya.Image;
        private name: Laya.Label;
        private charaName: Laya.Label;
        private dongtai: Laya.Sprite;
        private empty: Laya.Sprite;
        private infoBtn: Laya.Button;
        private skinId: number = -1;

        public onCreate(): void {
            this.unknown = this.me.getChildByName('unknown') as Laya.Sprite;
            this.skin = this.me.getChildByName('skin') as Laya.Image;
            this.name = this.me.getChildByName('name') as Laya.Label;
            this.charaName = this.me.getChildByName('chara_name') as Laya.Label;
            this.dongtai = this.me.getChildByName('dongtai') as Laya.Sprite;
            this.empty = this.me.getChildByName('empty') as Laya.Sprite;
            this.infoBtn = this.me.getChildByName('info_btn') as Laya.Button;
            this.infoBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.skinId < 0) return;
                UI_Activity_ClothesVote.Inst.jumpToSkinYulan(this.skinId);
            });
        }

        

        public setSkin(skinId: number): void {
            this.skinId = skinId;
            if (skinId == -1) {
                this.dongtai.visible = false;
                this.unknown.visible = true;
                this.empty.visible = true;
                this.skin.visible = false;
                this.name.visible = false;
                this.charaName.visible = false;
            } else {
                this.unknown.visible = false;
                this.empty.visible = false;
                this.skin.visible = true;
                this.name.visible = true;
                this.charaName.visible = true;
                let skinData = cfg.shops.goods.get(skinId);
                game.LoadMgr.setImgSkin(this.skin, skinData.icon, null, UI_Activity_ClothesVote.activitySign);
                let _skin = cfg.item_definition.skin.get(skinData.item_id);
                this.name.text = _skin['name_' + GameMgr.client_language];
                let chara = cfg.item_definition.character.get(_skin.character_id);
                this.charaName.text = chara['name_' + GameMgr.client_language];
                this.dongtai.visible = !!_skin.spine_type;
            }
        }


    }

    class Page_Rank_HotProgress extends UI_Component {
        private rewards: Array<Page_Rank_HotProgress_Reward>;
        private chance: Page_Rank_HotProgress_Chance;
        private progressLabel: Laya.Label;
        private receiveAllBtn: Laya.Button;
        private progressSlider: Laya.Image;
        private progress: number = 0;
        public onCreate(): void {
            this.rewards = [];
            let rewardsContainer: Laya.Sprite = this.me.getChildByName('rewards') as Laya.Sprite;
            for (let i = 0; i < 3; i++) {
                let rewardSprite = rewardsContainer.getChildByName('reward' + i) as Laya.Sprite;
                let rewardItem = new Page_Rank_HotProgress_Reward(rewardSprite);
                rewardItem.index = i; // 设置目标进度
                rewardItem.onClickReceive = new Laya.Handler(this, () => {
                    this.onClickReceiveOne(rewardItem.targetProgress);
                });
                this.rewards.push(rewardItem);
            }
            this.chance = new Page_Rank_HotProgress_Chance(rewardsContainer.getChildByName('chance') as Laya.Sprite);
            let progressSprite = this.me.getChildByName('progress_value') as Laya.Sprite;
            this.progressLabel = progressSprite.getChildByName('value') as Laya.Label;
            let slider = this.me.getChildByName('slider') as Laya.Sprite;
            this.progressSlider = slider.getChildByName('slider') as Laya.Image;
            this.receiveAllBtn = this.me.getChildByName('receive_all_btn') as Laya.Button;
            this.receiveAllBtn.clickHandler = new Laya.Handler(this, this.onClickReceiveAll);


        }

        public set currentProgress(value: number) {
            this.progress = value;
            this.freshProgressSlider();
            this.freshRewards();
            this.freshReceiveAllBtn();

        }

        private onClickReceiveAll() {
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            //获取所有可领取的奖励
            let canReceiveRewards = UI_Activity_ClothesVote.canReceiveHotProgressRewards;
            if (canReceiveRewards.length > 0) {
                // 领取所有可领取的奖励
                UI_Activity_ClothesVote.Inst.requestReceiveHotProgressReward(canReceiveRewards, new Laya.Handler(this, () => {
                    this.freshReceiveAllBtn();
                    this.freshRewards();
                }));
            }
        }

        private onClickReceiveOne(progress: number) {
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            // 获取指定进度的奖励
            UI_Activity_ClothesVote.Inst.requestReceiveHotProgressReward([progress], new Laya.Handler(this, () => {
                this.freshReceiveAllBtn();
                this.freshRewards();
            }));
        }

        private freshReceiveAllBtn() {
            let canReceiveRewards = UI_Activity_ClothesVote.canReceiveHotProgressRewards;
            let icon = this.receiveAllBtn.getChildByName('icon') as Laya.Image;
            let label = this.receiveAllBtn.getChildByName('value') as Laya.Label;
            icon.skin = game.Tools.localUISrc(canReceiveRewards.length > 0 ? 'myres/activity_clothes_vote/main_receive_all_btn.png' : 'myres/activity_clothes_vote/main_receive_all_btn_g.png')
            label.color = canReceiveRewards.length > 0 ? '#ffffff' : '#ece9ff';
            this.receiveAllBtn.mouseEnabled = canReceiveRewards.length > 0;
        }

        private freshRewards() {
            // 更新奖励状态
            for (let i = 0; i < this.rewards.length; i++) {
                let reward = this.rewards[i];
                if (reward.targetProgress <= this.progress) {
                    if (UI_Activity_ClothesVote.hotProgressRewardIsReceived(reward.targetProgress)) {
                        reward.state = 2; // 已领取
                    } else {
                        reward.state = 1; // 可领取
                    }
                } else {
                    reward.state = 0; // 未完成
                }
            }
            this.chance.received = this.progress >= 10000; // 假设10000为领取机会的条件
        }


        private freshProgressSlider() {
            let progress = Math.floor(this.progress / 100)
            this.progressLabel.text = progress + '%';
            //高度4-34代表0-25%
            if (progress <= 25) {
                this.progressSlider.height = 4 + (34 - 4) * (progress / 25);
            }
            //高度130-176代表25%-50%
            else if (progress <= 50) {
                this.progressSlider.height = 130 + (176 - 130) * ((progress - 25) / 25);
            }
            //高度272-317代表50%-75%
            else if (progress <= 75) {
                this.progressSlider.height = 272 + (317 - 272) * ((progress - 50) / 25);
            }
            //高度414-457代表75%-100%
            else if (progress <= 100) {
                this.progressSlider.height = 414 + (457 - 414) * ((progress - 75) / 25);
            }

        }



    }

    class Page_Rank_HotProgress_Reward extends UI_Component {
        private icon: Laya.Image;
        private count: Laya.Label;
        private receivedSprite: Laya.Sprite;
        private itemBtn: Laya.Button;
        private light: Laya.Sprite;
        private rewardId: number = -1;
        /**
         * 完成需要达成的进度
         */
        private progress: number = -1;
        private itemRect: UIRect = null;
        private tweenerId: number;
        private id: number = -1;

        public onCreate(): void {
            this.icon = this.me.getChildByName('icon') as Laya.Image;
            let countSprite = this.me.getChildByName('count') as Laya.Sprite;
            this.count = countSprite.getChildByName('count') as Laya.Label;
            this.receivedSprite = this.me.getChildByName('received') as Laya.Sprite;
            this.itemBtn = this.me.getChildByName('btn') as Laya.Button;
            this.itemBtn.clickHandler = new Laya.Handler(this, this.onClickItem);
            this.light = this.me.getChildByName('light') as Laya.Sprite;
            this.tweenerId = -1;
        }

        public set index(index: number) {
            this.id = index;
            let configDatas = cfg.activity.progress_reward.getGroup(UI_Activity_ClothesVote.voteProgressRewardActivityId);
            let configData = configDatas[index];
            if (configData) {
                this.progress = configData.progress;
                let reward = common.ConfigHelper.configString2Array<number>(configData.reward);
                let rewardId = reward[0][0];
                let rewardCount = reward[0][1];
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(this.icon);
                }
                game.Tools.setItemIcon(this.icon, this.itemRect, rewardId, UI_Activity_ClothesVote.activitySign, true);
                this.rewardId = rewardId;
                this.count.text = rewardCount.toString();
            }
        }

        public get targetProgress(): number {
            return this.progress;
        }


        private onClickItem() {
            //如果是可领取状态，则领取，如果是已领取或未完成，显示奖励信息
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            if (this.light.visible) {
                // 请求领取热度奖励
                this.onClickReceiveHandler?.run();
            } else {
                //显示奖励信息
                if (this.rewardId < 0) {
                    return;
                }
                UI_ItemDetail.Inst.show(this.rewardId);
            }
        }

        /**
         * 0 未完成，1 可领取，2 已领取
         */
        public set state(value: number) {
            this.light.visible = value == 1;
            this.receivedSprite.visible = value == 2;
            if (value == 1) {
                this.doTipClickAnimation();
            } else {
                this.stopTipClickAnimation();
            }
        }

        private onClickReceiveHandler: Laya.Handler;
        public set onClickReceive(handler: Laya.Handler) {
            this.onClickReceiveHandler = handler;

        }

        
        public doTipClickAnimation() {
            if (this.tweenerId != -1 && UI_Activity_ClothesVote.Inst.tweenManager.isTweenRunning(this.tweenerId)) {
                return;
            }
            this.tipClickAnimation(null);
        }


        private tipClickAnimation(onComplete: Laya.Handler) {
            let name = 'light' + this.id;
            if (UI_Activity_ClothesVote.Inst.isAnimPlaying(name)) {
                return;
            }
            UI_Activity_ClothesVote.Inst.playAnim(name, true, onComplete);
        }

        public stopTipClickAnimation() {
            let name = 'light' + this.id;
            if (UI_Activity_ClothesVote.Inst.isAnimPlaying(name)) {
                UI_Activity_ClothesVote.Inst.stopAnim(name);
            }
        }


    }

    class Page_Rank_HotProgress_Chance extends UI_Component {
        private icon: Laya.Image;
        private iconReceived: Laya.Sprite;
        private infoBtn: Laya.Button;
        public onCreate(): void {
            this.icon = this.me.getChildByName('icon') as Laya.Image;
            this.iconReceived = this.me.getChildByName('icon_received') as Laya.Sprite;
            this.infoBtn = this.me.getChildByName('btn') as Laya.Button;
            this.infoBtn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_ClothesVote.Inst.isLocking) {
                    return;
                }
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25089017));
            });

        }

        public set received(isReceived: boolean) {
            this.iconReceived.visible = isReceived;
            this.icon.visible = !isReceived;
        }
    }

    class Page_Vote extends UI_Component {
        private scrollview: capsui.CScrollView;
        private have_init = false;
        private randomSeed: number;
        private choice_info_list: Array<{ id: number, sort: number }>;
        private pageReward: Page_Vote_Reward;
        public onCreate(): void {
            this.scrollview = (this.me.getChildByName('content') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item), -1, 4);
            this.scrollview.reset();
            let femaleData = cfg.activity.vote_activity.get(UI_Activity_ClothesVote.femaleActivityId);
            let maleData = cfg.activity.vote_activity.get(UI_Activity_ClothesVote.maleActivityId);
            let strs = femaleData.choice_id_list.split(',');
            strs = strs.concat(maleData.choice_id_list.split(','));
            this.randomSeed = GameMgr.Inst.account_id;
            let n = strs.length;

            let tmp = null;
            this.choice_info_list = [];
            while (n > 0) {
                let index = this.random(0, n);
                n--;
                this.choice_info_list.push({ id: Number(strs[index]), sort: n - this.choice_info_list.length });
                tmp = strs[n];
                strs[n] = strs[index];
                strs[index] = tmp;
            }
            this.pageReward = new Page_Vote_Reward(this.me.getChildByName('vote_reward') as Laya.Sprite);
        }

        public show(isReset: boolean = true) {

            this.choice_info_list.sort((a, b) => {
                let sort_a = a.sort + UI_Activity_ClothesVote.get_vote_count(a.id) * 1000;
                let sort_b = b.sort + UI_Activity_ClothesVote.get_vote_count(b.id) * 1000;
                return sort_b - sort_a;
            })
            if (!this.have_init) {
                this.scrollview.addItem(this.choice_info_list.length);
                this.have_init = true;
            } else {
                this.scrollview.wantToRefreshAll();
            }
            if (isReset) {
                this.scrollview.rate = 0;
            }
            this.pageReward.show(isReset);
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        private render_item(data: any) {
            let index: number = data.index;
            let container: Laya.Sprite = data.container;
            let cache_data: Object = data.cache_data;
            let item: Page_Vote_Item = cache_data['cell'];
            if (!item) {
                item = new Page_Vote_Item(container);
                item.onClickInfo = new Laya.Handler(this, () => {
                    UI_Activity_ClothesVote.Inst.jumpToSkinYulan(item.itemId);
                });
                item.onClickVote1 = new Laya.Handler(this, () => {
                    if (UI_Activity_ClothesVote.Inst.isLocking) {
                        return;
                    }
                    if (UI_Activity_ClothesVote.Inst.onVoteEnd()) {
                        return;
                    }
                    if (UI_Bag.get_item_count(UI_Activity_Vote.item_id) <= 0) {
                        UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3633));
                        return;
                    }
                    let skin = cfg.shops.goods.get(item.itemId);
                    let _skin = cfg.item_definition.skin.get(skin.item_id);
                    let chara = cfg.item_definition.character.get(_skin.character_id);
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3632, [chara['name_' + GameMgr.client_language] + '-' + _skin['name_' + GameMgr.client_language]]), Laya.Handler.create(this, () => { 
                        UI_Activity_ClothesVote.Inst.requestVoteSkin(item.itemId, item.isFemale, 1, Laya.Handler.create(this, () => {
                            this.fresh();
                        }));
                    }));
                    
                });
                item.onClickVote10 = new Laya.Handler(this, () => {
                    if (UI_Activity_ClothesVote.Inst.isLocking) {
                        return;
                    }
                    if (UI_Activity_ClothesVote.Inst.onVoteEnd()) {
                        return;
                    }
                    if (UI_Bag.get_item_count(UI_Activity_Vote.item_id) < 10) {
                        UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3633));
                        return;
                    }
                    let skin = cfg.shops.goods.get(item.itemId);
                    let _skin = cfg.item_definition.skin.get(skin.item_id);
                    let chara = cfg.item_definition.character.get(_skin.character_id);
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3644, [chara['name_' + GameMgr.client_language] + '-' + _skin['name_' + GameMgr.client_language]]), Laya.Handler.create(this, () => {
                        UI_Activity_ClothesVote.Inst.requestVoteSkin(item.itemId, item.isFemale, 10, Laya.Handler.create(this, () => {
                            this.fresh();
                        }));
                    }));
                });

            }
            item.itemId = this.choice_info_list[index].id;
            item.voteCount = UI_Activity_ClothesVote.get_vote_count(item.itemId);

        }

        private seededRandom(seed, min, max): number {
            seed = (seed * 9301 + 49297) % 233280;
            var rand = seed / 233280;
            return min + rand * (max - min);
        }

        private random(min, max): number {

            min = min || 0;
            max = max || 1;
            var result = Math.floor(this.seededRandom(this.randomSeed, min, max));
            this.randomSeed += Math.floor(this.seededRandom(this.randomSeed, 1, 100000));
            return result;
        }

        public static haveRedPoint(): boolean {
            // 检查是否有可领取的奖励或者投票数量不为0
            if (UI_Activity_ClothesVote.get_vote_ended()) {
                return false;
            }
            let voteCount = UI_Bag.get_item_count(UI_Activity_ClothesVote.voteItemId);
            return UI_Activity_ClothesVote.canReceiveVoteCountRewards.length > 0 || voteCount > 0;
        }

        public fresh() { 
            this.scrollview.wantToRefreshAll();
            this.pageReward.refresh();
        }

        public doListAnim() {
            let tween_config = { delay: 16, duration: 280, ease: Laya.Ease.quadOut };
            let start_config = { alpha: 0, x_dis: 90 };
            let target_config = { alpha: 1 };
            let items = this.scrollview.items.map((value) => {
                return value.container;
            });
            let list_delay = game.Tools.listSpritesAnim(items, tween_config, start_config, target_config);
            return list_delay;
        }

    }

    class Page_Vote_Item extends UI_Component {
        private skin: Laya.Image;
        private name: Laya.Label;
        private chara_name: Laya.Label;
        private count: Laya.Label;
        private dongtai: Laya.Sprite;
        private vote1Btn: Laya.Button;
        private vote1BtnBg: Laya.Image;
        private vote1BtnLabel: Laya.Label;
        private vote10Btn: Laya.Button;
        private vote10BtnBg: Laya.Image;
        private vote10BtnLabel: Laya.Label;
        private infoBtn: Laya.Button;
        private id: number;
        private sex: number = 1; // 默认是女性角色投票
        public onCreate(): void {
            this.skin = this.me.getChildByName('skin') as Laya.Image;
            this.name = this.me.getChildByName('name') as Laya.Label;
            this.chara_name = this.me.getChildByName('chara_name') as Laya.Label;
            this.count = this.me.getChildByName('vote_count') as Laya.Label;
            this.dongtai = this.me.getChildByName('dongtai') as Laya.Sprite;
            this.vote1Btn = this.me.getChildByName('btn_vote1') as Laya.Button;
            this.vote1BtnBg = this.vote1Btn.getChildByName('bg') as Laya.Image;
            this.vote1BtnLabel = this.vote1Btn.getChildByName('count') as Laya.Label;
            this.vote10Btn = this.me.getChildByName('btn_vote10') as Laya.Button;
            this.vote10BtnBg = this.vote10Btn.getChildByName('bg') as Laya.Image;
            this.vote10BtnLabel = this.vote10Btn.getChildByName('count') as Laya.Label;
            this.infoBtn = this.me.getChildByName('btn_check') as Laya.Button;
        }

        public set onClickVote1(handler: Laya.Handler) {
            this.vote1Btn.clickHandler = handler;
        }

        public set onClickVote10(handler: Laya.Handler) {
            this.vote10Btn.clickHandler = handler;
        }

        public set onClickInfo(handler: Laya.Handler) {
            this.infoBtn.clickHandler = handler;
        }

        public set itemId(itemId: number) {
            this.id = itemId;
            let skin = cfg.shops.goods.get(itemId);
            game.LoadMgr.setImgSkin(this.skin, skin.icon, null, UI_Activity_ClothesVote.activitySign);
            let _skin = cfg.item_definition.skin.get(skin.item_id);
            this.dongtai.visible = !!_skin.spine_type;
            this.name.text = _skin['name_' + GameMgr.client_language];
            let chara = cfg.item_definition.character.get(_skin.character_id);
            this.chara_name.text = chara['name_' + GameMgr.client_language];
            this.sex = chara.sex;
            // 设置按钮状态
            let voteItemCount = UI_Bag.get_item_count(UI_Activity_ClothesVote.voteItemId);
            this.vote1BtnBg.skin = game.Tools.localUISrc(voteItemCount > 0 ? 'myres/activity_clothes_vote/main_vote_btn.png' : 'myres/activity_clothes_vote/main_vote_btn_g.png');
            this.vote1BtnLabel.color = voteItemCount > 0 ? '#7f442d' : '#a89188';
            this.vote10BtnBg.skin = game.Tools.localUISrc(voteItemCount >= 10 ? 'myres/activity_clothes_vote/main_vote_btn.png' : 'myres/activity_clothes_vote/main_vote_btn_g.png');
            this.vote10BtnLabel.color = voteItemCount >= 10 ? '#7f442d' : '#a89188';
        }

        public set voteCount(value: number) {
            this.count.text = game.Tools.strOfLocalization(25089004, [value.toString()]);
        }

        public get itemId(): number {
            return this.id;
        }

        public get isFemale(): boolean {
            return this.sex == 1;
        }
    }

    class Page_Vote_Reward extends UI_Component {
        private scrollview: capsui.CScrollView;
        private task_list: Array<Object>;
        private final_task: Page_Vote_Reward_Item;
        private receiveAllBtn: Laya.Button;
        private inited: boolean = false;


        public onCreate(): void {
            let content: Laya.Sprite = this.me.getChildByName('content') as Laya.Sprite;
            this.scrollview = content.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
            this.scrollview.reset();
            this.receiveAllBtn = this.me.getChildByName('receive_all_btn') as Laya.Button;
            this.receiveAllBtn.clickHandler = new Laya.Handler(this, this.onClickReceiveAll);
            this.final_task = new Page_Vote_Reward_Item(content.getChildByName('templete') as Laya.Sprite);
        }

        public show(isReset: boolean = false) {
            this.refresh();
            if (isReset) {
                this.scrollview.rate = 0;
            }
        }

        private render_item(data) {
            let index: number = data.index;
            let container: Laya.Sprite = data.container;
            let cache_data: Object = data.cache_data;
            let item: Page_Vote_Reward_Item = cache_data['cell'];
            if (!item) {
                item = new Page_Vote_Reward_Item(container);
                item.onClickReceive = new Laya.Handler(this, () => {
                    this.onClickReceiveOne(item.taskId);
                });
                data.cache_data['cell'] = item;
            }
            item.taskData = this.task_list[index] as game.ITaskProgress;
        }

        // 任务进度发生改变
        public refresh() {
            this.task_list = UI_Activity.getPeriodTaskList(UI_Activity_ClothesVote.voteCountRewardActivityId);
            if (this.task_list.length == 0) return;
            if (!this.inited) {
                this.inited = true;
                this.scrollview.reset();
                this.scrollview.addItem(this.task_list.length - 1);
            } else {
                this.scrollview.wantToRefreshAll();
            }
            let finalTask = this.task_list[this.task_list.length - 1] as game.ITaskProgress;
            this.final_task.taskData = finalTask;
            this.final_task.onClickReceive = new Laya.Handler(this, () => {
                this.onClickReceiveOne(finalTask.id);
            });
            this.freshReceiveAllBtn();
            
        }

        private onClickReceiveAll() {
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            if (UI_Activity_ClothesVote.Inst.onVoteEnd()) {
                return;
            }
            //获取所有可领取的奖励
            let canReceiveRewards = UI_Activity_ClothesVote.canReceiveVoteCountRewards;
            if (canReceiveRewards.length > 0) {
                // 领取所有可领取的奖励
                UI_Activity_ClothesVote.Inst.requestReceiveVoteCountReward(canReceiveRewards, new Laya.Handler(this, () => {
                    this.refresh();
                }));
            }
        }

        private onClickReceiveOne(taskId: number) {
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            if (UI_Activity_ClothesVote.Inst.onVoteEnd()) {
                return;
            }
            // 获取指定进度的奖励
            UI_Activity_ClothesVote.Inst.requestReceiveVoteCountReward([taskId], new Laya.Handler(this, () => {
                this.refresh();
            }));
        }

        private freshReceiveAllBtn() {
            let canReceiveRewards = UI_Activity_ClothesVote.canReceiveVoteCountRewards;
            let icon = this.receiveAllBtn.getChildByName('icon') as Laya.Image;
            let label = this.receiveAllBtn.getChildByName('value') as Laya.Label;
            icon.skin = game.Tools.localUISrc(canReceiveRewards.length > 0 ? 'myres/activity_clothes_vote/main_receive_all_btn.png' : 'myres/activity_clothes_vote/main_receive_all_btn_g.png')
            label.color = canReceiveRewards.length > 0 ? '#ffffff' : '#ece9ff';
            this.receiveAllBtn.mouseEnabled = canReceiveRewards.length > 0;
        }

      

        

        


    }

    class Page_Vote_Reward_Item extends UI_Component {
        private icon: Laya.Image;
        private count: Laya.Label;
        private receivedSprite: Laya.Sprite;
        private itemBtn: Laya.Button;
        private light: Laya.Sprite;
        private voteTitle: Laya.Label;
        private voteCount: Laya.Label;
        private rewardId: number = -1;
        private rewardCount: number = 0;
        private itemRect: UIRect = null;
        private _taskId: number = -1;
        private tweenerId: number = -1;

        public onCreate(): void {
            let item = this.me.getChildByName('item') as Laya.Sprite;
            this.icon = item.getChildByName('icon') as Laya.Image;
            let countSprite = item.getChildByName('count') as Laya.Sprite;
            this.count = countSprite.getChildByName('count') as Laya.Label;
            this.receivedSprite = item.getChildByName('received') as Laya.Sprite;
            this.itemBtn = item.getChildByName('btn') as Laya.Button;
            this.itemBtn.clickHandler = new Laya.Handler(this, this.onClickItem);
            this.light = item.getChildByName('light') as Laya.Sprite;
            this.voteTitle = this.me.getChildByName('vote_title') as Laya.Label;
            this.voteCount = this.me.getChildByName('vote_count') as Laya.Label;
            this.tweenerId = -1;
        }

        public set taskData(taskData: game.ITaskProgress) {
            this._taskId = taskData.id;
            let activityTaskInfo = cfg.activity.period_task.get(taskData.id);
            let baseTaskInfo = cfg.events.base_task.get(activityTaskInfo.base_task_id);
            if (activityTaskInfo && baseTaskInfo) {
                let reward = common.ConfigHelper.configString2Array<number>(activityTaskInfo.reward);
                this.rewardId = reward[0][0];
                this.rewardCount = reward[0][1];
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(this.icon);
                }
                game.Tools.setItemIcon(this.icon, this.itemRect, this.rewardId, UI_Activity_ClothesVote.activitySign, true);
                this.count.text = this.rewardCount.toString();
                let counter = Math.min(taskData.counter, baseTaskInfo.target);
                this.voteCount.text = counter + '/' + baseTaskInfo.target;
                this.state = taskData.achieved ? (taskData.rewarded ? 2 : 1) : 0; // 设置状态

            }
        }

        public get taskId(): number {
            return this._taskId;
        }

        public get taskCount(): number {
            return this.rewardCount;
        }

        private onClickItem() {
            //如果是可领取状态，则领取，如果是已领取或未完成，显示奖励信息
            if (!UI_Activity_ClothesVote.Inst || UI_Activity_ClothesVote.Inst.isLocking) return;
            if (this.light.visible) {
                // 请求领取热度奖励
                this.onClickReceiveHandler?.run();
            } else {
                //显示奖励信息
                if (this.rewardId < 0) {
                    return;
                }
                UI_ItemDetail.Inst.show(this.rewardId);
            }
        }

        /**
         * 0 未完成，1 可领取，2 已领取
         */
        public set state(value: number) {
            this.light.visible = value == 1;
            this.receivedSprite.visible = value == 2;
            
            if (value == 1) {
                this.doTipClickAnimation();
            } else {
                this.stopTipClickAnimation();
            }
        }

        private onClickReceiveHandler: Laya.Handler;
        public set onClickReceive(handler: Laya.Handler) {
            this.onClickReceiveHandler = handler;

        }

        
        public doTipClickAnimation() {
            if (this.tweenerId != -1 && UI_Activity_ClothesVote.Inst.tweenManager.isTweenRunning(this.tweenerId)) {
                return;
            }
            //0-0.5s 大小从1变为0.95 ，0.5-1s 大小从0.95变为1，循环
            this.tweenerId = UI_Activity_ClothesVote.Inst.tweenManager.addTweenTo(this.light, { scaleX: 0.95, scaleY: 0.95 }, 500, Laya.Ease.quadInOut, Laya.Handler.create(this, () => { 
                this.tweenerId = UI_Activity_ClothesVote.Inst.tweenManager.addTweenTo(this.light, { scaleX: 1, scaleY: 1 }, 500, Laya.Ease.quadInOut, Laya.Handler.create(this, () => { 
                    this.tweenerId = -1;
                    this.doTipClickAnimation();
                }));
            }));
        }

        public stopTipClickAnimation() {
            if (this.tweenerId) {
                UI_Activity_ClothesVote.Inst.tweenManager.removeTweener(this.tweenerId);
            }
        }

    }


    class Vote_TabButton extends UI_Component {

        private selectSprite: Laya.Sprite;
        private deselectSprite: Laya.Sprite;
        public onCreate(): void {
            this.selectSprite = this.me.getChildByName('select') as Laya.Sprite;
            this.deselectSprite = this.me.getChildByName('diselect') as Laya.Sprite;
        }


        public onSelect() {
            this.selectSprite.visible = true;
            this.deselectSprite.visible = false;
        }

        public onDeselect() {
            this.selectSprite.visible = false;
            this.deselectSprite.visible = true;
        }

    }

    class Vote_ItemCount extends UI_Component {
        private itemIcon: Laya.Image;
        private itemCount: Laya.Label;
        private itemContent: Laya.Label;
        public onCreate(): void {
            this.itemIcon = this.me.getChildByName('icon') as Laya.Image;
            this.itemCount = this.me.getChildByName('value') as Laya.Label;
            this.itemContent = this.me.getChildByName('content') as Laya.Label;
        }

        public set itemCountValue(value: number) {
            this.itemCount.text = value.toString();
            //居中对齐
            game.Tools.child_align_center(this.me, [5, 5]);
        }

    }




    export class UI_Activity_ClothesVote extends UIBase {
        public static Inst: UI_Activity_ClothesVote = null;
        public static activityId: number = 250890; // 每次修改
        /**
         * 女性角色投票活动ID
         */
        public static femaleActivityId: number = 250890;
        /**
         * 男性角色投票活动ID
         */
        public static maleActivityId: number = 250891;
        /**
         * 个人投票数量奖励活动ID
         */
        public static voteCountRewardActivityId: number = 250894;
        /**
         * 全服热度奖励活动ID
         */
        public static voteProgressRewardActivityId: number = 250895;
        /**
         * 投票物品ID
         */
        public static voteItemId: number = 309059;
        /**
         * 获取投票物品任务ID
         */
        public static voteTaskActivityId: number = 250892;

        /**
         * 获取投票物品月卡任务ID
         */
        public static voteYuekaTaskActivityId: number = 25089301;
        public static female_vote_rank: Array<game.IResFetchVoteActivity_VoteRankData>;
        public static male_vote_rank: Array<game.IResFetchVoteActivity_VoteRankData>;
        public static female_update_time: number;
        public static male_update_time: number;
        public static female_vote_count_info: Object;
        public static male_vote_count_info: Object;
        public static activitySign: string = 'activity_clothes_vote';
        public static progressRewardData: number[];
        private static hotProgress: number = 0;
        private static lastUpdateHotProgressTime: number = 0;
        private static lastUpdateFemaleVoteTime: number = 0;
        private static lastUpdateMaleVoteTime: number = 0;

        public static get_vote_count(id: number): number {
            if (UI_Activity_ClothesVote.female_vote_count_info && UI_Activity_ClothesVote.female_vote_count_info[id]) {
                return UI_Activity_ClothesVote.female_vote_count_info[id];
            }
            if (UI_Activity_ClothesVote.male_vote_count_info && UI_Activity_ClothesVote.male_vote_count_info[id]) {
                return UI_Activity_ClothesVote.male_vote_count_info[id];
            }
            return 0;
        }

        public static Init() {
            if (UI_Activity.activity_is_running(this.femaleActivityId)) {
                this.fetchFemaleRankInfo(false);
                this.fetchMaleRankInfo(false);
                this.fetchHotProgressInfo();
            }
        }

        public static have_redpoint(): boolean {
            let voteRedPoint = Page_Vote.haveRedPoint();
            let rankRedPoint = Page_Rank.haveRedPoint();
            let taskRedPoint = UI_Activity_ClothesVote_Task.haveRedPoint();
            //进入公示期且没有打开过页面需要显示红点
            return voteRedPoint || rankRedPoint || taskRedPoint || !this.isShowedPublicityPeriod;
        }



        public static fetchFemaleRankInfo(isShowPop:boolean = true) {
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchVoteActivity, { activity_id: this.femaleActivityId }, (err, res: game.IResFetchVoteActivity) => {
                if (err || res['error']) {
                    UI_Activity_ClothesVote.onMaintain(err, res, isShowPop);
                } 
                if (res) {
                    this.female_vote_rank = res.data;
                    this.female_update_time = res.update_time;
                    this.lastUpdateFemaleVoteTime = game.Tools.getServerTime();
                    app.Log.log("【Vote】Female Rank:" + JSON.stringify(res))
                    Laya.stage.event(EventCode.CLOTHES_VOTE_FAMALE_RANK_UPDATE);
                }
            });
        }

        public static fetchMaleRankInfo(isShowPop:boolean = true) {
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchVoteActivity, { activity_id: this.maleActivityId }, (err, res: game.IResFetchVoteActivity) => {
                if (err || res['error']) {
                    UI_Activity_ClothesVote.onMaintain(err, res, isShowPop);
                } 
                if (res) {
                    this.male_vote_rank = res.data;
                    this.male_update_time = res.update_time;
                    this.lastUpdateMaleVoteTime = game.Tools.getServerTime();
                    app.Log.log("【Vote】Male Rank:" + JSON.stringify(res))
                    Laya.stage.event(EventCode.CLOTHES_VOTE_MALE_RANK_UPDATE);
                }
            });
        }

        /**
         * 刷新个人投票数量
         * @param lst 
         */
        public static update_vote_data(lst: Array<game.IVoteData>) {
            this.female_vote_count_info = {};
            this.male_vote_count_info = {};
            let freshData = false;
            for (let info of lst) {

                if (info.activity_id == UI_Activity_ClothesVote.femaleActivityId) {
                    this.female_vote_count_info[info.vote] = info.count;
                    freshData = true;
                } else if (info.activity_id == UI_Activity_ClothesVote.maleActivityId) {
                    this.male_vote_count_info[info.vote] = info.count;
                    freshData = true;
                }
            }
            if (freshData) {
                // 刷新投票数量
                app.Log.log("【Vote】update_vote_data female:" + JSON.stringify(this.female_vote_count_info));
                app.Log.log("【Vote】update_vote_data male:" + JSON.stringify(this.male_vote_count_info));
                Laya.stage.event(EventCode.CLOTHES_VOTE_COUNT_UPDATE);
            }
        }

        public static update_progress_reward_data(lst: Array<game.IActivityProgressRewardData>) {
            for (let index = 0; index < lst.length; index++) {
                let data = lst[index];
                if (data.activity_id == UI_Activity_ClothesVote.voteProgressRewardActivityId) {
                    this.progressRewardData = game.Tools.deepCopy(data.rewarded_progresses);
                    app.Log.log("【Vote】update_progress_reward_data:" + JSON.stringify(data));
                    //刷新热度奖励
                    Laya.stage.event(EventCode.CLOTHES_VOTE_PROGRESS_REWARDED_UPDATE);
                }
            }
        }

        public static onReceiveProgressReward(progresses: number[]) {
            if (!this.progressRewardData) {
                this.progressRewardData = [];
            }
            let changed = false;
            for (let index = 0; index < progresses.length; index++) {
                const element = progresses[index];
                if (this.progressRewardData.indexOf(element) == -1) {
                    this.progressRewardData.push(element);
                    changed = true;
                }
            }
            if (changed) {
                Laya.stage.event(EventCode.CLOTHES_VOTE_PROGRESS_REWARDED_UPDATE);
            }
        }

        public static get_vote_ended(): boolean {
            if (!cfg.activity.vote_activity) return true;
            let _data = cfg.activity.vote_activity.get(UI_Activity_ClothesVote.femaleActivityId);
            return game.Tools.getTimeByStr(_data.vote_end_time) < game.Tools.getServerTime();
        }

        public static fetchHotProgressInfo() {
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchProgressRewardActivityInfo, { activity_id: UI_Activity_ClothesVote.voteProgressRewardActivityId }, (err, res: game.IResFetchProgressRewardActivityInfo) => {
                if (err || res['error']) {
                    if (!UI_Activity_ClothesVote.onMaintain(err, res)) {
                        UIMgr.Inst.showNetReqError(game.ERequest.fetchProgressRewardActivityInfo, err, res);
                    }
                } else {
                    app.Log.log("【Vote】fetchHotProgressInfo:" + JSON.stringify(res))
                    if (!res.progress || res.progress < 0) {
                        // 如果热度进度小于0，说明没有热度奖励
                        this.currentHotProgress = 0;
                    } else {
                        this.currentHotProgress = res.progress;
                    }
                    
                }
            });
        }

        public static set currentHotProgress(value: number) {
            this.hotProgress = value;
            this.lastUpdateHotProgressTime = game.Tools.getServerTime();
            // 发送热度更新的通知
            Laya.stage.event(EventCode.CLOTHES_VOTE_HOT_PROGRESS_UPDATE, value);
        }

        public static get currentHotProgress(): number {
            return this.hotProgress;
        }

        /**
         * 获取可以领取的热度奖励进度列表
         */
        public static get canReceiveHotProgressRewards(): Array<number> {
            let rewards = cfg.activity.progress_reward.getGroup(UI_Activity_ClothesVote.voteProgressRewardActivityId);
            let canReceive = [];
            rewards.forEach((reward) => {
                let hasReward = reward.reward != '';
                if (reward.progress <= UI_Activity_ClothesVote.currentHotProgress && hasReward) {
                    if (!this.hotProgressRewardIsReceived(reward.progress)) {
                        canReceive.push(reward.progress);
                    }
                }
            });
            return canReceive;
        }

        public static get canReceiveVoteCountRewards(): Array<number> {
            let list = UI_Activity.getPeriodTaskList(UI_Activity_ClothesVote.voteCountRewardActivityId);
            let canReceive = [];
            for (let info of list) {
                let infoData = info as game.ITaskProgress;
                // 如果任务已完成且未领取奖励，则可以领取
                if (infoData.achieved && !infoData.rewarded) {
                    canReceive.push(infoData.id);
                }
            }
            return canReceive;
        }

        /**
         * 指定进度的热度奖励是否已领取
         * @param progress 
         * @returns 
         */
        public static hotProgressRewardIsReceived(progress: number): boolean {
            if (!this.progressRewardData || !this.progressRewardData) return false;
            return this.progressRewardData.findIndex(item => item == progress) != -1;
        }

        private static publicityPeriodKey: string = 'clothes_vote_publicity_period';
        //公示期内是否查看过
        public static get isShowedPublicityPeriod(): boolean {

            //时间是否在公示期内
            if (!this.isPublicityPeriod) {
                //如果不在公示期内，直接返回true
                return true;
            }
            return game.LocalStorage.getActivityData(UI_Activity_ClothesVote.activityId, this.publicityPeriodKey) == '1';
        }

        public static set isShowedPublicityPeriod(value: boolean) {
            if (value) {
                game.LocalStorage.setActivityData(UI_Activity_ClothesVote.activityId, this.publicityPeriodKey, '1');
            } else {
                game.LocalStorage.setActivityData(UI_Activity_ClothesVote.activityId, this.publicityPeriodKey, '0');
            }
        }

        public static get isPublicityPeriod(): boolean {
            //时间是否在公示期内
            let isVoteEnd = this.get_vote_ended();
            let isActivityRunning = UI_Activity.activity_is_running(UI_Activity_ClothesVote.activityId);
            if (isActivityRunning || !isVoteEnd) {
                return false;
            }
            return true;
        }

        public static isMaintain:boolean = false;

        constructor() {
            super(new ui.lobby.activity_clothes_vote.activity_clothes_voteUI());
            UI_Activity_ClothesVote.Inst = this;
        }

        private locking: boolean = false;
        private pageRank: Page_Rank;
        private pageVote: Page_Vote;
        private tabGroup: UI_TabGroup_Base;
        private tabButtons: Array<Vote_TabButton> = [];
        private voteTaskBtn: Laya.Button;
        private voteItemCount: Vote_ItemCount;
        private voteTaskFinish: Laya.Sprite;
        private voteRedPoint: Laya.Sprite;
        private rankRedPoint: Laya.Sprite;
        private taskRedPoint: Laya.Sprite;
        private animMgr: UI_FrameAnimationMgr<ui.lobby.activity_clothes_vote.activity_clothes_voteUI>;
        public tweenManager: UI_TweenManager;

        public onCreate(): void {
            this.animMgr = new UI_FrameAnimationMgr(this.me);
            let root: Laya.Sprite = this.me.getChildByName('root') as Laya.Sprite;
            let top: Laya.Sprite = root.getChildByName('top') as Laya.Sprite;
            let btnBack: Laya.Button = top.getChildByName('btn_back') as Laya.Button;
            btnBack.clickHandler = new Laya.Handler(this, () => { 
                this.hide(true);
            });
            let btnInfo: Laya.Button = top.getChildByName('anim_root').getChildByName('btn_info') as Laya.Button;
            btnInfo.clickHandler = new Laya.Handler(this, () => {
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(25089001));
            });
            // let bg: Laya.Image = root.getChildByName('bg') as Laya.Image;
            // game.LoadMgr.setImgSkin(bg, 'myres/activity_clothes_vote/main_bg.jpg');
            this.pageRank = new Page_Rank(root.getChildByName('page_rank') as Laya.Sprite);
            this.pageVote = new Page_Vote(root.getChildByName('page_vote') as Laya.Sprite);
            let tabs = root.getChildByName('tabs') as Laya.Sprite;
            let btnRank: Laya.Button = tabs.getChildByName('btn_rank') as Laya.Button;
            let btnVote: Laya.Button = tabs.getChildByName('btn_vote') as Laya.Button;
            this.voteRedPoint = btnVote.getChildByName('redpoint') as Laya.Sprite;
            this.rankRedPoint = btnRank.getChildByName('redpoint') as Laya.Sprite;
            this.tabButtons.push(new Vote_TabButton(btnRank));
            this.tabButtons.push(new Vote_TabButton(btnVote));
            this.tabGroup = new UI_TabGroup_Base();
            this.tabGroup.AddTabButton(btnRank);
            this.tabGroup.AddTabButton(btnVote);
            this.tabGroup.onSelectChange = (index: number, btn: Laya.Button, manualSwitching:boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroup.selectedIndex) {
                    if (this.tabGroup.selectedIndex == 1) {
                        if (UI_Activity_ClothesVote.Inst.onVoteEnd()) {
                            return;
                        }
                    }
                    tabBtn.onSelect();
                    //手动点击才播放动画
                    this.onTabChange(manualSwitching);
                }
                else {
                    if (this.tabGroup.selectedIndex == 1) {
                        if (UI_Activity_ClothesVote.get_vote_ended()) {
                            return;
                        }
                    }
                    tabBtn.onDeselect();
                }

            };
            this.tabGroup.init();
            this.voteTaskBtn = root.getChildByName('get_ticket') as Laya.Button;
            this.voteTaskBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.onVoteEnd()) {
                    return;
                }
                UI_Activity_ClothesVote_Task.Inst.show();
            });
            this.taskRedPoint = this.voteTaskBtn.getChildByName('redpoint') as Laya.Sprite;
            this.voteItemCount = new Vote_ItemCount(this.voteTaskBtn.getChildByName('ticket_count') as Laya.Sprite);
            this.voteTaskFinish = root.getChildByName('finish') as Laya.Sprite;
            UI_Bag.add_item_listener(UI_Activity_ClothesVote.voteItemId, Laya.Handler.create(this, () => {
                if (this.enable) {
                    this.freshVoteItemCount();
                    this.freshRedPoint();
                    this.freshVotePage();
                }
            }, null, false));
            this.tweenManager = new UI_TweenManager();
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_ClothesVote', true);
            this.bindEvent();
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_ClothesVote', false);
            this.removeEvent();
            this.tweenManager.clearAllTweens();
        }

        private bindEvent() {
            Laya.stage.on(EventCode.ACTIVITY_PERIOD_TASK_UPDATE, this, this.freshVotePage);
            Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);
            Laya.stage.on(EventCode.CLOTHES_VOTE_HOT_PROGRESS_UPDATE, this, this.freshHotProgress);
            Laya.stage.on(EventCode.CLOTHES_VOTE_FAMALE_RANK_UPDATE, this, this.freshRankPage);
            Laya.stage.on(EventCode.CLOTHES_VOTE_MALE_RANK_UPDATE, this, this.freshRankPage);

        }

        private removeEvent() {
            Laya.stage.off(EventCode.ACTIVITY_PERIOD_TASK_UPDATE, this, this.freshVotePage);
            Laya.stage.off(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);
            Laya.stage.off(EventCode.CLOTHES_VOTE_HOT_PROGRESS_UPDATE, this, this.freshHotProgress);
            Laya.stage.off(EventCode.CLOTHES_VOTE_FAMALE_RANK_UPDATE, this, this.freshRankPage);
            Laya.stage.off(EventCode.CLOTHES_VOTE_MALE_RANK_UPDATE, this, this.freshRankPage);
        }

        public show(tabIndex: number = 0, isAnim: boolean = true) {
            //是否在公示期看过该界面
            if (UI_Activity_ClothesVote.isPublicityPeriod) {
                let isShowed = UI_Activity_ClothesVote.isShowedPublicityPeriod;
                if (!isShowed) {
                    UI_Activity_ClothesVote.isShowedPublicityPeriod = true;
                }
            }
            this.tabGroup.selectedIndex = tabIndex;
            this.checkVoteUpdate();
            this.checkHotProgressUpdate();
            this.fresh();
            this.enable = true;
           
            if (isAnim) {
                this.locking = true;
                this.animMgr.playAnim('show', false, Laya.Handler.create(this, () => { 
                    this.locking = false;
                }));
                if (tabIndex == 0) {
                    //如果rank排名没数据则不显示特效
                    if ((UI_Activity_ClothesVote.male_vote_rank && UI_Activity_ClothesVote.male_vote_rank.length > 0) || (UI_Activity_ClothesVote.female_vote_rank && UI_Activity_ClothesVote.female_vote_rank.length > 0)) {
                        Laya.timer.once(716, this, () => {
                            let effect = this.createEffect(this.me, 'scene/effect_25vote_flash.lh', new Laya.Point(958, 544));
                            effect.effect.addLoadedListener(Laya.Handler.create(this, () => { 
                                //有数据的才显示特效节点
                                let nodeParent = effect.effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite;
                                for (let index = 0; index < 4; index++) {
                                    let effectNode = nodeParent.getChildAt(index) as Laya.Sprite;
                                    //0-2是女性0-2,3是男性0
                                    if (index < 3) {
                                        effectNode.visible = !!UI_Activity_ClothesVote.female_vote_rank[index];
                                    } else {
                                        effectNode.visible = !!UI_Activity_ClothesVote.male_vote_rank[0];
                                    }
                                }
                            }))
                            
                            Laya.timer.once(1000, this, () => {
                                if (effect) {
                                    this.destroyEffect(effect);
                                }
                            });
                        });
                    }
                }
            }

        }

        public hide(isAnim: boolean = false,isForce:boolean = false) {
            if (this.locking && !isForce) return;
            UI_Lobby.Inst.enable = true;
            game.Scene_Lobby.Inst.change_bg('yard', true);
            if (isAnim) {
                this.locking = true;
                this.animMgr.playAnim('hide', false, Laya.Handler.create(this, () => {
                    this.locking = false;
                    this.enable = false;
                    
                }));
            }
            else {
                this.enable = false;
            }
        }

        public fresh() {
            
            this.freshRankPage();
            this.freshVotePage();
            this.freshVoteTaskBtn();
            this.freshVoteItemCount();
            this.freshHotProgress();
            this.freshRedPoint();
        }

        public requestReceiveHotProgressReward(progresses: number[], onComplete: Laya.Handler) {
            let req: game.IReqProgressRewardActivityReceive = {
                activity_id: UI_Activity_ClothesVote.voteProgressRewardActivityId,
                progresses: progresses
            };
            this.isLocking = true;
            app.Log.log("【Vote】progressRewardActivityReceive: " + JSON.stringify(req));
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.progressRewardActivityReceive, req, (err, res: game.IResProgressRewardActivityReceive) => {
                this.isLocking = false;
                if (err || res['error']) {
                    if (!UI_Activity_ClothesVote.onMaintain(err, res)) {
                        UIMgr.Inst.showNetReqError(game.ERequest.progressRewardActivityReceive, err, res);
                    }
                } else {
                    let rewards = [];
                    for (let reward of res.reward_items) {
                        if (reward['replace_count'] == 0) {
                            rewards.push(reward['reward']);
                        } else {
                            reward['reward']['count'] -= reward['replace_count'];
                            if (reward['reward']['count'] > 0) {
                                rewards.push(reward['reward']);
                            }
                            rewards.push(reward['replace']);
                        }
                    }
                    game.Tools.showRewards({ rewards: rewards }, null);
                    UI_Activity_ClothesVote.onReceiveProgressReward(progresses);
                    this.freshRedPoint();
                    onComplete?.run();
                }
            });
        }

        public requestReceiveVoteCountReward(taskIds: number[], onComplete: Laya.Handler) {
            if (this.isLocking) return;
            let req: game.IReqCompletePeriodActivityTaskBatch = {
                task_list: taskIds
            };
            this.isLocking = true;
            app.Log.log("【Vote】completePeriodActivityTaskBatch: " + JSON.stringify(req));
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, req, (err, res: game.IResCommon) => {
                this.isLocking = false;
                let rewardList = [];
                let rewardObj = {};
                for (let id of taskIds) {
                    //更新服务端奖励数据
                    UI_Activity.onPeriodTaskRewarded(id);
                    let taskConfigData = cfg.activity.period_task.get(id);
                    if (!taskConfigData.reward) {
                        continue;
                    }
                    let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                    let rewardId = rewardStr[0];
                    let rewardCount = Number(rewardStr[1]);
                    if (!rewardObj[rewardId]) {
                        rewardObj[rewardId] = rewardCount;
                    } else {
                        rewardObj[rewardId] += rewardCount;
                    }
                }
                for (let key in rewardObj) {
                    rewardList.push({ id: Number(key), count: rewardObj[key] });
                }
                game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                this.freshRedPoint();
                onComplete?.run();
            });
        }

        public requestVoteSkin(skinId: number, isFemale: boolean, count: number, onComplete: Laya.Handler) {
            if (this.isLocking) return;
            let req: game.IReqVoteActivity = {
                activity_id: isFemale ? UI_Activity_ClothesVote.femaleActivityId : UI_Activity_ClothesVote.maleActivityId,
                vote: skinId,
                count: count
            };
            this.isLocking = true;
            app.Log.log("【Vote】voteActivity:" + JSON.stringify(req))
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.voteActivity, req, (err, res: game.IResVoteActivity) => {
                this.isLocking = false;
                if (err || res['error']) {
                    if (!UI_Activity_ClothesVote.onMaintain(err, res)) {
                       UIMgr.Inst.showNetReqError(game.ERequest.voteActivity, err, res);
                    }
                } else {
                    UI_Activity_ClothesVote.update_vote_data(res.vote_records);
                    UI_LightTips.Inst.show(game.Tools.strOfLocalization(3634));
                    this.freshRedPoint();
                    this.freshVotePage();
                    onComplete?.run();
                }
            });
        }

        public set isLocking(value: boolean) {
            this.locking = value;
        }

        public get isLocking(): boolean {
            return this.locking;
        }

        public onTabChange(isAnim: boolean = true) {
            if (this.tabGroup.selectedIndex == 0) {
                this.pageRank.show();
                this.pageVote.hide();
                if (isAnim) {
                    this.locking = true;
                    this.animMgr.playAnim('rank_show', false, Laya.Handler.create(this, () => {
                    }));
                    this.animMgr.playAnim('vote_hide', false, Laya.Handler.create(this, () => {
                        this.locking = false;
                    }));
                }
                
            } else if (this.tabGroup.selectedIndex == 1) {
               
                this.pageRank.hide();
                this.pageVote.show(isAnim);
                if (isAnim) {
                    this.locking = true;
                    this.animMgr.playAnim('vote_show', false, Laya.Handler.create(this, () => {
                    }));
                    this.animMgr.playAnim('rank_hide', false, Laya.Handler.create(this, () => {
                        this.locking = false;
                    }));
                    this.pageVote.doListAnim();
                }
            }
            
        }

        /**
         * 排名数据变化时调用
         */
        private freshRankPage() {
            //显示3位女性排名
            for (let i = 0; i < 3; i++) {

                if (UI_Activity_ClothesVote.female_vote_rank) {
                    let data = UI_Activity_ClothesVote.female_vote_rank[i];
                    this.pageRank.setFemaleRank(data, i);
                } else {
                    this.pageRank.setFemaleRank(null, i);
                }

            }

            //显示男性排名
            if (UI_Activity_ClothesVote.male_vote_rank) {
                let maleRankData = UI_Activity_ClothesVote.male_vote_rank[0];
                this.pageRank.setMaleRank(maleRankData, 0);
            }
            else {
                this.pageRank.setMaleRank(null, 0);
            }
            this.pageRank.fresh();
        }

        private freshVotePage() { 
            this.pageVote.fresh();
        }

        public checkVoteUpdate() {
            let _data = cfg.activity.vote_activity.get(UI_Activity_ClothesVote.activityId);
            let _t = game.Tools.getTimeByStr(_data.vote_end_time) / 1000;
            //如果投票活动没结束
            if (UI_Activity_ClothesVote.female_update_time < _t || !UI_Activity_ClothesVote.get_vote_ended()) {
                //如果跨天或者超过5分钟，刷新数据
                let isPassFreshTime = !game.Tools.isPassedRefreshTimeServer(UI_Activity_ClothesVote.female_update_time);
                let isPassFiveMinutes = game.Tools.getServerTime() - UI_Activity_ClothesVote.lastUpdateFemaleVoteTime > 5 * 60 * 1000;
                if (isPassFiveMinutes || isPassFreshTime) {
                    UI_Activity_ClothesVote.fetchFemaleRankInfo();
                }
            }

            if (UI_Activity_ClothesVote.male_update_time < _t || !UI_Activity_ClothesVote.get_vote_ended()) {
                //如果跨天或者超过5分钟，刷新数据
                let isPassFreshTime = !game.Tools.isPassedRefreshTimeServer(UI_Activity_ClothesVote.male_update_time);
                let isPassFiveMinutes = game.Tools.getServerTime() - UI_Activity_ClothesVote.lastUpdateMaleVoteTime > 5 * 60 * 1000;
                if (isPassFiveMinutes || isPassFreshTime) {
                    UI_Activity_ClothesVote.fetchMaleRankInfo();
                }
            }
        }

        public checkHotProgressUpdate() {
            //打开界面时检查是否刷新，每5分钟刷新一次
            let currentTime = game.Tools.getServerTime();
            if (currentTime - UI_Activity_ClothesVote.lastUpdateHotProgressTime > 5 * 60 * 1000) {
                UI_Activity_ClothesVote.fetchHotProgressInfo();
            }
        }

        private freshVoteTaskBtn() {
            let isTaskOpen = UI_Activity.activity_is_running(UI_Activity_ClothesVote.voteTaskActivityId);
            this.voteTaskBtn.visible = isTaskOpen;
            this.voteTaskFinish.visible = !isTaskOpen;
            let isVoteOpen = !UI_Activity_ClothesVote.get_vote_ended();
            this.tabButtons[1].visible = isVoteOpen;
            this.tabButtons[0].me.x = isVoteOpen ? 5 : 326;
        }

        private freshVoteItemCount() {
            let count = UI_Bag.get_item_count(UI_Activity_ClothesVote.voteItemId);
            this.voteItemCount.itemCountValue = count;


        }

        public freshHotProgress() {
            this.pageRank.currentHotProgress = UI_Activity_ClothesVote.currentHotProgress;
        }

        public jumpToSkinYulan(skinId: number) {
            if (UI_Activity_ClothesVote.Inst.locking) return;
            this.enable = false;
            let goods = cfg.shops.goods.get(skinId);
            let currentSelectIndex = this.tabGroup.selectedIndex;
            // 保存跳转前的数据
            let isDetailOpen = UI_Activity_ClothesVote_Rank_Detail.Inst.enable;
            let detailScrollRate = 0;
            if (isDetailOpen) {
                detailScrollRate = UI_Activity_ClothesVote_Rank_Detail.Inst.scrollRate;
                UI_Activity_ClothesVote_Rank_Detail.Inst.hide();
            }
            game.Scene_Lobby.Inst.change_bg('indoor', true);
            UI_Skin_Yulan.Inst.show(goods.item_id, Laya.Handler.create(this, () => {
               
                //检测活动是否结束
                if (!UI_Activity.activity_is_running(UI_Activity_ClothesVote.activityId)) {
                    //如果活动结束，获取数据会有问题，所以不刷新
                    this.enable = true;
                    if (isDetailOpen) {
                        UI_Activity_ClothesVote_Rank_Detail.Inst.show(false, false);
                        UI_Activity_ClothesVote_Rank_Detail.Inst.scrollRate = detailScrollRate;
                    }
                    this.onActivityFinish(UI_Activity_ClothesVote.activityId);
                } else {
                    //检测是否在公示期，如果是公示期，则不显示投票页面
                    if (UI_Activity_ClothesVote.get_vote_ended()) {
                        this.show(0, false);
                        this.onTabChange(true);
                    } else {
                        this.show(currentSelectIndex, false);
                    }
                    if (isDetailOpen) {
                        UI_Activity_ClothesVote_Rank_Detail.Inst.show(false, false);
                        UI_Activity_ClothesVote_Rank_Detail.Inst.scrollRate = detailScrollRate;
                    }
                   
                }
                
            }))

        }

        public freshRedPoint() {
            this.voteRedPoint.visible = Page_Vote.haveRedPoint();
            this.rankRedPoint.visible = Page_Rank.haveRedPoint();
            this.taskRedPoint.visible = UI_Activity_ClothesVote_Task.haveRedPoint();
            UI_Lobby.Inst.top.refreshRedpoint();
        }

        private _effects: Array<game.UIEffect> = [];
        public createEffect(node: Laya.Sprite, effect_name: string, offset: Laya.Point, scale: number = 1.0): game.UIEffect {
            let effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(node, effect_name, offset, scale);
            this._add_effect(effect);
            return effect;
        }

        public destroyEffect(effect: game.UIEffect) { 
            if (effect) {
                effect.destory();
                this._remove_effect(effect);
            }
        }

        private _add_effect(effect: game.UIEffect) {
            this._effects.push(effect);
        }

        private _remove_effect(effect: game.UIEffect) {
            let lst: Array<game.UIEffect> = [];
            for (let i: number = 0; i < this._effects.length; i++) {
                if (this._effects[i] !== effect) {
                    lst.push(this._effects[i]);
                }
            }
            this._effects = lst;
        }

        public playAnim(name: string, loop: boolean = false, onComplete: Laya.Handler = null) {
            return this.animMgr.playAnim(name, loop, onComplete);
        }

        public stopAnim(name: string) {
            this.animMgr.stopAnim(name);
        }


        public isAnimPlaying(name: string): boolean {
            return this.animMgr.isAnimRunning(name);
        }


        public onActivityFinish(activityId: number) {
            if (!this.enable) {
                return;
            }
            if (activityId == UI_Activity_ClothesVote.activityId) {
                //弹出提示框
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                    this.hide();
                    UI_Activity_ClothesVote_Task.Inst.hide();
                    UI_Activity_ClothesVote_Rank_Detail.Inst.hide();
                }))
            }
        }

        public onVoteEnd() {
            if (UI_Activity_ClothesVote.get_vote_ended()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25070207), true, Laya.Handler.create(this, () => {
                    //刷新投票页面
                    UI_Activity_ClothesVote.Inst.show(0, false);
                    UI_Activity_ClothesVote.Inst.onTabChange(true);
                }));
                return true;
            }
            return false;
        }

        public static onMaintain(err, res ,isShowPop:boolean = true) {
            if (res && res['error'] && res['error']['code'] && (res['error']['code'] == 26123)) {
                this.isMaintain = true;
                if (isShowPop) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093), Laya.Handler.create(this, () => {
                        if (UI_Activity_ClothesVote.Inst && UI_Activity_ClothesVote.Inst.enable) {
                            UI_Activity_ClothesVote.Inst.hide(true,true);
                            UI_Activity_ClothesVote_Task.Inst.hide();
                            UI_Activity_ClothesVote_Rank_Detail.Inst.hide();
                        }
                    }))
                }
                return true;
            }
            return false;
        }


    }

}