module uiscript {

    class RankItem extends UI_Component {
        private head: UI_Character_Skin;
        private frame: Laya.Image;
        private progressSlider: Laya.Image;
        private progressText: Laya.Text;
        private btn: Laya.Button;
        private speed: number = 370 / 1.5;
        private progressTween1: Laya.Tween;
        private progressTween2: Laya.Tween;

        public onCreate(): void {
            let avatar = this.me.getChildByName('avatar') as Laya.Sprite;
            let headSprite = avatar.getChildByName('head') as Laya.Sprite;
            this.head = new UI_Character_Skin(headSprite, UI_Activity_ClothesVote.activitySign);
            this.frame = avatar.getChildByName('frame') as Laya.Image;
            this.btn = avatar.getChildByName('btn') as Laya.Button;
            let rate = this.me.getChildByName('rate') as Laya.Sprite;
            this.progressSlider = rate.getChildByName('progress_slider') as Laya.Image;
            this.progressText = rate.getChildByName('progress_value') as Laya.Text;
            
        }

        
        public doAnimation(): void {
            let startWidth = 0;
            let endWidth = this.progressSlider.width;
            this.progressWidth = startWidth;
            let tweenTime = endWidth / this.speed * 1000; // 转换为毫秒
            if (this.progressTween1) {
                this.progressTween1.clear();
            }
            this.progressTween1 = Laya.Tween.to(this.progressSlider, { width: endWidth }, tweenTime, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                this.progressWidth = endWidth; // 确保最终宽度正确
                this.progressTween1 = null;
            }));
            if (this.progressTween2) {
                this.progressTween2.clear();
            }
            this.progressTween2 = Laya.Tween.to(this.progressText, { x: this.progressSlider.x + endWidth + 10 }, tweenTime, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                this.progressText.x = this.progressSlider.x + endWidth + 10;
                this.progressTween2 = null;
            }));
        }

        public set headSkin(skinId: number) {
            this.head.setSkin(skinId, 'bighead');
        }

        public set frameSkin(value: string) {
            this.frame.skin = value;
        }

        public set progressSliderSkin(value: string) {
            this.progressSlider.skin = value;
        }

       
        public set progressWidth(value: number) {
            this.progressSlider.width = value;
            this.progressText.x = this.progressSlider.x + this.progressSlider.width + 10;
        }

        public set progressValue(value: string) {
            this.progressText.text = value;
        }

        public set onClickHandler(handler: Laya.Handler) {
            if (this.btn) {
                this.btn.clickHandler = handler;
            }
        }

    }

    class RankLine extends UI_Component {

        private femaleRank: RankItem;
        private maleRank: RankItem;
        public onCreate(): void {
            this.femaleRank = new RankItem(this.me.getChildByName('female') as Laya.Sprite);
            this.maleRank = new RankItem(this.me.getChildByName('male') as Laya.Sprite);
        }

        /**
         * 排名，从1开始
         */
        public set rank(value: number) {
            this.femaleRank.frameSkin = game.Tools.localUISrc(value > 3 ? 'myres/activity_clothes_vote/pop_ranking_avatar_frame_other.png' : `myres/activity_clothes_vote/pop_ranking_avatar_frame_female_${value}.png`);
            this.femaleRank.progressSliderSkin = game.Tools.localUISrc(value > 3 ? 'myres/activity_clothes_vote/pop_ranking_progress_bar_other.png' : `myres/activity_clothes_vote/pop_ranking_progress_bar_${value}.png`);
            this.maleRank.frameSkin = game.Tools.localUISrc(value > 1 ? 'myres/activity_clothes_vote/pop_ranking_avatar_frame_other.png' : `myres/activity_clothes_vote/pop_ranking_avatar_frame_male_${value}.png`);
            this.maleRank.progressSliderSkin = game.Tools.localUISrc(value > 1 ? 'myres/activity_clothes_vote/pop_ranking_progress_bar_other.png' : `myres/activity_clothes_vote/pop_ranking_progress_bar_${value}.png`);
        }

        public setFemaleRankData(data: IRankRenderData) {
            if (data) {
                let goodsId = data.id;
                let skinId = cfg.shops.goods.get(goodsId).item_id;
                this.femaleRank.headSkin = skinId;
                this.femaleRank.progressWidth = data.progressWidth;
                let rate = game.Tools.toFixedDown(data.progressValue / 100, 1);
                this.femaleRank.progressValue = rate + '%';
                this.femaleRank.onClickHandler = new Laya.Handler(this, () => {
                    if (UI_Activity_ClothesVote_Rank_Detail.Inst.isLocking) return;
                    UI_Activity_ClothesVote.Inst.jumpToSkinYulan(data.id);
                });
                
            } else {
                this.femaleRank.visible = false;
            }

        }

        public setMaleRankData(data: IRankRenderData) {
            if (data) {
                this.maleRank.visible = true;
                let goodsId = data.id;
                let skinId = cfg.shops.goods.get(goodsId).item_id;
                this.maleRank.headSkin = skinId;
                this.maleRank.progressWidth = data.progressWidth;
                let rate = game.Tools.toFixedDown(data.progressValue / 100, 1);
                this.maleRank.progressValue = rate + '%';
                this.maleRank.onClickHandler = new Laya.Handler(this, () => {
                    if (UI_Activity_ClothesVote_Rank_Detail.Inst.isLocking) return;
                    UI_Activity_ClothesVote.Inst.jumpToSkinYulan(data.id);
                });
            } else {
                this.maleRank.visible = false;
            }
        }

        public doAnimation(): void {
            if (this.femaleRank.visible) {
                this.femaleRank.doAnimation();
            }
            if (this.maleRank.visible) {
                this.maleRank.doAnimation();
            }
        }


    }

    interface IRankRenderData{
        id: number;
        progressWidth: number;
        progressValue: number;
    }

    export class UI_Activity_ClothesVote_Rank_Detail extends UIBase {
        public static Inst: UI_Activity_ClothesVote_Rank_Detail = null;
        constructor() {
            super(new ui.lobby.activity_clothes_vote.activity_clothes_vote_rank_detailUI());
            UI_Activity_ClothesVote_Rank_Detail.Inst = this;
        }

        private locking: boolean = false;
        private root: Laya.Sprite;
        private femaleRankMax: number = 10;
        private maleRankMax: number = 5;
        private femaleRankList: Array<IRankRenderData> = [];
        private maleRankList: Array<IRankRenderData> = [];
        private list: Laya.Sprite;
        private empty: Laya.Sprite;
        private rankLinetemplate: Laya.Sprite;
        private task_cells: Array<RankLine>;
        private scrollPanel: ScrollPanel;
        private freshTime: Laya.Sprite;

        public get isLocking(): boolean {
            return this.locking;
        }

        public onCreate(): void {
            let blackMask = this.me.getChildByName('black_mask');
            let maskCloseBtn = blackMask.getChildByName('mask_close_btn') as Laya.Button;
            maskCloseBtn.clickHandler = new Laya.Handler(this, this.hide);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            let btnBack: Laya.Button = this.root.getChildByName('close_btn') as Laya.Button;
            btnBack.clickHandler = new Laya.Handler(this, this.hide);
            this.list = this.root.getChildByName('content') as Laya.Sprite;
            this.empty = this.root.getChildByName('empty') as Laya.Sprite;
            this.scrollPanel = new ScrollPanel(this.root.getChildByName('content') as Laya.Sprite);
            this.rankLinetemplate = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.rankLinetemplate.visible = false;
            this.task_cells = [];
            for (let i: number = 0; i < 10; i++) {
                let taskCell = new RankLine(this.rankLinetemplate.scriptMap['capsui.UICopy']['getNodeClone']());
                this.scrollPanel.content.addChild(taskCell.me);
                this.task_cells.push(taskCell);
                taskCell.rank = i + 1; // 设置排名，从1开始

            }
            this.freshTime = this.root.getChildByName('fresh_time') as Laya.Sprite;
        }

        public onEnable(): void {
           
        }

        public onDisable(): void {
            
        }

        public show(isReset: boolean = true, isAnim: boolean = true) {
           
            this.fresh();
            if (isReset) {
                this.scrollPanel.rate = 0;
            }
            this.enable = true;
            
            
           
            if (isAnim) {
                this.locking = true;
                UIBase.anim_pop_out(this.root, null);
                this.doAnimation();
                Laya.timer.once(1500, this, () => {
                    this.locking = false;
                });
            } else {
                this.locking = true;
                UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                    this.locking = false;
                }))
            }
        }

        public hide() {
            if (this.locking) return;
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public fresh() {
            let femaleRankList = UI_Activity_ClothesVote.female_vote_rank;
            let maleRankList = UI_Activity_ClothesVote.male_vote_rank;
            //如果没有排名，则显示空状态
            if ((femaleRankList.length < 1 && maleRankList.length < 1)||(!femaleRankList && !maleRankList)) {
                this.list.visible = false;
                this.empty.visible = true;
                return;
            }
            this.list.visible = true;
            this.empty.visible = false;
            let femaleRankCount = femaleRankList.length > this.femaleRankMax ? this.femaleRankMax : femaleRankList.length;
            let maleRankCount = maleRankList.length > this.maleRankMax ? this.maleRankMax : maleRankList.length;
           
            //处理数据
            this.femaleRankList = [];
            //第一名宽度为370，宽度最小为12，第一名宽度固定为370，其它名次的宽度 = 370/第一名的比例*目标比例
            let firstPlaceWidth = 370;
            let minWidth = 12;
            for (let i = 0; i < femaleRankCount; i++) {
                let newData: IRankRenderData = {
                    id: femaleRankList[i].id,
                    progressWidth: 0,
                    progressValue: femaleRankList[i].share,
                }
                let width = i == 0 ? firstPlaceWidth : Math.max(minWidth, firstPlaceWidth * femaleRankList[i].share / this.femaleRankList[0].progressValue);
                newData.progressWidth = width;
                this.femaleRankList.push(newData);
            }
            this.maleRankList = [];
            //第一名宽度为370，宽度最小为12，第一名宽度固定为370，其它名次的宽度 = 370/第一名的比例*目标比例
            for (let i = 0; i < maleRankCount; i++) {
                let newData: IRankRenderData = {
                    id: maleRankList[i].id,
                    progressWidth: 0,
                    progressValue: maleRankList[i].share,
                }
                let width = i == 0 ? firstPlaceWidth : Math.max(minWidth, firstPlaceWidth * maleRankList[i].share / this.maleRankList[0].progressValue);
                newData.progressWidth = width;
                this.maleRankList.push(newData);
            }
            this.freshList();
            this.freshTime.visible = !UI_Activity_ClothesVote.get_vote_ended();

        }


        public get scrollRate(): number {
            return this.scrollPanel.rate;
        }

        public set scrollRate(value: number) {
            this.scrollPanel.rate = value;
        }

        private doAnimation(): void { 
            for (let i = 0; i < this.task_cells.length; i++) {
                let item: RankLine = this.task_cells[i];
                if (item) {
                    item.doAnimation();
                }
            }
        }

        private freshList() {
            let listCount = this.femaleRankList.length > this.maleRankList.length ? this.femaleRankList.length : this.maleRankList.length;
            let h: number = 0;
            for (let i: number = 0; i < this.task_cells.length; i++) {
                let taskCell = this.task_cells[i];
                if (i < listCount) {
                    taskCell.me.y = h;
                    h += taskCell.me.height;
                    let femaleRankData: IRankRenderData = this.femaleRankList[i];
                    let maleRankData: IRankRenderData = this.maleRankList[i];
                    taskCell.setFemaleRankData(femaleRankData);
                    taskCell.setMaleRankData(maleRankData);
                    taskCell.visible = true;

                } else {
                    taskCell.visible = false;
                }
            }
            this.scrollPanel.contentHeight = h;
            this.scrollPanel.fresh();
        }

    }

}