module uiscript {

    class TaskCell extends UI_Component {
        private item_icon: Laya.Image;
        private item_count: Laya.Label;
        private task_name: Laya.Label;
        private btn_get: Laya.Button;
        private getted: Laya.Image;
        private doing: Laya.Image;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;
        private bg: Laya.Image;

        private id: number = 0;
        private item_id: number = 0;

        public onCreate(): void {
            this.me.visible = false;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.task_name = this.me.getChildByName('taskname') as Laya.Label;

            this.item_icon = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.item_count = this.me.getChildByName('item').getChildByName('count').getChildByName('count') as Laya.Label;
            this.progress_bar = this.me.getChildByName('bar').getChildByName('val') as Laya.Sprite;
            this.progress_label = this.me.getChildByName('progress') as Laya.Label;
            this.btn_get = this.me.getChildByName('btn_get') as Laya.Button;
            this.getted = this.me.getChildByName('received') as Laya.Image;
            this.doing = this.me.getChildByName('doing') as Laya.Image;
            (this.me.getChildByName('item').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);

            this.btn_get.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_ClothesVote_Task.Inst.locking) return;
               
                //检测活动是否在进行中,不在进行中弹出提示，25070207
                if (UI_Activity_ClothesVote.get_vote_ended()) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25070207), true, Laya.Handler.create(this, () => {
                        //关闭当前页面，刷新投票页面
                        UI_Activity_ClothesVote_Task.Inst.hide();
                        UI_Activity_ClothesVote.Inst.show(0, false);
                    }));
                    return;

                }
                //如果跨天了，则弹出提示
                if (!game.Tools.isPassedRefreshTimeServer(UI_Activity_ClothesVote_Task.Inst.lastShowTime)) {
                    UI_Activity_ClothesVote_Task.Inst.onPassFreshTime();
                    return;
                }
                UI_Activity_ClothesVote_Task.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: this.id }, (err, res) => {
                    UI_Activity_ClothesVote_Task.Inst.locking = false;
                    if (err || res['error']) {
                        if (!UI_Activity_ClothesVote.onMaintain(err, res)) {
                            if (err && err.code == 2604) {
                                UI_Activity_ClothesVote_Task.Inst.onPassFreshTime();
                            }
                            else {
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            }
                        }
                        
                    } else {
                        let d_activity_task = cfg.activity.period_task.get(this.id);
                        let items = [];
                        let rewards = d_activity_task.reward.split('-');
                        items.push({ id: Number(rewards[0]), count: Number(rewards[1]) });
                        game.Tools.showRewards({ rewards: items }, null);
                        this.btn_get.visible = false;
                        this.getted.visible = true;
                        UI_Activity.onPeriodTaskRewarded(this.id);
                        UI_Activity_ClothesVote_Task.Inst.onClickGet();
                    }
                });
            });
        }


        public show(info: game.ITaskProgress) {
            this.me.visible = true;
            if (!info) {
                this.me.visible = false;
                return;
            }
            let id = info.id;
            this.id = id;
            let isYueka: boolean = (id == UI_Activity_ClothesVote.voteYuekaTaskActivityId);
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            this.bg.skin = game.Tools.localUISrc(isYueka ? "myres/activity_clothes_vote/pop_task_item_bg_sp.png" : "myres/activity_clothes_vote/pop_task_item_bg.png");
            this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
            let reward = d_activity_task.reward.split('-');
            this.item_id = parseInt(reward[0]);
            let d_view = game.GameUtility.get_item_view(this.item_id);
            game.LoadMgr.setImgSkin(this.item_icon, d_view.icon, null, 'UI_Activity_Combining');
            this.item_count.text = reward[1];
            let counter: number = info.counter;
            if (!counter) counter = 0;

            this.progress_bar.width = counter == 0 ? 4 : Math.min(1, counter / d_task_info.target) * 300;
            this.progress_label.text = Math.min(counter, d_task_info.target) + '/' + d_task_info.target;


            this.getted.visible = false;
            this.btn_get.visible = false;
            this.doing.visible = false;

            if (info.rewarded) {
                this.getted.visible = true;
            }
            else {
                if (info.achieved) {
                    this.btn_get.visible = true;
                }
                else {
                    this.doing.visible = true;
                }
            }

        }

    }

    export class UI_Activity_ClothesVote_Task extends UIBase {
        public static Inst: UI_Activity_ClothesVote_Task = null;
        public static haveGetReward(): boolean {
            let lst = this.getTaskList();
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }

        public static getTaskList() {
            let taskList: Array<Object> = [];
            let taskData = UI_Activity.getPeriodTaskList(UI_Activity_ClothesVote.voteTaskActivityId);
            if (taskData) {
                taskList = game.Tools.deepCopy<Array<Object>>(taskData);
            }
            //添加月卡任务
            let yuekaInfo = UI_Activity.getPeriodTaskInfo(UI_Activity_ClothesVote.voteYuekaTaskActivityId);
            if (yuekaInfo) {
                taskList.push(yuekaInfo);
            }
            return taskList;
        }


        constructor() {
            super(new ui.lobby.activity_clothes_vote.activity_clothes_vote_taskUI());
            UI_Activity_ClothesVote_Task.Inst = this;
        }

        public locking: boolean = false;
        private root: Laya.Sprite;
        private task_templete: Laya.Sprite;
        private task_cells: Array<TaskCell>;
        private scrollPanel: ScrollPanel;
        public lastShowTime: number = 0;
        private taskList: Array<Object> = [];
        private receiverAllBtn: Laya.Button;
        private ticketCountLabel: Laya.Label;
        private ticketInfoBtn: Laya.Button;

        public onCreate(): void {
            let blackMask = this.me.getChildByName('black_mask');
            let maskCloseBtn = blackMask.getChildByName('mask_close_btn') as Laya.Button;
            maskCloseBtn.clickHandler = new Laya.Handler(this, this.hide);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            let btnBack: Laya.Button = this.root.getChildByName('close_btn') as Laya.Button;
            btnBack.clickHandler = new Laya.Handler(this, this.hide);
            this.scrollPanel = new ScrollPanel(this.root.getChildByName('scroll_panel') as Laya.Sprite);
            this.task_templete = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.task_templete.visible = false;
            this.task_cells = [];
            for (let i: number = 0; i < 5; i++) {
                this.createTaskCell();
            }
            this.receiverAllBtn = this.root.getChildByName('receive_all_btn') as Laya.Button;
            this.receiverAllBtn.clickHandler = new Laya.Handler(this, this.onClickGetAll);
            
            this.ticketCountLabel = this.root.getChildByName('ticket_count').getChildByName('value') as Laya.Label;
            this.ticketInfoBtn = this.root.getChildByName('ticket_count').getChildByName('btn') as Laya.Button;
            this.ticketInfoBtn.clickHandler = new Laya.Handler(this, () => { 
                UI_ItemDetail.Inst.show(UI_Activity_ClothesVote.voteItemId);
            });
            UI_Bag.add_item_listener(UI_Activity_ClothesVote.voteItemId, Laya.Handler.create(this, () => {
                if (this.enable) {
                    this.freshTicketCount();
                }
            }, null, false));
        }

        public show() {
            this.enable = true;
            this.lastShowTime = Math.floor(game.Tools.getServerTime() / 1000);
            this.freshPage();
            this.locking = true;
            UIBase.anim_pop_out(this.root, null);
            this.doListAnim(Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public hide() {
            if (this.locking) return;
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public onEnable(): void {


        }

        public onDisable(): void {

        }

        public static haveRedPoint(): boolean {
            //如果活动没在进行中，则不显示红点
            if (UI_Activity_ClothesVote.get_vote_ended()) {
                return false;
            }
            return UI_Activity_ClothesVote_Task.haveGetReward();
        }

        private freshPage() {
            this.freshData();
            this.resetTaskList();
            this.freshGetAllBtn();
            this.freshTicketCount();
            this.scrollPanel.scrollValue = 0;
        }

        private freshData() {
            this.taskList = game.Tools.deepCopy(UI_Activity_ClothesVote_Task.getTaskList());
            this.taskList = this.taskList.sort((a, b) => {
                return this.sortTasks(a as game.ITaskProgress, b as game.ITaskProgress);
            });
        }

        private freshGetAllBtn() { 
            let receiveIcon = this.receiverAllBtn.getChildByName('icon') as Laya.Image;
            let receiveText = this.receiverAllBtn.getChildByName('value') as Laya.Label;
            let hasReward = UI_Activity_ClothesVote_Task.haveGetReward();
            receiveIcon.skin = game.Tools.localUISrc(hasReward ? "myres/activity_clothes_vote/pop_task_receive_btn.png" : "myres/activity_clothes_vote/pop_task_receive_btn_g.png");
            receiveText.color = hasReward ? "#7f442d" : "#a89188";
            this.receiverAllBtn.mouseEnabled = hasReward;
        }

   

        public onClickGetAll() {
            if (this.locking) {
                return;
            }
            //检测活动是否在进行中,不在进行中弹出提示，25070207
            if (UI_Activity_ClothesVote.get_vote_ended()) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25070207), true, Laya.Handler.create(this, () => {
                    //关闭当前页面，刷新投票页面
                    UI_Activity_ClothesVote_Task.Inst.hide();
                    UI_Activity_ClothesVote.Inst.show(0, false);
                }));
                return;

            }
            //如果跨天了，则弹出提示
            if (!game.Tools.isPassedRefreshTimeServer(this.lastShowTime)) {
                this.onPassFreshTime();
                return;
            }
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = UI_Activity_ClothesVote_Task.getTaskList();
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }
            if (needGetList.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err: game.IError, res) => {
                this.locking = false;
                if (err || res['error']) {
                    if (!UI_Activity_ClothesVote.onMaintain(err, res)) {
                        if (err && err.code == 2604) {
                            this.onPassFreshTime();
                        }
                        else {
                            UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                        }
                    }
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        rewardList.push({ id: rewardId, count: rewardCount });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                    this.onClickGet();
                }
            })
        }






        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.id == UI_Activity_ClothesVote.voteYuekaTaskActivityId && !task.rewarded) {
                weight += 10000; // 未领取月卡任务优先级最高
            }
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }


        private resetTaskList() {
            //如果cell不足，创建新的cell
            while (this.task_cells.length < this.taskList.length) {
                this.createTaskCell();
            }
            let h: number = 0;
            for (let i: number = 0; i < this.task_cells.length; i++) {
                let taskCell = this.task_cells[i];
                if (i < this.taskList.length) {
                    taskCell.me.y = h;
                    h += taskCell.me.height;
                    taskCell.show(this.taskList[i] as game.ITaskProgress);
                    taskCell.visible = true;
                    
                } else {
                    taskCell.me.visible = false;
                }
            }
            this.scrollPanel.contentHeight = h;
            this.scrollPanel.fresh();
        }



      

        private createTaskCell(): TaskCell {
            let taskCell = new TaskCell(this.task_templete.scriptMap['capsui.UICopy']['getNodeClone']());
            this.scrollPanel.content.addChild(taskCell.me);
            this.task_cells.push(taskCell);
            return taskCell;
        }

        public onPassFreshTime() {
            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(20211), true, Laya.Handler.create(this, () => {
                this.freshPage();
            }));
        }

       
        /**
         * 如果点击了对应的任务，会调用这个函数去改变当前数据和UI展示
         * @param index 
         */
        public onClickGet() {
            this.freshGetAllBtn();
            this.freshTaskList();
            //刷新大厅红点
            UI_Lobby.Inst.top.refreshRedpoint();
        }

        public freshTaskList() {
            for (let index = 0; index < this.taskList.length; index++) {
                const element = this.taskList[index];
                let newData = game.Tools.deepCopy(UI_Activity.getPeriodTaskInfo(element['id']));
                if (newData) {
                    this.taskList[index] = newData;
                }
            }
            for (let index = 0; index < this.task_cells.length; index++) {
                const element = this.task_cells[index];
                let data = this.taskList[index];
                if (data) {
                    element.show(data as game.ITaskProgress);
                }
            }
        }

        public freshTicketCount() {
            let count = UI_Bag.get_item_count(UI_Activity_ClothesVote.voteItemId);
            this.ticketCountLabel.text = count.toString();
        }


        private doListAnim(onComplete: Laya.Handler) {
            for (let i: number = 0; i < this.task_cells.length; i++) {
                let taskCell = this.task_cells[i];
                if (taskCell.me.visible) {
                    //从下往上滑的： 延迟0.1s，移动距离Y轴100，alpha0开始，单个时间0.15s，间隔时间0.066s， quadInOut
                    let delay = 100 + (this.task_cells.length - i - 1) * 66;
                    let begingY = taskCell.me.y + 100;
                    let endY = taskCell.me.y;
                    let beginAlpha = 0;
                    let endAlpha = 1;
                    taskCell.me.alpha = beginAlpha;
                    taskCell.me.y = begingY;
                    Laya.Tween.to(taskCell.me, { alpha: endAlpha, y: endY }, 150, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                        taskCell.me.alpha = endAlpha;
                        taskCell.me.y = endY;
                        if (i == 0) {
                            if (onComplete) {
                                onComplete.run();
                            }
                        }
                    }), delay);
                }
            }
           
        }

    }

}