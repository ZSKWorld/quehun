module uiscript {

    enum EEnemyState {
        NONE,
        IDLE,
        HIT,
        DEATH
    }

    enum EPlaneState {
        NONE,
        IDLE,
        MOVE,
        ATTACK
    }

    enum EStickState {
        NONE,
        MIDDLE,
        LEFT,
        RIGHT
    }

    interface IPageRewardData {
        rewardId: number;
        itemId: number;
        itemCount: number;
        data: lqc.Sheet_Shoot_ShootReward;
    }

    interface IEnemyData {
        enemyId: number;
        posX: number;
        posY: number;
        maxHp: number;
        currentHp: number;
        levelIndex: number;
        levelId: number;
        width: number;
    }

    interface ILevelData {
        level: number;
        enemies: IEnemyData[];
    }

    interface IAttackOrder {
        enemyId: number;
        damage: number;
        onShootComplete: Laya.Handler;
        /**
         * 有时候会有下一关的攻击指令，需要等下一关在执行
         */
        levelId: number;
        pos: number;
    }

    class Plane extends UI_Component {

        static create(): Laya.Sprite {
            let sprite = new ui.lobby.activity_shoot.activity_shoot_planeUI();
            return sprite;
        }

        private animController: UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_planeUI>;
        private animState: EPlaneState = EPlaneState.NONE;
        private moveAudioId: number = -1;
        public onCreate(): void {
            this.animController = new UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_planeUI>(this.me);
            this.animState = EPlaneState.NONE;
        }

        public set posX(value: number) {
            this.me.x = value;
        }

        public set posY(value: number) {
            this.me.y = value;
        }

        public get posX(): number {
            return this.me.x;
        }

        public get posY(): number {
            return this.me.y;
        }

        public get state(): EPlaneState {
            return this.animState;
        }

        public set state(value: EPlaneState) {
            if (this.animState == value) {
                return;
            }    
            this.animState = value;
            this.animController.stopAllAnimations();
            this.stopMoveAudio();
            switch (this.animState) {
                case EPlaneState.IDLE:
                    this.animController.playAnim("idle", true);
                    break;
                case EPlaneState.MOVE:
                    this.animController.playAnim("attack", false);
                    this.moveAudioId = view.AudioMgr.PlayAudio(10366, 0);
                    break;
                case EPlaneState.NONE:
                    break;
                case EPlaneState.ATTACK:
                    this.animController.playAnim("attack", false);
                    break;
            }
        }

        public onDisable(): void {
            this.state = EPlaneState.NONE;
        }

        private stopMoveAudio() { 
            if (this.moveAudioId != -1) {
                view.AudioMgr.StopAudio(this.moveAudioId);
                this.moveAudioId = -1;
            }
        }


    }

    class Bullet extends UI_Component {
        public static createTimes: number = 0;
        public static create(): Laya.Sprite {
            let sprite = new ui.lobby.activity_shoot.activity_shoot_bulletUI();
            this.createTimes++;
            return sprite;
        }
        private recoverHandler: Laya.Handler;
        private entityId: number = -1;
        private isRecover: boolean = false;
        constructor(comp: Laya.Sprite, entityId: number) {

            super(comp);
            this.entityId = entityId;
        }
        public onCreate(): void {

        }
        public set onRecover(handler: Laya.Handler) {
            this.recoverHandler = handler;
        }

        public recover() {
            if (this.isRecover) {
                return;
            }
            this.isRecover = true;
            this.me.removeSelf();
            this.me.visible = false;
            if (this.recoverHandler) {
                this.recoverHandler.run();
            }

        }
        public get id(): number {
            return this.entityId;
        }

        public set posX(value: number) {
            this.me.x = value;
        }

        public set posY(value: number) {
            this.me.y = value;
        }

        public get posX(): number {
            return this.me.x;
        }

        public get posY(): number {
            return this.me.y;
        }
    }

    class Enemy extends UI_Component {
        public static createTimes: number = 0;
        public static create(hp: number): Laya.Sprite {
            let sprite = null;
            if (hp == 1) {
                sprite = new ui.lobby.activity_shoot.activity_shoot_monster_smallUI();
            } else if (hp == 2) {
                sprite = new ui.lobby.activity_shoot.activity_shoot_monster_midUI();
            } else {
                sprite = new ui.lobby.activity_shoot.activity_shoot_monster_bigUI();
            }
            return sprite;
        }

        private recoverHandler: Laya.Handler;
        private data: IEnemyData;
        private entityId: number = -1;
        private isRecover: boolean = false;
        private root: Laya.Sprite;
        private hpSlider: Laya.Sprite;
        private hpVal: Laya.Image;
        private sliderMaxWidth: number = 90;
        private body: Laya.Image;
        private leftHand: Laya.Image;
        private rightHand: Laya.Image;
        private leftLeg: Laya.Image;
        private rightLeg: Laya.Image;
        private leftHandExtended: Laya.Image;
        private rightHandExtended: Laya.Image;
        private animController: UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_monster_smallUI | ui.lobby.activity_shoot.activity_shoot_monster_midUI | ui.lobby.activity_shoot.activity_shoot_monster_bigUI>;
        private animState: EEnemyState = EEnemyState.NONE;
        private effectOffset: Laya.Point = new Laya.Point(0, 0);
        public get state(): EEnemyState {
            return this.animState;
        }


        constructor(comp: Laya.Sprite, maxHp: number) {
            Enemy.createTimes++;
            super(comp);
            if (maxHp == 1) {
                this.animController = new UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_monster_smallUI>(comp);
            } else if (maxHp == 2) {
                this.animController = new UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_monster_midUI>(comp);
            } else {
                this.animController = new UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shoot_monster_bigUI>(comp);
            }
            this.entityId = Enemy.createTimes;
            this.changeState(EEnemyState.NONE);
            this.effectOffset = new Laya.Point(this.me.width / 2, this.me.height / 2);
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.hpSlider = this.root.getChildByName('hp_slider') as Laya.Sprite;
            this.hpVal = this.hpSlider.getChildByName('val') as Laya.Image;
            this.hpSlider.visible = false;
            let monster = this.root.getChildByName('monster') as Laya.Sprite;
            this.body = monster.getChildByName('body') as Laya.Image;
            let hand = monster.getChildByName('hand') as Laya.Sprite;
            if (hand) {
                this.leftHand = hand.getChildByName('left_hand') as Laya.Image;
                this.rightHand = hand.getChildByName('right_hand') as Laya.Image;
                this.leftHandExtended = this.leftHand.getChildByName('extend') as Laya.Image;
                this.rightHandExtended = this.rightHand.getChildByName('extend') as Laya.Image;
            }

            let leg = monster.getChildByName('leg') as Laya.Sprite;
            if (leg) {
                this.leftLeg = leg.getChildByName('left_leg') as Laya.Image;
                this.rightLeg = leg.getChildByName('right_leg') as Laya.Image;
            }



        }

        public set onRecover(handler: Laya.Handler) {
            this.recoverHandler = handler;
        }

        public set enemyData(data: IEnemyData) {
            this.data = game.Tools.deepCopy(data);
            this.render();
        }

        public get enemyData(): IEnemyData {
            return this.data;
        }

        public set pos(pos: Laya.Vector2) {
            this.me.pos(pos.x, pos.y);
        }

        public set posY(value: number) {
            this.me.y = value;
        }

        public set posX(value: number) {
            this.me.x = value;
        }

        public get posY(): number {
            return this.me.y;
        }

        public get posX(): number {
            return this.me.x;
        }

        public recover() {
            if (this.isRecover) {
                return;
            }
            this.isRecover = true;
            this.animController.stopAllAnimations();
            this.me.removeSelf();
            this.me.visible = false;
            if (this.recoverHandler) {
                this.recoverHandler.run();
            }

        }

        public get id(): number {
            return this.entityId;
        }

        private render() {
            if (!this.enemyData) {
                return;
            }
            let color: string = this.enemyData.levelIndex == 0 ? 'blue' : this.enemyData.levelIndex == 1 ? 'yellow' : 'red';
            let size: string = this.enemyData.maxHp == 1 ? 'small' : this.enemyData.maxHp == 2 ? 'mid' : 'big';
            let basePath = `myres/activity_shoot/main_game_monster_${size}_${color}`;
            this.body.skin = game.Tools.localUISrc(`${basePath}_body.png`);
            if (this.leftHand) {
                this.leftHand.skin = game.Tools.localUISrc(`${basePath}_left_hand.png`);
            }
            if (this.rightHand) {
                this.rightHand.skin = game.Tools.localUISrc(`${basePath}_right_hand.png`);
            }
            if (this.leftHandExtended) {
                this.leftHandExtended.skin = game.Tools.localUISrc(`${basePath}_left_hand1.png`);
            }
            if (this.rightHandExtended) {
                this.rightHandExtended.skin = game.Tools.localUISrc(`${basePath}_right_hand1.png`);
            }
            if (this.leftLeg) {
                this.leftLeg.skin = game.Tools.localUISrc(`${basePath}_left_leg.png`);
            }
            if (this.rightLeg) {
                this.rightLeg.skin = game.Tools.localUISrc(`${basePath}_right_leg.png`);
            }
            this.hp = this.enemyData.currentHp;
            if (this.enemyData.currentHp <= 0) {
                this.visible = false;
                this.animState = EEnemyState.DEATH;
            } else {
                this.visible = true;
            }
        }

        public set hp(val: number) {
            this.hpSlider.visible = val != this.enemyData.maxHp;
            let hpRate = val / this.enemyData.maxHp;
            this.hpVal.width = this.sliderMaxWidth * hpRate;
            this.enemyData.currentHp = val;
        }

        public get hp(): number {
            return this.enemyData.currentHp;
        }

        public onAttack(damage: number = 1, onAttackComplete: Laya.Handler = null) {
            view.AudioMgr.PlayAudio(10368);
            //最小的怪没有血条,受击,死亡动画，没有死亡特效
            let newHp = this.hp - damage;
            newHp = Math.max(0, newHp);
            UI_Activity_Shoot.Inst.createHitEffect(this.root, this.effectOffset);
            if (this.enemyData.maxHp == 1) {
                this.hp = newHp;

                if (newHp == 0) {
                    this.changeState(EEnemyState.DEATH);
                    this.hpSlider.visible = false;
                    this.visible = false;
                }
                //等待死亡特效播放完毕
                let waitingTime = Math.floor(300 / UI_Activity_Shoot.Inst.speed);
                Laya.timer.once(waitingTime, this, () => {
                    onAttackComplete?.run();
                });
                return;
            }
            let isHpAnimComplete = false;
            let isHitAnimComplete = false;
            this.doHpAnimation(newHp, Laya.Handler.create(this, () => {
                isHpAnimComplete = true;
                if (isHpAnimComplete && isHitAnimComplete) {
                    if (newHp == 0) {
                        this.hpSlider.visible = false;
                        this.visible = false;
                    }
                    onAttackComplete?.run();
                }
            }));
            if (newHp == 0) {
                UI_Activity_Shoot.Inst.createDeathEffect(this.root, this.effectOffset);
                this.changeState(EEnemyState.DEATH, Laya.Handler.create(this, () => {
                    isHitAnimComplete = true;
                    if (isHpAnimComplete && isHitAnimComplete) {
                        this.hpSlider.visible = false;
                        this.visible = false;
                        onAttackComplete?.run();
                    }
                }));
            } else {
                this.changeState(EEnemyState.HIT, Laya.Handler.create(this, () => {
                    isHitAnimComplete = true;
                    if (isHpAnimComplete && isHitAnimComplete) {
                        onAttackComplete?.run();
                    }
                }));
            }
        }



        public get attackPointY() {
            //最底部为攻击点
            return this.me.y + this.me.height;
        }

        public doHpAnimation(val: number, onComplete: Laya.Handler = null) {
            //5帧（0.0833秒）1点血
            this.hpSlider.visible = val != this.enemyData.maxHp;
            let hpRate = val / this.enemyData.maxHp;
            let newWidth = this.sliderMaxWidth * hpRate;
            Laya.Tween.to(this.hpVal, { width: newWidth }, 83.3, Laya.Ease.quadOut, Laya.Handler.create(this, () => {
                onComplete?.run();
            }));
            this.enemyData.currentHp = val;
        }


        public changeState(value: EEnemyState, onComplete: Laya.Handler = null) {
            if (this.animState == value) {
                return;
            }
            this.animState = value;
            this.animController.stopAllAnimations();
            switch (this.animState) {
                case EEnemyState.IDLE:
                    this.animController.playAnim("idle", true);
                    onComplete?.run();
                    break;
                case EEnemyState.HIT:
                    this.animController.playAnim("hit", false, Laya.Handler.create(this, () => {
                        this.changeState(EEnemyState.IDLE);
                        onComplete?.run();
                    }), UI_Activity_Shoot.Inst.speed);
                    break;
                case EEnemyState.DEATH:
                    let isHitComplete: boolean = false;
                    let isDeathComplete: boolean = false;
                    this.animController.playAnim("hit", false, Laya.Handler.create(this, () => {
                        isHitComplete = true;
                        if (isHitComplete && isDeathComplete) {
                            onComplete?.run();
                        }
                    }), UI_Activity_Shoot.Inst.speed);
                    this.animController.playAnim("death", false, Laya.Handler.create(this, () => {
                        isDeathComplete = true;
                        if (isHitComplete && isDeathComplete) {
                            onComplete?.run();
                        }
                    }), UI_Activity_Shoot.Inst.speed);
                    view.AudioMgr.PlayAudio(10369);
                case EEnemyState.NONE:
                    break;
            }
        }

        public onDisable(): void {

        }


    }


    class Page_Game extends UI_Component {
        private bornPosesY: number[] = [334, 201, 30];
        private planeBornPosY: number = 554;
        private bulletBornPosY: number = 495;
        private gridSpace: number = 24;
        private maxGrid: number = 32;
        private scene: Laya.Sprite;
        private bulletParent: Laya.Sprite;
        private enemyParent: Laya.Sprite;
        private emptySprite: Laya.Sprite;
        private bullets: Bullet[] = [];
        private enemies: Enemy[] = [];
        private plane: Plane;
        private levelCount: Laya.Image;
        private bulletCount: UI_ImageNumber;
        private enemyPoolSign: string = 'activity_shoot_enemy';
        private bulletPoolSign: string = 'activity_shoot_bullet';
        /**
         * 飞机移动速度,单位每帧4.5像素(60帧每秒)
         */
        private planeMoveSpeed: number = 4.5;
        /**
         * 攻击间隔,单位毫秒
         */
        private attackSpace: number = 416;
        /**
         * 1毫秒移动0.96像素
         */
        private bulletMoveSpeed: number = 0.96;
        private attackOrder: IAttackOrder[] = [];
        private helpBtn: Laya.Button;
        private defaultBulletDamage: number = 1;
        private helpGrids: Laya.Sprite;
        private isRunAttackOrder: boolean = false;
        private planeMoveTween: Laya.Tween = null;
        private bulletMoveTween: Laya.Tween = null;


        public onCreate(): void {
            this.scene = this.me.getChildByName('scene') as Laya.Sprite;
            this.emptySprite = this.me.getChildByName('empty') as Laya.Sprite;
            this.bulletParent = this.scene.getChildByName('bullets_parent') as Laya.Sprite;
            this.enemyParent = this.scene.getChildByName('monsters_parent') as Laya.Sprite;
            let levelSprite = this.me.getChildByName('level') as Laya.Sprite;
            this.levelCount = levelSprite.getChildByName('count') as Laya.Image;
            let levelTitle = levelSprite.getChildByName('title') as Laya.Image;
            this.levelCount.x = levelTitle.x + levelTitle.width + 20;
            let bulletSprite = this.me.getChildByName('bullet_count') as Laya.Sprite;
            this.bulletCount = new UI_ImageNumber(bulletSprite.getChildByName('count') as Laya.Sprite);
            let count_path = [];
            for (let index = 0; index < 10; index++) {
                let path = 'myres/activity_shoot/number_bullet_' + index + '.png';
                count_path.push(game.Tools.localUISrc(path));
            }
            this.bulletCount.init(count_path, 0,null,null,null, 3);
            this.bulletCount.align = 'left';
            this.createPlane();
            this.resetPlanePos();
            this.helpBtn = this.me.getChildByName('top').getChildByName('help_btn') as Laya.Button;
            this.helpBtn.clickHandler = Laya.Handler.create(this, () => {
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(25110101));
            }, null, false);
            this.emptySprite.visible = false;
            this.helpGrids = this.me.getChildByName('grids') as Laya.Sprite;
            this.helpGrids.visible = false;

        }

        public show(isReset: boolean, isAnim: boolean = false, onComplete: Laya.Handler = null): void {

            this.freshBulletCount();
            if (isReset) {
                this.resetPlanePos();
                this.changeLevel(UI_Activity_Shoot.currentLevelId);
            }
            this.visible = true;
            if (isAnim) {
                UI_Activity_Shoot.Inst.playAnim('game_enter', false, Laya.Handler.create(this, () => {
                    onComplete?.run();
                    this.plane.state = EPlaneState.IDLE;
                }))
            } else {
                onComplete?.run();
                this.plane.state = EPlaneState.IDLE;
            }


        }

        public hide(isAnim: boolean = false, onComplete: Laya.Handler = null): void {
            if (isAnim) {

                UI_Activity_Shoot.Inst.playAnim('game_hide', false, Laya.Handler.create(this, () => {
                    this.visible = false;
                    onComplete?.run();

                }))
            } else {
                this.visible = false;
                onComplete?.run();
            }

        }

        public onDisable(): void {
            this.clearBullets();
            this.plane.onDisable();
            Laya.timer.clearAll(this);
            this.isRunAttackOrder = false;
            this.attackOrder = [];
            this.planeMoveTween && this.planeMoveTween.clear();
            this.bulletMoveTween && this.bulletMoveTween.clear();
        }

        private createEnemy(hp: number) {
            let enemySprite = Laya.Pool.getItemByCreateFun(this.enemyPoolSign + hp, () => {
                return Enemy.create(hp);
            });
            let enemy = new Enemy(enemySprite, hp);
            this.enemyParent.addChild(enemySprite);
            this.enemies.push(enemy);
            enemy.onRecover = Laya.Handler.create(this, () => {
                Laya.Pool.recover(this.enemyPoolSign + hp, enemySprite);
                let index = this.enemies.findIndex(v => v.id == enemy.id);
                index != -1 && this.enemies.splice(index, 1);
            })
            enemy.visible = true;
            return enemy;

        }

        private createPlane() {
            let planeSprite = Plane.create();
            this.plane = new Plane(planeSprite);
            this.scene.addChild(planeSprite);
            this.plane.visible = true;
            return this.plane;
        }

        private createBullet() {
            let bulletSprite = Laya.Pool.getItemByCreateFun(this.bulletPoolSign, () => {
                return Bullet.create();
            });

            let entityId = Bullet.createTimes;
            let bullet = new Bullet(bulletSprite, entityId);
            bullet.visible = true;
            this.bulletParent.addChild(bulletSprite);
            this.bullets.push(bullet);

            bullet.onRecover = Laya.Handler.create(this, () => {
                Laya.Pool.recover(this.bulletPoolSign, bulletSprite);
                let index = this.bullets.findIndex(v => v.id == bullet.id);
                index != -1 && this.bullets.splice(index, 1);
            });
            return bullet;
        }

        public changeLevel(levelId: number, isShowAnim: boolean = false, onComplete: Laya.Handler = null) {
            let levelIndex = UI_Activity_Shoot.levels.findIndex(v => v.level == levelId);
            if (levelIndex == -1) {
                return;
            }
            this.clearEnemies();
            this.clearBullets();
            let levelData = UI_Activity_Shoot.levels[levelIndex];
            let enemies = levelData.enemies;
            for (let index = 0; index < enemies.length; index++) {
                const enemyData = enemies[index];
                let enemy = this.createEnemy(enemyData.maxHp);
                enemy.enemyData = enemyData;
                let posY = this.bornPosesY[enemy.enemyData.posY - 1];
                let posX = this.convertGridToPosX(enemyData.posX);
                enemy.pos = new Laya.Vector2(posX, posY);
            }

            this.levelCount.skin = game.Tools.localUISrc(`myres/activity_shoot/number_level_${levelIndex + 1}.png`);
            if (isShowAnim) {
                UI_Activity_Shoot.Inst.showEnemyEnterAnim(Laya.Handler.create(this, () => {
                    onComplete?.run();
                }));
            } else {
                onComplete?.run();
            }
        }



        public clearEnemies() {
            //recover的时候已经从数组里移除了,所以需要从后往前移除
            for (let index = this.enemies.length - 1; index >= 0; index--) {
                const element = this.enemies[index];
                element.recover();
            }
            this.enemies.length = 0;
        }

        public clearBullets() {
            //recover的时候已经从数组里移除了,所以需要从后往前移除
            for (let index = this.bullets.length - 1; index >= 0; index--) {
                const element = this.bullets[index];
                element.recover();
            }
            this.bullets.length = 0;
        }

        public freshBulletCount() {
            this.bulletCount.value = UI_Activity_Shoot.bulletCount;
        }

        public resetPlanePos() {
            let centerIndex = this.maxGrid / 2;
            this.plane.posX = centerIndex * this.gridSpace;
            this.plane.posY = this.planeBornPosY;
        }

        public movePlane(offsetX: number) {
            //移动飞机，但位置不可以超过左右边界
            let newPosX = this.plane.posX + offsetX * this.planeMoveSpeed * UI_Activity_Shoot.Inst.speed;
            newPosX = Math.max(0, Math.min(newPosX, this.maxGrid * this.gridSpace));
            this.plane.posX = newPosX;
            this.plane.state = EPlaneState.MOVE;
        }

        public stopPlane() {
            this.plane.state = EPlaneState.IDLE;
        }


        /**
         * 执行一次攻击，如果当前在攻击，则存储攻击数据
         * @param enemyId 
         * @param onShootComplete 
         */
        public shoot(enemyId: number, pos: number, levelId: number, onShootComplete: Laya.Handler = null, damage: number = this.defaultBulletDamage) {
            if (!this.visible) {
                return;
            }
            if (this.isRunAttackOrder) {
                let order: IAttackOrder = {
                    enemyId: enemyId,
                    levelId: levelId,
                    onShootComplete: onShootComplete,
                    damage: damage,
                    pos: pos
                }
                this.attackOrder.push(order);
                return;
            }
            this.isRunAttackOrder = true;
            let enemyTarget = this.enemies.find(v => v.enemyData.enemyId == enemyId);
            if (enemyTarget) {
                this.plane.state = EPlaneState.MOVE;
                //飞机移动到敌人的正中间，发射子弹
                this.movePlaneToGridCenter(pos, Laya.Handler.create(this, () => {
                    this.isRunAttackOrder = false;
                    this.plane.state = EPlaneState.ATTACK;
                    view.AudioMgr.PlayAudio(10367);
                    let bullet = this.createBullet();
                    bullet.posY = this.bulletBornPosY;
                    bullet.posX = this.plane.posX;
                    let offsetY = enemyTarget.attackPointY - bullet.posY;
                    let animTime = Math.abs(offsetY / (this.bulletMoveSpeed * UI_Activity_Shoot.Inst.speed));
                    this.bulletMoveTween = Laya.Tween.to(bullet, { posY: enemyTarget.attackPointY }, animTime, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                        bullet.recover();
                        //子弹到达敌人位置，敌人掉血
                        if (enemyTarget) {
                            enemyTarget.onAttack(1, onShootComplete);
                        }
                        this.bulletMoveTween = null;
                        this.plane.state = EPlaneState.IDLE;
                    }));
                }));
            }
            //在攻击冷却之后检测是否再次执行攻击
            Laya.timer.once(this.attackSpace, this, () => {
                if (this.attackOrder.length > 0 && this.visible) {
                    let newOrder = this.attackOrder.shift();
                    if (newOrder.levelId == UI_Activity_Shoot.currentLevelId) {
                        this.shoot(newOrder.enemyId, newOrder.pos, newOrder.levelId, newOrder.onShootComplete, newOrder.damage);
                    }
                }
            });
        }

        /**
         * 移动飞机到指定的格子的中心位置
         * @param gridIndex 
         * @param onMoveComplete 
         */
        public movePlaneToGridCenter(gridIndex: number, onMoveComplete: Laya.Handler = null) {
            //如果是同一个格子，则不用挪了
            let currentPos = this.convertPosXToGrid(this.plane.posX);
            if (currentPos == gridIndex) {
                onMoveComplete && onMoveComplete.run();
                return;
            }

            //移动到格子中心
            let targetX = this.convertGridToPosX(gridIndex);
            let offsetX = targetX - this.plane.posX;
            targetX = targetX + this.gridSpace / 2;
            targetX = Math.max(0, Math.min(targetX, this.maxGrid * this.gridSpace));
            let duration = Math.abs(offsetX) / this.planeMoveSpeed * (1000 / 60) / UI_Activity_Shoot.Inst.speed;
            this.planeMoveTween = Laya.Tween.to(this.plane, { posX: targetX }, duration, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                this.plane.posX = targetX;
                onMoveComplete && onMoveComplete.run();
                this.planeMoveTween = null;
            }));
        }

        /**
         * 世界坐标转格子坐标,配置里的格子坐标1开始
         * @param posX 
         * @returns 
         */
        private convertPosXToGrid(posX: number): number {
            return Math.floor(posX / this.gridSpace) + 1;
        }

        /**
         * 格子坐标转世界坐标,配置里的格子坐标1开始
         * @param gridX 
         * @returns 
         */
        private convertGridToPosX(gridX: number): number {
            return (gridX - 1) * this.gridSpace;
        }


        public getPlaneGridX() {
            return this.convertPosXToGrid(this.plane.posX);
        }

        public checkLevelFinish() {
            if (this.enemies.length == 0) {
                return true;
            }
            return false;
        }

        /**
         * 判断是否所有敌人都已死亡
         * @returns 
         */
        public isAllEnemiesDied(): boolean {
            let isAllDied = false;
            if (this.enemies.length > 0) {
                isAllDied = this.enemies.every(v => v.hp <= 0);
            }
            return isAllDied;
        }

        public setEnemiesState(state: EEnemyState) {
            for (let index = 0; index < this.enemies.length; index++) {
                this.enemies[index].changeState(state);
            }
        }

        public gameStart() {
            this.plane.state = EPlaneState.IDLE;
            this.setEnemiesState(EEnemyState.IDLE);
        }

        public gameComplete() {
            this.emptySprite.visible = true;
        }

       

    }

    class Page_Task extends UI_Component {



        private empty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabButtons: Array<UI_TabGroup_TabButton>;
        private btnGetAll: Laya.Button;
        private itemRect: UIRect = null;
        /**
       * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
       */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private needSort: boolean = false;

        public onCreate(): void {
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<UI_TabGroup_TabButton>();
            let tabs = this.me.getChildByName('tabs') as Laya.Sprite;
            for (let i = 0; i < tabs.numChildren; i++) {
                let tab = tabs.getChildAt(i) as Laya.Sprite;
                let tabButton = new UI_TabGroup_TabButton(tab);
                this.tabGroups.AddTabButton(tab as Laya.Button);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    if (this.needSort) this.freshData();
                    tabBtn.onSelect();
                    this.freshList();
                }
                else {
                    tabBtn.onDeselect();
                }

            };
            this.tabGroups.init();
            let list = this.me.getChildByName("content") as Laya.Sprite;
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender));
            this.scrollView.setElastic();
            this.empty = this.me.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.me.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick, null, false);
        }
        public show(isAnim: boolean = false, onComplete: Laya.Handler = null): void {
            this.freshData();
            this.tabGroups.selectedIndex = 0;
            this.freshList();
            this.visible = true;
            if (isAnim) {
                UI_Activity_Shoot.Inst.playAnim('task_enter', false, Laya.Handler.create(this, () => {
                    onComplete?.run();
                }));
            } else {
                onComplete?.run();
            }

        }

        public hide(isAnim: boolean = false, onComplete: Laya.Handler = null): void {
            if (isAnim) {
                UI_Activity_Shoot.Inst.playAnim('task_hide', false, Laya.Handler.create(this, () => {
                    this.visible = false;
                    onComplete?.run();
                }));
            } else {
                this.visible = false;
                onComplete?.run();
            }

        }

        //刷新列表数据
        private freshData() {
            this.needSort = false;
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_Activity_Shoot.activityTaskId);

            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element.id)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element.id)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);

        }


        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList() {
            if (!this.sortServerData) {
                return;
            }
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.empty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();

        }

        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task.id)) {
                let unlockTime = this.getTaskUnlockTime(task.id);
                weight = -10000 - unlockTime; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        private isTaskUnlock(taskId: number): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(taskId);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Shoot.activityId);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private getTaskUnlockTime(taskId: number): number {
            let taskConfig = cfg.activity.period_task.get(taskId);
            let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Shoot.activityId, taskConfig.reward_limit_day);
            return restSeconds;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Button;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let txtDesc = container.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('received') as Laya.Sprite;
            let txtUnComplete = unLockParent.getChildByName('uncomplete') as Laya.Sprite;
            let btnReceive = unLockParent.getChildByName("btn_receive") as Laya.Button;
            let txtProgress = unLockParent.getChildByName('progress') as Laya.Label;
            let imgProgressBar = unLockParent.getChildByName('bar').getChildByName('val') as Laya.Image;
            let txtLockedTime = lockedParent.getChildByName('locked') as Laya.Label;

            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData.id);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            txtDesc.color = isUnlock ? "#fffccf" : "#ccc8ff";
            let progress: number = serverData.counter || 0;
            txtProgress.text = (progress > baseTaskConfigData.target ? baseTaskConfigData.target : progress) + '/' + baseTaskConfigData.target;
            let progressValue = progress / baseTaskConfigData.target > 1 ? 1 : progress / baseTaskConfigData.target;
            progressValue = Math.max(0.01, Math.min(1, progressValue));
            imgProgressBar.scaleX = progressValue;
            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = !serverData.rewarded && serverData.achieved;
                txtUnComplete.visible = !serverData.rewarded && !serverData.achieved;
                let btnText = btnReceive.getChildAt(0) as Laya.Label;
                btnText.text = game.Tools.strOfLocalization(4251);
                imgGetted.visible = serverData.achieved && serverData.rewarded;
                if (serverData.achieved && !serverData.rewarded) {
                    //已完成未领取
                    //领取的点击事件
                    btnReceive.clickHandler = new Laya.Handler(this, () => {
                        if (UI_Activity_Shoot.Inst.locking) return;
                        UI_Activity_Shoot.Inst.lockPage(true);
                        app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            if (err || res['error']) {
                                UI_Activity_Shoot.Inst.lockPage(false);
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                this.needSort = true;
                                serverData.rewarded = true;
                                UI_Activity.onPeriodTaskRewarded(serverData.id);
                                Laya.timer.once(100, this, () => { 
                                    UI_Activity_Shoot.Inst.lockPage(false);
                                    game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                });
                                btnReceive.visible = false;
                                imgGetted.visible = true;
                                this.freshGetAllBtn();
                            }
                        });
                    }, null, false);
                }
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Shoot.activityTaskId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText1(restSeconds);
            }
            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("item") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, UI_Activity_Shoot.uiTag, true);
                txtCount.text = rewardCount.toString();
                itemParent.clickHandler = new Laya.Handler(this, () => {
                    if (UI_Activity_Shoot.Inst.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })

            }
        }

        private freshGetAllBtn() {
            let shouldSetGray = this.tabGroups.selectedIndex == 1 || !UI_Activity_Shoot.haveTaskComplete();
            this.btnGetAll.mouseEnabled = !shouldSetGray;
            this.btnGetAll.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_shoot/task_cant_receive_btn_bg.png' : 'myres/activity_shoot/task_can_receive_btn_bg.png');
            (this.btnGetAll.getChildByName('title') as Laya.Image).skin = game.Tools.localUISrc(shouldSetGray ? 'myres/activity_shoot/task_receive_all_title_gray.png' : 'myres/activity_shoot/task_receive_all_title.png');
            UI_Activity_Shoot.Inst.freshRedPoint();
        }

        private onGetAllBtnClick() {
            if (UI_Activity_Shoot.Inst.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Shoot.activityTaskId);
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = this.sortServerData[0];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        needGetList.push(data['id']);
                    } else {
                        break;
                    }
                }
            }
            if (needGetList.length == 0) return;
            UI_Activity_Shoot.Inst.lockPage(true);
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                
                if (err || res['error']) {
                    UI_Activity_Shoot.Inst.lockPage(false)
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    allRewardList.forEach(v => {
                        if (v.achieved && !v.rewarded)
                            v.rewarded = true;
                    });
                    let rewardList = [];
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = Number(rewardStr[0]);
                        let rewardCount = Number(rewardStr[1]);
                        rewardList.push({ id: rewardId, count: rewardCount });
                    }
                    this.needSort = true;
                    this.scrollView.wantToRefreshAll();
                    this.freshGetAllBtn();
                    Laya.timer.once(100, this, () => {
                        UI_Activity_Shoot.Inst.lockPage(false);
                        game.Tools.showRewards({ rewards: rewardList }, null, null);
                    });
                    
                }
            })
        }

    }



    class Page_Reward_Line_Item extends UI_Component {
        private infoBtn: Laya.Button;
        private countLabel: Laya.Label;
        private itemRect: UIRect;
        private itemIcon: Laya.Image;
        private remainCountLabel: Laya.Label;
        private itemId: number = -1;
        private done: Laya.Sprite;
        public onCreate(): void {
            this.infoBtn = this.me.getChildByName('btn') as Laya.Button;
            this.infoBtn.clickHandler = new Laya.Handler(this, this.onClickInfoBtn, null, false);
            this.countLabel = this.infoBtn.getChildByName('count').getChildByName('count') as Laya.Label;
            this.itemIcon = this.infoBtn.getChildByName('icon') as Laya.Image;
            this.remainCountLabel = this.infoBtn.getChildByName('remain').getChildByName('count') as Laya.Label;
            this.done = this.infoBtn.getChildByName('done') as Laya.Sprite;
            this.done.visible = false;
        }

        private onClickInfoBtn(): void {
            if (UI_Activity_Shoot.Inst.locking) return;
            if (this.itemId == -1) {
                return;
            }
            UI_ItemDetail.Inst.show(this.itemId);
        }

        public set id(value: number) {
            this.itemId = value;
            if (!this.itemRect) {
                this.itemRect = UIRect.CreateFromSprite(this.itemIcon);
            }
            game.Tools.setItemIcon(this.itemIcon, this.itemRect, this.itemId, UI_Activity_Shoot.uiTag, true);
        }

        public set count(value: number) {
            this.countLabel.text = value.toString();
        }

        public set remainCount(value: number) {
            this.remainCountLabel.text = game.Tools.strOfLocalization(3828) + value;
            this.done.visible = value <= 0;
        }


    }

    class Page_Reward_Line extends UI_Component {
        /**
         * 只有一行时的高度
         */
        private baseHeight: number = 158;
        /**
         * 分割线到最后一行的间距
         */
        private slideLineSpace: number = 15;
        /**
         * 每增加一行增加的高度
         */
        private lineHeight: number = 150;
        private itemSpace: number = 30;
        private lineMaxCount: number = 5;
        private renderHeight: number;
        private itemTemplate: Laya.Sprite;
        private slideLine: Laya.Sprite;
        private monsterIcon: Laya.Image;
        private starParents: Laya.Sprite;
        private stars: Laya.Image[];
        private items: Page_Reward_Line_Item[] = [];
        private level: number = 0;
        private levelRewardData: basic.Dictionary<number, IPageRewardData[]>;
        private levelParent: Laya.Sprite;
        private itemParent: Laya.Sprite;

        public onCreate(): void {
            this.levelParent = this.me.getChildByName('level') as Laya.Sprite;
            this.itemParent = this.me.getChildByName('items') as Laya.Sprite;
            this.itemTemplate = this.itemParent.getChildByName('item') as Laya.Sprite;
            this.itemTemplate.visible = false;
            this.renderHeight = this.baseHeight;
            this.slideLine = this.me.getChildByName('slide') as Laya.Sprite;
            let level = this.levelParent;
            this.monsterIcon = level.getChildByName('icon') as Laya.Image;
            this.starParents = level.getChildByName('stars') as Laya.Sprite;
            this.stars = [];
            for (let i = 0; i <= this.starParents.numChildren; i++) {
                let star = this.starParents.getChildByName(`star${i}`) as Laya.Image;
                this.stars.push(star);
            }
        }

        public get height(): number {
            return this.renderHeight;
        }

        public setLocalData(level: number, lineData: basic.Dictionary<number, IPageRewardData[]>, isLast: boolean = false): void {
            this.level = level;
            this.levelRewardData = lineData;
            let rewardCount = lineData.keys().length;
            let sortKeys = lineData.keys().sort((a, b) => this.sortItems(lineData.get(a)[0], lineData.get(b)[0]));
            let starCount: number = 0;
            //生成item
            for (let i = 0; i < rewardCount; i++) {
                let item = this.itemTemplate.scriptMap['capsui.UICopy']['getNodeClone']();
                item.visible = true;
                let rewardItem = new Page_Reward_Line_Item(item);
                let datas = lineData.get(sortKeys[i]);
                rewardItem.id = datas[0].itemId;
                rewardItem.count = datas[0].itemCount;
                let remainCount = datas.length;
                rewardItem.remainCount = remainCount;
                let lineIndex = Math.floor(i / this.lineMaxCount);
                let rowIndex = i % this.lineMaxCount;
                item.x = rowIndex * (this.itemTemplate.width + this.itemSpace);
                item.y = lineIndex * this.lineHeight;
                this.items.push(rewardItem);
                starCount = datas[0].data.star_num;
            }
            let totalLine = Math.ceil(rewardCount / this.lineMaxCount);
            let totalHeight = this.baseHeight + (totalLine - 1) * this.lineHeight;
            this.slideLine.visible = !isLast;
            if (!isLast) {
                this.slideLine.y = totalHeight;
                totalHeight += this.slideLineSpace;
            }
            this.renderHeight = totalHeight;
            let levelStr = level == 1 ? 'small' : level == 2 ? 'mid' : 'big';
            let monsterIconPath = `myres/activity_shoot/main_game_monster_${levelStr}_red.png`;
            this.monsterIcon.skin = game.Tools.localUISrc(monsterIconPath);
            for (let index = 0; index < this.starParents.numChildren; index++) {
                this.stars[index].visible = index < starCount;
            }
            game.Tools.child_align_center(this.starParents);
        }

        private sortItems(itemA: IPageRewardData, itemB: IPageRewardData): number {
            //首先有merge_reward的排在前面,merge_reward小的排在前面，道具id小的排在前面
            let mergeA = itemA.data.reward_merge;
            let mergeB = itemB.data.reward_merge;
            if (mergeA != 0 && mergeB != 0) {
                return mergeA - mergeB;
            } else if (mergeA != 0) {
                return -1;
            } else if (mergeB != 0) {
                return 1;
            } else {
                return itemA.itemId - itemB.itemId;
            }
        }

        public freshRemain(rewardedIds: number[]) {
            let rewardCount = this.levelRewardData.keys().length;
            let sortKeys = this.levelRewardData.keys().sort((a, b) => this.sortItems(this.levelRewardData.get(a)[0], this.levelRewardData.get(b)[0]));
            for (let i = 0; i < rewardCount; i++) {
                let rewardItem = this.items[i];
                let ids = this.levelRewardData.get(sortKeys[i]);
                let maxCount = ids.length;
                let remainCount = ids.length;
                //检测rewardId是否已经获取过
                for (let index = 0; index < ids.length; index++) {
                    const element = ids[index];
                    if (rewardedIds.includes(element.rewardId)) {
                        remainCount--;
                    }
                }
                rewardItem.remainCount = remainCount;
            }
        }

        public doSlideShowAnim(onComplete: Laya.Handler = null) {
            //slideLine alpha，从0到1，0.0666秒，quaoOutin
            this.slideLine.alpha = 0;
            Laya.Tween.to(this.slideLine, { alpha: 1 }, 66.6, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                onComplete?.run();
            }));
            this.levelParent.alpha = 0;
            this.levelParent.x += 262;
            this.itemParent.alpha = 0;
            this.itemParent.x += 262;
        }

        public doItemShowAnim(onComplete: Laya.Handler = null) {
            //level和item
            // alpha：从0到1，2帧（0.0333秒），quadOutin
            // X轴：从右往左，移动值262，linearOutin
            Laya.Tween.to(this.levelParent, { alpha: 1 }, 33.3, Laya.Ease.quadInOut, null);
            Laya.Tween.to(this.levelParent, { x: this.levelParent.x - 262 }, 450, Laya.Ease.linearInOut, null);
            Laya.Tween.to(this.itemParent, { alpha: 1 }, 33.3, Laya.Ease.quadInOut, null);
            Laya.Tween.to(this.itemParent, { x: this.itemParent.x - 262 }, 450, Laya.Ease.linearInOut, Laya.Handler.create(this, () => {
                onComplete?.run();
            }));

        }

    }

    class Page_Reward extends UI_Component {

        private lineTemplate: Laya.Sprite;
        private lines: Page_Reward_Line[];
        private scrollPanel: ScrollPanel;
        private countLabel: Laya.Label;
        private linesAnimCount: number = 3;
        public onCreate(): void {
            this.lines = [];
            this.scrollPanel = new ScrollPanel(this.me.getChildByName('list') as Laya.Sprite);
            this.scrollPanel.setElastic();
            this.countLabel = this.me.getChildByName('count').getChildByName('count') as Laya.Label;
            this.lineTemplate = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.lineTemplate.visible = false;
            this.initLines();

        }
        public show(isAnim: boolean = false, onComplete: Laya.Handler = null): void {
            this.scrollPanel.scrollValue = 0;
            this.freshRemain();
            this.visible = true;
            if (isAnim) {
                // UI_Activity_Shoot.Inst.lockPage(true);
                UI_Activity_Shoot.Inst.playAnim('reward_enter');
                for (let i = 0; i < this.linesAnimCount; i++) {
                    let index = i;
                    const element = this.lines[i];
                    element.doSlideShowAnim();
                    let animRunTime = i * 33;
                    Laya.timer.once(animRunTime, this, () => {
                        if (index == this.linesAnimCount - 1) {
                            element.doItemShowAnim(Laya.Handler.create(this, () => {
                                // UI_Activity_Shoot.Inst.lockPage(false);
                                onComplete?.run();
                            }));
                        } else {
                            element.doItemShowAnim();
                        }

                    });
                }
            } else {
                onComplete?.run();
            }
        }

        public hide(isAnim: boolean = false, onComplete: Laya.Handler = null): void {
            if (isAnim) {
                UI_Activity_Shoot.Inst.playAnim('reward_hide', false, Laya.Handler.create(this, () => {
                    this.visible = false;
                    onComplete?.run();
                }));
            } else {
                this.visible = false;
                onComplete?.run();
            }

        }





        private initLines() {
            if (!UI_Activity_Shoot.levelRewardsDic) {
                return;
            }
            //等级从高到低
            let levelKeys = UI_Activity_Shoot.levelRewardsDic.keys().sort((a, b) => b - a);
            let totalHeight: number = 0;
            for (let i = 0; i < levelKeys.length; i++) {
                let newLine = this.lineTemplate.scriptMap['capsui.UICopy']['getNodeClone']();
                this.scrollPanel.content.addChild(newLine);
                newLine.x = 24;
                let line = new Page_Reward_Line(newLine);
                line.setLocalData(levelKeys[i], UI_Activity_Shoot.levelRewardsDic.get(levelKeys[i]), i == levelKeys.length - 1);
                newLine.y = totalHeight;
                totalHeight += line.height;
                this.lines.push(line);
            }
            this.scrollPanel.contentHeight = totalHeight;

        }

        public freshRemain() {
            let remainCount = UI_Activity_Shoot.rewardTotalCount - UI_Activity_Shoot.rewardedIds.length;
            this.countLabel.text = game.Tools.strOfLocalization(3817) + remainCount + '/' + UI_Activity_Shoot.rewardTotalCount;
            for (let line of this.lines) {
                line.freshRemain(UI_Activity_Shoot.rewardedIds);
            }
        }

        public onGetRewards() {
            this.freshRemain();
        }


    }



    export class UI_Activity_Shoot extends UIBase {
        public static Inst: UI_Activity_Shoot;
        public static activityId: number = 251101;
        public static activityTaskId: number = 251102;
        public static bulletId: number = 30900096;
        public static uiTag: string = "UI_Activity_Shoot";
        /**
         * reward_level:{rewardId:IPageRewardData}
         */
        public static levelRewardsDic: basic.Dictionary<number, basic.Dictionary<number, IPageRewardData[]>>;
        public static rewardTotalCount: number = 0;
        /**
         * 已经领取过的奖励ID
         */
        public static rewardedIds: Array<number> = [];
        public static levels: Array<ILevelData> = [];
        public static currentLevelId: number = 1011;
        public static currentServerData: game.IActivityShootData = null;
        private static isInit: boolean = false;

        public static Init() {
            if (this.isInit) {
                return;
            }
            this.isInit = true;
            //配置表处理
            //获取所有本次活动的奖励
            this.rewardTotalCount = 0;
            this.levels = [];
            cfg.shoot.shoot_reward.forEach((v) => {
                if (v.activity_id == UI_Activity_Shoot.activityId) {
                    this.rewardTotalCount++;
                    let itemData = common.ConfigHelper.configString2Array<number>(v.reward)[0];
                    let itemId: number = itemData[0];
                    let itemCount: number = itemData[1];
                    if (!this.levelRewardsDic) {
                        this.levelRewardsDic = new basic.Dictionary<number, basic.Dictionary<number, IPageRewardData[]>>();
                    }
                    if (!this.levelRewardsDic.has(v.reward_level)) {
                        this.levelRewardsDic.set(v.reward_level, new basic.Dictionary<number, IPageRewardData[]>());
                    }

                    let rewardItem = {
                        rewardId: v.reward_id,
                        itemId: itemId,
                        itemCount: itemCount,
                        data: v
                    }
                    //itemid和count完全相同的，合并到同一个rewardid下
                    let levelRewards = this.levelRewardsDic.get(v.reward_level);
                    let rewardsKeys = levelRewards.keys();
                    let isFind: boolean = false;
                    for (let index = 0; index < rewardsKeys.length; index++) {
                        const element = rewardsKeys[index];
                        let rewardList = levelRewards.get(element);
                        if (rewardList && rewardList.length > 0) {
                            if (rewardList[0].itemId == itemId && rewardList[0].itemCount == itemCount) {
                                isFind = true;
                                //如果比第0个的merge_reward大，则这个放在第0个
                                if (rewardItem.data.reward_merge > rewardList[0].data.reward_merge) {
                                    rewardList.unshift(rewardItem);
                                } else {
                                    rewardList.push(rewardItem);
                                }
                            }
                        }
                    }
                    if (!isFind) {
                        levelRewards.set(rewardItem.rewardId, [rewardItem]);
                    }

                }
            })
            let activityInfo = cfg.shoot.shoot_info.get(UI_Activity_Shoot.activityId);
            let missions = cfg.shoot.shoot_mission.getGroup(activityInfo.missions_group_id);
            this.bulletId = activityInfo.bullet_item_id;
            for (let i = 0; i < missions.length; i++) {
                let mission = missions[i];
                let levelData: ILevelData = {
                    level: mission.level,
                    enemies: []
                };
                let enemyGroupId = mission.enemy_group_id;
                let enemies = cfg.shoot.shoot_enemy.getGroup(enemyGroupId);
                for (let index = 0; index < enemies.length; index++) {
                    const element = enemies[index];
                    let enemyData: IEnemyData = {
                        enemyId: element.enemy_id,
                        posX: element.x,
                        posY: element.y,
                        maxHp: element.hp,
                        currentHp: element.hp,
                        levelIndex: i,
                        levelId: mission.level,
                        width: element.width
                    }
                    levelData.enemies.push(enemyData);
                }
                this.levels.push(levelData);

            }
        }

        public static onFetchSuccess(datas: Array<any>) {
            for (let data of datas) {
                if (data.activity_id == this.activityId) {

                    app.Log.log('【Shoot】update_data' + JSON.stringify(data));
                    if (!this.currentServerData) {
                        this.currentServerData = data as game.IActivityShootData;
                        this.updateData();
                    } else {
                        this.currentServerData = data as game.IActivityShootData;
                    }


                }
            }
        }

        public static haveRedPoint(): boolean {
            if (!UI_Activity.activity_is_running(UI_Activity_Shoot.activityId)) {
                return false;
            }
            return this.haveTaskComplete() || this.canShoot();
        }

        public static haveTaskComplete(): boolean {
            let _list = UI_Activity.getPeriodTaskList(UI_Activity_Shoot.activityTaskId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Shoot.activityTaskId);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static canShoot(): boolean {
            if (!UI_Activity.activity_is_running(UI_Activity_Shoot.activityId)) {
                return false;
            }
            //如果有奖励可以领且子弹不为0

            let remainCount = this.rewardTotalCount - this.rewardedIds.length;
            if (this.bulletCount > 0 && remainCount > 0) {
                return true;
            }
            return false;
        }

        public static get bulletCount(): number {
            return UI_Bag.get_item_count(this.bulletId);
        }

        public static updateData() {
            if (!this.currentServerData) {
                return;
            }
            this.currentLevel = this.currentServerData.level;
            this.rewardedIds = game.Tools.deepCopy(this.currentServerData.rewarded_ids);
            for (let index = 0; index < this.levels.length; index++) {
                let levelData = this.levels[index];
                for (let j = 0; j < levelData.enemies.length; j++) {
                    const enemy = levelData.enemies[j];
                    let enemyServerData = this.currentServerData.enemies.find(e => e.enemy_id === enemy.enemyId);
                    if (enemyServerData) {
                        enemy.currentHp = enemyServerData.hp;
                    }

                }
            }
        }

        public static set currentLevel(value: number) {
            this.currentLevelId = value;
        }

        public static isGameComplete(): boolean {
            if (this.rewardTotalCount == this.rewardedIds.length) {
                return true;
            }
            return false;
        }

        public static currentEnemyTotalHp(): number { 
            let totalHp = 0;
            if (this.currentServerData) {
                for (let enemy of this.currentServerData.enemies) { 
                    totalHp += enemy.hp;
                }
            }
            return totalHp;
        }

        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private pageTabs: UI_TabGroup_Base;
        private tabButtons: Array<UI_TabGroup_TabButton> = [];
        private pageGame: Page_Game;
        private pageTask: Page_Task;
        private pageReward: Page_Reward;
        private stick: Laya.Sprite;
        private shot1Btn: Laya.Button;
        private shot10Btn: Laya.Button;
        private gameRedPoint: Laya.Sprite;
        private taskRedPoint: Laya.Sprite;
        private animMgr: UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shootUI>;
        private effectMgr: UI_EffectMgr;

        private isLocking: boolean = false;
        private currentStickState: EStickState = EStickState.NONE;
        private hit1EffectPath: string = "scene/effect_2511shoot_hit1.lh";
        private hit2EffectPath: string = "scene/effect_2511shoot_hit2.lh";
        private death1EffectPath: string = "scene/effect_2511shoot_death1.lh";
        private death2EffectPath: string = "scene/effect_2511shoot_death2.lh";

        public set stickState(value: EStickState) {
            if (this.stickState == value) {
                return;
            }
            this.currentStickState = value;
            switch (value) {
                case EStickState.NONE:
                    break;
                case EStickState.MIDDLE:
                    this.animMgr.playAnim('stick_mid', false);
                    break;
                case EStickState.LEFT:
                    this.animMgr.playAnim('stick_left', false);
                    break;
                case EStickState.RIGHT:
                    this.animMgr.playAnim('stick_right', false);
                    break;

                default:
                    break;
            }
        }

        public get stickState(): EStickState {
            return this.currentStickState;
        }
        /**
         * 摇杆中心全局坐标
         */
        private stickCenter: Laya.Point;

        private gameSpeed: number = 1;
        public get speed(): number {
            return this.gameSpeed;
        }
        public set speed(value: number) {
            this.gameSpeed = value;
        }


        constructor() {
            super(new ui.lobby.activity_shoot.activity_shootUI());
            UI_Activity_Shoot.Inst = this;
        }

        public onCreate(): void {
            this.animMgr = new UI_FrameAnimationMgr<ui.lobby.activity_shoot.activity_shootUI>(this.me);
            this.effectMgr = new UI_EffectMgr();
            UI_Activity_Shoot.Init();
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.stick = this.root.getChildByName('stick') as Laya.Sprite;
            let centerSprite = this.stick.getChildByName('stick_center') as Laya.Sprite;
            this.stickCenter = centerSprite.localToGlobal(new Laya.Point(0,0));
            this.shot1Btn = this.root.getChildByName('shoot_btn1') as Laya.Button;
            this.shot10Btn = this.root.getChildByName('shoot_btn10') as Laya.Button;
            this.closeBtn = this.root.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.isLocking) {
                    return;
                }
                this.hide();
            }, null, false);

            this.pageGame = new Page_Game(this.root.getChildByName('page_game') as Laya.Sprite);
            this.pageTask = new Page_Task(this.root.getChildByName('page_task') as Laya.Sprite);
            this.pageReward = new Page_Reward(this.root.getChildByName('page_reward') as Laya.Sprite);

            this.pageTabs = new UI_TabGroup_Base();
            let tabs = this.root.getChildByName('tabs') as Laya.Sprite;
            for (let i = 0; i < tabs.numChildren; i++) {
                let tab = tabs.getChildAt(i) as Laya.Sprite;
                let tabButton = new UI_TabGroup_TabButton(tab);
                this.pageTabs.AddTabButton(tab as Laya.Button);
                this.tabButtons.push(tabButton);
            }
            this.pageTabs.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.pageTabs.selectedIndex) {
                    tabBtn.onSelect();
                    //手动点击才播放动画
                    this.onTabChange(manualSwitching);
                }
                else {
                    tabBtn.onDeselect();
                }

            };
            this.pageTabs.init();
            this.bindDragEvent();
            this.gameRedPoint = tabs.getChildByName('tab_game').getChildByName('redpoint') as Laya.Sprite;
            this.taskRedPoint = tabs.getChildByName('tab_task').getChildByName('redpoint') as Laya.Sprite;
            UI_Bag.add_item_listener(UI_Activity_Shoot.bulletId, Laya.Handler.create(this, () => {
                if (this.enable) {
                    this.freshInfo();
                }
            }, null, false));


            this.shot1Btn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                //如果奖励全部完成了，弹出提示弹窗：
                if (UI_Activity_Shoot.isGameComplete()) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110104));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                //1）全部关卡敌人剩余血量小于10，弹出提示弹窗：
                // 25110103 剩余敌人不足
                if (UI_Activity_Shoot.currentEnemyTotalHp() < 1) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110103));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                // 2）全部关卡敌人剩余血量大于等于10，且弹药不足时，弹出提示弹窗：
                // 25110102 弹药不足，完成任务可以获得更多弹药
                if (UI_Activity_Shoot.bulletCount < 1) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110102));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                this.shoot(1);
            }, null, false);

            this.shot10Btn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                //如果奖励全部完成了，弹出提示弹窗：
                if (UI_Activity_Shoot.isGameComplete()) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110104));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                //1）全部关卡敌人剩余血量小于10，弹出提示弹窗：
                // 25110103 剩余敌人不足
                if (UI_Activity_Shoot.currentEnemyTotalHp() < 10) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110103));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                // 2）全部关卡敌人剩余血量大于等于10，且弹药不足时，弹出提示弹窗：
                // 25110102 弹药不足，完成任务可以获得更多弹药
                if (UI_Activity_Shoot.bulletCount < 10) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25110102));
                    UI_SecondConfirm.Inst.setBtnState(true, true);
                    return;
                }
                this.shoot(10);
            }, null, false);

            Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);

        }

        public onEnable(): void {
            this.freshInfo();
        }

        public onDisable(): void {
            this.animMgr.stopAllAnimations();
            this.pageGame.hide();
            this.pageTask.hide();
            this.pageReward.hide();
            this.effectMgr.clearAllEffects();
            this.stickState = EStickState.NONE;
        }

        public show() {
            this.lockPage(true)
            UI_Activity_Shoot.updateData();
            if (this.pageTabs.selectedIndex != 0) {
                this.pageTabs.selectedIndex = 0;
            } else {
                this.onTabChange(false);
            }
            this.freshInfo();
            this.enable = true;
            this.animMgr.playAnim('arcade_enter', false);
            this.animMgr.playAnim('bg_loop', true);
            this.showEnemyEnterAnim(Laya.Handler.create(this, () => {
                this.lockPage(false)
            }));


        }

        public showEnemyEnterAnim(onComplete: Laya.Handler = null) {

            this.stickState = EStickState.MIDDLE;
            this.animMgr.stopAnim('enemy_idle');
            this.pageGame.gameStart();
            this.animMgr.playAnim('enemy_enter', false, Laya.Handler.create(this, () => {
                this.animMgr.playAnim('enemy_idle', true)
                onComplete?.run();
            }));
            view.AudioMgr.PlayAudio(10364);

        }

        public hide() {

            this.lockPage(true);
            this.animMgr.playAnim('arcade_hide', false, Laya.Handler.create(this, () => {
                this.enable = false;
                this.lockPage(false);

            }));
        }

        private onTabChange(manualSwitching: boolean) {
            if (manualSwitching) {
                this.lockPage(true);
                view.AudioMgr.PlayAudio(10365);
            }

            if (this.pageTabs.selectedIndex == 0) {
                this.pageGame.show(!manualSwitching, manualSwitching, Laya.Handler.create(this, () => {
                    if (manualSwitching) {
                        this.lockPage(false);
                    }
                }));
                this.pageTask.hide(manualSwitching && this.pageTask.visible == true);
                this.pageReward.hide(manualSwitching && this.pageReward.visible == true);

            } else if (this.pageTabs.selectedIndex == 1) {
                this.pageGame.hide(manualSwitching && this.pageGame.visible == true);
                this.pageTask.show(manualSwitching, Laya.Handler.create(this, () => {
                    if (manualSwitching) {
                        this.lockPage(false);
                    }
                }));
                this.pageReward.hide(manualSwitching && this.pageReward.visible == true);
            } else if (this.pageTabs.selectedIndex == 2) {
                //奖励页面
                this.pageGame.hide(manualSwitching && this.pageGame.visible == true);
                this.pageTask.hide(manualSwitching && this.pageTask.visible == true);
                this.pageReward.show(manualSwitching, Laya.Handler.create(this, () => {
                    if (manualSwitching) {
                        this.lockPage(false);
                    }

                }));

            }
            
            if (manualSwitching) {
                this.freshInfo();
                this.effectMgr.clearAllEffects();
            }

        }
        /**
        * 鼠标摁下的坐标
        */
        private clickStartPos: Laya.Vector2;
        /**
         * 当前是否在执行拖拽
         */
        private isDrag: boolean;
        private lastClickPos: Laya.Vector2;
        private isMouseDown: boolean = false;

        private bindDragEvent() {
            this.stick.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
            this.me.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
            this.me.on(Laya.Event.MOUSE_OUT, this, this.onMouseUp);
        }
        private onMouseDown() {
            if (this.locking) {
                return;
            }
            this.isMouseDown = true;
            this.clickStartPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.lastClickPos = new Laya.Vector2(Laya.stage.mouseX, Laya.stage.mouseY);
            this.isDrag = false;
            Laya.timer.once(1, this, this.checkDrag);
        }

        private onMouseUp() {
            if (!this.isMouseDown) {
                return;
            }
            this.isMouseDown = false;
            //拖拽的结束
            if (this.isDrag) {
                this.onDragEnd();
                this.isDrag = false;
            }
            //点击的结束
            else {
                
            }
            this.clickStartPos = new Laya.Vector2(0, 0);
            this.lastClickPos = new Laya.Vector2(0, 0);
            Laya.timer.clear(this, this.checkDrag);
            Laya.timer.clear(this, this.onDragMove);
        }

        private checkDrag() {
            if (!this.isDrag) {
                this.isDrag = true;
                this.onDragStart();
                Laya.timer.loop(16, this, this.onDragMove);
                return;
            }

            Laya.timer.once(1, this, this.checkDrag);
        }

        private onDragStart() {

        }

        private onDragMove() {
            let mousePosX = Laya.stage.mouseX;
            let mousePosY = Laya.stage.mouseY;
            let offsetX = mousePosX - this.stickCenter.x;
            if (this.pageTabs.selectedIndex == 0) {
                if (offsetX > 0) {
                    this.stickState = EStickState.RIGHT;
                    offsetX = 1;
                } else if (offsetX < 0) {
                    this.stickState = EStickState.LEFT;
                    offsetX = -1;
                } 
                this.pageGame.movePlane(this.stickState == EStickState.LEFT ? -1 : 1);
                
            }
            this.lastClickPos = new Laya.Vector2(mousePosX, mousePosY);
        }

        private onDragEnd() {
            this.stickState = EStickState.MIDDLE;
            this.pageGame.stopPlane();
        }

        public freshRedPoint() {
            this.gameRedPoint.visible = UI_Activity_Shoot.canShoot();
            this.taskRedPoint.visible = UI_Activity_Shoot.haveTaskComplete();
            UI_Lobby.Inst.top.refreshRedpoint();
        }

        public onGetReward() {
            this.freshInfo();
        }

        public onShoot() {
            this.freshInfo();
        }

        private freshInfo() {
            this.freshRedPoint();
            this.pageGame.freshBulletCount();
            let canShoot1 = UI_Activity_Shoot.bulletCount >= 1 && !UI_Activity_Shoot.isGameComplete() && UI_Activity_Shoot.currentEnemyTotalHp() >=1;
            let canShoot10 = UI_Activity_Shoot.bulletCount >= 10 && !UI_Activity_Shoot.isGameComplete() && UI_Activity_Shoot.currentEnemyTotalHp() >=10;
            let shoot1Count = this.shot1Btn.getChildByName('count') as Laya.Sprite;
            let shoot10Count = this.shot10Btn.getChildByName('count') as Laya.Sprite;
            let shoot1CountLess = this.shot1Btn.getChildByName('count_less') as Laya.Sprite;
            let shoot10CountLess = this.shot10Btn.getChildByName('count_less') as Laya.Sprite;
            shoot1Count.visible = canShoot1;
            shoot1CountLess.visible = !shoot1Count.visible;
            shoot10Count.visible = canShoot10;
            shoot10CountLess.visible = !shoot10Count.visible;
            this.shot1Btn.mouseEnabled = !this.isLocking && this.pageTabs.selectedIndex == 0;
            this.shot10Btn.mouseEnabled = !this.isLocking && this.pageTabs.selectedIndex == 0;
            this.stick.mouseEnabled = this.pageTabs.selectedIndex == 0;
            if (UI_Activity_Shoot.isGameComplete()) {
                this.pageGame.gameComplete();
            }
        }

        public shoot(bulletCount: number) {
            // 发消息后根据返回的数据发射子弹
            if (this.locking) {
                return;
            }
            this.lockPage(true);
            let request: game.IReqShootActivityAttackEnemies = {
                activity_id: UI_Activity_Shoot.activityId,
                bullets_count: bulletCount,
                position: this.pageGame.getPlaneGridX()

            }
            app.Log.log('【Shoot】shootActivityAttackEnemies req:' + JSON.stringify(request));
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.shootActivityAttackEnemies, request, (err: game.IError, res: game.IResShootActivityAttackEnemies) => {
                app.Log.log('【Shoot】shootActivityAttackEnemies res:' + JSON.stringify(res));
                if (err || res['error']) {
                    this.lockPage(false);
                    UIMgr.Inst.showNetReqError(game.ERequest.shootActivityAttackEnemies, err, res);
                    return;
                }

                //接到协议后，挨个处理数据，如果有关卡变化，则执行changelevel之后再继续执行数据
                let records = game.Tools.deepCopy<game.IResShootActivityAttackEnemies_ActivityShootAttackRecord[]>(res.records);
                this.speed = bulletCount == 10 ? 2 : 1;
                let shootHandler = () => {
                    if (records.length > 0) {
                        //还有命令
                        let record = records[0];
                        if (record.level == UI_Activity_Shoot.currentLevelId) {
                            records.shift();
                            this.pageGame.shoot(record.enemy.enemy_id, record.position, record.level, Laya.Handler.create(this, shootHandler));
                        } else {
                            //打到中间切换关卡了
                            let nextLevel = record.level;
                            UI_Activity_Shoot.currentLevel = nextLevel;
                            this.pageGame.changeLevel(nextLevel, true, Laya.Handler.create(this, shootHandler));
                        }
                    } else {
                        //命令执行完毕

                        let animComplete = Laya.Handler.create(this, () => {
                            if (res.records && res.records.length > 0) {
                                let rewardList = [];
                                for (let index = 0; index < res.records.length; index++) {
                                    const element = res.records[index];
                                    let rewardedIds = element.reward_ids;
                                    if (rewardedIds.length > 0) {
                                        UI_Activity_Shoot.rewardedIds = UI_Activity_Shoot.rewardedIds.concat(rewardedIds);
                                        for (let index = 0; index < rewardedIds.length; index++) {
                                            const rewardId = rewardedIds[index];
                                            cfg.shoot.shoot_reward.forEach((v) => {
                                                if (v.activity_id == UI_Activity_Shoot.activityId && v.reward_id == rewardId) {
                                                    let rewardStr = common.ConfigHelper.configString2Array<number>(v.reward)[0];
                                                    let rewardId = Number(rewardStr[0]);
                                                    let rewardCount = Number(rewardStr[1]);
                                                    rewardList.push({ id: rewardId, count: rewardCount });
                                                }
                                            });
                                        }

                                    }

                                }

                                if (rewardList.length > 0) {
                                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                                }

                            }
                            this.speed = 1;
                            this.lockPage(false);
                            this.freshInfo();
                        });
                        if (this.pageGame.isAllEnemiesDied()) {
                            //如果所有敌人都死了，且还有下一关，则切换到下一关
                            let currentLevelIndex = UI_Activity_Shoot.levels.findIndex(v => v.level == UI_Activity_Shoot.currentLevelId);
                            let nextLevel = -1;
                            if (currentLevelIndex < (UI_Activity_Shoot.levels.length - 1)) {
                                nextLevel = UI_Activity_Shoot.levels[currentLevelIndex + 1].level;
                            }
                            if (nextLevel == -1) {
                                //没有下一关了
                                animComplete.run();

                            } else {
                                UI_Activity_Shoot.currentLevel = nextLevel;
                                this.pageGame.changeLevel(nextLevel, true, animComplete);
                            }

                        } else {
                            animComplete.run();
                        }
                    }

                };
                shootHandler();
            });
        }

        public onActivityFinish(activityId: number) {
            if (!this.enable) {
                return;
            }
            if (activityId == UI_Activity_Shoot.activityId) {
                //弹出提示框
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                    this.hide();
                }))
            }
        }

        public lockPage(lock: boolean) {
            this.isLocking = lock;
            this.pageTabs.locking = lock;
            this.shot1Btn.mouseEnabled = !lock && this.pageTabs.selectedIndex == 0;
            this.shot10Btn.mouseEnabled = !lock && this.pageTabs.selectedIndex == 0;
        }

        public get locking(): boolean {
            return this.isLocking;
        }

        public createHitEffect(target: Laya.Sprite, offset: Laya.Point) {
            return this.effectMgr.createEffect(this.speed == 1 ? this.hit1EffectPath : this.hit2EffectPath, target, offset, 1000, null, 1);
        }

        public createDeathEffect(target: Laya.Sprite, offset: Laya.Point) {
            return this.effectMgr.createEffect(this.speed == 1 ? this.death1EffectPath : this.death2EffectPath, target, offset, 1000, null, 1);
        }

        public clearEffect(effectId: number) {
            this.effectMgr.destoryEffect(effectId);
        }

        public playAnim(animName: string, loop: boolean = false, onComplete: Laya.Handler = null) {
            this.animMgr.playAnim(animName, loop, onComplete);
        }

    }
}