module uiscript {

    enum ERewardType {
        NONE,
        /**
         * 铜币
         */
        COIN,
        /**
         * 宝玉
         */
        JADE,
        /**
         * 蓝礼物
         */
        PRESENT_BLUE,
        /**
         * 紫礼物
         */
        PRESENT_PURPLE,
        /**
         * 插画
         */
        ILLUSTRATION


    }

    enum EGridType {
        NONE = '',
        /**
         * 奖励
         */
        REWARD = 'reward',
        /**
         * 百搭
         */
        ANY = 'any',
        /**
         * 万
         */
        M = 'm',
        /**
         * 筒
         */
        P = 'p',
        /**
         * 索
         */
        S = 's',
        /**
         * 风
         */
        W = 'w',
        /**
         * 三元
         */
        Y = 'y',

    }

    enum ECardState {
        NONE = 0,
        /**
         * 激活
         */
        ACTIVATED = 1,
        /**
         * 未激活
         */
        UNACTIVATED = 2,
        /**
         * 未解锁
         */
        LOCKED = 3,
        /**
         * 已完成
         */
        COMPLETED = 4,
    }

    enum EGridState {
        /**
         * 未完成
         */
        NONE = 0,
        /**
         * 已完成未领取
         */
        ACHIEVED = 1,
        /**
         * 已领取
         */
        REWARDED = 2,
    }

    enum ERewardState {
        /**
         * 未完成
         */
        NONE = 0,
        /**
         * 已完成未领取
         */
        ACHIEVED = 1,
        /**
         * 已领取
         */
        REWARDED = 2,
    }

    interface IRewardInfo {
        rewardId: number;
        state: ERewardState;
        itemId: number;
        itemCount: number;
        requireGridPos: number[];
        rewardType: ERewardType;
        nodeMark: number;
        cardId: number;

    }

    interface IGridInfo {
        type: EGridType;
        baseTaskId: number;
        /**
         * 从左到右，从上到下1-9
         */
        pos: number;
        state: EGridState;
    }

    interface ICardInfo {
        id: number;
        unlockDay: number;
        state: ECardState;
        grids: IGridInfo[];
        rewards: IRewardInfo[];
    }

    class Card extends UI_Component {
        public static createTimes: number = 0;
        public static create(): Laya.Sprite {
            let sprite = new ui.lobby.activitys.bingo.activity_bingo_cardUI();
            this.createTimes++;
            return sprite;
        }
        private cardInfo: ICardInfo;
        private lines: CardLine[] = [];
        private grids: CardGrid[] = [];
        private rewards: CardReward[] = [];
        private root: Laya.Sprite;
        private linePrarent: Laya.Sprite;
        private gridParent: Laya.Sprite
        private rewardParent: Laya.Sprite;
        private gridStartPos: Laya.Point = new Laya.Point(142, 36);
        private gridWidthSpace: number = 9;
        private gridHeightSpace: number = 8;
        private unlockSprite: Laya.Sprite;
        private unlockTip: Laya.Sprite;
        private unlockLabel: Laya.Label;
        private unlockImage: Laya.Image;
        private gridAnimSpaceTime: number = 83; //格子完成动画间隔时间
        private rewardAnims: string[] = ['default', 'nocomplete', 'complete', 'star'];
        private animController: UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_cardUI>;

        public get state(): ECardState {
            return this.cardInfo.state;
        }

        public get id(): number {
            return this.cardInfo.id;
        }

        public get rewardIds(): number[] {
            let ids: number[] = [];
            for (let reward of this.rewards) {
                ids.push(reward.rewardId);
            }
            return ids;
        }





        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.linePrarent = this.root.getChildByName('lines') as Laya.Sprite;
            this.gridParent = this.root.getChildByName('item_parents') as Laya.Sprite;
            this.rewardParent = this.root.getChildByName('reward_parents') as Laya.Sprite;
            this.unlockSprite = this.root.getChildByName('unlock') as Laya.Sprite;
            this.unlockTip = this.unlockSprite.getChildByName('tip') as Laya.Sprite;
            this.unlockLabel = this.unlockTip.getChildByName('tip_text') as Laya.Label;
            this.unlockImage = this.unlockTip.getChildByName('lock') as Laya.Image;
            this.animController = new UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_cardUI>(this.me);
        }

        public init(cardInfo: ICardInfo): void {
            this.cardInfo = cardInfo;
            // 创建线
            let lineCount = this.linePrarent._childs.length;
            for (let i = 0; i < lineCount; i++) {
                let lineSprite = CardLine.create();
                let parent = this.linePrarent.getChildAt(i) as Laya.Sprite;
                parent.addChild(lineSprite);
                let name = parent.name;
                let posStr = name.split('_');
                //string转number
                let targetPoses: number[] = [];
                for (let j = 0; j < posStr.length; j++) {
                    targetPoses.push(parseInt(posStr[j]));
                }

                let line = new CardLine(lineSprite);
                line.init(targetPoses);
                this.lines.push(line);

            }
            // 创建格子
            let gridCount = this.cardInfo.grids.length;
            for (let i = 0; i < gridCount; i++) {
                let gridSprite = CardGrid.create();
                this.gridParent.addChild(gridSprite);
                gridSprite.x = this.gridStartPos.x + (i % 3) * (gridSprite.width + this.gridWidthSpace);
                gridSprite.y = this.gridStartPos.y + Math.floor(i / 3) * (gridSprite.height + this.gridHeightSpace);
                let grid = new CardGrid(gridSprite);
                grid.init(this.cardInfo.grids[i]);
                this.grids.push(grid);
            }
            // 赋值奖励
            let rewardCount = this.cardInfo.rewards.length;
            for (let i = 0; i < rewardCount; i++) {
                let index = i;
                let rewardSprite = this.rewardParent.getChildAt(index) as Laya.Sprite;
                let reward = new CardReward(rewardSprite);
                //解锁对应的位置一致的数据
                let rewardPoses = UI_Activity_Bingo.rewardTargetPoses[index];
                //数组内数据一致即可，不要求顺序
                let info = this.cardInfo.rewards.find(r => UI_Activity_Bingo.isTargetPosEqual(r.requireGridPos, rewardPoses));
                reward.init(info);
                this.rewards.push(reward);
            }
            this.changeState(this.cardInfo.state);

        }



        public show(isDoAnim: boolean = false, onComplelte: Laya.Handler = null): void {
            this.freshCardState();
            this.visible = true;
            if (isDoAnim) {
                this.doShowAnim(onComplelte);
            }

        }

        public hide(): void {
            this.visible = false;
        }





        public doShowAnim(onComplelte: Laya.Handler = null): void {
            if (this.state == ECardState.LOCKED || this.state == ECardState.UNACTIVATED) {
                this.freshGrids(false);
                onComplelte?.run();
                return;
            }
            this.grids.forEach(grid => {
                grid.visible = false;
            });
            //播放每个格子的显示动画，间隔0.166s
            for (let index = 0; index < this.grids.length; index++) {
                const grid = this.grids[index];

                Laya.timer.once(index * 16.6, this, () => {
                    grid.visible = true;
                    if (index == this.grids.length - 1) {
                        //最后一个动画完成后回调，刷新数据
                        grid.doShowAnim(onComplelte);
                    } else {
                        grid.doShowAnim();
                    }
                });
            }

            //所有的线，播放显示动画
            for (let index = 0; index < this.lines.length; index++) {
                const line = this.lines[index];
                line.doShowAnim();
            }



        }

        public changeState(state: ECardState): void {
            this.cardInfo.state = state;
            switch (state) {
                case ECardState.UNACTIVATED:
                    this.unlockSprite.visible = true;
                    this.unlockLabel.text = game.Tools.strOfLocalization(25110903);
                    this.unlockLabel.fontSize = GameMgr.client_language == 'en' ? 20 : 30;
                    game.Tools.child_align_center(this.unlockTip, [10])
                    break;
                case ECardState.LOCKED:
                    this.unlockSprite.visible = true;
                    //根据解锁时间，获取解锁文本
                    let restSeconds = UI_Activity.getActivityUnLockTimeFrom5(UI_Activity_Bingo.activity_id, this.cardInfo.unlockDay);
                    if (restSeconds > 0) {
                        this.unlockLabel.text = game.Tools.getLockTimeText1(restSeconds);
                        this.unlockLabel.fontSize = 30;
                        game.Tools.child_align_center(this.unlockTip, [10]);
                    } else {
                        this.changeState(ECardState.UNACTIVATED);
                    }
                   
                    break;
                case ECardState.ACTIVATED:
                    this.unlockSprite.visible = false;
                    break;
                case ECardState.NONE || ECardState.COMPLETED:
                    this.unlockSprite.visible = false;
                    break;
            }
        }

        public freshGrids(isDoAnim: boolean = false, onComplelte: Laya.Handler = null): void {
            let cardData = UI_Activity_Bingo.cardInfos.find(c => c.id == this.cardInfo.id);
            //先刷新格子，再刷新奖励和线
            let onGridsComplete = Laya.Handler.create(this, () => {
                if (cardData.rewards) {
                    let hasDoRewardComplete = false;
                    cardData.rewards.forEach(rewardData => {
                        let rewardState = this.getRewardState(rewardData.rewardId);
                        if (rewardState != rewardData.state) {
                            hasDoRewardComplete = true;
                            this.changeRewardState(rewardData.rewardId, rewardData.state, isDoAnim, onComplelte);
                        }
                    });
                    if (!hasDoRewardComplete) {
                        onComplelte?.run();
                    }
                } else {
                    onComplelte?.run();
                }
            });
            let needChangeGridPoses: number[] = [];
            for (let index = 0; index < cardData.grids.length; index++) {
                let grid = cardData.grids[index];
                //如果和之前的状态不一样，才需要播放动画
                let gridState = grid.state;
                let currentState = this.getGridState(grid.pos);
                if (currentState != gridState) {
                    needChangeGridPoses.push(grid.pos);
                }
            }
            if (needChangeGridPoses.length > 0) {
                for (let index = 0; index < needChangeGridPoses.length; index++) {
                    const pos = needChangeGridPoses[index];
                    let gridData = cardData.grids.find(g => g.pos == pos);
                    let gridState = gridData.state;
                    if (index == needChangeGridPoses.length - 1) {
                        this.changeGridState(pos, gridState, isDoAnim, onGridsComplete);
                    } else {
                        this.changeGridState(pos, gridState, isDoAnim);
                    }

                }
                //根据格子状态刷新线
                this.lines.forEach(line => {
                    let isComplete = true;
                    for (let pos of line.gridsPos) {
                        let gridState = this.cardInfo.grids.find(g => g.pos == pos).state;
                        if (gridState != EGridState.REWARDED && gridState != EGridState.ACHIEVED) {
                            isComplete = false;
                        }
                    }
                    if (!line.complete) {
                        line.setComplete(isComplete, isDoAnim);
                    }
                });

            } else {
                onGridsComplete.run();
            }
        }

        public freshCardState() {
            let cardData = UI_Activity_Bingo.cardInfos.find(c => c.id == this.cardInfo.id);
            this.changeState(cardData.state);
        }

        /**
         * 显示完成动画
         * @param rewards 
         * @param onComplete 
         * @param isDoAnim 
         * @returns 
         */
        public doCompleteAnim(rewards: number[], onComplete: Laya.Handler = null): void {

            if (!rewards || rewards.length === 0) {
                onComplete.run();
                return;
            }
            //如果只有一个奖励，则播单个奖励的动画
            let rewardPoses: number[] = [];
            if (rewards.length === 1) {
                let rewardId = rewards[0];
                rewardPoses = UI_Activity_Bingo.findPosByRewardId(this.cardInfo.id, rewardId);
                //间隔一定时间changeState
                for (let index = 0; index < rewardPoses.length; index++) {
                    const element = rewardPoses[index];
                    Laya.timer.once(index * this.gridAnimSpaceTime, this, () => {
                        let grid = this.grids.find(cardGrid => {
                            return element == cardGrid.pos;
                        });
                        if (grid) {
                            //最后一个动画完成后回调
                            if (index == rewardPoses.length - 1) {
                                grid.changeState(EGridState.REWARDED, true, onComplete);
                            } else {
                                grid.changeState(EGridState.REWARDED, true);
                            }

                        }
                    });
                }
            }
            //如果有多个奖励，则播多个奖励的动画
            else {
                for (let index = 0; index < rewards.length; index++) {
                    let rewardId = rewards[index];
                    let poses = UI_Activity_Bingo.findPosByRewardId(this.cardInfo.id, rewardId);
                    //没有id才加入
                    for (let j = 0; j < poses.length; j++) {
                        const element = poses[j];
                        if (rewardPoses.indexOf(element) == -1) {
                            rewardPoses.push(element);
                        }
                    }

                }
                //一起播放
                for (let index = 0; index < rewardPoses.length; index++) {
                    const pos = rewardPoses[index];
                    let grid = this.grids.find(cardGrid => {
                        return pos == cardGrid.pos;
                    });
                    if (grid) {
                        if (index == rewardPoses.length - 1) {

                            grid.changeState(EGridState.REWARDED, true, Laya.Handler.create(this, () => {
                                onComplete?.run();
                            }));
                        } else {
                            grid.changeState(EGridState.REWARDED, true);
                        }

                    }
                }


            }
            //播放奖励领取动画
            for (let index = 0; index < rewards.length; index++) {
                const rewardId = rewards[index];
                this.changeRewardState(rewardId, ERewardState.REWARDED, true);
            }


        }


        public onEnable(): void {
            
            //根据当前格子状态刷新显示
            this.cardInfo.grids.forEach(gridInfo => {
                let grid = this.grids.find(cardGrid => { return cardGrid.pos == gridInfo.pos; });
                if (grid) {
                    grid.changeState(grid.state, false);
                }
            });
            //根据当前的奖励状态刷新显示
            this.cardInfo.rewards.forEach(rewardInfo => {
                this.changeRewardState(rewardInfo.rewardId, rewardInfo.state);
            });
            //根据格子状态刷新线
            this.lines.forEach(line => {
                let isComplete = true;
                for (let pos of line.gridsPos) {
                    let gridState = this.cardInfo.grids.find(g => g.pos == pos).state;
                    if (gridState != EGridState.REWARDED && gridState != EGridState.ACHIEVED) {
                        isComplete = false;
                    }
                }
                line.setComplete(isComplete, false);
            });
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            this.animController.stopAllAnimations();
            this.rewards.forEach(reward => {
                reward.onDisable();
            });
            this.grids.forEach(grid => {
                grid.onDisable();
            });
            this.lines.forEach(line => {
                line.onDisable();
            });
        }

        /**
         * 获取可领取的奖励id列表
         * @returns 
         */
        public getCanGetRewards(): number[] {
            let rewardIds: number[] = [];
            for (let reward of this.rewards) {
                if (reward.state == ERewardState.ACHIEVED) {
                    rewardIds.push(reward.rewardId);
                }
            }
            return rewardIds;
        }

        public changeGridState(pos: number, state: EGridState, isDoAnim: boolean = false, onComplete: Laya.Handler = null): void {
            let grid = this.grids.find(cardGrid => {
                return cardGrid.pos == pos;
            });
            if (grid) {
                grid.changeState(state, isDoAnim, onComplete);
            }
        }

        public changeRewardState(rewardId: number, state: ERewardState, isDoAnim: boolean = false, onComplete: Laya.Handler = null): void {
            let reward = this.rewards.find(cardReward => {
                return cardReward.rewardId == rewardId;
            });
            if (reward) {


                this.stopRewardAnim(rewardId);
                reward.changeState(state);
                if (isDoAnim) {
                    switch (state) {
                        case ERewardState.NONE:
                            this.doRewardAnim(rewardId, this.rewardAnims[0], false, onComplete);
                            break;
                        case ERewardState.ACHIEVED:
                            this.doRewardAnim(rewardId, this.rewardAnims[1], false, onComplete);
                            break;
                        case ERewardState.REWARDED:
                            this.doRewardAnim(rewardId, this.rewardAnims[2], false, onComplete);
                            break;
                    }
                }
                else {
                    onComplete?.run();
                }
                if (state == ERewardState.ACHIEVED) {
                    this.doRewardAnim(rewardId, this.rewardAnims[3], true);
                }
            }
        }

        private doRewardAnim(rewardId: number, animName: string, isLoop: boolean = false, onComplete: Laya.Handler = null): void {
            let reward = this.rewards.find(cardReward => {
                return cardReward.rewardId == rewardId;
            });
            if (reward) {
                let anim = reward.name + '_' + animName;
                //播放奖励动画
                this.animController.playAnim(anim, isLoop, onComplete);
            } else {
                onComplete?.run();
            }
        }

        public getGridState(pos: number): EGridState {
            let grid = this.grids.find(cardGrid => {
                return cardGrid.pos == pos;
            });
            return grid ? grid.state : EGridState.NONE;
        }

        public getRewardState(rewardId: number): ERewardState {
            let reward = this.rewards.find(cardReward => {
                return cardReward.rewardId == rewardId;
            });
            return reward ? reward.state : ERewardState.NONE;
        }

        private stopRewardAnim(rewardId: number) {
            let reward = this.rewards.find(cardReward => {
                return cardReward.rewardId == rewardId;
            });
            if (reward) {
                let animName = reward.name;
                for (let index = 0; index < this.rewardAnims.length; index++) {
                    const element = animName + '_' + this.rewardAnims[index];
                    this.animController.stopAnim(element);
                }
            }
        }


    }

    class CardGrid extends UI_Component {
        public static createTimes: number = 0;
        public static create(): Laya.Sprite {
            let sprite = new ui.lobby.activitys.bingo.activity_bingo_card_gridUI();
            this.createTimes++;
            return sprite;
        }

        private gridInfo: IGridInfo;
        private animController: UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_card_gridUI>;
        private root: Laya.Sprite;
        private typeIcon: Laya.Image;
        public onCreate(): void {
            this.animController = new UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_card_gridUI>(this.me as ui.lobby.activitys.bingo.activity_bingo_card_gridUI);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.typeIcon = this.root.getChildByName('type') as Laya.Image;


        }

        public init(info: IGridInfo) {
            this.gridInfo = info;
            this.changeState(this.gridInfo.state);
            let iconURL = 'myres/activity_bingo/card_type_' + this.gridInfo.type.toString() + '.png';
            this.typeIcon.skin = game.Tools.localUISrc(iconURL);
        }

        public changeState(state: EGridState, isDoAnim: boolean = false, onComplete: Laya.Handler = null): void {
            this.gridInfo.state = state;
            this.animController.stopAllAnimations();
            switch (state) {
                case EGridState.NONE:
                    this.animController.playAnim('nocomplete');
                    break;
                case EGridState.ACHIEVED:
                    this.animController.playAnim('complete', false);
                    this.animController.playAnim('anim_light', true);
                    if (isDoAnim) {
                        this.animController.playAnim('anim_lightup', false, onComplete);
                        UI_Activity_Bingo.Inst.creatEffect(UI_Activity_Bingo.completeEffect, this.root, new Laya.Point(0, 0));
                    }
                    break;
                case EGridState.REWARDED:
                    this.animController.playAnim('rewarded', false);
                    if (isDoAnim) {
                        this.animController.playAnim('anim_cat', false, onComplete);
                        UI_Activity_Bingo.Inst.creatEffect(UI_Activity_Bingo.rewardEffect, this.root, new Laya.Point(0, 0));
                    }
                    break;
            }
            if (!isDoAnim) {
                onComplete?.run();
            }
        }

        public get state(): EGridState {
            return this.gridInfo.state;
        }

        public get pos(): number {
            return this.gridInfo.pos;
        }

        public doShowAnim(onComplete: Laya.Handler = null): void {
            this.animController.playAnim('anim_show', false, onComplete);
            this.doLightAnim();
        }

        public doLightAnim() {
            if (this.state == EGridState.ACHIEVED) {
                this.animController.playAnim('anim_light', true);
            }
        }

        public onDisable(): void {
            this.animController.stopAllAnimations();
        }






    }

    class CardLine extends UI_Component {
        public static createTimes: number = 0;
        public static create(): Laya.Sprite {
            let sprite = new ui.lobby.activitys.bingo.activity_bingo_card_lineUI();
            this.createTimes++;
            return sprite;
        }
        /**
         * 连接的两个格子
         */
        private targetGridsPos: number[] = [];
        private root: Laya.Sprite;
        private whiteLine: Laya.Image;
        private brightLine: Laya.Image;
        private darkLine: Laya.Image;
        private animController: UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_card_lineUI>;
        private isComplete: boolean = false;

        public init(targetGridsPos: number[]): void {
            this.targetGridsPos = targetGridsPos;
        }

        public onCreate(): void {
            this.animController = new UI_FrameAnimationMgr<ui.lobby.activitys.bingo.activity_bingo_card_lineUI>(this.me as ui.lobby.activitys.bingo.activity_bingo_card_lineUI);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.whiteLine = this.root.getChildByName('white') as Laya.Image;
            this.brightLine = this.root.getChildByName('bright') as Laya.Image;
            this.darkLine = this.root.getChildByName('dark') as Laya.Image;
        }

        public get gridsPos(): number[] {
            return this.targetGridsPos;
        }

        public setComplete(isComplete: boolean, isDoAnim: boolean = false): void {
            this.isComplete = isComplete;
            if (isDoAnim && isComplete) {
                this.whiteLine.visible = true;
                this.brightLine.visible = true;
                this.animController.playAnim('completed', false);
            } else {
                this.brightLine.alpha = 1;
                this.whiteLine.visible = false;
                this.brightLine.visible = isComplete;
            }
        }

        public get complete(): boolean {
            return this.isComplete;
        }

        public onDisable(): void {
            // app.Log.log("onDisable: " + "TargetGridsPos:" + this.targetGridsPos[0] + "," + this.targetGridsPos[1]);
            this.animController.stopAllAnimations();
        }

        public doShowAnim(onComplete: Laya.Handler = null): void {
            // app.Log.log("doShowAnim: " + "TargetGridsPos:" + this.targetGridsPos[0] + "," + this.targetGridsPos[1]);
            this.animController.playAnim('show', false, onComplete);
        }



    }

    class CardReward extends UI_Component {
        private rewardInfo: IRewardInfo;
        private icon: Laya.Image;
        private achievedImage: Laya.Image;
        private receivedImage: Laya.Image;
        private toggleImage: Laya.Image;
        private bg: Laya.Image;
        private shadow: Laya.Image;
        private star: Laya.Sprite;
        private count: UI_ImageNumber;
        private btn: Laya.Button;

        public onCreate(): void {
            let display = this.me.getChildByName('display') as Laya.Sprite;
            this.icon = display.getChildByName('item') as Laya.Image;
            this.achievedImage = display.getChildByName('complete') as Laya.Image;
            this.receivedImage = display.getChildByName('received') as Laya.Image;
            this.toggleImage = display.getChildByName('toggle') as Laya.Image;
            this.bg = display.getChildByName('bg') as Laya.Image;
            this.shadow = display.getChildByName('shadow') as Laya.Image;
            this.achievedImage.visible = false;
            this.receivedImage.visible = false;
            this.toggleImage.visible = false;
            this.star = this.me.getChildByName('star') as Laya.Sprite;
            this.star.visible = false;
            let countSprite = display.getChildByName('count') as Laya.Sprite;
            this.count = new UI_ImageNumber(countSprite);
            let count_path = [];
            for (let index = 0; index < 10; index++) {
                let path = 'myres/activity_bingo/number_' + index + '.png';
                count_path.push(game.Tools.localUISrc(path));
            }
            this.count.init(count_path, -4);
            this.count.align = 'center';
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = Laya.Handler.create(this, () => {
                if (UI_Activity_Bingo.Inst.Locking) {
                    return;
                }
                if (this.rewardInfo.state == ERewardState.ACHIEVED) {
                    let rewardData: game.IReqBingoActivityReceiveReward_BingoReward = {
                        card_id: this.rewardInfo.cardId,
                        reward_id: this.rewardInfo.rewardId,
                    };
                    UI_Activity_Bingo.Inst.requestGetRewards([rewardData]);
                } else {
                    UI_ItemDetail.Inst.show(this.rewardInfo.itemId);
                }

            }, null, false);

        }

        public init(info: IRewardInfo): void {
            this.rewardInfo = info;
            this.changeState(this.rewardInfo.state);
            let iconURL = 'myres/activity_bingo/reward_' + this.rewardInfo.rewardType + '.png';
            this.icon.skin = game.Tools.localUISrc(iconURL);
            let isBlue = this.rewardInfo.nodeMark == 0;
            this.shadow.skin = game.Tools.localUISrc(isBlue ? 'myres/activity_bingo/reward_bg_blue_shadow.png' : 'myres/activity_bingo/reward_bg_purple_shadow.png');
            this.bg.skin = game.Tools.localUISrc(isBlue ? 'myres/activity_bingo/reward_bg_blue.png' : 'myres/activity_bingo/reward_bg_purple.png');
            this.achievedImage.skin = game.Tools.localUISrc(isBlue ? 'myres/activity_bingo/reward_bg_blue_receive.png' : 'myres/activity_bingo/reward_bg_purple_receive.png');
            this.receivedImage.skin = game.Tools.localUISrc(isBlue ? 'myres/activity_bingo/reward_bg_blue_received.png' : 'myres/activity_bingo/reward_bg_purple_received.png');
            this.count.value = this.rewardInfo.itemCount;
            this.count.visible = this.rewardInfo.itemCount > 1 && this.rewardInfo.rewardType == ERewardType.COIN;


        }

        public changeState(state: ERewardState): void {
            this.rewardInfo.state = state;
            switch (state) {
                case ERewardState.NONE:
                    this.achievedImage.visible = false;
                    this.receivedImage.visible = false;
                    this.toggleImage.visible = false;
                    this.star.visible = false;

                    break;
                case ERewardState.ACHIEVED:
                    this.achievedImage.visible = true;
                    this.receivedImage.visible = false;
                    this.toggleImage.visible = false;
                    this.star.visible = true;
                    break;
                case ERewardState.REWARDED:
                    this.achievedImage.visible = false;
                    this.receivedImage.visible = true;
                    this.toggleImage.visible = true;
                    this.star.visible = false;
                    this.toggleImage.alpha = 1;
                    this.receivedImage.alpha = 1;
                    break;
            }
        }

        public get state(): ERewardState {
            return this.rewardInfo.state;
        }

        public get rewardId(): number {
            return this.rewardInfo.rewardId;
        }

        public get name(): string {
            return this.me.name;
        }

    }



    export class UI_Activity_Bingo extends UI_ActivityBase {
        public static activity_id: number = 251190;
        private static isInit: boolean = false;
        public static Inst: UI_Activity_Bingo = null;
        public static cardInfos: ICardInfo[] = [];
        /**
         * 从奖励的Sprite0开始，依次对应解锁所需的位置
         */
        public static rewardTargetPoses: Array<Array<number>> = [
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9],
            [1, 5, 9],
            [3, 6, 9],
            [2, 5, 8],
            [1, 4, 7],
            [3, 5, 7],
        ];

        public static completeEffect: string = 'scene/effect_2511bingo_achieved.lh';
        public static rewardEffect: string = 'scene/effect_2511bingo_rewarded.lh';
        public static lastFetchTime: number = 0;

        public static initData() {
            if (this.isInit) return;
            this.isInit = true;
            this.cardInfos = [];
            let cards = cfg.activity.bingo_info.findGroup(this.activity_id);
            for (let cardCfg of cards) {
                let cardInfo: ICardInfo = {
                    id: cardCfg.card_id,
                    unlockDay: cardCfg.unlock_day,
                    state: ECardState.UNACTIVATED,
                    grids: [],
                    rewards: [],
                };
                let grids = cfg.activity.bingo_card.findGroup(cardCfg.card_id);
                for (let gridCfg of grids) {
                    let gridInfo: IGridInfo = {
                        type: gridCfg.type as EGridType,
                        baseTaskId: gridCfg.base_task_id,
                        pos: gridCfg.pos,
                        state: EGridState.NONE,
                    };
                    cardInfo.grids.push(gridInfo);
                }
                let rewards = cfg.activity.bingo_reward.findGroup(cardCfg.card_id);
                for (let rewardCfg of rewards) {
                    let reward = common.ConfigHelper.configString2Array<number>(rewardCfg.reward);
                    let rewardId = reward[0][0];
                    let rewardCount = reward[0][1];
                    let rewardInfo: IRewardInfo = {
                        rewardId: rewardCfg.reward_id,
                        state: ERewardState.NONE,
                        itemId: rewardId,
                        itemCount: rewardCount,
                        requireGridPos: rewardCfg.required_pos,
                        rewardType: rewardCfg.reward_type as ERewardType,
                        nodeMark: rewardCfg.node_mark,
                        cardId: cardCfg.card_id,
                    }
                    cardInfo.rewards.push(rewardInfo);
                }
                this.cardInfos.push(cardInfo);
            }

        }

        public static onFetchSuccess(res: game.IActivityBingoData[]) {
            if (!res) return;
            let serverData = res.find(r => r.activity_id == UI_Activity_Bingo.activity_id);
            if (!serverData) return;
           
            this.updateData(serverData.cards);
        }

        public static updateData(cards: game.IActivityBingoCardData[]) {
            this.lastFetchTime = Math.floor(game.Tools.getServerTime() / 1000);
            app.Log.log("【Bingo】updateData:" + JSON.stringify(cards));
            if (!cards || cards.length === 0) return;
            this.initData();
            cards.forEach(serverCard => {
                let cardId = serverCard.card_id;
                let cardInfo = this.cardInfos.find(card => {
                    return card.id == cardId;
                })
                if (!cardInfo) return;
                cardInfo.state = serverCard.state as ECardState;
                if (serverCard.rewarded_ids) {
                    serverCard.rewarded_ids.forEach(rewardId => {
                        let reward = cardInfo.rewards.find(r => r.rewardId == rewardId);
                        if (reward) {
                            reward.state = ERewardState.REWARDED;
                        }
                    })
                }
                //刷新格子的已完成状态
                if (serverCard.achieved_pos) {
                    serverCard.achieved_pos.forEach(pos => {
                        let grid = cardInfo.grids.find(g => g.pos == pos);
                        //获取格子对应的奖励
                        let rewardIds = UI_Activity_Bingo.getRewardGridPos(cardId, pos);
                        //检查该格子对应的奖励是否已领取，有任一奖励已领取，则该格子为已领取状态，否则为已完成状态
                        let isReward = false;
                        rewardIds.forEach(rewardId => {
                            let reward = cardInfo.rewards.find(r => r.rewardId == rewardId);
                            if (reward.state == ERewardState.REWARDED) {
                                isReward = true;
                            }
                        });
                        grid.state = isReward ? EGridState.REWARDED : EGridState.ACHIEVED;
                    });
                }
                //刷新奖励的可领取
                cardInfo.rewards.forEach(reward => {
                    let isAchieved = true;
                    reward.requireGridPos.forEach(pos => {
                        let grid = cardInfo.grids.find(g => g.pos == pos);
                        if (grid.state != EGridState.ACHIEVED && grid.state != EGridState.REWARDED) {
                            isAchieved = false;
                        }
                    });
                    if (isAchieved && reward.state != ERewardState.REWARDED) {
                        reward.state = ERewardState.ACHIEVED;
                    }
                });
            });


        }

        /**
         * 两个位置数组是否相等，顺序不限
         * @param poses1 
         * @param poses2 
         * @returns 
         */
        public static isTargetPosEqual(poses1: number[], poses2: number[]): boolean {
            if (poses1.length != poses2.length) {
                return false;
            }
            for (let pos of poses1) {
                if (poses2.indexOf(pos) == -1) {
                    return false;
                }
            }
            return true;
        }

        public static getAllReceivedRewards(): game.IReqBingoActivityReceiveReward_BingoReward[] {
            let rewardIds: game.IReqBingoActivityReceiveReward_BingoReward[] = [];
            for (let cardInfo of this.cardInfos) {
                for (let rewardInfo of cardInfo.rewards) {
                    if (rewardInfo.state == ERewardState.ACHIEVED) {
                        rewardIds.push({ card_id: cardInfo.id, reward_id: rewardInfo.rewardId });
                    }
                }
            }
            return rewardIds;
        }

        public getId(): number {
            return UI_Activity_Bingo.activity_id;
        }

        public isopen(): boolean {
            return UI_Activity.activity_is_running(this.getId());
        }

        public haveGetReward(): boolean {
            let haveReward = false;
            for (let cardInfo of UI_Activity_Bingo.cardInfos) {
                for (let rewardInfo of cardInfo.rewards) {
                    if (rewardInfo.state == ERewardState.ACHIEVED) {
                        haveReward = true;
                    }
                }
            }
            return haveReward;
        }

        public isShowGetAll(): boolean {
            return this.haveGetReward();
        }

        public haveRedPoint(): boolean {
            return this.haveGetReward();
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(this.getId());
            if (d && d.need_popout) return true;
            return false;
        }

        /**
         * 根据卡id和奖励id查找该奖励所需完成的格子位置
         * @param cardId 
         * @param rewardId 
         * @returns 
         */
        public static findPosByRewardId(cardId: number, rewardId: number): number[] {
            let poses: Array<number> = [];
            if (!this.isInit) {
                this.initData();
            }
            let cardInfo = this.cardInfos.find(c => c.id == cardId);
            if (cardInfo) {
                let rewardInfo = cardInfo.rewards.find(r => r.rewardId == rewardId);
                if (rewardInfo) {
                    poses = rewardInfo.requireGridPos;
                }
            }
            return poses;
        }

        /**
         * 根据卡id和位置id找到该格子可对应的所有奖励
         * @param cardId 
         * @param rewardId 
         */
        public static getRewardGridPos(cardId: number, gridPos: number): number[] {
            let rewards: number[] = [];
            if (!this.isInit) {
                this.initData();
            }
            let cardInfo = this.cardInfos.find(c => c.id == cardId);
            if (cardInfo) {
                for (let rewardInfo of cardInfo.rewards) {
                    if (rewardInfo.requireGridPos.indexOf(gridPos) != -1) {
                        rewards.push(rewardInfo.rewardId);
                    }
                }
            }
            return rewards;
        }

        /**
         * 获取奖励信息
         * @param cardId 
         * @param rewardId 
         * @returns 
         */
        public static getRewardInfo(cardId: number, rewardId: number): IRewardInfo {
            if (!this.isInit) {
                this.initData();
            }
            let cardInfo = this.cardInfos.find(c => c.id == cardId);
            if (cardInfo) {
                let rewardInfo = cardInfo.rewards.find(r => r.rewardId == rewardId);
                return rewardInfo;
            }
            return null;
        }

        /**
         * 获取卡片可领取的奖励id列表
         * @param cardId 
         * @returns 
         */
        public static getCardCanGetRewards(cardId: number): number[] {
            let rewardIds: number[] = [];
            if (!this.isInit) {
                this.initData();
            }
            let cardInfo = this.cardInfos.find(c => c.id == cardId);
            if (cardInfo) {
                for (let rewardInfo of cardInfo.rewards) {
                    if (rewardInfo.state == ERewardState.ACHIEVED) {
                        rewardIds.push(rewardInfo.rewardId);
                    }
                }
            }
            return rewardIds;
        }

        public static requestActivityData(onComplete:Laya.Handler = null): void { 
            if (UI_Activity_Bingo.Inst && UI_Activity_Bingo.Inst.enable) {
                let request: game.IReqFetchBingoActivityData = {
                    activity_id: UI_Activity_Bingo.activity_id,
                }
                this.lastFetchTime = Math.floor(game.Tools.getServerTime() / 1000);
                // app.Log.log("【Bingo】requestActivityData: " + JSON.stringify(request));
                app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.fetchBingoActivityData, request, (err: game.IError, res: game.IResFetchBingoActivityData) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(game.ERequest.fetchBingoActivityData, err, res);
                    } else { 
                        UI_Activity_Bingo.updateData(res.data.cards);
                    }
                    onComplete?.run();
                 });
            }
        }

        public static isFirstOpen = true;



        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Bingo.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.bingo.activity_bingoUI);
            UI_Activity_Bingo.Inst = this;
        }

        private root: Laya.Sprite;
        private cardParent: Laya.Sprite;
        private helpBtn: Laya.Button;
        private pageControl: UI_PageControll;
        private lastPageBtn: Laya.Button;
        private nextPageBtn: Laya.Button;
        private lastRedPoint: Laya.Sprite;
        private nextRedPoint: Laya.Sprite;
        private cards: Card[] = [];
        private isLocking: boolean = false;
        private effectMgr: UI_EffectMgr = null;
        private lastShowTime: number = 0;


        public onCreate(): void {
            UI_Activity_Bingo.initData();
            this.effectMgr = new UI_EffectMgr();
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.cardParent = this.root.getChildByName('cards') as Laya.Sprite;
            this.lastPageBtn = this.root.getChildByName('btn_left') as Laya.Button;
            this.nextPageBtn = this.root.getChildByName('btn_right') as Laya.Button;
            this.lastRedPoint = this.lastPageBtn.getChildByName('red_point') as Laya.Sprite;
            this.nextRedPoint = this.nextPageBtn.getChildByName('red_point') as Laya.Sprite;
            this.lastRedPoint.visible = false;
            this.nextRedPoint.visible = false;
            this.pageControl = new UI_PageControll();
            this.pageControl.init(this.lastPageBtn, this.nextPageBtn, (manualSwitching) => {
                this.onChangePage(manualSwitching);
            });
            let dots = this.root.getChildByName('pages_dots') as Laya.Sprite;
            this.pageControl.initDot(dots, 20)
            //创建卡片
            for (let cardInfo of UI_Activity_Bingo.cardInfos) {
                let card = this.createCard(game.Tools.deepCopy(cardInfo));
                this.cards.push(card);
            }
            this.pageControl.count = this.cards.length;
            this.pageControl.pageIndex = 0;
            this.helpBtn = this.root.getChildByName('help_btn') as Laya.Button;
            this.helpBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.isLocking) {
                    return;
                }
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(25110901));
            }, null, false);
            let intro = this.root.getChildByName('intro');
            let bg = intro.getChildByName('bg') as Laya.Image;
            let content = intro.getChildByName('content') as Laya.Label;
            bg.height = content.trueHeight + 16;

        }

        public onEnable(): void {
            Laya.timer.loop(1000, this, this.listenerRefresh);

        }

        public onDisable(): void {
            //把每个卡片都隐藏并刷新数据
            this.cards.forEach(card => {
                card.hide();
                card.freshGrids(false)
            });
            Laya.timer.clearAll(this);
            this.pageControl.pageIndex = -1;
            this.effectMgr.clearAllEffects();

        }

        public show() {
            this.lastShowTime = Math.floor(game.Tools.getServerTime() / 1000);
            this.setLocking(true);
            this.fresh();

            // 跳转到指定页
            this.enable = true;
            this.doShowAnim();
        }

        public hide() {
            this.enable = false;
        }

        private createCard(cardInfo: ICardInfo): Card {
            let card = new Card(Card.create());
            this.cardParent.addChild(card.me);
            card.init(cardInfo);
            return card;
        }

        private onChangePage(manualSwitching: boolean) {

            let pageIndex = this.pageControl.pageIndex;
            for (let index = 0; index < this.cards.length; index++) {
                let card = this.cards[index];
                if (index === pageIndex) {
                    card.show(manualSwitching);
                } else {
                    card.hide();
                }
            }
            this.effectMgr.clearAllEffects();
            this.freshPageBtn();
        }

        private freshPageBtn() {
            this.lastPageBtn.visible = this.pageControl.pageIndex > 0;
            this.nextPageBtn.visible = this.pageControl.pageIndex < this.pageControl.count - 1;
            this.freshBtnRedPoint();
        }

        public setLocking(isLocking: boolean): void {
            this.isLocking = isLocking;
            this.pageControl.isLocking = isLocking;
        }

        public get Locking(): boolean {
            return this.isLocking;
        }

        public fresh() {

            if (UI_Activity_Bingo.isFirstOpen) {
                UI_Activity_Bingo.isFirstOpen = false;
                //更新所有页
                this.cards.forEach(card => {
                    card.freshGrids(false);
                    card.freshCardState();
                });
            }
        }

        /**
         * 获取当前激活的卡片索引
         * @returns 
         */
        private getActiveCardIndex(): number {
            let activeCardIndex = -1;
            for (let index = 0; index < UI_Activity_Bingo.cardInfos.length; index++) {
                let cardInfo = UI_Activity_Bingo.cardInfos[index];
                if (cardInfo.state == ECardState.ACTIVATED) {
                    activeCardIndex = index;
                }
            }
            return activeCardIndex;
        }

        /**
         * 获取最后一个有可领取奖励的卡片索引
         * @returns 
         */
        private getLastRewardCardIndex(): number {
            let lastRewardCardIndex = -1;
            for (let index = 0; index < UI_Activity_Bingo.cardInfos.length; index++) {
                let canGetRewards = this.cards[index].getCanGetRewards();
                if (canGetRewards.length > 0) {
                    lastRewardCardIndex = index;
                }
            }
            return lastRewardCardIndex;
        }

        private getFirstLockedCardIndex(): number {
            let firstLockedCardIndex = -1;
            for (let index = 0; index < UI_Activity_Bingo.cardInfos.length; index++) {
                let cardInfo = UI_Activity_Bingo.cardInfos[index];
                if (cardInfo.state == ECardState.UNACTIVATED || cardInfo.state == ECardState.LOCKED) {
                    firstLockedCardIndex = index;
                    break;
                }
            }
            return firstLockedCardIndex;
        }


        private freshBtnRedPoint() {
            // 刷新翻页按钮红点
            let currentPageIndex = this.pageControl.pageIndex;
            let lastPageIndex = currentPageIndex - 1;
            let nextPageIndex = currentPageIndex + 1;
            let lastHaveReward = false;
            let nextHaveReward = false;
            //前面的页面是否有可领取奖励
            while (lastPageIndex >= 0) {
                if (UI_Activity_Bingo.getCardCanGetRewards(this.cards[lastPageIndex].id).length > 0) {
                    lastHaveReward = true;
                    break;
                }
                lastPageIndex--;
            }
            //后面的页面是否有可领取奖励
            while (nextPageIndex < this.cards.length) {
                if (UI_Activity_Bingo.getCardCanGetRewards(this.cards[nextPageIndex].id).length > 0) {
                    nextHaveReward = true;
                    break;
                }
                nextPageIndex++;
            }
            this.lastRedPoint.visible = lastHaveReward;
            this.nextRedPoint.visible = nextHaveReward;
        }


        public requestGetRewards(rewardDatas: game.IReqBingoActivityReceiveReward_BingoReward[], onComplete: Laya.Handler = null): void {
            UI_Activity_Bingo.Inst.setLocking(true);
            let request: game.IReqBingoActivityReceiveReward = {
                rewards: rewardDatas,
                activity_id: UI_Activity_Bingo.activity_id,
            }
            app.Log.log('【Bingo】requestGetRewards:' + JSON.stringify(request));
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.bingoActivityReceiveReward, request, (err: game.IError, res: game.IResBingoActivityReceiveReward) => {
                app.Log.log('【Bingo】requestGetRewardsRes:' + JSON.stringify(res));
                if (err || res['error']) {
                    this.setLocking(false)
                    if (err && err && err.code == 2604) {
                        this.onPassFreshTime();
                    }
                    else {
                        UIMgr.Inst.showNetReqError(game.ERequest.bingoActivityReceiveReward, err, res);
                    }
                } else {
                    let rewardItems = [];

                    //刷新cardInfo数据
                    UI_Activity_Bingo.updateData(res.cards);
                    //除了当前页外，刷新其他页数据
                    this.cards.forEach((card, index) => {
                        if (index != this.pageControl.pageIndex) {
                            card.freshCardState();
                            card.freshGrids(false);

                        }
                    });
                    this.freshRedPoint();

                    // 完成动画，如果当前卡有领取动画则播动画，无动画则不播动画
                    let currentCard = this.cards[this.pageControl.pageIndex];
                    let cardRewardIds: number[] = [];
                    rewardDatas.forEach(rewardData => {
                        if (rewardData.card_id == currentCard.id) {
                            cardRewardIds.push(rewardData.reward_id);
                        }
                        let rewardInfo = UI_Activity_Bingo.getRewardInfo(rewardData.card_id, rewardData.reward_id);
                        if (rewardInfo) {
                            rewardItems.push({ id: rewardInfo.itemId, count: rewardInfo.itemCount });
                        }
                    });
                    currentCard.doCompleteAnim(cardRewardIds, Laya.Handler.create(this, () => {


                        
                        game.Tools.showRewards({ rewards: rewardItems }, null);
                        let jumpPageIndex = this.pageControl.pageIndex;
                        //检查当前页是否还有可领取奖励
                        if (currentCard.getCanGetRewards().length == 0) {
                            //如果所有奖励都领取完毕，则检查还有无未领取奖励的卡片，跳转到最后一张可领取奖励的卡片
                            let lastRewardCardIndex = this.getLastRewardCardIndex();
                            if (lastRewardCardIndex != -1) {
                                jumpPageIndex = lastRewardCardIndex;
                            }
                            //没有奖励，检查激活页是否有未完成的格子，无且不是最后一页则跳转至激活页下一页，否则跳转至激活页
                            else {
                                let activeCard: Card = null;
                                let activatedCardIndex = this.getActiveCardIndex();
                                if (activatedCardIndex != -1) {
                                    activeCard = this.cards[activatedCardIndex];
                                    if (activeCard) {
                                        let uncompletedGrid = activeCard['cardInfo'].grids.find(g => g.state == EGridState.NONE);
                                        if (!uncompletedGrid) {
                                            if (activatedCardIndex < this.cards.length - 1) {
                                                jumpPageIndex = activatedCardIndex + 1;
                                            } else {
                                                jumpPageIndex = activatedCardIndex;
                                            }
                                        } else {
                                            jumpPageIndex = activatedCardIndex;
                                        }
                                    }
                                } else {
                                    //没有激活页则第一个未解锁页，否则最后一页
                                    let firstLockedCardIndex = this.getFirstLockedCardIndex();
                                    if (firstLockedCardIndex != -1) {
                                        jumpPageIndex = firstLockedCardIndex;
                                    }
                                    else { 
                                        jumpPageIndex = this.cards.length - 1;
                                    }
                                }
                                
                            }
                            if (jumpPageIndex != this.pageControl.pageIndex) {
                                Laya.timer.once(300, this, () => {
                                    this.pageControl.pageIndex = jumpPageIndex;
                                    let currentCard = this.cards[this.pageControl.pageIndex];
                                    currentCard.doShowAnim(Laya.Handler.create(this, () => {
                                        currentCard.freshGrids(true, Laya.Handler.create(this, () => {
                                            this.setLocking(false);
                                        }));
                                    }))
                                });

                            } else {
                                this.setLocking(false);
                            }

                        }
                        else {
                            this.setLocking(false);
                        }
                    }));
                }
            })
        }

        private onPassFreshTime() {
            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(20211), true, Laya.Handler.create(this, () => {
                //查看是否需要刷新数据
                if (!game.Tools.isPassedRefreshTimeServer(UI_Activity_Bingo.lastFetchTime)) {
                    this.setLocking(true)
                    //刷新数据
                    UI_Activity_Bingo.requestActivityData(Laya.Handler.create(this, () => {
                        this.setLocking(false);
                        UI_Activity.Inst.refreshPage();
                    }));
                } else {
                    UI_Activity.Inst.refreshPage();
                }
            }));
        }

        private getShowPageIndex(): number {
            let showIndex = -1;
            //获取第一张有新的格子完成的卡片索引
            for (let index = 0; index < UI_Activity_Bingo.cardInfos.length; index++) {
                let cardInfo = UI_Activity_Bingo.cardInfos[index];
                let card = this.cards[index];
                for (let i = 0; i < cardInfo.grids.length; i++) {
                    const gridInfo = cardInfo.grids[i];
                    let prevState = card.getGridState(gridInfo.pos);
                    if (gridInfo.state == EGridState.ACHIEVED && prevState != EGridState.ACHIEVED && prevState != EGridState.REWARDED) {
                        showIndex = index;
                        break;
                    }
                }
                if (showIndex != -1) {
                    break;
                }
            }
            //如果没有进度改变的卡片，则获取激活的那张，
            if (showIndex == -1) {
                showIndex = this.getActiveCardIndex();
            }
            //如果没有激活的卡片，则获取最后一张有可领取奖励的卡片
            if (showIndex == -1) {
                showIndex = this.getLastRewardCardIndex();
            }
            //如果也没有激活的卡片和可领取奖励的卡片，则显示下一个未激活的卡片
            if (showIndex == -1) {
                showIndex = this.getFirstLockedCardIndex();
            }

            //如果也没有，则显示最后一张卡片
            if (showIndex == -1) {
                showIndex = UI_Activity_Bingo.cardInfos.length - 1;
            }
            return showIndex;

        }


        public onClickGetAll() {
            if (UI_Activity_Bingo.Inst.Locking) {
                return;
            }
            let rewards = UI_Activity_Bingo.getAllReceivedRewards();
            this.requestGetRewards(rewards);
        }

        private doShowAnim() {
            this.setLocking(true);
            //展示卡的格子变化动画
            this.pageControl.pageIndex = -1;

            let doChangeAnim: Laya.Handler = Laya.Handler.create(this, () => {
                let pageIndex = this.getShowPageIndex();
                if (pageIndex != -1 && pageIndex != this.pageControl.pageIndex) {
                    this.pageControl.pageIndex = pageIndex;
                    let currentCard = this.cards[this.pageControl.pageIndex];
                    currentCard.doShowAnim(Laya.Handler.create(this, () => {
                        currentCard.freshGrids(true, Laya.Handler.create(this, () => {
                            doChangeAnim.run();
                        }));
                    }));
                } else {
                    this.setLocking(false);
                }
            }, null, false);
            doChangeAnim.run();
        }

        private freshRedPoint() {
            UI_Activity.Inst.freshGetAllBtn();
            UI_Activity.Inst.refresh_redpoint();
            UI_Lobby.Inst.top.refreshRedpoint();
            this.freshBtnRedPoint();
        }

        public creatEffect(path: string, target: Laya.Sprite, offset: Laya.Point) {
            let effectId = this.effectMgr.createEffect(path, target, offset, 1500, null, 1);
            return effectId;
        }

        private listenerRefresh() { 
            if (this.enable) {
                
                let isSameDay = game.Tools.isPassedRefreshTimeServer(this.lastShowTime);
                if (!isSameDay) {
                    this.lastShowTime = Math.floor(game.Tools.getServerTime() / 1000);
                    //如果过了刷新时间，要弹窗刷新页面
                    this.onPassFreshTime();
                }
            }
        }


    }

}