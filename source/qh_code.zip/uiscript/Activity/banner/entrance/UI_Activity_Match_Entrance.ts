module uiscript{
    export class UI_Activity_Match_Entrance extends UI_ActivityBase {
        private activityId: number = -1;
        private needPopup: boolean = false;
        constructor(id: number, name: string, needPopup: boolean) {
            super(name, new ui.lobby.activitys.activity_match_entranceUI());
            this.activityId = id;
            this.needPopup = needPopup;
        }

        public getId(): number {
            return this.activityId;
        }

        public isopen(): boolean {
            return UI_Activity.activity_is_running(this.activityId);
        }

        public haveRedPoint(): boolean {
            return false;
        }

        public need_popout(): boolean { 
            return this.needPopup;
        }

        private head: Laya.Image = null;
        private defultHeadSkin: string = 'myres/activity_base/match_entrance_bg.jpg';
        private defultBtnSkin: string = 'myres/activity_base/match_entrance_default.png';
        private enterBtn: Laya.Button = null;
        private loadingSprite: Laya.Sprite = null;
        private animController: UI_FrameAnimationMgr<ui.lobby.activitys.activity_match_entranceUI>;
        

        public onCreate(): void {
            this.head = this.me.getChildByName('head') as Laya.Image;
            this.enterBtn = this.me.getChildByName('btn') as Laya.Button;
            this.loadingSprite = this.me.getChildByName('loading') as Laya.Sprite;
            this.enterBtn.clickHandler = Laya.Handler.create(this, this.onClickEnter, null, false);
            this.animController = new UI_FrameAnimationMgr(this.me);

        }

        public show(): void { 
            this.render();
            this.enable = true;
        }

        public hide(): void {
            this.enable = false;
        }

        private render() {
            this.head.skin = game.Tools.localUISrc(this.defultHeadSkin);
            this.enterBtn.skin = game.Tools.localUISrc(this.defultBtnSkin);
            this.setLoading(true);
            let bannerData = UI_Activity.getActivityEntranceData(this.activityId);
            if (bannerData) {
                let isLoadBtnComplete = false;
                let isLoadHeadComplete = false;
                let onLoadComplete = () => { 
                    if (isLoadBtnComplete && isLoadHeadComplete) { 
                        this.setLoading(false);
                    }
                }

                Laya.loader.load(bannerData.banner_background_url, Laya.Handler.create(this, () => { 
                    this.head.skin = bannerData.banner_background_url;
                    isLoadHeadComplete = true;
                    onLoadComplete();
                }));
                Laya.loader.load(bannerData.banner_button_url, Laya.Handler.create(this, () => { 

                    this.enterBtn.skin = bannerData.banner_button_url;
                    this.enterBtn.anchorX = 0.5;
                    this.enterBtn.anchorY = 0.5;
                    this.enterBtn.x = 816;
                    this.enterBtn.y = 592;
                    
                    isLoadBtnComplete = true;
                    onLoadComplete();
                }));
            }
        }

        private onClickEnter() { 
            if (UI_PiPeiYuYue.Inst.enable) {
                UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                return;
            }
           
            //根据url跳转对应的大会室或者链接
            let bannerData = UI_Activity.getActivityEntranceData(this.activityId);
            //如果url是https开头的，就当做链接处理，否则当做游戏内跳转处理
            //https://开头的链接直接打开浏览器
            //majsoul://contest/detail?unique_id=xxx-
            if (bannerData) {
                if (bannerData.url.startsWith('https://')) {
                    game.Tools.open_link(bannerData.url);
                } else {
                    //根据链接拆分大会室id
                    let url = bannerData.url;
                    let prefix = 'majsoul://contest/detail?unique_id=';
                    if (url.startsWith(prefix)) {
                        let contestId = Number.parseInt(url.substring(prefix.length));
                        UI_Activity.Inst.close();
                        UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                            game.Scene_Lobby.Inst.change_bg('indoor', false);
                            UI_Match_Room.Inst.show(contestId);
                        }));
                        
                    }
                }
            }
        }

        private setLoading(isLoading: boolean) { 
            this.loadingSprite.visible = isLoading;
            if (isLoading) {
                this.animController.playAnim('loading_dot', true);
            } else {
                this.animController.stopAnim('loading_dot');
            }
            
        }

        public onEnable(): void {
            
        }

        public onDisable(): void {
            this.animController.stopAllAnimations();
        }



        




    }
}