/**
* name 
*/
module uiscript {



    class ItemButton extends UI_Component{
        private itemCountLabel: Laya.Label;
        private itemIcon: Laya.Image;
        private btnInfo: Laya.Button;
        private itemRect: UIRect = null;
        private id: number;
        private count: number;

        public get itemId(): number {
            return this.id;
        }

        public set itemId(value: number) {
            this.id = value;
            if (this.itemRect == null) {
                this.itemRect = UIRect.CreateFromSprite(this.itemIcon);
            }
            game.Tools.setItemIcon(this.itemIcon, this.itemRect, value, "UI_Activity", true);
        }


        public get itemCount(): number {
            return this.count;
        }

        public set itemCount(value: number) {
            this.count = value;
            this.itemCountLabel.text = value.toString();
        }


        public onCreate(): void {
            let countSprite = this.me.getChildByName('item_count') as Laya.Sprite;
            this.itemCountLabel = countSprite.getChildByName('count') as Laya.Label;
            let countTitleLabel = countSprite.getChildByName('title') as Laya.Label;
            game.Tools.sprite_align_center([countTitleLabel, this.itemCountLabel], 40);
            let itemSprite = this.me.getChildByName('icon') as Laya.Sprite;
            this.itemIcon = itemSprite.getChildByName('icon') as Laya.Image;
            this.btnInfo = itemSprite.getChildByName('info_btn') as Laya.Button;
            this.btnInfo.clickHandler = Laya.Handler.create(this, this.onClickItemInfo, null, false);
        }

        private onClickItemInfo() {
            if (this.id == 0) {
                return;
            }
            UI_ItemDetail.Inst.show(this.id);
        }
    }

    export class UI_Activity_Exchange_Reward extends UI_ActivityBase {

        /**
         * 当期兑换活动的奖励部分的活动id
         */
        public static activity_id: number = 260302;
        /**
         * 当期兑换活动的道具id
         */
        public static readonly items: Array<number> = [30900100, 30900101];
        private onItemChange: Laya.Handler;
        public isLock: boolean;
        private items: Array<ItemButton> = [];
        private root: Laya.Sprite;
        private scrollPanel: ScrollPanel;
        private head: Laya.Image;
        private task_templete: Laya.Sprite;
        private task_cells: Array<UI_Activity_TaskItem>;
        private head_height: number = 300;
        private taskList: Array<Object> = [];

        public getId(): number {
            return UI_Activity_Exchange_Reward.activity_id;
        }

        constructor() {
            super(cfg.activity.activity.get(UI_Activity_Exchange_Reward.activity_id)['name_' + GameMgr.client_language], new ui.lobby.activitys.activity_exchange_rewardUI());
        }

        public isopen(): boolean {
            return UI_Activity.activity_is_running(this.getId());
        }

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.scrollPanel = new ScrollPanel(this.root as Laya.Sprite);
            this.head = this.scrollPanel.content.getChildByName('head') as Laya.Image;
            this.task_templete = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.task_templete.visible = false;
            this.task_cells = [];
            for (let i: number = 0; i < 25; i++) {
                this.createTaskCell();
            }

           
            this.onItemChange = new Laya.Handler(this, () => {
                this.freshPage();
            })
            
            for (let index = 0; index < UI_Activity_Exchange_Reward.items.length; index++) {
                let itemSprite = this.head.getChildByName("item" + (index + 1)) as Laya.Sprite;
                let itemButton = new ItemButton(itemSprite);
                itemButton.itemId = UI_Activity_Exchange_Reward.items[index];
                this.items.push(itemButton);
            }
            //设置头部图
            game.LoadMgr.setImgSkin(this.head, cfg.activity.activity_banner.get(this.getId()).banner_big);

            
         
        }

        public refreshCurrencyCount() {
            for (let index = 0; index < this.items.length; index++) {
                let item = this.items[index];
                item.itemCount = UI_Bag.get_item_count(item.itemId);
            }
        }

        public show() {
            this.enable = true;
            this.freshPage();
        }

        public hide() {
            this.enable = false;
        }

        public onEnable(): void {
            //道具改变的时候添加监听
            for (let index = 0; index < UI_Activity_Exchange_Reward.items.length; index++) {
                let itemId = UI_Activity_Exchange_Reward.items[index];
                UI_Bag.add_item_listener(itemId, this.onItemChange);
            }
        }

        public onDisable(): void {
            //移除监听
            for (let index = 0; index < UI_Activity_Exchange_Reward.items.length; index++) {
                let itemId = UI_Activity_Exchange_Reward.items[index];
                UI_Bag.remove_item_listener(itemId, this.onItemChange);
            }

        }

        public haveRedPoint(): boolean {
            return this.haveGetReward();
        }

        public need_popout(): boolean {
            let d = cfg.activity.activity.get(this.getId());
            if (d && d.need_popout) return true;
            return false;
        }

        private freshPage() { 
            this.freshData();
            this.freshTaskList();
            this.scrollPanel.scrollValue = 0;
            this.refreshCurrencyCount();
        }

        private freshData() {
            this.taskList = game.Tools.deepCopy(UI_Activity.getPeriodTaskList(this.getId()));
            this.taskList = this.taskList.sort(this.sortTasks);
        }
       

        public isShowGetAll(): boolean {
            return this.haveGetReward();
        }

        public onClickGetAll() {
            if (this.isLock) {
                return;
            }
            //需要领取的奖励的id
            let needGetList: Array<number> = [];
            let allRewardList = UI_Activity.getPeriodTaskList(this.getId());
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }

            if (needGetList.length == 0) return;

            this.isLock = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTaskBatch, { task_list: needGetList }, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    for (let id of needGetList) {
                        //更新服务端奖励数据
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        rewardList.push({ id: rewardId, count: rewardCount });
                        //刷新对应item的状态
                        let index = this.taskList.findIndex((item) => {
                            return item['id'] == id;
                        });
                        this.onClickGet(index);
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                    UI_Activity.Inst.freshGetAllBtn();
                    UI_Lobby.Inst.top.refreshRedpoint();
                    


                }
            })
        }

        /**
         * 如果点击了对应的任务，会调用这个函数去改变当前数据和UI展示
         * @param index 
         */
        private onClickGet(index: number) {
            let taskData = this.taskList[index] as game.ITaskProgress;
            taskData.rewarded = true;
            this.itemRender(index);

        }




        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            // 为每种情况分配权重
            const weightA = (a.achieved ? (a.rewarded ? 3 : 0) : 2);
            const weightB = (b.achieved ? (b.rewarded ? 3 : 0) : 2);

            // 首先比较权重
            if (weightA !== weightB) {
                return weightA - weightB;
            }

            // 如果权重相同，则按照 ID 升序排序
            return a.id - b.id;
        }

        private freshTaskList() { 
            let h: number = this.head_height + 15;
            //如果cell不足，创建新的cell
            while (this.task_cells.length < this.taskList.length) {
                this.createTaskCell();
            }
            for (let i: number = 0; i < this.task_cells.length; i++) {
                let taskCell = this.task_cells[i];
                if (i < this.taskList.length) {
                    this.itemRender(i);
                    taskCell.me.y = h;
                    h += taskCell.me.height;
                    taskCell.visible = true;
                } else {
                    taskCell.me.visible = false;
                }
            }
            this.scrollPanel.contentHeight = h;
            this.scrollPanel.fresh();


        }
        
        private itemRender(index: number) {
            let taskCell = this.task_cells[index];
            let taskData = this.taskList[index] as game.ITaskProgress;
            let d_activity_task = cfg.activity.period_task.get(taskData.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            //显示奖励信息
            let _reward: string = d_activity_task.reward;
            let reward_id: number = 0;
            let rewardCount: number = 0;
            let ss: Array<string> = _reward.split('-');
            reward_id = parseInt(ss[0]);
            rewardCount = parseInt(ss[1]);
            taskCell.itemId = reward_id;
            taskCell.itemCount = rewardCount;
            //显示任务描述
            taskCell.taskDesc = d_task_info['desc_' + GameMgr.client_language];
            //显示进度
            taskCell.taskProgressMax = d_task_info.target;
            taskCell.taskProgress = taskData.counter;

            taskCell.progressVisible = true;
            //显示按钮状态
            taskCell.getBtnVisible = !taskData.rewarded;
            taskCell.alreadyGetVisible = taskData.rewarded;
            taskCell.maskVisible = taskData.rewarded;
            taskCell.getBtnGray = !taskData.achieved;
            taskCell.getBtnEnable = taskData.achieved;
            taskCell.infoVisible = true;

            //领取按钮点击事件
            taskCell.getBtnClickHandler = Laya.Handler.create(this, () => {
                if (this.isLock) {
                    return;
                }
                this.isLock = true;
                taskCell.getBtnGray = true;
                taskCell.getBtnEnable = false;
                app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.completePeriodActivityTask, { task_id: taskData.id }, (err, res) => {
                    this.isLock = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                    } else {
                        this.onClickGet(index);
                        game.Tools.showRewards({ rewards: [{ id: reward_id, count: rewardCount }] }, null);
                        UI_Activity.onPeriodTaskRewarded(taskData.id);
                        UI_Activity.Inst.freshGetAllBtn();
                        UI_Lobby.Inst.top.refreshRedpoint();
                    }
                });
            });
        }

        private createTaskCell(): UI_Activity_TaskItem {
            let taskCell = new UI_Activity_TaskItem(this.task_templete.scriptMap['capsui.UICopy']['getNodeClone']());
            taskCell.progressRemain = true;
            this.scrollPanel.content.addChild(taskCell.me);
            this.task_cells.push(taskCell);
            return taskCell;
        }

        public haveGetReward(): boolean {
            let lst = UI_Activity.getPeriodTaskList(this.getId());
            if (lst) {
                for (let i: number = 0; i < lst.length; i++) {
                    if (!lst[i]['rewarded'] && lst[i]['achieved']) {
                        return true;
                    }
                }
            }
            return false;
        }
     
    }
}