/**
* name 
*/
module uiscript{
	
	export class UI_ActivityBase extends UIBase{

		private __activity_name:string;

		constructor(name:string, sprite: Laya.Sprite) {
			super(sprite);
			this.__activity_name = name;
		}

		public get activity_name(): string { return this.__activity_name; }
		
		/**
		 * 用于从表格中读取数据
		 * @returns 
		 */
		public getId():number {return 0;}

		//活动是否开放中，不开放的活动不会显示
		public isopen():boolean {return false;}

		//活动是否要显示小红点
		public haveRedPoint():boolean {return false;}

		//活动是否要弹出来
		public need_popout():boolean {return false;}

		public show() {

		}
		
		public hide() {
			
		}

		/**
		 * 获取活动剩余时间
		 * @returns 时间戳，单位秒
		 */
		public getLastTime(): number{
			return -1;
		}

		/**
		 * 是否显示一键领取按钮
		 * @returns 
		 */
		public isShowGetAll(): boolean{
			return false;
		}

		/**
		 * 点击一键领取按钮触发的事件
		 */
		public onClickGetAll(): void { 

		}

		/**
		 * 是否有可以领取的奖励
		 * @returns 
		 */
		public haveGetReward(): boolean {
			return false;
		}
	}
}