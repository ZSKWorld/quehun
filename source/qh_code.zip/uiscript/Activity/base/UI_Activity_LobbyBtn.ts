module uiscript {
    export class UI_Activity_LobbyBtn extends UI_Component{
        private btn: Laya.Button;
        private time: Laya.Sprite;
        private timeText: Laya.Label;
        private timeBg: Laya.Sprite;
        private redPoint: Laya.Sprite;
        private icon: Laya.Image;
        /**
         * -1表示没有活动
         */
        public activityId: number = -1;
        private clickHandler: Laya.Handler;
        private showTime: boolean;

        public onCreate(): void {
            this.btn = this.me as Laya.Button;
            this.time = this.me.getChildByName("time") as Laya.Sprite;
            this.timeText = this.time.getChildByName("time") as Laya.Label;
            this.timeBg = this.time.getChildByName("bg") as Laya.Image;
            this.redPoint = this.me.getChildByName("redpoint") as Laya.Sprite;
            this.icon = this.me.getChildByName("icon") as Laya.Image;
            this.btn.clickHandler = new Laya.Handler(this, this.onClick);
            this.time.visible = false;
        }

        public init(activityId: number,clickHandler:Laya.Handler, showTime: boolean = true): void {
            this.activityId = activityId;
            this.showTime = showTime;
            if (activityId == -1) {
                this.visible = false;
                return;
            }
            this.clickHandler = clickHandler;
            let cfgData = cfg.activity.activity_banner.get(activityId);
            if (!cfgData || !cfgData.enter_icon) { 
                this.visible = false;
                return;
            }
            game.LoadMgr.setImgSkin(this.icon, cfgData.enter_icon);
        }


        public freshTime(): void {
            if (!this.isRunning || !this.showTime) {
                return;
            }
            this.time.visible = true;
            this.timeText.text = this.getRestTime();
            this.timeBg.width = this.timeText.trueWidth + 58;
            this.time.width = this.timeText.trueWidth + 53;
            this.time.x = 71 - this.time.width / 2;
        }

        public set timeVisible(value: boolean) {
            this.time.visible = value;
        }

        public get isRunning(): boolean {
            if (this.activityId == -1) {
                return false;
            }
            return UI_Activity.activity_is_running(this.activityId);
        }

        public fresh() {
            this.visible = this.isRunning;
            this.freshTime();
        }

        private onClick(): void { 
            this.clickHandler.run();
        }

        private getRestTime(): string {

            let str = '';
            if (UI_Activity.activity_is_running(this.activityId)) {
                let delta_time = UI_Activity.getActivityEndLeftTime(this.activityId);
                if (delta_time < 0) {
                    return str;
                }
                if (delta_time < 60 * 60) {
                    let k: number = Math.floor(delta_time / 60);
                    if (k == 0) k = 1;
                    str = k + game.Tools.strOfLocalization(2020);
                } else if (delta_time < 24 * 60 * 60) {
                    let k: number = Math.floor(delta_time / 60 / 60);
                    str = k.toString() + game.Tools.strOfLocalization(2021);
                } else {
                    let k: number = Math.floor(delta_time / 24 / 60 / 60);
                    str = k.toString() + game.Tools.strOfLocalization(2022);
                }

            }
            return str;
        }

        public set redPointVisible(value: boolean) {
            this.redPoint.visible = value;
        }

        public set y(y: number){
            this.me.y = y;
        }
    }

}