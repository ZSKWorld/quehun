module uiscript {
    export interface ITaskInfo{
        baseTaskId: number;
        rewardId: number;
        rewardCount: number;
    }
    export class UI_Activity_TaskItem extends UI_Component {

        private bg: Laya.Image;
        private empty_bg: Laya.Image;
        private info: Laya.Sprite;
        private item: Laya.Sprite;
        private itemCountLabel: Laya.Label;
        private itemIcon: Laya.Image;
        private btnInfo: Laya.Button;
        private btnGet: Laya.Button;
        private alreadyget: Laya.Sprite;
        private requirement: Laya.Label;
        private blackMask: Laya.Image;
        private id: number;
        private count: number;
        private itemRect: UIRect = null;
        private btnGetText: Laya.Label;
        private progress: Laya.Sprite;
        private progressBar: Laya.Sprite;
        private progressCount: Laya.Label;
        private progressMax: number = 0;
        private progressMin: number = 0;
        private progressValue: number = 0;
        /**
         * 进度条是否在值为0时剩余4像素
         */
        private isProgressRemain: boolean = false;
        





        public get itemId(): number {
            return this.id;
        }

        public set itemId(value: number) {
            this.id = value;
            if (this.itemRect == null) {
                this.itemRect = UIRect.CreateFromSprite(this.itemIcon);
            }
            game.Tools.setItemIcon(this.itemIcon, this.itemRect, value, "UI_Activity", true);
        }


        public get itemCount(): number {
            return this.count;
        }

        public set itemCount(value: number) {
            this.count = value;
            this.itemCountLabel.text = value.toString();
        }


        public onCreate(): void {
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.empty_bg = this.me.getChildByName('empty_bg') as Laya.Image;
            this.info = this.me.getChildByName('info') as Laya.Sprite;
            this.item = this.info.getChildByName('item') as Laya.Sprite;
            this.itemCountLabel = this.item.getChildByName('item_count') as Laya.Label;
            this.itemIcon = this.item.getChildByName('icon') as Laya.Image;
            this.btnInfo = this.item.getChildByName('info_btn') as Laya.Button;
            this.btnGet = this.info.getChildByName('btn_get') as Laya.Button;
            this.btnGetText = this.btnGet.getChildByName('text') as Laya.Label;
            this.alreadyget = this.info.getChildByName('alreadyget') as Laya.Sprite;
            this.requirement = this.info.getChildByName('requirement') as Laya.Label;
            this.btnInfo.clickHandler = Laya.Handler.create(this, this.onClickItemInfo, null, false);
            this.progress = this.info.getChildByName('progress') as Laya.Sprite;
            this.progressBar = this.progress.getChildByName('val') as Laya.Sprite;
            this.progressCount = this.progress.getChildByName('progress_text') as Laya.Label;
            this.blackMask = this.me.getChildByName('black_mask') as Laya.Image;
            if (this.blackMask) {
                this.blackMask.visible = false;
            }
            this.progress.visible = false;
            this.empty_bg.visible = false;
            this.alreadyget.visible = false;
        }


        public clearItem() {
            this.id = 0;
            this.itemIcon.skin = '';
            this.itemCountLabel.text = '';
        }

        public set taskDesc(desc: string) {
            this.requirement.text = desc;
        }

        public clearTaskDesc() {
            this.requirement.text = '';
        }


        public set getBtnGray(enable: boolean) {
            if (!enable) {
                this.getBtnTextColor = "#6d2e3a";
                this.btnGet.skin = game.Tools.localUISrc("myres/pop_panel/btn_y.png"); //可领取为黄色通用按钮
            } else {
                this.getBtnTextColor = "#525a6b";

                this.btnGet.skin = game.Tools.localUISrc("myres/pop_panel/btn_g.png");
            }
        }

        public set getBtnEnable(enable: boolean) {
            this.btnGet.mouseEnabled = enable;
        }

        public set getBtnText(text: string) {
            this.btnGetText.text = text;
        }

        public set getBtnClickHandler(handler: Laya.Handler) {
            this.btnGet.clickHandler = handler;
        }

        public clearGetBtnClickHandler() {
            game.Tools.clearBtnClickHandler(this.btnGet);
        }

        public set alreadyGetVisible(visible: boolean) {
            this.alreadyget.visible = visible;
        }

        public set getBtnTextColor(color: string) {
            this.btnGetText.color = color;
        }

        public set getBtnVisible(visible: boolean) {
            this.btnGet.visible = visible;
        }

        private onClickItemInfo() {
            if (this.id == 0) {
                return;
            }
            UI_ItemDetail.Inst.show(this.id);
        }

        public set empty(value: boolean) {
            this.empty_bg.visible = value;
            this.bg.visible = !value;
        }


        public set infoVisible(visible: boolean) {
            this.info.visible = visible;
        }

        public set progressVisible(visible: boolean) {
            this.progress.visible = visible;
        }


        /**
         * 设置进度条的最大值，需要在设置进度条值之前调用
         */
        public set taskProgressMax(value: number) {
            this.progressMax = value;
        }

        /**
         * 设置进度条的最小值，需要在设置进度条值之前调用,默认为0
         */
        public set taskProgressMin(value: number) {
            this.progressMin = value;
        }

        public set taskProgress(value: number) {
            if (value < this.progressMin) {
                value = this.progressMin;
            }
            if (value > this.progressMax) {
                value = this.progressMax;
            }
            this.progressValue = value;
            this.progressCount.text = value + '/' + this.progressMax;
            //使用scaleX的原因是width属性不能影响图片大小
            
            if (this.isProgressRemain&&value==0) {
                let progressWidth = this.progressBar.width;
                this.progressBar.scaleX = 4 / progressWidth;
            } else {
                this.progressBar.scaleX = value / this.progressMax;
            }
            
        }

        public get taskProgress(): number {
            return this.progressValue;
        }

        public set progressRemain(value: boolean) { 
            this.isProgressRemain = value;
        }

        public set maskVisible(visible: boolean) {
            if (this.blackMask) {
                this.blackMask.visible = visible;
            }
        }

        public refresh(taskInfo: game.ITaskProgress, d_activity_task: ITaskInfo) {
            const taskConfig = cfg.events.base_task.get(d_activity_task.baseTaskId);
            this.infoVisible = true;
            this.getBtnVisible = false;
            this.alreadyGetVisible = false;
            if (taskInfo.rewarded) {
                this.alreadyGetVisible = true;
            } else {
                this.getBtnVisible = true;
                this.getBtnGray = !taskInfo.achieved;
                this.getBtnEnable = !!taskInfo.achieved;
            }
            this.taskDesc = taskConfig['desc_' + GameMgr.client_language];
            this.itemId = d_activity_task.rewardId;
            this.itemCount = d_activity_task.rewardCount;
            let counter: number = taskInfo.counter || 0;
            counter = counter > taskConfig.target ? taskConfig.target : counter;
            this.progressVisible = true;
            this.taskProgressMax = taskConfig.target;
            this.taskProgress = counter;
        }

    }
}