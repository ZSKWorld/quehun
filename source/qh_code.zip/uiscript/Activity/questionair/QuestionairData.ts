module uiscript {
    export const enum QuestionType {
        None = "",
        Select = "select",
        Input = "input",
    }
    export const enum QuestionSubType {
        None = "",
        SingleLine = "single_row",
        CheckBox = "checkbox",
        Rate = "rate",
        Matrix = "matrix",
    }
    export const enum QuestionairType {
        /** 普通问卷 */
        Questionair = 1,
        /** 四象战报名 */
        SignUpSiXiangZhan,
        /** 官方赛事报名 */
        SignUpOfficalTournament,
    }
    export class QuestionairData {

        public static get channelName() {
            if (GameMgr.inDmm) return "web_dmm";
            if (GameMgr.client_type == "kr") return "web_kr";
            return "web";
        }
        private static _questionList: game.ProtoObject<game.IResFetchQuestionnaireList>;
        private static _finished_list: number[] = [];
        private static _questionairs: { [key in QuestionairType]: game.ProtoObject<game.IQuestionnaireBrief> } = {
            [QuestionairType.Questionair]: null,
            [QuestionairType.SignUpOfficalTournament]: null,
            [QuestionairType.SignUpSiXiangZhan]: null,
        };
        private static _questionDetails: { [key in QuestionairType]: game.ProtoObject<game.IQuestionnaireDetail> } = {
            [QuestionairType.Questionair]: null,
            [QuestionairType.SignUpOfficalTournament]: null,
            [QuestionairType.SignUpSiXiangZhan]: null,
        };
        private static _dataMap: { [key in QuestionairType]?: {
            openTime: number,
            finishTime: number,
            finishedList?: number[],
            questionair?: game.ProtoObject<game.IQuestionnaireBrief>,
            questionDetail?: game.ProtoObject<game.IQuestionnaireDetail>,
            sortedQuestions?: game.ProtoObject<game.IQuestionnaireQuestion>[],
        } } = {
                [QuestionairType.Questionair]: { openTime: 0, finishTime: 0 },
                [QuestionairType.SignUpOfficalTournament]: { openTime: 0, finishTime: 0 },
                [QuestionairType.SignUpSiXiangZhan]: { openTime: 0, finishTime: 0 },
            };

        private static _lockFetchList: boolean;
        private static _lockFetchDetail: boolean;

        static fetchList(caller?: any, func?: Function) {
            if (this._lockFetchList) return func && func.call(caller);
            this._lockFetchList = true;
            const param: game.IReqFetchQuestionnaireList = { lang: GameMgr.client_language, channel: this.channelName };
            app.NetAgent.sendReq2Lobby("Lobby", game.ERequest.fetchQuestionnaireList, param, (err, res: game.IResFetchQuestionnaireList) => {
                if (err || res.error) {
                    UIMgr.Inst.showNetReqError(game.ERequest.fetchQuestionnaireList, err, res);
                } else {
                    this._questionList = res;
                    this._finished_list = [...res.finished_list];
                    const timestamp = Math.floor(game.Tools.getServerTime() / 1000);
                    const validList = res.list.filter(v => timestamp >= v.effective_time_start && timestamp <= v.effective_time_end);
                    const unfinishedList = validList.filter(v => this._finished_list.indexOf(v.id) == -1);
                    Object.keys(this._questionairs).forEach(v => {
                        this._questionairs[v] = unfinishedList.filter(uv => uv.type == +v)[0];
                    });
                }
                this._lockFetchList = false;
                func && func.call(caller);
            });
        }

        static fetchDetail(type: QuestionairType, caller?: any, func?: Function) {
            if (this._lockFetchDetail || this._questionDetails[type]) return func && func.call(caller);
            this._lockFetchDetail = true;
            const call_func = () => {
                this._lockFetchDetail = false;
                func && func.call(caller);
            };
            const fetch_detail = () => {
                const questionair = this._questionairs[type];
                if (!questionair) return call_func();
                const param: game.IReqFetchQuestionnaireDetail = { id: questionair.id, lang: GameMgr.client_language, channel: this.channelName };
                app.NetAgent.sendReq2Lobby("Lobby", game.ERequest.fetchQuestionnaireDetail, param, (err, res: game.IResFetchQuestionnaireDetail) => {
                    if (err || res.error) {
                        UIMgr.Inst.showNetReqError(game.ERequest.fetchQuestionnaireDetail, err, res);
                    } else {
                        this._questionDetails[type] = res.detail;
                    }
                    call_func();
                });
            };
            if (this._questionairs[type]) fetch_detail();
            else this.fetchList(this, fetch_detail);
        }

        static recordTime(type: QuestionairType, isOpen?: boolean) {
            const time = Math.floor(game.Tools.getServerTime() / 1000);
            const recordTime = this._dataMap[type];
            if (isOpen) recordTime.openTime = time;
            else recordTime.finishTime = time;
        }

        static getData(type: QuestionairType) {
            const data = this._dataMap[type];
            data.finishedList = this._finished_list;
            data.questionair = this._questionairs[type];
            data.questionDetail = this._questionDetails[type];
            if (data.questionDetail && !data.sortedQuestions) {
                data.sortedQuestions = [];
                const questions = data.questionDetail.questions;
                questions.forEach((v, i) => {
                    const jsonV = v.toJSON();
                    data.sortedQuestions.push(jsonV);
                    if (jsonV.option_random_sort) {
                        const { type, option_random_sort_index, options, matrix_row } = jsonV;
                        const dataArr: any[] = type == QuestionType.Select && matrix_row && matrix_row.length ? matrix_row : options;

                        let unsort: any[];
                        const sort = dataArr;
                        if (option_random_sort_index > 0) {
                            unsort = sort.splice(0, option_random_sort_index);
                        } else if (option_random_sort_index < 0) {
                            unsort = sort.splice(option_random_sort_index);
                        }
                        for (let i = sort.length - 1; i >= 0; i--) {
                            const index = Math.floor(Math.random() * sort.length);
                            const temp = sort[i];
                            sort[i] = sort[index];
                            sort[index] = temp;
                        }
                        if (option_random_sort_index > 0) {
                            sort.unshift(...unsort);
                        } else if (option_random_sort_index < 0) {
                            sort.push(...unsort);
                        }
                    }
                });
            }
            return data;
        }

        static finished(type: QuestionairType) {
            this._finished_list.push(this._questionDetails[type].id);
        }
    }
}