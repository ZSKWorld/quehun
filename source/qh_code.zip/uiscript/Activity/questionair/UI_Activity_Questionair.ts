/**
* UI_Activity_Questionair  问卷 
*/
module uiscript {
    class UBBParser {
        private static _inst: UBBParser;
        private _text: string;
        private _readPos: number = 0;
        private _imgWidth: number = 0;
        private _imgHeight: number = 0;
        private _handlers: { [key: string]: Function };
        static get Inst() { return this._inst || (this._inst = new UBBParser()); }
        private constructor() {
            this._handlers = {
                url: this.onTag_URL,
                img: this.onTag_IMG,
                b: this.onTag_B,
                i: this.onTag_I,
                u: this.onTag_Simple,
                sup: this.onTag_Simple,
                sub: this.onTag_Simple,
                color: this.onTag_COLOR,
                font: this.onTag_FONT,
                size: this.onTag_SIZE,
            };
        }

        private onTag_URL(tagName: string, end: boolean, attr: string) {
            if (!end) {
                if (attr != null) return "<a href=\"" + attr + "\" target=\"_blank\">"; else {
                    var href = this.getTagText();
                    return "<a href=\"" + href + "\" target=\"_blank\">";
                }
            } else return "</a>";
        }
        private onTag_IMG(tagName: string, end: boolean, attr: string) {
            if (!end) {
                var src = this.getTagText(true);
                if (!src) return null;
                if (this._imgWidth) return "<img src=\"" + src + "\" width=\"" + this._imgWidth + "\" height=\"" + this._imgHeight + "\"/>";
                else return "<img src=\"" + src + "\"/>";
            } else return null;
        }
        private onTag_Simple(tagName: string, end: boolean, attr: string) {
            return end ? "</" + tagName + ">" : "<" + tagName + ">";
        }
        private onTag_I(tagName: string, end: boolean, attr: string) {
            return end ? ("</span>") : ("<span style='italic:true'>");
        }
        private onTag_B(tagName: string, end: boolean, attr: string) {
            return end ? ("</span>") : ("<span style='font-weight:bold'>");
        }
        private onTag_COLOR(tagName: string, end: boolean, attr: string) {
            if (!end) return "<font color=\"" + attr + "\">"; else return "</font>";
        }
        private onTag_FONT(tagName: string, end: boolean, attr: string) {
            if (!end) return "<font face=\"" + attr + "\">"; else return "</font>";
        }
        private onTag_SIZE(tagName: string, end: boolean, attr: string) {
            if (!end) return "<span style=\"font-size:" + attr + "\">";
            else return "</span>";
        }
        private getTagText(remove: boolean = false) {
            var pos1 = this._readPos;
            var pos2 = 0;
            var result = "";
            while ((pos2 = this._text.indexOf("[", pos1)) != -1) {
                if (this._text.charCodeAt(pos2 - 1) == 92) {
                    result += this._text.substring(pos1, pos2 - 1);
                    result += "[";
                    pos1 = pos2 + 1;
                } else {
                    result += this._text.substring(pos1, pos2);
                    break;
                }
            }
            if (pos2 == -1) return null;
            if (remove) this._readPos = pos2;
            return result;
        }
        parse(text: string, imgWidth: number = 0, imgHeight: number = 0, remove: boolean = false) {
            this._imgWidth = imgWidth;
            this._imgHeight = imgHeight;
            this._text = text;
            var pos1 = 0,
                pos2 = 0,
                pos3 = 0;
            var end = false;
            var tag, attr;
            var repl;
            var func;
            var result = "";
            while ((pos2 = this._text.indexOf("[", pos1)) != -1) {
                if (pos2 > 0 && this._text.charCodeAt(pos2 - 1) == 92) {
                    result += this._text.substring(pos1, pos2 - 1);
                    result += "[";
                    pos1 = pos2 + 1;
                    continue;
                }
                result += this._text.substring(pos1, pos2);
                pos1 = pos2;
                pos2 = this._text.indexOf("]", pos1);
                if (pos2 == -1) break;
                end = this._text.charAt(pos1 + 1) == '/';
                tag = this._text.substring(end ? pos1 + 2 : pos1 + 1, pos2);
                this._readPos = pos2 + 1;
                attr = null;
                repl = null;
                pos3 = tag.indexOf("=");
                if (pos3 != -1) {
                    attr = tag.substring(pos3 + 1);
                    tag = tag.substring(0, pos3);
                }
                tag = tag.toLowerCase();
                func = this._handlers[tag];
                if (func != null) {
                    if (!remove) {
                        repl = func.call(this, tag, end, attr);
                        if (repl != null) result += repl;
                    }
                } else result += this._text.substring(pos1, this._readPos);
                pos1 = this._readPos;
            }
            if (pos1 < this._text.length) result += this._text.substr(pos1);
            this._text = null;
            return result;
        }

    }
    class QuestionairStart {
        me: Laya.Sprite;
        private _html_text: Laya.HTMLDivElement;
        private _html_title: Laya.HTMLDivElement;
        private _scrollbar: capsui.CScrollBar;
        private _content: Laya.Panel;
        private _txt_btnText: Laya.Label;
        constructor(me: Laya.Sprite) {
            this.me = me;
            me.visible = false;
            const btnStart = me.getChildByName("btn_start") as Laya.Button;
            btnStart.clickHandler = Laya.Handler.create(this, () => {
                this.close();
                UI_Activity_Questionair.Inst.contentPanel.show();
            }, null, false);
            this._txt_btnText = btnStart.getChildAt(0) as Laya.Label;
            (me.getChildByName("btn_exit") as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_Activity_Questionair.Inst.close();
            }, null, false);

            this._scrollbar = (me.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this._scrollbar.init(new Laya.Handler(this, rate => {
                this._content.vScrollBar.value = this._content.vScrollBar.max * rate;
            }));
            this._content = me.getChildByName('content') as Laya.Panel;
            this._content.vScrollBarSkin = '';
            this._content.vScrollBar.on(Laya.Event.CHANGE, this, () => {
                this._scrollbar.setVal(this._content.vScrollBar.value / this._content.vScrollBar.max, this._content.height / (this._html_text.contextHeight + 5));
            });
            this._html_text = this._content.getChildByName("text") as Laya.HTMLDivElement;
            this._html_title = me.getChildByName("title") as Laya.HTMLDivElement;
            this._html_title.style.fontFamily = UI_Mail.font;
        }

        show() {
            const localAnswer = UI_Activity_Questionair.Inst.contentPanel.getLocalAnswer();
            this._txt_btnText.text = game.Tools.strOfLocalization(localAnswer && localAnswer.length > 0 ? 20129 : 20130);
            const { announcement_title, announcement_content } = QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType).questionDetail;
            QuestionairContent.loadHtmlTextures(announcement_title + announcement_content, Laya.Handler.create(this, () => {
                QuestionairContent.setHtmlText(this._html_title, announcement_title, 48, 10, "#D4CFCF", 100, 100);
                QuestionairContent.setHtmlText(this._html_text, announcement_content, 38, 10, "#80838c", 100, 100);
                this._html_text._height = this._html_text.contextHeight;
                this.rectifyDisplay();
                this.me.visible = true;
            }));
        }

        close() {
            this.me.visible = false;
        }

        private rectifyDisplay() {
            const { y, contextHeight } = this._html_title;
            this._content.height = this._content.y - (y + contextHeight + (contextHeight > 116 ? 24 : 48));
            this._scrollbar.me.y = this._content.y - this._content.height;
            this._scrollbar.updateHeight(this._content.height);
            this._content.refresh();
            this._content.vScrollBar.value = 0;
            this._content.vScrollBar.event(Laya.Event.CHANGE);
        }
    }
    class QuestionairFinished {
        me: Laya.Sprite;
        private _label_text: Laya.Label;
        private _locked: boolean = false;
        private _submited: boolean = false;
        constructor(me: Laya.Sprite) {
            this.me = me;
            me.visible = false;
            this._label_text = me.getChildByName("text") as Laya.Label;
            const btnSubmit = me.getChildByName("btn_confirm") as Laya.Button;
            btnSubmit.clickHandler = Laya.Handler.create(this, this.submitQuestion, [true], false);
        }

        show() {
            this._submited = false;
            QuestionairData.recordTime(UI_Activity_Questionair.Inst.questionairType);
            this._label_text.text = QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType).questionDetail.final_text;
            this.submitQuestion(false);
            this.me.visible = true;
        }

        close() {
            this.me.visible = false;
        }

        private submitQuestion(doClose: boolean) {
            if (this._locked) return;
            if (this._submited) {
                doClose && UI_Activity_Questionair.Inst.finished();
                return;
            }
            this._locked = true;
            const { openTime, finishTime, questionDetail } = QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType);
            const param: game.IReqSubmitQuestionnaire = {
                questionnaire_id: questionDetail.id,
                questionnaire_version_id: questionDetail.version_id,
                answers: UI_Activity_Questionair.Inst.contentPanel.answers.filter(v => {
                    if (v && v.values.length > 0) {
                        return v.values.every(vv => vv.value != "");
                    } else return false;
                }),
                open_time: openTime,
                finish_time: finishTime,
                client: game.ResourceVersion.version,
            };
            app.NetAgent.sendReq2Lobby("Lobby", game.ERequest.submitQuestionnaire, param, (err, res: game.IResCommon) => {
                this._locked = false;
                if (err || res.error) {
                    UIMgr.Inst.showNetReqError(game.ERequest.fetchQuestionnaireList, err, res);
                } else {
                    UI_Activity_Questionair.Inst.contentPanel.clearLocalAnswer();
                    this._submited = true;
                    doClose && UI_Activity_Questionair.Inst.finished();
                }
            });
        }
    }
    class QuestionBase extends Laya.EventDispatcher {
        parent: Laya.Sprite;
        htmlTitle: Laya.HTMLDivElement;
        content: Laya.Panel;
        scrollbar: capsui.CScrollBar;
        data: game.IQuestionnaireQuestion;
        originData: game.IQuestionnaireQuestion;
        protected _answer: game.IReqSubmitQuestionnaire_QuestionnaireAnswer;
        get type(): QuestionType { return this.data ? this.data.type as QuestionType : QuestionType.None; };
        get subType(): QuestionSubType { return this.data ? this.data.sub_type as QuestionSubType : QuestionSubType.None; }

        get answerOK() { return false; }
        get answer() { return this._answer; }

        constructor(parent: Laya.Sprite, htmlTitle: Laya.HTMLDivElement, content: Laya.Panel, scrollbar: capsui.CScrollBar) {
            super();
            this.parent = parent;
            this.htmlTitle = htmlTitle;
            this.content = content;
            this.scrollbar = scrollbar;
            this.onContructed();
            parent.visible = false;
        }

        show(data: game.IQuestionnaireQuestion, originData: game.IQuestionnaireQuestion, answer?: game.IReqSubmitQuestionnaire_QuestionnaireAnswer) {
            this.data = data;
            this.originData = originData;
            this._answer = answer;
            this.onShow();
            this.rectifyDisplay();
            this.scrollbar.me.y = this.content.y - this.content.height;
            this.scrollbar.updateHeight(this.content.height);
            this.refreshContent();
            this.parent.visible = true;
        }

        close() {
            this.data = null;
            this.originData = null;
            this._answer = null;
            this.onHide();
            this.parent.visible = false;
            this.parent.height = 10;
        }

        onScroll() { }

        protected onContructed() { }
        protected onShow() { }
        protected onHide() { }
        protected rectifyDisplay() {
            const { y, contextHeight } = this.htmlTitle;
            this.content.height = this.content.y - (y + contextHeight + (contextHeight > 116 ? 24 : 48));
        }

        protected refreshContent() {
            this.content.refresh();
            this.content.vScrollBar.value = 0;
            this.content.vScrollBar.event(Laya.Event.CHANGE);
        }
    }
    class QuestionairInput {
        private static template: QuestionairInput;
        me: Laya.Sprite;
        onChanged: Laya.Handler;
        private _input_txt: Laya.TextInput;
        private _img_bg: Laya.Image;
        private _img_underline: Laya.Image;
        private _txtLimit: number = 0;

        get input() { return this._input_txt; }
        get x() { return this.me.x; }
        set x(value) { this.me.x = value; }
        get y() { return this.me.y; }
        set y(value) { this.me.y = value; }
        get width() { return this.me.width; }
        set width(value) {
            this.me.width = value;
            this._img_bg.width = value;
            this._input_txt.width = value - 19 * 2;
            this._img_underline.width = this._input_txt.width;
        }
        get height() { return this.me.height; }
        set height(value) {
            this.me.height = value;
            this._img_bg.height = value;
            this._input_txt.height = value - this._input_txt.x * 2;
            this._img_underline.y = value - 12;
        }
        get visible() { return this.me.visible; }
        set visible(value) { this.me.visible = value; }
        get text() { return this._input_txt.text; }
        set text(value) { this._input_txt.text = value; }
        set focus(value: boolean) { this._input_txt.focus = value; }
        get multiline() { return this._input_txt.multiline; }
        set multiline(value) {
            this._input_txt.multiline = value;
            this._input_txt.wordWrap = value;
            this._txtLimit = value ? 1000 : 50;
            this._input_txt.prompt = game.Tools.strOfLocalization(20131, [this._txtLimit.toString()]);
        }
        get bgVisible() { return this._img_bg.visible; }
        set bgVisible(value) {
            this._img_bg.visible = value;
            this._img_underline.visible = !value;
        }

        static create() {
            const item: QuestionairInput = Laya.Pool.getItemByCreateFun("QuestionairInput", () => {
                const ui = (QuestionairInput.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                return new QuestionairInput(ui);
            });
            item.visible = true;
            return item;
        }

        constructor(me: Laya.Sprite) {
            this.me = me;
            this._input_txt = me.getChildByName("input_txt") as Laya.TextInput;
            if (GameMgr.client_language == 'kr') {
                this._input_txt.font = 'NotoSansKR';
            }
            this._img_bg = me.getChildByName("input_bg") as Laya.Image;
            this._img_underline = me.getChildByName("underline") as Laya.Image;

            let lastText = "";
            const onInput = () => {
                if (this._txtLimit <= 0) return;
                this._input_txt.text = this._input_txt.text.substring(0, this._txtLimit);
            }
            let duringComposition = false;
            const onCompositionstart = (event) => {
                // 输入中文开始
                duringComposition = true;
            };
            const onCompositionend = (event) => {
                // 输入中文结束
                duringComposition = false;
                onInput();
            };
            this._input_txt.on(Laya.Event.FOCUS, null, () => {
                lastText = this._input_txt.text;
                const input = (<Laya.Input>this._input_txt["_tf"]);
                input.nativeInput.addEventListener('compositionstart', onCompositionstart);
                input.nativeInput.addEventListener('compositionend', onCompositionend);
            });
            this._input_txt.on(Laya.Event.BLUR, null, () => {
                const input = (<Laya.Input>this._input_txt["_tf"]);
                input.nativeInput.removeEventListener('compositionstart', onCompositionstart);
                input.nativeInput.removeEventListener('compositionend', onCompositionend);
                lastText != this._input_txt.text && this.onChanged && this.onChanged.run();
            });

            this._input_txt.on(Laya.Event.INPUT, null, () => !duringComposition && onInput());
        }

        pos(x: number, y: number, speedMode: boolean = false) { this.me.pos(x, y, speedMode); }

        recover() {
            if (!QuestionairInput.template)
                QuestionairInput.template = this;
            this.visible = false;
            if (this.onChanged) this.onChanged.recover();
            this.onChanged = null;
            Laya.Pool.recover("QuestionairInput", this);
        }
    }
    /** 输入 */
    class InputQuestion extends QuestionBase {
        private _input: QuestionairInput;
        get answerOK() {
            if (!this.data) return false;
            if (this.data.require && !this._input.text) return false;
            return true;
        }
        get answer() {
            if (!this.data) return this._answer;
            if (!this._answer) {
                this._answer = { question_id: this.data.id, values: [{ value: "", custom_input: "" }] };
            }
            this._answer.values[0].value = this._input.text;
            return this._answer;
        }
        protected onContructed() {
            this._input = QuestionairInput.create();
            this._input.bgVisible = true;
            this._input.width = 1640;
            this._input.pos(0, 0, true);
            this._input.onChanged = Laya.Handler.create(this, this.event, [Laya.Event.CHANGED], false);
            this.parent.addChild(this._input.me);
        }

        protected onShow() {
            const { _input, data, _answer } = this;
            _input.multiline = data.sub_type != QuestionSubType.SingleLine;
            _input.text = _answer ? _answer.values[0].value : '';
            if (this.data.sub_type != QuestionSubType.SingleLine) {
                this._input.input.on(Laya.Event.FOCUS, this, this.onInputChanged);
                this._input.input.on(Laya.Event.BLUR, this, this.onInputChanged);
            } else {
                this._input.input.off(Laya.Event.FOCUS, this, this.onInputChanged);
                this._input.input.off(Laya.Event.BLUR, this, this.onInputChanged);
            }
        }

        protected rectifyDisplay() {
            super.rectifyDisplay();
            let height = 80;
            if (this.data.sub_type != QuestionSubType.SingleLine) {
                if (Laya.Input.isInputting)
                    height = this.content.height;
                else
                    height = Math.max(this.content.height, this._input.input.trueHeight + 40);
            }
            this._input.height = height;
            this.parent.height = height;
        }

        protected refreshContent() {
            this.content.refresh();
            this.content.vScrollBar.value = this.content.vScrollBar.max;
            // this.content.vScrollBar.event(Laya.Event.CHANGE);
        }

        private onInputChanged() {
            this.show(this.data, this.originData, this.answer);
        }
    }
    class SelectQuestionItem {
        private static template: SelectQuestionItem;
        me: Laya.Button;
        onInputChanged: Laya.Handler;
        private _img_bg: Laya.Image;
        private _img_selected: Laya.Image;
        private _img_check: Laya.Image;
        private _html_title: Laya.HTMLDivElement;
        private _input: QuestionairInput;

        private _title: string = "";
        checkbox: boolean = false;
        itemIndex: number = 0;
        private _selected: boolean = false;
        get selected() { return this._selected; }
        set selected(value) {
            if (value == this._selected) return;
            this._selected = value;
            this._img_selected.visible = value;
            this._img_check.visible = value && this.checkbox;
            QuestionairContent.setHtmlText(this._html_title, this._title, 38, 7, value ? "#d4cfcf" : "#80838c", 100, 100, GameMgr.client_language == 'kr' ? 'NotoSansKR' : '');
        }
        get title() { return this._title; }
        set title(value) {
            if (value == this._title) return;
            this._title = value;
            QuestionairContent.setHtmlText(this._html_title, value, 38, 7, "#80838c", 100, 100, GameMgr.client_language == 'kr' ? 'NotoSansKR' : '');
            this.refreshLayout();
        }
        set width(value: number) {
            this.me.width = value;
            this._img_bg.width = value;
            this._img_selected.width = value;
            this._img_check.x = value - this._img_check.width;
            this._html_title.width = value - 60;
            this.refreshLayout();
        }
        set allowInput(value: boolean) {
            if (value) {
                if (!this._input) {
                    this._input = QuestionairInput.create();
                    this._input.bgVisible = false;
                    this._input.height = 78;
                    this._input.multiline = false;
                    this._input.onChanged = Laya.Handler.create(this, this.onInputTextChanged, null, false);
                    this.me.addChild(this._input.me);
                }
            } else {
                if (this._input) this._input.recover();
                this._input = null;
            }
        }
        set inputFocus(value: boolean) { this._input && (this._input.focus = value); }
        get inputText() { return this._input ? this._input.text : ""; }
        set inputText(value) { if (this._input) this._input.text = value; }

        static create() {
            return Laya.Pool.getItemByCreateFun("SelectQuestionItem", () => {
                const ui = (SelectQuestionItem.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                return new SelectQuestionItem(ui as Laya.Button);
            }) as SelectQuestionItem;
        }

        constructor(me: Laya.Button) {
            this.me = me;
            this._img_bg = me.getChildByName("bg") as Laya.Image;
            this._img_selected = me.getChildByName("select") as Laya.Image;
            this._img_check = me.getChildByName("check") as Laya.Image;
            this._html_title = me.getChildByName("title") as Laya.HTMLDivElement;
            this._img_selected.mouseEnabled = false;
            this._img_check.mouseEnabled = false;
            this._html_title.mouseEnabled = false;
            this.selected = !this.selected;
            this.selected = false;
            this.title = "";
        }

        onClick(caller: any, listener: Function) {
            this._img_bg.on(Laya.Event.CLICK, caller, listener, [this]);
        }

        recover() {
            if (!SelectQuestionItem.template)
                SelectQuestionItem.template = this;
            this.allowInput = false;
            this.checkbox = false;
            this.itemIndex = 0;
            this.title = "";
            this.selected = false;
            this.me.visible = false;
            if (this.onInputChanged) this.onInputChanged.recover();
            this.onInputChanged = null;
            this._img_bg.offAll(Laya.Event.CLICK);
            Laya.Pool.recover("SelectQuestionItem", this);
        }

        private refreshLayout() {
            let isBreakLine = false;
            if (GameMgr.client_language == "en") {
                isBreakLine = this._html_title.contextWidth > this.me.width * 0.4;
            } else {
                isBreakLine = this._html_title.contextWidth > this.me.width * 0.5;
            }
            const height = this._html_title.contextHeight + 44 + (isBreakLine && this._input ? this._input.input.height + 10 : 0);
            this._img_bg.height = height;
            this._img_selected.height = height;
            this._img_check.y = height;
            this.me.height = height;
            if (this._input) {
                const x = isBreakLine ? 10 : (this._html_title.x + this._html_title.contextWidth + 50);
                const y = isBreakLine ? (this.me.height - 4 - this._input.height) : ((this.me.height - this._input.height) / 2);
                this._input.pos(x, y, true);
                this._input.width = this.me.width - x - 20;
            }
        }

        private onInputTextChanged() {
            if (!this.selected) this._img_bg.event(Laya.Event.CLICK);
            this.onInputChanged && this.onInputChanged.run();
        }
    }
    /** 单选|多选 */
    class SelectQuestion extends QuestionBase {
        private _items: SelectQuestionItem[] = [];
        get answerOK() {
            if (!this.data) return false;
            const selectedItems = this._items.filter(v => v.selected);
            if (this.data.require && selectedItems.length == 0) return false;
            return true;
        }
        get answer() {
            if (!this.data) return this._answer;
            const selectedItems = this._items.filter(v => v.selected);
            if (!this._answer) this._answer = { question_id: this.data.id, values: [] };
            const values = this._answer.values;
            if (values.length > selectedItems.length) values.length = selectedItems.length;
            const options = this.data.options;
            selectedItems.forEach((v, i) => {
                let value = values[i];
                if (!value) values.push(value = { value: "", custom_input: "" });
                value.value = options[v.itemIndex].value;
                value.custom_input = v.inputText;
            });
            return this._answer;
        }

        onScroll() {
            this._items.forEach(v => v.inputFocus = false);
        }

        protected onContructed() {
            new SelectQuestionItem(this.parent.getChildAt(0) as Laya.Button).recover();
        }

        protected onShow() {
            const { data, _answer, _items } = this;
            const maxCnt = data.options.length;
            for (let i = 0; i < maxCnt; i++) {
                const optionData = data.options[i];
                let item = _items[i];
                if (optionData) {
                    if (!item) _items.push(item = SelectQuestionItem.create());
                    item.checkbox = data.max_choice != 1;
                    item.itemIndex = i;
                    item.allowInput = optionData.allow_input;
                    item.title = optionData.label;
                    const answerValue = _answer ? _answer.values.find(v => v.value == optionData.value) : null;
                    item.selected = !!answerValue;
                    item.inputText = answerValue ? answerValue.custom_input : "";
                    item.onInputChanged = Laya.Handler.create(this, this.event, [Laya.Event.CHANGED], false);
                    item.onClick(this, this.onItemClick);
                    item.me.visible = true;
                }
            }
        }

        protected onHide() {
            this._items.forEach(v => v.recover());
            this._items.length = 0;
        }

        protected rectifyDisplay() {
            super.rectifyDisplay();
            //因为父物体布局和item布局相互依赖， 所以需要调用两次才能正确计算高度
            this.rectifyDisplay2();
            this.rectifyDisplay2();
        }

        private rectifyDisplay2() {
            let y = 0;
            this._items.forEach(v => {
                v.me.y = y;
                y += v.me.height + 18;
            });
            this.parent.height = y - 18;
            const screen_rate = this.content.height / this.parent.height;
            this._items.forEach(v => {
                v.width = screen_rate >= 1 ? 1640 : 1610;
            });
        }

        private onItemClick(item: SelectQuestionItem) {
            if (this.data.max_choice == 0) item.selected = !item.selected;
            else if (this.data.max_choice == 1) {
                if (item.selected) return;
                this._items.forEach(v => v.selected = v == item);
            } else {
                if (item.selected) item.selected = !item.selected;
                else {
                    const selectCnt = this._items.filter(v => v.selected).length;
                    if (selectCnt < this.data.max_choice) item.selected = !item.selected;
                }
            }
            this.event(Laya.Event.CHANGED);
        }
    }

    class MatrixQuestionTitle {
        private static template: MatrixQuestionTitle;
        me: Laya.Sprite;
        data: string;
        html_title: Laya.HTMLDivElement;
        private _title: string = "";
        get title() { return this._title; }
        set title(value) {
            if (value == this._title) return;
            this._title = value;
            QuestionairContent.setHtmlText(this.html_title, value, 38, 7, "#d4cfcf", 300, 300, GameMgr.client_language == 'kr' ? 'NotoSansKR' : '');
            this.me.height = this.html_title.y + this.html_title.contextHeight;
        }

        static create() {
            const item: MatrixQuestionTitle = Laya.Pool.getItemByCreateFun(
                "MatrixQuestionTitle", () => {
                    const ui = (MatrixQuestionTitle.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                    return new MatrixQuestionTitle(ui as Laya.Sprite);
                });
            return item;
        }

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.html_title = me.getChildByName("title") as Laya.HTMLDivElement;
        }

        show(data: string) {
            this.data = data;
            this.title = data;
            this.me.visible = true;
        }

        recover() {
            if (!MatrixQuestionTitle.template)
                MatrixQuestionTitle.template = this;
            this.data = "";
            this.title = "";
            this.me.visible = false;
            Laya.Pool.recover("MatrixQuestionTitle", this);
        }
    }

    class MatrixQuestionOptionTitle {
        private static template: MatrixQuestionOptionTitle;
        me: Laya.Label;
        data: game.IQuestionnaireQuestion_QuestionOption;

        static create() {
            const item: MatrixQuestionOptionTitle = Laya.Pool.getItemByCreateFun(
                "MatrixQuestionOptionTitle", () => {
                    const ui = (MatrixQuestionOptionTitle.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                    return new MatrixQuestionOptionTitle(ui as Laya.Label);
                });
            return item;
        }

        constructor(me: Laya.Label) {
            this.me = me;
            if (GameMgr.client_language == 'kr') {
                me.font = 'NotoSansKR';
            }
            me.wordWrap = true;
        }

        show(data: game.IQuestionnaireQuestion_QuestionOption) {
            this.data = data;
            this.me.text = data.label;
            this.me.visible = true;
        }

        recover() {
            if (!MatrixQuestionOptionTitle.template)
                MatrixQuestionOptionTitle.template = this;
            this.data = null;
            this.me.visible = false;
            Laya.Pool.recover("MatrixQuestionOptionTitle", this);
        }
    }

    class MatrixQuestionBtn {
        private static template: MatrixQuestionBtn;
        me: Laya.Button;
        private _img_checkbox: Laya.Image;
        titleIndex: number = 0;
        private _selected: boolean = false;
        get selected() { return this._selected; }
        set selected(value) {
            if (this._selected == value) return;
            this._selected = value;
            this._img_checkbox.visible = value;
        }

        static create() {
            const item: MatrixQuestionBtn = Laya.Pool.getItemByCreateFun(
                "MatrixQuestionBtn", () => {
                    const ui = (MatrixQuestionBtn.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                    return new MatrixQuestionBtn(ui as Laya.Button);
                });
            return item;
        }

        constructor(me: Laya.Button) {
            this.me = me;
            this._img_checkbox = me.getChildByName("checkbox") as Laya.Image;
            this._img_checkbox.visible = false;
        }

        show(titleIndex: number, selected: boolean = false) {
            this.titleIndex = titleIndex;
            this.selected = selected;
            this.me.visible = true;
        }

        onClick(caller: any, listener: Function) {
            this.me.on(Laya.Event.CLICK, caller, listener, [this]);
        }

        recover() {
            if (!MatrixQuestionBtn.template)
                MatrixQuestionBtn.template = this;
            this.titleIndex = 0;
            this.selected = false;
            this.me.visible = false;
            this.me.offAll(Laya.Event.CLICK);
            Laya.Pool.recover("MatrixQuestionBtn", this);
        }

    }

    /** 矩阵 */
    class MatrixQuestion extends QuestionBase {
        private _titles: MatrixQuestionTitle[] = [];
        private _optionTitles: MatrixQuestionOptionTitle[] = [];
        private _btns: MatrixQuestionBtn[][] = [];
        get answerOK() {
            if (!this.data) return false;
            const unselectItems = this._btns.filter(v => v.find(v1 => v1.selected) == null);
            if (this.data.require && unselectItems.length > 0) return false;
            return true;
        }
        get answer() {
            if (!this.data) return this._answer;
            if (!this._answer) this._answer = { question_id: this.data.id, values: [] };
            const values = this._answer.values;
            const { options, matrix_row } = this.data;
            const { matrix_row: originMatrixRow } = this.originData;
            this._btns.forEach((v, index) => {
                const originIndex = originMatrixRow.findIndex(v => matrix_row[index] == v);
                const value = values[originIndex] = values[originIndex] || { value: "", custom_input: "" };
                const selectedIndex = v.findIndex(v => v.selected);
                value.value = selectedIndex > -1 ? options[selectedIndex].value : "";
            });
            return this._answer;
        }
        protected onContructed() {
            new MatrixQuestionTitle(this.parent.getChildByName("title") as Laya.Sprite).recover();
            const optionTitle = new MatrixQuestionOptionTitle(this.parent.getChildByName("option_title") as Laya.Label);
            this.content.parent.addChild(optionTitle.me);
            optionTitle.recover();
            new MatrixQuestionBtn(this.parent.getChildByName("btn") as Laya.Button).recover();
        }

        protected onShow() {
            const { data, originData, _answer, _titles, _optionTitles, _btns } = this;
            const titleMaxCnt = data.matrix_row.length;
            for (let i = 0; i < titleMaxCnt; i++) {
                const titleData = data.matrix_row[i];
                if (titleData) {
                    if (!_titles[i]) _titles.push(MatrixQuestionTitle.create());
                    _titles[i].show(titleData);
                    if (!_btns[i]) _btns.push([]);
                }
            }
            const optionCnt = data.options.length;
            for (let i = 0; i < optionCnt; i++) {
                const optionTitleData = data.options[i];
                if (!_optionTitles[i]) _optionTitles.push(MatrixQuestionOptionTitle.create());
                _optionTitles[i].show(optionTitleData);

                _btns.forEach((btns, index) => {
                    if (!btns[i]) btns.push(MatrixQuestionBtn.create());
                    let selected = false;
                    if (_answer) {
                        const originIndex = originData.matrix_row.findIndex(v => v == data.matrix_row[index]);
                        selected = _answer.values[originIndex].value == optionTitleData.value;
                    }
                    btns[i].show(index, selected);
                    btns[i].onClick(this, this.onBtnClick);
                });
            }

        }

        protected onHide() {
            const recover = (v: MatrixQuestionTitle | MatrixQuestionOptionTitle | MatrixQuestionBtn) => v.recover();
            this._titles.forEach(recover);
            this._optionTitles.forEach(recover);
            this._btns.forEach(v => {
                v.forEach(recover);
                v.length = 0;
            });
            this._titles.length = 0;
            this._optionTitles.length = 0;
            this._btns.length = 0;
        }

        protected rectifyDisplay() {
            super.rectifyDisplay()
            const { data, _titles, _optionTitles, _btns, content, htmlTitle } = this;
            const optionMaxHeight = _optionTitles.reduce(
                (pv, cv) => cv.me.height > pv ? cv.me.height : pv, 0);
            const { y: hy, contextHeight } = htmlTitle;
            const optionTitleY = hy + contextHeight + (contextHeight > 116 ? 24 : 48) + optionMaxHeight;
            content.height = content.y - (optionTitleY + 9);
            let parentHeight = 0;
            _titles.forEach((v, i) => {
                v.me.pos(0, parentHeight);
                _btns[i].forEach(btn => btn.me.y = v.me.y + v.html_title.y + v.html_title.contextHeight / 2);
                parentHeight += v.me.height + 24;
            });
            this.parent.height = parentHeight - 24;

            const screen_rate = content.height / this.parent.height;
            const optionTitleW = data.options.length ? ((screen_rate >= 1 ? 1640 : 1610) - 410) / data.options.length : 200;
            _optionTitles.forEach((v, i) => {
                v.me.width = optionTitleW;
                v.me.pivotY = v.me.height;
                const x = 410 + optionTitleW * i;
                v.me.pos(x, optionTitleY, true);
                _btns.forEach(btns => btns[i].me.x = x + optionTitleW / 2);
            });
        }

        private onBtnClick(btn: MatrixQuestionBtn) {
            if (!btn.selected) {
                this._btns[btn.titleIndex].forEach(v => v.selected = v == btn);
                this.event(Laya.Event.CHANGED);
            }
        }
    }
    class QuestionairContent {
        //#region 
        private _me: Laya.Sprite;
        private _txt_must_answer: Laya.Text;
        private _txt_page_num: Laya.Text;
        private _html_title: Laya.HTMLDivElement;
        private _img_page_pro: Laya.Image;
        private _btn_lastPage: Laya.Button;
        private _btn_nextPage: Laya.Button;

        private _locked: boolean = false;
        private _curIndex: number = 0;
        private _answeredQueue: number[] = [];
        private _curQuestion: QuestionBase;
        private _inputQuestion: InputQuestion;
        private _selectQuestion: SelectQuestion;
        private _maxtrixQuestion: MatrixQuestion;
        private _originQuestions: game.IQuestionnaireQuestion[];
        private _sortedQuestions: game.IQuestionnaireQuestion[];
        answers: game.IReqSubmitQuestionnaire_QuestionnaireAnswer[] = [];
        //#endregion

        private get questions() {
            return QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType).questionDetail.questions;
        }

        static setHtmlText(div: Laya.HTMLDivElement, str: string, fontSize = 48, leading = 10, fontColor = "#80838c", imgWidth = 0, imgHeight = 0, font?: string) {
            div.style.valign = "bottom";
            div.style.fontFamily = font || UI_Mail.font;
            div.style.fontSize = fontSize;
            div.style.color = fontColor;
            div.style.leading = leading;
            if (/<href=(.+?)>/.test(str)) {
                div.mouseEnabled = true;
                div.on(Laya.Event.LINK, this, (url: string) => {
                    url.replace(/&amp;/g, '&');
                    if (!Laya.Browser.onPC) {
                        Laya.Browser.window.location.href = url;
                    } else {
                        game.Tools.open_new_window(url);
                    }
                });
            } else {
                div.mouseEnabled = false;
                div.offAll(Laya.Event.LINK);
            }
            str = str.replace(/&/g, "&amp;")
                .replace(/ /g, "&nbsp;")
                .replace(/\u00A0/g, "&nbsp;")
                .replace(/<b>/g, "[b]")
                .replace(/<\/b>/g, "[/b]")
                .replace(/<color=(#\w+?)>/g, "[color=$1]")
                .replace(/<\/color>/g, "[/color]")
                .replace(/<href=(.+?)>/g, "[color=#51f1ff][url=$1]")
                .replace(/<\/href>/g, "[/url][/color]")
                .replace(/<img&nbsp;src="(.*?)"\/>/g, (subStr, $v: string, pos) => {
                    const url = $v.replace(/&nbsp;/g, " ");
                    // const tex:Laya.Texture = Laya.loader.getRes(url);
                    // if (!tex || !tex.source) return "";
                    // else return `[img]${ url }[/img]`;
                    return `[img]${ url }[/img]`;
                })
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/\n/g, "<br/>")
                .replace(/(<br\/>){2,}/g, subStr => subStr.replace(/>/g, "> ").trim());
            str = UBBParser.Inst.parse(str, imgWidth, imgHeight);
            div.innerHTML = str;
        }

        static loadQuestionTextures(data: game.IQuestionnaireQuestion, cb?: Laya.Handler) {
            //加载完富文本里得图片再显示，不然显示适配有问题
            let str = "";
            str += data.describe;
            str += data.title;
            str += data.matrix_row.join("");
            str += data.options.map(v => v.label).join("");
            this.loadHtmlTextures(str, cb);
        }

        static loadHtmlTextures(htmlStr: string, cb?: Laya.Handler) {
            const textures: string[] = [];
            htmlStr = htmlStr.replace(/<img src="(.*?)"\/>/g, (subStr, $v, pos) => {
                if (textures.indexOf($v) == -1)
                    textures.push($v);
                return `[img]${ $v }[/img]`;
            });
            Laya.loader.load(textures, cb);
        }
        constructor(me: Laya.Sprite) {
            this._me = me;
            me.visible = false;
            this._txt_must_answer = me.getChildByName("must_answer") as Laya.Text;
            this._txt_page_num = me.getChildByName("page_num") as Laya.Text;
            this._html_title = me.getChildByName("title") as Laya.HTMLDivElement;
            this._img_page_pro = me.getChildByName("page_pro") as Laya.Image;
            this._btn_lastPage = me.getChildByName("btn_lastPage") as Laya.Button;
            this._btn_nextPage = me.getChildByName("btn_nextPage") as Laya.Button;

            (me.getChildByName("btn_exit") as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_Activity_Questionair.Inst.close();
            }, null, false);
            this._btn_lastPage.clickHandler = Laya.Handler.create(this, this.showLastQuestion, null, false);
            this._btn_nextPage.clickHandler = Laya.Handler.create(this, this.showNextQuestion, null, false);
            const content = me.getChildByName("content") as Laya.Panel;
            const scrollbar = (me.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'] as capsui.CScrollBar;

            new QuestionairInput(content.getChildAt(0) as Laya.Sprite).recover();
            this._inputQuestion = new InputQuestion(content.getChildByName("input") as Laya.Sprite, this._html_title, content, scrollbar);
            this._selectQuestion = new SelectQuestion(content.getChildByName("select") as Laya.Sprite, this._html_title, content, scrollbar);
            this._maxtrixQuestion = new MatrixQuestion(content.getChildByName("matrix") as Laya.Sprite, this._html_title, content, scrollbar);
            this._inputQuestion.on(Laya.Event.CHANGED, this, this.onAnswerChanged);
            this._selectQuestion.on(Laya.Event.CHANGED, this, this.onAnswerChanged);
            this._maxtrixQuestion.on(Laya.Event.CHANGED, this, this.onAnswerChanged);
            scrollbar.init(new Laya.Handler(this, rate => {
                content.vScrollBar.value = content.vScrollBar.max * rate;
            }));
            content.vScrollBarSkin = '';
            content.vScrollBar.on(Laya.Event.CHANGE, this, () => {
                if (this._curQuestion) {
                    this._curQuestion.onScroll();
                    scrollbar.setVal(content.vScrollBar.value / content.vScrollBar.max, content.height / this._curQuestion.parent.height);
                }
            });
        }

        show() {
            const { questionDetail, sortedQuestions } = QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType);
            this._originQuestions = questionDetail.questions;
            this._sortedQuestions = sortedQuestions;
            this.answers = this.getLocalAnswer();
            this._curIndex = -1;
            this._answeredQueue = this.getLocalAnswerQueue();
            this.showQuestion(this._answeredQueue[this._answeredQueue.length - 1] || 0);
            this._me.visible = true;
        }

        close() {
            this._inputQuestion.close();
            this._selectQuestion.close();
            this._maxtrixQuestion.close();
            this._me.visible = false;
        }

        clear() {
            this._curIndex = 0;
            this._curQuestion = null;
            this._answeredQueue.length = 0;
            this.answers.length = 0;
        }

        getLocalAnswer() {
            const keys = this.getLocalAnswerKeys(GameMgr.client_language);
            const jsonStr = Laya.LocalStorage.getItem(keys[0]);
            const data = jsonStr ? JSON.parse(game.Tools.dddsss(jsonStr)) : null;
            return (data || []) as game.IReqSubmitQuestionnaire_QuestionnaireAnswer[];
        }

        clearLocalAnswer() {
            this.clear();
            const keys = this.getLocalAnswerKeys();
            keys.forEach(v => Laya.LocalStorage.removeItem(v));
        }

        private showLastQuestion() {
            if (this._locked) return;
            if (this._answeredQueue.length <= 1) return;
            this.answers[this._curIndex] = this._curQuestion.answer;
            this._answeredQueue.pop();
            this.showQuestion(this._answeredQueue[this._answeredQueue.length - 1]);
        }

        private showNextQuestion() {
            if (this._locked) return;
            if (!this._curQuestion.answerOK) return;
            this.answers[this._curIndex] = this._curQuestion.answer;
            const jumpIndex = this.getJumpQuestionIndex();
            let index = 0;
            if (jumpIndex != -1) index = jumpIndex;
            else index = this._curIndex + 1;
            if (index < this._originQuestions.length) this.showQuestion(index);
            else {
                this.close();
                UI_Activity_Questionair.Inst.finishedPanel.show();
            }
        }

        private getJumpQuestionIndex() {
            const { _originQuestions: questions, answers } = this;
            const data = questions[this._curIndex];
            if (data.next_question && data.next_question.length > 0) {
                const cnt = data.next_question.length;
                let i = 0, j = 0;
                for (i = 0; i < cnt; i++) {
                    const nextQuest = data.next_question[i];
                    for (j = 0; j < nextQuest.conditions.length; j++) {
                        const conSuccess = nextQuest.conditions[j].conditions.every(condV => {
                            const questIndex = questions.findIndex(qv => qv.id == condV.question_id);
                            if (questIndex > -1) {
                                const questAnswer = answers[questIndex];
                                if (questAnswer) {
                                    if (condV.op == "==") {
                                        return condV.values.every(v => {
                                            return questAnswer.values.find(qav => qav.value == v) != null;
                                        });
                                    } else if (condV.op == "in") {
                                        return condV.values.some(v => {
                                            return questAnswer.values.find(qav => qav.value == v) != null;
                                        });
                                    } else return false;
                                } else return false;
                            } else return false;
                        });
                        if (conSuccess) return questions.findIndex(v => v.id == nextQuest.target_question_id);
                    }
                }
            }
            return -1;
        }

        private showQuestion(index: number) {
            const questions = this._originQuestions;
            const originData = questions[index];
            if (!originData) return;
            this._locked = true;
            QuestionairContent.loadQuestionTextures(originData, Laya.Handler.create(this, () => {
                if (this._answeredQueue.indexOf(index) == -1)
                    this._answeredQueue.push(index);
                this._curIndex = index;
                this.saveLocalAnswerQueue();
                this._txt_must_answer.visible = !!originData.require;
                this._txt_page_num.text = ""; //(index + 1) + "/" + questions.length;
                QuestionairContent.setHtmlText(this._html_title, originData.title + "\n[size=40]" + originData.describe + "[/size]", 48, 10, "#D4CFCF", 535, 300);
                this._img_page_pro.width = (index + 1) / questions.length * 794;
                this._btn_lastPage.alpha = index <= 0 ? 0.5 : 1;
                this._btn_lastPage.mouseEnabled = index > 0;
                if (this._curQuestion) this._curQuestion.close();
                this._curQuestion = this.getQuestion(originData);
                this._curQuestion.show(this._sortedQuestions[index], originData, this.answers[index]);
                this.refreshNextQuestionBtnState();
                (this._btn_nextPage.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc("myres/activity_questionair/" + (index == questions.length - 1 ? "submit.png" : "next_page.png"));
                this._locked = false;
            }));
        }

        private refreshNextQuestionBtnState() {
            const enable = this._curQuestion && this._curQuestion.answerOK;
            this._btn_nextPage.alpha = enable ? 1 : 0.5;
            this._btn_nextPage.mouseEnabled = enable;
        }

        private getQuestion(data: game.IQuestionnaireQuestion) {
            if (data.type == QuestionType.Input) {
                return this._inputQuestion;
            } else if (data.type == QuestionType.Select) {
                if (data.sub_type == QuestionSubType.Matrix)
                    return this._maxtrixQuestion;
                else
                    return this._selectQuestion;
            }
        }

        private onAnswerChanged() {
            this.refreshNextQuestionBtnState();
            Laya.timer.callLater(this, this.saveLocalAnswer);
        }

        private saveLocalAnswer() {
            this.answers[this._curIndex] = this._curQuestion.answer;
            const answers = this.answers.map(v => {
                return v && v.values.length > 0 && v.values.some(vv => vv.value || vv.custom_input) ? v : null;
            });
            if (!answers.length) return;
            const keys = this.getLocalAnswerKeys(GameMgr.client_language);
            const jsonStr = JSON.stringify(answers);
            Laya.LocalStorage.setItem(keys[0], game.Tools.eeesss(jsonStr));
        }

        private getLocalAnswerKeys(language?: string) {
            let result: string[];
            const questionairId = QuestionairData.getData(UI_Activity_Questionair.Inst.questionairType).questionDetail.id;
            if (language) {
                result = [["questionair", GameMgr.Inst.account_id, language, questionairId].join("_")];
            } else {
                result = [
                    ["questionair", GameMgr.Inst.account_id, "chs", questionairId].join("_"),
                    ["questionair", GameMgr.Inst.account_id, "chs_t", questionairId].join("_"),
                    ["questionair", GameMgr.Inst.account_id, "en", questionairId].join("_"),
                    ["questionair", GameMgr.Inst.account_id, "jp", questionairId].join("_"),
                    ["questionair", GameMgr.Inst.account_id, "kr", questionairId].join("_"),
                ];
            }
            result.forEach((v, i) => result[i] = game.Tools.eeesss(v));
            return result;
        }

        private getLocalAnswerQueue() {
            const keys = this.getLocalAnswerQueueKeys(GameMgr.client_language);
            const jsonStr = Laya.LocalStorage.getItem(keys[0]);
            return (jsonStr ? JSON.parse(game.Tools.dddsss(jsonStr)) : []) as number[];
        }

        private saveLocalAnswerQueue() {
            const keys = this.getLocalAnswerQueueKeys(GameMgr.client_language);
            const jsonStr = JSON.stringify(this._answeredQueue);
            Laya.LocalStorage.setItem(keys[0], game.Tools.eeesss(jsonStr));
        }

        private getLocalAnswerQueueKeys(language?: string) {
            const answerKeys = this.getLocalAnswerKeys(language);
            return answerKeys.map(v => v + game.Tools.eeesss("_queue"));
        }
    }
    export class UI_Activity_Questionair extends UIBase {
        static readonly TempUITag = "UI_Activity_Questionair";

        static Inst: UI_Activity_Questionair;
        private _label_title: Laya.Label;
        startPanel: QuestionairStart;
        finishedPanel: QuestionairFinished;
        contentPanel: QuestionairContent;

        questionairType: QuestionairType;

        constructor() {
            super(new ui.lobby.activitys.activity_questionairUI());
            UI_Activity_Questionair.Inst = this;
        }

        onCreate() {
            this._label_title = this.me.getChildByName("title") as Laya.Label;
            this.startPanel = new QuestionairStart(this.me.getChildByName("start") as Laya.Sprite);
            this.finishedPanel = new QuestionairFinished(this.me.getChildByName("finished") as Laya.Sprite);
            this.contentPanel = new QuestionairContent(this.me.getChildByName("content") as Laya.Sprite);
        }

        onEnable() {
            game.TempImageMgr.setUIEnable(UI_Activity_Questionair.TempUITag, true);
            game.LoadMgr.setImgSkin(this.me.getChildByName('bg') as Laya.Image, 'myres/activity_questionair/bg2.jpg', null, UI_Activity_Questionair.TempUITag);
        }

        onDisable() {
            game.TempImageMgr.setUIEnable(UI_Activity_Questionair.TempUITag, false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_questionair.atlas'));
        }

        show(type: QuestionairType) {
            this.questionairType = type;
            QuestionairData.recordTime(type, true);
            this._label_title.text = QuestionairData.getData(type).questionDetail.title;
            this.startPanel.show();
            this.enable = true;
        }

        close() {
            this.startPanel.close();
            this.finishedPanel.close();
            this.contentPanel.close();
            this.contentPanel.clear();
            this.enable = false;
            UI_Lobby.Inst.enable = true;
        }

        finished() {
            QuestionairData.finished(this.questionairType);
            this.close();
        }
    }
}