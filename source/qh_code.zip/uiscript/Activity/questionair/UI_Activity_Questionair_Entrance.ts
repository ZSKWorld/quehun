/**
* 纯入口用，每次替换图片，活动id和按钮事件，并替换图片
*/
module uiscript {
    class RewardItem {
        me: Laya.Button;
        uiCopy: capsui.UICopy;
        private _img_icon: Laya.Image;
        private _itemRect: UIRect;
        private _label_count: Laya.Label;
        private _itemData: game.IQuestionnaireReward;

        constructor(me: Laya.Button) {
            this.me = me;
            this.uiCopy = me.scriptMap["capsui.UICopy"];
            this._img_icon = me.getChildByName("icon") as Laya.Image;
            this._label_count = me.getChildByName("item_count") as Laya.Label;
            me.clickHandler = Laya.Handler.create(this, this.onItemClick, null, false);
        }

        refresh(index: number, data: game.IQuestionnaireReward) {
            this._itemData = data;
            this.me.visible = !!data;
            if (data) {
                if (this._itemRect == null) {
                    this._itemRect = UIRect.CreateFromSprite(this._img_icon);
                }
                game.Tools.setItemIcon(this._img_icon, this._itemRect, data.resource_id, UI_Activity_Questionair.TempUITag, true);
                this._label_count.text = data.count.toString();
                this.me.x = 122 * index + 58;
            }
        }

        clone() {
            const ui = this.uiCopy.getNodeClone() as Laya.Button;
            return new RewardItem(ui);
        }

        private onItemClick() {
            UI_ItemDetail.Inst.show(this._itemData.resource_id);
        }
    }
    export class UI_Activity_Questionair_Entrance extends UI_ActivityBase {
        private _label_time: Laya.Label;
        private _btn_btn: Laya.Button;
        private _img_bg: Laya.Image;
        private _rewardItems: RewardItem[] = [];
        protected readonly activityId: number = 5;
        protected readonly questionairType: QuestionairType = QuestionairType.Questionair;

        get activity_name() {
            const { questionair } = QuestionairData.getData(this.questionairType);
            return questionair ? questionair.banner_title : "";
        }
        //左边标题的名称
        constructor(activityId: number, questionairType: QuestionairType) {
            super('', new ui.lobby.activitys.activity_questionair_entranceUI());
            this.activityId = activityId;
            this.questionairType = questionairType;
        }

        getId() { return this.activityId; }

        //活动是否开放中，不开放的活动不会显示
        isopen() {
            const { finishedList, questionair } = QuestionairData.getData(this.questionairType);
            const timestamp = Math.floor(game.Tools.getServerTime() / 1000);
            const valid = questionair ? timestamp >= questionair.effective_time_start && timestamp <= questionair.effective_time_end : false;
            const finished = valid && questionair ? finishedList.indexOf(questionair.id) > -1 : true;
            return !finished;
        }

        //活动是否要显示小红点
        haveRedPoint() {
            const { finishedList, questionair, questionDetail } = QuestionairData.getData(this.questionairType);
            const finished = questionair ? finishedList.indexOf(questionair.id) > -1 : true;
            const reddot = questionair ? Laya.LocalStorage.getItem(game.Tools.eeesss('questionair_' + GameMgr.Inst.account_id + "_" + questionair.id)) : "";
            return questionDetail && !finished && !reddot;
        }

        //活动是否要弹出来
        need_popout() {
            return true;
        }

        onCreate() {
            this._label_time = this.me.getChildByName("time") as Laya.Label;
            this._label_time.color = ['', '#bde9ff', '#e3a5bd', '#fdf4c8'][this.questionairType] || '#bde9ff';
            this._btn_btn = this.me.getChildByName('btn') as Laya.Button;
            this._img_bg = this.me.getChildByName('head') as Laya.Image;
            this._btn_btn.clickHandler = new Laya.Handler(this, () => {
                const { finishedList, questionair, questionDetail } = QuestionairData.getData(this.questionairType);
                const finished = questionair ? finishedList.indexOf(questionair.id) > -1 : true;
                if (this.isopen() && questionDetail && !finished) {
                    if (UI_PiPeiYuYue.Inst.enable) {
                        UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                        return;
                    }
                    if (UI_Lobby.Inst.locking) return;
                    // if (!UI_Activity.activity_is_running(UI_Activity_Questionair_Entrance.activity_id)) {
                    //     UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3944));
                    //     return;
                    // }
                    UI_Activity.Inst.close();
                    UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                        UI_Activity_Questionair.Inst.show(this.questionairType);
                    }));
                }
            });
            this._rewardItems.push(new RewardItem(this.me.getChildByName("rewards").getChildByName("item") as Laya.Button));
        }

        show() {
            const bgSkin = "myres/activity_questionair/" + (["entry_bg1.jpg", "entry_bg2.jpg", "entry_bg3.jpg"][this.activityId - 5]);
            game.LoadMgr.setImgSkin(this._img_bg, bgSkin);
            if (!QuestionairData.getData(this.questionairType).questionDetail) {
                QuestionairData.fetchDetail(this.questionairType, this, this.show2);
            } else this.show2();
        }

        hide() {
            this.enable = false;
        }

        onEnable() {
            game.TempImageMgr.setUIEnable(UI_Activity_Questionair.TempUITag, true);
        }

        onDisable() {
            game.TempImageMgr.setUIEnable(UI_Activity_Questionair.TempUITag, false);
        }

        private show2() {
            const { finishedList, questionair } = QuestionairData.getData(this.questionairType);
            const rewards = questionair ? questionair.rewards : [];
            const maxCnt = Math.max(rewards.length, this._rewardItems.length);
            for (let i = 0; i < maxCnt; i++) {
                const reward = rewards[i];
                let item = this._rewardItems[i];
                if (reward && !item) {
                    item = this._rewardItems[0].clone();
                    this._rewardItems.push(item);
                }
                if (item) item.refresh(i, reward);
            }
            const date = new Date(questionair ? questionair.effective_time_start * 1000 : 0);
            const startTimeStr = [date.getFullYear(), date.getMonth() + 1, date.getDate()].map((v, i) => v.toString().padStart(i == 0 ? 4 : 2, "0")).join(".");
            date.setTime(questionair ? questionair.effective_time_end * 1000 : 0);
            const endTimeStr = [date.getFullYear(), date.getMonth() + 1, date.getDate()].map((v, i) => v.toString().padStart(i == 0 ? 4 : 2, "0")).join(".");
            this._label_time.text = startTimeStr + " - " + endTimeStr + game.Tools.strOfLocalization(20128);
            const finished = questionair ? finishedList.indexOf(questionair.id) > -1 : true;
            this._btn_btn.skin = game.Tools.localUISrc("myres/activity_questionair/" + (finished ? "btn_finished.png" : this.getBtnJoinSkin()));
            if (questionair) {
                Laya.LocalStorage.setItem(game.Tools.eeesss('questionair_' + GameMgr.Inst.account_id + "_" + questionair.id), "1");
            }
            this.enable = true;
        }

        private getBtnJoinSkin() {
            let client_language = GameMgr.client_language;
            if (client_language == "kr" || client_language == "jp") {
                if (this.questionairType == QuestionairType.SignUpOfficalTournament) {
                    return "btn_join2.png";
                }
            }
            return "btn_join1.png";
        }
    }
}