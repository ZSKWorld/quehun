/**
* 24ba主活动
*/
module uiscript {


    export interface Activity_2408_Spot_BuildingConfig {
        buildingId: number;
        buildingName: number;
        storys: Array<StoryConfig>;
        unlockDay: number;
        buildingUnlock: number;
        storyDesc: number;
        buildingRewards: Array<number>;
    }

    interface StoryConfig {
        storyId: number;
        storyName: number;
        buildingId: number;
        endingIds: Array<EndingConfig>;
    }

    interface EndingConfig {
        endingId: number;
        reward: number;
        storyId: number;
    }

    enum ESpotBuildingState { locked, timeLimited, canUnlock, unlock, timeLimitedAndLock };
    class ItemBuilding {
        private me: Laya.Sprite
        private icon: Laya.Image;
        private name: Laya.Label;
        private bgName: Laya.Image;
        private lock: Laya.Sprite;
        private unlock: Laya.Sprite;

        private tip: Laya.Sprite; // 剧情解锁和完成几个都在这下面
        private points: Laya.Sprite;
        private listPoint: Array<Laya.Sprite>;
        private labelLockTime: Laya.Label;
        private tipBg: Laya.Image;

        private btn: Laya.Button;

        private index: number;
        private father: UI_Activity_2408_Spot;
        private data: lqc.Sheet_Activity_SummerStory;
        private state: ESpotBuildingState = ESpotBuildingState.locked;
        private bgAdapter: common.SpriteAdapter;

        constructor(me: Laya.Sprite, index: number, father: UI_Activity_2408_Spot) {
            this.me = me;
            this.icon = this.me.getChildByName('building') as Laya.Image;
            this.name = this.me.getChildByName('state').getChildByName('name') as Laya.Label;
            if (GameMgr.client_language == "en" || GameMgr.client_language == "kr" || GameMgr.client_language == "jp") {
                this.name.width = 250;
                this.name.scaleX = 0.7;
                this.name.scaleY = 0.7;
            }
            // if (GameMgr.client_language == "chs_t") {
            //     this.name.width = 210;
            //     this.name.scaleX = 0.9;
            //     this.name.scaleY = 0.9;
            // }

            this.bgName = this.me.getChildByName('state').getChildByName('bg') as Laya.Image;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.unlock = this.me.getChildByName('unlock') as Laya.Sprite;
            this.tip = this.me.getChildByName('tip') as Laya.Sprite;
            this.tipBg = this.tip.getChildByName('bg') as Laya.Image;
            this.points = this.tip.getChildByName('points') as Laya.Sprite;
            this.listPoint = [];
            for (let i = 0; i < 3; i++) {
                this.listPoint.push(this.points.getChildByName(i.toString()).getChildByName('point') as Laya.Sprite);
            }
            this.labelLockTime = this.tip.getChildByName('lock') as Laya.Label;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.index = index;
            this.father = father;
            this.data = UI_Activity_2408_Spot.getStoryData('building', index + 1);
            this.name.text = game.Tools.eventStrOfLocalization(this.data.building_name);

            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (this.father.isLock) return;
                if (this.state == ESpotBuildingState.timeLimited || this.state == ESpotBuildingState.timeLimitedAndLock) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4469));
                    // this.doUnlockAnim();
                    return;
                }
                UI_Activity_2408_Spot_Building.Inst.show(this.index + 1);
            });
            this.bgAdapter = new common.SpriteAdapter(this.tipBg, this.labelLockTime, SpriteAdapterType.WIDTH2WIDTH, -84);
            // this.bgAdapter.fresh();

        }

        public show() {
            if (this.data.building_unlock) {
                if (UI_Bag.get_item_count(this.data.building_unlock) > 0) {
                    //建筑已解锁
                    this.state = ESpotBuildingState.unlock;
                    this.tipBg.width = 204
                }
                else {
                    let restSeconds = UI_Activity_2408_Spot.getBuildingUnlockSeconds(UI_Activity_2408_Spot.activityId, this.data.building);
                    if (restSeconds > 0) {

                        //如果上一个建筑没到达解锁时间，不显示时间
                        let lastBuildingId = 0;
                        let sortIndex = UI_Activity_2408_Spot.Inst.unlockBuildingSort.findIndex((v) => {
                            return v == this.data.building;
                        });
                        if (sortIndex > 0) {
                            lastBuildingId = UI_Activity_2408_Spot.Inst.unlockBuildingSort[sortIndex - 1];
                        }
                        let needShowTime = true;
                        if (lastBuildingId > 0) {
                            let lastBuildingUnlockTime = UI_Activity_2408_Spot.getBuildingUnlockSeconds(UI_Activity_2408_Spot.activityId, lastBuildingId);
                            needShowTime = lastBuildingUnlockTime <= 0;
                        }
                        if (!needShowTime) {
                            this.state = ESpotBuildingState.timeLimitedAndLock;
                            this.labelLockTime.text = game.Tools.strOfLocalization(4468);
                            // this.btn.mouseEnabled = false;
                        } else {
                            this.state = ESpotBuildingState.timeLimited;
                            this.labelLockTime.text = UI_Activity.getLockTimeText(restSeconds);
                            // this.btn.mouseEnabled = true;
                        }
                        this.bgAdapter.fresh();

                    } else {
                        this.btn.mouseEnabled = true;
                        //是否持有解锁道具
                        if (UI_Bag.get_item_count(UI_Activity_2408_Spot.unlockItemId) > 0) {
                            this.state = ESpotBuildingState.canUnlock;
                        } else {
                            this.state = ESpotBuildingState.locked;
                        }
                        
                    }

                }
            }


            switch (this.state) {
                case ESpotBuildingState.locked:
                    this.showLocked();
                    break;
                case ESpotBuildingState.timeLimited:
                    this.showTimeLimited();
                    break;
                case ESpotBuildingState.canUnlock:
                    this.showCanUnlock();
                    break;
                case ESpotBuildingState.unlock:
                    this.showUnlock();
                    this.freshPointData();
                    break;
                case ESpotBuildingState.timeLimitedAndLock:
                    this.showTimeLimited();
                    break;
                default:
                    break;
            }
        }

        public unlockBuilding() {
            this.state = ESpotBuildingState.unlock;
            this.showUnlock();
        }

        public showUnlock() {
            this.lock.visible = false;
            this.unlock.visible = false;
            this.tip.visible = true;
            this.bgName.skin = game.Tools.localUISrc('myres/activity_2408_spot/architectural_name_unlocking_bottom_2.png');
            this.labelLockTime.visible = false;
            this.points.visible = true;
            // 如果已解锁，判定显示点数，判断哪个完成了
            // this.freshPointData();
        }

        private freshPointData() {
            let storyIds = this.data.story_id.split(',');
            for (let i = 0; i < storyIds.length; ++i) {
                let storyData: game.IUnlockedStoryData = UI_Activity_2408_Spot.getUnlockedStory(Number(storyIds[i]));
                this.listPoint[i].visible = !!(storyData && storyData.finish_rewarded);
            }
        }

        private showPoint(count: number) {
            for (let i = 0; i < this.listPoint.length; i++) {
                // this.listPoint[i].visible = true;
                let point = this.listPoint[i];
                point.visible = i < count;
            }
        }

        public showLocked() {
            this.bgName.skin = game.Tools.localUISrc('myres/activity_2408_spot/architectural_name_unlocking_bottom_1.png');
            this.lock.visible = true;
            this.tip.visible = false;
            this.unlock.visible = false;
        }

        public showTimeLimited() {
            this.bgName.skin = game.Tools.localUISrc('myres/activity_2408_spot/architectural_name_unlocking_bottom_1.png');
            this.unlock.visible = false;
            this.lock.visible = true;
            this.tip.visible = true;
            this.points.visible = false;
            this.labelLockTime.visible = true;
        }

        public showCanUnlock() {
            this.bgName.skin = game.Tools.localUISrc('myres/activity_2408_spot/architectural_name_unlocking_bottom_1.png');
            this.lock.visible = true;
            this.tip.visible = false;
            this.unlock.visible = UI_Bag.get_item_count(UI_Activity_2408_Spot.unlockItemId) > 0;
        }

        private lockScale: number = 0.97;
        private lightScale: number = 1;
        private lockPos: Laya.Point = new Laya.Point(-124, 1);
        private lightPos: Laya.Point = new Laya.Point(-8, -4);

        public doUnlockAnim() {
            this.showPoint(0);
            //生成解锁特效
            let lockEffect = game.FrontEffect.Inst.create_ui_effect(this.bgName, 'scene/fx_ui_zhuyun_03.lh', this.lockPos, this.lockScale);
            lockEffect.enableFollowTarget = true;
            
            Laya.timer.once(300, this, () => { 
                this.lock.visible = false;
            })
            Laya.timer.once(500, this, () => {
                lockEffect.destory();
                //解锁特效播放完毕后生成闪光特效，闪光特效播一半，展示解锁状态
                let unlockEffect = game.FrontEffect.Inst.create_ui_effect(this.bgName, 'scene/fx_ui_zhuyun_04.lh', this.lightPos, this.lockScale);
                unlockEffect.enableFollowTarget = true;
                Laya.timer.once(500, this, () => {
                   
                    this.unlockBuilding();
                });
                Laya.timer.once(2500, this, () => {
                    unlockEffect.destory();
                });

            });

        }

        private pointScale = 1;
        private pointPos: Laya.Point = new Laya.Point(24, 24)
        /**
         * 绿点的弹出动画
         * @param index 
         */
        public doCompleteAnim(index, onComplete: Laya.Handler = null) {
            let point = this.listPoint[index];
            point.visible = false;
            let effect = game.FrontEffect.Inst.create_ui_effect(point.parent as Laya.Sprite, 'scene/fx_ui_zhuyun_02.lh', this.pointPos, this.pointScale);
            effect.enableFollowTarget = true;
            Laya.timer.once(600, this, () => {
                point.visible = true;
                effect.destory();
                onComplete?.run();
            });
            // console.log("展示剧情解锁动画",this.data.building,index);
            
        }
    }

    class ItemSpotReward {
        public me: Laya.Sprite;
        private icon: Laya.Image;
        private light: Laya.Image;
        private bgName: Laya.Image;
        private labelName: Laya.Label;
        private count: Laya.Sprite;
        private labelCount: Laya.Label;
        private received: Laya.Sprite;
        private locked: Laya.Sprite;
        private buildingIcon: Laya.Image;
        private rect: UIRect;
        private data: lqc.Sheet_Activity_PeriodTask;
        private rewardData: lqc.Sheet_Activity_SummerStoryReward;
        private itemId: number;
        private father: UI_Activity_2408_Spot;
        private btn: Laya.Button;
        private onClickTimeLimitHandler: Laya.Handler;
        private onClickDisCompleteHandler: Laya.Handler;
        private onClickCompleteHandler: Laya.Handler;
        private onClickGetHandler: Laya.Handler;

        private static labelColorLight: string = '#fff7d7'; // 可领取
        private static labelColorDark: string = '#96674d'; // 不可领取
        private static bgLight: string = 'myres/activity_2408_spot/board_text_bottom_2.png';
        private static bgDark: string = 'myres/activity_2408_spot/board_text_bottom_1.png';
        constructor(me: Laya.Sprite, data: lqc.Sheet_Activity_PeriodTask, father: UI_Activity_2408_Spot) {
            this.me = me;
            this.data = data;
            this.rewardData = cfg.activity.summer_story_reward.getGroup(UI_Activity_2408_Spot.activityId).find((v) => {
                return v.period_task_id == this.data.id;
            });
            this.received = this.me.getChildByName('received') as Laya.Sprite;
            this.locked = this.me.getChildByName('locked') as Laya.Sprite;
            this.light = this.me.getChildByName('light') as Laya.Image;
            this.bgName = this.me.getChildByName('bg_name') as Laya.Image;
            this.labelName = this.me.getChildByName('name') as Laya.Label;
            this.count = this.me.getChildByName('count') as Laya.Sprite;
            this.labelCount = this.count.getChildByName('count') as Laya.Label;
            this.father = father;
            this.icon = this.me.getChildByName('icon') as Laya.Image;
            this.rect = UIRect.CreateFromSprite(this.icon);
            this.buildingIcon = this.me.getChildByName('building_icon') as Laya.Image;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.onClickTimeLimitHandler = new Laya.Handler(this, () => {
                this.onClickTimeLimit();
            });
            this.onClickDisCompleteHandler = new Laya.Handler(this, () => {
                this.onClickDisComplete();
            });
            this.onClickCompleteHandler = new Laya.Handler(this, () => {
                this.onClickComplete();
            });
            this.onClickGetHandler = new Laya.Handler(this, () => {
                this.onClickGet();
            });

        }

        public show() {
            let _info: object = UI_Activity.getPeriodTaskInfo(this.data.id);
            let rewardInfo: Array<string> = this.data.reward.split('-');
            this.labelCount.text = rewardInfo[1];
            let itemId: number = Number(rewardInfo[0]);
            this.itemId = itemId;
            let baseTaskConfig = common.ConfigHelper.getPeriodTaskTarget(this.data.id);
            let language = common.ConfigHelper.getDescLangugeName();

            this.labelName.text = baseTaskConfig[language];
            this.buildingIcon.skin = game.Tools.localUISrc('myres/activity_2408_spot/build_icon_' + this.rewardData.building_icon + '.png');
            game.Tools.setItemIcon(this.icon, this.rect, itemId, 'UI_Activity_2048_Spot', true)
            //是否到达领取时间，如果没到，则显示锁
            let dayLimit = this.data.reward_limit_day;
            let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_2408_Spot.rewardActivityId);
            let restSeconds = dayLimit * 24 * 60 * 60 - activityDeltaSeconds;
            this.locked.visible = restSeconds > 0;
            this.received.visible = _info && _info['rewarded'];
            this.light.visible = _info && _info['achieved'] && !_info['rewarded'];
            if (restSeconds > 0) {
                //时间没到       
                this.bgName.skin = game.Tools.localUISrc(ItemSpotReward.bgDark);
                this.labelName.color = ItemSpotReward.labelColorLight;
                this.btn.clickHandler = this.onClickTimeLimitHandler

            } else if (!_info || !_info['achieved']) {
                // 时间到了未完成
                this.bgName.skin = game.Tools.localUISrc(ItemSpotReward.bgDark);
                this.labelName.color = ItemSpotReward.labelColorLight;
                this.btn.clickHandler = this.onClickDisCompleteHandler;
            } else if (_info['rewarded']) {
                // 已领取
                this.bgName.skin = game.Tools.localUISrc(ItemSpotReward.bgDark);
                this.labelName.color = ItemSpotReward.labelColorLight;
                this.btn.clickHandler = this.onClickCompleteHandler;
            } else {
                // 可领取
                this.bgName.skin = game.Tools.localUISrc(ItemSpotReward.bgLight);
                this.labelName.color = ItemSpotReward.labelColorDark;
                this.btn.clickHandler = this.onClickGetHandler;
            }

        }

        private onClickTimeLimit() {
            if (this.father.isLock) return;
            if (!this.itemId) return;

            UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4469));

        }

        private onClickDisComplete() {
            if (this.father.isLock) return;
            if (!this.itemId) return;

            UI_Info_Small.Inst.show(game.Tools.eventStrOfLocalization(this.rewardData.click_notice));
        }

        private onClickComplete() {
            if (this.father.isLock) return;
            if (!this.itemId) return;
            UI_ItemDetail.Inst.show(this.itemId);
        }

        private onClickGet() {
            if (this.father.isLock) return;
            if (!this.itemId) return;
            this.father.onSingleRewardBtnClick(this.data.id, new Laya.Handler(this, () => { 
                // this.showGetAnim();
            }));
        }




    }

    class Page_Cg_View extends UI_Component {
        private cg: Laya.Image;
        private closeBtn: Laya.Button;
        private onCloseHandler: Laya.Handler;
        private isLock: boolean = false;
        public onCreate(): void {
            this.cg = this.me.getChildByName("cg") as Laya.Image;
            this.closeBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
               
                this.hide();
                
            });
        }

        public show() {
            this.isLock = true;
            //显示动画，aplha从0到1,0.3s
            this.visible = true;
            this.me.alpha = 0;
            Laya.Tween.to(this.me, { alpha: 1 }, 300, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                this.isLock = false;
            }));
            
        }

        public hide() {
            if (this.isLock) {
                return;
            }
            this.visible = false;
            this.onCloseHandler?.run();
        }

        public set cgPath(value: string) {
            game.LoadMgr.setImgSkin(this.cg, value, null, "UI_Activity_2408_Spot");

        }

        public set onClose(handler: Laya.Handler) {
            this.onCloseHandler = handler;
        }




    }

    export class UI_Activity_2408_Spot extends UIBase {
        public static Inst: UI_Activity_2408_Spot = null;
        public static activityId: number = 240811;
        /**
         * 领取奖励的活动Id
         */
        public static rewardActivityId: number = 240812;
        /**
         * 使用道具解锁建筑的活动id
         */
        public static exchangeActivityId: number = 240814;
        /**
         * 用于解锁建筑的道具
         */
        public static unlockItemId: number = 309036;
        public static middleSpotId: number = 24081101;
        public static endSpotId: number = 24081102;
        public static cg1TaskId: number = 24081501;
        public static cg2TaskId: number = 24081502;
        public static cg1ItemId: number = 307458;
        public static cg2ItemId: number = 307459;

        public static get collectItems(): Array<number> {
            let list = [];
            let data = game.ActivityStoryDataHelper.getGroupData(this.activityId);
            for (let unlockStory of data.datas) {
                if (unlockStory.rewarded_ending) {
                    for (let index = 0; index < unlockStory.rewarded_ending.length; index++) {
                        list.push(unlockStory.rewarded_ending[index]);
                    }
                }
            }
            return list;
        };

        public static getUnlockedStory(storyId: number): game.IUnlockedStoryData {
            return game.ActivityStoryDataHelper.getStoryData(this.activityId, storyId);
        }

        public static getUnlockedStorys(): game.IUnlockedStoryData[] {
            return game.ActivityStoryDataHelper.getGroupData(this.activityId).datas;
        }

        // 通过key获取对应数据
        public static getStoryData(key: string, value: number): lqc.Sheet_Activity_SummerStory {
            let datas = cfg.activity.summer_story.getGroup(this.activityId);
            for (let data of datas) {
                if (data[key] == value) {
                    return data;
                }
            }
            return null;
        }

        public static getStoryActivityData(storyId: number): lqc.Sheet_Activity_StoryActivity {
            let datas = cfg.activity.story_activity.getGroup(this.activityId);
            for (let data of datas) {
                if (data.story_id == storyId) {
                    return data;
                }
            }
            return null;
        }

        /**
         * 对应建筑是否解锁，1宗祠，2商社，3茶楼，4拍卖行
         * @param buildingId 
         * @returns 
         */
        public static isBuildingUnlock(buildingId: number): boolean {
            let datas = cfg.activity.summer_story.getGroup(this.activityId);
            for (let data of datas) {
                if (data.building == buildingId) {
                    if (UI_Bag.get_item_count(data.building_unlock) > 0) {
                        return true;
                    }
                }
            }
            return false;
        }

        /**
         * 获取建筑解锁剩余时间
         * @param buildingId 
         * @returns 
         */
        public static getBuildingUnlockSeconds(activityId: number, buildingId: number): number {
            //在summer_story表中找到对应的建筑
            let buildingConfig = cfg.activity.summer_story.getGroup(activityId).find((v) => {
                return v.building == buildingId;
            });
            if (!buildingConfig) {
                return 0;
            }

            //根据建筑的第一个剧情查找对应的story_activity表中的数据
            let storyId = common.ConfigHelper.configString2Array<number>(buildingConfig.story_id)[0][0];
            let storyData = cfg.activity.story_activity.getGroup(activityId).find((v) => {
                return v.story_id == storyId;
            });
            if (!storyData) {
                return 0;
            }
            //获取解锁时间
            let timeLimit = storyData.unlock_day;
            let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_2408_Spot.activityId);
            let restSeconds = timeLimit * 24 * 60 * 60 - activityDeltaSeconds;
            return restSeconds;
        }

        /**
         * 
         * @returns 是否所有剧情已经阅读完毕
         */
        public static isSpotAllRead(): boolean {
            let groups = game.ActivityStoryDataHelper.getGroupData(this.activityId);
            if (groups) {
                for (let data of groups.datas) {
                    if (!data.finished_ending || data.finished_ending.length == 0) {
                        return false;
                    }
                }
            }

            return true;
        }

        /**
         * 当前分支结局是否已经达成
         * @param storyId 
         * @param endingId 
         * @returns 
         */
        public static isSpotEndingRead(storyId: number, endingId: number): boolean {
            let groups = game.ActivityStoryDataHelper.getGroupData(this.activityId);
            if (groups) {
                for (let data of groups.datas) {
                    if (data.story_id == storyId) {
                        return data.finished_ending.indexOf(endingId) >= 0;
                    }
                }
            }

            return false;
        }


        /**
         * 是否全收集道具
         */
        public static isSpotAllReward(): boolean {
            return this.collectItems.length == this.collectItemsId.length;
        }


        /**
         * 指定剧情是否已经阅读
         * @param storyId 
         * @returns 
         */
        public static isSpotRead(storyId: number): boolean {
            let info = UI_Activity_2408_Spot.getUnlockedStory(storyId);
            if (info && info.finish_rewarded > 0) {
                return true;
            }
            return false;
        }

        /**
         * 指定剧情是否全结局达成
         * @param storyId 
         * @returns 
         */
        public static isSpotComplate(storyId: number): boolean {
            let info = UI_Activity_2408_Spot.getUnlockedStory(storyId);
            if (info && info.all_finish_rewarded > 0) {
                return true;
            }
            return false;
        }

        /**
         * 指定剧情是否可解锁
         * @param storyId 
         * @returns 
         */
        public static isSpotCanUnlock(storyId: number): boolean {
            let data = UI_Activity_2408_Spot.getStoryActivityData(storyId);

            //如果有前置剧情，需要前置剧情已完成
            if (data.unlock_story) {
                let info = UI_Activity_2408_Spot.getUnlockedStory(Number(data.unlock_story));
                if (!info) {
                    // console.log("前置剧情未解锁",storyId, data.unlock_story);

                    return false;
                }
                if (!info.finish_rewarded || info.finish_rewarded == 0) {
                    // console.log("前置剧情未解锁", storyId,data.unlock_story);
                    return false;
                }
            }
            //如果有解锁时间，需要到时间
            if (data.unlock_day) {
                let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_2408_Spot.activityId);
                let restSeconds = data.unlock_day * 24 * 60 * 60 - activityDeltaSeconds;
                if (restSeconds > 0) {
                    // console.log("剧情未到解锁时间",storyId, data.unlock_day);

                    return false;
                }
            }
            //如果有解锁道具，需要有道具
            if (data.unlock_item) {
                let items = common.ConfigHelper.configString2Array<number>(data.unlock_item);
                for (let item of items) {
                    if (UI_Bag.get_item_count(item[0]) < item[1]) {
                        // console.log("道具未充足", storyId, item[0], item[1], UI_Bag.get_item_count(item[0]));
                        return false;
                    }
                }

            }
            return true;
        }

        /**
         * 是否建筑的所有剧情已经阅读完毕
         * @param buildingId 
         * @returns 
         */
        public static isBuildingComplete(buildingId: number): boolean {
            let buildingConfig = cfg.activity.summer_story.getGroup(this.activityId).find((v) => {
                return v.building == buildingId;
            });
            if (!buildingConfig) {
                return false;
            }
            let storys = common.ConfigHelper.configString2Array<number>(buildingConfig.story_id);
            for (let story of storys) {
                let storyId = story[0];
                let storyData = this.getUnlockedStory(storyId);
                if (!storyData || !storyData.finish_rewarded) {
                    return false;
                }
            }
            return true;
        }

        /**
         * 获取当前活动的可收集物品
         */
        public static collectItemsId: Array<number> = [
            30900046,
            30900047,
            30900049,
            30900048,
            30900051,
            30900050,
            30900052,
            30900053
        ];


        /**
         * 是否收集了某个道具
         * @param itemId 
         * @returns 
         */
        public static isCollectItem(itemId: number): boolean {
            //背包里是否有该道具
            return UI_Bag.get_item_count(itemId) > 0;
        }

        /**
         * 指定剧情的某个结局是否已经解锁
         * @param storyId 
         * @param endingId 
         * @returns 
         */
        public static isStoryEndingUnlocked(storyId: number, endingId: number): boolean {
            let storyData = this.getUnlockedStory(storyId);
            if (storyData) {
                return storyData.finished_ending.indexOf(endingId) >= 0;
            }
            return false;

        }

        /**
         * 用于解锁建筑的item的数量
         */
        public static get unlockItemCount(): number {
            return UI_Bag.get_item_count(this.unlockItemId);
        }




        private bg: Laya.Image;
        private listBuilding: Array<ItemBuilding>;
        private labelCount: Laya.Label;
        private countAdapt: common.SpriteAdapter;
        private panelReward: Laya.Panel;
        private listRewards: Array<ItemSpotReward>;
        private rewardTasks: lqc.Sheet_Activity_PeriodTask[];
        private rewardPerWidth: number = 190;
        private noteBtn: Laya.Button;
        private getAllBtn: Laya.Button;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private animLocks: Array<Laya.FrameAnimation> = [];
        private pages: Laya.Sprite;
        private noteRedPoint: Laya.Sprite;
        /**
         * 解锁建筑的顺序
         */
        public unlockBuildingSort: Array<number>;
        public isLock: boolean;

        private exchangeItemHandler: Laya.Handler;
        public buildingsConfig: basic.Dictionary<number, Activity_2408_Spot_BuildingConfig> = new basic.Dictionary<number, Activity_2408_Spot_BuildingConfig>();
        /**
         * 当前还未展示的建筑解锁动画
         */
        private unlockAnimBuilding: Array<number> = [];
        /**
         * 当前还未展示的剧情解锁动画，key为建筑id
         */
        private unlockAnimStory: basic.Dictionary<number, Array<number>> = new basic.Dictionary<number, Array<number>>();

        /**
         * 当前已解锁的建筑
         */
        private unlockBuilding: Array<number>;
        /**
         * 当前已解锁的剧情，key为建筑id
         */
        private unlockBuildingStory: basic.Dictionary<number, Array<number>>;
        private isInit: boolean = false;
        /**
         * 当前正在播放的audio的id
         */
        private audioIntroId: number = -1;
        private audioBgId: number = -1;
        private cgView: Page_Cg_View;

        constructor() {
            super(new ui.lobby.activity_2408_spot.activity_2408_spotUI());
            UI_Activity_2408_Spot.Inst = this;
        }

        public onCreate() {
            this.handleConfig();
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.listBuilding = [];
            let mid: Laya.Sprite = this.me.getChildByName('mid') as Laya.Sprite;
            for (let i = 0; i < 4; i++) {
                let buildingName = 'building_' + i;
                this.listBuilding.push(new ItemBuilding(mid.getChildByName(buildingName) as Laya.Sprite, i, this));
            }

            let remain = this.me.getChildByName('top').getChildByName('right').getChildByName('remain') as Laya.Sprite;
            this.labelCount = remain.getChildByName('count') as Laya.Label;
            this.countAdapt = new common.SpriteAdapter(remain.getChildByName('bg') as Laya.Image, this.labelCount, SpriteAdapterType.LEFTEXTEND, 170);
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2408_spot/background.png');

            this.exchangeItemHandler = new Laya.Handler(this, () => {
                this.onUpdateData();
            });

            let rewardSprite = this.me.getChildByName('bot').getChildByName('reward') as Laya.Sprite;
            this.panelReward = rewardSprite.getChildByName('content') as Laya.Panel;
            this.getAllBtn = rewardSprite.getChildByName('btn_receive') as Laya.Button;
            this.rewardTasks = [];
            cfg.activity.period_task.forEach((value) => {
                if (value.activity_id == UI_Activity_2408_Spot.rewardActivityId) {
                    this.rewardTasks.push(value);
                }
            });
            this.listRewards = [];
            let templete = this.panelReward.getChildByName('templete') as Laya.Sprite;
            for (let i = 0; i < this.rewardTasks.length; ++i) {
                let spr = i == 0 ? templete : templete.scriptMap['capsui.UICopy']['getNodeClone']();
                spr.x = templete.x + this.rewardPerWidth * i;
                this.listRewards.push(new ItemSpotReward(spr, this.rewardTasks[i], this));
            }
            this.panelReward.hScrollBarSkin = '';
            this.panelReward.refresh();
            (this.me.getChildByName('top').getChildByName('left').getChildByName('btn_return') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) return;
                this.close();
            });
            (this.me.getChildByName('top').getChildByName('right').getChildByName('btn_help') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) return;
                UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(4452));
            });
            (this.me.getChildByName('bot').getChildByName('reward').getChildByName('btn_receive') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) return;
                this.onAllRewardBtnClick();
            });

            this.noteBtn = this.me.getChildByName('bot').getChildByName('btn_note') as Laya.Button;
            this.noteBtn.clickHandler = new Laya.Handler(this, this.onClickNote);
            this.aniShow = (this.me as ui.lobby.activity_2408_spot.activity_2408_spotUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2408_spot.activity_2408_spotUI).hide;
            this.animLocks = [];
            for (let i = 0; i < 4; i++) {
                this.animLocks.push((this.me as ui.lobby.activity_2408_spot.activity_2408_spotUI)['unlock' + (i + 1)]);
            }
            Laya.stage.on(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
           
            
            this.cgView = new Page_Cg_View(this.me.getChildByName('page_cg_view') as Laya.Sprite);
            this.cgView.visible = false;
            this.pages = this.me.getChildByName('pages') as Laya.Sprite;
            this.pages.addChild((new UI_Activity_2408_Spot_Building()).me);
            this.pages.addChild((new UI_Activity_2408_Spot_Note()).me);
            this.pages.addChild((new UI_Activity_2408_Spot_CgGet()).me);
            this.noteRedPoint = this.noteBtn.getChildByName('red_point') as Laya.Sprite;

        }

        private handleConfig() {
            let buildingsConfig = cfg.activity.summer_story.getGroup(UI_Activity_2408_Spot.activityId);
            let storysConfig = cfg.activity.story_activity.getGroup(UI_Activity_2408_Spot.activityId);
            for (let building of buildingsConfig) {
                let buildingId = building.building;
                if (buildingId) {
                    let buildingName = building.building_name;
                    let storys = common.ConfigHelper.configString2Array<number>(building.story_id);
                    let buildingConfig: Activity_2408_Spot_BuildingConfig = {
                        buildingId: buildingId,
                        buildingName: buildingName,
                        storys: [],
                        unlockDay: 0,
                        buildingUnlock: building.building_unlock,
                        storyDesc: building.story_desc,
                        buildingRewards: []
                    };
                    for (let story of storys) {
                        let storyId = story[0];

                        let storyData = storysConfig.find((v) => {
                            return v.story_id == storyId;
                        })

                        buildingConfig.unlockDay = storyData.unlock_day;
                        let endings = cfg.activity.story_ending.findGroup(storyId);
                        let storyConfig: StoryConfig = {
                            storyId: storyId,
                            storyName: storyData.title,
                            buildingId: buildingId,
                            endingIds: []
                        };
                        for (let ending of endings) {
                            let endingConfig: EndingConfig = {
                                endingId: ending.ending_id,
                                reward: -1,
                                storyId: ending.story_id
                            };
                            if (ending.reward) {
                                endingConfig.reward = common.ConfigHelper.configString2Array<number>(ending.reward)[0][0];
                                buildingConfig.buildingRewards.push(endingConfig.reward);
                            }
                            storyConfig.endingIds.push(endingConfig);
                        }
                        buildingConfig.storys.push(storyConfig);
                    }
                    this.buildingsConfig.set(buildingId, buildingConfig);
                }

            }
            // console.log("buildingsConfig", JSON.stringify(this.buildingsConfig));
            //根据解锁时间为建筑排序
            this.unlockBuildingSort = [];
            for (let index = 1; index < 5; index++) {
                let buildingConfig = this.buildingsConfig.get(index);
                if (buildingConfig) {
                    this.unlockBuildingSort.push(index);
                }
            }
            this.unlockBuildingSort.sort((a, b) => {
                let buildingA = this.buildingsConfig.get(a);
                let buildingB = this.buildingsConfig.get(b);
                return buildingA.unlockDay - buildingB.unlockDay;
            });

        }

        public show() {
            app.Log.log("UI_Activity_2408_Spot show:" + JSON.stringify(UI_Activity_2408_Spot.getUnlockedStorys()));
            //清空待显示动画
            this.unlockAnimBuilding = [];
            this.unlockAnimStory.clear();
            this.refresh();
            this.panelReward.hScrollBar.value = 0;
            this.enable = true;
            //播放动画
            this.aniShow.play(0, false);
            view.AudioMgr.PlayAudio(10139);
            //todo 播放奖励列表展示动画，2帧内向左移动30
            let delay = this.aniShow.count * this.aniShow.interval;
            let tween_config = { delay: 50, duration: 100, ease: Laya.Ease.quadOut };
            let start_config = { alpha: 0, x_dis: 100 };
            let target_config = { alpha: 1 };
            let items = this.listRewards.map((value) => {
                return value.me;
            });
            let list_delay = game.Tools.listSpritesAnim(items, tween_config, start_config, target_config);
            delay = delay > list_delay ? delay : list_delay;
            this.isLock = true;
            Laya.timer.once(delay, this, () => {
                this.isLock = false;
                //如果没有播放过新手引导
                if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.Spot_2408_Checked)) {
                    this.showGuide(new Laya.Handler(this, () => {

                        app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.Spot_2408_Checked, 1);
                        this.checkCg1Get();

                    }));
                } else {
                    this.checkCg1Get(new Laya.Handler(this, () => {
                        this.checkCg2Get();
                    }));
                }
            });
            
        }



        private close() {
            this.aniHide.play(0, false);
            this.isLock = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.enable = false;
                UI_Lobby.Inst.enable = true;
                view.BgmListMgr.PlayLobbyBgm();
            });
        }

        public refresh() {
            this.refreshCount();
            this.refreshBuilding();
            this.refreshReward();
            this.refreshNoteRedPoint();
        }

        public refreshBuilding() {
            this.listBuilding.forEach((value) => {
                value.show();
            });
        }

        public refreshReward() {
            this.listRewards.forEach((value) => {
                value.show();
            });
            this.freshAllGetBtn();
        }

        // 刷新右上角数量
        public refreshCount() {
            let count = UI_Bag.get_item_count(UI_Activity_2408_Spot.unlockItemId);
            this.labelCount.text = game.Tools.strOfLocalization(4450, [count.toString()]);
            this.countAdapt.fresh();
        }

        // 单个领奖
        public onSingleRewardBtnClick(taskId: number, onComplete: Laya.Handler = null) {
            this.isLock = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: taskId }, (err, res) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                } else {
                    UI_Activity.onPeriodTaskRewarded(taskId);
                    let d_activity_task = cfg.activity.period_task.get(taskId);

                    let ss: Array<string> = d_activity_task.reward.split('-');
                    let reward_id = parseInt(ss[0]);
                    let reward_count = parseInt(ss[1]);

                    game.Tools.showRewards({ rewards: [{ id: reward_id, count: reward_count }] }, null);

                    this.refreshReward();
                    onComplete?.run();
                }
            });
        }



        private onAllRewardBtnClick() {
            let list = UI_Activity.getPeriodTaskList(UI_Activity_2408_Spot.rewardActivityId);
            let idList: Array<number> = [];
            list.forEach(element => {
                if (element['achieved'] && !element['rewarded']) {
                    idList.push(element['id']);
                }
            });
            if (idList.length > 0) {
                this.isLock = true;
                app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: idList }, (err, res) => {
                    this.isLock = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                    } else {
                        let lst = [];
                        let rewardObj = {};
                        for (let id of idList) {

                            UI_Activity.onPeriodTaskRewarded(id);
                            let _data = cfg.activity.period_task.get(id);
                            if (!_data || !_data.reward) continue;
                            let _reward = _data.reward.split('-');
                            let reward_id = Number(_reward[0]);
                            let reward_count = Number(_reward[1]);
                            if (!rewardObj[reward_id]) {
                                rewardObj[reward_id] = reward_count;
                            } else {
                                rewardObj[reward_id] += reward_count;
                            }
                        }
                        this.refreshReward();
                        // this.jumpToCurrentIndex();
                        for (let key in rewardObj) {
                            lst.push({ id: Number(key), count: rewardObj[key] });
                        }

                        game.Tools.showRewards({ rewards: lst }, null);
                    }
                });
            }
        }


        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_2408_Spot', true);
            UI_Bag.add_item_listener(UI_Activity_2408_Spot.unlockItemId, this.exchangeItemHandler);
            this.bindEvent();
            this.playBg();
           
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_2408_Spot', false);
            // Laya.loader.clearTextureRes(game.Tools.localUISrc('myres/activity_2408_spot/background.png'));
            UI_Bag.remove_item_listener(UI_Activity_2408_Spot.unlockItemId, this.exchangeItemHandler);
            UI_Activity_2408_Spot_Note.Inst.enable = false;
            UI_Activity_2408_Spot_Building.Inst.enable = false;
            this.removeEvent();
            this.stopBg();
        }

        private bindEvent() {
            Laya.stage.on(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);
        }

        private removeEvent() {
            // Laya.stage.off(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
            Laya.stage.off(EventCode.REMOVE_ACTIVITY, this, this.onActivityFinish);

        }

        private onClickNote() {
            if (this.isLock) {
                return;
            }
            UI_Activity_2408_Spot_Note.Inst.show();
        }

        private onUpdateData() {
           

            //检测故事数据的变更，如果有变化，则在列表里添加需要播放的动画
            let unlockBuilding = [];
            let unlockBuildingStory = new basic.Dictionary<number, Array<number>>();
            for (let buildingId of this.unlockBuildingSort) {
                let buildingConfig = this.buildingsConfig.get(buildingId);
                if (UI_Activity_2408_Spot.isBuildingUnlock(buildingId)) {
                    unlockBuilding.push(buildingId);
                    let unlockStory = [];
                    for (let story of buildingConfig.storys) {
                        if (UI_Activity_2408_Spot.isSpotRead(story.storyId)) {
                            unlockStory.push(story.storyId);
                        }
                    }
                    unlockBuildingStory.set(buildingId, unlockStory);
                }
            }
            // 如果是第一次初始化，则直接赋值
            if (!this.isInit) {
                
              
            }
            else {
                // 如果有变化，则播放动画
                for (let buildingId of unlockBuilding) {
                    if (this.unlockBuilding.indexOf(buildingId) < 0) {
                        this.unlockAnimBuilding.push(buildingId);
                    }
                    else {
                        let unlockStory = unlockBuildingStory.get(buildingId);
                        let oldUnlockStory = this.unlockBuildingStory.get(buildingId);
                        for (let storyId of unlockStory) {
                            if (oldUnlockStory.indexOf(storyId) < 0) {
                                if (!this.unlockAnimStory.has(buildingId)) {
                                    this.unlockAnimStory.set(buildingId, []);
                                }
                                this.unlockAnimStory.get(buildingId).push(storyId);
                            }
                        }
                    }
                }
            }
            // console.log("等待播放的动画", this.unlockAnimBuilding, this.unlockAnimStory);
            
            this.unlockBuilding = unlockBuilding;
            this.unlockBuildingStory = unlockBuildingStory;
            if (this.enable) {
                
                if (!this.isInit) {
                    this.refresh();
                }
                else {
                    this.refreshReward();
                    this.refreshCount();
                }
            }
            this.isInit = true;
            
        }

        public checkBuildingAnim() {
            this.isLock = true;
            //展示建筑解锁动画
            if (this.unlockAnimBuilding.length > 0) {
                view.AudioMgr.PlayAudio(10140);
                for (let index = 0; index < this.unlockAnimBuilding.length; index++) {
                    let buildingId = this.unlockAnimBuilding[index];
                    let building = this.listBuilding[buildingId - 1];
                    building.doUnlockAnim();
                    this.animLocks[buildingId - 1].play(0, false);
                    
                }
                //等待剧情解锁动画完毕
                Laya.timer.once(3000, this, () => {
                    this.unlockAnimBuilding = [];
                    this.checkPointAnim();
                })
            } else {
                this.checkPointAnim();
            }
           
        }

        private checkPointAnim() {
            //展示剧情解锁动画
            if (this.unlockAnimStory.getCount() > 0) {
                view.AudioMgr.PlayAudio(10142);
                let keys = this.unlockAnimStory.keys();
                for (let key of keys) {
                    let building = this.listBuilding[key - 1];
                    let storys = this.unlockAnimStory.get(key);
                    //根据storyId，检查显示哪一个
                    for (let storyId of storys) {
                        let pointIndex = this.buildingsConfig.get(key).storys.findIndex((v) => {
                            return v.storyId == storyId;
                        });
                        if (pointIndex >= 0) {
                            building.doCompleteAnim(pointIndex);
                        }

                    }
                }
                Laya.timer.once(500, this, () => {
                    this.unlockAnimStory.clear();
                    this.isLock = false;
                })
            }
            else {
                this.isLock = false;
            }
        }

        private freshAllGetBtn() {
            let list = UI_Activity.getPeriodTaskList(UI_Activity_2408_Spot.rewardActivityId);
            let allGet = true;
            for (let i = 0; i < list.length; i++) {
                if (list[i]['achieved'] && !list[i]['rewarded']) {
                    allGet = false;
                    break;
                }
            }
            this.getAllBtn.visible = !allGet;
        }

        public showGuide(onComplete?: Laya.Handler) {
            let step = 0;
            //找到所有对应活动id的引导
            let stepsConfig: Array<lqc.Sheet_Activity_ActivityGuide> = []
            cfg.activity.activity_guide.forEach((value) => {
                if (value.activity_id == UI_Activity_2408_Spot.activityId) {
                    stepsConfig.push(value);
                }
            });
            let nextStep = () => {
                if (step < stepsConfig.length) {
                    let guide = stepsConfig[step];
                    let name = "";
                    if (guide.char_id == 0) {
                        if (guide.char_str_id == 0) {
                            //如果是0，则为角色名字
                            name = GameMgr.Inst.account_data['nickname'];
                        } else {
                            //event表里的字符串id
                            name = game.Tools.eventStrOfLocalization(guide.char_str_id);
                        }

                    } else {
                        //角色名
                        name = cfg.item_definition.character.find(guide.char_id)["name_" + common.ConfigHelper.getLanguageName()];
                    }
                    let content = game.Tools.eventStrOfLocalization(guide.content_str_id);

                    if (guide.guide_location == 0) {
                        UI_Activity_Guide_Chat.Inst.showDownContent(name, content);
                    } else {
                        UI_Activity_Guide_Chat.Inst.showUpContent(name, content);
                    }

                    step++;
                } else {
                    // onComplete?.run();
                    UI_Activity_Guide_Chat.Inst.enable = false;
                    //先显示一张cg当关闭cg后执行onComplete
                    this.cgView.cgPath = "myres/activity_2408_spot/cg.jpg";
                    this.cgView.onClose = new Laya.Handler(this, () => {
                        onComplete?.run();
                    });
                    this.cgView.show();

                }
            };
            UI_Activity_Guide_Chat.Inst.doNextClickHandler = new Laya.Handler(this, nextStep);
            nextStep();
            UI_Activity_Guide_Chat.Inst.enable = true;
        }

        private checkCg1Get(onComplete?: Laya.Handler) {
            let taskInfo = UI_Activity.getPeriodTaskInfo(UI_Activity_2408_Spot.cg1TaskId);
            if (!taskInfo) {
                return;
            }
            //检查cg2是否已经领取
            if (taskInfo['rewarded']) {
                onComplete?.run();
                return;
            }
            //为用户领奖并显示获得cg页面
            this.isLock = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: [UI_Activity_2408_Spot.activityId] }, (err, res) => {
                if (err || res['error']) {
                    this.isLock = false;
                    UIMgr.Inst.showNetReqError('taskRequest', err, res);
                } else {
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: UI_Activity_2408_Spot.cg1TaskId }, (err, res) => {
                        this.isLock = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                        } else {
                            UI_Activity_2408_Spot_CgGet.Inst.show(UI_Activity_2408_Spot.cg1ItemId, false);
                            onComplete?.run();
                        }
                    });
                }
            });
        }

        public checkCg2Get() {
            let taskInfo = UI_Activity.getPeriodTaskInfo(UI_Activity_2408_Spot.cg2TaskId);
            if (!taskInfo) {
                return;
            }
            //检查cg2是否已经领取
            if (taskInfo['rewarded']) {
                return;
            }
            //检查cg2任务是否达成,如果达成则领取
            if (!taskInfo['achieved']) {
                return;
            }
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: UI_Activity_2408_Spot.cg2TaskId }, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                } else {
                    UI_Activity_2408_Spot_CgGet.Inst.show(UI_Activity_2408_Spot.cg2ItemId, true);
                }
            });
        }



        public static haveReward(): boolean {
            if (!UI_Activity.activity_is_running(UI_Activity_2408_Spot.activityId)) return false;
            //是否有可以领取的奖励
            let list = UI_Activity.getPeriodTaskList(UI_Activity_2408_Spot.rewardActivityId);
            for (let i = 0; i < list.length; i++) {
                if (list[i]['achieved'] && !list[i]['rewarded']) {
                    return true;
                }
            }
            return false;
        }

        public static haveUnlockItem(): boolean {
            return UI_Bag.get_item_count(UI_Activity_2408_Spot.unlockItemId) > 0;
        }

        

        private playBg() {
            view.AudioMgr.StopMusic(0);
            let ids = view.AudioMgr.playABBBSoundById(10137, 10138);
            this.audioIntroId = ids.a_id;
            this.audioBgId = ids.b_id;
        }

        private stopBg() {

            if (this.audioBgId != -1) {
                view.AudioMgr.StopAudio(this.audioBgId);
            }
            if (this.audioIntroId != -1) {
                view.AudioMgr.StopAudio(this.audioIntroId);
            }
            this.audioBgId = -1;
            this.audioIntroId = -1;
        }


        /**
         * 中间剧情是否已解锁未阅读
         * @private
         */
        public static isMiddleRedPoint(): boolean {
            let canUnlock = this.isSpotCanUnlock(this.middleSpotId);
            let hadRead = Laya.LocalStorage.getItem(this.middleSpotId.toString() + "_" + GameMgr.Inst.account_id) == "1";
            return canUnlock && !hadRead;
        }

        /**
         * 结束剧情是否已解锁，未阅读
         * @private
         */
        public static isEndRedPoint(): boolean {
            let canUnlock = this.isSpotCanUnlock(this.endSpotId);
            let hadRead = Laya.LocalStorage.getItem(this.endSpotId.toString() + "_" + GameMgr.Inst.account_id) == "1";
            return canUnlock && !hadRead;
        }
       

        public refreshNoteRedPoint() {
            this.noteRedPoint.visible = UI_Activity_2408_Spot.isMiddleRedPoint() || UI_Activity_2408_Spot.isEndRedPoint();
        }

        public onActivityFinish(activityId:number) {
            if (!this.enable) {
                return;
            }
            if (activityId == UI_Activity_2408_Spot.activityId) {
                //弹出提示框
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                    this.close();
                    UI_Activity_Guide_Chat.Inst.enable = false;
                    
                }))
            }
        }

    }


}