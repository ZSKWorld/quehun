/**
* 24ba主活动建筑弹窗
*/
module uiscript {

  
    export class UI_Activity_2408_Spot_Building extends UIBase {
        public static Inst: UI_Activity_2408_Spot_Building = null;
        private bg: Laya.Sprite;
        private root: Laya.Sprite;
        private building: Laya.Image;
        private buildingName: Laya.Label;
        private normal: Laya.Sprite;
        private lock: Laya.Sprite;
        private lockTime: Laya.Label;
        private unlock: Laya.Sprite; // 锁节点下的解锁节点
        private unlockCount: Laya.Label; // 剩余可解锁区域显示
        private currentBuildingId: number;
        public isLock: boolean;
        private stroyPanel: ScrollPanel;
        private storyLabel: Laya.Label;
        private closeBtn: Laya.Button;
        private buildingConfig:Activity_2408_Spot_BuildingConfig;
        private unlockBtn: UI_UniversalBtn;
        private spotEntrances: Array<UI_Activity_2408_Spot_SpotEntrance>;
        private items: Array<UI_Activity_2408_Spot_CollectItem>;
        private itemChangeHandler: Laya.Handler;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniDuring: Laya.FrameAnimation;
        private maskCloseBtn: Laya.Button;
        
        constructor() {
            super(new ui.lobby.activity_2408_spot.activity_2408_spot_buildingUI());
            UI_Activity_2408_Spot_Building.Inst = this;
        }

        public onCreate() { 
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.building = this.root.getChildByName('building').getChildByName('building') as Laya.Image;
            this.buildingName = this.root.getChildByName('building').getChildByName('name') as Laya.Label;
            if (GameMgr.client_language == 'en' ) {
                this.buildingName.scaleX = 1;
                this.buildingName.scaleY = 1;
                this.buildingName.width = 300;
            }
            if ( GameMgr.client_language == 'jp') {
                this.buildingName.scaleX = 0.9;
                this.buildingName.scaleY = 0.9;
                this.buildingName.width = 300;
            }
            this.stroyPanel = new ScrollPanel(this.root.getChildByName("desc") as Laya.Sprite);
            this.storyLabel = this.stroyPanel.content.getChildByName("desc") as Laya.Label;

            let right = this.root.getChildByName('right') as Laya.Sprite;
            this.normal = right.getChildByName('normal') as Laya.Sprite;
            this.spotEntrances = [];
            for (let index = 0; index < 3; index++) {
                let item = this.normal.getChildByName(`item_${index}`) as Laya.Sprite;
                let spotEntrance = new UI_Activity_2408_Spot_SpotEntrance(item, index);
                spotEntrance.clickHandler = new Laya.Handler(this, () => {
                    this.onSpotBtnClick(this.buildingConfig.storys[index].storyId);
                });
                this.spotEntrances.push(spotEntrance);
            }
            this.lock = right.getChildByName('lock') as Laya.Sprite;
            this.lockTime = this.lock.getChildByName('time') as Laya.Label;
            this.unlock = this.lock.getChildByName('unlock') as Laya.Sprite;
            this.unlockCount = this.unlock.getChildByName('count') as Laya.Label;
            this.closeBtn = this.root.getChildByName("btn_close") as Laya.Button;
            let closeBack = this.root.getChildByName("btn_close") as Laya.Button;
            closeBack.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.close();
            });
            
            this.unlockBtn = new UI_UniversalBtn(this.unlock.getChildByName('btn') as Laya.Sprite);
            this.unlockBtn.clickHandler = new Laya.Handler(this, () => { 
                if (this.isLock) return;

                this.onUnlockBuildingBtnClick();
            });
            this.items = [];
            let itemParent = this.normal.getChildByName('items') as Laya.Sprite;
            for (let index = 0; index < 2; index++) {
                let item = itemParent.getChildByName(`item_${index}`) as Laya.Sprite;
                let collectItem = new UI_Activity_2408_Spot_CollectItem(item);
                collectItem.Index = index;
                collectItem.clickHandler = null;
                this.items.push(collectItem);
                
            }
            this.itemChangeHandler = new Laya.Handler(this, () => { 
                this.onUpdateData();
            });
            this.aniShow = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_buildingUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_buildingUI).hide;
            this.aniDuring = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_buildingUI).piaofu;
            this.maskCloseBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                this.close();
            });

        }

        public show(buildingId: number) { 
            this.currentBuildingId = buildingId;
            this.buildingConfig = UI_Activity_2408_Spot.Inst.buildingsConfig.get(buildingId);
            this.stroyPanel.gotoTop();
            this.showBuilding();
            this.showStory();
            this.freshState();
            this.enable = true;
            this.aniShow.play(0, false);
            view.AudioMgr.PlayAudio(10141);
            this.isLock = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => { 
                this.aniDuring.play(0, true);
                this.isLock = false;
                
            });
        }
        

        public close() { 
            this.aniDuring.gotoAndStop(0);
            this.aniHide.play(0, false);
            this.isLock = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.enable = false;
                UI_Activity_2408_Spot.Inst.checkBuildingAnim();

            });
            
        }

        public onEnable(): void {
            this.bindEvent();
        }

        public onDisable(): void {
            this.removeEvent();
        }

        private bindEvent() {
            Laya.stage.on(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
            UI_Bag.add_item_listener(UI_Activity_2408_Spot.unlockItemId, this.itemChangeHandler);
        }

        private removeEvent() { 
            Laya.stage.off(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
            UI_Bag.remove_item_listener(UI_Activity_2408_Spot.unlockItemId, this.itemChangeHandler);
        }


        private onUpdateData() {
            // console.log('UI_Activity_2408_Spot_Building onUpdateData');
            
            if (!this.enable) {
                return;
            }
            this.freshState();
        }

        private freshState() {
            let isUnlock = UI_Activity_2408_Spot.isBuildingUnlock(this.currentBuildingId);
            if (isUnlock) {
                this.showUnlock()
            }
            else {
                this.showLock();
            }
            
        }

        private onSpotBtnClick(storyId: number) { 
            if (this.isLock) return;
            

            let data = UI_Activity_2408_Spot.getStoryActivityData(storyId);
            if (data) {
                let serverUnlockData = game.ActivityStoryDataHelper.getStoryData(UI_Activity_2408_Spot.activityId, storyId);
                if (!serverUnlockData) {
                    this.isLock = true;
                    let req: game.IReqStoryActivityUnlock = {
                        activity_id: UI_Activity_2408_Spot.activityId,
                        story_id: storyId
                    };
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.storyActivityUnlock, req, (err, res: game.IResCommon) => {
                        this.isLock = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.storyActivityUnlock, err, res);
                        } else {
                            this.enterStory(data.content_path, storyId)
                        }
                    });
                } else {
                    this.enterStory(data.content_path, storyId)
                }
            }
            
        }

        private enterStory(contentPath: string, storyId: number) {
            
            GameMgr.Inst.showSpotByEvent(contentPath, storyId, null, UI_Activity_2408_Spot.activityId, new Laya.Handler(this, () => {
                UI_Activity_2408_Spot.Inst.enable = false;
                game.Scene_Lobby.Inst.setBackHandler(Laya.Handler.create(this, () => {
                    if (!UI_Activity.activity_is_running(UI_Activity_2408_Spot.activityId)) {
                        uiscript.UI_Lobby.Inst.enable = true;
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                        }))
                        return;
                    }
                    this.showBuilding();
                    this.showStory();
                    this.freshState();
                    
                    UI_Activity_2408_Spot.Inst.refreshCount();
                    UI_Activity_2408_Spot.Inst.refreshReward();
                    UI_Activity_2408_Spot.Inst.checkCg2Get();
                    UI_Activity_2408_Spot.Inst.refreshNoteRedPoint();
                    UI_Activity_2408_Spot.Inst.enable = true;
                    UI_Activity_2408_Spot_Building.Inst.enable = true; 
                   
                }));
            }));
        }


        private showBuilding() { 
            this.buildingName.text = game.Tools.eventStrOfLocalization(this.buildingConfig.buildingName);
            this.building.skin = game.Tools.localUISrc(`myres/activity_2408_spot/build_card_${this.currentBuildingId}.png`);

        }

        private showStory() { 
           
            this.storyLabel.text = game.Tools.eventStrOfLocalization(this.buildingConfig.storyDesc);
            this.stroyPanel.contentHeight = this.storyLabel.trueHeight;
        }

        private showUnlock() {
            this.normal.visible = true;
            this.lock.visible = false;

            //显示剧情入口
            for (let index = 0; index < this.spotEntrances.length; index++) {
                let storyId = this.buildingConfig.storys[index].storyId;
                let spotEntrance = this.spotEntrances[index];
                if (UI_Activity_2408_Spot.isSpotCanUnlock(storyId)) {
                    if (UI_Activity_2408_Spot.isSpotComplate(storyId)) {
                        spotEntrance.showComplete();
                    }
                    else {
                        spotEntrance.showGo();
                    }
                    spotEntrance.title = game.Tools.eventStrOfLocalization(this.buildingConfig.storys[index].storyName);
                } else {
                    spotEntrance.showLock();
                }
            }
            //显示已收集道具
            this.freshCollectItem();
        }

        private showLock() {
            this.normal.visible = false;
            this.lock.visible = true;

            let restTime = UI_Activity_2408_Spot.getBuildingUnlockSeconds(UI_Activity_2408_Spot.activityId, this.currentBuildingId);
            
            //还没到解锁时间
            if (restTime>0) {
                this.unlock.visible = false;
                this.lockTime.visible = true;
                this.lockTime.text = UI_Activity.getLockTimeText(restTime);
            }
            else {
                this.unlock.visible = true;
                this.lockTime.visible = false;
                //剩余可解锁区域显示
                let count = UI_Activity_2408_Spot.unlockItemCount;
                this.unlockCount.text = game.Tools.strOfLocalization(4450, [count.toString()]);
                //刷新解锁按钮状态
                this.unlockBtn.setGrayed(count == 0);
                this.unlockBtn.setEnabled(count > 0);
            }
        }

        private onUnlockBuildingBtnClick() {
            this.isLock = true;
            let buildData = this.buildingConfig;
            let req: game.IReqExchangeActivityItem = {
                exchange_id: common.ConfigHelper.getExchangeIdByRewardId(UI_Activity_2408_Spot.exchangeActivityId, buildData.buildingUnlock),
                count: 1
            };
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.exchangeActivityItem, req, (err, res: game.IResExchangeActivityItem) => {
                this.isLock = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('exchangeActivityItem', err, res);
                } else {
                    //兑换成功 解锁建筑
                    this.freshState();
                    //已经解锁成功了，不可再次点击
                    this.unlockBtn.setEnabled(false);
                }
            });
        }

        private freshCollectItem() {
            for (let index = 0; index < this.items.length; index++) {
                let collectItem = this.items[index];
                if (collectItem.clickHandler) {
                    collectItem.clickHandler.recover();
                    collectItem.clickHandler = null;
                }
                let itemId = this.buildingConfig.buildingRewards[index];
                //已解锁弹出道具详情，未解锁弹出提示
                if (UI_Activity_2408_Spot.isCollectItem(itemId)) {
                    collectItem.itemId = itemId;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        UI_ItemDetail.Inst.show(itemId);
                    }, [index]);
                    collectItem.receive = true;
                } else {
                    collectItem.itemId = -1;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        let buildingName = game.Tools.eventStrOfLocalization(UI_Activity_2408_Spot.Inst.buildingsConfig.get(this.currentBuildingId).buildingName);
                        let tipString = game.Tools.strOfLocalization(4464, [buildingName]);
                        UI_Info_Small.Inst.show(tipString, true);
                    }, [index]);
                    collectItem.receive = false;
                }
            }
        }
        
    }

    

    
}