module uiscript {
    export class UI_Activity_2408_Spot_CgGet extends UIBase {
        public static Inst: UI_Activity_2408_Spot_CgGet = null;

        constructor() {
            super(new ui.lobby.activity_2408_spot.activity_2408_spot_getUI());
            UI_Activity_2408_Spot_CgGet.Inst = this;
        }
        private root: Laya.Sprite;

        private itemIcon: Laya.Image;
        private itemRect: UIRect;
        private itemName: Laya.Label;
        private closeBtn: Laya.Button;
        private tipImg: Laya.Image;
        private tipLabel: Laya.Label;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private isLock: boolean = false;
        private itemBtn: Laya.Button;
        private itemId: number;



        public onCreate(): void {
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            let item = this.root.getChildByName("item")
            this.itemIcon = item.getChildByName("icon") as Laya.Image;
            this.itemName = item.getChildByName("title") as Laya.Label;
            this.tipImg = this.root.getChildByName("tip_img") as Laya.Image;
            this.tipLabel = this.root.getChildByName("tip_text") as Laya.Label;
            this.itemBtn = item.getChildByName("btn") as Laya.Button;
            this.closeBtn = item.getChildByName("close_btn") as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => { 
                if (this.isLock) {
                    return;
                }
                this.hide();
            });
            this.aniShow = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_getUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_getUI).hide;
            if (GameMgr.client_language == "en" || GameMgr.client_language == "kr") {
                game.LoadMgr.setImgSkin(this.tipImg, "myres/activity_2408_spot/cg_get_tip.png");
            }
            this.itemBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                //显示道具详情
                UI_ItemDetail.Inst.show(this.itemId);
            });
        }

        
        public onEnable(): void {
           
        }

        public onDisable(): void {
           
        }

        public show(itemId: number, isImgTip: boolean) {
            this.itemId = itemId;
            if (this.itemRect == null) {
                this.itemRect = UIRect.CreateFromSprite(this.itemIcon);
            }
            game.Tools.setItemIcon(this.itemIcon, this.itemRect, itemId, "UI_Activity_2408_Spot", true);
            let info = game.GameUtility.get_item_view(itemId);
            this.itemName.text = info.name;
            this.tipImg.visible = isImgTip;
            this.tipLabel.visible = !isImgTip;
            this.me.visible = true;
            this.isLock = true;
            this.aniShow.play(0, false);
            let showEffect = game.FrontEffect.Inst.create_ui_effect(this.root, 'scene/fx_ui_zhuyun_06.lh', new Laya.Point(785, 200), 1);
            showEffect.enableFollowTarget = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.isLock = false;
                
            });
            Laya.timer.once(1000, this, () => { 
                showEffect.destory();
            });
        }

        public hide() {
            
            this.isLock = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.me.visible = false;
            });
        }

        
    }

}