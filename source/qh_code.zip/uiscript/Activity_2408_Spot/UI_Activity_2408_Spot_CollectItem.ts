module uiscript {

    export class UI_Activity_2408_Spot_CollectItem extends UI_Component {
        private unknown: Laya.Image;
        private icon: Laya.Image;
        private btn: Laya.Button;
        private itemRect: UIRect = null;
        private id = -1;
        private innerItemId = -1;
        private hook: Laya.Image;


        public onCreate(): void {
            this.unknown = this.me.getChildByName("unknown") as Laya.Image;
            this.icon = this.me.getChildByName("icon") as Laya.Image;
            this.btn = this.me.getChildByName("info_btn") as Laya.Button;
            this.itemRect = UIRect.CreateFromSprite(this.icon);
            this.hook = this.me.getChildByName("hook") as Laya.Image;
            this.hook.visible = false;
        }

        public set itemId(value: number) {
            this.innerItemId = value;
            this.unknown.visible = value == -1;
            this.icon.visible = !this.unknown.visible;
            if (this.itemId != -1) {
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(this.icon);
                }
                game.Tools.setItemIcon(this.icon, this.itemRect, value, "UI_Activity_2408_Spot", true);
            }

        }

        public get itemId(): number {
            return this.innerItemId;
        }

        public set clickHandler(value: Laya.Handler) {
            this.btn.clickHandler = value;
        }


        public set Index(value: number) {
            this.id = value;
        }

        public get Index(): number {
            return this.id;
        }

        public set receive(value: boolean) {
            this.hook.visible = value;
        }



    }


}