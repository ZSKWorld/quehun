module uiscript {


    class TaskItem extends UI_Component {
        private content: Laya.Label;
        private hook: Laya.Image;
        public onCreate(): void {
            this.content = this.me.getChildByName("content") as Laya.Label;
            this.hook = this.me.getChildByName("hook") as Laya.Image;
        }

        public setContent(value: string): void {
            this.content.text = value;
        }

        public setIsComplete(value: boolean) {
            this.hook.visible = value;
        }

        public get height(): number {
            return this.content.trueHeight;
        }
    }

    class Page_Cg_View extends UI_Component {
        private cg: Laya.Image;
        private closeBtn: Laya.Button;
        public onCreate(): void {
            this.cg = this.me.getChildByName("cg") as Laya.Image;
            this.closeBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
                this.hide();
            });

        }

        public show() {
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public refresh(skin: string, haveIds: number[]) {
            game.LoadMgr.setImgSkin(this.cg, skin, null, "UI_Activity_2408_Spot");
            for (let i = 0; i < this.cg.numChildren; i++) {
                let img = this.cg.getChildAt(i) as Laya.Image;
                img.visible = haveIds.indexOf(Number(img.name)) >= 0 && haveIds.length < UI_Activity_2408_Spot.collectItemsId.length;
            }
        }


    }

    class Page_Empty extends UI_Component {

        private lockTip: Laya.Label;
        public onCreate(): void {
            this.lockTip = this.me.getChildByName("lock_tip") as Laya.Label;
        }

        public onEnable(): void {

        }

        public show(isLock: boolean) {
            this.visible = true;
            this.lockTip.text = isLock ? game.Tools.strOfLocalization(4463) : game.Tools.strOfLocalization(4461);
        }

        public hide() {
            this.visible = false;
        }
    }

    class Page_Building extends UI_Component {
        private buildingImg: Laya.Image;
        private items: Array<UI_Activity_2408_Spot_CollectItem>;
        private spotEntrances: Array<UI_Activity_2408_Spot_SpotEntrance>;
        private buildingId: number;
        private stroyPanel: ScrollPanel;
        private storyLabel: Laya.Label;
        private buildingConfig: Activity_2408_Spot_BuildingConfig;
        private isLocking: boolean = false;


        public onCreate(): void {
            this.buildingImg = this.me.getChildByName("building") as Laya.Image;
            this.stroyPanel = new ScrollPanel(this.me.getChildByName("desc") as Laya.Sprite);
            this.storyLabel = this.stroyPanel.content.getChildByName("desc") as Laya.Label;
            this.items = [];
            let itemParent = this.me.getChildByName('items') as Laya.Sprite;
            for (let index = 0; index < 2; index++) {
                let item = itemParent.getChildByName(`item_${index}`) as Laya.Sprite;
                let collectItem = new UI_Activity_2408_Spot_CollectItem(item);
                collectItem.Index = index;
                collectItem.clickHandler = null;
                this.items.push(collectItem);
            }
            this.spotEntrances = [];
            let entrancesParent = this.me.getChildByName("spots") as Laya.Sprite;
            for (let index = 0; index < 3; index++) {
                let entrance = entrancesParent.getChildByName(`spot${index}`) as Laya.Sprite;
                let spotEntrance = new UI_Activity_2408_Spot_SpotEntrance(entrance, index);
                spotEntrance.clickHandler = new Laya.Handler(this, () => {
                    this.onSpotBtnClick(this.buildingConfig.storys[index].storyId);
                });
                this.spotEntrances.push(spotEntrance);
            }
        }

        public show(buildingId: number) {
            this.buildingId = buildingId;
            this.buildingConfig = UI_Activity_2408_Spot.Inst.buildingsConfig.get(this.buildingId);
            this.showBuilding();
            this.showStory();
            this.showEntrance();
            this.showCollectItem();
            this.visible = true;

        }

        public hide() {
            this.visible = false;
        }

        private showBuilding() {
            this.buildingImg.skin = game.Tools.localUISrc(`myres/activity_2408_spot/build_img_${this.buildingId}.png`);
        }

        private showStory() {
            this.storyLabel.text = game.Tools.eventStrOfLocalization(this.buildingConfig.storyDesc);
            this.stroyPanel.contentHeight = this.storyLabel.trueHeight;
            this.stroyPanel.gotoTop();
        }

        private showEntrance() {
            for (let index = 0; index < this.spotEntrances.length; index++) {
                let storyId = this.buildingConfig.storys[index].storyId;
                let spotEntrance = this.spotEntrances[index];
                if (UI_Activity_2408_Spot.isSpotCanUnlock(storyId)) {
                    if (UI_Activity_2408_Spot.isSpotComplate(storyId)) {
                        spotEntrance.showComplete();
                    }
                    else {
                        spotEntrance.showGo();
                    }
                    spotEntrance.title = game.Tools.eventStrOfLocalization(this.buildingConfig.storys[index].storyName);
                } else {
                    spotEntrance.showLock();
                }
            }

        }

        private showCollectItem() {
            for (let index = 0; index < this.items.length; index++) {
                let collectItem = this.items[index];
                let itemId = this.buildingConfig.buildingRewards[index];
                //已解锁弹出道具详情，未解锁弹出提示
                if (UI_Activity_2408_Spot.isCollectItem(itemId)) {
                    collectItem.itemId = itemId;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        UI_ItemDetail.Inst.show(itemId);
                    }, [index]);
                    collectItem.receive = true;
                } else {
                    collectItem.itemId = -1;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        let buildingName = game.Tools.eventStrOfLocalization(UI_Activity_2408_Spot.Inst.buildingsConfig.get(this.buildingId).buildingName);
                        let tipString = game.Tools.strOfLocalization(4464, [buildingName]);
                        UI_Info_Small.Inst.show(tipString, true);
                    }, [index]);
                    collectItem.receive = false;
                }
            }
        }

        private onSpotBtnClick(storyId: number) {
            if (this.isLocking) return;
            let data = UI_Activity_2408_Spot.getStoryActivityData(storyId);
            if (data) {
                let serverUnlockData = game.ActivityStoryDataHelper.getStoryData(UI_Activity_2408_Spot.activityId, storyId);
                if (!serverUnlockData) {
                    this.isLocking = true;
                    let req: game.IReqStoryActivityUnlock = {
                        activity_id: UI_Activity_2408_Spot.activityId,
                        story_id: storyId
                    };
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.storyActivityUnlock, req, (err, res: game.IResCommon) => {
                        this.isLocking = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.storyActivityUnlock, err, res);
                        } else {
                            UI_Activity_2408_Spot_Note.Inst.enterStory(data.content_path, storyId)
                        }
                    });
                } else {
                    UI_Activity_2408_Spot_Note.Inst.enterStory(data.content_path, storyId)
                }
            }
        }

        // private enterStory(contentPath: string, storyId: number) {
        //     GameMgr.Inst.showSpotByEvent(contentPath, storyId, null, UI_Activity_2408_Spot.activityId, new Laya.Handler(this, () => {
        //         UI_Activity_2408_Spot.Inst.enable = false;
        //         game.Scene_Lobby.Inst.setBackHandler(Laya.Handler.create(this, () => {
        //             UI_Activity_2408_Spot.Inst.refreshCount();
        //             UI_Activity_2408_Spot.Inst.refreshReward();
        //             UI_Activity_2408_Spot.Inst.refreshNoteRedPoint();
        //             UI_Activity_2408_Spot.Inst.checkCg2Get();
        //             UI_Activity_2408_Spot_Note.Inst.freshUI();
        //             UI_Activity_2408_Spot_Note.Inst.onTabChange();
        //             UI_Activity_2408_Spot_Note.Inst.enable = true;
        //             UI_Activity_2408_Spot.Inst.enable = true;

        //         }));
        //     }));
        // }

        


    }

    class Page_Character extends UI_Component {
        private character1: UI_Character_Skin;
        private character2: UI_Character_Skin;
        private playBtn: Laya.Button;
        private stroyPanel: ScrollPanel;
        private storyLabel: Laya.Label;
        private illust1: Laya.Sprite;
        private illust2: Laya.Sprite;
        private redPoint: Laya.Image;

        public onCreate(): void {
            this.illust1 = this.me.getChildByName("illust1") as Laya.Sprite;
            this.illust2 = this.me.getChildByName("illust2") as Laya.Sprite;
            this.character1 = new UI_Character_Skin(this.illust1.getChildByName("illust") as Laya.Sprite);
            this.character2 = new UI_Character_Skin(this.illust2.getChildByName("illust") as Laya.Sprite);
            this.playBtn = this.me.getChildByName("play_btn") as Laya.Button;
            let playBtnTitle = this.playBtn.getChildByName("title") as Laya.Label;
            if (GameMgr.client_language == "kr") {
                playBtnTitle.scaleX = 0.7;
                playBtnTitle.scaleY = 0.7;
            }
            this.stroyPanel = new ScrollPanel(this.me.getChildByName("desc") as Laya.Sprite);
            this.storyLabel = this.stroyPanel.content.getChildByName("desc") as Laya.Label;
            this.redPoint = this.playBtn.getChildByName("red_point") as Laya.Image;

        }

        public show() {
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public showCharaters(id1: number, id2: number = -1): void {
            if (id1 == -1) {
                this.character1.clear();
                this.character1.me.visible = false;
                return;
            }
            else {
                this.character1.setSkin(id1, 'waitingroom');
            }

            if (id2 == -1) {
                this.character2.clear();
                this.illust2.visible = false;
                this.illust1.x = 454;
                return;
            }
            else {
                this.illust2.visible = true;
                this.character2.setSkin(id2, 'waitingroom');
                this.illust1.x = 362;
                // this.character2.me.x = 545;
            }


        }

        public set story(value: string) {
            this.storyLabel.text = value;
            this.stroyPanel.contentHeight = this.storyLabel.trueHeight;
            this.stroyPanel.gotoTop();
        }


        public set clickHandler(value: Laya.Handler) {
            this.playBtn.clickHandler = value;
        }

        public onDispose(): void {
            this.character1.clear();
            this.character2.clear();
        }

        public set redPointVisible(value: boolean) {
            this.redPoint.visible = value;
        }
    }

    class Page_Cg extends UI_Component {
        private cg: Laya.Image;
        private openCgBtn: Laya.Button;
        private stroyPanel: ScrollPanel;
        private storyLabel: Laya.Label;
        private playBtn: Laya.Button;
        private redPoint: Laya.Image;
        public onCreate(): void {
            let cgSprite = this.me.getChildByName("cg") as Laya.Sprite;
            this.cg = cgSprite.getChildByName("cg").getChildByName("cg") as Laya.Image;
            this.openCgBtn = cgSprite.getChildByName("view_btn") as Laya.Button;
            this.stroyPanel = new ScrollPanel(this.me.getChildByName("desc") as Laya.Sprite);
            this.storyLabel = this.stroyPanel.content.getChildByName("desc") as Laya.Label;
            this.playBtn = this.me.getChildByName("play_btn") as Laya.Button;
            this.redPoint = this.playBtn.getChildByName("red_point") as Laya.Image;
        }

        public show() {
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public refresh(skin: string, haveIds: number[]) {
            game.LoadMgr.setImgSkin(this.cg, skin, null, "UI_Activity_2408_Spot");
            for (let i = 0; i < this.cg.numChildren; i++) {
                let img = this.cg.getChildAt(i) as Laya.Image;
                img.visible = haveIds.indexOf(Number(img.name)) >= 0 && haveIds.length < UI_Activity_2408_Spot.collectItemsId.length;
            }
        }

        public set story(value: string) {
            this.storyLabel.text = value;
            this.stroyPanel.contentHeight = this.storyLabel.trueHeight;
            this.stroyPanel.gotoTop();
        }

        public set playClickHandler(value: Laya.Handler) {
            this.playBtn.clickHandler = value;
        }

        public set openCgClickHandler(value: Laya.Handler) {
            this.openCgBtn.clickHandler = value;
        }

        public set redPointVisible(value: boolean) {
            this.redPoint.visible = value;
        }

    }

    class TabItem extends UI_Component {
        private select: Laya.Image;
        private unselect: Laya.Image;
        private name: Laya.Label;
        private selectColor: string = "#7C5C42";
        private unselectColor: string = "#f9eec2";

        public onCreate(): void {
            this.select = this.me.getChildByName("select") as Laya.Image;
            this.unselect = this.me.getChildByName("noselect") as Laya.Image;
            this.name = this.me.getChildByName("title") as Laya.Label;
            if (GameMgr.client_language == "en" || GameMgr.client_language == "jp" || GameMgr.client_language == "kr") {
                this.name.scaleX = 0.7;
                this.name.scaleY = 0.7;
                this.name.width = 300;
            }
        }

        public setSelected(value: boolean): void {
            this.select.visible = value;
            this.unselect.visible = !value;
            this.name.color = value ? this.selectColor : this.unselectColor;
        }

        public setName(value: string): void {
            this.name.text = value;
        }

    }


    export class UI_Activity_2408_Spot_Note extends UIBase {
        public static Inst: UI_Activity_2408_Spot_Note = null;
        constructor() {
            super(new ui.lobby.activity_2408_spot.activity_2408_spot_noteUI());
            UI_Activity_2408_Spot_Note.Inst = this;
        }

        private isLock: boolean = false;
        private tabNum: number = 7;
        private root: Laya.Sprite;
        private taskListPanel: Laya.Panel;
        private taskTemplate: Laya.Sprite;
        private taskListContainer: Laya.Sprite;
        private taskListScrollBar: capsui.CScrollBar;
        private closeBtn: Laya.Button;
        private maskCloseBtn: Laya.Button;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private midRedPoint: Laya.Image;
        private endRedPoint: Laya.Image;

        public activityId: number = 240813;
        private taskCfg: lqc.Sheet_Activity_PeriodTask[] = [];
        private taskItems: TaskItem[] = [];
        private pageCgView: Page_Cg_View;
        private pageEmpty: Page_Empty;
        private pageBuilding: Page_Building;
        private pageCharacter: Page_Character;
        private pageCg: Page_Cg;
        private tabGroup: UI_TabGroup_Base;
        private tabItems: TabItem[] = [];
        private summerStoryConfig: lqc.Sheet_Activity_SummerStory[];

        private collectItemParent: Laya.Sprite;
        private collectItems: UI_Activity_2408_Spot_CollectItem[] = [];

        public onCreate(): void {
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            this.summerStoryConfig = cfg.activity.summer_story.getGroup(UI_Activity_2408_Spot.activityId);
            let taskList = this.root.getChildByName("task_list") as Laya.Sprite;
            this.taskListPanel = taskList.getChildByName("list") as Laya.Panel;
            this.taskListContainer = this.taskListPanel.getChildByName("container") as Laya.Sprite;
            this.taskTemplate = this.taskListContainer.getChildByName("template") as Laya.Sprite;
            this.taskListScrollBar = (taskList.getChildByName("scrollbar") as Laya.Sprite).scriptMap["capsui.CScrollBar"];
            this.taskListScrollBar.init(new Laya.Handler(this, rate => {
                this.taskListPanel.vScrollBar.value = this.taskListPanel.vScrollBar.max * rate;
            }));
            this.taskListPanel.vScrollBarSkin = '';
            this.taskListPanel.vScrollBar.on('change', this, () => {
                this.taskListScrollBar.setVal(this.taskListPanel.vScrollBar.value / this.taskListPanel.vScrollBar.max, this.taskListPanel.height / (this.taskListContainer.height + this.taskListContainer.y));
            });
            this.taskCfg = common.ConfigHelper.getPeriodTasksByActivityId(this.activityId);
            this.createTaskItem()

            this.pageCgView = new Page_Cg_View(this.root.getChildByName("page_cg_view") as Laya.Sprite);
            this.pageEmpty = new Page_Empty(this.root.getChildByName("page_empty") as Laya.Sprite);
            this.pageBuilding = new Page_Building(this.root.getChildByName("page_building") as Laya.Sprite);
            this.pageCharacter = new Page_Character(this.root.getChildByName("page_character") as Laya.Sprite);
            this.pageCg = new Page_Cg(this.root.getChildByName("page_cg") as Laya.Sprite);

            this.pageCgView.visible = false;
            this.pageEmpty.visible = false;
            this.pageBuilding.visible = false;
            this.pageCharacter.visible = false;
            this.pageCg.visible = false;

            this.closeBtn = this.root.getChildByName("btn_close") as Laya.Button;
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
                this.hide();
            });
            this.maskCloseBtn = (this.me.getChildByName("bg") as Laya.Sprite).getChildByName("close_btn") as Laya.Button;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                this.hide();
            });

            let tabs = this.root.getChildByName("tabs") as Laya.Sprite;
            this.tabGroup = new UI_TabGroup_Base();
            for (let index = 0; index < this.tabNum; index++) {
                let tabSprite = tabs.getChildAt(index) as Laya.Button;
                let tabItem = new TabItem(tabSprite);
                let summerStoryConfig = this.summerStoryConfig[index];
                tabItem.setName(game.Tools.eventStrOfLocalization(summerStoryConfig.story_name));
                this.tabGroup.AddTabButton(tabSprite);
                this.tabItems.push(tabItem);
            }
            this.tabGroup.onSelectChange = (index) => {
                if (index == this.tabGroup.selectedIndex) {
                    this.onTabChange();
                    return;

                }

            }
            this.tabGroup.init();
            let mineItem = this.root.getChildByName("mine_item") as Laya.Sprite;
            this.collectItemParent = mineItem.getChildByName("items") as Laya.Sprite;
            this.createCollectItem();
            this.aniShow = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_noteUI).show;
            this.aniHide = (this.me as ui.lobby.activity_2408_spot.activity_2408_spot_noteUI).hide;
            this.midRedPoint = (tabs.getChildByName("btn_middle") as Laya.Sprite).getChildByName("red_point") as Laya.Image;
            this.endRedPoint = (tabs.getChildByName("btn_end") as Laya.Sprite).getChildByName("red_point") as Laya.Image;

        }

        private createTaskItem(): void {
            //每个任务的内容赋值
            this.taskTemplate.visible = false;
            let y = 0;
            for (let i = 0; i < this.taskCfg.length; i++) {
                let taskItem = new TaskItem(this.taskTemplate.scriptMap['capsui.UICopy'].getNodeClone());
                let cfgData = common.ConfigHelper.getPeriodTaskTarget(this.taskCfg[i].id);
                let descName = "desc_" + GameMgr.client_language;
                taskItem.setContent(cfgData[descName]);
                taskItem.me.y = y;
                this.taskListContainer.addChild(taskItem.me);
                this.taskItems.push(taskItem);
                y = y + taskItem.height + 30;
                taskItem.visible = true;
            }
            this.taskListContainer.height = y;

        }

        /**
         * 生成道具收集
         */
        private createCollectItem(): void {
            let space = 120;
            let collectItemSprite = this.collectItemParent.getChildByName("item") as Laya.Sprite;
            collectItemSprite.visible = false;
            let startX = collectItemSprite.x;
            let startY = collectItemSprite.y;
            let lineCount = 2;
            let rowCount = 4;
            for (let index = 0; index < 8; index++) {
                let collectItem = new UI_Activity_2408_Spot_CollectItem(collectItemSprite.scriptMap['capsui.UICopy'].getNodeClone());
                collectItem.Index = index;
                let x = startX + (index % rowCount) * space;
                let y = startY + Math.floor(index / rowCount) * space;
                collectItem.me.x = x;
                collectItem.me.y = y;
                collectItem.itemId = -1;
                collectItem.visible = true;
                this.collectItemParent.addChild(collectItem.me);
                collectItem.clickHandler = null;
                this.collectItems.push(collectItem);
            }
        }

        public onEnable(): void {
            this.bindEvent();
        }

        public onDisable(): void {
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_2408_spot/fragment.atlas'));
            this.removeEvent();
        }

        public show(): void {
            this.tabGroup.init();
            //task翻到最开始
            this.taskListPanel.vScrollBar.value = 0;
            this.freshUI();
            this.enable = true;
            this.aniShow.play(0, false);
            view.AudioMgr.PlayAudio(10141);
            this.isLock = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.isLock = false;
            });
        }

        public hide(): void {
           
            this.aniHide.play(0, false);
            this.isLock = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.isLock = false;
                this.enable = false;
                UI_Activity_2408_Spot.Inst.checkBuildingAnim();
            });
        }

        public freshUI() {

            this.freshTaskState();
            this.freshCollectItem();
            this.freshRedPoint();

        }

        private freshTaskState() {
            for (let i = 0; i < this.taskItems.length; i++) {
                let taskItem = this.taskItems[i];
                let taskCfg = this.taskCfg[i];
                let serverData = UI_Activity.getPeriodTaskInfo(taskCfg.id) as game.ITaskProgress;
                if (serverData) {
                    taskItem.setIsComplete(serverData.achieved);
                }
                else {
                    taskItem.setIsComplete(false);
                }

            }
        }

        private freshCollectItem() {
            for (let index = 0; index < this.collectItems.length; index++) {
                let collectItem = this.collectItems[index];
                let itemId = UI_Activity_2408_Spot.collectItemsId[index];
                //已解锁弹出道具详情，未解锁弹出提示
                if (UI_Activity_2408_Spot.isCollectItem(itemId)) {
                    collectItem.itemId = itemId;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        UI_ItemDetail.Inst.show(itemId);
                    }, [index]);
                } else {
                    collectItem.itemId = -1;
                    collectItem.clickHandler = new Laya.Handler(this, () => {
                        let id = Math.floor(index / 2) + 2;
                        //根据id去story表里找duildingId
                        let buildingId = cfg.activity.summer_story.findGroup(UI_Activity_2408_Spot.activityId).find(predicate => predicate.id == id).building;
                        if (buildingId) {
                            let buildingName = game.Tools.eventStrOfLocalization(UI_Activity_2408_Spot.Inst.buildingsConfig.get(buildingId).buildingName);
                            let tipString = game.Tools.strOfLocalization(4464, [buildingName]);
                            UI_Info_Small.Inst.show(tipString, true);
                        }
                      
                    }, [index]);
                }


            }

        }

        public onTabChange(): void {
            let selectIndex = this.tabGroup.selectedIndex;

            for (let index = 0; index < this.tabItems.length; index++) {
                let tabItem = this.tabItems[index];
                tabItem.setSelected(index == selectIndex);
            }
            let config = this.summerStoryConfig[selectIndex];

            switch (selectIndex) {
                case 0:
                    //竹林回忆，立绘
                    let character = common.ConfigHelper.configString2Array<number>(config.show_character);
                    this.pageCharacter.showCharaters(character[0][0]);
                    this.pageCharacter.story = game.Tools.eventStrOfLocalization(config.story_desc);
                    this.pageCharacter.show();
                    this.pageCharacter.redPointVisible = false;
                    this.pageBuilding.hide();
                    this.pageCg.hide();
                    this.pageEmpty.hide();
                    this.pageCharacter.clickHandler = new Laya.Handler(this, () => {
                        UI_Activity_2408_Spot.Inst.showGuide();
                    });
                    break;
                case 1:
                    //竹林商社，建筑,检测是否解锁，未解锁显示空白
                    this.pageCharacter.hide();
                    this.pageCg.hide();
                    if (UI_Activity_2408_Spot.isBuildingUnlock(config.building)) {
                        this.pageBuilding.show(config.building);
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageBuilding.hide();
                        this.pageEmpty.show(true);
                    }

                    break;
                case 2:
                    //宗祠，建筑
                    this.pageCharacter.hide();
                    this.pageCg.hide();
                    if (UI_Activity_2408_Spot.isBuildingUnlock(config.building)) {
                        this.pageBuilding.show(config.building);
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageBuilding.hide();
                        this.pageEmpty.show(true);
                    }
                    break;
                case 3:
                    //无双拍卖行，建筑
                    this.pageCharacter.hide();
                    this.pageCg.hide();
                    if (UI_Activity_2408_Spot.isBuildingUnlock(config.building)) {
                        this.pageBuilding.show(config.building);
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageBuilding.hide();
                        this.pageEmpty.show(true);
                    }
                    break;
                case 4:
                    //迷蝶茶楼，建筑
                    this.pageCharacter.hide();
                    this.pageCg.hide();
                    if (UI_Activity_2408_Spot.isBuildingUnlock(config.building)) {
                        this.pageBuilding.show(config.building);
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageBuilding.hide();
                        this.pageEmpty.show(true);
                    }
                    break;
                case 5:
                    //幕间，立绘
                    this.pageBuilding.hide();
                    this.pageCg.hide();
                    // let isUnlock = UI_Activity_2408_Spot.isSpotCanUnlock(UI_Activity_2408_Spot.middleSpotId);
                    let canUnlock = UI_Activity_2408_Spot.isSpotCanUnlock(UI_Activity_2408_Spot.middleSpotId);
                    if (canUnlock) {
                        //竹林回忆，立绘
                        let character = common.ConfigHelper.configString2Array<number>(config.show_character);
                        this.pageCharacter.showCharaters(character[0][0]);
                        this.pageCharacter.story = game.Tools.eventStrOfLocalization(config.story_desc);
                        this.pageCharacter.clickHandler = new Laya.Handler(this, () => {
                            this.onSpotBtnClick(UI_Activity_2408_Spot.middleSpotId);
                            Laya.LocalStorage.setItem(UI_Activity_2408_Spot.middleSpotId.toString() + "_" + GameMgr.Inst.account_id, "1");
                        });
                        this.pageCharacter.redPointVisible = UI_Activity_2408_Spot.isMiddleRedPoint();
                        this.pageCharacter.show();
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageCharacter.hide();
                        this.pageEmpty.show(true);
                    }
                    break;
                case 6:
                    //结束，cg
                    this.pageCharacter.hide();
                    this.pageBuilding.hide();
                    let canUnlockEnd = UI_Activity_2408_Spot.isSpotCanUnlock(UI_Activity_2408_Spot.endSpotId);
                    let cg = 'myres/activity_2408_spot/cg2.jpg';
                    let havedIds = [];
                    UI_Activity_2408_Spot.collectItemsId.forEach((id) => {
                        if (uiscript.UI_Bag.get_item_count(id) > 0) havedIds.push(id);
                    });
                    if (havedIds.length < UI_Activity_2408_Spot.collectItemsId.length) cg = 'myres/activity_2408_spot/cg2_empty.jpg';
                    if (canUnlockEnd) {
                        this.pageCg.refresh(cg, havedIds);
                        this.pageCg.story = game.Tools.eventStrOfLocalization(config.story_desc);
                        this.pageCg.playClickHandler = new Laya.Handler(this, () => {
                            this.onSpotBtnClick(UI_Activity_2408_Spot.endSpotId);
                            Laya.LocalStorage.setItem(UI_Activity_2408_Spot.endSpotId.toString() + "_" + GameMgr.Inst.account_id, "1");
                        });
                        this.pageCg.openCgClickHandler = new Laya.Handler(this, () => {
                            this.pageCgView.refresh(cg, havedIds);
                            this.pageCgView.show();
                        });
                        this.pageCg.redPointVisible = UI_Activity_2408_Spot.isEndRedPoint();
                        this.pageCg.show();
                        this.pageEmpty.hide();
                    }
                    else {
                        this.pageCg.hide();
                        this.pageEmpty.show(false);
                    }
                    break;

                default:
                    break;
            }




        }

        private bindEvent() {
            Laya.stage.on(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
        }

        private removeEvent() {
            Laya.stage.off(EventCode.ACTIVITY_SPOT_UPDATE, this, this.onUpdateData);
        }


        private onUpdateData() {
            if (!this.enable) {
                return;
            }
            this.freshUI();
            this.onTabChange();
        }


        private onSpotBtnClick(storyId: number) {
            if (this.isLock) return;
            let data = UI_Activity_2408_Spot.getStoryActivityData(storyId);
            if (data) {
                let serverUnlockData = game.ActivityStoryDataHelper.getStoryData(UI_Activity_2408_Spot.activityId, storyId);
                if (!serverUnlockData) {
                    this.isLock = true;
                    let req: game.IReqStoryActivityUnlock = {
                        activity_id: UI_Activity_2408_Spot.activityId,
                        story_id: storyId
                    };
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.storyActivityUnlock, req, (err, res: game.IResCommon) => {
                        this.isLock = false;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError(game.ERequest.storyActivityUnlock, err, res);
                        } else {
                            this.enterStory(data.content_path, storyId)
                        }
                    });
                } else {
                    this.enterStory(data.content_path, storyId)
                }
            }

        }

        public enterStory(contentPath: string, storyId: number) {
            
            GameMgr.Inst.showSpotByEvent(contentPath, storyId, null, UI_Activity_2408_Spot.activityId, new Laya.Handler(this, () => {
                
                UI_Activity_2408_Spot.Inst.enable = false;
                game.Scene_Lobby.Inst.setBackHandler(Laya.Handler.create(this, () => {
                    if (!UI_Activity.activity_is_running(UI_Activity_2408_Spot.activityId)) {
                        uiscript.UI_Lobby.Inst.enable = true;
                        UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
                        }))
                        return;
                    }
                    UI_Activity_2408_Spot.Inst.refreshCount();
                    UI_Activity_2408_Spot.Inst.refreshReward();
                    UI_Activity_2408_Spot.Inst.refreshNoteRedPoint();
                    UI_Activity_2408_Spot.Inst.checkCg2Get();
                    UI_Activity_2408_Spot.Inst.enable = true;
                    this.enable = true;
                    this.onUpdateData();
                }));
            }));
        }


        private freshRedPoint() {
            this.midRedPoint.visible = UI_Activity_2408_Spot.isMiddleRedPoint();
            this.endRedPoint.visible = UI_Activity_2408_Spot.isEndRedPoint();
        }

    }
}