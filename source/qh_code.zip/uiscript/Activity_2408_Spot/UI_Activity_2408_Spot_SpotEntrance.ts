module uiscript {
    export class UI_Activity_2408_Spot_SpotEntrance extends UI_Component {
        private name: Laya.Label;
        private icon: Laya.Image;
        private btn: Laya.Button;
        private index: number;
        public set clickHandler(handler: Laya.Handler) {
            this.btn.clickHandler = handler;
        }

        constructor(me: Laya.Sprite, index: number) {
            super(me);
            this.index = index;
            this.name = me.getChildByName('name') as Laya.Label;
            this.icon = me.getChildByName('icon') as Laya.Image;
            this.btn = me.getChildByName('btn') as Laya.Button;
        }


        public showLock() {
            this.btn.visible = false;
            this.icon.skin = game.Tools.localUISrc('myres/activity_2408_spot/pop_ups_chapter_lock.png');
            this.name.text = game.Tools.strOfLocalization(4454);
            this.name.color = '#968471';
        }

        public showGo() {
            this.btn.visible = true;
            this.icon.skin = game.Tools.localUISrc('myres/activity_2408_spot/pop_ups_chapter_arrow.png');
            // this.name.text = game.Tools.eventStrOfLocalization(this.data.title);
            this.name.color = '#536e75';
        }

        public showComplete() {
            this.btn.visible = true;
            this.icon.skin = game.Tools.localUISrc('myres/activity_2408_spot/hook.png');
            // this.name.text = game.Tools.eventStrOfLocalization(this.data.title);
            this.name.color = '#536e75';
        }

        public set title(title: string) {
            this.name.text = title;
        }
    }
}