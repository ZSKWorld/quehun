module uiscript{
    /**
     * 上下对话式的引导，没有操作，没有框选
     */
    export class UI_Activity_Guide_Chat extends UIBase {
        public static Inst: UI_Activity_Guide_Chat = null;

        constructor() {
            super(new ui.lobby.activity_2408_spot.activity_guide_chatUI());
            UI_Activity_Guide_Chat.Inst = this;
        }

        private root: Laya.Sprite;
        private nextBtn: Laya.Button;
        private meSprite: Laya.Sprite;
        private personSprite: Laya.Sprite;
        private otherSprite: Laya.Sprite;
        private person: Laya.Image;
        private downName: Laya.Label;
        private downContent: Laya.Label;
        private upName: Laya.Label;
        private upNameBg: Laya.Image;
        private upContent: Laya.Label;
        private nameAdapet: common.SpriteAdapter;

        public set doNextClickHandler(value: Laya.Handler) {
            this.nextBtn.clickHandler = value;
        }

        public set personImg(value: string) {
            this.person.skin = game.Tools.localUISrc(value);
        }

        public onCreate(): void {
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            this.nextBtn = this.me.getChildByName("next_btn") as Laya.Button;
            this.meSprite = this.root.getChildByName("me") as Laya.Sprite;
            this.downName = this.meSprite.getChildByName("name") as Laya.Label;
            this.downContent = this.meSprite.getChildByName("content") as Laya.Label;

            this.otherSprite = this.root.getChildByName("other") as Laya.Sprite;
            this.upName = this.otherSprite.getChildByName("name") as Laya.Label;
            this.upContent = this.otherSprite.getChildByName("content") as Laya.Label;
            this.upNameBg = this.otherSprite.getChildByName("name_bg") as Laya.Image;

            this.personSprite = this.root.getChildByName("person") as Laya.Sprite;
            this.person = this.personSprite.getChildByName("person") as Laya.Image;

            this.nameAdapet = new common.SpriteAdapter(this.upNameBg,this.upName,SpriteAdapterType.RIGHTEXTEND,-40);

        }

        private meShowAni: Laya.Tween;
        private otherShowAni: Laya.Tween;
        public showDownContent(name: string, content: string, isHideAnother: boolean = true) {
            if (this.otherShowAni) {
                Laya.Tween.clear(this.otherShowAni);
            }
            this.downName.text = name;
            this.downContent.text = content;
            this.otherSprite.visible = !isHideAnother;
            this.meSprite.visible = true;
            //需要做显示动画，aplha从0到1,0.3s
            this.meSprite.alpha = 0;
            this.meShowAni = Laya.Tween.to(this.meSprite, { alpha: 1 }, 300, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                this.meShowAni = null;
            }));

            
        }

        public showUpContent(name: string, content: string, isHideAnother: boolean = true) {
            if (this.meShowAni) {
                Laya.Tween.clear(this.meShowAni);
            }
            this.upName.text = name;
            this.upContent.text = content;
            this.meSprite.visible = !isHideAnother;
            this.otherSprite.visible = true;
            this.nameAdapet.fresh();
            //需要做显示动画，aplha从0到1,0.3s
            this.otherSprite.alpha = 0;
            this.otherShowAni = Laya.Tween.to(this.otherSprite, { alpha: 1 }, 300, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                this.otherShowAni = null;
            }));
        }

        public onDisable(): void {
            if (this.meShowAni) {
                Laya.Tween.clear(this.meShowAni);
            }
            if (this.otherShowAni) {
                Laya.Tween.clear(this.otherShowAni);
            }
        }

        

    }
}