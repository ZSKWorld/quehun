/**
* 24ba主活动
*/
module uiscript {
    export const enum Activity24BaAudio {
        bgm_loop = 10300,
        activity_enter = 10301,
        ui_open = 10302,
        great_success = 10303,
        success = 10304,
        failure = 10305,
        failure_switch_success = 10306,
        skill_ui_open = 10307,
        skill_level_up = 10308,
        level_up_14_17 = 10309,
        level_up_8_13 = 10310,
        level_up_1_7 = 10311,
        add_point = 10312,
    }

    export class UI_Activity_24ba extends UIBase {
        static readonly ItemIds = [30900080, 30900081, 30900082, 30900083];
        static readonly LevelUpItemIds: number[] = [this.ItemIds[1], this.ItemIds[2], this.ItemIds[3]];
        static readonly TopParamEffectIndex = {
            [this.ItemIds[0]]: 4, [this.ItemIds[1]]: 1, [this.ItemIds[2]]: 2, [this.ItemIds[3]]: 3,
        };
        static readonly ItemIcons = {
            [this.ItemIds[0]]: 'myres/activity_2501miaohui/img_74.png',
            [this.ItemIds[1]]: 'myres/activity_2501miaohui/img_73.png',
            [this.ItemIds[2]]: 'myres/activity_2501miaohui/img_73.png',
            [this.ItemIds[3]]: 'myres/activity_2501miaohui/img_73.png',
        };
        static readonly BuffLightSkins = {
            [this.ItemIds[0]]: 'myres/activity_2501miaohui/img_19.png',
            [this.ItemIds[1]]: 'myres/activity_2501miaohui/img_13.png',
            [this.ItemIds[2]]: 'myres/activity_2501miaohui/img_17.png',
            [this.ItemIds[3]]: 'myres/activity_2501miaohui/img_15.png',
        };
        static tempPos = new Laya.Point();

        //#region static
        public static Inst: UI_Activity_24ba = null;
        public static activityId: number = BA_Page_ActivityId.MAIN;
        public static startCharId: number = 200086;
        public static duringGuide: boolean = false;

        private static _activityData: lqc.Sheet_Activity_FestivalActivity;
        public static get activityData(): lqc.Sheet_Activity_FestivalActivity {
            if (!this._activityData) {
                this._activityData = cfg.activity.festival_activity.get(this.activityId);
            }
            return this._activityData;
        }

        public static activityLevel: number = 0;
        public static proposalList: game.IFestivalProposalData[] = [];
        public static eventList: number[] = [];
        public static buyRecord: { count: number, update_time: number };
        public static get maxEventId() {
            let eventId = 0;
            const eventGroup = cfg.activity.festival_event.getGroup(this.activityId);
            for (const eventData of eventGroup) {
                if (eventData.event_id > eventId)
                    eventId = eventData.event_id;
            }
            return eventId;
        }

        public static updateData(msg: game.IActivityFestivalData[]) {
            for (let data of msg) {
                if (data.activity_id == this.activityId) {
                    this.proposalList.length = 0;
                    this.eventList.length = 0;
                    this.activityLevel = data.level;
                    if (data.proposal_list) {
                        for (let proposal of data.proposal_list) {
                            this.proposalList.push(proposal);
                        }
                    }
                    if (data.event_list) {
                        for (let event of data.event_list) {
                            this.eventList.push(event);
                        }
                    }
                    this.buyRecord = data.buy_record;
                    break;
                }
            }
            if (this.Inst && this.Inst.enable) {
                this.Inst.refreshLevelTarget(); // 刷新一次升级界面
                this.Inst.refreshProposalCount();
            }
        }

        // 获取升级所需
        public static getLevelUpParam(level: number): number[] {
            let levelData = this.getLevelData(level);
            if (!levelData) {
                return null; // 返回null表示无该级
            }
            let param: number[] = [];
            if (!levelData.level_require) {
                for (let i = 0; i < UI_Activity_24ba.LevelUpItemIds.length; ++i) {
                    param.push(0);
                }
            } else {
                let requires = levelData.level_require.split(',');
                for (let require of requires) {
                    if (require) {
                        param.push(Number(require.split('-')[1]));
                    }

                }
            }
            return param;
        }

        public static getLevelData(level: number): lqc.Sheet_Activity_FestivalLevel {
            let eventGroup = cfg.activity.festival_level.getGroup(this.activityId);
            for (let eventData of eventGroup) {
                if (eventData.level == level) {
                    return eventData;
                }
            }
            return null;
        }

        public static getEventData(eventId: number): lqc.Sheet_Activity_FestivalEvent {
            let eventGroup = cfg.activity.festival_event.getGroup(this.activityId);
            for (let eventData of eventGroup) {
                if (eventData.event_id == eventId) {
                    return eventData;
                }
            }
            return null;
        }

        public static getProposalData(proposalId: number): lqc.Sheet_Activity_FestivalProposal {
            let proposalGroup = cfg.activity.festival_proposal.getGroup(this.activityId);
            for (let proposalData of proposalGroup) {
                if (proposalData.proposal_id == proposalId) {
                    return proposalData;
                }
            }
            return null;
        }
        public static getEndingData(groupId: number, endingId: number): lqc.Sheet_Activity_FestivalEnding {
            let endingGroup = cfg.activity.festival_ending.getGroup(groupId);
            for (let endingData of endingGroup) {
                if (endingData.ending_id == endingId) {
                    return endingData;
                }
            }
            return null;
        }

        /**
         * 剩余时间≥1天：显示4209（{0}天后解锁）
         * 1天＞剩余时间≥1小时：显示4210（{0}小时后解锁）
         * 1小时＞剩余时间：显示4214（{0}分钟后解锁）
         * 时间向下取整，小于1分钟时特殊显示一分钟
         * @param seconds 传入秒数
         * @param isLastWeek 是否是最后一周,如果是最后一周需要特殊显示 
         * @returns 
         */
        public static getFreshTimeText(seconds: number, isLastWeek: boolean): string {
            let timeString = "";
            let date = new common.TimeConvert(seconds);
            let day = date.getDays();
            let hour = date.getHours();
            let minute = date.getMinutes();
            let startId = isLastWeek ? 4272 : 4212;
            if (day > 0) {
                timeString = game.Tools.strOfLocalization(startId, [day.toString()]);
            }
            else if (date.getHours() > 0) {
                timeString = game.Tools.strOfLocalization(startId + 1, [hour.toString()]);
            }
            else {
                if (minute == 0) {
                    minute = minute + 1;
                }
                timeString = game.Tools.strOfLocalization(startId + 2, [minute.toString()]);
            }
            return timeString;
        }

        /**
         * 剩余时间≥1天：显示4209（{0}天后解锁）
         * 1天＞剩余时间≥1小时：显示4210（{0}小时后解锁）
         * 1小时＞剩余时间：显示4214（{0}分钟后解锁）
         * 时间向下取整，小于1分钟时特殊显示一分钟
         * @param seconds 
         * @returns 
         */
        public static getLockTimeText(seconds: number): string {
            let timeString = "";
            let date = new common.TimeConvert(seconds);
            let day = date.getDays();
            let hour = date.getHours();
            let minute = date.getMinutes();

            if (day > 0) {
                timeString = game.Tools.strOfLocalization(4209, [day.toString()]);
            }
            else if (date.getHours() > 0) {
                timeString = game.Tools.strOfLocalization(4210, [hour.toString()]);
            }
            else {
                if (minute == 0) {
                    minute = minute + 1;
                }
                timeString = game.Tools.strOfLocalization(4211, [minute.toString()]);
            }
            return timeString;
        }

        constructor() {
            super(new ui.lobby.activity_24ba.activity_24baUI());
            UI_Activity_24ba.Inst = this;
        }

        public static haveRedPoint(): boolean {
            if (!this.Inst) return false;
            if (BA_Page_Task.Inst.haveRedPoint() || BA_Page_Reward.Inst.haveRedPoint() || UI_Activity_24ba_Upgrade.haveRedPoint()) {
                return true;
            }
            return false;
        }
        //#endregion

        //#region properties
        private bgMain: Laya.Image;
        private bgMain2: Laya.Image;
        private containerTopRight: ContianerTopRight;
        private container_right: Laya.Sprite;

        // right部分
        private btnTask: Laya.Button;
        private btnReward: Laya.Button;
        // private btnMatch: Laya.Button;
        // private btnSpot: Laya.Button;
        private btnUpgrade: Laya.Button;

        // 左上角 提案计数
        private labelApplyCount: Laya.Label;
        private labelApplyDesc: Laya.Label;

        // 右上角升级
        private bubbleLevel: Laya.Sprite;
        private listLabelTarget: Laya.Label[];

        private pages: Array<BA_Page_Base> = [];
        // private btnMusic: Laya.Button;

        private lockStateDic: basic.Dictionary<ELockState, number> = new basic.Dictionary<ELockState, number>();

        public listTask: ItemTask[];
        private eventCount: number = 2; // 固定的事件格子数量
        private proposalCount: number = 4; // 固定的的提案格子

        public sortProposalList: ISortProposal[];
        private waitingShowYindao: boolean; // 首次剧情之后标记该值，下次进入打开引导
        // private musicMuted: boolean;
        private greetingMap: Object = {};
        private audioId: number;

        private itemStartTime: number;
        public ui: ui.lobby.activity_24ba.activity_24baUI;
        public endCg: EndCg;
        private updateDelta: boolean = true;
        //#endregion

        private effectBg: Laya.Scene;
        private effectBgAnim: Catfood.CAnimator;
        public pageShowCount = 0;

        public addLock(state: ELockState) {
            this.lockStateDic.set(state, 1);
        }
        public haveLock(state?: ELockState): boolean {
            if (!state) return this.lockStateDic.getCount() != 0;
            else return this.lockStateDic.has(state);
        }
        public removeLock(state: ELockState) {
            this.lockStateDic.remove(state);
        }

        public onCreate() {
            this.ui = this.me as ui.lobby.activity_24ba.activity_24baUI;
            const topLeft = this.me.getChildByName('top_left') as Laya.Sprite;
            // this.btnMusic = topLeft.getChildByName('btn_music') as Laya.Button;
            // this.btnMusic.clickHandler = new Laya.Handler(this, () => {
            //     if (this.haveLock()) return;
            //     this.onMusicChange(!this.musicMuted);
            // });
            (topLeft.getChildByName('btn_help') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                UI_Activity_24ba_Rule.Inst.show();
            });
            (topLeft.getChildByName('btn_return') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                this.close();
            });

            const topRight = this.me.getChildByName('top_right') as Laya.Sprite;
            this.containerTopRight = new ContianerTopRight(topRight);
            this.container_right = this.me.getChildByName('right') as Laya.Sprite;
            this.bgMain = this.me.getChildByName('bg').getChildByName('main') as Laya.Image;
            this.bgMain2 = this.me.getChildByName('bg').getChildByName('main2') as Laya.Image;


            // 提案事件区
            let mid = this.me.getChildByName('middle') as Laya.Sprite;
            this.listTask = [];
            let index = 0;
            for (; index < this.eventCount; ++index) {
                this.listTask.push(new ItemTask(mid.getChildByName(`character_${ index }`) as Laya.Sprite, index, true));
            }

            for (; index < this.eventCount + this.proposalCount; ++index) {
                this.listTask.push(new ItemTask(mid.getChildByName(`character_${ index }`) as Laya.Sprite, index, false));
            }

            // right
            const containerPage = this.me.getChildByName('container_page') as Laya.Sprite;
            this.pages.push(new BA_Page_Reward());
            this.pages.push(new BA_Page_Task());
            this.pages.forEach((value) => {
                containerPage.addChild(value.me);
            });
            this.btnUpgrade = this.container_right.getChildByName('btn_upgrade') as Laya.Button;
            this.btnReward = this.container_right.getChildByName('btn_reward') as Laya.Button;
            this.btnTask = this.container_right.getChildByName('btn_task') as Laya.Button;

            this.btnReward.clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                if (!UI_Activity.activity_is_running(BA_Page_Reward.Inst.activityId)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3944));
                    return;
                }
                view.AudioMgr.PlayAudio(Activity24BaAudio.ui_open);
                this.pages[0].doShowAnimation();
            });
            this.btnTask.clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                if (!UI_Activity.activity_is_running(BA_Page_Task.Inst.activityId)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3944));
                    return;
                }
                view.AudioMgr.PlayAudio(Activity24BaAudio.ui_open);
                this.pages[1].doShowAnimation();
            });
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                if (!UI_Activity.activity_is_running(UI_Activity_24ba_Upgrade.activityId)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3944));
                    return;
                }
                view.AudioMgr.PlayAudio(Activity24BaAudio.skill_ui_open);
                UI_Activity_24ba_Upgrade.Inst.show();
            });

            const bubbleApply = this.me.getChildByName('bubble_apply') as Laya.Sprite;
            bubbleApply.on(Laya.Event.CLICK, this, () => UI_ItemDetail.Inst.show(70000010));
            this.labelApplyCount = bubbleApply.getChildByName('count') as Laya.Label;
            this.labelApplyDesc = bubbleApply.getChildByName('desc') as Laya.Label;

            this.bubbleLevel = this.me.getChildByName('bubble_tip') as Laya.Sprite;
            this.listLabelTarget = [];
            for (let i = 0; i < UI_Activity_24ba.LevelUpItemIds.length; i++) {
                this.listLabelTarget.push(this.bubbleLevel.getChildByName(`param_${ i }`).getChildByName('count') as Laya.Label);
            }

            (this.me.getChildByName('apply') as Laya.Sprite).addChild(new UI_Activity_24ba_Apply().me);
            containerPage.addChild(new UI_Activity_24ba_Upgrade().me);
            this.endCg = new EndCg(this.me.getChildByName('cg') as Laya.Sprite);

            // this.musicMuted = !!Laya.LocalStorage.getItem(UI_Activity_24ba.activityId + 'musicMuted');
            game.LoadMgr.setImgSkin(this.bgMain, 'myres/activity_2501miaohui/bg.jpg', null, 'UI_Activity_24ba');
            game.LoadMgr.setImgSkin(this.bgMain2, 'myres/activity_2501miaohui/img_95.png', null, 'UI_Activity_24ba');

            const btn0 = this.me.getChildByName('btn_0') as Laya.Button;
            btn0.visible = false;
            //==DevDebug Start==
            btn0.visible = true;
            this.me.addChild(new UI_Activity_24ba_DevDebug().me);
            btn0.clickHandler = Laya.Handler.create(this, () => {
                UI_Activity_24ba_DevDebug.Inst.show();
            }, null, false);
            //==DevDebug End==
        }

        public show() {
            if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.BA2501_Yindao_Checked)) {
                UI_Activity_Yindao.Inst.show();
                UI_Activity_24ba.duringGuide = true;
            }
            if (app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.BA2501_LastEvent_Checked)
                && !app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.BA2501_PlayCG_Checked)) {
                this.endCg.show();
            }

            // 动画
            this.addLock(ELockState.lockAnim);
            view.AudioMgr.PlayAudio(Activity24BaAudio.activity_enter);
            this.ui.enter.play(0, false);
            Laya.timer.once(600, this, () => {
                this.removeLock(ELockState.lockAnim);
                UI_Activity_24ba_Apply.Inst.createCharacter();
                UI_Activity_24ba_Apply.Inst.createEffects();
            });
            if (!this.effectBg) {
                this.effectBg = Laya.Loader.getRes('scene/effect_25chunjie_home.ls');
                this.me.getChildByName('bg').addChild(this.effectBg);
            }
            this.effectBg.visible = true;
            this.effectBgAnim = (this.effectBg.getChildAt(1).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.effectBgAnim.Play('fx_ui_hd_023_001_e');
            this.enable = true;
            this.containerTopRight.refresh();
            this.refreshRedPoint();
            this.refreshProposalCount();
            for (let item of this.listTask) {
                item.hide();
            }

            view.AudioMgr.StopMusic(0);
            this.refreshMusicBtn();
            this.refreshEvent(true, false);
            this.refreshLevelTarget();
            this.refreshBtnState();

            this.stopBgm();
            this.playBgm();
        }

        public close() {
            this.addLock(ELockState.lockAnim);
            this.ui.close.play(0, false);
            if (this.effectBgAnim) this.effectBgAnim.Play('fx_ui_hd_023_001_l');
            Laya.timer.once(300, this, () => {
                this.removeLock(ELockState.lockAnim);
                this.enable = false;
                UI_Lobby.Inst.enable = true;
            });
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_24ba', true);
            game.LoadMgr.setImgSkin(this.bgMain, 'myres/activity_2501miaohui/bg.jpg', null, 'UI_Activity_24ba');
            game.LoadMgr.setImgSkin(this.bgMain2, 'myres/activity_2501miaohui/img_95.png', null, 'UI_Activity_24ba');
            this.itemStartTime = Laya.timer.currTimer;
            Laya.stage.on(BA_Page_EventId.DO_SHOW_ANIMATION, this, this.onPageDoShowAnimation);
            Laya.stage.on(BA_Page_EventId.DO_HIDE_ANIMATION, this, this.onPageDoHideAnimation);
        }

        public onDisable() {
            this.stopBgm();
            Laya.timer.clearAll(this);
            view.BgmListMgr.PlayLobbyBgm();
            game.TempImageMgr.setUIEnable('UI_Activity_24ba', false);
            // Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_24ba.atlas'));
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_2501miaohui.atlas'));
            Laya.stage.off(BA_Page_EventId.DO_SHOW_ANIMATION, this, this.onPageDoShowAnimation);
            Laya.stage.off(BA_Page_EventId.DO_HIDE_ANIMATION, this, this.onPageDoHideAnimation);
            UI_Activity_24ba_Apply.Inst.destroyCharacter();
            UI_Activity_24ba_Apply.Inst.destroyEffects();
            this.listTask.forEach(v => v.destroyEffect());
        }

        public update() {
            let _t = (Laya.timer.currTimer - this.itemStartTime) % 2000;
            let deltaY = 0;
            if (_t <= 1000) deltaY = Laya.Ease.quadInOut(_t, 0, 1, 1000) * -20;
            else deltaY = (1 - Laya.Ease.quadInOut(_t - 1000, 0, 1, 1000)) * -20;
            deltaY = this.updateDelta ? deltaY : 0;
            this.listTask.forEach((value: ItemTask) => {
                value.updateY(deltaY);
            });
        }


        // 红点刷新
        public refreshRedPoint(pageIndex: number = -1) {
            if (pageIndex == 2 || pageIndex < 0) {
                (this.btnReward.getChildByName('redpoint') as Laya.Sprite).visible = BA_Page_Reward.Inst.haveRedPoint();
            }
            if (pageIndex == 3 || pageIndex < 0) {
                (this.btnTask.getChildByName('redpoint') as Laya.Sprite).visible = BA_Page_Task.Inst.haveRedPoint();
            }

            (this.btnUpgrade.getChildByName('redpoint') as Laya.Sprite).visible = UI_Activity_24ba_Upgrade.haveRedPoint();

        }

        public refreshBtnState() {
            game.Tools.setGray(this.btnReward, !UI_Activity.activity_is_running(BA_Page_Reward.Inst.activityId));
            game.Tools.setGray(this.btnTask, !UI_Activity.activity_is_running(BA_Page_Task.Inst.activityId));
            game.Tools.setGray(this.btnUpgrade, !UI_Activity.activity_is_running(UI_Activity_24ba_Upgrade.activityId));
        }

        public refreshEvent(refreshTask: boolean = true, showPop: boolean = true) {
            let used: Object = {};
            this.sortProposalList = [];
            if (UI_Activity_24ba.eventList) {
                const eventList = UI_Activity_24ba.duringGuide ? [] : UI_Activity_24ba.eventList;
                for (let event of eventList) {
                    let eventData = UI_Activity_24ba.getEventData(event);
                    if (eventData) {
                        let pos = eventData.position - 1;
                        if (!used[pos]) {
                            used[pos] = 1;
                            if (refreshTask)
                                this.listTask[pos].show(event, null, showPop);
                            this.sortProposalList.push({ pos: pos, id: event, dataId: event, isEvent: true });
                        } else {
                            used[pos]++;
                        }
                    }
                }
            }

            if (UI_Activity_24ba.proposalList) {
                const proposalList = UI_Activity_24ba.duringGuide ? [
                    { id: 0, proposal_id: 20009, pos: 2 }
                ] : UI_Activity_24ba.proposalList;
                for (let proposal of proposalList) {
                    let proposalData = UI_Activity_24ba.getProposalData(proposal.proposal_id);
                    if (proposalData && proposal.pos) {
                        let pos = proposal.pos - 1 + this.eventCount;
                        if (!used[pos]) {
                            used[pos] = 1;
                            if (refreshTask)
                                this.listTask[pos].show(proposal.proposal_id, proposal.id, showPop);
                            this.sortProposalList.push({ pos: pos, id: proposal.id, dataId: proposal.proposal_id, isEvent: false });
                        } else {
                            used[pos]++;
                        }
                    }
                }
            }
            if (refreshTask) {
                for (let i = 0; i < this.listTask.length; ++i) {
                    if (!used[i]) {
                        this.listTask[i].hide();
                    }
                }
            }

            this.sortProposalList.sort((a, b) => { return a.pos - b.pos });
        }

        // 刷新右上角数据
        public refreshLevelTarget() {
            const param = UI_Activity_24ba.getLevelUpParam(UI_Activity_24ba.activityLevel + 1);
            if (!param) {
                this.bubbleLevel.visible = false;
                return;
            }
            this.bubbleLevel.visible = true;
            for (let i = 0; i < this.listLabelTarget.length; ++i) {
                const label = this.listLabelTarget[i];
                const count = UI_Bag.get_item_count(UI_Activity_24ba.LevelUpItemIds[i]);
                const target = param[i] ? param[i] : 0;
                label.text = target.toString();
                label.graphics.clear();
                if (target <= count) {
                    const dy = GameMgr.client_language == "chs" || GameMgr.client_language == "chs_t" ? 17 : 15;
                    label.graphics.drawLine(0, dy, label.trueWidth, dy, "#c38236", 1);
                }
                label.color = target <= count ? '#c38236' : '#724e40';
            }
        }

        public refreshProposalCount() {
            const { proposalCount, labelApplyCount, labelApplyDesc } = this;
            labelApplyDesc.wordWrap = false;
            labelApplyDesc.fontSize = 26;
            const proCount = UI_Activity_24ba.proposalList.length;
            const count = proCount + UI_Activity_24ba.eventList.length;
            labelApplyCount.text = game.Tools.strOfLocalization(4562, [count.toString()]);
            labelApplyDesc.text = game.Tools.strOfLocalization(proCount == 0 ? 4572 : (proCount <= proposalCount ? 4573 : 4563));

            const isMax = labelApplyDesc.trueWidth > 360;
            labelApplyDesc.fontSize = isMax ? 22 : 26;

            const isMax2 = labelApplyDesc.trueWidth > 360;
            labelApplyDesc.wordWrap = isMax2;
            labelApplyDesc.width = isMax2 ? 360 : labelApplyDesc.trueWidth;
            labelApplyDesc.y = isMax ? (isMax2 ? 45 : 61) : (isMax2 ? 45 : 57);

            labelApplyCount.fontSize = isMax2 ? 26 : 30;
            labelApplyCount.y = isMax2 ? 16 : 21;
        }

        // 返回延迟
        public showParamChange(effected_buff: number[], reward_items: game.IExecuteResult[]) {
            // Laya.timer.once(100, this, this.refreshLevelTarget);
            this.containerTopRight.showParamChange(effected_buff, reward_items);
        }

        public refreshItems() {
            this.containerTopRight.refresh();
        }

        public refreshLevel(level:number) {
            this.containerTopRight.refreshLevel(level);
        }

        private onPageDoShowAnimation(activityId: number) {
            this.pageShowCount++;
            UI_Activity_24ba.Inst.listTask.forEach(v => v.destroyEffect());
        }

        private onPageDoHideAnimation(activityId: number) {
            this.pageShowCount--;
            this.refreshRedPoint();
            if (activityId == BA_Page_ActivityId.TASK) {
                this.refreshItems();
                this.refreshEvent();
            }
            this.listTask.forEach(v => v.createEffect());
        }

        public showBuffEffect(id: number, fail2Success: boolean) {
            BuffAddedItem.create().show(id, fail2Success);
        }

        // 引导触发
        public showYindao() {
            this.listTask[3].showYindao();
        }

        // 引导用设置事件开关
        public setMidVisible(visible: boolean) {
            (this.me.getChildByName('middle') as Laya.Sprite).visible = visible;
        }


        public stopBgm() {
            if (this.audioId) {
                view.AudioMgr.StopAudio(this.audioId);
                this.audioId = 0;
            }
        }

        private playBgm() {
            // if (view.AudioMgr.musicMuted || this.musicMuted) return;
            if (view.AudioMgr.musicMuted) return;
            let audioPath = cfg.audio.audio.get(Activity24BaAudio.bgm_loop).path;
            let volume = view.AudioMgr.musicVolume;
            this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);

        }

        private refreshMusicBtn() {
            // if (this.musicMuted) {
            //     this.btnMusic.skin = game.Tools.localUISrc('myres/activity_2404ba/btn_audio_off.png');
            // } else {
            //     this.btnMusic.skin = game.Tools.localUISrc('myres/activity_2404ba/btn_audio_on.png');
            // }

        }

        private onMusicChange(state: boolean) {
            // if (state == this.musicMuted) return;
            // this.musicMuted = state;
            // if (this.musicMuted) {
            //     this.stopBgm();
            //     Laya.LocalStorage.setItem(UI_Activity_24ba.activityId + 'musicMuted', '1');
            // } else {
            //     this.playBgm();
            //     Laya.LocalStorage.removeItem(UI_Activity_24ba.activityId + 'musicMuted');
            // }
            // this.refreshMusicBtn();
        }

        public refreshPreGuideState(type: E_Act_Yindao_Type) {

        }

        public refreshGuideState(type: E_Act_Yindao_Type) {
            switch (type) {
                case E_Act_Yindao_Type.ba2501_2: {
                    this.updateDelta = false;
                    break;
                }
                case E_Act_Yindao_Type.ba2501_3: {
                    this.updateDelta = true;
                    UI_Activity_24ba_Apply.Inst.show(0, true);
                    break;
                }
                case E_Act_Yindao_Type.ba2501_4: {
                    this.sortProposalList.length = 0;
                    this.listTask.forEach(v => v.hide());
                    break;
                }
                case E_Act_Yindao_Type.ba2501_6: {
                    UI_Activity_24ba_Apply.Inst.close();
                    break;
                }
            }
        }

        public onGuideEnd() {
            UI_Activity_24ba.duringGuide = false;
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.BA2501_Yindao_Checked, 1);
            UI_Activity_24ba_Rule.Inst.show();
            this.refreshEvent(true, true);
        }
    }

    // 顶部数值栏
    class TopParam {
        private static instances: TopParam[] = [];
        private me: Laya.Sprite;
        private labelCount: Laya.Label;
        private change: Laya.Sprite;
        private changeCount: Laya.Label;
        // private changeIcon: Laya.Image;
        // private changeAdapt: common.SpriteAdapter;
        private bar: Laya.Sprite;// 进度条，货币无

        private effectRoot: Laya.Sprite; // 特效节点

        private itemId: number;
        private count: number = 0;
        private effectTuoWei: game.UIEffect;
        private effectBorder: game.UIEffect;
        // 特效时长 unity版60帧
        private effectStayFrame: number = 20;
        private effectFlyFrame: number = 25;

        private levelRequires: { [level: string]: number };
        private lastLevel: number = -1;

        constructor(me: Laya.Sprite, itemId: number) {
            TopParam.instances.push(this);
            this.me = me;
            this.labelCount = me.getChildByName('count') as Laya.Label;
            this.change = me.getChildByName('change') as Laya.Sprite;
            this.changeCount = this.change.getChildByName('count') as Laya.Label;
            // this.changeIcon = this.change.getChildByName('icon') as Laya.Image;
            // this.changeAdapt = new common.SpriteAdapter(this.changeIcon, this.changeCount, SpriteAdapterType.RIGHT2LEFT, 1);
            if ((me.getChildByName('bar') as Laya.Sprite)) {
                this.bar = (me.getChildByName('bar').getChildAt(0) as Laya.Sprite);
                this.bar.width = 0;
            }
            this.effectRoot = me.getChildByName('effect') as Laya.Sprite;
            this.itemId = itemId;
            (me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_24ba.Inst.haveLock()) return;
                UI_ItemDetail.Inst.show(this.itemId);
            });
        }

        public show() {
            if (this.lastLevel < 0)
                this.lastLevel = UI_Activity_24ba.activityLevel;
            const count = UI_Bag.get_item_count(this.itemId);

            this.labelCount.text = `${ count }`;
            this.change.visible = false;
            this.playBarAnim(count - this.count);
        }

        // 1次1.55s(45/60 + 0.8) 2次2.65s
        public showChangeAnim(changeCount: number, skillAdd: number, startGlobalPos: Laya.Point) {
            this.destroyTuoWei();
            this.change.visible = true;
            if (changeCount > 0) {
                this.effectTuoWei = game.FrontEffect.Inst.create_ui_effect(
                    this.effectRoot, `scene/effect_25chunjie_tuowei0${ UI_Activity_24ba.TopParamEffectIndex[this.itemId] }.lh`, new Laya.Point(), 1);
                this.me.globalToLocal(startGlobalPos, false);
                this.effectRoot.pos(startGlobalPos.x, startGlobalPos.y);
                Laya.timer.once(this.effectStayFrame / 60 * 1000, this, () => {
                    // labelCount是右对齐+上下居中
                    Laya.Tween.to(this.effectRoot, { x: 137, y: 54 }, this.effectFlyFrame / 60 * 1000);
                });
            }
            if (this.count + changeCount < 0) {
                changeCount = -this.count;
            }
            // 如果是+ 并且有buff，则播放两次动画
            if (changeCount <= 0) {
                skillAdd = 0;
            }

            // this.changeIcon.alpha = 0;
            this.changeCount.alpha = 0;
            // 延迟一个固定的特效飞的时间 45帧
            Laya.timer.once((this.effectStayFrame + this.effectFlyFrame) / 60 * 1000, this, () => {
                this.playChangeAnim(changeCount - skillAdd, skillAdd > 0 ? Laya.Handler.create(this, () => {
                    Laya.timer.once(300, this, () => {
                        this.playChangeAnim(skillAdd, null, true);
                    });
                }) : null);
            });

        }

        // 实际播放动画接口,1次0.8s
        private playChangeAnim(changeCount: number, complete?: Laya.Handler, isSkill?: boolean) {
            if (isSkill) {
                BuffAddedItem.create().show(this.itemId, false);
            }
            this.destroyBorder();
            if (this.itemId != UI_Activity_24ba.activityData.funds_id) {
                view.AudioMgr.PlayAudio(Activity24BaAudio.add_point);
                this.effectBorder = game.FrontEffect.Inst.create_ui_effect(this.me, `scene/effect_25chunjie_shuzhi.lh`, new Laya.Point(2, 4), 1);
            }
            this.change.visible = true;
            if (this.count + changeCount < 0) {
                changeCount = -this.count;
            }

            const havaBarAnim = !!this.bar;
            this.playBarAnim(changeCount, true, havaBarAnim ? complete : null);
            this.labelCount.text = `${ this.count }`;

            this.changeCount.text = (changeCount > 0 ? '+' : '-') + Math.abs(changeCount);
            this.changeCount.color = changeCount <= 0 ? '#fffdc7' : '#35ea1c';

            this.changeCount.alpha = 0;
            Laya.Tween.to(this.changeCount, { alpha: 1 }, 50);
            Laya.Tween.to(this.changeCount, { alpha: 0 }, 83, null, havaBarAnim ? null : complete, 700);

        }

        private playBarAnim(changeCount: number, anim: boolean = true, complete?: Laya.Handler) {
            const newCount = this.count + changeCount;
            if (this.bar) {
                const originW = 134;
                const [curRequire, nextRequire] = this.getLevelUpParam(UI_Activity_24ba.activityLevel);
                const rate = Math.min((newCount - curRequire) / (nextRequire - curRequire), 1);
                const width = !nextRequire ? originW : Math.max(rate * originW, 4);
                if (anim) {
                    if (this.lastLevel < UI_Activity_24ba.activityLevel) {
                        this.lastLevel++;
                        Laya.Tween.to(this.bar, { width: originW }, 500, null, Laya.Handler.create(this, () => {
                            this.bar.width = 0;
                            this.playBarAnim(0, anim, complete);
                        }));
                    } else {
                        this.lastLevel = UI_Activity_24ba.activityLevel;
                        Laya.Tween.to(this.bar, { width: width }, 500, null, complete);
                    }
                } else {
                    this.bar.width = width;
                    this.lastLevel = UI_Activity_24ba.activityLevel;
                    complete && complete.run();
                }
            } else {
                this.lastLevel = UI_Activity_24ba.activityLevel;
                complete && complete.run();
            }
            this.count = newCount;
        }

        // 获取升级所需
        private getLevelUpParam(level: number) {
            if (!this.levelRequires) {
                this.levelRequires = {};
                const levelRequires = this.levelRequires;
                const levels = cfg.activity.festival_level.getGroup(UI_Activity_24ba.activityId);
                for (let i = 0; i < levels.length; i++) {
                    const ele = levels[i];
                    if (ele.level_require) {
                        const dataArr = ele.level_require.split(',').map(v => v.split('-').map(Number));
                        const data = dataArr.find(v => v[0] == this.itemId);
                        if (data && data.length >= 2) levelRequires[ele.level] = data[1];
                    }
                }
            }
            return [this.levelRequires[level] || 0, this.levelRequires[level + 1] || 0];
        }

        public closeChange() {
            this.change.visible = false;
            this.destroyTuoWei();
            this.destroyBorder();
        }

        private destroyTuoWei() {
            if (this.effectTuoWei) {
                this.effectTuoWei.destory();
                this.effectTuoWei = null;
            }
        }

        private destroyBorder() {
            if (this.effectBorder) {
                this.effectBorder.destory();
                this.effectBorder = null;
            }
        }
    }

    class BuffAddedItem {
        private static template: BuffAddedItem;
        private static index: number = 0;
        public me: Laya.Sprite;
        public icon: Laya.Image;
        public desc: Laya.Label;
        static create() {
            const item: BuffAddedItem = Laya.Pool.getItemByCreateFun("BuffAddedItem", () => {
                const ui = (BuffAddedItem.template.me.scriptMap["capsui.UICopy"] as capsui.UICopy).getNodeClone();
                return new BuffAddedItem(ui);
            });
            item.me.visible = true;
            return item;
        }
        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.icon = me.getChildByName('icon') as Laya.Image;
            this.desc = me.getChildByName('desc') as Laya.Label;
        }

        show(id: number, fail2Success: boolean) {
            this.me.alpha = 0;
            this.me.pos(200, BuffAddedItem.index * 104);
            this.icon.skin = game.Tools.localUISrc(fail2Success ? 'myres/activity_2501miaohui/img_72.png' : UI_Activity_24ba.ItemIcons[id]);
            this.desc.text = game.Tools.strOfLocalization(fail2Success ? 4246 : 4266);
            Laya.Tween.to(this.me, { x: 0, alpha: 1 }, 150, null, Laya.Handler.create(this, this.hide), BuffAddedItem.index * 50, true);
            this.me.visible = true;
            BuffAddedItem.index++;
        }

        hide() {
            Laya.Tween.to(this.me, { x: 200, alpha: 0 }, 150, null, Laya.Handler.create(this, this.recover), 1000, true);
        }

        recover() {
            if (!BuffAddedItem.template)
                BuffAddedItem.template = this;
            else
                BuffAddedItem.index--;
            this.me.visible = false;
            Laya.Pool.recover("BuffAddedItem", this);
        }
    }

    //顶部条
    class ContianerTopRight {
        private me: Laya.Sprite;
        private change: Laya.Sprite; // 货币变化相关
        private itemParamCurrency: TopParam;
        private listParam: TopParam[] = [];
        private levelScale: number[] = [
            0.32, 0.32, 0.32, 0.32, 0.32, 0.32, 0.32, 0.32,
            0.35, 0.35, 0.35, 0.35, 0.35, 0.35,
            0.4, 0.4, 0.4, 0.4
        ];
        private level: Laya.Image;

        private effectStartPos: Laya.Point = new Laya.Point(1451, 610);
        private effectDeltaY: number = 86;
        constructor(me: Laya.Sprite) {
            this.me = me;
            const currency = this.me.getChildByName('currency');
            this.change = currency.getChildByName('change') as Laya.Sprite;
            this.itemParamCurrency = new TopParam(currency as Laya.Sprite, UI_Activity_24ba.activityData.funds_id);
            for (let i = 0; i < UI_Activity_24ba.LevelUpItemIds.length; ++i) {
                this.listParam.push(new TopParam(this.me.getChildByName(`param_${ i }`) as Laya.Sprite, UI_Activity_24ba.LevelUpItemIds[i]));
            }
            this.level = this.me.getChildByName('level') as Laya.Image;

            new BuffAddedItem(this.me.getChildByName('buff').getChildByName('template') as Laya.Sprite).recover();
            this.closeChange();

        }

        public refresh() {
            for (let itemParam of this.listParam) {
                itemParam.show();
            }
            this.refreshCurrency();
            this.refreshLevel(UI_Activity_24ba.activityLevel);
        }

        private refreshCurrency() {
            if (!UI_Activity_24ba.activityData) return;
            this.itemParamCurrency.show();
        }

        public refreshLevel(level: number) {
            let data = UI_Activity_24ba.getLevelData(level);
            if (!data) return;
            this.level.scale(this.levelScale[level], this.levelScale[level], true);
            game.LoadMgr.setImgSkin(this.level, `myres/activity_2501miaohui/${ data.level_res }`, null, 'UI_Activity_24ba');
        }

        public showParamChange(effected_buff: number[], rewards: game.IExecuteResult[]) {
            let baiziAdd: number = 0;
            let muyueAdd: number = 0;
            if (effected_buff) {
                if (effected_buff.indexOf(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.baizi]) != -1) {
                    baiziAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.baizi]);
                }
                if (effected_buff.indexOf(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.muyue]) != -1) {
                    muyueAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.muyue]);
                }
            }

            const showParams: TopParam[] = [];
            let startY = this.effectStartPos.y;
            for (const item of rewards) {
                const index = UI_Activity_24ba.LevelUpItemIds.indexOf(item.id);
                if (index >= 0) {
                    showParams.push(this.listParam[index]);
                    this.listParam[index].showChangeAnim(item.count, muyueAdd, new Laya.Point(this.effectStartPos.x, startY));
                } else if (item.id == UI_Activity_24ba.activityData.funds_id) {
                    this.itemParamCurrency.showChangeAnim(item.count, baiziAdd, new Laya.Point(this.effectStartPos.x, startY));
                }
                if (item.count > 0) startY += this.effectDeltaY;
            }
            Laya.timer.once(45 / 60 * 1000, this, () => {
                UI_Activity_24ba.Inst.refreshLevelTarget();
                if (UI_Activity_24ba_Apply.Inst.levelUp) {
                    this.listParam.forEach(v => !showParams.includes(v) && v.show());
                } 
            });
            Laya.timer.once(effected_buff && effected_buff.length > 0 ? 2800 : 1600, this, this.closeChange);
        }

        private closeChange() {
            this.change.visible = false;
            for (let item of this.listParam) {
                item.closeChange();
            }
        }
    }

    class ItemTask {
        private me: Laya.Sprite;
        private headContainer: Laya.Sprite;
        private head: Laya.Image;
        private tribute: Laya.Button;
        public id: number;
        private proposalServerId: number;
        private isEvent: boolean; // 事件或提案
        private index: number;
        private originY: number;
        private locking: boolean;
        private mouseOver: boolean;
        private effectLight: game.UIEffect;

        constructor(me: Laya.Sprite, index: number, is_event: boolean) {
            this.me = me;
            this.index = index;
            this.isEvent = is_event;
            this.tribute = this.me.getChildByName('tribute') as Laya.Button;
            const head = this.headContainer = this.me.getChildByName('head') as Laya.Sprite;
            this.originY = head.y;
            this.head = head.getChildByName('head') as Laya.Image;
            const headBtn = head.getChildByName('btn') as Laya.Button;
            this.tribute.clickHandler = headBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (!this.id) return UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4572));
                for (let i = 0; i < UI_Activity_24ba.Inst.sortProposalList.length; ++i) {
                    if (this.id == UI_Activity_24ba.Inst.sortProposalList[i].dataId) {
                        UI_Activity_24ba_Apply.Inst.show(i, true);
                        return;
                    }
                }
            });
            // headBtn.on(Laya.Event.MOUSE_OVER, this, () => this.mouseOver = true);
            headBtn.on(Laya.Event.MOUSE_DOWN, this, () => this.mouseOver = true);
            headBtn.on(Laya.Event.MOUSE_UP, this, () => this.mouseOver = false);
            headBtn.on(Laya.Event.MOUSE_OUT, this, () => this.mouseOver = false);
        }

        public show(id: number, proposalServerId?: number, showPop: boolean = true) {

            if (this.id == id && this.proposalServerId == proposalServerId) return;
            this.locking = true;
            this.proposalServerId = proposalServerId;
            this.id = id;
            if (!this.headContainer.visible) {
                this.headContainer.visible = true;
                this.changeHead();
                if (showPop) {
                    this.headContainer.scale(0, 0);
                    Laya.Tween.to(this.headContainer, { scaleX: 1.07, scaleY: 1.07 }, 200, Laya.Ease.quadOut, Laya.Handler.create(this, () => {
                        Laya.Tween.to(this.headContainer, { scaleX: 1, scaleY: 1 }, 50, Laya.Ease.quadIn, Laya.Handler.create(this, () => {
                            this.locking = false;
                        }))
                    }));
                } else this.locking = false;
            } else {
                this.changeHead();
                this.locking = false;
                // UIBase.anim_pop_hide(this.headContainer, new Laya.Handler(this, () => {
                //     this.changeHead();
                //     UIBase.anim_pop_out(this.headContainer, new Laya.Handler(this, () => {
                //         this.locking = false;
                //     }));
                // }));
            }

        }

        private changeHead() {
            if (this.isEvent) {
                let data = UI_Activity_24ba.getEventData(this.id);
                game.LoadMgr.setImgSkin(this.head, data.client_icon, null, 'UI_Activity_24ba');
            } else {
                let data = UI_Activity_24ba.getProposalData(this.id);
                game.LoadMgr.setImgSkin(this.head, data.client_icon, null, 'UI_Activity_24ba');
            }
            this.tribute.visible = true;
            if (!this.isEvent) {
                const skins = [0, 0, 100, 101, 102, 103];
                this.tribute.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + skins[this.index] + '.png');
            } else {
                this.createEffect();
            }
        }

        public hide() {
            this.headContainer.visible = false;
            this.id = 0;
            this.proposalServerId = null;
            this.tribute.visible = !this.isEvent;
            if (!this.isEvent) {
                this.tribute.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_97.png');
            }
            this.destroyEffect();
        }

        public showYindao() {
            game.LoadMgr.setImgSkin(this.head, 'extendRes/emo/activity/1.png', null, 'UI_Activity_24ba');
            this.headContainer.visible = true;
        }

        public updateY(deltaY: number) {
            if (this.mouseOver) return;
            this.headContainer.y = this.originY + deltaY;
        }

        public createEffect() {
            if (!this.isEvent) return;
            if (this.effectLight) return;
            if (!this.tribute.visible) return;
            if (UI_Activity_24ba.Inst.pageShowCount) return;
            this.effectLight = game.FrontEffect.Inst.create_ui_effect(this.tribute, 'scene/effect_25chunjie_item.lh', new Laya.Point(0, 80), 1);
        }

        public destroyEffect() {
            if (!this.effectLight) return;
            this.effectLight.destory();
            this.effectLight = null;
        }
    }

    class EndCg {
        private me: Laya.Sprite;
        private bg: Laya.Image;
        private btnBack: Laya.Button;
        private maozhua: Laya.Image;
        private chat: UI_Character_Chat;
        private chatId: number;

        private showBtn: boolean;
        private playEnd: boolean;
        private lock: boolean;
        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.bg = me.getChildByName('bg') as Laya.Image;
            this.btnBack = me.getChildByName('btn_back') as Laya.Button;
            this.btnBack.clickHandler = new Laya.Handler(this, this.hide);
            const chat = me.getChildByName('chat') as Laya.Sprite;
            const name = chat.getChildByName('name') as Laya.Label;
            const nameBg = chat.getChildByName('nameBg') as Laya.Image;
            this.maozhua = chat.getChildByName('maozhua') as Laya.Image;
            nameBg.width = name.trueWidth + 135;
            this.chat = new UI_Character_Chat(chat);
            this.bg.on(Laya.Event.CLICK, this, () => {
                if (this.lock) return;
                if (!this.showBtn) return this.showChat();
                if (!this.playEnd) return;
                this.hide();
            });
            this.hide();
        }

        public show() {
            this.lock = true;
            this.me.alpha = 0;
            Laya.Tween.to(this.me, { alpha: 1 }, 300, Laya.Ease.linearNone, Laya.Handler.create(this, () => this.lock = false));
            this.showBtn = false;
            this.playEnd = false;
            this.maozhua.visible = false;
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/cg.jpg', null, 'UI_Activity_24ba');
            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.BA2501_PlayCG_Checked, 1);
            this.me.visible = true;
        }

        public hide() {
            if (this.chatId) {
                view.AudioMgr.StopAudio(this.chatId);
                this.chatId = 0;
                this.chat.close(true);
            }
            this.lock = true;
            Laya.Tween.to(this.me, { alpha: 0 }, 300, Laya.Ease.linearNone, Laya.Handler.create(this, () => {
                this.lock = false;
                this.me.visible = false;
                this.btnBack.visible = false;
                this.chat.me.visible = false;
            }));
        }

        private showChat() {
            this.showBtn = true;
            this.btnBack.visible = true;
            this.chat.me.visible = true;
            const group = cfg.voice.event.getGroup(3);
            const data = group.find(v => v.type == 'end');
            this.chat.show(data['words_' + GameMgr.client_language]);
            const volume = view.AudioMgr.yuyinVolume * data.volume_fix;
            this.chatId = view.AudioMgr.PlaySound(data.path, volume, Laya.Handler.create(this, () => {
                this.playEnd = true;
                this.maozhua.visible = true;
                this.chatId = 0;
            }));
        }
    }

    const enum ELockState { lockAnim };


    export interface ISortProposal { pos: number, id: number, dataId: number, isEvent: boolean };
}