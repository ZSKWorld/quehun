/**
* 24ba提案界面
*/
module uiscript {
    const enum E24baApplyEvent {
        PlayAnim = "PlayAnim",
    }
    const enum E24baApplyAnimName {
        apply_enter = 'apply_enter',
        apply_close = 'apply_close',
        big_success_show = 'big_success_show',
        success_show = 'success_show',
        big_success_hide = 'big_success_hide',
        success_hide = 'success_hide',
        fail_show = 'fail_show',
        fail_hide = 'fail_hide',
        apply_enter01 = 'apply_enter01',
        apply_switch_R = 'apply_switch_R',
        apply_switch01_R = 'apply_switch01_R',
        apply_switch_L = 'apply_switch_L',
        apply_switch01_L = 'apply_switch01_L',
        apply_close01 = 'apply_close01',
        level_up_show = 'level_up_show',
        fail2success = 'fail2success',
        level_up_hide = 'level_up_hide',
    }
    // 选项或结局旁边的箭头
    class ContainerBuff {
        private me: Laya.Sprite;
        private buffList: Array<{ me: Laya.Sprite, icon: Laya.Image, arrowList: Laya.Image[], originY: number }> = [];

        constructor(me: Laya.Sprite) {
            this.me = me;
            for (let i = 0; i < 2; ++i) {
                let buff = this.me.getChildByName('buff_' + i) as Laya.Sprite;
                let arrowList: Laya.Image[] = [];
                for (let j = 0; j < 1; ++j) {
                    arrowList.push(buff.getChildByName('arrow_' + j) as Laya.Image);
                }
                this.buffList.push({ me: buff, icon: buff.getChildByName('icon') as Laya.Image, arrowList, originY: buff.y });
            }
        }
        public show(data: lqc.Sheet_Activity_FestivalEnding) {
            if (!data) {
                this.me.visible = false;
                return;;
            }
            this.me.visible = true;
            const buffArr = ContainerBuff.getBuffData(data);
            for (let i = 0; i < this.buffList.length; i++) {
                const element = buffArr[i];
                if (element) this.setBuffInfo(i, element.id, element.count);
                else this.buffList[i].me.visible = false;
            }
            if (buffArr.length == 1) {
                this.buffList[0].me.y = (this.buffList[1].originY + this.buffList[0].originY) / 2;
            } else {
                this.buffList[0].me.y = this.buffList[0].originY;
            }
        }
        private setBuffInfo(index: number, itemId: number, count: number) {
            let buff = this.buffList[index];
            if (!buff) return;
            buff.me.visible = true;
            buff.icon.skin = game.Tools.localUISrc(UI_Activity_24ba.BuffLightSkins[itemId]);
            let arrowCount = Math.ceil(Math.abs(count) / UI_Activity_24ba.activityData.arrow_amount);

            for (let i = 0, n = buff.arrowList.length; i < n; ++i) {
                if (count > 0) {
                    buff.arrowList[i].skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (arrowCount > 1 ? 27 : 29) + '.png');
                } else {
                    buff.arrowList[i].skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (arrowCount > 1 ? 117 : 26) + '.png');
                }
            }
        }

        public static getBuffData(data: lqc.Sheet_Activity_FestivalEnding) {
            const result: { id: number, count: number }[] = [];
            if (!data) return result;
            if (data.funds > 0) {
                result.push({ id: UI_Activity_24ba.activityData.funds_id, count: data.funds });
            }
            if (data.item_plus) {
                let plusItems = data.item_plus.split(',');
                for (let item of plusItems) {
                    let info = item.split('-');
                    result.push({ id: Number(info[0]), count: Number(info[1]) });
                }
            }
            if (data.funds < 0) {
                result.push({ id: UI_Activity_24ba.activityData.funds_id, count: data.funds });
            }
            if (data.item_minus) {
                let minusItems = data.item_minus.split(',');
                for (let item of minusItems) {
                    let info = item.split('-');
                    result.push({ id: Number(info[0]), count: -Number(info[1]) });
                }
            }
            return result;
        }
    }
    class ContainerChoose {
        public me: Laya.Sprite;
        private desc: Laya.Label;
        private btn: Laya.Button;
        private buffParent: ContainerBuff;
        private fundEnough: boolean = true;
        private index: number; // 选项index

        constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.btn = me.getChildByName('btn') as Laya.Button;
            this.desc = this.btn.getChildByName('desc') as Laya.Label;
            this.desc.on(Laya.Event.CHANGE, this, this.refreshDescSize);
            this.buffParent = new ContainerBuff(me.getChildByName('buff') as Laya.Sprite);
            this.index = index;
            this.btn.clickHandler = new Laya.Handler(this, this.onBtnClick);

        }
        private refreshDescSize() {
            const label = this.desc;
            label.width = 470;
            label.scale(0.85, 0.85);
            label.wordWrap = false;
            const tw = label.trueWidth;
            if (tw > 400) {
                const rate1 = 30 / 36;
                if (tw * rate1 > 400) {
                    const rate2 = 0.85 * 26 / 36;
                    label.scale(rate2, rate2);
                    label.width = 400 / rate2;
                    label.wordWrap = true;
                } else {
                    const scale = 400 / tw * 0.85;
                    label.scale(scale, scale);
                    label.width = 400 / scale;
                }
            }
		}

        public show(strId: number, is_event: boolean, groupId: number) {
            this.desc.text = UI_Activity_24ba.duringGuide ? game.Tools.strOfLocalization(strId) : game.Tools.eventStrOfLocalization(strId);

            let dataList = cfg.activity.festival_ending.getGroup(groupId);
            this.fundEnough = true;
            if (!UI_Activity_24ba.duringGuide && dataList && dataList.length == 1) {
                this.fundEnough = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id) + dataList[0].funds >= 0;
                this.buffParent.show(dataList[0]);
            } else {
                this.buffParent.show(null);
            }
        }

        private onBtnClick() {
            if (UI_Activity_24ba_Apply.Inst.haveLock()) return;

            if (!this.fundEnough) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4569));
                return;
            }

            UI_Activity_24ba_Apply.Inst.onApplyChooseClick(this.index);
        }

        public showYindao(str: string) {
            this.desc.text = str;
            this.buffParent.show(null);
        }
    }

    class PageApply {
        public me: Laya.Sprite;
        private content: Laya.Panel;
        private contentApply: Laya.Label;

        private chooseParent: Laya.Sprite;
        private listChooseContainer: ContainerChoose[];
        private effectParticle: game.UIEffect;
        private isEvent: boolean;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.content = this.me.getChildByName('info').getChildByName('content') as Laya.Panel;
            this.contentApply = this.content.getChildByName('content') as Laya.Label;
            this.content.vScrollBarSkin = '';
            this.content.vScrollBar.elasticDistance = 350;
            this.content.vScrollBar.elasticBackTime = 250;
            this.chooseParent = this.me.getChildByName('choose') as Laya.Sprite;
            this.listChooseContainer = [];
            for (let i = 0; i < 2; ++i) {
                this.listChooseContainer.push(new ContainerChoose(this.chooseParent.getChildByName('confirm_' + i) as Laya.Sprite, i));
            }
            this.fixEnStyle();
            UI_Activity_24ba_Apply.Inst.me.on(E24baApplyEvent.PlayAnim, this, (name: E24baApplyAnimName) => {
                if (name == E24baApplyAnimName.apply_enter01) this.createEffect();
                else if (name == E24baApplyAnimName.apply_close01) this.onClose();
            });
        }

        private fixEnStyle() {
            if (GameMgr.client_language == 'en') {
                this.contentApply.fontSize = 30;

            }
        }
        public showApply(id: number, is_event: boolean) {
            this.isEvent = is_event;
            this.me.visible = true;
            let data: Partial<lqc.Sheet_Activity_FestivalEvent & lqc.Sheet_Activity_FestivalProposal>;
            if (is_event) data = UI_Activity_24ba.getEventData(id);
            else data = UI_Activity_24ba.getProposalData(id);
            this.chooseParent.visible = true;
            this.chooseParent.event('onenable');
            this.listChooseContainer[0].show(UI_Activity_24ba.duringGuide ? 4586 : data.option_text_a, is_event, data.ending_group[0]);
            this.listChooseContainer[1].show(UI_Activity_24ba.duringGuide ? 4587 : data.option_text_b, is_event, data.ending_group[1]);
            this.contentApply.color = is_event ? '#7c88a9' : '#896e50';
            this.contentApply.text = UI_Activity_24ba.duringGuide ? game.Tools.strOfLocalization(4585) : game.Tools.eventStrOfLocalization(is_event ? data.event_text : data.proposal_text);
            this.content.refresh();
            this.content.vScrollBar.elasticDistance = this.content.vScrollBar.max == 0 ? 0 : 350;
            this.createEffect();
        }

        public onSwitch(enable: boolean) {
            this.me.visible = enable;
        }

        public onSwitchBtnChange(visible: boolean) {
            this.listChooseContainer.forEach(v => v.me.visible = !visible);
        }

        public onClose() {
            if (this.effectParticle) {
                this.effectParticle.destory();
                this.effectParticle = null;
            }
        }

        private createEffect() {
            this.onClose();
            const effectName: string = this.isEvent ? 'effect_25chunjie_lanlizi' : 'effect_25chunjie_jinlizi';
            this.effectParticle = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/' + effectName + '.lh', new Laya.Point(620, 400), 1);
        }
    }

    class PageEnd {
        private me: Laya.Sprite;
        private imageResult: Laya.Image;
        private labelResultType: Laya.Label;
        private content: Laya.Panel;
        private labelContent: Laya.Label;
        private infoResult: Laya.Label;
        private infoImg1: Laya.Image;
        private infoImg2: Laya.Image;
        private containerResult: ContainerBuff;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.imageResult = this.me.getChildByName('img_result') as Laya.Image;
            this.labelResultType = this.me.getChildByName('result') as Laya.Label;
            this.content = this.me.getChildByName('content') as Laya.Panel;
            this.labelContent = this.content.getChildByName('content') as Laya.Label;
            this.content.vScrollBarSkin = '';
            this.content.vScrollBar.elasticDistance = 350;
            this.content.vScrollBar.elasticBackTime = 250;

            const infoParent = this.me.getChildByName('info');
            this.infoResult = infoParent.getChildByName('result') as Laya.Label;
            this.infoImg1 = infoParent.getChildByName('img1') as Laya.Image;
            this.infoImg2 = infoParent.getChildByName('img2') as Laya.Image;
            const confirm = infoParent.getChildByName('confirm');
            this.containerResult = new ContainerBuff(confirm.getChildByName('buff') as Laya.Sprite);
            (confirm.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_24ba_Apply.Inst.haveLock()) return;
                if (UI_Activity_24ba_Apply.Inst.info.id >= UI_Activity_24ba.maxEventId) {
                    UI_Activity_24ba.Inst.endCg.show();
                    UI_Activity_24ba_Apply.Inst.close();
                } else
                    UI_Activity_24ba_Apply.Inst.onLastApplyDone();
            });

        }
        public showEnding(optionText: number, groupId: number, endingId: number) {
            const endingData = UI_Activity_24ba.getEndingData(groupId, endingId);
            if (!endingData) return;
            this.onSwitch(true);
            this.infoResult.text = game.Tools.eventStrOfLocalization(optionText);
            const halfWidth = this.infoResult.trueWidth / 2;
            this.infoImg1.x = this.infoResult.x - halfWidth - 33;
            this.infoImg2.x = this.infoResult.x + halfWidth + 39;
            const goodEnding = endingData.ending_type == 1;
            this.imageResult.skin = game.Tools.localUISrc(`myres/activity_2501miaohui/img_${ goodEnding ? 0 : 96 }.png`);
            this.labelResultType.text = game.Tools.strOfLocalization(goodEnding ? 4259 : 4260);
            this.labelContent.text = game.Tools.eventStrOfLocalization(endingData.ending_text);
            this.containerResult.show(endingData);
            this.content.refresh();
            this.content.vScrollBar.elasticDistance = this.content.vScrollBar.max == 0 ? 0 : 350;
        }

        public onSwitch(enable: boolean) {
            this.me.visible = true;
            this.imageResult.visible = enable;
            this.content.visible = enable;
            this.labelResultType.visible = enable;
        }

        public close() {
            this.me.visible = false;
        }
    }

    class PageResult {
        public me: Laya.Sprite;
        public result: Laya.Sprite;
        public bg: Laya.Image;
        public fail: Laya.Sprite;
        public success: Laya.Sprite;
        public bigSuccess: Laya.Sprite;
        public fail2Success: Laya.Sprite;
        public tributes: {
            parent: Laya.Image,
            icon: Laya.Image,
            name: Laya.Label,
            last: Laya.Label,
            now: Laya.Label,
            added: Laya.Label
        }[] = [];

        public levelUp: Laya.Sprite;
        public levelName: Laya.Label;
        public lastLevel: Laya.Label;
        public nowLevel: Laya.Label;
        public unlockCount: Laya.Label;
        public levelBg: Laya.Image;
        public level: Laya.Image;
        private oldItemCount: { [id: string]: number } = {};
        public effects: game.UIEffect[] = [];
        constructor(me: Laya.Sprite) {
            this.me = me;
            const result = this.result = me.getChildByName('result') as Laya.Sprite;
            this.bg = result.getChildByName('bg') as Laya.Image;
            this.fail = result.getChildByName('fail') as Laya.Sprite;
            this.success = result.getChildByName('success') as Laya.Sprite;
            this.bigSuccess = result.getChildByName('big_success') as Laya.Sprite;
            this.fail2Success = this.fail.getChildByName('fail2success') as Laya.Sprite;
            for (let i = 0; i < 2; i++) {
                const tribute = result.getChildByName('tribute' + i) as Laya.Image;
                const name = tribute.getChildByName('name') as Laya.Label;
                if (GameMgr.client_language == 'jp') name.y += 1;
                else if (GameMgr.client_language == 'en') name.y += 2;
                else if (GameMgr.client_language == 'kr') name.y += 2;
                this.tributes.push({
                    parent: tribute,
                    name,
                    icon: tribute.getChildByName('icon') as Laya.Image,
                    last: tribute.getChildByName('last') as Laya.Label,
                    now: tribute.getChildByName('now') as Laya.Label,
                    added: tribute.getChildByName('added') as Laya.Label,
                })
            }

            const levelUp = this.levelUp = me.getChildByName('level_up') as Laya.Sprite;
            this.level = levelUp.getChildByName('curLevel') as Laya.Image;
            this.levelBg = levelUp.getChildByName('bg') as Laya.Image;
            const level = levelUp.getChildByName('level');
            const unlock = levelUp.getChildByName('unlock');
            this.levelName = level.getChildByName('level') as Laya.Label;
            this.lastLevel = level.getChildByName('last_level') as Laya.Label;
            this.nowLevel = level.getChildByName('now_level') as Laya.Label;
            this.unlockCount = unlock.getChildByName('unlock_count') as Laya.Label;

            const pLevel = level.getChildByName('level') as Laya.Sprite;
            const pEvent = unlock.getChildByName('event') as Laya.Label;
            this.unlockCount.x = pEvent.x + pEvent.trueWidth / 2 + 53;
            if (GameMgr.client_language == 'jp') {
                pLevel.y += 2;
                pEvent.y += 2;
                this.lastLevel.font = this.nowLevel.font = this.unlockCount.font = 'jp_jiye';
            } else if (GameMgr.client_language == 'en') {
                pLevel.y += 2;
                pEvent.y += 2;
            } else if (GameMgr.client_language == 'kr') {
                pLevel.y += 2;
                pEvent.y += 2;
                this.lastLevel.y +=2;
                this.nowLevel.y +=2;
                this.unlockCount.y +=2;
            }
            me.visible = false;
            this.result.visible = false;
            this.levelUp.visible = false;
        }


        /**
         * 展示成功大成功
         * @param result 0➡失败，1➡成功，2➡大成功，3➡失败转成功
         */
        public showResult(result: number, reward_items: game.IExecuteResult[], effected_buff: number[], isEvent: boolean, goodEnding?: boolean) {
            this.me.visible = true;
            this.result.visible = true;
            this.levelUp.visible = false;

            this.fail.visible = result == 0 || result == 3;
            this.success.visible = result == 1;
            this.bigSuccess.visible = result == 2;
            this.fail2Success.visible = result == 3;
            const times: number[] = [0, 0, 80, 80];
            const effectDelay = [0, 0, 0, 0];
            const audioDelay = [0, 7, 7, 0];
            const effectNames: string[] = ['effect_25chunjie_lose', 'effect_25chunjie_success', 'effect_25chunjie_bigsuccess', 'effect_25chunjie_losetosuccess'];
            const audioIds: number[] = [Activity24BaAudio.failure, Activity24BaAudio.success, Activity24BaAudio.great_success, Activity24BaAudio.failure_switch_success];
            const bgSkins: number[] = [68, 69, 69, 68];
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/img_' + bgSkins[result] + '.png', null, 'UI_Activity_24ba');
            const aniNames = [
                E24baApplyAnimName.fail_show,
                E24baApplyAnimName.success_show,
                E24baApplyAnimName.big_success_show,
                E24baApplyAnimName.fail2success,
            ];
            for (let i = 0; i < this.tributes.length; i++) {
                const ele = this.tributes[i];
                const data = reward_items[i];
                ele.parent.visible = !!data;
                if (data) {
                    let baiziAdd: number = 0;
                    let muyueAdd: number = 0;
                    if (data.count > 0 && effected_buff) {
                        if (effected_buff.indexOf(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.baizi]) != -1) {
                            baiziAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.baizi]);
                        }
                        if (effected_buff.indexOf(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.muyue]) != -1) {
                            muyueAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.muyue]);
                        }
                    }

                    let buffAdded = 0;
                    const index = UI_Activity_24ba.LevelUpItemIds.indexOf(data.id);
                    if (index != -1) buffAdded = muyueAdd;
                    else if (data.id == UI_Activity_24ba.activityData.funds_id) buffAdded = baiziAdd;

                    ele.name.text = cfg.item_definition.item.get(data.id)['name_' + GameMgr.client_language];
                    ele.icon.skin = game.Tools.localUISrc(UI_Activity_24ba.BuffLightSkins[data.id]);

                    const count = UI_Bag.get_item_count(data.id);
                    ele.last.text = this.oldItemCount[data.id].toString();
                    ele.now.text = (Math.max(count - buffAdded, 0)).toString();
                    if (buffAdded > 0) {
                        ele.added.text = `+${ buffAdded }`;
                    } else {
                        ele.added.text = '';
                    }
                }
            }
            if (result == 3) {
                Laya.timer.once(50 / 60 * 1000, this, () => {
                    UI_Activity_24ba.Inst.showBuffEffect(UI_Activity_24ba.LevelUpItemIds[1], true);
                });
            }
            Laya.timer.once(effectDelay[result] / 60 * 1000, this, () => {
                if (this.effects[result]) {
                    this.hideEffect();
                    this.effects[result].effect.root.active = true;
                }
                Laya.timer.once(audioDelay[result] / 60 * 1000, this, () => view.AudioMgr.PlayAudio(audioIds[result]));
            });
            UI_Activity_24ba_Apply.Inst.playAnim(aniNames[result], () => {
                Laya.timer.once(times[result], this, () => {
                    UI_Activity_24ba.Inst.showParamChange(effected_buff, reward_items);
                    Laya.timer.once(1800, UI_Activity_24ba_Apply.Inst, UI_Activity_24ba_Apply.Inst.removeLock, ["show_result"]);
                });
            });
            if (isEvent) {
                UI_Activity_24ba_Apply.Inst.say(goodEnding ? 'success' : 'failure');
            } else {
                if (result == 0)
                    UI_Activity_24ba_Apply.Inst.say('failure');
                else if (result == 2) {
                    UI_Activity_24ba_Apply.Inst.say('success');
                }
            }
        }

        public showLevelUp(preLevel: number) {
            this.hideEffect();
            this.me.visible = true;
            this.result.visible = false;
            this.levelUp.visible = true;
            const lastData = UI_Activity_24ba.getLevelData(preLevel);
            const nextData = UI_Activity_24ba.getLevelData(preLevel + 1);
            this.lastLevel.text = game.Tools.eventStrOfLocalization(lastData.level_name);
            this.nowLevel.text = game.Tools.eventStrOfLocalization(nextData.level_name);
            this.levelName.x = this.lastLevel.x - this.lastLevel.trueWidth - 53;
            this.unlockCount.text = 'x ' + nextData.unlock_event_count;
            game.LoadMgr.setImgSkin(this.level, `myres/activity_2501miaohui/${ nextData.level_res }`, null, 'UI_Activity_24ba');
            game.LoadMgr.setImgSkin(this.levelBg, `myres/activity_2501miaohui/img_69.png`, null, 'UI_Activity_24ba');
            UI_Activity_24ba_Apply.Inst.setCharClickEnable(false);
        }

        public saveOldCount() {
            [...UI_Activity_24ba.LevelUpItemIds, UI_Activity_24ba.activityData.funds_id].forEach(v => {
                this.oldItemCount[v] = UI_Bag.get_item_count(v);
            });
        }

        public hide() {
            this.me.visible = false;
            UI_Activity_24ba_Apply.Inst.setCharClickEnable(true);
            this.hideEffect();
        }

        private hideEffect() {
            this.effects.forEach(v => v.effect.root.active = false);
        }
    }

    enum EApplyState { none, apply, end };
    export class UI_Activity_24ba_Apply extends UIBase {
        public static Inst: UI_Activity_24ba_Apply;

        private applyRoot: Laya.Sprite;
        private bg: Laya.Image; // 背景 事件和提案差分
        private bg0: Laya.Image; // 背景 事件和提案差分
        private bg1: Laya.Image; // 背景 事件和提案差分
        private gongpin: Laya.Image;
        private head: Laya.Image; // 头像
        private headBorder: Laya.Image;
        private title: Laya.Label;
        private charName: Laya.Label;

        private apply: PageApply;
        private end: PageEnd;
        private result: PageResult;

        private btnSwitch: Laya.Button;
        private labelSwitch: Laya.Label;
        private bgSwitch: Laya.Image;
        private btnLeft: Laya.Button;
        private btnRight: Laya.Button;

        private state: EApplyState;
        private index: number;
        public get info() { return UI_Activity_24ba.Inst.sortProposalList[this.index]; };

        private preLevel: number;
        private applySelect: number;
        private applyRes: game.IResResolveFestivalActivityProposal & game.IResResolveFestivalActivityEvent;
        /** 0➡失败，1➡成功，2➡大成功，3➡失败转成功 */
        private applyResult: number = 0;
        private lockStateDic: basic.Dictionary<string, number> = new basic.Dictionary<string, number>();

        private illust: Laya.Sprite;
        private lihui: Laya.Sprite;
        private spine: CatFoodSpine.SpineController;
        private chat: UI_Character_Chat;
        private chatBg: Laya.Image;
        private chatLabel: Laya.Label;
        private chatArrow: Laya.Image;
        private chat_id: number = 0;
        private effects: game.UIEffect[][] = [];
        get levelUp() { return this.preLevel < UI_Activity_24ba.activityLevel; }

        public addLock(state: string, duration?: number) {
            this.lockStateDic.set(state, 1);
            if (duration && duration > 0)
                Laya.timer.once(duration, this, () => this.removeLock(state));
        }
        public haveLock(state?: string): boolean {
            if (!state) {
                return this.lockStateDic.getCount() != 0;
            } else {
                return this.lockStateDic.has(state);
            }
        }
        public removeLock(state: string) {
            this.lockStateDic.remove(state);
        }

        constructor() {
            super(new ui.lobby.activity_24ba.activity_24ba_applyUI());
            UI_Activity_24ba_Apply.Inst = this;
        }

        public onCreate() {
            const root = this.me.getChildByName('root') as Laya.Sprite;
            const applyRoot = this.applyRoot = root.getChildByName('root') as Laya.Sprite;
            this.title = applyRoot.getChildByName('title') as Laya.Label;
            this.charName = applyRoot.getChildByName('char_name') as Laya.Label;
            const head = applyRoot.getChildByName('head') as Laya.Sprite;
            this.head = head.getChildByName('head') as Laya.Image;
            this.headBorder = head.getChildByName('border') as Laya.Image;
            this.bg = applyRoot.getChildByName('bg') as Laya.Image;
            this.bg0 = applyRoot.getChildByName('bg0') as Laya.Image;
            this.bg1 = applyRoot.getChildByName('bg1') as Laya.Image;
            this.gongpin = applyRoot.getChildByName('gongpin') as Laya.Image;
            this.apply = new PageApply(applyRoot.getChildByName('apply') as Laya.Sprite);
            this.end = new PageEnd(applyRoot.getChildByName('end') as Laya.Sprite);
            this.btnLeft = root.getChildByName('btn_left') as Laya.Button;
            this.btnRight = root.getChildByName('btn_right') as Laya.Button;
            this.btnSwitch = applyRoot.getChildByName('btn_switch') as Laya.Button;
            this.labelSwitch = this.btnSwitch.getChildByName('text') as Laya.Label;
            this.bgSwitch = this.btnSwitch.getChildByName('bg') as Laya.Image;
            this.result = new PageResult(root.getChildByName('result') as Laya.Sprite);

            // 角色 
            const illust = this.illust = this.me.getChildByName('illust') as Laya.Sprite;
            this.lihui = illust.getChildByName('illust') as Laya.Sprite;
            const chat = illust.getChildByName('chat') as Laya.Sprite;
            this.chatBg = chat.getChildByName('bg') as Laya.Image;
            this.chatArrow = chat.getChildByName('arrow') as Laya.Image;
            this.chatLabel = chat.getChildByName('content').getChildByName('info') as Laya.Label;
            this.chat = new UI_Character_Chat(chat);
            (illust.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.chat_id) this.stopsay();
                else {
                    if (this.spine) {
                        this.say('click');
                    }
                }
            }, null, false);

            this.btnLeft.clickHandler = new Laya.Handler(this, this.onBtnLeftRightClick, [true]);
            this.btnRight.clickHandler = new Laya.Handler(this, this.onBtnLeftRightClick, [false]);
            this.btnSwitch.clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                this.apply.onSwitch(this.state != EApplyState.apply);
                this.end.onSwitch(this.state == EApplyState.apply);
                this.state = this.state != EApplyState.apply ? EApplyState.apply : EApplyState.end;
                this.labelSwitch.text = game.Tools.strOfLocalization(this.state == EApplyState.apply ? 4575 : 4574);
                this.adaptSwitchBtn();
            });
            const btnClose = this.me.getChildByName('btn_close') as Laya.Button;
            const btnBack = applyRoot.getChildByName('btn_back') as Laya.Button;
            btnClose.clickHandler = btnBack.clickHandler = new Laya.Handler(this, () => {
                if (this.haveLock()) return;
                const { me, result, btnSwitch, info, applySelect, applyRes, applyResult } = this;
                if (btnSwitch.visible && info.id >= UI_Activity_24ba.maxEventId) {
                    UI_Activity_24ba.Inst.endCg.show();
                    this.close();
                    return;
                }
                if (result.me.visible) {
                    const callback = () => {
                        if (this.levelUp) {
                            const lastData = UI_Activity_24ba.getLevelData(this.preLevel);
                            const nextData = UI_Activity_24ba.getLevelData(this.preLevel + 1);
                            if (lastData && nextData) {
                                this.result.showLevelUp(this.preLevel++);
                                this.playAnim(E24baApplyAnimName.level_up_show);
                                Laya.timer.once(4 / 60 / 1000, this, () => {
                                    const curLevel = this.preLevel;
                                    UI_Activity_24ba.Inst.refreshLevel(curLevel);
                                    const effects = this.effects[curLevel];
                                    if (effects) {
                                        const [effect01, effect02] = effects;
                                        effect01.effect.root.active = effect02.effect.root.active = true;
                                    }
                                    Laya.timer.once(1000, this, this.createEffects, [curLevel + 1]);
                                    const audioId: number = curLevel <= 7 ? Activity24BaAudio.level_up_1_7 : (curLevel <= 13 ? Activity24BaAudio.level_up_8_13 : Activity24BaAudio.level_up_14_17);
                                    view.AudioMgr.PlayAudio(audioId);
                                });
                                this.addLock('show_level_up', 1000);
                                return;
                            }
                        }
                        this.result.hide();
                        if (info.isEvent) {
                            const eventData = UI_Activity_24ba.getEventData(info.dataId);
                            const groupId = eventData.ending_group[applySelect];
                            const optionText = applySelect == 0 ? eventData.option_text_a : eventData.option_text_b;
                            this.end.showEnding(optionText, groupId, applyRes.ending_id);
                            this.state = EApplyState.end;
                            this.apply.onSwitch(false);
                            this.end.onSwitch(true);
                            this.setBtnSwitchVisible(true);
                            this.playAnim(E24baApplyAnimName.apply_enter01);
                        } else {
                            this.onLastApplyDone();
                        }
                    }
                    if (result.result.visible) {
                        const aniNames = [
                            E24baApplyAnimName.fail_hide,
                            E24baApplyAnimName.success_hide,
                            E24baApplyAnimName.big_success_hide,
                            E24baApplyAnimName.success_hide,
                        ];
                        this.playAnim(aniNames[applyResult], callback);
                        return;
                    } else if (result.levelUp.visible) {
                        this.playAnim(E24baApplyAnimName.level_up_hide, callback);
                        return;
                    }
                }
                this.close();
            });
            this.hideCharacter();
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/img_33.png', null, 'UI_Activity_24ba');
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/img_34.png', null, 'UI_Activity_24ba');
        }

        public playAnim(name: E24baApplyAnimName, cb?: Function) {
            if (!this.me[name]) return;
            this.addLock(name);
            const ani = this.me[name] as Laya.FrameAnimation;
            ani.play(0, false);
            const delay = ani.count * ani.interval;
            Laya.timer.once(delay, this, () => {
                this.removeLock(name);
                cb && cb.call(this);
            });
            this.me.event(E24baApplyEvent.PlayAnim, name);
        }

        private getLevelEffectPath(level: number) {
            if (level <= 3) return null;
            else if (level <= 7) return ['scene/effect_25chunjie_lv01.lh', 'scene/effect_25chunjie_lv02.lh'];
            else if (level <= 9) return ['scene/effect_25chunjie_lan01.lh', 'scene/effect_25chunjie_lan02.lh'];
            else if (level <= 11) return ['scene/effect_25chunjie_zi01.lh', 'scene/effect_25chunjie_zi02.lh'];
            else if (level <= 13) return ['scene/effect_25chunjie_jin01.lh', 'scene/effect_25chunjie_jin02.lh'];
            else if (level <= 15) return ['scene/effect_25chunjie_hong01.lh', 'scene/effect_25chunjie_hong02.lh'];
            else return ['scene/effect_25chunjie_cai01.lh', 'scene/effect_25chunjie_cai02.lh'];
        }

        public show(index: number, anim: boolean = true) {
            this.refreshSpineStageIdle();
            this.preLevel = UI_Activity_24ba.activityLevel;
            const len = UI_Activity_24ba.Inst.sortProposalList.length;
            if (index < 0) index = len - 1;
            else if (index >= len) index = 0;
            this.index = index;
            const info = this.info;

            const skins = [98, 99, 100, 101, 102, 103];
            const pos = UI_Activity_24ba.Inst.listTask.findIndex(v => v.id == info.dataId);
            this.gongpin.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + skins[pos] + '.png');

            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/img_' + (info.isEvent ? 34 : 33) + '.png', null, 'UI_Activity_24ba');
            this.bg0.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (info.isEvent ? 40 : 39) + '.png');
            this.bg1.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (info.isEvent ? 42 : 41) + '.png');

            this.chatBg.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (info.isEvent ? 64 : 63) + '.png');
            this.chatArrow.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (info.isEvent ? 62 : 61) + '.png');
            this.chatLabel.color = info.isEvent ? '#69779d' : '#c38236';

            this.headBorder.skin = game.Tools.localUISrc('myres/activity_2501miaohui/img_' + (info.isEvent ? 32 : 31) + '.png');
            this.setBtnSwitchVisible(false);
            this.applyRoot.visible = true;
            this.btnLeft.visible = UI_Activity_24ba.Inst.sortProposalList.length != 1;
            this.btnRight.visible = UI_Activity_24ba.Inst.sortProposalList.length != 1;
            this.state = EApplyState.apply;
            this.apply.showApply(info.dataId, info.isEvent);
            this.end.close();
            let data: Partial<lqc.Sheet_Activity_FestivalEvent & lqc.Sheet_Activity_FestivalProposal>;
            if (info.isEvent) data = UI_Activity_24ba.getEventData(info.dataId);
            else data = UI_Activity_24ba.getProposalData(info.dataId);
            this.title.text = info.isEvent ? game.Tools.eventStrOfLocalization(data.event_title) : '';
            this.charName.color = info.isEvent ? '#5a647d' : '#896e50';
            this.charName.text = UI_Activity_24ba.duringGuide ? game.Tools.strOfLocalization(4584) : game.Tools.eventStrOfLocalization(data.client_name);
            game.LoadMgr.setImgSkin(this.head, data.client_icon, null, 'UI_Activity_24ba');
            this.illust.visible = true;
            this.enable = true;
            if (anim) {
                this.showGreeting();
                this.playAnim(E24baApplyAnimName.apply_enter);
            }
            view.AudioMgr.PlayAudio(Activity24BaAudio.ui_open);
        }

        private showGreeting() {
            const tag = game.Tools.eeesss('UI_Activity_24ba_Apply_Greeting');
            const str = Laya.LocalStorage.getItem(tag);
            let showGreeting = false;
            if (!str) showGreeting = true;
            else {
                const time = +str || 0;
                const oldDate = new Date(time);
                const curDate = new Date();
                if (oldDate.getFullYear() != curDate.getFullYear() || oldDate.getMonth() != curDate.getMonth() || oldDate.getDate() != curDate.getDate())
                    showGreeting = true;
            }
            if (showGreeting) {
                this.say('greeting');
                Laya.LocalStorage.setItem(tag, Date.now().toString());
            }
        }

        public close() {
            Laya.stage.event(BA_Page_EventId.ON_DISABLE);
            Laya.timer.clearAll(this);
            !UI_Activity_24ba.duringGuide && UI_Activity_24ba.Inst.refreshEvent();
            this.apply.onClose();
            this.playAnim(E24baApplyAnimName.apply_close, () => this.enable = false);
        }

        // 播放提案点击->结局
        private adaptSwitchBtn() {
            const width = this.labelSwitch.trueWidth + 75;
            this.bgSwitch.width = width;
            this.btnSwitch.width = width;
            this.btnSwitch.x = 1255 - width / 2;
        }

        // 当前申请完成
        public onLastApplyDone() {
            const isEvent = this.info.isEvent;
            UI_Activity_24ba.Inst.refreshEvent(true, false);
            if (UI_Activity_24ba.Inst.sortProposalList.length == 0) {
                this.close();
                return;
            }
            if (isEvent) this.onBtnLeftRightClick(false);
            else {
                this.show(this.index + 1, false);
                this.playAnim(E24baApplyAnimName.apply_enter01);
            }
        }

        private onBtnLeftRightClick(toLeft: boolean) {
            if (this.haveLock()) return;
            if (this.result.me.visible) return;
            // this.stopsay();
            this.playAnim(toLeft ? E24baApplyAnimName.apply_switch_R : E24baApplyAnimName.apply_switch_L, () => {
                let index = this.index;
                const pos1 = UI_Activity_24ba.Inst.sortProposalList.find(v => v.pos == 1);
                if (pos1) {
                    const list = UI_Activity_24ba.Inst.sortProposalList.filter(v => v.pos != 1);
                    list.push(pos1);
                    let infoIndex = list.findIndex(v => v.pos == this.info.pos);
                    infoIndex += (toLeft ? -1 : 1);
                    infoIndex < 0 && (infoIndex = list.length - 1);
                    infoIndex >= list.length && (infoIndex = 0);
                    index = UI_Activity_24ba.Inst.sortProposalList.findIndex(v => v.pos == list[infoIndex].pos);
                } else index += toLeft ? -1 : 1;
                this.show(index, false);
                view.AudioMgr.PlayAudio(Activity24BaAudio.ui_open);
                this.playAnim(toLeft ? E24baApplyAnimName.apply_switch01_R : E24baApplyAnimName.apply_switch01_L);
            });
        }

        public onApplyChooseClick(select: number) {
            this.result.saveOldCount();
            this.addLock('request');
            this.preLevel = UI_Activity_24ba.activityLevel;
            const { isEvent, id } = this.info;
            const requestName = isEvent ? game.ERequest.resolveFestivalActivityEvent : game.ERequest.resolveFestivalActivityProposal;
            app.NetAgent.sendReq2Lobby(
                'Lobby', requestName,
                { activity_id: UI_Activity_24ba.activityId, id, select },
                (err, res: game.IResResolveFestivalActivityProposal & game.IResResolveFestivalActivityEvent) => {
                    this.removeLock('request');
                    if (err || res.error) {
                        UIMgr.Inst.showNetReqError(requestName, err, res);
                    } else {
                        this.applySelect = select;
                        this.applyRes = res;
                        const { level, result, ending_id, reward_items, effected_buff } = res;
                        let applyResult = result;
                        let goodEnding = false;
                        UI_Activity_24ba.activityLevel = level;
                        this.refreshSpineStageIdle();
                        if (isEvent) {
                            const endingGroup = UI_Activity_24ba.getEventData(this.info.dataId).ending_group;
                            const endingData = UI_Activity_24ba.getEndingData(endingGroup[select], ending_id);
                            applyResult = endingData.ending_type == 1 ? 1 : 0;
                            goodEnding = endingData.ending_type == 1;
                        } else {
                            UI_Activity_24ba.Inst.refreshProposalCount();
                        }

                        applyResult = applyResult == 1 || applyResult == 2 ? applyResult : 0;
                        if (effected_buff && effected_buff.indexOf(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.xingye]) != -1)
                            applyResult = 3;
                        this.applyResult = applyResult;
                        UI_Activity_24ba_Apply.Inst.addLock('show_result');
                        UI_Activity_24ba_Apply.Inst.setCharClickEnable(false);
                        this.playAnim(E24baApplyAnimName.apply_close01, () => {
                            this.btnLeft.visible = this.btnRight.visible = false;
                            this.result.showResult(applyResult, reward_items, effected_buff, isEvent, goodEnding);
                            Laya.timer.once(100, UI_Activity_24ba.Inst, UI_Activity_24ba.Inst.refreshRedPoint);
                        });
                        if (id >= UI_Activity_24ba.maxEventId) {
                            app.PlayerBehaviorStatistic.update_val(app.EBehaviorType.BA2501_LastEvent_Checked, 1);
                        }
                    }
                });
        }

        private setBtnSwitchVisible(visible: boolean) {
            this.btnSwitch.visible = visible;
            if (visible) {
                this.labelSwitch.text = game.Tools.strOfLocalization(this.state == EApplyState.apply ? 4575 : 4574);
                this.adaptSwitchBtn();
            }

            this.apply.onSwitchBtnChange(visible);
        }

        public onEnable(): void {
            this.createEffects();
            Laya.stage.event(BA_Page_EventId.DO_SHOW_ANIMATION, UI_Activity_24ba.activityId);
        }

        public onDisable(): void {
            this.stopsay();
            Laya.stage.event(BA_Page_EventId.DO_HIDE_ANIMATION, UI_Activity_24ba.activityId);
        }

        public createEffects(level: number = -1) {
            if(level < 0) level = UI_Activity_24ba.activityLevel + 1;
            for (let i = 0; i < level; i++) {
                const effects = this.effects[i];
                effects && effects.forEach(v => v.destory());
                this.effects[i] = null;
            }
            for (let i = level; i < level + 2; i++) {
                const effectPath = this.getLevelEffectPath(i);
                const canCreate = !this.effects[i] && i <= 17 && effectPath;
                if (canCreate) {
                    const effect01 = game.FrontEffect.Inst.create_ui_effect(this.me, effectPath[0], new Laya.Point(1500, 520), 1);
                    const effect02 = game.FrontEffect.Inst.create_ui_effect(this.me, effectPath[1], new Laya.Point(1830, 60), 1);
                    effect01.effect.root.active = false;
                    effect02.effect.root.active = false;
                    this.effects[i] = [effect01, effect02];
                    const levelData = UI_Activity_24ba.getLevelData(i);
                    Laya.loader.load(game.Tools.localUISrc(`myres/activity_2501miaohui/${ levelData.level_res }`));
                }
            }
            const resultEffects = ['effect_25chunjie_lose', 'effect_25chunjie_success', 'effect_25chunjie_bigsuccess', 'effect_25chunjie_losetosuccess'];
            resultEffects.forEach((v, i) => {
                if (!this.result.effects[i]) {
                    this.result.effects[i] = game.FrontEffect.Inst.create_ui_effect(this.result.result, `scene/${ v }.lh`, new Laya.Point(550, -50), 1);
                    this.result.effects[i].effect.root.active = false;
                }
            });
            
        }

        public destroyEffects() {
            this.effects.forEach(v => v && v.forEach(v1 => v1.destory()));
            this.effects.length = 0;
            this.result.effects.forEach(v => v.destory());
            this.result.effects.length = 0;
        }

        public createCharacter() {
            if (this.spine) return;
            this.spine = CatFoodSpine.SpineMgr.Inst.getSprite(game.Tools.localUISrc('extendRes/spine/yunnv_event'), { id: 0 } as any, false);
            this.spine.root.visible = true;
            this.spine.pX = 0;
            this.spine.pY = 0;
            this.spine.sx = 0.96;
            this.spine.sy = 0.96;
            this.spine.offsetX = 0;
            this.spine.offsetY = 0;
            this.spine.aniAlpha = true;
            this.spine.updateSpineInfo();
            this.lihui.addChild(this.spine.root);
            this.refreshSpineStageIdle();
            // this.spine.setLoadOverHandler(Laya.Handler.create(this, null));
        }

        public destroyCharacter() {
            if (this.spine) {
                this.spine['spines'][0].customIdleAni = null;
                this.spine.reset();
                this.spine.root.visible = false;
                this.spine.root.removeSelf();
                this.spine = null;
            }
        }

        private animNames: { [key: string]: string[] } = {
            'click': ['click1', 'click2', 'click3', 'click4'],
            'success': ['event_s', 'event_s2', 'event_s3', 'event_s4'],
            'failure': ['event_f', 'event_f2', 'event_f3', 'event_f4'],
            'greeting': ['idle', 'idle2', 'idle3', 'idle4'],
        };
        public say(type: string) {
            if (this.chat_id) {
                view.AudioMgr.StopAudio(this.chat_id);
                this.chat_id = 0;
            }
            const stage = Math.floor(UI_Activity_24ba.activityLevel / 5);
            const group = cfg.voice.event.getGroup(3);
            const groupType = type == 'click' ? (Math.random() < 0.5 ? 'click_1' : 'click_2') : type;
            const data = group.find(v => v.stage == stage && v.type == groupType);
            this.spine.play(this.animNames[type][stage]);
            if (!data) return;
            this.chat.show(data['words_' + GameMgr.client_language]);
            const volume = view.AudioMgr.yuyinMuted ? 0 : view.AudioMgr.yuyinVolume * data.volume_fix;
            const chatId = this.chat_id = view.AudioMgr.PlaySound(data.path, volume, Laya.Handler.create(this, () => {
                if (chatId == this.chat_id) {
                    this.chat_id = 0;
                    this.stopsay();
                }
            }));
        }

        public stopsay() {
            if (this.chat.me.visible) this.chat.close(false);
            if (this.chat_id) {
                view.AudioMgr.StopAudio(this.chat_id);
                this.chat_id = 0;
            }
        }

        public refreshSpineStageIdle() {
            if (!this.spine) return;
            const stage = Math.floor(UI_Activity_24ba.activityLevel / 5);
            const idleName = ['idle', 'idle2', 'idle3', 'idle4'][stage];
            this.spine['spines'][0].customIdleAni = idleName;
            this.spine.play(idleName, true);
        }

        private hideCharacter() {
            this.stopsay();
            this.illust.visible = false;
        }

        public setCharClickEnable(enable: boolean) {
            this.illust.mouseEnabled = enable;
        }
    }
}
