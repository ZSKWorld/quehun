//==DevDebug==
/**
* 24ba提案界面
*/
module uiscript {

    function getChild<T extends Laya.Sprite>(parent: Laya.Sprite, name: string): T {
        return parent.getChildByName(name) as T;
    }

    class BasePanel<T> {
        protected data: T;
        protected me: Laya.Sprite;
        public constructor(me: Laya.Sprite) {
            this.me = me;
        }

        public updateData(data: T) {
            this.data = data;
            this.refreshDisplay();
        }

        public refreshDisplay() { }
    }

    class LevelPanel extends BasePanel<game.ProtoObject<game.IActivityFestivalData>> {
        private inputLevel: Laya.Input;
        public constructor(me: Laya.Sprite) {
            super(me);
            this.inputLevel = getChild(me, 'input_level');
            this.inputLevel.on(Laya.Event.BLUR, null, () => {
                const level = Math.floor(+this.inputLevel.text);
                if (!isNaN(level) && level >= 0) this.data.level = level;
                this.refreshDisplay();
            });
        }

        public refreshDisplay(): void {
            this.inputLevel.text = this.data.level.toString();
        }
    }

    class ScrollPanel<T extends Array<any>> extends BasePanel<T> {
        protected isEvent: boolean = false;
        protected inputId: Laya.Input;
        protected inputPos: Laya.Input;
        protected scrollView: capsui.CScrollView;
        public constructor(me: Laya.Sprite) {
            super(me);
            this.inputId = getChild(me, 'input_id');
            this.inputPos = getChild(me, 'input_pos');
            const dealInput = (input: Laya.Input, isId: boolean) => {
                const num = Math.max(Math.floor(+input.text), 0) || 0;
                const activityId = UI_Activity_24ba.activityId;
                const eventLegal = (isId && this.isEvent) ? !!cfg.activity.festival_event.getGroup(activityId).find(v => v.event_id == num) : true;
                const proposalLegal = (isId && !this.isEvent) ? !!cfg.activity.festival_proposal.getGroup(activityId).find(v => v.proposal_id == num) : true;
                const posLegal = !isId ? (num >= 0 && num <= 4) : true;
                input.text = (eventLegal && proposalLegal && posLegal) ? num.toString() : '';
            };
            this.inputId.on(Laya.Event.BLUR, this, () => dealInput(this.inputId, true));
            if (this.inputPos)
                this.inputPos.on(Laya.Event.BLUR, this, () => dealInput(this.inputPos, false));

            const btnAdd = me.getChildByName('btn_add') as Laya.Button;
            btnAdd.clickHandler = new Laya.Handler(this, () => {
                const id = +this.inputId.text;
                const pos = this.inputPos ? +this.inputPos.text : 0;
                if (isNaN(id) || isNaN(pos)) return;
                this.addData(id, pos) && this.refreshDisplay();
            });
            const btnAddAll = me.getChildByName('btn_addAll') as Laya.Button;
            btnAddAll.clickHandler = new Laya.Handler(this, () => {
                this.addAll();
                this.refreshDisplay();
            });

            const content = me.getChildByName('content') as Laya.Sprite;
            this.scrollView = content.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.onListItemRender));
            this.scrollView.setElastic();
        }

        public refreshDisplay(): void {
            this.scrollView.reset();
            this.scrollView.addItem(this.data.length, 50);
        }

        protected addData(id: number, pos: number) { return false; }
        protected addAll() { }
        protected onListItemRender(item) { }
    }

    class EventPanel extends ScrollPanel<number[]> {
        protected isEvent: boolean = true;

        protected addData(id: number, pos: number) {
            const index = this.data.indexOf(id);
            if (index >= 0) return false;
            this.data.push(id);
            return true;
        }

        protected addAll() {
            const eventGroup = cfg.activity.festival_event.getGroup(UI_Activity_24ba.activityId);
            for (const eventData of eventGroup) {
                if (!this.data.includes(eventData.event_id))
                    this.data.push(eventData.event_id);
            }
        }

        protected onListItemRender(item: { container: Laya.Sprite, index: number }) {
            const eventId = this.data[item.index];
            const cfgs = cfg.activity.festival_event.getGroup(UI_Activity_24ba.activityId);
            const cfgData = cfgs.find(v => v.event_id == eventId);
            const labelTxt: Laya.Label = getChild(item.container, 'label_txt');
            labelTxt.color = cfgData ? '#000000' : '#ff0000';
            labelTxt.text = eventId + '\t' + (cfgData ? game.Tools.eventStrOfLocalization(cfgData.event_text) : '未知的事件');
            const btnDelete: Laya.Button = getChild(item.container, 'btn_delete');
            btnDelete.clickHandler ||= Laya.Handler.create(this, this.deleteData);
            btnDelete.clickHandler.setTo(this, this.deleteData, [eventId], true);
        }

        private deleteData(id: number) {
            const index = this.data.findIndex(v => v == id);
            if (index <= -1) return;
            this.data.splice(index, 1);
            this.refreshDisplay();
        }
    }

    class ProposalPanel extends ScrollPanel<game.IFestivalProposalData[]> {

        protected addData(id: number, pos: number) {
            const maxId = this.data.reduce((pv, cv) => pv >= cv.id ? pv : cv.id, 0);
            this.data.push({ id: maxId + 1, proposal_id: id, pos: pos, });
            return true;
        }

        protected addAll() {
            const maxId = this.data.reduce((pv, cv) => pv >= cv.id ? pv : cv.id, 0);
            const cfgs = cfg.activity.festival_proposal.getGroup(UI_Activity_24ba.activityId);
            cfgs.forEach((v, i) => this.data.push({ id: maxId + i + 1, proposal_id: v.proposal_id, pos: 0 }));
        }

        protected onListItemRender(item: { container: Laya.Sprite, index: number }) {
            const proposalData = this.data[item.index];
            const cfgs = cfg.activity.festival_proposal.getGroup(UI_Activity_24ba.activityId);
            const cfgData = cfgs.find(v => v.proposal_id == proposalData.proposal_id);
            const labelTxt: Laya.Label = getChild(item.container, 'label_txt');
            labelTxt.color = cfgData ? '#000000' : '#ff0000';
            labelTxt.text = proposalData.proposal_id + '\t' + (cfgData ? game.Tools.eventStrOfLocalization(cfgData.proposal_text) : '未知的祈愿');
            const labelPos: Laya.Label = getChild(item.container, 'label_pos');
            labelPos.text = proposalData.pos.toString();

            const btnDelete: Laya.Button = getChild(item.container, 'btn_delete');
            btnDelete.clickHandler ||= Laya.Handler.create(this, this.deleteData, [item], false);
        }

        private deleteData(item: { container: Laya.Sprite, index: number }) {
            const id = this.data[item.index].id;
            const index = this.data.findIndex(v => v.id == id);
            if (index <= -1) return;
            this.data.splice(index, 1);
            this.refreshDisplay();
        }
    }

    export class UI_Activity_24ba_DevDebug extends UIBase {
        public static Inst: UI_Activity_24ba_DevDebug;
        constructor() {
            super(new ui.lobby.activity_24ba.activity_24ba_DevDebugUI());
            UI_Activity_24ba_DevDebug.Inst = this;
        }

        private root: Laya.Sprite;
        private levelPanel: LevelPanel;
        private eventPanel: EventPanel;
        private proposalPanel: ProposalPanel;
        private btnBack: Laya.Button;

        private _lockCnt: number = 0;
        private get locked() { return this._lockCnt > 0; }
        private set locked(value) {
            this._lockCnt += value ? 1 : -1;
            this.root.mouseEnabled = this.btnBack.mouseEnabled = !this.locked;
        }
        private data: game.ProtoObject<game.IActivityFestivalData>;

        public onCreate() {
            const me = this.me;
            const root = this.root = getChild(me, 'root');
            this.levelPanel = new LevelPanel(getChild(root, 'level'));
            this.eventPanel = new EventPanel(getChild(root, 'event'));
            this.proposalPanel = new ProposalPanel(getChild(root, 'proposal'));


            const btnUpdate: Laya.Button = getChild(root, 'btn_update');
            btnUpdate.clickHandler = Laya.Handler.create(this, this.onBtnUpdateClick, null, false);

            this.btnBack = getChild(me, 'btn_back');
            this.btnBack.clickHandler = Laya.Handler.create(this, this.close, null, false);
        }

        public show() {
            this.root.visible = false;
            this.enable = true;
            this.locked = true;
            const param: game.IReqFestivalFetchDebug = { activity_id: UI_Activity_24ba.activityId };
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.festivalActivityFetchDebug, param, (err, res: game.IResFestivalFetchDebug) => {
                this.locked = false;
                if (err || res.error) {
                    this.close();
                    UIMgr.Inst.showNetReqError(game.ERequest.festivalActivityFetchDebug, err, res);
                } else {
                    this.data = Object.assign({
                        activity_id: UI_Activity_24ba.activityId,
                        level: 0,
                        proposal_list: [],
                        event_list: [],
                        buy_record: { count: 0, update_time: 0 }
                    } as game.ProtoObject<game.IActivityFestivalData>, res.festival_activity.toJSON());

                    this.levelPanel.updateData(this.data);
                    this.eventPanel.updateData(this.data.event_list);
                    this.data.proposal_list.forEach(v => v.pos ||= 0);
                    this.proposalPanel.updateData(this.data.proposal_list);
                    this.root.visible = true;
                }
            });
        }


        public close() {
            this.enable = false;
        }

        public onEnable() {
            Laya.stage.event(BA_Page_EventId.DO_SHOW_ANIMATION);
        }

        public onDisable() {
            Laya.stage.event(BA_Page_EventId.DO_HIDE_ANIMATION);
        }

        private onBtnUpdateClick() {
            this.locked = true;
            const param: game.IReqFestivalDebug = { festival_activity: this.data };
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.festivalActivityDebug, param, (err, res: game.IResCommon) => {
                this.locked = false;
                this.close();
                if (err || res.error) {
                    UIMgr.Inst.showNetReqError(game.ERequest.festivalActivityFetchDebug, err, res);
                }
            });
        }
    }
}
