/**
* 24ba主活动
*/
module uiscript {
    export class UI_Activity_24ba_Entrance extends UI_ActivityBase {
        static Inst: UI_Activity_24ba_Entrance;
        private _btn_btn: Laya.Button;
        protected readonly activityId: number = BA_Page_ActivityId.MAIN;

        //左边标题的名称
        constructor() {

            super(cfg.activity.activity.get(BA_Page_ActivityId.MAIN)['name_' + GameMgr.client_language], new ui.lobby.activity_24ba.activity_24ba_entranceUI());
            UI_Activity_24ba_Entrance.Inst = this;
        }

        getId() { return this.activityId; }
        isopen() { return UI_Activity.activity_is_running(this.activityId); }
        //活动是否要弹出来
        need_popout() { return true; }

        onCreate() {
            this._btn_btn = this.me.getChildByName('btn') as Laya.Button;
            this._btn_btn.clickHandler = new Laya.Handler(this, () => {
                if (this.isopen()) {
                    if (UI_PiPeiYuYue.Inst.enable) {
                        UI_Popout.PopOutNoTitle(game.Tools.strOfLocalization(204), null);
                        return;
                    }
                    if (UI_Lobby.Inst.locking) return;
                    // if (!UI_Activity.activity_is_running(UI_Activity_Questionair_Entrance.activity_id)) {
                    //     UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3944));
                    //     return;
                    // }
                    UI_Activity.Inst.close();
                    UI_Lobby.Inst.Hide(Laya.Handler.create(this, () => {
                        UI_Activity_24ba.Inst.show();
                    }));
                }
            });
        }

        show() {
            this.enable = true;
        }

        hide() {
            this.enable = false;
        }

        onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_24ba_Entrance', true);
            game.LoadMgr.setImgSkin(this.me.getChildByName('head') as Laya.Image, 'myres/activity_2501miaohui/bg_entrance.jpg', null, 'UI_Activity_24ba_Entrance');
        }

        onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_24ba_Entrance', false);
        }
    }
}