/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_24ba_LevelUp extends UIBase {
        public static Inst: UI_Activity_24ba_LevelUp;
        constructor() {
            super(new ui.lobby.activity_24ba.activity_24ba_levelupUI());
            UI_Activity_24ba_LevelUp.Inst = this;
        }

        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private last: Laya.Image;
        private now: Laya.Image;
        private labelDesc: Laya.Label;
        private showLevel: number;
        private locking: boolean;

        private showAnim: Laya.FrameAnimation;
        private hideAnim: Laya.FrameAnimation;
        private effectName: string = "scene/effect_25chunjie_upgrade.lh";
        private effect: game.UIEffect;

        public onCreate() {
            this.bg = this.me.getChildByName('bg') as Laya.Sprite;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            this.last = this.root.getChildByName('last') as Laya.Image;
            this.now = this.root.getChildByName('now') as Laya.Image;
            this.labelDesc = this.root.getChildByName('desc') as Laya.Label;
            this.showAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_levelupUI).ani1;
            this.hideAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_levelupUI).ani2;
        }

        // level: 上一级的等级
        public show(level: number) {
            let lastData = UI_Activity_24ba.getLevelData(level);
            let nextData = UI_Activity_24ba.getLevelData(level + 1);
            if (!lastData || !nextData) {
                return;
            }
            this.showLevel = level + 1;
            this.last.skin = game.Tools.localUISrc('myres/activity_2404ba/' + lastData.level_res);
            this.now.skin = game.Tools.localUISrc('myres/activity_2404ba/' + nextData.level_res);
            this.labelDesc.text = game.Tools.strOfLocalization(4219, [nextData.unlock_event_count.toString()]);
            this.enable = true;
            // this.bg.alpha = 0;
            // Laya.Tween.to(this.bg, {alpha: 0.8}, 200);
            // this.root.alpha = 1;
            // this.locking = true;

            // UIBase.anim_alpha_in(this.root, {}, 200, 0, Laya.Handler.create(this, ()=>{
            //     this.locking = false;
            // }));
            view.AudioMgr.PlayAudio(Activity24BaAudio.skill_level_up);
            //播放开始动画
            this.locking = true;
            //显示动效
            this.effect = game.FrontEffect.Inst.create_ui_effect(this.root, this.effectName, new Laya.Point(960,200), 1);
            this.showAnim.play(0, false);
            Laya.timer.once(300, this, () => {
                this.locking = false;
            });
        }

        private close() {
            // Laya.Tween.to(this.bg, {alpha: 0}, 200);
            // this.locking = true;
            // UIBase.anim_alpha_out(this.root, {}, 200, 0, Laya.Handler.create(this, ()=>{
            //     this.locking = false;
            //     this.enable = false;
            // }));

            //播放关闭动画
            this.locking = true;
            this.showAnim.stop();
            this.hideAnim.play(0, false);
            //销毁动效
            if (this.effect) {
                this.effect.destory();
                this.effect = null;
            }
            Laya.timer.once(this.hideAnim.count * this.hideAnim.interval, this, () => {
                this.locking = false;
                this.enable = false;
                if (this.showLevel != UI_Activity_24ba.activityLevel) {
                    this.show(this.showLevel);
                }
            });
        }
    }
}