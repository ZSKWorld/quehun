/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_24ba_Rule extends UIBase {
        public static Inst: UI_Activity_24ba_Rule;
        constructor() {
            super(new ui.lobby.activity_24ba.activity_24ba_ruleUI());
            UI_Activity_24ba_Rule.Inst = this;
        }

        private bg: Laya.Image;
        private root: Laya.Sprite;
        private rootBg: Laya.Image;
        private img: Laya.Image;
        private btnLeft: Laya.Button;
        private btnRight: Laya.Button;
        private btnClose: Laya.Button;
        private pageCount: number = 2;
        private pageIndex: number = 0;
        private locking: boolean;

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('bg') as Laya.Image;

            this.rootBg = this.root.getChildByName('bg') as Laya.Image;
            this.img = this.root.getChildByName('img') as Laya.Image;
            this.btnLeft = this.root.getChildByName('btn_left') as Laya.Button;
            this.btnRight = this.root.getChildByName('btn_right') as Laya.Button;
            this.btnClose = this.root.getChildByName('btn_close') as Laya.Button;
            this.btnLeft.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.showPage(this.pageIndex - 1);
            });

            this.btnRight.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.showPage(this.pageIndex + 1);
            });

            this.btnClose.clickHandler = (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, {alpha: 0.3}, 200);
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            this.showPage(0);
        }
        
        private close() {
            this.locking = true;
            Laya.Tween.to(this.bg, {alpha: 0}, 200);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
                this.enable = false;
                this.locking = false;
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(4560));
            }));
        }

        private showPage(index: number) {
            if (index < 0 || index >= this.pageCount) return;
            this.pageIndex = index;
            this.btnLeft.visible = index != 0;
            this.btnRight.visible = index != this.pageCount - 1;
            game.LoadMgr.setImgSkin(this.img, `myres/activity_2501miaohui/rule_${index + 1}.png`, null, 'UI_Activity_24ba');
        }

        public onEnable(): void {
            game.LoadMgr.setImgSkin(this.rootBg, `myres/activity_2501miaohui/rule_bg.png`, null, 'UI_Activity_24ba');
            Laya.stage.event(BA_Page_EventId.DO_SHOW_ANIMATION);
        }

        public onDisable(): void {
            Laya.stage.event(BA_Page_EventId.DO_HIDE_ANIMATION);
        }
    }
}