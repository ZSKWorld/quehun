/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_24ba_Upgrade extends UIBase {
        public static Inst: UI_Activity_24ba_Upgrade;

        public static activityId: number = BA_Page_ActivityId.UPGRADE;
        public static buffIds: number[] = [25010201, 25010202, 25010203];
        public static get colorRed(): string {
            return '#ff5b5b';
        }
        public static get colorWhite(): string {
            return '#ffffff';
        }

        private showAnim: Laya.FrameAnimation;
        private hideAnim: Laya.FrameAnimation;
        // private showBuyResultAnim: Laya.FrameAnimation;
        // private hideBuyResultAnim: Laya.FrameAnimation;
        // private showUpgradeAnim: Laya.FrameAnimation;
        // private hideUpgradeAnim: Laya.FrameAnimation;
        private itemHandler = Laya.Handler.create(this, () => {
            UI_Activity_24ba.Inst.refreshItems();
        }, null, false);

        public static haveRedPoint(): boolean {
            if (!UI_Activity_24ba.activityData) return false;
            let count = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id);

            for (let buffId of this.buffIds) {
                let level = UI_Activity.getActivityBuffLevel(buffId);
                let nextData: lqc.Sheet_Activity_ActivityBuff;
                let buffDatas = cfg.activity.activity_buff.getGroup(buffId);
                for (let data of buffDatas) {
                    if (data.buff_level == level + 1) {
                        nextData = data;
                        break;
                    }
                }
                if (!nextData) continue;
                if (nextData.unlock_params[1]) {
                    let delta = UI_Activity.getActivityDeltaDay(UI_Activity_24ba_Upgrade.activityId);
                    if (delta < nextData.unlock_params[1]) {
                        continue;
                    }
                }
                if (nextData.unlock_params[2]) {
                    if (UI_Activity_24ba.activityLevel < nextData.unlock_params[2]) {
                        continue;
                    }
                }
                if (nextData.upgrade_resource_count <= count) return true;
            }

            // let delta = UI_Activity.getActivityDeltaDay(this.activityId);
            // let localDelta = Laya.LocalStorage.getItem('24ba_Upgrade_Time');
            // if (localDelta && delta == Number(localDelta)) return false;

            // let level = UI_Activity.getActivityBuffLevel(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            // let limitCount = UI_Activity_24ba.activityData.daily_buy_limit - UI_Activity_24ba.getBuyProposalCount();
            // let cost = UI_Activity_24ba.activityData.proposal_consume;
            // let buffAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            // cost -= buffAdd;
            // if (level > 0 && limitCount > 0 && count >= cost) {
            //     return true;
            // }

            return false;
        }
        constructor() {
            super(new ui.lobby.activity_24ba.activity_24ba_upgradeUI());
            UI_Activity_24ba_Upgrade.Inst = this;
        }

        public static getEffectLevelUpText(type: EBABuffType, descId: number, nowEffect: number, nextEffect: number) {
            let desc: string = game.Tools.eventStrOfLocalization(descId);
            const isXingYe = type == EBABuffType.xingye;
            if (isXingYe) desc = desc.replace('%', '');
            desc = `[color=#753821]${ desc }[/color]`;
            desc = desc.replace('{0}', isXingYe ? nowEffect + '%' : nowEffect.toString());
            if (nextEffect) {
                const nextStr = isXingYe ? nextEffect + '%' : nextEffect.toString();
                // desc += ` [img]${game.Tools.localUISrc('myres/activity_2501miaohui/img_28.png')}[/img] [color=#28b615]${nextStr}[/color]`;
                desc += ` [color=#30ce19]${ game.Tools.strOfLocalization(4265) }[/color] [color=#28b615]${ nextStr }[/color]`;
            }
            return game.Tools.ParseText(desc);
        }
        private root: Laya.Sprite;
        private listItemUpgrade: ItemUpgrade[];
        // private pageBuyResult: PageBuyResult;
        // private pageUpgradeResult: PageUpgradeResult;
        // private labelProposalTip: Laya.Label;
        // private labelBuyCost: Laya.Label;
        // private proposalSkill: Laya.Sprite;
        // private labelBuyCostFinal: Laya.Label;
        // private btnBuy: Laya.Button;
        // private buyRedPoint: Laya.Sprite;

        private itemListener: Laya.Handler;
        private locking: boolean;

        public onCreate() {

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.listItemUpgrade = [];
            for (let i = 0; i < 3; ++i) {
                this.listItemUpgrade.push(new ItemUpgrade(this.root.getChildByName('upgrade_' + i) as Laya.Sprite, i));
            }
            this.showAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).show;
            this.hideAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).hide;
            // this.showBuyResultAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).ani3;
            // this.hideBuyResultAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).ani4;
            // this.showUpgradeAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).ani5;
            // this.hideUpgradeAnim = (this.me as ui.lobby.activity_24ba.activity_24ba_upgradeUI).ani6;
            // this.pageBuyResult = new PageBuyResult(this.me.getChildByName('buy_result') as Laya.Sprite, this.showBuyResultAnim, this.hideBuyResultAnim);
            // this.pageUpgradeResult = new PageUpgradeResult(this.me.getChildByName('char_upgrade') as Laya.Sprite, this.showUpgradeAnim, this.hideUpgradeAnim);

            // let buyProposal = this.root.getChildByName('buy_proposal') as Laya.Sprite;
            // this.labelProposalTip = buyProposal.getChildByName('tip') as Laya.Label;
            // this.labelBuyCost = buyProposal.getChildByName('cost').getChildByName('cost') as Laya.Label;
            // this.proposalSkill = buyProposal.getChildByName('cost').getChildByName('skill') as Laya.Sprite;
            // this.btnBuy = buyProposal.getChildByName('btn_buy') as Laya.Button;
            // this.buyRedPoint = this.btnBuy.getChildByName('redpoint') as Laya.Sprite;
            // (buyProposal.getChildByName('btn_buy') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
            //     if (this.locking) return;
            //     this.onBuyProposalBtnClick();
            // });

            // this.labelBuyCostFinal = this.proposalSkill.getChildByName('cost') as Laya.Label;
            // if (!UI_Activity_24ba.activityData) return;
            // this.labelBuyCost.text = UI_Activity_24ba.activityData.proposal_consume.toString();
            this.itemListener = new Laya.Handler(this, this.refreshAllCost);

            (this.me.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            // if (GameMgr.client_language == 'en') {
            //     (this.root.getChildByName('btn_back').getChildByName('title') as Laya.Label).x = 43;
            // }
            // if (GameMgr.client_language == 'kr') {
            //     this.labelProposalTip.scaleX = this.labelProposalTip.scaleX * 0.9;
            //     this.labelProposalTip.scaleY = this.labelProposalTip.scaleY * 0.9;
            // }
        }

        public show() {
            // this.pageBuyResult.close(false);
            this.enable = true;
            this.refreshProposalCost();
            for (let item of this.listItemUpgrade) {
                item.show();
            }

            // view.AudioMgr.PlayAudio(10125);
            // // 记录当前打开是第几天
            // let delta = UI_Activity.getActivityDeltaDay(UI_Activity_24ba_Upgrade.activityId);
            // let localDelta = Laya.LocalStorage.getItem('24ba_Upgrade_Time');
            // if (!localDelta || delta != Number(localDelta)) {
            //     let count = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id);
            //     let level = UI_Activity.getActivityBuffLevel(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            //     let limitCount = UI_Activity_24ba.activityData.daily_buy_limit - UI_Activity_24ba.getBuyProposalCount();
            //     let cost = UI_Activity_24ba.activityData.proposal_consume;
            //     let buffAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            //     cost -= buffAdd;
            //     if (level > 0 && limitCount > 0 && count >= cost) {
            //         Laya.LocalStorage.setItem('24ba_Upgrade_Time', delta.toString());
            //     }
            // }



            UI_Bag.add_item_listener(UI_Activity_24ba.activityData.funds_id, this.itemListener);
            // this.pageUpgradeResult.close(false);
            // this.pageBuyResult.close(false);

            //播放开始动画
            this.locking = true;
            this.showAnim.play(0, false);
            Laya.timer.once(this.showAnim.count * this.showAnim.interval, this, () => {
                this.locking = false;
            });
        }


        public close() {
            if (this.locking) return;
            //播放关闭动画
            this.locking = true;
            this.hideAnim.play(0, false);
            Laya.timer.once(this.hideAnim.count * this.hideAnim.interval, this, () => {
                this.locking = false;
                this.enable = false;
                UI_Activity_24ba.Inst.refreshEvent();
                UI_Activity_24ba.Inst.refreshRedPoint();
                UI_Bag.remove_item_listener(UI_Activity_24ba.activityData.funds_id, this.itemListener);
            });
        }

        // 刷新所有按钮的货币
        private refreshAllCost() {
            this.refreshProposalCost();
            for (let item of this.listItemUpgrade) {
                item.refreshCost();
            }
        }

        // 升级按钮点击
        public onUpgradeBtnClick(type: EBABuffType, count: number) {
            if (this.locking) return;
            if (UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id) < count) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4569));
                return;
            }


            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'upgradeActivityBuff', { buff_id: UI_Activity_24ba_Upgrade.buffIds[type] }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('upgradeActivityBuff', err, res);
                } else {
                    // this.pageUpgradeResult.show(type, UI_Activity.getActivityBuffLevel(UI_Activity_24ba_Upgrade.buffIds[type]));
                    UI_Activity.upgradeActivityBuff(UI_Activity_24ba_Upgrade.buffIds[type]);
                    this.listItemUpgrade[type].show(true);
                    // if (type == EBABuffType.alu) {
                    //     this.refreshProposalCost();    
                    // }
                    uiscript.UI_Activity_24ba.Inst.refreshRedPoint();
                }
            });
        }

        public refreshProposalCost() {
            // let level = UI_Activity.getActivityBuffLevel(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            // let limitCount = UI_Activity_24ba.activityData.daily_buy_limit - UI_Activity_24ba.getBuyProposalCount();
            // if (level == 0) {
            //     this.labelProposalTip.text = game.Tools.strOfLocalization(4264);
            //     this.setGrayDisable(true);
            //     this.labelProposalTip.color = UI_Activity_24ba_Upgrade.colorRed;

            // } else {

            //     this.labelProposalTip.text = game.Tools.strOfLocalization(4243, [limitCount.toString(), UI_Activity_24ba.activityData.daily_buy_limit.toString()]);
            //     this.setGrayDisable(false);
            //     this.labelProposalTip.color = UI_Activity_24ba_Upgrade.colorWhite;
            // }
            // let cost = UI_Activity_24ba.activityData.proposal_consume;
            // let buffAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            // cost -= buffAdd;
            // let enough = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id) >= cost;
            // if (buffAdd > 0) {
            //     this.proposalSkill.visible = true;
            //     this.labelBuyCost.color = UI_Activity_24ba_Upgrade.colorWhite;
            //     this.labelBuyCostFinal.color = enough ? UI_Activity_24ba_Upgrade.colorWhite : UI_Activity_24ba_Upgrade.colorRed;
            //     this.labelBuyCostFinal.text = cost.toString(); 
            // } else {
            //     this.proposalSkill.visible = false;
            //     this.labelBuyCost.color = enough ? UI_Activity_24ba_Upgrade.colorWhite : UI_Activity_24ba_Upgrade.colorRed;
            // }
            // this.buyRedPoint.visible = false;
        }

        private onBuyProposalBtnClick() {
            // if (UI_Activity_24ba.getBuyProposalCount() >= UI_Activity_24ba.activityData.daily_buy_limit) {
            //     UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4244));
            //     return;
            // }
            // let cost = UI_Activity_24ba.activityData.proposal_consume;
            // let buffAdd = UI_Activity.getActivityBuffAdd(UI_Activity_24ba_Upgrade.buffIds[EBABuffType.alu]);
            // cost -= buffAdd;
            // let enough = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id) >= cost;
            // if (!enough) {
            //     UI_Info_Small.Inst.show(game.Tools.strOfLocalization(4569));
            //     return;
            // }
            // this.locking = true;
            // app.NetAgent.sendReq2Lobby('Lobby', 'buyFestivalProposal', {activity_id: UI_Activity_24ba.activityId}, (err, res)=>{
            //     this.locking = false;
            //     if (err || res['error']) {
            //         UIMgr.Inst.showNetReqError('buyFestivalProposal', err, res);
            //     } else {
            //         // this.pageBuyResult.show();
            //         Laya.timer.once(100, this, ()=>{
            //             this.refreshProposalCost();
            //             // UI_Activity_24ba.Inst.refreshEvent(false);
            //         })
            //     }
            // });
        }

        private setGrayDisable(gray: boolean) {
            // let image = this.btnBuy.getChildByName('image') as Laya.Image;
            // let text = this.btnBuy.getChildByName('text') as Laya.Label;
            // this.btnBuy.mouseEnabled = !gray;
            // image.skin = game.Tools.localUISrc(gray ? 'myres/activity_2404ba/btn_grey.png' : 'myres/activity_2404ba/btn_yellowgrey.png');
            // text.color = gray ? '#626e7f' : '#6D4B21';
        }

        public onEnable() {
            Laya.stage.event(BA_Page_EventId.DO_SHOW_ANIMATION, UI_Activity_24ba_Upgrade.activityId);
            UI_Bag.add_item_listener(UI_Activity_24ba.activityData.funds_id, this.itemHandler);
        }

        public onDisable() {
            // this.pageBuyResult.close(false);
            // this.pageUpgradeResult.close(false);
            Laya.stage.event(BA_Page_EventId.DO_HIDE_ANIMATION, UI_Activity_24ba_Upgrade.activityId);
            UI_Bag.remove_item_listener(UI_Activity_24ba.activityData.funds_id, this.itemHandler);
        }
    }

    class ItemUpgrade {
        private me: Laya.Sprite;
        private bg: Laya.Image;
        private labelName: Laya.Label;
        private labelLevelNow: Laya.Label;
        // private levelArrow: Laya.Sprite;
        // private labelLevelNext: Laya.Label;
        private desc: Laya.HTMLDivElement;
        // private line: Laya.Sprite;
        private upgrade: Laya.Sprite;
        private labelCost: Laya.Label;
        private limit: Laya.Sprite;
        private labelLimit: Laya.Label;
        private iconLimit: Laya.Sprite;
        private max: Laya.Image;
        private btnUpgrade: Laya.Button;
        private redpoint: Laya.Sprite;

        private nextData: lqc.Sheet_Activity_ActivityBuff;

        private type: EBABuffType;
        private effect: game.UIEffect;

        constructor(me: Laya.Sprite, type: EBABuffType) {
            this.me = me;
            this.type = type;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            // game.LoadMgr.setImgSkin(this.char, `myres/activity_2404ba/lihui/${EBABuffType[this.type]}1.png`, null, 'UI_Activity_24ba');
            this.labelName = this.me.getChildByName('name') as Laya.Label;
            // let level = this.me.getChildByName('level') as Laya.Label;
            // this.labelLevelNext = level.getChildByName('next') as Laya.Label;
            this.labelLevelNow = this.me.getChildByName('now') as Laya.Label;
            // this.levelArrow = level.getChildByName('arrow') as Laya.Sprite;
            this.desc = this.me.getChildByName('desc') as Laya.HTMLDivElement;
            // this.line = this.me.getChildByName('info').getChildByName('line') as Laya.Sprite;
            this.desc.style.leading = 7;
            this.desc.style.fontSize = 26;
            this.desc.style.fontFamily = UI_Mail.font;

            this.upgrade = this.me.getChildByName('upgrade') as Laya.Sprite;
            this.labelCost = this.upgrade.getChildByName('cost').getChildByName('cost') as Laya.Label;
            this.limit = this.upgrade.getChildByName('limit') as Laya.Sprite;
            this.labelLimit = this.limit.getChildByName('text') as Laya.Label;
            this.iconLimit = this.limit.getChildAt(0) as Laya.Sprite;
            this.max = this.me.getChildByName('max') as Laya.Image;
            // let bg = this.me.getChildByName('name').getChildByName('bg') as Laya.Image;
            // bg.width += this.labelName.trueWidth - this.labelName.width;
            this.btnUpgrade = this.upgrade.getChildByName('btn_upgrade') as Laya.Button;
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                if (!this.nextData) return;
                UI_Activity_24ba_Upgrade.Inst.onUpgradeBtnClick(this.type, this.nextData.upgrade_resource_count);
            });
            this.redpoint = this.btnUpgrade.getChildByName('redpoint') as Laya.Sprite;
        }

        public show(isUpgrade?: boolean) {
            if (isUpgrade) {
                this.destroyEffect();
                this.effect = game.FrontEffect.Inst.create_ui_effect(this.me, `scene/effect_25chunjie_upgrade.lh`, new Laya.Point(210, 520), 1);
                Laya.timer.once(2000, this, this.destroyEffect);
                view.AudioMgr.PlayAudio(Activity24BaAudio.skill_level_up);
            }
            let buffId = UI_Activity_24ba_Upgrade.buffIds[this.type];
            let level = UI_Activity.getActivityBuffLevel(buffId);
            let buffDatas = cfg.activity.activity_buff.getGroup(buffId);
            let nowData: lqc.Sheet_Activity_ActivityBuff, nextData: lqc.Sheet_Activity_ActivityBuff;
            for (let data of buffDatas) {
                if (data.buff_level == level) {
                    nowData = data;
                } else if (data.buff_level == level + 1) {
                    nextData = data;
                }
            }
            if (!nextData && !nowData) return;
            if (!nextData) {
                this.max.visible = true;
                this.upgrade.visible = false;
                // this.labelLevelNext.visible = false;
                // this.levelArrow.visible = false;
                // this.labelLevelNow.x = this.labelLevelNext.x;
            } else {
                this.max.visible = false;
                this.upgrade.visible = true;
                // this.labelLevelNext.visible = true;
                // this.levelArrow.visible = true;
                // this.labelLevelNext.text = game.Tools.strOfLocalization(4236, [(level + 1).toString()]);
                this.labelCost.text = nextData.upgrade_resource_count.toString();
                this.nextData = nextData;
                this.refreshLimitState();
            }
            this.labelName.text = game.Tools.eventStrOfLocalization((nowData || nextData).effect_desc_2);
            this.labelLevelNow.text = game.Tools.strOfLocalization(!nextData ? 4571 : 4236, [level.toString()]);
            let descId = nextData ? nextData.effect_desc : nowData.effect_desc;
            this.desc.innerHTML = UI_Activity_24ba_Upgrade.getEffectLevelUpText(this.type, descId, nowData ? nowData.effect : 0, nextData ? nextData.effect : 0);
            // this.line.y = this.desc.contextHeight + 20;
            this.refreshCost();
            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_2501miaohui/img_82.png', null, 'UI_Activity_24ba');
        }

        private refreshLimitState() {
            //没有达到时间需求
            if (this.nextData.unlock_params[1]) {

                //活动已经过去了多少秒
                let activityDeltaSeconds = UI_Activity.getActivityDeltaSeconds(UI_Activity_24ba_Upgrade.activityId);
                //需要几天解锁
                let timeLimit = this.nextData.unlock_params[1];
                //剩余秒数
                let restSeconds = timeLimit * 24 * 60 * 60 - activityDeltaSeconds;
                if (restSeconds > 0) {
                    this.setLimitText(UI_Activity_24ba.getLockTimeText(restSeconds));
                    return;
                }
            }
            //没有达到庆典等级需求
            if (this.nextData.unlock_params[2]) {
                if (UI_Activity_24ba.activityLevel < this.nextData.unlock_params[2]) {
                    let levelData = UI_Activity_24ba.getLevelData(this.nextData.unlock_params[2]);
                    this.setLimitText(game.Tools.strOfLocalization(4570, [game.Tools.eventStrOfLocalization(levelData.level_name)]));
                    return;
                }
            }
            this.btnUpgrade.mouseEnabled = true;
            this.limit.visible = false;
        }

        private setLimitText(str: string) {
            this.limit.visible = true;
            this.btnUpgrade.mouseEnabled = false;
            this.labelLimit.text = str;
            let textWidth = this.labelLimit.trueWidth;
            this.iconLimit.x = this.labelLimit.x - textWidth / 2 - 3 - 28;
        }

        public refreshCost() {
            if (!this.nextData) {
                this.redpoint.visible = false;
                return;
            }
            let enough = UI_Bag.get_item_count(UI_Activity_24ba.activityData.funds_id) >= this.nextData.upgrade_resource_count;
            this.labelCost.color = enough ? "#C38236" : "#C7431B";
            this.redpoint.visible = false;
            this.setGrayDisable(!enough || this.limit.visible);
        }

        private setGrayDisable(gray: boolean) {
            let image = this.btnUpgrade.getChildByName('image') as Laya.Image;
            // let text = this.btnUpgrade.getChildByName('text') as Laya.Label;
            this.btnUpgrade.mouseEnabled = !gray;
            image.skin = game.Tools.localUISrc(gray ? 'myres/activity_2501miaohui/img_56.png' : 'myres/activity_2501miaohui/img_54.png');
            // text.color = gray ? '#626e7f' : '#6D4B21';
        }

        private destroyEffect() {
            if (this.effect) {
                this.effect.destory();
                this.effect = null;
            }
        }
    }

    /** buff名称+对应图片名 */
    export enum EBABuffType {
        baizi,
        xingye,
        muyue
    }
}
