/**
* 魔法牌麻将
*/
module uiscript {


    export class UI_Activity_Amulet extends UIBase {
        public static Inst: UI_Activity_Amulet;
        /**
        * 麻将数据
        */
        public static activityId: number = 250811;
        public static upgradeData: game.IActivityAmuletUpgradeData = {
            skill: []
        };
        public static amuletIllustratedBook: game.IActivityAmuletIllustratedBookData;
        public static amuletLevelDic: basic.Dictionary<number, lqc.Sheet_Amulet_AmuletGames>;
        public static amuletLevelGroupDic: basic.Dictionary<number, number[]>
        public static amuletActivityConfig: lqc.Sheet_Amulet_AmuletActivity;
        public static needFetch: boolean = true;
        public static favoriteId: number = 0;
        public static recentRecords: game.IActivityAmuletGameRecordData[];
        public static statistic: game.IActivityAmuletStatisticData;
        public static locking: boolean;


        public static initBriefData() {
            if (!this.needFetch) return;
            this.needFetch = false;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivityFetchBrief, { activity_id: this.activityId }, (err, res: game.IResAmuletActivityFetchBrief) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.amuletActivityFetchBrief, err, res);
                } else {
                    let data = res || {} as game.IResAmuletActivityFetchBrief;
                    this.upgradeData = {
                        skill: []
                    };
                    this.amuletIllustratedBook = {} as game.IActivityAmuletIllustratedBookData;
                    this.statistic = {} as game.IActivityAmuletStatisticData;
                    this.recentRecords = [];
                    if (data.upgrade) {
                        for (let key in data.upgrade) {
                            const value = data.upgrade[key];
                            const valueType = typeof value;
                            if (valueType != 'function') {
                                this.upgradeData[key] = game.Tools.deepCopy(data.upgrade[key]);
                            }
                        }
                    }
                    if (data.illustrated_book) {
                        for (let key in data.illustrated_book) {
                            const value = data.illustrated_book[key];
                            const valueType = typeof value;
                            if (valueType != 'function') {
                                this.amuletIllustratedBook[key] = game.Tools.deepCopy(data.illustrated_book[key]);
                            }
                        }
                    }
                    if (data.game_records) {
                        this.recentRecords = data.game_records;
                    }
                    if (data.statistic) {
                        this.statistic = data.statistic;
                    }
                }
            });
        }

        public static haveRedPoint(): boolean {
            return UI_AmuletReward.haveRedPoint();
        }

        public static isPropInIllustratedBook(id: number): boolean {
            if (!this.amuletIllustratedBook.effect_collection) return false;
            return this.amuletIllustratedBook.effect_collection.indexOf(id) != -1;
        }

        public static isBadgeInIllustratedBook(id: number): boolean {
            if (!this.amuletIllustratedBook.badge_collection) return false;
            return this.amuletIllustratedBook.badge_collection.indexOf(id) != -1;
        }

        public static initConfig() {
            this.amuletLevelDic = new basic.Dictionary();
            this.amuletLevelGroupDic = new basic.Dictionary();
            this.amuletActivityConfig = cfg.amulet.amulet_activity.get(UI_Activity_Amulet.activityId);
            let bossConfig = cfg.amulet.amulet_games.getGroup(UI_Activity_Amulet.activityId);
            for (let index = 0; index < bossConfig.length; index++) {
                let boss = bossConfig[index];
                this.amuletLevelDic.set(boss.level, boss)
                if (!this.amuletLevelGroupDic.has(boss.level_group)) {
                    this.amuletLevelGroupDic.set(boss.level_group, []);
                }
                let bossArr = this.amuletLevelGroupDic.get(boss.level_group);
                bossArr.push(boss.level);
            }
            UI_PropDetailCard.initEffectGroup();
        }

        public static enterToPokerGame(data: game.IAmuletGameData) {
            if (!UI_Activity.activity_is_running(UI_Activity_Amulet.activityId)) return;
            GameMgr.Inst.enterAmuletGame(data);
            this.needFetch = false;
        }


        public static initData(data: game.IActivityAmuletData) {
            this.favoriteId = data.book_effect_id || 0;
            this.upgradeData = {
                skill: []
            };
            this.statistic = {} as game.IActivityAmuletStatisticData;
            this.recentRecords = [];
            this.amuletIllustratedBook = {} as game.IActivityAmuletIllustratedBookData;
            if (data.upgrade) {
                for (let key in data.upgrade) {
                    const value = data.upgrade[key];
                    const valueType = typeof value;
                    if (valueType != 'function') {
                        this.upgradeData[key] = game.Tools.deepCopy(data.upgrade[key]);
                    }
                }
            }
            if (data.illustrated_book) {
                for (let key in data.illustrated_book) {
                    const value = data.illustrated_book[key];
                    const valueType = typeof value;
                    if (valueType != 'function') {
                        this.amuletIllustratedBook[key] = game.Tools.deepCopy(data.illustrated_book[key]);
                    }
                }
            }
            if (data.game_records) {
                this.recentRecords = data.game_records;
            }
            if (data.statistic) {
                this.statistic = data.statistic;
            }
            if (!this.amuletLevelDic) {
                this.initConfig();
            }
        }
        public static updateStrengthenData(msg: game.IReqAmuletActivitySetSkillLevel) {
            if (msg.activity_id == UI_Activity_Amulet.activityId) this.upgradeData.skill = msg.skill;
        }

        public static setFavorite(targetId: number) {
            if (this.locking) return;
            this.locking = true;
            let param: game.IReqAmuletActivitySelectBookEffect = {
                activity_id: this.activityId,
                effect_id: targetId
            }
            app.Log.log(game.ERequest.amuletActivitySelectBookEffect + '  param ====  ' + JSON.stringify(param));
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivitySelectBookEffect, param, (err, res: game.IResAmuletActivityFetchBrief) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.amuletActivityFetchBrief, err, res);
                } else {
                    this.favoriteId = targetId;
                    UI_AmuletOverview.Inst.refreshPropFavorite();
                }
            });
        }

    }
}