module uiscript {
    /**
    * 牌库
    */
    export class UI_AmuletCardLibrary extends UI_PopupBase {
        public static Inst: UI_AmuletCardLibrary;
        private paiDatas: amulet.MJPai[];
        private templete: Laya.Sprite;
        private comPais: Laya.Sprite[];
        private pais: UI_MJP[];
        constructor() {
            super(new ui.amulet.amulet_cardlibraryUI());
            UI_AmuletCardLibrary.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.outClose = true;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.templete = this.root.getChildByName('templete') as Laya.Sprite;
            this.comPais = [this.templete];
            this.pais = [new UI_MJP(this.templete.getChildByName('pai') as Laya.Sprite)];
            for (let i = 1; i < 37; i++) {
                let com = this.templete.scriptMap['capsui.UICopy'].getNodeClone() as Laya.Sprite;
                this.root.addChild(com);
                this.comPais.push(com);
                this.pais.push(new UI_MJP(com.getChildByName('pai') as Laya.Sprite));
                let posIndex = i + 8; //1到9万空出来
                com.x = (posIndex % 10) * 118 + 167;
                com.y = 215 + 158 * Math.floor(posIndex / 10);
            }
            (this.root.getChildByName('btn_confirm') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                this.hide();
            }, null, false);
        }

        show() {
            if (this.locking) return;
            super.show();
            if (!this.paiDatas) {
                this.paiDatas = [];
                const paiLibrary = amulet.AmuletDesktopMgr.Inst.paiLibrary;
                for (let key in paiLibrary) {
                    let card = amulet.MJPai.Create({
                        id: -1,
                        tile: key
                    })
                    if (!card.baida) {
                        this.paiDatas.push(card);
                    }
                }
                this.paiDatas.sort((a, b) => { return amulet.MJPai.Distance(a, b); });
            }
            this.refresh();
            this.comPais.forEach((com, index) => {
                let targetAlpha = com.alpha;
                com.alpha = 0;
                com.scale(0.5, 0.5);
                Laya.Tween.clearAll(com);
                Laya.Tween.to(com, { alpha: targetAlpha, scaleX: 1, scaleY: 1 }, 100, Laya.Ease.quadInOut, null, 100 + index * 17);
            })
        }

        refresh() {
            this.comPais.forEach((comPai, index) => {
                if (this.paiDatas[index]) {
                    comPai.visible = true;
                    this.pais[index].show(this.paiDatas[index].toString(false));
                    if (UI_AmuletDesktopInfo.Inst.desktopStage == amulet.EAmuletGameState.DuringShop) {
                        (comPai.getChildByName('count') as Laya.Label).text = '';
                        comPai.alpha = 1;
                    } else {
                        let leftCount = amulet.AmuletDesktopMgr.Inst.getLeftPaiCount(this.paiDatas[index].toString(), true);
                        (comPai.getChildByName('count') as Laya.Label).text = leftCount.toString();
                        comPai.alpha = leftCount == 0 ? 0.35 : 1;
                    }
                    (comPai.getChildByName('score') as Laya.Label).color = comPai.alpha == 1 ? '#a5aef7' : '#ffffff';
                    (comPai.getChildByName('score') as Laya.Label).text = SciNum.getSciStr(amulet.AmuletDesktopMgr.Inst.getTileScore(this.paiDatas[index].toString()), 1, 5, true);
                    (comPai.getChildByName('bg') as Laya.Image).width = (comPai.getChildByName('score') as Laya.Label).textField.textWidth > 84 ? 90 :
                        (comPai.getChildByName('score') as Laya.Label).textField.textWidth + 6;
                    if (amulet.AmuletDesktopMgr.Inst.isTianPai(this.paiDatas[index])) {
                        this.pais[index].setFiltersState(EUIPaiFilterState.yellow);
                    } else {
                        this.pais[index].setFiltersState(EUIPaiFilterState.none);
                    }
                } else {
                    comPai.visible = false;
                }
            })
        }

        hide() {
            super.hide();
        }
    }
}