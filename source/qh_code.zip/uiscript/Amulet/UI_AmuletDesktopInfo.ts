/**
* name 
*/
module uiscript {
	export class UI_AmuletDesktopInfo extends UIBase {
		public static Inst: UI_AmuletDesktopInfo = null;

		private comPropsCardsBg: Laya.Sprite;
		private txtBunusCardsCount: Laya.Label;
		private btnReturn: Laya.Button;
		private btnCurrencyStar: Laya.Button;
		private txtCurrencyStarCount: Laya.Label;
		private chooseBoss: UI_AmuletChooseBoss;
		private comGaming: Laya.Sprite;
		public dorasTip: UI_AmuletDorasTip;
		public topBossBlood: UI_AmuletBossBlood;
		private btnNowLevel: Laya.Button;
		private comContainerShout: Laya.Sprite;
		private tipReplace: Laya.Sprite;
		private tipLock: Laya.Sprite;
		private shout_origin_x: number;
		private shout_origin_y: number;
		private shoutIllust: Laya.Image;
		private showIllustRect: UIRect;

		private huPaiResult: UI_AmuletHuPaiResult;
		private amuletShop: UI_AmuletShop;

		private btn_double_pass: Laya.Button;
		public min_double_time: number = 0;
		public max_double_time: number = 0;
		private huleshow: UI_AmuletHuleshow;
		private _container_fun: Laya.Sprite;
		private _fun_in: Laya.Sprite = null; // 功能按键详细部分
		private _fun_out: Laya.Sprite = null; // 功能按键非详细部分
		private _fun_in_spr: Laya.Sprite; // 功能按键详细的弹出关闭部分
		private aniShowBoss: Laya.FrameAnimation;
		private aniHideBoss: Laya.FrameAnimation;
		private aniShowDesktop: Laya.FrameAnimation;
		private aniShowVs: Laya.FrameAnimation;
		private aniHideShop: Laya.FrameAnimation;
		private effectFeverTime: Laya.Scene;
		private effectBg: Laya.Scene;
		private effectShop: game.UIEffect;
		private comEffect: Laya.Sprite;
		private comEffectFeverTime: Laya.Sprite;
		private aniEffect: Catfood.CAnimator;
		private effectBg1: Laya.Sprite3D;
		private effectBg2: Laya.Sprite3D;
		private effectFeverTime2: Laya.Sprite3D;
		private effectAniBg1: Catfood.CAnimator;
		private effectAniBg2: Catfood.CAnimator;

		public aniLock: number = 0;

		public currencyCount: SciNum;
		public desktopStage: amulet.EAmuletGameState = amulet.EAmuletGameState.CheckBoss;  //仅用于表示目前显示的状态
		private audioId: number;

		constructor() {
			super(new ui.amulet.amulet_desktopinfoUI());
			UI_AmuletDesktopInfo.Inst = this;
		}

		public onCreate() {
			this.comPropsCardsBg = this.me.getChildByName('card_bg') as Laya.Sprite;
			this.txtBunusCardsCount = this.comPropsCardsBg.getChildByName('card_count') as Laya.Label;
			this.btnReturn = this.me.getChildByName('back') as Laya.Button;

			this.btnCurrencyStar = this.me.getChildByName('currency') as Laya.Button;
			this.txtCurrencyStarCount = this.btnCurrencyStar.getChildByName('count') as Laya.Label;

			let aniShow = (this.me as ui.amulet.amulet_desktopinfoUI).showBoss02;
			this.chooseBoss = new UI_AmuletChooseBoss(this.me.getChildByName('choose_boss') as Laya.Sprite, this, aniShow);
			this.comGaming = this.me.getChildByName('gaming') as Laya.Sprite;

			this.dorasTip = new UI_AmuletDorasTip(this.comGaming.getChildByName('pai_tip') as Laya.Sprite, this);
			this.topBossBlood = new UI_AmuletBossBlood(this.comGaming.getChildByName('boss') as Laya.Sprite, this);
			this.tipReplace = this.comGaming.getChildByName('tip_replace') as Laya.Sprite;
			this.tipLock = this.comGaming.getChildByName('tip_lock') as Laya.Sprite;
			(this.tipReplace.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(20020);
			(this.tipReplace.getChildAt(0) as Laya.Image).width = (this.tipReplace.getChildAt(1) as Laya.Label).textField.width + 450;

			this.btnNowLevel = this.me.getChildByName('level') as Laya.Button;
			this.comContainerShout = this.comGaming.getChildByName('container_shout') as Laya.Sprite;
			this.comContainerShout.visible = false;
			this.shoutIllust = this.comContainerShout.getChildByName('illust').getChildByName('illust') as Laya.Image;
			this.showIllustRect = UIRect.CreateFromSprite(this.shoutIllust);
			this.shout_origin_x = this.comContainerShout.x;
			this.shout_origin_y = this.comContainerShout.y;

			this.huPaiResult = new UI_AmuletHuPaiResult(this.comGaming.getChildByName('hupai_result') as Laya.Sprite, this);

			this.amuletShop = new UI_AmuletShop(this.me.getChildByName('shop') as Laya.Sprite, this);

			this.btn_double_pass = this.me.getChildByName('btn_double_pass') as Laya.Button;

			this.huleshow = new UI_AmuletHuleshow(this.me.getChildByName('hule_show') as Laya.Sprite);

			this.comEffect = this.me.getChildByName('effect') as Laya.Sprite;
			this.aniShowBoss = (this.me as ui.amulet.amulet_desktopinfoUI).showBoss;
			this.aniHideBoss = (this.me as ui.amulet.amulet_desktopinfoUI).hideBoss;
			this.aniShowDesktop = (this.me as ui.amulet.amulet_desktopinfoUI).showDesktop;
			this.aniShowVs = (this.me as ui.amulet.amulet_desktopinfoUI).damoVS;
			this.aniHideShop = (this.me as ui.amulet.amulet_desktopinfoUI).hideShop;
			this._initFunc();
			this._initAutoFunc();
		}

		onFeverTimeLoaded(root: Laya.Sprite) {
			this.comEffectFeverTime = root.getChildByName('effect') as Laya.Sprite;
			this.topBossBlood.onFeverTimeLoaded(root);
		}

		private _initAutoFunc() {
			this._container_fun = this.comGaming.getChildByName('container_func') as Laya.Sprite;
			this._fun_in = this._container_fun.getChildByName('in') as Laya.Sprite;
			this._fun_out = this._container_fun.getChildByName('out') as Laya.Sprite;
			this._fun_in_spr = this._fun_in.getChildByName('in_func') as Laya.Sprite;
			let btn_func: Laya.Button = this._fun_out.getChildByName('btn_func') as Laya.Button;
			let btn_func2: Laya.Button = this._fun_out.getChildByName('btn_func2') as Laya.Button;
			let btn_func_in: Laya.Button = this._fun_in_spr.getChildByName('btn_func') as Laya.Button;
			btn_func.clickHandler = btn_func2.clickHandler = new Laya.Handler(this, () => {
				let target_x: number = 0;
				target_x = -270;
				Laya.Tween.to(this._container_fun, { x: -624 }, 60, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
					this._fun_in.visible = true;
					this._fun_out.visible = false;
					Laya.Tween.to(this._container_fun, { x: target_x }, 140, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
						btn_func.mouseEnabled = true;
						btn_func2.mouseEnabled = true;
						btn_func_in.mouseEnabled = true;
						this._fun_out.visible = false;
					}), 0, true, true);
				}));

				btn_func.mouseEnabled = false;
				btn_func2.mouseEnabled = false;
				btn_func_in.mouseEnabled = false;
			}, null, false);

			btn_func_in.clickHandler = new Laya.Handler(this, () => {
				let target_x: number = -546;

				Laya.Tween.to(this._container_fun, { x: -624 }, 140, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
					this._fun_in.visible = false;
					this._fun_out.visible = true;
					Laya.Tween.to(this._container_fun, { x: target_x }, 60, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
						btn_func.mouseEnabled = true;
						btn_func2.mouseEnabled = true;
						btn_func_in.mouseEnabled = true;
						this._fun_out.visible = true;
					}), 0, true, true);
				}));
				btn_func.mouseEnabled = false;
				btn_func2.mouseEnabled = false;
				btn_func_in.mouseEnabled = false;
			});
			let btn_autolipai = this._fun_in.getChildByName('btn_autolipai') as Laya.Button;
			let btn_autolipai2 = this._fun_out.getChildByName('btn_autolipai2') as Laya.Button;
			let label_autolipai = this._fun_out.getChildByName('autolipai') as Laya.Label;
			let _autolipai: boolean = true;
			this.refreshFuncBtnShow(btn_autolipai, label_autolipai, _autolipai);
			btn_autolipai.clickHandler = btn_autolipai2.clickHandler = Laya.Handler.create(this, () => {
				amulet.AmuletDesktopMgr.Inst.setAutoLiPai(!amulet.AmuletDesktopMgr.Inst.autoLiqi);
				this.refreshFuncBtnShow(btn_autolipai, label_autolipai, amulet.AmuletDesktopMgr.Inst.autoLiqi);
			}, null, false);

			let btn_autohu = this._fun_in.getChildByName('btn_autohu') as Laya.Button;
			let btn_autohu2 = this._fun_out.getChildByName('btn_autohu2') as Laya.Button;
			let label_autohu = this._fun_out.getChildByName('autohu') as Laya.Label;
			this.refreshFuncBtnShow(btn_autohu, label_autohu, false);
			btn_autohu.clickHandler = btn_autohu2.clickHandler = Laya.Handler.create(this, () => {
				amulet.AmuletDesktopMgr.Inst.setAutoHule(!amulet.AmuletDesktopMgr.Inst.autoHule);
				this.refreshFuncBtnShow(btn_autohu, label_autohu, amulet.AmuletDesktopMgr.Inst.autoHule);
			}, null, false);

			let btn_moqie = this._fun_in.getChildByName('btn_automoqie') as Laya.Button;
			let btn_moqie2 = this._fun_out.getChildByName('btn_automoqie2') as Laya.Button;
			let label_automoqie = this._fun_out.getChildByName('automoqie') as Laya.Label;
			this.refreshFuncBtnShow(btn_moqie, label_automoqie, false);
			btn_moqie.clickHandler = btn_moqie2.clickHandler = Laya.Handler.create(this, () => {
				amulet.AmuletDesktopMgr.Inst.setAutoMoQie(!amulet.AmuletDesktopMgr.Inst.autoMoqie);
				this.refreshFuncBtnShow(btn_moqie, label_automoqie, amulet.AmuletDesktopMgr.Inst.autoMoqie);
			}, null, false);

			if (Laya.Browser.onPC && !GameMgr.inConch) {
				btn_func.visible = false;
				btn_autohu2.visible = true;
				btn_autolipai2.visible = true;
				btn_moqie2.visible = true;
			} else {
				btn_func.visible = true;
				btn_autohu2.visible = false;
				btn_autolipai2.visible = false;
				btn_moqie2.visible = false;
			}
		}

		private refreshFuncBtnShow(btn: Laya.Button, label: Laya.Label, value: boolean) {
			let img: Laya.Image = btn.getChildByName('img_choosed') as Laya.Image;
			let labeBtn: Laya.Label = btn.getChildAt(1) as Laya.Label;
			if (!btn.mouseEnabled) {
				label.color = '#bbb7af';
				labeBtn.color = '#bbb7af';
			} else {
				label.color = value ? '#dd7213' : '#d0a681';
				labeBtn.color = '#b06a37';
			}
			img.visible = value;
		}

		public recordDoubleClickTime(t: number) {
			if (this.min_double_time) {
				this.min_double_time = Math.max(0, Math.min(t, this.min_double_time));
			} else {
				this.min_double_time = t;
			}

			if (this.max_double_time) {
				this.max_double_time = Math.max(t, this.max_double_time);
			} else {
				this.max_double_time = t;
			}
		}

		public addScene(scene: Laya.Scene) {
			(this.me.getChildByName('scene') as Laya.Sprite).addChild(scene);
			if (scene.name == 'mjdesktop_amulet_pk') {
				this.effectFeverTime2 = scene.getChildByName('room').getChildByName('bg').getChildByName('fx_qingyun_fevertime3') as Laya.Sprite3D;
			}
		}


		private _initFunc() {
			let __last_click_time: number = 0;
			this.btn_double_pass.clickHandler = Laya.Handler.create(this, () => {
				if (!view.DesktopMgr.double_click_pass) return;
				let t: number = Laya.timer.currTimer;
				if (__last_click_time + 300 > t) {
					if (UI_AmuletOperation.Inst.enable) {
						UI_AmuletOperation.Inst.onDoubleClick();
						this.recordDoubleClickTime(t - __last_click_time);
					}
					else {
						let dodiscard: boolean = amulet.AmuletDesktopMgr.Inst.mainrole.can_discard;
						if (dodiscard) {
							if (amulet.AmuletDesktopMgr.Inst.mainrole.DiscardLastPai()) {
								this.recordDoubleClickTime(t - __last_click_time);
							}
						}
					}
					__last_click_time = 0;
				} else {
					__last_click_time = t;
				}
			}, null, false);
			this.btnReturn.clickHandler = new Laya.Handler(this, () => {
				UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20094), Laya.Handler.create(this, () => {
					amulet.AmuletDesktopMgr.Inst.ClearDesktop();
					uiscript.UI_AmuletDesktopInfo.Inst.resetState();
					uiscript.UI_AmuletHome.Inst.show();
				}));
				UI_SecondConfirm.Inst.setBtnState(true, true);
			}, null, false);
			this.btnNowLevel.clickHandler = new Laya.Handler(this, () => {
				uiscript.UI_AmuletLeveList.Inst.show();
			}, null, false);
		}

		public show() {
			this.enable = true;
			this.comGaming.visible = false;
			this.topBossBlood.enable = false;
			this.chooseBoss.enable = false;
			this.amuletShop.enable = false;
			this.comContainerShout.visible = false;
			this.huPaiResult.enable = false;
			this.effectFeverTime2.active = false;
			if (!this.effectFeverTime) {
				this.effectFeverTime = Laya.loader.getRes('scene/effect_amulet_fevertime_top.ls');
				this.comEffectFeverTime.addChild(this.effectFeverTime);
				this.effectFeverTime.visible = false;
			}
			if (!this.effectShop) {
				this.effectShop = game.FrontEffect.Inst.create_ui_effect(this.comEffect, 'scene/effect_amulet_cardpackage.lh', new Laya.Point(960, 540), 1);
				this.effectShop.effect.addLoadedListener(Laya.Handler.create(this, () => {
					this.effectShop.effect.root.active = false;
				}));
			}
			if (!this.effectBg) {
				this.effectBg = Laya.loader.getRes('scene/effect_amulet_pk_bg.ls');
				(this.me.getChildByName('bg') as Laya.Sprite).addChild(this.effectBg);
				this.effectBg1 = this.effectBg.getChildByName('bg').getChildByName('qingyun_duiju_bg') as Laya.Sprite3D;
				this.effectBg2 = this.effectBg.getChildByName('bg').getChildByName('qingyun_duiju_bg_boss') as Laya.Sprite3D;
				this.effectAniBg1 = (this.effectBg1.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				this.effectAniBg2 = (this.effectBg2.getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			}
			this.effectBg1.active = true;
			this.effectAniBg1.Play('qingyun_duiju_bg_Idie');
			this.effectBg2.active = false;
			this.effectAniBg2.Stop();
		}

		public refreshState(state: amulet.EAmuletGameState, fromHome: boolean) {
			this.desktopStage = state;
			amulet.AmuletDesktopMgr.Inst.playBgm();
			if (state == amulet.EAmuletGameState.CheckBoss) {
				this.effectBg2.active = false;
				this.effectAniBg2.Stop();
				let delay = 250;
				if (this.amuletShop.enable) {
					delay = this.aniHideShop.count * this.aniHideShop.interval;
					this.amuletShop.hide();
				}
				Laya.timer.once(delay, this, () => {
					this.aniHideBoss.stop();
					this.aniShowBoss.stop();
					this.aniShowBoss.play(0, false);
					view.AudioMgr.PlayAudio(10337);
					this.chooseBoss.show();
				})
			} else if (state == amulet.EAmuletGameState.DuringFight) {
				let delay = 0;
				if (this.chooseBoss.enable) {
					this.aniHideBoss.gotoAndStop(0);
					this.aniHideBoss.play(0, false);
					this.chooseBoss.locking = true;
					delay = this.aniHideBoss.count * this.aniHideBoss.interval;
					Laya.timer.once(delay, this, () => {
						this.aniHideBoss.stop();
						this.chooseBoss.locking = false;
						this.chooseBoss.hide();
					});
				}
				let levelConfig = uiscript.UI_Activity_Amulet.amuletLevelDic.get(amulet.AmuletDesktopMgr.Inst.nowLevel);
				if (levelConfig && levelConfig.boss) {
					amulet.AmuletDesktopMgr.Inst.playBgm(10332);
					if (!fromHome) {
						this.effectBg2.active = true;
						this.effectAniBg2.Play('qingyun_duiju_bg_boss_open');
						Laya.timer.once(2000, this, () => {
							this.effectAniBg2.Play('qingyun_duiju_bg_boss_Idie');
						});
					} else {
						this.effectBg1.active = false;
						this.effectAniBg1.Stop();
						this.effectBg2.active = true;
						this.effectAniBg2.Play('qingyun_duiju_bg_boss_Idie');
					}
				}
				this.aniShowVs.gotoAndStop(0);
				Laya.timer.once(delay, this, () => {
					if (!fromHome) {
						this.aniShowDesktop.play(0, false);
						Laya.timer.once(1500, this, () => {
							if (levelConfig && levelConfig.boss) {
								this.effectBg1.active = false;
								this.effectAniBg1.Stop();
							}
							this.aniShowVs.play(0, false);
						});
						Laya.timer.once(1680, this, () => {
							let effect = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/effect_amulet_vs.lh', new Laya.Point(910, 151), 1);
							effect.effect.addLoadedListener(Laya.Handler.create(this, () => {
								effect.effect.root.active = false;
								effect.effect.root.active = true;
							}));
							Laya.timer.once(1000, effect, () => {
								effect.destory();
							})
						});
					} else {
						this.aniShowVs.gotoAndStop(16);
					}
					this.showDesktop();
				})
			} else if (state == amulet.EAmuletGameState.OpenRewardPackage) {
				this.hideDesktop();
				view.AudioMgr.PlayAudio(10155);
				this.aniLock++;
				Laya.timer.once(150, this, () => {
					this.aniLock--;
					const rewardLst = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.level_reward_candidates || [];
					const packageId = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.current_level_reward_pack;
					if (packageId) {
						this.openPropPackage(rewardLst, packageId, false);
					}
				})
			} else if (state == amulet.EAmuletGameState.DuringShop) {
				this.hideDesktop();
				this.aniLock++;
				Laya.timer.once(150, this, () => {
					this.aniLock--;
					view.AudioMgr.PlayAudio(10338);
					this.amuletShop.show(true);
				})
			}
		}

		refreshFeverTimeEffect(visible: boolean) {
			if (this.effectFeverTime) {
				let anim = (this.effectFeverTime.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				let levelConfig = uiscript.UI_Activity_Amulet.amuletLevelDic.get(amulet.AmuletDesktopMgr.Inst.nowLevel);
				let isBoss = levelConfig && levelConfig.boss;
				if (visible && !this.effectFeverTime.visible) {
					this.playFeverTimeBgm();
					this.effectFeverTime.visible = true;
					this.effectFeverTime2.active = true;
					let aniName = isBoss ? 'fx_qingyun2_fevertime_show_boss' : 'fx_qingyun2_fevertime_show1';
					anim.Play(aniName);
				}
				if (!visible && this.effectFeverTime.visible) {
					anim.Play('fx_qingyun2_fevertime_hide');
					this.effectFeverTime2.active = false;
					Laya.timer.once(133, this, () => {
						this.stopFeverTimeBgm();
						this.effectFeverTime.visible = false;
					})
				}
			}
		}

		public resetDesktopBg() {
			this.refreshFeverTimeEffect(false);
			if (this.effectBg) {
				this.effectBg1.active = true;
				this.effectAniBg1.Play('qingyun_duiju_bg_Idie');
				this.effectAniBg2.Play('qingyun_duiju_bg_boss_close');
				Laya.timer.once(200, this, () => {
					this.effectBg2.active = false;
				})
			}
		}

		public showDesktop() {
			this.comGaming.visible = true;
			this.refreshTipReplace();
			this.topBossBlood.refresh();
			this.dorasTip.refresh();
		}

		public hideDesktop() {
			this.comGaming.visible = false;
			this.topBossBlood.enable = false;
		}

		public onEnable(): void {
			game.TempImageMgr.setUIEnable('UI_AmuletDesktopInfo', true);
		}

		public onDisable(): void {
			game.TempImageMgr.setUIEnable('UI_AmuletDesktopInfo', false);
			if (this.effectShop) {
				this.effectShop.destory();
				this.effectShop = null;
			}
		}

		public refreshBossBlood(point: SciNum, anim: boolean = false) {
			this.topBossBlood.refreshScore(point, anim);
		}

		public addBossBlood(point: SciNum, anim: boolean = false, onComplete?: Laya.Handler) {
			this.topBossBlood.addScore(point, anim, onComplete);
		}

		public refreshCurrency(count: SciNum, doAnim: boolean = true) {
			if (doAnim && SciNum.compare(count, this.currencyCount) == 1) {
				let posX = UI_AmuletProp.Inst.isBuyPopupVisible ? 1040 : 940;
				let effect = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/effect_amulet_levelresult2.lh', new Laya.Point(posX, 545), 0.98);
				effect.effect.addLoadedListener(Laya.Handler.create(this, () => {
					effect.effect.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
					effect.effect.root.active = false;
					effect.effect.root.active = true;
				}));
				Laya.timer.once(1000, this, () => {
					effect.destory();
				})
			}
			this.currencyCount = SciNum.compare(count, SciNum.createSciNum()) == 1 ? count : SciNum.createSciNum();
			this.txtCurrencyStarCount.text = SciNum.getSciStr(this.currencyCount.toString(), 6);
		}

		public refreshLeftPai(count: number) {
			this.dorasTip.refreshLeftPai(count);
		}

		public refreshTipReplace(showLockTip: boolean = false) {
			let tipReplaceVisible = amulet.AmuletDesktopMgr.Inst.amuletGameData.stage == 2;
			Laya.Tween.clearAll(this.tipReplace);
			if (tipReplaceVisible) {
				if (!this.tipReplace.visible) {
					this.tipReplace.visible = true;
					this.tipReplace.alpha = 0;
					Laya.Tween.to(this.tipReplace, { alpha: 1 }, 150, Laya.Ease.quintInOut);
				} else {
					this.tipReplace.alpha = 1;
				}
			} else {
				if (this.tipReplace.visible) {
					Laya.Tween.to(this.tipReplace, { alpha: 0 }, 150, Laya.Ease.quintInOut, Laya.Handler.create(this, () => {
						this.tipReplace.visible = false;
					}));
				}
			}
			let lockTiles = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.locked_tile || [];
			if (showLockTip && lockTiles.length > 0) {
				this.tipLock.visible = true;
				this.tipLock.alpha = 0;
				Laya.Tween.to(this.tipLock, { alpha: 1 }, 150, Laya.Ease.quintInOut, null, 150);
				let score = UI_PropDetailCard.getLockTileTotal(EAmuletPropState.normal);
				(this.tipLock.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(20421, [score.toString()]);
				(this.tipLock.getChildAt(0) as Laya.Image).width = (this.tipLock.getChildAt(1) as Laya.Label).textField.width + 450;
				Laya.timer.once(3000, this, () => {
					Laya.Tween.to(this.tipLock, { alpha: 0 }, 150, Laya.Ease.quintInOut, Laya.Handler.create(this, () => {
						this.tipLock.visible = false;
					}));
				})
			} else {
				this.tipLock.visible = false;
			}
		}

		refreshPropCount(effects?: game.IAmuletEffectData[]) {
			this.txtBunusCardsCount.text = game.Tools.strOfLocalization(20017, [amulet.AmuletDesktopMgr.Inst.getNowPropVolume(effects).toString(), amulet.AmuletDesktopMgr.Inst.maxPropVolume.toString()]);
			(this.comPropsCardsBg.getChildByName('txt_bg') as Laya.Image).width = this.txtBunusCardsCount.textField.textWidth + 39;
		}

		public shout() {
			try {
				let img_illust: Laya.Image = this.comContainerShout.getChildByName('illust').getChildByName('illust') as Laya.Image;
				(this.comContainerShout.getChildByName('illust') as Laya.Sprite).visible = true;
				(this.comContainerShout.getChildAt(0) as Laya.Sprite).visible = true;
				img_illust.scaleX = 1; // 每次使用前需要重置scaleX
				if (!game.Tools.CalculateIllust(img_illust, GameMgr.Inst.account_data['avatar_id'], 0, UI_Character_Skin.EIllustType.desktopInfo)) {
					game.Tools.charaPart(GameMgr.Inst.account_data['avatar_id'], img_illust, 'full', this.showIllustRect, true, true);
				}

				let dx: number = -105;
				let dy: number = 0;
				this.comContainerShout.visible = true;
				this.comContainerShout.alpha = 0;
				this.comContainerShout.x = this.shout_origin_x + dx;
				this.comContainerShout.y = this.shout_origin_y + dy;
				Laya.Tween.to(this.comContainerShout, { alpha: 1, x: this.shout_origin_x, y: this.shout_origin_y }, 70);
				Laya.Tween.to(this.comContainerShout, { alpha: 0 }, 150, null, null, 600);
				Laya.timer.once(800, this, () => {
					Laya.loader.clearTextureRes(img_illust.skin);
					this.comContainerShout.visible = false;
				});
			} catch (e) {
				let _errorinfo: Object = {};
				_errorinfo['error'] = e.message;
				_errorinfo['stack'] = e.stack;
				_errorinfo['method'] = 'shout';
				_errorinfo['class'] = 'UI_DesktopInfos';
				GameMgr.Inst.onFatalError(_errorinfo);
			}
		}

		resetState() {
			if (this.effectBg) {
				this.effectBg1.active = true;
				this.effectAniBg1.Play('qingyun_duiju_bg_Idie');
				this.effectBg2.active = false;
				this.effectAniBg2.Stop();
			}
			this.effectFeverTime2.active = false;
			this.huleshow.enable = false;
			this.dorasTip.resetRounds();
			this.topBossBlood.enable = false;
			this.comGaming.visible = false;
			this.chooseBoss.enable = false;
			this.amuletShop.enable = false;
			this.comContainerShout.visible = false;
			this.huPaiResult.enable = false;
			this.tipReplace.visible = false;
			this.tipLock.visible = false;
			Laya.timer.clearAll(this);
			this.aniLock = 0;
			if (this.effectFeverTime) {
				this.effectFeverTime.visible = false;
			}
			this.aniShowBoss.stop();
			this.aniHideBoss.stop();
			this.aniShowDesktop.stop();
			this.aniShowVs.stop();
			this.aniHideShop.stop();
			this.stopFeverTimeBgm();
		}

		refreshBtnAutoMoqie() {
			const tingList = amulet.AmuletDesktopMgr.Inst.amuletGameData && amulet.AmuletDesktopMgr.Inst.amuletGameData.round.ting_list ? amulet.AmuletDesktopMgr.Inst.amuletGameData.round.ting_list : [];
			let btn_moqie = this._fun_in.getChildByName('btn_automoqie') as Laya.Button;
			let label_automoqie = this._fun_out.getChildByName('automoqie') as Laya.Label;
			let btn_moqie2 = this._fun_out.getChildByName('btn_automoqie2') as Laya.Button;
			//正在自动模切，突然不能听牌了
			if (amulet.AmuletDesktopMgr.Inst.autoMoqie && tingList.length == 0 && !amulet.AmuletDesktopMgr.Inst.isOperateHu) {
				amulet.AmuletDesktopMgr.Inst.setAutoMoQie(false);
				btn_moqie.mouseEnabled = tingList.length > 0;
				btn_moqie2.mouseEnabled = tingList.length > 0;
				this.refreshFuncBtnShow(btn_moqie, label_automoqie, amulet.AmuletDesktopMgr.Inst.autoMoqie);
				return;
			}
			//听牌了允许自动模切
			if (tingList.length > 0) {
				let canAuto = uiscript.UI_AmuletTingPai.Inst.checkDropLastPaiHu();
				btn_moqie.mouseEnabled = canAuto;
				btn_moqie2.mouseEnabled = canAuto;
				this.refreshFuncBtnShow(btn_moqie, label_automoqie, amulet.AmuletDesktopMgr.Inst.autoMoqie);
			}
		}

		openPropPackage(effectLst: game.IAmuletEffectCandidate[], packageId: number, inShop: boolean = true) {
			if (this.effectShop && this.effectShop.effect.loaded) {
				this.effectShop.effect.root.active = true;
				this.effectShop.effect.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
				let config = cfg.amulet.amulet_goods.get(packageId);
				let url = "scene/Assets/Resource/amulet/fx_qingyun_kabao_" + config.guaranteed + '.png';
				(this.effectShop.effect.root.getChildAt(0).getChildAt(0).getChildAt(0).getChildAt(0) as Laya.MeshSprite3D).meshRender.material['_MainTex'] = Laya.loader.getRes(url);
				(this.effectShop.effect.root.getChildAt(0).getChildAt(0).getChildAt(0).getChildAt(1) as Laya.MeshSprite3D).meshRender.material['_MainTex'] = Laya.loader.getRes(url);
				(this.effectShop.effect.root.getChildAt(0).getChildAt(0).getChildAt(0).getChildAt(2) as Laya.MeshSprite3D).meshRender.material['_MainTex'] = Laya.loader.getRes(url);
				this.aniEffect = (this.effectShop.effect.root.getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				this.aniEffect.Play('fx_qingyun_kabao');
				Laya.timer.once(750, this, () => {
					this.effectShop.effect.root.active = false;
				});
			}
			this.aniLock++;
			Laya.timer.once(600, this, () => {
				this.aniLock--;
				uiscript.UI_AmuletProp.Inst.showBuyProps(effectLst);
			});
		}

		hide() {
			this.enable = false;
		}

		public resetAutoFunc() {
			let _autolipai: boolean = true;
			let btn_autolipai = this._fun_in.getChildByName('btn_autolipai') as Laya.Button;
			let label_autolipai = this._fun_out.getChildByName('automoqie') as Laya.Label;
			this.refreshFuncBtnShow(btn_autolipai, label_autolipai, _autolipai);
			amulet.AmuletDesktopMgr.Inst.setAutoLiPai(_autolipai);
			let btn_autohu = this._fun_in.getChildByName('btn_autohu') as Laya.Button;
			let label_autohu = this._fun_out.getChildByName('autohu') as Laya.Label;
			this.refreshFuncBtnShow(btn_autohu, label_autohu, amulet.AmuletDesktopMgr.Inst.autoHule);
			let btn_moqie = this._fun_in.getChildByName('btn_automoqie') as Laya.Button;
			let label_automoqie = this._fun_out.getChildByName('automoqie') as Laya.Label;
			let btn_moqie2 = this._fun_out.getChildByName('btn_automoqie2') as Laya.Button;
			const tingList = amulet.AmuletDesktopMgr.Inst.amuletGameData && amulet.AmuletDesktopMgr.Inst.amuletGameData.round && amulet.AmuletDesktopMgr.Inst.amuletGameData.round.ting_list ? amulet.AmuletDesktopMgr.Inst.amuletGameData.round.ting_list : [];
			btn_moqie.mouseEnabled = tingList.length > 0;
			btn_moqie2.mouseEnabled = tingList.length > 0;
			this.refreshFuncBtnShow(btn_moqie, label_automoqie, amulet.AmuletDesktopMgr.Inst.autoMoqie);
			this._container_fun.x = -546;
			this._fun_in.visible = false;
			this._fun_out.visible = true;
			let btn_func: Laya.Button = this._fun_out.getChildByName('btn_func') as Laya.Button;
			let btn_func2: Laya.Button = this._fun_out.getChildByName('btn_func2') as Laya.Button;
			btn_func.mouseEnabled = true;
			btn_func2.mouseEnabled = true;
		}

		public doScoreAnim(score: game.IAmuletTileScore, duration: number) {
			this.dorasTip.doScoreAnim(score, duration);
		}

		public onQuitScene(): void {
			if (this.effectFeverTime) {
				this.effectFeverTime.destroy();
				this.effectFeverTime = null;
			}
			if (this.effectBg) {
				this.effectBg.destroy();
				this.effectBg = null;
			}
			this.topBossBlood.clearEffect();
			this.huPaiResult.clearEffect();
		}

		public stopFeverTimeBgm() {
			if (this.audioId) {
				view.AudioMgr.StopAudio(this.audioId, 500);
				this.audioId = 0;
			}
		}

		public playFeverTimeBgm() {
			this.audioId = view.AudioMgr.PlayAudio(10339, -1);
		}

		// ==DevDebug Start==
		public testShout(skinId: number) {
			let img_illust: Laya.Image = this.comContainerShout.getChildByName('illust').getChildByName('illust') as Laya.Image;
			(this.comContainerShout.getChildByName('illust') as Laya.Sprite).visible = true;
			(this.comContainerShout.getChildAt(0) as Laya.Sprite).visible = true;
			img_illust.scaleX = 1; // 每次使用前需要重置scaleX
			if (!game.Tools.CalculateIllust(img_illust, skinId, 0, UI_Character_Skin.EIllustType.desktopInfo)) {
				game.Tools.charaPart(skinId, img_illust, 'full', this.showIllustRect, true, true);
			}

			let dx: number = -105;
			let dy: number = 0;
			this.comContainerShout.visible = true;
			this.comContainerShout.alpha = 0;
			this.comContainerShout.x = this.shout_origin_x + dx;
			this.comContainerShout.y = this.shout_origin_y + dy;
			Laya.Tween.to(this.comContainerShout, { alpha: 1, x: this.shout_origin_x, y: this.shout_origin_y }, 70);
			Laya.Tween.to(this.comContainerShout, { alpha: 0 }, 150, null, null, 600);
			Laya.timer.once(800, this, () => {
				Laya.loader.clearTextureRes(img_illust.skin);
				this.comContainerShout.visible = false;
			});
		}
		// ==DevDebug End==
	}
}