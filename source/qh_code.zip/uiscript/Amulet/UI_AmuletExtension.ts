module uiscript {
    export class UI_AmuletFeverTime extends UIBase { //美术要求fevertime层级要在百分比下，听牌提示上，所以拆出来一个界面
        public static Inst: UI_AmuletFeverTime = null;

        constructor() {
            super(new ui.amulet.amulet_fevertimeUI());
            UI_AmuletFeverTime.Inst = this;
        }

        public onCreate(): void {
            UI_AmuletDesktopInfo.Inst.onFeverTimeLoaded(this.me);
        }
    }
    export class UI_AmuletChooseBoss extends UIBase {
        private comsBoss: ui.amulet.amulet_bossUI[];
        private btnConfirmBoss: Laya.Button;
        private tipLock: Laya.Sprite;
        private levelGroupDatas: lqc.Sheet_Amulet_AmuletGames[];
        private levelDetail: UI_AmuletLevelDetail;
        private level: number;
        private selectedIndex: number = -1;
        public locking: boolean;
        private anims: Laya.FrameAnimation[][][];
        private aniShow: Laya.FrameAnimation;
        private comDetail: Laya.Sprite;

        constructor(me: Laya.Sprite, father: UI_AmuletDesktopInfo, aniShow: Laya.FrameAnimation) {
            super(me);
            this.aniShow = aniShow;
        }

        public onCreate(): void {
            this.comsBoss = [];
            this.anims = [];
            for (let i = 1; i <= 3; i++) {
                let comBoss = this.me.getChildByName('boss' + i) as ui.amulet.amulet_bossUI;
                (comBoss.getChildByName('boss').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, this.chooseBoss, [i - 1, true], false);
                this.comsBoss.push(comBoss);
                let bossAnims = [];
                for (let j = 1; j <= 3; j++) {
                    let anims = [];
                    anims.push(comBoss['boss' + j + '_show']);
                    anims.push(comBoss['boss' + j + '_idle']);
                    bossAnims.push(anims);
                }
                this.anims.push(bossAnims);
            }
            this.btnConfirmBoss = this.me.getChildByName('confirm') as Laya.Button;
            this.btnConfirmBoss.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                const param: game.IReqAmuletActivityUpgrade = {
                    activity_id: amulet.AmuletDesktopMgr.activityId
                };
                amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.NextLevel, param);
            }, null, false);
            this.comDetail = this.me.getChildByName('level_detail') as Laya.Sprite;
            this.levelDetail = new UI_AmuletLevelDetail(this.comDetail);
            this.tipLock = this.me.getChildByName('tip_lock') as Laya.Sprite;
        }

        public doSelectAni(img: Laya.Image) {
            let sprite = img.mask;
            Laya.timer.clearAll(img);
            sprite.graphics.clear();
            sprite.graphics.drawPie(147, 131, 130, 0, 0, '#000000');
            img.repaint();
            let timer = Laya.timer.currTimer;
            Laya.timer.frameLoop(1, img, () => {
                let t = Laya.timer.currTimer - timer;
                let angle = Math.floor(t / 167 * 360);
                sprite.graphics.drawPie(147, 131, 130, 0, angle, '#000000');
                img.repaint();
            })
            Laya.timer.once(167, img, () => {
                Laya.timer.clearAll(img);
                sprite.graphics.drawPie(147, 131, 130, 0, 360, '#000000');
                img.repaint();
            })
        }

        private chooseBoss(index: number, manualSwitching: boolean = false) {
            if (this.selectedIndex == index) return;
            this.selectedIndex = index;
            this.comsBoss.forEach((boss, _index) => {
                if (!boss.visible) return;
                let isSelected = _index == index;
                let imgSelected = boss.getChildByName('boss').getChildByName('btn').getChildByName('boss_selected') as Laya.Image;
                imgSelected.visible = isSelected;
                if (isSelected) {
                    this.doSelectAni(imgSelected);
                }
            });
            this.btnConfirmBoss.visible = this.levelGroupDatas[index].level == this.level;
            this.tipLock.visible = this.levelGroupDatas[index].level > this.level;
            if (this.tipLock.visible) {
                (this.tipLock.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(20084, [this.levelGroupDatas[index - 1].level_name]);
                (this.tipLock.getChildAt(0) as Laya.Image).width = (this.tipLock.getChildAt(1) as Laya.Label).textField.width + 450;
            }
            this.levelDetail.refresh(this.levelGroupDatas[index]);
            this.levelDetail.setIsPassed(this.levelGroupDatas[index].level < this.level);
            this.aniShow.play(0, false);
        }

        public show() {
            this.enable = true;
            this.refresh();
            this.levelDetail.hide();
            this.btnConfirmBoss.visible = false;
            this.tipLock.visible = false;
            this.comsBoss.forEach((boss, index) => {
                if (!boss.visible) return;
                let target = 0;
                for (let j = 1; j <= 3; j++) {
                    if ((boss.getChildByName('boss').getChildByName('boss' + j) as Laya.Sprite).visible) {
                        target = j - 1;
                    }
                }
                let imgSelected = boss.getChildByName('boss').getChildByName('btn').getChildByName('boss_selected') as Laya.Image;
                imgSelected.visible = false;
                boss.alpha = 0;
                Laya.timer.once(83 * (index + 1), this, () => {
                    boss.alpha = 1;
                    this.anims[index][target][0].play(0, false);
                    Laya.timer.once(this.anims[index][target][0].count * this.anims[index][target][0].interval, this, () => {
                        this.anims[index][target][0].stop();
                        this.anims[index][target][1].play(0, true);
                    });
                })
            });
            let index = this.selectedIndex;
            this.selectedIndex = -1;
            Laya.timer.once(index * 83 + 200, this, () => {
                this.chooseBoss(index);
            })
        }

        public refresh() {
            this.level = amulet.AmuletDesktopMgr.Inst.nowLevel;
            const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(this.level);
            let bossIdsGroup = UI_Activity_Amulet.amuletLevelGroupDic.get(nowLevelConfig.level_group);
            bossIdsGroup.sort((a, b) => { return a - b; });
            this.levelGroupDatas = [];
            bossIdsGroup.forEach((levelId) => { this.levelGroupDatas.push(UI_Activity_Amulet.amuletLevelDic.get(levelId)) });
            (this.me.getChildByName('road') as Laya.Sprite).visible = bossIdsGroup.length > 1;
            let selectedIndex = 0;
            this.comsBoss.forEach((boss, index) => {
                boss.mouseEnabled = true;
                if (bossIdsGroup[index]) {
                    boss.visible = true;
                    (boss.getChildByName('title').getChildByName('title') as Laya.Label).text = this.levelGroupDatas[index].level_name;
                    (boss.getChildByName('boss').getChildByName('boss2') as Laya.Sprite).visible = bossIdsGroup[index] < this.level;
                    (boss.getChildByName('boss').getChildByName('boss1') as Laya.Sprite).visible = bossIdsGroup[index] >= this.level && !this.levelGroupDatas[index].boss;
                    (boss.getChildByName('boss').getChildByName('boss3') as Laya.Sprite).visible = bossIdsGroup[index] >= this.level && !!this.levelGroupDatas[index].boss;
                    if (bossIdsGroup[index] == this.level) selectedIndex = index;
                } else {
                    boss.visible = false;
                }
            });
            this.selectedIndex = selectedIndex;
            this.comsBoss[0].x = bossIdsGroup.length == 1 ? 959 : 590;
            this.comsBoss[0].y = bossIdsGroup.length == 1 ? 559 : 495;
        }

        public hide() {
            this.enable = false;
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            for (let i = 0; i < this.anims.length; i++) {
                for (let j = 0; j < this.anims[i].length; j++) {
                    for (let t = 0; t < this.anims[i][j].length; t++) {
                        this.anims[i][j][t].stop();
                    }
                }
            }
            this.aniShow.gotoAndStop(0);
        }
    }

    export class UI_AmuletDorasTip extends UIBase {
        private doras: Array<UI_MJP> = [];
        private father: UI_AmuletDesktopInfo;
        private txtLeftCard: Laya.Label;
        private btnCardLibrary: Laya.Button;
        private comAddScore: Laya.Sprite;
        private scorePai: UI_MJP;
        private txtScore: Laya.Label;
        private imgBg: Laya.Image;

        constructor(me: Laya.Sprite, father: UI_AmuletDesktopInfo) {
            super(me);
            this.father = father;
            this.enable = true;
        }

        public onCreate(): void {
            this.doras = [];
            let doraGroup1 = this.me.getChildAt(1).getChildByName('dora_group1') as Laya.Sprite;
            for (let i: number = 0; i < doraGroup1.numChildren; i++) {
                this.doras.push(new UI_MJP(doraGroup1.getChildAt(i) as Laya.Image));
            }
            this.txtLeftCard = this.me.getChildAt(0).getChildByName('left_card') as Laya.Label;
            this.btnCardLibrary = this.me.getChildAt(0).getChildByName('card_library') as Laya.Button;
            this.btnCardLibrary.clickHandler = new Laya.Handler(this, () => {
                uiscript.UI_AmuletCardLibrary.Inst.show();
            }, null, false);
            this.comAddScore = this.me.getChildByName('add_tile_score') as Laya.Sprite;
            this.scorePai = new UI_MJP(this.comAddScore.getChildByName('tile') as Laya.Sprite);
            this.txtScore = this.comAddScore.getChildByName('score') as Laya.Label;
            this.imgBg = this.comAddScore.getChildByName('bg') as Laya.Image;
        }

        public doScoreAnim(score: game.IAmuletTileScore, delay: number) {
            this.comAddScore.visible = true;
            this.scorePai.show(score.tile);
            this.txtScore.text = '+' + SciNum.getSciStr(score.score, 1, 5);
            this.imgBg.width = this.txtScore.trueWidth + 94;
            this.comAddScore.alpha = 0;
            this.comAddScore.y = 93;
            Laya.Tween.to(this.comAddScore, { alpha: 1, y: -7 }, 100, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                Laya.timer.once(delay - 200, this.comAddScore, () => {
                    Laya.Tween.to(this.comAddScore, { alpha: 0, y: -107 }, 100, Laya.Ease.quadInOut);
                });
            }));
        }

        public refresh() {
            this.enable = true;
            this.resetRounds();
            this.refreshDoras(amulet.AmuletDesktopMgr.Inst.doras);
            this.refreshLeftPai(amulet.AmuletDesktopMgr.Inst.amuletGameData.round.desktop_remain || 0);
        }

        public refreshLeftPai(count: number) {
            this.txtLeftCard.text = game.Tools.strOfLocalization(20015, [count.toString()]);
        }

        public refreshDoras(pais: amulet.MJPai[]) {
            if (pais.length > this.doras.length) {
                app.Log.log('doras太多了');
            }
            this.doras.forEach((pai, index) => {
                if (pais[index]) {
                    pai.show(pais[index].toString(false));
                } else {
                    pai.reset();
                }
            })
        }

        public resetRounds() {
            for (let i: number = 0; i < this.doras.length; i++) {
                this.doras[i].reset();
            }
            Laya.Tween.clearAll(this.comAddScore);
            Laya.timer.clearAll(this.comAddScore);
            this.comAddScore.visible = false;
        }
    }

    export class UI_AmuletBossBlood extends UIBase {
        private imgTargetScoreBg: Laya.Image;
        private txtTargetScore: Laya.Label;
        private txtTargetScoreTitle: Laya.Label;
        private imgBoss: Laya.Image;
        private imgBossEffect: Laya.Image;
        private btnBoss: Laya.Button;
        private comNowScore: Laya.Sprite;
        private scoreTemplteUI: capsui.UICopy;
        private imgScores: Laya.Sprite[] = [];
        private levelTargetScore: SciNum;
        private comBossDetail: UI_PropDetailPopup;
        private bossBuff: game.IAmuletBuffData;

        private imgHps: Laya.Sprite[];
        private imgProgress: Laya.Image;
        private hpRate: number = 0;
        private currentScore: SciNum;
        private comCutin: Laya.Sprite;
        private cutin: Laya.Sprite;
        private cutinImgs: Laya.Image[];
        private cutinImgPercent: Laya.Image;
        private lastCutinRate: number;
        private cutinEffect: Laya.Scene;
        private aniCutin: Catfood.CAnimator;
        private cutinGrade: number;
        private audioId: number;
        private duringAudio: boolean;

        constructor(me: Laya.Sprite, father: UI_AmuletDesktopInfo) {
            super(me);
        }

        public onCreate(): void {
            this.imgTargetScoreBg = this.me.getChildByName('target').getChildAt(0) as Laya.Image;
            this.txtTargetScore = this.me.getChildByName('target').getChildAt(0).getChildByName('target_score') as Laya.Label;
            this.txtTargetScoreTitle = this.me.getChildByName('target').getChildAt(0).getChildByName('title2') as Laya.Label;
            this.btnBoss = this.me.getChildByName('target').getChildByName('boss').getChildByName('boss_effect') as Laya.Button;
            this.imgBossEffect = this.btnBoss.getChildByName('boss_effect') as Laya.Image;
            this.imgBoss = this.me.getChildByName('target').getChildByName('boss').getChildByName('boss') as Laya.Image;
            this.comNowScore = this.me.getChildByName('score').getChildByName('score') as Laya.Sprite;
            this.scoreTemplteUI = (this.comNowScore.getChildByName('templete') as Laya.Sprite).scriptMap['capsui.UICopy'];
            (this.comNowScore.getChildByName('templete') as Laya.Sprite).visible = false;
            this.imgHps = [];
            for (let i = 1; i <= 5; i++) {
                this.imgHps.push((this.me.getChildAt(0).getChildByName('blood' + i) as Laya.Image).mask);
            }
            this.imgProgress = this.me.getChildByName('score').getChildByName('mask_head').getChildByName('progress') as Laya.Image;
            this.comBossDetail = new UI_PropDetailPopup(this.me.parent.getChildByName('detail') as Laya.Sprite, this);
            this.btnBoss.clickHandler = new Laya.Handler(this, () => {
                if (this.bossBuff) this.comBossDetail.showBossBuff(this.bossBuff);
            }, null, false);
        }

        onFeverTimeLoaded(root: Laya.Sprite) {
            this.comCutin = root.getChildByName('cutin') as Laya.Sprite;
            this.comCutin.visible = false;
            this.cutin = this.comCutin.getChildByName('cutin') as Laya.Sprite;
            this.cutinImgs = [];
            for (let i: number = 0; i < 3; i++) {
                this.cutinImgs.push(this.cutin.getChildByName('progress').getChildByName(i.toString()) as Laya.Image);
            }
            this.cutinImgPercent = this.cutin.getChildByName('progress').getChildByName('percent') as Laya.Image;
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            Laya.timer.clearAll(this.imgProgress);
            Laya.timer.clearAll(this.cutin);
            this.comCutin.visible = false;
            this.whenOutAudio(0);
        }

        public onEnable(): void {
            this.comCutin.visible = true;
            if (!this.cutinEffect) {
                this.cutinEffect = Laya.loader.getRes('scene/effect_amulet_fevertime_bottom.ls');
                (this.comCutin.getChildByName('effect_bg') as Laya.Sprite).addChild(this.cutinEffect);
                this.cutinEffect.visible = false;
                this.aniCutin = (this.cutinEffect.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            }
        }

        public refresh() {
            this.enable = true;
            this.cutin.visible = false;
            this.bossBuff = null;
            const nowLevel = amulet.AmuletDesktopMgr.Inst.nowLevel;
            const buff_list = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.buff_list;
            const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(nowLevel);
            this.levelTargetScore = amulet.AmuletDesktopMgr.Inst.getTargetScore();
            this.txtTargetScoreTitle.text = game.Tools.strOfLocalization(20018, [nowLevelConfig.level_name]);
            this.txtTargetScore.text = amulet.AmuletDesktopMgr.Inst.getTargetScoreStr();
            this.txtTargetScore.x = this.txtTargetScoreTitle.x + this.txtTargetScoreTitle.trueWidth + 10;
            this.imgTargetScoreBg.width = this.txtTargetScoreTitle.trueWidth + this.txtTargetScore.trueWidth + 53;
            this.imgBoss.skin = game.Tools.localUISrc(nowLevelConfig.boss ? 'myres/amulet/boss.png' : 'myres/amulet/boss_normal.png')
            this.imgBoss.x = nowLevelConfig.boss ? -40 : -2;
            this.imgBoss.y = nowLevelConfig.boss ? -1 : -5;
            this.imgBossEffect.visible = !!nowLevelConfig.boss;
            this.imgBossEffect.skin = nowLevelConfig.boss && buff_list && buff_list[0] ? game.Tools.localUISrc('myres/amulet/boss/boss_effect_' + buff_list[0].id + '.png') : '';
            this.refreshScore(SciNum.createSciNumByStr(amulet.AmuletDesktopMgr.Inst.amuletGameData.round.point || '0'), false);
            this.comBossDetail.hide();
            if (buff_list && buff_list[0]) {
                this.bossBuff = buff_list[0];
            }
        }

        refreshCutin(score: SciNum, doAnim: boolean = false) {
            if (SciNum.compare(score, this.levelTargetScore) == -1) {
                this.cutin.visible = false;
                this.cutinEffect.visible = false;
                this.lastCutinRate = 0;
                this.cutinGrade = 0;
                return;
            }
            let rate = SciNum.compare(score.multiply(SciNum.createSciNum(100)), this.levelTargetScore.multiply(SciNum.createSciNum(999))) == 1 ? 999 :
                score.multiply(SciNum.createSciNum(100)).divide(this.levelTargetScore).toNumber();
            if (rate >= 100) uiscript.UI_AmuletDesktopInfo.Inst.refreshFeverTimeEffect(true);
            let delay = 0;
            if (!this.lastCutinRate) { //首次出现
                this.lastCutinRate = 100;
                this.renderCutinPercent(100);
                delay = 167;
                if (this.aniCutin) {
                    this.cutinEffect.visible = true;
                    (this.cutinEffect.getChildAt(1) as Laya.Sprite3D).active = false;
                    (this.cutinEffect.getChildAt(1) as Laya.Sprite3D).active = true;
                    this.aniCutin.Play('fx_qingyun_fevertime2_01_laya');
                }
                this.cutin.visible = true;
                this.cutin.x = 290;
                this.cutin.alpha = 1;
                UIBase.anim_alpha_in(this.cutin, { x: 70 }, 167, 0, null, Laya.Ease.quadInOut);
                this.cutinGrade = 1;
            }
            if (doAnim && this.lastCutinRate != 999) {
                Laya.timer.clearAll(this.cutin);
                Laya.timer.once(delay, this, () => {
                    let start_time: number = Laya.timer.currTimer;
                    Laya.timer.frameLoop(1, this.cutin, () => {
                        let t: number = Laya.timer.currTimer - start_time;
                        let speed: number = t / 1000;
                        if (speed >= 1) {
                            speed = 1;
                        }
                        // speed = - speed * speed + 2 * speed;
                        const timePercent = this.lastCutinRate + (rate - this.lastCutinRate) * speed;
                        this.renderCutinPercent(Math.floor(timePercent));
                        this.refreshCutinEffect(Math.floor(timePercent));
                        if (speed >= 1) {
                            this.lastCutinRate = rate;
                            Laya.timer.clearAll(this.cutin);
                        }
                    });
                })
            } else {
                this.renderCutinPercent(rate);
            }
        }

        private refreshCutinEffect(rate: number) {
            if (this.aniCutin) {
                if (rate >= 300 && this.cutinGrade < 2) {
                    this.cutinGrade = 2;
                    this.aniCutin.Play('fx_qingyun_fevertime2_02_laya');
                }
                if (rate >= 500 && this.cutinGrade < 3) {
                    this.cutinGrade = 3;
                    this.aniCutin.Play('fx_qingyun_fevertime2_03_laya');
                }
            }
        }

        private renderCutinPercent(rate: number) {
            for (let i: number = 0; i < 3; i++) {
                let n: number = rate % 10;
                rate = Math.floor(rate / 10);
                this.cutinImgs[i].skin = game.Tools.localUISrc('myres/amulet/number/cutin_' + n.toString() + '.png');
            }
        }

        public addScore(point: SciNum, anim: boolean = false, onComplete?: Laya.Handler) {
            this.refreshScore(this.currentScore.add(point), anim, onComplete);
        }

        public whenInAudio() {
            if (!this.duringAudio) {
                this.duringAudio = true;
                this.audioId = view.AudioMgr.PlayAudio(10166, 0)
            }
        }

        public whenOutAudio(delay: number = 200) {
            if (this.duringAudio) {
                this.duringAudio = false;
                view.AudioMgr.StopAudio(this.audioId, delay);
                this.audioId = null;
            }
        }

        public refreshScore(score: SciNum, anim: boolean = false, onComplete?: Laya.Handler) {
            if (!this.enable) {
                onComplete && onComplete.run();
                return;
            }
            this.currentScore = score;
            this.refreshCutin(score, anim);
            this.renderScore(score.toString());
            if (anim) {
                let _index = 0;
                this.imgScores.forEach((img) => {
                    if ((img.getChildAt(0) as Laya.Image).skin != '') {
                        img.visible = false;
                        Laya.timer.once(34 * _index, this, () => {
                            img.visible = true;
                            Laya.Tween.clearAll(img);
                            img.scale(2, 2)
                            Laya.Tween.to(img, { scaleX: 1.1, scaleY: 1.1 }, 117, Laya.Ease.backOut);
                            Laya.Tween.to(img, { scaleX: 1, scaleY: 1 }, 50, Laya.Ease.quadInOut, null, 117);
                        })
                        _index++;
                    }
                })
                Laya.timer.once(_index * 34 + 200, this, () => {
                    onComplete && onComplete.run();
                });
                this.whenOutAudio(0);
                this.imgProgress.alpha = 0;
                Laya.timer.frameLoop(1, this.imgProgress, () => {
                    if (this.levelTargetScore == SciNum.createSciNum()) {
                        Laya.timer.clearAll(this.imgProgress);
                        this.whenInAudio();
                        return;
                    }
                    let targetRate = SciNum.compare(this.currentScore, this.levelTargetScore.multiply(SciNum.createSciNum(5))) == 1 ? 5 :
                        (this.currentScore.multiply(SciNum.createSciNum(1000)).divide(this.levelTargetScore).toNumber()) / 1000;
                    let dis = Math.abs(targetRate - this.hpRate);
                    if (dis > 0.0001) {
                        if (this.hpRate < targetRate) {
                            // -- hp增加，需要做动画
                            let speed = 0.1 + dis * 3;
                            speed = speed > 4 ? 4 : speed;
                            let move_dis = speed * 0.0167;
                            if (move_dis >= dis) {
                                this.refreshHp(targetRate);
                                this.imgProgress.alpha = 0;
                            } else {
                                this.refreshHp(this.hpRate + move_dis);
                                this.imgProgress.alpha = dis * 20;
                            }
                            if (dis > 0.07) {
                                this.whenInAudio();
                            } else {
                                this.whenOutAudio();
                            }
                        } else {
                            // -- hp减少，直接赋值，理论上会进来
                            this.imgProgress.alpha = 0;
                            this.refreshHp(targetRate);
                            this.whenOutAudio();
                        }
                    } else {
                        this.imgProgress.alpha = 0;
                        Laya.timer.clearAll(this.imgProgress);
                        this.whenOutAudio();
                    }
                })
            } else {
                this.imgProgress.alpha = 0;
                let rate = SciNum.compare(score, this.levelTargetScore.multiply(SciNum.createSciNum(5))) == 1 ? 5 :
                    (score.multiply(SciNum.createSciNum(1000)).divide(this.levelTargetScore).toNumber()) / 1000;
                this.refreshHp(rate);
                onComplete && onComplete.run();
            }
        }

        refreshHp(rate: number) {
            this.hpRate = rate;
            if (rate > this.imgHps.length) rate = this.imgHps.length;
            let integar = Math.floor(rate);
            let decimal = rate - integar;
            this.imgProgress.x = 730 * decimal;
            this.imgHps.forEach((img, index) => {
                if (index < integar) {
                    img.width = 730;
                } else if (index == integar) {
                    img.width = decimal * 730;
                } else {
                    img.width = 0;
                }
            })
        }

        public renderScore(score: string) {
            let chars = SciNum.getSciImgStrs(score, 6);
            this.imgScores.forEach(imgScore => (imgScore.getChildAt(0) as Laya.Image).skin = '');
            let lengthData = SciNum.getCharsLength(chars);
            let width = 34;
            let startX = 292 - (lengthData.totalL * width / 2);
            for (let i = 0; i < chars.length; i++) {
                let url = game.Tools.localUISrc('myres/amulet/number/' + chars[i] + '.png');
                if (!this.imgScores[i]) {
                    let imgScore = this.scoreTemplteUI.getNodeClone() as Laya.Image;
                    this.comNowScore.addChild(imgScore);
                    this.imgScores.push(imgScore);
                    imgScore.visible = true;
                }
                (this.imgScores[i].getChildAt(0) as Laya.Image).skin = url;
                this.imgScores[i].x = startX;
                startX += width * lengthData.scales[i];
            }
        }

        public clearEffect() {
            if (this.cutinEffect) {
                this.cutinEffect.destroy();
                this.cutinEffect = null;
            }
        }
    }

    export class UI_AmuletHuPaiResult extends UIBase {
        public static Inst: UI_AmuletHuPaiResult;
        private father: UI_AmuletDesktopInfo;
        private imgBg: Laya.Image;
        private comContainerFan: Laya.Sprite;
        private templeteFan: Laya.Sprite;
        private comContainerBasexFan: Laya.Sprite;
        private comFan: Laya.Sprite;
        private txtFan: Laya.Label;
        private comBase: Laya.Sprite;
        private txtBase: Laya.Label;
        private comFans: Laya.Sprite[] = [];
        private comPoint: Laya.Sprite;
        private scoreTemplteUI: capsui.UICopy;
        private imgPointNumber: Laya.Image[] = [];
        private imgPoint: Laya.Image;
        private locking: boolean;
        private huResult: game.IAmuletEventResult_HuResult;

        private aniModifyFanAdd: Laya.FrameAnimation;
        private aniModifyBaseAdd: Laya.FrameAnimation;
        private aniModifyFanMinus: Laya.FrameAnimation;
        private aniModifyBaseMinus: Laya.FrameAnimation;

        private currentBase: SciNum;
        private currentFan: SciNum;
        private fanList: game.IAmuletFan[];
        private templateEffectGold: Laya.Sprite3D;
        private templateEffectPurple: Laya.Sprite3D;
        private effectPoint: Laya.Sprite3D;
        private sceneEffect: Laya.Sprite3D;
        private templeteCopy: capsui.UICopy;
        private comEffect: Laya.Sprite;
        private autoClose: boolean;
        private canSkip: boolean;
        private onClose: Laya.Handler;
        private effectHooks: game.IAmuletEffectedHookData[];

        constructor(me: Laya.Sprite, father: UI_AmuletDesktopInfo) {
            super(me);
            this.father = father;
            UI_AmuletHuPaiResult.Inst = this;
        }

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.comContainerFan = this.me.getChildByName('container_fan') as Laya.Sprite;
            this.templeteFan = this.comContainerFan.getChildByName('templete') as Laya.Sprite;
            this.comFans = [this.templeteFan];
            this.comContainerBasexFan = this.me.getChildByName('container_basexfan') as Laya.Sprite;
            this.comFan = this.comContainerBasexFan.getChildByName('fan') as Laya.Sprite;
            this.comBase = this.comContainerBasexFan.getChildByName('fu') as Laya.Sprite;
            this.txtFan = this.comFan.getChildByName('fan_total') as Laya.Label;
            this.txtBase = this.comBase.getChildByName('fu_total') as Laya.Label;
            this.comPoint = this.me.getChildByName('container_score') as Laya.Sprite;
            this.imgPoint = this.comPoint.getChildByName('point') as Laya.Image;
            this.imgPoint.visible = false;
            this.imgPointNumber = [];
            this.scoreTemplteUI = (this.comPoint.getChildByName('templete') as Laya.Sprite).scriptMap['capsui.UICopy'];
            (this.comPoint.getChildByName('templete') as Laya.Sprite).visible = false;
            (this.me.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) {
                    if (this.canSkip) this.skipAnim();
                    return;
                }
                if (this.autoClose) return;
                this.checkedHuPai();
            }, null, false);
            this.aniModifyBaseAdd = (this.father.me as ui.amulet.amulet_desktopinfoUI).base_modify_add;
            this.aniModifyFanAdd = (this.father.me as ui.amulet.amulet_desktopinfoUI).fan_modify_add;
            this.aniModifyBaseMinus = (this.father.me as ui.amulet.amulet_desktopinfoUI).base_modify_minus;
            this.aniModifyFanMinus = (this.father.me as ui.amulet.amulet_desktopinfoUI).fan_modify_minus;
            this.templeteCopy = this.templeteFan.scriptMap['capsui.UICopy'] as capsui.UICopy;
        }

        public checkedHuPai() {
            //纯前端响应可以不必在回调中响应
            this.hide();
        }

        public show(huResult: game.IAmuletEventResult_HuResult, hookEffects: game.IAmuletEffectedHookData[] = [], autoClose: boolean = true, onClose?: Laya.Handler) {
            this.locking = true;
            this.enable = true;
            this.effectHooks = hookEffects;
            this.autoClose = autoClose;
            this.onClose = onClose;
            this.comFans.forEach(comFan => { comFan.visible = false; }); //再打开时清掉所有的comfan
            if (!this.sceneEffect) {
                this.sceneEffect = Laya.loader.getRes('scene/effect_amulet_hupai.ls');
                this.templateEffectGold = this.sceneEffect.getChildByName('fx_qingyun_jiesuan_gold') as Laya.Sprite3D;
                this.templateEffectPurple = this.sceneEffect.getChildByName('fx_qingyun_jiesuan_purple') as Laya.Sprite3D;
                this.effectPoint = this.sceneEffect.getChildByName('fx_qingyun_jiesuan_002') as Laya.Sprite3D;
                this.comEffect = this.me.getChildByName('effect') as Laya.Sprite;
                this.comEffect.addChild(this.sceneEffect);
                this.effectPoint.transform.localPosition = new Laya.Vector3(2000, 2000, 0);
                this.templateEffectGold.transform.localPosition = new Laya.Vector3(2000, 2000, 0);
                this.templateEffectPurple.transform.localPosition = new Laya.Vector3(2000, 2000, 0);
                this.effectPoint.active = true;
                this.templateEffectGold.active = true;
                this.templateEffectPurple.active = true;
            } else {
                this.resetEffect();
            }
            this.canSkip = false;
            this.me.alpha = 0;
            this.me.y = 800;
            Laya.Tween.to(this.me, { alpha: 1 }, 84, Laya.Ease.quadInOut);
            Laya.Tween.to(this.me, { y: 614 }, 133, Laya.Ease.quadOut, Laya.Handler.create(this, () => {
                this.canSkip = true;
            }));
            this.showMain(huResult);
        }

        public showMain(huResult: game.IAmuletEventResult_HuResult) {
            // app.Log.log('huResult' + JSON.stringify(huResult));
            this.huResult = huResult;
            const huleInfo = huResult.hu_base;
            this.fanList = huleInfo.fan_list;
            this.fanList.sort((a, b) => {
                if (b.val == a.val) return a.id - b.id;
                return SciNum.compare(SciNum.createSciNumByStr(b.val), SciNum.createSciNumByStr(a.val));
            });
            if (this.fanList && this.fanList.length > 0) {
                this.imgBg.height = 278 + Math.ceil(this.fanList.length / 3) * 60;
            }
            this.comContainerFan.y = this.imgBg.y - this.imgBg.height + 54;
            let delay = 133;
            this.fanList.forEach((fanInfo: game.IAmuletFan, index) => {
                delay = this.addNewFan(index, fanInfo, delay);
            });
            this.currentFan = SciNum.createSciNumByStr(huleInfo.fan || '0');
            this.currentBase = SciNum.createSciNumByStr(huleInfo.base || '0');

            this.txtFan.text = SciNum.getSciStr(huleInfo.fan, 6) + game.Tools.strOfLocalization(20021);
            this.txtBase.text = SciNum.getSciStr(huleInfo.base, 6) + game.Tools.strOfLocalization(20022);
            this.refreshCenter();
            this.comPoint.alpha = 0;
            this.comPoint.x = 552 - 150;

            this.comContainerBasexFan.alpha = 0;
            this.comContainerBasexFan.y = 177;
            this.comContainerBasexFan.scale(2, 2);
            delay = delay + 7 / 60 * 1000;
            Laya.timer.once(delay, this, () => {
                view.AudioMgr.PlayAudio(10159);
            })
            Laya.Tween.to(this.comContainerBasexFan, { alpha: 1 }, 50, null, null, delay);
            Laya.Tween.to(this.comContainerBasexFan, { scaleX: 0.8, scaleY: 0.8 }, 133, null, null, delay);
            Laya.Tween.to(this.comContainerBasexFan, { scaleX: 1, scaleY: 1 }, 117, null, null, delay + 133);

            delay = delay + 13 / 60 * 1000;
            Laya.timer.once(delay, this, () => {
                amulet.AmuletHookEffect.play(this.effectHooks, Laya.Handler.create(this, () => {
                    Laya.timer.once(300, this, () => {
                        // app.Log.log('正常结束');
                        this.canSkip = false;
                        this.showFinalResult();
                    });
                }))
            })
        }

        skipAnim() {
            // app.Log.log('跳过')
            this.canSkip = false;
            Laya.timer.clearAll(this);
            Laya.Tween.clearAll(this.comContainerBasexFan);
            Laya.Tween.clearAll(this.comPoint);
            this.comContainerBasexFan.scale(1, 1);
            this.comContainerBasexFan.alpha = 1;
            this.comFans.forEach(comFan => { Laya.Tween.clearAll(comFan); });
            const huleInfo = this.huResult.hu_final;
            if (huleInfo.fan_list && huleInfo.fan_list.length > 0) {
                this.imgBg.height = 278 + Math.ceil(huleInfo.fan_list.length / 3) * 60;
            }
            this.comContainerFan.y = this.imgBg.y - this.imgBg.height + 54;
            this.fanList.forEach((fanInfoBase: game.IAmuletFan, index) => {
                let fanInfo = fanInfoBase;
                for (let i = 0; i < huleInfo.fan_list.length; i++) {
                    if (fanInfoBase.id == huleInfo.fan_list[i].id) {
                        fanInfo = huleInfo.fan_list[i];
                    }
                }
                let comFan;
                if (this.comFans[index]) {
                    comFan = this.comFans[index];
                } else {
                    comFan = this.templeteCopy.getNodeClone();
                    this.comFans.push(comFan);
                    this.comContainerFan.addChild(comFan);
                }
                this.refreshComFanData(comFan, fanInfo);
                comFan.visible = true;
                comFan.pivot(150, 25);
                comFan.x = (index % 3) * 310 + comFan.pivotX;
                comFan.y = Math.floor(index / 3) * 60 + comFan.pivotY;
                comFan.alpha = 1;
                comFan.scale(1, 1);
            });
            let nowIndex = this.fanList.length;
            for (let i = 0; i < huleInfo.fan_list.length; i++) {
                let fanInfo = huleInfo.fan_list[i];
                let isNew = true;
                for (let j = 0; j < this.fanList.length; j++) {
                    if (this.fanList[j].id == fanInfo.id) {
                        isNew = false;
                        break;
                    }
                }
                if (isNew) {
                    this.fanList.push(fanInfo);
                    let comFan;
                    if (this.comFans[nowIndex]) {
                        comFan = this.comFans[nowIndex];
                    } else {
                        comFan = this.templeteCopy.getNodeClone();
                        this.comFans.push(comFan);
                        this.comContainerFan.addChild(comFan);
                    }
                    this.refreshComFanData(comFan, fanInfo);
                    comFan.visible = true;
                    comFan.pivot(150, 25);
                    comFan.x = (nowIndex % 3) * 310 + comFan.pivotX;
                    comFan.y = Math.floor(nowIndex / 3) * 60 + comFan.pivotY;
                    comFan.alpha = 1;
                    comFan.scale(1, 1);
                    nowIndex++;
                }
            }
            amulet.AmuletHookEffect.playImmediately(this.effectHooks, null);
            this.showFinalResult();
        }

        showFinalResult() {
            // app.Log.log('showFinalResult');
            this.txtFan.text = SciNum.getSciStr(this.huResult.hu_final.fan, 6) + game.Tools.strOfLocalization(20021);
            this.txtBase.text = SciNum.getSciStr(this.huResult.hu_final.base, 6) + game.Tools.strOfLocalization(20022);
            this.refreshCenter();
            Laya.Tween.to(this.comContainerBasexFan, { y: 136 }, 100, Laya.Ease.quadOut);
            Laya.Tween.to(this.comPoint, { x: 552, alpha: 1 }, 100, Laya.Ease.quadOut);
            this.renderScore(this.imgPointNumber, this.comPoint, this.huResult.hu_final.point);
            let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(this.comPoint, new Laya.Point(150, 0));
            pos.x = 0.5 - pos.x;
            pos.y = 0.5 - pos.y;
            this.effectPoint.transform.localPosition = new Laya.Vector3(pos.x * 32, pos.y * 18, 0);
            this.effectPoint.active = false;
            this.effectPoint.active = true;
            view.AudioMgr.PlayAudio(10145);
            Laya.timer.once(1000, this, () => {
                // app.Log.log('延时加上分');
                this.father.addBossBlood(SciNum.createSciNumByStr(this.huResult.hu_final.point || '0'), true, Laya.Handler.create(this, () => {
                    // app.Log.log('加上分了已经');
                    this.locking = false;
                    if (this.autoClose) this.checkedHuPai();
                }));
            });
        }

        public refreshCenter() {
            this.comFan.x = (this.txtFan.textField.width - 112) / 2 + 214;
            this.comBase.x = 56 - (this.txtBase.textField.width - 112) / 2;
            this.comContainerBasexFan.x = 552 + (this.txtBase.textField.width - this.txtFan.textField.width) / 2;
        }

        addFan(fan: SciNum, final: SciNum, onComplete: Laya.Handler) {
            this.currentFan = final;
            if (fan.coefficient > 0) this.aniModifyFanAdd.play(0, false);
            if (fan.coefficient < 0) this.aniModifyFanMinus.play(0, false);
            this.txtFan.text = SciNum.getSciStr(this.currentFan.toString(), 6) + game.Tools.strOfLocalization(20021);
            this.refreshCenter();
            onComplete.run();
        }

        addBase(base: SciNum, final: SciNum, onComplete: Laya.Handler) {
            this.currentBase = final;
            if (base.coefficient > 0) this.aniModifyBaseAdd.play(0, false);
            if (base.coefficient < 0) this.aniModifyBaseMinus.play(0, false);
            this.txtBase.text = SciNum.getSciStr(this.currentBase.toString(), 6) + game.Tools.strOfLocalization(20022);
            this.refreshCenter();
            onComplete.run();
        }

        modifyYiZhong(fan: game.IAmuletFan) {
            let exist = false;
            this.fanList.forEach((fanInfo, index) => {
                if (fanInfo.id == fan.id) {
                    exist = true;
                    let comFan = this.comFans[index];
                    let symbol = SciNum.compare(SciNum.createSciNumByStr(fan.val), SciNum.createSciNumByStr(fanInfo.val))
                    let up = symbol == 1;
                    let down = symbol == -1;
                    fanInfo.val = fan.val;
                    this.refreshComFanData(comFan, fanInfo);
                    comFan.scale(1.1, 1.1);
                    Laya.Tween.to(comFan, { scaleX: 1, scaleY: 1 }, 100, Laya.Ease.quadInOut);
                    let imgAdd = comFan.getChildByName('add') as Laya.Image;
                    Laya.Tween.clearAll(imgAdd);
                    imgAdd.alpha = 0;
                    if (up) {
                        imgAdd.alpha = 1;
                        imgAdd.y = 40;
                        imgAdd.scaleY = 1;
                        Laya.Tween.to(imgAdd, { y: 4 }, 233);
                        Laya.Tween.to(imgAdd, { alpha: 0 }, 50, Laya.Ease.quadInOut, null, 150);
                    }
                    if (down) {
                        imgAdd.alpha = 1;
                        imgAdd.y = 4;
                        imgAdd.scaleY = -1;
                        Laya.Tween.to(imgAdd, { y: 40 }, 233);
                        Laya.Tween.to(imgAdd, { alpha: 0 }, 50, Laya.Ease.quadInOut, null, 150);
                    }
                    return;
                }
            })
            if (!exist) {
                // app.Log.log('有不在baseresult里的番' + JSON.stringify(fan));
                this.fanList.push(fan);
                if (this.fanList && this.fanList.length > 0) {
                    this.imgBg.height = 278 + Math.ceil(this.fanList.length / 3) * 60;
                }
                this.comContainerFan.y = this.imgBg.y - this.imgBg.height + 54;
                this.addNewFan(this.fanList.length - 1, fan, 0);
            }
        }

        private addNewFan(index: number, fanInfo: game.IAmuletFan, delay: number): number {
            let comFan;
            if (this.comFans[index]) {
                comFan = this.comFans[index];
            } else {
                comFan = this.templeteCopy.getNodeClone();
                this.comFans.push(comFan);
                this.comContainerFan.addChild(comFan);
            }
            this.refreshComFanData(comFan, fanInfo);
            comFan.visible = true;
            comFan.pivot(150, 25);
            comFan.x = (index % 3) * 310 + comFan.pivotX;
            comFan.y = Math.floor(index / 3) * 60 + comFan.pivotY;
            Laya.Tween.clearAll(comFan);
            comFan.alpha = 0;
            let audioId: number = 10160;
            let fanSci = SciNum.createSciNumByStr(fanInfo.val);
            if (SciNum.compare(fanSci, SciNum.createSciNum(13)) >= 0) {
                comFan.scale(2.5, 2.5);
                Laya.Tween.to(comFan, { alpha: 1 }, 34, Laya.Ease.quadInOut, null, delay);
                Laya.Tween.to(comFan, { scaleX: 0.8, scaleY: 0.8 }, 83, Laya.Ease.quadIn, null, delay);
                Laya.Tween.to(comFan, { scaleX: 1, scaleY: 1 }, 83, Laya.Ease.quadOut, null, delay + 83);
                audioId = 10162;
            } else if (SciNum.compare(fanSci, SciNum.createSciNum(2)) >= 0) {
                comFan.scale(2, 2);
                Laya.Tween.to(comFan, { alpha: 1 }, 34, Laya.Ease.quadInOut, null, delay);
                Laya.Tween.to(comFan, { scaleX: 0.8, scaleY: 0.8 }, 133, Laya.Ease.quadIn, null, delay);
                Laya.Tween.to(comFan, { scaleX: 1, scaleY: 1 }, 100, Laya.Ease.quadOut, null, delay + 133);
                audioId = 10160;
            } else {
                comFan.scale(1.5, 1.5);
                Laya.Tween.to(comFan, { alpha: 1 }, 34, Laya.Ease.quadInOut, null, delay);
                Laya.Tween.to(comFan, { scaleX: 1, scaleY: 1 }, 133, Laya.Ease.quadOut, null, delay);
                audioId = 10161;
            }
            Laya.timer.once(delay, this, () => {
                view.AudioMgr.PlayAudio(audioId);
            })
            let effect: Laya.Sprite3D;
            if (SciNum.compare(fanSci, SciNum.createSciNum(13)) >= 0) {
                effect = this.templateEffectGold.clone();
            } else if (SciNum.compare(fanSci, SciNum.createSciNum(6)) >= 0) {
                effect = this.templateEffectPurple.clone();
            }
            if (effect) {
                this.sceneEffect.addChild(effect);
                effect.active = false;
                Laya.timer.once(delay + 1.17, this.sceneEffect, () => {
                    let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(comFan, new Laya.Point(0, 0));
                    pos.x = 0.5 - pos.x;
                    pos.y = 0.5 - pos.y;
                    effect.transform.localPosition = new Laya.Vector3(pos.x * 32, pos.y * 18, 0);
                    effect.active = true;
                })
            }
            if (SciNum.compare(fanSci, SciNum.createSciNum(13)) >= 0) {
                delay = delay + 30 / 60 * 1000;
            } else if (SciNum.compare(fanSci, SciNum.createSciNum(2)) >= 0) {
                delay = delay + 15 / 60 * 1000;
            } else {
                delay = delay + 5 / 60 * 1000;
            }
            return delay;
        }

        public renderScore(imgs: Laya.Image[], comPoint: Laya.Sprite, score: string) {
            let chars = SciNum.getSciImgStrs(score, 6);
            chars.push('')
            imgs.forEach(imgScore => imgScore.skin = '');
            let lengthData = SciNum.getCharsLength(chars);
            let width = 66;
            let startX = 614 - (lengthData.totalL * width / 2);

            for (let i = 0; i < chars.length; i++) {
                let url = game.Tools.localUISrc('myres/amulet/number/ww_' + chars[i] + '.png');
                if (!imgs[i]) {
                    let imgScore = this.scoreTemplteUI.getNodeClone() as Laya.Image;
                    comPoint.addChild(imgScore);
                    imgs.push(imgScore);
                    imgScore.visible = true;
                }
                imgs[i].skin = url;
                imgs[i].x = startX;
                startX += width * lengthData.scales[i];
            }
        }

        private refreshComFanData(comFan: Laya.Sprite, fan: game.IAmuletFan) {
            let fanValue = fan.val || '0';
            let bigIntFanValue = SciNum.createSciNumByStr(fanValue);
            let fanGrade: number = 5;
            let titleColor: string = '#8d5c3f';
            let fanColor: string = '#d86019';
            if (SciNum.compare(bigIntFanValue, SciNum.createSciNum(13)) == -1) {
                let numFanValue = Number(fanValue);
                fanGrade = numFanValue < 2 ? 1 : (numFanValue < 3 ? 2 : (numFanValue < 6 ? 3 : (numFanValue < 13 ? 4 : 5)));
                titleColor = numFanValue < 2 ? '#fff9ec' : (numFanValue < 3 ? '#ffffff' : (numFanValue < 6 ? '#ffffff' : (numFanValue < 13 ? '#ffffff' : '#8d5c3f')));
                fanColor = numFanValue < 2 ? '#ffe7a5' : (numFanValue < 3 ? '#ffeb45' : (numFanValue < 6 ? '#ffeb45' : (numFanValue < 13 ? '#ffeb45' : '#d86019')));
            }
            // 1/2/3/6/13+番=白黄蓝紫橙
            (comFan.getChildByName('fan_bg') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/opposite_bureau_count_the_bottom_of_the_entry_' + fanGrade + '.png');
            (comFan.getChildByName('fan') as Laya.Label).text = fan.val + game.Tools.strOfLocalization(20021);
            (comFan.getChildByName('fan') as Laya.Label).color = fanColor;
            let txtFan = comFan.getChildByName('title') as Laya.Label;
            txtFan.color = titleColor;
            if (cfg.fan.fan.get(fan.id)) {
                let fanConfig = cfg.fan.fan.get(fan.id);
                txtFan.text = fanConfig['name_' + GameMgr.client_language];
            } else if (cfg.amulet.amulet_fan.get(fan.id)) {
                let fanConfig = cfg.amulet.amulet_fan.get(fan.id);
                if (fanConfig) txtFan.text = game.Tools.eventStrOfLocalization(fanConfig.desc);
            }
        }

        public hide() {
            this.locking = true;
            this.resetEffect();
            UIBase.anim_alpha_out(this.me, { y: 200 }, 100, 0, Laya.Handler.create(this, () => {
                this.locking = false;
                this.canSkip = false;
                this.enable = false;
                this.comFans.forEach(comFan => { comFan.visible = false; });
                this.onClose && this.onClose.run();
            }));
        }

        public clearEffect() {
            this.resetEffect();
            if (this.sceneEffect) {
                this.sceneEffect.destroy();
                this.sceneEffect = null;
            }
        }

        public resetEffect() {
            if (this.sceneEffect) {
                Laya.timer.clearAll(this.sceneEffect);
                this.sceneEffect._childs.forEach((effect: Laya.Sprite, index) => {
                    if (index > 3) effect.destroy(true);
                })
            }
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            Laya.Tween.clearAll(this.me);
            this.resetEffect();
        }

    }

    export class SciNum {
        public coefficient: number;
        public exponent: number;
        /**
         * 创建一个科学计数法表示的数值
         * @param {number} coefficient 系数部分
         * @param {number} exponent 指数部分
         * @param {boolean} normalize 是否进行规范化 (默认为true)
         */
        constructor(coefficient, exponent, normalize = true) {
            this.coefficient = coefficient;
            this.exponent = exponent;
            if (normalize) {
                this.normalize();
            }
        }

        /**
         * 规范化科学计数法表示
         * 确保系数在 [1, 10) 范围内
         */
        normalize() {
            if (this.coefficient === 0) {
                this.exponent = 0;
                return;
            }
            // 处理系数为负数的情况
            const sign = Math.sign(this.coefficient);
            let absCoefficient = Math.abs(this.coefficient);

            // 调整系数到 [1, 10) 范围
            if (absCoefficient >= 10 || absCoefficient < 1) {
                const expAdjust = Math.floor(Math.log10(absCoefficient));
                absCoefficient /= Math.pow(10, expAdjust);
                this.exponent += expAdjust;
            }
            this.coefficient = sign * absCoefficient;
        }

        /**
        * 将科学计数法转换为普通数字
        * 注意：对于极大或极小的数可能会返回 Infinity 或 0
        * @returns {number}
        */
        toNumber() {
            return this.coefficient * Math.pow(10, this.exponent);
        }

        /**
         * 转换为字符串表示
         * @returns {string}
         */
        toString(degree: number = 6, maxLength: number = 12) {
            if (this.exponent >= maxLength) {
                return `${this.coefficient.toFixed(degree)}e${this.exponent}`;
            }
            let number = Number((this.coefficient * Math.pow(10, this.exponent)).toFixed(2));
            if (number % 1 == 0) {
                return Math.floor(number).toString();
            }
            return number.toString();
        }

        /**
         * 加法运算
         * @param {SciNum} other 另一个科学计数法数
         * @returns {SciNum} 结果
         */
        add(other) {
            // 对齐指数
            const [a, b] = SciNum.alignExponents(this, other);
            const newCoefficient = a.coefficient + b.coefficient;
            return new SciNum(newCoefficient, a.exponent);
        }

        /**
         * 减法运算
         * @param {SciNum} other 另一个科学计数法数
         * @returns {SciNum} 结果
         */
        subtract(other) {
            // 对齐指数
            const [a, b] = SciNum.alignExponents(this, other);
            const newCoefficient = a.coefficient - b.coefficient;
            return new SciNum(newCoefficient, a.exponent);
        }

        /**
         * 乘法运算
         * @param {SciNum} other 另一个科学计数法数
         * @returns {SciNum} 结果
         */
        multiply(other: SciNum) {
            const newCoefficient = this.coefficient * other.coefficient;
            const newExponent = this.exponent + other.exponent;
            return new SciNum(newCoefficient, newExponent);
        }

        /**
         * 除法运算
         * @param {SciNum} other 另一个科学计数法数
         * @returns {SciNum} 结果
         */
        divide(other) {
            if (other.coefficient === 0) {
                throw new Error("Division by zero");
            }
            const newCoefficient = this.coefficient / other.coefficient;
            const newExponent = this.exponent - other.exponent;
            return new SciNum(newCoefficient, newExponent);
        }

        /**
         * 比较两个科学计数法数的大小
         * @param {SciNum} other 另一个科学计数法数
         * @returns {number} 1 表示大于，-1 表示小于，0 表示等于
         */
        compare(other) {
            const [a, b] = SciNum.alignExponents(this, other);
            if (a.coefficient > b.coefficient) return 1;
            if (a.coefficient < b.coefficient) return -1;
            return 0;
        }

        public static _bigTable: { key: number, str: number }[];
        public static criticalMinValue: number = 8;
        public static criticalMaxValue: number = 302;

        public static get bigTable(): { key: number, str: number }[] {
            if (this._bigTable) return this._bigTable;
            let table = cfg.amulet.amulet_large_number;
            this._bigTable = [];
            table.forEach((value) => {
                this._bigTable.push({ key: Number(value.number_id), str: Number(value.number_unit_en) });
            })
            this._bigTable.sort((a, b) => a.key - b.key);
            return this._bigTable;
        }

        /**
         * 对齐两个科学计数法数的指数，返回新的系数和共同的指数
         * @param {SciNum} a 第一个数
         * @param {SciNum} b 第二个数
         * @returns {[SciNum, SciNum]} 对齐后的两个数
         */
        private static alignExponents(a: SciNum, b: SciNum) {
            if (a.exponent === b.exponent) {
                return [a, b]; // 直接返回原对象，因为它们已经对齐
            }

            const exponentDiff = a.exponent - b.exponent;
            if (exponentDiff > 0) {
                // a的指数更大，调整b
                return [
                    a, // 保持a不变
                    new SciNum(b.coefficient / Math.pow(10, exponentDiff), a.exponent, false) // 跳过规范化
                ];
            } else {
                // b的指数更大，调整a
                return [
                    new SciNum(a.coefficient / Math.pow(10, -exponentDiff), b.exponent, false), // 跳过规范化
                    b  // 保持b不变
                ];
            }
        }

        static createSciNumByStr(numStr: string = '0') {
            if (numStr.includes('e')) {
                const [baseStr, powStr] = numStr.split('e').map(value => Number(value));
                return new SciNum(baseStr, powStr);
            } else if (numStr.length > 12) {
                let coefficient = numStr[0] == '-' ? numStr.slice(0, 6) : numStr.slice(0, 5);
                return new SciNum(coefficient, numStr.length - coefficient.length);
            }
            return new SciNum(Number(numStr), 0)
        }

        static createSciNum(numStr: number = 0) {
            return new SciNum(numStr, 0)
        }

        /**
         * 比较两个科学计数法数的大小
         * @returns {number} 1 表示大于，-1 表示小于，0 表示等于
         */
        static compare(a: SciNum, b: SciNum) {
            const [alignA, alignB] = SciNum.alignExponents(a, b);
            if (alignA.coefficient > alignB.coefficient) return 1;
            if (alignA.coefficient < alignB.coefficient) return -1;
            return 0;
        }


        //degree保留几位小数，maxLength大于多少时用科学计数法, 返回科学计数法string
        public static getSciStr(numStr: string, degree: number, maxLength: number = 12, useSci: boolean = false): string {
            let sciNum = this.createSciNumByStr(numStr);
            if (sciNum.exponent <= SciNum.criticalMaxValue && sciNum.exponent >= SciNum.criticalMinValue && !useSci) {
                let coefficient = sciNum.coefficient;
                let exponent = sciNum.exponent;
                let lastStr = '';
                if (GameMgr.client_language == 'en') {
                    for (let i = this.bigTable.length - 1; i >= 0; i--) {
                        if (exponent > this.bigTable[i].key && this.bigTable[i].str) {
                            lastStr += game.Tools.strOfLocalization(this.bigTable[i].str);
                            exponent = exponent - this.bigTable[i].key;
                            break;
                        }
                    }
                } else {
                    for (let i = EBigNumerUnit.ji; i >= EBigNumerUnit.wan; i--) {
                        let value = Math.floor(exponent / (i * 4));
                        if (value > 0) {
                            while (value) {
                                lastStr += game.Tools.strOfLocalization(BigNumberStr[i]);
                                value--;
                            }
                            exponent = exponent % (i * 4);
                        }
                    }
                    lastStr = lastStr.split('').reverse().join('');
                }
                if (exponent > 0) {
                    coefficient = coefficient * (10 ** exponent);
                }
                return coefficient.toFixed(2) + lastStr;
            }
            return sciNum.toString(degree, maxLength);
        }

        //degree保留几位小数，maxLength大于多少时用科学计数法, 返回科学计数法对应的图片数组
        public static getSciImgStrs(numStr: string, degree: number, maxLength: number = 12): string[] {
            let sciNum = this.createSciNumByStr(numStr);
            let chars: string[] = [];
            if (sciNum.exponent <= SciNum.criticalMaxValue && sciNum.exponent >= SciNum.criticalMinValue) {
                let coefficient = sciNum.coefficient;
                let exponent = sciNum.exponent;
                let firstImgs = [];
                let lastImgs = [];
                if (GameMgr.client_language == 'en') {
                    for (let i = this.bigTable.length - 1; i >= 0; i--) {
                        if (exponent > this.bigTable[i].key && this.bigTable[i].str) {
                            let str = game.Tools.strOfLocalization(this.bigTable[i].str);
                            for (let j = 0; j < str.length; j++) {
                                let isSmall = /^[a-z]+$/.test(str[j]);
                                let letter = str[j].toLowerCase();
                                lastImgs.push('en' + letter + (isSmall ? 's' : ''));
                            }
                            exponent = exponent - this.bigTable[i].key;
                            break;
                        }
                    }
                } else {
                    for (let i = EBigNumerUnit.ji; i >= EBigNumerUnit.wan; i--) {
                        let value = Math.floor(exponent / (i * 4));
                        if (value > 0) {
                            while (value) {
                                lastImgs.push('big' + i);
                                value--;
                            }
                            exponent = exponent % (i * 4);
                        }
                    }
                    lastImgs = lastImgs.reverse();
                }
                if (exponent > 0) {
                    coefficient = coefficient * (10 ** exponent);
                }
                let firstStr = coefficient.toFixed(2);
                for (let i = 0; i < firstStr.length; i++) {
                    if (firstStr[i] == '-') {
                        continue;
                    } else if (firstStr[i] == '.') {
                        firstImgs.push('point');
                    } else {
                        firstImgs.push(firstStr[i]);
                    }
                }
                return firstImgs.concat(lastImgs);
            } else {
                let sciNumStr = sciNum.toString(degree, maxLength);
                for (let i = 0; i < sciNumStr.length; i++) {
                    if (sciNumStr[i] == '-') {
                        continue;
                    } else if (sciNumStr[i] == 'e') {
                        chars.push('e');
                    } else if (sciNumStr[i] == '.') {
                        chars.push('point');
                    } else {
                        chars.push(sciNumStr[i]);
                    }
                }
            }
            return chars;
        }

        public static getCharsLength(chars: string[]): { scales: number[], totalL: number } {
            let totalL = 0;
            let scales = [];
            let charScale = 1;
            chars.forEach((char) => {
                if (char.indexOf('big') >= 0) {
                    charScale = 1.2;
                }
                scales.push(charScale);
                totalL += charScale;
            })
            return { scales, totalL: totalL };
        }
    }

    enum EBigNumerUnit {
        none,
        wan,
        yi,
        zhao,
        jing,
        hai,
        zi,
        rang,
        gou,
        jian,
        zheng,
        zai,
        ji,
    }
    const BigNumberStr = ['', 25081134, 25081135, 25081136, 25081137, 25081138, 25081139, 25081140, 25081141, 25081142, 25081143, 25081144, 25081145]
}