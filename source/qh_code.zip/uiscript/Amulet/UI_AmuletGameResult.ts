module uiscript {
    export class UI_AmuletGameResult extends UIBase {
        public static Inst: UI_AmuletGameResult;
        private btnContinue: Laya.Button;
        private btnHome: Laya.Button;
        private gameResultData: amulet.IAmuletGameResult;
        private comWin: Laya.Sprite;
        private comFailed: Laya.Sprite;
        private container_hand: Laya.Sprite = null;
        private hands: Array<UI_MJP> = [];
        private container_avatar: Laya.Sprite;
        private avatar0: UI_Character_Skin;
        private comPoint: Laya.Sprite;
        private imgPointBg: Laya.Image;
        private comScore: Laya.Sprite;
        private scoreTemplteUI: capsui.UICopy;
        private imgPointNumber: Laya.Image[] = [];
        private container_fan: Laya.Sprite;
        private comFan: Laya.Sprite;
        private fan_imgs: Array<Laya.Image> = [];
        private imgFanTemplete: capsui.UICopy;
        private imgFanBg: Laya.Image;
        private imgFanWord: Laya.Image;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniWinShow: Laya.FrameAnimation;
        private aniWinIdle: Laya.FrameAnimation;
        private aniLoseShow: Laya.FrameAnimation;
        private aniStarIdle: Laya.FrameAnimation;
        private effectScore: game.UIEffect;
        private effectResult: game.UIEffect;
        private effectBg: Laya.Scene;
        private onConfirm: Laya.Handler;

        private locking: boolean;

        constructor() {
            super(new ui.amulet.amulet_gameresultUI());
            UI_AmuletGameResult.Inst = this;
        }
        public onCreate(): void {
            this.comWin = this.me.getChildByName('win') as Laya.Sprite;
            this.comFailed = this.me.getChildByName('failed') as Laya.Sprite;
            this.btnContinue = this.me.getChildByName('continue') as Laya.Button;
            this.btnHome = this.me.getChildByName('home') as Laya.Button;
            this.btnHome.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                amulet.AmuletDesktopMgr.Inst.ClearDesktop();
                uiscript.UI_AmuletHome.Inst.show();
                this.hide();
            }, null, false);
            this.btnContinue.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.onConfirm && this.onConfirm.run();
                this.hide();
            }, null, false);
            this.container_hand = this.me.getChildByName('container_hand') as Laya.Sprite;
            this.hands = [];
            for (let i: number = 0; i < this.container_hand.numChildren; i++) {
                let img: Laya.Image = this.container_hand.getChildAt(i) as Laya.Image;
                img.visible = false;
                this.hands.push(new UI_MJP(img));
            }
            this.hands = [];
            for (let i: number = 0; i < this.container_hand.numChildren; i++) {
                let img: Laya.Image = this.container_hand.getChildAt(i) as Laya.Image;
                img.visible = false;
                this.hands.push(new UI_MJP(img));
            }
            this.container_avatar = this.me.getChildByName('chara').getChildByName('container_avatar') as Laya.Sprite;
            this.avatar0 = new UI_Character_Skin(this.container_avatar.getChildByName('avatar0') as Laya.Image);
            this.avatar0.setType('starup');
            this.avatar0.setIllustType(UI_Character_Skin.EIllustType.starUp)
            this.comScore = this.me.getChildByName('bottom').getChildByName('score') as Laya.Sprite;
            this.imgPointBg = this.comScore.getChildByName('bg') as Laya.Image;
            this.comPoint = this.comScore.getChildByName('container_score') as Laya.Sprite;
            this.imgPointNumber = [];
            this.scoreTemplteUI = (this.comPoint.getChildByName('templete') as Laya.Sprite).scriptMap['capsui.UICopy'];
            (this.comPoint.getChildByName('templete') as Laya.Sprite).visible = false;
            this.container_fan = this.me.getChildByName('bottom').getChildByName('container_fanfu').getChildByName('fan') as Laya.Sprite;
            this.imgFanBg = this.me.getChildByName('bottom').getChildByName('container_fanfu').getChildByName('bg') as Laya.Image;
            this.imgFanWord = this.container_fan.getChildByName('word') as Laya.Image;
            this.comFan = this.container_fan.getChildByName('fan') as Laya.Sprite;
            this.imgFanTemplete = (this.comFan.getChildByName('templete') as Laya.Image).scriptMap['capsui.UICopy'];
            this.fan_imgs = [this.comFan.getChildByName('templete') as Laya.Image];
            this.aniShow = (this.me as ui.amulet.amulet_gameresultUI).show;
            this.aniHide = (this.me as ui.amulet.amulet_gameresultUI).hide;
            this.aniLoseShow = (this.me as ui.amulet.amulet_gameresultUI).over_show;
            this.aniWinShow = (this.me as ui.amulet.amulet_gameresultUI).win_show;
            this.aniWinIdle = (this.me as ui.amulet.amulet_gameresultUI).win_idle;
            this.aniStarIdle = (this.me as ui.amulet.amulet_gameresultUI).star_idle;
        }

        show(onConfirm?: Laya.Handler) {
            this.enable = true;
            this.onConfirm = onConfirm;
            this.gameResultData = amulet.AmuletDesktopMgr.Inst.gameResultData;
            this.avatar0.setSkin(UI_Sushe.main_chara_info.skin, 'full', '', false);
            //获取当前关卡的关卡信息
            const levelConfig = UI_Activity_Amulet.amuletLevelDic.get(amulet.AmuletDesktopMgr.Inst.gameResultData.level);

            this.comFailed.visible = this.gameResultData.reason == 1;
            this.comWin.visible = this.gameResultData.reason != 1;
            (this.me.getChildByName('content').getChildByName('03') as Laya.Sprite).visible = this.gameResultData.reason == 1;
            if (this.gameResultData.reason == 1) {
                (this.me.getChildByName('content').getChildByName('03').getChildByName('level') as Laya.Label).text = levelConfig.level_name;
            }
            (this.me.getChildByName('content').getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(this.gameResultData.reason == 1 ? 'myres/amulet/finish_text_bottom_2.png' : 'myres/amulet/finish_text_bottom_1.png');
            this.btnContinue.visible = this.gameResultData.reason == 3;
            let huData = amulet.AmuletDesktopMgr.Inst.amuletGameData.record.highest_hu;
            this.container_hand.visible = !!(huData && huData.pai);
            this.container_fan.visible = this.container_hand.visible;
            (this.me.getChildByName('pai_bg') as Laya.Sprite).visible = this.container_hand.visible;
            (this.me.getChildByName('bottom').getChildByName('container_fanfu') as Laya.Sprite).visible = this.container_hand.visible;
            this.comScore.visible = this.container_hand.visible;
            if (huData && huData.pai) {
                this.showHands(huData);
                this.refreshFan(huData.fan || '0');
                this.comScore.x = 1857 - this.imgFanBg.width;
                this.imgPointNumber.forEach(imgScore => imgScore.skin = '');
                let pointStrs = SciNum.getSciImgStrs(huData.point || '0', 6);
                let lengthData = SciNum.getCharsLength(pointStrs);
                let width = 66;
                let startX = -1 * width * lengthData.totalL;
                for (let i = 0; i < pointStrs.length; i++) {
                    let url = game.Tools.localUISrc('myres/amulet/number/ww_' + pointStrs[i] + '.png');
                    if (!this.imgPointNumber[i]) {
                        let imgScore = this.scoreTemplteUI.getNodeClone() as Laya.Image;
                        this.comPoint.addChild(imgScore);
                        this.imgPointNumber.push(imgScore);
                        imgScore.visible = true;
                    }
                    this.imgPointNumber[i].skin = url;
                    this.imgPointNumber[i].x = startX;
                    startX += width * lengthData.scales[i];
                }
                this.imgPointBg.width = 75 + width * lengthData.totalL;
                (this.comScore.getChildByName('title3') as Laya.Image).x = this.imgPointBg.x - this.imgPointBg.width - 32;
            }
            const recordData = amulet.AmuletDesktopMgr.Inst.amuletGameData.record;
            (this.me.getChildByName('content').getChildByName('01').getChildByName('prop_count') as Laya.Label).text = (recordData && recordData.effect_gain ?
                recordData.effect_gain : 0) + game.Tools.strOfLocalization(20038);
            (this.me.getChildByName('content').getChildByName('02').getChildByName('he_count') as Laya.Label).text = (recordData && recordData.game_hu_count ?
                recordData.game_hu_count : 0) + game.Tools.strOfLocalization(20039);
            if (this.comScore.visible) {
                Laya.timer.once(416, this, () => {
                    this.effectScore = game.FrontEffect.Inst.create_ui_effect(this.comScore, 'scene/effect_amulet_gameresult1.lh', new Laya.Point(-this.imgPointBg.width / 2, 20), -1);
                });
            }
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(1000, this, () => {
                this.locking = false;
            });
            if (!this.effectBg) {
                this.effectBg = Laya.loader.getRes('scene/effect_amulet_end_bg.ls');
                (this.me.getChildByName('bg') as Laya.Sprite).addChild(this.effectBg);
            }
            this.effectBg.visible = true;
            let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            anim.Play('fx_qingyun3_end_show');
            Laya.timer.once(1000, this, () => {
                anim.Play('fx_qingyun3_end_idle');
            });
            if (this.gameResultData.reason == 1) {
                this.aniLoseShow.play(0, false);
            } else {
                this.effectResult = game.FrontEffect.Inst.create_ui_effect(this.comWin, 'scene/effect_amulet_gameresult2.lh', new Laya.Point(312, 105), 1);
                this.aniWinShow.play(0, false);
                Laya.timer.once(this.aniWinShow.count * this.aniWinShow.interval, this, () => {
                    this.aniWinShow.stop();
                    this.aniWinIdle.play(0, true);
                })
            }
            this.aniStarIdle.play(0, true);
            view.AudioMgr.PlayAudio(10341);
        }

        refreshFan(fan: string) {
            const fanImgs = SciNum.getSciImgStrs(fan, 6);
            let lengthData = SciNum.getCharsLength(fanImgs);
            let width = 43;
            let startX = -1 * width * lengthData.totalL;
            this.fan_imgs.forEach((img) => img.visible = false);
            for (let i = 0; i < fanImgs.length; i++) {
                let imgFan = this.fan_imgs[i];
                if (!imgFan) {
                    imgFan = this.imgFanTemplete.getNodeClone() as Laya.Image;
                    this.fan_imgs.push(imgFan);
                    this.comFan.addChild(imgFan);
                }
                imgFan.visible = true;
                imgFan.x = startX;
                startX += width * lengthData.scales[i];
                imgFan.skin = game.Tools.localUISrc('myres/amulet/number/fan_' + fanImgs[i] + '.png');
            }
            this.imgFanBg.width = 81 + lengthData.totalL * width;
        }

        showHands(info: game.IActivityAmuletHuRecord) {
            let arrPais = info.pai.split(',');
            // let arrPais = ('1m2m3m4m5s5s5s5p5p5p7s7s7s4m').split(',');
            let arrHands = arrPais[0];
            let hands = [];
            for (let i = 0; i < arrHands.length + 2; i++) {
                if (arrHands[i] && arrHands[i + 1]) {
                    let pai = arrHands[i] + arrHands[i + 1];
                    hands.push(pai)
                } else {
                    break;
                }
                i++;
            }
            let hupai = hands[hands.length - 1];
            hands.pop();
            let ming = [];
            for (let i = 1; i < arrPais.length; i++) {
                let arrMings = arrPais[i];
                let _ming = '(';
                for (let j = 0; j < arrMings.length + 2; j++) {
                    if (arrMings[j] && arrMings[j + 1]) {
                        let pai = arrMings[j] + arrMings[j + 1];
                        _ming = _ming + (j == 0 ? '' : ',') + pai;
                    } else {
                        _ming = _ming + ')';
                        ming.push(_ming);
                        break;
                    }
                    j++;
                }
            }
            // app.Log.log('hands ====' + JSON.stringify(hands));
            // app.Log.log('ming ====' + JSON.stringify(ming));
            let width_pai: number = this.hands[0].me.width;
            let com_span: number = width_pai * 0.5;
            //显示手牌
            for (let i: number = 0; i < this.hands.length; i++) {
                this.hands[i].reset();
            }
            let current_index: number = 0;
            let current_x: number = 0;
            let hand: Array<mjcore.MJPai> = [];
            for (let i: number = 0; i < hands.length; i++) hand.push(mjcore.MJPai.Create(hands[i]));
            hand = hand.sort((a, b) => {
                let va: number = a.numValue() * 10 + (a.dora ? 0 : 1);
                let vb: number = b.numValue() * 10 + (b.dora ? 0 : 1);
                return va - vb;
            });
            for (let i: number = 0; i < hand.length; i++) {
                this.hands[current_index].show(hand[i].toString(false));
                this.hands[current_index].pos(current_x, 0)
                current_x += width_pai;
                current_index++;
            }
            current_x += com_span;
            //副露
            if (ming && ming.length > 0) {
                for (let i: number = 0; i < ming.length; i++) {
                    let str_ming: string = ming[i];
                    //新版ming的记录angang(5p,0p,0p,5p)这种
                    let s_category: string = '';
                    let _m: Array<string> = [];
                    for (let i: number = 0; i < str_ming.length; i++) {
                        if (str_ming.charAt(i) == '(') {
                            s_category = str_ming.substring(0, i);
                            _m = str_ming.substring(i + 1, str_ming.length - 1).split(',');
                            break;
                        }
                    }

                    for (let j: number = 0; j < _m.length; j++) {
                        let skin: string = _m[j];

                        skin = skin.replace('t', '');
                        this.hands[current_index].show(skin);
                        this.hands[current_index].pos(current_x, 0);
                        current_x += width_pai;
                        current_index++;
                    }
                    current_x += com_span;
                }
            }

            //胡的牌
            {
                this.hands[current_index].show(hupai.replace('t', ''));
                this.hands[current_index].pos(current_x, 0);
                current_x += width_pai;
                current_index++;
            }

            let scale: number = 1.4 / (current_x / 1120);
            this.container_hand.scaleX = this.container_hand.scaleY = scale;
        }

        hide() {
            if (this.effectScore) {
                this.effectScore.destory();
                this.effectScore = null;
            }
            if (this.effectResult) {
                this.effectResult.destory();
                this.effectResult = null;
            }
            Laya.timer.clearAll(this);
            let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            anim.Play('fx_qingyun3_end_hide');
            this.aniShow.stop();
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            this.effectBg.visible = false;
            this.aniHide.gotoAndStop(0);
            this.locking = false;
            this.enable = false;
            this.avatar0.clear();
            this.aniWinShow.stop();
            this.aniLoseShow.stop();
            this.aniWinIdle.stop();
            this.aniStarIdle.stop();
        }

        public onQuitScene(): void {
            if (this.effectBg) {
                this.effectBg.destroy();
                this.effectBg = null;
            }
        }
    }
}