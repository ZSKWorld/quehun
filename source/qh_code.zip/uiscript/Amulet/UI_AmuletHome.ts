/**
* name 
*/
module uiscript {
	export class UI_AmuletHome extends UIBase {
		public static Inst: UI_AmuletHome = null;
		private btnReturn: Laya.Button;
		private btnStart: Laya.Button;
		private btnRestart: Laya.Button;
		private btnStrengthen: Laya.Button;
		private btnReward: Laya.Button;
		private btnHelp: Laya.Button;
		private btnRank: Laya.Button;
		private btnChanllenge: Laya.Button;
		private btnIllustration: Laya.Button;
		private haveOldGameRecord: boolean;
		private effectBg: Laya.Scene;
		private aniShow: Laya.FrameAnimation;
		private aniIdle: Laya.FrameAnimation;
		private aniHide: Laya.FrameAnimation;
		public locking: boolean;
		private enterTime: string;
		private openOtherPage: boolean = false;

		constructor() {
			super(new ui.amulet.amulet_startUI());
			UI_AmuletHome.Inst = this;
		}

		public onCreate() {
			let comRightTop = this.me.getChildByName('right_top') as Laya.Sprite;
			let comRightBottom = this.me.getChildByName('right_bottom') as Laya.Sprite;
			this.btnReturn = this.me.getChildByName('back') as Laya.Button;
			this.btnStart = this.me.getChildByName('start') as Laya.Button;
			this.btnRestart = this.me.getChildByName('restart') as Laya.Button;
			this.btnStrengthen = comRightBottom.getChildByName('strengthen') as Laya.Button;
			this.btnReward = comRightBottom.getChildByName('reward') as Laya.Button;
			this.btnHelp = comRightTop.getChildByName('help') as Laya.Button;
			this.btnRank = comRightTop.getChildByName('rank') as Laya.Button;
			this.btnChanllenge = comRightTop.getChildByName('challenge') as Laya.Button;
			this.btnIllustration = comRightTop.getChildByName('illustration') as Laya.Button;
			this.aniShow = (this.me as ui.amulet.amulet_startUI).show;
			this.aniHide = (this.me as ui.amulet.amulet_startUI).hide;
			this.aniIdle = (this.me as ui.amulet.amulet_startUI).idle;
			this._initFunc();
		}


		private _initFunc() {
			this.btnReturn.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				game.Scene_Amulet.Inst.GameEnd();
			}, null, false);
			this.btnStart.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				//退出初始界面动画
				if (this.haveOldGameRecord) {
					amulet.AmuletDesktopMgr.Inst.InitGame();
				} else {
					let param: game.IReqAmuletActivityStartGame = {
						activity_id: UI_Activity_Amulet.activityId
					};
					amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.StartGame, param);
				}
			}, null, false);
			this.btnRestart.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20003), Laya.Handler.create(this, () => {
					this.locking = true;
					let param: game.IReqAmuletActivityGiveup = {
						activity_id: UI_Activity_Amulet.activityId
					}
					amulet.AmuletDesktopMgr.Inst.GiveUpGame(param, Laya.Handler.create(this, () => {
						this.locking = false;
						this.refreshStartBtn();
						UI_Activity_Amulet.initBriefData();
					}));
				}));
				UI_SecondConfirm.Inst.setBtnState(true, true);
			}, null, false);
			this.btnReward.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.openOtherPage = true;
				uiscript.UI_AmuletReward.Inst.show();
			}, null, false);
			this.btnStrengthen.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.openOtherPage = true;
				uiscript.UI_AmuletStrengthen.Inst.show();
			}, null, false);
			this.btnIllustration.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.openOtherPage = true;
				uiscript.UI_AmuletOverview.Inst.show();
			}, null, false);
			this.btnHelp.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.openOtherPage = true;
				this.showGuide();
			}, null, false);
			this.btnRank.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.openOtherPage = true;
				UI_AmuletRank.Inst.show();
			}, null, false);
			// this.btnChanllenge.clickHandler = new Laya.Handler(this, () => {
			// 	if (this.locking) return;
			// 	this.openOtherPage = true;
			// 	UI_AmuletChallenge.Inst.show();
			// }, null, false);
			this.btnChanllenge.visible = false;
		}

		public refreshRedPoint() {
			(this.btnStrengthen.getChildByName('red_point') as Laya.Image).visible = UI_AmuletStrengthen.haveRedPoint();
			// (this.btnChanllenge.getChildByName('red_point') as Laya.Image).visible = UI_AmuletChallenge.haveRedPoint();
			(this.btnReward.getChildByName('red_point') as Laya.Image).visible = UI_AmuletReward.haveRedPoint();
		}

		private updateGameRecord() {
			if (this.enterTime && game.Tools.isPassedRefreshTimeServer(Number(this.enterTime) / 1000)) return;
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.taskRequest, { params: [UI_Activity_Amulet.activityId] }, (err, res: game.IResCommon) => {
				if (err || res.error) {
				} else {
					game.LocalStorage.setItem('activityEveryDay' + UI_Activity_Amulet.activityId + GameMgr.Inst.account_id, game.Tools.getServerTime().toString());
					this.enterTime = game.Tools.getServerTime().toString();
				}
			});
		}

		public showGuide() {
			let extraConfig: IRuleExtraConfig = {
				onClose: Laya.Handler.create(this, () => {
					UI_Info_Mid_Scroll.Inst.show(game.Tools.strOfLocalization(25081130));
					game.LocalStorage.setItem('activityGuide' + UI_Activity_Amulet.activityId + GameMgr.Inst.account_id, game.Tools.getServerTime().toString());
				})
			}
			UI_Amulet_Rules.Inst.show(extraConfig);
		}

		public show(doAnim: boolean = true) {
			this.enable = true;
			this.aniIdle.stop();
			this.aniShow.stop();
			this.aniHide.stop();
			this.openOtherPage = false;
			(this.me.getChildByName('bg').getChildAt(0) as Laya.Image).skin = '';
			if (!this.effectBg) {
				this.effectBg = Laya.loader.getRes('scene/effect_amulet_bg.ls');
				(this.me.getChildByName('bg') as Laya.Sprite).addChild(this.effectBg);
				let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				anim.offAll(Laya.Event.LABEL);
				anim.on(Laya.Event.LABEL, this, this.onAnimLabel)
			}
			this.effectBg.visible = true;
			if (doAnim) this.showAnim();
			const time = game.LocalStorage.getItem('activityGuide' + UI_Activity_Amulet.activityId + GameMgr.Inst.account_id);
			if (!time) {
				this.showGuide();
			}
			this.enterTime = game.LocalStorage.getItem('activityEveryDay' + UI_Activity_Amulet.activityId + GameMgr.Inst.account_id);
			this.refreshRedPoint();
			this.refreshStartBtn();
			UI_Activity_Amulet.initBriefData();
		}

		onAnimLabel(labelName: string) {
			if (labelName == 'dragonShout') view.AudioMgr.PlayAudio(10334);
			if (labelName == 'magic') view.AudioMgr.PlayAudio(10335);
			if (labelName == 'shoot') view.AudioMgr.PlayAudio(10336);
			if (labelName == 'animStart') {
				(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = false;
				(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = true;
			}
		}

		refreshStartBtn() {
			this.haveOldGameRecord = (!!amulet.AmuletDesktopMgr.Inst.amuletGameData.stage) && (!amulet.AmuletDesktopMgr.Inst.amuletGameData.ended);
			this.btnRestart.visible = this.haveOldGameRecord;
			(this.btnStart.getChildByName('icon') as Laya.Image).skin = game.Tools.localUISrc(this.haveOldGameRecord ? 'myres/amulet/btn_continue.png' : 'myres/amulet/btn_start.png');
		}

		showAnim() {
			this.locking = true;
			let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			anim.Play('fx_ui_hd031_main_show_laya');
			this.aniShow.play(0, false);
			view.AudioMgr.PlayAudio(10333);
			Laya.timer.once(60 / 60 * 1000, this, () => {
				(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = false;
				(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = true;
				anim.Play('fx_ui_hd031_main_idle_laya');
			});
			Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
				this.locking = false;
				this.aniShow.stop();
				this.aniIdle.play(0, true);
			})
		}

		hide() {
			this.updateGameRecord();
			Laya.timer.clearAll(this);
			(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = false;
			this.aniIdle.stop();
			let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
			anim.Play('fx_ui_hd031_main_hide_laya');
			this.aniHide.play(0, false);
			this.locking = true;
			Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
				this.enable = false;
				this.locking = false;
			});
		}

		public onDisable(): void {
			game.TempImageMgr.setUIEnable('UI_AmuletHome', false);
			Laya.timer.clearAll(this);
			if (this.effectBg) {
				(this.effectBg.getChildAt(1).getChildAt(6).getChildAt(1) as Laya.Sprite3D).active = false;
				let anim = (this.effectBg.getChildAt(1) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
				anim.Stop();
				this.effectBg.visible = false;
			}
			this.aniIdle.stop();
			this.aniHide.stop();
			this.aniShow.stop();
			this.locking = false;
		}

		public onEnable(): void {
			game.TempImageMgr.setUIEnable('UI_AmuletHome', true);
		}

		public onQuitScene(): void {
			if (this.effectBg) {
				this.effectBg.destroy();
				this.effectBg = null;
			}
		}
	}
}