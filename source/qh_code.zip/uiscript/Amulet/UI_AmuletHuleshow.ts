/**
* name 
*/
module uiscript {
	export class UI_AmuletHuleshow extends UIBase {
		public static Inst: UI_AmuletHuleshow = null;
		constructor(me: Laya.Sprite) {
			super(me);
			UI_AmuletHuleshow.Inst = this;
		}
		private black_mask: Laya.Image = null;
		private container_zimo: Laya.Sprite = null;

		public onCreate() {
			this.black_mask = this.me.getChildByName('black_mask') as Laya.Image;
			this.container_zimo = this.me.getChildByName('container_zimo') as Laya.Sprite;
		}

		public showZimo(): void {
			this.container_zimo.visible = true;
			this.black_mask.alpha = 0;
			let img: Laya.Image = this.container_zimo.getChildByName('0') as Laya.Image;
			img.visible = true;
			img.alpha = 0;
			img.scaleX = 3;
			img.scaleY = 3;
			Laya.Tween.to(img, { alpha: 1, scaleX: 1, scaleY: 1 }, 200, Laya.Ease.strongIn, null, 300, true);
			Laya.Tween.to(img, { alpha: 0 }, 0, Laya.Ease.strongIn, null, 1200);
			Laya.timer.once(1200, this, () => { this.enable = false; });
			this.enable = true;
		}

		public onDisable() {
			Laya.timer.clearAll(this);
		}
	}
}