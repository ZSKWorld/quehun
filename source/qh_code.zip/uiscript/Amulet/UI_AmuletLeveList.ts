module uiscript {
    export class UI_AmuletLevelDetail {
        public me: Laya.Sprite;
        private imgBg: Laya.Image;
        private comReward: Laya.Sprite;
        private txtLevel: Laya.Label;
        private txtLevelContent: Laya.Label;
        private imgWin: Laya.Image;
        private txtTargetScore: Laya.Label;
        private nowLevelTip: Laya.Sprite;
        private imgScoreBg: Laya.Image;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.comReward = this.me.getChildByName('reward') as Laya.Sprite;
            this.txtLevel = this.me.getChildByName('level') as Laya.Label;
            this.txtLevelContent = this.me.getChildByName('content') as Laya.Label;
            this.txtTargetScore = this.me.getChildByName('target_score') as Laya.Label;
            this.imgWin = this.me.getChildByName('win') as Laya.Image;
            this.nowLevelTip = this.me.getChildByName('now_level') as Laya.Sprite;
            this.imgScoreBg = this.me.getChildByName('score_bg') as Laya.Image;
            this.nowLevelTip.visible = false;
        }

        refreshReward(levelConfig: lqc.Sheet_Amulet_AmuletGames) {
            let config: number[] = [];
            if (levelConfig.reward_pack) {
                config = levelConfig.reward_pack.split(',').map((id) => { return Number(id) });
            }
            let packIds: number[] = [];
            let counts: number[] = [];
            //合并一下一样的
            config.forEach((id) => {
                let index = packIds.indexOf(id);
                if (index == -1) {
                    packIds.push(id);
                    counts.push(1);
                } else {
                    counts[index]++;
                }
            })
            for (let i = 0; i < this.comReward.numChildren; i++) {
                let reward = this.comReward.getChildAt(i) as Laya.Sprite;
                let title = reward.getChildByName('reward') as Laya.Label;
                let count = reward.getChildByName('count') as Laya.Label;
                let icon = reward.getChildByName('icon_currency') as Laya.Image;
                title.x = GameMgr.client_language == 'chs' || GameMgr.client_language == 'chs_t' ? 82 : 80;
                if (i == 0) {
                    title.text = game.Tools.strOfLocalization(20013);
                    count.text = levelConfig.reward.toString();
                } else {
                    title.text = game.Tools.strOfLocalization(20401);
                    reward.visible = !!packIds[i - 1];
                    if (reward.visible) {
                        let packageConfig = cfg.amulet.amulet_goods.get(packIds[i - 1]);
                        icon.skin = game.Tools.localUISrc('myres/amulet/card/package_' + packageConfig.guaranteed + '.png');
                        count.text = counts[i - 1].toString();
                    }
                }
            }
        }

        setIsPassed(isPassed: boolean = false) {
            this.imgWin.visible = isPassed;
        }

        refreshNowLevel(isNowLevel: boolean = false) {
            this.nowLevelTip.visible = isNowLevel;
            this.imgBg.width = isNowLevel ? 1270 : 1240;
            this.imgBg.x = isNowLevel ? 615 : 618;
            (this.nowLevelTip.getChildAt(0) as Laya.Image).x = this.txtLevel.trueWidth + 60;
        }

        refresh(levelConfig: lqc.Sheet_Amulet_AmuletGames) {
            this.me.visible = true;
            this.txtLevel.text = levelConfig.level_name;
            this.refreshReward(levelConfig);
            this.txtLevelContent.text = '';
            if (levelConfig.boss) {
                let bossId = amulet.AmuletDesktopMgr.Inst.getBossId(levelConfig.level);
                if (cfg.amulet.amulet_buff.get(bossId)) {
                    this.txtLevelContent.text = game.Tools.eventStrOfLocalization(cfg.amulet.amulet_buff.get(bossId).desc);
                }
            }
            this.txtTargetScore.text = game.Tools.strOfLocalization(20012) + ' ' + amulet.AmuletDesktopMgr.Inst.getTargetScoreStr(levelConfig.level);
            if (this.imgScoreBg) {
                this.txtTargetScore.width = 273;
                this.txtTargetScore.align = this.txtTargetScore.trueWidth > 273 ? 'right' : 'center';
                if (this.txtTargetScore.trueWidth > 273) this.txtTargetScore.width = this.txtTargetScore.trueWidth;
                this.imgScoreBg.width = this.txtTargetScore.trueWidth + 27 < 300 ? 300 : this.txtTargetScore.trueWidth + 27;
            }
        }

        hide() {
            this.me.visible = false;
        }
    }
    export class UI_AmuletLeveList extends UI_PopupBase {
        public static Inst: UI_AmuletLeveList;
        private listLevel: UI_AmuletLevelDetail[];
        private level: number;

        constructor() {
            super(new ui.amulet.amulet_levellistUI());
            UI_AmuletLeveList.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.listLevel = [];
            for (let i = 1; i <= 3; i++) {
                this.listLevel.push(new UI_AmuletLevelDetail(this.root.getChildByName('level' + i) as Laya.Sprite));
            }
            this.outClose = true;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            (this.root.getChildByName('btn_confirm') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                this.hide();
            }, null, false);
        }

        show() {
            if (this.locking) return;
            super.show();
            this.level = amulet.AmuletDesktopMgr.Inst.nowLevel;
            let inShop = uiscript.UI_AmuletDesktopInfo.Inst.desktopStage == amulet.EAmuletGameState.DuringShop;
            if (inShop && UI_Activity_Amulet.amuletLevelDic.get(this.level) && UI_Activity_Amulet.amuletLevelDic.get(this.level).next_level) {
                this.level = UI_Activity_Amulet.amuletLevelDic.get(this.level).next_level;
            }
            const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(this.level);
            let bossIdsGroup = UI_Activity_Amulet.amuletLevelGroupDic.get(nowLevelConfig.level_group);
            bossIdsGroup.sort((a, b) => { return a - b; });
            this.listLevel.forEach((level, index) => {
                if (bossIdsGroup[index] && UI_Activity_Amulet.amuletLevelDic.get(bossIdsGroup[index])) {
                    level.refresh(UI_Activity_Amulet.amuletLevelDic.get(bossIdsGroup[index]));
                    level.setIsPassed(bossIdsGroup[index] < this.level || (bossIdsGroup[index] == amulet.AmuletDesktopMgr.Inst.nowLevel && inShop));
                    level.refreshNowLevel(bossIdsGroup[index] == this.level);
                }
                else {
                    level.hide();
                }
            });
            for (let i = 0; i < this.listLevel.length; i++) {
                let com = this.listLevel[i];
                Laya.Tween.clearAll(com);
                if (com.me.visible) {
                    let targetY = 155 + 210 * i;
                    com.me.y = targetY + 100;
                    com.me.alpha = 0;
                    Laya.Tween.to(com.me, { y: targetY, alpha: 1 }, 150, Laya.Ease.quadInOut, null, 68 * i + 100);
                }
            }
        }

        hide() {
            super.hide();
        }
    }
}