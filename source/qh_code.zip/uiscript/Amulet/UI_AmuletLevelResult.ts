module uiscript {
    /**
    * 小关胜利
    */
    export class UI_AmuletLevelResult extends UIBase {
        public static Inst: UI_AmuletLevelResult;
        private btnConfirm: Laya.Button;
        private btnCurrency: Laya.Button;
        private txtCurrency: Laya.Label;
        private txtLevel: Laya.Label;
        private txtScore: Laya.Label;
        private txtLevelCoin: Laya.Label;
        private panel: Laya.Panel;
        private templete: Laya.Sprite;
        private comExtraCoin: Laya.Sprite[];
        private txtTotalCount: Laya.Label;
        private imgTotalIcon: Laya.Image;
        private txtTotalTitle: Laya.Label;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private aniReceive: Laya.FrameAnimation;
        private aniChara: Laya.FrameAnimation;
        private aniStar: Laya.FrameAnimation;
        private locking: boolean;
        private effect1: game.UIEffect;
        private effect2: game.UIEffect;
        private aniEffect: Catfood.CAnimator;
        private showEffect1: boolean = false;
        private showEffect2: boolean = false;
        private onClose: Laya.Handler;
        private totalCoin: SciNum;

        constructor() {
            super(new ui.amulet.amulet_levelresultUI());
            UI_AmuletLevelResult.Inst = this;
        }

        public onCreate(): void {
            this.btnConfirm = this.me.getChildByName('continue') as Laya.Button;
            this.btnCurrency = this.me.getChildByName('currency') as Laya.Button;
            this.txtCurrency = this.btnCurrency.getChildByName('count') as Laya.Label;
            this.txtLevel = this.me.getChildByName('level').getChildByName('level') as Laya.Label;
            this.txtScore = this.me.getChildByName('score').getChildByName('score') as Laya.Label;
            this.txtLevelCoin = this.me.getChildByName('score').getChildByName('count') as Laya.Label;
            this.panel = this.me.getChildByName('panel') as Laya.Panel;
            this.templete = this.panel.getChildByName('extra') as Laya.Sprite;
            this.templete.visible = false;
            this.comExtraCoin = [this.templete];
            this.txtTotalCount = this.me.getChildByName('count') as Laya.Label;
            this.txtTotalTitle = this.me.getChildByName('title') as Laya.Label;
            this.imgTotalIcon = this.me.getChildByName('icon_currency') as Laya.Image;
            this.btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.receiveReward();
            }, null, false);
            this.aniShow = (this.me as ui.amulet.amulet_levelresultUI).show;
            this.aniHide = (this.me as ui.amulet.amulet_levelresultUI).hide;
            this.aniReceive = (this.me as ui.amulet.amulet_levelresultUI).lingqu;
            this.aniChara = (this.me as ui.amulet.amulet_levelresultUI).char_idle;
            this.aniStar = (this.me as ui.amulet.amulet_levelresultUI).bg_star;
            (this.me.getChildByName('score').getChildByName('score_title') as Laya.Label).text = game.Tools.strOfLocalization(20023);
            (this.btnConfirm.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(20025);
        }

        public receiveReward() {
            this.locking = true;
            this.showEffect2 = true;
            if (this.effect2.effect.loaded) this.effect2.effect.root.active = true;
            if (Number(this.txtTotalCount.text) > 0) this.aniEffect.Play(null);
            view.AudioMgr.PlayAudio(10149);
            Laya.timer.once(500, this, () => {
                this.txtCurrency.text = UI_AmuletDesktopInfo.Inst.currencyCount.add(this.totalCoin).toString();
            })
            Laya.timer.once(800, this, () => {
                this.onClose && this.onClose.run();
            })
        }

        show(data: game.IAmuletEventData, onClose: Laya.Handler) {
            this.enable = true;
            this.onClose = onClose;
            const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(amulet.AmuletDesktopMgr.Inst.nowLevel);
            let coin = SciNum.createSciNumByStr(data.result.upgrade_result.level_coin || '0');
            let extraCount = 0;
            let rewardConfig: number[] = [];
            if (nowLevelConfig.reward_pack) {
                rewardConfig = nowLevelConfig.reward_pack.split(',').map((id) => { return Number(id) });
            }
            let packIds: number[] = [];
            let counts: SciNum[] = [];
            rewardConfig.forEach((id) => { //合并重复的
                let index = packIds.indexOf(id);
                if (index == -1) {
                    packIds.push(id);
                    counts.push(SciNum.createSciNum(1));
                } else {
                    counts[index] = counts[index].add(SciNum.createSciNum(1));
                }
            })
            for (let i = 0; i < packIds.length; i++) {
                this.setExtraReward(extraCount, game.Tools.strOfLocalization(20402), counts[i], packIds[i]);
                extraCount++;
            }

            const point_coin = data.result.upgrade_result.point_coin;
            let target = 0;
            cfg.amulet.amulet_rewards.forEach((reward) => {
                if (reward.activity_id == UI_Activity_Amulet.activityId && reward.reward_coin == Number(point_coin)) {
                    target = reward.target_point;
                    return;
                }
            })
            if (target) {
                this.setExtraReward(extraCount, game.Tools.strOfLocalization(20024, [target.toString()]), SciNum.createSciNumByStr(point_coin));
                coin = coin.add(SciNum.createSciNumByStr(point_coin));
                extraCount++;
            }
            let getEffectCoin = function (effect: game.IAmuletEffectedHookData) {
                let coin = '0';
                if (effect.result && effect.result.coin_modify && effect.result.coin_modify.modify) {
                    coin = effect.result.coin_modify.modify;
                }
                return SciNum.createSciNumByStr(coin);
            }
            let effects: Array<{ id: number, count: SciNum }> = [];
            let effectIds: number[] = [];
            let bossBuff: Array<{ id: number, count: SciNum }> = [];
            let bossIds: number[] = [];
            let badges: Array<{ id: number, count: SciNum }> = [];
            let badgeIds: number[] = [];
            data.effected_hooks.forEach((effect, index) => {
                let addCoin = getEffectCoin(effect);
                if (addCoin.toNumber() != 0) {
                    if (effect.type == 3) {
                        let index = bossIds.indexOf(effect.id);
                        if (index >= 0) {
                            bossBuff[index].count = bossBuff[index].count.add(addCoin);
                        } else {
                            bossBuff.push({
                                id: effect.id,
                                count: addCoin
                            });
                            bossIds.push(effect.id);
                        }
                    } else if (effect.type == 1) {
                        let index = effectIds.indexOf(effect.id);
                        if (index >= 0) {
                            effects[index].count = effects[index].count.add(addCoin);
                        } else {
                            effects.push({
                                id: effect.id,
                                count: addCoin
                            });
                            effectIds.push(effect.id);
                        }
                    } else if (effect.type == 2) {
                        let index = badgeIds.indexOf(effect.id);
                        if (index >= 0) {
                            badges[index].count = badges[index].count.add(addCoin);
                        } else {
                            badges.push({
                                id: effect.id,
                                count: addCoin
                            });
                            badgeIds.push(effect.id);
                        }
                    }
                }
            })
            for (let i = 0; i < badges.length; i++) {
                let badge = badges[i];
                if (badge.count.toNumber() != 0) {
                    coin = coin.add(badge.count);
                    this.setExtraReward(extraCount, game.Tools.eventStrOfLocalization(cfg.amulet.amulet_badge.get(badge.id).badge_name), badge.count);
                    extraCount++;
                }
            }
            for (let i = 0; i < effects.length; i++) {
                let effect = effects[i];
                if (effect.count.toNumber() != 0) {
                    coin = coin.add(effect.count);
                    this.setExtraReward(extraCount, game.Tools.eventStrOfLocalization(cfg.amulet.amulet_effect.get(effect.id).name), effect.count);
                    extraCount++;
                }
            }
            for (let i = 0; i < bossBuff.length; i++) {
                let effect = bossBuff[i];
                if (effect.count.toNumber() != 0) {
                    coin = coin.add(effect.count);
                    this.setExtraReward(extraCount, game.Tools.strOfLocalization(20083), effect.count);
                    extraCount++;
                }
            }
            this.showEffect1 = false;
            this.showEffect2 = false;
            if (!this.effect1) {
                this.effect1 = game.FrontEffect.Inst.create_ui_effect(this.me.getChildByName('effect') as Laya.Sprite, 'scene/effect_amulet_levelresult1.lh', new Laya.Point(960, 540), 1);
            }
            if (!this.effect2) {
                this.effect2 = game.FrontEffect.Inst.create_ui_effect(this.me.getChildByName('effect') as Laya.Sprite, 'scene/effect_amulet_levelresult2.lh', new Laya.Point(940, 545), 0.98);
                this.effect2.effect.addLoadedListener(Laya.Handler.create(this, () => {
                    this.effect2.effect.root.transform.localRotationEuler = new Laya.Vector3(0, 180, 0);
                    this.effect2.effect.root.active = this.showEffect2;
                    this.aniEffect = this.effect2.effect.root._childs[0]._childs[0]._childs[0].getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                }));
            }
            this.panel.scrollTo(0, 0);
            this.panel.refresh();
            this.panel.height = extraCount > 5 ? 270 : 300;
            this.txtLevel.text = nowLevelConfig.level_name;
            this.txtLevelCoin.text = nowLevelConfig.reward.toString();
            this.txtScore.text = amulet.AmuletDesktopMgr.Inst.getTargetScoreStr();
            this.txtCurrency.text = SciNum.getSciStr(UI_AmuletDesktopInfo.Inst.currencyCount.toString(), 6);
            this.totalCoin = coin;
            this.txtTotalCount.text = coin.toString();
            this.aniShow.gotoAndStop(0);
            this.aniShow.play(0, false);
            this.aniStar.play(0, true);
            this.locking = true;
            this.btnConfirm.alpha = 0;
            this.txtTotalCount.alpha = 0;
            this.txtTotalTitle.alpha = 0;
            this.imgTotalIcon.alpha = 0;
            Laya.timer.once(500 + extraCount * 34, this, () => {
                this.locking = false;
                this.aniReceive.play(0, false);
                this.showEffect1 = true;
            });
            Laya.timer.once(1000, this, () => {
                this.aniShow.stop();
                this.aniChara.play(0, true);
            });
            view.AudioMgr.PlayAudio(10340);
        }

        setExtraReward(index: number, title: string, rewardCount: SciNum, packageId: number = 0) {
            let comExtraCoin;
            if (this.comExtraCoin[index]) {
                comExtraCoin = this.comExtraCoin[index];
            } else {
                let uiCopy = this.templete.scriptMap['capsui.UICopy'] as capsui.UICopy;
                comExtraCoin = uiCopy.getNodeClone();
                this.panel.addChild(comExtraCoin);
                this.comExtraCoin.push(comExtraCoin);
                comExtraCoin.x = 0;
            }
            comExtraCoin.visible = true;
            let txtTitle = comExtraCoin.getChildByName('title') as Laya.Label;
            let txtCurrency = comExtraCoin.getChildByName('count') as Laya.Label;
            let iconCurrency = comExtraCoin.getChildByName('icon_currency') as Laya.Image;
            let iconBg = comExtraCoin.getChildByName('bg') as Laya.Image;
            txtTitle.text = title;
            txtCurrency.text = rewardCount.toString();
            let packageConfig = cfg.amulet.amulet_goods.get(packageId);
            iconCurrency.skin = game.Tools.localUISrc(packageId ? 'myres/amulet/card/package_' + packageConfig.guaranteed + '.png' : 'myres/amulet/currency_opposite_bureau.png')
            iconBg.skin = game.Tools.localUISrc(packageId ? 'myres/amulet/pass_level_reward_bg1.png' : 'myres/amulet/pass_level_reward_bg2.png');
            iconCurrency.x = txtCurrency.x - txtCurrency.width - 45;
            let targetY = index * 60;
            comExtraCoin.y = targetY + 50;
            comExtraCoin.alpha = 0;
            Laya.Tween.clearAll(comExtraCoin);
            Laya.Tween.to(comExtraCoin, { y: targetY, alpha: 1 }, 167, Laya.Ease.quadInOut, null, 500 + index * 34);
        }

        hide() {
            this.aniHide.gotoAndStop(0);
            this.aniHide.play(0, false);
            let delay = this.aniHide.count * this.aniHide.interval;
            Laya.timer.once(delay, this, () => {
                this.aniHide.stop();
                this.enable = false;
                this.locking = false;
            })
        }

        public onDisable(): void {
            this.aniStar.stop();
            this.aniChara.stop();
            for (let i = 0; i < this.comExtraCoin.length; i++) {
                this.comExtraCoin[i].visible = false;
            }
            if (this.effect1) {
                this.effect1.destory();
                this.effect1 = null;
            }
            if (this.effect2) {
                this.effect2.destory();
                this.effect2 = null;
            }
        }
    }
}