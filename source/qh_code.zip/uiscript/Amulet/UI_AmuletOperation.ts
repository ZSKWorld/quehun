/**
* name 
*/
module uiscript {
	interface IGangType {
		isMixed: boolean;
		tiles: amulet.MJPai[];
	}
	export class UI_AmuletOperation extends UIBase {
		public static Inst: UI_AmuletOperation = null;
		private _gangTiles: IGangType[] = [];
		private operation: amulet.EAmuletPlayOperation = amulet.EAmuletPlayOperation.none;
		private _oplist: Array<string> = [];
		protected container_btns: Laya.Sprite;
		protected container_Detail: Laya.Sprite = null;
		protected btn_cancel: Laya.Button = null;
		protected btn_detail_back: Laya.Button = null;
		protected label_title: Laya.Label = null;
		private op_btns: Object = new Object();
		private containerChoosesPais: UI_MJP[][];

		constructor() {
			super(new ui.amulet.amulet_operationUI());
			UI_AmuletOperation.Inst = this;
		}

		public onCreate(): void {
			let container_btns: Laya.Sprite = this.me.getChildByName('container_btns') as Laya.Sprite;
			this.container_btns = container_btns;
			for (let i: number = 0; i < this.container_btns.numChildren; i++) {
				let btn: Laya.Button = this.container_btns.getChildAt(i) as Laya.Button;
				this.op_btns[btn.name] = btn;
				btn.visible = false;
				btn.clickHandler = new Laya.Handler(this, this.onClickOpBtn, [btn.name]);
			}

			this.container_Detail = this.me.getChildByName('container_detail') as Laya.Sprite;
			this.container_Detail.visible = false;
			for (let i: number = 0; i < 6; i++) {
				let _detail: Laya.Sprite = this.container_Detail.getChildByName('container_chooses').getChildByName('c' + i) as Laya.Sprite;
				_detail.visible = false;
				(_detail as Laya.Button).clickHandler = laya.utils.Handler.create(this, this.onClickDetail, [i], false);
			}
			this.btn_detail_back = this.container_Detail.getChildByName('btn_back') as Laya.Button;
			this.btn_detail_back.clickHandler = new Laya.Handler(this, this.onDetailBack, null, false);
			this.btn_cancel = this.me.getChildByName('btn_cancel') as Laya.Button;
			this.btn_cancel.visible = false;
			this.label_title = this.container_Detail.getChildByName('container_title').getChildByName('lab_title') as Laya.Label;
			this.label_title.text = '';
			let container_chooses: Laya.Sprite = this.container_Detail.getChildByName('container_chooses') as Laya.Sprite;
			this.containerChoosesPais = [];
			for (let i: number = 0; i < 12; i++) {
				let cc: Laya.Sprite = container_chooses.getChildByName('c' + i) as Laya.Sprite;
				let pais = [];
				for (let j: number = 0; j < 4; j++) {
					pais.push(new UI_MJP(cc.getChildByName('img' + j) as Laya.Image));
				}
				this.containerChoosesPais.push(pais);
			}
		}

		public show(data: game.IAmuletGameOperation[]): void {

			let oplist: Array<string> = [];
			let canDiscard = false;
			for (let i: number = 0; i < data.length; i++) {
				switch (data[i].type) {
					case amulet.EAmuletPlayOperation.endExchange: {
						this.operation = amulet.EAmuletPlayOperation.endExchange;
						oplist.push('btn_replace');
						break;
					}
					case amulet.EAmuletPlayOperation.gang: {
						this.operation = amulet.EAmuletPlayOperation.gang;
						oplist.push('btn_gang');
						this._gangTiles = [];
						let gangTiles = [];
						let mixedGangLst: string[] = []; //有融合杠不显示原暗杠 111m555p 1m → 杠 555p1m
						if (data[i].gang) {
							data[i].gang.forEach(gangInfo => {
								let tiles = gangInfo.tiles.map((tile) => amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(tile));
								tiles.sort((a, b) => { return a.numValue() - b.numValue() });
								let hands = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands.map((tile) => amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(tile).toString());
								let isMixedGang = false;
								for (let t = 0; t < tiles.length; t++) {
									for (let f = 0; f < tiles.length; f++) {
										if (f != t) {
											if (amulet.MJPai.Distance(tiles[t], tiles[f]) != 0) {
												isMixedGang = true;
												break;
											}
										}
									}
									if (isMixedGang) break;
								}
								if (isMixedGang) { //是融合杠，判断有无红宝牌，过滤掉没有红宝牌的杠
									let tileStrs = tiles.map((tile) => tile.toString());
									let gang5Tile = tiles.find(tile => tile.type != amulet.E_MJPai.z && tile.index == 5 && !tile.dora);
									if (gang5Tile) {
										let str = '0' + amulet.E_MJPai[gang5Tile.type];
										//手牌里有红宝牌，但是这个杠的组合里没有，直接返回
										if (hands.indexOf(str) != -1 && tileStrs.indexOf(str) == -1) return;
									}
									let isRepeat = true;
									tiles.forEach((tile) => {
										if (mixedGangLst.indexOf(tile.toString()) == -1) {
											isRepeat = false;
											mixedGangLst.push(tile.toString());
										}
									});
									if (!isRepeat)
										gangTiles.push({
											tiles,
											isMixed: true
										});
								} else {
									gangTiles.push({
										tiles,
										isMixed: false
									});
								}

							});
						}
						for (let i = 0; i < gangTiles.length; i++) {
							if (!gangTiles[i].isMixed) {
								let legal = true;
								for (let j = 0; j < mixedGangLst.length; j++) {
									if (amulet.MJPai.Distance(gangTiles[i].tiles[0], amulet.MJPai.Create({ id: -1, tile: mixedGangLst[j] })) == 0) {
										legal = false;
										break;
									}
								}
								if (legal) this._gangTiles.push(gangTiles[i]);
							} else {
								this._gangTiles.push(gangTiles[i]);
							}
						}
						break;
					}
					case amulet.EAmuletPlayOperation.rong: {
						this.operation = amulet.EAmuletPlayOperation.rong;
						oplist.push('btn_hu');
						break;
					}
					case amulet.EAmuletPlayOperation.discard: {
						canDiscard = true;
						break;
					}
				}
			}
			if (this.operation == amulet.EAmuletPlayOperation.endExchange || canDiscard) {
				oplist.push('btn_cancel');
			}
			this._oplist = oplist;
			this.showOp(oplist);
			this.enable = true;
			view.AudioMgr.PlayAudio(202);
		}

		public onClickOpBtn(name: string): void {
			view.AudioMgr.PlayAudio(101);
			switch (name) {
				case 'btn_replace': {
					this.onBtnReplace(); break;
				}
				case 'btn_gang': {
					this.onBtnGang(); break;
				}
				case 'btn_hu': {
					this.onBtnHu(); break;
				}
				case 'btn_cancel': {
					this.onBtnCancel(); break;
				}
			}
		}

		public onClickDetail(index: number): void {
			let ids: number[] = [];
			this._gangTiles[index].tiles.forEach((tile) => {
				ids.push(tile.id);
			})
			let param: game.IReqAmuletActivityOperate = {
				activity_id: UI_Activity_Amulet.activityId,
				type: amulet.EAmuletPlayOperation.gang,
				tile_list: ids
			};
			amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
		}

		public onDetailBack(): void {
			this.showOp(this._oplist);
			view.AudioMgr.PlayAudio(101);
		}

		public onBtnReplace(): void {
			let cards = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands;
			let leftCards = [];
			cards.forEach(id => {
				if (amulet.AmuletDesktopMgr.Inst.choosedReplacePaiIds.indexOf(id) == -1) {
					leftCards.push(id);
				}
			})
			if (leftCards.length == 13) return;
			let param: game.IReqAmuletActivityOperate = {
				activity_id: UI_Activity_Amulet.activityId,
				type: amulet.EAmuletPlayOperation.exchange,
				tile_list: leftCards
			};
			amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
		}

		public onBtnGang(): void {
			if (this._gangTiles.length > 1) {
				this.showDetail(game.Tools.strOfLocalization(2078), this._gangTiles);
			} else {
				let ids: number[] = [];
				this._gangTiles[0].tiles.forEach((tile) => {
					ids.push(tile.id);
				})
				const param: game.IReqAmuletActivityOperate = {
					activity_id: UI_Activity_Amulet.activityId,
					type: amulet.EAmuletPlayOperation.gang,
					tile_list: ids
				};
				amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
			}
		}

		public onBtnHu(): void {
			let param: game.IReqAmuletActivityOperate = {
				activity_id: UI_Activity_Amulet.activityId,
				type: amulet.EAmuletPlayOperation.rong,
				tile_list: []
			};
			amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
		}

		public onBtnCancel(): void {
			if (this.operation == amulet.EAmuletPlayOperation.endExchange) {
				let param: game.IReqAmuletActivityOperate = {
					activity_id: UI_Activity_Amulet.activityId,
					type: amulet.EAmuletPlayOperation.endExchange
				};
				amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.DoOperation, param);
			} else {
				this.enable = false;
				amulet.AmuletDesktopMgr.Inst.pendingAuto(true); //如果选择了自动模切，在取消杠，胡牌操作后自动模切
			}
		}

		public onDisable(): void {
			Laya.timer.clearAll(this);
		}

		public onDoubleClick(): void {
			if (this.operation == amulet.EAmuletPlayOperation.endExchange) return; //换牌不能双击跳过
			if ((!this.container_btns.visible) || (!(this.container_btns.getChildByName('btn_cancel') as Laya.Button).visible)) return; //压根没有胡牌按钮可选，跳过
			this.onBtnCancel();
		}

		public showOp(list: Array<string>) {
			this.container_Detail.visible = false;
			this.container_btns.visible = true;
			this.btn_cancel.visible = false;
			for (let i: number = this.container_btns.numChildren - 1; i >= 0; i--) {
				let open: boolean = false;
				let index: number = -1;
				let cc: Laya.Sprite = this.container_btns.getChildAt(i) as Laya.Sprite;
				for (let j: number = 0; j < list.length; j++) {
					if (list[j] == cc.name) {
						open = true;
						index = j;
						break;
					}
				}
				if (open) {
					cc.x = 881 - (list.length - 1 - index) * 280;
				}
				cc.visible = open;
				if (cc.name == 'btn_replace') {
					this.refreshBtnReplace();
				}
			}
			this.container_btns.alpha = 1;
			Laya.Tween.from(this.container_btns, { x: 750, alpha: 0 }, 160);
		}

		public refreshBtnReplace() {
			if (!this.container_btns) return;
			let btn = this.container_btns.getChildByName('btn_replace') as Laya.Button;
			if (btn.visible) {
				const count = amulet.AmuletDesktopMgr.Inst.changeTileCount;
				(btn.getChildByName('count') as Laya.Label).text = count.toString();
				const choosedCount = amulet.AmuletDesktopMgr.Inst.choosedReplacePaiIds.length;
				game.Tools.setGrayDisable(btn, count == 0 || choosedCount == 0);
			}
		}

		public showDetail(title: string, list: IGangType[]) {
			this.container_btns.visible = false;
			this.btn_cancel.visible = false;
			let container_title: Laya.Sprite = this.container_Detail.getChildByName('container_title') as Laya.Sprite;
			let lable_title: Laya.Label = container_title.getChildByName('lab_title') as Laya.Label;
			let container_chooses: Laya.Sprite = this.container_Detail.getChildByName('container_chooses') as Laya.Sprite;

			let current_width: number = 0;
			let current_height: number = -23;
			let width_pai: number = (container_chooses.getChildByName('c0').getChildByName('img0') as Laya.Sprite).width;
			let com_span: number = width_pai * 0.5;
			this.label_title.text = title;

			let max_width = 0;
			for (let i: number = 0; i < this.containerChoosesPais.length; i++) {
				let cc: Laya.Sprite = container_chooses.getChildByName('c' + i) as Laya.Sprite;
				if (i < list.length) {
					let pais: UI_MJP[] = this.containerChoosesPais[i];
					let tiles: amulet.MJPai[] = list[i].tiles;
					for (let j: number = 0; j < 4; j++) {
						let pai: UI_MJP = pais[j];
						pai.setFiltersState(EUIPaiFilterState.none);
						const titleUrl = (tiles[j]).toString();
						pai.show(titleUrl);
						pai.pos(j * width_pai, 0)
					}
					cc.width = 4 * width_pai;
					if (!(i == 0 || (list.length > 6 && i == Math.ceil(list.length / 2)))) current_width += com_span;
					cc.x = current_width;
					current_width += cc.width;
					max_width = Math.max(current_width, max_width);

					cc.y = current_height;
					cc.visible = true;
					if (list.length > 6 && i == Math.ceil(list.length / 2) - 1) {
						current_width = 0;
						current_height = 115;
					}
				} else {
					cc.visible = false;
				}
			}

			container_chooses.width = max_width;
			this.container_Detail.width = max_width + 120 * 2;
			container_title.x = this.container_Detail.width * 0.5;
			container_chooses.x = 100;
			this.btn_detail_back.x = this.container_Detail.width - 56;
			this.container_Detail.visible = true;
			this.container_Detail.x = 1920 / 2 - this.container_Detail.width / 2;
			if (list.length > 6) {
				this.container_Detail.height = 391;
				this.container_Detail.y = 626 + 255 - this.container_Detail.height;
			} else {
				this.container_Detail.height = 255;
				this.container_Detail.y = 626;
			}
		}
	}
}