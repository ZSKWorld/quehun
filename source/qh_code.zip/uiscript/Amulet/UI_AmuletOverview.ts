module uiscript {
    class UI_AmuletBadge extends UIBase {
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;
        private btnMask: Laya.Button;
        private btnClose: Laya.Button;
        private imgBg: Laya.Image;
        private imgBadge: Laya.Image;
        private txtName: Laya.Label;
        private panelDesc: Laya.Panel;
        private comContent: Laya.Sprite;
        private txtDesc: Laya.HTMLDivElement;
        private locking: boolean;

        constructor(me: Laya.Sprite, parent: ui.amulet.amulet_overviewUI) {
            super(me);
            this.aniShow = parent.show_badge;
            this.aniHide = parent.hide_badge;
        }

        onCreate() {
            this.btnMask = this.me.getChildByName('btn_mask') as Laya.Button;
            let root = this.me.getChildByName('root') as Laya.Sprite;
            this.imgBg = root.getChildByName('bg') as Laya.Image;
            this.imgBadge = root.getChildByName('badge') as Laya.Image;
            this.btnClose = root.getChildByName('btn_close') as Laya.Button;
            this.txtName = root.getChildByName('name') as Laya.Label;
            this.panelDesc = root.getChildByName('desc') as Laya.Panel;
            this.comContent = this.panelDesc.getChildByName('content') as Laya.Sprite;
            this.txtDesc = this.comContent.getChildByName('desc') as Laya.HTMLDivElement;
            if (GameMgr.client_language == 'jp') {
                this.txtDesc.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtDesc.style.font = '32px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtDesc.style.font = '32px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtDesc.style.font = '30px SimHei';
            } else {
                this.txtDesc.style.font = '30px NotoSansKR';
            }
            this.txtDesc.style.color = '#9d765b';
            this.txtDesc.style.leading = 6;
            this.txtDesc.style.letterSpacing = 0;
            this.btnClose.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.btnMask.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
        }

        show(badgeConfig: lqc.Sheet_Amulet_AmuletBadge) {
            this.locking = true;
            this.enable = true;
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            })
            this.imgBadge.skin = game.Tools.localUISrc('myres/amulet/card/' + badgeConfig.badge_image + '.png');
            this.txtName.text = game.Tools.eventStrOfLocalization(badgeConfig.badge_name);
            let prop = amulet.PropCard.CreatePropOption(0, badgeConfig.id);
            this.txtDesc.innerHTML = game.Tools.ParseText(game.Tools.eventStrOfLocalization(badgeConfig.badge_desc, UI_PropDetailCard.getBadgeFinalArgs(prop)), '#ffd133');
            this.comContent.height = this.txtDesc.contextHeight;
            this.panelDesc.scrollTo(0, 0);
            this.panelDesc.refresh();
        }

        hide() {
            this.locking = true;
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.count * this.aniHide.interval, this, () => {
                this.locking = false;
                this.aniHide.stop();
                this.enable = false;
            })
        }
    }

    class UI_SmallProp {
        public me: Laya.Sprite;
        private imgPlus: Laya.Image;
        private imgIcon: Laya.Image;
        private imgBg: Laya.Image;
        private imgBadge: Laya.Image;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.imgPlus = this.me.getChildByName('plus') as Laya.Image;
            this.imgIcon = this.me.getChildByName('icon') as Laya.Image;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.imgBadge = this.me.getChildByName('badge') as Laya.Image;
        }

        get width(): number {
            return this.me.width * this.me.scaleX;
        }

        refresh(effect: game.IActivityAmuletEffectRecordData, x: number) {
            this.me.visible = true;
            this.me.x = x;
            this.me.width = effect.volume * 160;
            this.me.event('size_change');
            let effectConfig = cfg.amulet.amulet_effect.get(effect.id);
            this.imgPlus.visible = !!effectConfig.card_remark;
            game.LoadMgr.setImgSkin(this.imgIcon, 'myres/amulet/effect/' + effectConfig.card_image + '.png', null, 'UI_AmuletOverview');
            this.imgBg.skin = game.Tools.localUISrc('myres/amulet/card/fu_bg' + effectConfig.rarity + (effect.volume == 1 ? '' : '_widen') + '.png');
            this.imgBadge.skin = effect.badge_id ? game.Tools.localUISrc('myres/amulet/card/badge_' + effect.badge_id + '.png') : '';
        }

        clear() {
            this.me.visible = false;
        }
    }

    class UI_RecentItem {
        private me: Laya.Sprite;
        private txtTitle: Laya.Label;
        private txtTime: Laya.Label;
        private imgTitle: Laya.Image;
        private comRecordProps: Laya.Sprite;
        private comStatistics: Laya.Sprite[];
        private comProps: UI_SmallProp[];
        constructor(me: Laya.Sprite) {
            this.me = me;
            this.txtTitle = this.me.getChildByName('title').getChildByName('title') as Laya.Label;
            this.txtTime = this.me.getChildByName('time') as Laya.Label;
            this.comRecordProps = this.me.getChildByName('container_prop') as Laya.Sprite;
            let comStatistic = this.me.getChildByName('statistics') as Laya.Sprite;
            this.comStatistics = [];
            this.comStatistics = comStatistic._childs;
            this.imgTitle = this.me.getChildByName('title') as Laya.Image;
            this.comProps = this.comRecordProps._childs.map(item => new UI_SmallProp(item));
        }

        refresh(index: number, data: game.IActivityAmuletGameRecordData) {
            this.txtTitle.text = game.Tools.strOfLocalization(25081105, [(index + 1).toString()]);
            this.txtTime.text = game.Tools.strOfLocalization(25081106, [game.Tools.time2YearMounthDateHourMinute(data.time)]);
            this.imgTitle.width = this.txtTitle.trueWidth + 26;
            let effects = data.effect_builds || [];
            let width = 0;
            for (let i = 0; i < this.comProps.length; i++) {
                let prop = this.comProps[i];
                if (effects[i]) {
                    prop.refresh(effects[i], width);
                    width = width + prop.width + 2;
                } else {
                    prop.clear();
                }
            }
            let statisticDatas: { title: string, desc: string }[] = [];
            //最高到达关卡
            let statistic = { title: game.Tools.strOfLocalization(20056), desc: game.Tools.strOfLocalization(20060) };
            if (data.level) {
                const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(data.level);
                statistic.desc = nowLevelConfig.level_name;
            }
            statisticDatas.push(statistic);
            //最高关卡得分	
            statistic = { title: game.Tools.strOfLocalization(25081107), desc: game.Tools.strOfLocalization(20060) };
            if (data.highest_level_score) {
                statistic.desc = SciNum.getSciStr(data.highest_level_score, 6);;
            }
            statisticDatas.push(statistic);
            //最高番数
            statistic = { title: game.Tools.strOfLocalization(25081108), desc: game.Tools.strOfLocalization(20060) };
            if (data.highest_fan) {
                statistic.desc = SciNum.getSciStr(data.highest_fan, 6);
            }
            statisticDatas.push(statistic);
            //最高分数
            statistic = { title: game.Tools.strOfLocalization(25081109), desc: game.Tools.strOfLocalization(20060) };
            if (data.highest_score) {
                statistic.desc = SciNum.getSciStr(data.highest_score, 6);
            }
            statisticDatas.push(statistic);
            //最多花费星币
            statistic = { title: game.Tools.strOfLocalization(25081116), desc: '0' };
            if (data.coin_consumed) {
                statistic.desc = data.coin_consumed.toString();
            }
            //最多开包数
            statistic = { title: game.Tools.strOfLocalization(25081117), desc: '0' };
            if (data.pack_count) {
                statistic.desc = data.pack_count.toString();
            }
            statisticDatas.push(statistic);

            for (let i = 0; i < statisticDatas.length; i++) {
                let com = this.comStatistics[i];
                com.x = i % 2 == 0 ? 0 : 596;
                com.y = 18 + Math.floor(i / 2) * 48;
                let txtTitle = com.getChildByName('title') as Laya.Label;
                let txtValue = com.getChildByName('value') as Laya.Label;
                txtTitle.text = statisticDatas[i].title;
                txtValue.x = txtTitle.x + txtTitle.trueWidth;
                txtValue.text = statisticDatas[i].desc;
                let width = txtValue.x + txtValue.trueWidth;
                let scale = 1;
                if (width > 550) scale = 550 / width;
                com.scale(scale, scale);
            }
        }
    }
    /**
    * 青云图鉴弹窗
    */
    export class UI_AmuletOverview extends UI_PopupBase {
        public static Inst: UI_AmuletOverview;
        private comBtns: Laya.Sprite;
        private panelAchieve: Laya.Panel;
        private achieveScrollBar: capsui.CScrollBar;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [20052, 25081101, 20053, 25081102];
        private tabButtons: Array<Amulet_TabButton>;
        private pageProp: Laya.Sprite;
        private pageBadge: Laya.Sprite;
        private pageAchieve: Laya.Sprite;
        private pageRecent: Laya.Sprite;
        private comAchieveContent: Laya.Sprite;
        private comPoint: Laya.Sprite;
        private scoreTemplteUI: capsui.UICopy;
        private imgPointNumber: Laya.Image[] = [];
        private containerHand: Laya.Sprite = null;
        private containerProp: Laya.Sprite = null;
        private scrollViewProp: capsui.CScrollView;
        private scrollViewBadge: capsui.CScrollView;
        private scrollViewRecent: capsui.CScrollView;
        private comStatistics: Laya.Sprite[];
        private templeteStatistic: capsui.UICopy;
        private comRecordProps: Laya.Sprite[];
        private popupBadge: UI_AmuletBadge;

        private hands: Array<UI_MJP> = [];
        private effectConfigGroup: lqc.Sheet_Amulet_AmuletEffect[] = [];
        private badgeConfigGroup: lqc.Sheet_Amulet_AmuletBadge[] = [];

        public get effectCounts(): number {
            return this.effectConfigGroup.length;
        }

        public get badgeCounts(): number {
            return this.badgeConfigGroup.length;
        }

        constructor() {
            super(new ui.amulet.amulet_overviewUI());
            UI_AmuletOverview.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.outClose = true;
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            this.pageProp = this.root.getChildByName("content1") as Laya.Sprite;
            this.pageBadge = this.root.getChildByName("content2") as Laya.Sprite;
            this.pageAchieve = this.root.getChildByName("content3") as Laya.Sprite;
            this.pageRecent = this.root.getChildByName("content4") as Laya.Sprite;
            this.panelAchieve = this.pageAchieve.getChildByName("content") as Laya.Panel;
            this.comAchieveContent = this.panelAchieve.getChildByName('content') as Laya.Sprite;
            let comPais = this.comAchieveContent.getChildAt(0) as Laya.Sprite;
            let comHu = comPais.getChildByName('hu_content') as Laya.Sprite;
            this.comPoint = comHu.getChildByName('container_score') as Laya.Sprite;
            this.imgPointNumber = [];
            this.scoreTemplteUI = (this.comPoint.getChildByName('templete') as Laya.Sprite).scriptMap['capsui.UICopy'];
            (this.comPoint.getChildByName('templete') as Laya.Sprite).visible = false;
            this.containerHand = comHu.getChildByName('container_hand') as Laya.Sprite;
            this.containerProp = comHu.getChildByName('container_prop') as Laya.Sprite;
            this.hands = [];
            for (let i: number = 0; i < this.containerHand.numChildren; i++) {
                let img: Laya.Image = this.containerHand.getChildAt(i) as Laya.Image;
                img.visible = false;
                this.hands.push(new UI_MJP(img));
            }
            this.effectConfigGroup = [];
            cfg.amulet.amulet_effect.forEach((effect, index) => {
                if (!effect.deprecated) {
                    this.effectConfigGroup.push(effect);
                }
            });
            this.effectConfigGroup.sort((a, b) => {
                if (a.rarity != b.rarity) return b.rarity - a.rarity;
                return a.id - b.id;
            })
            this.badgeConfigGroup = [];
            cfg.amulet.amulet_badge.forEach((badge, index) => {
                if (!badge.deprecated) {
                    this.badgeConfigGroup.push(badge);
                }
            });
            this.badgeConfigGroup.sort((a, b) => {
                if (a.rarity != b.rarity) return a.rarity - b.rarity;
                return a.id - b.id;
            })
            this.scrollViewProp = this.pageProp.scriptMap['capsui.CScrollView'];
            this.scrollViewProp.init_scrollview(new Laya.Handler(this, this.listPropRender), 239, 6);
            this.scrollViewBadge = this.pageBadge.scriptMap['capsui.CScrollView'];
            this.scrollViewBadge.init_scrollview(new Laya.Handler(this, this.listBadgeRender), 0, 6);
            this.scrollViewRecent = this.pageRecent.scriptMap['capsui.CScrollView'];
            this.scrollViewRecent.init_scrollview(new Laya.Handler(this, this.listRecentRender));

            this.achieveScrollBar = (this.pageAchieve.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this.achieveScrollBar.init(new Laya.Handler(this, rate => {
                this.panelAchieve.vScrollBar.value = this.panelAchieve.vScrollBar.max * rate;
            }));
            this.panelAchieve.vScrollBarSkin = '';
            this.panelAchieve.vScrollBar.on('change', this, () => {
                this.achieveScrollBar.setVal(this.panelAchieve.vScrollBar.value / this.panelAchieve.vScrollBar.max, this.panelAchieve.height / this.comAchieveContent.height);
            });
            this.popupBadge = new UI_AmuletBadge(this.me.getChildByName('badge_detail') as Laya.Sprite, this.me as ui.amulet.amulet_overviewUI);
            let templeteStatistic = this.panelAchieve.getChildByName('content').getChildByName('record').getChildByName('templete') as Laya.Sprite;
            this.templeteStatistic = templeteStatistic.scriptMap['capsui.UICopy'] as capsui.UICopy;
            this.comStatistics = [templeteStatistic];
            this.comRecordProps = [];
            for (let i = 0; i < this.containerProp.numChildren; i++) {
                this.comRecordProps.push(this.containerProp.getChildAt(i) as Laya.Sprite);
            }
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<Amulet_TabButton>();
            let tabsName = ['prop', 'badge', 'achievement', 'recent'];
            for (let i = 0; i < tabsName.length; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                if (GameMgr.client_language == 'en' && i == 1) {
                    tabName.x = 95;
                    tabName.scale(0.85, 0.85);
                }
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Amulet_TabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.refreshList();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.setTitle(game.Tools.strOfLocalization(20051));
        }

        private refreshList(delay: number = 0) {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            this.pageProp.visible = currentSelectIndex == 0;
            this.pageAchieve.visible = currentSelectIndex == 2;
            this.pageBadge.visible = currentSelectIndex == 1;
            this.pageRecent.visible = currentSelectIndex == 3;
            if (this.pageProp.visible) {
                this.refreshProps(delay);
            } else if (this.pageBadge.visible) {
                this.refreshBadges(delay);
            } else if (this.pageAchieve.visible) {
                this.refreshAchieve();
            } else {
                this.refreshRecent();
            }
            (this.root.getChildByName('bg').getChildByName('frame') as Laya.Image).visible = currentSelectIndex != 1;
        }

        show() {
            if (this.locking) return;
            super.show();
            this.tabGroups.init();
            this.refreshList(100);
        }

        hide() {
            super.hide();
        }

        private refreshProps(delay: number = 0) {
            this.scrollViewProp.reset();
            this.scrollViewProp.addItem(this.effectConfigGroup.length);
            this.locking = true;
            let list = this.scrollViewProp;
            list.me.mouseEnabled = false;
            let list_delay = 23 * 34 + 100;
            list.items.forEach((value) => {
                let com = value.container;
                let index = value.value_index;
                let btn = com.getChildByName('btn') as Laya.Button;
                btn.alpha = 0;
                btn.scale(0.5, 0.5);
                Laya.Tween.clearAll(btn);
                Laya.Tween.to(btn, { alpha: 1, scaleX: 1, scaleY: 1 }, 100, Laya.Ease.quadInOut, null, delay + index * 17);
            })
            Laya.timer.once(delay + list_delay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        private refreshBadges(delay: number = 0) {
            this.scrollViewBadge.reset();
            this.scrollViewBadge.addItem(this.badgeConfigGroup.length);
            this.locking = true;
            let list = this.scrollViewBadge;
            list.me.mouseEnabled = false;
            let list_delay = 23 * 34 + 100;
            list.items.forEach((value) => {
                let com = value.container;
                let index = value.value_index;
                let btn = com.getChildByName('btn') as Laya.Button;
                btn.alpha = 0;
                btn.scale(0.5, 0.5);
                Laya.Tween.clearAll(btn);
                Laya.Tween.to(btn, { alpha: 1, scaleX: 1, scaleY: 1 }, 100, Laya.Ease.quadInOut, null, delay + index * 17);
            })
            Laya.timer.once(delay + list_delay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        private refreshRecent() {
            let count = Math.min(5, UI_Activity_Amulet.recentRecords.length);
            this.scrollViewRecent.reset();
            this.scrollViewRecent.addItem(count);
            (this.pageRecent.getChildByName('empty') as Laya.Sprite).visible = count == 0;
        }

        private listPropRender(obj) {
            let comProp: Laya.Button = obj.container.getChildByName('btn') as Laya.Button;
            comProp.alpha = 1;
            comProp.scale(1, 1);
            Laya.Tween.clearAll(comProp);
            let index: number = obj.index;
            let effect: lqc.Sheet_Amulet_AmuletEffect = this.effectConfigGroup[index];
            let isUnLock = UI_Activity_Amulet.isPropInIllustratedBook(effect.id);
            (comProp.getChildByName('locked') as Laya.Image).visible = !isUnLock;
            comProp.mouseEnabled = isUnLock;
            (comProp.getChildByName('favorite') as Laya.Sprite).visible = UI_Activity_Amulet.favoriteId == effect.id;
            (comProp.getChildByName('icon') as Laya.Image).visible = isUnLock;
            if (isUnLock) {
                game.LoadMgr.setImgSkin(comProp.getChildByName('icon') as Laya.Image, 'myres/amulet/effect/' + effect.card_image + '.png', null, 'UI_AmuletOverview');
                (comProp.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/fu_bg' + effect.rarity + '.png');
                (comProp.getChildByName('plus') as Laya.Image).visible = !!effect.card_remark;
            } else {
                (comProp.getChildByName('bg') as Laya.Image).skin = '';
                (comProp.getChildByName('locked').getChildAt(0) as Laya.Image).visible = !!effect.card_remark;
            }
            game.Tools.clearBtnClickHandler(comProp);
            comProp.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                uiscript.UI_AmuletProp.Inst.showPropDetail(amulet.PropCard.CreatePropOption(effect.id), EAmuletPropState.onlyRead);
            }, null, false);
        }

        private listBadgeRender(obj) {
            let comBadge: Laya.Button = obj.container.getChildByName('btn') as Laya.Button;
            comBadge.alpha = 1;
            comBadge.scale(1, 1);
            Laya.Tween.clearAll(comBadge);
            let index: number = obj.index;
            let badge: lqc.Sheet_Amulet_AmuletBadge = this.badgeConfigGroup[index];
            let isUnLock = UI_Activity_Amulet.isBadgeInIllustratedBook(badge.id);
            (comBadge.getChildByName('locked') as Laya.Image).visible = !isUnLock;
            comBadge.mouseEnabled = isUnLock;
            (comBadge.getChildByName('icon') as Laya.Image).visible = isUnLock;
            if (isUnLock) {
                (comBadge.getChildByName('icon') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/' + badge.badge_image + '.png')
            }
            game.Tools.clearBtnClickHandler(comBadge);
            comBadge.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.popupBadge.show(badge);
            }, null, false);
        }

        /** 最近的对局记录 */
        private listRecentRender(obj) {
            let comRecord: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let data: game.IActivityAmuletGameRecordData = UI_Activity_Amulet.recentRecords[index];
            let comRecent: UI_RecentItem = obj.cache_data['record'];
            if (!comRecent) {
                comRecent = new UI_RecentItem(comRecord);
                obj.cache_data['record'] = comRecent;
            }
            comRecent.refresh(index, data);
        }

        /** 个人战绩页 */
        private refreshAchieve() {
            const huData = UI_Activity_Amulet.statistic.highest_hu;
            let haveHuData = huData && huData.pai && huData.pai != '';
            let comPais = this.comAchieveContent.getChildAt(0) as Laya.Sprite;
            (comPais.getChildByName('title') as Laya.Image).width = (comPais.getChildByName('title').getChildByName('title') as Laya.Label).trueWidth + 26;
            let comHu = comPais.getChildByName('hu_content') as Laya.Sprite;
            let comRecord = this.comAchieveContent.getChildAt(1) as Laya.Sprite;
            (comRecord.getChildByName('title') as Laya.Image).width = (comRecord.getChildByName('title').getChildByName('title') as Laya.Label).trueWidth + 26;
            (comPais.getChildByName('label_noinfo') as Laya.Label).visible = !haveHuData;
            (comPais.getChildByName('label_noinfo') as Laya.Label).text = game.Tools.strOfLocalization(2273);
            comHu.visible = haveHuData;
            if (comHu.visible) {
                this.imgPointNumber.forEach(imgScore => imgScore.skin = '');
                let comBaseXFan = comHu.getChildByName('container_basexfan') as Laya.Sprite;
                let txtFan = comBaseXFan.getChildByName('fan_total') as Laya.Label;
                let txtBase = comBaseXFan.getChildByName('fu_total') as Laya.Label;
                let txtX = comBaseXFan.getChildByName('x') as Laya.Label;
                txtFan.text = SciNum.getSciStr(huData.fan, 6) + game.Tools.strOfLocalization(20021);
                txtFan.x = 0;
                txtX.x = txtFan.trueWidth + 12;
                txtBase.x = txtFan.trueWidth + 47;
                txtBase.text = SciNum.getSciStr(huData.base, 6) + game.Tools.strOfLocalization(20022);
                comBaseXFan.width = txtBase.x + txtBase.trueWidth;
                comBaseXFan.x = 585 - comBaseXFan.width / 2;
                let chars = SciNum.getSciImgStrs(huData.point || '0', 6);
                let lengthData = SciNum.getCharsLength(chars);
                let singleWidth = 66;
                let startX = 0;
                for (let i = 0; i < chars.length; i++) {
                    let url = game.Tools.localUISrc('myres/amulet/number/ww_' + chars[i] + '.png');
                    if (!this.imgPointNumber[i]) {
                        let imgScore = this.scoreTemplteUI.getNodeClone() as Laya.Image;
                        this.comPoint.addChild(imgScore);
                        this.imgPointNumber.push(imgScore);
                        imgScore.visible = true;
                    }
                    this.imgPointNumber[i].skin = url;
                    this.imgPointNumber[i].x = startX;
                    startX += singleWidth * lengthData.scales[i];
                }
                this.comPoint.width = lengthData.totalL * singleWidth;
                this.comPoint.x = 580 - (this.comPoint.width * 0.76 / 2);
                this.containerHand.visible = !!huData.pai;
                if (this.containerHand.visible) {
                    this.showPais(huData.pai);
                }
                let effects = huData.effect_builds || [];
                let width = 0;
                for (let i = 0; i < this.comRecordProps.length; i++) {
                    let item = this.comRecordProps[i];
                    if (effects[i]) {
                        let effect = effects[i];
                        item.visible = true;
                        item.x = width;
                        item.width = effect.volume * 160;
                        item.event('size_change');
                        width = width + item.width * item.scaleX + 2;
                        let effectConfig = cfg.amulet.amulet_effect.get(effect.id);
                        (item.getChildByName('plus') as Laya.Image).visible = !!effectConfig.card_remark;
                        game.LoadMgr.setImgSkin(item.getChildByName('icon') as Laya.Image, 'myres/amulet/effect/' + effectConfig.card_image + '.png', null, 'UI_AmuletOverview');
                        (item.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/fu_bg' + effectConfig.rarity + (effect.volume == 1 ? '' : '_widen') + '.png');
                        (item.getChildByName('badge') as Laya.Image).skin = effect.badge_id ? game.Tools.localUISrc('myres/amulet/card/badge_' + effect.badge_id + '.png') : '';
                    } else {
                        item.visible = false;
                    }
                }
                this.containerProp.x = 587 - width / 2;
            }
            let statisticDatas: { title: string, desc: string }[] = [];
            let statistic = { title: game.Tools.strOfLocalization(20056), desc: game.Tools.strOfLocalization(20060) };
            if (UI_Activity_Amulet.statistic.highest_level) {
                const nowLevelConfig = UI_Activity_Amulet.amuletLevelDic.get(UI_Activity_Amulet.statistic.highest_level);
                statistic.desc = nowLevelConfig.level_name;
            }
            statisticDatas.push(statistic);
            //最高关卡得分	
            statistic = { title: game.Tools.strOfLocalization(25081107), desc: game.Tools.strOfLocalization(20060) };
            if (UI_Activity_Amulet.statistic.highest_level_score) {
                statistic.desc = SciNum.getSciStr(UI_Activity_Amulet.statistic.highest_level_score, 6);
            }
            statisticDatas.push(statistic);
            //最高番数
            statistic = { title: game.Tools.strOfLocalization(25081108), desc: game.Tools.strOfLocalization(20060) };
            if (UI_Activity_Amulet.statistic.highest_fan) {
                statistic.desc = SciNum.getSciStr(UI_Activity_Amulet.statistic.highest_fan, 6);
            }
            statisticDatas.push(statistic);
            //最高分数
            statistic = { title: game.Tools.strOfLocalization(25081109), desc: game.Tools.strOfLocalization(20060) };
            if (UI_Activity_Amulet.statistic.highest_score) {
                statistic.desc = SciNum.getSciStr(UI_Activity_Amulet.statistic.highest_score, 6);
            }
            statisticDatas.push(statistic);
            // 通关次数
            statistic = { title: game.Tools.strOfLocalization(25081110), desc: '0' };
            if (UI_Activity_Amulet.statistic.pass_game_count) {
                statistic.desc = UI_Activity_Amulet.statistic.pass_game_count.toString();
            }
            statisticDatas.push(statistic);
            //完成关卡数
            statistic = { title: game.Tools.strOfLocalization(25081111), desc: '0' };
            if (UI_Activity_Amulet.statistic.round_count) {
                statistic.desc = UI_Activity_Amulet.statistic.round_count.toString();
            }
            statisticDatas.push(statistic);
            // 护身符收集
            statistic = { title: game.Tools.strOfLocalization(25081112), desc: '0/' + UI_AmuletOverview.Inst.effectCounts };
            if (UI_Activity_Amulet.amuletIllustratedBook && UI_Activity_Amulet.amuletIllustratedBook.effect_collection) {
                statistic.desc = UI_Activity_Amulet.amuletIllustratedBook.effect_collection.length + '/' + UI_AmuletOverview.Inst.effectCounts
            }
            statisticDatas.push(statistic);
            //印章收集
            statistic = { title: game.Tools.strOfLocalization(25081113), desc: '0/' + UI_AmuletOverview.Inst.badgeCounts };
            if (UI_Activity_Amulet.amuletIllustratedBook && UI_Activity_Amulet.amuletIllustratedBook.badge_collection) {
                statistic.desc = UI_Activity_Amulet.amuletIllustratedBook.badge_collection.length + '/' + UI_AmuletOverview.Inst.badgeCounts
            }
            statisticDatas.push(statistic);
            //最多开包数
            statistic = { title: game.Tools.strOfLocalization(25081114), desc: '0' };
            if (UI_Activity_Amulet.statistic.open_pack_count) {
                statistic.desc = UI_Activity_Amulet.statistic.open_pack_count.toString();
            }
            statisticDatas.push(statistic);
            //最多花费星币
            statistic = { title: game.Tools.strOfLocalization(25081115), desc: '0' };
            if (UI_Activity_Amulet.statistic.highest_coin_consumed) {
                statistic.desc = UI_Activity_Amulet.statistic.highest_coin_consumed.toString();
            }
            statisticDatas.push(statistic);
            for (let i = 0; i < statisticDatas.length; i++) {
                let com = this.comStatistics[i]
                if (!com) {
                    com = this.templeteStatistic.getNodeClone() as Laya.Sprite;
                    comRecord.addChild(com);
                    this.comStatistics.push(com);
                }
                com.x = i % 2 == 0 ? 23 : 620;
                com.y = 96 + Math.floor(i / 2) * 48;
                let txtTitle = com.getChildByName('title') as Laya.Label;
                let txtValue = com.getChildByName('value') as Laya.Label;
                txtTitle.text = statisticDatas[i].title;
                txtValue.x = txtTitle.x + txtTitle.textField.textWidth;
                txtValue.text = statisticDatas[i].desc;
                let width = txtValue.x + txtValue.trueWidth;
                let scale = 1;
                if (width > 550) scale = 550 / width;
                com.scale(scale, scale);
            }
            this.panelAchieve.vScrollBar.value = 0;
            this.panelAchieve.vScrollBar.stopScroll();
            this.achieveScrollBar.reset();
            this.achieveScrollBar.setVal(0, this.panelAchieve.height / this.comAchieveContent.height);
        }

        private showPais(pais: string) {
            let arrPais = pais.split(',');
            // let arrPais = ('1m2m3m4m5p5p5p7s7s7s8s8s8s4m').split(',');
            let arrHands = arrPais[0];
            let hands = [];
            for (let i = 0; i < arrHands.length + 2; i++) {
                if (arrHands[i] && arrHands[i + 1]) {
                    let pai = arrHands[i] + arrHands[i + 1];
                    hands.push(pai)
                } else {
                    break;
                }
                i++;
            }
            let hupai = hands[hands.length - 1];
            hands.pop();
            let ming = [];
            for (let i = 1; i < arrPais.length; i++) {
                let arrMings = arrPais[i];
                let _ming = '(';
                for (let j = 0; j < arrMings.length + 2; j++) {
                    if (arrMings[j] && arrMings[j + 1]) {
                        let pai = arrMings[j] + arrMings[j + 1];
                        _ming = _ming + (j == 0 ? '' : ',') + pai;
                    } else {
                        _ming = _ming + ')';
                        ming.push(_ming);
                        break;
                    }
                    j++;
                }
            }
            // app.Log.log('hands ====' + JSON.stringify(hands));
            // app.Log.log('ming ====' + JSON.stringify(ming));

            let width_pai: number = this.hands[0].me.width;
            let com_span: number = width_pai * 0.5;
            for (let i: number = 0; i < this.hands.length; i++) {
                this.hands[i].reset();
            }
            let current_index: number = 0;
            let current_x: number = 0;
            let _hand_pais: Array<mjcore.MJPai> = [];
            for (let i: number = 0; i < hands.length; i++) {
                _hand_pais.push(mjcore.MJPai.Create(hands[i]));
            }
            _hand_pais = _hand_pais.sort((a, b) => {
                let va: number = a.numValue() * 10 + (a.dora ? 0 : 1);
                let vb: number = b.numValue() * 10 + (b.dora ? 0 : 1);
                return va - vb;
            });
            for (let i: number = 0; i < _hand_pais.length; i++) {
                this.hands[current_index].show(_hand_pais[i].toString(false));
                this.hands[current_index].pos(current_x, 0);
                current_x += width_pai;
                current_index++;
            }
            current_x += com_span;
            //副露
            if (ming && ming.length > 0) {
                for (let i: number = 0; i < ming.length; i++) {
                    let str_ming: string = ming[i];
                    //新版ming的记录angang(5p,0p,0p,5p)这种
                    let s_category: string = '';
                    let _m: Array<string> = [];
                    for (let i: number = 0; i < str_ming.length; i++) {
                        if (str_ming.charAt(i) == '(') {
                            s_category = str_ming.substring(0, i);
                            _m = str_ming.substring(i + 1, str_ming.length - 1).split(',');
                            break;
                        }
                    }

                    for (let j: number = 0; j < _m.length; j++) {
                        let skin: string = _m[j].replace('t', '');
                        this.hands[current_index].show(skin);
                        this.hands[current_index].pos(current_x, 0);
                        current_x += width_pai;
                        current_index++;
                    }
                    current_x += com_span;
                }
            }
            //胡的牌
            {
                this.hands[current_index].show(hupai.replace('t', ''));
                this.hands[current_index].pos(current_x, 0);
                current_x += width_pai;
                current_index++;
            }
            let scale: number = 1.01 / (current_x / 1120);
            this.containerHand.scaleX = this.containerHand.scaleY = scale;
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_AmuletOverview', false);
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_AmuletOverview', true);
        }

        public refreshPropFavorite() {
            this.scrollViewProp.wantToRefreshAll();
        }
    }
}