module uiscript {
    export enum EAmuletPropState {
        normal,
        shopSelect,
        freeSelect,
        onlyRead
    }
    export class UI_PropDetailPopup extends UIBase {
        public static opening: boolean = false;
        private father: UIBase;
        public locking: boolean;
        private selectedPackageId: number;
        private propData: amulet.PropCard;
        private panelDesc: Laya.Panel;
        private comDesc: Laya.Sprite;
        private txtDesc: Laya.HTMLDivElement;
        private btnConfirm: Laya.Button;

        constructor(me: Laya.Sprite, father: UIBase) {
            super(me);
            this.father = father;
            this.btnConfirm = this.me.getChildByName('btn_confirm') as Laya.Button;
            this.btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.selectedPackageId) {
                    const param: game.IReqAmuletActivityBuy = {
                        activity_id: amulet.AmuletDesktopMgr.activityId,
                        id: this.selectedPackageId
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.BuyFromShop, param);
                }
                if (this.propData) {
                    const param: game.IReqAmuletActivitySellEffect = {
                        activity_id: UI_Activity_Amulet.activityId,
                        id: this.propData.id
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SoldOutProp, param);
                    uiscript.UI_AmuletProp.Inst.onSmallPropClick(-1);
                }
                this.hide();
            }, null, false);
            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                this.hide();
                uiscript.UI_AmuletProp.Inst.onSmallPropClick(-1);
            }, null, false);
            (this.me.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                this.hide();
                uiscript.UI_AmuletProp.Inst.onSmallPropClick(-1);
            }, null, false);
            this.panelDesc = this.me.getChildByName('desc') as Laya.Panel;
            this.comDesc = this.panelDesc.getChildByName('desc') as Laya.Sprite;
            this.txtDesc = this.comDesc.getChildByName('prop_desc') as Laya.HTMLDivElement;
            if (GameMgr.client_language == 'jp') {
                this.txtDesc.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtDesc.style.font = '32px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtDesc.style.font = '32px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtDesc.style.font = '30px SimHei';
            } else {
                this.txtDesc.style.font = '30px NotoSansKR';
            }
            this.txtDesc.style.color = '#e7e9ec';
            this.txtDesc.style.leading = 6;
            this.txtDesc.style.letterSpacing = 0;
        }

        showPackage(goods: game.IAmuletGameShopGoods, pos: Laya.Vector2) {
            if (this.locking) return;
            if (this.enable && this.selectedPackageId == goods.id) return;
            UI_PropDetailPopup.opening = true;
            this.locking = true;
            UIBase.anim_pop_out(this.me, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.selectedPackageId = goods.id;
            this.enable = true;
            this.me.x = pos.x;
            this.me.y = pos.y;
            let packageConfig = cfg.amulet.amulet_goods.get(goods.goods_id);
            (this.me.getChildByName('prop_name') as Laya.Label).text = game.Tools.eventStrOfLocalization(packageConfig.pack_name);
            this.txtDesc.innerHTML = game.Tools.ParseText(game.Tools.eventStrOfLocalization(packageConfig.pack_desc), '#ffd133');
            this.comDesc.height = this.txtDesc.contextHeight;
            this.panelDesc.scrollTo(0, 0);
            this.panelDesc.refresh();
            let newPrice = goods.price;
            let nowPrice = Number(amulet.AmuletDesktopMgr.Inst.amuletGameData.game.coin);
            (this.me.getChildByName('price').getChildByName('price') as Laya.Label).text = newPrice.toString();
            this.btnConfirm.mouseEnabled = newPrice <= nowPrice;
            (this.btnConfirm.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc(newPrice <= nowPrice ? 'myres/amulet/button_5_yellow.png' : 'myres/amulet/button_5_grey.png');
            (this.btnConfirm.getChildByName('title') as Laya.Label).color = newPrice <= nowPrice ? '#442334' : '#525A6B';
        }

        showProp(prop: amulet.PropCard, pos: Laya.Vector2) {
            if (this.locking) return;
            if (this.enable && this.propData.id == prop.id) return;
            UI_PropDetailPopup.opening = true;
            this.locking = true;
            UIBase.anim_pop_out(this.me, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.propData = prop;
            this.enable = true;
            this.me.x = pos.x;
            this.me.y = pos.y;
            let propConfig = cfg.amulet.amulet_effect.get(prop.effectId);
            (this.me.getChildByName('prop_name') as Laya.Label).text = game.Tools.eventStrOfLocalization(propConfig.name, UI_PropDetailCard.getPropTitleArgs(propConfig, prop, EAmuletPropState.normal));
            let args = UI_PropDetailCard.getPropFinalArgs(propConfig, prop, EAmuletPropState.normal);
            let desc = game.Tools.eventStrOfLocalization(propConfig.desc, args);
            this.txtDesc.innerHTML = game.Tools.ParseText(desc, '#ffd133');
            this.comDesc.height = this.txtDesc.contextHeight;
            this.panelDesc.scrollTo(0, 0);
            this.panelDesc.refresh();
            (this.me.getChildByName('price').getChildByName('price') as Laya.Label).text = UI_PropDetailCard.getPropPrice(prop).toString();
        }

        showBossBuff(buff: game.IAmuletBuffData) {
            if (this.locking) return;
            UI_PropDetailPopup.opening = true;
            this.locking = true;
            UIBase.anim_pop_out(this.me, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.enable = true;
            let buffConfig = cfg.amulet.amulet_buff.get(buff.id);
            (this.me.getChildByName('prop_name') as Laya.Label).text = game.Tools.strOfLocalization(20083);
            let args = buffConfig.args.map(v => v.toString());
            args.forEach((arg, index) => {
                if (buff.store && buff.store[index] != null) {
                    arg = buff.store[index].toString();
                }
            })
            let desc = game.Tools.eventStrOfLocalization(buffConfig.desc, args);
            this.txtDesc.innerHTML = game.Tools.ParseText(desc, '#ffd133');
            this.comDesc.height = this.txtDesc.contextHeight;
            this.panelDesc.scrollTo(0, 0);
            this.panelDesc.refresh();
            (this.me.getChildByName('price') as Laya.Sprite).visible = false;
        }

        public hide() {
            if (this.locking) return;
            if (this.father['hideTag']) this.father['hideTag']();
            this.locking = true;
            this.selectedPackageId = 0;
            this.propData = null;
            UIBase.anim_pop_hide(this.me, Laya.Handler.create(this, () => {
                UI_PropDetailPopup.opening = false;
                this.enable = false;
                this.locking = false;
            }));
        }
    }

    export class UI_PropTags extends UIBase {
        private imgBg: Laya.Image;
        private comDesc: Laya.Sprite;
        private content: Laya.Panel;
        private templeteUI: capsui.UICopy;
        private comItems: Laya.Sprite[];
        public data: amulet.PropCard;
        private direct: string;

        onCreate() {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.content = this.imgBg.getChildByName('content') as Laya.Panel;
            this.comDesc = this.content.getChildByName('desc') as Laya.Sprite;
            let templete = this.comDesc.getChildByName('templete') as Laya.Sprite;
            this.templeteUI = templete.scriptMap['capsui.UICopy'] as capsui.UICopy;
            this.comItems = [templete];
        }

        show(prop: amulet.PropCard, type: EAmuletPropState, pos: Laya.Point, direct: string) {
            let datas: { title: string, desc: string }[] = [];
            if (prop.badge) {
                datas.push({
                    title: game.Tools.eventStrOfLocalization(prop.badgeConfig.badge_name), desc: game.Tools.eventStrOfLocalization(prop.badgeConfig.badge_desc, UI_PropDetailCard.getBadgeFinalArgs(prop))
                })
            }
            for (let i = 0; i < prop.config.tag_id.length; i++) {
                let tagConfig = prop.config.tag_id[i] ? cfg.amulet.amulet_tag.get(prop.config.tag_id[i]) : null;
                if (tagConfig) {
                    let tagArgs = UI_PropDetailCard.getTagArgs(prop.config.tag_id[i], type);
                    datas.push({
                        title: game.Tools.eventStrOfLocalization(tagConfig.tag_name), desc: game.Tools.eventStrOfLocalization(tagConfig.tag_desc, tagArgs)
                    })
                }
            }
            if (datas.length == 0) {
                if (this.enable) this.hide();
                return;
            }
            this.data = prop;
            this.direct = direct;
            this.enable = true;
            this.refreshPos(pos);
            this.comDesc.height = 0;
            for (let i = 0; i < datas.length; i++) {
                let item = this.comItems[i];
                if (!item) {
                    item = this.templeteUI.getNodeClone() as Laya.Sprite;
                    this.comDesc.addChild(item);
                    this.comItems.push(item);
                }
                item.visible = true;
                item.y = this.comDesc.height;
                let txtTitle = item.getChildByName('title') as Laya.Label;
                txtTitle.text = datas[i].title;
                let text = item.getChildByName('desc') as Laya.HTMLDivElement;
                if (GameMgr.client_language == 'jp') {
                    text.style.font = '26px NotoSansJapanese';
                } else if (GameMgr.client_language == 'chs') {
                    text.style.font = '28px HYWH';
                } else if (GameMgr.client_language == 'chs_t') {
                    text.style.font = '28px FZHT';
                } else if (GameMgr.client_language == 'en') {
                    text.style.font = '26px SimHei';
                } else {
                    text.style.font = '26px NotoSansKR';
                }
                text.style.color = '#e7e9ec';
                text.style.leading = 6;
                text.style.letterSpacing = 0;
                text.innerHTML = game.Tools.ParseText(datas[i].desc, '#7acdf3');
                item.height = text.contextHeight + 102;
                (item.getChildByName('split') as Laya.Image).y = text.contextHeight + 88;
                (item.getChildByName('split') as Laya.Image).visible = i < datas.length - 1;
                this.comDesc.height += i < datas.length - 1 ? item.height : item.height - 15;
            }
            if (this.comItems.length > datas.length) {
                for (let i = datas.length; i < this.comItems.length; i++) {
                    this.comItems[i].visible = false;
                }
            }
            this.content.height = this.comDesc.height > 726 ? 726 : this.comDesc.height;
            this.imgBg.height = this.content.height + 34;
            this.me.height = this.imgBg.height;
            this.content.scrollTo(0, 0);
            this.content.refresh();
            let moveX = direct == 'right' ? -50 : 50;
            Laya.Tween.clearAll(this.me);
            UIBase.anim_alpha_in(this.me, { x: moveX }, 150);
        }

        hide() {
            this.data = null;
            Laya.Tween.clearAll(this.me);
            UIBase.anim_alpha_out(this.me, {}, 100, 0, Laya.Handler.create(this, () => {
                this.enable = false;
            }));
        }

        refreshPos(pos: Laya.Point) {
            this.me.pivot(0, 0);
            this.me.pos(pos.x, pos.y);
        }

    }
    export class UI_PropDetailCard {
        private me: ui.amulet.amulet_propUI;
        public set enable(v: boolean) {
            this.me.visible = v;
        }
        public get enable(): boolean {
            return this.me.visible;
        }
        private father: UI_AmuletProp;
        private txtPropName: Laya.Label;
        private txtPropDesc: Laya.HTMLDivElement;
        private comDesc1: Laya.Sprite;
        private comDesc2: Laya.Sprite;
        private txtPropDesc2: Laya.HTMLDivElement;
        private comPrice: Laya.Sprite;
        private txtPriceTitle: Laya.Label;
        private txtPrice: Laya.Label;
        private btnSelect: Laya.Button;
        private btnSold: Laya.Button;
        private btnClose: Laya.Button;
        private btnFavorite: Laya.Button;
        private comFavorite: Laya.Sprite;
        private imgProp: Laya.Image;
        private imgPropBg: Laya.Image;
        private imgBadge: Laya.Image;
        private type: EAmuletPropState;
        private prop: amulet.PropCard;
        private tipPlus: Laya.Sprite;
        private tipUpgrade: Laya.Sprite;
        private imgSelected: Laya.Image;
        private isSelectGray: boolean;
        private alreadyHaveProp: game.IAmuletEffectData;
        private index: number;
        private baseEffectId: number;
        private locking: boolean;
        private canBeCombined: boolean = false;
        private isChangeBadge: boolean;
        private isUpgrade: boolean;
        private canRepeat: boolean;
        private badgePos: number[][] = [[74, 101], [66, 152], [364, 71], [375, 161]];
        private static effectsGroup: basic.Dictionary<number, number[]>;
        public static initEffectGroup() {
            this.effectsGroup = new basic.Dictionary();
            cfg.amulet.amulet_effect.forEach((effectConfig) => {
                if (effectConfig.effect_group) {
                    let arr = this.effectsGroup.get(effectConfig.effect_group) || [];
                    if (arr.indexOf(effectConfig.id) == -1) arr.push(effectConfig.id);
                    this.effectsGroup.set(effectConfig.effect_group, arr);
                }
            })
            // app.Log.log('this.effectsGroup ====' + JSON.stringify(this.effectsGroup));
        }
        public static canBeCombined(effectConfig: lqc.Sheet_Amulet_AmuletEffect, effects: game.IAmuletEffectData[]): boolean {
            let arr = this.effectsGroup.get(effectConfig.effect_group);
            if (!arr) return false;
            let count = 1;
            for (let i = 0; i < effects.length; i++) {
                if (arr.indexOf(effects[i].id) >= 0) count++;
            }
            return count == (arr.length / 2);
        }
        public static fanMap = [
            [140, 141, 100, 101, 1370, 1371, 1360, 1361, 1580, 1581, 1570, 1571, 1610, 1611,
                1680, 1681, 1560, 1561, 1550, 1551, 1480, 1481, 1420, 1421, 1290, 1291, 1450, 1451, 1250, 1251, 1380, 1381, 2090, 2091, 2140, 2141,
                2270, 2271, 2290, 2291, 2040, 2041
            ],
            [],
            []
        ]; //可能有多个参数，第几个参数需要/100就在第几个数组里加,下面这堆都是这样
        public static tianDoraMap = [
            [1400, 1401, 1510, 1511],
            [1160, 1161, 1580, 1581],
            []
        ]
        public static lockTileMap = [
            [1430, 1431],
            [],
            []
        ]

        public static getTianDoraTotal(type: EAmuletPropState): SciNum {
            let totalAdd = SciNum.createSciNum(1);
            if (type == EAmuletPropState.freeSelect || type == EAmuletPropState.onlyRead) return totalAdd;
            const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            for (let i = 0; i < effects.length; i++) {
                if (!effects[i].store) continue;
                if (effects[i].id == 2280 || effects[i].id == 2281 || effects[i].id == 2320 || effects[i].id == 2321) {
                    for (let j = 0; j < this.tianDoraMap.length; j++) {
                        if (effects[i].store[j + 1] && this.tianDoraMap[j].indexOf(Number(effects[i].store[0])) >= 0) {
                            totalAdd = totalAdd.add(SciNum.createSciNumByStr(effects[i].store[j + 1]));
                            break;
                        }
                    }
                } else {
                    for (let j = 0; j < this.tianDoraMap.length; j++) {
                        if (effects[i].store[j] && this.tianDoraMap[j].indexOf(effects[i].id) >= 0) {
                            totalAdd = totalAdd.add(SciNum.createSciNumByStr(effects[i].store[j]));
                            break;
                        }
                    }
                }
            }
            return totalAdd;
        }

        public static getLockTileTotal(type: EAmuletPropState): SciNum {
            let totalAdd = SciNum.createSciNum(1);
            if (type == EAmuletPropState.freeSelect || type == EAmuletPropState.onlyRead) return totalAdd;
            const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            for (let i = 0; i < effects.length; i++) {
                if (!effects[i].store) continue;
                if (effects[i].id == 2280 || effects[i].id == 2281 || effects[i].id == 2320 || effects[i].id == 2321) {
                    for (let j = 0; j < this.lockTileMap.length; j++) {
                        if (effects[i].store[j + 1] && this.lockTileMap[j].indexOf(Number(effects[i].store[0])) >= 0) {
                            totalAdd = totalAdd.add(SciNum.createSciNumByStr(effects[i].store[j + 1]));
                            break;
                        }
                    }
                } else {
                    for (let j = 0; j < this.lockTileMap.length; j++) {
                        if (effects[i].store[j] && this.lockTileMap[j].indexOf(effects[i].id) >= 0) {
                            totalAdd = totalAdd.add(SciNum.createSciNumByStr(effects[i].store[j]));
                            break;
                        }
                    }
                }
            }
            return totalAdd;
        }

        // --- 获取护身符的出售价格
        public static getPropPrice(prop: amulet.PropCard): number {
            let price = prop.config.sell_price;
            if (prop.badgeConfig && prop.badgeConfig.id == 600050) {
                price = price * prop.badgeConfig.args[0] / 100;
            }
            return price;
        }

        public static getTagArgs(tagId: number, type: EAmuletPropState): string[] {
            if (tagId == 25084001) return [this.getTianDoraTotal(type).toString()];
            if (tagId == 25084009) return [this.getLockTileTotal(type).toString()];
            return [];
        }

        // --- 获取印章的实际增益效果量
        public static getBadgeFinalArgs(prop: amulet.PropCard): string[] {
            let args = this.getBadgeArgs(prop);
            args = args.map((arg) => {
                if (!Number(arg)) return arg;
                if (Number(arg) != Infinity) {
                    if (Math.floor(Number(arg)).toString().length < SciNum.criticalMinValue) return arg;
                    arg = Math.floor(Number(arg)).toString();
                }
                return SciNum.getSciStr(arg, 6);
            });
            return args;
        }

        // --- 获取印章的实际增益效果量
        public static getBadgeArgs(prop: amulet.PropCard): string[] {
            if (prop.badge && prop.badge.id == 600010) { //x{0}番。关卡结束时，有{1}%概率印章消失。如果没有消失，则使番数效果x{2}，消失概率+{3}%
                let args = prop.badgeConfig.args.map((value, index) => {
                    if (prop.badge.store && prop.badge.store[index]) {
                        return prop.badge.store[index];
                    }
                    return value.toString();
                });
                // if (Number(args[0]) != Infinity) {
                //     return [(Number(args[0]) / 100).toString(), args[1].toString(), (Number(args[2]) / 100).toString(), args[3].toString()];
                // }
                return [SciNum.createSciNumByStr(args[0]).divide(SciNum.createSciNum(100)).toString(), args[1], (Number(args[2]) / 100).toString(), args[3].toString()];
            }
            return [];
        }

        // ----护身符标题的增益
        public static getPropTitleArgs(propConfig: lqc.Sheet_Amulet_AmuletEffect, prop: amulet.PropCard, type: EAmuletPropState): string[] {
            //除了直接点击卡面都用init_param_view
            let args = propConfig.init_param_view;
            // -- 先处理需要特判的值
            if (type != EAmuletPropState.onlyRead) { //只要不是图鉴

            }
            if (!prop.store || prop.store.length == 0) {
                return args.map((v, i) => {
                    if (this.fanMap[i] && this.fanMap[i].indexOf(prop.effectId) >= 0) return (v / 100).toString();
                    if (this.tianDoraMap[i] && this.tianDoraMap[i].indexOf(prop.effectId) >= 0) return this.getTianDoraTotal(type).toString();
                    if (this.lockTileMap[i] && this.lockTileMap[i].indexOf(prop.effectId) >= 0) return this.getLockTileTotal(type).toString();
                    return v.toString();
                })
            }
            if (propConfig.id == 2040 || propConfig.id == 2041) { //x1番。每当自摸红宝牌或关卡结束时，使本护身符升级（可无限升级）
                if (prop.store[0] == '0') return [(Number(args[0]) / 100).toString()];
                // if (Number(prop.store[0]) != Infinity && Number(prop.store[0]) * propConfig.args[1] != Infinity) {
                //     return [(Number(prop.store[0]) * propConfig.args[1] / 100).toString()];
                // }
                return [(SciNum.createSciNumByStr(prop.store[0]).multiply(SciNum.createSciNum(propConfig.args[1])).divide(SciNum.createSciNum(100))).toString()];
            }
            let storeArgs = prop.store.map(value => SciNum.createSciNumByStr(value));
            return storeArgs.map((v, i) => {
                if (this.fanMap[i] && this.fanMap[i].indexOf(prop.effectId) >= 0) {
                    // if (v.toNumber() != Infinity) {
                    //     return (v.toNumber() / 100).toString();
                    // }
                    return (v.divide(SciNum.createSciNum(100))).toString();
                }
                if (this.tianDoraMap[i] && this.tianDoraMap[i].indexOf(prop.effectId) >= 0) return this.getTianDoraTotal(type).toString();
                if (this.lockTileMap[i] && this.lockTileMap[i].indexOf(prop.effectId) >= 0) return this.getLockTileTotal(type).toString();
                return v.toString();
            });
        }

        public static getPropFinalArgs(propConfig: lqc.Sheet_Amulet_AmuletEffect, prop: amulet.PropCard, type: EAmuletPropState): string[] {
            let args = this.getPropArgs(propConfig, prop, type);
            args = args.map((arg) => {
                if (!Number(arg)) return arg;
                if (Number(arg) != Infinity) {
                    if (Math.floor(Number(arg)).toString().length < SciNum.criticalMinValue) return arg;
                    arg = Math.floor(Number(arg)).toString();
                }
                return SciNum.getSciStr(arg, 6);
            });
            return args;
        }
        // --- 获取护身符的实际增益效果量
        public static getPropArgs(propConfig: lqc.Sheet_Amulet_AmuletEffect, prop: amulet.PropCard, type: EAmuletPropState): string[] {
            //除了直接点击卡面都用init_param_view
            let args = propConfig.init_param_view;
            // -- 先处理需要特判的值
            const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            const coin = Number(amulet.AmuletDesktopMgr.Inst.amuletGameData.game.coin || '0');
            const total_consumed_coin = Number(amulet.AmuletDesktopMgr.Inst.amuletGameData.record.coin_consume || '0');
            const locked_tile_count = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.locked_tile_count || 0;
            const tian_dora = amulet.AmuletDesktopMgr.Inst.amuletGameData.round.tian_dora || [];
            const effect_counter = amulet.AmuletDesktopMgr.Inst.amuletGameData.record.effect_counter || [];
            if (type != EAmuletPropState.onlyRead) { //只要不是图鉴
                if (propConfig.id == 190 || propConfig.id == 191) {
                    let effectCount = effects.length;
                    let alreadyHave = false;
                    for (let i = 0; i < effects.length; i++) {
                        if (effects[i].id == 190 || effects[i].id == 191) {
                            alreadyHave = true;
                            break;
                        }
                    }
                    if (alreadyHave) {//已经在手上的拥有自己不扣分
                        effectCount = effects.length - 1 < 0 ? 0 : effects.length - 1;
                    }
                    let addScore = propConfig.args[0] + effectCount * propConfig.args[1];
                    if (addScore < 0) return ['0']; //不能倒扣分
                    return [addScore.toString()];
                } else if (propConfig.id == 220 || propConfig.id == 221) {
                    if (coin == 0) return ['0'];
                    return [Math.floor(coin / propConfig.args[0]).toString()];
                } else if (propConfig.id == 370) {
                    return [coin.toString()];
                } else if (propConfig.id == 371) {
                    return [Math.floor(coin * 1.2).toString()];
                } else if (propConfig.id == 110 || propConfig.id == 111) {
                    return [Math.floor(total_consumed_coin * (propConfig.args[0] / 100)).toString()];
                } else if (propConfig.id == 2010 || propConfig.id == 2011) { //+{0}分。效果量等同于本局游戏中魂牌种数的50倍。
                    return [(tian_dora.length * propConfig.args[0] / 100).toString()];
                } else if (propConfig.id == 2150 || propConfig.id == 2151) { //+{0}分。效果量等同于本局游戏中每次开包发现和获得本护身符次数的30倍
                    let count = 0;
                    for (let i = 0; i < effect_counter.length; i++) {
                        if (effect_counter[i].effect_id == 2150 || effect_counter[i].effect_id == 2151) {
                            count = count + Number(effect_counter[i].gain_count) + Number(effect_counter[i].pack_candidate_count);
                        }
                    }
                    return [(count * propConfig.args[1] / 100).toString()];
                }
            }
            if (!prop.store || prop.store.length == 0) {
                if (propConfig.id == 1240 || propConfig.id == 1241 || propConfig.id == 2211) { //关卡开始时，随机公开{花色}待摸牌4张。（每关会随机花色）
                    return [game.Tools.strOfLocalization(20406)];
                } else if (propConfig.id == 2200 || propConfig.id == 2201) { //每关一次。第{0}次和牌时，获得1张{1}品质随机护身符（要求次数和品质会逐渐提升！）
                    let rarityStrIds = [25081123, 25081122, 25081121, 25081120];
                    return [args[0].toString(), game.Tools.strOfLocalization(rarityStrIds[Number(args[1]) - 1])];
                } else if (propConfig.id == 2280 || propConfig.id == 2281) { //不稳定的护身符
                    return [game.Tools.strOfLocalization(25081125)];
                } else if (propConfig.id == 2320 || propConfig.id == 2321) { //星级黑客凌
                    return [game.Tools.strOfLocalization(25081125)];
                }
                return args.map((v, i) => {
                    if (this.fanMap[i] && this.fanMap[i].indexOf(prop.effectId) >= 0) return (v / 100).toString();
                    if (this.tianDoraMap[i] && this.tianDoraMap[i].indexOf(prop.effectId) >= 0) return this.getTianDoraTotal(type).toString();
                    if (this.lockTileMap[i] && this.lockTileMap[i].indexOf(prop.effectId) >= 0) return this.getLockTileTotal(type).toString();
                    return v.toString();
                })
            }
            let storeArgs = prop.store.map(value => SciNum.createSciNumByStr(value));
            if (propConfig.id == 1170 || propConfig.id == 1171 || propConfig.id == 1340 || propConfig.id == 1341) { //1170在你打出15张字牌后，使随机1种牌变为魂牌（还剩{0}张字牌）, 1340在你自摸13张索子牌后，成长为【通天藤蔓】（本护身符会无限出现，还剩{0}张索子）
                let count = type == EAmuletPropState.shopSelect ? Math.max(propConfig.args[0] - Number(prop.store[0]), 1) : propConfig.args[0] - Number(prop.store[0]);
                return [count.toString()];
            } else if (propConfig.id == 1240 || propConfig.id == 1241 || propConfig.id == 2211) { //关卡开始时，随机公开{花色}待摸牌4张。（每关会随机花色）
                if (prop.store[0] == '0') return [game.Tools.strOfLocalization(20407)];
                if (prop.store[0] == '1') return [game.Tools.strOfLocalization(20408)];
                if (prop.store[0] == '2') return [game.Tools.strOfLocalization(20409)];
                if (prop.store[0] == '3') return [game.Tools.strOfLocalization(20410)];
                return [game.Tools.strOfLocalization(20406)];
            } else if (propConfig.id == 1160 || propConfig.id == 1161) { //在你打出10张魂牌后，本护身符获得每张魂牌额外+1番的效果（还剩{0}张，当前每张魂牌{1}番）
                let count = type == EAmuletPropState.shopSelect ? Math.max(propConfig.args[0] - Number(prop.store[0]), 1) : propConfig.args[0] - Number(prop.store[0]);
                return [count.toString(), this.getTianDoraTotal(type).toString()];
            } else if (propConfig.id == 1250 || propConfig.id == 1251) { //	锁定3张待摸牌。每锁定6张牌后本护身符获得x1番（当前为x{0}番，还需锁定{1}张）
                let count = type == EAmuletPropState.shopSelect ? Math.max(propConfig.args[1] - Number(prop.store[1]), 1) : propConfig.args[1] - Number(prop.store[1]);
                // if (Number(prop.store[0]) != Infinity) {
                //     return [(Number(prop.store[0]) / 100).toString(), count.toString()];
                // }
                return [(storeArgs[0].divide(SciNum.createSciNum(100))).toString(), count.toString()];
            } else if (propConfig.id == 130 || propConfig.id == 131) { //+{0}番。效果量为本关已经和牌的次数+2。每关开始时重置
                return [(Number(prop.store[0]) + propConfig.args[0]).toString()];
            } else if (propConfig.id == 2040 || propConfig.id == 2041) { //x1番。每当自摸红宝牌或关卡结束时，使本护身符升级（可无限升级）
                if (prop.store[0] == '0') return [(Number(args[0]) / 100).toString()];
                // if (Number(prop.store[0]) != Infinity && Number(prop.store[0]) * propConfig.args[1] != Infinity) {
                //     return [(Number(prop.store[0]) * propConfig.args[1] / 100).toString()];
                // }
                return [(storeArgs[0].multiply(SciNum.createSciNum(propConfig.args[1])).divide(SciNum.createSciNum(100))).toString()];
            } else if (propConfig.id == 2200 || propConfig.id == 2201) { //每关一次。第{0}次和牌时，获得1张{1}品质随机护身符（要求次数和品质会逐渐提升！）
                let rarityStrIds = [25081123, 25081122, 25081121, 25081120];
                return [prop.store[0], game.Tools.strOfLocalization(rarityStrIds[Number(prop.store[1]) - 1])];
            } else if (propConfig.id == 2280 || propConfig.id == 2281 || propConfig.id == 2320 || propConfig.id == 2321) { //不稳定的护身符
                if (type == EAmuletPropState.shopSelect) return [game.Tools.strOfLocalization(25081125)];
                let tempPropId = 0;
                let tempStore: string[] = []
                for (let i = 0; i < prop.store.length; i++) {
                    if (i == 0) {
                        tempPropId = Number(prop.store[i]);
                    } else if (i < 10) {
                        tempStore.push(prop.store[i]);
                    }
                }
                if (tempPropId && cfg.amulet.amulet_effect.get(tempPropId)) {
                    let templeteProp = amulet.PropCard.CreatePropOption(tempPropId, null, tempStore);
                    let tempArgs = UI_PropDetailCard.getPropFinalArgs(templeteProp.config, templeteProp, type);
                    let tempDesc = game.Tools.eventStrOfLocalization(templeteProp.config.desc, tempArgs);
                    tempDesc = tempDesc.replace(/\[tag\]/g, '')
                    tempDesc = tempDesc.replace(/\[\/tag\]/g, '');
                    return [tempDesc];
                } else {
                    return [game.Tools.strOfLocalization(25081125)];
                }
            } else if (propConfig.id == 2070 || propConfig.id == 2071) { // 星币数量超过20时，超过部分改由本护身符存储。+{0}分。效果量等同于存储星币数量的10倍。（当前已存储{1}星币，出售时全额返还）
                return [(storeArgs[0].multiply(SciNum.createSciNum(Math.floor(propConfig.args[2] / 100)))).toString(), prop.store[0]];
            }
            return storeArgs.map((v, i) => {
                if (this.fanMap[i] && this.fanMap[i].indexOf(prop.effectId) >= 0) {
                    // if (v.toNumber() != Infinity) {
                    //     return (v.toNumber() / 100).toString();
                    // }
                    return (v.divide(SciNum.createSciNum(100))).toString();
                }
                if (this.tianDoraMap[i] && this.tianDoraMap[i].indexOf(prop.effectId) >= 0) return this.getTianDoraTotal(type).toString();
                if (this.lockTileMap[i] && this.lockTileMap[i].indexOf(prop.effectId) >= 0) return this.getLockTileTotal(type).toString();
                return v.toString();
            });
        }

        public static getPropUpgradeIdByPropId(propId: number) {
            let effectConfig = cfg.amulet.amulet_effect.get(propId);
            if (effectConfig && effectConfig.upgrade) {
                return effectConfig.upgrade;
            }
            return 0;
        }

        constructor(me: Laya.Sprite, father: UI_AmuletProp, index: number) {
            this.me = me as ui.amulet.amulet_propUI;
            this.father = father;
            this.index = index;
            this.txtPropName = this.me.getChildByName('name') as Laya.Label;
            this.comDesc1 = this.me.getChildByName('desc').getChildByName('desc1') as Laya.Sprite;
            this.txtPropDesc = this.comDesc1.getChildByName('desc') as Laya.HTMLDivElement;
            this.comDesc2 = this.me.getChildByName('desc').getChildByName('desc2') as Laya.Sprite;
            this.txtPropDesc2 = this.comDesc2.getChildByName('desc') as Laya.HTMLDivElement;
            this.comPrice = this.me.getChildByName('price') as Laya.Sprite;
            this.txtPrice = this.comPrice.getChildByName('price') as Laya.Label;
            this.txtPriceTitle = this.comPrice.getChildByName('title') as Laya.Label;
            this.btnSelect = this.me.getChildByName('confirm') as Laya.Button;
            this.btnFavorite = this.me.getChildByName('select_favorite') as Laya.Button;
            this.comFavorite = this.me.getChildByName('favorite') as Laya.Button;
            this.btnSold = this.me.getChildByName('btn_sold') as Laya.Button;
            this.btnClose = this.me.getChildByName('btn_close') as Laya.Button;
            this.imgProp = this.me.getChildByName('icon') as Laya.Image;
            this.imgPropBg = this.me.getChildByName('bg') as Laya.Image;
            this.imgBadge = this.me.getChildByName('badge') as Laya.Image;
            this.tipPlus = this.me.getChildByName('plus') as Laya.Image;
            this.tipUpgrade = this.me.getChildByName('upgrade') as Laya.Image;
            this.imgSelected = this.me.getChildByName('selected') as Laya.Image;
            this.btnSold.clickHandler = new Laya.Handler(this, () => {
                if (this.locking || this.father.locking) return;
                const param: game.IReqAmuletActivitySellEffect = {
                    activity_id: UI_Activity_Amulet.activityId,
                    id: this.prop.id
                }
                this.father.hide(-1, true);
                amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SoldOutProp, param);
            }, null, false);
            this.btnSelect.clickHandler = new Laya.Handler(this, () => {
                if (this.locking || this.father.locking) return;
                if (this.isSelectGray) {
                    uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20081));
                    return;
                }
                this.father.selectedIndex = index;
                if (amulet.AmuletDesktopMgr.Inst.amuletGameData.stage == 1) {
                    const param: game.IReqAmuletActivitySelectFreeEffect = {
                        activity_id: UI_Activity_Amulet.activityId,
                        selected_id: this.prop.effectId
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SelectFreeProp, param);
                } else if (amulet.AmuletDesktopMgr.Inst.amuletGameData.stage == 7) {
                    let id = this.baseEffectId;
                    const param: game.IReqAmuletActivitySelectRewardPack = {
                        activity_id: UI_Activity_Amulet.activityId,
                        id: id
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SelectRewardPack, param);
                } else {
                    let id = this.baseEffectId;
                    const param: game.IReqAmuletActivitySelectPack = {
                        activity_id: UI_Activity_Amulet.activityId,
                        id: id
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SelectPack, param);
                }
            }, null, false);
            this.btnClose.clickHandler = new Laya.Handler(this, () => {
                if (this.locking || this.father.locking) return;
                this.father.hide();
            }, null, false);
            this.btnFavorite.clickHandler = new Laya.Handler(this, () => {
                if (this.locking || this.father.locking) return;
                let isUsed = this.prop.effectId == UI_Activity_Amulet.favoriteId;
                let targetId = isUsed ? 0 : this.prop.effectId;
                UI_Activity_Amulet.setFavorite(targetId);
                this.father.hide();
            }, null, false);
            if (GameMgr.client_language == 'jp') {
                this.txtPropDesc.style.font = '30px NotoSansJapanese';
                this.txtPropDesc2.style.font = '30px NotoSansJapanese';
            } else if (GameMgr.client_language == 'chs') {
                this.txtPropDesc.style.font = '32px HYWH';
                this.txtPropDesc2.style.font = '32px HYWH';
            } else if (GameMgr.client_language == 'chs_t') {
                this.txtPropDesc.style.font = '32px FZHT';
                this.txtPropDesc2.style.font = '32px FZHT';
            } else if (GameMgr.client_language == 'en') {
                this.txtPropDesc.style.font = '30px SimHei';
                this.txtPropDesc2.style.font = '30px SimHei';
            } else {
                this.txtPropDesc.style.font = '30px NotoSansKR';
                this.txtPropDesc2.style.font = '30px NotoSansKR';
            }
            this.txtPropDesc.style.color = '#e7e9ec';
            this.txtPropDesc.style.leading = 6;
            this.txtPropDesc.style.letterSpacing = 0;
            this.txtPropDesc2.style.color = '#e7e9ec';
            this.txtPropDesc2.style.leading = 6;
            this.txtPropDesc2.style.letterSpacing = 0;
            this.txtPropName.color = '#ffe09d';
            if (GameMgr.client_language == 'kr') {
                this.txtPrice.y += 5;
            } else if (GameMgr.client_language == 'en') {
                this.txtPrice.y += 3;
            }
            (this.comDesc2.getChildAt(1) as Laya.Image).height = 389 - (this.comDesc2.getChildAt(0) as Laya.Label).trueWidth;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.type == EAmuletPropState.normal || this.type == EAmuletPropState.onlyRead) return;
                if (this.father.locking) return;
                if (this.locking) return;
                if (this.imgSelected.visible) {
                    this.hideTag();
                    return;
                }
                this.showTag();
                this.imgSelected.visible = true;
            }, null, false);
            (this.me.getChildByName('desc') as Laya.Panel).on(Laya.Event.MOUSE_DOWN, this, () => {
                if (this.type == EAmuletPropState.normal || this.type == EAmuletPropState.onlyRead) return;
                if (this.father.locking) return;
                if (this.locking) return;
                if (this.imgSelected.visible) {
                    this.hideTag();
                    return;
                }
                this.showTag();
                this.imgSelected.visible = true;
            });
        }

        private showTag() {
            let _pos: Laya.Point = UIMgr.Inst.getScenePosition(this.me, new Laya.Point(-this.me.pivotX, -this.me.pivotY));
            let pos = new Laya.Point(_pos.x + this.me.width - 8, _pos.y + 20);
            let direct = 'right';
            if (pos.x + 468 > 1920) {
                pos.x = _pos.x - 438;
                direct = 'left';
            }
            this.father.showTag(this.prop, this.type, pos, direct);
        }

        private hideTag() {
            Laya.timer.clear(this, this.showTag);
            this.father.hideTag();
        }

        public doAnimShow() {
            this.me.show.stop();
            this.me.show.play(0, false);
        }

        public refresh(prop: amulet.PropCard, alreadyHaveProp: game.IAmuletEffectData, type: EAmuletPropState, baseEffectId?: number) {
            this.type = type;
            this.baseEffectId = baseEffectId;
            this.enable = true;
            this.alreadyHaveProp = alreadyHaveProp;
            this.prop = prop;
            const propConfig = prop.config;
            const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            this.canBeCombined = !!propConfig.effect_group && UI_PropDetailCard.canBeCombined(propConfig, effects);
            this.txtPropName.text = game.Tools.eventStrOfLocalization(propConfig.name, UI_PropDetailCard.getPropTitleArgs(propConfig, prop, type));
            //是升级护身符
            this.isUpgrade = false;
            //是替换印章
            this.isChangeBadge = false;
            //是可以重复获得的护身符
            this.canRepeat = false;
            if (alreadyHaveProp) {
                if (UI_PropDetailCard.getPropUpgradeIdByPropId(alreadyHaveProp.id) == prop.effectId) {
                    this.isUpgrade = true;
                } else if (!prop.config.duplicate_enabled) {
                    this.isChangeBadge = true;
                } else {
                    this.canRepeat = true;
                }
            }
            if (this.isChangeBadge) {
                let propConfig3 = cfg.amulet.amulet_effect.get(alreadyHaveProp.id);
                let prop3 = amulet.PropCard.CreateProp(alreadyHaveProp);
                let args3 = UI_PropDetailCard.getPropFinalArgs(propConfig3, prop3, EAmuletPropState.shopSelect)
                let txt3 = game.Tools.eventStrOfLocalization(propConfig3.desc, args3);
                this.txtPropDesc.innerHTML = game.Tools.ParseText(txt3, '#ffd133');
            } else {
                let args = UI_PropDetailCard.getPropFinalArgs(propConfig, prop, type)
                let txt = game.Tools.eventStrOfLocalization(propConfig.desc, args);
                this.txtPropDesc.innerHTML = game.Tools.ParseText(txt, '#ffd133');
            }
            let height = this.txtPropDesc.contextHeight;
            this.comDesc1.height = height + 1;

            if (this.isUpgrade) {
                this.comDesc2.visible = true;
                //只有buySelect状态才显示旧卡属性
                this.comDesc2.y = height;
                const propConfig2 = cfg.amulet.amulet_effect.get(alreadyHaveProp.id);
                let prop2 = amulet.PropCard.CreateProp(alreadyHaveProp);
                let args2 = UI_PropDetailCard.getPropFinalArgs(propConfig2, prop2, EAmuletPropState.shopSelect)
                let txt2 = game.Tools.eventStrOfLocalization(propConfig2.desc, args2);
                this.txtPropDesc2.innerHTML = game.Tools.ParseText(txt2, '#ffd133');
                this.comDesc2.height = this.txtPropDesc2.contextHeight + 49;
            } else {
                this.comDesc2.visible = false;
                this.comDesc2.y = 0;
                this.comDesc2.height = 100;
            }
            let panel = this.me.getChildByName('desc') as Laya.Panel;
            panel.refresh();
            panel.vScrollBar.value = 0;
            game.LoadMgr.setImgSkin(this.imgProp, 'myres/amulet/effect/' + propConfig.card_image + '.png', null, 'UI_AmuletProp');
            this.imgPropBg.skin = game.Tools.localUISrc('myres/amulet/pop_ups_amuctional_description_' + propConfig.rarity + '.png');
            this.imgBadge.skin = '';
            if (this.prop.badgeConfig) {
                let random = prop.badge.random ? Math.floor(prop.badge.random / 100000 * 4) : Math.floor(Math.random() * 4);
                this.imgBadge.pos(this.badgePos[random][0] + 64, this.badgePos[random][1] + 64);
                this.imgBadge.skin = game.Tools.localUISrc('myres/amulet/card/' + this.prop.badgeConfig.badge_image + '.png');
            }
            this.txtPrice.text = UI_PropDetailCard.getPropPrice(prop).toString();
            this.btnFavorite.visible = this.type == EAmuletPropState.onlyRead && !!this.prop.config.book_enabled;
            let favorite = amulet.AmuletDesktopMgr.Inst.amuletGameData.game.book_effect_id || 0;
            this.comFavorite.visible = (this.type == EAmuletPropState.freeSelect && favorite == prop.effectId) || (this.type == EAmuletPropState.onlyRead && UI_Activity_Amulet.favoriteId == prop.effectId);
            this.btnSelect.visible = this.type == EAmuletPropState.freeSelect || this.type == EAmuletPropState.shopSelect;
            this.btnClose.visible = this.type == EAmuletPropState.normal || this.type == EAmuletPropState.onlyRead;
            this.btnSold.visible = this.type == EAmuletPropState.normal && (UI_AmuletDesktopInfo.Inst.desktopStage == amulet.EAmuletGameState.DuringShop || UI_AmuletDesktopInfo.Inst.desktopStage == amulet.EAmuletGameState.OpenRewardPackage);
            this.comPrice.x = (this.type == EAmuletPropState.onlyRead && !this.btnFavorite.visible) || (this.type == EAmuletPropState.normal && !this.btnSold.visible) ? 174 : 48;
            this.tipUpgrade.visible = this.isUpgrade || this.isChangeBadge || this.canRepeat;
            this.tipPlus.visible = prop.isPlus && !this.tipUpgrade.visible;
            (this.tipUpgrade.getChildAt(1) as Laya.Label).text = this.isUpgrade ? game.Tools.strOfLocalization('20061') : this.isChangeBadge ? game.Tools.strOfLocalization(25081119) : game.Tools.strOfLocalization(25081124);
            (this.tipUpgrade.getChildAt(0) as Laya.Image).width = (this.tipUpgrade.getChildAt(1) as Laya.Label).trueWidth + 66;
            this.refreshGrayDisable();
            this.imgSelected.visible = false;
            if (type == EAmuletPropState.normal || type == EAmuletPropState.onlyRead) {
                Laya.timer.once(200, this, this.showTag);
            }
        }

        public refreshGrayDisable() {
            this.isSelectGray = false;
            if (this.btnSelect.visible) {
                this.isSelectGray = false;
                if (this.alreadyHaveProp && !this.canRepeat) {
                    //如果是替换已有卡也要判断放不放得下
                    let oldBadgeVolume = 0;
                    if (this.alreadyHaveProp.badge) {
                        oldBadgeVolume = cfg.amulet.amulet_badge.get(this.alreadyHaveProp.badge.id).volume;
                    }
                    if (amulet.AmuletDesktopMgr.Inst.getNowPropVolume() >= amulet.AmuletDesktopMgr.Inst.maxPropVolume && this.prop.badgeConfig && this.prop.badgeConfig.volume > oldBadgeVolume) {
                        this.isSelectGray = true;
                    }
                } else if (this.canBeCombined) { //合并的不考虑
                } else {
                    if (amulet.AmuletDesktopMgr.Inst.getNowPropVolume() + this.prop.volume > amulet.AmuletDesktopMgr.Inst.maxPropVolume) this.isSelectGray = true;
                }
                (this.btnSelect.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc(!this.isSelectGray ? 'myres/amulet/button_5_yellow.png' : 'myres/amulet/button_5_grey.png');
                (this.btnSelect.getChildByName('title') as Laya.Label).color = !this.isSelectGray ? '#462632' : '#525A6B';
            }
            if (this.btnFavorite.visible) {
                let unlock = UI_Activity_Amulet.statistic.highest_level && UI_Activity_Amulet.statistic.highest_level > UI_Activity_Amulet.amuletActivityConfig.book_unlock_level;
                this.btnFavorite.mouseEnabled = unlock;
                let isUsed = this.prop.effectId == UI_Activity_Amulet.favoriteId;
                if (!unlock) {
                    (this.btnFavorite.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/button_5_grey.png');
                    (this.btnFavorite.getChildByName('title') as Laya.Label).color = '#525A6B';
                    (this.btnFavorite.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(25081103);
                } else if (isUsed) {
                    (this.btnFavorite.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/button_5_red.png');
                    (this.btnFavorite.getChildByName('title') as Laya.Label).color = '#ffeea9';
                    (this.btnFavorite.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(25081104);
                } else {
                    (this.btnFavorite.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/button_5_yellow.png');
                    (this.btnFavorite.getChildByName('title') as Laya.Label).color = '#462632';
                    (this.btnFavorite.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(25081103);
                }
            }
        }

        setSelected(v: boolean) {
            this.imgSelected.visible = v;
        }

        hide(isSelected: boolean = false) {
            if (!this.enable) return;
            this.hideTag();
            this.me.show.stop();
            if (this.index != -1) {
                this.locking = true;
                if (isSelected) {
                    Laya.Tween.to(this.me, { y: -384 }, 250, Laya.Ease.quadIn, Laya.Handler.create(this, () => {
                        this.locking = false;
                        this.enable = false;
                    }), 167);
                } else {
                    Laya.Tween.to(this.me, { scale: 0.9, alpha: 0 }, 250, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                        this.locking = false;
                        this.enable = false;
                        this.me.scale(1, 1);
                    }), 0);
                }
            }
        }
    }
    /**
    * 青云护身符大卡
    */
    export class UI_AmuletProp extends UIBase {
        public static Inst: UI_AmuletProp;
        private comSelectProp: Laya.Sprite;
        private propsSelect: UI_PropDetailCard[];

        private comBuyProp: Laya.Sprite;
        private propSold: UI_PropDetailPopup;
        private propsSmall: Laya.Sprite[];
        private propsBuy: UI_PropDetailCard[];
        private txtPropCount: Laya.Label;
        private txtCurrency: Laya.Label;
        private btnSkip: Laya.Button;

        private comTag: UI_PropTags;

        private aniShowFree: Laya.FrameAnimation;
        private aniShowInShop: Laya.FrameAnimation;
        private aniHideFree: Laya.FrameAnimation;
        private aniHideInShop: Laya.FrameAnimation;
        private aniHideSingle: Laya.FrameAnimation;
        private aniSellSingle: Laya.FrameAnimation;
        private aniShowSingle: Laya.FrameAnimation;

        private comPropDetail: Laya.Sprite;
        private comFavoriteLock: Laya.Sprite;
        private propDetail: UI_PropDetailCard;
        private _isOpen: boolean;

        public smallPropDatas: amulet.PropCard[];
        public locking: boolean;
        public selectedIndex: number = -1;

        public get isOpen(): boolean {
            return this._isOpen;
        }

        public set isOpen(isOpen: boolean) {
            this._isOpen = isOpen;
            game.TempImageMgr.setUIEnable('UI_AmuletProp', isOpen);
        }

        constructor() {
            super(new ui.amulet.amulet_propsUI());
            UI_AmuletProp.Inst = this;
        }

        public onCreate(): void {
            this.comSelectProp = this.me.getChildByName('select_prop') as Laya.Sprite;
            this.comSelectProp.visible = false;
            this.propsSelect = [];
            for (let i = 1; i <= 3; i++) {
                this.propsSelect.push(new UI_PropDetailCard(this.comSelectProp.getChildByName('select_prop' + i) as Laya.Sprite, this, (i - 1)));
            }

            this.comBuyProp = this.me.getChildByName('delete_prop') as Laya.Sprite;
            this.comBuyProp.visible = false;
            this.propSold = new UI_PropDetailPopup(this.comBuyProp.getChildByName('package_detail') as Laya.Sprite, this);
            this.propsSmall = [];
            let comSmallProps = this.comBuyProp.getChildByName('small_prop') as Laya.Sprite;
            for (let i = 0; i < 9; i++) {
                let propSmall = comSmallProps.getChildAt(i) as Laya.Sprite;
                (propSmall.getChildByName('plus') as Laya.Image).visible = false;
                (propSmall.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    this.onSmallPropClick(i);
                }, null, false)
                this.propsSmall.push(propSmall);
            }
            this.propsBuy = [];
            for (let i = 1; i <= 3; i++) {
                this.propsBuy.push(new UI_PropDetailCard(this.comBuyProp.getChildByName('props').getChildByName('select_prop' + i) as Laya.Sprite, this, (i - 1)));
            }
            this.txtPropCount = comSmallProps.getChildByName('count') as Laya.Label;
            this.txtCurrency = this.comBuyProp.getChildByName('currency').getChildByName('count') as Laya.Label;
            this.btnSkip = this.comBuyProp.getChildByName('btn_skip') as Laya.Button;
            this.btnSkip.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                const param: game.IReqAmuletActivitySelectPack | game.IReqAmuletActivitySelectRewardPack = {
                    activity_id: UI_Activity_Amulet.activityId,
                    id: 0
                }
                this.selectedIndex = -1;
                if (amulet.AmuletDesktopMgr.Inst.amuletGameData.stage == 7) {
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SelectRewardPack, param);
                } else {
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.SelectPack, param);
                }
            }, null, false);


            this.comPropDetail = this.me.getChildByName('prop_detail') as Laya.Sprite;
            this.comFavoriteLock = this.comPropDetail.getChildByName('lock_favorite') as Laya.Sprite;
            this.comPropDetail.visible = false;
            this.propDetail = new UI_PropDetailCard(this.comPropDetail.getChildByName('prop') as Laya.Sprite, this, -1);
            (this.comPropDetail.getChildByName('btn_mask') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);

            this.comTag = new UI_PropTags(this.me.getChildByName('tag') as Laya.Sprite);
            this.comTag.enable = false;

            this.aniShowFree = (this.me as ui.amulet.amulet_propsUI).showFree;
            this.aniShowInShop = (this.me as ui.amulet.amulet_propsUI).showInShop;
            this.aniHideFree = (this.me as ui.amulet.amulet_propsUI).hideFree;
            this.aniHideInShop = (this.me as ui.amulet.amulet_propsUI).hideInShop;
            this.aniShowSingle = (this.me as ui.amulet.amulet_propsUI).cardShow;
            this.aniHideSingle = (this.me as ui.amulet.amulet_propsUI).cardHide;
            this.aniSellSingle = (this.me as ui.amulet.amulet_propsUI).cardSell;

            let btnEmpty = this.comBuyProp.getChildByName('props').getChildByName('empty') as Laya.Button;
            btnEmpty.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hideTag();
            }, null, false);
            (this.comSelectProp.getChildByName('btn_mask') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hideTag();
            }, null, false);
            (this.btnSkip.getChildByName('img') as Laya.Image).width = (this.btnSkip.getChildByName('title') as Laya.Label).trueWidth + 97;
            this.btnSkip.width = (this.btnSkip.getChildByName('title') as Laya.Label).trueWidth + 90;
            this.btnSkip.x = 1882 - this.btnSkip.width / 2;
        }

        get isBuyPopupVisible() {
            return this.comBuyProp.visible;
        }

        public showTag(prop: amulet.PropCard, type: EAmuletPropState, pos: Laya.Point, direct: string) {
            this.comTag.show(prop, type, pos, direct);
            this.propsBuy.forEach(prop => prop.setSelected(false));
            this.propsSelect.forEach(prop => prop.setSelected(false));
        }

        public hideTag() {
            this.comTag.hide();
            this.propsBuy.forEach(prop => prop.setSelected(false));
            this.propsSelect.forEach(prop => prop.setSelected(false));
        }

        onSmallPropClick(index: number) {
            if (!this.comBuyProp.visible) return;
            for (let i = 0; i < this.propsSmall.length; i++) {
                (this.propsSmall[i].getChildByName('selected') as Laya.Image).visible = index == i;
                if (index == i) {
                    let pos = new Laya.Vector2(this.propsSmall[index].x + 368 - 86, this.propsSmall[index].y + 205 - 109);
                    this.propSold.showProp(this.smallPropDatas[index], pos);
                    let pos2 = new Laya.Point(pos.x + this.propSold.me.width / 2 + 14, pos.y + 2);
                    let direct = 'right';
                    if (pos2.x + 468 > 1920) {
                        pos2.x = pos.x - this.propSold.me.width / 2 - 456;
                        direct = 'left';
                    }
                    this.showTag(this.smallPropDatas[index], EAmuletPropState.normal, pos2, direct);
                }
            }
        }

        showSelectProp(propDatas: game.IAmuletEffectCandidate[]) {
            this.selectedIndex = -1;
            this.isOpen = true;
            view.AudioMgr.PlayAudio(10150);
            this.comSelectProp.visible = true;
            this.propsSelect.forEach((comProp, index) => {
                if (propDatas[index]) {
                    comProp.refresh(amulet.PropCard.CreatePropOption(propDatas[index].id, propDatas[index].badge_id), null, EAmuletPropState.freeSelect);
                    comProp.doAnimShow();
                }
            });
            this.aniShowFree.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShowFree.interval * this.aniShowFree.count, this, () => {
                this.locking = false;
            });
        }

        showBuyProps(propDatas: game.IAmuletEffectCandidate[]) {
            this.selectedIndex = -1;
            this.isOpen = true;
            this.comBuyProp.visible = true;
            (this.comBuyProp.getChildByName('props') as Laya.Sprite).x = propDatas.length == 3 ? 0 : propDatas.length == 2 ? 297 : 596;
            const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            this.propsBuy.forEach((comProp, index) => {
                if (!propDatas[index]) {
                    comProp.enable = false;
                    return;
                }
                let upgradeId = UI_PropDetailCard.getPropUpgradeIdByPropId(propDatas[index].id);
                let effectConfig = cfg.amulet.amulet_effect.get(propDatas[index].id);
                //是新卡
                let isNewOne = true;
                //先判断升级；完全不能升级在判断替换印章
                let alreadyHaveProp = effects.find(effect => {
                    if (upgradeId && UI_PropDetailCard.getPropUpgradeIdByPropId(effect.id) == upgradeId) {
                        isNewOne = false;
                        return true;
                    }
                    return false;
                });
                //判断是否能替换印章，卡有关系才能替换
                if (!alreadyHaveProp) {
                    alreadyHaveProp = effects.find(effect => {
                        if (upgradeId && effect.id == upgradeId) {
                            //可以重复获得的卡不允许替换印章
                            if (!effectConfig.duplicate_enabled) isNewOne = false;
                            return true;
                        }
                        return false;
                    });
                }
                let prop;
                if (isNewOne) {
                    prop = amulet.PropCard.CreatePropOption(propDatas[index].id, propDatas[index].badge_id, []);
                } else {
                    let store = alreadyHaveProp && alreadyHaveProp.store ? alreadyHaveProp.store : [];
                    prop = amulet.PropCard.CreatePropOption(upgradeId, propDatas[index].badge_id, store);
                }
                comProp.refresh(prop, alreadyHaveProp, EAmuletPropState.shopSelect, propDatas[index].id);
                comProp.doAnimShow();
            });
            this.propsSmall.forEach((smallProp) => { smallProp.visible = false; });
            this.smallPropDatas = [];
            this.refreshBuyPopup();
            this.aniShowInShop.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShowInShop.interval * this.aniShowInShop.count, this, () => {
                this.locking = false;
            });
        }

        refreshBuyPopup() {
            if (!this.comBuyProp.visible) return;
            const effectLists = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
            this.txtCurrency.text = amulet.AmuletDesktopMgr.Inst.amuletGameData.game.coin.toString();
            this.txtPropCount.text = amulet.AmuletDesktopMgr.Inst.getNowPropVolume() + '/' + amulet.AmuletDesktopMgr.Inst.maxPropVolume;
            const propDatas = amulet.AmuletDesktopMgr.Inst.amuletGameData.stage == 7 ? (amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.level_reward_candidates || []) :
                (amulet.AmuletDesktopMgr.Inst.amuletGameData.shop.candidate_effect_list || []);
            this.propsBuy.forEach((comProp, index) => {
                if (!propDatas[index]) {
                    comProp.enable = false;
                    return;
                }
                let upgradeId = UI_PropDetailCard.getPropUpgradeIdByPropId(propDatas[index].id);
                let effectConfig = cfg.amulet.amulet_effect.get(propDatas[index].id);
                let isNewOne = true;
                let alreadyHaveProp = effectLists.find(effect => {
                    if (upgradeId && UI_PropDetailCard.getPropUpgradeIdByPropId(effect.id) == upgradeId) {
                        isNewOne = false;
                        return true;
                    }
                    return false;
                });
                if (!alreadyHaveProp) {
                    alreadyHaveProp = effectLists.find(effect => {
                        if (upgradeId && effect.id == upgradeId) {
                            if (!effectConfig.duplicate_enabled) isNewOne = false;
                            return true;
                        }
                        return false;
                    });
                }
                let prop;
                if (isNewOne) {
                    prop = amulet.PropCard.CreatePropOption(propDatas[index].id, propDatas[index].badge_id, []);
                } else {
                    let store = alreadyHaveProp && alreadyHaveProp.store ? alreadyHaveProp.store : [];
                    prop = amulet.PropCard.CreatePropOption(upgradeId, propDatas[index].badge_id, store);
                }
                comProp.refresh(prop, alreadyHaveProp, EAmuletPropState.shopSelect, propDatas[index].id);
            });
            if (this.smallPropDatas.length == 0) {
                let delay = 0;
                let posX = 26;
                this.propsSmall.forEach((smallProp, index) => {
                    if (effectLists[index]) {
                        this.smallPropDatas.push(amulet.PropCard.CreateProp(effectLists[index]));
                        const propConfig = cfg.amulet.amulet_effect.get(effectLists[index].id);
                        (smallProp.getChildByName('plus') as Laya.Image).visible = !!propConfig.card_remark;
                        game.LoadMgr.setImgSkin(smallProp.getChildByName('icon') as Laya.Image, 'myres/amulet/effect/' + propConfig.card_image + '.png', null, 'UI_AmuletProp');
                        (smallProp.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/fu_bg' + propConfig.rarity + (effectLists[index].volume == 1 ? '' : '_widen') + '.png');
                        (smallProp.getChildByName('selected') as Laya.Image).visible = false;
                        (smallProp.getChildByName('badge') as Laya.Image).visible = !!effectLists[index].badge;
                        if (effectLists[index].badge) {
                            (smallProp.getChildByName('badge') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/badge_' + effectLists[index].badge.id + '.png');
                        }
                        smallProp.width = effectLists[index].volume * 120;
                        smallProp.pivotX = smallProp.width / 2;
                        smallProp.event('size_change');
                        let targetX = posX + smallProp.width / 2;
                        smallProp.visible = true;
                        smallProp.alpha = 0;
                        smallProp.scale(1, 1);
                        smallProp.x = targetX + 140; //从后面滑进来
                        Laya.Tween.to(smallProp, { x: targetX }, 167, Laya.Ease.quadOut, null, delay);
                        Laya.Tween.to(smallProp, { alpha: 1 }, 84, Laya.Ease.quadInOut, null, delay);
                        delay += 34;
                        posX = posX + smallProp.width + 21;
                    } else {
                        smallProp.visible = false;
                    }
                });
            } else {
                let effectIds = effectLists.map((value) => { return value.uid });
                let deleteIndex = -1;
                for (let index = 0; index < this.propsSmall.length; index++) {
                    let smallProp = this.propsSmall[index];
                    if (smallProp.visible) {
                        if (effectIds.indexOf(this.smallPropDatas[index].id) == -1) {
                            deleteIndex = index;
                            smallProp.visible = false;
                        }
                    }
                }
                this.smallPropDatas = [];
                let delay = 0;
                let posX = 26;
                this.propsSmall.forEach((smallProp, index) => {
                    if (effectLists[index]) {
                        this.smallPropDatas.push(amulet.PropCard.CreateProp(effectLists[index]));
                        const propConfig = cfg.amulet.amulet_effect.get(effectLists[index].id);
                        (smallProp.getChildByName('plus') as Laya.Image).visible = !!propConfig.card_remark;
                        game.LoadMgr.setImgSkin(smallProp.getChildByName('icon') as Laya.Image, 'myres/amulet/effect/' + propConfig.card_image + '.png', null, 'UI_AmuletProp');
                        (smallProp.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/fu_bg' + propConfig.rarity + (effectLists[index].volume == 1 ? '' : '_widen') + '.png');
                        (smallProp.getChildByName('selected') as Laya.Image).visible = false;
                        (smallProp.getChildByName('badge') as Laya.Image).visible = !!effectLists[index].badge;
                        if (effectLists[index].badge) {
                            (smallProp.getChildByName('badge') as Laya.Image).skin = game.Tools.localUISrc('myres/amulet/card/badge_' + effectLists[index].badge.id + '.png');
                        }
                        smallProp.visible = true;
                        smallProp.width = effectLists[index].volume * 120;
                        smallProp.pivotX = smallProp.width / 2;
                        smallProp.event('size_change');
                        if (index >= deleteIndex) {
                            let targetX = posX + smallProp.width / 2;
                            smallProp.x = targetX + 140; //从后面滑进来
                            Laya.Tween.to(smallProp, { x: targetX }, 167, Laya.Ease.quadOut, null, delay);
                            delay += 34;
                        }
                        posX = posX + smallProp.width + 21;
                    } else {
                        smallProp.visible = false;
                    }
                });
            }

        }

        showPropDetail(prop: amulet.PropCard, type: EAmuletPropState) {
            // app.Log.log('show prop ====' + JSON.stringify(prop));
            if (this.locking) return;
            this.isOpen = true;
            this.locking = true;
            this.comPropDetail.visible = true;
            if (type == EAmuletPropState.normal) {
                //看详情时展示最新的护身符数据
                const effects = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.effect_list || [];
                for (let i = 0; i < effects.length; i++) {
                    if (effects[i].uid == prop.id) {
                        prop = amulet.PropCard.CreateProp(effects[i]);
                        break;
                    }
                }
            }
            let highest_level = UI_Activity_Amulet.statistic.highest_level || 0;
            this.comFavoriteLock.visible = type == EAmuletPropState.onlyRead && highest_level <= UI_Activity_Amulet.amuletActivityConfig.book_unlock_level
            && !!prop.config.book_enabled;
            let levelName = UI_Activity_Amulet.amuletLevelDic.get(UI_Activity_Amulet.amuletActivityConfig.book_unlock_level).level_name;
            (this.comFavoriteLock.getChildByName('tip') as Laya.Label).text = game.Tools.strOfLocalization(25081118, [levelName]);
            this.propDetail.refresh(prop, null, type);
            this.propDetail.doAnimShow();
            this.aniShowSingle.play(0, false);
            Laya.timer.once(this.aniShowSingle.interval * this.aniShowSingle.count, this, () => {
                this.locking = false;
            });
        }

        afterSelectPackage() {
            if (this.selectedIndex >= 0) {
                view.AudioMgr.PlayAudio(10158);
            }
            if (UI_AmuletShop.Inst.enable) UI_AmuletShop.Inst.refreshCurrency();
            this.hide(this.selectedIndex);
        }

        hide(selectedIndex: number = -1, isSell: boolean = false) {
            this.hideTag();
            if (this.comPropDetail.visible) {
                this.locking = true;
                let ani = isSell ? this.aniSellSingle : this.aniHideSingle;
                ani.play(0, false);
                Laya.timer.once(ani.interval * ani.count, this, () => {
                    this.locking = false;
                    this.comPropDetail.visible = false;
                    this.isOpen = false;
                });
            }
            if (this.comSelectProp.visible) {
                this.locking = true;
                this.aniHideFree.play(0, false);
                Laya.timer.once(668, this, () => {
                    this.locking = false;
                    this.comSelectProp.visible = false;
                    this.isOpen = false;
                });
                this.propsSelect.forEach((prop, index) => { prop.hide(selectedIndex == index) });
            }
            if (this.comBuyProp.visible) {
                this.locking = true;
                this.aniHideInShop.play(0, false);
                let delay = selectedIndex != -1 ? 668 : 250;
                Laya.timer.once(delay, this, () => {
                    uiscript.UI_AmuletShop.Inst.setMaskVisible(false);
                    this.locking = false;
                    this.comBuyProp.visible = false;
                    this.isOpen = false;
                });
                this.propsBuy.forEach((prop, index) => { prop.hide(selectedIndex == index) });
                this.propsSmall.forEach((prop) => {
                    if (prop.visible) {
                        Laya.Tween.to(prop, { scaleX: 0.9, scaleY: 0.9, alpha: 0 }, 250, Laya.Ease.quadInOut);
                    }
                });
            }
        }
    }
}