module uiscript {
    export class Amulet_TabButton {
        private me: Laya.Button;
        private selectImg: Laya.Image;
        private title: Laya.Label;
        constructor(me: Laya.Button) {
            this.me = me;
            this.selectImg = this.me.getChildByName("select") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
        }
        public onSelect() {
            this.selectImg.visible = true;
            this.title.color = '#71361a';
        }
        public onDeselect() {
            this.selectImg.visible = false;
            this.title.color = '#9ea6e7';
        }
    }
    export class UI_AmuletReward extends UI_PopupBase {
        public static Inst: UI_AmuletReward;
        public static activityId: number = 250812;
        public static currencyId: number = 30900044;

        public static haveRedPoint(): boolean {
            let _list = UI_Activity.getPeriodTaskList(this.activityId);
            if (_list) {
                for (let _info of _list) {
                    if (_info['achieved'] && !_info['rewarded']) {
                        let d_task = cfg.activity.period_task.get(_info['id']);
                        let delta = UI_Activity.getActivityDeltaDay(this.activityId);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        private comBtns: Laya.Sprite;
        private listContainer: Laya.Panel;
        private listScrollBar: Laya.Sprite;
        private comEmpty: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [3668, 3670, 3669];
        private tabButtons: Array<Amulet_TabButton>;
        private btnGetAll: Laya.Button;
        private btnGetAllTitle: Laya.Label;
        private itemRect: UIRect = null;
        private txtCurrency: Laya.Label;
        private needSort: boolean;
        /**
        * 数据结构为 "id":24040301,"counter":3,"achieved":true,"rewarded":false,"failed":false
        */
        private serverData: Object[];
        /**
         * 已经排序过的数据，0-全部，1未完成，2已完成
         */
        private sortServerData: Array<Array<game.ITaskProgress>> = new Array();
        /**
         * 任务数据列表（UI）
         */
        private scrollView: capsui.CScrollView;
        private onItemFreshHandler: Laya.Handler;

        constructor() {
            super(new ui.amulet.amulet_rewardUI());
            UI_AmuletReward.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.outClose = true;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            let list = this.root.getChildByName("content") as Laya.Sprite;
            this.listContainer = list.getChildByName("content") as Laya.Panel;
            this.listScrollBar = list.getChildByName("scrollbar") as Laya.Sprite;
            this.comEmpty = this.root.getChildByName("empty") as Laya.Sprite;
            this.btnGetAll = this.root.getChildByName("btn_receive_all") as Laya.Button;
            this.btnGetAllTitle = this.btnGetAll.getChildByName('title') as Laya.Label;
            this.btnGetAllTitle.text = game.Tools.strOfLocalization(20045);
            this.btnGetAll.clickHandler = new Laya.Handler(this, this.onGetAllBtnClick);
            this.txtCurrency = this.root.getChildByName('currency').getChildByName('count') as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.txtCurrency.y += 2;
            }
            if (GameMgr.client_language == 'kr') {
                this.txtCurrency.y += 4;
            }
            this.scrollView = list.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.listItemRender), 215);
            this.initTabs();
            this.onItemFreshHandler = new Laya.Handler(this, this.refreshCurrency);
        }

        //根据当前选中的tab刷新列表,这个方法会将列表下拉的进度重置
        private freshList(delay: number = 0) {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let data = this.sortServerData[currentSelectIndex];
            this.comEmpty.visible = data.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(data.length);
            this.freshGetAllBtn();
            this.locking = true;
            let list = this.scrollView;
            list.me.mouseEnabled = false;
            let tween_config = { delay: 68, duration: 150, ease: Laya.Ease.quadInOut };
            let start_config = { alpha: 0, y_dis: 100 };
            let target_config = { alpha: 1 };
            let count = data.length > 4 ? 4 : data.length;
            let list_delay = 150 + (count - 1) * 68;
            list.me.alpha = 0;
            Laya.timer.once(delay, this, () => {
                list.me.alpha = 1;
                game.Tools.listAnim(list, count, tween_config, start_config, target_config);
            });
            Laya.timer.once(delay + list_delay, this, () => {
                list.me.mouseEnabled = true;
                this.locking = false;
            });
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base();
            this.tabButtons = new Array<Amulet_TabButton>();
            let tabsName = ['all', 'doing', 'achieved'];
            for (let i = 0; i < 3; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Amulet_TabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    if (this.needSort) this.freshData();
                    tabBtn.onSelect();
                    let delay = manualSwitching ? 0 : 100;
                    this.freshList(delay);
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        public show() {
            if (this.locking) return;
            super.show();
        }

        public close() {
            super.hide();
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_AmuletReward', false);
            UI_Bag.remove_item_listener(UI_AmuletReward.currencyId, this.onItemFreshHandler);
        }

        public onEnable() {
            //初始化数据，刷新下左侧的大奖信息和货币
            game.TempImageMgr.setUIEnable('UI_AmuletReward', true);
            this.freshData();
            this.tabGroups.init();
            UI_Bag.add_item_listener(UI_AmuletReward.currencyId, this.onItemFreshHandler);
            this.refreshCurrency();
        }

        public refreshCurrency() {
            let skillDatas = uiscript.UI_Activity_Amulet.upgradeData.skill || [];
            let costCurrency = 0; //已经花费的技能点
            skillDatas.forEach((data, index) => {
                let skillGroups = cfg.amulet.amulet_upgrade.getGroup(data.id);
                for (let i = 0; i < skillGroups.length; i++) {
                    if (skillGroups[i].level < data.level) costCurrency += skillGroups[i].skill_point;
                }
            });
            let moneyCount = UI_Bag.get_item_count(UI_AmuletReward.currencyId);
            this.txtCurrency.text = (moneyCount - costCurrency).toString();
            if (uiscript.UI_AmuletHome.Inst && uiscript.UI_AmuletHome.Inst.enable) {
                uiscript.UI_AmuletHome.Inst.refreshRedPoint();
            }
        }

        //刷新列表数据
        private freshData() {
            this.needSort = false;
            this.sortServerData.length = 0;
            //获取总列表 
            this.serverData = UI_Activity.getPeriodTaskList(UI_AmuletReward.activityId);
            // app.Log.log(`UI_AmuletReward的数据为:${JSON.stringify(this.serverData)}`)
            //排序已完成未领取＞未完成＞已完成已领取＞未解锁＞任务id
            let allTask = this.serverData.map(item => item as game.ITaskProgress)
            //排序
            allTask = allTask.sort((a, b) => {
                return this.sortTasks(a, b);
            });
            this.sortServerData.push(allTask);
            //未完成列表 
            let notAchieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == false || !this.isTaskUnlock(element)) {
                    notAchieved.push(element);
                }
            });
            this.sortServerData.push(notAchieved);
            //已完成列表
            let achieved = new Array();
            allTask.forEach(element => {
                if (element.achieved == true && this.isTaskUnlock(element)) {
                    achieved.push(element);
                }
            });
            this.sortServerData.push(achieved);
            if (uiscript.UI_AmuletHome.Inst && uiscript.UI_AmuletHome.Inst.enable) {
                uiscript.UI_AmuletHome.Inst.refreshRedPoint();
            }
        }


        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task)) {
                weight = -10000; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        /**
         * 列表Item渲染的方法
         * @param obj index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;

            let serverData = this.sortServerData[this.tabGroups.selectedIndex][index];
            let configData = cfg.activity.period_task.get(serverData.id);
            let baseTaskConfigData = cfg.events.base_task.get(configData.base_task_id);
            let rewardsData = common.ConfigHelper.configString2Array<number>(configData.reward)[0];
            let rewardId: number = rewardsData[0];
            let rewardCount: number = rewardsData[1];
            let itemParent = container.getChildByName("item") as Laya.Button;
            let lockedParent = container.getChildByName("locked") as Laya.Sprite;
            let unLockParent = container.getChildByName("unlock") as Laya.Sprite;
            let txtDesc = container.getChildByName('desc') as Laya.Label;
            let imgGetted = unLockParent.getChildByName('received') as Laya.Sprite;
            let btnReceive = unLockParent.getChildByName("btn_receive") as Laya.Button;
            let txtProgress = container.getChildByName('progress') as Laya.Label;
            let imgProgressBar = container.getChildByName('bar').getChildByName('val') as Laya.Image;
            let txtLockedTime = lockedParent.getChildByName('locked') as Laya.Label;

            //设置上锁的信息
            let isUnlock = this.isTaskUnlock(serverData);
            lockedParent.visible = !isUnlock;
            unLockParent.visible = isUnlock;
            txtDesc.text = baseTaskConfigData['desc_' + GameMgr.client_language];
            txtDesc.valign = isUnlock ? 'top' : 'middle';
            txtDesc.y = isUnlock ? 73 : 98;
            let progress: number = serverData.counter || 0;
            txtProgress.text = progress + '/' + baseTaskConfigData.target;
            imgProgressBar.scaleX = Math.min(1, Math.max(progress / baseTaskConfigData.target, 0.01));
            (container.getChildByName('bg') as Laya.Image).visible = configData.node_mark == 0;
            (container.getChildByName('bg_rare') as Laya.Image).visible = configData.node_mark != 0;
            if (isUnlock) {
                //赋值任务名称
                btnReceive.visible = !serverData.rewarded;
                let btnSkin = serverData.achieved && !serverData.rewarded ? 'myres/amulet/popup_reward_receive.png' : 'myres/amulet/popup_reward_unreceive.png';
                let btnTextColor = serverData.achieved && !serverData.rewarded ? '#462632' : '#a89188';
                btnReceive.skin = game.Tools.localUISrc(btnSkin);
                btnReceive.mouseEnabled = serverData.achieved;
                let btnText = btnReceive.getChildAt(0) as Laya.Label;
                btnText.color = btnTextColor;
                btnText.text = game.Tools.strOfLocalization(4251);
                imgGetted.visible = serverData.achieved && serverData.rewarded;
                if (serverData.achieved && !serverData.rewarded) {
                    //已完成未领取
                    //领取的点击事件
                    btnReceive.clickHandler = new Laya.Handler(this, () => {
                        if (this.locking) return;
                        this.locking = true;
                        app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTask, { task_id: serverData.id }, (err, res) => {
                            this.locking = false;
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTask, err, res);
                            } else {
                                this.needSort = true;
                                serverData.rewarded = true;
                                UI_Activity.onPeriodTaskRewarded(serverData.id);
                                game.Tools.showRewards({ rewards: [{ id: rewardId, count: rewardCount }] }, null);
                                btnReceive.visible = false;
                                imgGetted.visible = true;
                                this.freshGetAllBtn();
                            }
                        });
                    }, null, false);
                }
            }
            else {
                //上锁的时间提示,剩余多长时间，限制时长的总秒数-活动已经过去的总秒数
                let restSeconds = UI_Activity.getActivityUnLockTime(UI_AmuletReward.activityId, configData.reward_limit_day);
                txtLockedTime.text = game.Tools.getLockTimeText2(restSeconds);
            }
            // 奖励的渲染
            if (rewardsData.length >= 2) {
                let imgItem = itemParent.getChildByName("item") as Laya.Image;
                let txtCount = itemParent.getChildByName("count") as Laya.Label;
                if (this.itemRect == null) {
                    this.itemRect = UIRect.CreateFromSprite(imgItem);
                }
                game.Tools.setItemIcon(imgItem, this.itemRect, rewardId, "UI_AmuletReward", true);
                txtCount.text = rewardCount.toString();
                itemParent.clickHandler = new Laya.Handler(this, () => {
                    if (this.locking) return;
                    UI_ItemDetail.Inst.show(rewardId);
                })

            }
        }

        private isTaskUnlock(task: game.ITaskProgress): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(task.id);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_AmuletReward.activityId);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private freshGetAllBtn() {
            let shouldSetGray = !this.haveRedPoint();
            this.btnGetAll.mouseEnabled = !shouldSetGray;
            this.btnGetAll.skin = game.Tools.localUISrc(shouldSetGray ? 'myres/amulet/popup_reward_unreceive.png' : 'myres/amulet/popup_reward_receive.png');
            this.btnGetAllTitle.color = shouldSetGray ? '#a89188' : '#462632';
            UI_AmuletHome.Inst.refreshRedPoint();
        }

        /**
         * 是否有奖励可以领取
         * @returns true 有 false 没有
         */
        public haveRedPoint(): boolean {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let lst = this.sortServerData[currentSelectIndex];
            for (let index = 0; index < lst.length; index++) {
                let serverTask = lst[index] as game.ITaskProgress;
                //已完成，未领取，且已解锁
                if (serverTask.achieved == true && serverTask.rewarded == false) {
                    if (this.isTaskUnlock(serverTask)) {
                        return true;
                    }
                }
            }
            return false;
        }

        private onTaskReceived(id: number) {
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let allRewardList = this.sortServerData[currentSelectIndex];
            for (let data of allRewardList) {
                if (data.id == id) {
                    data.rewarded = true;
                }
            }
        }

        private onGetAllBtnClick() {
            if (this.locking) return;
            let delta = UI_Activity.getActivityDeltaDay(UI_AmuletReward.activityId);
            //需要领取的奖励的id
            let taskIds: Array<number> = [];
            let currentSelectIndex = this.tabGroups.selectedIndex;
            let allRewardList = this.sortServerData[currentSelectIndex];
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        taskIds.push(data.id);
                    } else {
                        break;
                    }
                }
            }
            if (taskIds.length == 0) return;
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.completePeriodActivityTaskBatch, { task_list: taskIds }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                } else {
                    let rewardList = [];
                    let rewardObj = {};
                    for (let id of taskIds) {
                        //更新服务端奖励数据
                        this.onTaskReceived(id);
                        UI_Activity.onPeriodTaskRewarded(id);
                        let taskConfigData = cfg.activity.period_task.get(id);
                        if (!taskConfigData.reward) {
                            continue;
                        }
                        let rewardStr = common.ConfigHelper.configString2Array<number>(taskConfigData.reward)[0];

                        let rewardId = rewardStr[0];
                        let rewardCount = Number(rewardStr[1]);
                        if (!rewardObj[rewardId]) {
                            rewardObj[rewardId] = rewardCount;
                        } else {
                            rewardObj[rewardId] += rewardCount;
                        }
                    }
                    this.needSort = true;
                    this.scrollView.wantToRefreshAll();
                    this.freshGetAllBtn();
                    for (let key in rewardObj) {
                        rewardList.push({ id: Number(key), count: rewardObj[key] });
                    }
                    game.Tools.showRewards({ rewards: rewardList }, null, null);
                }
            })
        }
    }
}