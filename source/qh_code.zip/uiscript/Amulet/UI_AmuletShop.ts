module uiscript {
    export class UI_CardPackage {
        private me: Laya.Sprite;
        private father: UI_AmuletShop;
        private btnDetail: Laya.Button;
        private data: game.IAmuletGameShopGoods;
        public pos: Laya.Vector2;
        private price: Laya.Label;
        private priceOrigin: Laya.Label;
        private tipSoldOut: Laya.Image;
        private cardBg: Laya.Image;
        private soldOut: boolean = false;
        private index: number;
        constructor(me: Laya.Sprite, father: UI_AmuletShop) {
            this.me = me;
            this.father = father;
            this.btnDetail = this.me.getChildByName('btn') as Laya.Button;
            this.price = this.me.getChildByName('price').getChildByName('count') as Laya.Label;
            this.priceOrigin = this.me.getChildByName('price').getChildByName('origin_count') as Laya.Label;
            this.tipSoldOut = this.me.getChildByName('sold') as Laya.Image;
            this.cardBg = this.me.getChildByName('bg') as Laya.Image;
            this.btnDetail.clickHandler = new Laya.Handler(this, () => {
                if (this.soldOut) return;
                this.father.showPackageDetail(this.data, new Laya.Vector2(this.pos.x + 810, this.pos.y + 468), this.index);
            }, null, false);
            this.me.pivot(80, 8);
        }

        show(data: game.IAmuletGameShopGoods, pos: Laya.Vector2, index: number) {
            this.index = index;
            this.data = data;
            this.pos = pos;
            this.me.visible = true;
            this.me.x = pos.x + this.me.pivotX;
            this.me.y = pos.y + this.me.pivotY;
            this.tipSoldOut.visible = !!data.sold;
            (this.me.getChildByName('price') as Laya.Sprite).visible = !data.sold;
            this.cardBg.visible = !data.sold;
            const goodConfig = cfg.amulet.amulet_goods.get(data.goods_id);
            if (!goodConfig) return;
            this.cardBg.skin = game.Tools.localUISrc('myres/amulet/card/opposite_bureau_store_card_bag_' + goodConfig.guaranteed + '.png');
            this.btnDetail.mouseEnabled = !data.sold;
            this.refreshPrice(data);
        }

        refreshPrice(data: game.IAmuletGameShopGoods) {
            const goodConfig = cfg.amulet.amulet_goods.get(data.goods_id);
            if (!goodConfig) return;
            this.data = data;
            let newPrice = data.price;
            this.priceOrigin.visible = newPrice != goodConfig.price; //原价
            this.price.x = newPrice == goodConfig.price ? 62 : 81; //现价
            this.priceOrigin.text = goodConfig.price.toString();
            this.price.text = newPrice.toString();
        }

        getSkin() {
            return this.cardBg.skin;
        }

        setSoldOut() {
            this.tipSoldOut.visible = true;
            (this.me.getChildByName('price') as Laya.Sprite).visible = false;
            this.cardBg.visible = false;
            this.btnDetail.mouseEnabled = false;
        }

        hide() {
            this.me.visible = false;
        }
    }

    class UI_UpgradeItem {
        private me: Laya.Sprite;
        private father: UI_AmuletShop;
        private txtProgress: Laya.Label;
        private txtTitle: Laya.Label;
        private btnUpgrade: Laya.Button;
        private btnUpgradeTitle: Laya.Label;
        private imgBtnBg: Laya.Image;
        private txtUpgradeCount: Laya.Label;
        private imgBg: Laya.Image;
        private tipMax: Laya.Label;
        private id: number;

        constructor(me: Laya.Sprite, father: UI_AmuletShop) {
            this.me = me;
            this.father = father;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.txtProgress = this.me.getChildByName('progress') as Laya.Label;
            this.txtTitle = this.me.getChildByName('title') as Laya.Label;
            this.btnUpgrade = this.me.getChildByName('btn_upgrade') as Laya.Button;
            this.btnUpgradeTitle = this.btnUpgrade.getChildByName('title') as Laya.Label;
            this.imgBtnBg = this.btnUpgrade.getChildByName('icon') as Laya.Image;
            this.txtUpgradeCount = this.btnUpgrade.getChildByName('count') as Laya.Label;
            this.tipMax = this.me.getChildByName('max') as Laya.Label;
            this.btnUpgrade.clickHandler = new Laya.Handler(this, () => {
                const param: game.IReqAmuletActivityUpgradeShopBuff = {
                    activity_id: amulet.AmuletDesktopMgr.activityId,
                    id: this.id
                }
                amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.UpgradeShopBuff, param);
            }, null, false);
            if (GameMgr.client_language == 'kr' || GameMgr.client_language == 'en') {
                this.btnUpgradeTitle.x = this.btnUpgradeTitle.x - 6;
            }
        }

        doAnim() {
            view.AudioMgr.PlayAudio(10156);
            let _effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(
                this.me, 'scene/effect_amulet_up.lh', new Laya.Point(166, 85), 1);
            Laya.timer.once(1000, this, () => {
                _effect.destory();
            });
        }

        setData(data: game.IAmuletBuffData, doAnim: boolean) {
            this.id = data.id;
            let buffConfig = cfg.amulet.amulet_shop_upgrade.getGroup(data.id);
            buffConfig.sort((a, b) => {
                return a.level - b.level;
            })
            const maxLevelConfig = buffConfig[buffConfig.length - 1];
            const maxLevel = maxLevelConfig.level;
            const nowLevel = Number(data.store ? data.store[0] : 0);
            const nowLevelConfig = buffConfig.find(buff => { return buff.level == nowLevel });
            let isMax = nowLevel == maxLevel;
            let alreadyFull = false; //理论没满级但是实际魂牌数已满
            if (!isMax && data.id == this.father.buffIds[0] && amulet.AmuletDesktopMgr.Inst.tians.length == 27) {
                alreadyFull = true;
                isMax = true;
            }
            let initValue;
            if (data.id == 8004) {
                initValue = UI_Activity_Amulet.amuletActivityConfig.init_tian_count;
            } else if (data.id == 8002) {
                initValue = UI_Activity_Amulet.amuletActivityConfig.init_dora_indicator;
            } else if (data.id == 8003) {
                initValue = UI_Activity_Amulet.amuletActivityConfig.init_open_desktop_count;
            }
            const nowProgress = nowLevelConfig ? nowLevelConfig.display_value : initValue;
            const nextLevelConfig = buffConfig.find(buff => { return buff.level == nowLevel + 1 });
            this.imgBg.skin = game.Tools.localUISrc(isMax ? 'myres/amulet/opposite_bureau_store_upgrade_bottom_max.png' : 'myres/amulet/opposite_bureau_store_upgrade_bottom_1.png');
            this.txtProgress.text = alreadyFull ? game.Tools.strOfLocalization(4111) : nowProgress + '/' + maxLevelConfig.display_value;
            this.btnUpgrade.visible = !isMax;
            this.tipMax.visible = isMax;
            if (nextLevelConfig) {
                const canPay = Number(amulet.AmuletDesktopMgr.Inst.amuletGameData.game.coin) >= nextLevelConfig.price;
                this.txtUpgradeCount.text = nextLevelConfig.price.toString();
                this.imgBtnBg.skin = game.Tools.localUISrc(canPay ? 'myres/amulet/button_4_orange.png' : 'myres/amulet/button_4_gray.png');
                this.btnUpgrade.mouseEnabled = canPay;
            }
            if (doAnim) this.doAnim();
        }
    }
    const packagePos = [
        [new Laya.Vector2(240, 80), new Laya.Vector2(490, 80)],
        [new Laya.Vector2(115, 80), new Laya.Vector2(365, 80), new Laya.Vector2(615, 80)],
        [new Laya.Vector2(110, 20), new Laya.Vector2(280, 140), new Laya.Vector2(450, 20), new Laya.Vector2(620, 140)],
        [new Laya.Vector2(25, 20), new Laya.Vector2(195, 140), new Laya.Vector2(365, 20), new Laya.Vector2(535, 140), new Laya.Vector2(705, 20)],
    ];
    export class UI_AmuletShop extends UIBase {
        public static Inst: UI_AmuletShop;
        private root: Laya.Sprite;
        private btnRefresh: Laya.Button;
        private btnNextLevel: Laya.Button;
        private panelProp: Laya.Sprite;
        private cardsProp: UI_CardPackage[] = [];
        private txtRefreshPay: Laya.Label;
        private popupDetail: UI_PropDetailPopup;
        private upgradeItems: UI_UpgradeItem[];
        public locking: boolean;
        private comEffect: Laya.Sprite;
        private aniComPackage: Laya.Sprite;
        private aniComPackageIcon: Laya.Image;
        private aniShakes: Laya.FrameAnimation[];
        private aniShowCard: Laya.FrameAnimation;
        private aniShopIdle: Laya.FrameAnimation;
        private aniShopStar1: Laya.FrameAnimation;
        private aniShopStar2: Laya.FrameAnimation;
        private aniShowShop: Laya.FrameAnimation;
        private aniHideShop: Laya.FrameAnimation;
        private mask: Laya.Sprite;
        private btnCardLibrary: Laya.Button;
        public buffIds: number[] = [8004, 8002, 8003];

        constructor(me: Laya.Sprite, father: UI_AmuletDesktopInfo) {
            super(me);
            UI_AmuletShop.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.btnRefresh = this.root.getChildByName('refresh') as Laya.Button;
            this.btnNextLevel = this.root.getChildByName('next') as Laya.Button;
            this.panelProp = this.root.getChildByName('panel') as Laya.Sprite;
            this.cardsProp = [];
            for (let i = 0; i < 5; i++) {
                let comCard = this.panelProp.getChildAt(i) as Laya.Sprite;
                let card = new UI_CardPackage(comCard, this);
                this.cardsProp.push(card);
            }
            this.txtRefreshPay = this.btnRefresh.getChildByName('count') as Laya.Label;
            this.popupDetail = new UI_PropDetailPopup(this.me.getChildByName('package_detail') as Laya.Sprite, this);
            this.upgradeItems = [];
            this.upgradeItems.push(new UI_UpgradeItem(this.root.getChildByName('hunpai') as Laya.Sprite, this));
            this.upgradeItems.push(new UI_UpgradeItem(this.root.getChildByName('dora') as Laya.Sprite, this));
            this.upgradeItems.push(new UI_UpgradeItem(this.root.getChildByName('openpai') as Laya.Sprite, this));
            this.btnNextLevel.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                const param: game.IReqAmuletActivityUpgrade = {
                    activity_id: amulet.AmuletDesktopMgr.activityId
                }
                amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.EndShopping, param);
            }, null, false);
            this.btnRefresh.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20082, [this.txtRefreshPay.text]), Laya.Handler.create(this, () => {
                    const param: game.IReqAmuletActivityRefreshShop = {
                        activity_id: amulet.AmuletDesktopMgr.activityId
                    }
                    amulet.AmuletDesktopMgr.Inst.DoAmuletGameAction(amulet.EAmuletGameAction.RefreshShop, param);
                }));
                UI_SecondConfirm.Inst.setBtnState(true, true);
            }, null, false);
            this.btnCardLibrary = this.me.getChildByName('cardlibrary').getChildByName('card_library') as Laya.Button;
            this.btnCardLibrary.clickHandler = new Laya.Handler(this, () => {
                uiscript.UI_AmuletCardLibrary.Inst.show();
            }, null, false);
            this.aniComPackage = this.me.getChildByName('panel_ani').getChildByName('ani') as Laya.Sprite;
            this.aniComPackage.visible = false;
            this.aniComPackageIcon = this.aniComPackage.getChildAt(0) as Laya.Image;
            this.comEffect = this.me.getChildByName('effect') as Laya.Sprite;
            this.mask = this.me.getChildByName('panel_ani').getChildByName('btn_mask') as Laya.Sprite;
            this.mask.visible = false;
            let ui = this.me.parent as ui.amulet.amulet_desktopinfoUI;
            this.aniShakes = [ui.shake1, ui.shake2, ui.shake3, ui.shake4, ui.shake5];
            this.aniShowCard = ui.showCard;
            this.aniShopIdle = ui.idleShop;
            this.aniShopStar1 = ui.shop_star_idle01;
            this.aniShopStar2 = ui.shop_star_idle02;
            this.aniShowShop = ui.showShop;
            this.aniHideShop = ui.hideShop;
        }

        public showPackageDetail(goods: game.IAmuletGameShopGoods, pos: Laya.Vector2, index: number) {
            view.AudioMgr.PlayAudio(10144);
            this.aniShakes[index].play(0, false);
            this.popupDetail.showPackage(goods, pos);
        }

        public show(doAnim: boolean = false) {
            this.enable = true;
            Laya.timer.clearAll(this);
            this.refresh(doAnim, true);
            Laya.timer.once(1000, this, () => {
                this.aniShopIdle.play(0, true);
            })
            this.aniShowShop.play(0, false);
            this.aniShopStar1.play(0, true);
            this.aniShopStar2.play(0, true);
        }

        public refreshCurrency() {
            this.refreshBuff(false);
            this.refreshBtn();
            const data = amulet.AmuletDesktopMgr.Inst.amuletGameData.shop;
            data.goods.forEach((value, index) => {
                if (this.cardsProp[index]) {
                    this.cardsProp[index].refreshPrice(value);
                }
            })
        }

        public refreshBtn() {
            const data = amulet.AmuletDesktopMgr.Inst.amuletGameData.shop;
            const refreshPrice = data.refresh_price || 0;
            const coin = Number(amulet.AmuletDesktopMgr.Inst.amuletGameData.game.coin || '0');
            this.txtRefreshPay.text = refreshPrice.toString();
            this.btnRefresh.mouseEnabled = refreshPrice <= coin;
            (this.btnRefresh.getChildByName('icon') as Laya.Image).skin = game.Tools.localUISrc(refreshPrice <= coin ? 'myres/amulet/button_1_blue.png' : 'myres/amulet/button_1_grey.png');
            (this.btnRefresh.getChildByName('title') as Laya.Label).color = refreshPrice <= coin ? '#f7efde' : '#8a776f';
        }

        public refresh(doAnim: boolean = false, firstShow: boolean = false, buffId: number = 0) {
            this.refreshPackage(doAnim, firstShow);
            this.refreshBuff(doAnim, buffId);
        }

        public refreshPackage(doAnim: boolean = false, firstShow: boolean = false) {
            if (doAnim) this.aniShowCard.play(0, false);
            const data = amulet.AmuletDesktopMgr.Inst.amuletGameData.shop;
            this.refreshBtn();
            this.cardsProp.forEach(prop => prop.hide());
            let delay = doAnim && !firstShow ? 167 : 0;
            //刷新商店延迟10帧
            Laya.timer.once(delay, this, () => {
                data.goods.forEach((value, index) => {
                    let pos = packagePos[data.goods.length - 2][index];
                    if (this.cardsProp[index]) {
                        this.cardsProp[index].show(value, pos, index);
                    }
                })
            });
            if (data.candidate_effect_list && data.candidate_effect_list.length > 0) {
                this.openPackage(data.candidate_effect_list);
            }
        }

        public openPackage(effectLst: game.IAmuletEffectCandidate[], packageUId?: number) {
            let delay = !!packageUId ? 968 : 0;
            let audioId = !!packageUId ? 10155 : 10150;
            const data = amulet.AmuletDesktopMgr.Inst.amuletGameData.shop;
            view.AudioMgr.PlayAudio(audioId);
            this.setMaskVisible(true);
            if (packageUId) {
                let packIndex = -1;
                let packageId;
                data.goods.forEach((good, index) => {
                    if (good.id == packageUId) {
                        packIndex = index;
                        packageId = good.goods_id;
                    }
                })
                if (packIndex >= 0) {
                    this.aniComPackage.visible = true;
                    this.aniComPackageIcon.visible = true;
                    this.aniComPackageIcon.skin = this.cardsProp[packIndex].getSkin();
                    let pos = packagePos[data.goods.length - 2][packIndex];
                    this.aniComPackage.x = pos.x + this.aniComPackage.pivotX;
                    this.aniComPackage.y = pos.y + this.aniComPackage.pivotY;
                    this.aniComPackage.scale(1, 1);
                    this.cardsProp[packIndex].setSoldOut();
                    Laya.Tween.to(this.aniComPackage, { scaleX: 2.01, scaleY: 2.01 }, 333, Laya.Ease.quadInOut);
                    Laya.Tween.to(this.aniComPackage, { x: 227, y: 106 }, 250, Laya.Ease.quadInOut);
                    Laya.Tween.to(this.aniComPackage, { rotation: 4 }, 200, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                        Laya.Tween.to(this.aniComPackage, { rotation: 0 }, 167, Laya.Ease.quadInOut);
                    }));
                    this.locking = true;
                    Laya.timer.once(367, this, () => {
                        this.locking = false;
                        this.aniComPackageIcon.visible = false;
                        this.aniComPackage.visible = false;
                        UI_AmuletDesktopInfo.Inst.openPropPackage(effectLst, packageId);
                    });
                }
            } else {
                uiscript.UI_AmuletProp.Inst.showBuyProps(effectLst);
            }
        }

        public refreshBuff(doAnim: boolean = false, buffId: number = 0) {
            const buffData = amulet.AmuletDesktopMgr.Inst.amuletGameData.effect.shop_buff_list || [];
            for (let i = 0; i < buffData.length; i++) {
                let index = this.buffIds.indexOf(buffData[i].id);
                if (this.upgradeItems[index]) {
                    this.upgradeItems[index].setData(buffData[i], buffData[i].id == buffId);
                }
            }
        }

        public hide() {
            this.locking = true;
            this.aniShowShop.stop();
            this.aniShopIdle.stop();
            Laya.timer.clearAll(this);
            this.aniHideShop.play(0, false);
            Laya.timer.once(this.aniHideShop.count * this.aniHideShop.interval, this, () => {
                this.locking = false;
                this.enable = false;
            })
        }

        public onDisable(): void {
            Laya.timer.clearAll(this);
            this.locking = false;
            this.cardsProp.forEach((value) => {
                value.hide();
            });
            this.aniShopStar1.stop();
            this.aniShopStar2.stop();
            this.aniShopIdle.stop();
            this.aniShowShop.stop();
        }

        public setMaskVisible(visible: boolean) {
            Laya.Tween.clearAll(this.mask);
            if (visible) {
                this.mask.visible = true;
                Laya.Tween.to(this.mask, { alpha: 1 }, 167, Laya.Ease.quadInOut)
            } else {
                Laya.Tween.to(this.mask, { alpha: 0 }, 167, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                    this.mask.visible = false;
                }))
            }
        }
    }
}