module uiscript {
    export class UI_AmuletStrengthen extends UI_PopupBase {
        public static Inst: UI_AmuletStrengthen;
        public static _strengthConfig: basic.Dictionary<number, lqc.Sheet_Amulet_AmuletUpgrade[]>;
        public static _strengthIds: number[];
        public static get strengthConfig(): basic.Dictionary<number, lqc.Sheet_Amulet_AmuletUpgrade[]> {
            if (!this._strengthConfig) {
                this.init();
            }
            return this._strengthConfig;
        }
        public static get strengthIds(): number[] {
            if (!this._strengthIds) {
                this.init();
            }
            return this._strengthIds;
        }

        public static haveRedPoint() {
            let skillDatas = uiscript.UI_Activity_Amulet.upgradeData.skill || [];
            let costCurrency = 0; //已经花费的技能点
            skillDatas.forEach((data, index) => {
                let skillGroups = cfg.amulet.amulet_upgrade.getGroup(data.id);
                for (let i = 0; i < skillGroups.length; i++) {
                    if (skillGroups[i].level < data.level) costCurrency += skillGroups[i].skill_point;
                }
            });
            let moneyCount = UI_Bag.get_item_count(UI_AmuletReward.currencyId) - costCurrency; //目前剩余的技能点
            for (let index = 0; index < this.strengthIds.length; index++) {
                let id = this.strengthIds[index];
                let skillGroups = this._strengthConfig.get(id);
                let skillData = skillDatas.find((skill) => { return skill.id == id; });
                if (!skillData) {
                    if (moneyCount >= skillGroups[0].skill_point) {
                        return true;
                    }
                    continue;
                }
                skillData.level = skillData.level || skillGroups[0].level;
                let nowSkillConfig = skillGroups[skillData.level];
                if (skillData.level != skillGroups[skillGroups.length - 1].level && moneyCount >= nowSkillConfig.skill_point) { //只要不是最高级而且有技能点可以用
                    return true;
                }
            }
            return false;
        }

        private static init() {
            this._strengthConfig = new basic.Dictionary();
            this._strengthIds = [];
            cfg.amulet.amulet_upgrade.forEachGroup((groups) => {
                let id = groups[0].id;
                this._strengthIds.push(id);
                groups.sort((a, b) => { return a.level - b.level; });
                this._strengthConfig.set(id, groups);
            })
        }
        private comStrengthens: Laya.Sprite[];
        private btnReset: Laya.Button;
        private txtCurrency: Laya.Label;
        private names: number[] = [20069, 20070, 20071, 20072, 20073, 20412];
        private descs: number[] = [20074, 20075, 20076, 20077, 20078, 20413];
        private skillDatas: game.IAmuletSkillData[];
        private onItemFreshHandler: Laya.Handler;
        private isChanged: boolean;

        constructor() {
            super(new ui.amulet.amulet_strengthenUI());
            UI_AmuletStrengthen.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.outClose = true;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.txtCurrency = this.root.getChildByName('currency').getChildByName('count') as Laya.Label;
            this.comStrengthens = [];
            let content = this.root.getChildByName('content') as Laya.Sprite;
            content._childs.forEach((com, index) => {
                this.comStrengthens.push(com);
                if (GameMgr.client_language == 'kr') {
                    (com.getChildByName('desc') as Laya.Label).font = 'NotoSansKR';
                }
                (com.getChildByName('btn_upgrade') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    if (!this.skillDatas[index]) return;
                    if (this.locking) return;
                    this.locking = true;
                    let datas = game.Tools.deepCopy(this.skillDatas) as game.IAmuletSkillData[];
                    datas.forEach((data, _index) => {
                        if (index == _index) {
                            data.level++;
                        }
                    })
                    const param: game.IReqAmuletActivitySetSkillLevel = {
                        activity_id: uiscript.UI_Activity_Amulet.activityId,
                        /** 技能点数与等级 */
                        skill: datas
                    }
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivitySetSkillLevel, param, (err, res) => {
                        this.locking = false;
                        if (err || res['error']) {
                            uiscript.UIMgr.Inst.showNetReqError(game.ERequest.amuletActivitySetSkillLevel, err, res);
                        } else {
                            this.isChanged = true;
                            UI_Activity_Amulet.updateStrengthenData(param);
                            this.refresh();
                            this.doAnim(index);
                        }
                    });
                }, null, false);
            });
            (this.root.getChildByName('btn_reset') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20049), Laya.Handler.create(this, () => {
                    this.locking = true;
                    let datas = game.Tools.deepCopy(this.skillDatas) as game.IAmuletSkillData[];
                    datas.forEach((data, _index) => {
                        data.level = 0;
                    })
                    const param: game.IReqAmuletActivitySetSkillLevel = {
                        activity_id: uiscript.UI_Activity_Amulet.activityId,
                        /** 技能点数与等级 */
                        skill: datas
                    }
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivitySetSkillLevel, param, (err, res) => {
                        this.locking = false;
                        if (err || res['error']) {
                            uiscript.UIMgr.Inst.showNetReqError(game.ERequest.amuletActivitySetSkillLevel, err, res);
                        } else {
                            this.isChanged = true;
                            UI_Activity_Amulet.updateStrengthenData(param);
                            this.refresh();
                        }
                    });
                }));
            }, null, false);
            this.onItemFreshHandler = new Laya.Handler(this, this.refresh);
            if (GameMgr.client_language == 'en') {
                this.txtCurrency.y += 2;
            }
            if (GameMgr.client_language == 'kr') {
                this.txtCurrency.y += 4;
            }
        }

        show() {
            if (this.locking) return;
            super.show();
            this.refresh();
            this.isChanged = false;
            for (let i = 0; i < this.comStrengthens.length; i++) {
                let com = this.comStrengthens[i];
                Laya.Tween.clearAll(com);
                com.alpha = 0;
                let targetY = Math.floor(i / 2) * 244 + 122;
                com.y = targetY + 100;
                Laya.Tween.to(com, { y: targetY, alpha: 1 }, 150, Laya.Ease.quadInOut, null, Math.floor(i / 2) * 68 + 100);
            }
        }

        doAnim(index: number) {
            this.locking = true;
            view.AudioMgr.PlayAudio(10156);
            let _effect: game.UIEffect = game.FrontEffect.Inst.create_ui_effect(
                this.comStrengthens[index], 'scene/effect_amulet_strengthen.lh', new Laya.Point(1, -1), 1);
            let loaded = false;
            _effect.effect.addLoadedListener(Laya.Handler.create(this, () => {
                loaded = true;
                Laya.timer.once(600, this, () => {
                    UI_LightTips.Inst.show(game.Tools.strOfLocalization(20048));
                });
            }));
            Laya.timer.once(1000, this, () => {
                this.locking = false;
                _effect.destory();
                if (!loaded) UI_LightTips.Inst.show(game.Tools.strOfLocalization(20048));
            });
        }

        refresh() {
            this.skillDatas = uiscript.UI_Activity_Amulet.upgradeData.skill || [];
            this.skillDatas.sort((a, b) => { return a.id - b.id });
            let costCurrency = 0;
            this.skillDatas.forEach((data, index) => {
                let skillGroups = cfg.amulet.amulet_upgrade.getGroup(data.id);
                for (let i = 0; i < skillGroups.length; i++) {
                    if (skillGroups[i].level < data.level) costCurrency += skillGroups[i].skill_point;
                }
            });
            let moneyCount = UI_Bag.get_item_count(UI_AmuletReward.currencyId) - costCurrency;
            this.comStrengthens.forEach((com, index) => {
                if (UI_AmuletStrengthen.strengthIds[index]) {
                    let skillGroups = UI_AmuletStrengthen._strengthConfig.get(UI_AmuletStrengthen.strengthIds[index]);
                    let skillData = this.skillDatas[index] || { level: skillGroups[0].level, id: UI_AmuletStrengthen.strengthIds[index] };
                    skillData.level = skillData.level || skillGroups[0].level;
                    let nowSkillConfig = skillGroups[skillData.level];
                    (com.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(this.names[index]);
                    (com.getChildByName('level') as Laya.Label).text = 'Lv.' + skillData.level;
                    let nextLevelDesc = '';
                    if (skillData.level != skillGroups[skillGroups.length - 1].level) {
                        let nextSkillConfig = skillGroups[skillData.level + 1];
                        nextLevelDesc = game.Tools.strOfLocalization(20079, [nextSkillConfig.display_value.toString()]);
                    }
                    (com.getChildByName('max') as Laya.Sprite).visible = skillData.level == skillGroups[skillGroups.length - 1].level;
                    (com.getChildByName('btn_upgrade') as Laya.Sprite).visible = skillData.level < skillGroups[skillGroups.length - 1].level;
                    (com.getChildByName('desc') as Laya.Label).text = game.Tools.strOfLocalization(this.descs[index], [nowSkillConfig.display_value.toString()]) + nextLevelDesc;
                    (com.getChildByName('btn_upgrade').getChildByName('count') as Laya.Label).text = 'x' + nowSkillConfig.skill_point;

                    (com.getChildByName('btn_upgrade') as Laya.Button).mouseEnabled = moneyCount >= nowSkillConfig.skill_point;
                    let url = moneyCount >= nowSkillConfig.skill_point ? 'myres/amulet/button_3.png' : 'myres/amulet/button_3_gray.png';
                    let colorTitle = moneyCount >= nowSkillConfig.skill_point ? '#6f3716' : '#a89188';
                    let colorCount = moneyCount >= nowSkillConfig.skill_point ? '#6f3716' : '#e33131';
                    (com.getChildByName('btn_upgrade').getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(url);
                    (com.getChildByName('btn_upgrade').getChildByName('title') as Laya.Label).color = colorTitle;
                    (com.getChildByName('btn_upgrade').getChildByName('count') as Laya.Label).color = colorCount;
                } else {
                    com.visible = false;
                }
            })
            this.txtCurrency.text = moneyCount.toString();
            (this.root.getChildByName('btn_reset') as Laya.Button).mouseEnabled = costCurrency != 0;
            let url = costCurrency != 0 ? 'myres/amulet/btn_strengthen_bg.png' : 'myres/amulet/btn_strengthen_bg_grey.png';
            let colorTitle = costCurrency != 0 ? '#a24821' : '#a89188';
            (this.root.getChildByName('btn_reset').getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc(url);
            (this.root.getChildByName('btn_reset').getChildByName('title') as Laya.Label).color = colorTitle;
        }

        hide() {
            if (this.isChanged) {
                UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20050));
            }
            super.hide();
        }

        public onEnable() {
            UI_Bag.add_item_listener(UI_AmuletReward.currencyId, this.onItemFreshHandler);
        }

        public onDisable(): void {
            if (uiscript.UI_AmuletHome.Inst && uiscript.UI_AmuletHome.Inst.enable) {
                uiscript.UI_AmuletHome.Inst.refreshRedPoint();
            }
            UI_Bag.remove_item_listener(UI_AmuletReward.currencyId, this.onItemFreshHandler);
        }
    }
}