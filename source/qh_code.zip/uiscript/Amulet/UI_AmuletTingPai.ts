/**
* name 
*/
module uiscript {

	interface item {
		container: Laya.Sprite;
		tile: UI_MJP;
		count: Laya.Label;
		fanValue: Laya.Label;
	}
	interface TingPaiInfo {
		tile: string;
		fan: number;
		pai: amulet.MJPai;
		count: number
	}

	interface TingPaiDiscardInfo {
		tile: string;
		pai: amulet.MJPai;
		tingTiles: TingPaiInfo[];
	}

	export class UI_AmuletTingPai extends UIBase {

		public static Inst: UI_AmuletTingPai = null;
		private container_tiles: Laya.Sprite = null;
		private root: Laya.Sprite = null;
		private items: Array<item> = [];
		private bg: Laya.Image;
		private btn_show: Laya.Button = null;
		private tingPaiDiscardInfos: Array<TingPaiDiscardInfo> = [];
		private mousedowned: boolean = false;

		constructor() {
			super(new ui.amulet.amulet_tingpaiUI());
			UI_AmuletTingPai.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.container_tiles = this.root.getChildByName('container_tiles') as Laya.Sprite;
			for (let i: number = 0; i < this.container_tiles.numChildren; i++) {
				let node: Laya.Sprite = this.container_tiles.getChildAt(i) as Laya.Sprite;
				if (GameMgr.client_language == 'kr') (node.getChildByName('fan') as Laya.Label).y += 3;
				this.items.push({
					container: node,
					tile: new UI_MJP(node.getChildByName('pai') as Laya.Image),
					fanValue: node.getChildByName('fan') as Laya.Label,
					count: node.getChildByName('count') as Laya.Label,
				});
				this.items[i].container.visible = false;
			}
			this.bg = this.root.getChildByName('bg') as Laya.Image;

			this.btn_show = this.me.getChildByName('btn_show') as Laya.Button;
			this.btn_show.on('mousedown', this, this._setMouseDown, [true]);
			this.btn_show.on('mouseup', this, this._setMouseDown, [false]);
			this.btn_show.on('mouseout', this, this._setMouseDown, [false]);
			this.btn_show.visible = false;
			this.reset();
		}

		public reset() {
			// app.Log.log('tingpai  reset');
			this.root.visible = false;
			this.btn_show.visible = false;
			this.mousedowned = false;
			this.tingPaiDiscardInfos = [];
		}

		public setData(data: game.IAmuletActivityTingInfo[]) {
			// app.Log.log('tingpai  data=====' + JSON.stringify(data))
			this.tingPaiDiscardInfos = [];
			if (data && data.length > 0) {
				for (let i = 0; i < data.length; i++) {
					let tingPaiData = data[i];
					let pai = amulet.MJPai.Create({ id: -1, tile: tingPaiData.tile });
					let tingPai = amulet.MJPai.Create({ id: -1, tile: tingPaiData.ting_tile });
					let tingPaiInfo = this.tingPaiDiscardInfos.find(ting => { return amulet.MJPai.Distance(ting.pai, pai) == 0; });
					const tingTile: TingPaiInfo = {
						tile: tingPaiData.ting_tile,
						fan: Number(tingPaiData.fan),
						pai: tingPai,
						count: amulet.AmuletDesktopMgr.Inst.getLeftPaiCount(tingPaiData.ting_tile, false)
					}
					if (tingPaiInfo) {
						if (amulet.MJPai.Create({ id: -1, tile: tingPaiInfo.tingTiles[0].tile }).baida) {
							if (tingTile.fan && tingTile.fan > tingPaiInfo.tingTiles[0].fan) tingPaiInfo.tingTiles[0].fan = tingTile.fan;
							if (tingTile.count) tingPaiInfo.tingTiles[0].count = tingPaiInfo.tingTiles[0].count + tingTile.count;
						} else {
							let tingTilesLstData = tingPaiInfo.tingTiles.find(tingTile => { return amulet.MJPai.Distance(tingTile.pai, tingPai) == 0; })
							if (!tingTilesLstData) {
								tingPaiInfo.tingTiles.push(tingTile);
								if (tingPaiInfo.tingTiles.length > amulet.BAIDA_COUNT) { //听牌数超过13张，展示为听百搭牌
									let baidaTingTile: TingPaiInfo = {
										tile: amulet.MJPai.Create({ id: -1, tile: 'bd' }).toString(),
										fan: 0,
										pai: tingPai,
										count: 0
									}
									for (let j = 0; j < tingPaiInfo.tingTiles.length; j++) {
										if (tingPaiInfo.tingTiles[j].count) baidaTingTile.count += tingPaiInfo.tingTiles[j].count;
										if (tingPaiInfo.tingTiles[j].fan && tingPaiInfo.tingTiles[j].fan > baidaTingTile.fan) baidaTingTile.fan = tingPaiInfo.tingTiles[j].fan;
									}
									tingPaiInfo.tingTiles = [baidaTingTile];
								}
							} else {
								if (Number(tingTile.fan) > Number(tingTilesLstData.fan)) tingTilesLstData.fan = tingTile.fan;
							}
						}
					} else {
						this.tingPaiDiscardInfos.push({
							tile: tingPaiData.tile,
							pai: pai,
							tingTiles: [tingTile]
						})
					}
				}
			}
			this.refreshBtnShow();
		}

		refreshBtnShow() {
			this.btn_show.visible = this.tingPaiDiscardInfos.length >= 1;
		}

		private _show(tingPaiInfo: Array<TingPaiInfo>) {
			if (amulet.AmuletDesktopMgr.Inst.duringHuPai) return;
			for (let i: number = 0; i < this.items.length; i++) {
				this.items[i].container.visible = false;
			}
			this.container_tiles.width = 127 * tingPaiInfo.length;
			this.container_tiles.x = 157 - this.container_tiles.width / 2;
			tingPaiInfo.forEach((tingInfo) => {
				if (!tingInfo.pai) tingInfo.pai = amulet.MJPai.Create({ id: -1, tile: tingInfo.tile });
			})
			tingPaiInfo.sort((a, b) => { return amulet.MJPai.Distance(a.pai, b.pai); });
			for (let i: number = 0; i < tingPaiInfo.length; i++) {
				this.items[i].container.visible = true;
				this.items[i].tile.show(tingPaiInfo[i].tile);
				this.items[i].container.x = 127 * i;
				this.items[i].container.y = 0;
				this.items[i].fanValue.text = tingPaiInfo[i].fan + game.Tools.strOfLocalization(20021);
				this.items[i].count.text = tingPaiInfo[i].tile == 'bd' ? game.Tools.strOfLocalization(3668) : tingPaiInfo[i].count + game.Tools.strOfLocalization(20038);
				if (amulet.AmuletDesktopMgr.Inst.isTianPai(tingPaiInfo[i].pai)) {
					this.items[i].tile.setFiltersState(EUIPaiFilterState.yellow);
				} else {
					this.items[i].tile.setFiltersState(EUIPaiFilterState.none);
				}
			}
			this.bg.width = 52 + 127 * tingPaiInfo.length;
			this.root.visible = true;
		}

		public checkDropLastPaiHu(): boolean {
			if (!amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands || amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands.length == 0) return false;
			if (!this.tingPaiDiscardInfos || this.tingPaiDiscardInfos.length == 0) return false;
			let pai = amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands[amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands.length - 1]);
			if (pai) {
				for (let i: number = 0; i < this.tingPaiDiscardInfos.length; i++) {
					if (amulet.MJPai.Distance(this.tingPaiDiscardInfos[i].pai, pai) == 0) {
						return true;
					}
				}
			}
			return false;
		}

		public onChooseTile(pai: amulet.MJPai) {
			if (pai && this.tingPaiDiscardInfos) {
				let index: number = -1;
				for (let i: number = 0; i < this.tingPaiDiscardInfos.length; i++) {
					if (amulet.MJPai.Distance(this.tingPaiDiscardInfos[i].pai, pai) == 0) {
						index = i;
						break;
					}
				}
				if (index == -1) {
					this.root.visible = false;
				} else {
					this._show(this.tingPaiDiscardInfos[index].tingTiles);
				}
			} else {
				this.root.visible = false;
			}
		}

		private _setMouseDown(v: boolean) {
			// app.Log.log('_setMouseDown ' + v);
			if (this.mousedowned == v) return;
			this.mousedowned = v;
			if (v) {
				//只有一种听牌
				if (this.tingPaiDiscardInfos && this.tingPaiDiscardInfos.length == 1) {
					this._show(this.tingPaiDiscardInfos[0].tingTiles);
				} else if (amulet.AmuletDesktopMgr.Inst.autoMoqie) {
					let pai = amulet.AmuletDesktopMgr.Inst.getDisplayMJPaiById(amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands[amulet.AmuletDesktopMgr.Inst.amuletGameData.round.hands.length - 1]);
					this.onChooseTile(pai);
				} else {
					this.root.visible = false;
				}
			} else {
				this.root.visible = false;
			}
		}

		onDiscardTile(pai: amulet.MJPai) {
			if (this.tingPaiDiscardInfos) {
				for (let i: number = 0; i < this.tingPaiDiscardInfos.length; i++) {
					if (amulet.MJPai.Distance(this.tingPaiDiscardInfos[i].pai, pai) == 0) {
						this.tingPaiDiscardInfos = [this.tingPaiDiscardInfos[i]];
						this.tingPaiDiscardInfos[0].pai = amulet.MJPai.Create({ tile: '', id: -1 });
						this.refreshBtnShow();
						return;
					}
				}
			}
		}

		public get isShow() {
			return this.root.visible;
		}
	}
}