// ==DevDebug==
module uiscript {
	export class UI_Amulet_Debug extends UIBase {
		public static Inst: UI_Amulet_Debug;

		public get meUI(): ui.amulet.amulet_DevDebugUI {
			return this.me as ui.amulet.amulet_DevDebugUI;
		}

		constructor() {
			super(new ui.amulet.amulet_DevDebugUI());
			UI_Amulet_Debug.Inst = this;
		}

		onCreate() {
			this.meUI.btn_show.clickHandler = new Laya.Handler(this, () => {
				this.meUI.root.visible = !this.meUI.root.visible;
			});
			this.meUI.root.visible = false;
			this.meUI.btn_close.clickHandler = new Laya.Handler(this, this.Close);
			this.meUI.btn_add_amulet.clickHandler = new Laya.Handler(this, this.AddAmulet);
			this.meUI.btn_shop_amulet.clickHandler = new Laya.Handler(this, this.ChangeShopAmuletSelect);
			this.meUI.btn_coin.clickHandler = new Laya.Handler(this, this.SetCoin);
			this.meUI.btn_open_mountain.clickHandler = new Laya.Handler(this, this.OpenMountain);
			this.meUI.btn_hands.clickHandler = new Laya.Handler(this, this.SetHands);
			this.meUI.btn_paishan.clickHandler = new Laya.Handler(this, this.SetPaiShan);
			this.meUI.btn_boss_buff.clickHandler = new Laya.Handler(this, this.SetBossBuff);
			this.meUI.btn_score.clickHandler = new Laya.Handler(this, this.SetPoint);
			this.meUI.testpoint.clickHandler = new Laya.Handler(this, this.TestPoint, [true]);
			this.meUI.btn_level.clickHandler = new Laya.Handler(this, this.SetLevel);
			this.meUI.changePaiScore.clickHandler = new Laya.Handler(this, this.SetPaiPoint);
			this.meUI.dora_confirm.clickHandler = new Laya.Handler(this, this.ChangeDora);
			this.meUI.hunpai_confirm.clickHandler = new Laya.Handler(this, this.ChangeHunpai);
			this.meUI.openoveriview.clickHandler = new Laya.Handler(this, this.OpenOverview);
			this.meUI.testscore1.on('input', this, this.TestPoint, [false]);
			this.meUI.testscore2.on('input', this, this.TestPoint, [false]);
		}

		private Close() {
			this.meUI.root.visible = false
		}

		private UpdateAmuletData(onComplete = null) {
			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchAmuletActivityData, { activity_id: UI_Activity_Amulet.activityId }, (err, res: game.IResFetchAmuletActivityData) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchInfo err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchInfo', err, res);
				} else {
					let data = res.data.game;
					UI_AmuletProp.Inst.hide();
					amulet.AmuletDesktopMgr.Inst.InitGameData(data);
					amulet.AmuletDesktopMgr.Inst.ClearDesktop();
					uiscript.UI_Activity_Amulet.needFetch = true;
					uiscript.UI_AmuletHome.Inst.show();
					this.Close();
					if (onComplete != null) {
						onComplete();
					}
				}
			});
		}

		private AddAmulet() {
			let sid: string = this.meUI.input_amulet_id.text;
			if (sid == '') return;
			let amulet_id: number = parseInt(sid);
			let d_data = cfg.amulet.amulet_effect.get(amulet_id);
			if (d_data == null) {
				UIMgr.Inst.ShowErrorInfo('输入错误，表里找不到这个护身符');
				return;
			}
			let val = this.meUI.input_amulet_val.text;
			let scores = [];
			if (val != '') {
				let valLst = val.split(',');
				for (let i = 0; i < valLst.length; i++) {
					scores.push(valLst[i]);
				}
			}

			app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivityFetchDebug, {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res: game.IResFetchAmuletActivityDebug) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.effect) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					let effects = msg.game.effect.effect_list || [];
					// for (let i = 0; i < effects.length; i++) {
					// 	if (effects[i].id == amulet_id) {
					// 		UIMgr.Inst.ShowErrorInfo('输入错误，场上有这个护身符了，不可重复');
					// 		return;
					// 	}
					// }

					let uid = -1;
					for (let i = 0; i < 20; i++) {
						let _uid = Math.floor(Math.random() * 1000000 + 10000);
						let haved = false;
						for (let j = 0; j < effects.length; j++) {
							if (effects[j].uid == _uid) {
								haved = true;
								break;
							}
						}
						if (!haved) {
							uid = _uid;
							break;
						}
					}
					if (uid != -1) {
						effects.push({
							id: amulet_id,
							uid: uid,
							store: scores,
							volume: 1
						});
						msg.game.effect.effect_list = effects;
						app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.amuletActivityDebug, {
							activity_data: msg
						}, (err, res) => {
							if (err || res['error']) {
								app.Log.Error('amuletActivityDebug err');
								UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
							} else {
								this.UpdateAmuletData();
							}
						});
					}
				}
			});
		}

		private ChangeShopAmuletSelect() {
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (msg.game.stage != 4 && msg.game.stage != 5) {
						UIMgr.Inst.ShowErrorInfo('此方法只能在商店使用，此时不是在商店，不能使用，stage不对');
						return;
					}
					if (msg.game.shop == null) {
						UIMgr.Inst.ShowErrorInfo('此方法只能在商店使用，此时不是在商店，不能使用，shop数据不存在');
						return;
					}
					let shop_amulets = this.meUI.input_shop_amulet.text;
					let shop_badges = this.meUI.input_shop_badge.text;
					if (shop_amulets == '') {
						return;
					}
					let amulets: game.IAmuletEffectCandidate[] = [];
					let amulet_id_list = shop_amulets.split(',');
					let badge_id_list = shop_badges.split(',');
					let recordPack: game.IAmuletEffectCounterData[] = [];
					if (msg.game.record && msg.game.record.effect_counter) {
						recordPack = msg.game.record.effect_counter;
					}
					if (!msg.game.record) {
						msg.game.record = {} as game.IAmuletGameRecordData;
					}
					for (let i = 0; i < amulet_id_list.length; i++) {
						let effect: game.IAmuletEffectCandidate = {
							id: parseInt(amulet_id_list[i]),
							badge_id: badge_id_list[i] ? parseInt(badge_id_list[i]) : null
						};
						amulets.push(effect);
					}
					for (let i = 0; i < amulets.length; i++) {
						let amulet_id = amulets[i].id;
						let d_data = cfg.amulet.amulet_effect.get(amulet_id);
						if (d_data == null) {
							UIMgr.Inst.ShowErrorInfo('输入错误，表里找不到这个护身符');
							return;
						}
						if (amulets[i].badge_id) {
							let d_data2 = cfg.amulet.amulet_badge.get(amulets[i].badge_id);
							if (d_data2 == null) {
								UIMgr.Inst.ShowErrorInfo('输入错误，表里找不到这个印章');
								return;
							}
						}
						let isFind = false;
						for (let i = 0; i < recordPack.length; i++) {
							if (recordPack[i].effect_id == amulet_id) {
								if (!recordPack[i].pack_candidate_count) recordPack[i].pack_candidate_count = 0;
								recordPack[i].pack_candidate_count++;
								isFind = true;
								break;
							}
						}
						if (!isFind) {
							recordPack.push({ effect_id: amulet_id, pack_candidate_count: 1, gain_count: 0 });
						}
					}
					msg.game.record.effect_counter = recordPack;
					msg.game.shop.candidate_effect_list = amulets;
					msg.game.stage = 5;
					this.Close()
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private SetCoin() {
			let scoin = this.meUI.input_coin.text;
			if (scoin == '') return;
			let coin_value: number = parseInt(scoin);
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;

					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.game) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					msg.game.game.coin = coin_value.toString();
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private OpenMountain() {
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					if (msg.game.round.desktop) msg.game.round.desktop_remain = msg.game.round.desktop.length;
					msg.game.round.show_desktop = [];
					msg.game.round.show_desktop_tiles = [];
					let lockedTiles = msg.game.round.locked_tile || [];
					for (let i = 0; i < msg.game.round.desktop.length; i++) {
						msg.game.round.show_desktop.push(msg.game.round.desktop[i]);
						msg.game.round.show_desktop_tiles.push({
							id: msg.game.round.desktop[i],
							pos: msg.game.round.desktop.length + lockedTiles.length - i - 1
						});
					}
					if (msg.game.round.locked_tile) {
						for (let i = 0; i < msg.game.round.locked_tile.length; i++) {
							msg.game.round.show_desktop.push(msg.game.round.locked_tile[i]);
							msg.game.round.show_desktop_tiles.push({
								id: msg.game.round.locked_tile[i],
								pos: msg.game.round.locked_tile.length - i - 1
							});
						}
					}
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private GetPaiList(str: string) {
			let lst = [];
			if (str == '') return lst;
			let type = '';
			for (let i = str.length - 1; i >= 0; i--) {
				let c = str[i];
				if (c.charCodeAt(0) >= '0'.charCodeAt(0) && c.charCodeAt(0) <= '9'.charCodeAt(0)) {
					if (type != '') {
						lst.push(c + type);
					}
				} else {
					type = c;
				}
			}
			return lst.reverse();
		}

		private SetHands() {
			let shands = this.meUI.input_hands.text;
			let paiLst = this.GetPaiList(shands);
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					let pool = {} as any;
					for (let i = 0; i < msg.game.round.pool.length; i++) {
						let id = msg.game.round.pool[i].id;
						let tile = msg.game.round.pool[i].tile
						if (pool[tile] == null) {
							pool[tile] = [];
						}
						pool[tile].push(id);
					}
					let used_id = {}
					for (let i = 0; i < msg.game.round.desktop.length; i++) {
						used_id[msg.game.round.desktop[i]] = true
					}
					let new_hands = [];
					for (let i = 0; i < paiLst.length; i++) {
						let pai = paiLst[i];
						if (pool[pai] == null) {
							UIMgr.Inst.ShowErrorInfo('输入错误，不存在牌' + pai);
							return;
						}
						let id = -1;
						for (let j = 0; j < pool[pai].length; j++) {
							if (!used_id[pool[pai][j]]) {
								id = pool[pai][j];
								break;
							}
						}
						if (id != -1) {
							new_hands.push(id);
							used_id[id] = true;
						} else {
							UIMgr.Inst.ShowErrorInfo('输入错误，牌' + pai + '找不到合适的id，张数超过上限');
							return;
						}
					}
					if (new_hands.length == 0) {
						UIMgr.Inst.ShowErrorInfo('输入错误，牌数量不符合要求：' + new_hands.length);
						return;
					}
					let mings = msg.game.round.ming || [];
					if (msg.game.stage == 2 && mings.length * 3 + new_hands.length != 13) {
						UIMgr.Inst.ShowErrorInfo('当前为换牌阶段；请检查手牌数量是否为13张');
						return;
					}
					if (msg.game.stage == 3 && mings.length * 3 + new_hands.length != 14) {
						UIMgr.Inst.ShowErrorInfo('当前为打牌阶段；请检查手牌数量是否为14张');
						return;
					}
					msg.game.round.hands = new_hands;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private SetPaiShan() {
			let str = this.meUI.input_paishan.text;
			let mountain = [];
			let open = [];
			let s = '';
			let inFang = false;
			for (let i = 0; i < str.length; i++) {
				let c = str[i];
				if (c == '[') {
					if (s != '') {
						let lst = this.GetPaiList(s);
						for (let j = 0; j < lst.length; j++) {
							mountain.push(lst[j]);
							open.push(!inFang);
						}
						s = ''
					}
					inFang = true;
				} else if (c == ']') {
					if (s != '') {
						let lst = this.GetPaiList(s);
						for (let j = 0; j < lst.length; j++) {
							mountain.push(lst[j]);
							open.push(!inFang);
						}
						s = ''
					}
					inFang = false;
				} else {
					s += c;
				}
			}
			if (s != '') {
				let lst = this.GetPaiList(s);
				for (let j = 0; j < lst.length; j++) {
					mountain.push(lst[j]);
					open.push(!inFang);
				}
				s = ''
			}

			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					let pool = {} as any;
					for (let i = 0; i < msg.game.round.pool.length; i++) {
						let id = msg.game.round.pool[i].id;
						let tile = msg.game.round.pool[i].tile
						if (pool[tile] == null) {
							pool[tile] = [];
						}
						pool[tile].push(id);
					}
					let used_id = {}
					for (let i = 0; i < msg.game.round.hands.length; i++) {
						used_id[msg.game.round.hands[i]] = true;
					}
					if (msg.game.round.locked_tile) {
						for (let i = 0; i < msg.game.round.locked_tile.length; i++) {
							used_id[msg.game.round.locked_tile[i]] = true;
						}
					}
					let new_mountian = [];
					for (let i = 0; i < mountain.length; i++) {
						let pai = mountain[i];
						if (pool[pai] == null) {
							UIMgr.Inst.ShowErrorInfo('输入错误，不存在牌' + pai);
							return;
						}
						let id = -1;
						for (let j = 0; j < pool[pai].length; j++) {
							if (!used_id[pool[pai][j]]) {
								id = pool[pai][j];
								break;
							}
						}
						if (id != -1) {
							new_mountian.push(id);
							used_id[id] = true;
						} else {
							UIMgr.Inst.ShowErrorInfo('输入错误，牌' + pai + '找不到合适的id，张数超过上限');
							return;
						}
					}
					if (new_mountian.length == 0) {
						UIMgr.Inst.ShowErrorInfo('输入错误，牌数量不符合要求：' + new_mountian.length);
						return;
					}
					let lockTiles = msg.game.round.locked_tile || [];
					msg.game.round.desktop = new_mountian;
					msg.game.round.show_desktop = [];
					msg.game.round.show_desktop_tiles = [];
					for (let i = 0; i < new_mountian.length; i++) {
						if (open[i]) {
							msg.game.round.show_desktop.push(new_mountian[i]);
							msg.game.round.show_desktop_tiles.push({
								id: new_mountian[i],
								pos: msg.game.round.desktop.length + lockTiles.length - i - 1
							});
						}
					}
					if (msg.game.round.locked_tile) {
						for (let i = 0; i < msg.game.round.locked_tile.length; i++) {
							msg.game.round.show_desktop.push(msg.game.round.locked_tile[i]);
							msg.game.round.show_desktop_tiles.push({
								id: msg.game.round.locked_tile[i],
								pos: msg.game.round.locked_tile.length - i - 1
							});
						}
					}
					msg.game.round.desktop_remain = msg.game.round.desktop.length;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private SetBossBuff() {
			let bossBuff = this.meUI.input_boss_buff.text;
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res: game.IResFetchAmuletActivityDebug) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.game || !msg.game.effect) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					msg.game.game.next_boss_buff = [];
					if (bossBuff != '') {
						let buffs = bossBuff.split(',');
						for (let i = 0; i < buffs.length; i++) {
							if (!cfg.amulet.amulet_buff.get(parseInt(buffs[i]))) {
								UIMgr.Inst.ShowErrorInfo('不合法的buffId');
								return;
							}
							msg.game.game.next_boss_buff.push(parseInt(buffs[i]));
						}
					}
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private SetPoint() {
			let pointStr = this.meUI.input_score.text;
			let pointExtraStr = this.meUI.score_extra.text;
			if (pointStr == '') return;
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					if (pointExtraStr != '0' && pointExtraStr != '') {
						if (Number(pointStr) >= 10) {
							UIMgr.Inst.ShowErrorInfo(pointStr + ' >= 10，不符合规范，请将前面的值改为整数部分小于10的数或将第二个值清除');
							return;
						}
						if (pointExtraStr.length > 4) {
							UIMgr.Inst.ShowErrorInfo('debug不支持这么大的数');
							return;
						}
						pointStr += 'e+';
						pointStr += pointExtraStr;
					} else {
						if (pointStr.indexOf('.') != -1) {
							UIMgr.Inst.ShowErrorInfo(pointStr + ' 中含有小数，请检查输入');
							return;
						}
					}
					msg.game.round.point = pointStr;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private SetPaiPoint() {
			let paiStr = this.meUI.paiScoreName.text;
			let pointStr = this.meUI.paiScoreScore.text;
			if (paiStr == '') return;
			if (pointStr == '') return;
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.game.tile_score_map) msg.game.game.tile_score_map = [];
					if (msg.game.game.tile_score_map.findIndex(tile => tile.tile == paiStr) >= 0) {
						msg.game.game.tile_score_map[msg.game.game.tile_score_map.findIndex(tile => tile.tile == paiStr)].score = pointStr;
					} else {
						msg.game.game.tile_score_map.push({ tile: paiStr, score: pointStr });
					}
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}


		private SetLevel() {
			let levelStr = this.meUI.input_level.text;
			if (levelStr == '') return;
			let levelID = parseInt(levelStr);
			let dTable = cfg.amulet.amulet_games.getGroup(amulet.AmuletDesktopMgr.activityId);
			let inputOK = false;
			for (let i = 0; i < dTable.length; i++) {
				if (dTable[i].level == levelID) {
					inputOK = true;
				}
			}
			if (!inputOK) {
				UIMgr.Inst.ShowErrorInfo('输入错误，没有找到关卡ID：' + levelStr);
				return;
			}
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					msg.game.game.level = levelID;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private ChangeDora() {
			let str = this.meUI.dora_input.text;
			let doraStr = [];
			let s = '';
			let inFang = false;
			for (let i = 0; i < str.length; i++) {
				let c = str[i];
				s += c;
			}
			if (s != '') {
				let lst = this.GetPaiList(s);
				for (let j = 0; j < lst.length; j++) {
					doraStr.push(lst[j]);
				}
				s = ''
			}

			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					let pool = {} as any;
					for (let i = 0; i < msg.game.round.pool.length; i++) {
						let id = msg.game.round.pool[i].id;
						let tile = msg.game.round.pool[i].tile
						if (pool[tile] == null) {
							pool[tile] = [];
						}
						pool[tile].push(id);
					}
					let used_id = {}
					if (msg.game.round.hands) {
						for (let i = 0; i < msg.game.round.hands.length; i++) {
							used_id[msg.game.round.hands[i]] = true;
						}
					}

					if (msg.game.round.desktop) {
						for (let i = 0; i < msg.game.round.desktop.length; i++) {
							used_id[msg.game.round.desktop[i]] = true;
						}
					}
					if (msg.game.round.locked_tile) {
						for (let i = 0; i < msg.game.round.locked_tile.length; i++) {
							used_id[msg.game.round.locked_tile[i]] = true;
						}
					}
					if (msg.game.round.used) {
						for (let i = 0; i < msg.game.round.used.length; i++) {
							used_id[msg.game.round.used[i]] = true;
						}
					}
					if (msg.game.round.ming) {
						for (let i = 0; i < msg.game.round.ming.length; i++) {
							for (let j = 0; j < msg.game.round.ming[i].tile_list.length; j++) {
								used_id[msg.game.round.ming[i].tile_list[j]] = true;
							}
						}
					}
					let new_mountain = msg.game.round.mountain.concat([]);
					let newDora = [];
					for (let i = 0; i < doraStr.length; i++) {
						let pai = doraStr[i];
						if (pool[pai] == null) {
							UIMgr.Inst.ShowErrorInfo('输入错误，不存在牌' + pai);
							return;
						}
						let id = -1;
						for (let j = 0; j < pool[pai].length; j++) {
							if (!used_id[pool[pai][j]]) {
								id = pool[pai][j];
								break;
							}
						}
						if (id != -1) {
							if (new_mountain.indexOf(id) == -1) {
								new_mountain.push(id);
							}
							newDora.push(id);
							used_id[id] = true;
						} else {
							UIMgr.Inst.ShowErrorInfo('输入错误，牌' + pai + '找不到合适的id，张数超过上限');
							return;
						}
					}
					msg.game.round.dora = newDora;
					msg.game.round.mountain = new_mountain;

					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private ChangeHunpai() {
			let str = this.meUI.hunpai_input.text;
			let new_tianpai = [];
			let s = '';
			for (let i = 0; i < str.length; i++) {
				let c = str[i];
				s += c;
			}
			if (s != '') {
				let lst = this.GetPaiList(s);
				for (let j = 0; j < lst.length; j++) {
					new_tianpai.push(lst[j]);
				}
				s = ''
			}

			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					if (msg.game == null || msg.game.ended || !msg.game.stage) {
						UIMgr.Inst.ShowErrorInfo('对局信息没有，可能是没有开始，不能修改数据');
						return;
					}
					if (!msg.game.round) {
						UIMgr.Inst.ShowErrorInfo('未在打牌中');
						return;
					}
					msg.game.round.tian_dora = new_tianpai;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private OpenOverview() {
			app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityFetchDebug', {
				activity_id: UI_Activity_Amulet.activityId
			}, (err, res) => {
				if (err || res['error']) {
					app.Log.Error('amuletActivityFetchDebug err');
					UIMgr.Inst.showNetReqError('amuletActivityFetchDebug', err, res);
				} else {
					let msg = JSON.parse(JSON.stringify(res)).activity_data as game.IActivityAmuletData;
					let lst = [];
					cfg.amulet.amulet_effect.forEach((effect) => {
						if (!effect.deprecated) {
							lst.push(effect.id);
						}
					})
					let lst2 = [];
					cfg.amulet.amulet_badge.forEach((badge) => {
						if (!badge.deprecated) {
							lst2.push(badge.id);
						}
					})
					msg.illustrated_book.effect_collection = lst;
					msg.illustrated_book.badge_collection = lst2;
					if (!msg.statistic) {
						msg.statistic = {} as game.IActivityAmuletStatisticData;
					}
					msg.statistic.highest_level = 1001;
					app.NetAgent.sendReq2Lobby('Lobby', 'amuletActivityDebug', {
						activity_data: msg
					}, (err, res) => {
						if (err || res['error']) {
							app.Log.Error('amuletActivityDebug err');
							UIMgr.Inst.showNetReqError('amuletActivityDebug', err, res);
						} else {
							this.UpdateAmuletData();
						}
					});
				}
			});
		}

		private TestPoint(force: boolean = false) {
			let pointStr = this.meUI.testscore1.text;
			let pointExtraStr = this.meUI.testscore2.text;
			if (pointStr == '') return;
			if (pointExtraStr != '0' && pointExtraStr != '') {
				if (Number(pointStr) >= 10) {
					if (force) UIMgr.Inst.ShowErrorInfo(pointStr + ' >= 10，不符合规范，请将前面的值改为整数部分小于10的数或将第二个值清除');
					return;
				}
				if (Number(pointExtraStr) == Infinity) {
					if (force) UIMgr.Inst.ShowErrorInfo('不支持这么大的数');
					return;
				}
				pointStr += 'e+';
				pointStr += pointExtraStr;
			} else {
				if (pointStr.indexOf('.') != -1) {
					if (force) UIMgr.Inst.ShowErrorInfo(pointStr + ' 中含有小数，请检查输入');
					return;
				}
			}
			this.meUI.testresult.text = SciNum.getSciStr(pointStr, 6);
			let types = ['', '', 'ww_', 'rank1_', 'rank_', 'fan_'];
			for (let j = 1; j <= 5; j++) {
				let parent = this.meUI['container_score' + j];
				let templete = parent.getChildAt(0).scriptMap['capsui.UICopy'] as capsui.UICopy;
				parent._childs.forEach(imgScore => imgScore.skin = '');
				let pointStrs = SciNum.getSciImgStrs(pointStr, 6);
				for (let i = 0; i < pointStrs.length; i++) {
					let url = game.Tools.localUISrc('myres/amulet/number/' + types[j] + pointStrs[i] + '.png');
					let imgScore = parent.getChildAt(i) as Laya.Image;
					if (!imgScore) {
						imgScore = templete.getNodeClone() as Laya.Image;
						parent.addChild(imgScore);
					}
					imgScore.skin = url;
					imgScore.x = 80 * i;
				}
			}

		}

	}
}