module uiscript {
    export class UI_AmuletRank extends UI_PopupBase {
        public static Inst: UI_AmuletRank;
        private nolimitlst: capsui.NoLimitList;
        private next_index: number = 0;
        private rankDatas: game.IResFetchActivityRank[] = [];
        private rank_list: Array<game.IResFetchActivityRank_ActivityRankItem> = [];
        private mineData: game.IResFetchActivityRank_ActivityRankItem;
        private userDataList: Array<game.IPlayerBaseView> = [];
        private empty: Laya.Label;
        private comSelf: Laya.Sprite;
        private contentPanel: Laya.Panel;
        private comBtns: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabCodes: Array<number> = [20085, 20086];
        private tabButtons: Array<Amulet_TabButton>;
        private isFriend: boolean;
        private selfHead: UI_Head;

        /**
         * 请求刷新的限制时长
         */
        public static refreshLimit: number = 3000;

        private lockNetWork: boolean;
        private fetchIndex: number = 0;

        constructor() {
            super(new ui.amulet.amulet_rankUI());
            UI_AmuletRank.Inst = this;
        }

        onCreate() {
            super.onCreate();
            this.outClose = true;
            this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            this.empty = this.root.getChildByName('empty') as Laya.Label;
            this.comSelf = this.root.getChildByName('self') as Laya.Sprite;
            let headSprite: Laya.Sprite = this.comSelf.getChildByName('head') as Laya.Sprite;
            this.selfHead = new UI_Head(headSprite, "UI_Amulet_Rank");
            let content = this.root.getChildByName('content') as Laya.Sprite;
            this.nolimitlst = content.scriptMap['capsui.NoLimitList'];
            this.nolimitlst.init_nolimitlist(
                Laya.Handler.create(this, this.load_next, null, false),
                Laya.Handler.create(this, this.render_item, null, false));
            this.contentPanel = content.getChildByName("content") as Laya.Panel;
            this.tabGroups = new UI_TabGroup_Base(this, () => {
                return this.lockNetWork;
            });
            this.tabButtons = new Array<Amulet_TabButton>();
            let tabsName = ['all', 'friend'];
            this.comBtns = this.root.getChildByName("tabs") as Laya.Sprite;
            for (let i = 0; i < 2; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                let tabName = btn.getChildByName("title") as Laya.Label;
                tabName.text = game.Tools.strOfLocalization(this.tabCodes[i]);
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Amulet_TabButton(btn);
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.refreshList();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        private refreshList() {
            this.loadRankData();
            this.freshPage();
        }

        public reset() {
            //进入房间时，重置之前的数据
            this.rankDatas = [null, null];
            this.rank_list = [];
            this.mineData = null;
            this.userDataList = [];
            this.next_index = 0;
            this.nolimitlst.reset();
            this.fetchIndex++;
        }

        public show() {
            super.show();
            this.reset();
            this.tabGroups.init();
            this.loadRankData();
            this.freshPage();
        }

        private freshPage() {
            if (this.rank_list.length == 0) {
                this.showEmpty();
            }
            this.renderMe();
        }

        public hide() {
            super.hide();
        }

        private loadRankData() {
            this.isFriend = this.tabGroups.selectedIndex == 1;
            this.userDataList = [];
            this.nolimitlst.reset();
            this.next_index = 0;
            let friendIds = [];
            if (this.isFriend) {
                friendIds = game.FriendMgr.friend_list.map((value) => value.base.account_id);
            }
            if (this.rankDatas[this.tabGroups.selectedIndex]) {
                let res = this.rankDatas[this.tabGroups.selectedIndex];
                this.mineData = res.self;
                this.rank_list = res.items;
                this.empty.visible = this.rank_list.length == 0;
                this.freshPage();
                if (this.rank_list.length > 0) {
                    this.nolimitlst.total_count = 1;
                }
                return;
            }
            let request: game.IReqFetchActivityRank = {
                activity_id: UI_Activity_Amulet.activityId,
                account_list: friendIds
            };
            let index = this.tabGroups.selectedIndex;
            let isFriend = this.isFriend;
            this.lockNetWork = true;
            this.fetchIndex++;
            let fetchIndex = this.fetchIndex;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.fetchActivityRank, request, (err, res: game.IResFetchActivityRank) => {
                this.lockNetWork = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('fetchContestPlayerRank', err, res);
                    this.nolimitlst.loadOver(false, 0);
                    this.showEmpty();
                } else {
                    // app.Log.log("fetchContestPlayerRank" + JSON.stringify(res));
                    let data: game.IResFetchActivityRank = game.Tools.deepCopy(res);
                    data.items = ((!isFriend || friendIds.length > 0) && data.items) ? data.items : [];
                    data.self = data.self || {
                        account_id: GameMgr.Inst.account_id,
                        score: 0,
                        /** json字符串,排行榜额外信息 */
                        data: '',
                        /** 排名 */
                        rank: 10000
                    };
                    data.self.account_id = GameMgr.Inst.account_id;
                    if (isFriend) {
                        data.items.push(data.self);
                        data.items.sort((a, b) => {
                            let scoreA = SciNum.createSciNum();
                            let levelA = 0;
                            let propA = 0;
                            let scoreB = SciNum.createSciNum();
                            let levelB = 0;
                            let propB = 0;
                            if (a.data && a.data != '') {
                                let dataA = this.getJsonParseStr(a.data);
                                scoreA = SciNum.createSciNumByStr(dataA.point || '0');
                                levelA = Number(dataA.level);
                                propA = Number(dataA.effect_count);
                            }
                            if (b.data && b.data != '') {
                                let dataB = this.getJsonParseStr(b.data);
                                scoreB = SciNum.createSciNumByStr(dataB.point || '0');
                                levelB = Number(dataB.level);
                                propB = Number(dataB.effect_count);
                            }
                            if (levelB != levelA) return levelB - levelA;
                            if (scoreA != scoreB) return SciNum.compare(scoreB, scoreA);
                            return propB - propA;
                        });
                        data.self.rank = data.items.findIndex((rankData) => { return rankData.account_id == GameMgr.Inst.account_id; }) + 1;
                    }
                    this.rankDatas[index] = data;
                    if (fetchIndex == this.fetchIndex) {
                        this.mineData = data.self;
                        this.rank_list = data.items;
                        this.empty.visible = this.rank_list.length == 0;
                        this.freshPage();
                        if (this.rank_list.length > 0) {
                            this.nolimitlst.total_count = 1;
                        }
                    }
                }
            });
        }


        private isListLoading: boolean = false;
        private load_next() {
            if (this.isListLoading) {
                this.nolimitlst.loadOver(false, 0);
                return;
            }
            let accountList: Array<number> = [];
            let deltaCount = this.rank_list.length - this.next_index;
            if (deltaCount == 0) {
                this.nolimitlst.loadOver(false, 0);
                return;
            }
            deltaCount = Math.min(20, deltaCount);
            for (let i = 0; i < deltaCount; i++) {
                accountList.push(this.rank_list[i + this.next_index].account_id);
            }
            let request: game.IReqMultiAccountId = {
                account_id_list: accountList
            };

            this.isListLoading = true;
            //加载用户信息，因为用户信息在中心服，所以需要另外发送信息
            // app.Log.log("rqs ProtoCode.FETCH_MULTI_ACCOUNT_BRIEF" + JSON.stringify(request));
            this.lockNetWork = true;
            let fetchIndex = this.fetchIndex;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.FETCH_MULTI_ACCOUNT_BRIEF, request, (err, res: game.IResMultiAccountBrief) => {
                this.lockNetWork = false;
                this.isListLoading = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(ProtoCode.FETCH_MULTI_ACCOUNT_BRIEF, err, res);
                    this.nolimitlst.loadOver(false, 0);
                } else {
                    if (fetchIndex != this.fetchIndex) {
                        this.nolimitlst.loadOver(false, 0);
                        return;
                    }
                    // app.Log.log("res ProtoCode.FETCH_MULTI_ACCOUNT_BRIEF" + JSON.stringify(res));

                    //新获得了多少个数据
                    this.next_index += res.players.length;
                    let delta_count: number = 0;
                    if (res.players) {
                        delta_count = res.players.length;
                        for (let index = 0; index < accountList.length; index++) {
                            let account = accountList[index];
                            let data = res.players.find((v) => {
                                return v.account_id == account;
                            })
                            this.userDataList.push(data);
                        }
                    }
                    if (delta_count > 0) {
                        this.nolimitlst.total_count = this.rank_list.length + 1;
                        this.nolimitlst.loadOver(true, delta_count);
                    } else {
                        this.nolimitlst.total_count = this.rank_list.length;
                        this.nolimitlst.loadOver(true, delta_count);
                    }

                }

            });
        }

        private render_item(data) {
            let index: number = data.index;
            let container: Laya.Sprite = data.container;
            let cacheData = data.cache_data as any;
            let itemData = this.rank_list[index];
            let userData = this.userDataList[index];
            let comRank = container.getChildByName('rank_info') as Laya.Label;
            //显示排名
            let imgRank: Laya.Image = comRank.getChildByName('rank_img') as Laya.Image;
            let bgRank: Laya.Image = container.getChildByName('bg') as Laya.Image;
            let bgRank2: Laya.Image = container.getChildByName('bg1') as Laya.Image;
            let comRankImg: Laya.Sprite = comRank.getChildByName('rank') as Laya.Sprite;
            comRankImg.visible = index >= 3;
            if (index < 3) {
                imgRank.visible = true;
                imgRank.skin = game.Tools.localUISrc('myres/amulet/rank_icon' + (index + 1).toString() + '.png');
                bgRank.skin = game.Tools.localUISrc('myres/amulet/rank_bg' + (index + 1).toString() + '.png');
                bgRank2.skin = game.Tools.localUISrc('myres/amulet/popup_rank_bg_top_three.png');
            } else {
                let rankString = (index + 1).toString();
                imgRank.skin = game.Tools.localUISrc('myres/amulet/rank_icon4.png');
                bgRank.skin = game.Tools.localUISrc('myres/amulet/rank_bg4.png');
                bgRank2.skin = game.Tools.localUISrc('myres/amulet/popup_rank_bg_normal.png');
                let strRank = SciNum.getSciImgStrs(rankString, 6);
                this.renderRank(comRankImg, strRank, false);
            }
            //显示头像
            let headSprite: Laya.Sprite = container.getChildByName('head') as Laya.Sprite;
            if (!cacheData.head) {
                cacheData.head = new UI_Head(headSprite, "UI_Match_Room");
            }

            if (itemData.account_id == GameMgr.Inst.account_id) {
                cacheData.head.id = userData.avatar_id;
            } else {
                cacheData.head.id = game.GameUtility.get_limited_skin_id(userData.avatar_id);
            }

            cacheData.head.set_head_frame(itemData.account_id, userData.avatar_frame);

            //点击头像，显示信息界面
            let btn_head: Laya.Button = container.getChildByName('btn_see') as Laya.Button;
            btn_head.clickHandler = Laya.Handler.create(this, () => {
                let showExtraConfig: IPlayerInfoShowConfig = {
                    accountId: itemData.account_id,
                    pageIndex: EPlayerInfoPage.liqi4,
                    gameCategory: EPlayerInfoGameCategory.matching,
                    gameType: EPlayerInfoGameType.rank,
                    nameReplace: GameMgr.Inst.hide_nickname ? game.Tools.strOfLocalization(3060) : ''
                }
                UI_PlayerInfo.Inst.show(showExtraConfig);
            }, null, false);
            //显示昵称
            let nameSprite: Laya.Sprite = container.getChildByName('name') as Laya.Sprite;
            game.Tools.SetNickname(nameSprite, userData, GameMgr.Inst.hide_nickname && GameMgr.Inst.hide_rank_name);
            //显示最大关
            let txtPropCount: Laya.Label = comRank.getChildByName('prop_count') as Laya.Label;
            let txtLevel: Laya.Label = comRank.getChildByName('level') as Laya.Label;
            txtPropCount.text = this.getPropCount(itemData);
            txtLevel.text = this.getLevel(itemData);
            let comScore: Laya.Sprite = comRank.getChildByName('score') as Laya.Sprite;
            this.renderScore(comScore, this.getScore(itemData), index + 1);
        }

        private renderMe() {
            this.comSelf.visible = true;
            //显示头像
            this.selfHead.id = UI_Sushe.main_chara_info.skin;
            this.selfHead.set_head_frame(GameMgr.Inst.account_data['account_id'], GameMgr.Inst.account_data['avatar_frame']);

            //显示昵称
            let nameSprite: Laya.Sprite = this.comSelf.getChildByName('name') as Laya.Sprite;
            game.Tools.SetNickname(nameSprite, GameMgr.Inst.account_data, GameMgr.Inst.hide_nickname && GameMgr.Inst.hide_rank_name);
            //点击头像，显示信息界面
            let btn_head: Laya.Button = this.comSelf.getChildByName('btn_see') as Laya.Button;
            btn_head.clickHandler = Laya.Handler.create(this, () => {
                let showExtraConfig: IPlayerInfoShowConfig = {
                    accountId: GameMgr.Inst.account_data['account_id'],
                    pageIndex: 1,
                    gameCategory: 1,
                    gameType: 1,
                    nameReplace: GameMgr.Inst.hide_nickname ? game.Tools.strOfLocalization(3060) : ''
                }
                UI_PlayerInfo.Inst.show(showExtraConfig);
            }, null, false);
            let comRank = this.comSelf.getChildByName('rank_info') as Laya.Label;
            //显示排名
            let imgRank: Laya.Image = comRank.getChildByName('rank_img') as Laya.Image;
            let comRankImg: Laya.Sprite = comRank.getChildByName('rank') as Laya.Sprite;
            let rank = this.isFriend && this.rank_list.length == 1 ? 1 : this.mineData && this.mineData.rank ? this.mineData.rank : 1000;
            comRankImg.visible = rank > 3;
            if (rank <= 3) {
                imgRank.skin = game.Tools.localUISrc('myres/amulet/rank_icon' + rank.toString() + '.png');
            } else {
                let rankString = rank >= 999 ? '999' : rank.toString();
                let isOut999 = rank >= 999;
                imgRank.skin = '';
                let strRank = SciNum.getSciImgStrs(rankString, 6);
                if (isOut999) strRank.push('add');
                this.renderRank(comRankImg, strRank, true);
            }
            let txtPropCount: Laya.Label = comRank.getChildByName('prop_count') as Laya.Label;
            let txtLevel: Laya.Label = comRank.getChildByName('level') as Laya.Label;
            txtPropCount.text = this.getPropCount(this.mineData);
            txtLevel.text = this.getLevel(this.mineData);
            let comScore: Laya.Sprite = comRank.getChildByName('score') as Laya.Sprite;
            this.renderScore(comScore, this.getScore(this.mineData), 1);
        }

        public renderScore(comScore: Laya.Sprite, score: string[], rank: number) {
            let scoreTemplteUI = (comScore.getChildAt(0) as Laya.Sprite).scriptMap['capsui.UICopy'];
            comScore._childs.forEach(imgScore => (imgScore.getChildAt(0) as Laya.Image).skin = '');
            comScore.scale(1, 1);
            if (score.length * 30 > 300) {
                comScore.scale(300 / (score.length * 30), 300 / (score.length * 30));
            }
            let startX = 160 - (score.length * 30 / 2);
            for (let i = 0; i < score.length; i++) {
                let _url = rank <= 3 ? 'myres/amulet/number/rank1_' : 'myres/amulet/number/rank_';
                let icon = score[i] == '.' ? 'point' : score[i];
                let url = game.Tools.localUISrc(_url + icon + '.png');
                if (!comScore.getChildAt(i)) {
                    let imgScore = scoreTemplteUI.getNodeClone() as Laya.Image;
                    comScore.addChild(imgScore);
                }
                ((comScore.getChildAt(i) as Laya.Sprite).getChildAt(0) as Laya.Image).skin = url;
                (comScore.getChildAt(i) as Laya.Sprite).x = startX + i * 30;
            }
        }

        public renderRank(comRank: Laya.Sprite, rankStr: string[], isMy: boolean) {
            let scoreTemplteUI = (comRank.getChildAt(0) as Laya.Sprite).scriptMap['capsui.UICopy'];
            comRank._childs.forEach(imgScore => (imgScore.getChildAt(0) as Laya.Image).skin = '');
            let lengthData = SciNum.getCharsLength(rankStr);
            let width = 30;
            let startX = isMy ? 90 : 87;
            startX = startX - (lengthData.totalL * width / 2);
            for (let i = 0; i < rankStr.length; i++) {
                let _url = isMy ? 'myres/amulet/number/rank1_' : 'myres/amulet/number/rank_';
                let icon = rankStr[i] == '.' ? 'point' : rankStr[i];
                let url = game.Tools.localUISrc(_url + icon + '.png');
                if (!comRank.getChildAt(i)) {
                    let imgScore = scoreTemplteUI.getNodeClone() as Laya.Image;
                    comRank.addChild(imgScore);
                }
                ((comRank.getChildAt(i) as Laya.Sprite).getChildAt(0) as Laya.Image).skin = url;
                (comRank.getChildAt(i) as Laya.Sprite).x = startX;
                startX += lengthData.scales[i] * width;
            }
        }

        getScore(rankData: game.IResFetchActivityRank_ActivityRankItem): string[] {
            if (!rankData || !rankData.data || rankData.data == '') return ['0'];
            let levelData = this.getJsonParseStr(rankData.data);
            let point = levelData.point || '0';
            return SciNum.getSciImgStrs(point, 6);
        }

        getPropCount(rankData: game.IResFetchActivityRank_ActivityRankItem): string {
            let totalCount = UI_AmuletOverview.Inst && UI_AmuletOverview.Inst.effectCounts ? UI_AmuletOverview.Inst.effectCounts : 0;
            if (!rankData || !rankData.data || rankData.data == '') return '0/' + totalCount;
            let levelData = this.getJsonParseStr(rankData.data);
            let count = levelData.effect_count || 0;
            count = count > totalCount ? totalCount : count;
            return count + '/' + totalCount;
        }

        // getChallengeCount(rankData: game.IResFetchActivityRank_ActivityRankItem): string {
        //     if (!rankData || !rankData.data || rankData.data == '') return '0';
        //     let levelData = this.getJsonParseStr(rankData.data);
        //     return (levelData.finished_task || 0).toString();
        // }

        getLevel(rankData: game.IResFetchActivityRank_ActivityRankItem): string {
            if (!rankData || !rankData.data || rankData.data == '') return game.Tools.strOfLocalization(20092);
            let levelData = this.getJsonParseStr(rankData.data);
            let levelConfig = uiscript.UI_Activity_Amulet.amuletLevelDic.get(levelData.level);
            if (!levelConfig) return game.Tools.strOfLocalization(20092);
            return levelConfig.level_name;
        }

        private showEmpty() {
            this.empty.visible = true;
            this.next_index = 0;
            this.rank_list = [];
            this.nolimitlst.reset();
            this.comSelf.visible = false;
        }

        public refreshAll() {
            this.nolimitlst.wantToRefreshAll();
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Amulet_Rank', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Amulet_Rank', false);
        }

        public getJsonParseStr(str: string): any {
            let obj = {
                level: 0,
                point: '0',
                effect_count: 0,
            };
            if (!str) return obj;
            try {
                obj = JSON.parse(str);
            }
            catch (ex) {
                return obj;
            }
            return obj;
        }
    }
}