/**
* name 
*/
module uiscript {
	/**
	 * 图文引导
	 */
	export class UI_Amulet_Rules extends UIBase {

		public static Inst: UI_Amulet_Rules = null;

		private root: Laya.Sprite = null;
		private blackmask: Laya.Sprite = null;

		private locking: boolean;
		private tab_index: number;

		// 前4个合宿界面介绍
		private main: Laya.Sprite;
		private img_0: Laya.Image;
		private img_1: Laya.Image;
		private img_2: Laya.Image;
		private arrow: Laya.Sprite;
		private btnMain: Laya.Button;

		// 对局规则
		private match: Laya.Sprite;
		private mid: Laya.Image;

		private chat: Laya.Sprite;
		private chat_bg: Laya.Image;
		private chat_arrow: Laya.Image;
		private chat_label: Laya.Label;
		private chatLabelDifW: number;  // label和bg的宽度差，用于适配
		private chatArrowAdapt: common.SpriteAdapter;
		private yiji: Laya.Image;
		private label_index: Laya.Label;

		private btns: Laya.Sprite;
		private pre_btn: Laya.Sprite;
		private skip_btn: Laya.Sprite;
		private next_btn: Laya.Sprite;
		private max_page: number = 4;
		private start_page: number = 0;

		private offsets: Array<number> = []; // 跳过按钮下的偏移 还有下一步按钮

		private extraConfig: IRuleExtraConfig;

		constructor() {
			super(new ui.amulet.amulet_rulesUI());
			UI_Amulet_Rules.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.blackmask = this.me.getChildByName('bmask') as Laya.Sprite;

			// 活动部分
			this.main = this.root.getChildByName('main') as Laya.Sprite;
			this.img_0 = this.main.getChildByName('0') as Laya.Image;
			this.img_1 = this.main.getChildByName('1') as Laya.Image;
			this.img_2 = this.img_1.getChildAt(0) as Laya.Image;
			this.arrow = this.main.getChildByName('arrow') as Laya.Sprite;
			// 对局
			this.match = this.root.getChildByName('match') as Laya.Sprite;

			this.mid = this.match.getChildByName('mid') as Laya.Image;
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'jp') {
				this.chat_label = this.root.getChildByName('chat').getChildByName('info_en') as Laya.Label;
				(this.root.getChildByName('chat').getChildByName('info') as Laya.Label).visible = false;
			} else {
				this.chat_label = this.root.getChildByName('chat').getChildByName('info') as Laya.Label;
				(this.root.getChildByName('chat').getChildByName('info_en') as Laya.Label).visible = false;
			}
			this.chat = this.root.getChildByName('chat') as Laya.Sprite;
			this.chat_bg = this.root.getChildByName('chat').getChildByName('bg') as Laya.Image;
			this.chat_arrow = this.root.getChildByName('chat').getChildByName('arrow') as Laya.Image;
			this.chatArrowAdapt = new common.SpriteAdapter(this.chat_arrow, this.chat_bg, SpriteAdapterType.RIGHT2RIGHT);
			this.chatLabelDifW = this.chat_bg.width - this.chat_label.width;
			this.label_index = this.root.getChildByName('index') as Laya.Label;
			this.yiji = this.root.getChildByName('chat').getChildByName('head') as Laya.Image;

			this.btns = this.me.getChildByName('btn') as Laya.Sprite;
			this.pre_btn = this.btns.getChildByName('pre') as Laya.Sprite;
			let offset_pre = (this.pre_btn.getChildAt(2) as Laya.Label).textField.textWidth - 102;
			this.pre_btn.width += offset_pre;
			this.pre_btn.x += offset_pre / 2;
			(this.pre_btn as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.changeTab(this.tab_index - 1);
			});

			let next = new Laya.Handler(this, () => {
				if (this.locking) return;
				if (this.tab_index == this.max_page - 1) {
					this.close();
				} else {
					this.changeTab(this.tab_index + 1);
				}
			});
			(this.root.getChildByName('chat').getChildByName('next') as Laya.Button).clickHandler = next;
			this.skip_btn = this.btns.getChildByName('skip') as Laya.Sprite;
			(this.skip_btn as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.close();
			});


			this.next_btn = this.btns.getChildByName('next') as Laya.Sprite;
			(this.next_btn as Laya.Button).clickHandler = next;
			this.btnMain = this.img_0.getChildByName('btn') as Laya.Button;
			this.btnMain.visible = false;
			this.btnMain.clickHandler = next;
			this.enable = false;

			// 适配下一步按钮和跳过按钮
			{
				for (let i = 0; i < 2; i++) {
					let child = this.skip_btn.getChildAt(i) as Laya.Sprite;
					let offset = (child.getChildAt(2) as Laya.Label).textField.textWidth - 68;
					child.width += offset;
					child.x += offset;
					this.offsets.push(offset);
				}
				let child = this.next_btn.getChildAt(0) as Laya.Sprite;
				let offset = (child.getChildAt(2) as Laya.Label).textField.textWidth - 102;
				child.width += offset;
				child.x += offset;
				this.offsets.push(offset);

				child = this.next_btn.getChildAt(1) as Laya.Sprite;
				offset = ((child.getChildAt(1) as Laya.Label).textField.textWidth - 136) / 2;
				child.width += offset;
				child.x += offset;
				this.offsets.push(offset);
			}
		}

		public show(extraConfig?: IRuleExtraConfig) {
			this.extraConfig = extraConfig;
			this.locking = true;
			this.enable = true;
			this.start_page = 0;
			this.max_page = 4;
			UIBase.anim_alpha_in(this.root, {}, 200, 0, Laya.Handler.create(this, () => {
				this.locking = false;
			}));
			this.blackmask.alpha = 0;
			Laya.Tween.to(this.blackmask, { alpha: 0.7 }, 150);
			UIBase.anim_alpha_in(this.btns, {}, 200);
			this.tab_index = -1;
			this.changeTab(this.start_page);
			Laya.loader.load(game.Tools.localUISrc('extendRes/emo/e200001/l_1.png'));
			Laya.loader.load(game.Tools.localUISrc('extendRes/emo/e200001/l_2.png'));
		}

		private changeTab(index: number) {

			if (index == this.tab_index) return;
			this.tab_index = index;
			let showIndex = index + 1 - this.start_page;
			let maxIndex = this.max_page - this.start_page;
			this.label_index.text = '(' + showIndex + '/' + maxIndex + ')';
			let valign_b: boolean = true; // true 为对话在下，false为在上
			this.chat.pos(80, 600);
			this.img_2.scale(1, 1);
			let chatBgWidth: number = 1277; // 对话背景宽度 
			(this.root.getChildByName('chat').getChildByName('next') as Laya.Button).mouseEnabled = false;
			// TODO可能需要做一个lock
			switch (this.tab_index) {
				case 0: {
					this.main.visible = true;
					this.match.visible = false;
					this.setImgSkin('myres/amulet/rules/1.png');
					this.img_0.pos(53, 63);
					this.img_0.size(1123, 648);
					this.arrow.visible = false;
					this.img_1.visible = false;
					this.img_2.skin = '';
					this.chat.pos(-129, 630);
					this.yiji.pos(1400, -168);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_1.png');
					chatBgWidth = 1278;
					break;
				}
				case 1: {
					this.main.visible = true;
					this.match.visible = false;
					this.setImgSkin('myres/amulet/rules/2.png');
					this.img_0.pos(108, 417);
					this.img_0.size(1488, 524);
					this.arrow.visible = false;
					this.img_1.visible = false;
					this.img_2.skin = '';
					valign_b = false;
					this.chat.pos(-73, 125);
					this.yiji.pos(-29, -127);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					chatBgWidth = 1468;
					break;
				}
				case 2: {

					this.main.visible = true;
					this.match.visible = false;
					this.setImgSkin('myres/amulet/rules/3.png');
					this.img_0.pos(380, 68);
					this.img_0.size(1294, 840);

					this.arrow.visible = false;
					this.img_1.visible = false;
					this.img_2.skin = '';

					chatBgWidth = 1054;
					this.chat.pos(46, 630);
					this.yiji.pos(-29, -168);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');

					valign_b = true;
					break;
				}
				case 3: {
					this.main.visible = true;
					this.match.visible = false;
					this.setImgSkin('myres/amulet/rules/4.png');
					this.img_0.pos(380, 68);
					this.img_0.size(1294, 840);
					this.arrow.visible = false;
					this.img_1.visible = false;
					this.img_2.skin = '';

					chatBgWidth = 1054;
					this.chat.pos(46, 630);
					this.yiji.pos(-29, -168);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_1.png');
					valign_b = true;
					break;
				}
			}

			this.chat_bg.width = chatBgWidth;
			this.chat_label.width = chatBgWidth - this.chatLabelDifW;

			if (index <= 3) {
				this.chat_label.text = game.Tools.strOfLocalization(25081126 + index);
			}

			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'jp') {
				this.chat_label.fontSize = 36;
				if (this.chat_label.textField.textHeight <= 160) {
					this.chat_label.fontSize = 36;
				} else {
					this.chat_label.fontSize = 28;
				}
			}
			// this.chat_bg.height = Math.min(246, this.chat_label.textField.textHeight + 55);
			this.chat_bg.height = this.chat_label.textField.textHeight + 65;
			this.chatArrowAdapt.fresh();
			if (valign_b) {
				this.chat_label.y = 145;
				this.chat_bg.y = 115;
				this.chat_arrow.y = this.chat_bg.height + 86;
			} else {
				this.chat_bg.y = 268 - this.chat_bg.height;
				this.chat_label.y = this.chat_bg.y + 32;
				this.chat_arrow.y = 243;
			}

			this.pre_btn.visible = index != this.start_page;
			let is_max = index == this.max_page - 1;
			// this.next_btn.visible = !is_max;
			(this.next_btn.getChildAt(0) as Laya.Sprite).visible = !is_max;
			(this.next_btn.getChildAt(1) as Laya.Sprite).visible = is_max;
			(this.skip_btn.getChildAt(0) as Laya.Sprite).visible = !is_max;
			(this.skip_btn.getChildAt(1) as Laya.Sprite).visible = is_max;
			let offset_index = is_max ? 1 : 0;
			this.skip_btn.width = 188 + this.offsets[offset_index];
			this.skip_btn.x = 1803 - this.offsets[offset_index] / 2;

			this.next_btn.width = 188 + this.offsets[2 + offset_index];
			this.next_btn.x = 1782 - this.offsets[2 + offset_index] / 2;
		}

		public close() {
			this.locking = true;
			Laya.Tween.to(this.blackmask, { alpha: 0 }, 150);
			UIBase.anim_alpha_out(this.btns, {}, 200);
			UIBase.anim_alpha_out(this.root, {}, 200, 0, Laya.Handler.create(this, () => {
				this.locking = false;
				this.enable = false;
				if (this.extraConfig && this.extraConfig.onClose) this.extraConfig.onClose.run();
			}));
			Laya.loader.clearTextureRes(game.Tools.localUISrc('extendRes/emo/e200001/l_1.png'));
			Laya.loader.clearTextureRes(game.Tools.localUISrc('extendRes/emo/e200001/l_2.png'));
		}

		private setImgSkin(url: string) {
			game.LoadMgr.setImgSkin(this.img_0, url, null, 'UI_Amulet_Rules');
		}


		public onEnable(): void {
			game.TempImageMgr.setUIEnable('UI_Amulet_Rules', true);
		}

		public onDisable(): void {
			game.TempImageMgr.setUIEnable('UI_Amulet_Rules', false);
		}
	}
}