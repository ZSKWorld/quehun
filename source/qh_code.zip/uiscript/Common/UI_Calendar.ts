module uiscript {
    export class UI_Calendar_Day extends UI_Component {
        private dayLabel: Laya.Label;
        private btn: Laya.Button;
        private todayImg: Laya.Image;
        private selectImg: Laya.Image;
        public onCreate(): void {
            this.btn = this.me as Laya.Button;
            this.dayLabel = this.me.getChildByName('day') as Laya.Label;
            this.todayImg = this.me.getChildByName('today') as Laya.Image;
            this.selectImg = this.me.getChildByName('selected') as Laya.Image;
        }

        public set clickHandler(handler: Laya.Handler) {
            this.btn.clickHandler = handler;
        }


        public set day(day: number) {
            this.dayLabel.text = day.toString();
        }

        public set today(isToday: boolean) {
            this.todayImg.visible = isToday;
        }

        public set select(isSelect: boolean) {
            this.selectImg.visible = isSelect;
        }

        public get select(): boolean {
            return this.selectImg.visible;
        }

        public set dayTextColor(color: string) {
            this.dayLabel.color = color;
        }


    }

    export class UI_Calendar extends UI_Component {
        /**
         * 当前时间 年/月用来显示当期日历展示的月份
         */
        private currentTimeLabel: Laya.Label;
        /**
         * 上一个月
         */
        private lastMonthBtn: Laya.Button;
        /**
         * 下一个月
         */
        private nextMonthBtn: Laya.Button;
        private dayContainer: Laya.Sprite;

        /**
         * 当前选择的时间戳
         */
        private currentSelectTimeStamp: number;
        /**
         * 当前展示的时间戳
         */
        private currentShowTimeStamp: number;

        private dayTemplate: Laya.Sprite;
        private days: UI_Calendar_Day[];
        /**
         * 限制日历开始时间，在此时间之前不可以选择,默认0,不限制
         */
        private selectStartTimeLimit: number;
        /**
         * 限制日历结束时间，在此时间之后不可以选择,默认0,不限制
         */
        private selectEndTimeLimit: number;
        /**
         * 限制日历开始时间，在此时间之前不可以展示,默认0,不限制
         */
        private showStartTimeLimit: number;
        /**
         * 限制日历结束时间，在此时间之后不可以展示,默认0,不限制
         */
        private showEndTimeLimit: number;
        private onSelectChange: Laya.Handler;
        /**
         * 日历是否框选今天
         */
        private isShowToday:boolean;

        public onCreate(): void {
            this.currentTimeLabel = this.me.getChildByName('month') as Laya.Label;
            this.lastMonthBtn = this.me.getChildByName('left') as Laya.Button;
            this.nextMonthBtn = this.me.getChildByName('right') as Laya.Button;
            this.dayContainer = this.me.getChildByName('days') as Laya.Sprite;
            this.dayTemplate = this.dayContainer.getChildByName('template') as Laya.Sprite;
            this.dayTemplate.visible = false;
            this.lastMonthBtn.clickHandler = Laya.Handler.create(this, this.lastMonth, null, false);
            this.nextMonthBtn.clickHandler = Laya.Handler.create(this, this.nextMonth, null, false);
            //创建日期，一行7个，一共5行，间距是template的宽高
            let templateWidth = this.dayTemplate.width;
            let templateHeight = this.dayTemplate.height;
            this.days = [];
            for (let index = 0; index < 6; index++) {
                for (let j = 0; j < 7; j++) {
                    let daySprite = this.dayTemplate.scriptMap['capsui.UICopy']['getNodeClone']();
                    let day = new UI_Calendar_Day(daySprite);
                    this.dayContainer.addChild(daySprite);
                    daySprite.x = j * templateWidth;
                    daySprite.y = index * templateHeight;
                    this.days.push(day);
                    day.visible = true;
                }

            }
            this.selectStartTimeLimit = 0;
            this.selectEndTimeLimit = 0;
            this.showStartTimeLimit = 0;
            this.showEndTimeLimit = 0;

        }

        /**
         * 会以该时间戳为基准展示日历
         * @param showTimeStamp 时间戳，如果是0则默认展示当前月份
         */
        public show(showTimeStamp: number = 0, isShowToday: boolean = true) {
            this.isShowToday = isShowToday;
            if (showTimeStamp == 0) {
                showTimeStamp = game.Tools.getServerTime();
            }
            this.showTime = showTimeStamp;
        }

        /**
         * 上一个月,更新currentShowTime
         */
        private lastMonth() {
            let date = new Date(this.currentShowTimeStamp);
            date.setMonth(date.getMonth() - 1);
            this.showTime = date.getTime();
        }

        /**
         * 下一个月,更新currentShowTime
         */
        private nextMonth() {
            let date = new Date(this.currentShowTimeStamp);
            date.setMonth(date.getMonth() + 1);
            this.showTime = date.getTime();

        }

        /**
         * 设置当前显示的时间戳
         */
        public set showTime(timeStamp: number) {
            this.currentShowTimeStamp = timeStamp;
            this.fresh();

        }

        /**
         * 设置当前选择的时间戳
         */
        public set selectTime(timeStamp: number) {
            this.currentSelectTimeStamp = timeStamp;
            this.fresh();

        }

        public get selectTime(): number {
            return this.currentSelectTimeStamp;
        }

        /**
         * 设置限制选择开始时间
         */
        public set selectStartLimit(timeStamp: number) {
            this.selectStartTimeLimit = timeStamp;
            this.fresh();

        }

        public get selectStartLimit(): number {
            return this.selectStartTimeLimit;
        }

        /**
         * 设置限制选择结束时间
         */
        public set selectEndLimit(timeStamp: number) {
            this.selectEndTimeLimit = timeStamp;
            this.fresh();

        }

        public get selectEndLimit(): number {
            return this.selectEndTimeLimit;
        }

        /**
         * 设置限制显示开始时间
         */
        public set showStartLimit(timeStamp: number) {
            this.showStartTimeLimit = timeStamp;
            this.fresh();

        }

        /**
         * 设置限制显示结束时间
         */
        public set showEndLimit(timeStamp: number) {
            this.showEndTimeLimit = timeStamp;
            this.fresh();
        }


        public set onSelect(handler: Laya.Handler) {
            this.onSelectChange = handler;
        }

        public fresh() {

            let date = new Date(this.currentShowTimeStamp);
            // this.currentTimeLabel.text = date.getFullYear() + game.Tools.strOfLocalization(10090) + game.Tools.strOfLocalization(10070 + date.getMonth() + 1);
            let currentYear = date.getFullYear();
            let currentMonth = date.getMonth() + 1;
            let currentMonthIndex = date.getMonth();
            this.currentTimeLabel.text = currentYear + game.Tools.strOfLocalization(10090) + '  ' + game.Tools.strOfLocalization(10070 + currentMonth);

            //获取本月第一天是周几
            let firstDay = game.Tools.getDayWeek(currentYear, currentMonth, 1);
            //获取本月总天数
            let totalDays = new Date(currentYear, currentMonth, 0).getDate();
            //如果上一个月小于显示时间限制，不显示上一个月的箭头

            let lastMonthIndex = currentMonthIndex - 1;
            let lastYear = currentYear;
            if (lastMonthIndex < 0) {
                lastMonthIndex = 11;
                lastYear--;
            }
            let lastMonth = new Date(lastYear, lastMonthIndex, 1);
            if (this.showStartTimeLimit != 0 && lastMonth.getTime() < this.showStartTimeLimit) {
                game.Tools.setGrayDisable(this.lastMonthBtn, true);
                this.lastMonthBtn.alpha = 0.4;
            } else {
                game.Tools.setGrayDisable(this.lastMonthBtn, false);
                this.lastMonthBtn.alpha = 1;
            }
            //如果下一个月大于显示时间限制，不显示下一个月的箭头
            //获取下个月第一天的时间戳,这里存在跨年的情况
            let nextMonthIndex = currentMonthIndex + 1;
            let nextYear = currentYear;
            if (nextMonthIndex > 11) {
                nextMonthIndex = 0;
                nextYear++;
            }
            let nextMonth = new Date(nextYear, nextMonthIndex, 1);


            if (this.showEndTimeLimit != 0 && nextMonth.getTime() >= this.showEndTimeLimit) {
                game.Tools.setGrayDisable(this.nextMonthBtn, true);
                this.nextMonthBtn.alpha = 0.4;
            } else {
                game.Tools.setGrayDisable(this.nextMonthBtn, false);
                this.nextMonthBtn.alpha = 1;
            }


            //设置日期
            for (let index = 0; index < this.days.length; index++) {
                let day = this.days[index];
                //从第一天开始到最后一天显示
                if (index >= firstDay && index < firstDay + totalDays) {
                    let dayCount = index - firstDay + 1;
                    //判断是否在显示时间范围内
                    let dayTimeStamp = new Date(currentYear, currentMonthIndex,dayCount).getTime();
                    //如果有限制显示开始时间，且小于限制显示开始时间
                    if (this.showStartTimeLimit && this.showStartTimeLimit != 0 && dayTimeStamp < this.showStartTimeLimit) {
                        day.visible = false;
                        continue;
                    }
                    //如果有限制显示结束时间，且大于限制显示结束时间
                    else if (this.showEndTimeLimit && this.showEndTimeLimit != 0 && dayTimeStamp > this.showEndTimeLimit) {
                        day.visible = false;
                        continue;
                    } else {
                        day.visible = true;
                        day.day = index - firstDay + 1;
                        //如果有限制选择开始时间，且小于限制选择开始时间
                        if (this.selectStartTimeLimit != 0 && dayTimeStamp < this.selectStartTimeLimit) {
                            day.touchable = false;
                        }
                        //如果有限制选择结束时间，且大于限制选择结束时间
                        else if (this.selectEndTimeLimit != 0 && dayTimeStamp > this.selectEndTimeLimit) {
                            day.touchable = false;
                        } else {
                            day.touchable = true;
                        }

                        day.today = (dayTimeStamp == game.Tools.getServerDateTimestamp()) && this.isShowToday;
                        //这里只要月和日相同就可以了
                        day.select = dayTimeStamp == new Date(this.currentSelectTimeStamp).setHours(0, 0, 0, 0);
                        day.clickHandler = new Laya.Handler(this, () => {
                            if (day.select) {
                                this.selectTime = 0;
                            } else {
                                this.selectTime = dayTimeStamp;
                            }
                            this.onSelectChange?.run();
                        });
                        day.dayTextColor = day.touchable ? "#D4CFCF" : "#9e9797";

                    }
                } else {
                    day.visible = false;
                }
            }
        }

    }
}