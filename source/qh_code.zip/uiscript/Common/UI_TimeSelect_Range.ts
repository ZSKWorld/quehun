module uiscript {

    export class UI_TimeSelect_Range extends UIBase {
        constructor() {
            super(new ui.common.time_select_rangesUI());
        }

        private bg: Laya.Image;
        private root: Laya.Sprite;
        private maskCloseBtn: Laya.Button;
        private btnClose: Laya.Button;
        private btnConfirm: Laya.Button;
        private selectTodayBtn: Laya.Button;
        private select7dayBtn: Laya.Button;
        private select30dayBtn: Laya.Button;
        private currentStartTimeLabel: Laya.Label;
        private currentEndTimeLabel: Laya.Label;
        private onConfirm: Laya.Handler;

        private startTimeCalendar: UI_Calendar;
        private endTimeCalendar: UI_Calendar;
        private currentStartTime: number;
        private currentEndTime: number;
        private isLock: boolean = false;
        private onSelectStartTime: Laya.Handler;
        private onSelectEndTime: Laya.Handler;

        public onCreate(): void {
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.maskCloseBtn = this.me.getChildByName('mask_close_btn') as Laya.Button;
            this.btnClose = this.root.getChildByName('btn_close') as Laya.Button;
            this.btnConfirm = this.root.getChildByName('btn_confirm') as Laya.Button;
            this.selectTodayBtn = this.root.getChildByName('btn_today') as Laya.Button;
            this.select7dayBtn = this.root.getChildByName('btn_7day') as Laya.Button;
            this.select30dayBtn = this.root.getChildByName('btn_30day') as Laya.Button;
            this.currentStartTimeLabel = this.root.getChildByName('current_start_time') as Laya.Label;
            this.currentEndTimeLabel = this.root.getChildByName('current_end_time') as Laya.Label;
            this.startTimeCalendar = new UI_Calendar(this.root.getChildByName('start_time') as Laya.Sprite);
            this.startTimeCalendar.onSelect = new Laya.Handler(this, () => {
                this.currentStartTime = this.startTimeCalendar.selectTime;
                this.onSelectStartTime?.run();
                this.fresh();
            });
            this.endTimeCalendar = new UI_Calendar(this.root.getChildByName('end_time') as Laya.Sprite);
            this.endTimeCalendar.onSelect = new Laya.Handler(this, () => {
                this.currentEndTime = this.endTimeCalendar.selectTime;
                this.onSelectEndTime?.run();
                this.fresh();
            });
            this.currentStartTime = 0;
            this.currentEndTime = 0;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                if (!this.isLock) {
                    this.hide();
                }
            });
            this.btnClose.clickHandler = new Laya.Handler(this, () => {
                if (!this.isLock) {
                    this.hide();
                }
            });

            this.btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (!this.isLock) {
                    this.hide();
                    this.onConfirm?.runWith([this.currentStartTime, this.currentEndTime]);
                }
            });
            this.selectTodayBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }

                this.startTimeCalendar.selectTime = game.Tools.getServerDateTimestamp();
                this.endTimeCalendar.selectTime = game.Tools.getServerDateTimestamp();
                this.currentStartTime = this.startTimeCalendar.selectTime;
                this.currentEndTime = this.endTimeCalendar.selectTime;
                //将日历显示到对应的日期
                this.startTimeCalendar.showTime = this.startTimeCalendar.selectTime;
                this.endTimeCalendar.showTime = this.endTimeCalendar.selectTime;
                this.onSelectStartTime?.run();
                this.onSelectEndTime?.run();
                this.fresh();
            });
            this.select7dayBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                let today = game.Tools.getServerDateTimestamp();
                this.startTimeCalendar.selectTime = today - 6 * 24 * 3600 * 1000;
                this.endTimeCalendar.selectTime = today;
                this.currentStartTime = this.startTimeCalendar.selectTime;
                this.currentEndTime = this.endTimeCalendar.selectTime;
                //将日历显示到对应的日期
                this.startTimeCalendar.showTime = this.startTimeCalendar.selectTime;
                this.endTimeCalendar.showTime = this.endTimeCalendar.selectTime;
                this.onSelectStartTime?.run();
                this.onSelectEndTime?.run();
                this.fresh();
            });
            this.select30dayBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.isLock) {
                    return;
                }
                let today = game.Tools.getServerDateTimestamp();
                this.startTimeCalendar.selectTime = today - 29 * 24 * 3600 * 1000;
                this.endTimeCalendar.selectTime = today;
                this.currentStartTime = this.startTimeCalendar.selectTime;
                this.currentEndTime = this.endTimeCalendar.selectTime;
                //将日历显示到对应的日期
                this.startTimeCalendar.showTime = this.startTimeCalendar.selectTime;
                this.endTimeCalendar.showTime = this.endTimeCalendar.selectTime;
                this.onSelectStartTime?.run();
                this.onSelectEndTime?.run();
                this.fresh();
            });

        }

        public onEnable(): void {

        }

        public onDisable(): void {

        }



        /**
         * 打开页面
         * @param selectStartTime 选择的开始时间
         * @param selectEndTime 选择的结束时间
         * @param showStartTime 打开时开始时间显示的位置
         * @param showEndTime 打开时结束时间显示的位置
         */
        public show(selectStartTime: number, selectEndTime: number, showStartTime: number = 0, showEndTime: number = 0): void {
            this.currentStartTime = selectStartTime;
            this.currentEndTime = selectEndTime;
            this.startTimeCalendar.show(showStartTime == 0 ? selectStartTime : showStartTime,false);
            this.startTimeCalendar.selectTime = selectStartTime;
            this.endTimeCalendar.show(showEndTime == 0 ? selectEndTime : showEndTime,false);
            this.endTimeCalendar.selectTime = selectEndTime;
            this.fresh();
            this.isLock = true;
            this.bg.alpha = 0;
            this.enable = true;
            Laya.Tween.to(this.bg, { alpha: 0.7 }, 150, Laya.Ease.quadInOut);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
            }));

        }

        public hide(): void {
            this.isLock = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 150, Laya.Ease.quadInOut);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
                this.enable = false;
            }));
        }


        private fresh() {

            //开始时间 2024/07/30
            let startNoSelectTip: string = game.Tools.strOfLocalization(20135) + "：" + game.Tools.strOfLocalization(20165);
            let endNoSelectTip: string = game.Tools.strOfLocalization(20136) + "：" + game.Tools.strOfLocalization(20165);
            // this.currentStartTimeLabel.text = this.currentStartTime == 0 ? startNoSelectTip : game.Tools.time2YearMounthDate(this.currentStartTime / 1000);
            let startTimeDate = new Date(this.currentStartTime);
            this.currentStartTimeLabel.text = this.currentStartTime == 0 ? startNoSelectTip : startTimeDate.getFullYear() + game.Tools.strOfLocalization(10090) + '  ' + game.Tools.strOfLocalization(10070 + startTimeDate.getMonth() + 1) + startTimeDate.getDate() + game.Tools.strOfLocalization(10091);
            //结束时间
            // this.currentEndTimeLabel.text = this.currentEndTime == 0 ? endNoSelectTip : game.Tools.time2YearMounthDate(this.currentEndTime / 1000);
            let endTimeDate = new Date(this.currentEndTime);
            this.currentEndTimeLabel.text = this.currentEndTime == 0 ? endNoSelectTip : endTimeDate.getFullYear() + game.Tools.strOfLocalization(10090) + '  ' + game.Tools.strOfLocalization(10070 + endTimeDate.getMonth() + 1) + endTimeDate.getDate() + game.Tools.strOfLocalization(10091);
        }

        public set onClickConfirm(handler: Laya.Handler) {
            this.onConfirm = handler;
        }

        public set startCalenderBeginLimit(startLimit: number) {
            this.startTimeCalendar.showStartLimit = startLimit;

        }

        public set startCalenderEndLimit(endLimit: number) {
            this.startTimeCalendar.showEndLimit = endLimit;
        }


        public set endCalenderBeginLimit(startLimit: number) {
            this.endTimeCalendar.showStartLimit = startLimit;
        }



        public set endCalenderEndLimit(endLimit: number) {
            this.endTimeCalendar.showEndLimit = endLimit;
        }

        public set startCalenderSelectBeginLimit(selectLimit: number) {
            this.startTimeCalendar.selectStartLimit = selectLimit;
        }

        public set endCalenderSelectBeginLimit(selectLimit: number) {
            this.endTimeCalendar.selectStartLimit = selectLimit;
        }

        public set startCalenderSelectEndLimit(selectLimit: number) {
            this.startTimeCalendar.selectEndLimit = selectLimit;
        }

        public set endCalenderSelectEndLimit(selectLimit: number) {
            this.endTimeCalendar.selectEndLimit = selectLimit;
        }

        public set onSelectStart(handler: Laya.Handler) {
            this.onSelectStartTime = handler;
        }

        public set onSelectEnd(handler: Laya.Handler) {
            this.onSelectEndTime = handler;
        }

        public get selectStartTime(): number {
            return this.currentStartTime;
        }

        public get selectEndTime(): number {
            return this.currentEndTime;
        }
    }


}