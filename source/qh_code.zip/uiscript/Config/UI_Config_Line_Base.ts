module uiscript {

    export enum EConfigOpreateType {
        /**
         * 用户操作输入的数据
         */
        USER,
        /**
         * 代码设置的数据
         */
        CODE
    }

    export enum EConfigLineLevel {
        /**
         * 没有父行的行
         */
        ONE = 1,
        /**
         * 上面仅有一级父行的行
         */
        TWO = 2,
    }

    export class UI_Config_Line_Base extends UI_Component {
        protected title: Laya.Label;
        protected cover: Laya.Sprite;
        protected level1Sprite: Laya.Sprite;
        protected level2Sprite: Laya.Sprite;
        protected originHeight: number; // 使用初始高度作为基准
        protected valueChangeListeners: Array<Laya.Handler> = [];
        protected isOperable: boolean = true; // 是否可操作
        protected helpBtn: Laya.Button;

        protected height: number;
        protected innerId: number;
        protected innerlineLevel: EConfigLineLevel;
        protected nextLineSpaceY: number = 0; // 与下一行的间距

        constructor(comp: Laya.Sprite, id: number, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE) {
            super(comp);
            this.innerId = id;
            this.level1Sprite = this.me.getChildByName('level1title') as Laya.Sprite;
            this.level2Sprite = this.me.getChildByName('level2title') as Laya.Sprite;
            this.helpBtn = this.me.getChildByName("help_btn") as Laya.Button;
            this.helpBtn.visible = false;
            this.lineLevel = lineLevel;

        }

        public set lineLevel(level: EConfigLineLevel) {
            this.innerlineLevel = level;
            this.level1Sprite.visible = (level == EConfigLineLevel.ONE);
            this.level2Sprite.visible = (level == EConfigLineLevel.TWO);
            if (level == EConfigLineLevel.ONE) {
                this.title = this.level1Sprite.getChildByName('name') as Laya.Label;
            } else if (level == EConfigLineLevel.TWO) {
                this.title = this.level2Sprite.getChildByName('name') as Laya.Label;
            }
        }

        public get lineLevel(): EConfigLineLevel {
            return this.innerlineLevel;
        }

        public onCreate(): void {
            this.me.visible = true;
            this.originHeight = this.me.height;
            this.height = this.originHeight;
            this.cover = this.me.getChildByName('cover') as Laya.Sprite;
            this.cover.visible = false;

        }

        protected setLineTitle(title: string) {
            if (this.title) {
                this.title.text = title;
                if (this.helpBtn) {
                    this.helpBtn.x = this.title.x + this.title.trueWidth - 7 + this.helpBtn.width / 2;
                }
            }

        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }

        // 刷新
        public refresh() {

        }

        public getInfo(): any {
            return null;
        }

        public pos(x: number, y: number) {
            this.me.pos(x, y);
        }

        public reset() {

        }

        public addValueListener(listener: Laya.Handler) {
            let index = this.valueChangeListeners.indexOf(listener);
            if (index >= 0) {
                return;
            }
            this.valueChangeListeners.push(listener);
        }

        public removeValueListener(listener: Laya.Handler) {
            let index = this.valueChangeListeners.indexOf(listener);
            if (index >= 0) {
                this.valueChangeListeners.splice(index, 1);
            }
        }

        protected onValueChange(op: EConfigOpreateType, data: any = null) {
            this.valueChangeListeners.forEach(element => {
                element.runWith([op, data]);
            });
        }

        /**
        * 当前内容是否合规
        * @returns 当前内容是否合规
        */
        public getValid(): boolean {
            return true;
        }

        public set select(value: boolean) {

        }

        /**
         * 当前内容是否与默认值不同
         * @returns 
         */
        public IsDiffWithDefault(): boolean {
            return false;
        }

        public get id(): number {
            return this.innerId;
        }

        public get lineTitle(): string {
            return this.title ? this.title.text : '';
        }

        /**
         * 是否可操作
         */
        public set operable(value: boolean) {
            this.isOperable = value;
            this.cover.visible = !value;
        }

        public get operable(): boolean {
            return this.isOperable;
        }

        public set space(value: number) {
            this.nextLineSpaceY = value;
        }

        public get space(): number {
            if (this.visible) {
                return this.nextLineSpaceY;
            }
            return 0;
        }

        public set onClickHelpBtn(handler: Laya.Handler) {
            if (handler) {
                this.helpBtn.clickHandler = handler;
                this.helpBtn.visible = handler != null;
            } else {
                this.helpBtn.clickHandler = null;
                this.helpBtn.visible = false;
            }
        }

        public get helpInfoRenderPos(): Laya.Vector2 {
            let pos = new Laya.Point();
            //help按钮右侧中间的全局坐标
            pos.x = this.helpBtn.x + this.helpBtn.width;
            pos.y = this.helpBtn.y;
            let globalPos = (this.helpBtn.parent as Laya.Sprite).localToGlobal(pos);
            return new Laya.Vector2(globalPos.x, globalPos.y);

        }
    }
}