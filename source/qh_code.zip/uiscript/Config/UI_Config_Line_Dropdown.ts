module uiscript {
    export class UI_Config_Line_DropDown extends UI_Config_Line_Base {
        private defaultValue: number = 0;
        private currentSelectIndex: number = 0;
        private dropdownBtn: Laya.Button;
        private dropdownBg: Laya.Image;
        private arrow: Laya.Image;
        private selectedLabel: Laya.Label;
        private titles: string[] = [];
        /**
         * 显示的限制范围列表，区域是一个矩形，0是左上角，1是右上角，2是右下角，3是左下角
         * 全局坐标
         */
        private renderRange: Array<Laya.Vector2> = [];

        public onCreate(): void {
            super.onCreate();
            this.renderRange = [];
            this.dropdownBtn = this.me.getChildByName("dropdown_btn") as Laya.Button;
            this.dropdownBtn.clickHandler = Laya.Handler.create(this, this.onClickDropdownBtn, null, false);
            this.selectedLabel = this.dropdownBtn.getChildByName("title") as Laya.Label;
            this.arrow = this.dropdownBtn.getChildByName("icon") as Laya.Image;
            this.dropdownBg = this.dropdownBtn.getChildByName("bg") as Laya.Image;
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }

        public init(lineTitle: string, titles: string[], renderRange: Array<Laya.Vector2>) {
            this.setLineTitle(lineTitle);
            this.titles = titles;
            this.renderRange = renderRange;
        }



        public setDefulatValue(value: number) {
            this.defaultValue = value;
        }

        public reset(): void {
            this.setInfo(this.defaultValue);
        }

        public setInfo(selectIndex: number, operateType: EConfigOpreateType = EConfigOpreateType.CODE) {
            this.currentSelectIndex = selectIndex;
            this.selectedLabel.text = this.titles[selectIndex];
            this.onValueChange(operateType, this.currentSelectIndex);
        }

        public getInfo(): number {
            return this.currentSelectIndex;
        }

        private onClickDropdownBtn() {
            UI_Config_Popup_Dropdown.Inst.init(this.titles, Laya.Handler.create(this, (selectedIndex: number, manualSwitching: boolean) => {
                if (manualSwitching) {
                    this.setInfo(selectedIndex, EConfigOpreateType.USER);
                }
            }, null, false));
            let upGlobalPos = this.dropdownBtn.localToGlobal(new Laya.Point(-8, -this.dropdownBtn.height / 2 - 4));
            let downGlobalPos = this.dropdownBtn.localToGlobal(new Laya.Point(-8, this.dropdownBtn.height / 2));
            //以弹窗大小为基准，向下弹出优先，向下弹出空间不足时向上弹出
            let renderPos: Laya.Vector2 = new Laya.Vector2(downGlobalPos.x, downGlobalPos.y);
            let dropDownHeight = UI_Config_Popup_Dropdown.Inst.height;
            let spaceDown = this.renderRange[2].y - renderPos.y;
            let isUp = false;
            if (spaceDown < dropDownHeight) {
                //向上弹出
                renderPos = new Laya.Vector2(upGlobalPos.x, upGlobalPos.y - dropDownHeight);
                isUp = true;
            }
            UI_Config_Popup_Dropdown.Inst.show(renderPos, this.currentSelectIndex, isUp);
        }



        /**
         * 是否可以选择，不可选择时，点击无效且隐藏箭头
         */
        public set selectEnable(value: boolean) {
            this.dropdownBtn.mouseEnabled = value;
            this.arrow.visible = value;
            this.dropdownBg.skin = game.Tools.localUISrc(value ? 'myres/bothui/config/setting_entry_btn.png' :'myres/bothui/config/setting_entry_btn_base.png')
        }
    }

}