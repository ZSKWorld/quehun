module uiscript {
    export class UI_Config_Line_JumpButton extends UI_Config_Line_Base {
        private jumpBtn: Laya.Button;
        private jumpTitle: Laya.Label;
        private onClickHandler: Laya.Handler;
        public onCreate(): void {
            super.onCreate();
            this.jumpBtn = this.me.getChildByName("jump_btn") as Laya.Button;
            this.jumpTitle = this.jumpBtn.getChildByName("title") as Laya.Label;
            this.jumpBtn.clickHandler = Laya.Handler.create(this, this.onClickJumpBtn, null, false);
        }

        public init(title: string,btnTitle:string,onClick:Laya.Handler,btnTitleColor:string) {
            this.setLineTitle(title);
            this.onClickHandler = onClick;
            this.jumpTitle.text = btnTitle;
            this.jumpTitle.color = btnTitleColor;
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }

        private onClickJumpBtn() {
            if (this.onClickHandler) {
                this.onClickHandler.run();
            }
        }

        public set btnTitle(title: string) { 
            this.jumpTitle.text = title;
        }

        public set btnTitleColor(color: string) { 
            this.jumpTitle.color = color;
        }




    }

}