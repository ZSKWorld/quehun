module uiscript {
    export class UI_Config_Line_PartStart extends UI_Config_Line_Base {
        public init(title: string): void {
            this.setLineTitle(title);
            this.onValueChange(EConfigOpreateType.CODE);
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }
    }

}