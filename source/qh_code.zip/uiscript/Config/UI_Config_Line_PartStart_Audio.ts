module uiscript {
    export class UI_Config_Line_PartStart_Audio extends UI_Config_Line_Base {
        private audioSprite: Laya.Sprite;
        private audioIcon: Laya.Image;
        private audioTitleLabel: Laya.Label;
        private audioNamePanel: Laya.Panel;
        private audioNameLabel: Laya.Label;
        private readonly speed: number = 180;//像素每秒
        private audioName: string = "";
        private rollRunningTime: number = 0;

        public onCreate(): void {
            super.onCreate();

            this.audioSprite = this.me.getChildByName('running_sound') as Laya.Sprite;
            this.audioTitleLabel = this.audioSprite.getChildByName('title') as Laya.Label;
            this.audioIcon = this.audioSprite.getChildByName('sound_icon') as Laya.Image;
           
            this.audioNamePanel = this.audioSprite.getChildByName('roll_panel') as Laya.Panel;
            this.audioNameLabel = this.audioNamePanel.getChildByName('sound_name') as Laya.Label;
            this.audioSprite.visible = false;

        }

        public init(title: string) {
            this.setLineTitle(title);
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }

        private setAudioName(name: string, audioType: view.E_Bgm_Type) {
            this.audioName = name;
            this.stopRoll();
            if (this.audioName == "") {
                this.audioSprite.visible = false;
                return;
            }
            this.audioTitleLabel.text = audioType == view.E_Bgm_Type.lobby ? game.Tools.strOfLocalization('26030118') : game.Tools.strOfLocalization('26030119');
            this.audioIcon.x = this.audioTitleLabel.x - this.audioTitleLabel.trueWidth - 10 - this.audioIcon.width;
            this.audioSprite.visible = true;
            this.audioNameLabel.text = name;
            //如果文字宽度超过面板宽度，开启滚动,否则居中显示
            if (this.audioNameLabel.trueWidth > this.audioNamePanel.width) {
                this.audioNameLabel.x = 0;
                
            } else {
                this.audioNameLabel.x = this.audioNamePanel.width / 2 - this.audioNameLabel.trueWidth / 2;
            }
        }

        public startRoll() {
            if (this.audioNameLabel.trueWidth > this.audioNamePanel.width) {
                this.rollRunningTime = 0;
                this.audioNameLabel.x = 0;
                Laya.timer.loop(100, this, this.rollUpdate);
            }
        }

        public stopRoll() {
            //如果文字宽度超过面板宽度，开启滚动,否则居中显示
            if (this.audioNameLabel.trueWidth > this.audioNamePanel.width) {
                this.audioNameLabel.x = 0;
            } else {
                this.audioNameLabel.x = this.audioNamePanel.width;
            }
            Laya.timer.clear(this, this.rollUpdate);
        }

        private rollUpdate(): void {
            //从右向左滚动，超过左边界时，重新执行startRoll
            let deltaTime = Laya.timer.delta / 1000;
            this.rollRunningTime += deltaTime;
            let moveX = this.speed * this.rollRunningTime;
            this.audioNameLabel.x = 0 - moveX;
            if (this.audioNameLabel.x + this.audioNameLabel.trueWidth < 0) {
                this.startRoll();
            }
        }

        public onDisable(): void {
            this.stopRoll();
            super.onDisable();
        }


        public getInfo() {
            return this.audioName;
        }

        public setInfo(audioName: string, audioType: view.E_Bgm_Type) {
            this.setAudioName(audioName, audioType);
        }


    }

}