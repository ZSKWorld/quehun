module uiscript {
    export class UI_Config_Line_Slider extends UI_Config_Line_Base {
        private slider: UI_Slider;
        private valueLabel: Laya.Label;
        private minValue: number = 0;
        private maxValue: number = 100;
        private defaultValue: number = 0;
        public onCreate(): void {
            super.onCreate();
            this.slider = new UI_Slider(this.me.getChildByName("slider") as Laya.Sprite,this.minValue,this.maxValue);
            this.valueLabel = this.slider.me.getChildByName("value") as Laya.Label;
            this.slider.onValueChangeHandler = Laya.Handler.create(this, this.onSliderValueChange, null, false);
            this.slider.onChangeStartHandler = Laya.Handler.create(this, () => {
                //开始拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_START_CHANGE);
            }, null, false);
            this.slider.onChangeEndHandler = Laya.Handler.create(this, () => {
                //结束拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_END_CHANGE);
            }, null, false);
        }

        public init(title: string, minValue: number = 0, maxValue: number = 100) {
            this.setLineTitle(title);
            this.minValue = minValue;
            this.maxValue = maxValue;
            
        }

        public setDefaultValue(value: number): void { 
            this.defaultValue = value;
        }

        private onSliderValueChange(operateType: EConfigOpreateType): void {
            let value = this.getInfo();
            this.valueLabel.text = value.toString();
            this.onValueChange(operateType, value);
        }

        public getInfo(): number {
            let value = this.slider.value;
            return value;
        }

        public setInfo(data: number) {
            let value = data;
            if (value < this.minValue) {
                value = this.minValue;
            }
            if (value > this.maxValue) {
                value = this.maxValue;
            }
            //需要fix一下数值，这里仅限整数
            value = Math.floor(value);
            this.slider.setValue(value);
            this.valueLabel.text = value.toString();
        }

        public reset(): void {
            this.setInfo(this.defaultValue);
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }


    }

}