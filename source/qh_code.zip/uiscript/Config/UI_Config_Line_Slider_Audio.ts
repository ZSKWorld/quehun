module uiscript {
    export interface IConfigSliderInfo{
        value: number;
        isMute: boolean;
    }

    export class UI_Config_Line_Slider_Audio extends UI_Config_Line_Base {
        private slider: UI_Slider;
        private valueLabel: Laya.Label;
        private minValue: number = 0;
        private maxValue: number = 100;
        private defaultValue: number = 0;
        private defaultMute: boolean = false;
        private muteToggle: UI_Toggle;

        public onCreate(): void {
            super.onCreate();
            this.slider = new UI_Slider(this.me.getChildByName("slider") as Laya.Sprite,this.minValue,this.maxValue);
            this.slider.onValueChangeHandler = Laya.Handler.create(this, this.onSliderValueChange, null, false);
            this.slider.onChangeStartHandler = Laya.Handler.create(this, () => {
                //开始拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_START_CHANGE);
            }, null, false);
            this.slider.onChangeEndHandler = Laya.Handler.create(this, () => {
                //结束拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_END_CHANGE);
            }, null, false);
            this.valueLabel = this.slider.me.getChildByName("value") as Laya.Label;
            this.muteToggle = new UI_Toggle(this.me.getChildByName("mute_toggle") as Laya.Sprite);
            this.muteToggle.addClickListener(Laya.Handler.create(this, this.onClickMuteToggle, null, false));
        }

        public init(title: string, minValue: number = 0, maxValue: number = 100) {
            this.setLineTitle(title);
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        public setDefaultValue(value: number, isMute: boolean) {
            this.defaultValue = value;
            this.defaultMute = isMute;
        }

        private onSliderValueChange(operateType: EConfigOpreateType): void {
            //如果是静音状态，先取消静音
            if (this.muteToggle.on && operateType == EConfigOpreateType.USER) {
                this.muteToggle.on = false;
                this.setMute(false);
            }
            let value = this.getInfo();
            this.valueLabel.text = value.value.toString();
            this.onValueChange(operateType,value);
        }

        public getInfo(): IConfigSliderInfo {
            return { value: this.slider.value, isMute: this.muteToggle.on };
        }

        

        public setSliderValue(data: number) {
            if (data < this.minValue) {
                data = this.minValue;
            }
            if (data > this.maxValue) {
                data = this.maxValue;
            }
            let rate = (data - this.minValue) / (this.maxValue - this.minValue);
            //赋值slider的时候调用了onValueChange，所以不需要再手动调用一次
            this.slider.setRate(rate);
            this.valueLabel.text = data.toString();
        }

        public reset(): void {
            this.setSliderValue(this.defaultValue);
            this.setMute(this.defaultMute);
        }

        public getHeight(): number {
            if (this.visible) {
                return this.height;
            }
            return 0;
        }
        
        /**
         * 
         * @param value true静音，false非静音
         */
        public setMute(value: boolean) {
            //静音的情况下，且显示为灰色,如果滑动滑动条，则改为非静音状态
            // this.slider.touchable = !value;
            // let thumbImage = !value ? "myres/bothui/config/setting_sound_progress_btn.png" : "myres/bothui/config/setting_sound_progress_btn_dis.png";
            let fillImage = !value ? "myres/bothui/config/setting_sound_progress_strip.png" : "myres/bothui/config/setting_sound_progress_strip_dis.png";
            // this.slider.thumbImage = game.Tools.localUISrc(thumbImage);
            this.slider.fillImage = game.Tools.localUISrc(fillImage);
            
        }

        private onClickMuteToggle() { 
            this.setMute(this.muteToggle.on);
            this.onValueChange(EConfigOpreateType.USER,this.getInfo());
        }

        public setInfo(value: IConfigSliderInfo) {
            //需要fix一下数值，这里仅限整数
            value.value = Math.floor(value.value);
            this.setSliderValue(value.value);
            this.muteToggle.on = value.isMute;
            this.setMute(value.isMute);
        }



    }

}