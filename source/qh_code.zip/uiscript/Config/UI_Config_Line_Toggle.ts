module uiscript{
    class TabButton extends UI_Component {
        private selectSprite: Laya.Sprite;
        private deselectSprite: Laya.Sprite;
        private deselectTitle: Laya.Label;
        private selectTitle: Laya.Label;
        public onCreate(): void {
            this.selectSprite = this.me.getChildByName('select') as Laya.Sprite;
            this.deselectSprite = this.me.getChildByName('diselect') as Laya.Sprite;
            this.deselectTitle = this.deselectSprite.getChildByName('title') as Laya.Label;
            this.selectTitle = this.selectSprite.getChildByName('title') as Laya.Label;
        }


        public set selected(v: boolean) {
            if (v) {
                this.onSelect();
            } else {
                this.onDeselect();
            }
        }

        public onSelect() {
            this.selectSprite.visible = true;
            this.deselectSprite.visible = false;
        }

        public onDeselect() {
            this.selectSprite.visible = false;
            this.deselectSprite.visible = true;
        }

        public set title(value: string) {
            this.deselectTitle.text = value;
            this.selectTitle.text = value;
        }
    }

    export class UI_Config_Line_Toggle extends UI_Config_Line_Base { 
        private defaultValue: number = 0;
        private tabGroup: UI_TabGroup_Base;
        private tabButtons: Array<TabButton>;
        
        public onCreate(): void {
            super.onCreate();
            this.tabGroup = new UI_TabGroup_Base();
            this.tabButtons = [];
            let tabs = this.me.getChildByName("tabs") as Laya.Sprite;
            for (let i = 0; i < 2; i++) { 
                let tab = tabs.getChildByName("tab" + i) as Laya.Sprite;
                this.tabGroup.AddTabButton(tab.getChildByName('btn') as Laya.Button);
                let tabButton = new TabButton(tab);
                this.tabButtons.push(tabButton);
            }
            this.tabGroup.onSelectChange = (index, btn, manualSwitching) => {
                this.onSelectChange(index, btn, manualSwitching);
            };
        }

        public init(lineTitle: string,titles: Array<string> = null): void { 
            this.setLineTitle(lineTitle);
            if (titles) {
                for (let i = 0; i < titles.length; i++) {
                    this.tabButtons[i].title = titles[i];
                }
            }

        }

        public setDefulatValue(value: number) {
            this.defaultValue = value;
        }

        public reset(): void {
            this.setInfo(this.defaultValue);
        }

        public setInfo(selectIndex: number, operateType: EConfigOpreateType = EConfigOpreateType.CODE) {
            this.tabGroup.forceSelect(selectIndex);
            this.onValueChange(operateType, this.getInfo());
        }

        public getInfo(): number {
            return this.tabGroup.selectedIndex;
        }

        private onSelectChange(index: number, btn: Laya.Button, manualSwitching: boolean = false) {
            let tab = this.tabButtons[index];
            if (index == this.tabGroup.selectedIndex) {
                tab.selected = true;
                if (manualSwitching) {
                    this.onValueChange(EConfigOpreateType.USER, this.getInfo());
                }
            } else {
                tab.selected = false;
            }

        }


    }
}