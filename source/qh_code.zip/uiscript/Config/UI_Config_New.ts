module uiscript {

    export enum EConfigFromType{
        DEFAULT = 0,
        ITEM_MATCH_BGM = 1,
        MATCH = 2,
        ITEM_LOBBY_BGM = 3,

    }

    export class UI_Config_New extends UIBase {
        public static Inst: UI_Config_New = null;
        /**
         * 是否关闭电脑随机角色功能，0为不关闭，1为关闭
         */
        public static disableRandomChar: number = 0;
        public static onFetchSuccess(misc: Partial<game.IResMisc>) {
            this.disableRandomChar = misc && misc.disable_room_random_bot_char || 0;
        }

        public static set disableClickEffect(index: number) {
            Laya.LocalStorage.setItem('clickEffect', index.toString());
        }

        public static get disableClickEffect(): number {
            return parseInt(Laya.LocalStorage.getItem('clickEffect') || '0');
        }

        private static ifNeedRestart: boolean = false;
        public static set needRestart(value: boolean) { 
            this.ifNeedRestart = value;
            if (UI_Config_New.Inst && UI_Config_New.Inst.enable) {
                UI_Config_New.Inst.freshRestartBtn();
            }
        }
        public static get needRestart(): boolean { 
            return this.ifNeedRestart;
        }

        constructor() {
            super(new ui.both_ui.config.config_newUI());
            UI_Config_New.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private restartBtn: Laya.Button;
        private logoutBtn: Laya.Button;
        private versionLabel: Laya.Label = null;

        private tabGroup: UI_TabGroup_Base;
        private tabButtons: Array<UI_TabGroup_TabButton>;
        private pageAudio: UI_Config_Page_Audio;
        private pageDisplay: UI_Config_Page_Display;
        private pagePrefer: UI_Config_Page_Prefer;
        private pageLanguage: UI_Config_Page_Language;
        private pageOther: UI_Config_Page_Other;
        private pages: Array<UI_Config_Page_Base>;
        private scrollPanel: ScrollPanel;
        private locking: boolean = false;
        private tabStartY: number = -3;
        private tabSpaceY: number = 104;
        private from: EConfigFromType = EConfigFromType.DEFAULT;
        
        public set lock(value: boolean) {
            this.locking = value;
        }

        public get lock(): boolean {
            return this.locking;
        }



        public onCreate(): void {
            this.tabButtons = new Array<UI_TabGroup_TabButton>();
            this.pages = new Array<UI_Config_Page_Base>();
            this.backCloseBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.lock) {
                    return;
                }
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName("root") as Laya.Sprite;
            this.closeBtn = this.root.getChildByName("close_btn") as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.lock) {
                    return;
                }
                this.hide();
            }, null, false);
            this.restartBtn = this.root.getChildByName("btn_restart") as Laya.Button;
            this.restartBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.lock) {
                    return;
                }
                this.restartGame();
            }, null, false);
            this.logoutBtn = this.root.getChildByName("btn_logout") as Laya.Button;
            this.logoutBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.lock) {
                    return;
                }
                this.logout();
            }, null, false);
            this.versionLabel = this.root.getChildByName("version") as Laya.Label;
            this.versionLabel.text = game.Tools.strOfLocalization(2040) + ':' + game.ResourceVersion.version;
           
            let list = this.root.getChildByName("config_list") as Laya.Sprite;
            let originPos = list.localToGlobal(new Laya.Point(0, 0));
            let renderRange = new Array<Laya.Vector2>();
            renderRange.push(new Laya.Vector2(originPos.x, originPos.y));
            renderRange.push(new Laya.Vector2(originPos.x + list.width, originPos.y));
            renderRange.push(new Laya.Vector2(originPos.x + list.width, originPos.y + list.height));
            renderRange.push(new Laya.Vector2(originPos.x, originPos.y + list.height));
            this.scrollPanel = new ScrollPanel(this.root.getChildByName("config_list") as Laya.Sprite);
            let pageParent = this.scrollPanel.content;
            let tabs = this.root.getChildByName("page_tab") as Laya.Sprite;
            this.tabGroup = new UI_TabGroup_Base();
            for (let index = 0; index < pageParent.numChildren; index++) {
                let pageComp = pageParent.getChildAt(index) as Laya.Sprite;
                let page: UI_Config_Page_Base = null;
                let tabBtn = tabs.getChildAt(index) as Laya.Button;
                switch (index) {
                    case EConfigPageType.AUDIO:
                        page = new UI_Config_Page_Audio(pageComp, EConfigPageType.AUDIO, renderRange);
                        this.pageAudio = page as UI_Config_Page_Audio;
                        break;
                    case EConfigPageType.DISPLAY:
                        page = new UI_Config_Page_Display(pageComp, EConfigPageType.DISPLAY,renderRange);
                        this.pageDisplay = page as UI_Config_Page_Display;
                        break;
                    case EConfigPageType.PREFER:
                        page = new UI_Config_Page_Prefer(pageComp, EConfigPageType.PREFER,renderRange);
                        this.pagePrefer = page as UI_Config_Page_Prefer;
                        break;
                    case EConfigPageType.LANGUAGE:
                        page = new UI_Config_Page_Language(pageComp, EConfigPageType.LANGUAGE,renderRange);
                        this.pageLanguage = page as UI_Config_Page_Language;
                        break;
                    case EConfigPageType.OTHER:
                        page = new UI_Config_Page_Other(pageComp, EConfigPageType.OTHER,renderRange);
                        this.pageOther = page as UI_Config_Page_Other;
                        break;
                }
                
                //只有英文地区和中文地区显示语言选项
                if (index == EConfigPageType.LANGUAGE) {
                    if (GameMgr.client_type == common.ERegionType.TRADITIONAL_CHINESE || GameMgr.client_type == common.ERegionType.ENGLISH) {
                        tabBtn.visible = true;
                    } else {
                        tabBtn.visible = false;
                        this.pageLanguage.visible = false;
                        continue;
                    }
                    
                }
                this.tabGroup.AddTabButton(tabBtn);
                let tabButton = new UI_TabGroup_TabButton(tabBtn);
                this.tabButtons.push(tabButton);
                if (page) {
                    this.pages.push(page);
                    page.builder();
                    page.onHeightChange = Laya.Handler.create(this, this.onContentHeightChange, null, false);
                }
            }
            this.tabGroup.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                this.onSelectPageChange(index, btn, manualSwitching)
            };
            this.refreshTabPosition();

        }

        private refreshTabPosition() { 
            for (let i = 0; i < this.tabButtons.length; i++) {
                let tabButton = this.tabButtons[i];
                tabButton.me.y = this.tabStartY + i * this.tabSpaceY;
            }
        }

        public show(from: EConfigFromType = EConfigFromType.DEFAULT) {
            this.from = from;
            this.startPanel();
            GameMgr.Inst.BehavioralStatistics(17);
            // if (GameMgr.gmoOpen) {
            //     UI_Recharge.getMobileBankInfo(null);
            // }
            this.tabGroup.forceSelect(EConfigPageType.AUDIO);
            this.freshRestartBtn();
            this.locking = true;
            this.enable = true;
            

            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                switch (from) {
                    case EConfigFromType.DEFAULT:
                        break;
                    case EConfigFromType.ITEM_MATCH_BGM:
                        UI_Config_Popup_Audio.Inst.show(EConfigAudioType.MATCH);
                        break;
                    case EConfigFromType.ITEM_LOBBY_BGM:
                        UI_Config_Popup_Audio.Inst.show(EConfigAudioType.LOBBY);
                        break;
                    default:
                        break;
                }
                this.locking = false;
            }));

        }

        public hide() {
            view.AudioMgr.musicMuted = view.AudioMgr.musicMuted;
            view.BgmListMgr.ResetBgm();
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Config', true);
            Laya.stage.on(EventCode.CONFIG_SLIDER_START_CHANGE, this, this.stopPanel);
            Laya.stage.on(EventCode.CONFIG_SLIDER_END_CHANGE, this, this.startPanel);
            
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Config', false);
            Laya.stage.off(EventCode.CONFIG_SLIDER_START_CHANGE, this, this.stopPanel);
            Laya.stage.off(EventCode.CONFIG_SLIDER_END_CHANGE, this, this.startPanel);
            this.pageAudio.visible = false;
            this.pageDisplay.visible = false;
            this.pagePrefer.visible = false;
            this.pageLanguage.visible = false;
            this.pageOther.visible = false;
        }



        // 清除所有设置
        public resetAllConfig() {
            let fpsmode = Laya.stage.frameRate;
            GameMgr.Inst.resetAllConfig();
            if (Laya.stage.frameRate != fpsmode) {
                // this.btn_restart.visible = true;
            }
            view.BgmListMgr.resetAllConfig();
            view.AudioMgr.resetAllConfig();
            uiscript.UI_Camera_Mode.resetAllConfig();
            Laya.LocalStorage.removeItem('clickEffect');
            let index = UI_Config.disableClickEffect;
            game.Scene_Lobby.Inst.set_lobby_click_effect(index == 0 ? game.Scene_Lobby.Inst.lobbyId : 0);
            GameMgr.Inst.hide_nickname = false;
            game.LocalStorage.setItem('hide_nickname', 'false');
            if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                UI_DesktopInfo.Inst.refreshNames();
            }
            if (UI_PaiPu.Inst && UI_PaiPu.Inst.enable) {
                UI_PaiPu.Inst.refreshAll();
            }

            if (UI_Ob.Inst.enable) {
                UI_Ob.Inst.refreshAll();
            }
            if (UI_Match_Room.Inst.enable) {
                UI_Match_Room.Inst.refreshAll();
            }
            if (UI_Hide_Name_Tip.Inst) {
                UI_Hide_Name_Tip.Inst.enable = false;
            }
            let oldDisableRandomChar = UI_Config_New.disableRandomChar;
            UI_Config_New.disableRandomChar = 0;
            const param: game.IReqSetFriendRoomRandomBotChar = { disable_random_char: 0 };
            this.locking = true;
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.setFriendRoomRandomBotChar, param, (err, res: game.IResCommon) => {
               
                if (err || res.error) {
                    UI_Config_New.disableRandomChar = oldDisableRandomChar;
                    this.freshCurrentPage();
                    UIMgr.Inst.showNetReqError(game.ERequest.setFriendRoomRandomBotChar, err, res);
                } else {
                    this.lock = false;
                }
            });
            this.freshCurrentPage();
        }

        public restartGame() {
            if (GameMgr.client_type == 'en') {
                let lan = Laya.LocalStorage.getItem('language');
                let str_id = lan == 'en' ? 8009 : (lan == 'kr' ? 8019 : 8008);
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(str_id), Laya.Handler.create(this, () => {
                    if (Laya.Browser.window['conch']) {
                        if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                            Laya.Browser.window['conch'].exit();
                        }
                    } else {
                        Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                    }
                }));
            } else {
                if (Laya.Browser.window['conch']) {
                    if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                        Laya.Browser.window['conch'].exit();
                    }
                } else {
                    Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                }
            }
        }

        public logout() {
            // UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(2718), Laya.Handler.create(this, () => {
            //     app.NetAgent.sendReq2Lobby('Lobby', 'logout', {}, () => { });
            //     Laya.LocalStorage.setItem('_pre_sociotype', '');
            //     if (Laya.Browser.window['conch']) {
            //         if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
            //             Laya.Browser.window['conch'].exit();
            //         }
            //     } else {
            //         Laya.Browser.window.location.href = GameMgr.Inst.link_url;
            //     }
            // }));
            // UI_SecondConfirm.Inst.setBtnState(true, true);
            if (GameMgr.inYoStar && !GameMgr.inDmm) {
                game.YoStarSDK.Inst.switchAccount();
            } else {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(2718), Laya.Handler.create(GameMgr.Inst, GameMgr.Inst.logout));
                UI_SecondConfirm.Inst.setBtnState(true, true);
            }
           
        }

        private onSelectPageChange(index: number, btn: Laya.Button, manualSwitching: boolean): void {
            let page = this.pages[index];
            let tabButton = this.tabButtons[index];
            tabButton.selected = (index == this.tabGroup.selectedIndex);

            if (index == this.tabGroup.selectedIndex) {
                page.show();
                this.scrollPanel.contentHeight = page.height;
                this.scrollPanel.scrollValue = 0;
                this.scrollPanel.fresh();
            } else {
                page.hide();
            }

        }

        private startPanel() { 
            this.scrollPanel.startScroll();
        }

        private stopPanel() {
            this.scrollPanel.stopScroll();
        }


        public freshRestartBtn() {
            this.restartBtn.visible = UI_Config_New.needRestart;
        }
       
        private onContentHeightChange(): void { 
            let newContentHeight = this.pages[this.tabGroup.selectedIndex].height;
            this.scrollPanel.contentHeight = newContentHeight;
        }

        private freshCurrentPage() {
            let page = this.pages[this.tabGroup.selectedIndex];
            page.refresh();
            this.onContentHeightChange();
        }

        public refreshGmoLinkState() {
            //暂未接入GMO
        }

        public get isMatchConfig(): boolean {
            return this.from == EConfigFromType.MATCH;
        }

        

    }

}