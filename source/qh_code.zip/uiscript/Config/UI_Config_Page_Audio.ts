module uiscript {

    enum EAudioLine {

        /**
         * 音量，标题
         */
        VOLUME_TITLE = 0,
        /**
         * 全局音量，音量滑动条
         */
        VOLUME_TOTAL = 1,
        /**
         * 音乐音量，音量滑动条
         */
        VOLUME_MUSIC = 2,
        /**
         * 音效音量，音量滑动条
         */
        VOLUME_EFFECT = 3,
        /**
         * 角色音量，音量滑动条
         */
        VOLUME_CHAR = 4,
        /**
         * 单角色音量，跳转按钮，二级选项
         */
        VOLUME_CHAR_SINGLE = 5,
        /**
         * 特殊语言，开关
         */
        VOLUME_SPECIAL = 6,
       

        /**
         * 曲目设置，带音频的标题
         */
        AUDIO_TITLE = 7,
        /**
         * 大厅音乐，跳转按钮
         */
        AUDIO_LOBBY_MUSIC = 8,
        /**
         * 比赛音乐，跳转按钮
         */
        AUDIO_MATCH_MUSIC = 9,

        /**
         * 播放控制，标题
         */
        PLAY_CONTROL_TITLE = 10,
        /**
         * 后台静音，开关
         */
        PLAY_CONTROL_BACKGROUND_MUTE = 11,

        /**
         * 立直音乐音量，音量滑动条
         */
        VOLUME_LICHI = 12,


    }

    export class UI_Config_Page_Audio extends UI_Config_Page_Base {
        public builder(): void {
            //音量-标题
            this.createLinePartStart(EAudioLine.VOLUME_TITLE, game.Tools.strOfLocalization('26030101'));
            //音量-全局音量，音量滑动条
            let totalVolumeLine = this.createLineSliderAudio(EAudioLine.VOLUME_TOTAL, game.Tools.strOfLocalization('26030102'), 0, 100);
            totalVolumeLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = totalVolumeLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let volumeRate = info.value / 100;
                    if (view.AudioMgr.allAudioVolume != volumeRate) {
                        // app.Log.log('change volume:' + volumeRate)
                        view.AudioMgr.allAudioVolume = volumeRate;
                    }
                    if (view.AudioMgr.allAudioMuted != info.isMute) {
                        // app.Log.log('change mute:' + info.isMute);
                        view.AudioMgr.allAudioMuted = info.isMute;
                        //如果全局静音，则后面所有的行都设置为不可操作
                        let volumeMusicLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_MUSIC);
                        volumeMusicLine.operable = !info.isMute;
                        let volumeEffectLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_EFFECT);
                        volumeEffectLine.operable = !info.isMute;
                        let volumeCharLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_CHAR);
                        volumeCharLine.operable = !info.isMute;
                        let volumeCharSingleLine = this.getLine<UI_Config_Line_JumpButton>(EAudioLine.VOLUME_CHAR_SINGLE);
                        volumeCharSingleLine.operable = !info.isMute;
                        let specialLine = this.getLine<UI_Config_Line_Toggle>(EAudioLine.VOLUME_SPECIAL);
                        specialLine.operable = !info.isMute;
                        let volumeLichiLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_LICHI);
                        volumeLichiLine.operable = !info.isMute;
                    }
                }

            }, null, false));
            //音量-音乐音量，音量滑动条
            let volumeMusicLine = this.createLineSliderAudio(EAudioLine.VOLUME_MUSIC, game.Tools.strOfLocalization('26030103'), 0, 100);
            volumeMusicLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = volumeMusicLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let volumeRate = info.value / 100;
                    if (view.AudioMgr.musicVolume != volumeRate) {
                        view.AudioMgr.musicVolume = volumeRate;
                    }
                    if (view.AudioMgr.musicMuted != info.isMute) {
                        view.AudioMgr.musicMuted = info.isMute;
                    }
                }
            }, null, false));


            //音量-音效音量，音量滑动条
            let volumeEffectLine = this.createLineSliderAudio(EAudioLine.VOLUME_EFFECT, game.Tools.strOfLocalization('26030104'), 0, 100);
            volumeEffectLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = volumeEffectLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let volumeRate = info.value / 100;
                    if (view.AudioMgr.audioVolume != volumeRate) {
                        view.AudioMgr.audioVolume = volumeRate;
                    }
                    if (view.AudioMgr.audioMuted != info.isMute) {
                        view.AudioMgr.audioMuted = info.isMute;
                    }
                }
            }, null, false));

            //音量-立直音量，音量滑动条
            let lichiVolumeLine = this.createLineSliderAudio(EAudioLine.VOLUME_LICHI, game.Tools.strOfLocalization('26030121'), 0, 100);
            lichiVolumeLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = lichiVolumeLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let volumeRate = info.value / 100;
                    if (view.AudioMgr.lizhiVolume != volumeRate) {
                        view.AudioMgr.lizhiVolume = volumeRate;
                    }
                    if (view.AudioMgr.lizhiMuted != info.isMute) {
                        view.AudioMgr.lizhiMuted = info.isMute;
                    }
                }
            }, null, false));

            //音量-角色音量，音量滑动条
            let volumeCharLine = this.createLineSliderAudio(EAudioLine.VOLUME_CHAR, game.Tools.strOfLocalization('26030105'), 0, 100);
            let charSingleJumpHandler = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                //如果在对局中，需要传入对局的角色id
                let matchIds:Array<number> = [];
                if (UI_Config_New.Inst.isMatchConfig) {
                    
                    let playerDatas = view.DesktopMgr.Inst.player_datas;
                    if (playerDatas) {
                        for (let i = 0; i < playerDatas.length; i++) { 
                            let charId = playerDatas[i]['character']['charid'];
                            //避免重复添加
                            if (matchIds.indexOf(charId) < 0) {
                                matchIds.push(charId);
                            }
                        }
                    }
                }
                UI_Config_Popup_Character_Audio.Inst.show(matchIds);
            }, null, false);
            volumeCharLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = volumeCharLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let volumeRate = info.value / 100;
                    if (view.AudioMgr.yuyinVolume != volumeRate) {
                        view.AudioMgr.yuyinVolume = volumeRate;
                    }
                    if (view.AudioMgr.yuyinMuted != info.isMute) {
                        view.AudioMgr.yuyinMuted = info.isMute;
                    }
                }
            }, null, false));

            //音量-单角色音量，跳转按钮，二级选项
            this.createLineJumpBtn(EAudioLine.VOLUME_CHAR_SINGLE, game.Tools.strOfLocalization('26030106'), game.Tools.strOfLocalization('26030003'), charSingleJumpHandler, this.normalSpace, this.jumpBtnDefaultColor, EConfigLineLevel.TWO);

            //音量-特殊语音，开关
            let specialLine = this.createLineToggle(EAudioLine.VOLUME_SPECIAL, game.Tools.strOfLocalization('26030107'),null, this.normalTitleSpace);
            specialLine.onClickHelpBtn = Laya.Handler.create(this, () => {
                //显示帮助
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Info.Inst.show(specialLine.helpInfoRenderPos, game.Tools.strOfLocalization(26030601));
            }, null, false);
            specialLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let index = specialLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let isMute = index == 1 ? true : false;
                    if (view.AudioMgr.teshuyuyinMuted != isMute) {
                        view.AudioMgr.teshuyuyinMuted = isMute;
                    }
                }
            }, null, false));

            //曲目设置-标题
            this.createLinePartStartAudio(EAudioLine.AUDIO_TITLE, game.Tools.strOfLocalization('26030108'));
            let lobbyMusicJumpHandler = Laya.Handler.create(this, () => {
                //打开大厅音乐页面
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Audio.Inst.show(EConfigAudioType.LOBBY);

            }, null, false);
            //曲目设置-大厅音乐，跳转按钮
            this.createLineJumpBtn(EAudioLine.AUDIO_LOBBY_MUSIC, game.Tools.strOfLocalization('26030109'), game.Tools.strOfLocalization('26030003'), lobbyMusicJumpHandler);
            let matchMusicJumpHandler = Laya.Handler.create(this, () => {
                //打开对局音乐页面
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Audio.Inst.show(EConfigAudioType.MATCH);
            }, null, false);
            //曲目设置-对局音乐，跳转按钮
            this.createLineJumpBtn(EAudioLine.AUDIO_MATCH_MUSIC, game.Tools.strOfLocalization('26030110'), game.Tools.strOfLocalization('26030003'), matchMusicJumpHandler, this.normalTitleSpace);
            //播放控制-标题
            this.createLinePartStart(EAudioLine.PLAY_CONTROL_TITLE, game.Tools.strOfLocalization('26030111'));
            //播放控制-后台静音，下拉框，开启，关闭
            let backgroundMuteLine = this.createLineToggle(EAudioLine.PLAY_CONTROL_BACKGROUND_MUTE, game.Tools.strOfLocalization('26030112'),null, this.normalTitleSpace);
            backgroundMuteLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let index = backgroundMuteLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let isMute = index == 0 ? true : false;
                    if (view.AudioMgr.backAudioMuted != isMute) {
                        view.AudioMgr.backAudioMuted = isMute;
                    }
                }
            }, null, false));

        }

        public show() {
            this.refresh();
            this.visible = true;

        }

        public hide() {
            this.visible = false;
        }

        public refresh(): void {
            this.loadData();
            this.refreshLinePos();
        }

        private loadData() {
            let totalVolumeLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_TOTAL);
            let totalVolumeInfo: IConfigSliderInfo = {
                value: view.AudioMgr.allAudioVolume * 100,
                isMute: view.AudioMgr.allAudioMuted
            };
            totalVolumeLine.setInfo(totalVolumeInfo);

            let volumeMusicLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_MUSIC);
            volumeMusicLine.operable = !totalVolumeInfo.isMute;
            let volumeMusicInfo: IConfigSliderInfo = {
                value: view.AudioMgr.musicVolumeTrue * 100,
                isMute: view.AudioMgr.musicMuted
            };
            volumeMusicLine.setInfo(volumeMusicInfo);

            let volumeEffectLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_EFFECT);
            volumeEffectLine.operable = !totalVolumeInfo.isMute;
            let volumeEffectInfo: IConfigSliderInfo = {
                value: view.AudioMgr.audioVolumeTrue * 100,
                isMute: view.AudioMgr.audioMuted
            };
            volumeEffectLine.setInfo(volumeEffectInfo);

            let volumeCharLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_CHAR);
            volumeCharLine.operable = !totalVolumeInfo.isMute;
            let volumeCharInfo: IConfigSliderInfo = {
                value: view.AudioMgr.yuyinVolumeTrue * 100,
                isMute: view.AudioMgr.yuyinMuted
            };
            volumeCharLine.setInfo(volumeCharInfo);


            let volumeCharSingleLine = this.getLine<UI_Config_Line_JumpButton>(EAudioLine.VOLUME_CHAR_SINGLE);
            volumeCharSingleLine.operable = !totalVolumeInfo.isMute;

            let specialLine = this.getLine<UI_Config_Line_Toggle>(EAudioLine.VOLUME_SPECIAL);
            specialLine.operable = !totalVolumeInfo.isMute;
            specialLine.setInfo(view.AudioMgr.teshuyuyinMuted ? 1 : 0);

            let lichiVolumeLine = this.getLine<UI_Config_Line_Slider_Audio>(EAudioLine.VOLUME_LICHI);
            lichiVolumeLine.operable = !totalVolumeInfo.isMute;
            let lichiVolumeInfo: IConfigSliderInfo = {
                value: view.AudioMgr.lizhiVolumeTrue * 100,
                isMute: view.AudioMgr.lizhiMuted
            }
            lichiVolumeLine.setInfo(lichiVolumeInfo);

            let backgroundMuteLine = this.getLine<UI_Config_Line_Toggle>(EAudioLine.PLAY_CONTROL_BACKGROUND_MUTE);
            let bgMuteIndex = view.AudioMgr.backAudioMuted ? 0 : 1;
            backgroundMuteLine.setInfo(bgMuteIndex);

            //在对局中不可打开大厅音乐设置界面
            let lobbyMusicLine = this.getLine<UI_Config_Line_JumpButton>(EAudioLine.AUDIO_LOBBY_MUSIC);
            if (UI_Config_New.Inst.isMatchConfig) {
                lobbyMusicLine.operable = false;
            } else {
                lobbyMusicLine.operable = true;
            }

            this.onBgmChange();
        }

        private onBgmChange() {
            let bgmLine = this.getLine<UI_Config_Line_PartStart_Audio>(EAudioLine.AUDIO_TITLE);
            let name = view.AudioMgr.musicMuted ? '' : view.AudioMgr.music_name;
            bgmLine.setInfo(name, view.BgmListMgr.type);
            if (name != '') {
                bgmLine.startRoll();
            } else {
                bgmLine.stopRoll();
            }

        }

        public onEnable(): void {
            Laya.stage.on(EventCode.ON_BGM_CHANGE, this, this.onBgmChange);
        }

        public onDisable(): void {
            Laya.stage.off(EventCode.ON_BGM_CHANGE, this, this.onBgmChange);
            let bgmLine = this.getLine<UI_Config_Line_PartStart_Audio>(EAudioLine.AUDIO_TITLE);
            bgmLine.stopRoll();
        }


    }

}