module uiscript {

    export enum EConfigPageType {
        AUDIO,
        DISPLAY,
        PREFER,
        LANGUAGE,
        OTHER
    }

    export class UI_Config_Page_Base extends UI_Component {
        protected innerPageType: EConfigPageType;
        public get pageType(): EConfigPageType {
            return this.innerPageType;
        }

        /**
         * 每一行的组件,用于按顺序渲染
         */
        protected lines: Array<UI_Config_Line_Base>;
        /**
         * 每一行的实例
         */
        protected linesDic: basic.Dictionary<number, UI_Config_Line_Base>;
        protected root: Laya.Sprite = null;
        protected totalHeight: number = 0;
        /**
         * 显示区域的限制范围，区域是一个矩形，0是左上角，1是右上角，2是右下角，3是左下角
         * 全局坐标
         */
        protected renderRange: Array<Laya.Vector2> = [];
        /**
         * 标题-普通，行间距
         */
        protected titleNormalSpace: number = 10;
        /**
         * 普通-普通，行间距
         */
        protected normalSpace: number = 5;
        /**
         * 普通-标题，行间距
         */
        protected normalTitleSpace: number = 40;

        /**
         * 跳转按钮默认标题颜色
         */
        protected jumpBtnDefaultColor: string = "#d4cfcf";

        constructor(comp: Laya.Sprite, pageType: EConfigPageType, renderRange: Array<Laya.Vector2>) {
            super(comp);
            this.innerPageType = pageType;
            this.renderRange = renderRange;
        }

        public onCreate(): void {
            this.lines = new Array<UI_Config_Line_Base>();
            this.linesDic = new basic.Dictionary<number, UI_Config_Line_Base>();
            this.root = this.me.getChildByName("root") as Laya.Sprite;
        }

        public builder() {

        }

        public refresh() {

        }

        public reset() {
            this.lines.forEach(line => {
                line.reset();
            });
        }

        public getInfo(lineId: number) {
            return this.linesDic.get(lineId).getInfo();
        }

        public addLine(id: number, line: UI_Config_Line_Base) {
            this.lines.push(line);
            this.linesDic.set(id, line);
        }

        // 创建各种类型的行

        public createLinePartStart(id: number, title: string, space: number = this.titleNormalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_PartStart {
            let sprite = new ui.both_ui.config.config_line_part_startUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_PartStart(sprite, id, lineLevel);
            line.init(title);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLinePartStartAudio(id: number, title: string, space: number = this.titleNormalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_PartStart_Audio {
            let sprite = new ui.both_ui.config.config_line_part_start_audioUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_PartStart_Audio(sprite, id, lineLevel);
            line.init(title);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLineDropDown(id: number, title: string, titles: Array<string>, space: number = this.normalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_DropDown {
            let sprite = new ui.both_ui.config.config_line_dropdownUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_DropDown(sprite, id, lineLevel);
            line.init(title, titles, this.renderRange);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLineJumpBtn(id: number, title: string, btnTitle: string, onClick: Laya.Handler, space: number = this.normalSpace, btnTitleColor: string = this.jumpBtnDefaultColor, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_JumpButton {
            let sprite = new ui.both_ui.config.config_line_jump_btnUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_JumpButton(sprite, id, lineLevel);
            line.init(title, btnTitle, onClick, btnTitleColor);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLineSlider(id: number, title: string, min: number, max: number, space: number = this.normalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_Slider {
            let sprite = new ui.both_ui.config.config_line_sliderUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_Slider(sprite, id, lineLevel);
            line.init(title, min, max);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLineSliderAudio(id: number, title: string, min: number, max: number, space: number = this.normalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_Slider_Audio {
            let sprite = new ui.both_ui.config.config_line_slider_audioUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_Slider_Audio(sprite, id, lineLevel);
            line.init(title, min, max);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public createLineToggle(id: number, title: string, titles: Array<string> = null, space: number = this.normalSpace, lineLevel: EConfigLineLevel = EConfigLineLevel.ONE): UI_Config_Line_Toggle {
            let sprite = new ui.both_ui.config.config_line_toggleUI();
            this.me.addChild(sprite)
            let line = new UI_Config_Line_Toggle(sprite, id, lineLevel);
            line.init(title, titles);
            line.space = space;
            this.addLine(id, line);
            return line;
        }

        public refreshLinePos() {
            let y = 0;
            this.totalHeight = 0;
            for (let index = 0; index < this.lines.length; index++) {
                let line = this.lines[index];
                line.pos(0, y)
                y += line.getHeight() + line.space;
                this.totalHeight += line.getHeight() + line.space;
            }
            this.me.height = this.totalHeight;
            this.onHeightChangeHandler?.run();
        }

        public show() {
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public get height(): number {
            return this.totalHeight;
        }

        private onHeightChangeHandler: Laya.Handler = null;
        public set onHeightChange(handler: Laya.Handler) {
            this.onHeightChangeHandler = handler;
        }
       



        public getLine<T>(id:number): T {
            if (this.linesDic.has(id)) {
                return this.linesDic.get(id) as T;
            }
            return null;
        }

        public getLineIndex(id: number): number {
            let line = this.getLine<UI_Config_Line_Base>(id);
            if (line) {
                return this.lines.findIndex((v => v.id == line.id));
            }
            return -1;
        }

    }

}