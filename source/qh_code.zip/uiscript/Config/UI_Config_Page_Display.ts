module uiscript {

    enum EDisplayLine { 
        /**
         * 画面，标题
         */
        DISPLAY_TITLE = 0,
        /**
         * 画面-帧率，下拉框
         */
        DISPLAY_FRAME_RATE = 1,
        /**
         * 画面-活动特效开关，开关
         */
        DISPLAY_ACTIVITY_EFFECT = 2,
    }

    export class UI_Config_Page_Display extends UI_Config_Page_Base {

        public static fpsSaveKey: string = 'fpsmode';
        public static activityEffectSaveKey: string = 'displayActivityEffect';
        public static fpsKeys: string[] = ['fast', 'slow'];
        public builder(): void {
            //画面，标题
            this.createLinePartStart(EDisplayLine.DISPLAY_TITLE, game.Tools.strOfLocalization(26030201))
            //画面-帧率，下拉框
            let frameRateLine = this.createLineDropDown(EDisplayLine.DISPLAY_FRAME_RATE, game.Tools.strOfLocalization(26030205), [game.Tools.strOfLocalization(26030207), game.Tools.strOfLocalization(26030206)]);
            frameRateLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let index = frameRateLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let fpsmode = UI_Config_Page_Display.fpsKeys[index];
                    if (Laya.LocalStorage.getItem(UI_Config_Page_Display.fpsSaveKey) == fpsmode) {
                        return;
                    }
                    Laya.LocalStorage.setItem(UI_Config_Page_Display.fpsSaveKey, fpsmode);
                    UI_Config_New.needRestart = true;
                }
            }, null, false));
            //增加提示弹窗
            frameRateLine.onClickHelpBtn = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Info.Inst.show(frameRateLine.helpInfoRenderPos, game.Tools.strOfLocalization(26030606));
            }, null, false);
            //画面-活动特效开关，开关
            let activityEffectLine = this.createLineToggle(EDisplayLine.DISPLAY_ACTIVITY_EFFECT, game.Tools.strOfLocalization(26030210));
            activityEffectLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = activityEffectLine.getInfo();
                    let isOpen = info == 0;
                    if (GameMgr.Inst.bannedActivityEffect == !isOpen) {
                        return;
                    }
                    GameMgr.Inst.bannedActivityEffect = !isOpen;
                    game.LocalStorage.setItem(UI_Config_Page_Display.activityEffectSaveKey, isOpen ? 'true' : 'false');
                }
            }, null, false));
        }

        public show() {
            this.refresh();
            this.visible = true;

        }

        public hide() {
            this.visible = false;
        }

        public refresh(): void {
            this.loadData();
            this.refreshLinePos();
        }

        public onEnable(): void {
            
        }

        public onDisable(): void {
            
        }

        private loadData() {
            let frameRateLine = this.getLine<UI_Config_Line_DropDown>(EDisplayLine.DISPLAY_FRAME_RATE);
            let fpsMode = Laya.LocalStorage.getItem(UI_Config_Page_Display.fpsSaveKey);
            let fpsIndex = UI_Config_Page_Display.fpsKeys.indexOf(fpsMode);
            frameRateLine.setInfo(fpsIndex);
            let activityEffectLine = this.getLine<UI_Config_Line_Toggle>(EDisplayLine.DISPLAY_ACTIVITY_EFFECT);
            activityEffectLine.setInfo(GameMgr.Inst.bannedActivityEffect ? 1 : 0);
        }

      


    }

}