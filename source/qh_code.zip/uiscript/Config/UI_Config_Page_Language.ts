module uiscript {

    enum ELanguageLine {
        /**
         * 语言设置，标题
         */
        LANGUAGE_TITLE = 0,
        /**
         * 语言设置，选择语言，跳转按钮
         */
        LANGUAGE_LANGUAGE_SET = 1,

    }

    export class UI_Config_Page_Language extends UI_Config_Page_Base {
        public builder(): void {
            this.createLinePartStart(ELanguageLine.LANGUAGE_TITLE, game.Tools.strOfLocalization('26030401'))

            this.createLineJumpBtn(ELanguageLine.LANGUAGE_LANGUAGE_SET, game.Tools.strOfLocalization('26030402'), game.Tools.strOfLocalization('26030404'), Laya.Handler.create(this, () => {
                // 打开语言选择页面
                UI_Config_Popup_Language_Select.Inst.show();
            }, null, false));

        }

        public show() {
            this.refresh();
            this.visible = true;

        }

        public hide() {
            this.visible = false;
        }

        public refresh(): void {
            this.loadData();
            this.refreshLinePos();
        }

        public onEnable(): void {
            Laya.stage.on(EventCode.CONFIG_LANGUAGE_CHANGE, this, this.loadData);

        }

        public onDisable(): void {
            Laya.stage.off(EventCode.CONFIG_LANGUAGE_CHANGE, this, this.loadData);

        }

        private loadData() {
            let languageLine = this.getLine<UI_Config_Line_JumpButton>(ELanguageLine.LANGUAGE_LANGUAGE_SET);
            languageLine.btnTitle = this.getLanguageNameByCode(UI_Config_Popup_Language_Select.currentLanguage);
        }

        private getLanguageNameByCode(code: string): string { 
            let languageName = game.Tools.strOfLocalization('26030404'); //默认简体中文
            switch (code) { 
                case 'chs':
                    languageName = game.Tools.strOfLocalization('26030404');
                    break;
                case 'chs_t':
                    languageName = game.Tools.strOfLocalization('26030405');
                    break;
                case 'en':
                    languageName = game.Tools.strOfLocalization('26030407');
                    break;
                case 'jp':
                    languageName = game.Tools.strOfLocalization('26030406');
                    break;
                case 'kr':
                    languageName = game.Tools.strOfLocalization('26030408');
                    break;
            }
            return languageName;
        }
    }

}