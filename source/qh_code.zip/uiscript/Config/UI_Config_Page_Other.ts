module uiscript {
    enum EOtherLine {
        /**
         * 其它，标题
         */
        OTHER_TITLE = 0,
        /**
         * 其它，役种一览，跳转按钮
         */
        OTHER_RULE = 1,
        /**
         * 其它，礼品码，跳转按钮
         */
        OTHER_GIFT_CODE = 2,
        /**
         * 其它，客服中心，跳转按钮
         */
        OTHER_SERVICE_CENTER = 3,
        /**
         * 其它，用户中心，跳转按钮
         */
        OTHER_USER_CENTER = 4,
        /**
         * 其它，绑定邮箱，跳转按钮
         * 仅限chs
         */
        OTHER_BIND_MAIL = 5,
        /**
         * 其它，用户协议，跳转按钮
         */
        OTHER_USER_GREEMENT = 6,
        /**
         * 其它，隐私政策，跳转按钮
         */
        OTHER_PRIVACY = 7,
        /**
         * 其它，特定商取引法，跳转按钮
         * 仅限jp
         */
        OTHER_SPECIAL_LAW1 = 8,
        /**
         * 其它，資金決済法，跳转按钮
         * 仅限jp
         */
        OTHER_SPECIAL_LAW2 = 9,
        /**
         * 其它，认证标记，开关
         */
        OTHER_VERIFIED = 10,
        /**
         * 其它，恢复默认设置，按钮
         */
        OTHER_RESET = 11,
        /**
         * 其它，删除账号，跳转按钮
         * 仅限chs
         */
        OTHER_DELETE_ACCOUNT = 12,
        /**
         * 其它，主播模式,开关
         */
        OTHER_STREAMER = 13,
        /**
         * 其它，主播模式，好友名称，下拉框
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_FRIEND_NAME = 14,
        /**
         * 其它，主播模式，跨服比赛名称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_CROSS_SERVER_NAME = 15,
        /**
         * 其它，主播模式，同服比赛名称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_SAME_SERVER_MATCH_NAME = 16,
        /**
         * 其它，主播模式，牌谱名称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_PAIPU_NAME = 17,
        /**
         * 其它，主播模式，观战名称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_BROADCAST_NAME = 18,
        /**
         * 其它，主播模式，赛事名称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_MATCH_ROOM_NAME = 19,
        /**
         * 其它，主播模式，排行榜昵称，开关
         * 二级选项，主播模式开启时显示
         */
        OTHER_STREAMER_BILLBOARD_NAME = 20,
    }

    export class UI_Config_Page_Other extends UI_Config_Page_Base {
        private verified_change_cd: number = 0;
        public builder(): void {
            //其它，标题
            this.createLinePartStart(EOtherLine.OTHER_TITLE, game.Tools.strOfLocalization(26030501));
            //其它，役种一览，跳转按钮
            let onClickJumpRule = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                // UI_Config_New.Inst.hide();
                UI_Rules.Inst.show(0);
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_RULE, game.Tools.strOfLocalization(26030502), game.Tools.strOfLocalization(26030004), onClickJumpRule);
            //其它，礼品码，跳转按钮
            let onClickJumpGiftCode = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                // UI_Config_New.Inst.hide();
                UI_Config_Popup_Giftcode.Inst.show();
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_GIFT_CODE, game.Tools.strOfLocalization(26030503), game.Tools.strOfLocalization(26030005), onClickJumpGiftCode);
            //其它，客服中心，跳转按钮
            let onClickServiceCenter = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                this.onClickServiceCenter();
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_SERVICE_CENTER, game.Tools.strOfLocalization(26030505), game.Tools.strOfLocalization(26030009), onClickServiceCenter);
            //其它，用户中心，跳转按钮
            if (GameMgr.client_type != 'chs_t') {
                let onClickUserCenter = Laya.Handler.create(this, () => {
                    if (UI_Config_New.Inst.lock) return;
                    this.onClickUserCenter();
                }, null, false);
                this.createLineJumpBtn(EOtherLine.OTHER_USER_CENTER, game.Tools.strOfLocalization(26030506), game.Tools.strOfLocalization(26030009), onClickUserCenter);
            }
            //其它，邮箱认证，跳转按钮
            if (GameMgr.client_type == 'chs_t') {
                let onClickBindMail = Laya.Handler.create(this, () => {
                    if (UI_Config_New.Inst.lock) return;
                    // UI_Config_New.Inst.hide();
                    if (game.LoginMgr.sociotype >= 1) {
                        UI_Config_Popup_Bind_Mail_Password.Inst.show();
                    } else {
                        UI_Config_Popup_Bind_Mail.Inst.show();
                    }
                }, null, false);
                this.createLineJumpBtn(EOtherLine.OTHER_BIND_MAIL, game.Tools.strOfLocalization(26030507), game.Tools.strOfLocalization(26030508), onClickBindMail);
            }
            //其它，用户协议，跳转按钮
            let onClickUserAgreement = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                this.onClickUserAgreement();
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_USER_GREEMENT, game.Tools.strOfLocalization(26030516), game.Tools.strOfLocalization(26030004), onClickUserAgreement);
            //其它，隐私政策，跳转按钮
            let onClickPrivacyPolicy = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                this.onClickPrivacyPolicy();
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_PRIVACY, game.Tools.strOfLocalization(26030517), game.Tools.strOfLocalization(26030004), onClickPrivacyPolicy);
            //其它，特定商取引法，跳转按钮
            //其它，資金決済法，跳转按钮
            if (GameMgr.client_type == 'jp') {
                let onClickSpecialLaw1 = Laya.Handler.create(this, () => {
                    if (UI_Config_New.Inst.lock) return;
                    this.onClickSpecialLaw1();
                }, null, false);
                this.createLineJumpBtn(EOtherLine.OTHER_SPECIAL_LAW1, game.Tools.strOfLocalization(26030518), game.Tools.strOfLocalization(26030004), onClickSpecialLaw1);
                let onClickSpecialLaw2 = Laya.Handler.create(this, () => {
                    if (UI_Config_New.Inst.lock) return;
                    this.onClickSpecialLaw2();
                }, null, false);
                this.createLineJumpBtn(EOtherLine.OTHER_SPECIAL_LAW2, game.Tools.strOfLocalization(26030519), game.Tools.strOfLocalization(26030004), onClickSpecialLaw2);
            }
            //其它，认证标记，下拉框
            let verifiedLine = this.createLineToggle(EOtherLine.OTHER_VERIFIED, game.Tools.strOfLocalization(26030520));
            verifiedLine.onClickHelpBtn = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Info.Inst.show(verifiedLine.helpInfoRenderPos, game.Tools.strOfLocalization(26030604));
            }, null, false);
            verifiedLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = verifiedLine.getInfo();
                    let isShowVerified = info == 0;
                    if (this.isShowVerified == isShowVerified) return;
                    if (game.Tools.getServerTime() < this.verified_change_cd) {
                        //恢复原设置
                        verifiedLine.setInfo(this.isShowVerified ? 0 : 1);
                        return;
                    }
                    this.verified_change_cd = game.Tools.getServerTime() + 1000;
                    let param: game.IReqSetVerifiedHidden = {
                        verified_hidden: info == 0 ? 0 : 1,
                    }
                    app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.setVerifiedHidden, param, (err, res) => {
                        this.verified_change_cd = 0;
                        if (err || res['error']) {
                            uiscript.UIMgr.Inst.showNetReqError(game.ERequest.setVerifiedHidden, err, res);
                            //恢复原设置
                            verifiedLine.setInfo(this.isShowVerified ? 0 : 1);
                            return;
                        } else {
                            GameMgr.Inst.accountVerifiedData.verified_hidden = param.verified_hidden;
                            if (isShowVerified) {
                                GameMgr.Inst.account_data['verified'] = GameMgr.Inst.accountVerifiedData.verified_value;
                                GameMgr.Inst.accountVerifiedData.verified_value = 0;
                            } else {
                                GameMgr.Inst.accountVerifiedData.verified_value = GameMgr.Inst.account_data['verified'];
                                GameMgr.Inst.account_data['verified'] = 0;
                            }
                            if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                                UI_DesktopInfo.Inst.refreshNames();
                            }
                            if (UI_PaiPu.Inst && UI_PaiPu.Inst.enable) {
                                UI_PaiPu.Inst.refreshAll();
                            }
                            if (UI_Ob.Inst.enable) {
                                UI_Ob.Inst.refreshAll();
                            }
                            if (UI_Match_Room.Inst.enable) {
                                UI_Match_Room.Inst.refreshAll();
                            }
                            if (UI_Lobby.Inst && UI_Lobby.Inst.enable) {
                                UI_Lobby.Inst.top.refresh();
                            }
                        }
                    });

                }
            }, null, false));

            //其它，恢复默认设置，跳转按钮
            let onClickReset = Laya.Handler.create(this, () => {
                if (UI_Config_New.Inst.lock) return;
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(26030522), Laya.Handler.create(this, () => {
                    UI_Config_New.Inst.resetAllConfig();
                }));
            }, null, false);
            this.createLineJumpBtn(EOtherLine.OTHER_RESET, game.Tools.strOfLocalization(26030521), game.Tools.strOfLocalization(26030534), onClickReset);
            //其它，删除账号，跳转按钮,web端无
            //其它，主播模式，下拉框
            let streamerLine = this.createLineToggle(EOtherLine.OTHER_STREAMER, game.Tools.strOfLocalization(26030524));
            streamerLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = streamerLine.getInfo();
                    let isHide = info == 0;
                    if (GameMgr.Inst.hide_nickname == isHide) {
                        return;
                    }
                    GameMgr.Inst.hide_nickname = isHide;
                    game.LocalStorage.setItem('hide_nickname', isHide ? 'true' : 'false');
                    if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                        UI_DesktopInfo.Inst.refreshNames();
                    }
                    if (UI_PaiPu.Inst && UI_PaiPu.Inst.enable) {
                        UI_PaiPu.Inst.refreshAll();
                    }

                    if (UI_Ob.Inst.enable) {
                        UI_Ob.Inst.refreshAll();
                    }
                    if (UI_Match_Room.Inst.enable) {
                        UI_Match_Room.Inst.refreshAll();
                    }
                    if (UI_Hide_Name_Tip.Inst) {
                        UI_Hide_Name_Tip.Inst.enable = isHide;
                    }
                    this.onStreamerOptionChanged();
                    this.refreshLinePos();
                }
            }, null, false));
            //其它，主播模式-对局名称，二级选项,下拉框
            let friendNameline = this.createLineDropDown(EOtherLine.OTHER_STREAMER_FRIEND_NAME, game.Tools.strOfLocalization(26030527), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            friendNameline.selectEnable = false;
            //其它，主播模式-跨服比赛名称，二级选项,下拉框
            let crossServerMatchNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_CROSS_SERVER_NAME, game.Tools.strOfLocalization(26030528), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            crossServerMatchNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = crossServerMatchNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_other_zone_name != isHide) {
                        GameMgr.Inst.hide_other_zone_name = isHide;
                        game.LocalStorage.setItem('hide_other_zone_name', isHide ? 'true' : 'false');
                        if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                            UI_DesktopInfo.Inst.refreshNames();
                        }
                    }
                }
            }, null, false));
            //其它，主播模式-同服比赛名称，二级选项,下拉框
            let sameServerMatchNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_SAME_SERVER_MATCH_NAME, game.Tools.strOfLocalization(26030529), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            sameServerMatchNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = sameServerMatchNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_desktop_name != isHide) {
                        GameMgr.Inst.hide_desktop_name = isHide;
                        game.LocalStorage.setItem('hide_desktop_name', isHide ? 'true' : 'false');
                        if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                            UI_DesktopInfo.Inst.refreshNames();
                        }
                    }
                }
            }, null, false));
            //其它，主播模式-牌谱名称，二级选项,下拉框
            let paipuNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_PAIPU_NAME, game.Tools.strOfLocalization(26030530), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            paipuNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = paipuNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_paipu_name != isHide) {
                        GameMgr.Inst.hide_paipu_name = isHide;
                        game.LocalStorage.setItem('hide_paipu_name', isHide ? 'true' : 'false');
                        if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                            UI_DesktopInfo.Inst.refreshNames();
                        }
                        if (UI_PaiPu.Inst && UI_PaiPu.Inst.enable) {
                            UI_PaiPu.Inst.refreshAll();
                        }
                    }
                }
            }, null, false));
            //其它，主播模式-观战名称，二级选项,下拉框
            let broadcastNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_BROADCAST_NAME, game.Tools.strOfLocalization(26030531), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            broadcastNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = broadcastNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_ob_name != isHide) {
                        GameMgr.Inst.hide_ob_name = isHide;
                        game.LocalStorage.setItem('hide_ob_name', isHide ? 'true' : 'false');
                        if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                            UI_DesktopInfo.Inst.refreshNames();
                        }
                        if (UI_Ob.Inst.enable) {
                            UI_Ob.Inst.refreshAll();
                        }
                    }
                }
            }, null, false));
            //其它，主播模式-赛事名称，二级选项,下拉框
            let matchRoomNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_MATCH_ROOM_NAME, game.Tools.strOfLocalization(26030532), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            matchRoomNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = matchRoomNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_match_name != isHide) {
                        GameMgr.Inst.hide_match_name = isHide;
                        game.LocalStorage.setItem('hide_match_name', isHide ? 'true' : 'false');
                        if (UI_DesktopInfo.Inst && UI_DesktopInfo.Inst.enable) {
                            UI_DesktopInfo.Inst.refreshNames();
                        }
                        if (UI_Match_Room.Inst.enable) {
                            UI_Match_Room.Inst.refreshAll();
                        }
                    }
                }
            }, null, false));
            //其它，主播模式-排行榜昵称，二级选项,下拉框
            let billboardNameLine = this.createLineToggle(EOtherLine.OTHER_STREAMER_BILLBOARD_NAME, game.Tools.strOfLocalization(26030533), [
                game.Tools.strOfLocalization(26030525),
                game.Tools.strOfLocalization(26030526)
            ], this.normalSpace, EConfigLineLevel.TWO);
            billboardNameLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let isHide = billboardNameLine.getInfo() == 1;
                    if (GameMgr.Inst.hide_rank_name != isHide) {
                        GameMgr.Inst.hide_rank_name = isHide;
                        game.LocalStorage.setItem('hide_rank_name', isHide ? 'true' : 'false');
                    }
                }
            }, null, false));
        }

        public show() {
            this.refresh();
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public onEnable(): void {

        }

        public onDisable(): void {

        }

        private loadData() {
            this.freshEmailBind();
            let verifiedLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_VERIFIED);
            if (GameMgr.Inst.account_data['verified'] || GameMgr.Inst.accountVerifiedData.verified_value) {
                verifiedLine.setInfo(this.isShowVerified ? 0 : 1);
            } else {
                verifiedLine.visible = false;
            }
            let streamerLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER);
            streamerLine.setInfo(GameMgr.Inst.hide_nickname ? 0 : 1);
            this.onStreamerOptionChanged();
            let friendNameLine = this.getLine<UI_Config_Line_DropDown>(EOtherLine.OTHER_STREAMER_FRIEND_NAME);
            friendNameLine.setInfo(1);
            let crossServerMatchNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_CROSS_SERVER_NAME);
            crossServerMatchNameLine.setInfo(GameMgr.Inst.hide_other_zone_name ? 1 : 0);
            let sameServerMatchNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_SAME_SERVER_MATCH_NAME);
            sameServerMatchNameLine.setInfo(GameMgr.Inst.hide_desktop_name ? 1 : 0);
            let paipuNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_PAIPU_NAME);
            paipuNameLine.setInfo(GameMgr.Inst.hide_paipu_name ? 1 : 0);
            let broadcastNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_BROADCAST_NAME);
            broadcastNameLine.setInfo(GameMgr.Inst.hide_ob_name ? 1 : 0);
            let matchRoomNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_MATCH_ROOM_NAME);
            matchRoomNameLine.setInfo(GameMgr.Inst.hide_match_name ? 1 : 0);
            let billboardNameLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER_BILLBOARD_NAME);
            billboardNameLine.setInfo(GameMgr.Inst.hide_rank_name ? 1 : 0);

        }

        public refresh(): void {
            this.loadData();
            this.refreshLinePos();
        }

        private freshEmailBind() {
            if (GameMgr.client_type == 'chs_t') {
                let bindMailLine = this.getLine<UI_Config_Line_JumpButton>(EOtherLine.OTHER_BIND_MAIL);
                if (GameMgr.Inst.account_data['email_verify']) {
                    //邮箱已验证
                    bindMailLine.btnTitle = game.Tools.strOfLocalization('26030509');
                    bindMailLine.btnTitleColor = '#8dff25';

                } else {
                    //邮箱未验证
                    bindMailLine.btnTitle = game.Tools.strOfLocalization('26030508');
                    bindMailLine.btnTitleColor = '#edb26f';
                }
            }
        }


        /**
         * 点击客服中心
         */
        private onClickServiceCenter() {
            //打开客服中心界面，每个语言有不同的处理
            if (GameMgr.client_type == 'chs_t') {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3151), Laya.Handler.create(this, () => {
                    let url: string = GameMgr.config_data['wapchat_url'] + '?'; //'https://ykf-webchat.7moor.com/wapchat.html?';
                    url += 'fromUrl=' + game.Tools.getFinalUrl(GameMgr.config_data['homepage_url']);
                    url += '&urlTitle=' + '网页';
                    if (GameMgr.client_language == 'chs') {
                        url += '&accessId=4eb5a8b0-aafc-11ea-b418-397d5a9a3f68'
                        url += '&language=' + 'ZHCN';
                    } else {
                        url += '&accessId=4184be70-95b1-11ea-b027-616616b0ded6'
                        url += '&language=' + 'EN';
                    }
                    let d_customField = {};
                    d_customField['登陆状态'] = '已登录';
                    d_customField['昵称'] = GameMgr.Inst.account_data['nickname'];
                    d_customField['游戏ID'] = GameMgr.Inst.account_id;
                    d_customField['登陆账号名'] = game.LoginMgr.sociotype == 0 ? game.LocalStorage.getItem('account') : ('第三方登陆:' + game.LoginMgr.sociotype);
                    d_customField['vip等级'] = GameMgr.Inst.account_data['vip'];
                    let d_level = cfg.level_definition.level_definition.get(GameMgr.Inst.account_data['level']['id']);
                    if (d_level) {
                        d_customField['四麻段位'] = d_level['full_name_chs'];
                    } else {
                        d_customField['四麻段位'] = '无';
                    }
                    let d_level3 = cfg.level_definition.level_definition.get(GameMgr.Inst.account_data['level3']['id']);
                    if (d_level3) {
                        d_customField['三麻段位'] = d_level['full_name_chs'];
                    } else {
                        d_customField['三麻段位'] = '无';
                    }
                    d_customField['平台'] = '网页';
                    d_customField['版本'] = game.ResourceVersion.version;
                    let d_otherParams = {};
                    d_otherParams['nickName'] = GameMgr.Inst.account_data['nickname'];

                    url += '&customField=' + JSON.stringify(d_customField);
                    url += '&otherParams=' + JSON.stringify(d_otherParams);
                    url += '&clientId=' + game.Tools.encode_account_id2(GameMgr.Inst.account_id);

                    game.Tools.open_link(url);
                }));
                UI_SecondConfirm.Inst.setBtnState(true, true);
            } else {
                game.YoStarSDK.Inst.showAiHelp();
            }
        }

        /**
         * 点击用户中心
         */
        private onClickUserCenter() {
            game.YoStarSDK.Inst.userCenter();
        }

        /**
         * 点击用户协议
         */
        private onClickUserAgreement() {
            if (GameMgr.client_type == 'chs_t') {
                // UI_Config_New.Inst.hide();
                UI_User_Xieyi_enjp.Inst.show(`docs/chs_t/fuwuxieyi_${GameMgr.client_language}.txt`);
            } else {
                game.YoStarSDK.Inst.showAgreement(["user_agreement"]);
            }
        }

        /**
         * 点击隐私条款
         */
        private onClickPrivacyPolicy() {
            if (GameMgr.client_type == 'chs_t') {
                // UI_Config_New.Inst.hide();
                UI_User_Xieyi_enjp.Inst.show(`docs/chs_t/yinsitiaokuan_${GameMgr.client_language}.txt`);
            } else if (GameMgr.client_type == 'kr') {
                game.YoStarSDK.Inst.showAgreement(["credit_investigation"]);
            } else {
                game.YoStarSDK.Inst.showAgreement(["privacy_agreement"]);
            }
        }


        /**
         * 点击特定商取引法
         */
        private onClickSpecialLaw1() {
            if (GameMgr.inDmm) {
                // UI_Config_New.Inst.hide();
                UI_User_Xieyi_enjp.Inst.show('docs/jp_falv1_dmm.txt');
            } else {
                game.YoStarSDK.Inst.showAgreement(["specific_commercial_transaction_act"]);
            }
        }

        /**
         * 点击資金決済法
         */
        private onClickSpecialLaw2() {
            game.YoStarSDK.Inst.showAgreement(["fund_settlement_algorithm"]);
        }

        private onStreamerOptionChanged() {
            let streamerLine = this.getLine<UI_Config_Line_Toggle>(EOtherLine.OTHER_STREAMER);
            let isOpen = streamerLine.getInfo() == 0;
            let optionIds = [
                EOtherLine.OTHER_STREAMER_FRIEND_NAME,
                EOtherLine.OTHER_STREAMER_CROSS_SERVER_NAME,
                EOtherLine.OTHER_STREAMER_SAME_SERVER_MATCH_NAME,
                EOtherLine.OTHER_STREAMER_PAIPU_NAME,
                EOtherLine.OTHER_STREAMER_BROADCAST_NAME,
                EOtherLine.OTHER_STREAMER_MATCH_ROOM_NAME,
                EOtherLine.OTHER_STREAMER_BILLBOARD_NAME,
            ];
            for (let i = 0; i < optionIds.length; i++) {
                let line = this.getLine <UI_Config_Line_Base>(optionIds[i]);
                line.visible = isOpen;
            }
        }

        private get isShowVerified(): boolean {
            return !(GameMgr.Inst.accountVerifiedData.verified_hidden || 0);
        }


    }

}