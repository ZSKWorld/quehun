module uiscript {
    enum EPreferLine {
        /**
         * 对局，标题
         */
        MATCH_TITLE = 0,
        /**
         * 对局，出牌模式，下拉菜单
         */
        MATCH_PLAY_CARD_WAY = 1,
        /**
         * 对局，双击过牌，开关
         */
        MATCH_DOUBLE_CLICK_PASS = 2,
        /**
         * 对局，牌面角标，下拉菜单
         * 仅限en,kr
         */
        MATCH_CARD_NUMBER_SHOW = 3,
        /**
         * 使用偏好，标题
         */
        USING_TITLE = 4,
        /**
         * 使用偏好，留言，下拉菜单
         * 除中文区
         */
        USING_MESSAGE = 5,
        /**
         * 使用偏好，宿舍角色显示，跳转按钮
         */
        USING_CHAR_IN_SUSHE = 6,
        /**
         * 使用偏好，动态服饰，开关
         */
        USING_DONGTAI = 7,
        /**
         * 使用偏好，电脑形象，下拉菜单
         */
        USING_AI_SKIN = 8,
        /**
         * 使用偏好，大厅特效，下拉菜单
         */
        USING_LOBBY_EFFECT = 9,



    }
    export class UI_Config_Page_Prefer extends UI_Config_Page_Base {
        private comment_change_cd: number = 0;
        private ai_look_change_cd: number = 0;
        public builder(): void {
            //对局，标题
            this.createLinePartStart(EPreferLine.MATCH_TITLE, game.Tools.strOfLocalization('26030301'))
            //对局，出牌模式，下拉菜单
            let playCardWayLine = this.createLineDropDown(EPreferLine.MATCH_PLAY_CARD_WAY, game.Tools.strOfLocalization('26030302'), [
                game.Tools.strOfLocalization('26030303'),
                game.Tools.strOfLocalization('26030304'),
            ]);
            playCardWayLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = playCardWayLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    if (view.DesktopMgr.click_prefer == info) {
                        return;
                    }
                    view.DesktopMgr.click_prefer = info;
                    Laya.LocalStorage.setItem('click_prefer', info.toString());
                }
            }, null, false));

            //对局，双击过牌，下拉菜单
            let hasNext = GameMgr.client_language == 'en' || GameMgr.client_language == 'kr';
            let doubleClickPassLine = this.createLineToggle(EPreferLine.MATCH_DOUBLE_CLICK_PASS, game.Tools.strOfLocalization('26030305'),[], hasNext ? this.normalSpace : this.normalTitleSpace);
            doubleClickPassLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                let info = doubleClickPassLine.getInfo();
                if (operateType == EConfigOpreateType.USER) {
                    let passValue = info == 0 ? 1 : 0;
                    if (view.DesktopMgr.double_click_pass == passValue) {
                        return;
                    }
                    view.DesktopMgr.double_click_pass = passValue
                    Laya.LocalStorage.setItem('double_click_pass', passValue.toString());
                }
            }, null, false));
            //对局，牌面角标，下拉菜单
            if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
                let cardNumberShowLine = this.createLineDropDown(EPreferLine.MATCH_CARD_NUMBER_SHOW, game.Tools.strOfLocalization('26030307'), [
                    game.Tools.strOfLocalization('26030308'),
                    game.Tools.strOfLocalization('26030309'),
                ], this.normalTitleSpace);

                cardNumberShowLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                    let info = cardNumberShowLine.getInfo();
                    let isOpen = info == 0;
                    if (operateType == EConfigOpreateType.USER) {
                        if (view.DesktopMgr.en_mjp == isOpen) {
                            return;
                        }
                        game.LocalStorage.setItem('en_mjp', isOpen ? 'true' : 'false');
                        view.DesktopMgr.en_mjp = isOpen;
                        GameMgr.Inst.load_mjp_view();
                        GameMgr.Inst.load_touming_mjp_view();
                        GameMgr.Inst.loadSpecialMJPMView();
                    }
                }, null, false));
            }

            //使用偏好，标题
            this.createLinePartStart(EPreferLine.USING_TITLE, game.Tools.strOfLocalization('26030310'))
            //使用偏好，留言，下拉菜单
            if (GameMgr.client_type != 'chs_t') {
                let messageLine = this.createLineDropDown(EPreferLine.USING_MESSAGE, game.Tools.strOfLocalization('26030311'), [
                    game.Tools.strOfLocalization('26030312'),
                    game.Tools.strOfLocalization('26030313'),
                    game.Tools.strOfLocalization('26030314'),
                ]);
                messageLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                    if (operateType == EConfigOpreateType.USER) {
                        let info = messageLine.getInfo();
                        if (GameMgr.Inst.comment_allow == info) return;
                        if (game.Tools.getServerTime() < this.comment_change_cd) {
                            //恢复原设置
                            messageLine.setInfo(GameMgr.Inst.comment_allow);
                            return;
                        }
                        this.comment_change_cd = game.Tools.getServerTime() + 1000;
                        app.NetAgent.sendReq2Lobby('Lobby', 'updateCommentSetting', { comment_allow: info }, (err, res) => {
                            this.comment_change_cd = 0;
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError('updateCommentSetting', err, res);
                                //恢复原设置
                                messageLine.setInfo(GameMgr.Inst.comment_allow);
                            } else {
                                GameMgr.Inst.comment_allow = info;
                            }
                        });
                    }
                }, null, false));
            }
            //使用偏好，宿舍角色显示，跳转按钮
            let charInSusheHandler = Laya.Handler.create(this, () => {
                //打开宿舍角色显示页面
                UI_Config_Popup_Character_Visible.Inst.show();
            }, null, false);
            this.createLineJumpBtn(EPreferLine.USING_CHAR_IN_SUSHE, game.Tools.strOfLocalization('26030315'), game.Tools.strOfLocalization('26030003'), charInSusheHandler);
            //使用偏好，动态服饰，下拉菜单
            let dongtaiLine = this.createLineToggle(EPreferLine.USING_DONGTAI, game.Tools.strOfLocalization('26030318'));
            dongtaiLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = dongtaiLine.getInfo();
                    let isOpen = info == 0;
                    if (GameMgr.Inst.open_dongtai == isOpen) {
                        return;
                    }
                    GameMgr.Inst.open_dongtai = isOpen;
                    game.LocalStorage.setItem('open_dongtai', isOpen ? 'true' : 'false');
                    UI_Lobby.Inst.enable && UI_Lobby.Inst.resetSkin();
                }
            }, null, false));
            //使用偏好，电脑形象，下拉菜单
            let aiSkinLine = this.createLineDropDown(EPreferLine.USING_AI_SKIN, game.Tools.strOfLocalization('26030319'), [
                game.Tools.strOfLocalization('26030320'),
                game.Tools.strOfLocalization('26030321'),
            ]);
            aiSkinLine.onClickHelpBtn = Laya.Handler.create(this, () => {
                //显示帮助
                if (UI_Config_New.Inst.lock) {
                    return;
                }
                UI_Config_Popup_Info.Inst.show(aiSkinLine.helpInfoRenderPos, game.Tools.strOfLocalization(26030603));
            }, null, false);
            aiSkinLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = aiSkinLine.getInfo();
                    if (UI_Config_New.disableRandomChar == info) {
                        return;
                    }
                    if (game.Tools.getServerTime() < this.ai_look_change_cd) {
                        //恢复原设置
                        aiSkinLine.setInfo(UI_Config_New.disableRandomChar);
                        return;
                    }
                    this.ai_look_change_cd = game.Tools.getServerTime() + 1000;
                    const param: game.IReqSetFriendRoomRandomBotChar = { disable_random_char: info };
                    app.NetAgent.sendReq2Lobby(ServerType.LOBBY, game.ERequest.setFriendRoomRandomBotChar, param, (err, res: game.IResCommon) => {
                        this.ai_look_change_cd = 0;
                        if (err || res.error) {
                            UIMgr.Inst.showNetReqError(game.ERequest.setFriendRoomRandomBotChar, err, res);
                            //恢复原设置
                            aiSkinLine.setInfo(UI_Config_New.disableRandomChar);
                        } else {
                            UI_Config_New.disableRandomChar = info;
                        }
                    });
                }
            }, null, false));
            //使用偏好，大厅特效，下拉菜单
            let lobbyEffectLine = this.createLineDropDown(EPreferLine.USING_LOBBY_EFFECT, game.Tools.strOfLocalization('26030322'), [
                game.Tools.strOfLocalization('26030323'),
                game.Tools.strOfLocalization('26030324'),
            ]);
            lobbyEffectLine.addValueListener(Laya.Handler.create(this, (operateType: EConfigOpreateType) => {
                if (operateType == EConfigOpreateType.USER) {
                    let info = lobbyEffectLine.getInfo();
                    if (UI_Config_New.disableClickEffect == info) {
                        return;
                    }
                    UI_Config_New.disableClickEffect = info;
                    game.Scene_Lobby.Inst.set_lobby_click_effect(info == 0 ? game.Scene_Lobby.Inst.lobbyId : 0);
                }
            }, null, false));

        }

        public show() {
            this.refresh();
            this.visible = true;

        }

        public hide() {
            this.visible = false;
        }

        public refresh(): void {
            this.loadData();
            this.refreshLinePos();
        }

        public onEnable(): void {

        }

        public onDisable(): void {

        }

        private loadData() {
            let playCardWayLine = this.getLine<UI_Config_Line_DropDown>(EPreferLine.MATCH_PLAY_CARD_WAY);
            playCardWayLine.setInfo(view.DesktopMgr.click_prefer);
            let doubleClickPassLine = this.getLine<UI_Config_Line_Toggle>(EPreferLine.MATCH_DOUBLE_CLICK_PASS);
            doubleClickPassLine.setInfo(view.DesktopMgr.double_click_pass == 1 ? 0 : 1);
            if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
                let cardNumberShowLine = this.getLine<UI_Config_Line_DropDown>(EPreferLine.MATCH_CARD_NUMBER_SHOW);
                let isOpen = view.DesktopMgr.en_mjp;
                cardNumberShowLine.setInfo(isOpen ? 0 : 1);
                //如果是从对局进入的，角标不可设置
                cardNumberShowLine.selectEnable = UI_Lobby.Inst.enable;
            }
            if (GameMgr.client_type != 'chs_t') {
                let messageLine = this.getLine<UI_Config_Line_DropDown>(EPreferLine.USING_MESSAGE);
                messageLine.setInfo(GameMgr.Inst.comment_allow);
            }
            let dongtaiLine = this.getLine<UI_Config_Line_Toggle>(EPreferLine.USING_DONGTAI);
            dongtaiLine.setInfo(GameMgr.Inst.open_dongtai ? 0 : 1);
            let aiSkinLine = this.getLine<UI_Config_Line_DropDown>(EPreferLine.USING_AI_SKIN);
            aiSkinLine.setInfo(UI_Config_New.disableRandomChar);
            let lobbyEffectLine = this.getLine<UI_Config_Line_DropDown>(EPreferLine.USING_LOBBY_EFFECT);
            lobbyEffectLine.setInfo(UI_Config_New.disableClickEffect);

        }
    }

}