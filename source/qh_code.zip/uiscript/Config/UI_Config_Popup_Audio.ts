module uiscript {
    export enum EConfigAudioType {
        LOBBY = 0,
        MATCH = 1,
    }

    class RunningAnim extends UI_Component { 

        public static create(): RunningAnim {
            let spr = new ui.both_ui.config.config_popup_lobby_audio_runningUI();
            return new RunningAnim(spr);
        }

        private animController: UI_FrameAnimationMgr<ui.both_ui.config.config_popup_lobby_audio_runningUI>;
        public onCreate(): void {
            this.animController = new UI_FrameAnimationMgr(this.me);
        }

        public onEnable(): void {
            this.animController.stopAllAnimations();
            this.animController.playAnim('ani1', true);
        }

        public onDisable(): void {
            this.animController.stopAllAnimations();
        }
    }

    class AudioItem extends UI_Component {
        private selectToggle: UI_Toggle;
        private audioName: Laya.Label;
        private playToggle: UI_Toggle;
        private running: RunningAnim;
        private have: Laya.Sprite;
        private noHave: Laya.Sprite;
        private lockInfoLabel: Laya.Label;

        private onClickSelectHandler: Laya.Handler;
        private onClickPlayHandler: Laya.Handler;



        public onCreate(): void {
            this.audioName = this.me.getChildByName('title') as Laya.Label;
            this.noHave = this.me.getChildByName('no_have') as Laya.Sprite;
            this.have = this.me.getChildByName('have') as Laya.Sprite;
            this.selectToggle = new UI_Toggle(this.have.getChildByName('select_toggle') as Laya.Sprite);
            this.selectToggle.addClickListener(Laya.Handler.create(this, () => {
                this.onClickSelectHandler?.run();
            }, null, false));
            this.playToggle = new UI_Toggle(this.have.getChildByName('play_toggle') as Laya.Sprite);
            this.playToggle.addClickListener(Laya.Handler.create(this, () => {
                this.onClickPlayHandler?.run();
                this.running.visible = this.playToggle.on;
            }, null, false));
            let runningParent = this.have.getChildByName('running') as Laya.Sprite;
            this.running = RunningAnim.create();
            runningParent.addChild(this.running.me);
            this.lockInfoLabel = this.noHave.getChildByName('title') as Laya.Label;

        }

        public set select(on: boolean) {
            this.selectToggle.on = on;
            this.audioName.color = on ? '#8dff25' : '#8d99bb';
        }

        public get select(): boolean { 
            return this.selectToggle.on;
        }

        public set play(on: boolean) {
            this.playToggle.on = on;
            this.running.visible = on;
        }

        public get play(): boolean { 
            return this.playToggle.on;
        }
        


        public set isHave(have: boolean) {
            this.noHave.visible = !have;
            this.have.visible = have;
            this.audioName.color = have ? '#8dff25' : '#8d99bb';
        }

        public set name(name: string) {
            this.audioName.text = name;
        }

        public set onClickSelect(handler: Laya.Handler) {
            this.onClickSelectHandler = handler;
        }

        public set onClickPlay(handler: Laya.Handler) {
            this.onClickPlayHandler = handler;
        }

        public set lockInfo(info: string) { 
            this.lockInfoLabel.text = info;
        }


    }


    export class UI_Config_Popup_Audio extends UIBase {
        public static Inst: UI_Config_Popup_Audio = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_lobby_audioUI());
            UI_Config_Popup_Audio.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private title: Laya.Label;
        private randomToggle: UI_Toggle;
        private audioList: capsui.CScrollView;
        private audioType: EConfigAudioType;
        private allAudioList: Array<number> = [];
        private locking: boolean = false;



        public onCreate(): void {
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.title = this.root.getChildByName('title') as Laya.Label;
            let randomToggleSpr = this.root.getChildByName('random_toggle') as Laya.Sprite;
            this.randomToggle = new UI_Toggle(randomToggleSpr);
            this.randomToggle.addClickListener(Laya.Handler.create(this, this.onClickRandomToggle, null, false));
            this.audioList = (this.root.getChildByName('list') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.audioList.init_scrollview(Laya.Handler.create(this, this.itemRender, null, false), -1, 2, 20);

        }

        public show(audioType: EConfigAudioType) {
            this.audioType = audioType;
            let titleCode = audioType == EConfigAudioType.LOBBY ? 26030116 : 26030117;
            this.title.text = game.Tools.strOfLocalization(titleCode)
            this.loadData();
            this.audioList.rate = 0;
            this.locking = true;
            this.enable = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public hide() {
            this.locking = true;
            view.BgmListMgr.ResetBgm();
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public onEnable(): void {
            Laya.stage.on(EventCode.ON_BGM_CHANGE, this, this.freshList);
        }

        public onDisable(): void {
            Laya.stage.off(EventCode.ON_BGM_CHANGE, this, this.freshList);
            
        }

        private onClickRandomToggle(): void {
            let isRandom = this.randomToggle.on;
            this.randomToggle.titleColor = isRandom ? '#8dff25' : '#8d99bb';
            if (this.audioType == EConfigAudioType.LOBBY) {
                view.BgmListMgr.bgm_lobby_mode = isRandom ? 'rand' : 'list';
                Laya.LocalStorage.setItem(game.Tools.eeesss('bgm_lobby_mode' + GameMgr.Inst.account_id), view.BgmListMgr.bgm_lobby_mode);
            }
            else if (this.audioType == EConfigAudioType.MATCH) {
                view.BgmListMgr.bgm_mj_mode = isRandom ? 'rand' : 'list';
                Laya.LocalStorage.setItem(game.Tools.eeesss('bgm_mj_mode' + GameMgr.Inst.account_id), view.BgmListMgr.bgm_mj_mode);
            }
        }

        private loadData() {

            if (this.audioType == EConfigAudioType.LOBBY) {
                this.randomToggle.on = view.BgmListMgr.bgm_lobby_mode != 'list';
            } else if (this.audioType == EConfigAudioType.MATCH) {
                this.randomToggle.on = view.BgmListMgr.bgm_mj_mode != 'list';
            }
            this.allAudioList = [];
            cfg.audio.bgm.forEach(configData => { 
                if ((this.audioType == EConfigAudioType.LOBBY && configData.type == 'lobby') ||
                    (this.audioType == EConfigAudioType.MATCH && configData.type == 'mj')) {
                    if (configData.auto_hide && !UI_Bag.get_item_count(configData.id)) return;
                    this.allAudioList.push(configData.id);
                }
            });
            this.audioList.reset();
            this.audioList.addItem(this.allAudioList.length);
            this.onClickRandomToggle();
        }

        private freshList() {
            this.audioList.wantToRefreshAll();
        }

        private itemRender(data: any) {
            const index: number = data.index;
            const container: Laya.Sprite = data.container;
            const cache_data: any = data.cache_data;

            const item: AudioItem = cache_data.item = cache_data.item || new AudioItem(container);
            const audioId: number = this.allAudioList[index];
            const audioConfig = cfg.audio.bgm.get(audioId);
            const itemConfig = cfg.item_definition.item.get(audioConfig.id);
            if (itemConfig) {
                item.name = itemConfig['name_' + GameMgr.client_language];
            } else {
                item.name = audioConfig['name_' + GameMgr.client_language];
            }
            let noHave = audioConfig.unlock_item && UI_Bag.get_item_count(audioConfig.unlock_item) == 0;
            item.isHave = !noHave;
            item.lockInfo = audioConfig['unlock_desc_' + GameMgr.client_language];
            let isOn: boolean = view.BgmListMgr.playing_bgm != '' && view.BgmListMgr.playing_bgm == audioConfig.path;
            let isInList: boolean = false;
            if (this.audioType == EConfigAudioType.LOBBY) {
                isInList = view.BgmListMgr.findIndexInLobby(audioConfig.path) >= 0;
                item.onClickSelect = Laya.Handler.create(this, () => {
                   
                    if (isInList) {
                        let lst = view.BgmListMgr.baned_bgm_lobby_list;
                        lst.push(audioConfig.path);
                        view.BgmListMgr.baned_bgm_lobby_list = lst;
                        if (view.BgmListMgr.playing_bgm == audioConfig.path) {
                            view.BgmListMgr.onHandStop();
                        }
                    } else {
                        let list: Array<string> = [];
                        for (let i: number = 0; i < view.BgmListMgr.baned_bgm_lobby_list.length; i++) {
                            if (view.BgmListMgr.baned_bgm_lobby_list[i] == audioConfig.path) continue;
                            list.push(view.BgmListMgr.baned_bgm_lobby_list[i]);
                        }
                        view.BgmListMgr.baned_bgm_lobby_list = list;
                    }
                    view.BgmListMgr.saveConfig();
                    this.freshList();
                }, null, false);
            }
            if (this.audioType == EConfigAudioType.MATCH) {
                isInList = view.BgmListMgr.findIndexInMJ(audioConfig.path) >= 0;
                item.onClickSelect = Laya.Handler.create(this, () => {
                    if (isInList) {
                        let lst = view.BgmListMgr.baned_bgm_mj_list;
                        lst.push(audioConfig.path);
                        view.BgmListMgr.baned_bgm_mj_list = lst;
                        if (view.BgmListMgr.playing_bgm == audioConfig.path) {
                            view.BgmListMgr.onHandStop();
                        }
                    } else {
                        let list: Array<string> = [];
                        for (let i: number = 0; i < view.BgmListMgr.baned_bgm_mj_list.length; i++) {
                            if (view.BgmListMgr.baned_bgm_mj_list[i] == audioConfig.path) continue;
                            list.push(view.BgmListMgr.baned_bgm_mj_list[i]);
                        }
                        view.BgmListMgr.baned_bgm_mj_list = list;
                    }
                    view.BgmListMgr.saveConfig();
                    this.freshList();
                }, null, false);
            } 
            item.play = isOn;
            item.onClickPlay = Laya.Handler.create(this, () => {
                if (view.BgmListMgr.playing_bgm == audioConfig.path) {
                    view.BgmListMgr.onHandStop();
                } else {
                    view.BgmListMgr.tryPlayBgm(audioConfig.path);
                }
            }, null, false);
            item.select = isInList;
           

        }

       
    }

}