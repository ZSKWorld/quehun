module uiscript {

    class TxtInput {
        public me: Laya.Sprite;
        private txtinput: Laya.TextInput;
        public wrong: Laya.Sprite;
        public accept: Laya.Sprite;
        private func_pending: Laya.Handler;
        private onTextInputHandler: Laya.Handler;

        public get text() { return this.txtinput.text; }

        public get isOK() { return !this.func_pending || this.func_pending.run(); }

        public constructor(me: Laya.Sprite, func_pending: Laya.Handler) {
            this.me = me;
            this.func_pending = func_pending;
            this.txtinput = me.getChildByName('txtinput') as Laya.TextInput;
            this.wrong = me.getChildByName('wrong') as Laya.Sprite;
            this.accept = me.getChildByName('accept') as Laya.Sprite;

            this.txtinput.on('focus', this, () => {
                this.wrong.visible = false;
                this.accept.visible = false;
            });
            this.txtinput.on('blur', this, () => {
                this.wrong.visible = false;
                this.accept.visible = false;
                if (this.txtinput.text != '') {
                    if (!this.func_pending || this.func_pending.run()) {
                        this.accept.visible = true;
                    } else {
                        this.wrong.visible = true;
                    }
                }
            });
            this.txtinput.on('input', this, this.onTextInput);
            this.reset();
           
        }

        public reset() {
            this.txtinput.text = '';
            this.wrong.visible = false;
            this.accept.visible = false;
        }

        public set onInput(func: Laya.Handler) {
            this.onTextInputHandler = func;
        }

        private onTextInput() {
            this.onTextInputHandler && this.onTextInputHandler.run();
        }

        public set text(value: string) {
            this.txtinput.text = value;
        }
    }

    export class UI_Config_Popup_Bind_Mail extends UIBase {
        public static Inst: UI_Config_Popup_Bind_Mail;

        private root: Laya.Sprite;
        private bind: Laya.Sprite;
        private unbind: Laya.Sprite;
        private input_mail: TxtInput;
        /**
         * 换绑邮箱时显示的邮箱信息
         */
        private mail_info: Laya.Label;
        private label_mail: Laya.Label;
        private mail_title: Laya.Label;
        private input_code: Laya.TextInput;
        private btn_send_code: Laya.Button;
        private bg_send_code: Laya.Image;
        private label_send_code: Laya.Label;
        private btn_confirm: UI_UniversalBtn;

        private locking: boolean;
        private during_send_cd: boolean;
        private last_send_time: number;
        private complete: Laya.Handler;
        private is_force: boolean;


        constructor() {
            super(new ui.both_ui.config.config_popup_bind_mailUI());
            UI_Config_Popup_Bind_Mail.Inst = this;
        }

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;

            this.bind = this.root.getChildByName('bind') as Laya.Sprite;
            this.unbind = this.root.getChildByName('unbind') as Laya.Sprite;
            this.input_mail = new TxtInput(this.unbind.getChildByName('input_mail') as Laya.Sprite, new Laya.Handler(this, () => {
                return game.Tools.pending_email_vaild(this.input_mail.text);
            }));
            this.input_mail.onInput = Laya.Handler.create(this, this.freshConfirmBtn, null, false);
            this.mail_info = this.unbind.getChildByName('label_email') as Laya.Label;
            this.label_mail = this.bind.getChildByName('info') as Laya.Label;
            this.mail_title = this.bind.getChildByName('label_email') as Laya.Label;
            this.input_code = this.unbind.getChildByName('input_code').getChildByName('txtinput') as Laya.TextInput;
            this.input_code.on('input', this, () => {
                this.freshConfirmBtn();
            });
            this.btn_send_code = this.unbind.getChildByName('btn_send_code') as Laya.Button;
            this.bg_send_code = this.btn_send_code.getChildByName('icon') as Laya.Image;
            this.label_send_code = this.btn_send_code.getChildByName('info') as Laya.Label;
            this.btn_confirm = new UI_UniversalBtn(this.root.getChildByName('confirm_btn') as Laya.Sprite);
            this.btn_confirm.type = EUniversalBtnType.CONFIRM_YELLOW;

            this.btn_confirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.isBinded) {
                    this.close();
                    return;
                }
                let email: string = '';
                if (!GameMgr.Inst.account_data['email']) {
                    if (!this.input_mail.isOK) {
                        UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2786));
                        return;
                    }
                    email = this.input_mail.text;
                }
                app.NetAgent.sendReq2Lobby('Lobby', 'bindEmail', {
                    email: email,
                    code: this.input_code.text,
                    password: GameMgr.encodeP(game.LoginMgr.password)
                }, (err, res) => {

                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('bindEmail', err, res);
                        this.last_send_time = 0;
                    } else {
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2785));
                        GameMgr.Inst.account_data['email'] = game.Tools.encode_email(email);
                        GameMgr.Inst.account_data['email_verify'] = 1;
                        this.close();
                    }
                });
            });

            this.btn_send_code.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                let _email: string = '';
                if (!GameMgr.Inst.account_data['email']) {
                    if (!this.input_mail.isOK) {
                        UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2786));
                        return;
                    }
                    _email = this.input_mail.text;
                }
                this.setSendCodeEnabled(false);
                this.during_send_cd = true;
                this.last_send_time = Laya.timer.currTimer;
                this.refresh_send();
                app.NetAgent.sendReq2Lobby('Lobby', 'createEmailVerifyCode', {
                    email: _email,
                    usage: 1
                }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('createEmailVerifyCode', err, res);
                        this.last_send_time = 0;
                    } else {
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2810));
                    }
                });
            });

            (this.root.getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.is_force) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3852), Laya.Handler.create(this, () => {
                        if (Laya.Browser.window['conch']) {
                            // var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
                            // _c.call('restart');
                            if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                                Laya.Browser.window['conch'].exit();
                            }
                        } else {
                            Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                        }
                    }));
                } else {
                    this.close();
                }

            });

            (this.me.getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.is_force) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3852), Laya.Handler.create(this, () => {
                        if (Laya.Browser.window['conch']) {
                            // var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
                            // _c.call('restart');
                            if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                                Laya.Browser.window['conch'].exit();
                            }
                        } else {
                            Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                        }
                    }));
                } else {
                    this.close();
                }

            });

            this.during_send_cd = false;
            this.last_send_time = 0;
        }

        public show(force: boolean = false, complete: Laya.Handler = null) {
            this.enable = true;
            this.locking = true;
            this.input_code.text = '';
            Laya.timer.clearAll(this);
            this.is_force = force;
            this.complete = complete;
            if (this.isBinded) {
                this.bind.visible = true;
                this.unbind.visible = false;
                this.label_mail.text = GameMgr.Inst.account_data['email'];
                
                //如果mail+title的宽度超过，则调整title和mail的scale至bind的宽度
                let total_width = this.mail_title.width * this.mail_title.scaleX + this.label_mail.width * this.label_mail.scaleX;
                if (total_width > this.bind.width) {
                    let scale = this.bind.width / total_width;
                    this.mail_title.scaleX = this.mail_title.scaleY = scale;
                    this.label_mail.scaleX = this.label_mail.scaleY = scale;
                }
                game.Tools.child_align_center(this.bind);
                this.btn_confirm.setTitle(game.Tools.strOfLocalization(2129));
                
            } else {
                this.bind.visible = false;
                this.unbind.visible = true;
                if (GameMgr.Inst.account_data['email']) {
                    this.input_mail.me.visible = false;
                    this.mail_info.visible = true;
                    this.mail_info.text = GameMgr.Inst.account_data['email'];
                    this.input_mail.text = GameMgr.Inst.account_data['email'];
                } else {
                    this.input_mail.me.visible = true;
                    this.input_mail.reset();
                    this.mail_info.visible = false;
                }
                this.btn_confirm.setTitle(game.Tools.strOfLocalization(26030514));
            }
            this.freshConfirmBtn();

            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            if (!this.during_send_cd) {
                this.during_send_cd = false;
                this.setSendCodeEnabled(true);
                this.label_send_code.text = game.Tools.strOfLocalization(2787);
            } else {
                this.refresh_send();
            }
            Laya.timer.frameLoop(1, this, () => {
                this.refresh_send();
            });
        }

        public close() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
                Laya.timer.clearAll(this);
                if (this.complete) this.complete.run();
            }));
        }

        private refresh_send() {
            if (!this.during_send_cd) return;
            let t: number = Laya.timer.currTimer - this.last_send_time;
            if (t >= 60 * 1000) {
                this.during_send_cd = false;
                this.setSendCodeEnabled(true);
                this.label_send_code.text = game.Tools.strOfLocalization(2787);
            } else {
                this.label_send_code.text = game.Tools.strOfLocalization(2682, [Math.ceil(60 - t / 1000).toString()]);
            }
        }

        private get isBinded(): boolean {
            return GameMgr.Inst.account_data['email_verify'];
        }


        private freshConfirmBtn() {
            if (this.isBinded) {
                this.btn_confirm.setGrayed(false);
                this.btn_confirm.setEnabled(true);
            } else {
                //验证码或者邮箱没输入就显示灰色
                let isInputAll = this.input_code.text != '' && (this.input_mail.isOK|| GameMgr.Inst.account_data['email']);
                this.btn_confirm.setGrayed(!isInputAll);
                this.btn_confirm.setEnabled(isInputAll);
            }
        }

        private setSendCodeEnabled(enabled: boolean) {
            this.btn_send_code.mouseEnabled = enabled;
            this.label_send_code.color = enabled ? '#edb26f' : '#525a6b';
            this.bg_send_code.skin = game.Tools.localUISrc(enabled ? 'myres/bothui/config/setting_send_btn.png' : 'myres/bothui/config/setting_send_btn_dis.png')
        }

    }
}