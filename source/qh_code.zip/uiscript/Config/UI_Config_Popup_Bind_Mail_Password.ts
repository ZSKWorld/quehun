module uiscript {

    class TxtInput {
        public me: Laya.Sprite;
        private txtinput: Laya.TextInput;
        public wrong: Laya.Sprite;
        public accept: Laya.Sprite;
        private func_pending: Laya.Handler;
        private onTextInputHandler: Laya.Handler;

        public get text() { return this.txtinput.text; }

        public get isOK() { return !this.func_pending || this.func_pending.run(); }

        public constructor(me: Laya.Sprite, func_pending: Laya.Handler) {
            this.me = me;
            this.func_pending = func_pending;
            this.txtinput = me.getChildByName('txtinput') as Laya.TextInput;
            this.wrong = me.getChildByName('wrong') as Laya.Sprite;
            this.accept = me.getChildByName('accept') as Laya.Sprite;

            this.txtinput.on('focus', this, () => {
                this.wrong.visible = false;
                this.accept.visible = false;
            });
            this.txtinput.on('blur', this, () => {
                this.wrong.visible = false;
                this.accept.visible = false;
                if (this.txtinput.text != '') {
                    if (!this.func_pending || this.func_pending.run()) {
                        this.accept.visible = true;
                    } else {
                        this.wrong.visible = true;
                    }
                }
            });
            this.txtinput.on('input', this, this.onTextInput);
            this.reset();
            
        }

        public reset() {
            this.txtinput.text = '';
            this.wrong.visible = false;
            this.accept.visible = false;
        }

        public set onInput(func: Laya.Handler) {
            this.onTextInputHandler = func;
        }
        private onTextInput() {
            this.onTextInputHandler && this.onTextInputHandler.run();
        }
    }

    export class UI_Config_Popup_Bind_Mail_Password extends UIBase {

        public static Inst: UI_Config_Popup_Bind_Mail_Password;
        constructor() {
            super(new ui.both_ui.config.config_popup_bind_mail_passwordUI());
            UI_Config_Popup_Bind_Mail_Password.Inst = this;
        }

        private root: Laya.Sprite;
        private input_mail: TxtInput;
        private label_mail: Laya.Label;
        private input_code: Laya.TextInput;
        private input_password0: TxtInput;
        private input_password1: TxtInput;
        private btn_send_code: Laya.Button;
        private label_send_code: Laya.Label;
        private btn_confirm: UI_UniversalBtn;

        private locking: boolean;
        private during_send_cd: boolean;
        private last_send_time: number;
        private complete: Laya.Handler;

        private is_force: boolean;
        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.input_mail = new TxtInput(this.root.getChildByName('input_mail') as Laya.Sprite, new Laya.Handler(this, () => {
                return game.Tools.pending_email_vaild(this.input_mail.text);
            }));
            this.input_mail.onInput = Laya.Handler.create(this, this.freshConfirmBtn, null, false);
            this.label_mail = this.root.getChildByName('label_email').getChildByName('info') as Laya.Label;
            this.input_code = this.root.getChildByName('input_code').getChildByName('txtinput') as Laya.TextInput;
            this.input_code.on('input', this, () => {
                this.freshConfirmBtn();
            });
            this.input_password0 = new TxtInput(this.root.getChildByName('input_password0') as Laya.TextInput, new Laya.Handler(this, () => {
                return this.input_password0.text.length >= 6 && this.input_password0.text.length <= 20;
            }));
            this.input_password0.onInput = Laya.Handler.create(this, this.freshConfirmBtn, null, false);
            this.input_password1 = new TxtInput(this.root.getChildByName('input_password1') as Laya.TextInput, new Laya.Handler(this, () => {
                return this.input_password0.text == this.input_password1.text && this.input_password1.text.length >= 6 && this.input_password1.text.length <= 20;
            }));
            this.input_password1.onInput = Laya.Handler.create(this, this.freshConfirmBtn, null, false);
            this.btn_send_code = this.root.getChildByName('btn_send_code') as Laya.Button;
            this.label_send_code = this.btn_send_code.getChildByName('info') as Laya.Label;
            this.btn_confirm = new UI_UniversalBtn(this.root.getChildByName('btn_confirm') as Laya.Sprite);
            this.btn_confirm.type = EUniversalBtnType.CONFIRM_YELLOW;

            this.btn_confirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.input_password0.text != this.input_password1.text) {
                    return;
                }
                let email: string = '';
                if (!GameMgr.Inst.account_data['email']) {
                    if (!this.input_mail.isOK) {
                        UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2786));
                        return;
                    }
                    email = this.input_mail.text;
                }
                app.NetAgent.sendReq2Lobby('Lobby', 'bindEmail', {
                    email: email,
                    code: this.input_code.text,
                    password: GameMgr.encodeP(this.input_password0.text)
                }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('bindEmail', err, res);
                        this.last_send_time = 0;
                    } else {
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2785));
                        GameMgr.Inst.account_data['email'] = game.Tools.encode_email(email);
                        GameMgr.Inst.account_data['email_verify'] = 1;
                        this.close();
                    }
                });
            });
            this.btn_send_code.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                let _email: string = '';
                if (!GameMgr.Inst.account_data['email']) {
                    if (!this.input_mail.isOK) {
                        UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(2786));
                        return;
                    }
                    _email = this.input_mail.text;
                }
                this.setSendCodeEnabled(false);
                this.during_send_cd = true;
                this.last_send_time = Laya.timer.currTimer;
                this.refresh_send();
                app.NetAgent.sendReq2Lobby('Lobby', 'createEmailVerifyCode', {
                    email: _email,
                    usage: 1
                }, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('createEmailVerifyCode', err, res);
                        this.last_send_time = 0;
                    } else {
                        UI_LightTips.Inst.show(game.Tools.strOfLocalization(2810));
                    }
                });
            });

            (this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.is_force) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3852), Laya.Handler.create(this, () => {
                        if (Laya.Browser.window['conch']) {
                            // var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
                            // _c.call('restart');
                            if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                                Laya.Browser.window['conch'].exit();
                            }
                        } else {
                            Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                        }
                    }));
                } else {
                    this.close();
                }
            });
            (this.me.getChildByName('close_btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this.is_force) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3852), Laya.Handler.create(this, () => {
                        if (Laya.Browser.window['conch']) {
                            // var _c = Laya.PlatformClass.createClass("layaair.majsoul.mjmgr");
                            // _c.call('restart');
                            if (Laya.Browser.window['conch'] && Laya.Browser.window['conch'].exit) {
                                Laya.Browser.window['conch'].exit();
                            }
                        } else {
                            Laya.Browser.window.location.href = GameMgr.Inst.link_url;
                        }
                    }));
                } else {
                    this.close();
                }
            });

            this.during_send_cd = false;
            this.last_send_time = 0;
        }

        public show(force: boolean = false, complete: Laya.Handler = null) {
            // (this.root.getChildByName('btn_close') as Laya.Button).visible = !force;
            this.is_force = force;
            this.complete = complete;
            //如果已经绑定过了，跳出绑定信息即可
            if (this.isBinded) {
                UI_Config_Popup_Bind_Mail.Inst.show(force, complete);  
                return;
            }
            this.freshConfirmBtn();
            this.enable = true;
            this.locking = true;
            this.input_code.text = '';
            this.input_password0.reset();
            this.input_password1.reset();
            if (GameMgr.Inst.account_data['email']) {
                this.input_mail.me.visible = false;
                this.label_mail.text = GameMgr.Inst.account_data['email'];
                (this.label_mail.parent as Laya.Sprite).visible = true;
            } else {
                this.input_mail.me.visible = true;
                this.input_mail.reset();
                (this.label_mail.parent as Laya.Sprite).visible = false;
            }
            Laya.timer.clearAll(this);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            if (!this.during_send_cd) {
                this.during_send_cd = false;
                this.setSendCodeEnabled(true);
                this.label_send_code.text = game.Tools.strOfLocalization(2787);
            } else {
                this.refresh_send();
            }
            (this.root.getChildByName('chsinfo') as Laya.Sprite).visible = GameMgr.client_type == 'chs_t';

            Laya.timer.frameLoop(1, this, () => {
                this.refresh_send();
            });
        }

        public close() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
                Laya.timer.clearAll(this);
                if (this.complete) this.complete.run();
            }));
        }

        private refresh_send() {
            if (!this.during_send_cd) return;
            let t: number = Laya.timer.currTimer - this.last_send_time;
            if (t >= 60 * 1000) {
                this.during_send_cd = false;
                this.setSendCodeEnabled(true)
                this.label_send_code.text = game.Tools.strOfLocalization(2787);
            } else {
                this.setSendCodeEnabled(false);
                this.label_send_code.text = game.Tools.strOfLocalization(2682, [Math.ceil(60 - t / 1000).toString()]);
            }
        }

        private setSendCodeEnabled(enabled: boolean) {
            this.btn_send_code.mouseEnabled = enabled;
            this.label_send_code.color = enabled ? '#edb26f' : '#525a6b';
            this.btn_send_code.skin = game.Tools.localUISrc(enabled ? 'myres/bothui/config/setting_send_btn.png' : 'myres/bothui/config/setting_send_btn_dis.png')
        }

        private freshConfirmBtn() {
            let isMailOk = this.input_mail.isOK || GameMgr.Inst.account_data['email'];
            //验证码或者邮箱没输入就显示灰色
            let isInputAll = this.input_code.text != '' && isMailOk && this.input_password0.isOK && this.input_password1.isOK;
            this.btn_confirm.setGrayed(!isInputAll);
            this.btn_confirm.setEnabled(isInputAll);
        }

        private get isBinded(): boolean {
            return GameMgr.Inst.account_data['email_verify'];
        }
    }

}