module uiscript {


    class CharAudioItem extends UI_Component { 
        private head: UI_Character_Skin;
        private slider: UI_Slider;
        private valueLabel: Laya.Label;
        private minValue: number = 0;
        private maxValue: number = 100;
        private muteToggle: UI_Toggle;
        private onValueChangeHandler: Laya.Handler;
        private charId: number;
        public onCreate(): void {
            this.slider = new UI_Slider(this.me.getChildByName("slider") as Laya.Sprite, this.minValue, this.maxValue);
            this.slider.onValueChangeHandler = Laya.Handler.create(this, this.onSliderValueChange, null, false);
            this.slider.onChangeStartHandler = Laya.Handler.create(this, () => {
                //开始拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_START_CHANGE);
            }, null, false);
            this.slider.onChangeEndHandler = Laya.Handler.create(this, () => {
                //结束拖动
                Laya.stage.event(EventCode.CONFIG_SLIDER_END_CHANGE);
            }, null, false);
            this.valueLabel = this.slider.me.getChildByName("value") as Laya.Label;
            this.muteToggle = new UI_Toggle(this.me.getChildByName("mute_toggle") as Laya.Sprite);
            this.muteToggle.addClickListener(Laya.Handler.create(this, this.onClickMuteToggle, null, false));
            this.head = new UI_Character_Skin(this.me.getChildByName("head").getChildByName('icon') as Laya.Sprite);
        }

        private onSliderValueChange(operateType: EConfigOpreateType): void {
            //如果是静音状态，先取消静音
            if (this.muteToggle.on && operateType == EConfigOpreateType.USER) {
                this.muteToggle.on = false;
                this.setMute(false);
            }
            let value = this.getInfo();
            this.valueLabel.text = value.value.toString();
            this.onValueChangeHandler?.runWith([operateType, this.getInfo()]);
        }

        public getInfo(): IConfigSliderInfo {
            return { value: this.slider.value, isMute: this.muteToggle.on };
        }

        private onClickMuteToggle() {
            this.setMute(this.muteToggle.on);
            this.onValueChangeHandler?.runWith([EConfigOpreateType.USER, this.getInfo()]);
        }

        public setInfo(value: IConfigSliderInfo) {
            this.setSliderValue(value.value);
            this.muteToggle.on = value.isMute;
            this.setMute(value.isMute);
        }

        /**
        * 
        * @param value true静音，false非静音
        */
        private setMute(value: boolean) {
            //静音的情况下，且显示为灰色,如果滑动滑动条，则改为非静音状态
            // this.slider.touchable = !value;
            // let thumbImage = !value ? "myres/bothui/config/setting_sound_progress_btn.png" : "myres/bothui/config/setting_sound_progress_btn_dis.png";
            let fillImage = !value ? "myres/bothui/config/setting_sound_progress_strip.png" : "myres/bothui/config/setting_sound_progress_strip_dis.png";
            // this.slider.thumbImage = game.Tools.localUISrc(thumbImage);
            this.slider.fillImage = game.Tools.localUISrc(fillImage);
        }

        public setSliderValue(data: number) {
            if (data < this.minValue) {
                data = this.minValue;
            }
            if (data > this.maxValue) {
                data = this.maxValue;
            }
            let rate = (data - this.minValue) / (this.maxValue - this.minValue);
            //赋值slider的时候调用了onValueChange，所以不需要再手动调用一次
            this.slider.setRate(rate);
            this.valueLabel.text = data.toString();
        }

        public set characterId(charId: number) {
            this.charId = charId;
        }

        public get characterId(): number {
            return this.charId;
        }

        public loadHeadIcon() {
            let d_chara = cfg.item_definition.character.get(this.charId);
            this.head.setSkin(d_chara.init_skin, 'smallhead');
        }

        public clearHeadIcon() { 
            this.head.clear();
        }

        public set onValueChange(value: Laya.Handler) { 
            this.onValueChangeHandler = value;
        }
        
    }

    export class UI_Config_Popup_Character_Audio extends UIBase {
        public static Inst: UI_Config_Popup_Character_Audio = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_character_audioUI());
            UI_Config_Popup_Character_Audio.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private filterBtn: Laya.Button;
        private scrollPanel: ScrollPanel;
        private charTemplate: Laya.Sprite;
        private matchTitle: Laya.Sprite;
        private otherTitle: Laya.Sprite;
        private empty: Laya.Sprite;
        private startX: number = 17;
        private titleItemSpaceY: number = 7;
        private itemSpaceY: number = 10;
        private itemSpaceX: number = 20;
        private itemTitleSpaceY: number = 20;
        private allEmptyPosY: number = 224;
        private matchTitleEmptySpaceY: number = 50;
        private lineItemCount: number = 2;

        private renderFilter: ICharFilterData;
        private onFilterChangeHandler: Laya.Handler;
        private allCharIds: number[] = [];
        private matchCharIds: number[] = [];
        private isMatch: boolean = false;
        private renderItems: CharAudioItem[] = [];
        private locking: boolean = false;

        public onCreate(): void {
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.filterBtn = this.root.getChildByName('btn_filter') as Laya.Button;
            this.filterBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                UI_Char_Filter.Inst.show(this.renderFilter, this.onFilterChangeHandler);
            }, null, false);
            this.onFilterChangeHandler = new Laya.Handler(this, (filterData: ICharFilterData) => {
                this.renderFilter = filterData;
                this.refresh();
            }); 
            this.scrollPanel = new ScrollPanel(this.root.getChildByName('list') as Laya.Sprite);
            this.charTemplate = this.scrollPanel.content.getChildByName('template') as Laya.Sprite;
            this.charTemplate.visible = false;
            this.matchTitle = this.scrollPanel.content.getChildByName('title_match') as Laya.Sprite;
            this.matchTitle.visible = false;
            let matchTitleLabel = this.matchTitle.getChildByName('title') as Laya.Label;
            let matchTitleLine = this.matchTitle.getChildByName('line') as Laya.Image;
            //根据标题文本调整线的宽度
            let matchTitleDiff= 90 - matchTitleLabel.trueWidth;
            matchTitleLine.width += matchTitleDiff;
            
            this.otherTitle = this.scrollPanel.content.getChildByName('title_other') as Laya.Sprite;
            this.otherTitle.visible = false;
            let otherTitleLabel = this.otherTitle.getChildByName('title') as Laya.Label;
            let otherTitleLine = this.otherTitle.getChildByName('line') as Laya.Image;
            //根据标题文本调整线的宽度
            let otherTitleDiff= 60 - otherTitleLabel.trueWidth;
            otherTitleLine.width += otherTitleDiff;

            this.empty = this.scrollPanel.content.getChildByName('empty') as Laya.Sprite;
            this.empty.visible = false;
            this.initAllCharIds();
            for (let index = 0; index < this.allCharIds.length; index++) {
                let newSprite = this.charTemplate.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
                this.scrollPanel.content.addChild(newSprite);
                let item = new CharAudioItem(newSprite);
                this.renderItems.push(item);
                item.characterId = this.allCharIds[index];
                item.onValueChange = Laya.Handler.create(this, (operateType: EConfigOpreateType, info: IConfigSliderInfo) => { 
                    if (operateType == EConfigOpreateType.USER) {
                        let volume = info.value;
                        let isMute = info.isMute;
                        let currentVolume = view.AudioMgr.getCVvolume(item.characterId) * 100;
                        let currentMute = view.AudioMgr.getCVmute(item.characterId);
                        if (volume != currentVolume) {
                            view.AudioMgr.setCVvolume(item.characterId, volume / 100);
                        }
                        if (isMute != currentMute) {
                            view.AudioMgr.setCVmute(item.characterId, isMute);
                        }
                    }
                },null,false);
            }
        }

        public show(matchIds: number[] = []): void {
            this.matchCharIds = matchIds;
            this.isMatch = this.matchCharIds.length > 0;
            this.matchTitle.visible = this.isMatch;
            this.otherTitle.visible = this.isMatch;
            this.renderFilter = UI_Char_Filter.defalutFilterData;
            this.refresh();
            this.loadAllHeadIcons();
            this.loadData();
            this.scrollPanel.rate = 0;
            this.locking = true;
            this.enable = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public hide() { 
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public onEnable(): void {
            Laya.stage.on(EventCode.CONFIG_SLIDER_START_CHANGE, this, this.stopPanel);
            Laya.stage.on(EventCode.CONFIG_SLIDER_END_CHANGE, this, this.startPanel);
        }

        private stopPanel() {
            this.scrollPanel.stopScroll();
        }

        private startPanel() {
            this.scrollPanel.startScroll();
        }

        public onDisable(): void {
            for (let index = 0; index < this.renderItems.length; index++) {
                const element = this.renderItems[index];
                element.clearHeadIcon();
            }
            Laya.timer.clearAll(this);
            Laya.stage.off(EventCode.CONFIG_SLIDER_START_CHANGE, this, this.stopPanel);
            Laya.stage.off(EventCode.CONFIG_SLIDER_END_CHANGE, this, this.startPanel);
            
        }

        private refresh() {
            this.freshFilterBtn();
            let matchItems: CharAudioItem[] = [];
            let otherItems: CharAudioItem[] = [];
            for (let index = 0; index < this.renderItems.length; index++) {
                const item = this.renderItems[index];
                let itemConfig = cfg.item_definition.character.get(item.characterId);
                if (!itemConfig.open || (itemConfig.launch_time && game.Tools.getTimeByStr(itemConfig.launch_time) > game.Tools.getServerTime())) {
                    item.visible = false;
                    continue;
                }
                // 23/12/08 添加起售时间
                if (itemConfig.region_limit == 1 && GameMgr.regionLimited && !UI_Sushe.chara_owned(itemConfig.id)) {
                    item.visible = false;
                    continue;
                }
                let isInMatch = this.matchCharIds.indexOf(item.characterId) >= 0;
                if (isInMatch) {
                    matchItems.push(item);
                    item.visible = true;
                }
                else {
                    //检查是否被筛选
                    let isShow = UI_Char_Filter.isShowChar(item.characterId, this.renderFilter);
                    if (isShow) {
                        otherItems.push(item);
                    }
                    item.visible = isShow;
                }
            }
            //布局
            let curY = 0;
            let totalHeight = 0;
            
            if (matchItems.length > 0) {
                this.matchTitle.y = curY;
                curY += this.matchTitle.height + this.titleItemSpaceY;
                let curX = this.startX;
                for (let index = 0; index < matchItems.length; index++) { 
                    const item = matchItems[index];
                    item.me.x = curX;
                    item.me.y = curY;
                    curX += item.me.width + this.itemSpaceX;
                    if ((index + 1) % this.lineItemCount == 0) {
                        curX = this.startX;
                        curY += item.me.height + this.itemSpaceY;
                    }
                }
                //如果item不能整除lineItemCount，则多加一行高度
                if (matchItems.length % this.lineItemCount != 0) {
                    curY += matchItems[matchItems.length - 1].me.height + this.itemSpaceY;
                }
                curY += this.itemTitleSpaceY;
                this.otherTitle.y = curY;
                curY += this.otherTitle.height;
            } 
            
            this.empty.visible = otherItems.length == 0;
            if (otherItems.length == 0) {
                //调整空的位置
                this.empty.y = this.isMatch ? (curY  + this.matchTitleEmptySpaceY) : this.allEmptyPosY;
                totalHeight = this.empty.y + this.empty.height;
            } else {
                curY += this.isMatch ? this.titleItemSpaceY : 0;
                let curX = this.startX;
                for (let index = 0; index < otherItems.length; index++) { 
                    const item = otherItems[index];
                    item.me.x = curX;
                    item.me.y = curY;
                    curX += item.me.width + this.itemSpaceX;
                    if ((index + 1) % this.lineItemCount == 0) {
                        curX = this.startX;
                        curY += item.me.height + this.itemSpaceY;
                    }
                }
                //如果item不能整除lineItemCount，则多加一行高度
                if (otherItems.length % this.lineItemCount != 0) {
                    curY += otherItems[otherItems.length - 1].me.height + this.itemSpaceY;
                }
                totalHeight = curY;
            }
            this.scrollPanel.contentHeight = totalHeight;
        }

        private initAllCharIds() { 
            this.allCharIds = [];
            let characters = game.Tools.GetSheetSortBy('item_definition', 'character', 'sort') as Array<lqc.Sheet_ItemDefinition_Character>;
            characters.forEach(char => {
               
                this.allCharIds.push(char.id);
            });
        }

        private freshFilterBtn() {
            if (UI_Char_Filter.isFilterSame(this.renderFilter, UI_Char_Filter.defalutFilterData)) {
                this.filterBtn.skin = game.Tools.localUISrc(UI_Char_Filter.filterBtnDarkPath);
            } else {
                this.filterBtn.skin = game.Tools.localUISrc(UI_Char_Filter.filterBtnLightPath);
            }
        }

        private loadAllHeadIcons() { 
            //分帧加载头像,一帧加载10个
            let index = 0;
            Laya.timer.frameLoop(1, this, () => { 
                if (index < 0 || index >= this.renderItems.length) {
                    Laya.timer.clearAll(this);
                    return;
                }
                for (let i = 0; i < 10; i++) {
                    if (index >= this.renderItems.length) {
                        break;
                    }
                    const item = this.renderItems[index];
                    item.loadHeadIcon();
                    index++;
                }
            });
        }

        private loadData() {
            for (let index = 0; index < this.renderItems.length; index++) {
                let item = this.renderItems[index];
                let info:IConfigSliderInfo = {
                    value: view.AudioMgr.getCVvolume(item.characterId) * 100,
                    isMute: view.AudioMgr.getCVmute(item.characterId)
                }
                item.setInfo(info);
            }
        }

       

        
    }

}