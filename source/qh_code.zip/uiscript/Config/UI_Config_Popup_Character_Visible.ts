module uiscript {

    class CharItem extends UI_Component{
        private headSprite: Laya.Sprite;
        private head: UI_Character_Skin;
        private usingImg: Laya.Image;
        private hide: Laya.Sprite;
        private btn: Laya.Button;
        public onCreate(): void {
            this.headSprite = this.me.getChildByName('head') as Laya.Sprite;
            this.head = new UI_Character_Skin(this.headSprite.getChildByName('icon') as Laya.Sprite,'UI_Config');
            this.usingImg = this.me.getChildByName('using') as Laya.Image;
            this.hide = this.me.getChildByName('hide') as Laya.Sprite;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
        }

        public set char(charId: number) { 
            if (charId == -1) {
                this.headSprite.visible = false;
                this.usingImg.visible = false;
                this.hide.visible = false;
                this.btn.visible = false;
                return;
            }
            this.headSprite.visible = true;
            this.btn.visible = true;
            let d_chara = cfg.item_definition.character.get(charId);
            this.head.setSkin(d_chara.init_skin, 'smallhead');
            
        }

        public set isUsing(v: boolean) {
            this.usingImg.visible = v;
        }

        public set isHide(v: boolean) {
            this.hide.visible = v;
        }

        public set onClick(h: Laya.Handler) {
            this.btn.clickHandler = h;
        }



    }

    export class UI_Config_Popup_Character_Visible extends UIBase {
        public static Inst: UI_Config_Popup_Character_Visible = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_character_visibleUI());
            UI_Config_Popup_Character_Visible.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private charList: capsui.CScrollView;
        private allCharList: number[] = [];
        private hiddenMap: { [charId: string]: number };
        private lineCount: number = 7;
        private locking: boolean = false;


        public onCreate(): void {
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.charList = (this.root.getChildByName('list') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.charList.init_scrollview(Laya.Handler.create(this, this.itemRender, null, false), -1,this.lineCount, -4);

        }

        public show() {
            this.loadData();
            this.charList.rate = 0;
            this.locking = true;
            this.enable = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public hide() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        public onEnable(): void {
            
        }

        public onDisable(): void {
            this.sendHiddenInfo();
        }

        private loadData() {
            this.hiddenMap = game.Tools.deepCopy(UI_Sushe.hidden_characters_map);
            this.allCharList = [];
            //女角色在男角色之前，如果女性的最后一行没有满，则使用id=-1的占位符补齐，以保证男角色从新的一行开始显示
            let femaleList: number[] = [];
            let maleList: number[] = [];
            let _characters = game.Tools.GetSheetSortBy('item_definition', 'character', 'sort');
            _characters.forEach((charConfig: lqc.Sheet_ItemDefinition_Character) => {
                if (!charConfig.open || (charConfig.launch_time && game.Tools.getTimeByStr(charConfig.launch_time) > game.Tools.getServerTime())) {
                    return
                } else if (!UI_Sushe.chara_owned(charConfig.id)) {
                    return;
                }
                if (charConfig.sex == 1) {
                    femaleList.push(charConfig.id);
                } else {
                    maleList.push(charConfig.id);
                }
            });
            this.allCharList = this.allCharList.concat(femaleList);
            let remain = this.lineCount - (femaleList.length % this.lineCount);
            if (remain < this.lineCount) {
                for (let i = 0; i < remain; i++) {
                    this.allCharList.push(-1);
                }
            }
            this.allCharList = this.allCharList.concat(maleList);
            
            this.charList.reset();
            this.charList.addItem(this.allCharList.length);
        }

        private freshList() {
            this.charList.wantToRefreshAll();
        }

        private itemRender(data: any) {
            const index: number = data.index;
            const container: Laya.Sprite = data.container;
            const cache_data: any = data.cache_data;

            const item: CharItem = cache_data.item = cache_data.item || new CharItem(container);
            let charId = this.allCharList[index];
            item.char = this.allCharList[index];
            item.isUsing = UI_Sushe.main_character_id == charId;
            item.isHide = this.hiddenMap[charId] == 1;
            item.onClick = Laya.Handler.create(this, this.onHiddenBtnClick, [charId], false);

        }

        private onHiddenBtnClick(id: number) {
            if (this.locking) {
                return;
            }
            if (id == UI_Sushe.main_character_id) {
                UI_Info_Small.Inst.show(game.Tools.strOfLocalization(3611));
                return;
            }
            //如果在随机池中，则先执行从池中移除后隐藏
            if (UI_RoleSet.isInRandomPool(id) && !this.hiddenMap[id]) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(20209), Laya.Handler.create(this, () => {
                    this.hiddenMap[id] = this.hiddenMap[id] ? 0 : 1;
                    this.freshList();
                }));
                UI_SecondConfirm.Inst.setBtnState(true, true);
                return;
            }
            this.hiddenMap[id] = this.hiddenMap[id] ? 0 : 1;
            this.freshList();
        }

        private sendHiddenInfo() {
            if (!this.hiddenMap) return;
            let randomChanged: number[] = [];
            let hiddenChanged = false;
            for (const key in this.hiddenMap) {
                const hidden = this.hiddenMap[key];
                if (!!hidden != !!UI_Sushe.hidden_characters_map[key]) {
                    hiddenChanged = true;
                    const charId = +key;
                    if (UI_RoleSet.isInRandomPool(charId) && hidden) {
                        randomChanged.push(charId);
                    }
                    UI_Sushe.change_char_hidden(charId, hidden);
                }
            }
            if (!hiddenChanged) return;

            if (randomChanged.length) {
                randomChanged.forEach(charId => {
                    UI_RoleSet.changePool(charId, -1, true);
                });
                UI_RoleSet.updateData();
            }

            this.hiddenMap = null;
            UI_Sushe.updateSort(null, null, null, Laya.Handler.create(this, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('setHiddenCharacter', err, res);
                } else {
                    UI_Lobby.Inst.btns.refreshSusheRedpoint();
                }
            }));
        }
    }
}