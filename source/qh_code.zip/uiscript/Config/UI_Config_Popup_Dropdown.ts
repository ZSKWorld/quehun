module uiscript {

    class Line extends UI_Component {
        private isSelected: boolean = false;
        private selectImg: Laya.Image;
        private titleLabel: Laya.Label;
        private btn: Laya.Button;
        public onCreate(): void {
            this.selectImg = this.me.getChildByName('select') as Laya.Image;
            this.titleLabel = this.me.getChildByName('title') as Laya.Label;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
        }

        public set selected(value: boolean) {
            this.isSelected = value;
            this.selectImg.visible = value;
        }

        public get selected(): boolean {
            return this.isSelected;
        }

        public set title(value: string) {
            this.titleLabel.text = value;
        }

        public get button(): Laya.Button {
            return this.btn;
        }

    }

    export class UI_Config_Popup_Dropdown extends UIBase {
        public static Inst: UI_Config_Popup_Dropdown = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_dropdownUI());
            UI_Config_Popup_Dropdown.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private bg: Laya.Image;
        private tabGroup: UI_TabGroup_Base;
        private scrollPanel: ScrollPanel;
        private templateLine: Laya.Sprite = null;
        private lines: Array<Line>;
        private maxPanelHeight: number = 292;//3.5个行高度
        private onValueChangeHandler: Laya.Handler = null;
        public onCreate(): void {
            this.lines = [];
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.root.getChildByName('bg') as Laya.Image;
            let selectList = this.root.getChildByName('select_list') as Laya.Sprite;
            this.scrollPanel = new ScrollPanel(selectList);
            this.templateLine = this.scrollPanel.content.getChildByName('temp') as Laya.Sprite;
            this.templateLine.visible = false;
            this.lines = [];
            this.tabGroup = new UI_TabGroup_Base();
            this.tabGroup.onSelectChange = (index, btn, manualSwitching) => {
                this.onSelectChange(index, btn, manualSwitching);
            };
            this.tabGroup.ignoreSameCheck = true;
        }

        public onEnable(): void {

        }

        public onDisable(): void {

        }

        public init(titles: Array<string>, onValueChange: Laya.Handler = null) {
            this.onValueChangeHandler = onValueChange;
            //先生成行，再设置选中
            this.tabGroup.clear();
            if (this.lines.length < titles.length) {
                let needAddCount = titles.length - this.lines.length;
                for (let i = 0; i < needAddCount; i++) {
                    let lineComp = this.createLine();
                    let line = new Line(lineComp);
                    this.lines.push(line);
                }
            }

            for (let i = 0; i < this.lines.length; i++) {
                let line = this.lines[i];
                if (i < titles.length) {
                    line.me.visible = true;
                    line.title = titles[i];
                    this.tabGroup.AddTabButton(line.button);
                    line.me.y = i * this.templateLine.height;
                } else {
                    line.me.visible = false;
                }
            }
            this.tabGroup.init();
            let renderHeight = Math.min(this.maxPanelHeight, titles.length * this.templateLine.height);
            this.root.height = renderHeight;
            this.bg.height = renderHeight + 66;
            this.scrollPanel.panelHeight = renderHeight;
            let contentHeight = titles.length * this.templateLine.height;
            this.scrollPanel.contentHeight = contentHeight;
            this.scrollPanel.me.height = renderHeight;
            this.scrollPanel.rate = 0;
            this.scrollPanel.fresh();

        }

        public show(pos: Laya.Vector2, selectIndex: number = 0,isUp:boolean = false) {
            this.position = pos;
            this.tabGroup.selectedIndex = selectIndex;
            this.bg.skin = game.Tools.localUISrc(isUp ? 'myres/bothui/config/setting_dropdown_base_flip.png' :'myres/bothui/config/setting_dropdown_base.png')
            this.enable = true;
        }



        public hide() {
            this.enable = false;
        }



        private createLine(): Laya.Sprite {
            let _clone = this.templateLine.scriptMap['capsui.UICopy'];
            let _line: Laya.Sprite = _clone.getNodeClone();
            return _line;
        }

        private onSelectChange(index: number, btn: Laya.Button, manualSwitching: boolean = false) {
            let line = this.lines[index];
            if (index == this.tabGroup.selectedIndex) {
                line.selected = true;
                this.onValueChangeHandler?.runWith([index, manualSwitching]);
                this.hide();
            } else {
                line.selected = false;
            }

        }

        public set rate(value: number) {
            this.scrollPanel.rate = value;
        }

        public set position(value: Laya.Vector2) {
            this.root.x = value.x;
            this.root.y = value.y;
        }

        public get height(): number {
            return this.root.height;
        }

    }

}