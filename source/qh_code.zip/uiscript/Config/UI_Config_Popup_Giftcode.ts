module uiscript {
    export class UI_Config_Popup_Giftcode extends UIBase {
        public static Inst: UI_Config_Popup_Giftcode = null;

        public root: Laya.Sprite;
        public input: Laya.TextInput;
        public btn_confirm: Laya.Button;
        private locking: boolean;
        private btn_cd: number;
        private CODE_POOL = [
            // 'a','b','c','d','e','f','g','h','j',  // remove i o l
            // 'k','m','n','p','q','r','s','t','u',
            // 'v','w','x','y','z',

            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J',  // remove I O L
            'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U',
            'V', 'W', 'X', 'Y', 'Z',

            '2', '3', '4', '5', '6', '7', '8', '9',      // remove 0 1
        ];
        private length: number = 12;

        constructor() {
            super(new ui.both_ui.config.config_popup_giftcodeUI());
            UI_Config_Popup_Giftcode.Inst = this;
        }

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.input = this.root.getChildByName('textinput').getChildByName('input') as Laya.TextInput;
            this.input.on('input', this, () => {
                this.input.text = this.input.text.replace(/\s*/g, '');
            });

            (this.root.getChildByName('close_btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);

            (this.me.getChildByName('close_btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            this.btn_confirm = this.root.getChildByName('confirm_btn') as Laya.Button;
            this.btn_confirm.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (this.btn_cd > Laya.timer.currTimer) return;
                this.btn_cd = Laya.timer.currTimer + 1000;
                let code = this.input.text.trim();
                if (this.isSpecialCode(code)) {
                    app.NetAgent.sendReq2Lobby('Lobby', 'useSpecialGiftCode', { code: code }, (err, res) => {
                        this.btn_cd = 0;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('useGiftCode', err, res);
                        } else {
                            let rewards: Array<{ id: number, count: number }> = [];
                            for (let reward of res['rewards']) {
                                if (reward['replace_count'] > 0) {
                                    reward['reward']['count'] -= reward['replace_count'];
                                }
                                if (reward['reward']['count'] > 0) {
                                    let added = false;
                                    for (let finalReward of rewards) {
                                        if (finalReward.id == reward['reward']['id']) {
                                            finalReward.count += reward['reward']['count'];
                                            added = true;
                                            break;
                                        }
                                    }
                                    if (!added) {
                                        rewards.push(reward['reward']);
                                    }
                                }
                                if (reward['replace']) {
                                    let added = false;
                                    for (let finalReward of rewards) {
                                        if (finalReward.id == reward['replace']['id']) {
                                            finalReward.count += reward['replace']['count'];
                                            added = true;
                                            break;
                                        }
                                    }
                                    if (!added) {
                                        rewards.push(reward['replace']);
                                    }
                                }
                            }
                            game.Tools.showRewards({ rewards: rewards }, null);
                        }
                    });
                } else {
                    app.NetAgent.sendReq2Lobby('Lobby', 'useGiftCode', { code: code }, (err, res) => {
                        this.btn_cd = 0;
                        if (err || res['error']) {
                            UIMgr.Inst.showNetReqError('useGiftCode', err, res);
                        } else {
                            game.Tools.showRewards(res, null);
                        }
                    });
                }

            }, null, false);
            // this.input.on('input', this, ()=>{
            // 	this.btn_confirm.visible = this.input.text.length == 12;
            // });
        }

        public show() {
            this.enable = true;
            this.locking = true;
            this.input.text = '';
            this.btn_cd = 0;
            this.btn_confirm.visible = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public close() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }


        private isSpecialCode(code: string) {
            if (code.length !== this.length) return true;
            for (let i = 0; i < code.length; i++) {
                if (this.CODE_POOL.indexOf(code[i]) == -1) return true;
            }

            return false;
        }
    }

}