module uiscript {
    export class UI_Config_Popup_Info extends UIBase {
        public static Inst: UI_Config_Popup_Info = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_infoUI());
            UI_Config_Popup_Info.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private bg: Laya.Image;
        private arrow: Laya.Sprite;
        private contentLabel: Laya.Label;

        public onCreate(): void { 
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.root.getChildByName('bg') as Laya.Image;
            this.arrow = this.root.getChildByName('arrow') as Laya.Sprite;
            this.contentLabel = this.root.getChildByName('content') as Laya.Label;
        }

        public onEnable(): void {
            
        }

        public onDisable(): void { 

        }

        public show(pos: Laya.Vector2, info: string) {
            this.root.x = pos.x;
            this.root.y = pos.y;
            this.contentLabel.text = info;
            this.bg.height = this.contentLabel.trueHeight + 77;
            // this.arrow.y = this.bg.height/2;
            this.enable = true;
        }

        public hide(): void {
            this.enable = false;
        }
    }

}