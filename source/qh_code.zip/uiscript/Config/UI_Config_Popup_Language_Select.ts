module uiscript{

    class LanguageItem extends UI_Component { 
        private title: Laya.Label;
        private diselectBg: Laya.Sprite;
        private selectBg: Laya.Sprite;
        private btn: Laya.Button;
        private currentToggle: Laya.Image;
        public onCreate(): void {
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.title = this.me.getChildByName('title') as Laya.Label;
            this.diselectBg = this.me.getChildByName('diselect') as Laya.Sprite;
            this.selectBg = this.me.getChildByName('select') as Laya.Sprite;
            this.currentToggle = this.me.getChildByName('current') as Laya.Image;

        }

        public setTitle(title: string) { 
            this.title.text = title;
        }

        public set selected(isSelected: boolean) { 
            this.selectBg.visible = isSelected;
            this.diselectBg.visible = !isSelected;
            this.title.color = isSelected ? "#85ecff" : "#d4cfcf";
        }

        public get button(): Laya.Button {
            return this.btn;
        }

        public set current(isCurrent: boolean) {
            this.currentToggle.visible = isCurrent; 
        }

    }

    export class UI_Config_Popup_Language_Select extends UIBase {
        public static languageCode: Map<common.ELanguageType, number> = new Map<common.ELanguageType, number>([
            [common.ELanguageType.SIMPLE_CHINESE, 26030404],
            [common.ELanguageType.TRADITIONAL_CHINESE, 26030405],
            [common.ELanguageType.ENGLISH, 26030407],
            [common.ELanguageType.JAPANESE, 26030406],
            [common.ELanguageType.KOREAN, 26030408],
        ]);

        public static regionLanguageMap: Map<common.ERegionType, common.ELanguageType[]> = new Map<common.ERegionType, common.ELanguageType[]>([
            [common.ERegionType.TRADITIONAL_CHINESE, [common.ELanguageType.SIMPLE_CHINESE, common.ELanguageType.TRADITIONAL_CHINESE]],
            [common.ERegionType.SIMPLE_CHINESE, [common.ELanguageType.SIMPLE_CHINESE, common.ELanguageType.TRADITIONAL_CHINESE]],
            [common.ERegionType.ENGLISH, [common.ELanguageType.ENGLISH, common.ELanguageType.KOREAN, common.ELanguageType.TRADITIONAL_CHINESE]],
            [common.ERegionType.KOREAN, [common.ELanguageType.ENGLISH, common.ELanguageType.KOREAN, common.ELanguageType.TRADITIONAL_CHINESE]],
            [common.ERegionType.JAPANESE, [common.ELanguageType.JAPANESE]]
        ]);
            
        public static Inst: UI_Config_Popup_Language_Select = null;
        constructor() {
            super(new ui.both_ui.config.config_popup_language_selectUI());
            UI_Config_Popup_Language_Select.Inst = this;
        }

        private backCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private restartBtn: UI_UniversalBtn;
        private tabGroup: UI_TabGroup_Base;
        private scrollPanel: ScrollPanel;
        private itemTemplate: Laya.Sprite;
        private needRestart: boolean = false;
        private items: LanguageItem[] = [];
        private startPosesY: number[] = [129, 73, 0];
        private itemSpace: number = 13;
        private minHeight: number = 345;
        private locking: boolean = false;
        


        public onCreate(): void {
            this.backCloseBtn = this.me.getChildByName('close_btn') as Laya.Button;
            this.backCloseBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('close_btn') as Laya.Button;
            this.closeBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                this.hide();
            }, null, false);
            
            this.restartBtn = new UI_UniversalBtn(this.root.getChildByName('restart_btn') as Laya.Sprite);
            this.restartBtn.type = EUniversalBtnType.WARNING_BLUE;
            this.restartBtn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) {
                    return;
                }
                UI_Config_New.Inst.restartGame();
            }, null, false);
            this.scrollPanel = new ScrollPanel(this.root.getChildByName('list') as Laya.Sprite);
            this.itemTemplate = this.scrollPanel.content.getChildByName('templete') as Laya.Sprite;
            this.itemTemplate.visible = false;
            let languages = UI_Config_Popup_Language_Select.regionLanguageMap.get(GameMgr.client_type as common.ERegionType);
            this.tabGroup = new UI_TabGroup_Base();
            if (languages) { 
                languages.forEach((lang) => { 
                    let newSprite = this.itemTemplate.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
                    this.scrollPanel.content.addChild(newSprite);
                    let item = new LanguageItem(newSprite);
                    let langCode = UI_Config_Popup_Language_Select.languageCode.get(lang) || 26030404;
                    item.setTitle(game.Tools.strOfLocalization(langCode));
                    this.items.push(item);
                    this.tabGroup.AddTabButton(item.button);
                })

                //一个Item用一个的位置，2个item用第二个位置，3个及以上用第三个位置
                let startY = this.startPosesY[Math.min(this.items.length - 1, 2)];
                for (let i = 0; i < this.items.length; i++) {
                    let item = this.items[i];
                    item.me.y = startY + i * (this.itemTemplate.height + this.itemSpace);
                }
                let totalHeight = this.items.length * this.itemTemplate.height + (this.items.length - 1) * this.itemSpace;
                this.scrollPanel.contentHeight = Math.max(this.minHeight, totalHeight);
               
                this.tabGroup.onSelectChange = (index, btn, manualSwitching) => {
                    this.onSelectChange(index, btn, manualSwitching);
                }
            }
        }

        public show() {
            this.freshRestartBtn();
            let currentLanguage = UI_Config_Popup_Language_Select.currentLanguage;
            let langIndex = this.convertLanguage2Index(currentLanguage);
            this.tabGroup.forceSelect(langIndex);
            this.freshCurrentToggle();
            this.scrollPanel.rate = 0;
            this.locking = true;
            this.enable = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public hide() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        private freshRestartBtn() {
            this.restartBtn.setGrayed(!this.needRestart);
        }

        private onSelectChange(index: number, btn: Laya.Button, manualSwitching: boolean = false) {
            let item = this.items[index];
            if (index == this.tabGroup.selectedIndex) {
                item.selected = true;
                if (manualSwitching) {
                    if (this.locking) {
                        return;
                    }
                    let currentLanguage = UI_Config_Popup_Language_Select.currentLanguage;
                    let selectedLanguage = this.convertIndex2Language(index);
                    if (currentLanguage != selectedLanguage) {
                        UI_Config_Popup_Language_Select.currentLanguage = selectedLanguage;
                        // UI_Config_New.Inst.have_change_lan = true;
                        // UI_Config_New.needRestart = true;
                        this.needRestart = true;
                        this.freshRestartBtn();
                        this.freshCurrentToggle();
                        Laya.stage.event(EventCode.CONFIG_LANGUAGE_CHANGE);
                    }
                }
                
            } else {
                item.selected = false;
            }

        }

        private convertLanguage2Index(lang: common.ELanguageType): number {
            let languages = UI_Config_Popup_Language_Select.regionLanguageMap.get(GameMgr.client_type as common.ERegionType);
            for (let i = 0; i < languages.length; i++) {
                if (languages[i] == lang) {
                    return i;
                }
            }
            return 0;
        }

        private convertIndex2Language(index: number): common.ELanguageType { 
            let languages = UI_Config_Popup_Language_Select.regionLanguageMap.get(GameMgr.client_type as common.ERegionType);
            return languages[index];
        }

        private freshCurrentToggle() { 
            let currentLanguage = UI_Config_Popup_Language_Select.currentLanguage;
            let selectIndex = this.convertLanguage2Index(currentLanguage);
            this.items.forEach((item, index) => {
                item.current = index == selectIndex;
            });
        }

        public static get currentLanguage(): common.ELanguageType{
            let s: string = Laya.LocalStorage.getItem('language');
            //如果没有在当前的type中找到，或者localStorage里存的不是合法的语言类型，就默认使用当前客户端语言
            let languages = UI_Config_Popup_Language_Select.regionLanguageMap.get(GameMgr.client_type as common.ERegionType);
            if (!languages.includes(s as common.ELanguageType)) {
                s = GameMgr.client_language;
                this.currentLanguage = s as common.ELanguageType;
            }
            return s as common.ELanguageType;
        }
        
        public static set currentLanguage(lang: common.ELanguageType) {
            Laya.LocalStorage.setItem('language', lang);
        }
    }
}