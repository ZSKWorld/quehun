/**
* ui的麻将牌 牌下层+子节点牌上层 
*/
module uiscript {
    export enum EUIPaiFilterState{
        none,
        yellow,
        gray,
        dora,
        lidora
    }
    // 设置UI麻将牌
    // 注：对局内除zhanxing_mode特有的UI_Astrology界面已经全部改用UI_MJP
    export class UI_MJP {
        private front: Laya.Image;
        private bei: Laya.Image;
        public me: Laya.Sprite;

        private static YELLOW_FILTER: Array<number> = [1, 0, 0, 0, 0,
            0, 0.917, 0, 0, 0,
            0, 0, 0.663, 0, 0,
            0, 0, 0, 1, 0
        ];
        private static GRAY_FILTER: Array<number> = [
            0.6, 0, 0, 0, 0,
            0, 0.6, 0, 0, 0,
            0, 0, 0.6, 0, 0,
            0, 0, 0, 1, 0
        ];
        private static DORA_FILTER: Array<number> = [
            0.35, 0, 0, 0, 0,
            0, 0.77, 0, 0, 0,
            0, 0, 1, 0, 0,
            0, 0, 0, 1, 0
        ];
        private static LiDORA_FILTER: Array<number> = [
            1, 0, 0, 0, 0,
            0, 0.64, 0, 0, 0,
            0, 0, 0.44, 0, 0,
            0, 0, 0, 1, 0
        ];
        private static PAI_FILTERS: number[][] = [
            [], this.YELLOW_FILTER, this.GRAY_FILTER, this.DORA_FILTER, this.LiDORA_FILTER
        ];

        public static getUIPaiFilterByState(state: EUIPaiFilterState){
            return this.PAI_FILTERS[state];
        }

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.onCreate();
        }
        public onCreate() {
            this.bei = this.me as Laya.Image;
            this.front = this.bei.getChildAt(0) as Laya.Image;
        }

        /**
        * skin: 牌信息，back为盖牌，其他为1s，2p, isToumingpai：出天命模式外透明牌显示，只有单面，显示图也有透明图
        */
        public show(skin: string, isToumingpai: boolean = false) {
            this.reset();
            if (!skin) return;
            this.me.visible = true;
            skin = skin.replace('t', ''); //这边不显示透明牌
            const mjpmPath = this.getMjpResPath(skin, isToumingpai);
            if (isToumingpai) {
                this.bei.skin = game.Tools.localUISrc(mjpmPath + skin + '.png');
                return;
            }
            const mjpPath: string = 'myres2/mjp/' + GameMgr.Inst.mjp_view + '/hand/';
            if (skin == 'back') {
                this.bei.skin = game.Tools.localUISrc(mjpmPath + '5z.png');
                this.front.skin = game.Tools.localUISrc(mjpPath + 'back.png')
            } else {
                this.front.skin = game.Tools.localUISrc(mjpPath + 'front.png');
                this.bei.skin = game.Tools.localUISrc(mjpmPath + skin + '.png');
            }
            this.me.filters = [];
        }

        public getMjpResPath(skin: string, isToumingpai: boolean = false): string {
            if (isToumingpai) return 'myres2/mjp/' + GameMgr.Inst.touming_mjp_view + '/ui/';
            if (game.Scene_MJ.Inst && game.Scene_MJ.Inst.active) {
                if (view.DesktopMgr.Inst.is_jiuchao_mode()) { //透明牌模式不使用自定义牌面
                    let default_mjp_view: string = 'mjpface_default';
                    let item_surface_id: number = game.GameUtility.get_view_default_item_id(game.EView.mjp_surface);
                    let d_surface_view = cfg.item_definition.view.get(item_surface_id);
                    if (d_surface_view) default_mjp_view = d_surface_view.res_name;
                    if (view.DesktopMgr.en_mjp) {
                        default_mjp_view += '_0';
                    }
                    return 'myres2/mjpm/' + default_mjp_view + '/ui/';
                }
            }
            if (skin == 'bd') {
                return 'myres2/mjpm/' + GameMgr.Inst.specialMJPMView + '/ui/';
            }
            return 'myres2/mjpm/' + GameMgr.Inst.mjp_surface_view + '/ui/';
        }

        /**
        * 天命模式专用，变黄
        */
        public setYellowState() {
            this.me.filters = [new Laya.ColorFilter(UI_MJP.getUIPaiFilterByState(EUIPaiFilterState.yellow))];
        }

        public setFiltersState(state: EUIPaiFilterState = EUIPaiFilterState.none) {
            if (state == EUIPaiFilterState.none) {
                this.me.filters = [];
            } else {
                this.me.filters = [new Laya.ColorFilter(UI_MJP.getUIPaiFilterByState(state))];
            }
        }

        public pos(x?: number, y?: number) {
            if (x != undefined && x != null) this.me.x = x;
            if (y != undefined && y != null) this.me.y = y;
        }

        public reset() {
            this.front.skin = '';
            this.bei.skin = '';
            this.me.visible = false;
        }

        // 强制设置单张图
        public showSkin(skin: string) {
            this.front.skin = '';
            this.bei.skin = skin;
        }
    }
}