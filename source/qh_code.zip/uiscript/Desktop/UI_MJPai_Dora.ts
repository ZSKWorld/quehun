module uiscript {
    export interface UI_MJPai_DoraInfo {
        mode: number; //0:自摸，1:点炮，2:满贯流局
        isTianMing: boolean;
        isJiuChao: boolean;
        doras: Array<string>;
    }

    export class UI_MJPai_Dora extends UI_Component {
        private mjps: Array<UI_MJP>;
        private maxLength: number = 5;


        public onCreate(): void {
            this.mjps = [];
            this.maxLength = 5;
            for (let i = 0; i < this.maxLength; i++) {
                let mjp = new UI_MJP(this.me.getChildAt(i) as Laya.Sprite);
                this.mjps.push(mjp);
            }

        }

        /**
         * 
         * @param info 
         * @param isHide 无数据是否隐藏 
         */
        public show(info: UI_MJPai_DoraInfo, isHide: boolean = false) {
            for (let i: number = 0; i < this.maxLength; i++) {
                let skin: string = 'back';

                if (i < info.doras.length) skin = info.doras[i];
                if (skin == 'back' && info.isJiuChao) {
                    this.mjps[i].showSkin(game.Tools.localUISrc('myres/mjdesktop/tou_dora_back.png'));
                } else if (skin.indexOf('t') != -1) {
                    this.mjps[i].show(skin, true);
                } else {
                    this.mjps[i].show(skin);

                }

                if (isHide) {
                    //没有对应数据的隐藏，有数据的显示
                    this.mjps[i].me.visible = i < info.doras.length;
                }

            }
        }

    }

}