module uiscript {

    export interface UI_MJPai_HandInfo {

        hand: Array<string>;
        ming: Array<string>;
        hupai: string;
        mode: number; //0:自摸，1:点炮，2:满贯流局
        isTianMing: boolean;
        isJiuChao: boolean;

    }

    /**
     * 这个对应的UI下面需要有20个Image
     */
    export class UI_MJPai_Hand extends UI_Component {
        private mjps: Array<UI_MJP>;
        private maxLength: number = 20;
        private width_pai: number = 0;
        private com_span: number = 0;

        /**
         * 基础长度，如果牌的长度超过这个长度，就会缩小
         */
        private innerBaseWidth: number = 0;
        public set baseWidth(value: number) {
            this.innerBaseWidth = value;
        }

        public onCreate(): void {

            this.mjps = [];
            this.maxLength = 20;

            for (let i = 0; i < this.maxLength; i++) {
                let mjp = new UI_MJP(this.me.getChildAt(i) as Laya.Sprite);
                this.mjps.push(mjp);
            }
            this.width_pai = this.mjps[0].me.width;
            this.com_span = this.width_pai * 0.5;
        }

        public show(info: UI_MJPai_HandInfo, isRenderTouMing: boolean = true): void {
            let width_pai: number = this.mjps[0].me.width;
            let com_span: number = width_pai * 0.5;
            for (let i: number = 0; i < this.mjps.length; i++) {
                this.mjps[i].reset();
            }
            let current_index: number = 0;
            let current_x: number = 0;
            let hand: Array<mjcore.MJPai> = [];
            for (let i: number = 0; i < info.hand.length; i++) hand.push(mjcore.MJPai.Create(info.hand[i]));
            if (!isRenderTouMing) {
                for (let index = 0; index < hand.length; index++) {
                    const element = hand[index];
                    element.touming = false;
                }
            }
            hand = hand.sort((a, b) => {
                let va: number = a.numValue() * 10 + (a.dora ? 0 : 1);
                let vb: number = b.numValue() * 10 + (b.dora ? 0 : 1);
                return va - vb;
            });
            for (let i: number = 0; i < hand.length; i++) {
                if (info.isTianMing) {
                    this.mjps[current_index].show(hand[i].toString());
                    if (hand[i].touming) {
                        this.mjps[current_index].setYellowState();
                    }
                } else {

                    this.mjps[current_index].show(hand[i].toString(false), hand[i].touming);

                }

                this.mjps[current_index].pos(current_x, 0);
                current_x += width_pai;
                current_index++;
            }

            //副露
            if (info.ming && info.ming.length > 0) {
                current_x += com_span;
                for (let i: number = 0; i < info.ming.length; i++) {
                    let str_ming: string = info.ming[i];
                    if (str_ming.charAt(str_ming.length - 1) != ')') {
                        //兼容老版红宝牌只有3个的时候标准情况，加入多宝牌后记录会出问题
                        let _m: Array<string> = str_ming.split('|');
                        if (_m.length == 1) {
                            let s_type: string = _m[0].charAt(1);
                            let s_index: string = _m[0].charAt(0);
                            if (s_index == '0') s_index = '5';
                            for (let j: number = 0; j < 4; j++) {
                                let skin: string = '';
                                if (j == 0 || j == 3) {
                                    skin = 'back';
                                } else {
                                    if (j == 1 && s_index == '5' && s_type != 'z') {
                                        skin = '0' + s_type;
                                    } else {
                                        skin = s_index + s_type;
                                    }
                                }
                                this.mjps[current_index].pos(current_x, 0);
                                this.mjps[current_index].show(skin)
                                current_x += width_pai;
                                current_index++;
                            }
                        } else {
                            for (let j: number = 0; j < _m.length; j++) {
                                let skin: string = _m[j].toString();
                                if (info.isTianMing) {
                                    this.mjps[current_index].show(skin);
                                    if (skin.indexOf('t') != -1) {
                                        this.mjps[current_index].setYellowState();
                                    }
                                } else {
                                    this.mjps[current_index].show(skin, skin.indexOf('t') != -1 && isRenderTouMing);
                                }
                                this.mjps[current_index].pos(current_x, 0);
                                current_x += width_pai;
                                current_index++;
                            }
                        }
                    } else {
                        //新版ming的记录angang(5p,0p,0p,5p)这种
                        let s_category: string = '';
                        let _m: Array<string> = [];
                        for (let i: number = 0; i < str_ming.length; i++) {
                            if (str_ming.charAt(i) == '(') {
                                s_category = str_ming.substring(0, i);
                                _m = str_ming.substring(i + 1, str_ming.length - 1).split(',');
                                break;
                            }
                        }
                        if (s_category == 'angang' && !info.isJiuChao) {
                            let s_index: string = _m[0].charAt(0);
                            let s_type: string = _m[0].charAt(1);
                            let dora_count: number = 0;
                            for (let i: number = 0; i < _m.length; i++) {
                                if (_m[i].charAt(0) == '0') dora_count++;
                            }
                            if (dora_count > 0) s_index = '5';
                            for (let i: number = 0; i < _m.length; i++) {
                                let skin: string = '';
                                if (i == 0 || i == 3) {
                                    skin = 'back';
                                } else {
                                    if (i <= dora_count) skin = '0' + s_type;
                                    else skin = s_index + s_type;
                                }


                                skin = skin.replace('t', '');
                                this.mjps[current_index].show(skin);
                                this.mjps[current_index].pos(current_x, 0);
                                if (info.isTianMing && skin.indexOf('t') >= 0) {
                                    this.mjps[current_index].setYellowState();
                                }
                                current_x += width_pai;
                                current_index++;
                            }
                        } else if (s_category == 'angang') {
                            let s_index: string = _m[0].charAt(0);
                            let s_type: string = _m[0].charAt(1);
                            for (let i: number = 0; i < _m.length; i++) {
                                let skin: string = '';
                                if (i == 0) {
                                    skin = 'back';
                                } else {
                                    skin = s_index + s_type;
                                }

                                if (i != 0) {
                                    this.mjps[current_index].show(skin, isRenderTouMing);
                                } else {
                                    this.mjps[current_index].show(skin);
                                }
                                this.mjps[current_index].pos(current_x, 0);
                                current_x += width_pai;
                                current_index++;
                            }
                        } else {
                            _m = game.Tools.sortPaiStr(_m);
                            for (let j: number = 0; j < _m.length; j++) {
                                let skin: string = _m[j];

                                if (skin.indexOf('t') != -1 && !info.isTianMing) {
                                    this.mjps[current_index].show(skin, isRenderTouMing);
                                } else {
                                    this.mjps[current_index].show(skin);
                                }
                                if ((skin.indexOf('t') != -1 && info.isTianMing)) {
                                    this.mjps[current_index].setYellowState();
                                }
                                this.mjps[current_index].pos(current_x, 0);
                                current_x += width_pai;
                                current_index++;
                            }
                        }
                    }
                }
            }

            current_x += com_span;
            //胡的牌
            if (info.mode != 2) {
                if (info.hupai.indexOf('t') != -1 && !info.isTianMing) {
                    this.mjps[current_index].show(info.hupai, isRenderTouMing);
                } else {
                    this.mjps[current_index].show(info.hupai);
                }
                this.mjps[current_index].pos(current_x, 0);
                current_x += width_pai;
                current_index++;
            }

            //设置缩放
            let scale: number = 1;
            if (this.innerBaseWidth != 0 && current_x > this.innerBaseWidth) {
                scale = this.innerBaseWidth / current_x;
            }
            this.me.scaleX = this.me.scaleY = scale;
            // let scale: number = 1160 * 0.96 / current_x;

            // this.me.scaleX = this.me.scaleY = scale;


        }


    }

}