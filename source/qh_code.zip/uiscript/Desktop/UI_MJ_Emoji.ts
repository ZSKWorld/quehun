module uiscript {
    export class UI_MJ_Emoji extends UIBase {
        public static Inst: UI_MJ_Emoji = null;
        constructor() {
            super(new ui.mj.mj_emojiUI());
            UI_MJ_Emoji.Inst = this;
        }
        private root: Laya.Sprite;
        private in: Laya.Sprite;
        private out: Laya.Sprite;
        private in_out: Laya.Sprite;
        private btn_chat: Laya.Button;
        private btn_chat_in: Laya.Button
        private scrollbar: capsui.CScrollBar;
        private scrollview: capsui.CScrollView;
        private btn_emos: Array<Laya.Sprite> = [];
        private emo_infos: { char_id: number, emoji: Array<Array<number>>, server: number };
        private btn_mask: Laya.Sprite;
        private emo_log_count: number;

        private emos: Array<{ path: string, sub_id: number, sort: number }> = [];
        private allgray: boolean = false;

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.in = this.root.getChildByName('in') as Laya.Sprite;
            this.out = this.root.getChildByName('out') as Laya.Sprite;
            this.in_out = this.in.getChildByName('in_out') as Laya.Sprite;
            this.btn_chat = this.out.getChildByName('btn_chat') as Laya.Button;
            this.btn_mask = this.out.getChildByName('btn_mask') as Laya.Sprite;
            this.btn_chat.clickHandler = new Laya.Handler(this, () => {
                this.switchShow(true);
            });
            this.btn_chat_in = this.in_out.getChildByName('btn_chat') as Laya.Button;
            this.btn_chat_in.clickHandler = new Laya.Handler(this, () => {
                this.switchShow(false);
            });
            this.scrollbar = (this.in.getChildByName('scrollbar_light') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this.scrollview = this.in.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item), -1, 3);
            this.scrollview.reset();
            this.scrollbar.init(null);
            this.scrollview.me.on('ratechange', this, () => {
                if (this.scrollview.total_height > 0) {
                    this.scrollbar.setVal(this.scrollview.rate, this.scrollview.view_height / this.scrollview.total_height);
                } else {
                    this.scrollbar.setVal(0, 1);
                }
            });
            // if (GameMgr.client_language != 'chs') {
            (this.out.getChildAt(2) as Laya.Sprite).visible = false;
            (this.out.getChildAt(3) as Laya.Sprite).visible = true;
        }
        public initRoom() {
            let chara = view.DesktopMgr.Inst.main_role_character_info;
            let d_ch = cfg.item_definition.character.find(chara['charid']);
            this.emo_log_count = 0;
            this.emos = [];
            for (let i: number = 0; i < 9; i++) {
                this.emos.push({
                    path: d_ch.emo + '/' + i + '.png',
                    sub_id: i,
                    sort: i
                });
            }
            if (chara['extra_emoji']) {
                for (let i: number = 0; i < chara['extra_emoji'].length; i++) {
                    this.emos.push({
                        path: d_ch.emo + '/' + chara['extra_emoji'][i] + '.png',
                        sub_id: chara['extra_emoji'][i],
                        sort: chara['extra_emoji'][i] > 12 ? 1000000 - chara['extra_emoji'][i] : chara['extra_emoji'][i]
                    });
                }
            }
            this.emos = this.emos.sort((a, b) => { return a.sort - b.sort; });
            this.allgray = false;
            this.scrollbar.reset();
            this.scrollview.reset();
            this.scrollview.addItem(this.emos.length);
            this.btn_chat.disabled = false;
            this.btn_mask.visible = view.DesktopMgr.Inst.emoji_switch;
            // if (GameMgr.client_language != 'chs') {
            (this.out.getChildAt(3) as Laya.Sprite).visible = !view.DesktopMgr.Inst.emoji_switch;
            // }
            this.root.x = 1896;
            this.in.visible = false;
            this.out.visible = true;
            this.emo_infos = { char_id: chara['charid'], emoji: [], server: GameMgr.client_type == 'chs_t' ? 1 : (GameMgr.client_type == 'jp' ? 2 : 3) };
        }

        private render_item(data) {
            let index: number = data.index;
            let container: Laya.Sprite = data.container;

            let emo: { path: string, sub_id: number } = this.emos[index];
            let btn: Laya.Button = container.getChildByName('btn') as Laya.Button;
            btn.skin = game.LoadMgr.getResImageSkin(emo.path);
            if (this.allgray) {
                game.Tools.setGrayDisable(btn, true);
            } else {
                game.Tools.setGrayDisable(btn, false);
                btn.clickHandler = Laya.Handler.create(this, () => {
                    if (app.NetAgent.netRouteGroup_mj.getConnectState() == game.EConnectState.usable) {
                        GameMgr.Inst.BehavioralStatistics(22);
                        let have_add = false;
                        for (let info of this.emo_infos.emoji) {
                            if (info[0] == emo.sub_id) {
                                info[0]++;
                                have_add = true;
                                break;
                            }
                        }
                        if (!have_add) {
                            this.emo_infos.emoji.push([emo.sub_id, 1]);
                        }
                        app.NetAgent.sendReq2MJ('FastTest', 'broadcastInGame', {
                            content: JSON.stringify({ emo: emo.sub_id }),
                            except_self: false
                        }, (err, res) => {

                        });
                    }

                    this.change_all_gray(true);
                    Laya.timer.once(5000, this, () => {
                        this.change_all_gray(false);
                    });
                    this.switchShow(false);
                }, null, false);
            }
        }

        private change_all_gray(gray: boolean) {
            this.allgray = gray;
            this.scrollview.wantToRefreshAll();
        }


        public switchShow(show_detail: boolean) {
            let target_x: number = 0;
            if (!show_detail) {
                target_x = 1896;
            } else {
                target_x = 1367;
            }
            Laya.Tween.to(this.root, { x: 1972 }, show_detail ? 60 : 140, Laya.Ease.strongOut, Laya.Handler.create(this, () => {

                if (show_detail) {
                    this.out.visible = false;
                    this.in.visible = true;
                } else {
                    this.out.visible = true;
                    this.in.visible = false;
                }
                Laya.Tween.to(this.root, { x: target_x }, !show_detail ? 60 : 140, Laya.Ease.strongOut, Laya.Handler.create(this, () => {
                    this.btn_chat.disabled = false;
                    this.btn_chat_in.disabled = false;
                }), 0, true, true);
            }), 0, true, true);

            this.btn_chat.disabled = true;
            this.btn_chat_in.disabled = true;
        }

        public sendEmoLogUp() {
            if (this.emo_log_count > 0 && this.emo_infos && view.DesktopMgr.Inst.mode == view.EMJMode.play) {
                let counts = GameMgr.Inst.getMouse();
                GameMgr.Inst.postInfo2Server('emo_stats', {
                    data: this.emo_infos,
                    m: view.DesktopMgr.click_prefer,
                    d: counts,
                    e: window.innerHeight / 2,
                    f: window.innerWidth / 2,
                    t: UI_DesktopInfo.Inst.min_double_time,
                    g: UI_DesktopInfo.Inst.max_double_time,
                    uuid: GameMgr.Inst.mj_game_uuid
                }, false);
                this.emo_infos.emoji = [];
            }
            this.emo_log_count++;
        }

        public reset() {
            this.emo_infos = null;
            this.scrollbar.reset();
            this.scrollview.reset();
        }

        public set rootPosX(x: number) {
            this.root.x = x;
        }

        public get rootPosX(): number {
            return this.root.x;
        }

        public set rootPosY(y: number) {
            this.root.y = y;
        }

        public get rootPosY(): number {
            return this.root.y;
        }


    }

}