module uiscript {

    class PopUp_Info extends UI_Component {
        private maskCloseBtn: Laya.Button;
        private root: Laya.Sprite;
        private closeBtn: Laya.Button;
        private title: Laya.Label;
        private content: Laya.Label;
        private icon: Laya.Image;
        private isLock: boolean = false;

        public onCreate(): void {
            this.maskCloseBtn = this.me.getChildByName('close') as Laya.Button;
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.closeBtn = this.root.getChildByName('close') as Laya.Button;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                if (!this.isLock) {
                    this.close();
                }
            });
            this.closeBtn.clickHandler = new Laya.Handler(this, () => {
                if (!this.isLock) {
                    this.close();
                }
            });
            this.title = this.root.getChildByName('title') as Laya.Label;
            this.content = this.root.getChildByName('desc') as Laya.Label;
            this.icon = this.root.getChildByName('icon') as Laya.Image;
        }

        public show(groupId: number) {
            this.isLock = true;
            let config = cfg.achievement.badge_group.get(groupId);
            game.LoadMgr.setImgSkin(this.icon, "myres2/badge/" + config.img, null, "UI_MJ_Highlight");
            this.title.text = game.Tools.strOfLocalization(config.name);
            this.content.text = game.Tools.strOfLocalization(config.desc);
            this.visible = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
            }));
        }

        public close() {
            this.isLock = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.isLock = false;
                this.visible = false;
            }));
        }



    }

    class HighlightItem extends UI_Component {
        private btn: Laya.Button;
        private icon: Laya.Image;
        private title: Laya.Label;
        private countLabel: Laya.Label;
        private onClickHandler: Laya.Handler;
        public onCreate(): void {
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.title = this.me.getChildByName('title') as Laya.Label;
            this.countLabel = this.me.getChildByName('count') as Laya.Label;
            this.btn.clickHandler = new Laya.Handler(this, this.onClick);
            this.icon = this.me.getChildByName('icon') as Laya.Image;
        }

        public set highlightType(groupId: number) {
            let config = cfg.achievement.badge_group.get(groupId);
            game.LoadMgr.setImgSkin(this.icon, "myres2/badge/" + config.img, null, "UI_MJ_Highlight");
            this.title.text = game.Tools.strOfLocalization(config.name);

        }

        public set count(count: number) {
            this.countLabel.text = "+" + count.toString();
        }

        public set clickHandler(handler: Laya.Handler) {
            this.onClickHandler = handler;
        }

        private onClick() {
            if (this.onClickHandler) {
                this.onClickHandler.run();
            }
        }

        

    }
    export class UI_MJ_Highlight extends UIBase {
        public static Inst: UI_MJ_Highlight;
        private root: Laya.Sprite;
        private itemSpace: number = 25;
        private items2: Array<HighlightItem> = [];
        private items2Parent: Laya.Sprite;
        private items2Anims: Array<Laya.FrameAnimation> = [];
        private items5: Array<HighlightItem> = [];
        private items5Parent: Laya.Sprite;
        private items5Anims: Array<Laya.FrameAnimation> = [];
        private popupInfo: PopUp_Info;
        private onCompleteHandler: Laya.Handler;
        private isLock: boolean = false;
        private showAnimation: Laya.FrameAnimation;

        constructor() {
            super(new ui.mj.desktop_highlightUI());
            UI_MJ_Highlight.Inst = this;
        }

        public onCreate(): void {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.popupInfo = new PopUp_Info(this.me.getChildByName('popup_info') as Laya.Sprite);
            this.popupInfo.visible = false;
            this.items2Parent = this.root.getChildByName('items2') as Laya.Sprite;
            this.items5Parent = this.root.getChildByName('items5') as Laya.Sprite;
          
            for (let i = 0; i < 2; i++) {
                let item = new HighlightItem(this.items2Parent.getChildAt(i) as Laya.Sprite);
                this.items2.push(item);
            }

            for (let i = 0; i < 5; i++) {
                let item = new HighlightItem(this.items5Parent.getChildAt(i) as Laya.Sprite);
                this.items5.push(item);
            }
            this.showAnimation = (this.me as ui.mj.desktop_highlightUI).show;
            this.items2Anims.push((this.me as ui.mj.desktop_highlightUI).ani2_0 as Laya.FrameAnimation);
            this.items2Anims.push((this.me as ui.mj.desktop_highlightUI).ani2_1 as Laya.FrameAnimation);
            this.items5Anims.push((this.me as ui.mj.desktop_highlightUI).ani5_0 as Laya.FrameAnimation);
            this.items5Anims.push((this.me as ui.mj.desktop_highlightUI).ani5_1 as Laya.FrameAnimation);
            this.items5Anims.push((this.me as ui.mj.desktop_highlightUI).ani5_2 as Laya.FrameAnimation);
            this.items5Anims.push((this.me as ui.mj.desktop_highlightUI).ani5_3 as Laya.FrameAnimation);
            this.items5Anims.push((this.me as ui.mj.desktop_highlightUI).ani5_4 as Laya.FrameAnimation);
        }

        /**
         * id 徽章id
         * changeCount 变化数量
         * @param datas {id: number, changeCount: number}[]
         */
        public show(datas: Array<Object>, onCompleteHandler: Laya.Handler) {
            this.onCompleteHandler = onCompleteHandler;
            //测试数据
            // {
            //     datas = [];
            //     datas.push({ id: 810001, changeCount: 1 });
            //     datas.push({ id: 810002, changeCount: 1 });
            //     datas.push({ id: 810003, changeCount: 1 });
            //     datas.push({ id: 810004, changeCount: 1 });
            //     datas.push({ id: 810005, changeCount: 1 });
            //     datas.push({ id: 810012, changeCount: 1 });
            //     datas.push({ id: 810013, changeCount: 1 });
            // }
           
            // 转换徽章id为徽章组id，同组的徽章只显示一个，数量累加
            let badgeGroup: Array<{ id: number, changeCount: number }> = [];
            for (let i = 0; i < datas.length; i++) {
                let badgeId = datas[i]['id'];
                let config = null;
                cfg.achievement.badge_group.forEach((item: lqc.Sheet_Achievement_BadgeGroup) => {
                    if (item.badge_id.indexOf(badgeId) != -1) {
                        config = item;
                    }
                });
                let data = badgeGroup.find(predicate => predicate.id == config.id);
                if (data) {
                    data.changeCount += datas[i]['changeCount'];
                } else {
                    badgeGroup.push({ id: config.id, changeCount: datas[i]['changeCount'] });
                }

            }

            if (badgeGroup.length <= 2) {
                this.render2Items(badgeGroup);
                this.items2Parent.visible = true;
                this.items5Parent.visible = false;
            } else {
                this.render5Items(badgeGroup);
                this.items2Parent.visible = false;
                this.items5Parent.visible = true;
            }
            this.enable = true;
            // 显示动画
            this.doShowAnim(badgeGroup.length);
            
        }

        public close() {

            this.enable = false;
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_MJ_Highlight', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_MJ_Highlight', false);
        }

        private render2Items(datas: Array<Object>) {
            let visibleItems = [];
            let spaces = [];
            for (let i = 0; i < this.items2.length; i++) {
                let item = this.items2[i];
                if (datas[i]) {
                    item.visible = true;
                    item.highlightType = datas[i]['id'];
                    item.count = datas[i]['changeCount'];
                    visibleItems.push(item.me);
                    spaces.push(this.itemSpace);
                    item.clickHandler = new Laya.Handler(this, this.onClickItem, [datas[i]['id']]);

                } 
                else {
                    item.visible = false;
                }
                
            }

            game.Tools.sprite_align_center(visibleItems, 445, spaces);
            for (let i = 0; i < this.items2.length; i++) {
                let item = this.items2[i];
                item.visible = false;

            }

        }

        private render5Items(datas: Array<Object>) {
            let visibleItems = [];
            let spaces = [];
            for (let i = 0; i < this.items5.length; i++) {
                let item = this.items5[i];
                if (datas[i]) {
                    item.visible = true;
                    item.highlightType = datas[i]['id'];
                    item.count = datas[i]['changeCount'];
                    visibleItems.push(item.me);
                    spaces.push(this.itemSpace);
                    item.clickHandler = new Laya.Handler(this, this.onClickItem, [datas[i]['id']]);
                } else {
                    item.visible = false;
                }
                
            }
            game.Tools.sprite_align_center(visibleItems, 445, spaces);
            for (let i = 0; i < this.items5.length; i++) {
                let item = this.items5[i];
                item.visible = false;

            }
        }

        private onClickItem(groupId: number) {
            if (this.isLock) {
                return;
            }
            this.popupInfo.show(groupId);
        }


        private effect2Point = new Laya.Point(3, 144);
        private effect5Point = new Laya.Point(78, 144);
        private doShowAnim(itemCount: number) {
            this.isLock = true;
            //播放ui动画
            this.showAnimation.play(0, false);
            //挨个显示徽章，间隔4帧
            let items = itemCount <= 2 ? this.items2 : this.items5;
            let anims = itemCount <= 2 ? this.items2Anims : this.items5Anims;
            let effectPoint = itemCount <= 2 ? this.effect2Point : this.effect5Point;
            let index = 0;
            let showItem = () => {
                if (index < itemCount) {
                    items[index].visible = true;
                    anims[index].play(0, false);
                    //生成特效
                    let showEffect = game.FrontEffect.Inst.create_ui_effect(items[index].me, 'scene/effect_ggsk_js.lh', effectPoint, 1);
                    Laya.timer.once(500, this, () => { 
                        showEffect.destory();
                    })
                    Laya.timer.once(60, this, showItem);
                    index++;
                } 
            }
            //4帧
            Laya.timer.once(60, this, showItem);
            //ui动画结束后显示按钮
            Laya.timer.once(itemCount * 60 + 800, this, () => {
                this.isLock = false;
                if (this.onCompleteHandler) {
                    this.onCompleteHandler.run();
                }
            });

        }


    }
}