module uiscript {

    enum MakaBtnState {
        NONE = 0,
        ANALYSISING = 1,
        OFF = 2,
        ON = 3,
    }

    class MakaBtn extends UI_Component {

        private btn: Laya.Button;
        private icon: Laya.Image;
        private bg: Laya.Image;
        private title: Laya.Label;
        private btnState: MakaBtnState = MakaBtnState.NONE;


        public onCreate(): void {
            this.btn = this.me.getChildByName("btn") as Laya.Button;
            this.icon = this.me.getChildByName("icon") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
            //如果是英文版，则字体大小改为18
            this.title.fontSize = GameMgr.client_language == "en" ? 18 : 20;
            this.bg = this.me.getChildByName("bg") as Laya.Image;
            this.bg.width = this.title.trueWidth + 14;

        }

        public set onClick(handler: Laya.Handler) {
            this.btn.clickHandler = handler;
        }

        public set state(state: MakaBtnState) {
            this.btnState = state;
            let titleStr = "";
            let iconStr = "";
            let titleColor = "";
            switch (state) {
                case MakaBtnState.NONE:
                    titleStr = game.Tools.strOfLocalization(20358);
                    iconStr = "myres/mjdesktop/maka/maka_match_analysis_button_close.png"
                    titleColor = "#B2BBCE";
                    break;
                case MakaBtnState.ANALYSISING:
                    titleStr = game.Tools.strOfLocalization(20359);
                    iconStr = "myres/mjdesktop/maka/maka_match_analysis_button_close.png"
                    titleColor = "#70F6FB";
                    break;
                case MakaBtnState.OFF:
                    titleStr = game.Tools.strOfLocalization(20360);
                    iconStr = "myres/mjdesktop/maka/maka_match_analysis_button_close.png"
                    titleColor = "#B2BBCE";
                    break;
                case MakaBtnState.ON:
                    titleStr = game.Tools.strOfLocalization(20361);
                    iconStr = "myres/mjdesktop/maka/maka_match_analysis_button_open.png"
                    titleColor = "#FFD861";
                    break;
            }
            this.title.text = titleStr;
            this.icon.skin = game.Tools.localUISrc(iconStr);
            this.title.color = titleColor;
            this.bg.width = this.title.trueWidth + 14;
        }

        public get state(): MakaBtnState {
            return this.btnState;
        }


    }

    class MineScore extends UI_Component {
        private allMakaLevelImg: Laya.Image;
        private juMakaLevelImg: Laya.Image;
        public onCreate(): void {
            this.allMakaLevelImg = this.me.getChildByName("all_maka_level") as Laya.Image;
            this.juMakaLevelImg = this.me.getChildByName("ju_maka_level") as Laya.Image;
        }

        public set allMakaLevel(score: number) {
            this.allMakaLevelImg.skin = game.MakaManager.getLevelImg(score);
        }

        public set juMakaLevel(score: number) {
            this.juMakaLevelImg.skin = game.MakaManager.getLevelImg(score);
        }

    }

    /**
     * 推荐打、立直牌
     */
    class CardTip extends UI_Component {
        private bgBest: Laya.Image;
        private bgNormal: Laya.Image;
        private wordImage: Laya.Image;
        private scoreLabel: Laya.Label;
        public onCreate(): void {

            this.bgBest = this.me.getChildByName("bg_best") as Laya.Image;
            this.bgNormal = this.me.getChildByName("bg_normal") as Laya.Image;
            this.wordImage = this.me.getChildByName("word") as Laya.Image;
            this.scoreLabel = this.me.getChildByName("score") as Laya.Label;
        }

        public show(actionType: game.EMakaOperationType, score: number, isBest: boolean) {
            this.bgBest.visible = isBest;
            this.bgNormal.visible = !isBest;
            this.wordImage.skin = game.MakaManager.getOperationImg(actionType, isBest);
            this.scoreLabel.text = score.toString();
            this.scoreLabel.visible = score > 0;
            this.scoreLabel.color = isBest ? "#4a443c" : "#deeeff";
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

        public move(x: number, y: number) {
            this.me.x = x;
            this.me.y = y;
        }
    }

    class CardTips extends UI_Component {
        private mineCard: Laya.Sprite;
        private mineWord: Laya.Image;
        private tips: CardTip[];
        /**
         * 最多有4个提示
         */
        private tipsMaxCount: number;
        public onCreate(): void {
            this.mineCard = this.me.getChildByName("mine") as Laya.Sprite;
            this.mineWord = this.mineCard.getChildByName("word") as Laya.Image
            this.tips = [];
            this.tipsMaxCount = 4;
            for (let i = 1; i < (this.tipsMaxCount + 1); i++) {
                let tip = new CardTip(this.me.getChildByName(`tip${i}`) as Laya.Sprite);
                this.tips.push(tip);
            }
        }


        public set minePosVisible(visible: boolean) {
            this.mineCard.visible = visible;
        }

        public set minePos(pos: Laya.Vector2) {
            this.mineCard.x = pos.x;
            this.mineCard.y = pos.y;
        }

        /**
         * null 显示图片我
         * true 显示我立直
         * false 显示我打
         */
        public set mineContent(isLichi: boolean | null) {
            let path = "myres/mjdesktop/maka/i.png";
            if (isLichi != null) {
                path = isLichi ? "myres/mjdesktop/maka/small_me_li.png" : "myres/mjdesktop/maka/small_me_da.png";
            }
            this.mineWord.skin = game.Tools.localUISrc(path);
        }

        /**
         * 
         * @param tipsData 
         * @param bestIndex 最佳操作的索引，-1表示出牌的操作里没有最佳操作 
         */
        public show(tipsData: game.MakaOperation[], bestIndex: number = -1) {

            for (let i = 0; i < this.tips.length; i++) {
                let tip = this.tips[i];
                if (tip) {
                    let data = tipsData[i];
                    if (!data) {
                        tip.hide();
                        continue;
                    }
                    tip.show(data.operationType, data.score, bestIndex == i);
                }

            }
        }

        public setPoses(poses: Laya.Vector2[]) {
            for (let i = 0; i < poses.length; i++) {
                let tip = this.tips[i];
                if (tip) {
                    tip.move(poses[i].x, poses[i].y);
                }
            }
        }

        public setPos(index: number, pos: Laya.Vector2) {
            let tip = this.tips[index];
            if (!tip) {
                return;
            }
            this.tips[index].move(pos.x, pos.y);
        }





    }

    /**
     * 推荐操作中的牌
     */
    class TipCard extends UI_Component {
        private bgNormal: Laya.Image;
        private bgBest: Laya.Image;
        private valueImage: Laya.Image;
        public onCreate(): void {
            this.bgNormal = this.me.getChildByName("bg_normal") as Laya.Image;
            this.bgBest = this.me.getChildByName("bg_best") as Laya.Image;
            this.valueImage = this.me.getChildByName("value") as Laya.Image;
        }

        public show(value: mjcore.MJPai, isBest: boolean) {

            this.bgNormal.visible = !isBest;
            this.bgBest.visible = isBest;

            let paiName = value.toString();
            let path: string = "myres/mjdesktop/pai/" + paiName + ".png";
            this.valueImage.skin = game.Tools.localUISrc(path);
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }
    }

    /**
     * 推荐操作含牌，如碰、杠、吃等
     */
    class CardOperationTip extends UI_Component {
        private titleImg: Laya.Image;
        private scoreLabel: Laya.Label;
        private cardsParent: Laya.Sprite;
        private tipCards: TipCard[];
        public onCreate(): void {
            this.titleImg = this.me.getChildByName("word") as Laya.Image;
            this.scoreLabel = this.me.getChildByName("score") as Laya.Label;
            this.cardsParent = this.me.getChildByName("cards") as Laya.Sprite;
            this.tipCards = [];
            for (let i = 1; i < 3; i++) {
                let tipCard = new TipCard(this.cardsParent.getChildByName(`card${i}`) as Laya.Sprite);
                this.tipCards.push(tipCard);
            }
        }

        public show(data: game.MakaOperation, isBest: boolean) {
            this.titleImg.skin = game.MakaManager.getOperationImg(data.operationType, isBest);
            this.scoreLabel.text = data.score > 0 ? data.score.toString() : "";
            this.scoreLabel.color = isBest ? "#4a443c" : "#deeeff";
            let visibleCard: Array<Laya.Sprite> = [];
            let spaces: Array<number> = [];
            for (let i = 0; i < this.tipCards.length; i++) {
                let tipCard = this.tipCards[i];
                let tile = data.tiles[i];
                if (tile) {
                    tipCard.show(tile, isBest);
                    visibleCard.push(tipCard.me);
                    spaces.push(10);
                } else {
                    tipCard.hide();
                }
            }
            game.Tools.sprite_align_center(visibleCard, 32, spaces)
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }
    }

    /**
     * 推荐操作中的文字提示，如跳过，胡等
     */
    class WordOperationTip extends UI_Component {
        private titleImg: Laya.Image;
        private scoreLabel: Laya.Label;

        public onCreate(): void {
            this.titleImg = this.me.getChildByName("word") as Laya.Image;
            this.scoreLabel = this.me.getChildByName("score") as Laya.Label;
        }

        public show(data: game.MakaOperation, isBest: boolean) {
            this.titleImg.skin = game.MakaManager.getOperationImg(data.operationType, isBest);
            this.scoreLabel.visible = data.score > 0;
            this.scoreLabel.color = isBest ? "#4a443c" : "#deeeff";
            if (data.score > 0) {
                this.scoreLabel.text = data.score.toString();
            }
            else {
                this.scoreLabel.text = "";
            }
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }
    }

    class OperationTip extends UI_Component {
        private bgNormal: Laya.Image;
        private bgBest: Laya.Image;
        private bgMine: Laya.Image;
        private mineImage: Laya.Image;
        private cardOperationTip: CardOperationTip;
        private wordOperationTip: WordOperationTip;

        public onCreate(): void {
            this.bgNormal = this.me.getChildByName("bg_normal") as Laya.Image;
            this.bgBest = this.me.getChildByName("bg_best") as Laya.Image;
            this.bgMine = this.me.getChildByName("bg_me") as Laya.Image;
            this.mineImage = this.me.getChildByName("mine") as Laya.Image;
            this.cardOperationTip = new CardOperationTip(this.me.getChildByName("op_card") as Laya.Sprite);
            this.wordOperationTip = new WordOperationTip(this.me.getChildByName("op_word") as Laya.Sprite);
        }

        public show(makaOperationData: game.MakaOperation, isBest: boolean, isMine: boolean = false) {
            //如果有牌的数据则显示牌的提示，否则显示文字提示
            if (makaOperationData.tiles) {
                this.cardOperationTip.show(makaOperationData, isBest);
                this.wordOperationTip.hide();
            } else {
                this.wordOperationTip.show(makaOperationData, isBest);
                this.cardOperationTip.hide();
            }
            let isAdd: boolean = makaOperationData.score <= 0;
            this.bgNormal.visible = !isBest && !isAdd;
            this.bgBest.visible = isBest && !isAdd;
            this.bgMine.visible = isMine && isAdd;
            this.mineImage.visible = isMine;
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }



    }

    class OperationTips extends UI_Component {
        private tips: OperationTip[];
        public onCreate(): void {
            this.tips = [];
            for (let i = 1; i < 5; i++) {
                let tip = new OperationTip(this.me.getChildByName(`tip${i}`) as Laya.Sprite);
                this.tips.push(tip);
            }
        }

        /**
         * 
         * @param tipsData 操作数据
         * @param bestIndex 最优推荐
         * @param mineIndex 和我的操作相符的推荐
         */
        public show(tipsData: game.MakaOperation[], bestIndex: number = -1, mineIndex: number = -1) {
            for (let i = 0; i < this.tips.length; i++) {
                let tip = this.tips[i];
                let data = tipsData[i];
                if (!data) {
                    tip.hide();
                    continue;
                }
                tip.show(data, bestIndex == i, mineIndex == i);
            }
            this.visible = true;
        }

        public hide() {
            this.visible = false;
        }

    }

    class DifferentJumpBtn extends UI_Component {
        private bg: Laya.Image;
        private titleBg: Laya.Image;
        private title: Laya.Label;
        private isNext: boolean = false;
        private btn: Laya.Button;

        public onCreate(): void {
            this.bg = this.me.getChildByName("bg") as Laya.Image;
            this.titleBg = this.me.getChildByName("title_bg") as Laya.Image;
            this.title = this.me.getChildByName("title") as Laya.Label;
            this.title.fontSize = GameMgr.client_language == "en" ? 18 : 20;
            this.titleBg.width = this.title.trueWidth + 14;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.isGrayed = false;
        }

        public set isGrayed(grayed: boolean) {
            let bgPath = "";
            let titleBgPath = grayed ? "myres/mjdesktop/maka/dark_text_bottom.png" : "myres/mjdesktop/maka/text_bottom.png";
            if (this.isNext) {
                bgPath = grayed ? "myres/mjdesktop/maka/lower_difference_dark.png" : "myres/mjdesktop/maka/lower_difference_bright.png";
            } else {
                bgPath = grayed ? "myres/mjdesktop/maka/upper_difference_dark.png" : "myres/mjdesktop/maka/upper_difference_bright.png";
            }
            this.bg.skin = game.Tools.localUISrc(bgPath);
            this.titleBg.skin = game.Tools.localUISrc(titleBgPath);
            this.btn.mouseEnabled = !grayed;

        }

        public set clickHandler(handler: Laya.Handler) {
            this.btn.clickHandler = handler;
        }

        public set isNextBtn(isNext: boolean) {
            this.isNext = isNext;
        }
    }

    export class UI_Maka_Info extends UI_Component {


        private makaBtn: MakaBtn;
        private mineScore: MineScore;
        private cardTips: CardTips;
        private operationTips: OperationTips;
        private currentUUID: string;
        private currentSeat: number;
        private makaData: game.MakaData;
        private showInfo: boolean = false;
        private currentRoundsData: Array<Round>;
        private currentMakaPlayerData: game.MakaPlayer;
        private currentCardTipsData: Array<game.MakaOperation>;
        private currentOperationTipsData: Array<game.MakaOperation>;
        private currentMineOperation: game.MakaOperation;
        private currentRoundIndex: number = 0;
        private currentXunIndex: number = 0;
        private currentActionIndex: number = 0;
        private lastDifBtn: DifferentJumpBtn;
        private nextDifBtn: DifferentJumpBtn;
        private showAnim: Laya.FrameAnimation;
        private hideAnim: Laya.FrameAnimation;
        private isLock: boolean = false;

        public set infoVisible(visible: boolean) {
            if (this.isLock) {
                return;
            }
            this.showInfo = visible;
            this.mineScore.visible = visible;
            // this.cardTips.visible = visible && this.needShowCardTips;
            // this.operationTips.visible = visible && this.needShowOperationTips;

            this.freshMakaBtnState();
            if (this.infoVisible && this.makaData) {
                this.showStep(this.currentRoundIndex, this.currentXunIndex, this.currentActionIndex);
                this.freshJumpDiffBtn();
                this.showAnim.play(0, false);
                this.isLock = true;
                this.lastDifBtn.visible = true;
                this.nextDifBtn.visible = true;
                Laya.timer.once(this.showAnim.count * this.showAnim.interval, this, () => {
                    this.isLock = false;
                })
            }
            else {
                this.hideAnim.play(0, false);
                this.isLock = true;
                Laya.timer.once(this.hideAnim.count * this.hideAnim.interval, this, () => {
                    this.isLock = false;
                    this.lastDifBtn.visible = false;
                    this.nextDifBtn.visible = false;
                })
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                this.cardTips.visible = false;
                this.operationTips.visible = false;
            }
        }

        public get infoVisible(): boolean {
            return this.showInfo;
        }


        public onCreate(): void {
            this.makaBtn = new MakaBtn(this.me.getChildByName("maka_btn") as Laya.Sprite);
            this.mineScore = new MineScore(this.me.getChildByName("mine_score") as Laya.Sprite);
            this.cardTips = new CardTips(this.me.getChildByName("card_tip") as Laya.Sprite);
            this.operationTips = new OperationTips(this.me.getChildByName("operation_tip") as Laya.Sprite);
            this.makaBtn.onClick = Laya.Handler.create(this, this.onClickMakaBtn, null, false);
            this.lastDifBtn = new DifferentJumpBtn(this.me.getChildByName("last_dif_btn") as Laya.Sprite);
            this.lastDifBtn.isNextBtn = false;
            this.nextDifBtn = new DifferentJumpBtn(this.me.getChildByName("next_dif_btn") as Laya.Sprite);
            this.nextDifBtn.isNextBtn = true;
            this.lastDifBtn.clickHandler = Laya.Handler.create(this, () => {
                let lastDif = this.getLastDifActionIndex(this.currentRoundIndex, this.currentActionIndex);
                if (lastDif.roundIndex >= 0) {
                    UI_Replay.Inst.jumpStep(lastDif.roundIndex, lastDif.actionIndex);
                }
            }, null, false);
            this.nextDifBtn.clickHandler = Laya.Handler.create(this, () => {
                let nextDif = this.getNextDifActionIndex(this.currentRoundIndex, this.currentActionIndex);
                if (nextDif.roundIndex >= 0) {
                    UI_Replay.Inst.jumpStep(nextDif.roundIndex, nextDif.actionIndex);
                }
            }, null, false);
            this.showAnim = (this.me.parent as ui.mj.replayUI).show;
            this.hideAnim = (this.me.parent as ui.mj.replayUI).hide;

        }

        public onEnable(): void {
            this.isLock = false;
            Laya.stage.on(EventCode.ON_FETCH_MAKA_DETAIL_COMPLETE, this, this.onMakaDataChange);
            Laya.stage.on(EventCode.ON_MAKA_ANALYSIS_LIST_CHANGE, this, this.onMakaDataChange);
            Laya.stage.on(EventCode.ON_MAKA_ANALYSIS_COMPLETE, this, this.onAnalysisComplete);
            Laya.stage.on(EventCode.ON_MAKA_ANALYSIS_WINDOW_CLOSE, this, this.showMakaInfo);
        }

        public onDisable(): void {
            Laya.stage.off(EventCode.ON_FETCH_MAKA_DETAIL_COMPLETE, this, this.onMakaDataChange);
            Laya.stage.off(EventCode.ON_MAKA_ANALYSIS_LIST_CHANGE, this, this.onMakaDataChange);
            Laya.stage.off(EventCode.ON_MAKA_ANALYSIS_COMPLETE, this, this.onAnalysisComplete);
            Laya.stage.off(EventCode.ON_MAKA_ANALYSIS_WINDOW_CLOSE, this, this.showMakaInfo);
            view.DesktopMgr.Inst.CloseMakaChiPengEffect();
            Laya.timer.clearAll(this);
        }

        public show(uuid: string): void {
            this.currentUUID = uuid;
            this.makaData = game.MakaManager.Inst.getMakaData(uuid);
            //重置属性
            this.showInfo = false;
            this.currentRoundsData = null;
            this.currentMakaPlayerData = null;
            this.currentCardTipsData = [];
            this.currentOperationTipsData = [];
            this.currentMineOperation = null;
            this.currentRoundIndex = 0;
            this.currentXunIndex = 0;
            this.currentActionIndex = 0;
            this.currentMineOperation = null;
            this.visible = true;
            this.freshMakaBtnState();

        }

        public setData(seat: number, rounds: Array<Round>) {
            this.currentSeat = seat;
            this.currentRoundsData = rounds;
            this.currentMakaPlayerData = game.MakaManager.Inst.setMakaPlayerData(this.currentUUID, this.currentSeat, rounds);
            this.freshJumpDiffBtn();
            // app.Log.log("Maka数据" + JSON.stringify(this.currentMakaPlayerData));
        }




        public hide(): void {
            this.visible = false;
        }

        /**
         * 展示指定recordIndex的推荐操作
         * @param recordIndex 
         */
        public showStep(roundIndex: number, xunIndex: number, actionIndex: number) {
            this.currentRoundIndex = roundIndex;
            this.currentXunIndex = xunIndex;
            this.currentActionIndex = actionIndex;
            if (!this.infoVisible) {
                return;
            }
            if (!this.currentRoundsData) {
                return;
            }
            this.freshJumpDiffBtn();
            //用于找maka数据的下标
            let currentAction = this.currentRoundsData[roundIndex].actions[actionIndex];
            let makaIndex = currentAction.allIndex;
            this.currentCardTipsData = [];
            this.currentOperationTipsData = [];
            this.currentMineOperation = null;

            if (!this.currentMakaPlayerData) {
                this.mineScore.visible = false;
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                return;
            }
            let makaRounds = this.currentMakaPlayerData.roundsData;
            this.mineScore.visible = true;
            this.mineScore.allMakaLevel = this.currentMakaPlayerData.rating;
            //该局的数据
            if (!makaRounds) {
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                return;
            }
            let currentRoundData = makaRounds[roundIndex];
            this.mineScore.juMakaLevel = currentRoundData.rating;

            //本局所有的巡数据
            let makaXuns = currentRoundData.xunData;
            if (!makaXuns) {
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                return;
            }
            //当前xun的数据
            let makaXun = makaXuns[xunIndex];
            if (!makaXun) {
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                return;
            }
            //当前的所有推荐操作
            let makaActions = makaXun.predicationDataDic;
            if (!makaActions) {
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                return;
            }

            let mineOperation = makaXun.mineOperationDic.get(makaIndex);
            if (!mineOperation) {
                this.cardTips.visible = false;
                this.operationTips.visible = false;
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
                app.Log.log("未获取到本人本次Maka数据")
                return;
            }

            let actions = makaActions.get(makaIndex);
            if (actions) {
                app.Log.log(`第${roundIndex}局，第${xunIndex + 1}巡，第${actionIndex}步，makaIndex:${makaIndex},推荐操作：${JSON.stringify(actions)},makaIndex:${makaIndex}，当前步骤数据${JSON.stringify(currentAction)}，当前手牌${JSON.stringify(this.currentRoundsData[roundIndex].tilesDic.get(actionIndex))}`);
                //展示推荐操作
                let bestIndexInCard = -1;
                let bestIndexInOperation = -1;
                let bestScore = -1;
                //我的操作，如果是-1则预测操作中没有我的操作
                let mineIndex = -1;
                this.currentMineOperation = mineOperation;
                //找到分数最高的操作，将操作分开，打和立直打是牌上的提示，其他的是操作的提示
                for (let index = 0; index < actions.operations.length; index++) {
                    const element = actions.operations[index];
                    if (element.operationType == game.EMakaOperationType.DA || element.operationType == game.EMakaOperationType.LICHIDA) {
                        this.currentCardTipsData.push(element);
                        if (element.score > bestScore) {
                            bestIndexInCard = this.currentCardTipsData.length - 1;
                            bestScore = element.score;
                        }
                    } else {
                        this.currentOperationTipsData.push(element);
                        if (element.score > bestScore) {
                            bestIndexInOperation = this.currentOperationTipsData.length - 1;
                            bestScore = element.score;
                        }
                    }
                }

                //显示牌的推荐
                this.cardTips.show(this.currentCardTipsData, bestIndexInCard);
                //显示我的操作
                if (this.currentMineOperation.operationType == game.EMakaOperationType.DA || this.currentMineOperation.operationType == game.EMakaOperationType.LICHIDA) {
                    // app.Log.log(`我当前的操作是打牌,牌是${game.Tools.getTileName(this.currentMineOperation.tiles[0])}`);
                    //我的操作是打牌
                    this.cardTips.minePosVisible = true;
                    if (this.currentMineOperation.tiles && this.currentMineOperation.tiles.length > 0) {
                        this.cardTips.minePos = this.getMinePaiPos(this.currentMineOperation.tiles[0]);
                    }
                    //如果我的操作不在推荐内，则显示为我打 我立
                    //如果我的操作这张牌既推荐打，也推荐立，则也显示我打，我立
                    let hasOperation: boolean = false;
                    let hasDa: boolean = false;
                    let hasLichi: boolean = false;
                    for (let index = 0; index < this.currentCardTipsData.length; index++) {
                        const element = this.currentCardTipsData[index];
                        let isSame = game.MakaManager.isSame(this.currentMineOperation, element);
                        if (isSame) {
                            hasOperation = true;
                        }
                        //如果推荐的这张牌和我操作的牌一致
                        if (element.operationType == game.EMakaOperationType.DA) {
                            if (element.tiles && element.tiles.length > 0) {
                                let tile = element.tiles[0];
                                if (mjcore.MJPai.isSame(tile, this.currentMineOperation.tiles[0],true)) {
                                    hasDa = true;
                                } 
                            }
                        }
                        if (element.operationType == game.EMakaOperationType.LICHIDA) {
                            if (element.tiles && element.tiles.length > 0) {
                                let tile = element.tiles[0];
                                if (mjcore.MJPai.isSame(tile, this.currentMineOperation.tiles[0],true)) {
                                    hasLichi = true;
                                }
                            }
                        }

                    }
                    if (!hasOperation || (hasDa && hasLichi)) {
                        this.cardTips.mineContent = this.currentMineOperation.operationType == game.EMakaOperationType.LICHIDA;
                    }
                    else {
                        this.cardTips.mineContent = null;
                    }
                } else {
                    //我的操作是吃，碰，杠，胡等
                    this.cardTips.minePosVisible = false;
                    let isForceSkip = false;
                    if (this.currentMineOperation.operationType == game.EMakaOperationType.SKIP) {
                        isForceSkip = this.isForceSkip(roundIndex, xunIndex, actionIndex, this.currentSeat);
                    }
                    if (!isForceSkip) {
                        //是操作提示，找到是我的那个操作的提示（操作一致，牌一致）,如果没有则在队列末尾加上我的操作
                        for (let index = 0; index < this.currentOperationTipsData.length; index++) {
                            const element = this.currentOperationTipsData[index];
                            let isSame = game.MakaManager.isSame(this.currentMineOperation, element);
                            if (isSame) {
                                mineIndex = index;
                            }

                        }


                        if (mineIndex == -1) {
                            this.currentOperationTipsData.push(this.currentMineOperation);
                            mineIndex = this.currentOperationTipsData.length - 1;
                        }
                    }
                }

                this.operationTips.show(this.currentOperationTipsData, bestIndexInOperation, mineIndex);
            }


            this.cardTips.visible = this.showInfo && this.needShowCardTips;
            this.operationTips.visible = this.showInfo && this.needShowOperationTips;
            //如果有操作推荐且上一步是别人打牌，则显示鸣牌特效
            if (this.showInfo && this.currentOperationTipsData.length > 0 && currentAction.name == view.ERecordType.DiscardTile) {
                view.DesktopMgr.Inst.ShowMakaChiPengEffect();
            } else {
                view.DesktopMgr.Inst.CloseMakaChiPengEffect();
            }
            if (this.showInfo && this.needShowCardTips) {
                this.setCardTipsPos();
                //让提示显示在牌的位置上
                Laya.timer.frameLoop(1, this, this.setCardTipsPos)
            } else {
                Laya.timer.clear(this, this.setCardTipsPos);
            }
            
        }

        private setCardTipsPos() {
            //同步推荐牌的位置
            if (this.currentCardTipsData.length > 0) {
                let poses: Laya.Vector3[] = [];
                let yOffestDic: basic.Dictionary<mjcore.MJPai, number> = new basic.Dictionary<mjcore.MJPai, number>();
                for (let i = 0; i < this.currentCardTipsData.length; i++) {
                    if (this.currentCardTipsData[i].tiles && this.currentCardTipsData[i].tiles.length > 0) {
                        let pai = this.currentCardTipsData[i].tiles[0];
                        let pos = this.getMakaPaiPos(pai);
                        if (yOffestDic.has(pai)) {
                            yOffestDic.set(pai, yOffestDic.get(pai) - 40);
                        } else {
                            yOffestDic.set(pai, 0);
                        }
                        pos.y += yOffestDic.get(pai);
                        poses.push(pos);
                    } else {
                        app.Log.log(`当前${this.currentRoundIndex}局,${this.currentXunIndex}巡,操作${this.currentActionIndex},没有牌的提示数据:${JSON.stringify(this.currentCardTipsData[i])}`);
                    }
                }
                this.cardTips.setPoses(poses);
            }
            if (this.currentMineOperation) {
                //同步我的操作牌的位置
                if (this.currentMineOperation.operationType == game.EMakaOperationType.DA || this.currentMineOperation.operationType == game.EMakaOperationType.LICHIDA) {
                    if (this.currentMineOperation.tiles && this.currentMineOperation.tiles.length > 0) {
                        this.cardTips.minePos = this.getMinePaiPos(this.currentMineOperation.tiles[0]);
                    }
                }
            } else {
                app.Log.log(`第${this.currentRoundIndex}局，第${this.currentXunIndex + 1}巡，第${this.currentActionIndex}步，本人数据未正常获取`);
                Laya.timer.clear(this, this.setCardTipsPos);

            }
            
        }

        private freshMakaBtnState() {
            if (game.MakaManager.Inst.isAnalysising(this.currentUUID)) {
                this.makaBtn.state = MakaBtnState.ANALYSISING;
                return;
            }
            if (!this.makaData) {
                this.makaBtn.state = MakaBtnState.NONE;
            } else {
                if (this.makaData.state == game.EMakaAnalysisState.NONE || this.makaData.state == game.EMakaAnalysisState.ANALYSIS_EXPIRED) {
                    this.makaBtn.state = MakaBtnState.NONE;
                } else {
                    this.makaBtn.state = this.showInfo ? MakaBtnState.ON : MakaBtnState.OFF;
                }
            }
        }


        private onClickMakaBtn() {
            //如果是维护模式，则不弹出分析界面
            if (game.MakaManager.Inst.isMaintain) {
                game.MaintainMgr.showMaintainTip();
                return;
            }
            if (!this.makaData) {
                UI_Maka_Analysis.Inst.show(UI_PaiPu.Inst.getPaipuData(this.currentUUID), true);
            } else {
                if (this.makaData.state == game.EMakaAnalysisState.NONE || this.makaData.state == game.EMakaAnalysisState.ANALYSIS_EXPIRED || this.makaData.state == game.EMakaAnalysisState.ANALYSISING) {
                    UI_Maka_Analysis.Inst.show(UI_PaiPu.Inst.getPaipuData(this.currentUUID), true);
                } else {
                    this.infoVisible = !this.showInfo;
                    this.freshMakaBtnState();
                }
            }
        }

        private onMakaDataChange(uuid: string) {
            if (uuid == this.currentUUID) {
                this.makaData = game.MakaManager.Inst.getMakaData(uuid);
                this.freshMakaBtnState();
            }
        }



        /**
         * 根据牌面数据获取牌的位置
         * @param pai 
         * @returns 
         */
        private getMakaPaiPos(pai: mjcore.MJPai): Laya.Vector3 {
            let pos = new Laya.Vector3();
            for (let i = view.DesktopMgr.Inst.mainrole.hand.length - 1; i >= 0; i--) {
                let hand = view.DesktopMgr.Inst.mainrole.hand[i];
                let handPai = hand.val;
                if (mjcore.MJPai.isSame(handPai, pai,true)) {
                    let pos = new Laya.Vector3();
                    game.Scene_MJ.Inst.camera_hand.worldToViewportPoint(hand.mySelf.transform.position, pos);
                    pos.x -= 50;
                    pos.y -= 100;
                    return pos;
                }
            }
            return pos;
        }

        private getMinePaiPos(pai: mjcore.MJPai): Laya.Vector3 {
            let pos = new Laya.Vector3();
            for (let i = view.DesktopMgr.Inst.mainrole.hand.length - 1; i >= 0; i--) {
                let hand = view.DesktopMgr.Inst.mainrole.hand[i];
                let handPai = hand.val;
                if (mjcore.MJPai.isSame(handPai, pai,true)) {
                    game.Scene_MJ.Inst.camera_hand.worldToViewportPoint(hand.mySelf.transform.position, pos);
                    pos.x -= 50;
                    pos.y += 35;
                    return pos;
                }
            }
            return pos;
        }


        /**
         * 如果在牌谱内分析完毕，则要请求分析数据
         * @param uuid 
         */
        private onAnalysisComplete(uuid: string) {
            //只有在分析界面未打开时才请求
            if (uuid == this.currentUUID && !UI_Maka_Analysis.Inst.enable) {
                game.MakaManager.Inst.fetchAnalysisData(this.currentUUID, Laya.Handler.create(this, (err, res) => {


                }));
            }
        }

        /**
         * 获取下一个和Maka推荐不同的操作
         * @param currentRoundIndex 
         * @param xunIndex 
         * @param currentActionIndex 
         */
        private getNextDifActionIndex(currentRoundIndex: number, currentActionIndex: number): { roundIndex: number, actionIndex: number } {
            if (!this.currentRoundsData) {
                return { roundIndex: -1, actionIndex: -1 };
            }
            //获取下个ActionIndex,如果跨回合了，回合要+1
            let acitons = this.currentRoundsData[currentRoundIndex].actions;
            let nextActionIndex = currentActionIndex + 1;
            let nextRoundIndex = currentRoundIndex;
            if (acitons.length <= nextActionIndex) {
                nextRoundIndex = currentRoundIndex + 1;
                if (nextRoundIndex >= this.currentRoundsData.length) {
                    return { roundIndex: -1, actionIndex: -1 };
                } else {
                    nextActionIndex = 0;
                }
            }
            //根据这个index获取Maka信息
            let nextAction = this.currentRoundsData[nextRoundIndex].actions[nextActionIndex];
            //下一个操作所在巡的Index
            let nextXunIndex = UI_Replay.Inst.getXunIndex(nextRoundIndex, nextActionIndex);
            //获取对应操作的推荐操作
            let makaOperations = game.MakaManager.Inst.getMakaPredication(this.currentUUID, this.currentSeat, nextRoundIndex, nextXunIndex, nextAction.allIndex);
            //如果没有推荐操作，则继续找下一个
            if (!makaOperations || makaOperations.operations.length == 0 || makaOperations.isSame) {
                return this.getNextDifActionIndex(nextRoundIndex, nextActionIndex);
            }
            return { roundIndex: nextRoundIndex, actionIndex: nextActionIndex };
        }

        /**
        * 获取上一个和Maka推荐不同的操作
        * @param currentRoundIndex 
        * @param xunIndex 
        * @param currentActionIndex 
        */
        private getLastDifActionIndex(currentRoundIndex: number, currentActionIndex: number): { roundIndex: number, actionIndex: number } {
            //获取下个ActionIndex,如果跨回合了，回合要+1
            if (!this.currentRoundsData) {
                return { roundIndex: -1, actionIndex: -1 };
            }

            let lastActionIndex = currentActionIndex - 1;
            let lastRoundIndex = currentRoundIndex;
            if (lastActionIndex < 0) {
                lastRoundIndex = currentRoundIndex - 1;
                if (lastRoundIndex < 0) {
                    return { roundIndex: -1, actionIndex: -1 };
                } else {
                    lastActionIndex = this.currentRoundsData[lastRoundIndex].actions.length - 1;
                }
            }
            //根据这个index获取Maka信息
            let lastAction = this.currentRoundsData[lastRoundIndex].actions[lastActionIndex];
            //上一个操作所在巡的Index
            let lastXunIndex = UI_Replay.Inst.getXunIndex(lastRoundIndex, lastActionIndex);
            //获取对应操作的推荐操作
            let makaOperations = game.MakaManager.Inst.getMakaPredication(this.currentUUID, this.currentSeat, lastRoundIndex, lastXunIndex, lastAction.allIndex);
            //如果没有推荐操作，则继续找下一个
            if (!makaOperations || makaOperations.operations.length == 0 || makaOperations.isSame) {
                return this.getLastDifActionIndex(lastRoundIndex, lastActionIndex);
            }
            return { roundIndex: lastRoundIndex, actionIndex: lastActionIndex };
        }

        private freshJumpDiffBtn() {
            let lastDif = this.getLastDifActionIndex(this.currentRoundIndex, this.currentActionIndex);
            let nextDif = this.getNextDifActionIndex(this.currentRoundIndex, this.currentActionIndex);
            this.lastDifBtn.isGrayed = lastDif.roundIndex < 0;
            this.nextDifBtn.isGrayed = nextDif.roundIndex < 0;
        }


        /**
         * 判断是否是强制跳过
         * 1.如果下一步是其他人和牌，且我没有和牌的预测，则是强制跳过
         * 2.如果下一步是其他人的碰，杠，且我没有和牌的预测，则是强制跳过
         */
        private isForceSkip(roundIndex: number, xunIndex: number, actionIndex: number, seat: number): boolean {
            let isForceSkip = false;
            let nextOperation = this.currentRoundsData[roundIndex].actions[actionIndex + 1];
            let currentAction = this.currentRoundsData[roundIndex].actions[actionIndex];
            let prediction = game.MakaManager.Inst.getMakaPredication(this.currentUUID, seat, roundIndex, xunIndex, currentAction.allIndex);
            let hasPreditionHu = false;
            for (let i = 0; i < prediction.operations.length; i++) {
                if (prediction.operations[i].operationType == game.EMakaOperationType.HU) {
                    hasPreditionHu = true;
                    break;
                }
            }
            if (nextOperation) {
                if (nextOperation.name == view.ERecordType.Hu) {
                    let huleData = nextOperation.data as game.IRecordHule;
                    let hulePlayers = huleData.hules;
                    let isMeHule = false;
                    for (let i = 0; i < hulePlayers.length; i++) {
                        if (hulePlayers[i].seat == seat) {
                            isMeHule = true;
                            break;
                        }
                    }
                    if (!isMeHule && !hasPreditionHu) {
                        isForceSkip = true;
                    }

                } else if (nextOperation.name == view.ERecordType.ChiPengGang) {
                    //如果是别人的碰杠，且我没有和牌的预测，则是强制跳过
                    let chiPengData = nextOperation.data as game.IRecordChiPengGang;
                    //如果数据里是顺子，则是吃
                    if (chiPengData.type != mjcore.E_Ming.shunzi) {
                        if (chiPengData.seat != seat && !hasPreditionHu) {
                            isForceSkip = true;
                        }
                    }
                }
            }
            return isForceSkip;
        }


        public get needShowCardTips(): boolean {
            if (!this.currentMineOperation && (!this.currentCardTipsData || this.currentCardTipsData.length == 0)) {
                return false;
            }
            let isDa = this.currentMineOperation.operationType == game.EMakaOperationType.DA || this.currentMineOperation.operationType == game.EMakaOperationType.LICHIDA;
            let hasData = this.currentCardTipsData && this.currentCardTipsData.length > 0;
            return isDa || hasData;
        }

        public get needShowOperationTips(): boolean {
            if (!this.currentMineOperation && (!this.currentOperationTipsData || this.currentOperationTipsData.length == 0)) {
                return false;
            }
            let isDa = this.currentMineOperation.operationType == game.EMakaOperationType.DA || this.currentMineOperation.operationType == game.EMakaOperationType.LICHIDA;
            let hasData = this.currentOperationTipsData && this.currentOperationTipsData.length > 0;
            return !isDa || hasData;
        }

        public showMakaInfo() {
            //如果是维护模式，则不弹出分析界面
            if (game.MakaManager.Inst.isMaintain) {
                return;
            }
            if (!this.makaData) {
                return;
            }
            if (this.makaData.state == game.EMakaAnalysisState.NONE || this.makaData.state == game.EMakaAnalysisState.ANALYSIS_EXPIRED || this.makaData.state == game.EMakaAnalysisState.ANALYSISING) {
                return;
            }
            this.infoVisible = true;
            this.freshMakaBtnState();
           
        }



    }
}