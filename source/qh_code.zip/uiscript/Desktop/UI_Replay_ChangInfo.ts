module uiscript {

    enum UI_ChangInfo_LineType {
        DEFAULT = 0,
        LIUJU = 1,
        RONG = 2,
        ZIMO = 3,
        FANGCHONG = 4,
        SEPERATE1 = 5,
        SEPERATE2 = 6
    }

    interface Action {
        name: string;
        data: Object;
    }

    interface Round {
        roundIndex: number;
        xun: Array<number>;
        actions: Array<Action>;
    }

    interface PlayerListData {
        name: string;
        score: number;
        tile: mjcore.E_Dadian_Title;
        handInfo: UI_MJPai_HandInfo;
        doraInfo: UI_MJPai_DoraInfo;
        liDoraInfo: UI_MJPai_LiDoraInfo;
        isZimo: boolean;
        isRemarks: boolean;
    }

    class LineBase extends UI_Component {

        public get typeId(): UI_ChangInfo_LineType {
            return UI_ChangInfo_LineType.DEFAULT;
        }

        public set height(value: number) {
            this.me.height = value;
        }

        public get height(): number {
            return this.me.height;
        }

    }

    class Line_LiuJu extends LineBase {

        public get typeId(): number {
            return UI_ChangInfo_LineType.LIUJU;
        }
        private titleLabel: Laya.Label;
        private playerParent: Laya.Sprite;
        private players: Array<ListItem_Player>;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("title") as Laya.Label;
            this.playerParent = this.me.getChildByName("players") as Laya.Sprite;
            this.players = new Array<ListItem_Player>();
            for (let i = 0; i < 4; i++) {
                let player = this.playerParent.getChildByName("player" + i) as Laya.Sprite;
                this.players.push(new ListItem_Player(player));
            }
        }

        public set title(value: string) {
            this.titleLabel.text = value;

        }

        public set titleColor(value: string) {
            this.titleLabel.color = value;
        }

        public showPlayers(players: Array<PlayerListData>) {
            for (let i = 0; i < 4; i++) {

                let playerData = players[i];
                let player = this.players[i];
                if (i < players.length) {
                    player.name = playerData.name;
                    player.score = playerData.score;
                    player.tilePath = playerData.tile == mjcore.E_Dadian_Title.E_Dadian_Title_none ? "" : "myres/lobby/tile_" + playerData.tile + ".png";
                    player.dora = playerData.doraInfo;
                    player.liDora = playerData.liDoraInfo;
                    player.hand = playerData.handInfo;
                    player.isRemarks = playerData.isRemarks;
                    player.visible = true;
                } else {
                    player.visible = false;
                }
            }
            let addPlayerCount = players.length - 1;
            if (addPlayerCount < 0) {
                addPlayerCount = 0;
            }
            this.height = 50 + 60 * addPlayerCount;
        }

    }

    class Line_Rong extends LineBase {

        public get typeId(): number {
            return UI_ChangInfo_LineType.RONG;
        }
        private titleLabel: Laya.Label;
        private playerParent: Laya.Sprite;
        private players: Array<ListItem_Player>;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("title") as Laya.Label;
            this.playerParent = this.me.getChildByName("players") as Laya.Sprite;
            this.players = new Array<ListItem_Player>();
            for (let i = 0; i < 4; i++) {
                let player = this.playerParent.getChildByName("player" + i) as Laya.Sprite;
                this.players.push(new ListItem_Player(player));
            }
        }

        public set title(value: string) {
            this.titleLabel.text = value;
        }

        public showPlayers(players: Array<PlayerListData>) {
            for (let i = 0; i < 4; i++) {

                let playerData = players[i];
                let player = this.players[i];
                if (i < players.length) {
                    player.name = playerData.name;
                    player.score = playerData.score;
                    player.tilePath = playerData.tile == mjcore.E_Dadian_Title.E_Dadian_Title_none ? "" : "myres/lobby/tile_" + playerData.tile + ".png";
                    player.dora = playerData.doraInfo;
                    player.liDora = playerData.liDoraInfo;
                    player.hand = playerData.handInfo;
                    player.isRemarks = playerData.isRemarks;
                    player.visible = true;
                } else {
                    player.visible = false;
                }
            }
            let addPlayerCount = players.length - 1;
            if (addPlayerCount < 0) {
                addPlayerCount = 0;
            }
            this.height = 50 + 60 * addPlayerCount;
        }


    }


    class Line_Zimo extends LineBase {
        public get typeId(): number {
            return UI_ChangInfo_LineType.ZIMO;
        }
        private titleLabel: Laya.Label;
        private playerParent: Laya.Sprite;
        private players: Array<ListItem_Player>;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("title") as Laya.Label;
            this.playerParent = this.me.getChildByName("players") as Laya.Sprite;
            this.players = new Array<ListItem_Player>();
            for (let i = 0; i < 4; i++) {
                let player = this.playerParent.getChildByName("player" + i) as Laya.Sprite;
                this.players.push(new ListItem_Player(player));
            }
        }

        public set title(value: string) {
            this.titleLabel.text = value;
        }
        public showPlayers(players: Array<PlayerListData>) {
            for (let i = 0; i < 4; i++) {
                let playerData = players[i];
                let player = this.players[i];
                if (i < players.length) {

                    player.name = playerData.name;
                    player.score = playerData.score;
                    player.tilePath = playerData.tile == mjcore.E_Dadian_Title.E_Dadian_Title_none ? "" : "myres/lobby/tile_" + playerData.tile + ".png";
                    player.dora = playerData.doraInfo;
                    player.liDora = playerData.liDoraInfo;
                    player.hand = playerData.handInfo;
                    player.isRemarks = playerData.isRemarks;
                    player.visible = true;
                } else {
                    player.visible = false;
                }
            }
            let addPlayerCount = players.length - 1;
            if (addPlayerCount < 0) {
                addPlayerCount = 0;
            }
            this.height = 50 + 60 * addPlayerCount;
        }

    }

    class Line_FangChong extends LineBase {
        public get typeId(): number {
            return UI_ChangInfo_LineType.FANGCHONG;
        }
        private titleLabel: Laya.Label;
        private playerParent: Laya.Sprite;
        private players: Array<ListItem_Player>;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("title") as Laya.Label;
            this.playerParent = this.me.getChildByName("players") as Laya.Sprite;
            this.players = new Array<ListItem_Player>();
            for (let i = 0; i < 4; i++) {
                let player = this.playerParent.getChildByName("player" + i) as Laya.Sprite;
                this.players.push(new ListItem_Player(player));
            }
        }

        public set title(value: string) {
            this.titleLabel.text = value;
        }

        public showPlayers(players: Array<PlayerListData>) {
            for (let i = 0; i < 4; i++) {

                let playerData = players[i];
                let player = this.players[i];
                if (i < players.length) {
                    if (!playerData.isZimo) {
                        player.name = playerData.name;
                        player.score = playerData.score;
                        player.tilePath = playerData.tile == mjcore.E_Dadian_Title.E_Dadian_Title_none ? "" : "myres/lobby/tile_" + playerData.tile + ".png";
                        player.isRemarks = playerData.isRemarks;
                    }
                    else {
                        player.name = null;
                        player.score = null;
                        player.tilePath = null;
                    }

                    player.dora = playerData.doraInfo;
                    player.liDora = playerData.liDoraInfo;
                    player.hand = null;
                    player.visible = true;
                } else {
                    player.visible = false;
                }
            }
            let addPlayerCount = players.length - 1;
            if (addPlayerCount < 0) {
                addPlayerCount = 0;
            }
            this.height = 50 + 60 * addPlayerCount;
        }
    }

    class Line_Seperate1 extends LineBase {
        public get typeId(): number {
            return UI_ChangInfo_LineType.SEPERATE1;
        }
    }

    class Line_Seperate2 extends LineBase {
        public get typeId(): number {
            return UI_ChangInfo_LineType.SEPERATE2;
        }
    }

    class ListItem_Player_Dora extends UI_Component {
        private oneCardWidth: number = 30;
        private cardSpace: number = 10;
        private startWidth: number = 102;
        private titleStartWidth: number = 48;
        private titleLabel: Laya.Label;
        private cardParent: Laya.Box;
        private doraComp: UI_MJPai_Dora;
        private bg: Laya.Image;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("name") as Laya.Label;
            this.cardParent = this.me.getChildByName("cards") as Laya.Box;
            this.doraComp = new UI_MJPai_Dora(this.cardParent);
            this.bg = this.me.getChildByName("bg") as Laya.Image;
        }

        public show(info: UI_MJPai_DoraInfo) {
            this.visible = true;
            //把info所有的透明牌信息移除,t->''
            for (let i = 0; i < info.doras.length; i++) {
                let skin = info.doras[i];
                skin = skin.replace('t', '');
                info.doras[i] = skin;
            }
            this.doraComp.show(info, true);
            //根据宝牌数量调整宽度和位置
            let doraCount = info.doras.length;
            let cardsWidth = this.oneCardWidth * doraCount + (doraCount - 1) * this.cardSpace;
            this.cardParent.width = cardsWidth;
            let cardDeltaWidth = cardsWidth - this.oneCardWidth;
            let nameDeltaWidth = this.titleLabel.trueWidth - this.titleStartWidth;
            this.me.width = this.startWidth + cardDeltaWidth + nameDeltaWidth;
            this.bg.width = this.me.width;
            this.bg.x = this.me.width;
            
            // console.log("设置标题位置", this.cardParent.x, this.cardParent.width,info.doras);
            Laya.timer.frameOnce(2, this, () => { 
                this.titleLabel.x = this.cardParent.x - this.cardParent.width - 5;
            })
            
            
        }

        public hide() {
            this.visible = false;
        }
    }

    class ListItem_Player_LiDora extends UI_Component {
        private oneCardWidth: number = 30;
        private cardSpace: number = 10;
        private startWidth: number = 102;
        private titleStartWidth: number = 48;
        private titleLabel: Laya.Label;
        private cardParent: Laya.Sprite;
        private doraComp: UI_MJPai_LiDora;
        private bg: Laya.Image;
        public onCreate(): void {
            this.titleLabel = this.me.getChildByName("name") as Laya.Label;
            this.cardParent = this.me.getChildByName("cards") as Laya.Sprite;
            this.doraComp = new UI_MJPai_LiDora(this.cardParent);
            this.bg = this.me.getChildByName("bg") as Laya.Image;
        }

        public show(info: UI_MJPai_LiDoraInfo) {
            this.visible = true;
            //把info所有的透明牌信息移除,t->''
            for (let i = 0; i < info.lidoras.length; i++) {
                let skin = info.lidoras[i];
                skin = skin.replace('t', '');
                info.lidoras[i] = skin;
            }
           

            this.doraComp.show(info,true);
            //根据宝牌数量调整宽度和位置
            let doraCount = info.lidoras.length;
            let cardsWidth = this.oneCardWidth * doraCount + (doraCount - 1) * this.cardSpace;
            this.cardParent.width = cardsWidth;
            let cardDeltaWidth = cardsWidth - this.oneCardWidth;
            let nameDeltaWidth =  this.titleLabel.trueWidth - this.titleStartWidth;
            this.me.width = this.startWidth + cardDeltaWidth + nameDeltaWidth;
            this.bg.width = this.me.width;
            this.bg.x = this.me.width;
            Laya.timer.frameOnce(2, this, () => {
                this.titleLabel.x = this.cardParent.x - this.cardParent.width - 5;
            })
        }

        public hide() {
            this.visible = false;
        }
    }

    class ListItem_Player extends UI_Component {
        private nameLabel: Laya.Label;
        private scoreLabel: Laya.Label;
        private tileImg: Laya.Image;
        private handSprite: Laya.Sprite;
        private handComp: UI_MJPai_Hand;
        private doraSprite: Laya.Sprite;
        private doraComp: ListItem_Player_Dora;
        private liDoraSprite: Laya.Sprite;
        private liDoraComp: ListItem_Player_LiDora;
        private doraStartPosX: number = 998;
        private originNameColor: string;
        public onCreate(): void {

            this.nameLabel = this.me.getChildByName("name") as Laya.Label;
            this.originNameColor = this.nameLabel.color;
            this.scoreLabel = this.me.getChildByName("point") as Laya.Label;
            this.tileImg = this.me.getChildByName("tile") as Laya.Image;
            this.handSprite = this.me.getChildByName("container_hand") as Laya.Sprite;
            this.doraSprite = this.me.getChildByName("container_dora") as Laya.Sprite;
            this.liDoraSprite = this.me.getChildByName("container_lidora") as Laya.Sprite;
            if (this.handSprite) {
                this.handComp = new UI_MJPai_Hand(this.handSprite);
                this.handComp.baseWidth = this.handComp.me.width;
            }
            if (this.doraSprite) {

                this.doraComp = new ListItem_Player_Dora(this.doraSprite);
            }
            if (this.liDoraSprite) {

                this.liDoraComp = new ListItem_Player_LiDora(this.liDoraSprite);
            }

        }


        public set tilePath(value: string | null) {
            if (value == null) {
                this.tileImg.skin = "";
                return
            }
            this.tileImg.skin = game.Tools.localUISrc(value);
        }

        public set score(value: number | null) {
            if (value == null) {
                this.scoreLabel.text = "";
                return;
            }
            this.scoreLabel.text = (value >= 0 ? "+" : "") + value.toString();
        }

        public set name(value: string | null) {
            if (value == null) {
                this.nameLabel.text = "";
                return;
            }
            this.nameLabel.text = value;
        }

        public set hand(info: UI_MJPai_HandInfo) {
            if (this.handSprite && this.handComp) {
                if (info == null) {
                    this.handSprite.visible = false;

                }
                else {
                    this.handSprite.visible = true;
                    this.handComp.show(info,false);
                }

            }

        }

        public set dora(info: UI_MJPai_DoraInfo) {
            if (this.doraSprite && this.doraComp) {
                if (info == null || !info.doras || info.doras.length == 0) {
                    // this.doraSprite.visible = false;
                    this.doraComp.hide();
                }
                else {
                    // this.doraSprite.visible = true;
                    this.doraComp.show(info);
                    this.doraComp.me.x = this.doraStartPosX;

                }
            }

        }

        public set liDora(info: UI_MJPai_LiDoraInfo) {
            if (this.liDoraSprite && this.liDoraComp) {
                if (info == null || !info.lidoras || info.lidoras.length == 0) {
                    this.liDoraComp.hide();
                }
                else {
                    this.liDoraComp.show(info);
                    //里宝牌的位置是宝牌的位置+10，如果显示的话
                    if (this.doraSprite.visible) {
                        this.liDoraSprite.x = this.doraSprite.x - this.doraSprite.width - 10;
                    }
                    else {
                        this.liDoraSprite.x = this.doraStartPosX;
                    }
                }
            }

        }

        public set isRemarks(v: boolean) {
            this.nameLabel.color = v ? '#c3e2ff' : this.originNameColor;
        }
    }



    class UI_Replay_ChangInfo_ListItem extends UI_Component {
        protected roundData: Round;
        protected bg: Laya.Image;
        protected titleChang: Laya.Label;
        protected titleJu: Laya.Label;
        protected titleW: Laya.Label;
        protected titleBen: Laya.Label;
        protected titleBenchang: Laya.Label;
        protected lineLiuJuTemp: Laya.Sprite;
        protected lineRongTemp: Laya.Sprite;
        protected lineZimoTemp: Laya.Sprite;
        protected lineFangChongTemp: Laya.Sprite;
        protected lineSeperate1Temp: Laya.Sprite;
        protected lineSeperate2Temp: Laya.Sprite;
        protected info: Laya.Sprite;
        protected showLines: Array<LineBase> = [];
        protected btn: Laya.Button;
        protected makaLevelImg: Laya.Image;

        public onCreate(): void {
            this.btn = this.me as Laya.Button;
        }

        public show(round: Round,isShowMaka:boolean = false) {
            this.roundData = round;
        }

        public get height(): number {
            return this.me.height;
        }

        public set height(value: number) {
            this.me.height = value;
            this.bg.height = value;
        }

        public set clickHandler(handler: Laya.Handler) {
            this.btn.clickHandler = new Laya.Handler(this, () => {
                handler?.run();
            });
        }

        /**
         * 回收所有行
         */
        protected clearLines() {                 
            for (let i = 0; i < this.showLines.length; i++) {
                this.recycleLine(this.showLines[i]);
            }
            this.showLines = [];
            
        }



        protected createLine_LiuJu(): Line_LiuJu {
            let line = this.lineLiuJuTemp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineLiuJu = new Line_LiuJu(line);
            this.linePool.push(lineLiuJu);
            return lineLiuJu;
        }

        protected createLine_Rong(): Line_Rong {
            let line = this.lineRongTemp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineRong = new Line_Rong(line);
            this.linePool.push(lineRong);
            return lineRong;
        }

        protected createLine_Zimo(): Line_Zimo {
            let line = this.lineZimoTemp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineZimo = new Line_Zimo(line);
            this.linePool.push(lineZimo);
            return lineZimo;
        }

        protected createLine_FangChong(): Line_FangChong {
            let line = this.lineFangChongTemp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineFangChong = new Line_FangChong(line);
            this.linePool.push(lineFangChong);
            return lineFangChong;
        }

        protected createLine_Seperate1(): Line_Seperate1 {
            let line = this.lineSeperate1Temp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineSeperate1 = new Line_Seperate1(line);
            this.linePool.push(lineSeperate1);
            return lineSeperate1;
        }

        protected createLine_Seperate2(): Line_Seperate2 {
            let line = this.lineSeperate2Temp.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
            this.info.addChild(line);
            let lineSeperate2 = new Line_Seperate2(line);
            this.linePool.push(lineSeperate2);
            return lineSeperate2;
        }

        /**
         * 用池来管理行，避免频繁创建销毁
         */
        protected linePool: Array<LineBase> = [];
        protected getLine(typeId: UI_ChangInfo_LineType): LineBase {
            let line: LineBase = this.linePool.find((line) => {
                return line.typeId == typeId;
            });
            if (line == null) {
               line = this.generateLine(typeId);
            }
            game.Tools.removeFromArray(this.linePool, line);
            line.visible = true;
            this.showLines.push(line);
            return line;
        }

        protected generateLine(typeId: UI_ChangInfo_LineType): LineBase {
            let line: LineBase = null;
            switch (typeId) {
                case UI_ChangInfo_LineType.LIUJU:
                    line= this.createLine_LiuJu()
                    break;
                case UI_ChangInfo_LineType.RONG:
                    line =this.createLine_Rong();
                    break;
                case UI_ChangInfo_LineType.ZIMO:
                    line =this.createLine_Zimo();
                    break;
                case UI_ChangInfo_LineType.FANGCHONG:
                    line =this.createLine_FangChong();
                    break;
                case UI_ChangInfo_LineType.SEPERATE1:
                    line =this.createLine_Seperate1();
                    break;
                case UI_ChangInfo_LineType.SEPERATE2:
                    line =this.createLine_Seperate2();
                    break;
                default:
                    break;
            }
            return line;
        }

        /**
         * 回收行
         */
        protected recycleLine(line: LineBase) {
            line.visible = false;
            this.linePool.push(line);
        }
    }

    class UI_Replay_ChangInfo_ListItem_Big extends UI_Replay_ChangInfo_ListItem {


        // protected roundData: Round;
        private normalSpans: Array<number> = [3, 3, 50, 3, 0];
        private startHeight: number = 150;
        private lineBaseHeight: number = 50;
        public get height(): number {
            return this.me.height;
        }

        public set height(value: number) {
            this.me.height = value;
            this.bg.height = value;
        }
        public onCreate(): void {
            super.onCreate();
            this.bg = this.me.getChildByName("bg") as Laya.Image;
            let containerTitle = this.me.getChildByName("container_title") as Laya.Sprite;
            this.titleChang = containerTitle.getChildByName("chang") as Laya.Label;
            this.titleJu = containerTitle.getChildByName("ju") as Laya.Label;
            this.titleW = containerTitle.getChildByName("w") as Laya.Label;
            this.titleBen = containerTitle.getChildByName("ben") as Laya.Label;
            this.titleBenchang = containerTitle.getChildByName("benchang") as Laya.Label;
            this.info = this.me.getChildByName("info") as Laya.Sprite;
            this.lineLiuJuTemp = this.info.getChildByName("line_liuju") as Laya.Sprite;
            this.lineRongTemp = this.info.getChildByName("line_rong") as Laya.Sprite;
            this.lineZimoTemp = this.info.getChildByName("line_zimo") as Laya.Sprite;
            this.lineFangChongTemp = this.info.getChildByName("line_fangchong") as Laya.Sprite;
            this.lineSeperate1Temp = this.info.getChildByName("line_seperate1") as Laya.Sprite;
            this.lineSeperate2Temp = this.info.getChildByName("line_seperate2") as Laya.Sprite;
            this.lineLiuJuTemp.visible = false;
            this.lineRongTemp.visible = false;
            this.lineZimoTemp.visible = false;
            this.lineFangChongTemp.visible = false;
            this.lineSeperate1Temp.visible = false;
            this.lineSeperate2Temp.visible = false;
            if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
                this.titleChang.y = 29;
                this.titleJu.y = 28;
                this.titleW.y = 29;
                this.titleBen.y = 28;
                this.titleBenchang.y = 29;
            }
            this.makaLevelImg = this.me.getChildByName("maka_level") as Laya.Image;

        }

        public show(round: Round,isShowMaka:boolean = false) {
            this.roundData = round;
            this.renderTitle();
            this.renderInfo();
            this.renderMakaInfo(isShowMaka);
        }

        private renderTitle() {
            for (let i: number = 0; i < this.roundData.actions.length; i++) {
                let action = this.roundData.actions[i];
                //找到对应的数据,"RecordNewRound"只有这个数据里有场次标题信息

                if (this.roundData.actions[i].name == 'RecordNewRound') {
                    //川麻标题是第n局
                    if (view.DesktopMgr.Inst.is_chuanma_mode()) {
                        this.titleBen.visible = false;
                        this.titleBenchang.visible = false;
                        let s_round = '';
                        if (GameMgr.client_language == 'en') {
                            s_round = 'Round';
                        }
                        else if (GameMgr.client_language == 'kr') {
                            s_round = '제';
                        }
                        else {
                            s_round = '第';
                        }
                        this.titleChang.text = s_round;
                        this.titleJu.text = (action.data['ju_count'] + 1).toString();
                        //让这几个文本居中
                        let texts = [this.titleChang, this.titleJu, this.titleW];
                        game.Tools.sprite_align_center(texts, 600);
                    } else {
                        //非川麻
                        this.titleBen.visible = true;
                        this.titleBenchang.visible = true;
                        this.titleChang.text = UI_Replay_ChangInfo.seatStr(action.data['chang'] % 4);
                        this.titleJu.text = (action.data['ju'] + 1).toString();
                        this.titleBen.text = action.data['ben'].toString();
                        //居中文本
                        let texts = [this.titleChang, this.titleJu, this.titleW, this.titleBen, this.titleBenchang];
                        game.Tools.sprite_align_center(texts, 600, this.normalSpans);
                    }
                }
            }

        }

        private renderInfo() {
            let actions = this.roundData.actions;
            // app.Log.log("对局信息刷新(大)" + JSON.stringify(this.roundData));
            //判断本轮是否结束，如果未结束，则显示进行中
            let finalAction: Action = actions[actions.length - 1];
            if (!UI_Replay_ChangInfo.isRoundEnd(finalAction.name)) {
                this.showRunning();
                return;
            }
            //川麻的特殊显示
            if (view.DesktopMgr.Inst.is_chuanma_mode()) {
                this.showChuanMa();
            }
            else {

                //遍历所有的action中是否有胡牌信息
                let hasWin: boolean = false;
                for (let action of actions) {
                    if (action.name == 'RecordHuleXueZhanEnd' || action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHule') {
                        hasWin = true;
                        break;
                    }
                }
                if (hasWin) {
                    //荣和   
                    this.showWinEnd();
                }
                else {
                    //这个是没牌摸的结算，根据听牌人有分数变动-1000+1000
                    if (finalAction.name == 'RecordNoTile') {
                        this.showLiuJu();
                    }
                    //结局是流局
                    else if (finalAction.name == 'RecordLiuJu') {
                        this.showLiuJuNoScore();

                    }
                }

            }
        }

        private renderMakaInfo(isShowMaka: boolean = false) {
            if (!isShowMaka) {
                this.makaLevelImg.visible = false;
                return;
            }
            this.makaLevelImg.visible = true;
            let seat = view.DesktopMgr.Inst.seat;
            let uuid = GameMgr.Inst.record_uuid;
            let makaData = game.MakaManager.Inst.getMakaPlayerData(uuid, seat);
            if (!makaData) {
                this.makaLevelImg.skin = "";
                return;
            }
            let round = makaData.roundsData[this.roundData.roundIndex];
            this.makaLevelImg.skin = game.MakaManager.getLevelImg(round.rating);
        }
         



        /**
         * 无人扣分的流局，只有一行流局信息，并且无分数信息
         */
        private showLiuJuNoScore() {
            this.clearLines();
            let actions = this.roundData.actions;
            let finalAction: Action = actions[actions.length - 1];
            let finalData = finalAction.data;

            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
            line.title = game.Tools.strOfLocalization(UI_Replay_ChangInfo.liujuStrId[finalData["type"]]);
            line.titleColor = "#8e8fab";
            line.showPlayers([]);
            line.me.y = 0;
            this.height = this.startHeight;
            
        }

        /**
         * 有人扣分的流局，一行流局信息，多行分数信息
         */
        private showLiuJu() {
            this.clearLines();
            let actions = this.roundData.actions;
            let finalAction: Action = actions[actions.length - 1];
            let finalData = finalAction.data;

            let scores: Array<{ old_score: number, delta: number }> = [];
            for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                scores.push({ old_score: finalData['scores'][0]['old_scores'][i], delta: 0 });
            }
            for (let i: number = 0; i < finalData['scores']['length']; i++) {
                for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                    if (finalData['scores'][i]['delta_scores'] && finalData['scores'][i]['delta_scores'][j]) {
                        scores[j].delta += finalData['scores'][i]['delta_scores'][j];
                    }
                }
            }
            let indexs: Array<number> = [];
            for (let i: number = 0; i < scores.length; i++) {
                if (scores[i].delta != 0) {
                    indexs.push(i);
                }
            }
            //创建一行流局信息
            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
            //流局满贯
            if (finalData['liujumanguan']) {
                line.title = game.Tools.strOfLocalization(2170);

            } else {
                line.title = game.Tools.strOfLocalization(2171);
            }
            line.titleColor = "#8e8fab";
            let players: Array<PlayerListData> = [];
            if (finalData['liujumanguan'] || finalData['scores']) {
                for (let i = 0; i < indexs.length; i++) {
                    let playerIndex = indexs[i];
                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(playerIndex);
                    let playerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: scores[playerIndex].delta,
                        tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                        handInfo: null,
                        doraInfo: null,
                        liDoraInfo: null,
                        isZimo: false,
                    };
                    players.push(playerData);
                }
            }
            line.showPlayers(players);
            line.me.y = 0;
            this.height = this.startHeight + line.height - this.lineBaseHeight;

        }

        /**
        * 本轮游戏尚未结束，显示正在进行中
        */
        private showRunning() {
            this.clearLines();
            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
            line.title = game.Tools.strOfLocalization(3036);
            line.titleColor = '#8ADB97';
            line.showPlayers([]);
            line.me.y = 0;
            this.height = this.startHeight;
        }

        /**
         * 有人胡牌，荣和：一行荣和信息（+分割线+放铳信息），自摸：一行自摸信息
         * 如果有多人胡牌则加一个分割线2再显示信息
         */
        private showWinEnd() {
            this.clearLines();
            let totalHeight: number = 0;
            let actions = this.roundData.actions;
            let huActions: Array<Action> = [];
            let finalAction: Action = actions[actions.length - 1];
            //找到所有的胡牌信息
            for (let action of actions) {
                if (action.name == 'RecordHuleXueZhanEnd' || action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHule') {
                    huActions.push(action);
                }
            }

            //遍历所有的信息，查找是否有胡牌信息
            for (let index = 0; index < huActions.length; index++) {
                let action = huActions[index];
                let actionData = action.data;
                //本轮次内的胡牌信息
                let huDatas: Array<Object> = actionData['hules'];
                //本轮胡牌是否是自摸
                let isZimo: boolean = huDatas[0]['zimo'];
                let mode: number = isZimo ? 0 : 1;
                //本轮所有胡牌玩家的数据
                let players: Array<PlayerListData> = [];
                for (let i = 0; i < huDatas.length; i++) {
                    let data = huDatas[i];
                    let handData: UI_MJPai_HandInfo = {
                        hand: data['hand'],
                        ming: data['ming'],
                        hupai: data['hu_tile'],
                        mode: mode,
                        isTianMing: false,
                        isJiuChao: false,
                    }

                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(data['seat']);
                    let playerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: actionData['delta_scores'][data['seat']],
                        tile: data['title_id'],
                        handInfo: handData,
                        doraInfo: null,
                        liDoraInfo: null,
                        isZimo: isZimo
                    };
                    players.push(playerData);
                }
                

                //当前里宝牌数据,只有立直的人有里宝数据
                let liDoras: Array<string> = [];
                // 找到有里宝的人的座位
                let lichiSeat: number = 0;
                for (let index = 0; index < huDatas.length; index++) {
                    if (huDatas[index]['li_doras'] && huDatas[index]['li_doras'].length > 0) {
                        liDoras = huDatas[index]['li_doras'];
                        lichiSeat = huDatas[index]['seat'];
                        break;
                    }
                }
                //当前宝牌数据
                let doraData: UI_MJPai_DoraInfo = {
                    mode: mode,
                    doras: huDatas[0]['doras'],
                    isJiuChao: false,
                    isTianMing: false
                }

                let liDoraData: UI_MJPai_LiDoraInfo = {
                    mode: mode,
                    lidoras: liDoras,
                    isJiuChao: false,
                    isTianMing: false
                }
                
                //如果是血战模式，需要从hules_history中拿到宝牌信息
                if (view.DesktopMgr.Inst.xuezhan) {
                    //根据座位找到对应的数据
                    let hules_history = finalAction.data['hules_history'] as Array<Object>;
                    for (let i = 0; i < huDatas.length; i++) { 
                        let huData = huDatas[i];
                        let seat = huData['seat'];
                        for (let j = 0; j < hules_history.length; j++) {
                            let hules = hules_history[j];
                            if (hules['seat'] == seat) {
                                doraData.doras = hules['doras'];
                                //如果有里宝牌，就不用再找了
                                if (hules['li_doras'] && hules['li_doras'].length > 0) {
                                    liDoraData.lidoras = hules['li_doras'];
                                    break;
                                }
                                
                            }
                        }
                    }
                    // doraData.doras = hules_history[0]['doras'];
                    // for (let index = 0; index < hules_history.length; index++) {
                    //     const element = hules_history[index];
                    //     if (element['seat'] == lichiSeat) {
                    //         liDoraData.lidoras = element['li_doras'];
                    //         break;
                    //     }
                    // }
                }


                //生成自摸
                if (isZimo) {
                    let line = this.getLine(UI_ChangInfo_LineType.ZIMO) as Line_Zimo;
                    line.title = game.Tools.strOfLocalization(2177);
                    line.showPlayers(players);
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                    //自摸也要生成放铳行，用来显示宝牌和里宝牌
                    //生成放铳分割线
                    let seperate = this.getLine(UI_ChangInfo_LineType.SEPERATE1) as Line_Seperate1;
                    seperate.visible = true;
                    seperate.me.y = totalHeight;
                    totalHeight += seperate.height;
                    //放铳信息
                    let chongPlayers: Array<PlayerListData> = [];
                    let chongPlayerData: PlayerListData = {
                        name: "",
                        score: 0,
                        tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                        handInfo: null,
                        doraInfo: doraData,
                        liDoraInfo: liDoraData,
                        isZimo: true,
                        isRemarks: false,
                    };
                    chongPlayers.push(chongPlayerData);
                    let chongLine = this.getLine(UI_ChangInfo_LineType.FANGCHONG) as Line_FangChong;
                    chongLine.title = ""
                    chongLine.showPlayers(chongPlayers);
                    chongLine.me.y = totalHeight;
                    totalHeight += chongLine.height;

                }
                //生成荣和
                else {
                    let line = this.getLine(UI_ChangInfo_LineType.RONG) as Line_Rong;
                    line.title = game.Tools.strOfLocalization(2178);
                    line.showPlayers(players);
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                    //生成放铳分割线
                    let seperate = this.getLine(UI_ChangInfo_LineType.SEPERATE1) as Line_Seperate1;
                    seperate.me.y = totalHeight;
                    totalHeight += seperate.height;
                    //放铳信息
                    let chongPlayers: Array<PlayerListData> = [];
                    let chongSeat: number = 0;
                    for (let j: number = 0; j < actionData['delta_scores'].length; j++) {

                        if (actionData['delta_scores'][j] < actionData['delta_scores'][chongSeat]) {
                            chongSeat = j; //放铳的人一定是输的最多的，即时有包牌
                        } else if (actionData['delta_scores'][j] == actionData['delta_scores'][chongSeat]) {
                            // 如果有人相同掉分，则找出谁是包牌的,一定不是包牌的
                            if (actionData['baopai'] > 0 && actionData['baopai_seats'] && actionData['baopai_seats'].length > 0) {
                                for (let _bao_seat of actionData['baopai_seats']) {
                                    if (_bao_seat == chongSeat) {
                                        chongSeat = j;
                                        break;
                                    }
                                }
                            } else if (actionData['baopai'] > 0 && actionData['baopai'] - 1 == chongSeat) {
                                chongSeat = j;
                            }
                        }
                    }
                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(chongSeat);
                    let chongPlayerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: actionData['delta_scores'][chongSeat],
                        tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                        handInfo: null,
                        doraInfo: doraData,
                        liDoraInfo: liDoraData,
                        isZimo: false
                    };
                    chongPlayers.push(chongPlayerData);
                    let chongLine = this.getLine(UI_ChangInfo_LineType.FANGCHONG) as Line_FangChong;
                    chongLine.showPlayers(chongPlayers);
                    chongLine.title = game.Tools.strOfLocalization(2667);
                    
                    chongLine.me.y = totalHeight;
                    totalHeight += chongLine.height;

                }
                //如果接下来还有数据，就加一个分割线
                if (index < huActions.length - 1) {
                    let line = this.getLine(UI_ChangInfo_LineType.SEPERATE2) as Line_Seperate2;
                    
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                }

            }

            //如果最后的结果是流局，则还要显示一行流局信息
            if (finalAction.name == 'RecordLiuJu' || finalAction.name == 'RecordNoTile') {
                //生成分割线
                let line = this.getLine(UI_ChangInfo_LineType.SEPERATE2) as Line_Seperate2;
                line.me.y = totalHeight;
                totalHeight += line.height;
                //生成流局信息
                if (finalAction.name == 'RecordLiuJu') {
                    let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
                    line.title = game.Tools.strOfLocalization(UI_Replay_ChangInfo.liujuStrId[finalAction["type"]]);
                    line.titleColor = "#8e8fab";
                    line.showPlayers([]);
                    
                    line.me.y = totalHeight;
                    totalHeight += line.height;

                } else {
                    let scores: Array<{ old_score: number, delta: number }> = [];
                    let finalData = finalAction.data;
                    for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        scores.push({ old_score: finalData['scores'][0]['old_scores'][i], delta: 0 });
                    }
                    for (let i: number = 0; i < finalData['scores']['length']; i++) {
                        for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                            scores[j].delta += finalData['scores'][i]['delta_scores'][j];
                        }
                    }
                    let indexs: Array<number> = [];
                    for (let i: number = 0; i < scores.length; i++) {
                        if (scores[i].delta != 0) {
                            indexs.push(i);
                        }
                    }
                    //创建一行流局信息
                    let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
                    //流局满贯
                    if (finalData['liujumanguan']) {
                        line.title = game.Tools.strOfLocalization(2170);

                    } else {
                        line.title = game.Tools.strOfLocalization(2171);
                    }
                    line.titleColor = "#8e8fab";
                    let players: Array<PlayerListData> = [];
                    if (finalData['liujumanguan'] || finalData['scores']) {
                        for (let i = 0; i < indexs.length; i++) {
                            let playerIndex = indexs[i];
                            const nameInfo = view.DesktopMgr.Inst.getPlayerName(playerIndex);
                            let playerData: PlayerListData = {
                                name: nameInfo.nickname,
                                isRemarks: nameInfo.isRemarks,
                                score: scores[playerIndex].delta,
                                tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                                handInfo: null,
                                doraInfo: null,
                                liDoraInfo: null,
                                isZimo: false
                            };
                            players.push(playerData);
                        }
                    }
                    line.showPlayers(players);
                    
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                }
            }

            this.height = this.startHeight + totalHeight - this.lineBaseHeight;

        }

        /**
         * 赤羽之战，因为开杠有分，所以要显示点数变动，不显示具体内容，并且不可展开
         */
        private showChuanMa() {
            //本局产生的分数变化，未发生变化的是0
            let deltaScores = [];
            for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                deltaScores.push(0);
            }
            for (let action of this.roundData.actions) {

                if (action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHuleXueZhanEnd') {
                    for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        deltaScores[i] += action.data['delta_scores'][i];
                    }

                } else if (action.name == 'RecordNoTile') {
                    for (let i = 0; i < action.data['scores']['length']; i++) {
                        if (action.data['scores'][i]['delta_scores'] && action.data['scores'][i]['delta_scores'].length > 0) {
                            for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                                deltaScores[j] += action.data['scores'][i]['delta_scores'][j];
                            }
                        }
                    }
                } else if (action.name == 'RecordGangResult' || action.name == 'RecordGangResultEnd') {
                    for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        deltaScores[i] += action.data['gang_infos']['delta_scores'][i];
                    }
                }
            }
            this.clearLines();
            let line = this.getLine(UI_ChangInfo_LineType.RONG) as Line_Rong;
            line.title = game.Tools.strOfLocalization(3257);
            let players: Array<PlayerListData> = [];
            for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                const nameInfo = view.DesktopMgr.Inst.getPlayerName(i);
                let playerData: PlayerListData = {
                    name: nameInfo.nickname,
                    isRemarks: nameInfo.isRemarks,
                    score: deltaScores[i],
                    tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                    handInfo: null,
                    doraInfo: null,
                    liDoraInfo: null,
                    isZimo: false
                };
                players.push(playerData);
            }
            line.showPlayers(players);
            line.me.y = 0;
            this.height = this.startHeight + line.height - this.lineBaseHeight;
        }



    }


    class UI_Replay_ChangInfo_ListItem_Small extends UI_Replay_ChangInfo_ListItem {

        private normalSpans: Array<number> = [3, 3, 50, 3, 0];


        private startHeight: number = 150;
        private lineBaseHeight: number = 50;

        public onCreate(): void {
            super.onCreate();
            this.bg = this.me.getChildByName("bg") as Laya.Image;
            let containerTitle = this.me.getChildByName("container_title") as Laya.Sprite;
            this.titleChang = containerTitle.getChildByName("chang") as Laya.Label;
            this.titleJu = containerTitle.getChildByName("ju") as Laya.Label;
            this.titleW = containerTitle.getChildByName("w") as Laya.Label;
            this.titleBen = containerTitle.getChildByName("ben") as Laya.Label;
            this.titleBenchang = containerTitle.getChildByName("benchang") as Laya.Label;
            this.info = this.me.getChildByName("info") as Laya.Sprite;
            this.lineLiuJuTemp = this.info.getChildByName("line_liuju") as Laya.Sprite;
            this.lineRongTemp = this.info.getChildByName("line_rong") as Laya.Sprite;
            this.lineZimoTemp = this.info.getChildByName("line_zimo") as Laya.Sprite;
            this.lineFangChongTemp = this.info.getChildByName("line_fangchong") as Laya.Sprite;
            this.lineSeperate1Temp = this.info.getChildByName("line_seperate1") as Laya.Sprite;
            this.lineSeperate2Temp = this.info.getChildByName("line_seperate2") as Laya.Sprite;
            this.lineLiuJuTemp.visible = false;
            this.lineRongTemp.visible = false;
            this.lineZimoTemp.visible = false;
            this.lineFangChongTemp.visible = false;
            this.lineSeperate1Temp.visible = false;
            this.lineSeperate2Temp.visible = false;
            if (GameMgr.client_language == 'en' || GameMgr.client_language == 'kr') {
                this.titleChang.y = 29;
                this.titleJu.y = 28;
                this.titleW.y = 29;
                this.titleBen.y = 28;
                this.titleBenchang.y = 29;
            }

            this.makaLevelImg = this.me.getChildByName("maka_level") as Laya.Image;
        }

        public show(round: Round,isShowMaka:boolean = false) {
            this.roundData = round;
            this.renderTitle();
            this.renderInfo();
            this.renderMakaInfo(isShowMaka);
        }

        private renderTitle() {
            
            for (let i: number = 0; i < this.roundData.actions.length; i++) {
                let action = this.roundData.actions[i];
                //找到对应的数据,"RecordNewRound"只有这个数据里有场次标题信息

                if (this.roundData.actions[i].name == 'RecordNewRound') { 
                    //川麻标题是第n局
                    if (view.DesktopMgr.Inst.is_chuanma_mode()) {
                        this.titleBen.visible = false;
                        this.titleBenchang.visible = false;
                        let s_round = '';
                        if (GameMgr.client_language == 'en') {
                            s_round = 'Round';
                        }
                        else if (GameMgr.client_language == 'kr') {
                            s_round = '제';
                        }
                        else {
                            s_round = '第';
                        }
                        this.titleChang.text = s_round;
                        this.titleJu.text = (action.data['ju_count'] + 1).toString();
                        //让这几个文本居中
                        let texts = [this.titleChang, this.titleJu, this.titleW];
                        game.Tools.sprite_align_center(texts, 373);
                    } else {
                        //非川麻
                        this.titleBen.visible = true;
                        this.titleBenchang.visible = true;
                        this.titleChang.text = UI_Replay_ChangInfo.seatStr(action.data['chang'] % 4);
                        this.titleJu.text = (action.data['ju'] + 1).toString();
                        this.titleBen.text = action.data['ben'].toString();
                        //居中文本
                        let texts = [this.titleChang, this.titleJu, this.titleW, this.titleBen, this.titleBenchang];
                        game.Tools.sprite_align_center(texts, 373, this.normalSpans);
                    }
                }
            }
        }

        private renderInfo() {
            let actions = this.roundData.actions;
            //判断本轮是否结束，如果未结束，则显示进行中
            let finalAction: Action = actions[actions.length - 1];
            if (!UI_Replay_ChangInfo.isRoundEnd(finalAction.name)) {
                this.showRunning();
                return;
            }
            //川麻的特殊显示
            if (view.DesktopMgr.Inst.is_chuanma_mode()) {
                this.showChuanMa();
            }
            else {

                //遍历所有的action中是否有胡牌信息
                let hasWin: boolean = false;
                for (let action of actions) {
                    if (action.name == 'RecordHuleXueZhanEnd' || action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHule') {
                        hasWin = true;
                        break;
                    }
                }
                if (hasWin) {
                    //荣和   
                    this.showWinEnd();
                }
                else {
                    //这个是没牌摸的结算，根据听牌人有分数变动-1000+1000,没牌摸也有可能没分数变动
                    if (finalAction.name == 'RecordNoTile') {
                        this.showLiuJu();
                    }
                    //结局是流局
                    else if (finalAction.name == 'RecordLiuJu') {
                        this.showLiuJuNoScore();

                    }
                }

            }
        }

        private renderMakaInfo(isShowMaka: boolean = false) {
            if (!isShowMaka) {
                this.makaLevelImg.visible = false;
                return;
            }
            this.makaLevelImg.visible = true;
            let seat = view.DesktopMgr.Inst.seat;
            let uuid = GameMgr.Inst.record_uuid;
            let makaData = game.MakaManager.Inst.getMakaPlayerData(uuid, seat);
            if (!makaData) {
                this.makaLevelImg.skin = "";
                return;
            }
            let round = makaData.roundsData[this.roundData.roundIndex];
            this.makaLevelImg.skin = game.MakaManager.getLevelImg(round.rating);
        }

        /**
         * 本轮游戏尚未结束，显示正在进行中
         */
        private showRunning() {
            this.clearLines();
            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
            line.title = game.Tools.strOfLocalization(3036);
            line.titleColor = '#8ADB97';
            
            line.showPlayers([]);
            
            this.height = this.startHeight;
        }

        /**
         * 无人扣分的流局，只有一行流局信息，并且无分数信息
         */
        private showLiuJuNoScore() {
            this.clearLines();
            let actions = this.roundData.actions;
            let finalAction: Action = actions[actions.length - 1];
            let finalData = finalAction.data;

            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
            line.title = game.Tools.strOfLocalization(UI_Replay_ChangInfo.liujuStrId[finalData["type"]]);
            line.titleColor = "#8e8fab";
            line.showPlayers([]);
            line.me.y = 0;
            
            this.height = this.startHeight;

        }

        /**
         * 有人扣分的流局，一行流局信息，多行分数信息
         */
        private showLiuJu() {
            this.clearLines();
            let actions = this.roundData.actions;
            let finalAction: Action = actions[actions.length - 1];
            let finalData = finalAction.data;

            let scores: Array<{ old_score: number, delta: number }> = [];
            for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                scores.push({ old_score: finalData['scores'][0]['old_scores'][i], delta: 0 });
            }
            for (let i: number = 0; i < finalData['scores']['length']; i++) {
                for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                    if (finalData['scores'][i]['delta_scores'] && finalData['scores'][i]['delta_scores'][j]) {
                        scores[j].delta += finalData['scores'][i]['delta_scores'][j];
                    }
                }
            }
            let indexs: Array<number> = [];
            for (let i: number = 0; i < scores.length; i++) {
                if (scores[i].delta != 0) {
                    indexs.push(i);
                }
            }
            //创建一行流局信息
            let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;

            //流局满贯
            if (finalData['liujumanguan']) {
                line.title = game.Tools.strOfLocalization(2170);

            } else {
                line.title = game.Tools.strOfLocalization(2171);
            }
            line.titleColor = "#8e8fab";
            let players: Array<PlayerListData> = [];
            if (finalData['liujumanguan'] || finalData['scores']) {
                for (let i = 0; i < indexs.length; i++) {
                    let playerIndex = indexs[i];
                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(playerIndex);
                    let playerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: scores[playerIndex].delta,
                        tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                        handInfo: null,
                        doraInfo: null,
                        liDoraInfo: null,
                        isZimo: false
                    };
                    players.push(playerData);
                }
            }
            line.showPlayers(players);
            line.me.y = 0;
            
            this.height = this.startHeight + line.height - this.lineBaseHeight;

        }

        /**
         * 有人胡牌，荣和：一行荣和信息（+分割线+放铳信息），自摸：一行自摸信息
         * 如果有多人胡牌则加一个分割线2再显示信息
         */
        private showWinEnd() {
            this.clearLines();
            let totalHeight: number = 0;
            let actions = this.roundData.actions;
            let huActions: Array<Action> = [];
            let finalAction: Action = actions[actions.length - 1];
            //找到所有的胡牌信息
            for (let action of actions) {
                if (action.name == 'RecordHuleXueZhanEnd' || action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHule') {
                    huActions.push(action);
                }
            }

            //遍历所有的信息，查找是否有胡牌信息
            for (let index = 0; index < huActions.length; index++) {
                let action = huActions[index];
                let actionData = action.data;
                //本轮次内的胡牌信息
                let huDatas: Array<Object> = actionData['hules'];
                //本轮胡牌是否是自摸
                let isZimo: boolean = huDatas[0]['zimo'];
                //本轮所有胡牌玩家的数据
                let players: Array<PlayerListData> = [];
                for (let i = 0; i < huDatas.length; i++) {
                    let data = huDatas[i];
                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(data['seat']);
                    let playerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: actionData['delta_scores'][data['seat']],
                        tile: data['title_id'],
                        handInfo: null,
                        doraInfo: null,
                        liDoraInfo: null,
                        isZimo: false
                    };
                    players.push(playerData);
                }
                //生成自摸
                if (isZimo) {
                    let line = this.getLine(UI_ChangInfo_LineType.ZIMO) as Line_Zimo;
                    line.title = game.Tools.strOfLocalization(2177);
                    line.showPlayers(players);
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                }
                //生成荣和
                else {
                    let line = this.getLine(UI_ChangInfo_LineType.RONG) as Line_Rong;
                    line.title = game.Tools.strOfLocalization(2178);
                    line.showPlayers(players);
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                    //生成放铳分割线
                    let seperate = this.getLine(UI_ChangInfo_LineType.SEPERATE1) as Line_Seperate1;
                    seperate.visible = true;
                    seperate.me.y = totalHeight;
                    totalHeight += seperate.height;
                    //放铳信息
                    let chongPlayers: Array<PlayerListData> = [];

                    let chongSeat: number = 0;
                    for (let j: number = 0; j < actionData['delta_scores'].length; j++) {

                        if (actionData['delta_scores'][j] < actionData['delta_scores'][chongSeat]) {
                            chongSeat = j; //放铳的人一定是输的最多的，即时有包牌
                        } else if (actionData['delta_scores'][j] == actionData['delta_scores'][chongSeat]) {
                            // 如果有人相同掉分，则找出谁是包牌的,一定不是包牌的
                            if (actionData['baopai'] > 0 && actionData['baopai_seats'] && actionData['baopai_seats'].length > 0) {
                                for (let _bao_seat of actionData['baopai_seats']) {
                                    if (_bao_seat == chongSeat) {
                                        chongSeat = j;
                                        break;
                                    }
                                }
                            } else if (actionData['baopai'] > 0 && actionData['baopai'] - 1 == chongSeat) {
                                chongSeat = j;
                            }
                        }
                    }
                    const nameInfo = view.DesktopMgr.Inst.getPlayerName(chongSeat);
                    let chongPlayerData: PlayerListData = {
                        name: nameInfo.nickname,
                        isRemarks: nameInfo.isRemarks,
                        score: actionData['delta_scores'][chongSeat],
                        tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                        handInfo: null,
                        doraInfo: null,
                        liDoraInfo: null,
                        isZimo: false
                    };
                    chongPlayers.push(chongPlayerData);
                    let chongLine = this.getLine(UI_ChangInfo_LineType.FANGCHONG) as Line_FangChong;
                    chongLine.showPlayers(chongPlayers);
                    chongLine.me.y = totalHeight;
                    totalHeight += chongLine.height;

                }
                //如果接下来还有数据，就加一个分割线
                if (index < huActions.length - 1) {
                    let line = this.getLine(UI_ChangInfo_LineType.SEPERATE2) as Line_Seperate2;
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                }

            }

            //如果最后的结果是流局，则还要显示一行流局信息
            if (finalAction.name == 'RecordLiuJu' || finalAction.name == 'RecordNoTile') {
                //生成分割线
                let line = this.getLine(UI_ChangInfo_LineType.SEPERATE2) as Line_Seperate2;
                line.me.y = totalHeight;
                totalHeight += line.height;
                //生成流局信息
                if (finalAction.name == 'RecordLiuJu') {
                    let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
                    line.title = game.Tools.strOfLocalization(UI_Replay_ChangInfo.liujuStrId[finalAction["type"]]);
                    line.titleColor = "#8e8fab";
                    line.showPlayers([]);
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                } else {
                    let scores: Array<{ old_score: number, delta: number }> = [];
                    let finalData = finalAction.data;
                    //先从第一轮取旧分数
                    for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        scores.push({ old_score: finalData['scores'][0]['old_scores'][i], delta: 0 });
                    }
                    //根据每一轮的分数变动计算总分数变动
                    for (let i: number = 0; i < finalData['scores']['length']; i++) {
                        for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                            scores[j].delta += finalData['scores'][i]['delta_scores'][j];
                        }
                    }
                    let indexs: Array<number> = [];
                    for (let i: number = 0; i < scores.length; i++) {
                        if (scores[i].delta != 0) {
                            indexs.push(i);
                        }
                    }
                    //创建一行流局信息
                    let line = this.getLine(UI_ChangInfo_LineType.LIUJU) as Line_LiuJu;
                    //流局满贯
                    if (finalData['liujumanguan']) {
                        line.title = game.Tools.strOfLocalization(2170);

                    } else {
                        line.title = game.Tools.strOfLocalization(2171);
                    }
                    line.titleColor = "#8e8fab";
                    let players: Array<PlayerListData> = [];
                    if (finalData['liujumanguan'] || finalData['scores']) {
                        for (let i = 0; i < indexs.length; i++) {
                            let playerIndex = indexs[i];
                            const nameInfo = view.DesktopMgr.Inst.getPlayerName(playerIndex);
                            let playerData: PlayerListData = {
                                name: nameInfo.nickname,
                                isRemarks: nameInfo.isRemarks,
                                score: scores[playerIndex].delta,
                                tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                                handInfo: null,
                                doraInfo: null,
                                liDoraInfo: null,
                                isZimo: false
                            };
                            players.push(playerData);
                        }
                    }
                    line.showPlayers(players);
                    
                    
                    line.me.y = totalHeight;
                    totalHeight += line.height;
                }
            }
            this.height = this.startHeight + totalHeight - this.lineBaseHeight;

        }

        /**
         * 赤羽之战，因为开杠有分，所以要显示点数变动，不显示具体内容，并且不可展开
         */
        private showChuanMa() {
            //本局产生的分数变化，未发生变化的是0
            let deltaScores = [];
            for (let i: number = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                deltaScores.push(0);
            }
            for (let action of this.roundData.actions) {

                if (action.name == 'RecordHuleXueZhanMid' || action.name == 'RecordHuleXueZhanEnd') {
                    for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        deltaScores[i] += action.data['delta_scores'][i];
                    }
                } else if (action.name == 'RecordNoTile') {
                    // console.log('川麻 RecordNoTile', JSON.stringify(action.data));
                    
                    for (let i = 0; i < action.data['scores']['length']; i++) {
                        if (action.data['scores'][i]['delta_scores'] && action.data['scores'][i]['delta_scores'].length > 0) {
                            for (let j: number = 0; j < view.DesktopMgr.Inst.player_count; j++) {
                                deltaScores[j] += action.data['scores'][i]['delta_scores'][j];
                                if (action.data['scores'][i]['taxes'][j]) {
                                    deltaScores[j] += action.data['scores'][i]['taxes'][j];
                                }

                            }
                        }
                    }
                } else if (action.name == 'RecordGangResult' || action.name == 'RecordGangResultEnd') {
                    for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                        deltaScores[i] += action.data['gang_infos']['delta_scores'][i];
                    }
                }
            }
            this.clearLines();
            let line = this.getLine(UI_ChangInfo_LineType.RONG) as Line_Rong;
            line.title = game.Tools.strOfLocalization(3257);
            let players: Array<PlayerListData> = [];
            for (let i = 0; i < view.DesktopMgr.Inst.player_count; i++) {
                const nameInfo = view.DesktopMgr.Inst.getPlayerName(i);
                let playerData: PlayerListData = {
                    name: nameInfo.nickname,
                    isRemarks: nameInfo.isRemarks,
                    score: deltaScores[i],
                    tile: mjcore.E_Dadian_Title.E_Dadian_Title_none,
                    handInfo: null,
                    doraInfo: null,
                    liDoraInfo: null,
                    isZimo: false
                };
                players.push(playerData);
            }
            line.showPlayers(players);
            line.me.y = 0;
            this.height = this.startHeight + line.height - this.lineBaseHeight;
        }



    }

    class UI_Replay_ChangInfo_Panel extends UI_Component {
        private upBtn: Laya.Button;
        private downBtn: Laya.Button;
        private scrollPanel: ScrollPanel;
        private panel: Laya.Panel;
        private expandBtn: Laya.Button;
        private infoItems: Array<UI_Replay_ChangInfo_ListItem> = new Array<UI_Replay_ChangInfo_ListItem>();
        private itemTemplete: Laya.Sprite;
        private rounds: Array<Round> = [];
        public locking: boolean = false;
        private maxHeight: number = 650;
        private isBig: boolean = false;
        private isShowMaka:boolean = false;

        private onClickExpandHandler: Laya.Handler;
        public set onClickExpand(handler: Laya.Handler) {
            this.onClickExpandHandler = handler;
        }

        private onPanelValueChangeHandler: Laya.Handler;
        public set onPanelValueChange(handler: Laya.Handler) {
            this.onPanelValueChangeHandler = handler;
        }


        public onCreate(): void {
            this.upBtn = this.me.getChildByName("up") as Laya.Button;
            this.downBtn = this.me.getChildByName("down") as Laya.Button;
            this.expandBtn = this.me.getChildByName("btn_expand") as Laya.Button;
            this.panel = this.me.getChildByName("panel") as Laya.Panel;
            this.scrollPanel = new ScrollPanel(this.me);
            this.itemTemplete = this.scrollPanel.content.getChildByName("templete") as Laya.Sprite;
            this.itemTemplete.visible = false;
            this.upBtn.clickHandler = new Laya.Handler(this, () => {
                this.scrollPanel.scrollValue -= 100;
            });
            this.downBtn.clickHandler = new Laya.Handler(this, () => {
                this.scrollPanel.scrollValue += 100;
            });
            this.scrollPanel.onValueChange = new Laya.Handler(this, () => {               
                this.upBtn.visible = this.scrollPanel.rate > 0;
                //有滚动的余地才显示下滚按钮
                this.downBtn.visible = this.scrollPanel.needScroll && this.scrollPanel.rate < 1;
                if (this.onPanelValueChangeHandler) {
                    this.onPanelValueChangeHandler.runWith(this.scrollPanel.rate);
                }
            });
            this.expandBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.onClickExpandHandler) {
                    this.onClickExpandHandler.run();
                }
            });
          
        }

        public show(rounds: Array<Round>, isBig: boolean, itemClickHandler: Laya.Handler,isShowMaka:boolean) {
            this.rounds = rounds;
            this.isBig = isBig;
            this.isShowMaka = isShowMaka;
            this.freshList(itemClickHandler);
            this.upBtn.visible = false;
            this.downBtn.visible = this.scrollPanel.needScroll;
            this.visible = true;

        }

        public close() {
            this.visible = false;
        }

        private freshList(itemClickHandler: Laya.Handler) {
            //如果item不够用，就创建新的
            while (this.infoItems.length < this.rounds.length) {
                let item = this.itemTemplete.scriptMap['capsui.UICopy']['getNodeClone']() as Laya.Sprite;
                this.scrollPanel.content.addChild(item);
                item.x = 0;
                item.y = this.infoItems.length == 0 ? 0 : this.infoItems[this.infoItems.length - 1].me.y + this.infoItems[this.infoItems.length - 1].height;
                if (this.isBig) {
                    this.infoItems.push(new UI_Replay_ChangInfo_ListItem_Big(item));
                }
                else {
                    this.infoItems.push(new UI_Replay_ChangInfo_ListItem_Small(item));
                }

            }
            //如果item多了，就隐藏多余的
            for (let i = this.rounds.length; i < this.infoItems.length; i++) {
                this.infoItems[i].me.visible = false;
            }
            let itemHeight: number = 0;
            //刷新每个item
            for (let i = 0; i < this.rounds.length; i++) {
                this.infoItems[i].me.visible = true;
                this.infoItems[i].show(this.rounds[i],this.isShowMaka);
                this.infoItems[i].me.y = itemHeight;
                itemHeight += this.infoItems[i].height;
                this.infoItems[i].clickHandler = new Laya.Handler(this, () => {
                    if (itemClickHandler) {
                        let itemIndex = i;
                        itemClickHandler.runWith(itemIndex);
                    }
                });
            }
            this.freshHeight();
            this.freshExpandBtn();
        }

        private freshHeight() {
            let height = 0;
            for (let i = 0; i < this.infoItems.length; i++) {
                let item = this.infoItems[i];
                if (item.visible) {
                    height += item.height;
                }
            }
            this.scrollPanel.contentHeight = height;
            if (height < this.maxHeight) {
                this.panel.height = height;
            }
            else {
                this.panel.height = this.maxHeight;
            }

        }

        private freshExpandBtn() {
            //如果是川麻不显示按钮
            this.expandBtn.visible = !view.DesktopMgr.Inst.is_chuanma_mode();
            this.expandBtn.y = this.panel.y - this.panel.height / 2;
        }




        public get rate(): number {
            return this.scrollPanel.rate;
        }

        public set rate(value: number) {
            this.scrollPanel.rate = value;
        }
    }

    export class UI_Replay_ChangInfo extends UI_Component {

        public static liujuStrId: Array<number> = [0, 2172, 2173, 2174, 2175, 2176];
        public static seatStrChs: Array<string> = ['东', '南', '西', '北'];
        public static seatStrJp: Array<string> = ['東', '南', '西', '北'];
        public static seatStrEn: Array<string> = ['East', 'South', 'West', 'North'];
        public static seatStrKr: Array<string> = ['동', '남', '서', '북'];
        public static seatStr(index: number): string {
            if (GameMgr.client_language == 'chs') {
                return UI_Replay_ChangInfo.seatStrChs[index];
            }
            else if (GameMgr.client_language == 'jp' || GameMgr.client_language == 'chs_t') {
                return UI_Replay_ChangInfo.seatStrJp[index];
            }
            else if (GameMgr.client_language == 'en') {
                return UI_Replay_ChangInfo.seatStrEn[index];
            }
            else if (GameMgr.client_language == 'kr') {
                return UI_Replay_ChangInfo.seatStrKr[index];
            }
            return "";
        }

        public locking: boolean = false;
        private panelSmall: UI_Replay_ChangInfo_Panel;
        private panelBig: UI_Replay_ChangInfo_Panel;
        private rounds: Array<Round> = [];
        private itemClickHandler: Laya.Handler = null;
        private isBig: boolean = false;
        private currentRate: number = 0;
        private maskCloseBtn: Laya.Button;
        public isShowMaka: boolean = false;
        public set onItemClick(handler: Laya.Handler) {
            this.itemClickHandler = handler;
        }

        public onCreate(): void {

            this.panelBig = new UI_Replay_ChangInfo_Panel(this.me.getChildByName("big") as Laya.Sprite);
            this.panelSmall = new UI_Replay_ChangInfo_Panel(this.me.getChildByName("small") as Laya.Sprite);
            this.panelBig.onClickExpand = new Laya.Handler(this, () => {
                this.showPanelSmall(this.panelBig.rate);
                this.isBig = false;
            });
            this.panelSmall.onClickExpand = new Laya.Handler(this, () => {
                this.showPanelBig(this.panelSmall.rate);
                this.isBig = true;
            });
            this.maskCloseBtn = this.me.getChildByName("close_btn") as Laya.Button;
            this.maskCloseBtn.clickHandler = new Laya.Handler(this, () => {
                this.close();
            });


        }


        public show(rounds: Array<Round>, isShowMaka: boolean = false) {
            this.isShowMaka = isShowMaka;
            this.rounds = rounds;
            this.locking = true;
            this.showPanelBig(this.currentRate);
            if (!this.isBig) {
                this.showPanelSmall(this.currentRate);
            }
            this.visible = true;
            UIBase.anim_alpha_in(this.me, { y: 30 }, 120, 0, Laya.Handler.create(this, () => {
                this.locking = false;
            }));

        }

        public close() {
            this.locking = true;
            this.currentRate = this.isBig ? this.panelBig.rate : this.panelSmall.rate;
            UIBase.anim_alpha_out(this.me, { y: 30 }, 120, 0, Laya.Handler.create(this, () => {
                this.locking = false;
                this.visible = false;
                this.panelBig.close();
                this.panelSmall.close();
            }));
        }

        public reset() {
            this.currentRate = 0;
            this.isBig = false;
        }


        private showPanelSmall(rate:number = 0) {
            this.currentRate = rate;
            this.panelBig.close(); 
            this.panelSmall.show(this.rounds, false, this.itemClickHandler,this.isShowMaka);
            this.panelSmall.rate = rate;
        }

        private showPanelBig(rate: number = 0) {
            this.currentRate = rate;
            this.panelSmall.close();
            this.panelBig.show(this.rounds, true, this.itemClickHandler,this.isShowMaka);
            this.panelBig.rate = rate;
            
        }

        public static isRoundEnd(name: string): boolean {
            return name == 'RecordNoTile' || name == 'RecordLiuJu' || name == 'RecordHule' || name == 'RecordHuleXueZhanEnd' || name == 'RecordGangResultEnd';
        }
    }

}