/**
* name 
*/
module uiscript {
	export class UI_Entrance_Account_Deleted extends UIBase {

		public static Inst: UI_Entrance_Account_Deleted = null;

		public root: Laya.Sprite;
		public desc: Laya.Label;
		private locking: boolean = false;
		private resizeSprList: Array<Laya.Sprite> = [];
		private originWidthList: Array<number> = [];
		private origin_desc_width: number;
		private confrim: Laya.Button;
		private cancel: Laya.Button;
		private orgin_btn_x_list: Array<number> = [];
		private lineHeight: number;
		private resetXSprList: Array<Laya.Sprite> = [];
		private originXList: Array<number> = [];
		private maxLine: number = 3;
		private yo_uid: string;
		private yo_token: string;

		constructor() {
			super(new ui.entrance.account_deletedUI());
			UI_Entrance_Account_Deleted.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.confrim = this.root.getChildByName('btn_confirm') as Laya.Button;
			this.confrim.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.locking = true;
				if (GameMgr.client_type != 'chs_t' && this.yo_uid) {
					// Yo.reborn({ uid: this.yo_uid, token: this.yo_token }).then(data0 => {
					// 	this.locking = false;
					// 	if (data0.result == 0) {
					// 		this.close();
					// 		UI_SecondConfirm_Entrance.Inst.show_only_confirm(game.Tools.strOfLocalization(8030));

					// 	} else {

					// 	}
					// });
				} else {
					app.NetAgent.sendReq2Lobby('Lobby', 'cancelDeleteAccount', {}, (err, res) => {
						this.locking = false;
						if (err || res['error']) {
							UIMgr.Inst.showNetReqError('cancelDeleteAccount', err, res);
						} else {
							UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(GameMgr.client_type == 'chs_t' ? 8037 : 8030), 0, false);
							net.NetRouteGroup_Entrance.Inst.close();
							Laya.timer.once(200, this, () => {
								net.NetRouteGroup_Entrance.Inst.connect(null);
							});
							this.close();
						}
					});
				}



			}, null, false);

			if (GameMgr.client_type != 'chs_t') {
				let label_confirm = (this.confrim.getChildAt(0) as Laya.Label);
				label_confirm.text = game.Tools.strOfLocalization(8028);
				label_confirm.x = 84;
				this.confrim.width = 176;

			}
			this.cancel = this.root.getChildByName('btn_cancel') as Laya.Button;
			this.cancel.clickHandler = Laya.Handler.create(this, () => {
				if (this.locking) return;
				net.NetRouteGroup_Entrance.Inst.close();
				Laya.timer.once(200, this, () => {
					net.NetRouteGroup_Entrance.Inst.connect(null);
				});
				this.close();

			}, null, false);


			if (GameMgr.client_language == 'kr') {
				(this.cancel.getChildAt(0) as Laya.Sprite).y += 3;
				(this.confrim.getChildAt(0) as Laya.Sprite).y += 3;
			}
			this.orgin_btn_x_list.push(this.confrim.x);
			this.orgin_btn_x_list.push(this.cancel.x);
			let bg = this.root.getChildByName('bg0') as Laya.Sprite;
			this.resizeSprList.push(bg);
			this.originWidthList.push(bg.width);
			let bound = this.root.getChildByName('bound') as Laya.Sprite;
			this.resizeSprList.push(bound);
			this.originWidthList.push(bound.width);

			let right = this.root.getChildByName('bg0').getChildByName('right') as Laya.Sprite;
			this.resetXSprList.push(right);
			this.originXList.push(right.x);

			this.desc = this.root.getChildByName('desc') as Laya.Label;
			this.origin_desc_width = this.desc.width;
			this.locking = false;
			this.lineHeight = this.desc.fontSize + this.desc.leading;
		}

		public show(desc: string) {
			// this.desc.text = desc;
			this.set_desc(desc);

			this.locking = true;
			this.enable = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
				this.locking = false;
			}));
		}

		public setYoInfo(uid: string, token: string) {
			this.yo_uid = uid;
			this.yo_token = token;
		}
		private set_desc(desc: string) {
			this.desc.text = desc;
			let height = this.desc.textField.textHeight;
			let addWidth = 0;
			if (height > this.lineHeight * this.maxLine) {
				this.desc.width = height / (this.lineHeight * this.maxLine) * this.origin_desc_width;
				addWidth = this.desc.width - this.origin_desc_width;

			} else {
				if (this.desc.textField.textHeight > this.desc.fontSize * 1.5) {
					this.desc.align = 'left';
				} else {
					this.desc.align = 'center';
				}
			}
			for (let i = 0; i < this.resizeSprList.length; i++) {
				this.resizeSprList[i].width = this.originWidthList[i] + addWidth;
			}
			for (let i = 0; i < this.resetXSprList.length; i++) {
				this.resetXSprList[i].width = this.originXList[i] + addWidth;
			}
		}

		public onDisable() {
			this.desc.width = this.origin_desc_width;
			for (let i = 0; i < this.resizeSprList.length; i++) {
				this.resizeSprList[i].width = this.originWidthList[i];
			}
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
				this.locking = false;
				this.enable = false;
			}));
		}
	}
}