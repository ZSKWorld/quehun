/**
* name 
*/
module uiscript{
	export class UI_Entrance_Change_Language extends UIBase {

		public static Inst:UI_Entrance_Change_Language;
		private root:Laya.Sprite;
		private locking:boolean;
		private index:number = 0;
		private changing:Laya.Sprite;

		constructor() {
			super(new ui.entrance.change_languageUI());
			UI_Entrance_Change_Language.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			let container_check:Laya.Sprite = this.root.getChildByName('checkbox') as Laya.Sprite;
			container_check.visible = true;
			for (let i:number = 0; i < 4; i++) {
				(container_check.getChildByName('c' + i).getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
					if (this.locking) return;
					if (i == this.index) return;
					this.change(i);
				});
			}

			if (GameMgr.client_type == 'chs_t') {
				(container_check.getChildByName('c2') as Laya.Sprite).visible = false;
				(container_check.getChildByName('c3') as Laya.Sprite).visible = false;
			} else {
				(container_check.getChildByName('c0') as Laya.Sprite).visible = false;
				(container_check.getChildByName('c1') as Laya.Sprite).x = 168;
				let bg = this.root.getChildByName('bg') as Laya.Sprite;
				// (bg.getChildAt(0) as Laya.Sprite).x = 20;
				(bg.getChildAt(0) as Laya.Sprite).width = 820;
				// (bg.getChildAt(1) as Laya.Sprite).x = 20;
				(bg.getChildAt(1) as Laya.Sprite).width = 860;
			}
			(this.root.getChildByName('btn_confirm') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				let lan:string = GameMgr.client_language;
				if (this.index == 0) lan = 'chs';
				else if (this.index == 1) lan = 'chs_t';
				else if (this.index == 2) lan = 'en';
				else if (this.index == 3) lan = 'kr';
				if (lan != GameMgr.client_language) {
					Laya.LocalStorage.setItem('language', lan);
					Laya.Browser.window.location.href = GameMgr.Inst.link_url;
					this.changing.visible = true;
					container_check.visible = false;
					(this.root.getChildByName('btn_confirm') as Laya.Button).visible = false;
					(this.root.getChildByName('btn_cancel') as Laya.Button).visible = false;
				} else {
					this.close();
				}
			});
			(this.root.getChildByName('btn_cancel') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});
			this.changing = this.root.getChildByName('changing') as Laya.Sprite;
		}

		public show() {
			this.enable = true;
			this.locking = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
			this.index = 0;
			switch(GameMgr.client_language) {
				case 'chs': this.index = 0; break;
				case 'chs_t': this.index = 1; break;
				case 'en': this.index = 2; break;
				case 'kr': this.index = 3; break;
			}
			this.change(this.index);
			this.changing.visible = false;
		}

		private change(index:number) {
			this.index = index;
			for (let i:number = 0; i < 4; i++) {
				let container:Laya.Sprite = this.root.getChildByName('checkbox').getChildByName('c' + i) as Laya.Sprite;
				(container.getChildByName('btn') as Laya.Button).mouseEnabled = i != index;
				(container.getChildByName('checkbox') as Laya.Sprite).visible = i == index;
				(container.getChildByName('lan') as Laya.Label).color = i == index ? '#cad4f7' : '#9ba1b2';
			}
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
		}
	}
}