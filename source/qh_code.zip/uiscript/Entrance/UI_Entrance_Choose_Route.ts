/**
* name 
*/
module uiscript{
	export class UI_Entrance_Choose_Route extends UIBase {

		public static Inst:UI_Entrance_Choose_Route;

		public root: Laya.Sprite;
		private origin_root_y: number;
		public btns:Array<Laya.Button> = [];
		private bounds: Array<CBounds> = [];
		private templeteUI: capsui.UICopy;
		private locking: boolean;

		private routes: net.NetRoute[] = [];


		constructor() {
			super(new ui.entrance.choose_routeUI());
			UI_Entrance_Choose_Route.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('servers').getChildByName('container') as Laya.Sprite;
			this.origin_root_y = this.root.y;
			this.me.visible = false;
			(this.me.getChildByName('servers').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.close();
			}, null, false);
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.close();
			}, null, false);
			let template = this.root.getChildByName('templete') as Laya.Button;
			this.templeteUI = template.scriptMap["capsui.UICopy"] as capsui.UICopy;
			this.btns = [template];
			this.bounds.push(new CBounds(this.root.getChildByName('bg0') as Laya.Sprite, true, true));
			this.bounds.push(new CBounds(this.root.getChildByName('bg0').getChildAt(0) as Laya.Sprite, false, true));
			this.bounds.push(new CBounds(this.root.getChildByName('bg0').getChildAt(1) as Laya.Sprite, false, true));
			this.bounds.push(new CBounds(this.root.getChildByName('bound') as Laya.Sprite, true, true));
		}

		public show() {
			this.enable = true;
			this.routes = [];
			for (let id in net.NetRouteGroup_Entrance.Inst.routeInfos) {
				this.routes.push(net.NetRouteGroup_Entrance.Inst.routeInfos[id].route);
			}
			this.routes.sort((a, b) => {
				if (a.order != b.order) return a.order - b.order;
				return a.routeID < b.routeID ? -1 : 1;
			});

			let ext_h = (this.routes.length - 5) * 125;
			this.root.pivotY = 250 + ext_h / 2;
			for (let bound of this.bounds) {
				bound.SetExtH(ext_h);
			}
			this.locking = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));

			for (let i:number = 0; i < this.routes.length; i++) {
				let btn: Laya.Button = this.btns[i];
				if (!btn) {
					btn = this.templeteUI.getNodeClone() as Laya.Button;
					this.btns.push(btn);
					this.root.addChild(btn);
				}
				btn.visible = true;
				btn.pos(250, 85 + 130 * i);
				let _route: net.NetRoute = this.routes[i];
				(btn.getChildByName('info') as Laya.Label).text = game.Tools.strOfLocalization(3150) + _route.name;
				game.Tools.clearBtnClickHandler(btn);
				btn.clickHandler = Laya.Handler.create(this, () => {
					if (this.locking) return;
					net.NetRouteGroup_Entrance.Inst.setMainRoute(_route.routeID);
					UI_Entrance.Inst.updateServer();
					this.close();
				}, null, false);
			}
			if (this.btns.length > this.routes.length) {
				for (let i: number = this.routes.length; i < this.btns.length; i++) {
					this.btns[i].visible = false;
				}
			}
			net.NetRouteGroup_Entrance.Inst.detectAll();
			Laya.timer.clearAll(this);
			Laya.timer.frameLoop(1, this, () => {
				for (let i:number = 0; i < this.routes.length; i++) {
					let btn:Laya.Button = this.btns[i];
					let label_time:Laya.Label = btn.getChildByName('time') as Laya.Label;
					let img:Laya.Image = btn.getChildByName('img') as Laya.Image;
					let data = net.NetRouteGroup_Entrance.Inst.getRouteInfo(this.routes[i].routeID);
					UI_Entrance_Choose_Route.refresh(img, label_time, data.busyState, data.state, data.delay);
				}
			});
		}

		public static refresh(img: Laya.Image, label_time: Laya.Label, busyState: string, state?: game.EConnectState, delay?: number) {
			if (net.GatewayFetcher.getMaintenance() != null) {
				img.visible = false;
				label_time.visible = true;
				label_time.text = game.Tools.strOfLocalization(3149);
				label_time.fontSize = 25;
				label_time.color = '#7e818b';
			} else if (busyState == "busy") {
				img.visible = false;
				label_time.visible = true;
				label_time.text = game.Tools.strOfLocalization(69);
				label_time.fontSize = 25;
				label_time.color = '#e03737';
			} else if (state == game.EConnectState.tryconnect) {
				img.visible = true;
				label_time.visible = false;
				img.skin = game.Tools.localUISrc('myres/entrance/fetching.png');
				img.rotation += Laya.timer.delta * 0.5;
			} else if (state == game.EConnectState.connecting) {
				img.visible = true;
				label_time.visible = false;
				img.skin = game.Tools.localUISrc('myres/entrance/connecting.png');
				img.rotation += Laya.timer.delta * 0.5;
			} else if (state == game.EConnectState.usable || ((delay > 0 && delay < 10) && (state == game.EConnectState.closing || state == game.EConnectState.disconnect))) {
				img.visible = false;
				label_time.visible = true;
				if (delay < 0.001) {
					label_time.text = '--';
				} else {
					label_time.text = Math.floor(delay * 1000 / 2) + 'ms';
				}
				label_time.fontSize = 30;
				if (delay < 0.001) label_time.color = '#7e818b';
				else if (delay < 0.3) label_time.color = '#32dd5b';
				else if (delay < 0.8) label_time.color = '#ffe154';
				else label_time.color = '#e03737';
			} else {
				img.visible = false;
				label_time.visible = true;
				label_time.fontSize = 25;
				label_time.color = '#7e818b';
				label_time.text = game.Tools.strOfLocalization(3148);
			}
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.enable = false;
				this.locking = false;
				Laya.timer.clearAll(this);
			}));
		}

	}
}