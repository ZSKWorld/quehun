/**
* name 
*/
module uiscript{
	export class UI_Entrance_Error extends UIBase {

		public static Inst:UI_Entrance_Error;

		private root: Laya.Sprite;
		private origin_root_y: number;
		private info: Laya.Label;
		private code: Laya.Label;
		private btn_full_close: Laya.Button;
		private btn_close: Laya.Button;
		private resizeSprList:Array<Laya.Sprite> = [];
		private resetYSprList: Array<Laya.Sprite> = [];
		private originHeightList:Array<number> = [];
		private originYList: Array<number> = [];
		private origin_desc_height:number;

		private locking:boolean = false;

		public constructor() {
			super(new ui.entrance.error_infoUI());
			UI_Entrance_Error.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('error').getChildByName('container') as Laya.Sprite;
			this.origin_root_y = this.root.y;
			this.info = this.root.getChildByName('text') as Laya.Label;
			this.code = this.root.getChildByName('code') as Laya.Label;
			this.me.visible = false;
			let cancelHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return ;
				this.close();
			}, null, false);
			this.btn_close = this.root.getChildByName('btn_close') as Laya.Button;
			this.btn_full_close = this.me.getChildByName('btn') as Laya.Button;
			this.btn_close.clickHandler = cancelHandler;
			this.btn_full_close.clickHandler = cancelHandler;

			(this.root.getChildByName('btn') as Laya.Button).clickHandler = cancelHandler;

			let bg = this.root.getChildByName('bg0') as Laya.Sprite;
			this.resizeSprList.push(bg);
			this.originHeightList.push(bg.height);
			let bound = this.root.getChildByName('bound') as Laya.Sprite;
			this.resizeSprList.push(bound);
			this.originHeightList.push(bound.height);

			this.origin_desc_height = this.info.height;

			this.resetYSprList.push(this.root.getChildByName('bg0').getChildByName('left') as Laya.Sprite);
			this.resetYSprList.push(this.root.getChildByName('bg0').getChildByName('right') as Laya.Sprite);
			this.resetYSprList.push(this.root.getChildByName('btn') as Laya.Sprite);
			for (let spr of this.resetYSprList) {
				this.originYList.push(spr.y);
			}
		}

		public show(info:string, code: number, iserror?: boolean) {
			this.setDesc(info);
			if (iserror) (this.root.getChildByName('einfo') as Laya.Text).text = app.Log.getCacheLog();
			else (this.root.getChildByName('einfo') as Laya.Text).text = '';
			if (code > 0) {
				this.code.text = game.Tools.strOfLocalization(3753, [code + '']);
			} else {
				this.code.text = '';
			}
			this.enable = true;
			this.locking = true;
			this.root.scale(1, 1);
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));	
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.enable = false;
				this.locking = false;
			}));
		}

		private setDesc(desc:string) {
			this.info.text = desc;
			
			this.info.wordWrap = true;
			
			let height = this.info.textField.textHeight;
			let ext_height = 0;
			
			this.info.valign = 'middle';
			if (height > this.info.fontSize * 1.5) {
				this.info.align = 'left';
				height = this.info.textField.textHeight;
				ext_height = Math.max(0, height - this.origin_desc_height);
			} else {
				this.info.align = 'center';
			}
			for (let i = 0; i < this.resizeSprList.length; ++i) {
				this.resizeSprList[i].height = this.originHeightList[i] + ext_height;
			}
			for (let i = 0; i < this.resetYSprList.length; ++i) {
				this.resetYSprList[i].y = this.originYList[i] + ext_height;
			}
			this.root.y = this.origin_root_y - ext_height / 2;
		}
	}
}