/**
* name 
*/
module uiscript {

	interface iAnnouncement {
		id: number;
		title: string;
		content: string;
		header_image: string;
		sort: number;
	}


	export class UI_Entrance_Info extends UIBase {

		public static Inst: UI_Entrance_Info = null;
		public static announcements: Array<iAnnouncement> = [];
		public static last_fetch_time: number;

		public static fetchAnnouncements(complete: Laya.Handler) {
			net.GatewayFetcher.fetchAnnounceList(Laya.Handler.create(this, d => {
				if (d.err) {
					app.Log.Error("fetchAnnounceList error: " + JSON.stringify(d.err));
					complete.runWith(false);
				} else {
					this.last_fetch_time = Laya.timer.currTimer;
					let _d = JSON.parse(d.res);
					if (_d && _d.data && _d.data.announce_list) {
						this.announcements = _d.data.announce_list;
						this.announcements.sort((a, b) => { 
							return b.sort - a.sort;
						})
					} else {
						this.announcements = [];
					}
					complete.runWith(true);
				}
			}));
        }

		private static _refreshAnnouncements(msg) {
			if (msg['announcements']) {
				this.announcements = msg['announcements'];
				this.announcements.sort((a, b) => { 
					return b.sort - a.sort;
				});
			}
		}

	
		public container_left: Laya.Sprite;
		public container_right: Laya.Sprite;
		public left_sroll: capsui.CScrollView;
		private loading: Laya.Label;
		private content: Laya.Panel;
		private scrollbar: capsui.CScrollBar;
		private info_parent: Laya.Sprite;
		private right_img: Laya.Image;
		private right_title: Laya.Label;
		private info: Laya.HTMLDivElement;
		private select_index: number = -1;
		private complete: Laya.Handler = null;
		private show_indexs: Array<number> = [];
		private noinfo: Laya.Sprite;
		private loading_index: number = 0;
		private loading_show_str: string;
		private height: number = 0;

		private root: Laya.Sprite;
		private locking: boolean;


		constructor() {
			super(new ui.lobby.infoUI());
			UI_Entrance_Info.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (this.locking) return;
				this.close();
			}, null, false);

			this.container_left = this.root.getChildByName('left') as Laya.Sprite;
			this.container_right = this.root.getChildByName('right') as Laya.Sprite;

			this.left_sroll = (this.root.getChildByName('left') as Laya.Sprite).scriptMap['capsui.CScrollView'];
			this.left_sroll.init_scrollview(Laya.Handler.create(this, this._renderLeft, null, false));
			this.content = this.container_right.getChildByName('content') as Laya.Panel;
			this.left_sroll.setElastic();
			this.scrollbar = (this.container_right.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
			this.scrollbar.init(null);
			this.content.vScrollBarSkin = '';
			this.content.vScrollBar.on('change', this, () => {
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / (this.info_parent.height + this.info_parent.y));
			});
			this.content.vScrollBar.elasticDistance = 350;
			this.content.vScrollBar.elasticBackTime = 250;
			this.noinfo = this.root.getChildByName('empty') as Laya.Sprite;
			this.loading = this.root.getChildByName('loading') as Laya.Label;
			this.loading_show_str = game.Tools.strOfLocalization(3448);
			this.right_img = this.content.getChildByName('img') as Laya.Image;
			this.right_title = this.content.getChildByName('title') as Laya.Label;
			this.info_parent = this.content.getChildByName('parent') as Laya.Sprite;
			if (GameMgr.client_language == 'en') {
				(this.root.getChildByName('title') as Laya.Sprite).y += 8;
			}
			// this.info = new Laya.HTMLDivElement();
			// this.info_parent.addChild(this.info);
			// this.info.pos(0, 0);


			// this.info.width = 870;
			// this.info.style.lineHeight = 36;
			// this.info.style.valign = "top";
			// this.info.style.width = 870;
			// this.info.style.align = "left";


		}

		public show(complete: Laya.Handler = null) {
			this.enable = true;
			this.complete = complete;
			this.locking = true;
			if (!UI_Entrance_Info.last_fetch_time && Laya.timer.currTimer - UI_Entrance_Info.last_fetch_time < 300000) {
				this.container_left.visible = true;
				this.loading.visible = false;
				this.noinfo.visible = false;
				this.container_right.visible = false;
				let delay: number = 0;
				this.root.visible = false;
				Laya.timer.frameOnce(delay, this, () => {
					this.show_announcements();
					this.root.visible = true;
					UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
						this.locking = false;
					}));
				});
			} else {
				UIBase.anim_pop_out(this.root, null);
				this.loading.visible = true;
				this.container_left.visible = false;
				this.noinfo.visible = true;
				this.container_right.visible = false;
				this.showLoadingText();
				Laya.timer.loop(800, this, this.showLoadingText);
                UI_Entrance_Info.fetchAnnouncements(Laya.Handler.create(this, (success: boolean)=>{
                    if (!success) {
                        UI_Entrance.Inst.showError(game.Tools.strOfLocalization(3900));
                    }
                    this.show_announcements();
                }))
			
			}

		}

		public close() {
			this.locking = true;

			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
				this.locking = false;
				this.enable = false;
				if (this.complete) this.complete.run();
			}));
		}




		private show_announcements() {
            Laya.timer.clear(this, this.showLoadingText);
			this.locking = false;
			
			this.container_left.visible = true;

			let _indexs: Array<number> = [];
			for (let i: number = 0; i < UI_Entrance_Info.announcements.length; i++) _indexs.push(i);
			

			this.show_indexs = _indexs;
			if (this.show_indexs.length == 0) {
				this.loading.visible = true;
				this.loading.text = game.Tools.strOfLocalization(3678);
			} else {
				this.loading.visible = false;
			}
			this.noinfo.visible = this.show_indexs.length == 0;
			this.container_right.visible = this.show_indexs.length > 0;
			this.select_index = 0;
			this.left_sroll.reset();
			this.left_sroll.addItem(this.show_indexs.length);

			if (this.show_indexs.length > 0) {
				this._renderRight(0, true);
			}

		}

		private _renderLeft(data: any) {
			let index: number = data.index;
			let container: Laya.Sprite = data.container;
			let _ann: iAnnouncement = UI_Entrance_Info.announcements[this.show_indexs[index]];
			let bg: Laya.Image = container.getChildByName('bg') as Laya.Image;
			bg.skin = game.Tools.localUISrc(this.select_index == index ? 'myres/info/info_title_select.png' : 'myres/info/info_title.png');
			let _new = (container.getChildByName('new') as Laya.Sprite);
			_new.visible = false;
			let title = container.getChildByName('title') as Laya.Label;
			title.text = _ann.title;
			// if (title.textField.textHeight > 40) {
			// 	title.align = 'left';
			// } else {
			// 	title.align = 'center';
			// }
			(container as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.select_index == index) return;
				let old_index = this.select_index;
				this._renderRight(index, false);
				bg.skin = game.Tools.localUISrc('myres/info/info_title_select.png');
				if (old_index >= 0) this.left_sroll.wantToRefreshItem(old_index);
			})

		}

		private _renderRight(index: number, force: boolean) {
			if (!force && this.select_index == index) return;
			let ann: iAnnouncement = UI_Entrance_Info.announcements[this.show_indexs[index]];
			this.select_index = index;
			this.right_title.text = ann.title;
			let y = 0;
			if (ann.header_image) {
				this.right_img.height = 150;
                if (ann.header_image.startsWith('internal://')) {
                    game.LoadMgr.setImgSkin(this.right_img, ann.header_image.replace('internal://', 'myres/info/'));
                }
			} else {
				this.right_img.height = 0;
			}
			y += this.right_img.height;
			this.right_title.y = y + 20;
			y += 140;
			this.info_parent.y = y;
			this.getFinalShowStr(ann.content);
			Laya.timer.frameOnce(1, this, () => {
				this.height = 0;
				for (let i = 0; i < this.info_parent.numChildren; i++) {
					let _info = this.info_parent.getChildAt(i) as Laya.HTMLDivElement;
					if (_info.visible) {
						_info.y = this.height;
						this.height += _info.contextHeight;

					}
				}
				this.info_parent.height = this.height + 10;
				this.content.refresh();
				this.content.vScrollBar.value = 0;
				this.scrollbar.setVal(this.content.vScrollBar.value / this.content.vScrollBar.max, this.content.height / (this.info_parent.height + this.info_parent.y));
			})

		}

		private getShowStr(str: string): string {
			str = game.Tools.EncodeHtmlText(str);
			let re = /\s/g;
			str = str.replace(re, "&nbsp;");
			str = "<span style='font:30px SimHei word-break:break-all' color='#d7d3d1'>" + str + "</span>";
			re = /<\/b><\/color>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei' color='#d7d3d1'>");
			re = /<\/b>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei' color='#d7d3d1'>");
			re = /<\/color>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei' color='#d7d3d1'>");
			re = /<color=(#\w+)><b>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei;font-weight:bold' color='$1'>");
			re = /<color=(#\w+)>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei' color='$1'>");
			re = /<b>/g;
			str = str.replace(re, "</span><span style='font:30px SimHei;font-weight:bold' color='#d7d3d1'>");

			return str;
		}

		private getFinalShowStr(str: string) {
			let lst = str.split('\n');
			let i = 0;
			for (; i < lst.length; i++) {
				let info: Laya.HTMLDivElement;
				if (this.info_parent.numChildren <= i) {
					info = new Laya.HTMLDivElement();
					this.info_parent.addChild(info);
					info.pos(0, this.height);


					info.width = 870;
					info.style.lineHeight = 36;
					info.style.valign = "top";
					info.style.width = 870;
					info.style.align = "left";

				} else {
					info = this.info_parent.getChildAt(i) as Laya.HTMLDivElement;
					info.visible = true;
				}
				try {
					if (lst[i].indexOf('<href') != -1) {
						let str = game.Tools.EncodeHtmlText(lst[i]);
						let re = /<href=(.+?)>/g;
						str = str.replace(re, "<span style='font:30px SimHei' color='#51f1ff' href='$1'>").replace('/href', '/span');
						info.innerHTML = str;
						info.off(Laya.Event.LINK, this, this.onLinkSurvey);
						info.on(Laya.Event.LINK, this, this.onLink);
					} else if (lst[i].indexOf('<survey') != -1) {
						let str = game.Tools.EncodeHtmlText(lst[i]);
						let re = /<survey=(.+?)>/g;
						str = str.replace(re, "<span style='font:30px SimHei' color='#51f1ff' href='$1'>").replace('/survey', '/span');
						info.innerHTML = str;
						info.off(Laya.Event.LINK, this, this.onLink);
						info.on(Laya.Event.LINK, this, this.onLinkSurvey);
					
					} else {
						info.innerHTML = this.getShowStr(lst[i]);
						info.off(Laya.Event.LINK, this, this.onLinkSurvey);
						info.off(Laya.Event.LINK, this, this.onLink);
					}
					// info.innerHTML = this.getShowStr(lst[i]);
				} catch (e) {
					app.Log.Error('公告错误:' + lst[i]);
				}
			}
			for (; i < this.info_parent.numChildren; i++) {
				(this.info_parent.getChildAt(i) as Laya.HTMLDivElement).visible = false;
			}

		}

		private showLoadingText() {
			this.loading_index = ++this.loading_index > 3 ? 1 : this.loading_index;
			let showStr = this.loading_show_str;
			for (let i = 0; i < this.loading_index; i++) {
				showStr += '.';
			}
			this.loading.text = showStr;
		}

		public onDisable() {
			let atlas_root = 'res/atlas/';
			if (GameMgr.client_language != 'chs') {
				atlas_root += GameMgr.client_language + '/';
			}
			Laya.loader.clearTextureRes(atlas_root + 'myres/info.atlas');
		}

		private onLink(url: string) {
			url.replace(/&amp;/g, '&');
			if (!Laya.Browser.onPC) {
				Laya.Browser.window.location.href = url;
			} else {
				game.Tools.open_new_window(url);
			}
		}
		private onLinkSurvey(url: string) {
			if (!Yo) return;
			url.replace(/&amp;/g, '&');
			game.YoStarSDK.Inst.showSurvey({
				activityID: url,
				gameUID: String(GameMgr.Inst.account_id),
				gameNotifyURL:""
			});
			// Yo.survey({
			// 	accessToken: GameMgr.Inst.yostar_accessToken,
			// 	activity: url, // 问卷id，获取方式为可由邮件等，由运营配置
			// 	gameid: GameMgr.Inst.yostar_uid, // 游戏id，相同问卷id不可重复提交问卷
			// }).then(data0 => {
			// 	if (data0.result === 0) {
			// 		this.onLink(data0.wj_url);
			// 	} else {
				
			// 	}
			// });
		}
	}
}