/**
* name 
*/
module uiscript{

	class TxtInput {
		public me:Laya.Sprite;
		private txtinput:Laya.TextInput;
		public wrong:Laya.Sprite;
		public accept:Laya.Sprite;
		private func_pending: Laya.Handler;
		public func_unfocus: Laya.Handler;

		public get text() { return this.txtinput.text; }

		public get isOK() { return !this.func_pending || this.func_pending.run(); }

		public constructor(me: Laya.Sprite, func_pending: Laya.Handler, func_unfocus: Laya.Handler = null) {
			this.me = me;
			this.func_pending = func_pending;
			this.func_unfocus = func_unfocus;
			this.txtinput = me.getChildByName('txtinput') as Laya.TextInput;
			this.wrong = me.getChildByName('no') as Laya.Sprite;
			this.accept = me.getChildByName('yes') as Laya.Sprite;
			this.txtinput.on('focus', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
			});
			this.txtinput.on('blur', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
				if (this.txtinput.text != '') {
					if (!this.func_pending || this.func_pending.run()) {
						this.accept.visible = true;
					} else {
						this.wrong.visible = true;
					}
				}
				this.func_unfocus?.run();
			});
			this.reset();
		}

		public showError() {
			this.accept.visible = false;
			this.wrong.visible = true;
		}

		public reset() {
			this.txtinput.text = '';
			this.wrong.visible = false;
			this.accept.visible = false;
		}

		public set focus(value: boolean) {
			this.txtinput.focus = value;
		}

		public refresh() { 
			this.wrong.visible = false;
			this.accept.visible = false;
			if (this.txtinput.text != '') {
				if (!this.func_pending || this.func_pending.run()) {
					this.accept.visible = true;
				} else {
					this.wrong.visible = true;
				}
			}
		}
	}

	export class UI_Entrance_Mail_Regist extends UIBase {

		public static Inst:UI_Entrance_Mail_Regist;

		private root:Laya.Sprite;
		
		private content:Laya.Sprite;
		private account:TxtInput;
		private password0:TxtInput;
		private password1:TxtInput;
		private code_input:TxtInput;
		private btn_close:Laya.Button;
		private btn_regist:Laya.Button;
		private container_social:Laya.Sprite;
		private social_btns:Array<Laya.Button>;
		private container_checkbox:Laya.Sprite;
		private checkbox:Laya.Sprite;
		private connect_loading:Laya.Sprite;
		private btn_send_code:Laya.Button;
		private label_send_code:Laya.Label;

		private locking:boolean;
		private during_send_cd:boolean = false;
		private last_send_time:number = 0;
		private action_version: number = 0;

		public constructor() {
			super(new ui.entrance.mail_registUI());
			UI_Entrance_Mail_Regist.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('page_mail_regist') as Laya.Sprite;
			this.connect_loading = this.me.getChildByName('loading') as Laya.Sprite;
			this.connect_loading.visible = false;

			this.content = this.root.getChildByName('root') as Laya.Sprite;
			this.account = new TxtInput(this.content.getChildByName('container_account') as Laya.Sprite, new Laya.Handler(this, ()=>{
				return game.Tools.pending_email_vaild(this.account.text);
			}));
			this.password0 = new TxtInput(this.content.getChildByName('container_mima') as Laya.Sprite, new Laya.Handler(this, ()=>{
				let str:string = this.password0.text;
				return str.length >= 6 && str.length <= 20;
			}), new Laya.Handler(this, ()=>{
				this.password1.refresh();
			}));
			this.password1 = new TxtInput(this.content.getChildByName('container_mima2') as Laya.Sprite, new Laya.Handler(this, ()=>{
				if (this.password0.text != this.password1.text) return false;
				return  this.password1.text.length >= 6 && this.password1.text.length <= 20;
			}));			
			this.code_input = new TxtInput(this.content.getChildByName('container_code') as Laya.Sprite, new Laya.Handler(this, ()=>{
				return this.code_input.text.length == 6;
			}));

			this.btn_close = this.content.getChildByName('btn_close') as Laya.Button;
			this.btn_close.clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.close();
			}, null, false);
			(this.content.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.close();
			}, null, false);
			this.btn_regist = this.content.getChildByName('btn_regist') as Laya.Button;
			this.btn_regist.clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.onRegist();
			}, null, false);

			this.btn_send_code = this.content.getChildByName('btn_send_code') as Laya.Button;
			this.label_send_code = this.btn_send_code.getChildByName('info') as Laya.Label;

			this.btn_send_code.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return ;
				if (this.account.text == '') {
					this.account.showError();
					return;
				}
				if (!this.account.isOK) return;
				
				this.btn_send_code.mouseEnabled = false;
				this.during_send_cd = true;
				this.last_send_time = Laya.timer.currTimer;
				this.refresh_send();

				let str = this.account.text;
				let type:string = '';
				if (game.Tools.pending_email_vaild(str)) type = 'email';
				// if (game.Tools.pending_phonenumber_valid(str)) type = 'phone';
				var xhr = new Laya.HttpRequest();
				xhr.once(Laya.Event.COMPLETE,this, (data)=>{
					let d = JSON.parse(data);
					if (d.error && d.error.code) {
						this.onPanelShow();
						UI_Entrance.Inst.showError('', d.error.code);
						this.last_send_time = 0;
					} else {
						if (type == 'email') UI_Entrance.Inst.showInfo(game.Tools.strOfLocalization(2810));
						// if (type == 'phone') UI_Entrance.Inst.showInfo(game.Tools.strOfLocalization(2833));
					}
				});
				xhr.once(Laya.Event.ERROR,this, (e)=>{
					this.onPanelShow();
					UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(2790), 0, false);
					this.last_send_time = 0;
				});
				if (type == 'email') {
					xhr.send(GameMgr.system_email_url + '/api/user/sign_up_code', `type=email&email=${str}`, "post");
				}
				//  else if (type == 'phone') {
				// 	xhr.send(GameMgr.system_email_url + '/api/user/sign_up_code', `type=phone&phone=${str}`, "post");
				// }
			});
			
			this.root.visible = false;
			this.locking = false;

			this.container_social = this.content.getChildByName('social') as Laya.Sprite;
			this.social_btns = [];
			for (let i = 0; i < 4; i++) {
				this.social_btns.push(this.container_social.getChildByName('btn' + i) as Laya.Button);
				this.social_btns[i].visible = false;
			}
			let social_datas = [];
			if (GameMgr.client_type == 'chs') {
				social_datas = [
					{ img: "myres/entrance/weibo.png", type: 2 },
					{ img: "myres/entrance/QQ.png", type: 3 },
					{ img: "myres/entrance/weixin.png", type: 1 },
				];
			}
			if (GameMgr.client_type == 'chs_t') {
				social_datas = [
					{ img: GameMgr.client_language == 'chs_t' ? "myres/entrance/facebook_chs.png" : "myres/entrance/facebook.png", type: 13 },
					{ img: GameMgr.client_language == 'chs_t' ? "myres/entrance/google_chs.png" : "myres/entrance/google.png", type: 20 },
				];
			}
			for (let i:number = 0; i < social_datas.length; i++) {
				let btn:Laya.Button = this.social_btns[i];
				
				if (i < social_datas.length) {
					btn.visible = true;
					(btn.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc(social_datas[i].img);
					btn.clickHandler = new Laya.Handler(this, ()=>{
						UI_Entrance.trySocio(social_datas[i].type);
					});
					btn.x = (i - (social_datas.length - 1) / 2) * 155 + 252;
				} else {
					btn.visible = false;
				}
			}

			(this.content.getChildByName('checkbox') as Laya.Sprite).visible = GameMgr.client_type == 'chs';
			(this.content.getChildByName('checkbox_chst') as Laya.Sprite).visible = GameMgr.client_type == 'chs_t';

			if (GameMgr.client_type == 'chs') {
				this.container_checkbox = this.content.getChildByName('checkbox') as Laya.Sprite;
				this.container_checkbox.visible = true;
				this.checkbox = this.container_checkbox.getChildByName('checkbox') as Laya.Sprite;
				(this.container_checkbox.getChildByName('btn_lock') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
					UI_User_Xieyi.Inst.show(Laya.Handler.create(this, ()=>{
						this.onchangecheck(true);
					}));
				}, null, false);
				(this.container_checkbox.getChildByName('btn_check') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
					this.onchangecheck(!this.checkbox.visible);
				}, null, false);
			} else if (GameMgr.client_type == 'chs_t'){
				this.container_checkbox = this.content.getChildByName('checkbox_chst') as Laya.Sprite;
				this.container_checkbox.visible = true;
				this.checkbox = this.container_checkbox.getChildByName('checkbox') as Laya.Sprite;
				(this.container_checkbox.getChildByName('btn_lock0') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
					UI_User_Xieyi_enjp.Inst.show(`docs/chs_t/fuwuxieyi_${GameMgr.client_language}.txt`);
				}, null, false);
				(this.container_checkbox.getChildByName('btn_lock1') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
					UI_User_Xieyi_enjp.Inst.show(`docs/chs_t/yinsitiaokuan_${GameMgr.client_language}.txt`);
				}, null, false);
				(this.container_checkbox.getChildByName('btn_check') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
					this.onchangecheck(!this.checkbox.visible);
				}, null, false);
			}


			this.account.reset();
			this.password0.reset();
			this.password1.reset();
			this.last_send_time = 0;
		}

		public close(){
			this.action_version++;
			this.locking = true;
			UIBase.anim_pop_hide(this.content, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
			Laya.timer.clearAll(this);
		}

		public show() {
			this.root.visible = true;
			this.locking = true;
			Laya.timer.clearAll(this);
			this.enable = true;
			UIBase.anim_pop_out(this.content, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));

			this.connect_loading.visible = false;
			this.onchangecheck(true);
			if (!this.during_send_cd) {
				this.during_send_cd = false;
				this.btn_send_code.mouseEnabled = true;
				this.label_send_code.text = game.Tools.strOfLocalization(2787);
			} else {
				this.refresh_send();
			}
			
			Laya.timer.frameLoop(1, this, ()=>{
				this.refresh_send();
			});
		}

		private onRegist() {
			let _account:string = this.account.text;
			let _code:string = this.code_input.text;
			let _pwd0:string = this.password0.text;
			let _pwd1:string = this.password1.text;

			if (_account == '') {
				this.account.showError();
			}
			if (_code == '') {
				this.code_input.showError();
			}
			if (_pwd0 == '') {
				this.password0.showError();
			}
			if (_pwd1 == '') {
				this.password1.showError();
			}

			if (!this.account.isOK || !this.code_input.isOK || !this.password0.isOK || !this.password1.isOK) {
				return;
			}

			let type: number = 0;
			if (game.Tools.pending_email_vaild(_account)) type = 1;
			if (game.Tools.pending_phonenumber_valid(_account)) type = 2;

			this.action_version++;
			let action_version:number = this.action_version;
			this.connect_loading.visible = true;

			let onNetOK = () => {
				if (this.action_version != action_version) return;
				UI_Entrance.Inst.try_regist_account(_account, _code, _pwd0, type, Laya.Handler.create(this, ()=>{
					if (this.action_version != action_version) return;
					this.connect_loading.visible = false;
				}));
			};

			UI_Entrance.ensureNetwork(onNetOK, () => {
				if (this.action_version != action_version) return;
				this.connect_loading.visible = false;
			});
		}

		private onchangecheck(f:boolean) {
			this.checkbox.visible = f;
			this.btn_regist.visible = f;
			this.container_social.visible = f;
		}

		private refresh_send() {
			if (!this.during_send_cd) return;
			let t:number = Laya.timer.currTimer - this.last_send_time;
			if (t >= 60 * 1000) {
				this.during_send_cd = false;
				this.btn_send_code.mouseEnabled = true;
				this.label_send_code.text = game.Tools.strOfLocalization(2787);
			} else {
				this.label_send_code.text = game.Tools.strOfLocalization(2682, [Math.ceil(60 - t / 1000).toString()]);
			}
		}

		private onPanelShow() {
			this.code_input.focus = false;
			this.password0.focus = false;
			this.password1.focus = false;
		}
	}
}