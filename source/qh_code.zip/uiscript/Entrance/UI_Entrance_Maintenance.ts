/**
* name 
*/
module uiscript{
	export class UI_Entrance_Maintenance extends UIBase {

		public static Inst:UI_Entrance_Maintenance;

		public root: Laya.Sprite;
		public info: Laya.Label;

		public constructor() {
			super (new ui.entrance.maintenanceUI());
			UI_Entrance_Maintenance.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('maintenance').getChildByName('container') as Laya.Sprite;
			this.info = this.root.getChildByName('text') as Laya.Label;
			this.me.visible = false;
			(this.root.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				this.close();
			}, null, false);
		}

		public show(info:string) {
			this.info.text = info;
			if (this.info.textField.textHeight > 1.5 * this.info.fontSize) {
				this.info.align = 'left';
			} else {
				this.info.align = 'center';
			}
			this.me.visible = true;
			UIBase.anim_pop_out(this.root, null);	
		}

		public close() {
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.me.visible = false;
			}));
		}
	}
}