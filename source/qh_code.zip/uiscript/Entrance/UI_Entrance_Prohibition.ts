/**
* name 
*/
module uiscript{
	export class UI_Entrance_Prohibition extends UIBase {

		public static Inst:UI_Entrance_Prohibition;

		public root: Laya.Sprite;
		public info: Laya.Label;

		public constructor() {
			super(GameMgr.client_type == 'jp' ? new ui.entrance.account_prohibition_midUI() : new ui.entrance.account_prohibitionUI());
			UI_Entrance_Prohibition.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('Prohibition').getChildByName('container') as Laya.Sprite;
			this.info = this.root.getChildByName('text') as Laya.Label;
			this.me.visible = false;
			(this.root.getChildByName('btn').getChildAt(0) as Laya.Sprite).y += GameMgr.client_language == 'kr' ? 4 : 0;
			(this.root.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				this.close();
			}, null, false);
		}

		public show(res) {
			let type:number = 0;
			if (res['u32_params'] && res['u32_params'].length >= 1) {
				type = res['u32_params'][0];
			}
			// 因为挂机被封号
			if (type == 1) {
				let d:Object = {};
				d['type'] = 2;
				d['ban_end_time'] = res['u32_params'][1] + res['u32_params'][2];
				game.Tools.showGuaJiChengFa(d);
				return;
			} else if (type == 3) {
				this.set_desc(game.Tools.strOfLocalization(3161));
			} else if(type == 5 || type == 4) {
				let s:string = game.Tools.strOfLocalization(2064) + '\n';
				// s += '封禁时间：' + game.Tools.time2YearMounthDate(res['u32_params'][0]) + ' ' + game.Tools.time2HourMinute(res['u32_params'][0]) + '\n';
				// if (res['u32_params'] && res['u32_params'].length >= 2) {
				// 	if (res['u32_params'][2] == 0) {
				// 		s += game.Tools.strOfLocalization(2065) + '\n';
				// 	} else {
				// 		let open_time = res['u32_params'][1] + res['u32_params'][2];
				// 		s += game.Tools.strOfLocalization(2066) + game.Tools.time2YearMounthDate(open_time) + ' ' + game.Tools.time2HourMinute(open_time) + '\n';
				// 	}
				// }
			
				s += game.Tools.strOfLocalization(2067) + game.Tools.strOfLocalization(3439);
				
				this.set_desc(s);
			} else if (type == 6) {
				let s:string = game.Tools.strOfLocalization(8015, [game.Tools.time2YearMounthDate(res['u32_params'][1]) + ' ' + game.Tools.time2HourMinute(res['u32_params'][1], true)]);
				this.set_desc(s);
			} else {
				let s:string = game.Tools.strOfLocalization(2064) + '\n';
				// s += '封禁时间：' + game.Tools.time2YearMounthDate(res['u32_params'][0]) + ' ' + game.Tools.time2HourMinute(res['u32_params'][0]) + '\n';
				if (res['u32_params'] && res['u32_params'].length >= 2) {
					if (res['u32_params'][2] == 0) {
						s += game.Tools.strOfLocalization(2065) + '\n';
					} else {
						let open_time = res['u32_params'][1] + res['u32_params'][2];
						s += game.Tools.strOfLocalization(2066) + game.Tools.time2YearMounthDate(open_time) + ' ' + game.Tools.time2HourMinute(open_time) + '\n';
					}
				}
				if (res['str_params'] && res['str_params'].length > 0) {
					s += game.Tools.strOfLocalization(2067) + res['str_params'][0];
				}
				this.set_desc(s);
			}


			this.me.visible = true;
			UIBase.anim_pop_out(this.root, null);	
		}

		protected set_desc(desc:string) {
			this.info.text = desc;
			if (this.info.textField.textHeight > 1.5 * this.info.fontSize) {
				this.info.align = 'left';
			} else {
				this.info.align = 'center';
			}
		}

		public close() {
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.me.visible = false;
			}));
		}
	}
}