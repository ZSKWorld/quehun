/**
* name 
*/
module uiscript{
	export class UI_Entrance_Queue extends UIBase {

		public static Inst:UI_Entrance_Queue;

		private root: Laya.Sprite;
		private locking: boolean;
		private label_time: Laya.Label;
		private label_rank: Laya.Label;
		private _rank: number;

		public constructor() {
			super(new ui.entrance.login_queueUI());
			UI_Entrance_Queue.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('error').getChildByName('container') as Laya.Sprite;
			this.label_time = this.root.getChildByName('time') as Laya.Label;
            // this.desc = this.root.getChildByName('desc') as Laya.Label;
			this.label_rank = this.root.getChildByName('rank') as Laya.Label;
			(this.root.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				UI_Entrance.Inst.onCancelQueue();
				this.close();
			}, null, false);

			if (GameMgr.client_language == 'en') {
				let offset_x = 140;
				(this.root.getChildByName('title1') as Laya.Sprite).x += offset_x;
				(this.root.getChildByName('title2') as Laya.Sprite).x += offset_x;
				(this.root.getChildByName('time') as Laya.Sprite).x += offset_x;

				(this.root.getChildByName('title0') as Laya.Sprite).x -= 20;
				(this.root.getChildByName('rank') as Laya.Sprite).x -= 20;
			}
		}

		public show(time: number, rank: number) {
			this._rank = rank;
			if (this._rank > 999) {
				this.label_rank.text = '999+';
			} else {
				this.label_rank.text = rank + '';
			}
			let _time = Math.ceil(time / 60);
			if (_time > 60) {
				this.label_time.text = '60+';
			} else {
				this.label_time.text = _time + '';
			}
			
            Laya.timer.loop(10 * 1000, this, this.fetchQueueInfo); // 每分钟重新拉排队信息
			this.enable = true;
			UIBase.anim_pop_out(this.root, null);	
		}

		public close() {
            Laya.timer.clearAll(this);
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				Laya.timer.clearAll(this);
				this.enable = false;
			}));
		}

       

        private fetchQueueInfo() {
            app.NetAgent.sendReq2Lobby('Lobby', 'fetchQueueInfo', {}, (err, res)=>{
				if (err || res['error']) {
					Laya.timer.clearAll(this);
                    this.close();
					if (err) {
						UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(3766), 0, false);
					} else {
						UI_Entrance.Inst.showError(err, res['error'])
					}
				} else {
					let rank = res['rank'];
					if (rank < this._rank) {
						this._rank = rank;
						if (this._rank > 999) {
							this.label_rank.text = '999+';
						} else {
							this.label_rank.text = rank + '';
						}
					}
					let _time = Math.ceil(res['remain'] / 60);
					if (_time > 60) {
						this.label_time.text = '60+';
					} else {
						this.label_time.text = _time + '';
					}
				}
			});
        }
	}
}