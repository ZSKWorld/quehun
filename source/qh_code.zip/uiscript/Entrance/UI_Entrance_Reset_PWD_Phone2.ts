/**
* name 
*/
module uiscript {

	class TxtInput {
		public me:Laya.Sprite;
		private txtinput:Laya.TextInput;
		public wrong:Laya.Sprite;
		public accept:Laya.Sprite;
		private func_pending:Laya.Handler;

		public get text() { return this.txtinput.text; }

		public get isOK() { return !this.func_pending || this.func_pending.run(); }

		public constructor(me: Laya.Sprite, func_pending: Laya.Handler) {
			this.me = me;
			this.func_pending = func_pending;
			this.txtinput = me.getChildByName('txtinput') as Laya.TextInput;
			this.wrong = me.getChildByName('no') as Laya.Sprite;
			this.accept = me.getChildByName('yes') as Laya.Sprite;

			this.txtinput.on('focus', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
			});
			this.txtinput.on('blur', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
				if (this.txtinput.text != '') {
					if (!this.func_pending || this.func_pending.run()) {
						this.accept.visible = true;
					} else {
						this.wrong.visible = true;
					}
				}
			});
			this.reset();
		}

		public showError() {
			this.accept.visible = false;
			this.wrong.visible = true;
		}

		public reset() {
			this.txtinput.text = '';
			this.wrong.visible = false;
			this.accept.visible = false;
		}
	}

	export class UI_Entrance_Reset_PWD_Phone2 extends UIBase {
		
		public static Inst:UI_Entrance_Reset_PWD_Phone2;

		private root:Laya.Sprite;
		private label_phonenumber:Laya.Label;
		private input_code:TxtInput;
		private pwd0:TxtInput;
		private pwd1:TxtInput;
		private btn_send_code:Laya.Button;
		private label_send_code:Laya.Label;
		private btn_confirm:Laya.Button;

		private phonenumber:string;
		private locking:boolean;
		private during_send_cd:boolean = false;
		private last_send_time:number = 0;

		constructor() {
			super(new ui.entrance.reset_password_phone2UI());
			UI_Entrance_Reset_PWD_Phone2.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.label_phonenumber = this.root.getChildByName('phonenumber') as Laya.Label;
			this.pwd0 = new TxtInput(this.root.getChildByName('container_mima') as Laya.Sprite, new Laya.Handler(this, ()=>{
				let str:string = this.pwd0.text;
				return str.length >= 6 && str.length <= 20;
			}));
			this.pwd1 = new TxtInput(this.root.getChildByName('container_mima2') as Laya.Sprite, new Laya.Handler(this, ()=>{
				if (this.pwd1.text != this.pwd0.text) return false;
				return  this.pwd1.text.length >= 6 && this.pwd1.text.length <= 20;
			}));			
			this.input_code = new TxtInput(this.root.getChildByName('container_code') as Laya.Sprite, new Laya.Handler(this, ()=>{
				return this.input_code.text.length == 6;
			}));

			this.btn_send_code = this.root.getChildByName('btn_send_code') as Laya.Button;
			this.label_send_code = this.btn_send_code.getChildByName('info') as Laya.Label;

			this.btn_send_code.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return ;
				
				this.btn_send_code.mouseEnabled = false;
				this.during_send_cd = true;
				this.last_send_time = Laya.timer.currTimer;
				this.refresh_send();

				let str = this.phonenumber;
				var xhr = new Laya.HttpRequest();
				xhr.once(Laya.Event.COMPLETE,this, (data)=>{
					let d = JSON.parse(data);
					if (d.error && d.error.code) {
						UI_Entrance.Inst.showError('', d.error.code);
						this.last_send_time = 0;
					} else {
						UI_Entrance.Inst.showInfo(game.Tools.strOfLocalization(2833));
					}
				});
				xhr.once(Laya.Event.ERROR,this, (e)=>{
					UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(2790), 0, false);
					this.last_send_time = 0;
				});
				xhr.send(GameMgr.system_email_url + '/api/user/forget_password', `type=phone&phone=${str}`, "post"); 
			});

			this.btn_confirm = this.root.getChildByName('btn_confirm') as Laya.Button;
			this.btn_confirm.clickHandler = Laya.Handler.create(this, ()=>{
				if (this.locking) return;
				this.onComfirm();
			}, null, false);
			(this.root.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
				UI_Entrance_Reset_Password.Inst.show();
			});
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});
		}

		public show(phonenumber:string) {
			this.phonenumber = phonenumber;
			this.label_phonenumber.text = phonenumber;
			Laya.timer.clearAll(this);
			if (!this.during_send_cd) {
				this.during_send_cd = false;
				this.btn_send_code.mouseEnabled = true;
				this.label_send_code.text = game.Tools.strOfLocalization(2787);
			} else {
				this.refresh_send();
			}
			
			Laya.timer.frameLoop(1, this, ()=>{
				this.refresh_send();
			});

			this.locking = true;
			this.enable = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
			
		}

		public close() {
			this.locking = true;
			Laya.timer.clearAll(this);
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
		}

		private refresh_send() {
			if (!this.during_send_cd) return;
			let t:number = Laya.timer.currTimer - this.last_send_time;
			if (t >= 60 * 1000) {
				this.during_send_cd = false;
				this.btn_send_code.mouseEnabled = true;
				this.label_send_code.text = game.Tools.strOfLocalization(2787);
			} else {
				this.label_send_code.text = game.Tools.strOfLocalization(2682, [Math.ceil(60 - t / 1000).toString()]);
			}
		}

		private onComfirm() {
			
			let _code:string = this.input_code.text;
			let _pwd0:string = this.pwd0.text;
			let _pwd1:string = this.pwd1.text;

			if (_code == '') {
				this.input_code.showError();
			}
			if (_pwd0 == '') {
				this.pwd0.showError();
			}
			if (_pwd1 == '') {
				this.pwd1.showError();
			}

			if (!this.input_code.isOK || !this.pwd0.isOK || !this.pwd1.isOK) {
				return;
			}

			var xhr = new Laya.HttpRequest();
			xhr.once(Laya.Event.COMPLETE,this, (data)=>{
				let d = JSON.parse(data);
				if (d.error && d.error.code) {
					UI_Entrance.Inst.showError('', d.error.code);
					this.last_send_time = 0;
				} else {
					UI_Entrance.Inst.showInfo(game.Tools.strOfLocalization(2834));
					this.close();
				}
			});
			xhr.once(Laya.Event.ERROR,this, (e)=>{
				UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(2790), 0, false);
				this.last_send_time = 0;
			});
			xhr.send(GameMgr.system_email_url + '/api/user/reset_password/phone',
			 `phone=${this.phonenumber}&code=${this.input_code.text}&pass=${GameMgr.encodeP(this.pwd0.text)}`,
			 "post"); 
		}
	}
}