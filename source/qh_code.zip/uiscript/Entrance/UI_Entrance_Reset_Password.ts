/**
* name 
*/
module uiscript{

	class TxtInput {
		public me:Laya.Sprite;
		private txtinput:Laya.TextInput;
		public wrong:Laya.Sprite;
		public accept:Laya.Sprite;
		private func_pending:Laya.Handler;

		public get text() { return this.txtinput.text; }

		public get isOK() { return !this.func_pending || this.func_pending.run(); }

		public constructor(me: Laya.Sprite, func_pending: Laya.Handler) {
			this.me = me;
			this.func_pending = func_pending;
			this.txtinput = me.getChildByName('txtinput') as Laya.TextInput;
			this.wrong = me.getChildByName('no') as Laya.Sprite;
			this.accept = me.getChildByName('yes') as Laya.Sprite;

			this.txtinput.on('focus', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
			});
			this.txtinput.on('blur', this, ()=>{
				this.wrong.visible = false;
				this.accept.visible = false;
				if (this.txtinput.text != '') {
					if (this.isOK) {
						this.accept.visible = true;
					} else {
						this.wrong.visible = true;
					}
				}
			});
			this.reset();
		}

		public reset() {
			this.txtinput.text = '';
			this.wrong.visible = false;
			this.accept.visible = false;
		}
	}

	export class UI_Entrance_Reset_Password extends UIBase {

		public static Inst:UI_Entrance_Reset_Password;

		private root:Laya.Sprite;
		private container_input_mail:Laya.Sprite;
		private btn_send:Laya.Button;
		private input_email:TxtInput;
		
		private container_success:Laya.Sprite;
		private label_email:Laya.Label;

		private locking:boolean;
		private sended:boolean = false;

		constructor() {
			super (new ui.entrance.reset_passwordUI());
			UI_Entrance_Reset_Password.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('page_reset_password').getChildByName('root') as Laya.Sprite;
			this.container_input_mail = this.root.getChildByName('container_input_mail') as Laya.Sprite;
			this.btn_send = this.container_input_mail.getChildByName('btn_send') as Laya.Button;
			let during_send:boolean = false;
			let try_send_time:number = 0;
			let cd_time:number = 0;
			let pending_btn_state = ()=>{
				if (during_send) return;
				if (Laya.timer.currTimer < cd_time) return;
				game.Tools.setGrayDisable(this.btn_send, false);
			};

			this.btn_send.clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return; 
				if (this.input_email.text == '' || !this.input_email.isOK) return;
				if (game.Tools.pending_phonenumber_valid(this.input_email.text)) {
					this.close();
					UI_Entrance_Reset_PWD_Phone2.Inst.show(this.input_email.text);
					return;
				}
				if (during_send) return;
				game.Tools.setGrayDisable(this.btn_send, true);
				during_send = true;
				try_send_time++;
				cd_time = Laya.timer.currTimer + try_send_time * 1300;
				Laya.timer.once(try_send_time * 1300 , this, ()=>{
					pending_btn_state();
				});
				// 发送重置密码邮件
				let str = this.input_email.text;
				var xhr = new Laya.HttpRequest();
				xhr.once(Laya.Event.COMPLETE,this, (data)=>{
					let d = JSON.parse(data);
					during_send = false;
					pending_btn_state();
					if (d.error && d.error.code) {
						UI_Entrance.Inst.showError('', d.error.code);
					} else {
						this.sended = true;
						this.label_email.text = game.Tools.encode_email(str);
						this.refresh_show();
					}
				});
				xhr.once(Laya.Event.ERROR,this, (e)=>{
					during_send = false;
					pending_btn_state();
					UI_Entrance_Error.Inst.show(game.Tools.strOfLocalization(2790), 0, false);
				});
            	xhr.send(GameMgr.system_email_url + '/api/user/forget_password', `email=${this.input_email.text}`, "post");
			});
			this.input_email = new TxtInput(this.container_input_mail.getChildByName('container_account') as Laya.Sprite, new Laya.Handler(this, ()=>{
				return game.Tools.pending_email_vaild(this.input_email.text) /*|| game.Tools.pending_phonenumber_valid(this.input_email.text)*/;
			}));
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});
			(this.root.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});
			(this.root.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				if (this.sended) {
					this.sended = false;
					this.refresh_show();
				} else {
					this.close();
				}
			});

			this.container_success = this.root.getChildByName('container_success') as Laya.Sprite;
			(this.container_success.getChildByName('btn_confirm') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});
			this.label_email = this.container_success.getChildByName('mail') as Laya.Label;
		}

		public show() {
			this.sended = false;
			this.refresh_show();
			this.locking = true;
			this.enable = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
		}

		private refresh_show() {
			if (!this.sended) {
				this.container_input_mail.visible = true;
				this.container_success.visible = false;
			} else {
				this.container_input_mail.visible = false;
				this.container_success.visible = true;
			}
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
		}
	}
}