/**
* name 
*/
module uiscript {
	class LoginType {
		public me: Laya.Sprite;
		public imgNewPlayerSelected: Laya.Image;
		public imgOldPlayerSelected: Laya.Image;
		constructor(me: Laya.Sprite) {
			this.me = me;
			(me.getChildByName('btn_confirm') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (this.imgNewPlayerSelected.visible) {
					const { loginIndex, sociotype, accessToken } = UI_Entrance_Third_Bind_Email.Inst;
					UI_Entrance.Inst._try_regist_socio(loginIndex, sociotype, accessToken);
					UI_Entrance_Third_Bind_Email.Inst.close();
				} else if (this.imgOldPlayerSelected.visible) {
					this.close();
					UI_Entrance_Third_Bind_Email.Inst.confirmBind.show();
				}
			}, null, false);
			(me.getChildByName('btn_cancel') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				UI_Entrance_Third_Bind_Email.Inst.close();
			}, null, false);
			const btnNewPlayer = me.getChildByName('btn_new_player') as Laya.Button;
			const btnOldPlayer = me.getChildByName('btn_old_player') as Laya.Button;
			this.imgNewPlayerSelected = btnNewPlayer.getChildByName('select') as Laya.Image;
			this.imgOldPlayerSelected = btnOldPlayer.getChildByName('select') as Laya.Image;
			btnNewPlayer.clickHandler = Laya.Handler.create(this, this.refreshSelect, [1], false);
			btnOldPlayer.clickHandler = Laya.Handler.create(this, this.refreshSelect, [2], false);
		}

		show() {
			UI_Entrance_Third_Bind_Email.Inst.changeTitle(20220);
			this.refreshSelect(0);
			this.me.visible = true;
		}

		close() {
			this.me.visible = false;
		}

		private refreshSelect(select: 0 | 1 | 2) {
			this.imgNewPlayerSelected.visible = select == 1;
			this.imgOldPlayerSelected.visible = select == 2;
		}
	}

	class ConfirmBind {
		public me: Laya.Sprite;
		public account: Laya.Sprite;
		public submit: Laya.Sprite;
		public inputAccount: Laya.Input;
		public inputPassword: Laya.Input;
		public level: UI_Level;
		public level3: UI_Level;
		public name: Laya.Sprite;
		private loginRes: game.IResLogin;
		private loginData: game.IResLogin;
		constructor(me: Laya.Sprite) {
			this.me = me;
			this.account = me.getChildByName('account') as Laya.Sprite;
			this.submit = me.getChildByName('submit') as Laya.Sprite;
			this.inputAccount = this.account.getChildByName('email') as Laya.Input;
			this.inputPassword = this.account.getChildByName('password') as Laya.Input;
			(this.account.getChildByName('btn_next') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (UI_Entrance_Third_Bind_Email.Inst.lockMain) return;
				UI_Entrance_Third_Bind_Email.Inst.lockMain = true;

				if (UI_Entrance.Inst.multiLogin()) {
					UI_Entrance.Inst.showInfo(game.Tools.strOfLocalization(2058));
					return;
				}
				const account = this.inputAccount.text;
				const password = this.inputPassword.text;

				app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.login, {
					account: account,
					password: GameMgr.encodeP(password),
					reconnect: false,
					device: GameMgr.Inst.get_device_info(),
					random_key: GameMgr.device_id,
					client_version: {
						resource: game.ResourceVersion.version,
					},
					gen_access_token: true,
					currency_platforms: game.Tools.get_platform_currency(),
					type: 0,
					client_version_string: GameMgr.Inst.getClientVersion(),
					tag: GameMgr.Inst.getReportClientType()
				}, (err, res: game.IResLogin) => {
					UI_Entrance_Third_Bind_Email.Inst.lockMain = false;
					if (err) {
						UI_Entrance.Inst.showError(game.Tools.strOfLocalization(2061), err);
					} else if (res['error']) {
						UI_Entrance.Inst.showError('', res['error']['code']);
					} else {
						this.loginRes = res;
						this.loginData = res['toJSON']();
						this.loginData.account.verified = 0;
						this.refreshSubmit();
					}
				});
			}, null, false);
			this.level = new UI_Level(this.submit.getChildByName('rank1') as Laya.Sprite, '');
			this.level3 = new UI_Level(this.submit.getChildByName('rank2') as Laya.Sprite, '');
			this.name = this.submit.getChildByName('name') as Laya.Sprite;

			(this.submit.getChildByName('btn_confirm') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (UI_Entrance_Third_Bind_Email.Inst.lockMain) return;
				UI_Entrance_Third_Bind_Email.Inst.lockMain = true;
				const { sociotype, code } = UI_Entrance_Third_Bind_Email.Inst;
				const param: game.IReqBindOauth2 = { type: sociotype, token: code };
				app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.bindOauth2, param, (err, res: game.IResCommon) => {
					UI_Entrance_Third_Bind_Email.Inst.lockMain = false;
					if (err || res.error) {
						uiscript.UIMgr.Inst.showNetReqError('bindOauth2', err, res);
					} else {
						const { inputAccount, inputPassword, loginRes } = this;
						const account = inputAccount.text;
						const password = inputPassword.text;
						Laya.LocalStorage.setItem('_pre_sociotype', '0');
						game.LocalStorage.setItem('account', account);
						game.LocalStorage.setItem('password', password);
						game.LocalStorage.setItem('login_type_tab', '0');
						game.LoginMgr.account = account;
						game.LoginMgr.password = password;
						game.LoginMgr.sociotype = 0;
						GameMgr.country = loginRes.country;
						GameMgr.Inst.account_id = loginRes.account_id;
						GameMgr.Inst.account_data = loginRes.account;

						this.loginData = this.loginRes = null;
						UI_Entrance_Third_Bind_Email.Inst.close();
						UI_Entrance.Inst._onLoginSuccess(0, loginRes);
					}
				});
			}, null, false);
			(this.submit.getChildByName('btn_cancel') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
				if (UI_Entrance_Third_Bind_Email.Inst.lockMain) return;
				UI_Entrance_Third_Bind_Email.Inst.close();
			}, null, false);
		}
		show() {
			UI_Entrance_Third_Bind_Email.Inst.changeTitle(20225);
			this.refreshAccount();
			this.me.visible = true;
		}

		close() {
			this.me.visible = false;
			if (this.loginData) {
				this.loginRes = null;
				this.loginData = null;
				net.NetRouteGroup_Entrance.Inst.close();
				net.NetRouteGroup_Entrance.Inst.connect(null);
			}
		}

		private refreshAccount() {
			this.inputAccount.text = '';
			this.inputPassword.text = '';
			this.account.visible = true;
			this.submit.visible = false;
		}

		private refreshSubmit() {
			game.Tools.SetNickname(this.name, this.loginData.account);
			this.level.id = this.loginData.account.level.id;
			this.level3.id = this.loginData.account.level3.id;
			this.account.visible = false;
			this.submit.visible = true;
		}
	}
	export class UI_Entrance_Third_Bind_Email extends UIBase {

		public static Inst: UI_Entrance_Third_Bind_Email;

		public lockMain: boolean = false;
		public root: Laya.Sprite;
		public title: Laya.Label;
		public loginType: LoginType;
		public confirmBind: ConfirmBind;


		public loginIndex: number;
		public sociotype: number;
		public accessToken: string;
		public code: string;

		public constructor() {
			super(new ui.entrance.third_bind_emailUI());
			UI_Entrance_Third_Bind_Email.Inst = this;
		}

		public onCreate() {
			const closeHandler = Laya.Handler.create(this, () => {
				if (this.lockMain) return;
				this.close();
			}, null, false);
			(this.me.getChildByName('bg') as Laya.Button).clickHandler = closeHandler;
			const root = this.root = this.me.getChildByName('root') as Laya.Sprite;
			(root.getChildByName('close') as Laya.Button).clickHandler = closeHandler;
			this.title = root.getChildByName('title') as Laya.Label;
			this.loginType = new LoginType(root.getChildByName('login_type') as Laya.Sprite);
			this.confirmBind = new ConfirmBind(root.getChildByName('confirm_bind') as Laya.Sprite);
		}

		public show(login_index: number, sociotype: number, access_token: string, code: string = '') {
			this.loginIndex = login_index;
			this.sociotype = sociotype;
			this.accessToken = access_token;
			this.code = code;
			this.lockMain = true;
			this.loginType.show();
			this.confirmBind.close();
			this.me.visible = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
				this.lockMain = false;
			}));
		}

		public close() {
			this.lockMain = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
				this.loginType.close();
				this.confirmBind.close();
				this.me.visible = false;
				this.lockMain = false;
			}));
		}

		public changeTitle(id: number) {
			this.title.text = game.Tools.strOfLocalization(id);
		}
	}
}