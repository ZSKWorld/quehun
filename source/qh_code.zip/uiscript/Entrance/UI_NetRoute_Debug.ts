// ==DevDebug==

module uiscript {

	const Color_TryConnect: Array<number> = [0, 0, 0, 0, 0,
		0, 0.84, 0, 0, 0,
		0, 0, 1, 0, 0,
		0, 0, 0, 1, 0];
	const Color_Connecting: Array<number> = [0, 0, 0, 0, 0,
		0, 0.6, 0, 0, 0,
		0, 0, 1, 0, 0,
		0, 0, 0, 1, 0];
	const Color_Usable: Array<number> = [0, 0, 0, 0, 0,
		0, 0.6, 0, 0, 0,
		0, 0, 0, 0, 0,
		0, 0, 0, 1, 0];
	const Color_Closing: Array<number> = [1.0, 0, 0, 0, 0,
		0, 1.0, 0, 0, 0,
		0, 0, 1.0, 0, 0,
		0, 0, 0, 1, 0];
	const Color_Reconnect: Array<number> = [1.0, 0, 0, 0, 0,
		0, 0.31, 0, 0, 0,
		0, 0, 0.0, 0, 0,
		0, 0, 0, 1, 0];

	class RouteItem {
		public root: Laya.Sprite;
		public routeID: string;
		public route: net.NetRoute = null;

		private bg: Laya.Image;
		private choosed: Laya.Image;
		private txtRouteID: Laya.Label;
		private txtConnectInfo: Laya.Label;
		private btnDetail: Laya.Button;
		private btnOpen: Laya.Button;
		private btnClose: Laya.Button;
		private containerDetails: Laya.Sprite;
		private url: Laya.Label;
		private tail: Laya.Label;
		private lastPingTime: Laya.Label;
		private duringDetect: Laya.Label;
		private locked: Laya.Label;
		private waitingRpcCount: Laya.Label;

		private showDetail: boolean;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.bg = root.getChildByName('bg') as Laya.Image;
			this.choosed = root.getChildByName('choosed') as Laya.Image;
			this.txtRouteID = root.getChildByName('routeID') as Laya.Label;
			this.txtConnectInfo = root.getChildByName('connectInfo') as Laya.Label;
			this.btnOpen = root.getChildByName('btns').getChildByName('btnOpen') as Laya.Button;
			this.btnOpen.clickHandler = new Laya.Handler(this, () => {
				this.route.connect();
			});
			this.btnClose = root.getChildByName('btns').getChildByName('btnClose') as Laya.Button;
			this.btnClose.clickHandler = new Laya.Handler(this, () => {
				this.route.close();
			});
			this.btnDetail = root.getChildByName('btns').getChildByName('btnDetail') as Laya.Button;
			this.btnDetail.clickHandler = new Laya.Handler(this, () => {
				this.showDetail = !this.showDetail;
				this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			});
			this.showDetail = false;
			this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			(root.getChildByName('btns').getChildByName('btnClearBan') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				this.route.bannedTimestamp = 0;
			});

			this.containerDetails = root.getChildByName('details') as Laya.Sprite;
			this.url = this.containerDetails.getChildByName('url') as Laya.Label;
			this.tail = this.containerDetails.getChildByName('tail') as Laya.Label;
			this.lastPingTime = this.containerDetails.getChildByName('lastPingTime') as Laya.Label;
			this.duringDetect = this.containerDetails.getChildByName('duringDetect') as Laya.Label;
			this.locked = this.containerDetails.getChildByName('locked') as Laya.Label;
			this.waitingRpcCount = this.containerDetails.getChildByName('waitingRpcCount') as Laya.Label;
		}

		public setRoute(route: net.NetRoute) {
			this.route = route;
			this.routeID = route.routeID;
			this.root.visible = true;
		}

		public refresh(choosed: boolean): number {
			let h: number = 0;
			this.choosed.visible = choosed;
			this.txtRouteID.text = `routeID: ${this.routeID},   忙碌状态: ${this.route.busyState},   推荐等级：${this.route.level}`;

			let stateDesc: { str: string, color: Array<number> } = UI_NetRoute_Debug.getConnectStateDesc(this.route.state);
			let strConnectInfo = `连接状态: ${stateDesc.str}`;
			this.bg.filters = [new Laya.ColorFilter(stateDesc.color)];

			if (this.route.state === game.EConnectState.connecting || this.route.state === game.EConnectState.usable) {
				strConnectInfo = `${strConnectInfo},   线路类型: `;
				if (this.route.routeType === net.RouteType.Main) {
					strConnectInfo = `${strConnectInfo}主线路`;
				} else if (this.route.routeType === net.RouteType.Standby) {
					strConnectInfo = `${strConnectInfo}备用线路`;
				} else if (this.route.routeType === net.RouteType.Detect) {
					strConnectInfo = `${strConnectInfo}检测线路`;
				} else {
					strConnectInfo = `${strConnectInfo}未知线路类型`;
				}
				strConnectInfo = `${strConnectInfo},   延迟: ${Math.floor(this.route.getDelay() * 1000)}ms`;
				strConnectInfo = `${strConnectInfo},   质量等级: ${UI_NetRoute_Debug.getQualityGradeDesc(this.route.getQualityGrade())}`;
			} else {
				strConnectInfo = `${strConnectInfo},   上次探测质量等级: ${UI_NetRoute_Debug.getQualityGradeDesc(this.route.lastDetectQuilty)}`;
			}
			const nowTime = Laya.timer.currTimer / 1000;
			if (this.route.bannedTimestamp > nowTime) {
				strConnectInfo = `${strConnectInfo},   禁用到${Math.floor(this.route.bannedTimestamp - nowTime)}秒后`;
			} else {
				strConnectInfo = `${strConnectInfo},   未禁用`;
			}

			this.txtConnectInfo.text = strConnectInfo;
			this.btnOpen.visible = this.route.state === game.EConnectState.none || this.route.state === game.EConnectState.closing || this.route.state === game.EConnectState.disconnect;
			this.btnClose.visible = this.route.state === game.EConnectState.tryconnect || this.route.state === game.EConnectState.connecting || this.route.state === game.EConnectState.usable;
			h = 100;
			if (this.showDetail) {
				this.containerDetails.visible = true;
				let _h: number = 0;
				this.url.text = `url: ${this.route.url}`;
				this.tail.text = `tail: ${this.route.tail}`;
				_h += 20 * 2;
				if (this.route.state === game.EConnectState.connecting || this.route.state === game.EConnectState.usable) {
					this.lastPingTime.text = `上次ping的时间:  ${Math.floor(nowTime - this.route.lastPingTime)}秒前`;
					this.lastPingTime.visible = true;
					this.lastPingTime.pos(0, _h);
					_h += 20 * 1;
				} else {
					this.lastPingTime.visible = false;
				}
				if (this.route.duringDetect) {
					this.duringDetect.text = '正在高频检测中...';
					this.duringDetect.visible = true;
					this.duringDetect.pos(0, _h);
					_h += 20;
				} else {
					this.duringDetect.visible = false;
				}
				if (this.route.locked) {
					this.locked.text = '正在切换线路...';
					this.locked.visible = true;
					this.locked.pos(0, _h);
					_h += 20;
				} else {
					this.locked.visible = false;
				}
				this.waitingRpcCount.text = `等待的rpc数量:  ${this.route.waitingRpcCount}`;
				this.waitingRpcCount.pos(0, _h);
				_h += 20;
				h += _h;
			} else {
				this.containerDetails.visible = false;
			}
			h += 5;
			this.bg.height = h;
			this.root.height = h;
			return h;
		}
	}

	class NB_Entrance {
		public root: Laya.Sprite;
		private choosedRouteID: Laya.Label;
		private routes: RouteItem[];

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.root.visible = false;
			this.choosedRouteID = this.root.getChildByName('choosedRouteID') as Laya.Label;
			let container_routes: Laya.Sprite = this.root.getChildByName('container_routes') as Laya.Sprite;
			let route_templete: Laya.Sprite = container_routes.getChildByName('templete') as Laya.Sprite;
			route_templete.visible = false;
			this.routes = [];
			let clone = route_templete.scriptMap['capsui.UICopy'] as capsui.UICopy;
			// this.routes.push(new RouteItem(route_templete));
			for (let i = 0; i < 10; i++) {
				this.routes.push(new RouteItem(clone.getNodeClone()));
			}
			for (let i = 0; i < this.routes.length; i++) {
				this.routes[i].root.visible = false;
			}
		}

		public refresh(): number {
			if (!net.NetRouteGroup_Entrance.Inst) {
				this.root.visible = false;
				return 0;
			}
			this.root.visible = true;
			let h: number = 0;
			const _net = net.NetRouteGroup_Entrance.Inst;
			let countRoute = 0;
			for (let routeID in _net.routeInfos) {
				countRoute++;
				let routeInfo = _net.routeInfos[routeID];
				let routeItem: RouteItem = null;
				for (let i = 0; i < this.routes.length; i++) {
					if (this.routes[i].routeID === routeID) {
						routeItem = this.routes[i];
						break;
					}
				}
				if (!routeItem) {
					for (let i = 0; i < this.routes.length; i++) {
						if (!this.routes[i].routeID) {
							routeItem = this.routes[i];
							routeItem.setRoute(routeInfo.route);
							break;
						}
					}
				}
				if (!routeItem) {
					app.Log.Error_t('UI_NetRoute_Debug', '线路超过10条，找不到cell了，init里面多加一点');
					return;
				}
				routeItem.root.y = h;
				h += routeItem.refresh(_net.choosedRouteID === routeID);
				h += 5;
			}
			this.choosedRouteID.text = `choosedRouteID:  ${_net.choosedRouteID},    线路数量: ${countRoute}`;
			h += 70;
			this.root.height = h;
			return h;
		}
	}

	class NB_Lobby {
		public root: Laya.Sprite;
		private choosedRouteID: Laya.Label;
		private _TickCheckMainRouteRet: Laya.Label;
		private _TickCheckDetectRet: Laya.Label;
		private _DoDetectRet: Laya.Label;
		private routeMainID: Laya.Label;
		private routeStandbyID: Laya.Label;
		private routeDetectID: Laya.Label;
		private btnHandStep: Laya.Button;


		private routes: RouteItem[];

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.root.visible = false;
			this.choosedRouteID = this.root.getChildByName('choosedRouteID') as Laya.Label;
			this._TickCheckMainRouteRet = this.root.getChildByName('_TickCheckMainRouteRet') as Laya.Label;
			this._TickCheckDetectRet = this.root.getChildByName('_TickCheckDetectRet') as Laya.Label;
			this._DoDetectRet = this.root.getChildByName('_DoDetectRet') as Laya.Label;
			this.routeMainID = this.root.getChildByName('routeMainID') as Laya.Label;
			this.routeStandbyID = this.root.getChildByName('routeStandbyID') as Laya.Label;
			this.routeDetectID = this.root.getChildByName('routeDetectID') as Laya.Label;

			let btns: Laya.Sprite = this.root.getChildByName('btns') as Laya.Sprite;
			this.btnHandStep = (btns.getChildByName('btnHandStep') as Laya.Button);
			this.btnHandStep.clickHandler = new Laya.Handler(this, () => {
				net.NetRouteGroup.Inst.handStepTick = !net.NetRouteGroup.Inst.handStepTick;
				this.btnHandStep.label = net.NetRouteGroup.Inst.handStepTick ? '手动切换' : '自动切换';
			});
			net.NetRouteGroup.Inst.handStepTick = false;
			this.btnHandStep.label = net.NetRouteGroup.Inst.handStepTick ? '手动切换' : '自动切换';
			(btns.getChildByName('_TickCheckMainRoute') as Laya.Button).clickHandler = new Laya.Handler(this, () => { net.NetRouteGroup.Inst['_tickCheckMainRoute'](); });
			(btns.getChildByName('_TickCheckDetect') as Laya.Button).clickHandler = new Laya.Handler(this, () => { net.NetRouteGroup.Inst['_tickCheckDetect'](); });
			(btns.getChildByName('_SwitchStandby2Main') as Laya.Button).clickHandler = new Laya.Handler(this, () => { net.NetRouteGroup.Inst['_switchStandby2Main'](); });
			(btns.getChildByName('_DoDetect') as Laya.Button).clickHandler = new Laya.Handler(this, () => { net.NetRouteGroup.Inst['_doDetect'](1000000); });
			(btns.getChildByName('_SwitchDetect2Standby') as Laya.Button).clickHandler = new Laya.Handler(this, () => { net.NetRouteGroup.Inst['_switchDetect2Standby'](); });

			let container_routes: Laya.Sprite = this.root.getChildByName('container_routes') as Laya.Sprite;
			let route_templete: Laya.Sprite = container_routes.getChildByName('templete') as Laya.Sprite;
			route_templete.visible = false;
			this.routes = [];
			let clone = route_templete.scriptMap['capsui.UICopy'] as capsui.UICopy;
			for (let i = 0; i < 10; i++) {
				this.routes.push(new RouteItem(clone.getNodeClone()));
			}
			for (let i = 0; i < this.routes.length; i++) {
				this.routes[i].root.visible = false;
			}
		}

		public refresh(): number {
			if (!net.NetRouteGroup.Inst || !net.NetRouteGroup.Inst.initedFromEntrance) {
				this.root.visible = false;
				return 0;
			}
			this.root.visible = true;
			let h: number = 0;
			const _net = net.NetRouteGroup.Inst;

			let stateDes = UI_NetRoute_Debug.getConnectStateDesc(_net.state);
			let strConnectInfo = `连接状态: ${stateDes.str}`;
			strConnectInfo = `${strConnectInfo},   延迟: ${Math.floor(_net.getDelay() * 1000)}ms`;
			strConnectInfo = `${strConnectInfo},   线路质量: ${UI_NetRoute_Debug.getQualityGradeDesc(_net.getQualityGrade())}`;

			if (_net.duringReconnect) {
				strConnectInfo = `${strConnectInfo},   主线重连中: 是`;
				strConnectInfo = `${strConnectInfo},   重连次数: ${_net.reconnectCounter}`;
			} else {
				strConnectInfo = `${strConnectInfo},   主线重连中: 否`;
			}
			this.choosedRouteID.text = strConnectInfo;
			this._TickCheckMainRouteRet.text = `主备检查结果： ${_net._TickCheckMainRouteRet}`;
			this._TickCheckDetectRet.text = `备线和探险检查结果： ${_net._TickCheckDetectRet}`;
			this._DoDetectRet.text = `线路探测执行结果： ${_net._DoDetectRet}`;

			if (_net.routeMain) {
				this.routeMainID.text = `主线路ID: ${_net.routeMain.routeID}`;
			} else {
				this.routeMainID.text = '主线路ID: 无';
			}
			if (_net.routeStandby) {
				this.routeStandbyID.text = `备用线路ID: ${_net.routeStandby.routeID}`;
			} else {
				this.routeStandbyID.text = '备用线路ID: 无';
			}
			if (_net.routeDetect) {
				this.routeDetectID.text = `探测线路ID: ${_net.routeDetect.routeID}`;
			} else {
				this.routeDetectID.text = '探测线路ID: 无';
			}
			h += 300;

			let _h:number = 0;
			for (let routeID in _net.routes) {
				let route = _net.routes[routeID];
				let routeItem: RouteItem = null;
				for (let i = 0; i < this.routes.length; i++) {
					if (this.routes[i].routeID === routeID) {
						routeItem = this.routes[i];
						break;
					}
				}
				if (!routeItem) {
					for (let i = 0; i < this.routes.length; i++) {
						if (!this.routes[i].routeID) {
							routeItem = this.routes[i];
							routeItem.setRoute(route);
							break;
						}
					}
				}
				if (!routeItem) {
					app.Log.Error_t('UI_NetRoute_Debug', '线路超过10条，找不到cell了，init里面多加一点');
					return;
				}
				routeItem.root.y = _h;
				_h += routeItem.refresh(_net.getMainRouteID() === routeID);
				_h += 5;
			}
			h += _h;
			this.root.height = h;
			return h;
		}
	}

	class NB_MJ {
		public root: Laya.Sprite;
		private choosedRouteID: Laya.Label;
		private route: RouteItem;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.root.visible = false;
			this.choosedRouteID = this.root.getChildByName('choosedRouteID') as Laya.Label;
			let container_routes: Laya.Sprite = this.root.getChildByName('container_routes') as Laya.Sprite;
			let route_templete: Laya.Sprite = container_routes.getChildByName('templete') as Laya.Sprite;
			route_templete.visible = false;
			this.route = new RouteItem(route_templete);
		}

		public refresh(): number {
			if (app.NetAgent.netRouteGroup_mj && (app.NetAgent.netRouteGroup_mj.getConnectState() == game.EConnectState.none 
			|| app.NetAgent.netRouteGroup_mj.getConnectState() == game.EConnectState.disconnect)) {
				this.root.visible = false;
				return 0;
			}
			const _net = app.NetAgent.netRouteGroup_mj;
			this.root.visible = true;
			let h: number = 70;
			this.choosedRouteID.text = `routeID:  ${_net.route.routeID}`;
			h += 70;
			this.route.setRoute(_net.route);
			h += this.route.refresh(true);
			h += 5;
			this.root.height = h;
			return h;
		}
	}

	class RouteItemLive {
		public root: Laya.Sprite;
		public routeID: string;
		public route: net.LiveSocket = null;

		private bg: Laya.Image;
		private choosed: Laya.Image;
		private txtRouteID: Laya.Label;
		private txtConnectInfo: Laya.Label;
		private btnDetail: Laya.Button;
		private btnOpen: Laya.Button;
		private btnClose: Laya.Button;
		private containerDetails: Laya.Sprite;
		private url: Laya.Label;
		private tail: Laya.Label;
		private lastPingTime: Laya.Label;
		private duringDetect: Laya.Label;
		private locked: Laya.Label;
		private waitingRpcCount: Laya.Label;

		private showDetail: boolean;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.bg = root.getChildByName('bg') as Laya.Image;
			this.choosed = root.getChildByName('choosed') as Laya.Image;
			this.txtRouteID = root.getChildByName('routeID') as Laya.Label;
			this.txtConnectInfo = root.getChildByName('connectInfo') as Laya.Label;
			this.btnOpen = root.getChildByName('btns').getChildByName('btnOpen') as Laya.Button;
			this.btnOpen.visible = false;
			this.btnClose = root.getChildByName('btns').getChildByName('btnClose') as Laya.Button;
			this.btnClose.visible = false;
			this.btnDetail = root.getChildByName('btns').getChildByName('btnDetail') as Laya.Button;
			this.btnDetail.clickHandler = new Laya.Handler(this, () => {
				this.showDetail = !this.showDetail;
				this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			});
			this.showDetail = false;
			this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			this.btnDetail.visible = false;
			(root.getChildByName('btns').getChildByName('btnClearBan') as Laya.Button).visible = false;

			this.containerDetails = root.getChildByName('details') as Laya.Sprite;
			this.containerDetails.visible = false;
			this.url = this.containerDetails.getChildByName('url') as Laya.Label;
			this.tail = this.containerDetails.getChildByName('tail') as Laya.Label;
			this.lastPingTime = this.containerDetails.getChildByName('lastPingTime') as Laya.Label;
			this.duringDetect = this.containerDetails.getChildByName('duringDetect') as Laya.Label;
			this.locked = this.containerDetails.getChildByName('locked') as Laya.Label;
			this.waitingRpcCount = this.containerDetails.getChildByName('waitingRpcCount') as Laya.Label;
		}

		public setRoute(route: net.LiveSocket) {
			this.route = route;
			this.routeID = route.routeID;
			this.root.visible = true;
		}

		public refresh(choosed: boolean): number {
			let h: number = 0;
			this.choosed.visible = choosed;
			this.txtRouteID.text = `routeID: ${this.routeID}, url: ${this.route.url}`;

			let stateDesc: { str: string, color: Array<number> } = UI_NetRoute_Debug.getConnectStateDesc(game.LiveNetMgr.Inst.connect_state);
			let strConnectInfo = `连接状态: ${stateDesc.str}`;
			this.txtConnectInfo.text = strConnectInfo;
			h = 100;
			this.bg.height = h;
			this.root.height = h;
			return h;
		}
	}

	class NB_GuanZhan {
		public root: Laya.Sprite;
		private choosedRouteID: Laya.Label;
		private route: RouteItemLive;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.root.visible = false;
			this.choosedRouteID = this.root.getChildByName('choosedRouteID') as Laya.Label;
			let container_routes: Laya.Sprite = this.root.getChildByName('container_routes') as Laya.Sprite;
			let route_templete: Laya.Sprite = container_routes.getChildByName('templete') as Laya.Sprite;
			route_templete.visible = false;
			this.route = new RouteItemLive(route_templete);
		}

		public refresh(): number {
			if (!game.LiveNetMgr.Inst || !game.LiveNetMgr.Inst.connect_state || (game.LiveNetMgr.Inst.connect_state == game.EConnectState.none 
			|| game.LiveNetMgr.Inst.connect_state == game.EConnectState.disconnect)) {
				this.root.visible = false;
				return 0;
			}
			const _net = game.LiveNetMgr.Inst;
			this.root.visible = true;
			let h: number = 70;
			this.choosedRouteID.text = '';
			h += 70;
			this.route.setRoute(game.LiveNetMgr.Inst.socket);
			h += this.route.refresh(true);
			h += 5;
			this.root.height = h;
			return h;
		}
	}

	class RouteItemChat {
		public root: Laya.Sprite;
		public routeID: string;
		public route: net.ContestChatSocket = null;

		private bg: Laya.Image;
		private choosed: Laya.Image;
		private txtRouteID: Laya.Label;
		private txtConnectInfo: Laya.Label;
		private btnDetail: Laya.Button;
		private btnOpen: Laya.Button;
		private btnClose: Laya.Button;
		private containerDetails: Laya.Sprite;
		private url: Laya.Label;
		private tail: Laya.Label;
		private lastPingTime: Laya.Label;
		private duringDetect: Laya.Label;
		private locked: Laya.Label;
		private waitingRpcCount: Laya.Label;

		private showDetail: boolean;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.bg = root.getChildByName('bg') as Laya.Image;
			this.choosed = root.getChildByName('choosed') as Laya.Image;
			this.txtRouteID = root.getChildByName('routeID') as Laya.Label;
			this.txtConnectInfo = root.getChildByName('connectInfo') as Laya.Label;
			this.btnOpen = root.getChildByName('btns').getChildByName('btnOpen') as Laya.Button;
			this.btnOpen.visible = false;
			this.btnClose = root.getChildByName('btns').getChildByName('btnClose') as Laya.Button;
			this.btnClose.visible = false;
			this.btnDetail = root.getChildByName('btns').getChildByName('btnDetail') as Laya.Button;
			this.btnDetail.clickHandler = new Laya.Handler(this, () => {
				this.showDetail = !this.showDetail;
				this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			});
			this.showDetail = false;
			this.btnDetail.label = this.showDetail ? '隐藏详情' : '显示详情';
			this.btnDetail.visible = false;
			(root.getChildByName('btns').getChildByName('btnClearBan') as Laya.Button).visible = false;

			this.containerDetails = root.getChildByName('details') as Laya.Sprite;
			this.containerDetails.visible = false;
			this.url = this.containerDetails.getChildByName('url') as Laya.Label;
			this.tail = this.containerDetails.getChildByName('tail') as Laya.Label;
			this.lastPingTime = this.containerDetails.getChildByName('lastPingTime') as Laya.Label;
			this.duringDetect = this.containerDetails.getChildByName('duringDetect') as Laya.Label;
			this.locked = this.containerDetails.getChildByName('locked') as Laya.Label;
			this.waitingRpcCount = this.containerDetails.getChildByName('waitingRpcCount') as Laya.Label;
		}

		public setRoute(route: net.ContestChatSocket) {
			this.route = route;
			this.routeID = route.routeID;
			this.root.visible = true;
		}

		public refresh(choosed: boolean): number {
			let h: number = 0;
			this.choosed.visible = choosed;
			this.txtRouteID.text = `routeID: ${this.routeID}, url: ${this.route.url}`;

			let stateDesc: { str: string, color: Array<number> } = UI_NetRoute_Debug.getConnectStateDesc(game.ContestChatNetMgr.Inst.connect_state);
			let strConnectInfo = `连接状态: ${stateDesc.str}`;
			this.txtConnectInfo.text = strConnectInfo;
			h = 100;
			this.bg.height = h;
			this.root.height = h;
			return h;
		}
	}

	class NB_Chat {
		public root: Laya.Sprite;
		private choosedRouteID: Laya.Label;
		private route: RouteItemChat;

		public constructor(root: Laya.Sprite) {
			this.root = root;
			this.root.visible = false;
			this.choosedRouteID = this.root.getChildByName('choosedRouteID') as Laya.Label;
			let container_routes: Laya.Sprite = this.root.getChildByName('container_routes') as Laya.Sprite;
			let route_templete: Laya.Sprite = container_routes.getChildByName('templete') as Laya.Sprite;
			route_templete.visible = false;
			this.route = new RouteItemChat(route_templete);
		}

		public refresh(): number {
			if (!game.ContestChatNetMgr.Inst || !game.ContestChatNetMgr.Inst.connect_state || (game.ContestChatNetMgr.Inst.connect_state == game.EConnectState.none 
			|| game.ContestChatNetMgr.Inst.connect_state == game.EConnectState.disconnect)) {
				this.root.visible = false;
				return 0;
			}
			const _net = game.ContestChatNetMgr.Inst;
			this.root.visible = true;
			let h: number = 70;
			this.choosedRouteID.text = '';
			h += 70;
			this.route.setRoute(game.ContestChatNetMgr.Inst.socket);
			h += this.route.refresh(true);
			h += 5;
			this.root.height = h;
			return h;
		}
	}

	export class UI_NetRoute_Debug extends UIBase {

		public static Inst: UI_NetRoute_Debug;
		private root: Laya.Sprite = null;
		private panel: Laya.Panel = null;

		private entrance: NB_Entrance;
		private lobby: NB_Lobby;
		private mj: NB_MJ;
		private guanzhan: NB_GuanZhan;
		private chat: NB_Chat;

		public constructor() {
			super(new ui.entrance.netRoute_DevDebugUI());
			UI_NetRoute_Debug.Inst = this;
		}

		public onCreate(): void {
			this.root = this.me.getChildByName('root').getChildByName('container') as Laya.Sprite;
			this.panel = this.root.getChildByName('lst').getChildByName('content') as Laya.Panel;
			this.panel.vScrollBarSkin = game.Tools.localUISrc('myres/vscroll.png');
			this.panel.vScrollBar.visible = false;
			this.entrance = new NB_Entrance(this.panel.getChildByName('NetRouteGroup_Entrance') as Laya.Sprite);
			this.lobby = new NB_Lobby(this.panel.getChildByName('NetRouteGroup') as Laya.Sprite);
			this.mj = new NB_MJ(this.panel.getChildByName('NetRouteGroup_Single_MJ') as Laya.Sprite);
			this.guanzhan = new NB_GuanZhan(this.panel.getChildByName('guanzhan') as Laya.Sprite);
			this.chat = new NB_Chat(this.panel.getChildByName('chat') as Laya.Sprite);
			(this.panel.getChildByName('NetRouteGroup_Single_MJ') as Laya.Sprite).visible = false;
			(this.panel.getChildByName('guanzhan') as Laya.Sprite).visible = false;
			(this.panel.getChildByName('chat') as Laya.Sprite).visible = false;
			this.root.visible = false;
			let detailOpenBtn = (this.me.getChildByName('root').getChildByName('btn') as Laya.Button);
			detailOpenBtn.clickHandler = new Laya.Handler(this, this.switchOpen);
			(this.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, this.close);
			let btnHide = (this.me.getChildByName('root').getChildByName('btn_hide') as Laya.Button);
			btnHide.clickHandler = new Laya.Handler(this, () => {
				detailOpenBtn.visible = false;
				btnHide.visible = false;
			});
		}

		// 切换打开状态
		private switchOpen() {
			this.root.visible = !this.root.visible;
			Laya.timer.clearAll(this);
			if (this.root.visible) {
				Laya.timer.loop(0.1, this, this.refresh);
			}
		}

		// 关闭
		private close() {
			this.root.visible = false;
			Laya.timer.clearAll(this);
		}

		// 刷新界面
		private refresh() {
			let h: number = 0;
			h += this.entrance.refresh();
			this.lobby.root.y = h;
			h += this.lobby.refresh();
			this.mj.root.y = h;
			h += this.mj.refresh();
			this.guanzhan.root.y = h;
			h += this.guanzhan.refresh();
			this.chat.root.y = h;
			h += this.chat.refresh();
			// this.panel.vScrollBar.height = h;
		}

		// 获取连接状态描述
		public static getConnectStateDesc(state: game.EConnectState): { str: string, color: Array<number> } {
			let str = '';
			let color = null;
			if (state === game.EConnectState.tryconnect) {
				str = '尝试连接中';
				color = Color_TryConnect;
			} else if (state === game.EConnectState.connecting) {
				str = '连上待确认';
				color = Color_Connecting;
			} else if (state === game.EConnectState.usable) {
				str = '线路可用';
				color = Color_Usable;
			} else if (state === game.EConnectState.closing) {
				str = '正在关闭';
				color = Color_Closing;
			} else if (state === game.EConnectState.disconnect) {
				str = '已关闭';
				color = Color_Closing;
			} else if (state === game.EConnectState.reconnecting) {
				str = '正在重连';
				color = Color_Reconnect;
			} else {
				str = '未知状态';
				color = Color_Closing;
			}
			return { str: str, color: color };
		}

		// 获取质量等级描述
		public static getQualityGradeDesc(qualityGrade: number) {
			const DELAY_INF = Infinity;
			if (qualityGrade < DELAY_INF) {
				return `${Math.floor(qualityGrade * 1000)}ms`;
			} else {
				return '未知';
			}
		}

	}
}