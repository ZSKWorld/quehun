module uiscript {
    class Cell_Spot {
        private me: Laya.Sprite;
        public lock: Laya.Sprite;
        private lock_label: Laya.Label;
        private name: Laya.Label;
        private desc: Laya.Label;
        private index: number;
        private redpoint: Laya.Sprite;
        private _data: lqc.Sheet_Spot_Event;

        public constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.lock = me.getChildByName('lock') as Laya.Sprite;
            this.lock_label = this.lock.getChildByName('time') as Laya.Label;
            this.name = me.getChildByName('name') as Laya.Label;
            this.desc = me.getChildByName('desc') as Laya.Label;
            this.index = index;
            this.redpoint = me.getChildByName('redpoint') as Laya.Sprite;
            this._data = cfg.spot.event.get(index + 22040701);
            (this.me.getChildByName('play') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.lock.visible) return;
                UI_Huiye.Inst.closeNowPage();
                GameMgr.Inst.showSpotByEvent(this._data.content_path);
            }, null, false);
        }

        public show(i: number) {
            // TODO 判定是否解锁，时间判定
            if (this._data.unlock_time && new Date(this._data.unlock_time).getTime() > game.Tools.getServerTime()) {
                this.me.x = 121;
                this.name.text = this._data['title_' + GameMgr.client_language];
                (this.me.getChildByName('play') as Laya.Button).visible = false;
                this.lock.visible = true;
                this.desc.visible = false;
                this.redpoint.visible = false;
                if (i == 1) {
                    this.lock_label.text = game.Tools.strOfLocalization(3593);
                } else {
                    this.lock_label.text = game.Tools.strOfLocalization(3594);
                }
            } else {
                this.me.x = 59;
                this.redpoint.visible = Number(Laya.LocalStorage.getItem(game.Tools.eeesss('huiye_spot' + GameMgr.Inst.account_id))) < this.index;
                this.name.text = this._data['title_' + GameMgr.client_language];
                this.desc.text = this._data['content_' + GameMgr.client_language];
                (this.me.getChildByName('play') as Laya.Button).visible = true;
                this.lock.visible = false;
                this.desc.visible = true;
            }
        }
    }
    class Cell_Card {
        private me: Laya.Sprite;
        public lock: Laya.Sprite;
        private index: number;
        private father: Page_Huiye_Collect;

        public constructor(me: Laya.Sprite, index: number, father: Page_Huiye_Collect) {
            this.me = me;
            this.father = father;
            this.me.visible = false;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            (this.me.getChildAt(0) as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                this.father.locking = true;
                this.father.show_card(index);
            }, null, false);
        }

        public show(data: any) {
            this.me.visible = true;
            if (data.achieved) {
                (this.me.getChildAt(0) as Laya.Button).visible = true;
                this.lock.visible = false;
            } else {
                (this.me.getChildAt(0) as Laya.Button).visible = false;
                this.lock.visible = true;
            }
        }
    }
    export class Page_Huiye_Collect extends Page_Activity_Base {
        public static activity_id: number = 220403;

        public static haveRedPoint(): boolean {
            let looked_index: number = Number(Laya.LocalStorage.getItem(game.Tools.eeesss('huiye_spot' + GameMgr.Inst.account_id)));
            for (let index = 1; index < 3; index++) {
                let data = cfg.spot.event.get(index + 22040701);
                if ((!data.unlock_time || new Date(data.unlock_time).getTime() <= game.Tools.getServerTime()) && looked_index  < index) {
                    return true;
                }
            }
            
            return false;
        }
        private tabs: Array<Laya.Sprite> = [];
        private spot_cells: Array<Cell_Spot> = [];
        private card_cells: Array<Cell_Card> = [];
        private page_kapai: Laya.Sprite;
        private page_juqing: Laya.Sprite;
        private now_page: number = -1;
        private all_data_lst: Array<Object> = [];
        private progress: Laya.Label;
        private item_id: number;
        public locking: boolean = false;
        private item_name: string;
        private item_count: number;

        public onPageCreate() {
            let tabs_parent = this.me.getChildByName('tabs') as Laya.Sprite;
            this.page_kapai = this.me.getChildByName('page_kapai') as Laya.Sprite;
            this.page_juqing = this.me.getChildByName('page_juqing') as Laya.Sprite;
            for (let i = 0; i < tabs_parent.numChildren; i++) {
                this.tabs.push(tabs_parent.getChildAt(i) as Laya.Sprite);
                (tabs_parent.getChildAt(i) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    this.on_tab_btn_click(i);
                });
            }
            for (let i = 0; i < 3; i++) {
                this.spot_cells.push(new Cell_Spot(this.page_juqing.getChildByName('item_' + i) as Laya.Sprite, i));
            }
            for (let i = 1; i < 16; i++) {
                this.card_cells.push(new Cell_Card(this.page_kapai.getChildByName('card' + i) as Laya.Sprite, i, this));
            }
            this.now_page = -1;
            this.progress = this.page_kapai.getChildByName('progress') as Laya.Label;
            ((this.me.getChildByName('big_card') as Laya.Sprite).getChildByName('close') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.locking = true;
                let card = (this.me.getChildByName('big_card') as Laya.Sprite).getChildByName('card') as Laya.Image;
                Laya.Tween.to(card, { scaleX: 0, scaleY: 0 }, 70, null, Laya.Handler.create(this, () => {
                    this.locking = false;
                    (this.me.getChildByName('big_card') as Laya.Sprite).visible = false;
                }));
            }, null, false);
        }

        public show_card(index: number) {
            (this.me.getChildByName('big_card') as Laya.Sprite).visible = true;
            let card = (this.me.getChildByName('big_card') as Laya.Sprite).getChildByName('card') as Laya.Image;
            let str: string;
            if (index <= 5) {
                str = 'zhuang';
            } else {
                if (index <= 10) {
                    str = 'fortune';
                    index = index - 5;
                } else {
                    str = 'fate';
                    index = index - 10;
                }
            }
            game.LoadMgr.setImgSkin(card, 'myres2/fieldspell/big_' + str + index + '.png');
            card.scale(0, 0);
            Laya.Tween.to(card, { scaleX: 1.5, scaleY: 1.5 }, 70, null, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }
        public onShow() {
            let lst = UI_Activity.getPeriodTaskList(Page_Huiye_Collect.activity_id);
            this.all_data_lst = lst;
            this.all_data_lst.sort(function (a, b) {
                return a['id'] - b['id'];
            });
            this.on_tab_btn_click(0);
            this.redpoint_refresh();
        }
        public redpoint_refresh() {
            (this.me.getChildByName('tabs').getChildByName('juqing').getChildByName('redpoint') as Laya.Sprite).visible = Page_Huiye_Collect.haveRedPoint();

        }
        public total_refresh() {
            let j: number = 0;
            for (let i = 0; i < 15; i++) {
                if (this.all_data_lst[i]['achieved']) {
                    j++;
                }
            }
            this.progress.text = game.Tools.strOfLocalization(3578, [j.toString()]);
        }
        private on_tab_btn_click(tab_index: number) {
            for (let i = 0; i < this.tabs.length; i++) {
                (this.tabs[i].getChildAt(1) as Laya.Sprite).visible = tab_index != i;
            }
            switch (tab_index) {
                case 0: // 卡牌页
                    if (this.now_page == 0) return;
                    this.now_page = 0;
                    this.tabs[0].scale(1, 1);
                    this.tabs[1].scale(0.88, 0.88);
                    this.page_juqing.visible = false;
                    this.page_kapai.visible = true;
                    for (let i = 0; i < 15; i++) {
                        this.card_cells[i].show(this.all_data_lst[i]);
                    }
                    this.total_refresh();
                    break;
                case 1: // 剧情页
                    if (this.now_page == 1) return;
                    this.now_page = 1;
                    this.tabs[0].scale(0.88, 0.88);
                    this.tabs[1].scale(1, 1);
                    this.page_juqing.visible = true;
                    this.page_kapai.visible = false;
                    let index = 0;
                    let have_lock = false;
                    for (let i = 0; i < this.spot_cells.length; i++) {
                        this.spot_cells[i].show(i);
                        if (!have_lock) {
                            if (this.spot_cells[i].lock.visible) {
                                have_lock = true;
                                Laya.LocalStorage.setItem(game.Tools.eeesss('huiye_spot' + GameMgr.Inst.account_id), '' + index);
                            } else if (index == 2) {
                                Laya.LocalStorage.setItem(game.Tools.eeesss('huiye_spot' + GameMgr.Inst.account_id), '' + 3);
                            }
                        }
                        index++;

                    }
                    break;

            }
        }
        public onClose() {
            this.now_page = -1;
            UI_Huiye.Inst.refresh_red_point(0);
            for (let i = 1; i <= 5; i++) {
                Laya.loader.clearTextureRes('myres2/fieldspell/big_fate' + i + '.png');
            }
            for (let i = 1; i <= 5; i++) {
                Laya.loader.clearTextureRes('myres2/fieldspell/big_zhuang' + i + '.png');
            }
            for (let i = 1; i <= 5; i++) {
                Laya.loader.clearTextureRes('myres2/fieldspell/big_fortune' + i + '.png');
            }

        }
    }
}