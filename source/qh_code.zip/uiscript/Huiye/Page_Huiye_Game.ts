module uiscript {
    export class Page_Huiye_Game extends Page_Activity_Base {
        public static activity_id: number = 220402;

        private match_btn: Laya.Button;
        private match_img: Laya.Image
        private matching_spr: Laya.Sprite;
        private matching_label: Laya.Label;
        private _matching: boolean;
        private cancelStr: string;
        private cancelShowIndex: number = 0;
        private anim_time = 2800;
        private introduce1: Laya.Label;
        private introduce2: Laya.Label;
        private match_sid: string = '2:46';


        public get matching(): boolean {
            return this._matching;
        }

        public set matching(state: boolean) {
            if (this._matching == state) {
                return;
            }

            this._matching = state;

            game.LoadMgr.setImgSkin(this.match_img, 'myres/activity_huiye/' + (this._matching ? 'btn_cancel_match1.png' : 'btn_match1.png'));
            this.matching_spr.visible = this._matching;
            if (this._matching) {
                this.showCancelText();
                Laya.timer.loop(800, this, this.showCancelText);
            } else {
                Laya.timer.clear(this, this.showCancelText);
            }

        }

        public onPageCreate() {
            this.match_btn = this.me.getChildByName('match').getChildByName('match') as Laya.Button;
            (this.me.getChildByName('match').getChildByName('rule') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                uiscript.UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3587));
            })
            this.match_img = this.match_btn.getChildAt(0) as Laya.Image;
            this.matching_spr = this.match_btn.getChildByName('matching') as Laya.Sprite;
            this.matching_label = this.matching_spr.getChildAt(1) as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.matching_label.fontSize = 24;
            }
            this.matching_spr.visible = false;
            this.introduce1 = this.me.getChildByName('introduce1') as Laya.Label;
            this.introduce2 = this.me.getChildByName('introduce2') as Laya.Label;
            this.introduce1.y -= 40;
            this.introduce2.y -= 40;
            this.cancelStr = game.Tools.strOfLocalization(2525);
            this.match_btn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.on_match_btn_click();
            });


            (this.me.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, this.on_close_btn_click);
            game.LobbyNetMgr.Inst.add_connect_listener(['OnReconnectStarted', 'OnChangeMainRouteBegin'], this, () => {
                if (this.enable) {
                    this.close();
                    if (this.matching) {
                        this.cancelMatch(null);
                    }
                }
            });
        }

        public onShow() {
            game.LoadMgr.setImgSkin(this.match_img, 'myres/activity_huiye/btn_match1.png');

        }

        private on_close_btn_click() {
            if (this.matching) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3199), Laya.Handler.create(this, () => {
                    this.cancelMatch(Laya.Handler.create(this, this.close));
                }));
            } else {
                this.close();
            }
        }

        private on_match_btn_click() {
            if (this.matching) {
                this.cancelMatch(null);
            } else {
                this.startMatch();
            }
        }

        public cancelMatch(handler: Laya.Handler) {
            this.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'cancelUnifiedMatch', {
                match_sid: this.match_sid
            }, (err, res) => {
                this.locking = false;

                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('cancelUnifiedMatch', err, res);
                } else {
                    this.matching = false;
                    if (handler) {
                        handler.run();
                    }
                }
            });
        }

        public startMatch() {
            this.matching = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'startUnifiedMatch', {
                match_sid: this.match_sid,
                client_version_string: GameMgr.Inst.getClientVersion()
            }, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('startUnifiedMatch', err, res);
                    this.matching = false;
                } else {

                }
            });
        }

        private showCancelText() {
            this.cancelShowIndex = ++this.cancelShowIndex > 3 ? 1 : this.cancelShowIndex;
            let showStr = this.cancelStr;
            for (let i = 0; i < this.cancelShowIndex; i++) {
                showStr += '.';
            }
            this.matching_label.text = showStr;
        }

        public onDisable() {
            this.matching = false;
        }
    }
}