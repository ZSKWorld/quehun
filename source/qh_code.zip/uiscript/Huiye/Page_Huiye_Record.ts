module uiscript {
    class TaskCell {
        public me: Laya.Sprite;

        private container_info: Laya.Sprite;
        private item_icon: Laya.Image;
        private item_name: Laya.Label;
        private item_count: Laya.Label;
        private task_name: Laya.Label;
        private btn_get: Laya.Button;
        private doing: Laya.Sprite;
        private getted: Laya.Sprite;
        private lock: Laya.Sprite;
        private lock_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;
        private reward_count: number = 0;
        private father: Page_Huiye_Record;

        public constructor(me: Laya.Sprite, father: Page_Huiye_Record) {
            this.me = me;
            this.father = father;
            this.me.visible = false;
            this.container_info = me.getChildByName('info') as Laya.Sprite;
            this.task_name = this.container_info.getChildByName('requirement') as Laya.Label;
            this.item_icon = this.me.getChildByName('item').getChildByName('item') as Laya.Image;
            this.item_name = this.me.getChildByName('item_name') as Laya.Label;
            this.item_count = this.me.getChildByName('item_count') as Laya.Label;
            this.btn_get = this.container_info.getChildByName('btn_get') as Laya.Button;
            this.getted = this.container_info.getChildByName('getted') as Laya.Sprite;
            this.doing = this.container_info.getChildByName('doing') as Laya.Sprite;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.lock_label = this.lock.getChildByName('time') as Laya.Label;
            (this.me.getChildByName('item').getChildByName('btn_item') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);
        }

        public show(info: any) {
            this.me.visible = true;
            this.me.x = 55;
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);

            this.container_info.visible = true;


            if (info.rewarded) {
                this.getted.visible = true;
                this.lock.visible = false;
                this.container_info.visible = true;
                this.btn_get.visible = false;
                this.doing.visible = false;
            } else {
                this.getted.visible = false;

                if (info.achieved) {
                    this.btn_get.visible = true;
                    this.doing.visible = false;
                    this.setBtnGrayDisable(false);
                    this.btn_get.clickHandler = Laya.Handler.create(this, () => {
                        this.setBtnGrayDisable(true);
                        app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: id }, (err, res) => {
                            this.setBtnGrayDisable(false);
                            if (err || res['error']) {
                                UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                            } else {
                                if (this.id == id) {
                                    this.getted.visible = true;
                                    this.lock.visible = false;
                                    this.container_info.visible = true;
                                    this.btn_get.visible = false;
                                    this.doing.visible = false;
                                    let count = this.reward_count;

                                    let s: string = game.Tools.strOfLocalization(2234) + (this.item_name.text + ' x' + count);
                                    UI_LightTips.Inst.show(s);

                                }
                                this.father.task_rewarded(id);
                                UI_Activity.onTaskRewarded(id);
                            }
                        });
                    }, null, false);
                } else {
                    this.setBtnGrayDisable(true);
                    this.btn_get.clickHandler = null;
                    this.btn_get.visible = false;
                    this.doing.visible = true;

                }
            }

            this.task_name.text = d_task_info['desc_' + GameMgr.client_language];

            let reward = d_activity_task.reward.split('-');
            this.item_id = parseInt(reward[0]);


            this.reward_count = parseInt(reward[1]);
            let d_currency = cfg.item_definition.currency.get(this.item_id);
            if (d_currency) {
                game.LoadMgr.setImgSkin(this.item_icon, d_currency.icon);
                this.item_name.text = d_currency['name_' + GameMgr.client_language];
            }
            let d_item = cfg.item_definition.item.get(this.item_id);
            if (d_item) {
                game.LoadMgr.setImgSkin(this.item_icon, d_item.icon);
                this.item_name.text = d_item['name_' + GameMgr.client_language];
            }
            this.item_count.x = this.item_name.textField.textWidth + this.item_name.x;

            this.item_count.text = 'x' + parseInt(reward[1]);
            let counter: number = info.counter;
            if (!counter) counter = 0;
            if (counter > d_task_info.target) counter = d_task_info.target;

            let delta = Page_Huiye_Record.getActivityDeltaDay();
            this.lock.visible = d_activity_task.reward_limit_day > delta;
            this.container_info.visible = !this.lock.visible;
            if (d_activity_task.reward_limit_day > delta) {
                this.lock_label.text = game.Tools.strOfLocalization(3595, [game.Tools.strOfLocalization(3595 + d_activity_task.reward_limit_day)]);
            }
        }
        private setBtnGrayDisable(gray: boolean) {
            game.Tools.setGrayDisable(this.btn_get, gray);
        }

    }


    export class Page_Huiye_Record extends Page_Activity_Base {
        public static activity_id: number = 220405;

        public static getActivityDeltaDay(): number {
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }

        public static haveRedPoint(): boolean {
            let lst = UI_Activity.getPeriodTaskList(Page_Huiye_Record.activity_id);
            let delta = Page_Huiye_Record.getActivityDeltaDay();
            for (let data of lst) {
                if (!data['rewarded'] && data['achieved']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData.reward_limit_day <= delta) return true;
                }
            }
            return false;
        }
        private scrollview: capsui.CScrollView;
        private empty: Laya.Sprite;
        private score: Laya.Label;

        private all_data_lst: Array<Object> = [];
        private show_data_lst: Array<Object> = [];
        private scoreBar: Laya.Sprite;
        private per_height: number = 151;


        public onPageCreate() {
            this.scrollview = this.me.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));

            let tabs_parent = this.me.getChildByName('tabs') as Laya.Sprite;
            this.empty = this.me.getChildByName('empty') as Laya.Sprite;
            this.scoreBar = this.me.getChildByName('content').getChildByName('scorebar').getChildByName('scrollpoint') as Laya.Sprite;

        }

        public onShow() {
            let lst = UI_Activity.getPeriodTaskList(Page_Huiye_Record.activity_id);
            this.all_data_lst = lst;
            this.refresh_list();
            this.refreshProgress();
        }
        public refreshProgress() {
            (this.me.getChildByName('activity_score') as Laya.Label).text = UI_Bag.get_item_count(309056).toString();
            let scoreBarBg = this.me.getChildByName('content').getChildByName('scorebar').getChildByName('scrollbar') as Laya.Sprite;
            scoreBarBg.height = this.show_data_lst.length * this.per_height - 50;
            let max = -1;
            for (let i = 0; i < this.show_data_lst.length; i++) {
                if (this.show_data_lst[i]['achieved'] && !this.show_data_lst[i]['rewarded']) {
                    max = i;
                    break;
                }

                if (!this.show_data_lst[i]['achieved']) {
                    let taskData = cfg.events.base_task.get(cfg.activity.period_task.get(this.show_data_lst[i]['id']).base_task_id);
                    if (i == 0) {
                        if (UI_Bag.get_item_count(309056)) {
                            let height = UI_Bag.get_item_count(309056) / taskData.target * this.per_height * 0.5;
                            this.scoreBar.height = height;
                            (this.me.getChildByName('content').getChildByName('scorebar').getChildByName('point') as Laya.Sprite).y = height - 7;
                        } else {
                            this.scoreBar.height = 0;
                            (this.me.getChildByName('content').getChildByName('scorebar').getChildByName('point') as Laya.Sprite).y = 0;
                        }

                    } else {
                        let lastData = cfg.events.base_task.get(cfg.activity.period_task.get(this.show_data_lst[i - 1]['id']).base_task_id);
                        let height = ((UI_Bag.get_item_count(309056) - lastData.target) / (taskData.target - lastData.target) + i - 0.5) * this.per_height;
                        this.scoreBar.height = height;
                        (this.me.getChildByName('content').getChildByName('scorebar').getChildByName('point') as Laya.Sprite).y = height - 7;
                    }
                    if (max < 0) {
                        max = i - 1;
                    }
                    this.scrollview.rate = Math.min(1, max / (this.show_data_lst.length - 5));
                    return;
                }
            }
            if (max < 0) {
                this.scrollview.rate = 1;
            } else {
                this.scrollview.rate = Math.min(1, max / (this.show_data_lst.length - 5));
            }
            
            this.scoreBar.height = this.show_data_lst.length * this.per_height - 51;
            (this.me.getChildByName('content').getChildByName('scorebar').getChildByName('point') as Laya.Sprite).y = this.scoreBar.height - 7;
        }

        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.show_data_lst[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container, this);
            }
            cache_data['cell'].show(data);

        }

        private refresh_list() {
            let delta = Page_Huiye_Record.getActivityDeltaDay();
            this.show_data_lst = [];
            let _index = 0;
            for (let data of this.all_data_lst) {
                let cfgData = cfg.activity.period_task.get(data['id']);
                if (cfgData.reward_limit_day <= delta) {
                    this.show_data_lst.splice(_index++, 0, data);
                } else {
                    this.show_data_lst.push(data);
                }
            }
            // this.empty.visible = this.show_data_lst.length == 0;
            this.scrollview.reset();
            this.scrollview.addItem(this.show_data_lst.length);
        }
        // 由于show_list与实际数据不匹配，完成任务时需要额外修改rewarded
        public task_rewarded(task_id: number) {
            for (let task of this.show_data_lst) {
                if (task['id'] == task_id) {
                    task['rewarded'] = true;
                    return;
                }
            }
        }

        public onClose() {
            UI_Huiye.Inst.refresh_red_point(2);
        }

    }
}