module uiscript {
    export class UI_Huiye extends UIBase {
        public static Inst: UI_Huiye = null;
        public static activity_id: number = 220401;

        constructor() {
            super(new ui.huiye.huiyeUI());
            UI_Huiye.Inst = this;
        }

        public static have_reddot(): boolean {
            if (Page_Huiye_Task.haveRedPoint() || Page_Huiye_Record.haveRedPoint() || Page_Huiye_Collect.haveRedPoint()) {
                return true;
            }
            return false;
        }
        private bg_main: Laya.Image;

        private container_top: Laya.Sprite;
        private container_tip: Laya.Sprite;
        private container_logo: Laya.Sprite;
        private content: Laya.Sprite;
        private btn_task: Laya.Sprite;
        private btn_record: Laya.Sprite;
        private btn_game: Laya.Sprite;
        private btn_collect: Laya.Sprite;

        private locking: boolean;
        private pages: Array<Page_Activity_Base> = [];
        private _cur_page: Page_Activity_Base;
        // private effect: Laya.Scene;
        private origin_btn_y: Array<number>;

        public onCreate() {
            this.container_top = this.me.getChildByName("top") as Laya.Sprite;
            this.container_tip = this.me.getChildByName("tip") as Laya.Sprite;
            this.container_logo = this.me.getChildByName("logo") as Laya.Sprite;
            this.content = this.me.getChildByName("content") as Laya.Sprite;

            this.bg_main = (this.content.getChildByName('bg') as Laya.Sprite).getChildByName('bg') as Laya.Image;

            (this.container_top.getChildByName('back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.on_close_btn_click();
            });
            (this.container_tip.getChildByName('tip') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Liandong_Rules.Inst.show(E_Liandong_Rules_Style.Main);
            });

            this.pages.push(new Page_Huiye_Collect(this.me.getChildByName('Page_Collect') as Laya.Sprite));
            this.pages.push(new Page_Huiye_Game(this.me.getChildByName('Page_Game') as Laya.Sprite));
            this.pages.push(new Page_Huiye_Record(this.me.getChildByName('Page_Record') as Laya.Sprite));
            this.pages.push(new Page_Huiye_Task(this.me.getChildByName('Page_Task') as Laya.Sprite));

            this.btn_collect = this.content.getChildByName('collection') as Laya.Sprite;
            this.btn_game = this.content.getChildByName('game') as Laya.Sprite;
            this.btn_record = this.content.getChildByName('record') as Laya.Sprite;
            this.btn_task = this.content.getChildByName('task') as Laya.Sprite;

            this.origin_btn_y = [];
            this.origin_btn_y.push(this.btn_collect.y);
            this.origin_btn_y.push(this.btn_game.y);
            this.origin_btn_y.push(this.btn_record.y);
            this.origin_btn_y.push(this.btn_task.y);

            (this.content.getChildByName('collection') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(0);
            });
            (this.content.getChildByName('game') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(1);
            });
            (this.content.getChildByName('record') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(2);
            });
            (this.content.getChildByName('task') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(3);

            });

            app.NetAgent.addListener2Lobby('NotifyMatchGameStart', Laya.Handler.create(this, (msg) => {
                if (this.enable) {
                    GameMgr.Inst.in_huiye = true;
                }
                if (this._cur_page && this._cur_page.enable) {
                    this._cur_page.enable = false;
                }
            }));

        }

        public show() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
            game.LoadMgr.setImgSkin(this.bg_main, 'myres/activity_huiye/bg.jpg');
            this.locking = true;
            this.enable = true;
            this.btn_collect.y = this.origin_btn_y[0];
            this.btn_game.y = this.origin_btn_y[1];
            this.btn_record.y = this.origin_btn_y[2];
            this.btn_task.y = this.origin_btn_y[3];
            this.refresh_red_point();
            UIBase.anim_alpha_in(this.bg_main, {}, 300);
            UIBase.anim_alpha_in(this.btn_collect, { y: -30 }, 200, 400);
            UIBase.anim_alpha_in(this.btn_game, { y: -30 }, 200, 400);
            UIBase.anim_alpha_in(this.btn_record, { y: 30 }, 200, 400);
            UIBase.anim_alpha_in(this.btn_task, { y: 30 }, 200, 400);

            UIBase.anim_alpha_in(this.container_top, { y: -30 }, 200, 0, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            UIBase.anim_alpha_in(this.container_tip, { y: 0 }, 200);

            UIBase.anim_alpha_in(this.container_logo, { y: 300 }, 200);
            game.Tools.localUISrc('myres/activity_huiye/btn_match1.png');
            if (!Laya.LocalStorage.getItem(game.Tools.eeesss('huiye_rules' + GameMgr.Inst.account_id))) {
                Laya.LocalStorage.setItem(game.Tools.eeesss('huiye_rules' + GameMgr.Inst.account_id), '1');
                UI_Liandong_Rules.Inst.show(E_Liandong_Rules_Style.Main);
            }
        }

        public closeNowPage() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
        }

        private on_close_btn_click() {
            this.close();
        }

        public close() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
            UIBase.anim_alpha_out(this.btn_collect, { y: 30 }, 200, 0, Laya.Handler.create(this, () => {
                this.enable = false;
                GameMgr.Inst.EnterLobby();
            }));
            UIBase.anim_alpha_out(this.btn_game, { y: 30 }, 200);
            UIBase.anim_alpha_out(this.btn_record, { y: -30 }, 200);
            UIBase.anim_alpha_out(this.btn_task, { y: -30 }, 200);
            UIBase.anim_alpha_out(this.container_top, { y: 30 }, 200);
            UIBase.anim_alpha_out(this.container_tip, {}, 200);
            UIBase.anim_alpha_out(this.container_logo, {}, 200);

        }

        public onDisable() {
            Laya.timer.clearAll(this);
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.enable = false;
            }
            Laya.loader.clearTextureRes('myres/activity_huiye/btn_match1.png');
            Laya.loader.clearTextureRes('myres/activity_huiye/btn_cancel_match1.png');


        }
        public show_page(index: number) {
            if (index >= this.pages.length) {
                return;
            }
            this.locking = true;
            Laya.timer.once(200, this, ()=>{
                this.locking = false;
            })
            this._cur_page = this.pages[index];
            this.pages[index].show();
        }
        public refresh_red_point(pageIndex: number = -1) {
            if (pageIndex == 2 || pageIndex < 0) {
                (this.content.getChildByName('record').getChildByName('redpoint') as Laya.Sprite).visible = Page_Huiye_Record.haveRedPoint();
            }
            if (pageIndex == 3 || pageIndex < 0) {
                (this.content.getChildByName('task').getChildByName('redpoint') as Laya.Sprite).visible = Page_Huiye_Task.haveRedPoint();
            }
            if (pageIndex == 0 || pageIndex < 0) {
                (this.content.getChildByName('collection').getChildByName('redpoint') as Laya.Sprite).visible = Page_Huiye_Collect.haveRedPoint();
            }
        }

    }
}