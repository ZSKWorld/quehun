/**
* name 
*/
module uiscript{
	export class UI_Info_Base extends UIBase {

		public root: Laya.Sprite;
		private origin_root_y: number;
		protected desc: Laya.Label;
		private btn: Laya.Button;
		private origin_height: number;
		private locking: boolean;
		private resizeSprList:Array<Laya.Sprite> = [];
		private resetYSprList: Array<Laya.Sprite> = [];
		private originHeightList:Array<number> = [];
		private originYList: Array<number> = [];
		private onCloseHandler: Laya.Handler;

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.origin_root_y = this.root.y;
			this.resizeSprList = [];
			this.resizeSprList.push(this.root.getChildAt(0) as Laya.Sprite);
			this.resizeSprList.push(this.root.getChildAt(1) as Laya.Sprite);
			this.originHeightList = [];
			for (let spr of this.resizeSprList) {
				this.originHeightList.push(spr.height);
			}

			this.resetYSprList.push(this.root.getChildByName('bg0').getChildByName('left') as Laya.Sprite);
			this.resetYSprList.push(this.root.getChildByName('bg0').getChildByName('right') as Laya.Sprite);
			this.resetYSprList.push(this.root.getChildByName('btn') as Laya.Sprite);
			for (let spr of this.resetYSprList) {
				this.originYList.push(spr.y);
			}
			

			this.desc = this.root.getChildByName('desc') as Laya.Label;
			this.origin_height = this.desc.height;
			
            this.btn = this.me.getChildByName('btn') as Laya.Button;
			this.locking = false;
			
            this.btn.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            (this.root.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
			if (GameMgr.client_language == 'kr') {
				this.desc.font = 'NotoSansKR';
			}
		}

		public show(desc:string, full_close: boolean = true,onCloseHandler?: Laya.Handler) {
			this.set_desc(desc);
			this.btn.mouseEnabled = full_close;
			this.onCloseHandler = onCloseHandler;
			this.locking = true;
			this.enable = true;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
		}

		public close() {
			this.locking = true;
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
				this.onCloseHandler?.run();
				this.onCloseHandler = null;
			}));
		}

		protected set_desc(desc:string) {
			this.desc.text = desc;
			let height = this.desc.textField.textHeight * this.desc.scaleY;
			let offset_y = Math.max(0, height - this.origin_height);
			for (let i = 0;i < this.resizeSprList.length; i++) {
				this.resizeSprList[i].height = this.originHeightList[i] + offset_y;
			}

			for (let i = 0;i < this.resetYSprList.length; i++) {
				this.resetYSprList[i].y = this.originYList[i] + offset_y;
			}
			this.root.y = this.origin_root_y - offset_y / 2;
		}

		
	}
}