/**
* name 
*/
module uiscript{
	export class UI_Info_Mid extends UI_Info_Base {

		public static Inst:UI_Info_Mid = null;


		constructor(){
			super(new ui.both_ui.info_midUI());
			UI_Info_Mid.Inst = this;
		}
	}
}