/**
* name 
*/
module uiscript{
	export class UI_Info_Mid_Title extends UI_Info_Base {

		public static Inst:UI_Info_Mid_Title = null;
        public title: Laya.Label;

		constructor(){
			super(new ui.both_ui.info_midUI());
			UI_Info_Mid_Title.Inst = this;
		}

        public onCreate() {
            super.onCreate();
            this.title = this.root.getChildByName('title') as Laya.Label;
        }

        public show_title(desc:string, full_close: boolean = true, title: string) {
			super.show(desc, full_close);
            this.title.text = title;
		}
	}
}