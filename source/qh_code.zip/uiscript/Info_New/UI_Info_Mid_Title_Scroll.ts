/**
* name 
*/
module uiscript {
    export class UI_Info_Mid_Title_Scroll extends UIBase {

        public static Inst: UI_Info_Mid_Title_Scroll = null;

        private root: Laya.Sprite;
        private btn: Laya.Button;
        private panel: Laya.Panel;
        private label_desc: Laya.Label;
        private scrollbar: capsui.CScrollBar;
        private locking: boolean;
        public title: Laya.Label;


        constructor() {
            super(new ui.both_ui.info_mid_title_scrollUI());
            UI_Info_Mid_Title_Scroll.Inst = this;
        }

        public onCreate() {

            this.root = this.me.getChildByName('root') as Laya.Sprite;

            this.panel = this.root.getChildByName('content') as Laya.Panel;
            this.label_desc = this.panel.getChildByName('desc') as Laya.Label;
            (this.root.getChildAt(0).getChildAt(0) as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);

            this.scrollbar = (this.root.getChildByName('scrollbar') as Laya.Sprite).scriptMap['capsui.CScrollBar'];
            this.scrollbar.init(new Laya.Handler(this, rate => {
                this.panel.vScrollBar.value = this.panel.vScrollBar.max * rate;
            }));
            this.panel.vScrollBarSkin = '';
            this.panel.vScrollBar.on('change', this, () => {
                this.refresh_scroll_bar();
            });

            (this.root.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);

            (this.root.getChildByName('close') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);

            this.btn = this.me.getChildByName('btn') as Laya.Button;

            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.title = this.root.getChildByName('title') as Laya.Label;

            if (GameMgr.client_language == 'kr') {
                this.label_desc.font = 'NotoSansKR';
            }
        }

        public show(desc: string, title: string, full_close: boolean = true) {
            this.set_desc(desc);
            this.title.text = title;
            this.btn.mouseEnabled = full_close;
            this.locking = true;
            this.enable = true;
            //翻到顶部
            this.panel.vScrollBar.value = 0;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public close() {
            this.locking = true;
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        private set_desc(desc: string) {
            this.label_desc.text = desc;
            this.label_desc.height = this.label_desc.textField.textHeight;
            this.panel.refresh();
            this.refresh_scroll_bar();
        }

        private refresh_scroll_bar() {
            let h: number = this.label_desc.height;
            if (h > 0) {
                this.scrollbar.setVal(this.panel.vScrollBar.value / this.panel.vScrollBar.max, this.panel.height / h);
            } else {
                this.scrollbar.setVal(0, 1);
            }
        }
    }
}