/**
* name 
*/
module uiscript{
	export class UI_Info_Small extends UI_Info_Base {

		public static Inst:UI_Info_Small = null;


		constructor(){
			super(new ui.both_ui.info_smallUI());
			UI_Info_Small.Inst = this;
		}
		
		protected set_desc(desc:string) {
			super.set_desc(desc);
			if (this.desc.textField.textHeight > 1.5 * this.desc.fontSize) {
				this.desc.align = 'left';
			} else {
				this.desc.align = 'center';
			}
		}
	}
}