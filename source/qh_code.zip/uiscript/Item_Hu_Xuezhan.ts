/**
* name 
*/
module uiscript{
    export class Item_Hu_Xuezhan {
        private me:Laya.Sprite;
        private container_title:Laya.Sprite = null;
		private container_score:Laya.Sprite = null;
		private img_parent:Laya.Sprite = null;
        private score_imgs:Array<Laya.Image> = [];
        private effect_yiman:game.UIEffect = null;
		private origin_x:number = 0;
        private origin_y:number = 0;
		private _index:number = 0;
		private txt_delta:Laya.Label;
		private name:Laya.Sprite;
		private head: UI_Head;
		private audio_id: number;
		private timerManager: UI_TimerManager = null;
		private tweenManager: UI_TweenManager = null;
		private isDoAnimation: boolean = false;
		private score: number;
		private titleId: number;
		private delta: number;

		
        constructor(me:Laya.Sprite, index:number) {
			this.me = me;
			this.txt_delta = this.me.getChildByName('label_delta') as Laya.Label;
            this.origin_y = this.me.y;
			this.origin_x = this.me.x;
			this._index = index;
			this.me.visible = false;
            this.container_title = me.getChildByName('container_title') as Laya.Sprite;
			this.container_score = me.getChildByName('container_score') as Laya.Sprite;
			this.img_parent = this.container_score.getChildByName('parent') as Laya.Sprite;
			this.name = me.getChildByName('name') as Laya.Sprite;
			this.head = new UI_Head(me.getChildByName('head') as Laya.Sprite, '');
			for (let i:number = 0; i < 7; i++) {
				this.score_imgs.push(this.container_score.getChildByName(i.toString()) as Laya.Image);
			}
			this.timerManager = new UI_TimerManager();
			this.tweenManager = new UI_TweenManager();
        }

		public show(score: number, title_id: number, delta: number = 0, force: boolean = false, doAnim: boolean = true){
          
			if (this.audio_id) {
				view.AudioMgr.StopAudio(this.audio_id);
				this.audio_id = 0;
			}
			Laya.Tween.clearAll(this.me);
			this.tweenManager.clearAllTweens();
			this.timerManager.clear();
			if (delta == 0 && !force) {
				this.me.visible = false;
				this.onDisable();
				return;
			}

			this.score = score;
			this.titleId = title_id;
			this.delta = delta;
			
			if (!doAnim) {
				this.isDoAnimation = false;
				this.timerManager.clear();
				this.tweenManager.completeAllTweens();
				this.showRecord(this.score, this.titleId, this.delta);
				return;
			}
			this.isDoAnimation = true;
			this.timerManager.start();
            this.container_title.alpha = 0;
            this.container_score.alpha = 1;
            this.container_title.scale(1.5, 1.5);
            this.me.visible = true;
			this.me.alpha = 1;
            this.setScore(score);
            this.setTitle(title_id);
			let dx:number = 0;
			let dy:number = 0;
			switch(this._index) {
				case 0: dy = -80; break;
				case 1: dx = -80; break;
				case 2: dy = 80; break;
				case 3: dx = 80; break;
			}
			
			this.me.x = this.origin_x + dx;
			this.me.y = this.origin_y + dy;
			this.me.alpha = 0;
			this.tweenManager.addTweenTo(this.me, { alpha: 1, x: this.origin_x, y: this.origin_y }, 100, null, null, 120);
			
            if (title_id) {
				this.tweenManager.addTweenTo(this.container_title, {alpha:1, scaleX:0.5, scaleY:0.5}, 150, null,null, 750);
			}
			let needchange = false;
			this.txt_delta.visible = false;
			let seat = view.DesktopMgr.Inst.localPosition2Seat(this._index);
			let accountinfo:Object = view.DesktopMgr.Inst.player_datas[seat];
			
			view.DesktopMgr.Inst.setNickname(this.name, seat, '#c3e2ff', '#ffffff', true);
			this.head.id = accountinfo['avatar_id'];
			this.head.set_head_frame(accountinfo['account_id'], accountinfo['avatar_frame']);

			if (delta != 0) {
				needchange = true;
				if (delta > 0) {
					this.txt_delta.text = '+' + delta;
					this.txt_delta.color = '#64cf42';
				} else {
					this.txt_delta.text = delta.toString();
					this.txt_delta.color = '#d61111';
				}
				this.txt_delta.visible = true;
				this.txt_delta.alpha = 0;
				this.tweenManager.addTweenTo(this.txt_delta, {alpha: 1}, 100, null, null, 250);
			}
			if (needchange) {
				let nowrate:number = 0;
				for (let i:number = 0; i < 16; i++) {
					this.timerManager.addTimerOnce(600 + 30 * i, ()=>{
						if (nowrate == 0) {
							this.audio_id = view.AudioMgr.PlayAudio(222, 4);
						}
						nowrate++;
						let rate:number = nowrate / 16;
							let d:number = Math.ceil(delta * rate);
							if (nowrate != 16) {
								let _left:number = delta - d;
								if (_left > 0) {
									this.txt_delta.text = '+' + _left;
								} else {
									this.txt_delta.text = _left.toString();
								}
							} else {
								this.txt_delta.visible = false;
							}
							this.setScore(score + d);
					});
				}
			}
		}
		
		private showRecord(score: number, title_id: number, delta: number = 0) {
			this.container_title.alpha = 1;
			this.container_score.alpha = 1;
			this.container_title.scale(0.5, 0.5);
			this.me.visible = true;
			this.me.alpha = 1;
			this.setScore(score + delta);
			this.setTitle(title_id);
			this.me.x = this.origin_x;
			this.me.y = this.origin_y;
			this.txt_delta.visible = false;
			let seat = view.DesktopMgr.Inst.localPosition2Seat(this._index);
			let accountinfo: Object = view.DesktopMgr.Inst.player_datas[seat];

			let nameinfo = view.DesktopMgr.Inst.getPlayerName(seat);
			game.Tools.SetNickname(this.name, nameinfo, false, true);
			this.head.id = accountinfo['avatar_id'];
			this.head.set_head_frame(accountinfo['account_id'], accountinfo['avatar_frame']);


		}

        private setScore(score:number) {
            let upZero = score >= 0;
            let showScore = Math.abs(score).toString();
            for (let i:number = 0; i < this.score_imgs.length; i++) {
                this.score_imgs[i].visible = false;
            }
			let index = 0;
            for (let i = showScore.length - 1; i >= 0; i--) {
                this.score_imgs[index].skin = game.Tools.localUISrc('myres/mjdesktop/number/ww_' + showScore[i] + '.png');
				this.score_imgs[index].visible = true;
				index++;
            }
			
			if (!upZero) {
				this.score_imgs[index].visible = true;
				this.score_imgs[index].skin = game.Tools.localUISrc('myres/mjdesktop/number/ww_minus.png');
			}
			// this.img_parent.x = (showScore.length - 7) * 35;
        }

        private setTitle(title_id) {
			for (let i = 0; i < this.container_title.numChildren; i++) {
				(this.container_title.getChildAt(i) as Laya.Sprite).visible = false;
            }
            if (!title_id) {
                return;
            }
			let yiman_effect:number = 0;
			switch(title_id) {
				case mjcore.E_Dadian_Title.E_Dadian_Title_leijiyiman: yiman_effect = 2;  break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman: yiman_effect = 1;  break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman2: yiman_effect = 2; break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman3: yiman_effect = 2; break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman4: yiman_effect = 2; break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman5: yiman_effect = 2; break;
				case mjcore.E_Dadian_Title.E_Dadian_Title_yiman6: yiman_effect = 2; break;
				default: break;
			}
			if (GameMgr.client_language == 'chs' || GameMgr.client_language == 'chs_t') {
				let list:Array<string> = [];
				switch(title_id) {
					case mjcore.E_Dadian_Title.E_Dadian_Title_manguan: list = ['', 'man', 'guan', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_tiaoman: list = ['', 'tiao', 'man', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_beiman: list = ['', 'bei', 'man', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_sanbeiman: list = ['', 'san', 'bei', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_leijiyiman: list = ['lei', 'ji', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman: list = ['', 'yi', 'man', '']; yiman_effect = 1;  break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman2: list = ['liang', 'bei', 'yi', 'man']; yiman_effect = 2; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman3: list = ['san', 'bei', 'yi', 'man']; yiman_effect = 2; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman4: list = ['si', 'bei', 'yi', 'man']; yiman_effect = 2; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman5: list = ['wu', 'bei', 'yi', 'man']; yiman_effect = 2; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman6: list = ['liu', 'bei', 'yi', 'man']; yiman_effect = 2; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_liuman: list = ['liu1', 'ju', 'man', 'guan']; yiman_effect = 2; break;
					default: break;
				}
				let container:Laya.Sprite = this.container_title.getChildByName('chs') as Laya.Sprite;
				container.visible = true;
				for (let i:number = 0; i < container.numChildren; i++) {
					(container.getChildAt(i) as Laya.Sprite).visible = false;
				}
				for (let i:number = 0; i < list.length; i++) {
					if (list[i] == '') continue;
					let img:Laya.Image = container.getChildAt(i) as Laya.Image;
					img.visible = true;
					img.skin = game.Tools.localUISrc('myres/word_' + list[i] + '.png');
				}
			} else if (GameMgr.client_language == 'en') {
				let container:Laya.Sprite = this.container_title.getChildByName('en') as Laya.Sprite;
				container.visible = true;
				let img:Laya.Image = container.getChildAt(0) as Laya.Image;
				switch(title_id) {
					case mjcore.E_Dadian_Title.E_Dadian_Title_manguan: img.skin = 'en/myres/Mangan.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_tiaoman: img.skin = 'en/myres/Haneman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_beiman: img.skin = 'en/myres/Baiman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_sanbeiman: img.skin = 'en/myres/Sanbaiman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_leijiyiman: img.skin = 'en/myres/Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman: img.skin = 'en/myres/Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman2: img.skin = 'en/myres/Double Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman3: img.skin = 'en/myres/Triple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman4: img.skin = 'en/myres/Quadruple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman5: img.skin = 'en/myres/Quintuple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman6: img.skin = 'en/myres/Sextuple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_liuman: img.skin = 'en/myres/Mangan at Draw.png'; break;
					default: break;
				}
			} else if (GameMgr.client_language == 'jp') {
				let list:Array<string> = [];
				switch(title_id) {
					case mjcore.E_Dadian_Title.E_Dadian_Title_manguan: list = ['', 'man', 'guan', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_tiaoman: list = ['', 'tiao', 'man', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_beiman: list = ['', 'bei', 'man', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_sanbeiman: list = ['', 'san', 'bei', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_leijiyiman: list = ['shu', 'ji', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman: list = ['', 'yi', 'man', '']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman2: list = ['er', 'bei', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman3: list = ['san', 'bei', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman4: list = ['si', 'bei', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman5: list = ['wu', 'bei', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman6: list = ['liu', 'bei', 'yi', 'man']; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_liuman: list = ['liu1', 'ju', 'man', 'guan']; break;
					default: break;
				}
				let container:Laya.Sprite = this.container_title.getChildByName('chs') as Laya.Sprite;
				container.visible = true;
				for (let i:number = 0; i < container.numChildren; i++) {
					(container.getChildAt(i) as Laya.Sprite).visible = false;
				}
				for (let i:number = 0; i < list.length; i++) {
					if (list[i] == '') continue;
					let img:Laya.Image = container.getChildAt(i) as Laya.Image;
					img.visible = true;
					img.skin = 'jp/myres/word_' + list[i] + '.png';
				}
			} else if (GameMgr.client_language == 'kr') {
				let container: Laya.Sprite = this.container_title.getChildByName('en') as Laya.Sprite;
				container.visible = true;
				let img: Laya.Image = container.getChildAt(0) as Laya.Image;
				switch (title_id) {
					case mjcore.E_Dadian_Title.E_Dadian_Title_manguan: img.skin = 'kr/myres/Mangan.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_tiaoman: img.skin = 'kr/myres/Haneman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_beiman: img.skin = 'kr/myres/Baiman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_sanbeiman: img.skin = 'kr/myres/Sanbaiman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_leijiyiman: img.skin = 'kr/myres/Accumulate Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman: img.skin = 'kr/myres/Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman2: img.skin = 'kr/myres/Double Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman3: img.skin = 'kr/myres/Triple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman4: img.skin = 'kr/myres/Quadruple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman5: img.skin = 'kr/myres/Quintuple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_yiman6: img.skin = 'kr/myres/Sextuple Yakuman.png'; break;
					case mjcore.E_Dadian_Title.E_Dadian_Title_liuman: img.skin = 'kr/myres/Mangan at Draw.png'; break;
					default: img.skin = ''; break;
				}
			}
			// if (yiman_effect != 0) {
			// 	Laya.timer.once(1000, this, ()=>{
			// 		let target:Laya.Sprite;
			// 		let url:string;
			// 		if (GameMgr.client_language == 'en') {
			// 			target = this.container_title.getChildByName('effect_yiman_en') as Laya.Sprite;
			// 			url = 'scene/effect_yiman2.lh';
			// 		} else {
			// 			if (yiman_effect == 1) {
			// 				target = this.container_title.getChildByName('effect_yiman') as Laya.Sprite;
			// 				url = 'scene/effect_yiman.lh';
			// 			} else {
			// 				target = this.container_title.getChildByName('effect_yiman2') as Laya.Sprite;
			// 				url = 'scene/effect_yiman2.lh';
			// 			}
			// 		}

			// 		this.effect_yiman = game.FrontEffect.Inst.create_ui_effect(target, url, new Laya.Point(0, 0), 10.4);
			// 	});
			// }
        }


		public hide() {
			this.me.visible = false;
			this.onDisable();
			if (this.audio_id) {
				view.AudioMgr.StopAudio(this.audio_id);
				this.audio_id = 0;
			}
			let dx:number = 0;
			let dy:number = 0;
			switch(this._index) {
				case 0: dy = -80; break;
				case 1: dx = -80; break;
				case 2: dy = 80; break;
				case 3: dx = 80; break;
			}
			Laya.Tween.to(this.me, {alpha: 0, x: this.origin_x + dx, y: this.origin_y + dy}, 120);

			if (this.effect_yiman) {
				this.effect_yiman.destory();
				this.effect_yiman = null;
			}

		}

		

		public onDisable() {
			Laya.timer.clearAll(this);
			this.timerManager.clear();
			this.timerManager.stop();
			this.tweenManager.clearAllTweens();
		}

		public skipAnim() {
			if (!this.isDoAnimation) {
				return;
			}
			this.isDoAnimation = false;
			this.timerManager.clear();
			this.tweenManager.completeAllTweens();
			this.showRecord(this.score, this.titleId, this.delta);
		}
    }

}