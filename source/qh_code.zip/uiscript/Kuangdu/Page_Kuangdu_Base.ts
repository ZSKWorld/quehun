module uiscript {
    export class Page_Kuangdu_Base extends UIBase{
        public content:Laya.Sprite;
        private blackmask:Laya.Sprite;
        private bg:Laya.Image;
        public locking:boolean;

        public onCreate() {
            this.content = this.me.getChildByName('content') as Laya.Sprite;
            this.blackmask = this.me.getChildByName('blackmask') as Laya.Sprite;
            (this.content.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, this.close);
            this.onPageCreate();
        }

        public onPageCreate() {

        }
        public show() {
            this.locking = true;
            this.enable = true;
            Laya.Tween.to(this.blackmask, {alpha: 0.3}, 200, null, Laya.Handler.create(this.blackmask, ()=>{
				
				this.blackmask['alpha'] = 0.3;
			}));
            UIBase.anim_pop_out(this.content, new Laya.Handler(this, ()=>{
                this.locking = false;
                this.onShowFinish();
            }));
            this.onShow();
        }

        public onShow() {

        }

        public onShowFinish() {

        }
        
        public close() {
            this.locking = true;
            Laya.Tween.to(this.blackmask, {alpha: 0}, 200, null, Laya.Handler.create(this.blackmask, ()=>{
				
				this.blackmask['alpha'] = 0;
			}));
            UIBase.anim_pop_hide(this.content, new Laya.Handler(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
            this.onClose();
        }

        public onClose() {

        }
    }
}