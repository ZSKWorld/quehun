module uiscript {
    export class Page_Kuangdu_Match extends Page_Kuangdu_Base {
        public static activity_id:number = 1176;
        
        private dora_btn:Laya.Button;
        private chiyu_btn:Laya.Button;
        private matching_label:Laya.Label;
        private _matching:boolean = false;
        private cancelStr:string;
        private cancelShowIndex:number = 0;

        
        private mode:game.EMatchMode;


        public get matching():boolean {
            return this._matching;
        }

        public set matching(state:boolean) {
            if (this._matching == state) {
                return;
            }
            UI_Kuangdu.Inst.matching = state;
            this._matching = state;
          
            
            if (this._matching) {
                if (this.mode == game.EMatchMode.chiyu) {
                    this.setGrayDisable(this.dora_btn, true);
                    this.matching_label = this.chiyu_btn.getChildByName('matching') as Laya.Label;
                } else {
                    this.setGrayDisable(this.chiyu_btn, true);
                    this.matching_label = this.dora_btn.getChildByName('matching') as Laya.Label;
                }
                this.showCancelText();
                Laya.timer.loop(800, this, this.showCancelText);
            } else {
                Laya.timer.clear(this, this.showCancelText);
                this.setGrayDisable(this.chiyu_btn, false);
                this.setGrayDisable(this.dora_btn, false);
            }
            if (this.matching_label) {
                this.matching_label.visible = this._matching;
            }
            
        }

        public onPageCreate () {
            this.dora_btn = this.content.getChildByName('dora') as Laya.Button;
            this.chiyu_btn = this.content.getChildByName('chiyu') as Laya.Button;
            this.cancelStr = game.Tools.strOfLocalization(2525);
            (this.dora_btn.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                this.on_dora_btn_click();
            });

            (this.chiyu_btn.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                this.on_chiyu_btn_click();
            });

            let dora_tip = (this.dora_btn.getChildByName('dora_tip') as Laya.Button);
            dora_tip.clickHandler = new Laya.Handler(this, ()=>{
                uiscript.UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3424));
            });

			
            let chiyu_tip = (this.chiyu_btn.getChildByName('chiyu_tip') as Laya.Button);
            chiyu_tip.clickHandler = new Laya.Handler(this, ()=>{
                uiscript.UI_Info_Big.Inst.show(game.Tools.strOfLocalization(3395));
            });
            
            (this.content.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, this.on_close_btn_click);
            (this.content.getChildByName('rule') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                uiscript.UI_Kuangdu_Rules.Inst.show(E_Kuangdu_Rules_Style.Match);
            });

            (this.content.getChildByName('yi') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
               UI_Rules.Inst.show(0, null, 1);
            });

            game.LobbyNetMgr.Inst.add_connect_listener(['OnReconnectStarted', 'OnChangeMainRouteBegin'], this, () => {
				if (this.enable) {
					this.close();
                    if (this.matching) {
                        this.cancelMatch(null);
                    }
				}
			});

            app.NetAgent.addListener2Lobby('NotifyMatchTimeout', Laya.Handler.create(this, (msg)=>{
				this.matching = false;
			}));
        }

      

        private on_close_btn_click() {
            if (this.matching) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3199), Laya.Handler.create(this, ()=>{
                    this.cancelMatch(Laya.Handler.create(this, this.close));
                }));
            } else {
                this.close();
            }
        }

        private on_dora_btn_click() {
            if (this.matching) {
                this.cancelMatch(null);
            } else {
                this.onStartMatchBtnClick(game.EMatchMode.dora);
                this.matching_label;
            }
        }

        private on_chiyu_btn_click() {
            if (this.matching) {
                this.cancelMatch(null);
            } else {
                if (!Laya.LocalStorage.getItem(game.Tools.eeesss('kuangdu_rules_match' + GameMgr.Inst.account_id))) {
                    Laya.LocalStorage.setItem(game.Tools.eeesss('kuangdu_rules_match' + GameMgr.Inst.account_id), '1');
                    UI_Kuangdu_Rules.Inst.show(E_Kuangdu_Rules_Style.Match);
                } else {
                    this.onStartMatchBtnClick(game.EMatchMode.chiyu);
                }
            }
        }

        public cancelMatch(handler:Laya.Handler) {
            this.locking = true;
            let matchMode = cfg.desktop.matchmode.get(this.mode);
            app.NetAgent.sendReq2Lobby('Lobby', 'cancelUnifiedMatch', {
                match_sid: matchMode.type + ':' + this.mode
            }, (err, res) => {
                this.locking = false;
                
                if (err || res['error']) {
					UIMgr.Inst.showNetReqError('cancelUnifiedMatch', err, res);
				} else {
					this.matching = false;
                    if (handler) {
                        handler.run();
                    }
				}
            });
        }

        public startMatch() {
            this.matching = true;
            let matchMode = cfg.desktop.matchmode.get(this.mode);
            app.NetAgent.sendReq2Lobby('Lobby', 'startUnifiedMatch', {
                match_sid: matchMode.type + ':' + this.mode,
				client_version_string: GameMgr.Inst.getClientVersion()
            }, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('startUnifiedMatch', err, res);
					this.matching = false;
				} else {
					
				}
            });
        }

        private showCancelText() {
            this.cancelShowIndex = ++this.cancelShowIndex > 3 ? 1 : this.cancelShowIndex;
            let showStr = this.cancelStr;
            for (let i = 0; i < this.cancelShowIndex; i++) {
                showStr += '.';
            }
            this.matching_label.text = showStr;
        }

        public onDisable() {
            this.matching = false;
        }

        private onStartMatchBtnClick(mode:game.EMatchMode) {
            this.mode = mode;
            this.startMatch();
           
        }

        public onShow() {
            (this.chiyu_btn.getChildByName('matching') as Laya.Label).visible = false;
            (this.dora_btn.getChildByName('matching') as Laya.Label).visible = false;
        }

        private setGrayDisable(sprite: Laya.Sprite, v: boolean) {
			if (v) {
                let a:Array<number> = [0.8, 0, 0, 0, 0,
                                        0, 0.8, 0, 0, 0,
                                        0, 0, 0.8, 0, 0,
                                        0, 0, 0, 1, 0];
				(sprite.getChildByName('btn') as Laya.Button).mouseEnabled = false;
				sprite.filters = [new Laya.ColorFilter(a)];
			} else {
				(sprite.getChildByName('btn') as Laya.Button).mouseEnabled = true;
				sprite.filters = [];
			}
          
        }
    }
}