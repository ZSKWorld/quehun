module uiscript {
    class TaskCell {
		public me:Laya.Sprite;

		private container_info:Laya.Sprite;
		private item_icon:Laya.Image;
		private item_name:Laya.Label;
    
		private task_name:Laya.Label;
	
		private btn_get:Laya.Button;
        private getted:Laya.Sprite;
        

		private id:number = 0;
        private item_id:number = 0;
        private reward_count:number = 0;

		public constructor(me: Laya.Sprite) {
			this.me = me;
			this.me.visible = false;
			this.container_info = me.getChildByName('info') as Laya.Sprite;
            this.task_name = this.container_info.getChildByName('requirement') as Laya.Label;
			this.item_icon = this.container_info.getChildByName('item').getChildByName('item') as Laya.Image;
			this.item_name = this.container_info.getChildByName('item_name') as Laya.Label;
			
            this.btn_get = this.container_info.getChildByName('btn_get') as Laya.Button;
            this.getted = this.container_info.getChildByName('getted') as Laya.Sprite;
			(this.container_info.getChildByName('btn_item') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				UI_ItemDetail.Inst.show(this.item_id);
			}, null, false);
		} 

		public show(info:any) {
			this.me.visible = true;
			let id = info.id;
			this.id = id;
			let d_activity_task = cfg.activity.period_task.get(info.id);
			let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
			
			this.container_info.visible = true;
	

			if (info.rewarded) {
                this.getted.visible = true;
                this.btn_get.visible = false;
			} else {
                this.getted.visible = false;
                this.btn_get.visible = true;
				if (info.achieved) {
					this.setBtnGrayDisable(false);
					this.btn_get.clickHandler = Laya.Handler.create(this, ()=>{
						this.btn_get.mouseEnabled = false;
						app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: id}, (err, res) => {
							this.btn_get.mouseEnabled = true;
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
							} else {
								if (this.id == id) {
									this.getted.visible = true;
                                    this.btn_get.visible = false;
									let s:string = game.Tools.strOfLocalization(2234) + (this.item_name.text);
									UI_LightTips.Inst.show(s);
                                   
								}
                                info['rewarded'] = true;
								UI_Activity.onTaskRewarded(id);
							}
						});
					}, null, false);
				} else {
					this.setBtnGrayDisable(true);
					this.btn_get.clickHandler = null;
				}
			}

			this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
			// this.task_name.fontSize = 26;
            // this.task_name.y = 34;
            // if (this.task_name.textField.textHeight > 28) {
            //     this.task_name.fontSize = 20;
            //     this.task_name.y = 36;
            // }
            let reward = d_activity_task.reward.split('-');
			this.item_id = parseInt(reward[0]);
            
            
            this.reward_count = parseInt(reward[1]);
			let d_currency = cfg.item_definition.currency.get(this.item_id);
			if (d_currency) {
				game.LoadMgr.setImgSkin(this.item_icon, d_currency.icon);
				this.item_name.text = d_currency['name_' + GameMgr.client_language] + 'x' + this.reward_count;
			}
			let d_item = cfg.item_definition.item.get(this.item_id);
			if (d_item) {
				game.LoadMgr.setImgSkin(this.item_icon, d_item.icon);
				this.item_name.text = d_item['name_' + GameMgr.client_language] + 'x' + this.reward_count;
			}
			
		}

        private setBtnGrayDisable(gray:boolean) {
            this.btn_get.mouseEnabled = !gray;
            (this.btn_get.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc(gray ? 'myres/activity_kuangdu/btn_incomplete.png' : 'myres/activity_kuangdu/btn_receive.png');
        }
	}
    export class Page_Kuangdu_Reward extends Page_Kuangdu_Base{
        public static activity_id:number = 1177;
        public static haveRedPoint():boolean{
            let lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Reward.activity_id);
            for (let data of lst) {
                if (!data['rewarded'] && data['achieved']) {
                    return true;
                }
            }
            return false;
        }

        private scrollview: capsui.CScrollView;
        private scoreBar: Laya.Sprite;
        private data_lst: Array<Object> = [];
        private per_height:number = 129;
       
        public onPageCreate(){
            this.scrollview = this.content.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
            this.scrollview.setElastic();
            this.data_lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Reward.activity_id);
            let scoreBarBg = this.content.getChildByName('content').getChildByName('scorebar').getChildByName('scrollbar') as Laya.Sprite;
            scoreBarBg.height = this.data_lst.length * this.per_height + 8;
            this.scoreBar = this.content.getChildByName('content').getChildByName('scorebar').getChildByName('scrollpoint') as Laya.Sprite;
        }

        private render_item(obj) {
            let container:Laya.Sprite = obj.container;
			let index:number = obj.index;
            let cache_data:Object = obj.cache_data;
            let data = this.data_lst[index];
            if(!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container);
            }
            cache_data['cell'].show(data);
        }

        public onShow() {
            this.data_lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Reward.activity_id);
            this.scrollview.reset();
            this.scrollview.addItem(this.data_lst.length);
            this.refreshProgress();
        }

        public refreshProgress() {
            let max = 0;
            
            for (let i = 0; i < this.data_lst.length; i++) {
                if (this.data_lst[i]['achieved'] && !this.data_lst[i]['rewarded']) {
                    max = i;
                }
                
                if (!this.data_lst[i]['achieved']) {
                    let taskData = cfg.events.base_task.get(cfg.activity.period_task.get(this.data_lst[i]['id']).base_task_id);
                    if (i == 0) {
                        let height = UI_Bag.get_item_count(UI_Kuangdu.item_id) / taskData.target * this.per_height * 0.5;
                        this.scoreBar.height = height;
                    } else {
                        let lastData = cfg.events.base_task.get(cfg.activity.period_task.get(this.data_lst[i - 1]['id']).base_task_id);
                        let height = ((UI_Bag.get_item_count(UI_Kuangdu.item_id) - lastData.target) / (taskData.target - lastData.target) + i - 0.5) * this.per_height;
                        this.scoreBar.height = height;
                       
                    }
                    this.scrollview.rate = Math.min(1, max / (this.data_lst.length - 5));
                    return;
                }
            }
            this.scrollview.rate = Math.min(1, max / (this.data_lst.length - 5));
            this.scoreBar.height = this.data_lst.length * this.per_height;
        }

        public onClose() {
            UI_Kuangdu.Inst.refresh_red_point(0);
            UI_Kuangdu.Inst.refresh_red_point(2);
        }
    }
}