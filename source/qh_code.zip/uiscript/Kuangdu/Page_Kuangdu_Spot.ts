module uiscript {
    class Cell_Spot{
        public lock:Laya.Sprite;
        private lock_label:Laya.Label;
        private name:Laya.Label;
        private index_label:Laya.Label;
        private desc:Laya.Label;
        private index:number;
        private _data:lqc.Sheet_Spot_Event;

        public constructor(me: Laya.Sprite, index:number) {
			this.lock = me.getChildByName('lock') as Laya.Sprite;
            this.lock_label = this.lock.getChildByName('lock') as Laya.Label;
            this.name = me.getChildByName('name') as Laya.Label;
            this.index_label = me.getChildByName('index') as Laya.Label;
            this.desc = me.getChildByName('desc') as Laya.Label;
            this.index = index;
            this._data = cfg.spot.event.get(index+118201);
			(me.getChildByName('play') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
                if (this.lock.visible) return;
                UI_Kuangdu.Inst.closeNowPage();
				GameMgr.Inst.showSpotByEvent(this._data.content_path);
			}, null, false);
            // TODO 刷新显示，加载剧情

            if(index == 4) {
                if(GameMgr.client_language == 'en') {
                    this.desc.width = 462;
                } else {
                    this.desc.width = 455;
                }
            }
		}

        public show() {
            if ((this._data.key_item_id != 0 && UI_Bag.get_item_count(this._data.key_item_id) < this._data.key_amount )) {
                this.name.text = game.Tools.strOfLocalization(3338);
                this.desc.text = game.Tools.strOfLocalization(3338);
                this.index_label.text = game.Tools.strOfLocalization(3338);
                this.lock.visible = true;
                this.lock_label.text = game.Tools.strOfLocalization(3412, [this._data.key_amount.toString()]);
            } else {
                this.name.text = this._data['title_' + GameMgr.client_language];
                this.index_label.text = this._data['subtitle_' + GameMgr.client_language];
                this.desc.text = this._data['content_' + GameMgr.client_language];
                this.lock.visible = false;
            }
        }
    }
    export class Page_Kuangdu_Spot extends Page_Kuangdu_Base {
        public static activity_id: number = 1177;
        private cells:Array<Cell_Spot> = [];
        public static haveRedPoint():boolean{
            let index = Math.max(1, Number(Laya.LocalStorage.getItem(game.Tools.eeesss('kuangdu_spot' + GameMgr.Inst.account_id))));
        
            let data = cfg.spot.event.get(index + 118201);
            if (data && data.key_amount <= UI_Bag.get_item_count(data.key_item_id)) {
                return true;
            } 
            return false;
        }

        public onPageCreate() {
            for(let i = 0; i < 6; i++) {
                this.cells.push(new Cell_Spot(this.content.getChildByName('item_' + i) as Laya.Sprite, i));
            }
        }

        public onShow(){
            let index = 0;
            let have_lock = false;
            for (let cell of this.cells) {
                cell.show();
                
                if (!have_lock) {
                    if (cell.lock.visible) {
                        have_lock = true;
                        Laya.LocalStorage.setItem(game.Tools.eeesss('kuangdu_spot' + GameMgr.Inst.account_id), '' + index);
                    } else if (index == 5) {
                        Laya.LocalStorage.setItem(game.Tools.eeesss('kuangdu_spot' + GameMgr.Inst.account_id), '' + 6);
                    }
                }
                index++;

            }
            UI_Kuangdu.Inst.refresh_red_point(3);
        }
    }
}