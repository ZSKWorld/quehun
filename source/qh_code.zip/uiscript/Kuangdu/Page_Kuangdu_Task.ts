module uiscript {
    class TaskCell {
		public me:Laya.Sprite;

		private container_info:Laya.Sprite;
		private item_icon:Laya.Image;
		private item_name:Laya.Label;
		private item_count:Laya.Label;
        private item_add:Laya.Label;
        private add0:Laya.Label;
		private task_name:Laya.Label;
		private progress_bar:Laya.Sprite;
		private progress_label:Laya.Label;
		private btn_get:Laya.Button;
        private getted:Laya.Sprite;

        private lock:Laya.Sprite;

		private id:number = 0;
        private item_id:number = 0;
        private reward_count:number = 0;
        private father:Page_Kuangdu_Task;

		public constructor(me: Laya.Sprite, father:Page_Kuangdu_Task) {
			this.me = me;
            this.father = father;
			this.me.visible = false;
			this.container_info = me.getChildByName('info') as Laya.Sprite;
            this.task_name = this.container_info.getChildByName('requirement') as Laya.Label;
            if (GameMgr.client_language =='en') {
                this.task_name.fontSize = 22;
                this.task_name.wordWrap = true;
            }
			this.item_icon = this.container_info.getChildByName('item').getChildByName('item') as Laya.Image;
			this.item_name = this.container_info.getChildByName('item_name') as Laya.Label;
			this.item_count = this.container_info.getChildByName('item_count') as Laya.Label;
            this.item_add = this.container_info.getChildByName('add') as Laya.Label;
            this.add0 = this.container_info.getChildByName('add0') as Laya.Label;
			this.progress_bar = this.container_info.getChildByName('bar').getChildByName('val') as Laya.Sprite;
			this.progress_label = this.container_info.getChildByName('progress') as Laya.Label;
            this.btn_get = this.container_info.getChildByName('btn_get') as Laya.Button;
            this.getted = this.container_info.getChildByName('getted') as Laya.Sprite;
            this.lock = this.container_info.getChildByName('lock') as Laya.Sprite;
			(this.container_info.getChildByName('btn_item') as Laya.Button).clickHandler = Laya.Handler.create(this, ()=>{
				UI_ItemDetail.Inst.show(this.item_id);
			}, null, false);
		} 

		public show(info:any) {
			this.me.visible = true;
			let id = info.id;
			this.id = id;
			let d_activity_task = cfg.activity.period_task.get(info.id);
			let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
			
			this.container_info.visible = true;
	

			if (info.rewarded) {
                this.getted.visible = true;
                this.lock.visible = false;
                this.btn_get.visible = false;
			} else {
                this.getted.visible = false;
                this.btn_get.visible = true;
				if (info.achieved) {
					this.setBtnGrayDisable(false);
					this.btn_get.clickHandler = Laya.Handler.create(this, ()=>{
						this.btn_get.mouseEnabled = false;
						app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: id}, (err, res) => {
							this.btn_get.mouseEnabled = true;
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
							} else {
								if (this.id == id) {
									this.getted.visible = true;
                                    this.btn_get.visible = false;
                                    let count = this.reward_count;
                                    let buff_add = UI_Activity.getActivityBuffAdd(117502);
                                    if (buff_add > 0) {
                                        count = Math.floor(buff_add * count / 100);
                                    }
									let s:string = game.Tools.strOfLocalization(2234) + (this.item_name.text + ' x' + count);
									UI_LightTips.Inst.show(s);
                                   
								}
                                this.father.task_rewarded(id);
                                UI_Kuangdu.Inst.refresh_currency_count();
								UI_Activity.onTaskRewarded(id);
                                this.father.refresh_red_dot();
							}
						});
					}, null, false);
				} else {
					this.setBtnGrayDisable(true);
					this.btn_get.clickHandler = null;
				}

                let delta = Page_Kuangdu_Task.getActivityDeltaDay();
                if (d_activity_task.reward_limit_day > delta) {
                    this.lock.visible = true;
                    this.btn_get.visible = false;
                } else {
                    this.lock.visible = false;
                    this.btn_get.visible = true;
                }
			}
            

			this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
			// this.task_name.fontSize = 26;
            // this.task_name.y = 34;
            // if (this.task_name.textField.textHeight > 28) {
            //     this.task_name.fontSize = 20;
            //     this.task_name.y = 36;
            // }
            let reward = d_activity_task.reward.split('-');
			this.item_id = parseInt(reward[0]);
            
            
            this.reward_count = parseInt(reward[1]);
			let d_currency = cfg.item_definition.currency.get(this.item_id);
			if (d_currency) {
				game.LoadMgr.setImgSkin(this.item_icon, d_currency.icon);
				this.item_name.text = d_currency['name_' + GameMgr.client_language];
			}
			let d_item = cfg.item_definition.item.get(this.item_id);
			if (d_item) {
				game.LoadMgr.setImgSkin(this.item_icon, d_item.icon);
				this.item_name.text = d_item['name_' + GameMgr.client_language];
			}
			this.item_count.x = this.item_name.textField.textWidth + this.item_name.x;
            let add = UI_Activity.getActivityBuffAdd(117502);
            let base_num = parseInt(reward[1]);
            let final_num = (Math.floor(base_num * add /100));
            let add_num = final_num - base_num;
            if (add_num > 0) {
                
                
                this.item_count.text = 'x' + final_num + ' (' + base_num;
                this.item_add.visible = true;
                this.item_add.text = '+' + add_num;
                this.add0.visible = true;
                this.item_add.x = this.item_count.textField.textWidth + this.item_count.x;
                this.add0.x = this.item_add.textField.textWidth + this.item_add.x;
            } else {
                this.item_count.text = 'x' + parseInt(reward[1]);
                this.item_add.visible = false;
                this.add0.visible = false;
            }

			let counter:number = info.counter;
			if (!counter) counter = 0;
			if (counter > d_task_info.target) counter = d_task_info.target;
			this.progress_bar.mask.width = 300 * counter / d_task_info.target;
			this.progress_label.text = counter.toString() + '/' + d_task_info.target.toString();
		}

        private setBtnGrayDisable(gray:boolean) {
            this.btn_get.mouseEnabled = !gray;
            this.btn_get.skin = game.Tools.localUISrc(gray ? 'myres/activity_kuangdu/btn_incomplete.png' : 'myres/activity_kuangdu/btn_receive.png');
        }
	}


    export class Page_Kuangdu_Task extends Page_Kuangdu_Base{
        public static activity_id: number = 1178;

        public static getActivityDeltaDay():number{
            let start_time = UI_Activity.getActivityStartTime(this.activity_id) * 1000;
            let day = Math.floor((start_time + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let now = Math.floor((Laya.timer.currTimer + GameMgr.Inst.server_time_delta + 3 * 3600 * 1000) / (24 * 3600 * 1000));
            let delta = Math.max(0, now - day);
            return delta;
        }
        public static haveRedPoint():boolean{
            let lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Task.activity_id);
            let delta = Page_Kuangdu_Task.getActivityDeltaDay();
            for (let data of lst) {
                if (!data['rewarded'] && data['achieved']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData.reward_limit_day <= delta) return true;
                }
            }
            return false;
        }
        private scrollview: capsui.CScrollView;
        private tabs: Array<Laya.Sprite> = [];
        private empty:Laya.Sprite;

        private all_data_lst: Array<Object> = [];
        private show_data_lst: Array<Object> = [];
        private reddot:Laya.Sprite;
        private lock_label:Laya.Label;
        

        public onPageCreate (){
            this.scrollview = this.content.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));
            this.scrollview.setElastic();
            
            let tabs_parent = this.content.getChildByName('tabs') as Laya.Sprite;
            this.empty = this.content.getChildByName('empty') as Laya.Sprite;
            this.reddot = tabs_parent.getChildByName('achieved').getChildByName('redpoint') as Laya.Sprite;
            this.lock_label = this.content.getChildByName('tip') as Laya.Label;
            for (let i = 0; i < tabs_parent.numChildren; i++) {
                this.tabs.push(tabs_parent.getChildAt(i) as Laya.Sprite);
                (tabs_parent.getChildAt(i) as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                    this.on_tab_btn_click(i);
                });
            }
        }

        public onShow() {
            let lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Task.activity_id);
            this.all_data_lst = lst;
            this.on_tab_btn_click(0);
            this.refresh_red_dot();
            let delta = Page_Kuangdu_Task.getActivityDeltaDay();
            if (delta >= 10) {
                this.lock_label.visible = false;
            } else {
                this.lock_label.visible = true;
                this.lock_label.text = game.Tools.strOfLocalization(3413, [game.Tools.strOfLocalization(3414 + delta)]);
            }
        }

        private render_item(obj) {
            let container:Laya.Sprite = obj.container;
			let index:number = obj.index;
            let cache_data:Object = obj.cache_data;
            let _data = this.show_data_lst[index];
            for (let data of this.all_data_lst) {
                if (data['id'] == _data['id']) {
                    _data = data
                }
            }
            if(!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container, this);
            }
            cache_data['cell'].show(_data);
        }

        private on_tab_btn_click(tab_index:number) {
            for (let i = 0; i < this.tabs.length; i++) {
                (this.tabs[i].getChildAt(0) as Laya.Sprite).visible = tab_index != i;
                (this.tabs[i].getChildAt(1) as Laya.Sprite).visible = tab_index == i;
            }
            let delta = Page_Kuangdu_Task.getActivityDeltaDay();
            switch (tab_index) {
                case 0: // 全部
                    this.show_data_lst = [];
                    let _index = 0;
                    for (let data of this.all_data_lst) {
                        let cfgData = cfg.activity.period_task.get(data['id']);
                        if (cfgData.reward_limit_day <= delta) {
                            this.show_data_lst.splice(_index++, 0, data);
                        } else {
                            this.show_data_lst.push(data);
                        }
                    }
                    
                    break;
                case 1: // 未完成
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        if (!data['rewarded'] && !data['achieved']) {
                            let cfgData = cfg.activity.period_task.get(data['id']);
                            if (cfgData.reward_limit_day <= delta) this.show_data_lst.push(data);
                        }
                    }
                    break;
                case 2: // 已完成
                    this.show_data_lst = [];
                    let index = 0;
                    for (let data of this.all_data_lst) {
                        if (!data['rewarded'] && data['achieved']) {
                            let cfgData = cfg.activity.period_task.get(data['id']);
                            if (cfgData.reward_limit_day <= delta) this.show_data_lst.splice(index++, 0, data);
                            
                        } else if (data['rewarded']) {
                            this.show_data_lst.push(data);
                        }
                    }
                    break;   
              
            }
            this.empty.visible = this.show_data_lst.length == 0;
            this.scrollview.reset();
            this.scrollview.addItem(this.show_data_lst.length);
        }

    

        // 由于show_list与实际数据不匹配，完成任务时需要额外修改rewarded
        public task_rewarded(task_id:number) {
            let lst = UI_Activity.getPeriodTaskList(Page_Kuangdu_Task.activity_id);
            this.all_data_lst = lst;
            this.scrollview.wantToRefreshAll();
        }

        public onClose() {
            UI_Kuangdu.Inst.refresh_red_point(0);
            UI_Kuangdu.Inst.refresh_red_point(1);
            UI_Kuangdu.Inst.refresh_red_point(2);
        }

        public refresh_red_dot() {
            // this.reddot.visible = Page_Kuangdu_Task.haveRedPoint();
        }
    }
}