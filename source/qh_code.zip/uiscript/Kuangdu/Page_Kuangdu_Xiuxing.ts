module uiscript {
    class Cell {
        private me:Laya.Sprite;
        private index:number;
        private buff_id:number;
        private star_imgs:Array<Laya.Image>;
        
        private now:Laya.Label;
        private next:Laya.Label;
        private max:Laya.Sprite; // 底部满级显示

        private levelup_btn:Laya.Button;
        private cost:Laya.Label;
        private father:Page_Kuangdu_Xiuxing;
        private level:Laya.Label;

        private donate_count:number = 0;

        constructor(me:Laya.Sprite, index:number, father:Page_Kuangdu_Xiuxing) {
            this.me = me;
            this.index = index;
            this.father = father;
            this.buff_id = 117501 + this.index;
            let star = this.me.getChildByName('star') as Laya.Sprite;
            this.star_imgs = [];
            for (let i = 0; i < star.numChildren; i++) {
                this.star_imgs.push(star.getChildAt(i) as Laya.Image);
            }
            this.levelup_btn = me.getChildByName('levelup') as Laya.Button;
            this.cost = this.levelup_btn.getChildByName('count') as Laya.Label;
            this.max = me.getChildByName('max') as Laya.Sprite;
            this.now = me.getChildByName('now') as Laya.Label;
            this.next = me.getChildByName('next') as Laya.Label;
            this.level = me.getChildByName('level') as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.next.x += 44;
            } else if (GameMgr.client_language == 'jp') {
                this.next.x += 15;
            }
            this.levelup_btn.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Bag.get_item_count(Page_Kuangdu_Xiuxing.item_id) < this.donate_count) {
                    UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(3246));
                    return;
                }
                app.NetAgent.sendReq2Lobby('Lobby', 'upgradeActivityBuff', {buff_id:this.buff_id}, (err, res) => {
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('upgradeActivityBuff', err, res);
                    } else {
                       
                        UI_Activity.upgradeActivityBuff(this.buff_id);
                        this.show();
                        if (this.index == 0) {
                            UI_Kuangdu.Inst.refresh_max_count();
                        }
                        this.father.refreshAllBtnState();
                        let level = UI_Activity.getActivityBuffLevel(this.buff_id);
                        if (level >= 5) {
                            UI_LightTips.Inst.show(game.Tools.strOfLocalization(3247));
                        } else {
                            UI_LightTips.Inst.show(game.Tools.strOfLocalization(3245));
                        }
                    }
                });
            });
        }

        public show() {
            let lst = cfg.activity.activity_buff.getGroup(this.buff_id);
            let buffData:lqc.Sheet_Activity_ActivityBuff = null;
            let level = UI_Activity.getActivityBuffLevel(this.buff_id);
            let nxtBuffData:lqc.Sheet_Activity_ActivityBuff = null;
            for (let data of lst) {
                if (data.buff_level == level) {
                    buffData = data;
                } else if (data.buff_level == level + 1) {
                    nxtBuffData = data;
                    break;
                }
            }
            this.donate_count = nxtBuffData ? nxtBuffData.upgrade_resource_count : -1;
            for (let i = 0; i < this.star_imgs.length; i++) {
                game.LoadMgr.setImgSkin(this.star_imgs[i], i < level ? 'myres/activity_kuangdu/star_l.png' : 'myres/activity_kuangdu/star_d.png');
            }
            this.level.text = level + '';
            this.cost.text = 'x' + this.donate_count;
            this.refreshBtnState();
             
            if (!nxtBuffData) {
                this.max.visible = true;
                this.next.visible = false;
                this.levelup_btn.visible = false;
                
            } else {
                this.max.visible = false;
                this.next.visible = true;
                this.levelup_btn.visible = true;
            }
            

            if (this.index == 0) {
                let max_count:number = 0;
                cfg.item_definition.source_limit.forEach(x => {
                    if (x.item_id == UI_Kuangdu.item_id) {
                        max_count = x.item_limit;
                    }
                });
                this.now.text = buffData ? max_count * buffData.effect / 100 + '' : String(max_count);
                if (nxtBuffData) {
                    this.next.text = String(max_count * nxtBuffData.effect / 100);
                }
                
            } else {
                let add = buffData ? (buffData.effect - 100) : 0;
                this.now.text = '+' + add + '%';
                
                if (nxtBuffData) {
                    add = nxtBuffData.effect - 100;
                    this.next.text = '+' + add + '%';
                }
            }
            
        }

        public refreshBtnState() {
            game.Tools.setGrayDisable(this.levelup_btn as Laya.Sprite, UI_Bag.get_item_count(Page_Kuangdu_Xiuxing.item_id) < this.donate_count);
        }
    }
    export class Page_Kuangdu_Xiuxing extends Page_Kuangdu_Base{
        public static activity_id:number = 1175;
        public static item_id:number = 309034;
        public static haveRedPoint():boolean{
            if (UI_Bag.get_item_count(this.item_id) > 0) {
                for (let i = 0; i < 4; i++) {
                    if (UI_Activity.getActivityBuffLevel(117501 + i) < 5) {
                        return true
                    }
                }
            }
            return false;
        }

        private cells:Array<Cell>;
        private count:Laya.Label;

        public onPageCreate (){
            this.count = this.content.getChildByName('count').getChildAt(1) as Laya.Label;
            this.cells = [];
            for(let i = 0; i < 4; i++) {
                this.cells.push(new Cell(this.content.getChildByName('item_'+ i) as Laya.Sprite, i, this));
            }
        }

        public onShow() {
            this.refreshCount();
            for (let cell of this.cells) {
                cell.show();
            }
        }

        public refreshAllBtnState() {
            this.refreshCount();
            for (let cell of this.cells) {
                cell.refreshBtnState();
            } 
        }

        private refreshCount() {
            this.count.text = 'x' + UI_Bag.get_item_count(Page_Kuangdu_Xiuxing.item_id);
        }

        public onClose() {
            UI_Kuangdu.Inst.refresh_red_point(1);
        }
    }
}