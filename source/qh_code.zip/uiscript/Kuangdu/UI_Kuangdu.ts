module uiscript {
    export class UI_Kuangdu extends UIBase {
        public static Inst:UI_Kuangdu = null;
        public static item_id:number = 309035;
        public static activity_id:number = 1175;

        constructor() {
			super(new ui.kuangdu.kuangduUI());
			UI_Kuangdu.Inst = this;
        }
        
        public static have_reddot():boolean {
            if (Page_Kuangdu_Reward.haveRedPoint() || Page_Kuangdu_Spot.haveRedPoint() || Page_Kuangdu_Task.haveRedPoint() || Page_Kuangdu_Xiuxing.haveRedPoint()) {
                return true;
            }
            return false;
        }
        private pt_counts:Array<Laya.Image>;
        private label_today_count:Laya.Label;
        private label_today_max_count:Laya.Label;
        private bg_main:Laya.Image;
        // 动画部分
        private container_top:Laya.Sprite;
        private container_tip:Laya.Sprite;
        private container_info:Laya.Sprite;
        private container_logo:Laya.Sprite;
        private content:Laya.Sprite;

        private locking:boolean;
        private pages:Array<Page_Kuangdu_Base> = [];
        private _cur_page:Page_Kuangdu_Base;
        private _last_pt:number = -1;

        public matching:boolean;

        public onCreate() {
            this.container_top = this.me.getChildByName("top") as Laya.Sprite;
            this.container_tip = this.me.getChildByName("tip") as Laya.Sprite;
            this.container_info = this.me.getChildByName("info") as Laya.Sprite;
            this.container_logo = this.me.getChildByName("logo") as Laya.Sprite;
            this.content = this.me.getChildByName("content") as Laya.Sprite;

            this.bg_main = this.content.getChildByName('bg_main') as Laya.Image;
         
            this.pt_counts = [];
            let scores = this.container_info.getChildByName('scores') as Laya.Sprite;
            for (let i = 0; i < 7; i++) {
                this.pt_counts.push(scores.getChildByName(i + '') as Laya.Image);
            }
            this.label_today_count = this.container_info.getChildByName('today') as Laya.Label;
            this.label_today_max_count = this.container_info.getChildByName('max') as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.label_today_count.x += 50;
                this.label_today_max_count.x += 50;
            }

            (this.container_top.getChildByName('back') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_close_btn_click();
            });
            (this.container_tip as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                uiscript.UI_Kuangdu_Rules.Inst.show(E_Kuangdu_Rules_Style.Kuangdu);
            });
            
           
            this.pages.push(new Page_Kuangdu_Task(this.me.getChildByName('Page_Task') as Laya.Sprite));
            this.pages.push(new Page_Kuangdu_Xiuxing(this.me.getChildByName('Page_Xiuxing') as Laya.Sprite));
            this.pages.push(new Page_Kuangdu_Match(this.me.getChildByName('Page_Duizhan') as Laya.Sprite));
            this.pages.push(new Page_Kuangdu_Reward(this.me.getChildByName('Page_Reward') as Laya.Sprite));
            this.pages.push(new Page_Kuangdu_Spot(this.me.getChildByName('Page_Spot') as Laya.Sprite));
            
            (this.content.getChildByName('task') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.show_page(0);
            });
            (this.content.getChildByName('xiuxing') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.show_page(1);
            });
            (this.content.getChildByName('match') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                if (!UI_Activity.activity_is_running(Page_Kuangdu_Match.activity_id)) {
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(3440));
                } else {
                    this.show_page(2);
                }
                
            });
            (this.content.getChildByName('reward') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.show_page(3);
            });
            (this.content.getChildByName('spot') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.show_page(4);
            });
            app.NetAgent.addListener2Lobby('NotifyMatchGameStart', Laya.Handler.create(this, (msg) => {
                if (this.enable) {
                    GameMgr.Inst.in_kuangdu = true;
                }
				if (this._cur_page && this._cur_page.enable) {
                    this._cur_page.close();
                }
			}));
        }
        
        public show() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
            if (!UI_Activity.activity_is_running(Page_Kuangdu_Match.activity_id)) {
				(this.content.getChildByName('match') as Laya.Sprite).filters = [new Laya.ColorFilter(uiscript.GRAY_FILTER)];
			} else {
				(this.content.getChildByName('match') as Laya.Sprite).filters = [];
			}
            
            this.refresh_currency_count();
            this.refresh_max_count();
            game.LoadMgr.setImgSkin(this.bg_main, 'myres/activity_kuangdu/bg_view.png');
            this.locking = true;
            this.enable = true;
            this.refresh_red_point();
            UIBase.anim_alpha_in(this.container_top, { y: -30 }, 200, 0, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            UIBase.anim_alpha_in(this.container_tip, { y: 0 }, 200);
        
            UIBase.anim_alpha_in(this.content, null, 200);
            UIBase.anim_alpha_in(this.container_logo, { y: 830 }, 200);
            UIBase.anim_alpha_in(this.container_info, { y: 900 }, 200);
            
        }

        public closeNowPage() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
        }

        private on_close_btn_click() {
            if (this.matching) {
                UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(3199), Laya.Handler.create(this, ()=>{
                    (this._cur_page as Page_Kuangdu_Match).cancelMatch(Laya.Handler.create(this, this.close));
                }));
            } else{
                this.close();
            }
        }
        
        public close() {
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.close();
            }
            
            this.enable = false;
            
			GameMgr.Inst.EnterLobby();
        }

        public onDisable() {
            Laya.timer.clearAll(this);
            if (this._cur_page && this._cur_page.enable) {
                this._cur_page.enable = false;
            }
        }

        public show_page(index:number) {
            if (index >= this.pages.length) {
                return;
            }
            this._cur_page = this.pages[index];
            this.pages[index].show();
        }

        public refresh_currency_count() {
            Laya.timer.clearAll(this);
            let count = UI_Bag.get_item_count(UI_Kuangdu.item_id);
            UI_Kuangdu.Inst.refresh_red_point(3);
            if (this._last_pt < 0 || count == this._last_pt) {
                this._last_pt = count;
                for (let i = 0; i < this.pt_counts.length; i++) {
                    let score = count % 10;
                    count = Math.floor(count / 10);
                    (this.pt_counts[i].getChildByName('score') as Laya.Image).y = 0;
                    (this.pt_counts[i].getChildByName('score1') as Laya.Image).y =200;
                    if (count == 0 && score != 0) {
                        (this.pt_counts[i].getChildByName('score') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_kuangdu/r' + score + '.png');
                    } else {
                        (this.pt_counts[i].getChildByName('score') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_kuangdu/b' + score + '.png');
                    }
                }
            } else {
                let nextPT = count;
                for (let i = 0; i < this.pt_counts.length; i++) {
                    let score = this._last_pt % 10;
                    let nextScore = count % 10;
                    this._last_pt = Math.floor(this._last_pt / 10);
                    count = Math.floor(count / 10);
                    (this.pt_counts[i].getChildByName('score') as Laya.Image).y = 0;
                    (this.pt_counts[i].getChildByName('score1') as Laya.Image).y =200;
                    if (this._last_pt == 0 && score != 0) {
                        (this.pt_counts[i].getChildByName('score') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_kuangdu/r' + score + '.png');
                    } else {
                        (this.pt_counts[i].getChildByName('score') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_kuangdu/b' + score + '.png');
                    }
                    if (score != nextScore || (count!= 0 && this._last_pt == 0)) {
                        this.show_pt_anim(i, score, nextScore, count == 0);
                    }
                }
                this._last_pt = nextPT;
            }
            
            this.label_today_count.text = String(UI_Bag.get_item_daily_record(10006, UI_Kuangdu.item_id));
        }

        private show_pt_anim(index:number, lastPT:number, nowPT:number, is_first:boolean) {
            let max_speed = 700; //最快速度
            let accelerate = 1000; // 加速度 
            let min_speed = 200; // 减速时最小速度
            let elasticDist = 20; // 回弹距离
            let slowDist = 80; // 开始减速距离
            let maxShowTime = 3000; // 动画最长时间，防止意外
            let dist = nowPT - lastPT;
            if (dist <=0) dist += 10;
            dist *= 100;
            let speed = 0;
            let start_time = Laya.timer.currTimer;
            let start_time_1 = Laya.timer.currTimer;
            let offset_y = 0;
            let elasticing = false; // 回弹中
            let func = ()=>{
                let delta = Laya.timer.currTimer - start_time;
                let last_offset_y = offset_y;

                // 防止一直播放的保险机制
                if (Laya.timer.currTimer - start_time_1 > maxShowTime) {
                    offset_y = dist;
                    Laya.timer.clear(this, func);
                } else {
                    if (offset_y < dist / 2 && speed < max_speed) {
                        speed += accelerate * delta/ 1000;
                    } else if (offset_y >= dist / 2 && dist - offset_y < slowDist) {
                        speed -= accelerate * delta / 1000;
                        speed = Math.max(min_speed, speed);
                    }
                    if (elasticing) {
                        
                        offset_y -= speed * delta/ 1000;
                        if (offset_y < dist) {
                            offset_y = dist;
                            Laya.timer.clear(this, func);
                        }
                    } else {
                        offset_y += speed * delta / 1000;
                        if (offset_y > dist + elasticDist) {
                            elasticing = true;
                        }
                    }
                }
                
                
                if (Math.ceil(offset_y/ 100) != Math.ceil(last_offset_y / 100)) {
                    let childIndex = Math.ceil(offset_y/ 100) % 2;
                    (this.pt_counts[index].getChildAt(childIndex) as Laya.Image).skin = game.Tools.localUISrc('myres/activity_kuangdu/' + (is_first? 'r' : 'b') + (lastPT + Math.ceil(offset_y / 100))%10 + '.png');
                }
               
                (this.pt_counts[index].getChildAt(0) as Laya.Image).y = -(offset_y + 100) % 200 + 100;
                (this.pt_counts[index].getChildAt(1) as Laya.Image).y = -(offset_y) % 200 + 100;
                start_time = Laya.timer.currTimer;
            }
            Laya.timer.frameLoop(1, this, func);
        }
        public refresh_max_count() {
            let max_count:number = 0;
            cfg.item_definition.source_limit.forEach(x => {
                if (x.item_id == UI_Kuangdu.item_id) {
                    max_count = x.item_limit;
                }
            });
            let level = UI_Activity.getActivityBuffLevel(117501);
            let lst = cfg.activity.activity_buff.getGroup(117501);
            for (let i = 0; i < lst.length; i++) {
                if (level == lst[i].buff_level) {
                    max_count = Math.floor(max_count * lst[i].effect / 100);
                    break;
                }
            }
          
            this.label_today_max_count.text = '/' + max_count;
        }

        public refresh_red_point(pageIndex:number = -1) {
            if (pageIndex == 0 || pageIndex < 0) {
                (this.content.getChildByName('task').getChildByName('redpoint') as Laya.Sprite).visible = Page_Kuangdu_Task.haveRedPoint();
            }
            if (pageIndex == 1 || pageIndex < 0) {
                (this.content.getChildByName('xiuxing').getChildByName('redpoint') as Laya.Sprite).visible = Page_Kuangdu_Xiuxing.haveRedPoint();
            }
            if (pageIndex == 2 || pageIndex < 0) {
                (this.content.getChildByName('reward').getChildByName('redpoint') as Laya.Sprite).visible = Page_Kuangdu_Reward.haveRedPoint();
            }
            if (pageIndex == 3 || pageIndex < 0) {
                (this.content.getChildByName('spot').getChildByName('redpoint') as Laya.Sprite).visible = Page_Kuangdu_Spot.haveRedPoint();
            }
        }
    }
}