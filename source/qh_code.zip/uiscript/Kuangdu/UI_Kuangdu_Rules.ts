/**
* name 
*/
module uiscript{
	export enum E_Kuangdu_Rules_Style { Kuangdu, Match, All };
	
	export class UI_Kuangdu_Rules extends UIBase{

		public static Inst:UI_Kuangdu_Rules = null;

		private root:Laya.Sprite = null;
		private blackmask:Laya.Sprite = null;

		private locking:boolean;
		private tab_index:number;

		// 前4个合宿界面介绍
		private kuangdu:Laya.Sprite;
		private top:Laya.Sprite;
		private page:Laya.Image;
		private light:Laya.Image;
		private arrow:Laya.Sprite;

		private tip0:Laya.Sprite;
		private page0:Laya.Image;
		private light0:Laya.Image;
		private arrow0:Laya.Sprite;

		// 对局规则
		private match:Laya.Sprite;
		private mid:Laya.Image;
		private title:Laya.Label;

		// private chat_block: UI_Character_Chat = null;
		private chat_bg:Laya.Sprite;
		private chat_arrow:Laya.Sprite;
		private chat_label:Laya.Label;
		private yiji:Laya.Image;
		private label_index:Laya.Label;

		private btns:Laya.Sprite;
		private pre_btn:Laya.Sprite;
		private skip_btn:Laya.Sprite;
		private next_btn:Laya.Sprite;
		private max_page:number = 9;
		private start_page:number = 0;
		private type:E_Kuangdu_Rules_Style = E_Kuangdu_Rules_Style.Kuangdu;

		constructor() {
			super(new ui.kuangdu.kuangdu_rulesUI());
			UI_Kuangdu_Rules.Inst = this;
		}

		public onCreate() {
			this.root = this.me.getChildByName('root') as Laya.Sprite;
			this.blackmask = this.me.getChildByName('bmask') as Laya.Sprite;
			
			// 合宿
			this.kuangdu = this.root.getChildByName('kuangdu') as Laya.Sprite;
			this.top = this.kuangdu.getChildByName('top') as Laya.Sprite;
			this.page = this.kuangdu.getChildByName('page') as Laya.Image;
			this.light = this.kuangdu.getChildByName('light') as Laya.Image;
			this.arrow = this.kuangdu.getChildByName('arrow') as Laya.Sprite;

			this.tip0 = this.kuangdu.getChildByName('0') as Laya.Sprite;
			this.page0 = this.tip0.getChildByName('page') as Laya.Image;
			this.light0 = this.tip0.getChildByName('light') as Laya.Image;
			this.arrow0 = this.tip0.getChildByName('arrow') as Laya.Sprite;

			// 对局
			this.match = this.root.getChildByName('match') as Laya.Sprite;
			
			this.mid = this.match.getChildByName('mid') as Laya.Image;
			this.title = this.match.getChildByName('title') as Laya.Label;
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'jp') {
				this.chat_label = this.root.getChildByName('chat').getChildByName('info_en') as Laya.Label;
				(this.root.getChildByName('chat').getChildByName('info') as Laya.Label).visible = false;	
			} else {
				this.chat_label = this.root.getChildByName('chat').getChildByName('info') as Laya.Label;
				(this.root.getChildByName('chat').getChildByName('info_en') as Laya.Label).visible = false;	
			}
			this.chat_bg = this.root.getChildByName('chat').getChildByName('bg') as Laya.Label;
			this.chat_arrow = this.root.getChildByName('chat').getChildByName('arrow') as Laya.Sprite;
			
			this.label_index = this.root.getChildByName('index') as Laya.Label;
			this.yiji = this.root.getChildByName('chat').getChildByName('head') as Laya.Image;

			this.btns = this.me.getChildByName('btn') as Laya.Sprite;
			this.pre_btn = this.btns.getChildByName('pre') as Laya.Sprite;
			(this.pre_btn as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.changeTab(this.tab_index - 1);
			});

			(this.root.getChildByName('chat').getChildByName('next') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				if (this.tab_index == this.max_page - 1) {
					this.close();
				} else {
					this.changeTab(this.tab_index + 1);
				}
			});
			this.skip_btn = this.btns.getChildByName('skip') as Laya.Sprite;
			(this.skip_btn as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				this.close();
			});

			this.next_btn = this.btns.getChildByName('next') as Laya.Sprite;
			(this.next_btn as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
				if (this.locking) return;
				if (this.tab_index == this.max_page - 1) {
					this.close();
				} else {
					this.changeTab(this.tab_index + 1);
				}
			});
			this.enable = false;

			if(GameMgr.client_language == 'en') {
				let spr:Laya.Sprite = this.top.getChildAt(0) as Laya.Sprite;
				(spr.getChildAt(0) as Laya.Sprite).height = 59;
				(spr.getChildAt(2) as Laya.Label).fontSize = 26;
			}
		}

		public show(type:E_Kuangdu_Rules_Style) {
			this.type = type;
			this.locking = true;
			this.enable = true;
			this.max_page = this.type == E_Kuangdu_Rules_Style.Kuangdu ? 4 : 9;
			this.start_page = this.type == E_Kuangdu_Rules_Style.Match ? 4 : 0;
			UIBase.anim_pop_out(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
			}));
			this.blackmask.alpha = 0;
			Laya.Tween.to(this.blackmask, {alpha: 0.7}, 150);
			UIBase.anim_alpha_in(this.btns, {}, 200);
			this.tab_index = -1;
			this.changeTab(this.start_page);
			Laya.loader.load(game.Tools.localUISrc('extendRes/emo/e200001/l_1.png'));
			Laya.loader.load(game.Tools.localUISrc('extendRes/emo/e200001/l_2.png'));
			// Laya.loader.load(game.Tools.localUISrc('extendRes/emo/e200001/l_1.png'));
		}

		private changeTab(index:number) {

			if (index == this.tab_index) return;
			this.tab_index = index;
			let showIndex = index + 1 - this.start_page;
			let maxIndex = this.max_page - this.start_page;
			this.label_index.text = '(' + showIndex +'/' + maxIndex + ')';
			// TODO可能需要做一个lock
			switch (this.tab_index) {
				case 0: {
					this.kuangdu.visible = true;
					this.match.visible = false;
					this.top.visible = true;
					this.page.skin = game.Tools.localUISrc('myres/kuangdu_rules/page0.png');
					this.page.pos(438, 242);
					// this.chat_block.show('asdasda', 100);
					// this.chat_block.show(game.Tools.strOfLocalization(3348), GameMgr.client_language == 'en' ? 10 : 5);
					// this.chat_label.text = game.Tools.strOfLocalization(3348);
					this.arrow.pos(1105, 362);
					this.arrow.scale(1, 1);
					this.arrow.rotation = 30;
					this.tip0.visible = false;

					this.light.pos(1066, 528);
					this.light.skin = game.Tools.localUISrc('myres/activity_kuangdu/btn_4.png');
					this.light.scale(1.22, 1.22);
					this.yiji.pos(-24, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_1.png');
					break;
				}
				case 1: {
					this.kuangdu.visible = true;
					this.match.visible = false;
					this.top.visible = false;
					this.page.skin = game.Tools.localUISrc('myres/kuangdu_rules/page1.png');
					this.page.pos(688, 264);
					this.tip0.visible = false;
					// this.chat_block.show(game.Tools.strOfLocalization(3349), GameMgr.client_language == 'en' ? 10 : 5);				
					// this.chat_label.text = game.Tools.strOfLocalization(3349);

					this.arrow.pos(637, 359);
					this.arrow.rotation = -30;
					this.arrow.scale(-1, 1);

					this.light.pos(376, 524);
					this.light.skin = game.Tools.localUISrc('myres/activity_kuangdu/btn_0.png');
					this.light.scale(1, 1);
					this.tip0.visible = false;
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break;
				}
				case 2: {
					this.kuangdu.visible = true;
					this.match.visible = false;
					this.top.visible = false;
					this.page.skin = game.Tools.localUISrc('myres/kuangdu_rules/page2.png');
					this.page.pos(772, 247);
					this.tip0.visible = false;

					this.arrow.pos(717, 522);
					this.arrow.rotation = 225;
					this.arrow.scale(1, 1);

					this.light.pos(498, 276);
					this.light.skin = game.Tools.localUISrc('myres/activity_kuangdu/btn_3.png');
					this.light.scale(1, 1);

					// this.chat_block.show('asdasda', 100); 		
					// this.chat_block.show(game.Tools.strOfLocalization(3350), GameMgr.client_language == 'en' ? 10 : 5);			
					// this.chat_label.text = game.Tools.strOfLocalization(3350);
					this.yiji.pos(-24, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_1.png');
					break;
				}
				case 3: {
					this.kuangdu.visible = true;
					this.match.visible = false;
					this.top.visible = false;
					this.page.skin = game.Tools.localUISrc('myres/kuangdu_rules/page3.png');
					this.page.pos(348, 43);
					

					this.arrow.pos(302, 207);
					this.arrow.rotation = -30;
					this.arrow.scale(-1, 1);
					this.light.pos(36, 373);
					this.light.skin = game.Tools.localUISrc('myres/activity_kuangdu/btn_1.png');
					this.light.scale(1, 1);

					this.tip0.visible = true;
					this.page0.pos(609, 328);
					this.page0.skin = game.Tools.localUISrc('myres/kuangdu_rules/page4.png');
					this.arrow0.pos(1294, 477);
					this.arrow0.rotation = 105;
					this.arrow0.scale(-1, 1);

					this.light0.pos(1034, 216);
					this.light0.skin = game.Tools.localUISrc('myres/activity_kuangdu/btn_2.png');

					// this.chat_block.show('asdasda', 100); 			
					// this.chat_block.show(game.Tools.strOfLocalization(3351), GameMgr.client_language == 'en' ? 10 : 5);		
					// this.chat_label.text = game.Tools.strOfLocalization(3351);
					
					this.yiji.pos(1175, -162);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_1.png');
					break;
				}
				case 4: {
					this.kuangdu.visible = false;
					this.match.visible = true;
					this.mid.skin = game.Tools.localUISrc('myres/kuangdu_rules/match0.png');
				
					this.title.text = game.Tools.strOfLocalization(3352);
					
					// this.chat_block.show('asdasda', 100); 					
					// this.chat_label.text = game.Tools.strOfLocalization(3356);
					// this.chat_block.show(game.Tools.strOfLocalization(3356), GameMgr.client_language == 'en' ? 10 : 5);
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break;
				}
				case 5: {
					this.kuangdu.visible = false;
					this.match.visible = true;
					this.mid.skin = game.Tools.localUISrc('myres/kuangdu_rules/match1.png');
				
					this.title.text = game.Tools.strOfLocalization(3353);

					// this.chat_label.text = game.Tools.strOfLocalization(3357);
					// this.chat_block.show(game.Tools.strOfLocalization(3357), GameMgr.client_language == 'en' ? 10 : 5);
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break;
				}
				case 6: {
					this.kuangdu.visible = false;
					this.match.visible = true;
					this.mid.skin = game.Tools.localUISrc('myres/kuangdu_rules/match2.png');
				
					this.title.text = game.Tools.strOfLocalization(3354);

					// this.chat_label.text = game.Tools.strOfLocalization(3358);
					// this.chat_block.show(game.Tools.strOfLocalization(3358), GameMgr.client_language == 'en' ? 10 : 5);
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break;
				}
				case 7: {
					this.kuangdu.visible = false;
					this.match.visible = true;
					this.mid.skin = game.Tools.localUISrc('myres/kuangdu_rules/match3.png');
		
					this.title.text = game.Tools.strOfLocalization(3355);

					// this.chat_label.text = game.Tools.strOfLocalization(3359);
					// this.chat_block.show(game.Tools.strOfLocalization(3359), GameMgr.client_language == 'en' ? 10 : 5);
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break;
				}
				case 8: {
					this.kuangdu.visible = false;
					this.match.visible = true;
					this.mid.skin = game.Tools.localUISrc('myres/kuangdu_rules/match4.png');
				
					this.title.text = game.Tools.strOfLocalization(3355);

					// this.chat_label.text = game.Tools.strOfLocalization(3359);
					// this.chat_block.show(game.Tools.strOfLocalization(3359), GameMgr.client_language == 'en' ? 10 : 5);
					this.yiji.pos(-29, -160);
					game.LoadMgr.setImgSkin(this.yiji, 'extendRes/emo/e200001/l_2.png');
					break; 
				}
			}
			if (GameMgr.client_language == 'en' || GameMgr.client_language == 'jp') {
				if (this.tab_index < 4) {
					this.chat_label.fontSize = 37;
				} else {
					this.chat_label.fontSize = 28;
				}
			}
			this.chat_label.text = game.Tools.strOfLocalization(3403 + index);
			
			this.chat_bg.height = this.chat_label.textField.textHeight > 150 ? 236 : this.chat_label.textField.textHeight + 65;
			this.chat_arrow.y = this.chat_bg.height + 86;
			this.pre_btn.visible = index != this.start_page;
			(this.next_btn.getChildAt(0) as Laya.Sprite).visible = index != this.max_page - 1;
			(this.next_btn.getChildAt(1) as Laya.Sprite).visible = index == this.max_page - 1;
			(this.skip_btn.getChildAt(0) as Laya.Sprite).visible = index != this.max_page - 1;
			(this.skip_btn.getChildAt(1) as Laya.Sprite).visible = index == this.max_page - 1;
		}

		public close() {
			this.locking = true;
			Laya.Tween.to(this.blackmask, {alpha: 0}, 150);
			UIBase.anim_alpha_out(this.btns, {}, 200);
			UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, ()=>{
				this.locking = false;
				this.enable = false;
			}));
			Laya.loader.clearTextureRes(game.Tools.localUISrc('extendRes/emo/e200001/l_1.png'));
			Laya.loader.clearTextureRes(game.Tools.localUISrc('extendRes/emo/e200001/l_2.png'));
		}
	}
}