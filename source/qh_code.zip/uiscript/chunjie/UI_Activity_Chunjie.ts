/**
* name 
*/
module uiscript {
    // 白龙庙 主建筑
    class Building_Main {
        private me: Laya.Sprite;
        private icon: Laya.Image; // 主建筑
        private points: Array<{ bg: Laya.Image, num: Laya.Label }>;
        private bars: Array<Laya.Sprite>;
        private label_count: Laya.Label;
        private stage_requires: Array<number>;
        private item_id: number;
        private showing_count: number;
        private effects: Array<game.UIEffect>;

        constructor(me: Laya.Sprite) {
            this.me = me;
            this.icon = this.me.getChildByName('icon') as Laya.Image;

            let progress: Laya.Sprite = this.me.getChildByName('detail').getChildByName('progress') as Laya.Sprite;
            this.points = [];
            this.bars = [];
            this.stage_requires = [];
            if (!UI_Activity_Chunjie.activity_data) return;
            for (let i = 0; i < 4; ++i) {
                let num = progress.getChildByName('point_' + i).getChildByName('num') as Laya.Label;
                this.points.push({ bg: progress.getChildByName('point_' + i).getChildByName('bg') as Laya.Image, num: num });
                let reward = UI_Activity_Chunjie.activity_data.stage_require[i].split('-');
                num.text = reward[1];
                if (i == 0) {
                    this.item_id = Number(reward[0]);
                }
                this.stage_requires.push(Number(reward[1]));
                if (GameMgr.client_language == 'kr' || GameMgr.client_language == 'en') {
                    num.y = 35;
                }
            }

            for (let i = 0; i < 3; ++i) {
                this.bars.push(progress.getChildByName('bar_' + i).getChildAt(0) as Laya.Sprite);
            }

            (this.me.getChildByName('detail').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {

                if (UI_Activity_Chunjie.Inst.locking) return;
                this.reset();
                UI_Activity_Chunjie_Main.Inst.show();
            });

            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {

                if (UI_Activity_Chunjie.Inst.locking) return;
                this.reset();
                UI_Activity_Chunjie_Main.Inst.show();
            });

            (this.me.getChildByName('fanrongdu').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {

                if (UI_Activity_Chunjie.Inst.locking) return;
                // 打开繁荣度介绍
                this.reset();
                UI_Info_Mid.Inst.show(game.Tools.strOfLocalization(4116));
            });

            this.label_count = this.me.getChildByName('fanrongdu').getChildAt(1) as Laya.Label;
            if (GameMgr.client_language == 'en') {
                (this.me.getChildByName('detail').getChildAt(1) as Laya.Sprite).x = 193;
            }
        }


        // 刷新显示
        public refresh() {
            let _count = UI_Bag.get_item_count(this.item_id);
            this.label_count.text = game.Tools.strOfLocalization(4058, [_count.toString()]);
            this.showing_count = _count;
            let _stage = 0;
            // 设置进度条
            for (let i = 0; i < 4; ++i) {
                let point = this.points[i];
                if (_count >= this.stage_requires[i]) {
                    point.num.color = '#000001';
                    _stage = i;
                    point.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/point_l.png');
                } else {
                    point.num.color = '#bdb1aa';
                    point.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/point_d.png');
                }
                if (i != 0) {
                    let bar = this.bars[i - 1];
                    bar.mask.width = Math.min(1, Math.max(0, (_count - this.stage_requires[i - 1]) / (this.stage_requires[i] - this.stage_requires[i - 1]))) * 44;
                }
            }

            // 设置当前阶段
            game.LoadMgr.setImgSkin(this.icon, 'myres/activity_24chunjie/scene/building_0_' + _stage + '.png', null, 'UI_Activity_Chunjie');
        }

        public playAnim() {
            let _count = UI_Bag.get_item_count(this.item_id);
            if (_count == this.showing_count) return;
            this.label_count.text = game.Tools.strOfLocalization(4058, [_count.toString()]);
            let _current_progress: number = 0;
            let _next_progress: number = 0;
            for (let i = 0; i < 4; ++i) {
                if (this.showing_count >= this.stage_requires[i]) {
                    _current_progress = i;
                } else if (this.showing_count >= this.stage_requires[i - 1]) {
                    _current_progress += (this.showing_count - this.stage_requires[i - 1]) / (this.stage_requires[i] - this.stage_requires[i - 1])
                }
                if (_count >= this.stage_requires[i]) {
                    _next_progress = i;
                } else if (_count >= this.stage_requires[i - 1]) {
                    _next_progress += (_count - this.stage_requires[i - 1]) / (this.stage_requires[i] - this.stage_requires[i - 1]);
                }
            }
            this.showing_count = _count;
            if (_next_progress == _current_progress) return;
            let _show_progress = _current_progress;
            let _pre_time = Laya.timer.currTimer;
            let _speed = 1.5; // 1s几格
            Laya.timer.frameLoop(1, this, () => {
                let _now_time = Laya.timer.currTimer;
                let _pre_progress = _show_progress;
                _show_progress += (_now_time - _pre_time) / 1000 * _speed;
                _pre_time = _now_time;

                if (_show_progress >= _next_progress) {
                    Laya.timer.clearAll(this);
                    Laya.timer.once(1500, this, this.destroyEffects);
                    _show_progress = _next_progress;
                }
                if (Math.floor(_pre_progress) < Math.floor(_show_progress)) {
                    for (let i = Math.floor(_pre_progress) + 1; i <= Math.floor(_show_progress); ++i) {
                        let point = this.points[i];
                        game.FrontEffect.Inst.create_ui_effect(point.bg, 'scene/effect_chunjie_bailong.lh', new Laya.Point(30, 25), 1);
                        point.num.color = '#000001';
                        point.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/point_l.png');
                    }
                    game.LoadMgr.setImgSkin(this.icon, 'myres/activity_24chunjie/scene/building_0_' + Math.floor(_show_progress) + '.png', null, 'UI_Activity_Chunjie');
                }
                for (let i = 0; i < this.bars.length; ++i) {
                    this.bars[i].mask.width = Math.max(0, Math.min(1, _show_progress - i)) * 44;
                }
            })
        }

        private destroyEffects() {
            if (this.effects) {
                for (let effect of this.effects) {
                    effect.destory();
                }
            }
        }
        public reset() {
            Laya.timer.clearAll(this);
            this.refresh();
            this.destroyEffects();
        }
    }

    // 森林矿山等产出建筑
    class Building_Normal {
        private items: Array<Item_Normal>;
        private name: Laya.Label;
        private label_output: Laya.Label;
        private pos: Laya.Sprite;

        private origin_pos_x: number;
        public tag: Laya.Image;
        private icon: Laya.Image;
        private bg: Laya.Sprite;
        private btn: Laya.Button;
        private origin_tag_y: number;
        private max: Laya.Sprite;
        private item_output: Item_Output;
        private strike: Laya.Sprite;


        private playing_upgrade_anim: boolean;
        private type: number;
        private building_id: number;
        private reward: { id: number, count: number };

        constructor(me: Laya.Sprite, type: number) {
            this.type = type;
            this.pos = me.getChildByName('detail').getChildByName('pos') as Laya.Sprite;
            this.origin_pos_x = this.pos.x;
            this.name = this.pos.getChildByName('name') as Laya.Label;

            this.strike = me.getChildByName('detail').getChildByName('strike') as Laya.Sprite;
            (this.strike.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                UI_Info_Mid.Inst.show(game.Tools.strOfLocalization(4081));
            });
            this.label_output = this.pos.getChildByName('output') as Laya.Label;
            this.tag = this.pos.getChildByName('tag') as Laya.Image;
            this.origin_tag_y = this.tag.y;
            this.icon = this.pos.getChildByName('icon') as Laya.Image;
            this.bg = this.pos.getChildByName('bg') as Laya.Sprite;
            this.max = this.pos.getChildByName('max') as Laya.Sprite;
            this.btn = this.pos.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                UI_Activity_Chunjie_Upgrade.Inst.show(this.type);

            });
            this.item_output = new Item_Output(me.getChildByName('outputs') as Laya.Sprite, new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                if (this.item_output.locking) return;
                this.refreshOutputCount();
                UI_Activity_Chunjie.Inst.locking = true;
                this.item_output.locking = true;
                let buildingData = UI_Activity_Chunjie.getBuildDataByType(this.type);
                let reward_id = this.reward.id;
                app.NetAgent.sendReq2Lobby('Lobby', 'receiveVillageBuildingReward', {
                    building_id: this.building_id, rewards: [this.reward], activity_id: UI_Activity_Chunjie.activity_id
                }, (err, res) => {
                    UI_Activity_Chunjie.Inst.locking = false;
                    this.item_output.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('receiveVillageBuildingReward', err, res);

                    } else {

                        //如果update还没更新,手动设置一下老的data的数据并计算产出
                        let audio_id = 10110;
                        if (reward_id == 30900007) {
                            audio_id = 10113;
                        } else if (reward_id == 30900009) {
                            audio_id = 10112;
                        } else if (reward_id == 30900008) {
                            audio_id = 10111;
                        }
                        view.AudioMgr.PlayAudio(audio_id);
                        this.item_output.playCollectAnim(UI_Activity_Chunjie.Inst.container_currency.getTargetPosById(reward_id));
                        buildingData.reward = null;

                    }
                })
            }));

            this.items = [];
            for (let i = 0; i < 4; ++i) {
                let index = i;
                let item = new Item_Normal(me.getChildByName('buildings').getChildAt(i) as Laya.Sprite, this.type, index, new Laya.Handler(this, () => {
                    this.onFarmerClick(index);
                }));
                this.items.push(item);
            }
        }

        public refresh(): boolean {
            let unlock_item: boolean = false;
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            let _reward_data = cfg.item_definition.item.get(Number(cfg_data.produce_item.split('-')[0]));
            game.LoadMgr.setImgSkin(this.icon, _reward_data.icon_transparent, null, 'UI_Activity_Chunjie');
            this.name.text = game.Tools.strOfLocalization(cfg_data.building_name);
            //
            if (this.building_id && building_data.id != this.building_id) {
                let pre_data = UI_Activity_Chunjie.getCfgBuildData(this.building_id);
                let now_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
                for (let i = pre_data.max_worker_count; i < now_data.max_worker_count; ++i) {
                    this.items[i].playUnlockAnim();
                    unlock_item = true;
                }

            }
            this.building_id = building_data.id;
            this.refreshOutputLabel();
            this.refreshOutputCount();
            this.refreshUpgradeState();
            for (let item of this.items) {
                item.refresh(building_data);
            }
            this.fixDetail();
            return unlock_item;
        }

        private fixDetail() {
            let _width = 85;
            _width += this.name.textField.textWidth * this.name.scaleX + 26;
            this.icon.x = _width;
            _width += 35;
            this.label_output.x = _width;
            _width += this.label_output.textField.textWidth * this.label_output.scaleX + 30;
            this.bg.width = _width;
            this.btn.width = _width;
            this.pos.x = this.origin_pos_x - (_width - 315) / 2;
            this.pos.pivotX = _width / 2;

        }
        //打开升级界面时的刷新
        public refresh_locking() {
            this.refreshUpgradeState();
        }

        private onFarmerClick(index: number) {
            if (UI_Activity_Chunjie.Inst.locking) return;
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let _cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            if (index > _cfg_data.max_worker_count) {
                return;
            }
            let have_farmer = false;
            if (building_data.workers && building_data.workers[index]) {
                have_farmer = true;
            }
            if (!have_farmer && UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id) == 0) {
                // 没人提示
                UIMgr.Inst.ShowErrorInfo1(game.Tools.strOfLocalization(4077));
                return;
            }

            UI_Activity_Chunjie.Inst.locking = true;
            app.NetAgent.sendReq2Lobby('Lobby', 'setVillageWorker', {
                building_id: building_data.id, worker_pos: index, activity_id: UI_Activity_Chunjie.activity_id
            }, (err, res) => {
                UI_Activity_Chunjie.Inst.locking = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError('setVillageWorker', err, res);
                } else {

                    let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
                    // 拷贝数据
                    let server_building_data: iBuildingData = res['building'];
                    building_data.id = server_building_data.id;
                    building_data.reward = server_building_data.reward;
                    building_data.workers = server_building_data.workers;
                    this.items[index].refresh(building_data, true);
                    this.refreshOutputLabel();
                    if (have_farmer) {
                        view.AudioMgr.PlayAudio(10107);//撤回音效
                    } else {
                        view.AudioMgr.PlayAudio(10108);//添加音效
                    }


                }
            })
        }

        // 刷新每小时产出
        private refreshOutputLabel() {
            let rate = this.getOutputRate();
            this.label_output.text = game.Tools.strOfLocalization(4059, [(rate.base + rate.extra).toString()]);
        }

        // 刷新目前产量
        private refreshOutputCount() {
            let is_strike = UI_Activity_Chunjie.getStrikeState();
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let farmer_count = 0;
            if (building_data.workers) {
                for (let i = 0; i < 4; ++i) {
                    if (building_data.workers[i])++farmer_count;
                }
            }

            this.strike.visible = is_strike && farmer_count != 0;
            let count = 0;
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);

            let id = Number(cfg_data.produce_item.split('-')[0])
            if (building_data.reward) {
                for (let reward of building_data.reward) {
                    count += reward.count;
                }
            }
            let _skin = cfg.item_definition.item.get(id).icon_transparent;
            this.item_output.show(_skin, count);
            this.reward = { id: id, count: count };
        }

        // 获得当前产地每小时产出多少
        private getOutputRate(): { base: number, extra: number } {
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            let farmer_count = 0;
            if (building_data.workers) {
                for (let i = 0; i < 4; ++i) {
                    if (building_data.workers[i])++farmer_count;
                }
            }

            return { base: (cfg_data.base_produce ? Number(cfg_data.base_produce.split('-')[1]) : 0), extra: farmer_count * Number(cfg_data.produce_item.split('-')[1]) };
        }

        // 刷新是否可升级状态
        public refreshUpgradeState() {
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            if (!cfg_data.next_level_id) {
                this.tag.visible = false;
                this.max.visible = true;
                this.stopUpgradeAnim();
            } else {
                this.tag.visible = true;
                this.max.visible = false;
                if (UI_Bag.checkItemEnough(cfg_data.upgrade_item)) {
                    this.tag.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_upgrade_l.png');
                    if (!this.playing_upgrade_anim) {
                        this.playUpdgradeAnim();
                    }
                } else {
                    this.stopUpgradeAnim();
                    this.tag.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_upgrade_d.png');
                }
            }
        }

        private playUpdgradeAnim() {
            this.playing_upgrade_anim = true;
        }

        private stopUpgradeAnim() {
            this.playing_upgrade_anim = false;
            this.tag.y = this.origin_tag_y;
        }

        public setUpgradeY(offset_y: number) {
            if (!this.playing_upgrade_anim) return;
            this.tag.y = this.origin_tag_y + offset_y;
        }

        public setAddAlpha(alpha: number) {
            for (let item of this.items) {
                item.setAddAlpha(alpha);
            }
        }
        public reset() {
            this.stopUpgradeAnim();
            for (let item of this.items) {
                item.reset();
            }
            this.item_output.stopAnim();
        }

        public onYindao(is_add: boolean) {
            if (is_add) {
                view.AudioMgr.PlayAudio(10108);
                this.items[0].worker_effect.visible = true;
                this.items[0].playAddAnim();

                this.label_output.text = game.Tools.strOfLocalization(4059, ['1']);
            } else {
                view.AudioMgr.PlayAudio(10107);
                let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
                this.items[0].refresh(building_data, false);
                this.refreshOutputLabel();
            }
        }

        public onVisibleChange(visible: boolean) {
            for (let item of this.items) {
                item.onVisibleChange(visible);
            }
        }

        public onYindaoOutputChange(count: number) {
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);

            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);

            let id = Number(cfg_data.produce_item.split('-')[0])
            let _skin = cfg.item_definition.item.get(id).icon_transparent;
            this.item_output.show(_skin, count);
        }
    }

    // 产出建筑单元
    class Item_Normal {
        private building: Laya.Image;
        private me: Laya.Sprite;
        private farmer: Laya.Image;
        private btn: Laya.Button;
        private add: Laya.Sprite;
        private lock: Laya.Sprite;
        private label_lock: Laya.Label;
        private index: number; // 从1开始
        private type: number;
        private playing_anim: boolean;
        private playing_add_anim: boolean;
        public worker_effect: ui.lobby.chunjie.worker_particleUI;

        constructor(me: Laya.Sprite, type: number, index: number, handler: Laya.Handler) {
            this.index = index;

            this.me = me;
            this.building = this.me.getChildByName('building') as Laya.Image;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.farmer = this.btn.getChildByName('farmer') as Laya.Image;
            
            this.add = this.btn.getChildByName('add') as Laya.Sprite;
            this.add.pivotX = 11;
            this.add.pivotY = 11;
            this.add.x += 11;
            this.add.y += 11;
            this.farmer.pivotX = 67;
            this.farmer.pivotY = 59;
            this.farmer.x = 38;
            this.farmer.y = 41;

            this.btn.clickHandler = handler;
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            (this.lock.getChildAt(0) as Laya.Image).alpha = 0.3;
            this.label_lock = this.lock.getChildAt(1) as Laya.Label;
            this.label_lock.visible = false;
            this.setBuildingImg(type);
            (this.lock.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                UI_Activity_Chunjie_Upgrade.Inst.show(this.type);
            });

            this.worker_effect = new ui.lobby.chunjie.worker_particleUI();
            this.worker_effect.ani1.interval = 16;
            this.btn.addChild(this.worker_effect);
            this.worker_effect.pos(-60, -60);
        }

        // 设置建筑图标,
        public setBuildingImg(type: number) {
            this.type = type;

            let img_type = Math.floor(type / 1000) == 3 ? Math.floor(type / 1000).toString() + (type % 10) : Math.floor(type / 1000).toString();
            game.LoadMgr.setImgSkin(this.building, 'myres/activity_24chunjie/scene/building_' + img_type + '_' + this.index + '.png', null, 'UI_Activity_Chunjie');
        }

        public refresh(building_data: iBuildingData, anim: boolean = false) {
            if (this.playing_add_anim) return;
            let _need_show_anim = false;
            let _data: lqc.Sheet_Activity_VillageBuilding = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            this.worker_effect.visible = false;
            if (_data.max_worker_count <= this.index) {
                this.lock.visible = true;
                this.building.visible = false;
                this.btn.visible = false;
            } else {
                this.building.visible = true;
                this.btn.visible = true;
                this.lock.visible = false;
                if (building_data.workers && building_data.workers[this.index]) {
                    this.farmer.alpha = 1;
                    this.worker_effect.visible = true;
                    if (anim) {
                        this.playAddAnim();
                    } else {

                        this.add.visible = false;
                        this.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');

                    }
                    return;
                }
                this.farmer.alpha = 0.7;
                this.add.visible = true;
                _need_show_anim = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id) > 0;
                this.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
            }
           
        }


        public reset() {
            this.playing_add_anim = false;
        }
       

        public playAddAnim() {
            this.playing_add_anim = true;
            this.btn.mouseEnabled = false;
            this.farmer.alpha = 1;
            let effect = game.FrontEffect.Inst.create_ui_effect(this.btn, 'scene/effect_chunjie_nongming.lh', new Laya.Point(178, 0), 1);
            Laya.Tween.to(this.btn, { alpha: 0 }, 60, null, Laya.Handler.create(this, () => {
                this.add.visible = false;
                this.playing_add_anim = false;
                this.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                this.farmer.scale(1.6 * 0.58, 1.6 * 0.58);
                Laya.Tween.to(this.btn, { alpha: 1 }, 100, null, null, 50);
                Laya.Tween.to(this.farmer, { scaleX: 0.58, scaleY: 0.58 }, 160, null, null, 50);
            }));
            Laya.timer.once(600, this, () => {
                this.btn.mouseEnabled = true;
                effect.destory();
            });
        }

        public playUnlockAnim() {
            UI_Activity_Chunjie.Inst.locking = true;
            Laya.Tween.to(this.lock, { alpha: 0, y: 62 }, 333, null);
            this.building.scale(0.8, 0.8);
            this.building.alpha = 0;
            this.building.visible = true;
            Laya.Tween.to(this.building, { alpha: 1 }, 166, null, null, 500);
            Laya.Tween.to(this.building, { scaleX: 0.97, scaleY: 0.97 }, 200, null, Laya.Handler.create(this, () => {
                Laya.Tween.to(this.building, { scaleX: 1, scaleY: 1 }, 300);
            }), 500);
            this.btn.scale(1.2111, 1.2111);
            this.btn.alpha = 0;
            this.btn.visible = true;
            this.btn.mouseEnabled = false;
            let effect = game.FrontEffect.Inst.create_ui_effect(this.btn, 'scene/effect_chunjie_shine.lh', new Laya.Point(0, 0), 1);
            Laya.timer.once(2200, this, () => {
                this.btn.mouseEnabled = true;
                UI_Activity_Chunjie.Inst.locking = false;
                effect.destory();
            });
            Laya.Tween.to(this.btn, { alpha: 1, scaleX: 1, scaleY: 1 }, 250, null, null, 750);
        }

        public onVisibleChange(visible: boolean) {
            if (visible) {
                this.worker_effect.ani1.play(0, true);
            } else {
                this.worker_effect.ani1.stop();
            }
        }

        public setAddAlpha(alpha: number) {
            this.add.alpha = alpha;
        }
    }

    // 农舍
    class Building_NongShe {
        private tag: Laya.Image; // 升级标
        private origin_tag_y: number;
        private icon_cost: Laya.Image;
        private cost: Laya.Label;
        private icon: Laya.Image;// 随等级改变
        private upgrade_btn: Laya.Button;
        private strike: Laya.Sprite;
        private free: Laya.Sprite;
        private type: number = 5001;
        private playing_upgrade_anim: boolean;

        private farmers: Array<{ doing: Laya.Sprite, bg: Laya.Image, icon: Laya.Image, farmer: Laya.Image, lock: Laya.Sprite, btn: Laya.Button }>;

        constructor(me: Laya.Sprite, icon: Laya.Image) {
            this.tag = me.getChildByName('detail').getChildByName('tag') as Laya.Image;
            this.origin_tag_y = this.tag.y;
            this.upgrade_btn = me.getChildByName('detail').getChildByName('btn') as Laya.Button;
            this.icon = icon;
            this.icon_cost = me.getChildByName('detail').getChildByName('icon_cost') as Laya.Image;
            this.cost = me.getChildByName('detail').getChildByName('cost') as Laya.Label;
            this.farmers = [];
            let templete = me.getChildByName('detail').getChildByName('items').getChildByName('0') as Laya.Sprite;
            for (let i = 0; i < 16; ++i) {
                let _item: Laya.Sprite = templete;
                if (i != 0) {
                    _item = templete.scriptMap['capsui.UICopy']['getNodeClone']();

                }
                _item.x = i * 63 + 39;
                let btn = _item.getChildByName('btn') as Laya.Button;
                btn.clickHandler = new Laya.Handler(this, () => {
                    if (UI_Activity_Chunjie.Inst.locking) return;
                    if (this.farmers[i].lock.visible) {
                        UI_Activity_Chunjie_Upgrade.Inst.show(this.type);
                    } else {
                        UIMgr.Inst.ShowErrorInfo1(game.Tools.strOfLocalization(4155));
                    }

                });
                this.farmers.push({ btn, doing: _item.getChildByName('doing') as Laya.Sprite, bg: _item.getChildByName('doing').getChildAt(0) as Laya.Image, icon: _item.getChildByName('doing').getChildByName('icon') as Laya.Image, farmer: _item.getChildByName('farmer') as Laya.Image, lock: _item.getChildByName('lock') as Laya.Sprite });
            }

            (me.getChildByName('detail').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                UI_Activity_Chunjie_Upgrade.Inst.show(this.type);

            });

            this.strike = me.getChildByName('detail').getChildByName('strike') as Laya.Sprite;
            if (GameMgr.client_language == 'en') {
                let img = this.strike.getChildAt(0) as Laya.Image;
                img.y = -45;
                img.height = 87;
                img.width = 470;
                (this.strike.getChildAt(1) as Laya.Sprite).y = -11;
                let label = this.strike.getChildAt(2) as Laya.Label;
                label.width = 360;
                label.y = -33;
                label.wordWrap = true;
            }
            (this.strike.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                UI_Info_Mid.Inst.show(game.Tools.strOfLocalization(4081));
            });
            this.free = me.getChildByName('detail').getChildByName('free') as Laya.Sprite;

        }

        public refresh() {
            let is_strike = UI_Activity_Chunjie.getStrikeState();
            this.strike.visible = is_strike;
            this.cost.color = is_strike ? '#fb5e5e' : '#fff5e5';
            this.refreshFarmerState();
            this.refreshUpgradeState();
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            game.LoadMgr.setImgSkin(this.icon, 'myres/activity_24chunjie/scene/building_5_' + (cfg_data.building_stage - 1) + '.png', null, 'UI_Activity_Chunjie');
        }

        // 刷新是否可升级状态
        public refreshUpgradeState() {
            let building_data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            if (!cfg_data.next_level_id) {
                this.tag.visible = false;
                this.stopUpgradeAnim();
                // this.upgrade_btn.visible = false;
            } else {
                this.tag.visible = true;
                // this.upgrade_btn.visible = true;
                if (UI_Bag.checkItemEnough(cfg_data.upgrade_item)) {
                    this.playUpdgradeAnim();
                    this.tag.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_upgrade_l.png');
                } else {
                    this.stopUpgradeAnim();
                    this.tag.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_upgrade_d.png');
                }
            }
        }

        // 刷新农民状态
        public refreshFarmerState() {
            let building_data: iBuildingData = UI_Activity_Chunjie.getBuildDataByType(this.type);
            let cfg_data: lqc.Sheet_Activity_VillageBuilding = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
            let unlock_count: number = cfg_data.args[0];
            let index: number = 0;
            let cost: number = 0;
            if (UI_Activity_Chunjie.buildings) {
                for (let building of UI_Activity_Chunjie.buildings) {
                    if (building.workers) {
                        let building_data = UI_Activity_Chunjie.getCfgBuildData(building.id);
                        for (let i = 0; i < 4; ++i) {
                            if (building.workers[i]) {
                                let farmer = this.farmers[index++];
                                if (!farmer) break;
                                farmer.lock.visible = false;
                                farmer.farmer.visible = true;
                                farmer.doing.visible = true;
                                farmer.btn.visible = false;
                                farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_7.png');
                                farmer.bg.skin = '';
                                let reward_data = cfg.item_definition.item.get(building_data.produce_item.split('-')[0]);
                                game.LoadMgr.setImgSkin(farmer.icon, reward_data.icon_transparent, null, 'UI_Activity_Chunjie');
                                cost += building_data.worker_consume;
                            }

                        }
                    }
                }
            }
            if (UI_Activity_Chunjie.trip) {
                for (let trip of UI_Activity_Chunjie.trip) {

                    let farmer = this.farmers[index++];
                    if (!farmer) break;
                    farmer.lock.visible = false;
                    farmer.farmer.visible = false;
                    farmer.doing.visible = true;
                    farmer.btn.visible = false;
                    farmer.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/trip.png');
                    let reward_id = Number(UI_Activity_Chunjie.activity_data.trip_reward[trip.dest_id % 3].split('-')[0]);
                    let reward_data = cfg.item_definition.item.get(reward_id);
                    game.LoadMgr.setImgSkin(farmer.icon, reward_data.icon_transparent, null, 'UI_Activity_Chunjie');
                }
            }
            let _count = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id);
            let have_free = _count != 0;
            if (!have_free && UI_Activity_Chunjie.trip) {
                for (let trip of UI_Activity_Chunjie.trip) {
                    if (trip.start_round <= UI_Activity_Chunjie.round - UI_Activity_Chunjie.activity_data.trip_round) {
                        have_free = true;
                        break;
                    }
                }
            }

            this.free.visible = have_free && !this.strike.visible;
            for (let i = 0; i < _count; ++i) {
                let farmer = this.farmers[index++];
                if (!farmer) break;
                farmer.lock.visible = false;
                farmer.farmer.visible = true;
                farmer.doing.visible = false;
                farmer.btn.visible = false;
                farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_4.png');
            }
            for (; index < unlock_count; ++index) {
                let farmer = this.farmers[index];
                farmer.lock.visible = false;
                farmer.farmer.visible = true;
                farmer.doing.visible = false;
                farmer.btn.visible = true;
                farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
            }
            for (; index < this.farmers.length; ++index) {
                let farmer = this.farmers[index];
                farmer.lock.visible = true;
                farmer.farmer.visible = true;
                farmer.doing.visible = false;
                farmer.btn.visible = true;
                farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_5.png');
            }


            this.cost.text = game.Tools.strOfLocalization(4114, [cost.toString()]);
            this.icon_cost.x = 490 - this.cost.textField.textWidth * this.cost.scaleX;

        }

        private playUpdgradeAnim() {
            this.playing_upgrade_anim = true;
        }

        private stopUpgradeAnim() {
            this.playing_upgrade_anim = false;
            this.tag.y = this.origin_tag_y;
        }

        public setUpgradeY(offset_y: number) {
            if (!this.playing_upgrade_anim) return;
            this.tag.y = this.origin_tag_y + offset_y;
        }

        public setYindaoState(state: number) {
            if (state < 0) {
                this.refresh();
            } else {
                let building_data: iBuildingData = UI_Activity_Chunjie.getBuildDataByType(this.type);
                let cfg_data: lqc.Sheet_Activity_VillageBuilding = UI_Activity_Chunjie.getCfgBuildData(building_data.id);
                let unlock_count: number = cfg_data.args[0];
                let index: number = 0;
                let cost: number = 0;
                let data = UI_Activity_Chunjie.getBuildDataByType(1001);
                let building: iBuildingData = { id: data.id, workers: [state], reward: null };
                for (let i = 0; i < 4; ++i) {

                    let building_data = UI_Activity_Chunjie.getCfgBuildData(building.id);
                    if (building.workers[i]) {
                        let farmer = this.farmers[index++];
                        if (!farmer) break;
                        farmer.lock.visible = false;
                        farmer.farmer.visible = true;
                        farmer.doing.visible = true;
                        farmer.btn.visible = false;
                        farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_7.png');
                        farmer.bg.skin = '';
                        let reward_data = cfg.item_definition.item.get(building_data.produce_item.split('-')[0]);
                        game.LoadMgr.setImgSkin(farmer.icon, reward_data.icon_transparent, null, 'UI_Activity_Chunjie');
                        cost += building_data.worker_consume;
                    }
                }


                let _count = state == 0 ? 1 : 0;
                this.free.visible = _count > 0 && !this.strike.visible;
                for (let i = 0; i < _count; ++i) {
                    let farmer = this.farmers[index++];
                    if (!farmer) break;
                    farmer.lock.visible = false;
                    farmer.farmer.visible = true;
                    farmer.doing.visible = false;
                    farmer.btn.visible = false;
                    farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_4.png');
                }
                for (; index < unlock_count; ++index) {
                    let farmer = this.farmers[index];
                    farmer.lock.visible = false;
                    farmer.farmer.visible = true;
                    farmer.doing.visible = false;
                    farmer.btn.visible = true;
                    farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
                }
                for (; index < this.farmers.length; ++index) {
                    let farmer = this.farmers[index];
                    farmer.lock.visible = true;
                    farmer.farmer.visible = true;
                    farmer.doing.visible = false;
                    farmer.btn.visible = true;
                    farmer.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_5.png');
                }


                this.cost.text = game.Tools.strOfLocalization(4114, [cost.toString()]);
                this.icon_cost.x = 490 - this.cost.textField.textWidth * this.cost.scaleX;
            }
        }
    }

    // 探险
    class Building_Trip {
        private items: Array<Item_Trip>;
        private btn_img: Laya.Image;
        private btn_label: Laya.Label;

        constructor(me: Laya.Sprite) {
            let click_handler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;

                UI_Activity_Chunjie_Trip.Inst.show();
            });

            let btn_parent = me.getChildByName('detail').getChildByName('btn') as Laya.Sprite;
            this.btn_img = btn_parent.getChildByName('bg') as Laya.Image;
            this.btn_label = btn_parent.getChildByName('text') as Laya.Label;
            (btn_parent.getChildByName('btn') as Laya.Button).clickHandler = click_handler;

            this.items = [];
            for (let i = 0; i < 3; i++) {
                let output = me.getChildByName('outputs').getChildByName(i.toString()) as Laya.Sprite;
                let item = me.getChildByName('detail').getChildByName('item_' + i) as Laya.Sprite;
                this.items.push(new Item_Trip(item, output, click_handler));
            }
        }

        public refresh(reset_pos: boolean) {
            if (reset_pos) {
                for (let i = 0; i < this.items.length; ++i) {
                    let _data = UI_Activity_Chunjie.trip ? UI_Activity_Chunjie.trip[i] : null;
                    this.items[i].refresh(_data);
                }
            } else {
                for (let item of this.items) {
                    let trip = UI_Activity_Chunjie.getTripDataByDestId(item.dest_id);
                    item.refresh(trip);
                }
            }
            
        }

        

        public reset() {
            for (let item of this.items) {
                item.reset();
            }
        }

        public setAddAlpha(alpha: number) {
            for (let item of this.items) {
                item.setAddAlpha(alpha);
            }
        }
    }

    class Item_Trip {
        private me: Laya.Sprite;
        private add: Laya.Sprite;
        private farmer: Laya.Image;
        private doing: Laya.Sprite;
        private time: Laya.Label;
        private time_en: Laya.Label;
        private icon: Laya.Image;

        private item_output: Item_Output;
        public dest_id: number = -1;
        private locking: boolean;
        private playing_anim: boolean;
        private reward: { id: number, count: number };

        constructor(main: Laya.Sprite, output: Laya.Sprite, click_handler: Laya.Handler) {
            this.me = main;
            let receive_handler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                if (this.locking) return;
                if (this.dest_id < 0 || !this.reward || this.reward.count == 0) return;
                this.locking = true;
                this.item_output.locking = true;
                let reward_id = this.reward.id;
                let dest_id = this.dest_id;
                
                app.NetAgent.sendReq2Lobby('Lobby', 'receiveVillageTripReward', {
                    dest_id: this.dest_id, rewards: [this.reward], activity_id: UI_Activity_Chunjie.activity_id
                }, (err, res) => {
                    this.item_output.locking = false;
                    this.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('receiveVillageTripReward', err, res);
                       
                    } else {
                        for (let i = 0; i < UI_Activity_Chunjie.trip.length; ++i) {
                            if (UI_Activity_Chunjie.trip[i].dest_id == dest_id) {
                                UI_Activity_Chunjie.trip.splice(i, 1);
                                break;
                            }
                        }
                        this.dest_id = -1;
                        this.reward = null;
                        this.playAnim();
                        this.item_output.playCollectAnim(UI_Activity_Chunjie.Inst.container_currency.getTargetPosById(reward_id));
                        view.AudioMgr.PlayAudio(10110);
                        
                    }
                })
            });
            (main.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie.Inst.locking) return;
                if (!(this.dest_id < 0 || !this.reward || this.reward.count == 0)) {
                    receive_handler.run();
                    return;
                }
                click_handler.run();
            });
            this.item_output = new Item_Output(output, receive_handler);
            this.doing = main.getChildByName('doing') as Laya.Sprite;
            this.farmer = main.getChildByName('farmer') as Laya.Image;
            this.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
            this.add = main.getChildByName('add') as Laya.Sprite;
            this.time = this.doing.getChildByName('time') as Laya.Label;
            this.time_en = this.doing.getChildByName('time_en') as Laya.Label;
            if (GameMgr.client_language != 'en') {
                this.time_en.text = '';
                
            } else {
                this.time.y = 50;
            }
            this.icon = this.doing.getChildByName('icon') as Laya.Image;
        }

        public refresh(trip_data: iTripData) {
            this.reward = null;

            if (trip_data) {
                if (UI_Activity_Chunjie_Trip.Inst.enable) {
                    if (this.dest_id != trip_data.dest_id) {
                        Laya.Tween.to(this.farmer, { alpha: 0 }, 100);
                        this.playing_anim = true;
                        Laya.Tween.to(this.add, { alpha: 0 }, 100, null, Laya.Handler.create(this, ()=>{
                            this.add.visible = false;
                            this.playing_anim = false;
                        }));
                        this.doing.visible = true;
                        this.doing.alpha = 0;
                        Laya.Tween.to(this.doing, { alpha: 1 }, 120, null, null, 100);
                        this.icon.scale(0.5, 0.5);
                        Laya.Tween.to(this.icon, { scaleX: 1, scaleY: 1 }, 180, null, null, 100);
                    }
                } else {
                    this.add.visible = false;
                    this.farmer.visible = false;
                    this.doing.visible = true;
                }
                this.dest_id = trip_data.dest_id;

                let _count = 0;
                let _id = 0;
                let round = UI_Activity_Chunjie.round;
                if (trip_data.reward && trip_data.reward[0]) {
                    this.time.visible = false;
                    this.time_en.visible = false;
                    _count = trip_data.reward[0].count;
                    _id = trip_data.reward[0].id;
                } else if (round - trip_data.start_round >= UI_Activity_Chunjie.activity_data.trip_round) {
                    this.time.visible = false;
                    this.time_en.visible = false;
                    let rewards = UI_Activity_Chunjie.activity_data.trip_reward[trip_data.dest_id % 3].split('-');
                    _id = Number(rewards[0]);
                    _count = trip_data.level * Number(rewards[1]);
                } else {
                    let rewards = UI_Activity_Chunjie.activity_data.trip_reward[trip_data.dest_id % 3].split('-');
                    _id = Number(rewards[0]);
                    this.time.visible = true;
                    this.time_en.visible = true;
                    let _left_round = UI_Activity_Chunjie.activity_data.trip_round - (round - trip_data.start_round);
                    this.time.text = GameMgr.client_language == 'en' ? _left_round.toString() : (_left_round.toString() + game.Tools.strOfLocalization(4180));
                }
                this.reward = { id: _id, count: _count };
                let _skin = cfg.item_definition.item.get(_id).icon_transparent;
                this.item_output.show(_skin, _count);
                game.LoadMgr.setImgSkin(this.icon, _skin, null, 'UI_Activity_Chunjie');
            } else {
                
                this.farmer.alpha = 1;
                this.add.alpha = 1;
                this.dest_id = -1;
                this.item_output.show('', 0);
                this.farmer.visible = true;
                this.doing.visible = false;
                this.add.visible = true;
            }
        }

        public reset() {
            this.item_output.stopAnim();
        }

        private playAnim() {
            Laya.Tween.to(this.me, {scaleX: 0, scaleY: 0}, 150, null, Laya.Handler.create(this, ()=>{
                this.farmer.alpha = 1;
                this.add.alpha = 1;
                this.dest_id = -1;
                this.farmer.visible = true;
                this.doing.visible = false;
                this.add.visible = true;
                Laya.Tween.to(this.me, {scaleX: 1, scaleY: 1}, 150);
            }));
        }

        public setAddAlpha(alpha: number) {
            if (this.playing_anim) return;
            this.add.alpha = alpha;
        }

    }

    //产出数量展示单元
    class Item_Output {
        private me: Laya.Sprite;
        private output_counts: Array<Laya.Image>;
        private output_images: Array<Laya.Image>;
        private count_parent: Laya.Sprite;
        private bg: Laya.Sprite;
        public locking: boolean; //点收取前就需要lock，防止notify先到刷新了

        private count: number;
        private skin_path: string;

        private origin_y: number;
        private playing_anim: boolean;

        private pos_list: Array<{ x: number, y: number }> = [{ x: 38, y: 33 }, { x: 63, y: 33 }, { x: 23, y: 53 }, { x: 48, y: 53 }, { x: 73, y: 53 }, { x: 10, y: 73 }, { x: 35, y: 73 }, { x: 60, y: 73 }, { x: 85, y: 73 }];
        constructor(me: Laya.Sprite, click_handler: Laya.Handler) {
            this.me = me;
            this.output_counts = [];
            this.count_parent = me.getChildByName('count') as Laya.Sprite;
            for (let i = 0; i < 5; ++i) {
                let image = me.getChildByName('count').getChildAt(i) as Laya.Image;
                this.output_counts.push(image);
                image.x = 6 + 17 * i;
            }

            this.output_images = [];
            let image_parent = me.getChildByName('images') as Laya.Sprite;
            for (let i = 0; i < 9; ++i) {
                if (i == 0) {
                    this.output_images.push(image_parent.getChildAt(0) as Laya.Image);
                } else {
                    let image = new Laya.Image();
                    image.width = 49;
                    image.height = 49;
                    this.output_images.push(image);
                    image_parent.addChild(image);
                }

            }
            this.bg = this.me.getChildByName('bg') as Laya.Sprite;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = click_handler;
            this.origin_y = this.me.y;
        }

        public show(skin_path: string, count: number) {
            this.skin_path = skin_path;
            this.count = count;
            if (this.locking) return; // 动画播放阶段不刷新显示
            this.bg.alpha = 1;
            this.count_parent.alpha = 1;
            // this.count_parent.visible = false;
            if (!count) {
                this.stopAnim();
                this.me.visible = false;
            } else {
                if (!this.playing_anim) {
                    this.playVisibleAnim();
                }
                this.me.visible = true;
                game.LoadMgr.setImgSkin(this.output_images[0], skin_path, Laya.Handler.create(this, () => {
                    for (let image of this.output_images) {
                        image.skin = this.output_images[0].skin;
                    }
                }), 'UI_Activity_Chunjie');
                let count_str = count.toString();
                for (let i = 1; i < 5; ++i) {
                    let image = this.output_counts[i];

                    if (i <= count_str.length) {
                        image.visible = true;
                        image.skin = game.Tools.localUISrc('myres/activity_24chunjie/count_' + count_str[i - 1] + '.png');
                    } else {
                        image.visible = false;
                    }
                }
                this.count_parent.x = 50 - (17 * count_str.length - 17) / 2;
                let show_count = Math.min(this.output_images.length, count);
                let offset_x = show_count < 4 ? (4 - show_count) * 12.5 : 0;
                let offset_y = show_count <= 4 ? 10 : (show_count <= 8 ? 5 : 0);
                for (let i = 0; i < this.output_images.length; ++i) {
                    let image = this.output_images[i];
                    if (i < this.output_images.length - show_count) {
                        image.visible = false;
                    } else {
                        image.visible = true;
                        image.alpha = 1;
                        image.pos(this.pos_list[i].x - offset_x, this.pos_list[i].y - offset_y);
                    }
                }
            }
        }

        public playCollectAnim(target_pos: Laya.Point) {
            
            let local_pos = this.me.globalToLocal(target_pos);
            this.locking = true;
            let index = 0;
            let t = Math.sqrt((Math.pow(local_pos.x, 2) + Math.pow(local_pos.y, 2))) / 1.5;
            for (let i = this.output_images.length - 1; i >= 0; i--) {
                let image = this.output_images[i];
                if (image.visible) {

                    Laya.Tween.to(image, { x: local_pos.x, y: local_pos.y }, t + 116, null, null, index * 16);
                    Laya.Tween.to(image, { alpha: 0 }, 100, null, null, index * 16 + t + 16);
                    ++index;
                } else {
                    break;
                }
            }
            Laya.Tween.to(this.bg, { alpha: 0 }, 250);
            Laya.Tween.to(this.count_parent, { alpha: 0 }, 250);
            Laya.timer.once(index * 16 + t + 116, this, () => {
                this.locking = false;
                this.show(this.skin_path, this.count);
            });// 动画结束了刷新一下，万一刚好到1h
        }

        private playVisibleAnim() {
            this.playing_anim = true;
            this.me.y = this.origin_y;
            Laya.Tween.to(this.me, { y: this.origin_y - 6 }, 1000, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                Laya.Tween.to(this.me, { y: this.origin_y }, 1000, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                    this.playVisibleAnim();
                }));
            }));
        }

        public stopAnim() {
            this.playing_anim = false;
            Laya.Tween.clearAll(this.me);
        }
    }

    class Container_Currency {
        public me: Laya.Sprite;
        private list_item_id: Array<number>;
        private list_label_count: Array<Laya.Label>;
        private strike: Laya.Sprite;
        private label_time: Laya.Label;
        constructor(me: Laya.Sprite) {
            this.me = me;
            this.strike = this.me.getChildByName('strike') as Laya.Sprite;
            this.label_time = this.me.getChildByName('time') as Laya.Label;
            this.list_item_id = [];
            this.list_label_count = [];
            for (let i = 0; i < 6; ++i) {
                let item_id = 30900007 + i;
                this.list_item_id.push(item_id);
                let currency = me.getChildByName('currency_' + i) as Laya.Sprite;
                let _data = cfg.item_definition.item.get(item_id);
                game.LoadMgr.setImgSkin(currency.getChildByName('icon') as Laya.Image, _data.icon_transparent, null, 'UI_Activity_Chunjie');

                let label = currency.getChildByName('count') as Laya.Label;
                this.list_label_count.push(label);
                (currency.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                    if (UI_Activity_Chunjie.Inst.locking) return;
                    UI_ItemDetail.Inst.show(item_id);
                });
                UI_Bag.add_item_listener(item_id, new Laya.Handler(this, () => {
                    label.text = UI_Bag.get_item_count(item_id).toString();

                }));
            }
        }

        public show() {
            let is_strike = UI_Activity_Chunjie.getStrikeState();
            let food_count = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.food_item_id);
            for (let i = 0; i < this.list_item_id.length; ++i) {
                let item_id = this.list_item_id[i];
                this.list_label_count[i].text = UI_Bag.get_item_count(item_id).toString();

            }
            this.strike.visible = is_strike;

            this.label_time.visible = false;
            if (!is_strike) {
                let consume = UI_Activity_Chunjie.getRoundConsume();
                if (consume > 0) {
                    this.label_time.visible = true;
                    this.label_time.text = game.Tools.strOfLocalization(4124) + game.Tools.strOfLocalization(4126, [Math.floor(food_count / consume).toString()]);
                }
            }

        }


        public getTargetPosById(id: number): Laya.Point {
            let index = this.list_item_id.indexOf(id);
            if (index < 0) {
                return null;
            }
            return (this.list_label_count[index].parent as Laya.Sprite).localToGlobal(new Laya.Point(0, 0));
        }

        public onYindao(count: number) {

            if (count >= 0) {
                this.list_label_count[1].text = count.toString();
            } else {
                let item_id = this.list_item_id[1];
                this.list_label_count[1].text = UI_Bag.get_item_count(item_id).toString();
            }
        }
    }
    interface iBuildingData { id: number; workers: Array<number>; reward: Array<{ id: number, count: number }> };
    export interface iTripData {
        start_round: number, dest_id: number, reward: Array<{ id: number, count: number }>, level: number,
        info: { nickname: string, avatar: number, avatar_frame: number, title: number, verified: number }
    };

    export class UI_Activity_Chunjie extends UIBase {
        public static Inst: UI_Activity_Chunjie;
        public static activity_id: number = 240101;
        public static round: number = 0;
        public static trip: Array<iTripData>;
        public static buildings: Array<iBuildingData>;
        public static tasks: Object; // 已完成任务
        public static _sort_data_map: Object = null;

        public static get sort_data_map(): Object {
            if (!this._sort_data_map) {
                this._sort_data_map = {};
                let datas: Array<lqc.Sheet_Activity_VillageBuilding> = cfg.activity.village_building.getGroup(this.activity_id);
                for (let data of datas) {
                    if (!this._sort_data_map[data.type]) {
                        this._sort_data_map[data.type] = [data];
                    } else {
                        this._sort_data_map[data.type].push(data);
                    }
                }
            }
            return this._sort_data_map;
        }
        public static get activity_data(): lqc.Sheet_Activity_VillageActivityInfo {
            if (!this._activity_data) {
                this._activity_data = cfg.activity.village_activity_info.get(this.activity_id);
            }
            return this._activity_data;
        }
        private static _activity_data: lqc.Sheet_Activity_VillageActivityInfo;


        public static update_data(datas: Array<any>) {
            for (let data of datas) {
                if (data.activity_id == this.activity_id) {
                    this.round = data.round;
                    this.buildings = [];
                    this.trip = [];
                    this.tasks = {};
                    if (data.buildings) {
                        for (let building of data.buildings) {
                            this.buildings.push(building);
                        }
                    }
                    this.buildings.sort((a, b) => {
                        return a.id - b.id;
                    });
                    if (data.trip) {
                        for (let trip of data.trip) {
                            this.trip.push(trip);
                        }
                    }
                    if (data.tasks) {
                        for (let task of data.tasks) {
                            this.tasks[task.id] = task.completed_count;
                        }
                    }
                    if (this.Inst && this.Inst.enable) {
                        Laya.timer.frameOnce(1, this, () => {
                            this.Inst.refreshAll();
                        });

                    }
                }
            }
        }
        // 根据type获取指定datas
        public static getCfgBuildDataGroupByType(type: number): Array<lqc.Sheet_Activity_VillageBuilding> {
            return this.sort_data_map[type];
        }

        // type 4位，返回null不太舒服，统一处理一下塞一个id正确的空的
        public static getBuildDataByType(type: number): iBuildingData {

            if (this.buildings) {
                let cfgDatas = this.getCfgBuildDataGroupByType(type);
                if (cfgDatas) {
                    for (let building of this.buildings) {
                        for (let data of cfgDatas) {
                            if (data.building_id == building.id) {
                                return building;
                            }
                        }
                    }
                }

            }

            let empty_building = { id: type * 100 + 1, workers: [], reward: [] };
            this.buildings.push(empty_building);
            this.buildings.sort((a, b) => {
                return a.id - b.id;
            });
            return empty_building;
        }

        public static getBuildDataById(id: number): iBuildingData {
            for (let building of this.buildings) {
                if (building.id == id) {
                    return building;
                }
            }
            return null;
        }

        public static getCfgBuildData(id: number): lqc.Sheet_Activity_VillageBuilding {
            let group = cfg.activity.village_building.getGroup(this.activity_id);
            if (group) {
                for (let data of group) {
                    if (data.building_id == id) {
                        return data;
                    }
                }
            }
            return null;
        }

        public static getTotalFarmerCount(): number {
            let count = UI_Bag.get_item_count(this.activity_data.worker_item_id);
            if (this.buildings) {
                for (let building of this.buildings) {
                    if (building.workers) {
                        for (let state of building.workers) {
                            if (state)++count;
                        }
                    }
                }
            }
            if (this.trip) {
                count += this.trip.length;
            }
            return count;
        }

        public static getTripDataByDestId(dest_id: number): iTripData {
            if (this.trip) {
                for (let trip of this.trip) {
                    if (trip.dest_id == dest_id) {
                        return trip;
                    }
                }
            }
            return null;
        }


        public static have_redpoint(): boolean {
            return UI_Activity_Chunjie_Task.haveRedPoint() || UI_Activity_Chunjie_Reward.haveRedPoint() || UI_Bag.checkItemEnough(this.activity_data.round_consume);
        }

        // 获得一轮消耗
        public static getRoundConsume(): number {
            let count = 0;
            if (this.buildings) {
                for (let building of this.buildings) {
                    if (building.workers) {
                        for (let state of building.workers) {
                            if (state)++count;
                        }
                    }
                }
            }
            return count;
        }

        public static getStrikeState(): boolean {
            return UI_Bag.get_item_count(this.activity_data.food_item_id) < this.getRoundConsume();
        }

        private bg: Laya.Image;
        private scene: Laya.Image;
        private building_main: Building_Main;
        private building_nongshe: Building_NongShe;
        private building_trip: Building_Trip;
        private list_building_normal: Array<Building_Normal>;
        private container_page: Laya.Sprite;

        private redpoint_task: Laya.Sprite;
        private redpoint_reward: Laya.Sprite;
        private redpoint_main: Laya.Sprite;

        // 附加额外界面
        public page_upgrade: UI_Activity_Chunjie_Upgrade;
        public page_miao: UI_Activity_Chunjie_Main;
        public page_task: UI_Activity_Chunjie_Task;
        public page_reward: UI_Activity_Chunjie_Reward;
        public page_trip: UI_Activity_Chunjie_Trip;
        private page_rule: UI_Activity_Chunjie_Rule;

        public container_currency: Container_Currency;

        private btn_next: Laya.Button;
        private bg_next: Laya.Image;
        private label_count: Laya.Label;

        private show_page_time: number;

        public locking_refresh: boolean; // 打开升级面板时，把收到notify时的刷新锁了

        private audio_id: number;
        private loop_audio_id: number;
        private round_item_id: number;


        constructor() {
            super(new ui.lobby.chunjie.activity_chunjieUI());
            UI_Activity_Chunjie.Inst = this;
        }

        public locking: boolean;

        public onCreate() {
            this.bg = this.me.getChildByName('scene').getChildAt(0) as Laya.Image;
            this.scene = this.me.getChildByName('buildings').getChildAt(0) as Laya.Image;

            let buildings = this.me.getChildByName('buildings');
            let buildings_ui = this.me.getChildByName('builidings_ui');
            this.building_main = new Building_Main(buildings.getChildByName('building_main') as Laya.Sprite);
            this.building_nongshe = new Building_NongShe(buildings_ui.getChildByName('building_nongshe') as Laya.Sprite, buildings.getChildByName('building_nongshe').getChildByName('icon') as Laya.Image);
            this.building_trip = new Building_Trip(buildings_ui.getChildByName('building_trip') as Laya.Sprite);

            this.list_building_normal = [];
            for (let i = 1; i <= 4; ++i) {
                let building = buildings.getChildByName('building_' + i) as Laya.Sprite;
                let type = i * 1000 + 1;
                if (i == 3) {
                    let start_building_id = Number(UI_Activity_Chunjie.activity_data.random_building.split(',')[GameMgr.Inst.account_id % 3]);
                    let cfgData = UI_Activity_Chunjie.getCfgBuildData(start_building_id);
                    type = cfgData.type;
                }
                this.list_building_normal.push(new Building_Normal(building, type));
            }
            this.container_page = this.me.getChildByName('container_page') as Laya.Sprite;
            this.container_currency = new Container_Currency(this.me.getChildByName('container_currency') as Laya.Sprite);

            let top = this.me.getChildByName('container_top') as Laya.Sprite;
            let left = top.getChildByName('left') as Laya.Sprite;

            this.btn_next = left.getChildByName('btn').getChildByName('btn') as Laya.Button;
            this.btn_next.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (!UI_Bag.checkItemEnough(UI_Activity_Chunjie.activity_data.round_consume)) {
                    this.locking = true;
                    Laya.timer.frameOnce(14, this, ()=>{
                        this.locking = false;
                    });
                    UIMgr.Inst.ShowErrorInfo1(game.Tools.strOfLocalization(4154));
                    return;
                }
                if (UI_Activity_Chunjie.getStrikeState()) {
                    this.locking = true;
                    Laya.timer.frameOnce(14, this, ()=>{
                        this.locking = false;
                    });
                    UIMgr.Inst.ShowErrorInfo(game.Tools.strOfLocalization(4151));
                    return;
                }
                let self = this;
                let func = function () {
                    self.locking = true;
                    self.locking_refresh = true;
                    app.NetAgent.sendReq2Lobby('Lobby', 'nextRoundVillage', { activity_id: UI_Activity_Chunjie.activity_id }, (err, res) => {
                        self.locking = false;
                        if (err || res['error']) {
                            self.locking_refresh = false;
                            UIMgr.Inst.showNetReqError('nextRoundVillage', err, res);

                        } else {
                            // TODO播云动画

                            UI_Activity_Chunjie_Next.Inst.show(Laya.Handler.create(self, () => {
                                self.locking_refresh = false;
                                UI_Activity_Chunjie.update_data([res['activity_data']]);
                            }));

                        }
                    });
                }
                let have_free = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id) != 0;
                if (!have_free && UI_Activity_Chunjie.trip) {
                    for (let trip of UI_Activity_Chunjie.trip) {
                        if (trip.start_round <= UI_Activity_Chunjie.round - UI_Activity_Chunjie.activity_data.trip_round) {
                            have_free = true;
                            break;
                        }
                    }
                }
                if (have_free) {
                    UI_SecondConfirm.Inst.show(game.Tools.strOfLocalization(4150), Laya.Handler.create(this, func));
                } else {
                    func();
                }
            });

            this.bg_next = left.getChildByName('btn').getChildByName('bg') as Laya.Image;
            let count = left.getChildByName('count') as Laya.Sprite;
            this.label_count = count.getChildByName('count') as Laya.Label;
            this.label_count.text = '12';
            let _offset_x = (count.getChildAt(1) as Laya.Label).textField.textWidth * (count.getChildAt(1) as Laya.Label).scaleX - 130;
            this.label_count.x += _offset_x;
            count.x -= _offset_x / 2;
            (left.getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            if (GameMgr.client_language == 'en') {
                (left.getChildByName('btn_info') as Laya.Button).x = 634;
            }
            (left.getChildByName('btn_info') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.building_main.reset();
                this.page_rule.show();
            });

            this.round_item_id = Number(UI_Activity_Chunjie.activity_data.round_consume.split('-')[0]);
            UI_Bag.add_item_listener(this.round_item_id, new Laya.Handler(this, this.refreshRoundCount));
            if (GameMgr.client_language == 'en') {
                count.y = 284;
                count.x -= 15;
                (left.getChildByName('btn') as Laya.Sprite).pos(252, 253);
                (left.getChildByName('info') as Laya.Sprite).visible = false;
            } else {
                (left.getChildByName('info_fix') as Laya.Sprite).visible = false;
            }

            let right = top.getChildByName('right') as Laya.Sprite;
            (right.getChildByName('btn_reward') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.page_reward.show();
            });

            if (GameMgr.client_language == 'chs_t') {
                (right.getChildByName('btn_reward').getChildByName('text') as Laya.Sprite).visible = false;
                (right.getChildByName('btn_reward').getChildByName('bg_text') as Laya.Sprite).visible = false;
            }
            (right.getChildByName('btn_task') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.page_task.show();
            });
            this.redpoint_task = right.getChildByName('btn_task').getChildByName('redpoint') as Laya.Sprite;
            this.redpoint_reward = right.getChildByName('btn_reward').getChildByName('redpoint') as Laya.Sprite;
            this.redpoint_main = buildings.getChildByName('building_main').getChildByName('detail').getChildByName('redpoint') as Laya.Sprite;

            this.page_upgrade = new UI_Activity_Chunjie_Upgrade();
            this.container_page.addChild(this.page_upgrade.me);

            this.page_miao = new UI_Activity_Chunjie_Main();
            this.container_page.addChild(this.page_miao.me);

            this.page_task = new UI_Activity_Chunjie_Task();
            this.container_page.addChild(this.page_task.me);
            this.page_reward = new UI_Activity_Chunjie_Reward();
            this.container_page.addChild(this.page_reward.me);

            this.page_trip = new UI_Activity_Chunjie_Trip();
            this.container_page.addChild(this.page_trip.me);

            this.page_rule = new UI_Activity_Chunjie_Rule();
            this.container_page.addChild(this.page_rule.me);

            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjieUI).show;
            show_anim.interval = 16.7;
            let strike = (this.me as ui.lobby.chunjie.activity_chunjieUI).strike;
            let self = this;
            document.addEventListener("visibilitychange", function () {
                if (!self.enable) return;
                if (document.visibilityState != "visible") {
                    self.onVisibleChange(false);
                } else {
                    self.onVisibleChange(true);
                }
            });
            this.onVisibleChange(false);
        }

        public show() {

            view.AudioMgr.PlayAudio(10106);
            this.enable = true;
            this.refreshTrip();
            this.show_page_time = Laya.timer.currTimer;
            this.refreshRoundCount();
            view.AudioMgr.StopMusic();
            let _audio = cfg.audio.audio.get(10101);
            let _loop_audio = cfg.audio.audio.get(10102);
            let audio_info = view.AudioMgr.playABBBSound(_audio.path, _loop_audio.path, view.AudioMgr.musicMuted || view.AudioMgr.allAudioMuted ? 0 : view.AudioMgr.musicVolume, _audio.time_length);
            this.audio_id = audio_info.a_id;
            this.loop_audio_id = audio_info.b_id;
            let sound_channel = view.AudioMgr.GetAudioChannel(this.loop_audio_id);
            if (sound_channel) {
                sound_channel['_duration'] = 73.4;
            }

            game.LoadMgr.setImgSkin(this.bg, 'myres/activity_24chunjie/scene/bg.jpg', null, 'UI_Activity_Chunjie');
            game.LoadMgr.setImgSkin(this.scene, 'myres/activity_24chunjie/scene/scene.png', null, 'UI_Activity_Chunjie');
            this.locking = true;
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjieUI).show;
            show_anim.wrapMode = 0;
            show_anim.play(0, false);
            this.container_currency.show();
            Laya.timer.once(250, this, () => {
                this.locking = false;
            });
            
            this.refreshAll();
            if (!app.PlayerBehaviorStatistic.get_val(app.EBehaviorType.Chunjie_Yindao_Checked)) {
                UI_Activity_Yindao.Inst.show();
            }
        }

        public refreshAll() {
            this.refreshRedpoint();
            this.container_currency.show();
            this.refreshNongShe();
            this.refreshTrip(false);

            //打开升级界面时,白龙庙不刷新，产出建筑只刷新是否可升级和产出数量，不刷新地
            if (this.locking_refresh) {
                for (let building of this.list_building_normal) {
                    building.refresh_locking();
                }
                return;
            }
            this.building_main.refresh();
            
            let need_play_unlock_audio: boolean = false;
            for (let building of this.list_building_normal) {
                if (building.refresh()) {
                    need_play_unlock_audio = true;
                }
            }
            if (need_play_unlock_audio) {
                view.AudioMgr.PlayAudio(10105);
            }
        }

        // 单刷探险部分
        public refreshTrip(reset_pos: boolean = true) {
            this.building_trip.refresh(reset_pos);
        }

        public refreshNongShe() {
            this.building_nongshe.refresh();
        }
        public close() {
            this.locking = true;
            
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjieUI).show;
            show_anim.wrapMode = 1;
            show_anim.play(show_anim.count, false);
            Laya.timer.once(250, this, () => {
                this.locking = false;
                this.enable = false;
                UI_Lobby.Inst.enable = true;
            });

        }
        public update() {

            let offset_time = (Laya.timer.currTimer - this.show_page_time) % 3000;
            let offset_y = 0;
            if (offset_time < 250) {
                offset_y = -offset_time / 250 * 5;
            } else if (offset_time <= 500) {
                offset_y = (offset_time - 500) / 250 * 5;
            }
            for (let building of this.list_building_normal) {
                building.setUpgradeY(offset_y);
            }
            this.building_nongshe.setUpgradeY(offset_y);

            let add_offset_time = (Laya.timer.currTimer - this.show_page_time) % 2000;
            let alpha = Math.abs(add_offset_time - 1000) / 1000 * 0.48 + 0.52;
            for (let building of this.list_building_normal) {
                building.setAddAlpha(alpha);
            }
            this.building_trip.setAddAlpha(alpha);
        }


        public onEnable() {
            this.onVisibleChange(true);
            game.TempImageMgr.setUIEnable('UI_Activity_Chunjie', true);
            
        }

        public onDisable() {
            if (this.audio_id) {
                view.AudioMgr.StopAudio(this.audio_id);
                this.audio_id = 0;
            }
            if (this.loop_audio_id) {
                view.AudioMgr.StopAudio(this.loop_audio_id);
                this.loop_audio_id = 0;
            }
            view.BgmListMgr.PlayLobbyBgm();

            for (let building of this.list_building_normal) {
                building.reset();
            }
            this.building_main.reset();
            this.building_trip.reset();

            this.onVisibleChange(false);
            game.TempImageMgr.setUIEnable('UI_Activity_Chunjie', false);
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_24chunjie.atlas'));
        }

        public setCurrencyLayer(front: boolean) {
            this.me.setChildIndex(this.container_currency.me, front ? this.me._childs.length - 1 : this.me._childs.length - 2);
        }

        public onUpgradeClose() {
            this.building_main.playAnim(); // 播放繁荣度动画
            this.refreshAll();
        }

        public refreshRedpoint() {
            this.redpoint_reward.visible = UI_Activity_Chunjie_Reward.haveRedPoint();
            this.redpoint_task.visible = UI_Activity_Chunjie_Task.haveRedPoint();
            this.redpoint_main.visible = UI_Activity_Chunjie_Main.haveRedPoint();
        }

        public onYindaoWorkerChange(is_add: boolean) {
            this.list_building_normal[0].onYindao(is_add);
        }
        public onYindaoCurrencyStateChange(count: number) {
            this.container_currency.onYindao(count);
        }
        private onVisibleChange(visible: boolean) {
            if (!visible) {
                (this.me as ui.lobby.chunjie.activity_chunjieUI).strike.stop();
            } else {
                (this.me as ui.lobby.chunjie.activity_chunjieUI).strike.play(0, true);
            }

            for (let item of this.list_building_normal) {
                item.onVisibleChange(visible);
            }
        }

        //允许强行 设置显示
        public refreshRoundCount(count: number = -1) {
            if (this.label_count) {
                let _count = count >= 0 ? count : UI_Bag.get_item_count(this.round_item_id);
                (this.btn_next.parent.getChildByName('redpoint') as Laya.Sprite).visible = _count > 0;
                this.bg_next.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_' + (_count == 0 ? 'd.png' : 'l.png'));
                this.label_count.color = _count == 0 ? '#fb5e5e' : '#3b2a1f';
                this.label_count.text = _count.toString();
            }
        }

        // state= -1 结束引导状态 0 空闲 1森林
        public onYindaoNongsheState(farmer_state: number) {
            this.building_nongshe.setYindaoState(farmer_state);
        }

        public onYindaoStart() {
            this.onYindaoNongsheState(0);
            this.onYindaoCurrencyStateChange(0);
            this.refreshRoundCount(1);
        }

        public onYindaoOutputChange(count: number) {
            this.list_building_normal[0].onYindaoOutputChange(count);
        }
    }
}