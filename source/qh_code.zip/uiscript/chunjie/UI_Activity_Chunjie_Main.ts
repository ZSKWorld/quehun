module uiscript {
    class TaskCell {
        public me: Laya.Sprite;
        private bg: Laya.Image;
        private desc: Laya.Label;
        private done: Laya.Sprite;
        private cost: Laya.Sprite;
        private list_cost: Array<{ me: Laya.Sprite, icon: Laya.Image, count: Laya.Label }>;
        private btn: Laya.Button;
        private btn_image: Laya.Image;
        private btn_label: Laya.Label;
        private repeat: Laya.Sprite;
        private repeat_lock: Laya.Sprite;
        private label_count: Laya.Label;
        private icon: Laya.Sprite;
        private lock: Laya.Sprite;

        private id: number = 0;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.desc = this.me.getChildByName('desc') as Laya.Label;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn_image = this.btn.getChildByName('image') as Laya.Image;
            this.btn_label = this.btn.getChildByName('text') as Laya.Label;
            this.done = this.me.getChildByName('done') as Laya.Sprite;
            this.cost = this.me.getChildByName('cost') as Laya.Sprite;
            this.list_cost = [];
            for (let i = 0; i < 2; ++i) {
                let _item = this.cost.getChildAt(i) as Laya.Sprite;
                this.list_cost.push({ me: _item, icon: _item.getChildAt(0) as Laya.Image, count: _item.getChildByName('count') as Laya.Label });
            }
            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.repeat = this.me.getChildByName('repeat') as Laya.Sprite;
            this.repeat_lock = this.repeat.getChildByName('lock') as Laya.Sprite;
            this.icon = this.me.getChildByName('icon') as Laya.Sprite;
            (this.icon.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie_Main.Inst.locking) return;
                UI_ItemDetail.Inst.show(UI_Activity_Chunjie.activity_data.worker_item_id);
            });
            if (GameMgr.client_language == 'en') {
                let repeat = this.repeat.getChildByName('repeat') as Laya.Sprite;
                (repeat.getChildAt(0) as Laya.Sprite).width = 208;
                (repeat.getChildAt(2) as Laya.Sprite).x = -31;
            }
            this.label_count = this.me.getChildByName('count').getChildByName('count') as Laya.Label;
            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie_Main.Inst.locking) return;
                UI_Activity_Chunjie_Main.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'completeVillageTask', { task_id: this.id, activity_id: UI_Activity_Chunjie.activity_id }, (err, res) => {
                    UI_Activity_Chunjie_Main.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completeVillageTask', err, res);
                    } else {
                        let rewards = res['reward_items'];
                        let items = [];
                        if (rewards) {
                            for (let reward of rewards) {
                                items.push(reward.reward);
                            }
                            if (items[0].id == UI_Activity_Chunjie.activity_data.worker_item_id) {
                                UI_Activity_Chunjie_Main_Reward.Inst.show(Laya.Handler.create(this, () => {
                                    UI_Activity_Chunjie_Main.Inst.onTaskRewarded();
                                }));
                            } else {
                                game.Tools.showRewards({ rewards: items }, null);
                            }
                        }


                        UI_Activity_Chunjie_Main.Inst.onTaskComplete();
                        UI_Activity_Chunjie.Inst.refreshNongShe();
                        // if (!this.repeat.visible) {
                        //     this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_d.png');
                        //     this.btn.visible = false;
                        //     this.cost.visible = false;
                        //     this.done.visible = true;
                        // }


                    }
                });
            });
        }

        public show(data: lqc.Sheet_Activity_VillageTask) {
            this.me.visible = true;
            if (!data) {
                // 引导
                this.lock.visible = false;
                this.done.visible = false;
                this.repeat.visible = false;
                this.label_count.text = '1';
                this.cost.visible = true;
                this.btn.visible = true;
                this.icon.visible = true;
                this.desc.text = game.Tools.strOfLocalization(4113);
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_l.png');
                this.btn_label.text = game.Tools.strOfLocalization(4050);
                this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                let index = 0;
                for (let i = 0; i < 2; ++i) {
                    let item = this.list_cost[i];
                    if (i == 1) {
                        item.me.visible = false;
                        break;
                    }
                    item.me.visible = true;
                    let id = 30900008 + i;
                    item.count.text = '1';
                    let item_data = cfg.item_definition.item.get(id);
                    game.LoadMgr.setImgSkin(item.icon, item_data.icon_transparent, null, 'UI_Activity_Chunjie');

                    item.count.color = '#ffffff';

                    ++index;

                }
                this.cost.x = index == 1 ? 742 : 692;
                return;
            }
            this.id = data.mission_id;
            let _delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            this.repeat.visible = !!data.if_loop;
            this.icon.visible = !data.if_loop;
            this.label_count.text = '1';
            if (data.if_loop) {
                this.label_count.text = data.reward.split('-')[1];
                this.desc.text = game.Tools.strOfLocalization(data.mission_str);
                
                if (UI_Bag.checkItemEnough(data.unlock_point)) {
                    // this.repeat_count.visible = true;
                    this.lock.visible = false;
                    this.done.visible = false;
                    this.cost.visible = true;
                    this.btn.visible = true;
                    this.repeat_lock.visible = false;
                    this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_l.png');

                    let rewards = data.consume.split(',');
                    let enough = true;
                    let index = 0;
                    for (let i = 0; i < 2; ++i) {
                        let item = this.list_cost[i];
                        if (rewards[i]) {

                            item.me.visible = true;
                            let nums = rewards[i].split('-');
                            let id = Number(nums[0]);
                            let count = Number(nums[1]);
                            item.count.text = nums[1];
                            let item_data = cfg.item_definition.item.get(id);
                            game.LoadMgr.setImgSkin(item.icon, item_data.icon_transparent, null, 'UI_Activity_Chunjie');
                            if (UI_Bag.get_item_count(id) < count) {
                                enough = false;
                                item.count.color = '#fb5e5e';
                            } else {
                                item.count.color = '#ffffff';
                            }
                            ++index;
                        } else {
                            item.me.visible = false;
                        }
                    }
                    this.cost.x = index == 1 ? 742 : 692;
                    if (!enough) {
                        this.btn.mouseEnabled = false;
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                        this.btn_label.text = game.Tools.strOfLocalization(4074);
                    } else {
                        // 可上供
                        this.btn.mouseEnabled = true;
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                        this.btn_label.text = game.Tools.strOfLocalization(4050);

                    }
                } else {
                    // this.repeat_count.visible = false;
                    (this.repeat_lock.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(4107, [data.unlock_point.split('-')[1]]);

                    this.lock.visible = false;
                    this.done.visible = false;
                    this.cost.visible = false;
                    this.btn.visible = false;
                    this.repeat_lock.visible = true;
                    this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_d.png');
                }
            } else if (_delta < data.unlock_day) {
                this.lock.visible = true;
                this.done.visible = false;
                this.cost.visible = false;
                this.btn.visible = false;
                this.desc.text = game.Tools.strOfLocalization(4072, [(data.unlock_day - _delta).toString()]);
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_d.png');
            } else if (UI_Activity_Chunjie.tasks && UI_Activity_Chunjie.tasks[data.mission_id]) {
                this.lock.visible = false;
                this.done.visible = true;
                this.cost.visible = false;
                this.btn.visible = false;
                this.desc.text = game.Tools.strOfLocalization(data.mission_str);
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_d.png');
            } else {
                this.lock.visible = false;
                this.done.visible = false;
                this.cost.visible = true;
                this.btn.visible = true;
                this.desc.text = game.Tools.strOfLocalization(data.mission_str);
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_l.png');
                let rewards = data.consume.split(',');
                let enough = true;
                let index = 0;
                for (let i = 0; i < 2; ++i) {
                    let item = this.list_cost[i];
                    if (rewards[i]) {

                        item.me.visible = true;
                        let nums = rewards[i].split('-');
                        let id = Number(nums[0]);
                        let count = Number(nums[1]);
                        item.count.text = nums[1];
                        let item_data = cfg.item_definition.item.get(id);
                        game.LoadMgr.setImgSkin(item.icon, item_data.icon_transparent, null, 'UI_Activity_Chunjie');
                        if (UI_Bag.get_item_count(id) < count) {
                            enough = false;
                            item.count.color = '#fb5e5e';
                        } else {
                            item.count.color = '#ffffff';
                        }
                        ++index;
                    } else {
                        item.me.visible = false;
                    }
                }
                this.cost.x = index == 1 ? 742 : 692;
                if (!enough) {
                    this.btn.mouseEnabled = false;
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                    this.btn_label.text = game.Tools.strOfLocalization(4074);
                } else {
                    let nongshe_data = UI_Activity_Chunjie.getBuildDataByType(5001); // 写死类型
                    let building_data = UI_Activity_Chunjie.getCfgBuildData(nongshe_data.id);
                    let now_farmer_count = UI_Activity_Chunjie.getTotalFarmerCount();
                    if (now_farmer_count < building_data.args[0]) {
                        // 可升级
                        this.btn.mouseEnabled = true;
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                        this.btn_label.text = game.Tools.strOfLocalization(4050);
                    } else {
                        // 农舍不足
                        this.btn.mouseEnabled = false;
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                        this.btn_label.text = game.Tools.strOfLocalization(4075);
                    }
                }
            }
        }

        public onYindaoDone() {
            this.repeat.visible = false;
            this.icon.visible = true;
            this.lock.visible = false;
            this.done.visible = true;
            this.cost.visible = false;
            this.btn.visible = false;
            this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_list_d.png');
        }
    }
    export class UI_Activity_Chunjie_Main extends UIBase {
        public static Inst: UI_Activity_Chunjie_Main = null;

        public static haveRedPoint(): boolean {
            if (!this.Inst) return false;
            if (this.Inst.checkDisplayIdChange()) {
                return true;
            }
            let nongshe_data = UI_Activity_Chunjie.getBuildDataByType(5001); // 写死类型
            let building_data = UI_Activity_Chunjie.getCfgBuildData(nongshe_data.id);
            let now_farmer_count = UI_Activity_Chunjie.getTotalFarmerCount();
            let farmer_limit = now_farmer_count >= building_data.args[0];
         
            let datas = cfg.activity.village_task.getGroup(UI_Activity_Chunjie.activity_id);
            let repeat_unlocked = 0;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            let fruit_type: string = (GameMgr.Inst.account_id % 3).toString();
            for (let data of datas) {
                if (data.fruit_type.indexOf(fruit_type) == -1) continue; // 先排除无法使用任务
                if (data.if_loop) {
                    if (repeat_unlocked == 0) {
                        if (UI_Bag.checkItemEnough(data.unlock_point)) {
                            repeat_unlocked = 1;
                            if (UI_Bag.checkItemEnough(data.consume)) return true;
                        } else {
                            repeat_unlocked = 2;
                        }
                    } else if (repeat_unlocked == 1) {
                        if (UI_Bag.checkItemEnough(data.consume)) return true;
                    }
                } else {
                    if (!farmer_limit && delta >= data.unlock_day && !(UI_Activity_Chunjie.tasks && UI_Activity_Chunjie.tasks[data.mission_id])) {
                        if (UI_Bag.checkItemEnough(data.consume)) return true;
                    }
                }
            }
            return false;
        }

        public btn_close: Laya.Button;
        private root: Laya.Sprite;
        private scrollview: capsui.CScrollView;
        private sort_datas: Array<lqc.Sheet_Activity_VillageTask>;
        private label_tip: Laya.Label;

        private lihui: Laya.Sprite;
        public spine: CatFoodSpine.SpineSprite;
        private chat: UI_Character_Chat;
        private chat_id: number = 0;
        private sound_id: number;

        private display_id: number;
        private last_display_id: number = -1; //上一次使用的id

        // 阶段判断依据
        public stage_requires: Array<number>;
        public item_id: number;


        private bg: Laya.Sprite;
        public locking: boolean;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_miaoUI());
            UI_Activity_Chunjie_Main.Inst = this;
        }

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;


            this.root = this.me.getChildByName('root') as Laya.Sprite;

            this.btn_close = this.root.getChildByName('btn_close') as Laya.Button;
            this.btn_close.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);

            this.stage_requires = [];
            if (!UI_Activity_Chunjie.activity_data) return;
            for (let i = 0; i < 4; ++i) {
                let reward = UI_Activity_Chunjie.activity_data.stage_require[i];
                if (i == 0) {
                    this.item_id = Number(reward.split('-')[0]);
                }
                this.stage_requires.push(Number(reward.split('-')[1]));
            }
            
            this.scrollview = (this.root.getChildByName('task').getChildByName('scrollview') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            
            this.scrollview.init_scrollview(Laya.Handler.create(this, this.render_item, null, false));

            let illust = this.root.getChildByName('illust') as Laya.Sprite;
            this.lihui = illust.getChildByName('image') as Laya.Image;
            this.chat = new UI_Character_Chat(illust.getChildByName('chat') as Laya.Sprite);
            this.chat.close(true);

            this.label_tip = this.root.getChildByName('task').getChildByName('tip') as Laya.Label;
            (illust.getChildByName('click') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.spine) {
                    this.spine.play('click');
                }
                
                if (this.sound_id) {
                    this.stopsay();
                } else {
                    this.say('click');
                }
            });
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_miaoUI).show;
            show_anim.interval = 16.7;

            if (GameMgr.client_language == 'en') {
                (illust.getChildByName('title') as Laya.Sprite).pos(-63, 18);
            }
        }

        public show() {
            Laya.timer.clearAll(this);
            this.enable = true;
            this.locking = true;
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_miaoUI).show;
            show_anim.wrapMode = 0;
            show_anim.play(0, false);
            view.AudioMgr.PlayAudio(10103);
            let item_count = UI_Bag.get_item_count(this.item_id);
            let stage = 0;
            for (let require of this.stage_requires) {
                if (item_count >= require) {
                    ++stage;
                } else {
                    break;
                }
            }
            app.NetAgent.sendReq2Lobby('Lobby', 'taskRequest', { params: [240101] }, (err, res) => {
            });
            if (this.last_display_id < 0 || this.last_display_id == stage) {
                this.setSpine(stage);
                Laya.timer.once(540, this, () => {
                    this.locking = false;
                });
            } else {
                this.setSpine(this.last_display_id, false);
                this.playUpgradeAnim(stage);
            }

            let datas: Array<lqc.Sheet_Activity_VillageTask> = cfg.activity.village_task.getGroup(UI_Activity_Chunjie.activity_id);
            this.sort_datas = [];
            let fruit_type: string = (GameMgr.Inst.account_id % 3).toString();
            let check_show_tip: boolean = false;
            let need_show_tip: boolean = false;
            // 数据排序
            for (let data of datas) {
                if (data.fruit_type.indexOf(fruit_type) == -1) continue; // 先排除无法使用任务
                // 循环任务特殊处理
                this.sort_datas.push(data);
                if (!check_show_tip && data.unlock_point) {
                    check_show_tip = true;
                    need_show_tip = UI_Bag.checkItemEnough(data.unlock_point);
                }
            }
            this.label_tip.visible = need_show_tip;
            this.refreshTip();
            this.sort_datas.sort((a, b) => {
                return this.getSort(a) - this.getSort(b);
            });

            this.scrollview.reset();
            this.scrollview.addItem(this.sort_datas.length);
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            UI_Activity_Chunjie.Inst.locking_refresh = true;
        }

        public resortData() {
            this.sort_datas.sort((a, b) => {
                return this.getSort(a) - this.getSort(b);
            });
        }
        public show_yindao() {
            Laya.timer.clearAll(this);
            this.enable = true;
            this.locking = true;
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_miaoUI).show;
            show_anim.wrapMode = 0;
            show_anim.play(0, false);
            view.AudioMgr.PlayAudio(10103);
            let item_count = UI_Bag.get_item_count(this.item_id);
            let stage = 0;
            for (let require of this.stage_requires) {
                if (item_count >= require) {
                    ++stage;
                } else {
                    break;
                }
            }

            if (this.last_display_id < 0 || this.last_display_id == stage) {
                this.setSpine(stage);
                Laya.timer.once(540, this, () => {
                    this.locking = false;
                });
            } else {
                this.setSpine(this.last_display_id, false);
                this.playUpgradeAnim(stage);
            }

            let datas: Array<lqc.Sheet_Activity_VillageTask> = cfg.activity.village_task.getGroup(UI_Activity_Chunjie.activity_id);
            this.sort_datas = [];
            let fruit_type: string = (GameMgr.Inst.account_id % 3).toString();
            let check_show_tip: boolean = false;
            let need_show_tip: boolean = false;
            // 数据排序
            for (let data of datas) {
                if (data.fruit_type.indexOf(fruit_type) == -1) continue; // 先排除无法使用任务
                // 循环任务特殊处理
                this.sort_datas.push(data);
                if (!check_show_tip && data.unlock_point) {
                    check_show_tip = true;
                    need_show_tip = UI_Bag.checkItemEnough(data.unlock_point);
                }
            }
            this.label_tip.visible = need_show_tip;
            this.refreshTip();
            this.sort_datas.sort((a, b) => {
                return this.getSort(a) - this.getSort(b);
            });
            this.sort_datas.splice(0, 0, null);
            this.scrollview.reset();
            this.scrollview.addItem(this.sort_datas.length);
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            UI_Activity_Chunjie.Inst.locking_refresh = true;
        }

        public close(handler?: Laya.Handler) {
            this.locking = true;
            this.stopsay();
            view.AudioMgr.PlayAudio(10104);
            UI_Activity_Chunjie.Inst.refreshNongShe();
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_miaoUI).show;
            show_anim.wrapMode = 1;
            show_anim.play(show_anim.count, false);
            Laya.timer.once(540, this, () => {
                this.enable = false;
                this.locking = false;
                if (handler) {
                    handler.run();
                }
            });
            this.last_display_id = this.display_id;
            this.display_id = -1;
            UI_Activity_Chunjie.Inst.locking_refresh = false;
            UI_Activity_Chunjie.Inst.onUpgradeClose();
        }



        private setSpine(_display_id: number, need_say: boolean = true) {
            if (!this.enable) return;
            if (this.display_id == _display_id) return;
            this.display_id = _display_id;
            this.last_display_id = _display_id;
            if (this.spine) {
                if (this.spine.parent.parent == this.lihui) {
                    (this.spine.parent as Laya.Sprite).visible = false;
                    this.spine.reset();
                    this.lihui.removeChild(this.spine);

                }
                this.spine = null;
            }
            let important: boolean = false;
            this.spine = CatFoodSpine.SpineMgr.Inst.getSprite(game.Tools.localUISrc('extendRes/spine/NS_240' + _display_id), null, important);
            //添加到舞台
            this.lihui.addChild(this.spine.parent);
            (this.spine.parent as Laya.Sprite).visible = false;
            let id = this.spine.id;
            let setSpine = () => {
                if (!this.spine || id != this.spine.id) return;
                this.spine.pos(100, -140);
                (this.spine.parent as Laya.Sprite).visible = true;
                this.lihui.scaleX = 1;

                this.spine.pX = 0;
                this.spine.pY = 0;

                if (_display_id == 1) {
                    this.spine.offsetX = 640;
                    this.spine.offsetY = 900;
                    this.spine.sx = this.spine.sy = 0.18;
                } else if (_display_id == 2) {
                    this.spine.offsetX = 630;
                    this.spine.offsetY = 580;
                    this.spine.sx = this.spine.sy = 0.19;
                } else if (_display_id == 3) {
                    this.spine.offsetX = 610;
                    this.spine.offsetY = 620;
                    this.spine.sx = this.spine.sy = 0.22;
                } else {
                    this.spine.offsetX = 640;
                    this.spine.offsetY = 610;
                    this.spine.sx = this.spine.sy = 0.195;
                }

                this.spine.play('idle');
                this.stopsay();
                if (need_say) {
                    this.say('greeting');
                }

            }
            if (this.spine.state == CatFoodSpine.ESpineState.loaded) {
                setSpine();
            } else {
                this.spine.once('loadover', this, setSpine);
            }
        }

        public say(type: string) {
            if (this.sound_id) return;
            let _group = cfg.voice.event.getGroup(2);
            if (type == 'click') {
                type = Math.random() < 0.5 ? 'click_1' : 'click_2';
            }
            let _data: lqc.Sheet_Voice_Event = null;
            for (let data of _group) {
                if (data.stage == (this.display_id - 1) && data.type == type) {
                    _data = data;
                    break;
                }
            }
            if (!_data) return;
            this.chat_id++;
            let chat_id = this.chat_id;
            let volume = view.AudioMgr.yuyinVolume * _data.volume_fix;
            if (view.AudioMgr.yuyinMuted) {
                volume = 0;
            }
            this.chat.show(_data['words_' + GameMgr.client_language]);
            this.sound_id = view.AudioMgr.PlaySound(_data.path, volume, Laya.Handler.create(this, () => {
                Laya.timer.once(500, this, () => {
                    if (this.chat_id == chat_id) {
                        this.stopsay();
                    }
                });
            }));
        }

        private stopsay() {
            // this.container_chat.visible = false;
            this.chat.close(false);
            if (this.sound_id) {
                view.AudioMgr.StopAudio(this.sound_id);
                this.sound_id = 0;

            }

        }

        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.sort_datas[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container);
            }
            cache_data['cell'].show(data);

        }


        public onDisable() {
            
            if (this.spine) {
                if (this.spine.parent.parent == this.lihui) {
                    (this.spine.parent as Laya.Sprite).visible = false;
                    this.spine.reset();
                    this.lihui.removeChild(this.spine.parent);
                }
                this.spine = null;
            }
        }

        // 普通已解锁未完成>循环已解锁>普通未解锁>循环未解锁>普通已完成
        private getSort(data: lqc.Sheet_Activity_VillageTask): number {
            let _delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            if (data.if_loop) {
                if (data.unlock_point) {
                    if (!UI_Bag.checkItemEnough(data.unlock_point)) {
                        return data.mission_id + 10000 * 3;
                    }
                }
                return data.mission_id + 10000 * 1;
            } else if (UI_Activity_Chunjie.tasks && UI_Activity_Chunjie.tasks[data.mission_id]) {
                return data.mission_id + 10000 * 4;
            } else if (data.unlock_day <= _delta) {
                return data.mission_id;
            } else {
                return data.mission_id + 10000 * 2;
            }
        }

        public onTaskComplete() {
            this.resortData();
            this.scrollview.wantToRefreshAll();
            this.refreshTip();
            this.stopsay();
            this.say('praise');
            Laya.timer.once(100, this, () => {
                this.resortData();
                this.scrollview.wantToRefreshAll();
                if (this.label_tip.visible) {
                    this.refreshTip();
                } else {
                    let fruit_type: string = (GameMgr.Inst.account_id % 3).toString();
                    let need_show_tip: boolean = false
                    for (let data of this.sort_datas) {
                        if (data.fruit_type.indexOf(fruit_type) == -1) continue; // 先排除无法使用任务
                        if (data.unlock_point && UI_Bag.checkItemEnough(data.unlock_point)) {
                            this.label_tip.visible = true;
                            this.refreshTip();
                            return;
                        }
                    }
                }
            });
        }

        private refreshTip() {
            let count = 0;
            for (let data of this.sort_datas) {
                if (data.if_loop && UI_Activity_Chunjie.tasks[data.mission_id]) {
                    count += Number(data.reward.split('-')[1]) * UI_Activity_Chunjie.tasks[data.mission_id];
                }
            }
            this.label_tip.text = game.Tools.strOfLocalization(4108, [count.toString()]);
        }

        private playUpgradeAnim(stage: number) {
            Laya.timer.once(200, this, () => {
                let effect = game.FrontEffect.Inst.create_ui_effect(this.lihui, 'scene/effect_chunjie_shengji.lh', new Laya.Point(450, 400), 1);
                Laya.timer.once(2000, this, () => {
                    effect.destory();
                    this.locking = false;
                });
            });
            Laya.timer.once(800, this, () => {
                this.setSpine(stage);
            });
        }

        public onTaskRewarded() {
            let item_count = UI_Bag.get_item_count(this.item_id);
            let stage = 0;
            for (let require of this.stage_requires) {
                if (item_count >= require) {
                    ++stage;
                } else {
                    break;
                }
            }

            if (this.last_display_id != stage) {
                Laya.timer.once(540, this, () => {
                    this.locking = false;
                });
                this.playUpgradeAnim(stage);
            }
        }

        public checkDisplayIdChange(): boolean {
            let stage = 0;
            let item_count = UI_Bag.get_item_count(this.item_id);
            for (let require of this.stage_requires) {
                if (item_count >= require) {
                    ++stage;
                } else {
                    break;
                }
            }

            if (this.last_display_id < 0) { // 如果没生成过last_id，则算一下
                this.last_display_id = stage;
            }
            return stage != this.last_display_id;
        }

        public onYindaoTaskDone() {
            this.stopsay();
            this.say('praise');
            this.scrollview.items[0].cache_data['cell'].onYindaoDone();
        }
    }
}