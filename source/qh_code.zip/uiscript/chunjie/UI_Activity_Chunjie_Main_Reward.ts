module uiscript {
    export class UI_Activity_Chunjie_Main_Reward extends UIBase {
        public static Inst: UI_Activity_Chunjie_Main_Reward = null;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_main_rewardUI());
            UI_Activity_Chunjie_Main_Reward.Inst = this;
        }

        private root: Laya.Sprite;
        private handler: Laya.Handler;
        private locking: boolean;
        
        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_main_rewardUI).show;
            show_anim.interval = 16.7;
            
            if (GameMgr.client_language == 'chs_t') {
                (this.root.getChildAt(1) as Laya.Label).text = '';
            } else {
                (this.root.getChildAt(1).getChildByName('image') as Laya.Sprite).visible = false;
            }
        }

        public show(handler: Laya.Handler) {
            view.AudioMgr.PlayAudio(10109);
            this.handler = handler;
            this.enable = true;
            this.locking = true;
            Laya.timer.once(600, this, ()=>{
                this.locking = false;
            });
            this.root.alpha = 1;
            (this.me as ui.lobby.chunjie.activity_chunjie_main_rewardUI).show.play(0, false);
        }

        private close() {
            this.locking = true;
            UIBase.anim_alpha_out(this.root, {}, 200, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
                if (this.handler) {
                    this.handler.run();
                    this.handler = null;
                }
            }));
        }
    }
}