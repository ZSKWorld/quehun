module uiscript {
    export class UI_Activity_Chunjie_Next extends UIBase {
        public static Inst: UI_Activity_Chunjie_Next = null;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_nextUI());
            UI_Activity_Chunjie_Next.Inst = this;
        }

        private skin: Laya.Image;
        private btn: Laya.Button;
        private audio_id: number;
        private locking: boolean;
        private handler: Laya.Handler;
        
        public onCreate() {
            this.skin = this.me.getChildByName('skin').getChildByName('skin') as Laya.Image;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            // this.btn.clickHandler = new Laya.Handler(this, ()=>{
            //     if (this.locking) return;
            //     this.skip();
            // });
        }

        public show(handler?: Laya.Handler) {
            this.handler = handler;
            // this.locking = true;
            // Laya.timer.once(500, this, ()=>{
            //     this.locking = false;
            // });
            this.audio_id = view.AudioMgr.PlayAudio(10117);
            this.enable = true;
            (this.me as ui.lobby.chunjie.activity_chunjie_nextUI).ani1.play(0, false);
            Laya.timer.once(2100, this, ()=>{
                this.enable = false;
            });
            Laya.timer.once(1200, this, ()=>{
                if (this.handler) {
                    this.handler.run();
                    this.handler = null;
                }
            });
            let stage = 0;
            for (let i = 0; i < 4; ++i) {
                let reward = UI_Activity_Chunjie.activity_data.stage_require[i];
                if (!UI_Bag.checkItemEnough(reward)) {
                    break;
                }
                stage = i;
            }
            game.LoadMgr.setImgSkin(this.skin, 'myres/activity_24chunjie/scene/' + (stage + 1) + '.png', null, 'UI_Activity_Chunjie');
        }


        private skip() {
            view.AudioMgr.StopAudio(this.audio_id, 0);
            this.enable = false;
            (this.me as ui.lobby.chunjie.activity_chunjie_nextUI).ani1.stop();
            Laya.timer.clearAll(this);
            if (this.handler) {
                this.handler.run();
                this.handler = null;
            }
        }
    }
}