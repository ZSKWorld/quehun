module uiscript {
    class TaskCell {
        public me: Laya.Sprite;
        
        private bg: Laya.Image;
        private item_icon: Laya.Image;
        private item_count: Laya.Label;

        private unlock: Laya.Sprite;
        private desc: Laya.Label;
        private btn_get: Laya.Button;
        private btn_image: Laya.Image;
        private getted: Laya.Image;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;

        private origin_rect: UIRect;
        //private reward_count: number = 0;
        private father: UI_Activity_Chunjie_Reward;

        public constructor(me: Laya.Sprite, father: UI_Activity_Chunjie_Reward) {
            this.me = me;
            this.father = father;
            this.bg = this.me.getChildAt(0) as Laya.Image;
            this.item_icon = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.origin_rect = UIRect.CreateFromSprite(this.item_icon);
            this.item_count = this.me.getChildByName('item').getChildByName('count') as Laya.Label;

            this.desc = this.me.getChildByName('desc') as Laya.Label;

            this.unlock = this.me.getChildByName('unlock') as Laya.Sprite;
            this.progress_bar = this.unlock.getChildByName('bar').getChildByName('bar') as Laya.Sprite;
            this.progress_label = this.unlock.getChildByName('progress') as Laya.Label;
            this.btn_get = this.unlock.getChildByName('btn') as Laya.Button;
            this.btn_image = this.btn_get.getChildByName('image') as Laya.Image;
            this.getted = this.unlock.getChildByName('done') as Laya.Image;


            (this.me.getChildByName('item').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);

            this.btn_get.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Chunjie_Reward.Inst.locking) return;
                UI_Activity_Chunjie_Reward.Inst.locking = true;
                let _id = this.id;
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: _id}, (err, res) => {
                    UI_Activity_Chunjie_Reward.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        let d_activity_task = cfg.activity.period_task.get(_id);
                        let items = [];
                        let rewards = d_activity_task.reward.split('-');
                        items.push({id: Number(rewards[0]), count: Number(rewards[1])});
                        game.Tools.showRewards({ rewards: items }, null);
                        if (this.id == _id) {
                            this.btn_get.visible = false;
                            this.getted.visible = true;
                            let d_activity_task = cfg.activity.period_task.get(this.id);
                            this.bg.skin = game.Tools.localUISrc(d_activity_task.node_mark ? 'myres/activity_24chunjie/bg_task_sp_d.png' : 'myres/activity_24chunjie/bg_task_d.png');
                        }
                        
                        this.father.task_rewarded(_id);
                        UI_Activity.onPeriodTaskRewarded(_id);
                        this.father.refreshReceiveBtn();
                    }
                });
            });
        }

        public show(info: any) {
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            let reward = d_activity_task.reward.split('-');
            this.item_id = parseInt(reward[0]);
            this.item_count.text = reward[1];
            game.Tools.setItemIcon(this.item_icon, this.origin_rect, this.item_id, 'UI_Activity_Chunjie', true);
            if (d_activity_task.reward_limit_day > delta) {
                this.bg.skin = game.Tools.localUISrc(d_activity_task.node_mark ? 'myres/activity_24chunjie/bg_task_sp_d.png' : 'myres/activity_24chunjie/bg_task_d.png');
                this.unlock.visible = false;
                this.desc.text = game.Tools.strOfLocalization(4130, [game.Tools.strOfLocalization(4130 + d_activity_task.reward_limit_day)]);
            } else {
                this.unlock.visible = true;
                this.desc.text = d_task_info['desc_' + GameMgr.client_language];
                
                let counter: number = info.counter;
                if (!counter) counter = 0;
            
                this.progress_bar.mask.width = Math.min(1, counter / d_task_info.target) * 300;
                this.progress_label.text = Math.min(counter, d_task_info.target) + '/' + d_task_info.target;
        

                this.getted.visible = false;
                this.btn_get.visible = false;
                this.btn_get.mouseEnabled = true;
                if (info.rewarded) {
                    this.getted.visible = true;
                    this.btn_get.visible = false;
                    this.bg.skin = game.Tools.localUISrc(d_activity_task.node_mark ? 'myres/activity_24chunjie/bg_task_sp_d.png' : 'myres/activity_24chunjie/bg_task_d.png');
                }
                else {
                    this.bg.skin = game.Tools.localUISrc(d_activity_task.node_mark ? 'myres/activity_24chunjie/bg_task_sp.png' : 'myres/activity_24chunjie/bg_task_l.png');
                    this.btn_get.visible = true;
                    this.getted.visible = false;
                    if (info.achieved) {
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                    }
                    else {
                        this.btn_get.mouseEnabled = false;
                        this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                    }
                }

            }
        }

    }
    export class UI_Activity_Chunjie_Reward extends UIBase {
        public static activity_id: number = 240103;
        public static Inst: UI_Activity_Chunjie_Reward = null;

        public static haveRedPoint(): boolean {
            
            let datas = UI_Activity.getPeriodTaskList(UI_Activity_Chunjie_Reward.activity_id);
            if (datas) {
                let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie_Reward.activity_id);
                for (let data of datas) {
                    if (data['achieved'] && !data['rewarded']) {
                        let d_task = cfg.activity.period_task.get(data['id']);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        private root: Laya.Sprite;
        private bg: Laya.Sprite;

        private scrollview: capsui.CScrollView;
        private empty: Laya.Sprite;

        public locking: boolean;

        private btn_receive_all: Laya.Button;
        private img_receive_all: Laya.Image;
        private tab_index: number;
        private list_tab: Array<{img: Laya.Image, label: Laya.Label}>;

        private all_data_lst: Array<Object> = [];
        private show_data_lst: Array<Object> = [];
       

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_rewardUI());
            UI_Activity_Chunjie_Reward.Inst = this;
        }

        public onCreate() {
            (this.me.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            
            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            
            let tabs = this.root.getChildByName('tabs') as Laya.Sprite;
            (tabs.getChildByName('btn_0') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(0);
            });
            (tabs.getChildByName('btn_1') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(1);
            });
            (tabs.getChildByName('btn_2') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(2);
            });
            this.list_tab = [];
            this.list_tab.push({img: tabs.getChildByName('btn_0').getChildByName('bg') as Laya.Image, label: tabs.getChildByName('btn_0').getChildAt(1) as Laya.Label});
            this.list_tab.push({img: tabs.getChildByName('btn_1').getChildByName('bg') as Laya.Image, label: tabs.getChildByName('btn_1').getChildAt(1) as Laya.Label});
            this.list_tab.push({img: tabs.getChildByName('btn_2').getChildByName('bg') as Laya.Image, label: tabs.getChildByName('btn_2').getChildAt(1) as Laya.Label});

            this.scrollview = (this.root.getChildByName('scrollview') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));

            this.empty = this.root.getChildByName('empty') as Laya.Sprite;
            
            this.btn_receive_all = this.root.getChildByName('btn_receive_all') as Laya.Button;
            this.img_receive_all = this.btn_receive_all.getChildAt(0) as Laya.Image;
            this.btn_receive_all.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.onReceiveAllBtnClick();
            });
        }


        public onShow() {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Chunjie_Reward.activity_id);
            this.all_data_lst = lst;
            this.refreshReceiveBtn();
            this.tab_index = -1;
            this.on_tab_btn_click(0);
        }

        public show() {
            view.AudioMgr.PlayAudio(10115);
            Laya.timer.clearAll(this);  
            this.enable = true;
            this.locking = true;
            this.me.alpha = 1;
            this.me.x = 0;
            UIBase.anim_alpha_in(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            this.onShow();
        }

        public close() {
            this.locking = true;
            UI_Activity_Chunjie.Inst.refreshRedpoint();
            UIBase.anim_alpha_out(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
            
        }


        public task_rewarded(task_id: number) {
            for (let task of this.all_data_lst) {
                if (task['id'] == task_id) {
                    task['rewarded'] = true;
                    return;
                }
            }
        }

        private on_tab_btn_click(tab_index: number) {
            if (tab_index == this.tab_index) {
                return;
            }
            this.tab_index = tab_index;
            
            for (let i = 0; i < 3; i++) {
                this.list_tab[i].img.skin = game.Tools.localUISrc(tab_index == i ? 'myres/activity_24chunjie/tab_l.png' : 'myres/activity_24chunjie/tab_d.png');
                this.list_tab[i].label.color = tab_index == i ? '#ffffff' : '#9f8d8a';
            }
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            switch (tab_index) {
                case 0: // 全部
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        this.show_data_lst.push(data);
                    }
                    this.show_data_lst.sort((a,b)=>{
                        return this.getSort(a) - this.getSort(b);
                    })
                    break;
                case 1: // 未完成
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        if (!data['rewarded'] && !data['achieved']) {
                            let cfgData = cfg.activity.period_task.get(data['id']);
                            if (cfgData.reward_limit_day <= delta) this.show_data_lst.push(data);
                        }
                    }
                    break;
                case 2: // 已完成
                    this.show_data_lst = [];
                    let index = 0;
                    for (let data of this.all_data_lst) {
                        let cfgData = cfg.activity.period_task.get(data['id']);
                        if (cfgData.reward_limit_day > delta) {

                        } else if (!data['rewarded'] && data['achieved']) {
                            this.show_data_lst.splice(index++, 0, data);
                        } else if (data['rewarded']) {
                            this.show_data_lst.push(data);
                        }
                    }
                    break;

            }
            this.empty.visible = this.show_data_lst.length == 0;
            this.scrollview.reset();
            this.scrollview.addItem(this.show_data_lst.length);
           
            
        }

        // 获得对应数据排序值
        private getSort(data: Object): number {
            let _sort = 0;
            
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            let cfgData = cfg.activity.period_task.get(data['id']);
            if (cfgData.reward_limit_day <= delta) {
                if (data['achieved'] && !data['rewarded']) {
                    _sort =  0;
                } else if (data['rewarded']) {
                    _sort =  2;
                } else {
                    _sort = 1;
                }
            } else {
                _sort = 3;
            }
            return _sort * 1000 + data['id'] % 1000;
        }


        //刷新一键领取状态
        public refreshReceiveBtn() {
            let _can_receive = false;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            for (let data of this.all_data_lst) {
                let cfgData = cfg.activity.period_task.get(data['id']);
                if (cfgData && cfgData.reward_limit_day > delta) {
                    continue;
                }
                if (data['achieved'] && !data['rewarded']) {
                    _can_receive = true;
                    break;
                }
            }
            this.btn_receive_all.mouseEnabled = _can_receive;
            this.img_receive_all.skin = game.Tools.localUISrc(_can_receive ? 'myres/activity_24chunjie/btn_l.png' : 'myres/activity_24chunjie/btn_d.png');
           
        }

        private onReceiveAllBtnClick() {
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Chunjie.activity_id);
            
            let list: Array<number> = [];
            for (let data of this.all_data_lst) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        list.push(data['id']);
                    }
                        
                }
            }
            if (list.length == 0) return;
            this.locking = true;
            
            app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTaskBatch', { task_list: list }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    
                    UIMgr.Inst.showNetReqError('completePeriodActivityTaskBatch', err, res);
                } else {
                    let lst = [];
                    for (let id of list) {
                        
                        this.task_rewarded(id);
                        let _data = cfg.activity.period_task.get(id);
                        if (!_data || !_data.reward) continue;
                        let _reward = _data.reward.split('-');
                        let reward_id = Number(_reward[0]);
                        let reward_count = Number(_reward[1]);
                        lst.push({ id: reward_id, count: reward_count });
                    }
                    
                    this.btn_receive_all.mouseEnabled = false;
                    this.img_receive_all.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
           
                    this.scrollview.wantToRefreshAll();
                    

                    game.Tools.showRewards({ rewards: lst }, null, null);
                }
            })
        }

        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.show_data_lst[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container, this);
            }
            cache_data['cell'].show(data);

        }
    }

    
}