module uiscript {
    export class UI_Activity_Chunjie_Rule extends UIBase {
        public static Inst: UI_Activity_Chunjie_Rule = null;

        private root: Laya.Sprite;
        private btn_left: Laya.Button;
        private btn_right: Laya.Button;
        private tip_pages: Array<Laya.Image>;
        private image: Laya.Image;
        private page_id: number;
        private locking: boolean;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_ruleUI());
            UI_Activity_Chunjie_Rule.Inst = this;
        }

        public onCreate() {
            (this.me.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.btn_left = this.root.getChildByName('btn_left') as Laya.Button;
            this.btn_right = this.root.getChildByName('btn_right') as Laya.Button;
            this.btn_left.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.onPageChange(this.page_id - 1);
            });
            this.btn_right.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.onPageChange(this.page_id + 1);
            });

            this.image = this.root.getChildByName('img') as Laya.Image;
            this.tip_pages = [];
            for (let i = 0; i < 3; ++i) {
                this.tip_pages.push(this.root.getChildByName('pages').getChildAt(i) as Laya.Image);
            }
        }

        // 4位1001 3003数字
        public show() {
            view.AudioMgr.PlayAudio(10115);
            this.enable = true;
            this.locking = true;
            this.page_id = -1;
            this.onPageChange(0);
            this.me.alpha = 1;
            this.me.x = 0;
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            UIBase.anim_alpha_in(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
         
        }

        public close() {
            this.locking = true;
            UIBase.anim_alpha_out(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
                UI_Info_Big.Inst.show(game.Tools.strOfLocalization(4109));
            }));
        }

        private onPageChange(page_id: number) {
            if (page_id < 0 || page_id > 2) return;
            if (page_id == this.page_id) return;
            this.image.skin = game.Tools.localUISrc('myres/activity_24chunjie_yindao/' + (page_id + 1) + '.png');
            for (let i = 0; i < 3; ++i) {
                this.tip_pages[i].skin = game.Tools.localUISrc(page_id == i ? 'myres/activity_24chunjie_yindao/choice_l.png' : 'myres/activity_24chunjie_yindao/choice_d.png');
            }
            this.btn_left.visible = page_id != 0;
            this.btn_right.visible = page_id != 2;
            this.page_id = page_id;
        }

        public onDisable() {
            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_24chunjie_yindao.atlas'));
        }
    }
}