module uiscript {
    class TaskCell {
        public me: Laya.Sprite;
        private bg: Laya.Image;
        private item_icon: Laya.Image;
        private item_count: Laya.Label;
        private desc: Laya.Label;
        private btn_get: Laya.Button;
        private btn_image: Laya.Image;
        private getted: Laya.Image;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.bg = this.me.getChildByName('bg') as Laya.Image;
            this.desc = this.me.getChildByName('desc') as Laya.Label;
          
            this.item_icon = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.item_count = this.me.getChildByName('item').getChildByName('count') as Laya.Label;
            this.progress_bar = this.me.getChildByName('bar').getChildByName('bar') as Laya.Sprite;
            this.progress_label = this.me.getChildByName('progress') as Laya.Label;
            this.btn_get = this.me.getChildByName('btn') as Laya.Button;
            this.btn_image = this.btn_get.getChildByName('image') as Laya.Image;
            this.getted = this.me.getChildByName('done') as Laya.Image;
            (this.me.getChildByName('item').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);

            this.btn_get.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Chunjie_Task.Inst.locking) return;
                UI_Activity_Chunjie_Task.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'completeActivityTask', { task_id: this.id }, (err, res) => {
                    UI_Activity_Chunjie_Task.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completeActivityTask', err, res);
                    } else {
                        let d_activity_task = cfg.activity.task.get(this.id);
                        let items = [];
                        items.push({id: d_activity_task.reward_id, count: d_activity_task.reward_count});
                        game.Tools.showRewards({ rewards: items }, Laya.Handler.create(this, ()=>{
                            UI_Activity_Chunjie.Inst.refreshAll();
                        }));
                        this.btn_get.visible = false;
                        this.getted.visible = true;
                        this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_d.png');
                        UI_Activity.onTaskRewarded(this.id);
                    }
                });
            });
        }

        public show(info: any) {
            this.me.visible = true;
            if (!info) {
                this.me.visible = false;
                return;
            }
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
      
            this.desc.text = d_task_info['desc_' + GameMgr.client_language];
            
            this.item_id = d_activity_task.reward_id;
            let d_view = game.GameUtility.get_item_view(this.item_id);
            game.LoadMgr.setImgSkin(this.item_icon, d_view.icon, null, 'UI_Activity_Chunjie');
            this.item_count.text = d_activity_task.reward_count.toString();
            let counter: number = info.counter;
            if (!counter) counter = 0;
           
            this.progress_bar.mask.width = Math.min(1, counter / d_task_info.target) * 300;
            this.progress_label.text = Math.min(counter, d_task_info.target) + '/' + d_task_info.target;
       

            this.getted.visible = false;
            this.btn_get.visible = false;
            
            if (info.rewarded) {
                this.getted.visible = true;
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_d.png');
            }
            else {
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_l.png');
                this.btn_get.visible = true;
                if (info.achieved) {
                    this.btn_get.mouseEnabled = true;
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                }
                else {
                    this.btn_get.mouseEnabled = false;
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                }
            }

        }

    }
    export class UI_Activity_Chunjie_Task extends UIBase {
        public static activity_id: number = 240102;
        public static Inst: UI_Activity_Chunjie_Task = null;

        public static haveRedPoint(): boolean {
            let datas = UI_Activity.getTaskList(UI_Activity_Chunjie_Task.activity_id);
            if (datas) {
                for (let data of datas) {
                    if (data['achieved'] && !data['rewarded']) return true;
                }
            }

            return false;
        }

        public btn_close: Laya.Button;
        private templetes: Array<TaskCell> = [];
        private root: Laya.Sprite;
        private label_daily_count: Laya.Label;
        public locking: boolean;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_taskUI());
            UI_Activity_Chunjie_Task.Inst = this;
        }

        public onCreate() {
            (this.me.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            this.root = this.me.getChildByName('root') as Laya.Sprite;
           
            this.btn_close = this.me.getChildByName('btn_close') as Laya.Button;
            this.btn_close.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            
            for (let i = 0; i < 3; i++) {
                this.templetes.push(new TaskCell(this.root.getChildByName('item_' + i) as Laya.Sprite));
            }

            let daily = this.root.getChildByName('daily_task') as Laya.Sprite;
            (daily.getChildByName('tip') as Laya.Label).text = game.Tools.strOfLocalization(4121, [cfg.activity.game_task.get(24010401).reward_count.toString()]);
            this.label_daily_count = daily.getChildByName('count') as Laya.Label;
        }


        public onShow() {
            let datas = UI_Activity.getTaskList(UI_Activity_Chunjie_Task.activity_id);
            for (let i = 0; i < 3; i++) {
                this.templetes[i].show(datas[i]);
            }
            let limit_item_id: number = 30900007;
            let limit_id: number = 10014;

            let limit_datas = cfg.item_definition.source_limit.getGroup(limit_id);
            let limit_count = 0;
            
            for (let data of limit_datas) {
                if (data.item_id == limit_item_id) {
                    limit_count = data.item_limit;
                    break;
                }
            }
            this.label_daily_count.text = game.Tools.strOfLocalization(4122, [UI_Bag.get_item_daily_record(limit_id, limit_item_id).toString(), limit_count.toString()]);
        }

        public show() {
            view.AudioMgr.PlayAudio(10115);
            Laya.timer.clearAll(this);  
            this.enable = true;
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            this.locking = true;
            
            this.me.alpha = 1;
            this.me.x = 0;
            UIBase.anim_alpha_in(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            // UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
            //     this.locking = false;
            // }))
            this.onShow();
        }

        public close() {
            this.locking = true;
          
            UIBase.anim_alpha_out(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
            }));
        }


        public onDisable(): void {
            Laya.timer.clearAll(this);    
        }
    }
}