module uiscript {
    interface iFriendInfo {
        account_id: number;
        info?: game.iFriendInfo;
        level: number;
        trip?: iTripData;
    }
    class TripCell {
        public me: Laya.Sprite;
        private bg: Laya.Image;

        private btn: Laya.Button;
        private btn_image: Laya.Image;
        private btn_worker: Laya.Image;

        private player: Laya.Sprite;
        private head: UI_Head;
        private npc_head: Laya.Image;
        private npc_tag: Laya.Image;
        private title: UI_PlayerTitle;
        private label_level: Laya.Label;
        private icon_dest: Laya.Image;
        private name: Laya.Sprite;

        private add: Laya.Sprite;
        private icon_add: Laya.Image;
        private label_add: Laya.Label;
        private cost: Laya.Sprite;
        private icon_cost: Laya.Image;
        private label_cost: Laya.Label;

        private doing: Laya.Sprite;
        private icon_doing: Laya.Sprite;//适配用
        private label_left_round: Laya.Label;

        private done: Laya.Sprite;

        private anim: Laya.Sprite;
        private ship: Laya.Sprite;
        private bg_anim: Laya.Sprite;
        private animing: boolean;

        private info: iFriendInfo;
        private reward: { id: number, count: number };

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.bg = this.me.getChildByName('bg') as Laya.Image;

            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.btn.clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie_Trip.Inst.locking) return;
              
                UI_Activity_Chunjie_Trip.Inst.locking = true;
                UI_Activity_Chunjie_Trip.Inst.setScrollViewEnable(false);
                app.NetAgent.sendReq2Lobby('Lobby', 'startVillageTrip', {
                    dest: this.info.account_id, activity_id: UI_Activity_Chunjie.activity_id
                }, (err, res) => {

                    if (err || res['error']) {
                        UI_Activity_Chunjie_Trip.Inst.locking = false;
                        UI_Activity_Chunjie_Trip.Inst.setScrollViewEnable(true);
                        UIMgr.Inst.showNetReqError('startVillageTrip', err, res);
                    } else {

                        this.playAnim();
                        let have_notify = false;
                        if (UI_Activity_Chunjie.trip) {
                            for (let i = 0; i < UI_Activity_Chunjie.trip.length; ++i) {
                                if (UI_Activity_Chunjie.trip[i].dest_id == res['dest_id']) {
                                    have_notify = true;
                                    break;
                                }
                            }
                        }

                        UI_Activity_Chunjie_Trip.Inst.refresh();
                        if (!have_notify) {
                            // 如果notify没下来，过一会再刷一下
                            Laya.timer.once(150, this, () => {
                                UI_Activity_Chunjie.Inst.refreshTrip(true);
                                UI_Activity_Chunjie_Trip.Inst.refresh();
                            });
                        } else {
                            UI_Activity_Chunjie.Inst.refreshTrip(true);
                        }


                    }
                });
            });
            this.btn_image = this.btn.getChildByName('image') as Laya.Image;
            this.btn_worker = this.btn.getChildAt(1) as Laya.Image;

            this.player = this.me.getChildByName('player') as Laya.Sprite;
            this.title = new UI_PlayerTitle(this.player.getChildByName('title') as Laya.Image, 'UI_Activity_Chunjie');
            this.head = new UI_Head(this.player.getChildByName('head') as Laya.Sprite, 'UI_Activity_Chunjie');
            (this.player.getChildByName('head').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Chunjie_Trip.Inst.locking) return;
                if (!this.info || this.info.account_id < 10) return;
                UI_PlayerInfo.Inst.show({
                    accountId: this.info.account_id
                });
            })
            this.npc_head = this.player.getChildByName('head').getChildByName('npc_head') as Laya.Image;
            this.npc_tag = this.player.getChildByName('head').getChildByName('npc') as Laya.Image;
            this.label_level = this.player.getChildByName('level').getChildByName('level') as Laya.Label;
            this.icon_dest = this.player.getChildByName('level').getChildByName('icon') as Laya.Image;
            this.name = this.player.getChildByName('name') as Laya.Sprite;

            this.add = this.me.getChildByName('add') as Laya.Sprite;
            this.cost = this.me.getChildByName('cost') as Laya.Sprite;
            this.icon_add = this.add.getChildByName('icon') as Laya.Image;
            this.label_add = this.add.getChildByName('count') as Laya.Label;
            this.icon_cost = this.cost.getChildByName('icon') as Laya.Image;
            this.label_cost = this.cost.getChildByName('count') as Laya.Label;

            this.doing = this.me.getChildByName('doing') as Laya.Sprite;
            this.icon_doing = this.doing.getChildByName('icon') as Laya.Image;
            this.label_left_round = this.doing.getChildByName('left_time') as Laya.Label;
            

            this.done = this.me.getChildByName('done') as Laya.Sprite;
            (this.done.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (UI_Activity_Chunjie_Trip.Inst.locking) return;
                UI_Activity_Chunjie_Trip.Inst.locking = true;
                let dest_id = this.info.account_id;
                let trip_data = UI_Activity_Chunjie.getTripDataByDestId(dest_id);
                if (!trip_data) return;
                app.NetAgent.sendReq2Lobby('Lobby', 'receiveVillageTripReward', {
                    dest_id: dest_id, rewards: [this.reward], activity_id: UI_Activity_Chunjie.activity_id
                }, (err, res) => {
                    UI_Activity_Chunjie_Trip.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('receiveVillageTripReward', err, res);
                    } else {
                        for (let i = 0; i < UI_Activity_Chunjie.trip.length; ++i) {
                            if (UI_Activity_Chunjie.trip[i].dest_id == dest_id) {
                                UI_Activity_Chunjie.trip.splice(i, 1);
                                break;
                            }
                        }
                        game.Tools.showRewards({ rewards: [this.reward] }, null);// 临时展示一下,要改为动画
                        UI_Activity_Chunjie_Trip.Inst.onTripRewardRecieved(dest_id);
                        UI_Activity_Chunjie.Inst.refreshTrip();
                        Laya.timer.once(100, this, () => {
                            UI_Activity_Chunjie_Trip.Inst.refresh();
                            UI_Activity_Chunjie.Inst.refreshNongShe();
                        })
                    }
                })
            });

            // 动画部分
            this.anim = this.me.getChildByName('anim') as Laya.Sprite;
            this.ship = this.anim.getChildByName('ship') as Laya.Sprite;
            this.bg_anim = (this.anim.getChildByName('bg') as Laya.Sprite).mask;
        }

        public show(info: iFriendInfo) {
            if (this.info == info && this.animing) return;
            this.reset();
            this.anim.visible = false;
            // 固定部分在该处显示，其他需要动态更新部分丢到refresh内
            if (info.account_id < 100) {
                this.title.me.visible = false;
                this.name.y = 87;
                this.head.set_head_frame(0, 0);
                (this.player.getChildByName('head').getChildByName('head') as Laya.Sprite).visible = false;
                this.npc_head.visible = true;
                this.npc_tag.visible = true;
                game.Tools.SetNickname(this.name, { account_id: info.account_id, nickname: game.Tools.strOfLocalization(4047 + info.account_id) });
            } else if (!info.info) {
                this.title.me.visible = true;
                this.name.y = 117;
                if (info.trip.info) {
                    this.title.id = info.trip.info.title;
                    this.head.id = info.trip.info.avatar;
                    this.head.set_head_frame(info.account_id, info.trip.info.avatar_frame);
                    (this.player.getChildByName('head').getChildByName('head') as Laya.Sprite).visible = true;
                    this.npc_head.visible = false;
                    this.npc_tag.visible = false;
                    game.Tools.SetNickname(this.name, {nickname: info.trip.info.nickname, account_id: info.account_id, verified: info.trip.info.verified}, GameMgr.Inst.hide_nickname);
                }
                
            } else {
                this.title.me.visible = true;
                this.name.y = 117;
                this.title.id = info.info.base.title;
                this.head.id = info.info.base.avatar_id;
                this.head.set_head_frame(info.account_id, info.info.base.avatar_frame);
                (this.player.getChildByName('head').getChildByName('head') as Laya.Sprite).visible = true;
                this.npc_head.visible = false;
                this.npc_tag.visible = false;
                game.Tools.SetNickname(this.name, info.info.base, GameMgr.Inst.hide_nickname);
            }
            let cost_data = cfg.item_definition.item.get(UI_Activity_Chunjie.activity_data.food_item_id);
            game.LoadMgr.setImgSkin(this.icon_cost, cost_data.icon_transparent, null, 'UI_Activity_Chunjie');
            this.label_cost.text = '-' + UI_Activity_Chunjie.activity_data.trip_consume;

            let reward: Array<string> = UI_Activity_Chunjie.activity_data.trip_reward[info.account_id % 3].split('-');
            let id: number = Number(reward[0]);

            let add_data = cfg.item_definition.item.get(id);
            game.LoadMgr.setImgSkin(this.icon_add, add_data.icon_transparent, null, 'UI_Activity_Chunjie');


            game.LoadMgr.setImgSkin(this.icon_dest, add_data.icon_transparent, null, 'UI_Activity_Chunjie');
            this.info = info;
            this.refresh();

        }

        private refresh() {
            let reward: Array<string> = UI_Activity_Chunjie.activity_data.trip_reward[this.info.account_id % 3].split('-');
            let count: number = Number(reward[1]) * (this.info.level + 1);
            this.label_cost.color = '#ffffff';
            let trip_data = UI_Activity_Chunjie.getTripDataByDestId(this.info.account_id);
            if (trip_data) {
                
                this.label_level.text = game.Tools.strOfLocalization(4053) + trip_data.level;
                if ((trip_data.reward && trip_data.reward[0])) {
                    count = trip_data.reward[0].count;
                    // 已完成
                    this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_sp.png');
                    this.cost.visible = false;
                    this.add.visible = true;
                    this.add.y = 94;
                    this.done.visible = true;
                    this.doing.visible = false;
                    this.btn.visible = false;
                } else {
                    count = Number(reward[1]) * (trip_data.level + 1);
                    this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_d.png');
                    // 进行中
                    this.cost.visible = true;
                    this.add.visible = true;
                    this.add.y = 35;
                    this.done.visible = false;
                    this.doing.visible = true;
                    this.btn.visible = false;
                    this.refreshRound();
                }
            } else {
                this.label_level.text = game.Tools.strOfLocalization(4053) + this.info.level;
                this.bg.skin = game.Tools.localUISrc('myres/activity_24chunjie/bg_task_l.png');
                let _trip_count = UI_Activity_Chunjie.trip ? UI_Activity_Chunjie.trip.length : 0;
                let _farmer_count = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id);
                if (UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.food_item_id) < UI_Activity_Chunjie.activity_data.trip_consume) {
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                    this.btn_worker.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_6.png');
                    this.btn.mouseEnabled = false;
                    this.label_cost.color = '#fb5e5e';
                } else if (_trip_count == 3) {
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                    this.btn_worker.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_6.png');
                    this.btn.mouseEnabled = false;
                } else if (_farmer_count == 0) {
                    this.btn_worker.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_6.png');
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_d.png');
                    this.btn.mouseEnabled = false;
                } else {
                    this.btn_worker.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                    this.btn_image.skin = game.Tools.localUISrc('myres/activity_24chunjie/btn_l.png');
                    this.btn.mouseEnabled = true;
                }
                this.cost.visible = true;
                this.add.visible = true;
                this.add.y = 35;
                this.done.visible = false;
                this.doing.visible = false;
                this.btn.visible = true;
            }
            this.label_add.text = '+' + count;
            this.reward = { id: Number(reward[0]), count: count };
        }

        private refreshRound() {
            let trip_data = UI_Activity_Chunjie.getTripDataByDestId(this.info.account_id);
            if (!trip_data) {
                this.reset();
                this.refresh();
                return;
            }
            let round = UI_Activity_Chunjie.activity_data.trip_round - (UI_Activity_Chunjie.round - trip_data.start_round);

            this.label_left_round.text = game.Tools.strOfLocalization(4129, [round.toString()]);
            if (GameMgr.client_language == 'en') {
                this.label_left_round.valign = 'top';
                this.label_left_round.pivotY = 0;
                this.label_left_round.y = 59;
            }
            let width = this.label_left_round.textField.textWidth * this.label_left_round.scaleX;
           
            this.label_left_round.x = 157 - (width + 35) / 2;
            this.icon_doing.x = this.label_left_round.x - 35;
        }

        public reset() {
            Laya.timer.clearAll(this);
        }

        // 播放出发动画
        private playAnim() {
            view.AudioMgr.PlayAudio(10114); //探险出发音效
            this.animing = true;
            this.anim.visible = true;
            this.bg_anim.alpha = 0;
            this.ship.alpha = 0;
            this.bg_anim.x = 1011;
            this.ship.x = 868;
            Laya.Tween.to(this.ship, { alpha: 1 }, 166);
            Laya.Tween.to(this.ship, { x: 535 }, 580, Laya.Ease.quadIn, Laya.Handler.create(this, () => {
                Laya.Tween.to(this.ship, { x: -236 }, 420);
            }));
            Laya.Tween.to(this.ship, { alpha: 0 }, 84, null, null, 916);

            Laya.Tween.to(this.bg_anim, { alpha: 1 }, 166);
            Laya.Tween.to(this.bg_anim, { x: 678 }, 580, Laya.Ease.quadIn, Laya.Handler.create(this, () => {
                Laya.Tween.to(this.bg_anim, { x: -305 }, 620);
            }));
            Laya.Tween.to(this.bg_anim, { alpha: 0 }, 200, null, Laya.Handler.create(this, () => {
                this.animing = false;
                this.anim.visible = false;
                UI_Activity_Chunjie_Trip.Inst.locking = false;
                UI_Activity_Chunjie_Trip.Inst.setScrollViewEnable(true);
            }), 1000);
            Laya.timer.once(800, this, () => {
                this.refresh();
            });

        }
    }
    export class UI_Activity_Chunjie_Trip extends UIBase {
        public static Inst: UI_Activity_Chunjie_Trip = null;

        public btn_close: Laya.Button;
        private scrollview: capsui.CScrollView;
        private root: Laya.Sprite;
        private label_count: Laya.Label;
        private label_tip: Laya.Label;

        private friend_infos: Array<iFriendInfo>;
        public locking: boolean;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_tripUI());
            UI_Activity_Chunjie_Trip.Inst = this;
        }

        public onCreate() {
            (this.me.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.root = this.me.getChildByName('root') as Laya.Sprite;

            this.btn_close = this.me.getChildByName('btn_close') as Laya.Button;
            this.btn_close.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            this.scrollview = (this.root.getChildByName('scrollview') as Laya.Sprite).scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));

            this.label_count = this.root.getChildByName('title').getChildByName('count') as Laya.Label;
            if (GameMgr.client_language == 'en') {
                this.label_count.x = 230;
            }
            this.label_tip = this.root.getChildByName('title').getChildByName('left_count') as Laya.Label;
            (this.root.getChildByName('tip') as Laya.Label).text = game.Tools.strOfLocalization(4127, [UI_Activity_Chunjie.activity_data.trip_round.toString()])
        }

        // 拉取好友等级
        private _loadInfo() {
            let account_ids: Array<number> = [];
            // 只拉取是好友的部分
            for (let i = 0; i < this.friend_infos.length; i++) {
                if (this.friend_infos[i].account_id > 100 && this.friend_infos[i].info) {
                    account_ids.push(this.friend_infos[i].account_id);
                }
            }
            
            if (account_ids.length == 0) {
                this.showFriends();
            } else {
                UI_Activity_Chunjie_Trip.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'getFriendVillageData', { activity_id: UI_Activity_Chunjie.activity_id, account_list: account_ids }, (err, res) => {
                    UI_Activity_Chunjie_Trip.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('getFriendVillageData', err, res);
                    } else {
                        for (let data of res['list']) {
                            for (let _data of this.friend_infos) {
                                if (_data.account_id == data.account_id) {
                                    _data.level = data.level ? data.level : 1;
                                    break;
                                }
                            }
                        }
                        this.showFriends();
                    }
                });
            }
        }

        public show() {
            view.AudioMgr.PlayAudio(10115);
            Laya.timer.clearAll(this);
            this.enable = true;
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            this.locking = true;
            this.me.alpha = 1;
            this.me.x = 0;
            UIBase.anim_alpha_in(this.me, { x: 100 }, 250, 0, Laya.Handler.create(this, () => {
                this.locking = false;
            }));


            this.scrollview.reset();
            this.friend_infos = [];
            let trip_datas: Array<iTripData> = [];
            for (let trip of UI_Activity_Chunjie.trip) {
                trip_datas.push(trip);
            }
            for (let friend of game.FriendMgr.friend_list) {
                let trip_data: iTripData = null;
                for (let i = 0; i < trip_datas.length; ++i) {
                    if (trip_datas[i].dest_id == friend.base.account_id) {
                        trip_data = trip_datas[i];
                        trip_datas.splice(i, 1);
                        break;
                    }
                }
            
                let _info = { account_id: friend.base.account_id, level: 0, info: friend, trip: trip_data }; // 先初始化为1级，后续fetch修正
                this.friend_infos.push(_info);
            }
            for (let i = 0; i < 3; i++) {
                if (GameMgr.Inst.account_id % 3 != i) {
                    let trip_data: iTripData = null;
                    for (let j = 0; j < trip_datas.length; ++j) {
                        if (trip_datas[j].dest_id == i) {
                            trip_data = trip_datas[j];
                            trip_datas.splice(j, 1);
                            break;
                        }
                    }
                    let _info = { account_id: i, level: 0, trip: trip_data };
                    
                    this.friend_infos.push(_info);
                   
                }
            }
            // // 将无数据
            for (let trip of trip_datas) {
             
                let _info = { account_id: trip.dest_id, level: 0, info: null, trip: trip };
                
                this.friend_infos.push(_info);
                
            }
            
            this.refreshTitle();
            this._loadInfo();
        }

       
        private getSort(info: iFriendInfo): number {
            if (info.trip) {
                return 100000 - info.trip.start_round;
            } else if (info.account_id < 100) {
                return 0;    
            } else {
                return info.level + 100;
            }
        }
        public close() {
            this.locking = true;
            UIBase.anim_alpha_out(this.me, { x: 100 }, 250, 0, Laya.Handler.create(this, () => {
                this.locking = false;
                this.enable = false;
            }));
        }

        private showFriends() {
            this.friend_infos.sort((a, b) => {
                return this.getSort(b) - this.getSort(a);
            });
            this.scrollview.addItem(this.friend_infos.length);
        }
        public onDisable(): void {
            for (let item of this.scrollview.items) {
                let cache_data = item.cache_data;
                if (cache_data['cell']) {
                    cache_data['cell'].reset();
                }
            }
            Laya.timer.clearAll(this);
        }

        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.friend_infos[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TripCell(container);
            }
            cache_data['cell'].show(data);

        }

        public refresh() {
            this.scrollview.wantToRefreshAll();
            this.refreshTitle();
        }
        public refreshTitle() {
            let _trip_count = UI_Activity_Chunjie.trip ? UI_Activity_Chunjie.trip.length : 0;
            let _farmer_count = UI_Bag.get_item_count(UI_Activity_Chunjie.activity_data.worker_item_id);
            this.label_count.text = game.Tools.strOfLocalization(4084, [_trip_count + '/3']);
            this.label_tip.color = '#b3a3a1';
            if (_trip_count == 3) {
                this.label_tip.text = game.Tools.strOfLocalization(4079);
                this.label_tip.color = '#fb5e5e';
            } else if (_farmer_count == 0) {
                this.label_tip.color = '#fb5e5e';
                this.label_tip.text = game.Tools.strOfLocalization(4078);
            } else {
                this.label_tip.text = game.Tools.strOfLocalization(4085, [_farmer_count.toString()]);
            }
        }

        public onTripRewardRecieved(dest_id: number) {
            let deleted = false;
            for (let i = 0; i < this.friend_infos.length; ++i) {
                if (this.friend_infos[i].account_id == dest_id) {
                    if (dest_id > 100 && !this.friend_infos[i].info) {
                        this.friend_infos.splice(i, 1);
                        deleted = true;
                    }
                    break;
                }
            }
            if (!deleted) {
                this.scrollview.wantToRefreshAll();
            } else {
                this.scrollview.reset();
                this.scrollview.addItem(this.friend_infos.length);
            }
            this.refreshTitle();
        }
        public setScrollViewEnable(enable: boolean) {
            this.scrollview.setScrollEnable(enable);
        }
    }
}