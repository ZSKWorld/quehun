module uiscript {
    export class UI_Activity_Chunjie_Upgrade extends UIBase {
        public static Inst: UI_Activity_Chunjie_Upgrade = null;

        private root: Laya.Sprite;
        private name: Laya.Label;
        private tag: Laya.Image;
        private items: Array<{me: Laya.Sprite, farmer: Laya.Image, lock: Laya.Sprite}>;
        private cost_parent: Laya.Sprite;
        private costs: Array<{me: Laya.Sprite, icon: Laya.Image, count: Laya.Label}>;
        private btn_upgrade: Laya.Button;
        private btn_image: Laya.Image;
        private level: Laya.Sprite;
        private level_now: Laya.Label;
        private level_next: Laya.Label;

        private locking: boolean;
        private item_enough: boolean;

        private type: number;
        private buildData: lqc.Sheet_Activity_VillageBuilding;

        private start_anim_time: number;
        private start_anim_index: number;
        private start_anim_count: number;

        private effects: Array<game.UIEffect>;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_upgradeUI());
            UI_Activity_Chunjie_Upgrade.Inst = this;
        }

        public onCreate() {
            (this.me.getChildByName('bg').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.name = this.me.getChildByName('root').getChildByName('title').getChildByName('name') as Laya.Label;
            this.tag = this.me.getChildByName('root').getChildByName('title').getChildByName('upgrade') as Laya.Image;
            this.items = [];
            let _templete = this.me.getChildByName('root').getChildByName('mid').getChildByName('farmers').getChildByName('item_0') as Laya.Sprite;
            for (let i = 0; i < 16; ++i) {
                let _item: Laya.Sprite = null;
                if (i == 0) {
                    _item = _templete;
                } else {
                    _item = _templete.scriptMap['capsui.UICopy']['getNodeClone']();
                }
                this.items.push({me: _item, farmer: _item.getChildByName('farmer') as Laya.Image, lock: _item.getChildByName('lock') as Laya.Sprite});
            }

            this.costs = [];
            this.cost_parent = this.me.getChildByName('root').getChildByName('cost') as Laya.Sprite;
            for (let i = 0; i < 3; i++) {
                let _item = this.me.getChildByName('root').getChildByName('cost').getChildAt(i) as Laya.Sprite;
                this.costs.push({me: _item, icon: _item.getChildAt(0) as Laya.Image, count: _item.getChildByName('count') as Laya.Label});
            }

            this.btn_upgrade = this.me.getChildByName('root').getChildByName('btn_upgrade') as Laya.Button;
            this.btn_image = this.btn_upgrade.getChildAt(0) as Laya.Image;
            this.btn_upgrade.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                if (!this.item_enough) return;
                this.locking = true;
                let building_id = this.buildData.building_id;
                app.NetAgent.sendReq2Lobby('Lobby', 'upgradeVillageBuilding', {
                    building_id: building_id, activity_id: UI_Activity_Chunjie.activity_id
                }, (err, res)=>{
                    
                    if (err || res['error']) {
                        this.locking = false;
                        UIMgr.Inst.showNetReqError('upgradeVillageBuilding', err, res);
                    } else {
                        this.playUpgradeAnim();
                        Laya.timer.once(1500, this, ()=>{
                            this.destroyAllEffects();
                            this.refresh();
                            this.locking = false;
                            UI_Activity_Chunjie_Upgrade_Result.Inst.show(building_id, Laya.Handler.create(this, ()=>{
                                UI_Activity_Chunjie.Inst.refreshAll();
                                
                            }));
                        });
                        
                        
                    }
                })
                
            });

            (this.me.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });

            this.level = this.me.getChildByName('root').getChildByName('mid').getChildByName('level') as Laya.Sprite;
            this.level_now = this.level.getChildByName('now') as Laya.Label;
            this.level_next = this.level.getChildByName('next') as Laya.Label;
        }

        // 4位1001 3003数字
        public show(type: number) {
            view.AudioMgr.PlayAudio(10115);
            Laya.timer.clearAll(this);  
            this.enable = true;
            this.locking = true;
            this.me.alpha = 1;
            this.me.x = 0;
            UIBase.anim_alpha_in(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
            }));
            UI_Activity_Chunjie.Inst.locking_refresh = true;
            UI_Activity_Chunjie.Inst.setCurrencyLayer(true);
            this.type = type;
            this.refresh();
        }

        private refresh() {
            let data = UI_Activity_Chunjie.getBuildDataByType(this.type);
            this.buildData = UI_Activity_Chunjie.getCfgBuildData(data.id);
            if (!this.buildData) {
                this.close();
                return;
            }
            if (this.buildData.func == 'housing') {
                this.level.y = -48;
                for (let i = 0; i < this.items.length; i++) {
                    let item = this.items[i];
                    item.me.scale(0.9, 0.9);
                    item.me.pos(69 + 117 * (i % 4), -114 + Math.floor(i / 4) * 117);
                   
                }
            } else {
                this.level.y = 74;
                for (let i = 0; i < this.items.length; i++) {
                    let item = this.items[i];
                    item.me.scale(1,  1);
                    item.me.pos(33 + 130 * i, 34);
                   
                }
            }


            if (!this.buildData.next_level_id) {
                this.start_anim_time = - 1;
                this.level.visible = false;
                this.cost_parent.visible = false;
                this.btn_upgrade.mouseEnabled = false;
                this.tag.skin = '';
                this.btn_image.skin = '';
                (this.btn_upgrade.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(4076);
                if (this.buildData.func == 'housing') {
                    this.level.y = -48;
                    let totalCount = UI_Activity_Chunjie.getTotalFarmerCount();
                    for (let i = 0; i < this.items.length; i++) {
                        let item = this.items[i];
                        
                        item.me.visible = true;
                        item.lock.visible = false;
                        if (i < totalCount) {
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                        } else {
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
                        }
                    }
    
                } else {
                    let worker_count = 0;
                    if (data.workers) {
                        for (let i = 0; i < 4; ++i) {
                            if (data.workers[i]) {
                                ++worker_count;
                            }
                        }
                    }
                    for (let i = 0; i < this.items.length; i++) {
                        let item = this.items[i];
                        if (i >= 4) {
                            item.me.visible = false;
                        } else {
                            item.me.visible = true;
                            item.lock.visible = false;
                            if (i < worker_count) {
                                item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                            } else {
                                item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
                            }
                        }
                    }
                }
                this.name.text = game.Tools.strOfLocalization(this.buildData.building_name);
                return;
            }
            this.start_anim_time = Laya.timer.currTimer;
            this.level.visible = true;
            this.cost_parent.visible = true;
            this.btn_upgrade.mouseEnabled = true;
            (this.btn_upgrade.getChildAt(1) as Laya.Label).text = game.Tools.strOfLocalization(4051);
            // 农舍
            if (this.buildData.func == 'housing') {
                this.level.y = -48;
                let nextBuildData = UI_Activity_Chunjie.getCfgBuildData(this.buildData.next_level_id);
                let totalCount = UI_Activity_Chunjie.getTotalFarmerCount();
                this.start_anim_count = nextBuildData.args[0] - this.buildData.args[0];
                this.start_anim_index = this.buildData.args[0];
                for (let i = 0; i < this.items.length; i++) {
                    let item = this.items[i];
                    
                    item.me.visible = true;
                    if (i < this.buildData.args[0]) {
                        item.lock.visible = false;
                        if (i < totalCount) {
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                        } else {
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
                        }
                        
                    } else if (i < nextBuildData.args[0]) {
                        item.lock.visible = true;
                        item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_2.png');
                    } else {
                        item.lock.visible = true;
                        item.lock.rotation = 0;
                        item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_5.png');
                    }
                    
                }

            } else {
                this.start_anim_count = 1;
                this.start_anim_index = this.buildData.max_worker_count;
                let worker_count = 0;
                if (data.workers) {
                    for (let i = 0; i < 4; ++i) {
                        if (data.workers[i]) {
                            ++worker_count;
                        }
                    }
                }
                for (let i = 0; i < this.items.length; i++) {
                    let item = this.items[i];
                    if (i >= 4) {
                        item.me.visible = false;
                    } else {
                        item.me.visible = true;
                        if (i < worker_count) {
                            item.lock.visible = false;
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_1.png');
                        } else if (i < this.buildData.max_worker_count) {
                            item.lock.visible = false;
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_3.png');
                        } else if (i == this.buildData.max_worker_count) {
                            
                            item.lock.visible = true;
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_2.png');
                        } else {
                            item.lock.rotation = 0;
                            item.lock.visible = true;
                            item.farmer.skin = game.Tools.localUISrc('myres/activity_24chunjie/farmer_5.png');
                        }
                    }
                }
            }
            this.name.text = game.Tools.strOfLocalization(this.buildData.building_name);
            this.level_now.text = game.Tools.strOfLocalization(4053) + this.buildData.level;
            this.level_next.text = game.Tools.strOfLocalization(4053) + (this.buildData.level + 1);
            this.checkCostEnough();
        }
        public close() {
            this.locking = true;
            this.start_anim_time = -1;
            UIBase.anim_alpha_out(this.me, {x: 100}, 150, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
                UI_Activity_Chunjie.Inst.locking_refresh = false;
                UI_Activity_Chunjie.Inst.onUpgradeClose();
            }));
        }

        private checkCostEnough() {
            let costs = this.buildData.upgrade_item.split(',');
            let index = 0;
            this.item_enough = true;
            for (let cost of costs) {
                if (cost) {
                    let item = this.costs[index];
                    item.me.visible = true;
                    let cost_nums = cost.split('-');
                    let id = Number(cost_nums[0]);
                    let count = Number(cost_nums[1]);
                    if (UI_Bag.get_item_count(id) < count) {
                        item.count.color = '#fb5e5e';
                        this.item_enough = false;
                    } else {
                        item.count.color = '#ffffff';
                    }
                    item.count.text = cost_nums[1];
                    let _itemData = cfg.item_definition.item.get(id);
                    game.LoadMgr.setImgSkin(item.icon, _itemData.icon_transparent, null, 'UI_Activity_Chunjie');
                    ++index;
                }
            }
            this.cost_parent.x = 147 + (3 - index) * 149 / 2;
            for (; index < this.costs.length; ++index) {
                this.costs[index].me.visible = false;
            }

            this.btn_image.skin = game.Tools.localUISrc(this.item_enough ? 'myres/activity_24chunjie/btn_l.png' : 'myres/activity_24chunjie/btn_d.png');
            this.tag.skin = game.Tools.localUISrc(this.item_enough ? 'myres/activity_24chunjie/btn_upgrade_l.png' : 'myres/activity_24chunjie/btn_upgrade_d.png');
        }

        public update() {
            if (this.start_anim_time > 0) {
                let _t = (Laya.timer.currTimer - this.start_anim_time) % 1500;
                let rot = 0;
                let _frame_time = 1 / 60 * 1000;
                if (_t <= 5 * _frame_time) {
                    rot = 12 * (_t / (5 * _frame_time));
                } else if (_t <= 14 * _frame_time){
                    rot = 12 - 24 * (_t - 5 * _frame_time) / ((14 - 5) * _frame_time);
                } else if (_t <= 25 * _frame_time) {
                    rot = -12 + 21 * (_t - 14 * _frame_time) / ((25 - 14) * _frame_time);
                } else if (_t <= 30 * _frame_time) {
                    rot = 9 - 9 * (_t - 25 * _frame_time) / ((30 - 25) * _frame_time);
                } else {
                    rot = 0;
                }

                for (let i = this.start_anim_index; i < this.start_anim_index + this.start_anim_count; ++i) {
                    this.items[i].lock.rotation = rot;
                }
            }
        }

        private playUpgradeAnim() {
            view.AudioMgr.PlayAudio(10116);
            this.effects = [];
            for (let i = this.start_anim_index; i < this.start_anim_index + this.start_anim_count; ++i) {
                this.items[i].lock.visible = false;
                this.effects.push(game.FrontEffect.Inst.create_ui_effect(this.items[i].lock, 'scene/effect_chunjie_jiesuo.lh', new Laya.Point(), this.items[i].me.scaleX));
            }
        }

        private destroyAllEffects() {
            if (this.effects) {
                for (let effect of this.effects) {
                    effect.destory();
                }
                this.effects = null;
            }
        }
    }
}