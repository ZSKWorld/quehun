module uiscript {
    export class UI_Activity_Chunjie_Upgrade_Result extends UIBase {
        public static Inst: UI_Activity_Chunjie_Upgrade_Result = null;

        constructor() {
            super(new ui.lobby.chunjie.activity_chunjie_upgrade_resultUI());
            UI_Activity_Chunjie_Upgrade_Result.Inst = this;
        }

        private root: Laya.Sprite;
        private name: Laya.Label;
        private level_now: Laya.Label;
        private level_next: Laya.Label;
        private count: Laya.Label;
        private handler: Laya.Handler;
        private locking: boolean;
        
        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.name = this.root.getChildByName('name') as Laya.Label;
            this.count = this.root.getChildByName('count') as Laya.Label;
            this.level_now = this.root.getChildByName('level').getChildByName('now') as Laya.Label;
            this.level_next = this.root.getChildByName('level').getChildByName('next') as Laya.Label;
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.close();
            });
            let show_anim = (this.me as ui.lobby.chunjie.activity_chunjie_upgrade_resultUI).show;
            show_anim.interval = 16.7;
        }

        public show(now_building_id: number, handler: Laya.Handler) {
            view.AudioMgr.PlayAudio(10109);
            this.handler = handler;
            let _data = UI_Activity_Chunjie.getCfgBuildData(now_building_id);
            if (_data.func == 'housing') {
                // 农舍
                let _next_data = UI_Activity_Chunjie.getCfgBuildData(_data.next_level_id);
                this.count.text = '+' + (_next_data.args[0] - _data.args[0]);
            } else {
                
                this.count.text = '+1';
            }
            this.enable = true;
            this.locking = true;
            this.root.alpha = 1;
            (this.me as ui.lobby.chunjie.activity_chunjie_upgrade_resultUI).show.play(0, false);
            Laya.timer.once(600, this, ()=>{
                this.locking = false;
            });
            this.level_now.text = game.Tools.strOfLocalization(4053) + _data.level;
            this.level_next.text = game.Tools.strOfLocalization(4053) + (_data.level + 1);
            this.name.text = game.Tools.strOfLocalization(_data.building_name);
        }

        private close() {
            this.locking = true;
            UIBase.anim_alpha_out(this.root, {}, 200, 0, Laya.Handler.create(this, ()=>{
                this.locking = false;
                this.enable = false;
                if (this.handler) {
                    this.handler.run();
                    this.handler = null;
                }
            }));
        }
    }
}