/**
* 合成主界面
*/
module uiscript {

	enum E_Order_State { empty = 0, normal, running, wrong, enter, complete }//0：无  1: 普通  2:正确动画  3:错误动画 4:进入动画
	class Item_Order_Item extends UI_Component {
		private tipCommit1: Laya.Sprite;
		private tipCommit2: Laya.Sprite;
		private icon: Laya.Image;
		private complete: Laya.Sprite;
		private isTwoItem: boolean;
		private craftId: number;
		private itemBase: Laya.Sprite;

		public onCreate(): void {
			this.tipCommit1 = this.me.getChildByName('tip_commit1') as Laya.Sprite;
			this.tipCommit2 = this.me.getChildByName('tip_commit2') as Laya.Sprite;
			let item = this.me.getChildByName('item') as Laya.Sprite;
			this.icon = item.getChildByName('icon') as Laya.Image;
			this.complete = item.getChildByName('completed') as Laya.Sprite;
			this.complete.visible = false;
			this.itemBase = item;
		}

		public set tipCommitVisible(visible: boolean) {
			this.tipCommit1.visible = visible && !this.isTwoItem;
			this.tipCommit2.visible = visible && this.isTwoItem;
		}

		public get isCommitVisible(): boolean {
			if (this.isTwoItem) {
				return this.tipCommit2.visible;
			}
			return this.tipCommit1.visible;
		}

		public set craft(craftId: number) {
			this.craftId = craftId;
			if (craftId) {
				let _data = UI_Activity_Combining.getCraftData(craftId);
				this.icon.skin = game.Tools.localUISrc('myres/activity_combining/' + _data.img_name);
			} else {
				this.icon.skin = '';
			}
		}

		public get craft(): number {
			return this.craftId;
		}

		public set isTwo(isTwo) {
			this.isTwoItem = isTwo;
		}

		public set isComplete(complete: boolean) {
			this.complete.visible = complete;
			if (complete) {
				this.tipCommit1.visible = false;
				this.tipCommit2.visible = false;
			}
			this.icon.alpha = complete ? 0.5 : 1;
		}

		public clear() {
			this.icon.skin = '';
			this.craftId = -1;
			this.isTwoItem = false;
			this.visible = false;
		}

		public reset() {
			this.itemBase.scaleX = 1;
			this.itemBase.scaleY = 1;
			this.itemBase.alpha = 1;
		}

		public showEffect() {
			UI_Activity_Combining.Inst.createEffect(this.me, new Laya.Point(0, 0), false);
		}



	}
	class Item_Order {
		public me: Laya.Sprite;
		private chara: Laya.Image;
		private origin_chara_x: number;
		private enter_offset_x: number;
		private out_offset_x: number;

		private other: Laya.Sprite; // 动画用整合节点
		private bg: Laya.Image;
		private rect: Laya.Sprite;
		private tip: Laya.Sprite;
		// 正确部分
		private tip_correct: Laya.Sprite;
		private correct_reward: Laya.Sprite;;

		private tip_wrong: Laya.Sprite;
		private label_count: Laya.Label;
		private label_reward: Laya.Label;
		private itemParent: Laya.Sprite;
		private items: Array<Item_Order_Item> = [];
		private maxItemCount: number = 2;
		private otherAnimBase: ui.lobby.combining.activity_combining_char_otherUI;

		// 进入动画
		private tip_enter: Laya.Sprite;

		public index: number;
		private img_pre_name: string;
		/**
		 * 需求的商品的id
		 */
		public craft_ids: number[] = [];
		/**
		 * 对应index的商品是否完成
		 */
		public complete_ids: boolean[] = [];
		public state: E_Order_State;
		public charaId: number; // 客人id

		constructor(me: Laya.Sprite, index: number, animBase: ui.lobby.combining.activity_combining_char_otherUI) {
			this.me = me;
			this.index = index;
			this.chara = this.me.getChildByName('char_parent').getChildByName('chara') as Laya.Image;
			this.origin_chara_x = this.chara.x;
			this.enter_offset_x = index == 0 ? -249 : (index == 1 ? -270 : 250);
			this.out_offset_x = index == 0 ? -249 : (index == 1 ? 270 : 250);
			this.other = this.me.getChildByName('other_root').getChildByName('other') as Laya.Sprite;
			this.otherAnimBase = animBase;
			this.bg = this.other.getChildByName('bg') as Laya.Image;
			this.rect = this.me.getChildByName('rect') as Laya.Sprite;

			this.tip = this.other.getChildByName('tip') as Laya.Sprite;
			this.tip_correct = this.tip.getChildByName('correct') as Laya.Sprite;
			this.correct_reward = this.tip_correct.getChildByName('reward') as Laya.Sprite;
			this.tip_wrong = this.tip.getChildByName('wrong') as Laya.Sprite;

			this.items = [];
			this.itemParent = this.other.getChildByName('items') as Laya.Sprite;
			this.label_count = this.itemParent.getChildByName('price').getChildByName('count') as Laya.Label;
			for (let i = 1; i < this.maxItemCount + 1; i++) {
				let item = this.itemParent.getChildByName('item' + i) as Laya.Sprite;
				this.items.push(new Item_Order_Item(item));
			}

			this.label_reward = this.tip_correct.getChildByName('reward').getChildByName('count') as Laya.Label;
			this.img_pre_name = index == 0 ? 'left_' : (index == 1 ? 'mid_' : 'right_');
			this.tip_enter = this.tip.getChildByName('enter') as Laya.Sprite;
		}

		public show(craft_ids: number[], charId: number, complete_ids: number[] = []) {
			Laya.timer.clearAll(this);
			this.reset();
			this.charaId = charId;
			this.refreshCraft(craft_ids, complete_ids);
			let customerData = cfg.activity.combining_customer.get(this.charaId);
			if (craft_ids.length > 0) {
				this.me.visible = true;
				this.itemParent.visible = true;
				this.tip_wrong.visible = false;
				this.tip_correct.visible = false;
				this.tip_enter.visible = false;
				this.state = E_Order_State.normal;
				let price: number = this.orderPrice;
				this.label_count.text = price.toString();
				this.label_reward.text = '+' + price;
				//如果是新的客人，则从'myres/activity_combining/'中获取图片，如果是老的客人，则从'myres2/loading_3que1/'中获取图片
				let folder = customerData.customer_loading != 1 ? 'myres/activity_combining/' : 'myres2/loading_3que1/';
				let charPath = folder + customerData.customer_skin + '.png';
				game.LoadMgr.setImgSkin(this.chara, charPath, null, 'UI_Activity_Combining');

			} else {
				this.me.visible = false;
				this.state = E_Order_State.empty;
				this.chara.skin = '';
			}
		}


		public refreshCraft(craft_id: number[], complete_ids: number[] = []) {
			this.craft_ids = craft_id;
			//根据complete_ids来判断哪些道具已经完成
			let hasUse: Array<number> = [];
			for (let index = 0; index < craft_id.length; index++) {
				const id = craft_id[index];
				let completeIndex = complete_ids.indexOf(id);
				if (completeIndex != -1 && hasUse.indexOf(id) == -1) {
					this.complete_ids[index] = true;
					hasUse.push(id);
				} else {
					this.complete_ids[index] = false;
				}
			}

			//如果是两个道具，则显示两个道具的背景和位置，一个则为一个的背景和位置
			this.bg.skin = game.Tools.localUISrc(this.craft_ids.length > 1 ? 'myres/activity_combining/bg_demand2.png' : 'myres/activity_combining/bg_demand.png');
			for (let index = 0; index < this.items.length; index++) {
				const element = this.items[index];
				if (index >= this.craft_ids.length) {
					element.clear();
					continue;
				}
				element.me.visible = true;
				element.isTwo = this.craft_ids.length > 1;
				element.craft = this.craft_ids[index];
				element.isComplete = this.complete_ids[index];
				if (index == 0) {
					element.me.x = this.craft_ids.length > 1 ? 168 : 255;
				}
			}



		}

		public checkInArea(x: number, y: number): boolean {
			// if (!this.me.visible) return false;
			if (this.state != E_Order_State.normal && this.state != E_Order_State.wrong && this.state != E_Order_State.running) return false;
			let startX = this.me.x + this.rect.x + (this.me.parent as Laya.Sprite).x;
			let startY = this.me.y + this.rect.y + (this.me.parent as Laya.Sprite).y;
			if (x >= startX && x <= startX + this.rect.width && y >= startY && y < this.rect.height + startY) {
				return true;
			}
			return false;
		}

		public onOrderChooesd(craft_id: number, pos: number, complete: Laya.Handler): boolean {
			if (this.craft_ids.length == 0 || !this.craft_ids) {
				return false;
			}
			this.resetWrongAnim();
			//检查是否有可提交
			let itemIndex = -1;
			let needCompleteCount = 0;
			for (let index = 0; index < this.craft_ids.length; index++) {
				const id = this.craft_ids[index];
				if (craft_id == id && !this.complete_ids[index]) {
					itemIndex = index;
				}
				if (!this.complete_ids[index]) {
					needCompleteCount++;
				}
			}

			if (itemIndex == -1) {
				this.showWrongAnim();
				return false;
			} else {
				//如果是最后一个订单，则显示完成动画
				if (needCompleteCount > 1) {
					this.showCorrectAnim(itemIndex);
				} else {
					this.showComleteAnim();
					//对应的item显示合成特效
					this.items[itemIndex].showEffect();
				}

				app.NetAgent.sendReq2Lobby('Lobby', 'finishCombiningOrder', {
					activity_id: UI_Activity_Combining.activity_id,
					craft_pos: pos,
					order_pos: this.index
				}, (err, res) => {
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('finishCombiningOrder', err, res);
						// 报错了，还原成之前的样子
						complete.runWith(false);
						Laya.timer.clearAll(this);
						this.itemParent.visible = true;
						this.tip_wrong.visible = false;
						this.tip_correct.visible = false;
						this.state = E_Order_State.normal;
						this.me.alpha = 1;
					} else {
						complete.runWith(true);
					}
				})
				return true;
			}
		}

		// 播放错误动画
		private showWrongAnim() {
			this.setBgState(false);
			this.tip_wrong.visible = true;
			this.state = E_Order_State.wrong;

			this.playAnim('tishi_cuowu01', false, Laya.Handler.create(this, () => {
				this.tip_wrong.visible = false;
				this.state = E_Order_State.normal;
				UI_Activity_Combining.Inst.checkAllOrder();
			}));
		}

		private resetWrongAnim() {
			this.tip_wrong.visible = false;
			this.itemParent.visible = true;
			this.itemParent.alpha = 1;
			this.state = E_Order_State.normal;
			Laya.Tween.clearAll(this.itemParent);
			Laya.Tween.clearAll(this.tip_wrong);
		}

		/**
		 * 完成单个订单
		 */
		private showCorrectAnim(index: number) {
			this.setBgState(false);
			let item = this.items[index];
			item.isComplete = true;
			this.complete_ids[index] = true;

		}


		/**
		 * 完成所有订单
		 */
		private showComleteAnim() {
			this.setBgState(false);
			this.state = E_Order_State.complete;
			let animComplete: boolean = false;
			let audioComplete: boolean = false;
			let onComplete = Laya.Handler.create(this, () => {
				// 播放人物消失牌子消失动画
				UI_Activity_Combining.Inst.playAnim('char' + (this.index + 1) + '_c', false, Laya.Handler.create(this, () => {
					this.tip_correct.visible = false;
					//获取下一个订单
					let order = UI_Activity_Combining.getOrderInfo(this.index);
					if (!order) {
						this.show([], 0);
						UI_Activity_Combining.Inst.checkAllOrderDone(true);
					} else {
						let charId = order.char_id;
						// ==DevDebug Start==
						let charStaticId = UI_Activity_Combining.staticCharIds[this.index];
						if (charStaticId > 0) {
							charId = charStaticId;
						}
						// ==DevDebug End==
						this.show(order.craft_id, charId, order.finished_craft_id);
						this.showEnterAnim();
					}
				}));
			}, null, true);
			//播放该人物语音，语音播放完毕后生成下个客人
			let customerData = cfg.activity.combining_customer.get(this.charaId);
			let voice = customerData.complete_sound;
			// 播放语音
			UI_Activity_Combining.Inst.playSound(voice, Laya.Handler.create(this, () => {
				if (!audioComplete) {
					audioComplete = true;
					if (animComplete) {
						onComplete.run();
					}
				}
			}));
			if (Laya.Browser.onIOS) {
				//如果5s后没有完成订单，则直接完成订单，防止因为sound停止被卡住
				Laya.timer.once(5000, this, () => {
					if (!audioComplete) {
						audioComplete = true;
						if (animComplete) {
							onComplete.run();
						}
					}	
				});
			}
			

			// UI_Activity_Combining.Inst.createEffect(this.bg, new Laya.Point(129, 84));
			this.tip_correct.visible = true;
			this.playAnim('tishi_wancheng01', false, Laya.Handler.create(this, () => {
				animComplete = true;
				if (audioComplete) {
					onComplete.run();
				}
			}));
		}

		private showEnterAnim() {
			this.state = E_Order_State.enter;
			this.setBgState(false);
			let onAnimComplete = Laya.Handler.create(this, () => {
				//显示点单动画
				this.tip_enter.visible = true;
				this.playAnim('tishi_diancan01', false, Laya.Handler.create(this, () => {
					
					this.tip_enter.visible = false;
					this.state = E_Order_State.normal;
					UI_Activity_Combining.Inst.checkAllOrder(true);
				}));

			});
			let animName = 'char' + (this.index + 1) + '_o';
			UI_Activity_Combining.Inst.playAnim(animName, false, onAnimComplete);
		}

		/**
		 * 提示可以完成
		 * @param is_green 
		 */
		public setBgState(is_green: boolean, pos: number = -1, isAnim: boolean = false) {
			let isGreen = is_green && (this.state == E_Order_State.normal || this.state == E_Order_State.running);
			for (let index = 0; index < this.items.length; index++) {
				let item = this.items[index];
				if (index == pos || pos == -1) {
					if (isGreen) {
						if (!item.isCommitVisible && isAnim) {
							//播放绿色刷新动画
							let itemAnimName = 'item' + (index + 1) + '_tip' + (this.craft_ids.length > 1 ? 2 : 1) + '_o';
							this.playAnim(itemAnimName);
						} else {
							let itemAnimName = 'item' + (index + 1) + '_tip' + (this.craft_ids.length > 1 ? 2 : 1) + '_i';
							this.playAnim(itemAnimName, false);
						}
					} else {
						if (item.isCommitVisible && isAnim) {
							let itemAnimName = 'item' + (index + 1) + '_tip' + (this.craft_ids.length > 1 ? 2 : 1) + '_c';
							this.playAnim(itemAnimName);
						}
					}
					item.tipCommitVisible = isGreen;

				}
			}
		}




		public reset() {
			Laya.Tween.clearAll(this.chara);
			Laya.timer.clearAll(this);
			this.chara.x = this.origin_chara_x;
			this.other.y = 0;
			this.other.alpha = 1;
			
		}

		public onClose() {
			this.stopAllAnim();
			for (let index = 0; index < this.items.length; index++) {
				let item = this.items[index];
				item.reset();
			}
			this.playAnim('idle');
			if (Laya.Browser.onIOS) {
				this.me.offAll();
			}
			Laya.timer.clearAll(this);
		}

		/**
		 * 获取匹配的当前道具的Pos
		 * @param craft_id 道具id
		 * @param isCheckComplete 是否检查完成
		 */
		public getMatchItem(craft_id: number, isCheckComplete: boolean = true): number {
			for (let index = 0; index < this.items.length; index++) {
				let item = this.items[index];
				if (item.craft == craft_id) {
					if (isCheckComplete) {
						if (!this.complete_ids[index]) {
							return index;
						}
					} else {
						return index;
					}
				}
			}
			return -1;
		}

		public get charaCenter(): Laya.Vector2 {
			//转成世界坐标的角色中心位置
			if (!this.chara) return new Laya.Vector2(0, 0);
			let worldPos = this.chara.localToGlobal(new Laya.Point(this.chara.width / 2, this.chara.height / 2));
			return new Laya.Vector2(worldPos.x, worldPos.y);
		}

		public get orderPrice(): number {
			let price: number = 0;
			for (let index = 0; index < this.craft_ids.length; index++) {
				let craft_id = this.craft_ids[index];
				let priceStr = UI_Activity_Combining.getCraftData(craft_id).order_price;
				let _reward_count = priceStr.split('-')[1];
				price += Number(_reward_count);
			}
			if (this.craft_ids.length > 1) {
				//乘以倍率并向上取整
				price = Math.ceil(price * UI_Activity_Combining.getAcitivityInfo().multi_order_rate / 100);
			}
			return price;
		}
		private runningAnims: Array<string> = [];
		public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
			this.otherAnimBase[name].play(0, isLoop);
			this.runningAnims.push(name);
			this.otherAnimBase[name].once(Laya.Event.COMPLETE, this, () => {
				if (onComplete) {
					onComplete.run();
				}
				this.runningAnims = this.runningAnims.filter(anim => anim !== name);
			});
		}

		public stopAnim(name: string) {
			// console.log('stop order anim', this.index, name);
			this.otherAnimBase[name].stop();
		}

		public stopAllAnim() { 
			for (let animName of this.runningAnims) {
				this.stopAnim(animName);
			}
			this.runningAnims = [];
		}


	}

	class Item_Craft {
		public static offset: Laya.Vector2 = new Laya.Vector2(430 - 93, 599 - 61);
		public static per_width: number = 192;
		public static per_height: number = 124;

		public me: Laya.Sprite;
		public craft_id: number;
		private icon: Laya.Image;
		private lock: Laya.Sprite;
		private star: Laya.Sprite; // 星星特效

		private tip_in_area: Laya.Sprite;
		private tip_order: Laya.Sprite;

		public index: number; // 物理坐标
		public pos: number; // 服务器坐标
		public data: lqc.Sheet_Activity_CombiningCraft;
		private origin_pos: Laya.Vector2;

		private playing_breathe_anim: boolean = false;
		public unlock_count: number;
		private unlock_state: number = 0; // 0: 无 1:锁 2:解锁
		private animBase: ui.lobby.combining.activity_combining_itemUI;

		public get locking(): boolean {
			return this.lock.visible;
		}

		public moving: boolean;
		constructor(me: Laya.Sprite, index: number, pos: number) {
			this.index = index;
			this.pos = pos;
			this.me = me;
			this.icon = me.getChildByName('icon') as Laya.Image;
			this.lock = me.getChildByName('lock') as Laya.Sprite;
			this.star = me.getChildByName('star') as Laya.Sprite;
			this.star.visible = false;
			let datas = cfg.activity.combining_map.getGroup(UI_Activity_Combining.activity_id);
			let unlock_count: number = 0;
			for (let data of datas) {
				if (data.workbench_count > pos) {
					unlock_count = data.point_item_count;
					break;
				}
			}
			this.unlock_count = unlock_count;

			this.origin_pos = new Laya.Vector2(this.icon.x, this.icon.y);
			this.me.x = Item_Craft.per_width * (index % 6) + 93;
			this.me.y = Item_Craft.per_height * Math.floor(index / 6) + 61;

			this.tip_in_area = me.getChildByName('tip_1') as Laya.Sprite;
			this.tip_order = me.getChildByName('tip_0') as Laya.Sprite;
			this.animBase = this.me as ui.lobby.combining.activity_combining_itemUI;
		}

		public refresh(craft_id: number, isAnim: boolean = false) {
			this.data = null;
			this.icon.x = this.origin_pos.x;
			this.icon.y = this.origin_pos.y;

			this.craft_id = craft_id;
			this.tip_order.alpha = 1;
			this.tip_order.visible = false;
			this.tip_in_area.visible = false;
			Laya.Tween.clearAll(this.icon);
			this.stopBreatheAnim();
			this.icon.scale(1, 1);
			if (craft_id) {
				let data = UI_Activity_Combining.getCraftData(craft_id);
				this.data = data;
				this.icon.skin = game.Tools.localUISrc('myres/activity_combining/' + data.img_name);
				if (this.data.if_bonus) {
					//显示星星特效
					this.star.visible = true;
					this.playAnim('star', true);
				} else {
					this.star.visible = false;
					this.stopAnim('star');
				}
				UI_Activity_Combining.Inst.checkOrder(this, isAnim);
			} else {
				this.icon.skin = '';
			}
		}

		public refreshUnlockState(unlock_count: number) {
			let lock_state = this.pos < unlock_count ? 2 : 1;

			if (!this.unlock_state) {
				this.unlock_state = lock_state;
				this.lock.x = 0;
				this.lock.y = 0;
				this.lock.alpha = 1;
				if (this.pos < unlock_count) {
					this.icon.visible = true;
					this.lock.visible = false;

				} else {
					this.lock.visible = true;
					this.icon.visible = false;
				}
			} else {

				if (this.unlock_state != lock_state) {
					this.unlock_state = lock_state;
					this.lock.x = 0;
					this.lock.y = 0;
					this.lock.alpha = 1;
					Laya.Tween.clearAll(this.lock);

					if (lock_state == 1) {

						this.lock.visible = true;
						this.icon.visible = false;
					} else {
						this.showUnlockAnim();
					}
				}
			}

		}

		private showUnlockAnim() {
			// TODO 接入金币
			Laya.Tween.to(this.lock, { x: -10, y: 5 }, 33, null, Laya.Handler.create(this, () => {
				Laya.Tween.to(this.lock, { x: 0, y: 0 }, 66, null, Laya.Handler.create(this, () => {
					Laya.Tween.to(this.lock, { x: 10, y: -5 }, 66, null, Laya.Handler.create(this, () => {
						Laya.Tween.to(this.lock, { x: 0, y: 0 }, 33, null, Laya.Handler.create(this, () => {
							Laya.Tween.to(this.lock, { x: -10, y: 5 }, 33, null, Laya.Handler.create(this, () => {
								Laya.Tween.to(this.lock, { x: 0, y: 0 }, 66, null, Laya.Handler.create(this, () => {
									Laya.Tween.to(this.lock, { x: 0, y: 28, alpha: 0 }, 132, null, Laya.Handler.create(this, () => {
										this.lock.visible = false;
										this.icon.visible = true;
									}), 200);
								}));
							}));
						}));
					}));
				}));
			}));

		}


		public onMouseDown() {
			this.moving = true;
			this.pauseBreatheAnim();
			this.setTipOrderVisible(false);
			Laya.Tween.to(this.icon, { scaleX: 1.2, scaleY: 1.2 }, 200);
			//如果是小费，暂停播放星星特效
			if (this.data.if_bonus) {
				this.star.visible = false;
				this.stopAnim('star');
			}
		}

		// 拖拽取消
		public onMouseOver() {
			// 可能需要根据距离修改t
			this.moving = true;
			let _dis = Math.sqrt(Math.pow(this.origin_pos.x - this.icon.x, 2) + Math.pow(this.origin_pos.y - this.icon.y, 2));
			let _speed = 5000 / 1000;
			Laya.Tween.clearAll(this.icon);
			Laya.Tween.to(this.icon, { x: this.origin_pos.x, y: this.origin_pos.y, scaleX: 1, scaleY: 1 }, _dis / _speed, null, Laya.Handler.create(this, () => {
				this.moving = false;
				this.resumeBreatheAnim();
				UI_Activity_Combining.Inst.checkOrder(this);
				if (this.data.if_bonus) {
					this.star.visible = true;
					this.playAnim('star', true);
				}
			}));
		}

		public onMouseMove(globalPosX: number, globalPosY: number) {
			let localPosX = this.me.globalToLocal(new Laya.Point(globalPosX, globalPosY)).x;
			let localPosY = this.me.globalToLocal(new Laya.Point(globalPosX, globalPosY)).y;
			this.icon.x = localPosX;
			this.icon.y = localPosY;
		}

		public getCheckPos(): Laya.Vector2 {
			return new Laya.Vector2(this.me.x + Item_Craft.offset.x + this.icon.x - this.origin_pos.x, this.me.y + Item_Craft.offset.y + this.icon.y - this.origin_pos.y);
		}

		//显示是否在区域内
		public setInArea(in_area: boolean) {
			//经过区域时显示放大缩小的动画
			if (this.craft_id && !this.moving) {
				if (in_area && !this.tip_in_area.visible) {
					this.playAnim('mouse_over');
					// console.log('play mouse over anim');

				} else if (!in_area && this.tip_in_area.visible) {
					this.playAnim('mouse_remove');
					// console.log('play mouse remove anim');
				}
			}

			// this.tip_order.alpha = in_area ? 0 : 1;
			if (!this.tip_order.visible) {
				this.tip_in_area.visible = in_area;
			}
			
		}

		public showGenerateAnim() {
			this.playAnim('item_show');

		}

		public showEffect() {
			UI_Activity_Combining.Inst.createEffect(this.me, new Laya.Point(0, 0), false);
		}

		public showBonusCreateEffect() {
			UI_Activity_Combining.Inst.createEffect(this.me, new Laya.Point(0, 0), true);
		}

		public playBreatheAnim() {
			if (this.playing_breathe_anim) return;
			// this._anim_start_time = Laya.timer.currTimer;
			this.playing_breathe_anim = true;
			this.icon.scale(1, 1);
			// Laya.timer.frameLoop(1, this, this._update);
			this.playAnim('tip_drag', true);
		}

		public stopBreatheAnim() {
			this.playing_breathe_anim = false;
			this.stopAnim('tip_drag');
			this.icon.scale(1, 1);
			Laya.timer.clearAll(this);
		}

		public pauseBreatheAnim() {
			if (!this.playing_breathe_anim) return;
			this.stopAnim('tip_drag');
			this.icon.scale(1, 1);
			Laya.timer.clearAll(this);
		}

		public resumeBreatheAnim() {
			if (!this.playing_breathe_anim) return;
			this.playAnim('tip_drag', true);
		}

		public setTipOrderVisible(visible: boolean, isAnim: boolean = false) {
			if (visible) {
				if (!this.tip_order.visible && isAnim) {
					this.playAnim('tip0_o');
				} else {
					this.playAnim('tip0_i');
				}

			} else {
				if (this.tip_order.visible && isAnim) {
					this.playAnim('tip0_c');
				}
			}
			this.tip_order.visible = visible;
		}

		public close() {
			Laya.timer.clearAll(this);
			Laya.Tween.clearAll(this.icon);
			this.icon.skin = '';
			this.stopAllAnim();
			this.playAnim('idle');
		}


		private runningAnims: Array<string> = [];
		public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
			this.animBase[name].play(0, isLoop);
			this.runningAnims.push(name);
			this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
				if (onComplete) {
					onComplete.run();
				}
				this.runningAnims = this.runningAnims.filter(anim => anim !== name);
			});
		}

		public stopAnim(name: string) {
			// console.log('stop anim',this.index, name);
			
			this.animBase[name].stop();
		}

		public stopAllAnim() {
			for (let animName of this.runningAnims) {
				this.stopAnim(animName);
			}
			this.runningAnims = [];
		}

		/**
		 * icon当前的中心位置，全局坐标
		 */
		public get center(): Laya.Vector2 {
			//转成世界坐标的中心位置
			if (!this.icon) return new Laya.Vector2(0, 0);
			let worldPos = this.icon.localToGlobal(new Laya.Point(this.icon.width / 2, this.icon.height / 2));
			return new Laya.Vector2(worldPos.x, worldPos.y);
		}

	}

	export class UI_Activity_Combining extends UIBase {
		public static Inst: UI_Activity_Combining;
		public static activity_id: number = 250601;
		public static workbench: Object = {};
		public static orders: Array<game.IActivityCombiningOrderData>;
		public static recyble_bin: game.IActivityCombiningWorkbench;
		public static currency_item_id: number = 30900090;
		public static point_item_id: number = 30900091;
		public static unlocked_craft: Array<number>;

		private static daily_bonus_count: number = 0;
		private static lastUpdateBonusTime: number = 0;
		/**
		 * 每日已经获得的小费数量，如果上次刷新时间已经跨天了，则重置为0
		 */
		public static get dailyBonusCount(): number {
			if (!game.Tools.isPassedRefreshTimeServer(this.lastUpdateBonusTime)) {
				this.dailyBonusCount = 0;
			}
			return this.daily_bonus_count;

		}

		public static set dailyBonusCount(count: number) {
			this.daily_bonus_count = count;
			this.lastUpdateBonusTime = Math.floor(game.Tools.getServerTime() / 1000);
		}


		public static get unlock_craft_count(): number {
			let _count = UI_Bag.get_item_count(this.point_item_id);
			let _craft_count = 0;
			let datas = cfg.activity.combining_map.getGroup(this.activity_id);
			for (let data of datas) {
				if (data.point_item_count <= _count) {
					_craft_count = data.workbench_count;
				} else {
					break;
				}
			}
			return _craft_count;
		}

		public static getCraftData(craft_id: number): lqc.Sheet_Activity_CombiningCraft {
			return cfg.activity.combining_craft.get(craft_id);
		}

		public static update_data(datas: Array<any>) {
			for (let data of datas) {
				if (data.activity_id == this.activity_id) {
					// app.Log.log('UI_Activity_Combining.update_data' + JSON.stringify(data));
					this.workbench = {};
					for (let workbench of data.workbench) {
						this.workbench[workbench.pos] = workbench.craft_id;
					};
					this.orders = data.orders;
					this.recyble_bin = data.recyble_bin;
					this.unlocked_craft = data.unlocked_craft;
					this.dailyBonusCount = data.daily_bonus_count;

				}
			}
		}

		public static getOrderInfo(pos: number) {
			if (!this.orders) return null;
			let _day = UI_Activity.getActivityDeltaDay(this.activity_id);
			for (let order of this.orders) {
				if (order.pos == pos && order.unlock_day <= _day) {
					return order;
				}
			}
		}

		public static getAcitivityInfo(): lqc.Sheet_Activity_CombiningActivityInfo {
			return cfg.activity.combining_activity_info.get(UI_Activity_Combining.activity_id);
		}

		public static have_redpoint(): boolean {
			if (UI_Activity_Combining_Reward.haveRedPoint() || UI_Activity_Combining_Task.haveRedPoint()) return true;
			if (!this.orders) return false;
			let _day = UI_Activity.getActivityDeltaDay(this.activity_id);
			for (let order of this.orders) {
				if (order.unlock_day <= _day) {
					for (let key in this.workbench) {
						// if (this.workbench[key] == order.craft_ids) {
						// 	return true;
						// }
						let needComplete: Array<number> = game.Tools.deepCopy(order.craft_id);
						let completes: Array<number> = game.Tools.deepCopy(order.finished_craft_id);
						//两个数组求差集
						for (let complete of completes) {
							let index = needComplete.indexOf(complete);
							if (index != -1) {
								needComplete.splice(index, 1);
							}
						}
						for (let index = 0; index < needComplete.length; index++) {
							const element = needComplete[index];
							if (this.workbench[key] == element) {
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		public list_item_order: Array<Item_Order>;
		public list_item_craft: Array<Item_Craft>;

		private order_empty: Laya.Sprite;

		private btn_recycle: Laya.Button;
		public btn_recovery: Laya.Button;
		private recycle_reward: Laya.Sprite;
		private label_recycle_reward: Laya.Label;
		private icon_recycle_reward: Laya.Image;

		private top: Laya.Sprite;
		private label_currency0: UI_ScrollText;
		private label_currency1: UI_ScrollText;

		private btn_bin0: Laya.Button;
		private btn_bin1: Laya.Button;
		private lock_bin1: Laya.Sprite;
		private unlock_bin1: Laya.Sprite;
		private costLabel0: Laya.Label;
		private costLabel1: Laya.Label;
		private recycle_tip: Laya.Sprite;

		private moving: boolean;
		private moving_item: Item_Craft;
		private in_area_item: Item_Craft;
		private move_start_x: number;
		private move_start_y: number;
		private unlock_count: number;
		private activityFinishHandler: Laya.Handler;

		private task_redpoint: Laya.Sprite;
		private reward_redpoint: Laya.Sprite;

		// 无操作两秒后，展示可合成的呼吸动画
		private last_operation_time: number;
		private showing_can_combining: boolean;

		private item_pos_list: Array<Array<number>> = [[17, 9, 1, 2, 13, 21], [18, 10, 3, 4, 14, 22], [19, 11, 5, 6, 15, 23], [20, 12, 7, 8, 16, 24]];
		public locking: boolean;

		private base_data: lqc.Sheet_Activity_CombiningActivityInfo;

		private effects: Array<game.UIEffect> = [];
		private bgRoot: Laya.Image;
		private desktop_bg: Laya.Image;
		private recycleFlyStartPos: Laya.Vector2;
		private animBase: ui.lobby.combining.activity_combiningUI;
		private tipShowTime: number = 4000; // 用于判断是否展示提示
		private craftFlyStartPoses: basic.Dictionary<number, Laya.Vector2> = new basic.Dictionary<number, Laya.Vector2>();
		private craftFlyBinIcon: basic.Dictionary<number, Laya.Sprite> = new basic.Dictionary<number, Laya.Sprite>();
		private flyItemParent: Laya.Sprite;
		private newPopUpWaitTime: number = 300;

		// ==DevDebug Start==
		public static staticCharIds: Array<number> = [-1, -1, -1];
		// ==DevDebug End==


		constructor() {
			super(new ui.lobby.combining.activity_combiningUI());
			UI_Activity_Combining.Inst = this;
			this.animBase = this.me as ui.lobby.combining.activity_combiningUI;
		}

		public onCreate(): void {
			this.list_item_order = [];
			for (let i = 0; i < 3; i++) {
				let other = new ui.lobby.combining.activity_combining_char_otherUI();
				other.name = 'other';
				let order = this.me.getChildByName('orders').getChildByName('' + i) as Laya.Sprite;
				order.getChildByName('other_root').addChild(other);
				this.list_item_order.push(new Item_Order(order, i, other));
			}
			this.order_empty = this.me.getChildByName('orders').getChildByName('empty') as Laya.Sprite;
			this.list_item_craft = [];
			let main = this.me.getChildByName('main') as Laya.Sprite;
			let itemParent = main.getChildByName('items') as Laya.Sprite;
			for (let i = 0; i < 4 * 6; i++) {
				let _spr = new ui.lobby.combining.activity_combining_itemUI();
				_spr.name = i.toString();
				itemParent.addChild(_spr);
				this.list_item_craft.push(new Item_Craft(_spr, i, this.item_pos_list[Math.floor(i / 6)][i % 6] - 1));
			}

			this.btn_recycle = main.getChildByName('btn_recycle') as Laya.Button;
			this.btn_recovery = main.getChildByName('btn_recovery') as Laya.Button;
			this.recycle_reward = this.btn_recycle.getChildByName('reward') as Laya.Sprite;
			this.recycle_tip = this.btn_recycle.getChildByName('recycle_tip') as Laya.Sprite;
			this.label_recycle_reward = this.recycle_reward.getChildByName('count') as Laya.Label;
			this.icon_recycle_reward = this.recycle_reward.getChildByName('icon') as Laya.Image;
			this.btn_recovery.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.locking = true;
				app.NetAgent.sendReq2Lobby('Lobby', 'recoverCombiningRecycle', {
					activity_id: UI_Activity_Combining.activity_id,
				}, (err, res) => {
					this.locking = false;
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('recoverCombiningRecycle', err, res);
					} else {
						UI_Activity_Combining.workbench[res['pos']] = res['craft_id'];
						for (let item of this.list_item_craft) {
							if (item.pos == res['pos']) {
								item.refresh(res['craft_id']);
							}
						}
						this.checkAllOrder();
						this.btn_recovery.visible = false;
					}
				});
			});

			this.btn_bin0 = main.getChildByName('right').getChildByName('btn1').getChildByName('btn_bin_0') as Laya.Button;
			this.btn_bin1 = main.getChildByName('right').getChildByName('btn2').getChildByName('btn_bin_1') as Laya.Button;
			this.lock_bin1 = this.btn_bin1.getChildByName('lock') as Laya.Sprite;
			this.unlock_bin1 = this.btn_bin1.getChildByName('unlock') as Laya.Sprite;

			this.btn_bin0.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.onBinBtnClick(0);

			});
			this.btn_bin1.clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				if (this.lock_bin1.visible) return; // 未解锁
				this.onBinBtnClick(1);
			});

			this.top = this.me.getChildByName('top') as Laya.Sprite;
			(this.top.getChildByName('left').getChildByName('btn_info') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_Activity_Combining_Yindao.Inst.show();
			});
			(this.top.getChildByName('left').getChildByName('btn_back') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				this.close();
			});
			(this.top.getChildByName('btn_menu') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_Activity_Combining_Menu.Inst.show();
			});
			(this.top.getChildByName('btn_task') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_Activity_Combining_Task.Inst.show();
			});
			(this.top.getChildByName('btn_reward') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_Activity_Combining_Reward.Inst.show();
			});
			this.task_redpoint = this.top.getChildByName('btn_task').getChildByName('redpoint') as Laya.Sprite;
			this.reward_redpoint = this.top.getChildByName('btn_reward').getChildByName('redpoint') as Laya.Sprite;

			this.label_currency0 = new UI_ScrollText(this.top.getChildByName('currency').getChildByName('0').getChildByName('count') as Laya.Label);
			(this.top.getChildByName('currency').getChildByName('0').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_ItemDetail.Inst.show(UI_Activity_Combining.currency_item_id);
			});
			this.label_currency1 = new UI_ScrollText(this.top.getChildByName('currency').getChildByName('1').getChildByName('count') as Laya.Label);
			(this.top.getChildByName('currency').getChildByName('1').getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
				if (this.locking) return;
				UI_ItemDetail.Inst.show(UI_Activity_Combining.point_item_id);
			});


			this.me.on('mousedown', this, this.mouseDown);
			this.me.on('mouseup', this, this.mouseUp);
			this.me.on('mousemove', this, this.mouseMove);
			this.me.on('mouseover', this, this.mouseEnd);
			this.me.on('mouseout', this, this.mouseEnd);

			this.base_data = cfg.activity.combining_activity_info.get(UI_Activity_Combining.activity_id);
			//添加道具数量刷新
			UI_Bag.add_item_listener(UI_Activity_Combining.point_item_id, new Laya.Handler(this, () => {
				this.refreshPointCount();
			}));
			UI_Bag.add_item_listener(UI_Activity_Combining.currency_item_id, new Laya.Handler(this, () => {
				this.setCoinCount(UI_Bag.get_item_count(UI_Activity_Combining.currency_item_id));
			}));
			let _cost = this.base_data.craft_bin_price[0].split('-');
			this.costLabel0 = this.btn_bin0.getChildByName('cost') as Laya.Label;
			this.costLabel1 = this.btn_bin1.getChildByName('unlock').getChildByName('cost') as Laya.Label;
			this.costLabel0.text = _cost[1];
			_cost = this.base_data.craft_bin_price[1].split('-');
			this.costLabel1.text = _cost[1];
			(this.btn_bin1.getChildByName('lock').getChildByName('count') as Laya.Label).text = game.Tools.strOfLocalization(4010, [this.base_data.craft_bin_unlock[1].toString()]);
			app.NetAgent.addListener2Lobby('NotifyAccountUpdate', new Laya.Handler(this, msg => {
				let __data = msg['update'];
				if (__data && __data.activity_period_task && __data.activity_period_task.progresses) {
					Laya.timer.once(100, this, () => {
						this.refreshRedPoint();
					})
				}

			}));
			this.bgRoot = this.me.getChildByName('bg') as Laya.Image;
			this.desktop_bg = this.me.getChildByName('main').getChildByName('desktop_bg') as Laya.Image;
			//加载ui背景
			// game.LoadMgr.setImgSkin(this.bg, 'myres/activity_combining/bg.jpg')
			//加载桌面背景
			game.LoadMgr.setImgSkin(this.desktop_bg, 'myres/activity_combining/bg_desktop.png');
			let startPoint = this.btn_recycle.localToGlobal(new Laya.Point(this.btn_recycle.width / 2, this.btn_recycle.height / 2));
			this.recycleFlyStartPos = new Laya.Vector2(startPoint.x, startPoint.y);
			// 初始化合成道具飞行起始位置
			this.flyItemParent = this.me.getChildByName('fly_items') as Laya.Sprite;

			let craft1Pos = (this.btn_bin0.getChildByName('item1') as Laya.Sprite).localToGlobal(new Laya.Point(50, 50));
			this.craftFlyBinIcon.set(11001, this.btn_bin0.getChildByName('item1') as Laya.Sprite);
			this.craftFlyStartPoses.set(11001, new Laya.Vector2(craft1Pos.x, craft1Pos.y));
			let craft2Pos = (this.btn_bin0.getChildByName('item2') as Laya.Sprite).localToGlobal(new Laya.Point(50, 50));
			this.craftFlyBinIcon.set(12001, this.btn_bin0.getChildByName('item2') as Laya.Sprite);
			this.craftFlyStartPoses.set(12001, new Laya.Vector2(craft2Pos.x, craft2Pos.y));
			let craft3Pos = (this.btn_bin1.getChildByName('unlock').getChildByName('item1') as Laya.Sprite).localToGlobal(new Laya.Point(50, 50));
			this.craftFlyBinIcon.set(13001, this.btn_bin1.getChildByName('unlock').getChildByName('item1') as Laya.Sprite);
			this.craftFlyStartPoses.set(13001, new Laya.Vector2(craft3Pos.x, craft3Pos.y));
			let craft4Pos = (this.btn_bin1.getChildByName('unlock').getChildByName('item2') as Laya.Sprite).localToGlobal(new Laya.Point(50, 50));
			this.craftFlyBinIcon.set(14001, this.btn_bin1.getChildByName('unlock').getChildByName('item2') as Laya.Sprite);
			this.craftFlyStartPoses.set(14001, new Laya.Vector2(craft4Pos.x, craft4Pos.y));
			this.activityFinishHandler = new Laya.Handler(this, msg => {
				this.onActivityFinish(msg);
			});

		}

		public onEnable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Combining', true);
			app.NetAgent.addListener2Lobby('NotifyActivityChange', this.activityFinishHandler);

		}

		public onDisable() {
			game.TempImageMgr.setUIEnable('UI_Activity_Combining', false);
			app.NetAgent.removeListener2Lobby('NotifyActivityChange', this.activityFinishHandler);

			Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_combining.atlas'));
			this.stopAllSounds();
			for (let index = 0; index < this.list_item_order.length; index++) {
				let item = this.list_item_order[index];
				item.reset();
				item.onClose();
			}
			this.stopAllAnim();
			this.playAnim('char1_i');
			this.playAnim('char2_i');
			this.playAnim('char3_i');
			for (let item of this.list_item_craft) {
				item.close();
			}
			this.destroyEffects();

		}

		public show() {

			this.last_operation_time = Laya.timer.currTimer;
			this.showing_can_combining = false;
			this.enable = true;
			UI_Activity_Combining_Yindao.pre_load();
			if (!game.LocalStorage.getGuide(UI_Activity_Combining.activity_id)) {
				UI_Activity_Combining_Yindao.Inst.show();
				game.LocalStorage.setGuide(UI_Activity_Combining.activity_id);
			}
			this.refreshPointCount();
			this.refreshRedPoint();
			this.setCoinCount(UI_Bag.get_item_count(UI_Activity_Combining.currency_item_id), false);
			this.setPointCount(UI_Bag.get_item_count(UI_Activity_Combining.point_item_id), false);
			this.showRecycleTip(false);

			let index = 0;
			for (let item of this.list_item_order) {
				let order = UI_Activity_Combining.getOrderInfo(index);

				if (!order) {
					item.show([], 0);

				} else {
					let charId = order.char_id;
					// ==DevDebug Start==
					let staticCharId = UI_Activity_Combining.staticCharIds[index];
					if (staticCharId > 0) {
						charId = staticCharId;
					}
					// ==DevDebug End==
					item.show(order.craft_id, charId, order.finished_craft_id);
				}

				let animName = 'char' + (index + 1) + '_o';
				UI_Activity_Combining.Inst.playAnim(animName);
				++index;
			}
			for (let item of this.list_item_craft) {
				item.refresh(UI_Activity_Combining.workbench[item.pos]);
			}

			this.checkAllOrderDone();
			this.checkAllOrder();
			this.btn_recovery.visible = false;
			this.recycle_reward.visible = false;
			this.locking = true;
			this.playAnim('show', false, Laya.Handler.create(this, () => {
				this.locking = false;
			}));
			view.AudioMgr.StopMusic(0);
			this.stopBgm();
			this.playBgm();
			this.playAnim('bear_idle', true);
		}

		public close() {

			this.locking = true;
			this.last_operation_time = Laya.timer.currTimer;
			this.clearAllCombiningBreathe();

			this.playAnim('close', false, Laya.Handler.create(this, () => {
				
				this.enable = false;
				UI_Lobby.Inst.enable = true;
			}))

		}


		public mouseDown() {
			if (this.locking) return;
			if (this.moving) return;
			let x = this.me.mouseX;
			let y = this.me.mouseY;
			let _item = this.getInAreaCraftItem(x, y);
			if (_item && _item.locking) {
				// UIMgr.Inst.ShowErrorInfo1(game.Tools.strOfLocalization(4038, [_item.unlock_count.toString()]));
				UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25060006, [_item.unlock_count.toString()]));
				UI_SecondConfirm.Inst.setBtnState(true, true);
			} else if (_item && _item.craft_id) {
				this.moving = true;
				this.moving_item = _item;
				this.move_start_x = x;
				this.move_start_y = y;
				_item.onMouseDown();
				let mousePosX = Laya.stage.mouseX;
				let mousePosY = Laya.stage.mouseY;
				this.moving_item.onMouseMove(mousePosX, mousePosY);
				_item.me.parent.setChildIndex(_item.me, 23); // 放到最上层
				for (let item of this.list_item_craft) {
					item.pauseBreatheAnim();
				}
				this.clearAllCombiningBreathe();
				//如果是最高级小费，则提示回收
				if (_item.data.if_bonus && _item.data.level == 3) {
					this.showRecycleTip(true);
				}
			}


		}

		public mouseMove() {
			if (this.moving) {
				let mousePosX = Laya.stage.mouseX;
				let mousePosY = Laya.stage.mouseY;
				this.moving_item.onMouseMove(mousePosX, mousePosY);

				let pos = this.moving_item.center;
				let _item = this.getInAreaCraftItem(pos.x, pos.y);
				//如果当前item不等于之前的区域内item,将之前的item设置为不在区域内
				if (this.in_area_item && _item && this.in_area_item.index != _item.index) {
					this.in_area_item.setInArea(false);
					this.in_area_item = null;
				}
				if (this.in_area_item && !_item) {
					this.in_area_item.setInArea(false);
					this.in_area_item = null;
				}

				if (_item && !_item.locking) {
					this.in_area_item = _item;
					_item.setInArea(true);
				}

				//如果拖拽的有物体，则路过的浣熊的时候显示放大动画
				if (this.moving_item) {

					this.playRaconScaleAnim(this.checkRecycle(pos.x, pos.y));
				}

			}
		}

		// 拖动结束
		public mouseUp() {
			if (!this.moving) return;
			this.showRecycleTip(false);
			if (this.in_area_item) {
				this.in_area_item.setInArea(false);
				this.in_area_item = null;
			}
			for (let item of this.list_item_craft) {
				item.resumeBreatheAnim();
			}
			this.last_operation_time = Laya.timer.currTimer;
			// for (let item of this.list_item_craft) {
			// 	item.resumeBreatheAnim();
			// }
			let mousePosX = Laya.stage.mouseX;
			let mousePosY = Laya.stage.mouseY;
			this.moving_item.onMouseMove(mousePosX, mousePosY);
			let pos = this.moving_item.center;
			let pre_craft_id = this.moving_item.craft_id;
			this.moving_item.moving = false;
			{
				let item = this.getInAreaCraftItem(pos.x, pos.y);
				if (item && item != this.moving_item) {
					// 如果
					if (item.locking) {
						this.mouseEnd();
						return;
					} else if (!item.craft_id || item.craft_id != pre_craft_id) {
						let from_item = this.moving_item;
						let to_item = item;
						let to_craft_id = item.craft_id;
						to_item.refresh(from_item.craft_id);
						from_item.refresh(to_craft_id);
						// 先变，如果挂了再还原
						this.locking = true;
						app.NetAgent.sendReq2Lobby('Lobby', 'moveCombiningCraft', {
							activity_id: UI_Activity_Combining.activity_id,
							from: this.moving_item.pos,
							to: item.pos
						}, (err, res) => {
							this.locking = false;
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('moveCombiningCraft', err, res);
								// 报错了，还原成之前的样子
								to_item.refresh(to_craft_id);
								from_item.refresh(from_item.craft_id);
							} else {
								this.btn_recovery.visible = false;
								if (res['bonus']) {
									for (let item of this.list_item_craft) {
										if (item.pos == res['bonus']['pos']) {
											item.refresh(res['bonus']['craft_id']);
											item.showGenerateAnim();
											break;
										}
									}
								}
							}

						});
					} else {
						let from_item = this.moving_item;
						let to_item = item;
						let _upgrade_id = this.moving_item.data.upgrade_craft_id;
						if (!_upgrade_id) {
							from_item.onMouseOver();
							this.moving_item = null;
							this.moving = false;
							return;
						}
						to_item.refresh(_upgrade_id,true);
						to_item.showGenerateAnim();
						to_item.showEffect();
						//如果是小费，则还需播放小费特效
						if (UI_Activity_Combining.getCraftData(_upgrade_id).if_bonus) {
							to_item.showBonusCreateEffect();
						}
						from_item.refresh(0);
						this.checkAllOrder(true);
						view.AudioMgr.PlayAudio(10001);
						// 先变，如果挂了再还原
						this.locking = true;
						let _is_new = UI_Activity_Combining.unlocked_craft.indexOf(_upgrade_id) == -1;
						app.NetAgent.sendReq2Lobby('Lobby', 'moveCombiningCraft', {
							activity_id: UI_Activity_Combining.activity_id,
							from: this.moving_item.pos,
							to: item.pos
						}, (err, res) => {
							
							if (err || res['error']) {
								UIMgr.Inst.showNetReqError('moveCombiningCraft', err, res);
								// 报错了，还原成之前的样子
								to_item.refresh(pre_craft_id);
								from_item.refresh(pre_craft_id);
								this.checkAllOrder();
								this.locking = false;
							} else {
								this.btn_recovery.visible = false;
								if (res['bonus']) {
									for (let item of this.list_item_craft) {
										if (item.pos == res['bonus']['pos']) {
											item.refresh(res['bonus']['craft_id']);
											item.showGenerateAnim();
											break;
										}
									}
								}

								if (_is_new) {
									
									Laya.timer.once(this.newPopUpWaitTime, this, () => {
										UI_Activity_Combining_New.Inst.show(_upgrade_id);
										this.locking = false;

									});
								} else {
									this.locking = false;
								}
							}
						});

					}
					this.moving_item = null;
					this.moving = false;
					return;
				}
			}

			// 丢到回收站
			if (this.checkRecycle(pos.x, pos.y)) {
				let from_item = this.moving_item;
				this.locking = true;
				let is_bonus = from_item.data.if_bonus;
				from_item.refresh(0);
				//播放回收按钮动画
				Laya.Tween.to(this.btn_recycle, { scaleX: 0.8, scaleY: 0.8 }, 100, null, Laya.Handler.create(this, () => {
					Laya.Tween.to(this.btn_recycle, { scaleX: 1, scaleY: 1 }, 100);
				}));
				let oldPointCount = UI_Bag.get_item_count(UI_Activity_Combining.point_item_id);
				app.NetAgent.sendReq2Lobby('Lobby', 'combiningRecycleCraft', { activity_id: UI_Activity_Combining.activity_id, pos: from_item.pos }, (err, res) => {
					this.locking = false;
					if (err || res['error']) {
						UIMgr.Inst.showNetReqError('combiningRecycleCraft', err, res);
						from_item.refresh(pre_craft_id);// 还原
					} else {
						let rewards = res['reward_items'];
						if (!rewards || rewards.length == 0) return;
						let _id: number = rewards[0]['reward']['id'];
						let _count: number = rewards[0]['reward']['count'];
						if (game.GameUtility.get_id_type(_id) == game.EIDType.currency) {
							let d_currency = cfg.item_definition.currency.get(_id);
							game.LoadMgr.setImgSkin(this.icon_recycle_reward, d_currency.icon, null, 'UI_Activity_Combining');
						} else {
							let d_item = cfg.item_definition.item.get(_id);
							game.LoadMgr.setImgSkin(this.icon_recycle_reward, d_item.icon_transparent, null, 'UI_Activity_Combining');
						}
						this.btn_recovery.visible = !is_bonus;
						this.label_recycle_reward.text = '+' + _count.toString();
						this.recycle_reward.visible = true;
						this.recycle_reward.alpha = 0;
						UI_Activity_Combining.Inst.checkAllOrder();
						// 播放
						this.recycle_reward.y = -19;
						Laya.Tween.to(this.recycle_reward, { alpha: 1 }, 200);
						Laya.Tween.to(this.recycle_reward, { alpha: 0, y: - 60 }, 200, null, Laya.Handler.create(this, () => {
							this.recycle_reward.visible = false;
						}), 400);
						//成功回收小费，播放飞币动画
						if (is_bonus) {
							this.createPointCoin(this.recycleFlyStartPos, _count, Laya.Handler.create(this, () => {
								this.setPointCount(oldPointCount + _count, true);
							}));
							view.AudioMgr.PlayAudio(10002);
						} 
						this.stopAnim('bear_idle');
						this.playAnim('bear_use', false, Laya.Handler.create(this, () => {
							this.playAnim('bear_idle', true);
						}));
					}
				});
				this.moving_item = null;
				this.moving = false;
				return;
			}

			//
			for (let item of this.list_item_order) {
				if (item.checkInArea(pos.x, pos.y)) {
					let from_item = this.moving_item;
					let oldPointCount = UI_Bag.get_item_count(UI_Activity_Combining.point_item_id);
					let orderPrice = item.orderPrice;
					if (item.onOrderChooesd(from_item.craft_id, from_item.pos, Laya.Handler.create(this, (success: boolean) => {
						this.locking = false;
						if (!success) {
							// 失败了还原
							from_item.refresh(pre_craft_id);
							UI_Activity_Combining.Inst.checkAllOrder();
						} else {
							//成功完成订单
							if (item.state == E_Order_State.complete) {

								this.createPointCoin(item.charaCenter, orderPrice, Laya.Handler.create(this, () => {
									this.setPointCount(oldPointCount + orderPrice, true);
								}));
							}

							UI_Activity_Combining.Inst.checkAllOrder();
						}
					}))) {
						this.locking = true;
						this.btn_recovery.visible = false;
						view.AudioMgr.PlayAudio(10002);
						from_item.refresh(0);
					} else {
						this.mouseEnd();
					}
					this.moving_item = null;
					this.moving = false;
					return;
				}
			}
			//如果全为空
			this.mouseEnd();

		}

		// 拖动结束
		public mouseEnd() {
			if (!this.moving) return;
			this.moving = false;
			this.moving_item.onMouseOver();
			this.moving_item = null;
		}

		private checkRecycle(x: number, y: number): boolean {
			return this.btn_recycle.hitTestPoint(x, y);
		}

		private refreshPointCount() {
			let _point_count = UI_Bag.get_item_count(UI_Activity_Combining.point_item_id);
			// this.label_currency1.text = _point_count.toString();
			let _unlock_count = UI_Activity_Combining.unlock_craft_count;
			if (this.unlock_count != _unlock_count) {
				this.unlock_count = _unlock_count;
				for (let item of this.list_item_craft) {
					item.refreshUnlockState(_unlock_count);
				}
			}

			if (_point_count >= this.base_data.craft_bin_unlock[1]) {
				this.unlock_bin1.visible = true;
				this.lock_bin1.visible = false;
			} else {
				this.unlock_bin1.visible = false;
				this.lock_bin1.visible = true;
			}
		}

		public refreshRedPoint() {
			this.task_redpoint.visible = UI_Activity_Combining_Task.haveRedPoint();
			this.reward_redpoint.visible = UI_Activity_Combining_Reward.haveRedPoint();
		}

		private getInAreaCraftItem(x: number, y: number): Item_Craft {
			let _x = x - 388;
			let _y = y - 542;
			let _item = this.list_item_craft[0];
			if (_x < 0 || _y < 0) return null;
			if (_x % Item_Craft.per_width > _item.me.width || _y % Item_Craft.per_height > _item.me.height) {
				return null;
			}
			let _index_x = Math.floor(_x / Item_Craft.per_width);
			let _index_y = Math.floor(_y / Item_Craft.per_height);
			if (_index_x < 6 && _index_y < 4) {
				return this.list_item_craft[_index_y * 6 + _index_x];
			}
			return null;
		}

		// 检查是否是可提交订单
		public checkOrder(item: Item_Craft, isAnim: boolean = false) {
			let hasCraft = false;
			if (item.craft_id) {
				for (let _item_order of this.list_item_order) {
					if (_item_order.state == E_Order_State.normal) {
						let craftIndex = _item_order.getMatchItem(item.craft_id);
						if (craftIndex != -1) {
							_item_order.setBgState(true, craftIndex, isAnim);
							hasCraft = true;
						}
					}
				}
			}
			item.setTipOrderVisible(hasCraft, isAnim);
		}

		// 刷新所有订单可领取状态
		public checkAllOrder(isAnim: boolean = false) {
			// console.log('checkAllOrder', isAnim);
			
			for (let item_order of this.list_item_order) {
				//遍历每个item,检查是否有可以提交的订单
				if (item_order.state == E_Order_State.normal) {
					let craftIndexs: Array<number> = [];
					for (let _item of this.list_item_craft) {
						if (_item.craft_id) {
							let craftIndex = item_order.getMatchItem(_item.craft_id);
							if (craftIndex != -1) {
								craftIndexs.push(craftIndex);
							}
						}
					}
					for (let index = 0; index < 2; index++) {
						if (craftIndexs.indexOf(index) != -1) {
							item_order.setBgState(true, index, isAnim);
						} else {
							item_order.setBgState(false, index, isAnim);
						}
					}
				}
				
			}
			for (let _item of this.list_item_craft) {
				this.checkOrder(_item, isAnim);
			}
		}

		// 检查是否已满
		private checkWorkBenchFull(): boolean {
			for (let i = 0; i < this.unlock_count; i++) {
				if (!UI_Activity_Combining.workbench[i]) {
					return false;
				}
			}
			return true;
		}

		// 检查订单是否已全部完成
		public checkAllOrderDone(isAnim: boolean = false): void {
			for (let i = 0; i < 3; i++) {
				if (UI_Activity_Combining.getOrderInfo(i)) {
					this.order_empty.visible = false;
					return;
				}
			}
			for (let index = 0; index < this.list_item_order.length; index++) {
				const element = this.list_item_order[index];
				if (element.state != E_Order_State.empty) {
					// 有订单正在播放动画
					return;
				}
			}
			this.order_empty.visible = true;
			let isAllEmpty = !UI_Activity_Combining.orders || UI_Activity_Combining.orders.length == 0;
			(this.order_empty.getChildByName('today') as Laya.Sprite).visible = !isAllEmpty;
			(this.order_empty.getChildByName('all') as Laya.Sprite).visible = isAllEmpty;
			if (isAnim) {
				this.playAnim('char_empty_show');
			}

			
		}

		public update(): void {
			if (!this.enable) {
				return;
			}
			if (!this.showing_can_combining && !this.moving) {
				if (Laya.timer.currTimer - this.last_operation_time >= this.tipShowTime) {
					this.startShowCombiningBreathe();
				}
			}
		}

		// 只有1组呼吸 
		private startShowCombiningBreathe() {
			//如果有最高级小费，显示呼吸动画
			for (let index = 0; index < this.list_item_craft.length; index++) {
				const element = this.list_item_craft[index];
				if (element.data && element.data.if_bonus && !element.data.upgrade_craft_id) {
					element.playBreatheAnim();
					this.showing_can_combining = true;
				}

			}
			//如果有可以组合的物品，显示呼吸动画，仅显示一组
			let length = this.list_item_craft.length;
			for (let i = 0; i < length; i++) {
				let _item = this.list_item_craft[i];
				if (_item.data && _item.data.upgrade_craft_id) {
					for (let j = i + 1; j < length; j++) {
						if (this.list_item_craft[j].craft_id == _item.craft_id) {
							_item.playBreatheAnim();
							this.list_item_craft[j].playBreatheAnim();
							this.showing_can_combining = true;
							return;
						}
					}
				}
			}
			//没有可以组合的物品，但是有钱，显示菜板呼吸
			if (this.checkWorkBenchFull()) {
				// 已满
				return;
			}

			for (let index = 0; index < 2; index++) {
				let _cost = this.base_data.craft_bin_price[index].split('-');
				if (UI_Bag.get_item_count(Number(_cost[0])) < Number(_cost[1])) {
					// 货币不足
					return;
				}
				//如果是第二个要检查是否已经解锁
				if (index == 1 && this.lock_bin1.visible) {
					// 未解锁
					return;
				}
				this.playAnim('bin' + (index + 1) + '_tip', true);
				this.showing_can_combining = true;
				
			}


		}
		private clearAllCombiningBreathe() {
			if (!this.showing_can_combining) return;
			this.showing_can_combining = false;
			for (let item of this.list_item_craft) {
				item.stopBreatheAnim();
			}
			this.stopAnim('bin1_tip');
			this.stopAnim('bin2_tip');
		}

		public createEffect(target: Laya.Sprite, offset: Laya.Point, isBonus: boolean = false) {
			let effect = game.FrontEffect.Inst.create_ui_effect(target, isBonus ? 'scene/effect_25liaoliwu_cat.lh' : 'scene/effect_25liaoliwu_hecheng.lh', offset, 1);
			this.effects.push(effect);
			Laya.timer.once(1300, this, () => {
				effect.destory();
				for (let i = 0; i < this.effects.length; i++) {
					if (this.effects[i] == effect) {
						this.effects.splice(i, 1);
						return;
					}
				}
			})
		}

		private destroyEffects() {
			for (let i = 0; i < this.effects.length; i++) {
				this.effects[i].destory();
			}
			this.effects = [];
		}

		private runningAnims: Array<string> = [];
		public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
			this.animBase[name].play(0, isLoop);
			this.runningAnims.push(name);
			this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
				if (onComplete) {
					onComplete.run();
				}
				this.runningAnims = this.runningAnims.filter(anim => anim !== name);
			});
		}

		public stopAnim(name: string) {
			// console.log('stop main anim', name);
			this.animBase[name].stop();
		}

		public stopAllAnim() {
			for (let animName of this.runningAnims) {
				this.stopAnim(animName);
			}
			this.runningAnims = [];
		}

		private onBinBtnClick(index: number) {
			if (this.checkWorkBenchFull()) {
				// 提示已满
				UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25060010));
				UI_SecondConfirm.Inst.setBtnState(true, true);
				return;
			}
			let _cost = this.base_data.craft_bin_price[index].split('-');
			if (UI_Bag.get_item_count(Number(_cost[0])) < Number(_cost[1])) {
				// 货币不足
				UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(25060011));
				UI_SecondConfirm.Inst.setBtnState(true, true);

				return;
			}
			this.locking = true;
			let pre_unlocked = UI_Activity_Combining.unlocked_craft;
			app.NetAgent.sendReq2Lobby('Lobby', 'generateCombiningCraft', {
				activity_id: UI_Activity_Combining.activity_id,
				bin_id: this.base_data.craft_bin[index]
			}, (err, res) => {
				
				if (err || res['error']) {
					this.locking = false;
					UIMgr.Inst.showNetReqError('generateCombiningCraft', err, res);
				} else {
					let craftId = res['craft_id'];
					let needShowNew = false;
					if (!pre_unlocked || pre_unlocked.indexOf(res['craft_id']) == -1) {
						let _data = cfg.activity.combining_craft.get(res['craft_id']);
						if (_data.level != 1) {
							needShowNew = true;
						}
					}
					if (!needShowNew) {
						this.locking = false;
					}
					let onComplete = Laya.Handler.create(this, () => {
						
						//0.3秒后显示新弹窗,解除锁定，不需要显示，直接解除锁定
						if (needShowNew) {
							Laya.timer.once(this.newPopUpWaitTime, this, () => {
								UI_Activity_Combining_New.Inst.show(res['craft_id']);
								this.locking = false;
							});
						} 
						this.btn_recovery.visible = false;
						this.checkAllOrder(true);
						this.clearAllCombiningBreathe();
						this.last_operation_time = Laya.timer.currTimer;
					});
					if (craftId) {
						UI_Activity_Combining.workbench[res['pos']] = res['craft_id'];
						let block = this.list_item_craft.find(item => item.pos == res['pos']);
						if (block) {
							// block.refresh(res['craft_id']);
							// block.showGenerateAnim();
							//生成飞行物，飞行完毕后刷新
							let flyCraftId = res['craft_id'];
							switch (flyCraftId) {
								case 11001:
								case 11002:
									flyCraftId = 11001;
									break;
								case 12001:
								case 12002:
									flyCraftId = 12001;
									break;
								case 13001:
								case 13002:
									flyCraftId = 13001;
									break;
								case 14001:
								case 14002:
									flyCraftId = 14001;
									break;
								default:
									flyCraftId = -1;
									break;
							}
							if (flyCraftId == -1) {
								block.refresh(res['craft_id']);
								block.showGenerateAnim();
								//如果是小费，需要显示小费特效
								if (UI_Activity_Combining.getCraftData(res['craft_id']).if_bonus) {
									block.showBonusCreateEffect();
								}
								onComplete.run();
								
							} else {
								let startPos = this.craftFlyStartPoses.get(flyCraftId);
								let endPos = block.center;
								let icon = this.craftFlyBinIcon.get(flyCraftId);
								icon.visible = false;
								this.createFlyCraft(flyCraftId, startPos, endPos, Laya.Handler.create(this, () => {
									block.refresh(res['craft_id'], true);
									block.showGenerateAnim();
									icon.visible = true;
									//如果是2级Item，显示合成特效
									if (UI_Activity_Combining.getCraftData(res['craft_id']).level == 2) {
										block.showEffect();
									}
									onComplete.run();
								}));
							}
						}
					} else {
						onComplete.run();
					}


				}
			});
		}


		private refreshCostColor() {
			//如果货币不足，则显示红色
			let cost0 = Number(this.costLabel0.text);
			let cost1 = Number(this.costLabel1.text);
			this.costLabel1.color = UI_Bag.get_item_count(UI_Activity_Combining.currency_item_id) < cost1 ? '#ff4f57' : '#ffecd6';
			this.costLabel0.color = UI_Bag.get_item_count(UI_Activity_Combining.currency_item_id) < cost0 ? '#ff4f57' : '#ffecd6';
		}

		public setCoinCount(count: number, isLabelTween: boolean = true) {
			if (isLabelTween) {
				//滚动
				this.label_currency0.change(count);
			} else {
				this.label_currency0.set(count)
			}
			this.refreshCostColor();
		}

		public setPointCount(count: number, isLabelTween: boolean = true) {
			if (isLabelTween) {
				//滚动
				this.label_currency1.change(count);
			} else {
				this.label_currency1.set(count);
			}

		}

		private runningSounds: Array<number> = [];
		public playSound(soundPath: string, onCompletet?: Laya.Handler) {
			let sound_id = view.AudioMgr.PlaySound(soundPath, view.AudioMgr.yuyinVolume, onCompletet);
			this.runningSounds.push(sound_id);
			return sound_id;
		}

		private stopAllSounds() {
			for (let sound_id of this.runningSounds) {
				view.AudioMgr.StopAudio(sound_id);
			}
			this.stopBgm();
			view.BgmListMgr.PlayLobbyBgm();
			this.runningSounds = [];
		}

		public showRecycleTip(visible: boolean) {

			this.recycle_tip.visible = visible;
			if (visible) {
				this.playAnim('bear_tip', true);
			} else {
				this.stopAnim('bear_tip');
			}
		}
		private coinSign: string = "combining_coin";
		private coinEndPos: Laya.Vector2 = new Laya.Vector2(1685, 63);
		private coinFlyDuration: number = 500;
		public createPointCoin(startPos: Laya.Vector2, price: number, onComplete: Laya.Handler) {
			let coinCount = Math.floor(price / this.base_data.one_coin_num);
			coinCount = coinCount == 0 ? 1 : Math.min(coinCount, this.base_data.coin_num_max);
			let coinList: UI_FlyItem[] = new Array();
			let lastUpX = true;
			let lastUpY = true;
			let range = 120;
			for (let index = 0; index < coinCount; index++) {
				let currentIndex = index;
				let coin = UI_FlyItemFactory.Inst.createFlyItem(this.coinSign, Laya.Image);
				let coinImg = coin.me as Laya.Image;
				coinImg.skin = game.Tools.localUISrc("myres/activity_combining/currency1.png");
				coinImg.anchorX = 0.5;
				coinImg.anchorY = 0.5;
				coinImg.width = 45;
				coinImg.height = 45;
				coinImg.x = startPos.x;
				coinImg.y = startPos.y;
				let randomX = Math.random() * range;
				randomX = lastUpX ? -randomX : randomX;
				lastUpX = randomX > 0;
				let randomY = Math.random() * range;
				randomY = lastUpY ? -randomY : randomY;
				lastUpY = randomY > 0;
				let coinStartPos: Laya.Vector2 = new Laya.Vector2(startPos.x + randomX, startPos.y + randomY);

				//用tween动画飞到指定位置
				Laya.Tween.to(coinImg, { x: coinStartPos.x, y: coinStartPos.y }, 200, null, null, 0);
				this.flyItemParent.addChild(coinImg);
				coinList.push(coin);
				Laya.timer.once(200, this, () => {
					coin.doStraightMoveAnim(0, coinStartPos, this.coinEndPos, this.coinFlyDuration, new Laya.Handler(this, () => {
						UI_FlyItemFactory.Inst.recycleFlyItem(coin);
						if (currentIndex == 0) {
							//第一个金币飞到
							onComplete?.run();
						}
					}))
				});

			}
		}

		private audioId: number;
		public stopBgm() {
			if (this.audioId) {
				view.AudioMgr.StopAudio(this.audioId);
				this.audioId = 0;
			}
		}

		private playBgm() {
			if (view.AudioMgr.musicMuted) return;
			let audioPath = cfg.audio.audio.get(10000).path;
			let volume = view.AudioMgr.musicVolume;
			// this.audioId = view.AudioMgr.PlayLoopSound(audioPath, volume);
			view.AudioMgr.PlayMusic(audioPath,0,true,true,true);
		}

		private isRaconScaler: boolean = false;
		private playRaconScaleAnim(in_area: boolean) {
			if (in_area && !this.isRaconScaler) {
				this.isRaconScaler = true;
				this.playAnim('bottle_over');
			} else if (!in_area && this.isRaconScaler) {
				this.isRaconScaler = false;
				this.playAnim('bottle_remove');
			}
		}

		private bgScene: Laya.Scene;
		public initScene() {
			if (this.bgScene) {
				let bg = this.bgScene.getChildByName('root').getChildAt(0) as Laya.Sprite3D;
				bg.active = false;
				bg.active = true;
				return;
			}
			this.bgScene = Laya.loader.getRes('scene/effect_25liaoliwu_bg.ls') as Laya.Scene;
			this.bgRoot.addChild(this.bgScene);
		}

		public destroyScene() {
			this.bgScene?.destroy();
			this.bgScene = null;
		}

		private craftSign: string = "combining_craft";
		private craftFlyDuration: number = 300;
		public createFlyCraft(craftId: number, startPos: Laya.Vector2, endPos: Laya.Vector2, onComplete: Laya.Handler) {
			let data = UI_Activity_Combining.getCraftData(craftId);
			let craft = UI_FlyItemFactory.Inst.createFlyItem(this.craftSign, Laya.Image);
			let craftImg = craft.me as Laya.Image;
			craftImg.skin = game.Tools.localUISrc('myres/activity_combining/' + data.img_name);
			craftImg.anchorX = 0.5;
			craftImg.anchorY = 0.5;
			craftImg.width = 105;
			craftImg.height = 105;
			craftImg.x = startPos.x;
			craftImg.y = startPos.y;
			this.flyItemParent.addChild(craftImg);
			let controlPosX = startPos.x + (endPos.x - startPos.x) / 2;
			let controlPosY = startPos.y - 200 + (endPos.y - startPos.y) / 2;
			let controlPos = new Laya.Vector2(controlPosX, controlPosY);
			craft.doBezierMoveAnimTween(0, startPos, controlPos, endPos, this.craftFlyDuration, Laya.Handler.create(this, () => {
				UI_FlyItemFactory.Inst.recycleFlyItem(craft);
				onComplete?.run();
			}));
		}

		public onActivityFinish(msg) {
			if (this.enable == false) {
				if (UI_Lobby.Inst.enable) {
					UI_Lobby.Inst.refreshInfo();
				}
				return;
			}
			if (msg.end_activities) {
				for (let i: number = 0; i < msg.end_activities.length; i++) {
					let id = msg.end_activities[i];
					if (id == UI_Activity_Combining.activity_id) {
						UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(4437), new Laya.Handler(this, () => {
							UI_Activity_Combining_Yindao.Inst.close(true);
							UI_Activity_Combining_Menu.Inst.close();
							UI_Activity_Combining_Reward.Inst.close();
							UI_Activity_Combining_Task.Inst.close();
							UI_Activity_Combining_New.Inst.close();
							this.close();
						}))
						return;
					}
				}
			}

		}

	}
}