module uiscript {
    class MenuCell {
        public me: Laya.Sprite;
        private items: Array<{unknown: Laya.Image, icon: Laya.Image, id: number}>;

        public constructor(me: Laya.Sprite, index: number) {
            this.me = me;
            this.items = [];
            let _count = index == 4 ? 3 : 5;
            for (let i = 0; i < _count; i++) {
                let item = this.me.getChildByName('items').getChildByName('item' + i) as Laya.Sprite;
                let icon = item.getChildByName('icon') as Laya.Image;
                let id = index * 1000 + i + 1001 + 10000;
                let _data = cfg.activity.combining_craft.get(id);
                icon.skin = game.Tools.localUISrc('myres/activity_combining/' + _data.img_name);
                let btn = icon.getChildByName('btn') as Laya.Button;
                btn.clickHandler = new Laya.Handler(this, () => {
                    UI_Activity_Combining_New.Inst.show(id, false);
                });
                this.items.push({unknown: item.getChildByName('unknown') as Laya.Image, icon, id});
            }
        }

        public show() {
            for (let item of this.items) {
                if (UI_Activity_Combining.unlocked_craft.indexOf(item.id) != -1) {
                    item.unknown.visible = false;
                    item.icon.visible = true;
                } else {
                    item.unknown.visible = true;
                    item.icon.visible = false;
                }
            }
        }

    }

    export class UI_Activity_Combining_Menu extends UIBase {
        public static Inst: UI_Activity_Combining_Menu = null;

        public btn_close: Laya.Button;
        private templetes: Array<MenuCell> = [];
        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private animBase: ui.lobby.combining.activity_combining_menuUI;
        public locking: boolean;

        constructor() {
            super(new ui.lobby.combining.activity_combining_menuUI());
            UI_Activity_Combining_Menu.Inst = this;
        }

        public onCreate() {
            this.animBase = this.me as ui.lobby.combining.activity_combining_menuUI;
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
           
            this.btn_close = this.root.getChildByName('close') as Laya.Button;
            this.btn_close.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            let content = this.root.getChildByName('content') as Laya.Sprite;
            for (let i = 0; i < 5; i++) {
                this.templetes.push(new MenuCell(content.getChildByName('templete' + i) as Laya.Sprite, i));
            }
        }


        public onShow() {
            for (let item of this.templetes) {
                item.show();
            }
        }

        public show() {
            Laya.timer.clearAll(this);  
            this.enable = true;
            this.locking = true;
            this.onShow();
            this.playAnim('show', false, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public close() {
            this.locking = true;
            UI_Activity_Combining.Inst.refreshRedPoint();
            this.playAnim('hide', false, Laya.Handler.create(this, () => {
                this.enable = false;
                this.locking = false;
            }));
        }

        public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
            this.animBase[name].play(0, isLoop);
            if (onComplete) {
                this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
                    onComplete.run();
                });
            }
        }

        public stopAnim(name: string) {
            this.animBase[name].stop();
        }
    }
}