module uiscript {
    export class UI_Activity_Combining_New extends UIBase {
        public static Inst: UI_Activity_Combining_New = null;
        private eff: Laya.Sprite;
        private effStatic: Laya.Sprite;
        private root: Laya.Sprite;
        private icon: Laya.Image;
        private effect: game.UIEffect;
        private starsParent: Laya.Sprite;
        private maxStarCount: number = 5;
        private itemName: Laya.Label
        private itemIntro: Laya.Label;
        private titleImg: Laya.Image;
        private animBase: ui.lobby.combining.activity_combining_newUI;
        public locking: boolean;


        constructor() {
            super(new ui.lobby.combining.activity_combining_newUI());
            UI_Activity_Combining_New.Inst = this;
        }

        public onCreate() {
            let maskBtn = this.me.getChildAt(0).getChildAt(0) as Laya.Button;
            maskBtn.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.icon = this.root.getChildByName('icon') as Laya.Image;
            this.starsParent = this.root.getChildByName('stars') as Laya.Sprite;
            let intro = this.root.getChildByName('intro') as Laya.Sprite;
            this.itemName = intro.getChildByName('item_name') as Laya.Label;
            this.itemIntro = intro.getChildByName('item_intro') as Laya.Label;
            this.titleImg = this.root.getChildByName('title') as Laya.Image;
            this.animBase = this.me as ui.lobby.combining.activity_combining_newUI;
            this.eff = this.root.getChildByName('eff') as Laya.Sprite;
            this.effStatic = this.root.getChildByName('eff_static') as Laya.Sprite;


        }



        /**
         * 
         * @param id 
         * @param isNew 是否是发现新菜品，如果不是，则不显示标题 
         * @returns 
         */
        public show(id: number, isNew: boolean = true) {
            if (!id) return;
            let data = cfg.activity.combining_craft.get(id);
            if (isNew) {
                if (data.if_bonus || data.level == 1) return;
                view.AudioMgr.PlayAudio(10003);
            }
            this.eff.visible = isNew;
            this.effStatic.visible = !isNew;

            Laya.timer.clearAll(this);
            this.enable = true;
            this.icon.skin = game.Tools.localUISrc('myres/activity_combining/' + data.img_name);
            this.showStars(data.level);
            this.titleImg.visible = isNew;
            this.itemName.text = game.Tools.eventStrOfLocalization(data.craft_name);
            //如果是小费，则还需要拼接今日可以卖出多少小费
            if (data.if_bonus) {
                let bonusTimes = UI_Activity_Combining.getAcitivityInfo().bonus_daily_limit - UI_Activity_Combining.dailyBonusCount;
                let price = common.ConfigHelper.configString2Array<number>(data.recycling_price)[0][1];
                this.itemIntro.text = game.Tools.eventStrOfLocalization(data.craft_desc, [price.toString(), bonusTimes.toString()]);
            } else {
                this.itemIntro.text = game.Tools.eventStrOfLocalization(data.craft_desc);
            }
            this.locking = true;
            this.playAnim('show', false, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            if (isNew) {
                //播放光
                this.playAnim('light', true);
                //播放星星
                this.playAnim('star', true);
                //播放背景光旋转
                this.playAnim('glow_rot', true);
            }


        }

        public close() {
            this.locking = true;
            if (this.effect) {
                this.effect.destory();
            }
            this.stopAnim('light');
            this.stopAnim('star');
            this.stopAnim('glow_rot');
            this.playAnim('hide', false, Laya.Handler.create(this, () => {
                this.enable = false;
                this.locking = false;
            }));
        }

        private showStars(count: number) {
            let visibleStars: Array<Laya.Image> = [];
            if (count > this.maxStarCount) count = this.maxStarCount;
            for (let i = 0; i < this.maxStarCount; i++) {
                let star = this.starsParent.getChildAt(i) as Laya.Image;
                if (i < count) {
                    star.visible = true;
                    visibleStars.push(star);
                } else {
                    star.visible = false;
                }
            }
            //居中显示
            game.Tools.sprite_align_center(visibleStars, this.starsParent.width / 2);
        }

        public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
            this.animBase[name].play(0, isLoop);
            if (onComplete) {
                this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
                    onComplete.run();
                });
            }
        }

        public stopAnim(name: string) {
            this.animBase[name].stop();
        }


    }
}