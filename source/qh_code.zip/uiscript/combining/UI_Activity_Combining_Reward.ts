module uiscript {
    class TaskCell {
        public me: Laya.Sprite;
        
        private bg: Laya.Image;
        private item_icon: Laya.Image;
        private item_count: Laya.Label;

        private unlock: Laya.Sprite;
        private task_name: Laya.Label;
        private lock_task_name: Laya.Label;
        private btn_get: Laya.Button;
        private getted: Laya.Image;
        private doing: Laya.Image;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;

        private lock: Laya.Sprite;
        private lock_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;

        private origin_rect: UIRect;
        //private reward_count: number = 0;
        private father: UI_Activity_Combining_Reward;

        public constructor(me: Laya.Sprite, father: UI_Activity_Combining_Reward) {
            this.me = me;
            this.father = father;
            this.bg = this.me.getChildAt(0) as Laya.Image;
            this.item_icon = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.origin_rect = UIRect.CreateFromSprite(this.item_icon);
            this.item_count = this.me.getChildByName('item').getChildByName('count') as Laya.Label;

            this.unlock = this.me.getChildByName('unlock') as Laya.Sprite;
            this.task_name = this.unlock.getChildByName('taskname') as Laya.Label;
            this.progress_bar = this.unlock.getChildByName('bar').getChildByName('val') as Laya.Sprite;
            this.progress_label = this.unlock.getChildByName('progress') as Laya.Label;
            this.btn_get = this.unlock.getChildByName('btn_get') as Laya.Button;
            this.getted = this.unlock.getChildByName('received') as Laya.Image;
            this.doing = this.unlock.getChildByName('doing') as Laya.Image;


            (this.me.getChildByName('item').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);

            this.btn_get.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Combining_Reward.Inst.locking) return;
                UI_Activity_Combining_Reward.Inst.locking = true;
                let _id = this.id;
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: _id}, (err, res) => {
                    UI_Activity_Combining_Reward.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        let d_activity_task = cfg.activity.period_task.get(_id);
                        let items = [];
                        let rewards = d_activity_task.reward.split('-');
                        items.push({id: Number(rewards[0]), count: Number(rewards[1])});
                        game.Tools.showRewards({ rewards: items }, null);
                        if (this.id == _id) {
                            this.btn_get.visible = false;
                            this.getted.visible = true;
                            // this.bg.skin = game.Tools.localUISrc('myres/activity_combining/list_panel_4.png');
                        }
                        
                        this.father.task_rewarded(_id);
                        UI_Activity.onPeriodTaskRewarded(_id);
                        this.father.refreshReceiveBtn();
                    }
                });
            });

            this.lock = this.me.getChildByName('lock') as Laya.Sprite;
            this.lock_label = this.lock.getChildByName('time') as Laya.Label;
            this.lock_task_name = this.lock.getChildByName('taskname') as Laya.Label;
        }

        public show(info: any) {
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
            
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            this.lock.visible = d_activity_task.reward_limit_day > delta;
            let reward = d_activity_task.reward.split('-');
            this.item_id = parseInt(reward[0]);
            this.item_count.text = reward[1];
            game.Tools.setItemIcon(this.item_icon, this.origin_rect, this.item_id, 'UI_Activity_Combining', true);
            this.bg.skin = game.Tools.localUISrc(d_activity_task.node_mark == 0 ? 'myres/activity_combining/list_panel_4.png' : 'myres/activity_combining/list_panel_5.png');
            if (d_activity_task.reward_limit_day > delta) {
                this.lock.visible = true;
                this.unlock.visible = false;
                let restSeconds = UI_Activity.getActivityUnLockTimeFrom5(UI_Activity_Combining_Reward.activity_id, d_activity_task.reward_limit_day);
                this.lock_label.text = game.Tools.getLockTimeText1(restSeconds)
                this.lock_task_name.text = d_task_info['desc_' + GameMgr.client_language];

            } else {
                this.lock.visible = false;
                this.unlock.visible = true;
                this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
                
                let counter: number = info.counter;
                if (!counter) counter = 0;
            
                this.progress_bar.width = counter == 0 ? 6 : Math.min(1, counter / d_task_info.target) * 251;
                
                this.progress_label.text = Math.min(counter, d_task_info.target) + '/' + d_task_info.target;
        

                this.getted.visible = false;
                this.btn_get.visible = false;
                this.doing.visible = false;
                
                if (info.rewarded) {
                    this.getted.visible = true;
                }
                else {
                    if (info.achieved) {
                        this.btn_get.visible = true;
                       
                    }
                    else {
                        this.doing.visible = true;
                    }
                }

            }
        }

    }
    export class UI_Activity_Combining_Reward extends UIBase {
        public static activity_id: number = 250604;
        public static Inst: UI_Activity_Combining_Reward = null;

        public static haveRedPoint(): boolean {
            
            let datas = UI_Activity.getPeriodTaskList(UI_Activity_Combining_Reward.activity_id);
            if (datas) {
                let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
                for (let data of datas) {
                    if (data['achieved'] && !data['rewarded']) {
                        let d_task = cfg.activity.period_task.get(data['id']);
                        if (d_task && d_task.reward_limit_day <= delta) {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        private root: Laya.Sprite;
        private bg: Laya.Sprite;

        private scrollview: capsui.CScrollView;
        private empty: Laya.Sprite;

        public locking: boolean;

        private btn_receive_all: Laya.Button;
        private img_receive_all: Laya.Image;
        private tab_index: number;
        private tab_bg_list: Array<{choosed: Laya.Sprite, unchoose: Laya.Sprite,title:Laya.Label}>;

        private all_data_lst: Array<Object> = [];
        private show_data_lst: Array<Object> = [];
        private animBase: ui.lobby.combining.activity_combining_rewardUI;
       

        constructor() {
            super(new ui.lobby.combining.activity_combining_rewardUI());
            UI_Activity_Combining_Reward.Inst = this;
        }

        public onCreate() {
            this.animBase = this.me as ui.lobby.combining.activity_combining_rewardUI;
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            
            (this.root.getChildByName('close') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            
            let tabs = this.root.getChildByName('tabs') as Laya.Sprite;
            (tabs.getChildByName('all') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(0);
            });
            (tabs.getChildByName('achieved') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(1);
            });
            (tabs.getChildByName('doing') as Laya.Button).clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.on_tab_btn_click(2);
            });
            this.tab_bg_list = [];
            this.tab_bg_list.push({
                choosed: tabs.getChildByName('all').getChildByName('choosed') as Laya.Image,
                unchoose: tabs.getChildByName('all').getChildByName('unchoose') as Laya.Image,
                title: tabs.getChildByName('all').getChildAt(2) as Laya.Label
            });
            this.tab_bg_list.push({
                choosed: tabs.getChildByName('achieved').getChildByName('choosed') as Laya.Image,
                unchoose: tabs.getChildByName('achieved').getChildByName('unchoose') as Laya.Image,
                title: tabs.getChildByName('achieved').getChildAt(2) as Laya.Label
            });
            this.tab_bg_list.push({
                choosed: tabs.getChildByName('doing').getChildByName('choosed') as Laya.Image,
                unchoose: tabs.getChildByName('doing').getChildByName('unchoose') as Laya.Image,
                title: tabs.getChildByName('doing').getChildAt(2) as Laya.Label
            });
            let rewards = this.root.getChildByName('rewards') as Laya.Sprite;

            this.scrollview = rewards.scriptMap['capsui.CScrollView'];
            this.scrollview.init_scrollview(new Laya.Handler(this, this.render_item));

            this.empty = this.root.getChildByName('empty') as Laya.Sprite;
            
            this.btn_receive_all = this.root.getChildByName('btn_receive') as Laya.Button;
            this.img_receive_all = this.btn_receive_all.getChildAt(0) as Laya.Image;
            this.btn_receive_all.clickHandler = new Laya.Handler(this, ()=>{
                if (this.locking) return;
                this.onReceiveAllBtnClick();
            }, null, false);
        }


        public onShow() {
            let lst = UI_Activity.getPeriodTaskList(UI_Activity_Combining_Reward.activity_id);
            this.all_data_lst = lst;
            this.refreshReceiveBtn();
            this.tab_index = -1;
            this.on_tab_btn_click(0);
        }

        public show() {
            Laya.timer.clearAll(this);  
            this.enable = true;
            this.locking = true;
            this.onShow();
            let tween_config = { delay: 50, duration: 280, ease: Laya.Ease.quadOut };
            let start_config = { alpha: 0, x_dis: 100 };
            let target_config = { alpha: 1 };
            let items = this.scrollview.items.map((value) => {
                return value.container;
            });
            let list_delay = game.Tools.listSpritesAnim(items, tween_config, start_config, target_config);
            this.playAnim('show', false, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            
        }

        public close() {
            this.locking = true;
            UI_Activity_Combining.Inst.refreshRedPoint();
            this.playAnim('hide', false, Laya.Handler.create(this, () => {
                this.enable = false;
                this.locking = false;
            }));
        }


        public task_rewarded(task_id: number) {
            for (let task of this.all_data_lst) {
                if (task['id'] == task_id) {
                    task['rewarded'] = true;
                    return;
                }
            }
        }

        private on_tab_btn_click(tab_index: number) {
            if (tab_index == this.tab_index) {
                return;
            }
            this.tab_index = tab_index;
            
            for (let i = 0; i < 3; i++) {
                this.tab_bg_list[i].unchoose.visible = tab_index != i;
                this.tab_bg_list[i].choosed.visible = tab_index == i;
                this.tab_bg_list[i].title.color = tab_index == i ? '#89695a' : '#bea294';
            }
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            switch (tab_index) {
                case 0: // 全部
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        this.show_data_lst.push(data);
                    }
                    this.show_data_lst.sort((a, b) => {
                        return this.sortTasks(a as game.ITaskProgress, b as game.ITaskProgress);
                    });
                    break;
                case 2: // 未完成
                    this.show_data_lst = [];
                    for (let data of this.all_data_lst) {
                        if (!data['rewarded'] && !data['achieved']) {
                            let cfgData = cfg.activity.period_task.get(data['id']);
                            if (cfgData.reward_limit_day <= delta) this.show_data_lst.push(data);
                        }
                    }
                    break;
                case 1: // 已完成
                    this.show_data_lst = [];
                    let index = 0;
                    for (let data of this.all_data_lst) {
                        let cfgData = cfg.activity.period_task.get(data['id']);
                        if (cfgData.reward_limit_day > delta) {

                        } else if (!data['rewarded'] && data['achieved']) {
                            this.show_data_lst.splice(index++, 0, data);
                        } else if (data['rewarded']) {
                            this.show_data_lst.push(data);
                        }
                    }
                    break;

            }
           
            this.empty.visible = this.show_data_lst.length == 0;
            this.scrollview.reset();
            this.scrollview.addItem(this.show_data_lst.length);
           
            
        }

        // 获得对应数据排序值
        private getSort(data: Object): number {
            let _sort = 0;
            
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            let cfgData = cfg.activity.period_task.get(data['id']);
            if (cfgData.reward_limit_day <= delta) {
                if (data['achieved'] && !data['rewarded']) {
                    _sort =  0;
                } else if (data['rewarded']) {
                    _sort =  2;
                } else {
                    _sort = 1;
                }
            } else {
                _sort = 3;
            }
            return _sort * 1000 + data['id'] % 1000;
        }


        //刷新一键领取状态
        public refreshReceiveBtn() {
            let _can_receive = false;
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            for (let data of this.all_data_lst) {
                let cfgData = cfg.activity.period_task.get(data['id']);
                if (cfgData && cfgData.reward_limit_day > delta) {
                    continue;
                }
                if (data['achieved'] && !data['rewarded']) {
                    _can_receive = true;
                    break;
                }
            }
            this.btn_receive_all.visible = _can_receive;
           
        }

        private onReceiveAllBtnClick() {
            let delta = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            
            let list: Array<number> = [];
            for (let data of this.all_data_lst) {
                if (data['achieved'] && !data['rewarded']) {
                    let cfgData = cfg.activity.period_task.get(data['id']);
                    if (cfgData && cfgData.reward_limit_day <= delta) {
                        list.push(data['id']);
                    }
                        
                }
            }
            if (list.length == 0) return;
            this.locking = true;
            
            app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTaskBatch', { task_list: list }, (err, res) => {
                this.locking = false;
                if (err || res['error']) {
                    
                    UIMgr.Inst.showNetReqError('completePeriodActivityTaskBatch', err, res);
                } else {
                    let lst = [];
                    for (let id of list) {
                        
                        this.task_rewarded(id);
                        let _data = cfg.activity.period_task.get(id);
                        if (!_data || !_data.reward) continue;
                        let _reward = _data.reward.split('-');
                        let reward_id = Number(_reward[0]);
                        let reward_count = Number(_reward[1]);
                        lst.push({ id: reward_id, count: reward_count });
                    }
                    
                    this.btn_receive_all.visible = false;
                    this.scrollview.wantToRefreshAll();
                    

                    game.Tools.showRewards({ rewards: lst }, null, null);
                }
            })
        }

        private render_item(obj) {
            let container: Laya.Sprite = obj.container;
            let index: number = obj.index;
            let cache_data: Object = obj.cache_data;
            let data = this.show_data_lst[index];
            if (!cache_data['cell']) {
                cache_data['cell'] = new TaskCell(container, this);
            }
            cache_data['cell'].show(data);

        }

        // 排序函数
        private sortTasks(a: game.ITaskProgress, b: game.ITaskProgress) {
            return this.calculateWeight(b) - this.calculateWeight(a);
        }

        private calculateWeight(task: game.ITaskProgress): number {
            let weight = 0;
            if (task.achieved && !task.rewarded) {
                weight += 1000; // 已完成未领取
            } else if (!task.achieved) {
                weight += 500; // 未完成
            } else if (task.achieved && task.rewarded) {
                weight += 300; // 已完成已领取
            }
            if (!this.isTaskUnlock(task.id)) {
                let unlockTime = this.getTaskUnlockTime(task.id);
                weight = -10000 - unlockTime; // 未解锁
            }
            // 使用任务 ID 作为次要排序依据
            return weight - task.id;
        }

        private isTaskUnlock(taskId:number): boolean {
            //从配置表获取当前任务应该进行的时间段
            let taskConfig = cfg.activity.period_task.get(taskId);
            //到哪天才能领取
            let timeLimit = taskConfig.reward_limit_day;
            let activityDeltaTime = UI_Activity.getActivityDeltaDay(UI_Activity_Combining.activity_id);
            if (activityDeltaTime < timeLimit) {
                return false;
            }
            return true;
        }

        private getTaskUnlockTime(taskId:number): number { 
            let taskConfig = cfg.activity.period_task.get(taskId);
            let restSeconds = UI_Activity.getActivityUnLockTime(UI_Activity_Combining_Reward.activity_id, taskConfig.reward_limit_day);
            return restSeconds;
        }

        public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
            this.animBase[name].play(0, isLoop);
            if (onComplete) {
                this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
                    onComplete.run();
                });
            }
        }

        public stopAnim(name: string) {
            this.animBase[name].stop();
        }
    }

    
}