module uiscript {
    class TaskCell {
        public me: Laya.Sprite;
        private item_icon: Laya.Image;
        private item_count: Laya.Label;
        private task_name: Laya.Label;
        private btn_get: Laya.Button;
        private getted: Laya.Image;
        private doing: Laya.Image;
        private progress_bar: Laya.Sprite;
        private progress_label: Laya.Label;

        private id: number = 0;
        private item_id: number = 0;

        public constructor(me: Laya.Sprite) {
            this.me = me;
            this.me.visible = false;
            this.task_name = this.me.getChildByName('taskname') as Laya.Label;
          
            this.item_icon = this.me.getChildByName('item').getChildByName('icon') as Laya.Image;
            this.item_count = this.me.getChildByName('item').getChildByName('count') as Laya.Label;
            this.progress_bar = this.me.getChildByName('bar').getChildByName('val') as Laya.Sprite;
            this.progress_label = this.me.getChildByName('progress') as Laya.Label;
            this.btn_get = this.me.getChildByName('btn_get') as Laya.Button;
            this.getted = this.me.getChildByName('received') as Laya.Image;
            this.doing = this.me.getChildByName('doing') as Laya.Image;
            (this.me.getChildByName('item').getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                UI_ItemDetail.Inst.show(this.item_id);
            }, null, false);

            this.btn_get.clickHandler = new Laya.Handler(this, ()=>{
                if (UI_Activity_Combining_Task.Inst.locking) return;
                UI_Activity_Combining_Task.Inst.locking = true;
                app.NetAgent.sendReq2Lobby('Lobby', 'completePeriodActivityTask', { task_id: this.id }, (err, res) => {
                    UI_Activity_Combining_Task.Inst.locking = false;
                    if (err || res['error']) {
                        UIMgr.Inst.showNetReqError('completePeriodActivityTask', err, res);
                    } else {
                        let d_activity_task = cfg.activity.period_task.get(this.id);
                        let items = [];
                        let rewards = d_activity_task.reward.split('-');
                        items.push({id: Number(rewards[0]), count: Number(rewards[1])});
                        game.Tools.showRewards({ rewards: items }, null);
                        this.btn_get.visible = false;
                        this.getted.visible = true;
                        UI_Activity.onPeriodTaskRewarded(this.id);
                        UI_Activity_Combining_Task.Inst.onGetReward();
                    }
                });
            });
        }

        public show(info: any) {
            this.me.visible = true;
            if (!info) {
                this.me.visible = false;
                return;
            }
            let id = info.id;
            this.id = id;
            let d_activity_task = cfg.activity.period_task.get(info.id);
            let d_task_info = cfg.events.base_task.get(d_activity_task.base_task_id);
      
            this.task_name.text = d_task_info['desc_' + GameMgr.client_language];
            let reward = d_activity_task.reward.split('-');
            
            this.item_id = parseInt(reward[0]);
            let d_view = game.GameUtility.get_item_view(this.item_id);
            game.LoadMgr.setImgSkin(this.item_icon, d_view.icon, null, 'UI_Activity_Combining');
            this.item_count.text = reward[1];
            let counter: number = info.counter;
            if (!counter) counter = 0;
           
            this.progress_bar.width = counter == 0 ? 6 : Math.min(1, counter / d_task_info.target) * 251;
            this.progress_label.text = Math.min(counter, d_task_info.target) + '/' + d_task_info.target;
       

            this.getted.visible = false;
            this.btn_get.visible = false;
            this.doing.visible = false;

            if (info.rewarded) {
                this.getted.visible = true;
            }
            else {
                if (info.achieved) {
                    this.btn_get.visible = true;
                }
                else {
                    this.doing.visible = true;
                }
            }

        }

    }
    export class UI_Activity_Combining_Task extends UIBase {
        public static activity_id: number = 250603;
        public static Inst: UI_Activity_Combining_Task = null;

        public static haveRedPoint(): boolean {
            let datas = UI_Activity.getPeriodTaskList(UI_Activity_Combining_Task.activity_id);
            if (datas) {
                for (let data of datas) {
                    if (data['achieved'] && !data['rewarded']) return true;
                }
            }

            return false;
        }

        public btn_close: Laya.Button;
        private templetes: Array<TaskCell> = [];
        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private receiverAllBtn: Laya.Button;
        public locking: boolean;
        private animBase: ui.lobby.combining.activity_combining_taskUI;

        constructor() {
            super(new ui.lobby.combining.activity_combining_taskUI());
            UI_Activity_Combining_Task.Inst = this;
        }

        public onCreate() {
            this.animBase = this.me as ui.lobby.combining.activity_combining_taskUI;
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
           
            this.btn_close = this.root.getChildByName('close') as Laya.Button;
            this.btn_close.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.close();
            }, null, false);
            let content = this.root.getChildByName('content') as Laya.Sprite;
            for (let i = 0; i < 3; i++) {
                this.templetes.push(new TaskCell(content.getChildByName('task_templete' + i) as Laya.Sprite));
            }
            this.receiverAllBtn = this.root.getChildByName('btn_receive') as Laya.Button;
            this.receiverAllBtn.clickHandler = Laya.Handler.create(this, () => {
                this.completeAllTask();
            }, null, false);
           
        }


        public onShow() {
            let datas = UI_Activity.getPeriodTaskList(UI_Activity_Combining_Task.activity_id);
            for (let i = 0; i < 3; i++) {
                this.templetes[i].show(datas[i]);
            }
            
        }

        public show() {
            Laya.timer.clearAll(this);  
            this.enable = true;
            this.locking = true;
            this.playAnim('show', false, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.onShow();
            this.freshCompleteAll();
        }

        public close() {
            this.locking = true;
            this.playAnim('hide', false, Laya.Handler.create(this, () => {
                this.enable = false;
                this.locking = false;
            }));
            UI_Activity_Combining.Inst.refreshRedPoint();
        }


        public onDisable(): void {
            Laya.timer.clearAll(this);    
        }

        //检查是否有可以完成的任务，有则显示一键领取按钮，无则不显示
        private freshCompleteAll() {
            let needGetList = this.getNeedReceiveTaskList();
            if (needGetList.length > 0) {
                this.receiverAllBtn.visible = true;
            } else {
                this.receiverAllBtn.visible = false;
            }
        }
        
        private getNeedReceiveTaskList(): Array<number> { 
            let needGetList: Array<number> = [];
            let allRewardList = UI_Activity.getPeriodTaskList(UI_Activity_Combining_Task.activity_id);
            for (let data of allRewardList) {
                if (data['achieved'] && !data['rewarded']) {
                    needGetList.push(data['id']);
                }
            }
            return needGetList;
        }


        private completeAllTask() {
            if (this.locking) return;
            //需要领取的奖励的id
            let needGetList = this.getNeedReceiveTaskList();
            if (needGetList.length == 0) return;
            let req: game.IReqCompletePeriodActivityTaskBatch = {
                task_list: needGetList
            }
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY,game.ERequest.completePeriodActivityTaskBatch,req, (err, res) => {
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(game.ERequest.completePeriodActivityTaskBatch, err, res);
                    return;
                }
                let rewardList = [];
                let rewardObj = {};
                for (let id of needGetList) {
                    //更新服务端奖励数据
                    UI_Activity.onPeriodTaskRewarded(id);
                    let d_activity_task = cfg.activity.period_task.get(id);
                    let rewards = d_activity_task.reward.split('-');
                    let rewardId = Number(rewards[0]);
                    let rewardCount = Number(rewards[1]);
                    if (!rewardObj[rewardId]) {
                        rewardObj[rewardId] = rewardCount;
                    } else {
                        rewardObj[rewardId] += rewardCount;
                    }
                   
                }

                for (let key in rewardObj) {
                    rewardList.push({ id: Number(key), count: rewardObj[key] });
                }
                game.Tools.showRewards({ rewards: rewardList }, null, null, 30);
                this.onShow();
                this.onGetReward();
            });
        }

        public onGetReward() {
            this.freshCompleteAll();
            //刷新红点
            UI_Activity_Combining.Inst.refreshRedPoint();
        }

        public playAnim(name: string, isLoop: boolean = false, onComplete?: Laya.Handler) {
            this.animBase[name].play(0, isLoop);
            if (onComplete) {
                this.animBase[name].once(Laya.Event.COMPLETE, this, () => {
                    onComplete.run();
                });
            }
        }

        public stopAnim(name: string) {
            this.animBase[name].stop();
        }
    }
}