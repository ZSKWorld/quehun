module uiscript {
    export class UI_Activity_Combining_Yindao extends UIBase {
        public static Inst: UI_Activity_Combining_Yindao = null;

        private root: Laya.Sprite;
        private bg: Laya.Sprite;
        private btn_left: Laya.Button;
        private btn_right: Laya.Button;
        private point0: Laya.Image;
        private point1: Laya.Image;
        private page: Laya.Image;

        private cur_page: number;
        public locking: boolean;

        private static preloaded: boolean;
        public static pre_load() {
            if (this.preloaded) return;
            if (UI_Activity.activity_is_running(UI_Activity_Combining.activity_id)) {
                this.preloaded = true;
                Laya.loader.load([game.Tools.localUISrc('myres/activity_combining_yindao/page_1.png'), game.Tools.localUISrc('myres/activity_combining_yindao/page_2.png')]);
            }
        }
        constructor() {
            super(new ui.lobby.combining.activity_combining_yindaoUI());
            UI_Activity_Combining_Yindao.Inst = this;
        }

        public onCreate() {
            this.bg = this.me.getChildAt(0) as Laya.Sprite;
            // (this.bg.getChildAt(0) as Laya.Button).clickHandler = new Laya.Handler(this, () => {
            //     if (this.locking) return;
            //     this.close();
            // });

            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.page = this.root.getChildByName('page') as Laya.Image;

            this.point0 = this.root.getChildByName('point_0') as Laya.Image;
            this.point1 = this.root.getChildByName('point_1') as Laya.Image;

            this.btn_left = this.root.getChildByName('btn_left') as Laya.Button;
            this.btn_right = this.root.getChildByName('btn_right') as Laya.Button;
            this.btn_left.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(0);
            });
            this.btn_right.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.show_page(1);
            });

            (this.root.getChildByName('close') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
            // switch (GameMgr.client_language) {
            //     case 'chs':
            //     case 'chs_t':
            //         this.page.width = 1273;
            //         this.page.height = 733;
            //         break;
            //     case 'en':
            //         this.page.width = 1331;
            //         this.page.height = 732;
            //         break;
            //     case 'jp':
            //         this.page.width = 1366;
            //         this.page.height = 734;
            //         break;
            //     case 'kr':
            //         this.page.width = 1289;
            //         this.page.height = 730;
            //         break;
            // }
        }

        private show_page(index: number) {
            this.point0.skin = game.Tools.localUISrc(index == 0 ? 'myres/activity_combining_yindao/tip_page_l.png' : 'myres/activity_combining_yindao/tip_page_d.png');
            this.point1.skin = game.Tools.localUISrc(index == 1 ? 'myres/activity_combining_yindao/tip_page_l.png' : 'myres/activity_combining_yindao/tip_page_d.png');
            this.btn_left.visible = index != 0;
            this.btn_right.visible = index != 1;
            game.LoadMgr.setImgSkin(this.page, 'myres/activity_combining_yindao/page_' + (index + 1) + '.png', null, 'UI_Activity_Combining_Yindao');
        }

        public show() {
            Laya.Tween.to(this.bg, { alpha: 0.5 }, 200);
            this.enable = true;
            this.show_page(0);
            this.locking = true;
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }

        public close(force: boolean = false) {
            this.locking = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
            if (!force) {
                UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                    this.enable = false;
                    this.locking = false;
                    UI_Info_Big.Inst.show(game.Tools.strOfLocalization(25060001));
                }))
            }

        }

        public onEnable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Combining_Yindao', true);
        }

        public onDisable() {
            game.TempImageMgr.setUIEnable('UI_Activity_Combining_Yindao', false);

            Laya.loader.clearTextureRes(game.LoadMgr.getAtlasRoot() + game.Tools.localUISrc('myres/activity_combining_yindao.atlas'));
        }
    }
}