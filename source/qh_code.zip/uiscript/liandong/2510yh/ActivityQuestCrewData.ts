module uiscript {
    interface IQCEmployee {
        id: number;
        str: number;
        spd: number;
        luc: number;
        sta: number;
    }

    export interface IQcChara extends lqc.Sheet_QuestCrew_QcCharacterPool {
        skinConfig: lqc.Sheet_ItemDefinition_Skin;
        charaName: string;
    }
    export interface IQcQuest extends lqc.Sheet_QuestCrew_QcQuestPool {
        skinConfig: lqc.Sheet_ItemDefinition_Skin;
        charaName: string;
    }

    export interface IQcConfig extends lqc.Sheet_QuestCrew_QcInfo {
        refreshPrice: number;
        chargePrice: number;
    }

    export enum EQuestCrewEvent {
        ChargePower = "ChargePower",
        HireEmployee = "HireEmployee",
        RefreshMarket = "RefreshMarket",
        StartQuest = "StartQuest",
        CurrencyChange = "CurrencyChange",
        NewEmployee = "NewEmployee",
    }

    export class ActivityQuestCrewData extends Laya.EventDispatcher {
        private static _inst: ActivityQuestCrewData;
        static get Inst() { return this._inst || (this._inst = new ActivityQuestCrewData()); }

        public activityId: number = 251001;

        public lockNetwork: boolean;
        public qcConfig: IQcConfig;
        public charaPool: basic.Dictionary<number, IQcChara>;
        public questPool: basic.Dictionary<number, IQcQuest>;
        public memberPool: basic.Dictionary<number, game.ITimeCounterData>;
        public qcData: game.IActivityQuestCrewData;
        public marketCount: number = 0;
        /** 人才市场里买来的员工数量 */
        public memberBuyCount: number = 0;
        private bigSucFactor: number = 1.5;
        public currencyCount: number = 0;
        public currencyId: number = 30900095;
        private requestMap: Object;
        private needCheckId: number = 0;
        public duringGuide: boolean = false;
        public afterGuideQuest: boolean = false;
        public tempCurrency: number = 1;
        public inited: boolean = false;

        private constructor() {
            super();
            if (!cfg.quest_crew || !cfg.quest_crew.qc_info) return;
            this.inited = true;
            let config = cfg.quest_crew.qc_info.get(this.activityId);
            if (!config) return;
            this.qcConfig = {
                refreshPrice: Number(config.refresh_market_price.split('-')[1]),
                chargePrice: Number(config.character_charging_price.split('-')[1]),
                ...config
            };
            this.charaPool = new basic.Dictionary();
            this.questPool = new basic.Dictionary();
            this.marketCount = 0;
            let charaGroup = cfg.quest_crew.qc_character_pool.getGroup(this.qcConfig.character_pool_id);
            charaGroup.forEach((value) => {
                let charaConfig: IQcChara = {
                    skinConfig: null,
                    charaName: '',
                    ...value
                };
                if (value.item_id) {
                    let d_chara = cfg.item_definition.character.get(value.item_id);
                    if (d_chara) {
                        charaConfig.charaName = d_chara['name_' + GameMgr.client_language];
                        let d_skin = cfg.item_definition.skin.get(d_chara.init_skin);
                        charaConfig.skinConfig = d_skin;
                    }
                } else {
                    charaConfig.charaName = game.Tools.eventStrOfLocalization(value.name);
                }
                if (value.show_in_market) this.marketCount++;
                this.charaPool.set(value.character_id, charaConfig);
            });
            let questGroup = cfg.quest_crew.qc_quest_pool.getGroup(this.qcConfig.quest_pool_id);
            questGroup.forEach((value) => {
                let questConfig: IQcQuest = {
                    skinConfig: null,
                    charaName: '',
                    ...value
                };
                if (questConfig.client) {
                    questConfig.charaName = game.Tools.eventStrOfLocalization(value.client_name);
                } else {
                    let d_chara = cfg.item_definition.character.get(value.character_id);
                    if (d_chara) {
                        questConfig.charaName = d_chara['name_' + GameMgr.client_language];
                        let d_skin = cfg.item_definition.skin.get(d_chara.init_skin);
                        questConfig.skinConfig = d_skin;
                    }
                }
                this.questPool.set(value.quest_id, questConfig);
            });
            this.bigSucFactor = this.qcConfig.great_success_ceo / 100;
            UI_Bag.add_item_listener(this.currencyId, Laya.Handler.create(this, () => {
                this.currencyCount = UI_Bag.get_item_count(this.currencyId);
            }, null, false));
            this.requestMap = {
                [EQuestCrewEvent.HireEmployee]: game.ERequest.questCrewActivityHire,
                [EQuestCrewEvent.ChargePower]: game.ERequest.questCrewActivityFeed,
                [EQuestCrewEvent.RefreshMarket]: game.ERequest.questCrewActivityRefreshMarket,
                [EQuestCrewEvent.StartQuest]: game.ERequest.questCrewActivityStartQuest,
            }
        }

        public get guideQuestData(): IQcQuest {
            let value: lqc.Sheet_QuestCrew_QcQuestPool = {
                id: 2001, // 委托池id
                quest_id: 20301, // 委托ID
                sort: 0, // 委托排序从小到大s
                type: 0, // 委托种类
                str: 30, // 需求力量
                spd: 30, // 需求速度
                luc: 30, // 需求运气
                unlock_days: 0, // 解锁日，0表示活动开始日
                consume: 2, // 消耗体力值
                rewards: 0, // 赠送qc_character的id
                client: 0, // 委托人种类
                character_id: 200001, // 雀魂雀士id
                client_name: 0, // 委托人名str/event
                quest_desc: 25101059, // 委托描述文str/event
                npc_code: '', // npc素材编号0001-0016
            };
            let questConfig: IQcQuest = {
                skinConfig: null,
                charaName: '',
                ...value
            };
            if (questConfig.client) {
                questConfig.charaName = game.Tools.eventStrOfLocalization(value.client_name);
            } else {
                let d_chara = cfg.item_definition.character.get(value.character_id);
                if (d_chara) {
                    questConfig.charaName = d_chara['name_' + GameMgr.client_language];
                    let d_skin = cfg.item_definition.skin.get(d_chara.init_skin);
                    questConfig.skinConfig = d_skin;
                }
            }
            return questConfig;
        }

        public initData(datas: game.IActivityQuestCrewData[]) {
            if(!this.inited) return;
            this.qcData = {
                activity_id: this.activityId,
                members: [],
                quest_board: [],
                market_board: []
            }
            if (datas) {
                for (let i: number = 0; i < datas.length; i++) {
                    let msg = datas[i];
                    if (msg.activity_id == this.activityId) {
                        for (let key in msg) {
                            const value = msg[key];
                            const valueType = typeof value;
                            if (valueType != 'function') {
                                this.qcData[key] = game.Tools.deepCopy(msg[key]);
                            }
                        }
                    }
                }
            }
            this.currencyCount = UI_Bag.get_item_count(this.currencyId);
            this.refreshData();
        }

        public updateData(msg: { value_changes: game.IActivityQuestCrewChanges }) {
            if (msg.value_changes) {
                if (msg.value_changes.market_board && msg.value_changes.market_board.dirty) this.qcData.market_board = game.Tools.deepCopy(msg.value_changes.market_board.value);
                if (msg.value_changes.members && msg.value_changes.members.dirty) {
                    msg.value_changes.members.value.forEach(value => {
                        let consumed_sta = value.consumed_sta || {} as game.ITimeCounterData;
                        let data = {
                            member_id: value.member_id,
                            consumed_sta: {
                                count: consumed_sta.count || 0,
                                update_time: consumed_sta.update_time || 0
                            }
                        }
                        let index = this.qcData.members.findIndex(_value => _value.member_id == value.member_id);
                        if (index == -1) {
                            this.needCheckId = data.member_id;
                            this.qcData.members.push(data);
                        } else {
                            this.qcData.members[index] = data;
                        }
                    })
                }
                if (msg.value_changes.quest_board && msg.value_changes.quest_board.dirty) {
                    msg.value_changes.quest_board.value.forEach(value => {
                        let data = {
                            quest_id: value.quest_id,
                            finished: value.finished || 0,
                            finished_time: value.finished_time || 0
                        };
                        let index = this.qcData.quest_board.findIndex(_value => _value.quest_id == value.quest_id)
                        if (index == -1) {
                            this.qcData.quest_board.push(data)
                        } else {
                            this.qcData.quest_board[index] = data;
                        }
                    })
                }
            }

            this.refreshData();
        }

        private refreshData() {
            this.memberBuyCount = 0;
            this.memberPool = new basic.Dictionary();
            for (let i = 0; i < this.qcData.members.length; i++) {
                let member = this.qcData.members[i]
                this.memberPool.set(member.member_id, member.consumed_sta);
                if (this.charaPool.get(member.member_id).show_in_market) this.memberBuyCount++;
            }
        }

        get nowQuests(): IQcQuest[] {
            let quests = [];
            let delta_day = UI_Activity.getActivityDeltaDay(this.activityId);
            let completed = []
            this.qcData.quest_board.forEach(value => {
                if (value.finished) completed.push(value.quest_id);
            });
            this.questPool.values().forEach(data => {
                if (data.unlock_days <= delta_day && completed.indexOf(data.quest_id) == -1) {
                    quests.push(data);
                }
            });
            return quests;
        }

        get lockedQuests(): IQcQuest[] {
            let quests = [];
            let delta_day = UI_Activity.getActivityDeltaDay(this.activityId);
            let completed = []
            this.qcData.quest_board.forEach(value => {
                if (value.finished) completed.push(value.quest_id);
            });
            this.questPool.values().forEach(data => {
                if (data.unlock_days > delta_day && completed.indexOf(data.quest_id) == -1) {
                    quests.push(data);
                }
            });
            return quests;
        }

        public getConsumedByCharaId(charaId: number): number {
            if (this.duringGuide) {
                if (this.afterGuideQuest && charaId == 10002) return 1;
                return 3;
            }
            let data = this.memberPool.get(charaId);
            return this.getConsumedSta(data, charaId);
        }

        public getConsumedSta(data: game.ITimeCounterData, charaId: number): number {
            let consumed = 0;
            if (data && data.update_time) {
                if (game.Tools.isPassedRefreshTimeServer(data.update_time) && data.count) {
                    consumed = data.count;
                }
            }
            let charaOrigin = this.charaPool.get(charaId);
            if (charaOrigin) {
                return charaOrigin.sta - consumed;
            }
            return 0;
        }

        public getFeedCount(personCount: number) {
            let oneNeedPower = this.qcConfig.chargePrice;
            return oneNeedPower * personCount;
        }

        public isFishEnough(count: number) {
            if (this.duringGuide) return this.tempCurrency >= count;
            return this.currencyCount >= count;
        }

        public checkEmployee() {
            if (this.needCheckId) {
                this.event(EQuestCrewEvent.NewEmployee, [this.needCheckId]);
                this.needCheckId = 0;
            }
        }


        // 发协议
        sendRequest(eventName: EQuestCrewEvent, param: any, onSuccess?: Laya.Handler) {
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            let currencyCount = UI_Bag.get_item_count(this.currencyId);
            let requestName = this.requestMap[eventName];
            app.Log.log(requestName + ' req ==== ' + JSON.stringify(param));
            app.NetAgent.sendReq2Lobby('Lobby', requestName, param, (err, res) => {
                this.lockNetwork = false;
                if (err || res['error']) {
                    UIMgr.Inst.showNetReqError(requestName, err, res);
                } else {
                    app.Log.log(requestName + ' res ==== ' + JSON.stringify(res));
                    if (res) {
                        if (res.execute_result) {
                            for (let i = 0; i < res.execute_result.length; i++) {
                                let result = res.execute_result[i];
                                if (result && result.id && result.id == this.currencyId) {
                                    this.currencyCount = currencyCount + result.count;
                                }
                            }
                        }
                        this.updateData(res);
                    }
                    let data = res;
                    if (eventName == EQuestCrewEvent.ChargePower) {
                        data = [param.member_id];
                    }
                    this.event(eventName, data);
                    onSuccess && onSuccess.runWith(res);
                }
            });
        }


        public addRandomTeam(quest: IQcQuest): number[] | null {
            let [x, y, z] = [quest.str, quest.spd, quest.luc]
            let employees: IQCEmployee[] = this.memberPool.keys().map(key => {
                let charaConfig = this.charaPool.get(key);
                return {
                    id: key,
                    str: charaConfig.str,
                    spd: charaConfig.spd,
                    luc: charaConfig.luc,
                    sta: this.getConsumedByCharaId(key)
                }
            });
            // 随机打乱员工数组
            const shuffled = this.shuffleArray(employees);
            const n = shuffled.length;

            // 阶段1: 寻找体力满足的组合
            // 检查1人组合
            for (let i = 0; i < n; i++) {
                const emp = shuffled[i];
                if (emp.str >= this.bigSucFactor * x && emp.spd >= this.bigSucFactor * y && emp.luc >= this.bigSucFactor * z) {
                    if (emp.sta >= 1) {
                        return [emp.id];
                    }
                } else if (emp.str >= x && emp.spd >= y && emp.luc >= z) {
                    if (emp.sta >= 2) {
                        return [emp.id];
                    }
                }
            }

            // 检查2人组合
            for (let i = 0; i < n; i++) {
                for (let j = i + 1; j < n; j++) {
                    const emp1 = shuffled[i];
                    const emp2 = shuffled[j];
                    const totalStrength = emp1.str + emp2.str;
                    const totalSpeed = emp1.spd + emp2.spd;
                    const totalLuck = emp1.luc + emp2.luc;
                    if (totalStrength >= this.bigSucFactor * x && totalSpeed >= this.bigSucFactor * y && totalLuck >= this.bigSucFactor * z) {
                        if (emp1.sta >= 1 && emp2.sta >= 1) {
                            return [emp1.id, emp2.id];
                        }
                    } else if (totalStrength >= x && totalSpeed >= y && totalLuck >= z) {
                        if (emp1.sta >= 2 && emp2.sta >= 2) {
                            return [emp1.id, emp2.id];
                        }
                    }
                }
            }

            // 检查3人组合
            for (let i = 0; i < n; i++) {
                for (let j = i + 1; j < n; j++) {
                    for (let k = j + 1; k < n; k++) {
                        const emp1 = shuffled[i];
                        const emp2 = shuffled[j];
                        const emp3 = shuffled[k];
                        const totalStrength = emp1.str + emp2.str + emp3.str;
                        const totalSpeed = emp1.spd + emp2.spd + emp3.spd;
                        const totalLuck = emp1.luc + emp2.luc + emp3.luc;
                        if (totalStrength >= this.bigSucFactor * x && totalSpeed >= this.bigSucFactor * y && totalLuck >= this.bigSucFactor * z) {
                            if (emp1.sta >= 1 && emp2.sta >= 1 && emp3.sta >= 1) {
                                return [emp1.id, emp2.id, emp3.id];
                            }
                        } else if (totalStrength >= x && totalSpeed >= y && totalLuck >= z) {
                            if (emp1.sta >= 2 && emp2.sta >= 2 && emp3.sta >= 2) {
                                return [emp1.id, emp2.id, emp3.id];
                            }
                        }
                    }
                }
            }

            // 阶段2: 如果没有找到体力满足的组合，则寻找属性值满足但不考虑体力的组合
            // 检查1人组合
            for (let i = 0; i < n; i++) {
                const emp = shuffled[i];
                if (emp.str >= x && emp.spd >= y && emp.luc >= z) {
                    return [emp.id];
                }
            }

            // 检查2人组合
            for (let i = 0; i < n; i++) {
                for (let j = i + 1; j < n; j++) {
                    const emp1 = shuffled[i];
                    const emp2 = shuffled[j];
                    const totalStrength = emp1.str + emp2.str;
                    const totalSpeed = emp1.spd + emp2.spd;
                    const totalLuck = emp1.luc + emp2.luc;
                    if (totalStrength >= x && totalSpeed >= y && totalLuck >= z) {
                        return [emp1.id, emp2.id];
                    }
                }
            }

            // 检查3人组合
            for (let i = 0; i < n; i++) {
                for (let j = i + 1; j < n; j++) {
                    for (let k = j + 1; k < n; k++) {
                        const emp1 = shuffled[i];
                        const emp2 = shuffled[j];
                        const emp3 = shuffled[k];
                        const totalStrength = emp1.str + emp2.str + emp3.str;
                        const totalSpeed = emp1.spd + emp2.spd + emp3.spd;
                        const totalLuck = emp1.luc + emp2.luc + emp3.luc;
                        if (totalStrength >= x && totalSpeed >= y && totalLuck >= z) {
                            return [emp1.id, emp2.id, emp3.id];
                        }
                    }
                }
            }

            return [];
        }

        private shuffleArray<T>(array: T[]): T[] {
            const shuffled = array.slice();
            for (let i = shuffled.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
            }
            return shuffled;
        }
    }
}
