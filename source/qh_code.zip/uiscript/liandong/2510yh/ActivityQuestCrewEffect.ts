module uiscript {
    export class QuestCrew_QuestData {
        constructor(questId: number, members: IQcChara[]) {
            this._id = questId;
            this._config = ActivityQuestCrewData.Inst.questPool.get(questId);
            this.members = members;
            if (ActivityQuestCrewData.Inst.duringGuide && questId == 20301) {
                this._config = ActivityQuestCrewData.Inst.guideQuestData;
            }
        }

        private calcGSLine(line: number[]) {
            for (const effect of this._effects) {
                line = effect.calcGSLine(line);
            }
            return line;
        }

        private calcSLine(line: number[]) {
            for (const effect of this._effects) {
                line = effect.calcSLine(line);
            }
            return line;
        }

        private calcPreConsume(member: IQcChara, origin: number) {
            let result = origin;
            for (const effect of this._effects) {
                const changed = effect.calcPreConsume(member, result);
                result = changed;
            }
            for (const effect of this._effects) {
                const changed = effect.calcValidConsume(member, result);
                result = changed;
            }
            return result;
        }

        public calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number) {
            let result = origin;
            for (const effect of this._effects) {
                result = effect.calcAbility(type, member, result);
            }
            return result;
        }

        get totalAbility(): IHYAbility {
            if (!this._totalAbility) {
                const totalSpd = this.members.reduce((pre, member) => {
                    return pre + this.calcAbility(EQuestCrewAbiliy.spd, member, member.spd);
                }, 0);
                const totalStr = this.members.reduce((pre, member) => {
                    return pre + this.calcAbility(EQuestCrewAbiliy.str, member, member.str);
                }, 0);
                const totalLuc = this.members.reduce((pre, member) => {
                    return pre + this.calcAbility(EQuestCrewAbiliy.luc, member, member.luc);
                }, 0);
                const ability = { str: totalStr, spd: totalSpd, luc: totalLuc };
                this._totalAbility = ability;
            }
            return this._totalAbility;
        }

        get consumeAfterEffect(): number[][] {
            let consumes = [[], []];
            for (const member of this.members) {
                consumes[0].push(this.calcPreConsume(member, this.config.consume));
                consumes[1].push(this.calcPreConsume(member, this.config.consume * ActivityQuestCrewData.Inst.qcConfig.great_success_effect_ceo / 100));
            }
            return consumes;
        }

        get targetAbility(): { success: IHYAbility, bigSuccess: IHYAbility } {
            if (!this._targetAbility) {
                const originSLine = [this.config.str, this.config.spd, this.config.luc];
                const finalSLine = this.calcSLine(originSLine);
                const originGSLine = originSLine.map((value) => Math.floor(value * ActivityQuestCrewData.Inst.qcConfig.great_success_ceo / 100));
                const finalGSLine = this.calcGSLine(originGSLine);
                this._targetAbility = {
                    success: { str: finalSLine[0], spd: finalSLine[1], luc: finalSLine[2] },
                    bigSuccess: { str: finalGSLine[0], spd: finalGSLine[1], luc: finalGSLine[2] },
                }
            }
            return this._targetAbility;
        }

        get isBigSuccess(): boolean {
            if (this._isBigSuccess == null) {
                let isBigSuccess = true;
                let totalAbility = this.totalAbility;
                let targetAbility = this.targetAbility;
                for (let i = 0; i < 3; i++) {
                    if (totalAbility[EQuestCrewAbiliy[i + 1]] < targetAbility.bigSuccess[EQuestCrewAbiliy[i + 1]]) {
                        isBigSuccess = false;
                        break;
                    }
                }
                this._isBigSuccess = isBigSuccess;
            }
            return this._isBigSuccess;
        }

        get isSuccess(): boolean {
            if (this._isSuccess == null) {
                let isSuccess = true;
                let totalAbility = this.totalAbility;
                let targetAbility = this.targetAbility;
                for (let i = 0; i < 3; i++) {
                    if (totalAbility[EQuestCrewAbiliy[i + 1]] < targetAbility.success[EQuestCrewAbiliy[i + 1]]) {
                        isSuccess = false;
                        break;
                    }
                }
                this._isSuccess = isSuccess;
            }
            return this._isSuccess;
        }

        get effectedLst(): boolean[] {
            let isEffected = [];
            for (const effect of this._effects) {
                isEffected.push(effect.isEffect());
            }
            return isEffected;
        }

        get config() {
            return this._config;
        }

        get members() {
            return this._members;
        }

        set members(members: IQcChara[]) {
            this._members = members;
            this._effects = [];
            this._members.forEach((member) => {
                if (member.effect) {
                    let type = cfg.quest_crew.qc_effect.get(member.effect).type;
                    let className = EffectTypeMap[type];
                    if (className) {
                        this._effects.push(new className(member.effect, member, this));
                    }
                }
            });
            this._isBigSuccess = null;
            this._isSuccess = null;
            this._targetAbility = null;
            this._totalAbility = null;
        }

        get id(): number {
            return this._id;
        }

        private _config: IQcQuest;
        private _members: IQcChara[];
        private _effects: QuestCrewEffect[];
        private _isBigSuccess: boolean;
        private _isSuccess: boolean;
        private _targetAbility: { success: IHYAbility, bigSuccess: IHYAbility };
        private _totalAbility: IHYAbility;
        private _id: number;
    }

    export class QuestCrewEffect {
        constructor(id: number, member: IQcChara, emitter: QuestCrew_QuestData) {
            this.id_ = id;
            this.member_ = member;
            this.emitter_ = emitter;
        }

        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number) {
            return origin;
        }

        calcPreConsume(member: IQcChara, origin: number) {
            return origin;
        }

        calcValidConsume(member: IQcChara, origin: number) {
            return origin;
        }

        calcGSLine(line: number[]) {
            return line;
        }

        calcSLine(line: number[]) {
            return line;
        }

        isEffect() {
            return false;
        }

        get member() {
            return this.member_;
        }

        get id() {
            return this.id_;
        }

        get args() {
            const effect = cfg.quest_crew.qc_effect.get(this.id_);
            return effect.args;
        }

        protected id_: number;
        protected member_: IQcChara;
        protected emitter_: QuestCrew_QuestData;
    }

    // x名成员共同接受委托时，所有成员的数值+y%
    export class QuestCrewEffect102 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (this.isEffect()) {
                return Math.floor(origin + origin * this.args[1] / 100);
            }
            return origin;
        }

        isEffect() {
            return this.emitter_.members.length == this.args[0];
        }
    }

    // 委托中有员工x[1力量 2速度 3运气]>y时，所有成员的[同上，三围]+z%
    export class QuestCrewEffect105 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (this.args[2] !== type)
                return origin;

            if (this.isEffect()) {
                return Math.floor(origin + origin * this.args[2] / 100);
            }
            return origin;
        }

        isEffect() {
            return this.emitter_.members.some(member => {
                return member[EQuestCrewAbiliy[this.args[0]]] > this.args[1];
            });
        }
    }
    // 委托中有x名员工y【三围】>z时，自己不消耗体力
    export class QuestCrewEffect106 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.members.filter(member => {
                return member[EQuestCrewAbiliy[this.args[1]]] > this.args[2];
            }).length > this.args[0];
        }

        calcPreConsume(member: IQcChara, origin: number): number {
            if (this.isEffect() && member.character_id === this.member.character_id) {
                return 0;
            }
            return origin;
        }
    }

    // 和x[活动角色id]一起参加委托时，所有数值+y%
    export class QuestCrewEffect108 extends QuestCrewEffect {
        isEffect() {
            return !!this.emitter_.members.find(m => m.character_id === this.args[0]);
        }

        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (!this.isEffect())
                return origin;

            if (member.character_id !== this.member.character_id)
                return origin;

            return Math.floor(origin + origin * this.args[1] / 100);
        }
    }

    // 和x[活动角色id]一起参加委托时，不消耗体力，x的消耗体力+y
    export class QuestCrewEffect109 extends QuestCrewEffect {
        calcPreConsume(member: IQcChara, origin: number): number {
            if (!this.emitter_.members.some(m => m.character_id === this.args[0]))
                return origin;

            if (member.character_id === this.member.character_id) {
                return 0;
            }

            if (member.character_id === this.args[0]) {
                return origin + this.args[1];
            }

            return origin;
        }

        isEffect() {
            return this.emitter_.members.some(m => m.character_id === this.args[0]);
        }
    }

    // 和x或y[活动角色id]一起参加委托时，不消耗体力，x或y的消耗体力+z
    export class QuestCrewEffect110 extends QuestCrewEffect {
        calcPreConsume(member: IQcChara, origin: number): number {
            const otherCharacters = [this.args[0], this.args[1]];
            if (!this.emitter_.members.find(m => otherCharacters.includes(m.character_id)))
                return origin;

            if (member.character_id === this.member.character_id) {
                return 0;
            }

            if (otherCharacters.includes(member.character_id)) {
                return origin + this.args[2];
            }

            return origin;
        }

        isEffect() {
            const otherCharacters = [this.args[0], this.args[1]];
            return !!this.emitter_.members.find(m => otherCharacters.includes(m.character_id));
        }
    }


    // 委托的大成功数值要求变动x%
    export class QuestCrewEffect111 extends QuestCrewEffect {
        calcGSLine(line: number[]): number[] {
            return line.map(value => Math.floor(value + value * this.args[0] / 100));
        }

        isEffect() {
            return true;
        }
    }


    // 参与委托的其他员工数值变动x%
    export class QuestCrewEffect112 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (member.character_id === this.member.character_id) {
                return origin;
            }
            return Math.floor(origin + origin * this.args[0] / 100);
        }

        isEffect() {
            return this.emitter_.members.length > 1;
        }
    }

    // x名成员接受委托时，其他员工数值+y%
    export class QuestCrewEffect113 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (this.emitter_.members.length == this.args[0] && member.character_id !== this.member.character_id) {
                return Math.floor(origin + origin * this.args[1] / 100);
            }
            return origin;
        }

        isEffect() {
            return this.emitter_.members.length == this.args[0];
        }
    }

    // 其他员工x【三围】数值+y%
    export class QuestCrewEffect114 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (member.character_id === this.member.character_id)
                return origin;
            if (type === this.args[0])
                return Math.floor(origin + origin * this.args[1] / 100);
            return origin;
        }

        isEffect() {
            return this.emitter_.members.length > 1;
        }
    }

    // 包含自己，所有员工全数值+y%
    export class QuestCrewEffect115 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            return Math.floor(origin + origin * this.args[0] / 100);
        }

        isEffect() {
            return true;
        }
    }

    //包含自己，体力为1时也能完成委托（为0不可）
    export class QuestCrewEffect117 extends QuestCrewEffect {
        calcValidConsume(member: IQcChara, origin: number) {
            return Math.min(1, origin);
        }

        isEffect() {
            return true;
        }
    }

    //委托的成功/大成功数值要求变动x%
    export class QuestCrewEffect118 extends QuestCrewEffect {
        calcGSLine(line: number[]): number[] {
            return line.map(value => Math.floor(value + value * this.args[0] / 100));
        }

        calcSLine(line: number[]): number[] {
            return line.map(value => Math.floor(value + value * this.args[0] / 100));
        }

        isEffect() {
            return true;
        }
    }

    // 委托中包含无技能的员工时，所有成员的x【三围】+y%
    export class QuestCrewEffect120 extends QuestCrewEffect {
        calcAbility(type: EQuestCrewAbiliy, member: IQcChara, origin: number): number {
            if (!this.isEffect()) {
                return origin;
            }

            if (type !== this.args[0])
                return origin;

            return Math.floor(origin + origin * this.args[1] / 100);
        }

        isEffect() {
            return this.emitter_.members.some(member => !member.skill);
        }
    }

    // 满足委托的大成功要求时，自己不消耗体力
    export class QuestCrewEffect121 extends QuestCrewEffect {
        calcPreConsume(member: IQcChara, origin: number): number {
            if (member.character_id !== this.member.character_id)
                return origin;

            if (!this.emitter_.isBigSuccess)
                return origin;

            return 0;
        }

        isEffect() {
            return this.emitter_.isBigSuccess;
        }
    }

    //完成委托时，+x%概率变为大成功
    export class QuestCrewEffect101 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.isSuccess;
        }
    }

    //成功解决委托后，有x%概率获得y物品z个
    export class QuestCrewEffect103 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.isSuccess;
        }
    }

    //委托需要的数值总和超过x时，+y%概率变为大成功
    export class QuestCrewEffect104 extends QuestCrewEffect {
        isEffect() {
            if (this.emitter_.isBigSuccess) return false;
            const questCfg = this.emitter_.config;
            if (questCfg.str + questCfg.luc + questCfg.spd > this.args[0]) {
                return true;
            }
        }
    }

    //委托中有x名员工y【三围】>z时，n%概率获得p物品q个
    export class QuestCrewEffect107 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.members.filter(member => {
                return this.emitter_.calcAbility(this.args[1], member, member[EQuestCrewAbiliy[this.args[1]]]) > this.args[2];
            }).length > this.args[0];
        }
    }

    //包含自己，所有员工+x%概率不消耗体力
    export class QuestCrewEffect116 extends QuestCrewEffect {
        isEffect() {
            return true;
        }
    }

    //x名成员共同接受委托时，大成功概率+y%
    export class QuestCrewEffect119 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.members.length == this.args[0];
        }
    }

    export class QuestCrewEffect122 extends QuestCrewEffect {
        isEffect() {
            return this.emitter_.isBigSuccess;
        }
    }


    const EffectTypeMap = {
        102: QuestCrewEffect102,
        105: QuestCrewEffect105,
        106: QuestCrewEffect106,
        108: QuestCrewEffect108,
        109: QuestCrewEffect109,
        110: QuestCrewEffect110,
        111: QuestCrewEffect111,
        112: QuestCrewEffect112,
        113: QuestCrewEffect113,
        114: QuestCrewEffect114,
        115: QuestCrewEffect115,
        117: QuestCrewEffect117,
        118: QuestCrewEffect118,
        120: QuestCrewEffect120,
        121: QuestCrewEffect121,
        //下边这些是概率触发
        101: QuestCrewEffect101,
        103: QuestCrewEffect103,
        104: QuestCrewEffect104,
        107: QuestCrewEffect107,
        116: QuestCrewEffect116,
        119: QuestCrewEffect119,
        122: QuestCrewEffect122,
    }

}
