module uiscript {
    export const maxQuestAbility = 240;
    export const maxMemberAbility = 90;
    export interface IHYAbility {
        str: number;
        spd: number;
        luc: number;
    }
    export enum EQuestCrewAbiliy {
        none, str, spd, luc
    }

    export class UI_QuestCrew_Ability_SmallBars extends UI_Component {
        private bars: Laya.Sprite[];
        private maxWidth: number = 116;
        public onCreate(): void {
            this.bars = [];
            for (let i = 0; i < 3; i++) {
                this.bars.push((this.me.getChildByName('bar' + i).getChildByName('val') as Laya.Image).mask);
            }
        }

        public refresh(data: IQcChara) {
            for (let i = 0; i < 3; i++) {
                this.bars[i].width = data[EQuestCrewAbiliy[i + 1]] / maxMemberAbility * this.maxWidth;
            }
        }
    }

    export class UI_QuestCrew_Ability_Bars extends UI_Component {

        private imgVal: Laya.Image;
        private mask: Laya.Sprite;
        private imgTarget1: Laya.Image;
        private imgTarget2: Laya.Image;
        private successValue: number;
        private bigSuccessValue: number;
        private maxWidth: number;
        private isSuccess: boolean;
        private isBigSuccess: boolean;
        private nowValue: number;

        public onCreate(): void {
            this.imgVal = this.me.getChildByName('bar').getChildByName('val') as Laya.Image;
            this.mask = this.imgVal.mask;
            let comTarget = this.me.getChildByName('target') as Laya.Sprite;
            this.imgTarget1 = comTarget.getChildByName('progress1') as Laya.Image;
            this.imgTarget2 = comTarget.getChildByName('progress2') as Laya.Image;
            this.maxWidth = this.imgVal.width;
            this.mask.width = 0;
        }

        public setTarget(success: number, bigSuccess: number, refresh: boolean = false) {
            this.successValue = success;
            this.bigSuccessValue = bigSuccess;
            if (refresh) {
                this.isSuccess = this.nowValue >= this.successValue;
                this.isBigSuccess = this.nowValue >= this.bigSuccessValue;
                let [img1, img2] = [this.imgTarget2, this.imgTarget1];
                if (this.isBigSuccess) {
                    [img1, img2] = [this.imgTarget1, this.imgTarget2];
                }
                img1.x = Math.min(this.successValue / maxQuestAbility, 1) * this.maxWidth;
                img2.x = Math.min(this.bigSuccessValue / maxQuestAbility, 1) * this.maxWidth;
                img1.skin = game.Tools.localUISrc('myres/activity_2510questcrew/progress_target1' + (this.isSuccess ? '_done' : '') + '.png');
                img2.skin = game.Tools.localUISrc('myres/activity_2510questcrew/progress_target2' + (this.isBigSuccess ? '_done' : '') + '.png');
            }
        }

        public setVal(value: number, doAnim: boolean = true) {
            if (!this.successValue) return;
            Laya.Tween.clearAll(this.mask);
            Laya.timer.clearAll(this);
            let targetWidth = Math.min(value / maxQuestAbility, 1) * this.maxWidth;
            if (doAnim) {
                let beginValue = this.mask.width / this.maxWidth * maxQuestAbility;
                this.refreshStar(beginValue, false);
                Laya.timer.frameLoop(1, this, () => {
                    let nowValue = this.mask.width / this.maxWidth * maxQuestAbility;
                    this.refreshStar(nowValue);
                })
                Laya.Tween.to(this.mask, { width: targetWidth }, 250, Laya.Ease.quadInOut, Laya.Handler.create(this, () => {
                    Laya.timer.clearAll(this);
                    this.refreshStar(value);
                }));
            } else {
                this.mask.width = targetWidth;
                this.refreshStar(value);
            }

        }

        private refreshStar(value: number, doAnim: boolean = true) {
            this.nowValue = value;
            let isSuccess = value >= this.successValue;
            let isBigSuccess = value >= this.bigSuccessValue;
            if (doAnim && isSuccess == this.isSuccess && isBigSuccess == this.isBigSuccess) return;
            let [img1, img2] = [this.imgTarget2, this.imgTarget1];
            if (isBigSuccess) {
                [img1, img2] = [this.imgTarget1, this.imgTarget2];
            }
            img1.x = Math.min(this.successValue / maxQuestAbility, 1) * this.maxWidth;
            img2.x = Math.min(this.bigSuccessValue / maxQuestAbility, 1) * this.maxWidth;
            img1.skin = game.Tools.localUISrc('myres/activity_2510questcrew/progress_target1' + (isSuccess ? '_done' : '') + '.png');
            img2.skin = game.Tools.localUISrc('myres/activity_2510questcrew/progress_target2' + (isBigSuccess ? '_done' : '') + '.png');
            let needShake = (isSuccess != this.isSuccess && isSuccess) || (isBigSuccess != this.isBigSuccess && isBigSuccess);
            if (needShake) {
                let effetName = (isBigSuccess != this.isBigSuccess && isBigSuccess) ? 'scene/effect_questcrew_star.lh' : 'scene/effect_questcrew_star_blue.lh';
                let effect = game.FrontEffect.Inst.create_ui_effect(this.imgTarget2, effetName, new Laya.Point(-1, -2), 1);
                Laya.timer.once(1000, effect, () => {
                    effect.destory();
                })
            }
            this.isBigSuccess = isBigSuccess;
            this.isSuccess = isSuccess;
        }
    }

    export enum EQuestCrewSort {
        sta,
        str,
        spd,
        luc
    }

    export class UI_QuestCrew_Sort extends UI_Component {

        private father: UI_QuestCrew_QuestDispatch | UI_Activity_QuestCrew_Talent;
        private btnOut: Laya.Button;
        private comPanel: Laya.Sprite;
        private btnBottom: Laya.Button;
        private imgArrow: Laya.Image;
        private btns: Laya.Sprite[];
        private btnCodes: number[] = [25101031, 25101032, 25101033, 25101034];
        private selectIndex: EQuestCrewSort = EQuestCrewSort.sta;

        constructor(me: Laya.Sprite, father: UI_QuestCrew_QuestDispatch | UI_Activity_QuestCrew_Talent) {
            super(me);
            this.father = father;
            this.btnOut = this.me.getChildByName('out') as Laya.Button;
            this.btnOut.clickHandler = Laya.Handler.create(this, this.refreshPanel, [false], false);
            this.comPanel = this.me.getChildByName('pannel') as Laya.Sprite;
            this.btnBottom = this.me.getChildByName('btn') as Laya.Button;
            this.imgArrow = this.btnBottom.getChildByName('arrow') as Laya.Image;
            this.btnBottom.clickHandler = Laya.Handler.create(this, this.refreshPanel, [true], false);
            this.refreshPanel(false, false);
            this.btns = [];
            for (let i = 0; i < this.btnCodes.length; i++) {
                let com = this.comPanel.getChildByName(i.toString()) as Laya.Sprite;
                this.btns.push(com);
                (com.getChildByName('text') as Laya.Label).text = game.Tools.strOfLocalization(this.btnCodes[i]);
                (com.getChildByName('btn') as Laya.Button).clickHandler = Laya.Handler.create(this, () => {
                    this.selectIndex = i;
                    this.father.onSortChange(i);
                    this.refreshPanel(false);
                }, null, false);
            }
        }

        private refreshPanel(open: boolean, doAnim: boolean = true) {
            this.btnOut.visible = open;
            this.comPanel.visible = open;
            let rotation = open ? 0 : 180;
            let alpha = open ? 1 : 0;
            let y = open ? -198 : -146;
            Laya.Tween.clearAll(this.imgArrow);
            Laya.Tween.clearAll(this.comPanel);
            if (doAnim) {
                Laya.Tween.to(this.imgArrow, { rotation: rotation }, 100, null, null, 0, true);
                Laya.Tween.to(this.comPanel, { alpha, y }, 120, Laya.Ease.quadOut, null, 0, true);
            } else {
                this.imgArrow.rotation = rotation;
                this.comPanel.alpha = alpha;
                this.comPanel.y = y;
            }
            (this.btnBottom.getChildByName('title') as Laya.Label).text = game.Tools.strOfLocalization(this.btnCodes[this.selectIndex]);
            (this.btnBottom.getChildByName('icon') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/sort_icon' + this.selectIndex + '.png');
        }

        public reset() {
            this.selectIndex = EQuestCrewSort.sta;
            this.refreshPanel(false, false);
        }
    }

    export class UI_QuestCrew_EmployeeHead extends UI_Component {
        private imgBg: Laya.Image;
        private comPower: Laya.Sprite;
        private txtPowerCount: Laya.Label;
        private comBilitys: UI_QuestCrew_Ability_SmallBars;
        private imgHead: Laya.Image;
        private txtName: Laya.Label;
        private txtDesc: Laya.Label;
        private imgTop: Laya.Image;
        private imgStar: Laya.Image;
        private originFontSize: number;

        onCreate() {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.comPower = this.me.getChildByName('power') as Laya.Sprite;
            if (this.comPower) {
                this.txtPowerCount = this.comPower.getChildByName('count') as Laya.Label;
            }
            this.imgHead = this.me.getChildByName('head') as Laya.Image;
            this.txtName = this.me.getChildByName('name') as Laya.Label;
            this.txtDesc = this.me.getChildByName('desc') as Laya.Label;
            this.imgStar = this.me.getChildByName('star') as Laya.Image;
            let comAbility = this.me.getChildByName('abilitys') as Laya.Sprite;
            if (comAbility) {
                this.comBilitys = new UI_QuestCrew_Ability_SmallBars(comAbility);
            }
            if (this.txtDesc && GameMgr.client_language == 'kr') {
                this.txtDesc.font = 'NotoSansKR';
            }
            if (this.txtDesc) {
                this.originFontSize = this.txtDesc.fontSize;
            }
        }

        refresh(data: IQcChara) {
            let charaType = data.item_id ? 1 : 2;
            game.LoadMgr.setImgSkin(this.imgHead, UI_QuestCrew_Extension.getSkinPath(data, 'bighead'), null, 'UI_Activity_Liandong_Main');
            if (this.txtPowerCount) {
                let count = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
                this.txtPowerCount.text = count.toString();
                this.txtPowerCount.color = count == 0 ? '#ff5e5e' : '#fee77e';
            }
            this.imgBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/staff_end_small_' + charaType + '.jpg');
            if (this.imgTop) this.imgTop.skin = game.Tools.localUISrc('myres/activity_2510questcrew/employee_box_decoration_' + charaType + '.jpg');
            if (this.comBilitys) this.comBilitys.refresh(data);
            if (this.txtDesc) {
                this.txtDesc.text = UI_QuestCrew_Extension.iconReplaceStr + game.Tools.eventStrOfLocalization(data.skill);
            }
            if (this.imgStar) {
                this.imgStar.visible = !!data.skill;
                let scale = this.txtDesc.fontSize / this.originFontSize;
                this.imgStar.scale(scale, scale);
            }
            if (this.txtName) this.txtName.text = data.charaName;
        }

    }
    export class UI_QuestCrew_EmployeeCard extends UI_Component {
        private imgBg: Laya.Image;
        public comPower: Laya.Sprite;
        private txtPowerCount: Laya.Label;
        private comIllust: Laya.Sprite;
        private illust: UI_Character_Skin;
        private imgChara: Laya.Image;
        private comBilitys: UI_QuestCrew_Ability_SmallBars;
        private imgTop: Laya.Image;
        private imgAbilityBg: Laya.Image;
        private btnCard: Laya.Button;
        private btnClose: Laya.Button;
        private clickHandler: Laya.Handler;
        private closeHandler: Laya.Handler;
        private data: IQcChara;

        onCreate() {
            this.comIllust = this.me.getChildByName('illust').getChildByName('illust').getChildByName('container_illust') as Laya.Sprite;
            this.imgChara = this.me.getChildByName('illust').getChildByName('npc') as Laya.Image;
            this.illust = new UI_Character_Skin(this.comIllust.getChildByName('illust') as Laya.Image);
            this.illust.setIllustType(UI_Character_Skin.EIllustType.waitingRoom);
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.imgTop = this.me.getChildByName('top') as Laya.Image;
            this.btnCard = this.me.getChildByName('btn') as Laya.Button;
            this.btnClose = this.me.getChildByName('close') as Laya.Button;
            this.comPower = this.me.getChildByName('power') as Laya.Sprite;
            this.txtPowerCount = this.comPower.getChildByName('count') as Laya.Label;
            this.imgAbilityBg = this.me.getChildByName('ability_bg') as Laya.Image;
            this.comBilitys = new UI_QuestCrew_Ability_SmallBars(this.me.getChildByName('abilitys') as Laya.Sprite);
            this.btnCard.visible = false;
            this.btnClose.visible = false;
            this.btnCard.clickHandler = Laya.Handler.create(this, () => {
                if (this.clickHandler) this.clickHandler.runWith(this.data);
            }, null, false);
            this.btnClose.clickHandler = Laya.Handler.create(this, () => {
                if (this.closeHandler) this.closeHandler.runWith(this.data);
            }, null, false);
        }

        refresh(data: IQcChara, isHire: boolean = false) {
            this.data = data;
            let isEmpty = !data;
            this.comIllust.visible = !isEmpty;
            this.imgChara.visible = !isEmpty;
            this.comPower.visible = !isEmpty && !isHire;
            this.comBilitys.visible = !isEmpty;
            this.imgAbilityBg.visible = !isEmpty;
            let charaType = 3;
            if (data) {
                charaType = data.item_id ? 1 : 2;
                if (data.npc_code) {
                    game.LoadMgr.setImgSkin(this.imgChara, UI_QuestCrew_Extension.getSkinPath(data, 'waitingroom'), null, 'UI_Activity_Liandong_Main');
                    this.imgChara.visible = true;
                    this.illust.clear();
                } else {
                    this.imgChara.visible = false;
                    this.illust.setSkin(data.skinConfig.id, 'waitingroom');
                }
                let count = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
                this.txtPowerCount.text = count.toString();
                this.txtPowerCount.color = count == 0 ? '#ff5e5e' : '#fee77e';
                this.comBilitys.refresh(data);
            }
            this.imgBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/staff_end_big_' + charaType + '.jpg');
            this.imgAbilityBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/employee_box_property_bottom_' + charaType + '.png');
            this.imgTop.skin = game.Tools.localUISrc('myres/activity_2510questcrew/employee_box_decoration_' + charaType + '.png');
        }

        refreshBySelect(data: IQcChara, isEnough: boolean = true) {
            this.refresh(data);
            let isEmpty = !data;
            this.btnCard.visible = true;
            this.btnClose.visible = !isEmpty;
            (this.btnCard.getChildAt(0) as Laya.Image).visible = isEmpty;
            if (data) {
                this.txtPowerCount.color = isEnough ? '#fee77e' : '#ff5e5e';
            }
        }

        setClickHandler(func: Laya.Handler) {
            if (this.clickHandler) this.clickHandler.recover();
            this.clickHandler = func;
        }

        setCloseHandler(func: Laya.Handler) {
            if (this.closeHandler) this.closeHandler.recover();
            this.closeHandler = func;
        }
    }

    export class UI_QuestCrew_Extension {

        public static getSkinPath(config: IQcChara | IQcQuest, type: string): string {
            let url = '';
            if (config.skinConfig) {
                url = (config.skinConfig.path + '/' + type + '.png')
            } else {
                url = 'myres/activity_2510questcrew/npc/' + type + '/' + (config.npc_code) + '.png';
            }
            return url;
        }

        public static get iconReplaceStr(): string {
            if (GameMgr.client_language == 'chs') return '   ';
            if (GameMgr.client_language == 'chs_t') return '    ';
            if (GameMgr.client_language == 'kr') return '    ';
            if (GameMgr.client_language == 'jp') return '    ';
            if (GameMgr.client_language == 'en') return '  ';
        }
    }

}