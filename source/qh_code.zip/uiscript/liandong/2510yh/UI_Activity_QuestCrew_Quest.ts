module uiscript {
    class UI_QuestCrew_QuestHead extends UI_Component {
        private imgBg: Laya.Image;
        private imgHead: Laya.Image;
        private imgframe: Laya.Image;
        private imgSelected: Laya.Image;
        private btn: Laya.Button;
        private comSelected: Laya.Sprite;
        private questConfig: lqc.Sheet_QuestCrew_QcQuestPool;
        /** 头像类型 1-委托页签 2-委托人头像 */
        private type: number;
        private onClick: Laya.Handler;

        public onCreate(): void {
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
            this.imgHead = this.me.getChildByName('head') as Laya.Image;
            this.imgframe = this.me.getChildByName('frame') as Laya.Image;
            this.btn = this.me.getChildByName('btn') as Laya.Button;
            this.comSelected = this.me.getChildByName('selected') as Laya.Sprite;
            if (this.comSelected) this.imgSelected = this.comSelected.getChildAt(0) as Laya.Image;
            this.type = !!this.comSelected ? 1 : 2;
            this.btn.clickHandler = Laya.Handler.create(this, () => {
                this.onClick && this.onClick.run();
            }, null, false);
        }

        public setClickHandler(func: Laya.Handler) {
            if (this.onClick) this.onClick.recover();
            this.onClick = func;
        }

        public set selected(v: boolean) {
            if (this.type == 1) this.comSelected.visible = v;
            let scale = v ? 1.1 : 1;
            Laya.Tween.clearAll(this.me);
            Laya.Tween.to(this.me, { scaleX: scale, scaleY: scale }, 100, Laya.Ease.backOut);
            if (this.imgSelected) {
                if (v) {
                    Laya.timer.frameLoop(1, this.imgSelected, this.breathingEffect, [this.imgSelected]);
                } else {
                    Laya.timer.clearAll(this.imgSelected);
                }
            }
        }

        public refresh(questConfig: IQcQuest) {
            this.questConfig = questConfig;
            if (this.type == 1) {
                this.imgframe.skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_avatar_frame_' + questConfig.type + '.png');
            }
            game.LoadMgr.setImgSkin(this.imgHead, UI_QuestCrew_Extension.getSkinPath(questConfig, 'smallhead'), null, 'UI_Activity_Liandong_Main');
        }

        breathingEffect(img: Laya.Image) {
            let x = Math.sin(Laya.timer.currTimer / 100) * 1.1 + 202;
            img.x = x;
        }

        public onDisable(): void {
            if (this.imgSelected) Laya.timer.clearAll(this.imgSelected);
        }
    }
    class UI_QuestCrew_QuestDetail extends UI_Component {
        private head: UI_QuestCrew_QuestHead;
        private txtName: Laya.Label;
        private txtQuestDesc: Laya.Label;
        private comReward: Laya.Sprite;
        private txtReward: Laya.Label;
        private progressBars: UI_QuestCrew_Ability_Bars[];
        private questData: QuestCrew_QuestData;
        private comPreResult: Laya.Sprite;
        private imgResult: Laya.Image;
        private txtResult: Laya.Label;
        private comNPC: Laya.Sprite;
        private comAbility: Laya.Sprite;

        public onCreate(): void {
            this.comNPC = this.me.getChildByName('npc') as Laya.Sprite;
            this.comAbility = this.me.getChildByName('ability') as Laya.Sprite;
            this.head = new UI_QuestCrew_QuestHead(this.comNPC.getChildByName('head') as Laya.Sprite);
            this.txtName = this.comNPC.getChildByName('name') as Laya.Label;
            this.comReward = this.me.getChildByName('reward') as Laya.Sprite;
            this.txtReward = this.comReward.getChildByName('desc') as Laya.Label;
            this.txtQuestDesc = this.me.getChildByName('task_detail') as Laya.Label;
            let comAbilitys = this.comAbility.getChildByName('abilitys') as Laya.Sprite;
            this.progressBars = [];
            for (let i = 0; i < comAbilitys.numChildren; i++) {
                this.progressBars.push(new UI_QuestCrew_Ability_Bars(comAbilitys.getChildByName(i.toString()) as Laya.Sprite));
            }
            this.comPreResult = this.comAbility.getChildByName('pre_result') as Laya.Sprite;
            this.imgResult = this.comPreResult.getChildByName('icon') as Laya.Image;
            this.txtResult = this.comPreResult.getChildByName('title') as Laya.Label;
        }

        show(quest: QuestCrew_QuestData, members: IQcChara[]) {
            this.visible = true;
            this.questData = quest;
            this.questData.members = members;
            this.head.refresh(quest.config);
            let questConfig = this.questData.config;
            this.txtName.text = questConfig.charaName;
            this.txtQuestDesc.text = game.Tools.eventStrOfLocalization(questConfig.quest_desc);
            this.comReward.visible = !!questConfig.rewards;
            if (this.comReward.visible) {
                let rewardChara = ActivityQuestCrewData.Inst.charaPool.get(questConfig.rewards);
                if (rewardChara) {
                    this.txtReward.text = UI_QuestCrew_Extension.iconReplaceStr + ' ' + game.Tools.strOfLocalization(25101027, [rewardChara.charaName]);
                }
            }
            let target = quest.targetAbility;
            for (let i = 0; i < this.progressBars.length; i++) {
                this.progressBars[i].setTarget(target.success[EQuestCrewAbiliy[i + 1]], target.bigSuccess[EQuestCrewAbiliy[i + 1]], true);
            }
            this.refreshProgress(quest);
        }

        refreshProgress(quest: QuestCrew_QuestData) {
            if (!this.questData) return;
            let target = quest.targetAbility;
            for (let i = 0; i < this.progressBars.length; i++) {
                this.progressBars[i].setTarget(target.success[EQuestCrewAbiliy[i + 1]], target.bigSuccess[EQuestCrewAbiliy[i + 1]]);
            }
            let total = quest.totalAbility;
            for (let i = 0; i < this.progressBars.length; i++) {
                this.progressBars[i].setVal(total[EQuestCrewAbiliy[i + 1]]);
            }
            this.comPreResult.visible = quest.members.length > 0;
            if (this.comPreResult.visible) {
                let isSuccess = quest.isSuccess;
                let isBigSuccess = quest.isBigSuccess;
                this.imgResult.skin = game.Tools.localUISrc('myres/activity_2510questcrew/request_ability_tip' + (isBigSuccess ? 2 : (isSuccess ? 1 : 0)) + '.png')
                this.txtResult.text = game.Tools.strOfLocalization(isBigSuccess ? 25101049 : (isSuccess ? 25101048 : 25101047))
                this.txtResult.color = isBigSuccess ? '#d68f05' : (isSuccess ? '#8197de' : '#ae9791');
            }
        }

        hide() {
            this.visible = false;
            for (let i = 0; i < this.progressBars.length; i++) {
                this.progressBars[i].setVal(0, false);
            }
        }
    }

    class UI_QuestCrew_SelectItem extends UI_QuestCrew_EmployeeHead {
        private father: UI_QuestCrew_QuestDispatch;
        private imgCardBg: Laya.Image;
        private imgSelected: Laya.Image;
        private btnCharge: Laya.Button;
        private txtOrder: Laya.Label;
        private imgMask: Laya.Image;
        private btnSelect: Laya.Button;
        private data: IQcChara;
        private index: number;
        private canCharge: boolean;

        constructor(me: Laya.Sprite, father: UI_QuestCrew_QuestDispatch) {
            super(me);
            this.father = father;
            this.imgCardBg = this.me.getChildByName('card_bg') as Laya.Image;
            this.imgSelected = this.me.getChildByName('selected') as Laya.Image;
            this.btnCharge = this.me.getChildByName('add_power') as Laya.Button;
            this.btnSelect = this.me.getChildByName('btn') as Laya.Button;
            this.txtOrder = this.imgSelected.getChildByName('order') as Laya.Label;
            this.imgMask = this.me.getChildByName('grey_mask') as Laya.Image;
            this.btnCharge.clickHandler = Laya.Handler.create(this, () => {
                if (UI_Activity_QuestCrew_Quest.Inst.locking) return;
                if (!this.canCharge) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101061));
                    return;
                }
                const param: game.IReqQuestCrewActivityFeed = {
                    activity_id: ActivityQuestCrewData.Inst.activityId,
                    member_id: [this.data.character_id]
                }
                ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.ChargePower, param, Laya.Handler.create(this, () => {
                    this.onPowerCharge();
                }));
            }, null, false);
            this.btnSelect.clickHandler = Laya.Handler.create(this, () => {
                if (UI_Activity_QuestCrew_Quest.Inst.locking) return;
                this.father.onItemSelected(this.index);
            }, null, false);
        }

        refreshShow(data: IQcChara, index: number) {
            super.refresh(data);
            this.data = data;
            this.index = index;
            this.imgCardBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_list_bottom_' + (data.item_id ? 1 : 2) + '.png')
            let selectedIndex = this.father.tempSelected.indexOf(data.character_id);
            this.imgSelected.visible = selectedIndex >= 0;
            if (selectedIndex >= 0) {
                this.txtOrder.text = (selectedIndex + 1).toString();
            }
            let count = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
            this.canCharge = count < data.sta && ActivityQuestCrewData.Inst.isFishEnough(ActivityQuestCrewData.Inst.qcConfig.chargePrice);
            this.btnCharge.mouseEnabled = count < data.sta;
            (this.btnCharge.getChildAt(0) as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_list_button_recharge' + (this.canCharge ? '' : '_grey') + '.png');
            this.imgMask.visible = !this.imgSelected.visible && this.father.tempSelected.length == 3;
            this.btnSelect.visible = !this.imgMask.visible;
        }

        onPowerCharge() {
            let effect = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/effect_questcrew_charge.lh', new Laya.Point(-180, -72), 1);
            Laya.timer.once(600, effect, () => {
                this.refreshShow(this.data, this.index);
            });
            Laya.timer.once(2000, effect, () => {
                effect.destory();
            });
        }
    }

    class UI_QuestCrew_ResultEffect extends UI_Component {

        private head: UI_QuestCrew_EmployeeHead;
        private desc: Laya.Label;
        private imgBg: Laya.Image;

        public onCreate(): void {
            this.head = new UI_QuestCrew_EmployeeHead(this.me.getChildByName('head') as Laya.Sprite);
            this.desc = this.me.getChildByName('desc') as Laya.Label;
            this.imgBg = this.me.getChildByName('bg') as Laya.Image;
        }

        public refresh(memberId: number, desc: string) {
            let charaConfig = ActivityQuestCrewData.Inst.charaPool.get(memberId);
            if (!charaConfig) return;
            this.visible = true;
            this.head.refresh(charaConfig);
            this.desc.text = desc;
            let charaType = charaConfig.item_id ? 1 : 2;
            this.imgBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_result_trigger_bottom_' + charaType + '.png');
        }
    }

    enum EBtnAnimName {
        show,
        idle,
        click,
        clickIdle,
        clickCancel,
        start
    }
    export class UI_QuestCrew_QuestDispatch extends UI_Component {
        private father: UI_Activity_QuestCrew_Quest;
        private comTitle: Laya.Sprite;
        private txtTitle: Laya.Label;
        private comSelect: Laya.Sprite;
        private comResult: Laya.Sprite;
        private comPageResult: Laya.Sprite;
        private comPageWorking: Laya.Sprite;
        private txtWorking: Laya.Label;
        private btnConfirmResult: Laya.Button;
        private comPagePrepare: Laya.Sprite;
        private comPageSelect: Laya.Sprite;
        private scrollViewSelect: capsui.CScrollView;
        private btnSelectConfirm: Laya.Button;
        private btnSelectReset: Laya.Button;
        private btnSelectCancel: Laya.Button;
        private comSelectSort: UI_QuestCrew_Sort;
        private btnGo: Laya.Button;
        private btnRandomAdd: Laya.Button;
        private btnCharge: Laya.Button;
        private txtChargeCount: Laya.Label;
        private comDesc: Laya.Sprite;
        private comDescEmpty: Laya.Sprite;
        private imgStars: Laya.Image[];
        private txtDesc: Laya.HTMLDivElement;
        private txtTest: Laya.HTMLDivElement;
        private comEffects: UI_QuestCrew_ResultEffect[];

        private typeSort: EQuestCrewSort = EQuestCrewSort.sta;
        public tempSelected: number[];
        public employees: IQcChara[];
        public questData: QuestCrew_QuestData;
        private comEmployees: UI_QuestCrew_EmployeeCard[];
        private workingStrings: string[];
        private aniShowPrepare: Laya.FrameAnimation;
        private aniResultShowPrepare: Laya.FrameAnimation;
        private aniHidePrepareToSelect: Laya.FrameAnimation;
        private aniHidePrepareToResult: Laya.FrameAnimation;
        private aniShowSelect: Laya.FrameAnimation;
        private aniHideSelect: Laya.FrameAnimation;
        private aniResultButton: Laya.FrameAnimation;
        private aniEffects: Laya.FrameAnimation;
        private aniBtnGos: Laya.FrameAnimation[];
        private effectCharges: game.UIEffect[] = [];
        private effectWorking: Laya.Sprite3D;
        private aniWorking: Catfood.CAnimator;
        /** 分别为成功，大成功，成功转大成功 */
        private effectResults: Laya.Sprite3D[];
        private aniResults: Catfood.CAnimator[];
        private isMouseDown: boolean;
        private audioIds: number[] = [];
        private canCharge: boolean;
        private btnGoTip: string = '';

        constructor(me: Laya.Sprite, father: UI_Activity_QuestCrew_Quest) {
            super(me);
            this.father = father;
            this.comSelect = this.me.getChildByName('select') as Laya.Sprite;
            this.comResult = this.me.getChildByName('result') as Laya.Sprite;
            this.comPageResult = this.comResult.getChildByName('result') as Laya.Sprite;
            let comEffect = this.comPageResult.getChildByName('effects') as Laya.Sprite;
            this.comEffects = [];
            for (let i = 0; i < comEffect.numChildren; i++) {
                this.comEffects.push(new UI_QuestCrew_ResultEffect(comEffect.getChildAt(i) as Laya.Sprite));
            }
            this.comPageWorking = this.comResult.getChildByName('working') as Laya.Sprite;
            this.txtWorking = this.comPageWorking.getChildByName('title') as Laya.Label;
            this.btnConfirmResult = this.comPageResult.getChildByName('confirm') as Laya.Button;
            this.btnConfirmResult.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                this.father.onCheckedResult();
            }, null, false);
            this.comPagePrepare = this.comSelect.getChildByName('prepare') as Laya.Sprite;
            this.comPageSelect = this.comSelect.getChildByName('select') as Laya.Sprite;
            this.comSelectSort = new UI_QuestCrew_Sort(this.comSelect.getChildByName('sort') as Laya.Sprite, this);
            let comContent = this.comPageSelect.getChildByName('content') as Laya.Sprite;
            this.scrollViewSelect = comContent.scriptMap['capsui.CScrollView'];
            this.scrollViewSelect.init_scrollview(new Laya.Handler(this, this.listItemRender), null, 2);
            this.btnSelectCancel = this.comPageSelect.getChildByName('btn_cancel') as Laya.Button;
            this.btnSelectReset = this.comPageSelect.getChildByName('btn_reset') as Laya.Button;
            this.btnSelectConfirm = this.comPageSelect.getChildByName('btn_confirm') as Laya.Button;
            this.btnGo = this.comPagePrepare.getChildByName('go') as Laya.Button;
            this.btnCharge = this.comPagePrepare.getChildByName('add_power') as Laya.Button;
            this.txtChargeCount = this.btnCharge.getChildByName('count') as Laya.Label;
            this.btnRandomAdd = this.comPagePrepare.getChildByName('add_person') as Laya.Button;
            this.comDesc = this.comPagePrepare.getChildByName('effect_desc') as Laya.Sprite;
            this.comDescEmpty = this.comPagePrepare.getChildByName('effect_empty') as Laya.Sprite;
            this.imgStars = [];
            for (let i = 1; i <= 3; i++) {
                this.imgStars.push(this.comDesc.getChildByName('star' + i) as Laya.Image);
            }
            this.txtDesc = this.comDesc.getChildByName('text') as Laya.HTMLDivElement;
            this.txtTest = this.comDesc.getChildByName('test') as Laya.HTMLDivElement;
            this.comTitle = this.me.getChildByName('title') as Laya.Sprite;
            let comTeams = this.comPagePrepare.getChildByName('teams') as Laya.Sprite;
            this.comEmployees = [];
            for (let i = 0; i < comTeams.numChildren; i++) {
                let card = new UI_QuestCrew_EmployeeCard(comTeams.getChildAt(i) as Laya.Sprite);
                card.setClickHandler(Laya.Handler.create(this, () => {
                    if (this.father.locking) return;
                    this.hidePreparePage(false, Laya.Handler.create(this, () => {
                        this.showSelectPage();
                    }));
                }, null, false));
                card.setCloseHandler(Laya.Handler.create(this, () => {
                    if (this.father.locking) return;
                    this.tempSelected.splice(i, 1);
                    let members = this.tempSelected.map(v => ActivityQuestCrewData.Inst.charaPool.get(v));
                    this.father.members = members;
                    this.questData.members = members;
                    this.showPreparePage();
                }, null, false));
                this.comEmployees.push(card);
            }
            this.btnSelectCancel.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                this.tempSelected = this.father.members.map(v => v.character_id);
                this.hideSelectPage(Laya.Handler.create(this, () => {
                    this.showPreparePage();
                }))
            }, null, false);
            this.btnSelectReset.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                this.tempSelected = [];
                this.scrollViewSelect.wantToRefreshAll();
                let tempQuest = new QuestCrew_QuestData(this.questData.id, []);
                this.father.refreshNowProgress(tempQuest);
            }, null, false);
            this.btnSelectConfirm.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                let members = this.tempSelected.map(v => ActivityQuestCrewData.Inst.charaPool.get(v));
                this.father.members = members;
                this.questData.members = members;
                this.hideSelectPage(Laya.Handler.create(this, () => {
                    this.showPreparePage();
                }))
            }, null, false);
            this.btnGo.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                if (this.btnGoTip) {
                    UI_Info_Small.Inst.show(this.btnGoTip);
                    return;
                }
                const param: game.IReqQuestCrewActivityStartQuest = {
                    activity_id: ActivityQuestCrewData.Inst.activityId,
                    joined_members: this.tempSelected,
                    quest_id: this.questData.id
                }
                ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.StartQuest, param, Laya.Handler.create(this, (res: game.IResQuestCrewActivityStartQuest) => {
                    this.father.members = [];
                    this.hidePreparePage(true, Laya.Handler.create(this, () => {
                        this.onQuestDone(res);
                    }))
                }));
            }, null, false);
            this.btnCharge.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                if (!this.canCharge) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101061));
                    return;
                }
                let charaIds = [];
                let indexs = [];
                for (let i = 0; i < this.father.members.length; i++) {
                    let data = this.father.members[i];
                    if (data) {
                        let nowPower = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
                        if (nowPower < data.sta) {
                            charaIds.push(data.character_id);
                            indexs.push(i);
                        }
                    }
                }
                const param: game.IReqQuestCrewActivityFeed = {
                    activity_id: ActivityQuestCrewData.Inst.activityId,
                    member_id: charaIds
                }
                ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.ChargePower, param, Laya.Handler.create(this, this.onPowerCharge, [indexs]));
            }, null, false);
            this.btnRandomAdd.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                this.tempSelected = ActivityQuestCrewData.Inst.addRandomTeam(this.questData.config);
                if (this.tempSelected.length == 0) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101060));
                    return;
                }
                let members = this.tempSelected.map(v => ActivityQuestCrewData.Inst.charaPool.get(v));
                this.father.members = members;
                this.questData.members = members;
                this.showPreparePage();
            }, null, false);
            let workingStringBase = game.Tools.strOfLocalization(25101035);
            this.workingStrings = [];
            this.workingStrings.push(`${workingStringBase}`);
            this.workingStrings.push(`${workingStringBase}.`);
            this.workingStrings.push(`${workingStringBase}..`);
            this.workingStrings.push(`${workingStringBase}...`);
            let aniRoot = this.father.me as ui.liandong.yh.activity_2510questcrew_entrustUI;
            this.aniShowPrepare = aniRoot.assign_show;
            this.aniResultShowPrepare = aniRoot.assign_result_show;
            this.aniHidePrepareToSelect = aniRoot.assign_select;
            this.aniHidePrepareToResult = aniRoot.assign_result;
            this.aniShowSelect = aniRoot.select_show;
            this.aniHideSelect = aniRoot.select_hide;
            this.aniResultButton = aniRoot.result_cofirm;
            this.aniEffects = aniRoot.result_effects;
            this.aniBtnGos = [aniRoot.go_show, aniRoot.go_idle, aniRoot.go_click, aniRoot.go_click_idle, aniRoot.go_click_cancel, aniRoot.go_start]
            this.comPageSelect.visible = false;
            this.comPagePrepare.visible = false;
            this.btnGo.on('mousedown', this, () => {
                this.isMouseDown = true;
                this.playBtnGoAnim(EBtnAnimName.click);
            });
            this.btnGo.on('mouseup', this, () => {
                if (!this.isMouseDown) return;
                this.isMouseDown = false;
                if (this.father.locking || this.btnGoTip != '') {
                    this.playBtnGoAnim(EBtnAnimName.clickCancel);
                } else {
                    this.playBtnGoAnim(EBtnAnimName.start);
                }
            });
            this.btnGo.on('mouseout', this, () => {
                if (!this.isMouseDown) return;
                this.isMouseDown = false;
                this.playBtnGoAnim(EBtnAnimName.clickCancel);
            });
        }

        playBtnGoAnim(type: EBtnAnimName, onComplete?: Laya.Handler) {
            this.aniBtnGos.forEach(anim => anim.stop());
            Laya.timer.clearAll(this.btnGo);
            let anim = this.aniBtnGos[type];
            let isIdle = type == EBtnAnimName.idle || type == EBtnAnimName.clickIdle;
            anim.play(0, isIdle);
            let nextType: EBtnAnimName;
            if (type == EBtnAnimName.click) {
                nextType = EBtnAnimName.clickIdle;
            } else if (type == EBtnAnimName.idle || type == EBtnAnimName.clickIdle || type == EBtnAnimName.start) {
            } else {
                nextType = EBtnAnimName.idle;
            }
            if (!nextType) {
                onComplete && onComplete.run();
                return;
            }
            let delay = anim.interval * anim.count;
            Laya.timer.once(delay, this.btnGo, () => {
                this.playBtnGoAnim(nextType);
                onComplete && onComplete.run();
            })
        }

        private refreshLabelStyle(label: Laya.HTMLDivElement, fontSize: number = 26, leading: number = 4) {
            if (GameMgr.client_language == 'jp') {
                label.style.font = `${fontSize}px NotoSansJapanese`;
            } else if (GameMgr.client_language == 'chs') {
                label.style.font = `${fontSize}px HYWH`;
            } else if (GameMgr.client_language == 'chs_t') {
                label.style.font = `${fontSize}px FZHT`;
            } else if (GameMgr.client_language == 'en') {
                label.style.font = `${fontSize}px SimHei`;
            } else {
                label.style.font = `${fontSize}px NotoSansKR`;
            }
            label.style.color = '#ae9791';
            label.style.leading = leading;
            label.style.letterSpacing = 0;
        }

        private startWorkingTextAnim() {
            let textAnimStartTime = Laya.timer.currTimer;
            this.txtWorking.text = this.workingStrings[0];
            //每隔800ms播放一次动画
            Laya.timer.loop(600, this.txtWorking, () => {
                //当前时间差
                let timeSpace: number = Laya.timer.currTimer - textAnimStartTime;
                //如果时间差/800%3的值为0，则没有.,1则为1个点，以此类推
                let dotCount: number = timeSpace / 600 % 4;
                dotCount = Math.floor(dotCount);
                this.txtWorking.text = this.workingStrings[dotCount];
            });
        }

        private stopWorkingTextAnim() {
            Laya.timer.clearAll(this.txtWorking);
        }

        onQuestDone(res: game.IResQuestCrewActivityStartQuest) {
            this.father.locking = true;
            this.comSelect.visible = false;
            this.comResult.visible = true;
            this.comPageWorking.visible = true;
            this.comPageResult.visible = false;
            this.stopWorkingTextAnim();
            this.startWorkingTextAnim();
            this.audioIds.push(view.AudioMgr.PlayAudio(10358));
            if (this.effectWorking) {
                this.effectWorking.active = true;
                this.aniWorking.Play(null);
            }
            let resultDelay = 80 / 60 * 1000;
            Laya.timer.once(resultDelay, this, () => {
                this.stopWorkingTextAnim();
                this.comPageWorking.visible = false;
                this.comPageResult.visible = true;
                let originResult = res.result;
                let isChanged = false;
                this.comEffects.forEach(com => {
                    com.visible = false;
                });
                let effectTips: { memberId: number, desc: string, type: number }[] = [];
                if (res && res.effect_info) {
                    /** type 特性类型 1结果变化 2消耗变化 3获得奖励 */
                    res.effect_info.forEach((effect, index) => {
                        if (effect.result) {
                            if (effect.result.result_change && effect.result.result_change.from) {
                                if (!isChanged) {
                                    originResult = effect.result.result_change.from;
                                }
                                isChanged = true;
                                effectTips.push({ memberId: effect.member_id, desc: game.Tools.eventStrOfLocalization(25102001), type: 1 });
                            }
                            if (effect.result.consumed_change) {
                                for (let j = 0; j < effect.result.consumed_change.length; j++) {
                                    let consumeChange = effect.result.consumed_change[j];
                                    let desc = '';
                                    if (consumeChange.to > consumeChange.from) {
                                        desc = game.Tools.eventStrOfLocalization(25102004);
                                    } else if (consumeChange.to == 0) {
                                        desc = game.Tools.eventStrOfLocalization(25102003);
                                    }
                                    if (desc) {
                                        effectTips.push({
                                            memberId: consumeChange.member_id,
                                            desc,
                                            type: 2
                                        })
                                    }
                                }
                            }
                            if (effect.result.reward && effect.result.reward.execute_reward) {
                                for (let j = 0; j < effect.result.reward.execute_reward.length; j++) {
                                    let reward = effect.result.reward.execute_reward[j];
                                    if (reward.reward && reward.reward.id == ActivityQuestCrewData.Inst.currencyId) {
                                        effectTips.push({
                                            memberId: effect.member_id,
                                            desc: game.Tools.eventStrOfLocalization(25102002, [reward.reward.count.toString()]),
                                            type: 3
                                        })
                                    }
                                }
                            }
                        }
                    })
                }
                if (effectTips.length > 0) {
                    for (let i = 0; i < effectTips.length; i++) {
                        let comEffect = this.comEffects[i];
                        if (comEffect) {
                            comEffect.refresh(effectTips[i].memberId, effectTips[i].desc);
                        }
                    }
                    this.aniEffects.play(0, false);
                }
                let delay = isChanged ? 3500 : 2000;
                let result = isChanged ? 2 : originResult - 1;
                this.refreshResult(result);
                this.btnConfirmResult.visible = false;
                Laya.timer.once(delay - resultDelay, this, () => {
                    this.father.locking = false;
                    this.btnConfirmResult.visible = true;
                    this.aniResultButton.play(0, false);
                })
            })
        }

        show(questData: QuestCrew_QuestData, fromResult: boolean = false) {
            this.clearAnim();
            this.visible = true;
            this.questData = questData;
            this.questData.members = this.father.members;
            this.tempSelected = this.father.members.map(v => v.character_id);
            if (ActivityQuestCrewData.Inst.duringGuide) {
                this.employees = [10001, 10002].map((id) => ActivityQuestCrewData.Inst.charaPool.get(id));
            } else {
                this.employees = ActivityQuestCrewData.Inst.memberPool.keys().map((id) => ActivityQuestCrewData.Inst.charaPool.get(id));
            }
            this.comResult.visible = false;
            this.comSelect.visible = true;
            if (this.comPageSelect.visible) {
                this.hideSelectPage(Laya.Handler.create(this, () => {
                    this.showPreparePage(fromResult);
                }))
            } else {
                this.showPreparePage(fromResult);
            }
        }

        hide() {
            this.visible = false;
            this.comResult.visible = false;
            this.comSelect.visible = true;
            this.comPageSelect.visible = false;
            this.comPagePrepare.visible = false;
            this.clearAnim();
        }

        clearAnim() {
            this.stopWorkingTextAnim();
            Laya.timer.clearAll(this);
            if (this.effectWorking) {
                this.effectWorking.active = false;
                this.aniWorking.Stop();
            }
            if (this.effectResults) {
                this.effectResults.forEach(effect => effect.active = false);
                this.aniResults.forEach(anim => anim.Stop());
            }
            this.audioIds.forEach(audioId => {
                view.AudioMgr.StopAudio(audioId);
            });
            this.audioIds = [];
        }

        /**
         * 列表Item渲染的方法
         * @param data index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(data) {
            let index = data.index;
            let cache_data = data.cache_data;
            let item: Laya.Sprite = data.container;
            data.container.alpha = 1;
            if (!cache_data.card) {
                cache_data.card = new UI_QuestCrew_SelectItem(item.getChildAt(0) as Laya.Sprite, this);
            }
            let head = cache_data.card as UI_QuestCrew_SelectItem;
            head.refreshShow(this.employees[index], index);
        }

        onItemSelected(index: number) {
            let charaId = this.employees[index].character_id;
            let selectedIndex = this.tempSelected.indexOf(charaId);
            if (selectedIndex >= 0) {
                let indexs = [];
                for (let i = 0; i < this.tempSelected.length; i++) {
                    let orderIndex = this.employees.findIndex((v) => v.character_id == this.tempSelected[i]);
                    indexs.push(orderIndex);
                }
                this.tempSelected.splice(selectedIndex, 1);
            } else if (this.tempSelected.length < 3) {
                this.tempSelected.push(charaId)
            }
            this.scrollViewSelect.wantToRefreshAll();
            let tempQuest = new QuestCrew_QuestData(this.questData.id, this.tempSelected.map(v => ActivityQuestCrewData.Inst.charaPool.get(v)));
            this.father.refreshNowProgress(tempQuest);
        }

        onSortChange(index: EQuestCrewSort) {
            if (this.typeSort == index) return;
            this.typeSort = index;
            this.refreshContent();
        }

        refreshContent(doAnim: boolean = true, memberId: number = -1) {
            this.employees.sort((a, b) => {
                if (this.typeSort == EQuestCrewSort.sta) {
                    let powerA = ActivityQuestCrewData.Inst.getConsumedByCharaId(a.character_id);
                    let powerB = ActivityQuestCrewData.Inst.getConsumedByCharaId(b.character_id);
                    if (powerB != powerA) return powerB - powerA;
                }
                if (this.typeSort == EQuestCrewSort.spd && a.spd != b.spd) return b.spd - a.spd;
                if (this.typeSort == EQuestCrewSort.luc && a.luc != b.luc) return b.luc - a.luc;
                if (this.typeSort == EQuestCrewSort.str && a.str != b.str) return b.str - a.str;
                return a.character_id - b.character_id;
            });
            this.scrollViewSelect.reset();
            if (this.employees.length > 0) {
                this.scrollViewSelect.addItem(this.employees.length);
            }
            if (memberId >= 0) {
                let index = this.employees.findIndex(v => v.character_id == memberId);
                this.scrollViewSelect._content.vScrollBar.value = Math.floor(index / 2) * 256;
            }
            if (doAnim) {
                this.father.locking = true;
                let list = this.scrollViewSelect;
                list.me.mouseEnabled = false;
                let count = 0;
                list.items.forEach((item, index) => {
                    count++;
                    Laya.Tween.clearAll(item);
                    item.container.alpha = 0;
                    let targetY = item.container.y;
                    item.container.y = targetY + 100;
                    Laya.Tween.to(item.container, { y: targetY, alpha: 1 }, 150, Laya.Ease.quadInOut, null, 68 * Math.floor(index / 2))
                })
                let list_delay = 150 + (Math.ceil(count / 2) - 1) * 68;
                Laya.timer.once(list_delay, this, () => {
                    list.me.mouseEnabled = true;
                    this.father.locking = false;
                });
            }
        }

        showPreparePage(fromResult: boolean = false, clearEffect: boolean = true) {
            if (fromResult) {
                this.aniResultShowPrepare.play(0, false);
                this.playBtnGoAnim(EBtnAnimName.show);
            } else if (!this.comPagePrepare.visible) {
                this.aniShowPrepare.play(0, false);
                this.playBtnGoAnim(EBtnAnimName.show);
            }
            if (clearEffect && this.effectCharges.length > 0) {
                this.effectCharges.forEach(effect => effect.destory());
                this.effectCharges = [];
            }
            this.comTitle.visible = true;
            this.comPageSelect.visible = false;
            this.comPagePrepare.visible = true;
            this.comSelectSort.visible = false;
            let employeeDatas = this.questData.members;
            let personCount = 0;
            let str = '';
            let descs: string[] = [];
            let names: string[] = [];
            let skills: string[] = [];
            let isEffected = this.questData.effectedLst;
            let index = 0;
            for (let i = 0; i < employeeDatas.length; i++) {
                let data = employeeDatas[i];
                let nowPower = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
                if (nowPower < data.sta) {
                    personCount += 1;
                }
                if (data.skill) {
                    let name = data.charaName + game.Tools.strOfLocalization(25101045);
                    let skill = game.Tools.eventStrOfLocalization(data.skill);
                    let desc = name + skill;
                    str += desc;
                    str += '<br>';
                    descs.push(desc);
                    names.push(name);
                    skills.push(skill);
                    index++;
                }
            }
            if (descs.length > 0) {
                this.comDesc.visible = true;
                this.comDescEmpty.visible = false;
                this.refreshLabelStyle(this.txtDesc);
                this.refreshLabelStyle(this.txtTest);
                let fontSize = 26;
                let leading = 4;
                this.txtDesc.innerHTML = str;
                let tw: number = this.txtDesc.contextHeight;
                let lineCount = Math.ceil(tw / (fontSize + leading));
                if (lineCount > 6) {
                    fontSize = Math.floor(fontSize / Math.sqrt(lineCount / 6));
                    leading = Math.floor(leading / Math.sqrt(lineCount / 6));
                    this.refreshLabelStyle(this.txtDesc, fontSize, leading);
                    this.refreshLabelStyle(this.txtTest, fontSize, leading);
                }
                str = '';
                for (let i = 0; i < names.length; i++) {
                    let name = game.Tools.ParseText('[tag]' + names[i] + '[/tag]', '#000000');
                    let skill = game.Tools.ParseText((isEffected[i] ? '[tag]' : '') + skills[i] + (isEffected[i] ? '[/tag]' : ''), '#3a775f');
                    str += (name + skill + '<br>');
                }
                this.txtDesc.innerHTML = str;
                let startY = 5;
                for (let i = 0; i < this.imgStars.length; i++) {
                    let imgStar = this.imgStars[i];
                    imgStar.visible = !!descs[i];
                    if (descs[i]) {
                        imgStar.y = startY;
                        this.txtTest.innerHTML = descs[i];
                        startY += this.txtTest.contextHeight;
                    }
                }
            } else {
                this.comDesc.visible = false;
                this.comDescEmpty.visible = true;
            }
            let feedCount = ActivityQuestCrewData.Inst.getFeedCount(personCount);
            let isSuccess = this.questData.isSuccess;
            let isBigSuccess = this.questData.isBigSuccess;
            let consumes = this.questData.consumeAfterEffect;
            //体力不足
            let isPowerPoor = false;
            this.comEmployees.forEach((employee, index) => {
                let data = this.father.members[index];
                if (data) {
                    let type = isBigSuccess ? 1 : 0;
                    let consume = consumes[type][index];
                    let count = ActivityQuestCrewData.Inst.getConsumedByCharaId(data.character_id);
                    let isEnough = count >= consume;
                    employee.refreshBySelect(data, isEnough);
                    if (!isEnough) isPowerPoor = true;
                } else {
                    employee.refreshBySelect(null);
                }
            })
            this.father.refreshNowProgress(this.questData);
            let isFeedGrey = false;
            if (feedCount == 0) {
                isFeedGrey = true;
            } else {
                isFeedGrey = !ActivityQuestCrewData.Inst.isFishEnough(feedCount);
            }
            this.canCharge = !isFeedGrey;
            this.btnCharge.mouseEnabled = feedCount > 0;
            (this.btnCharge.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_button_recharge' + (isFeedGrey ? '_grey' : '') + '.png');
            this.txtChargeCount.text = feedCount.toString();
            this.btnGoTip = '';
            if (!isSuccess) {
                this.btnGoTip = game.Tools.strOfLocalization(25101064);
            } else if (isPowerPoor) {
                this.btnGoTip = game.Tools.strOfLocalization(25101063);
            }
            let isGoGrey = (!isSuccess || isPowerPoor);
            (this.btnGo.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_button_set_off' + (isGoGrey ? '_grey' : '') + '.png');
            (this.btnGo.getChildByName('cat').getChildByName('title') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/entrustment_button_set_title' + (isGoGrey ? '_grey' : '') + '.png');
        }

        hidePreparePage(toResult: boolean = false, onComplete?: Laya.Handler) {
            this.aniShowPrepare.stop();
            this.aniResultShowPrepare.stop();
            let anim = toResult ? this.aniHidePrepareToResult : this.aniHidePrepareToSelect;
            anim.play(0, false);
            this.father.locking = true;
            Laya.timer.once(anim.interval * anim.count, this, () => {
                this.father.locking = false;
                onComplete && onComplete.run();
            })
        }

        showSelectPage() {
            this.comTitle.visible = false;
            this.comPageSelect.visible = true;
            this.comPagePrepare.visible = false;
            this.comSelectSort.visible = true;
            this.refreshContent();
            this.aniShowSelect.play(0, false);
        }

        hideSelectPage(onComplete: Laya.Handler) {
            let list = this.scrollViewSelect;
            list.me.mouseEnabled = false;
            list.items.forEach((item, index) => {
                Laya.Tween.clearAll(item);
                let targetY = item.container.y + 100;
                Laya.Tween.to(item.container, { y: targetY, alpha: 0 }, 150, Laya.Ease.quadInOut);
            })
            this.aniHideSelect.play(0, false);
            this.father.locking = true;
            Laya.timer.once(this.aniHideSelect.interval * this.aniHideSelect.count, this, () => {
                list.items.forEach((item) => {
                    Laya.Tween.clearAll(item);
                })
                list.me.mouseEnabled = true;
                this.father.locking = false;
                onComplete && onComplete.run();
            });
        }

        resetOrder() {
            this.typeSort = EQuestCrewSort.sta;
            this.comSelectSort.reset();
        }

        onEmployeePowerChange(memberId: number) {
            view.AudioMgr.PlayAudio(10363);
            if (this.comSelect.visible) {
                if (this.comPageSelect.visible) {
                    if (this.typeSort == EQuestCrewSort.sta) {
                        this.father.locking = true;
                        this.scrollViewSelect.me.mouseEnabled = false;
                        Laya.timer.once(1500, this, () => {
                            this.father.locking = false;
                            this.scrollViewSelect.me.mouseEnabled = true;
                            this.refreshContent(false, memberId);
                        })
                    }
                } else if (this.comPagePrepare.visible) {
                    this.father.locking = true;
                    Laya.timer.once(600, this, () => {
                        this.father.locking = false;
                        this.showPreparePage(false, false);
                    })
                }
            }
        }

        onPowerCharge(indexs: number[]) {
            for (let i = 0; i < indexs.length; i++) {
                let effect = game.FrontEffect.Inst.create_ui_effect(this.comEmployees[indexs[i]].comPower, 'scene/effect_questcrew_charge.lh', new Laya.Point(18, 13), 1);
                this.effectCharges.push(effect);
            }
        }

        public onEnable(): void {
            ActivityQuestCrewData.Inst.on(EQuestCrewEvent.ChargePower, this, this.onEmployeePowerChange);
        }

        public onDisable(): void {
            Laya.timer.clearAll(this.btnGo);
            this.aniBtnGos.forEach(anim => anim.stop());
            ActivityQuestCrewData.Inst.off(EQuestCrewEvent.ChargePower, this, this.onEmployeePowerChange);
            this.clearAnim();
        }

        public refreshResult(result: number) {
            if (!this.effectWorking) return;
            this.effectWorking.active = false;
            this.effectResults[result].active = true;
            for (let i = 0; i < this.effectResults[result]._childs.length; i++) {
                let effect = this.effectResults[result]._childs[i];
                let localization = game.Tools.GetNodeByNameInChildren(effect, 'localization') as Laya.Sprite3D;
                if (localization) {
                    if (localization.getChildByName('chs')) {
                        (localization.getChildByName('chs') as Laya.Sprite3D).active = GameMgr.client_language != 'en' && GameMgr.client_language != 'kr';
                    }
                    if (localization.getChildByName('en')) {
                        (localization.getChildByName('en') as Laya.Sprite3D).active = GameMgr.client_language == 'en';
                    }
                    if (localization.getChildByName('kr')) {
                        (localization.getChildByName('kr') as Laya.Sprite3D).active = GameMgr.client_language == 'kr';
                    }
                }
            }
            let audioId = result != 1 ? 10359 : 10360;
            this.audioIds.push(view.AudioMgr.PlayAudio(audioId));
            if (result == 2) {
                Laya.timer.once(80 / 60 * 1000, this, () => {
                    this.audioIds.push(view.AudioMgr.PlayAudio(10360));
                });
            }
            let anim = this.aniResults[result];
            let aniName = this.effectResults[result].name + '_01';
            anim.Play(aniName);
            Laya.timer.once(anim.GetDurationByAnimName(aniName) * 1000, this, () => {
                anim.Play(this.effectResults[result].name + '_02');
            });
        }

        public refreshGuideState(type: E_Act_Yindao_Type) {
            if (type == E_Act_Yindao_Type.showQCSelect) {
                this.hidePreparePage(false, Laya.Handler.create(this, () => {
                    this.showSelectPage();
                }));
            } else if (type == E_Act_Yindao_Type.showQCSelectConfirm) {
                this.tempSelected = [10002];
                let members = this.tempSelected.map(v => ActivityQuestCrewData.Inst.charaPool.get(v));
                this.father.members = members;
                this.questData.members = members;
                this.scrollViewSelect.wantToRefreshAll();
                this.father.refreshNowProgress(this.questData);
            } else if (type == E_Act_Yindao_Type.showQCGo) {
                this.hideSelectPage(Laya.Handler.create(this, () => {
                    this.showPreparePage();
                }))
            } else if (type == E_Act_Yindao_Type.showQCCheckResult) {
                this.father.members = [];
                ActivityQuestCrewData.Inst.afterGuideQuest = true;
                this.hidePreparePage(true, Laya.Handler.create(this, () => {
                    this.onQuestDone({
                        error: null,
                        result: 1,
                        value_changes: null,
                        effect_info: null,
                    });
                }))
            }
        }

        public initEffect(effect: Laya.Sprite3D) {
            this.effectWorking = effect.getChildByName('working') as Laya.Sprite3D;
            this.aniWorking = (this.effectWorking.getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            this.effectResults = [];
            this.aniResults = [];
            let comResult = effect.getChildByName('result') as Laya.Sprite3D;
            for (let i = 0; i < comResult._childs.length; i++) {
                let effect = comResult._childs[i];
                this.effectResults.push(effect);
                this.aniResults.push((effect as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator)
            }
            this.effectWorking.active = false;
            this.effectResults.forEach(effect => effect.active = false);
        }

        public destroyEffect(): void {
            this.effectWorking = null;
            this.effectResults = [];
            this.aniResults = [];
        }
    }

    export class UI_Activity_QuestCrew_Quest extends UIBase {
        public static Inst: UI_Activity_QuestCrew_Quest;
        constructor() {
            super(new ui.liandong.yh.activity_2510questcrew_entrustUI);
            UI_Activity_QuestCrew_Quest.Inst = this;
        }
        private comRoot: Laya.Sprite;
        private comLeft: Laya.Sprite;
        private comMiddle: Laya.Sprite;
        private comRight: Laya.Sprite;
        private questDetail: UI_QuestCrew_QuestDetail;
        private questTabs: capsui.CScrollView;
        private questWork: UI_QuestCrew_QuestDispatch;
        public members: IQcChara[];
        private comEmpty: Laya.Sprite;
        private txtEmpty: Laya.Label;

        private selectedTabIndex: number;
        public quests: QuestCrew_QuestData[];
        public locking: boolean;

        public aniShowBg: Laya.FrameAnimation;
        public aniHideBg: Laya.FrameAnimation;

        public onCreate(): void {
            this.comRoot = this.me.getChildByName('root') as Laya.Sprite;
            this.comLeft = this.comRoot.getChildByName('left') as Laya.Sprite;
            this.comMiddle = this.comRoot.getChildByName('middle') as Laya.Sprite;
            this.comRight = this.comRoot.getChildByName('right') as Laya.Sprite;
            this.questDetail = new UI_QuestCrew_QuestDetail(this.comMiddle);
            this.questWork = new UI_QuestCrew_QuestDispatch(this.comRight, this);
            this.questTabs = this.comLeft.scriptMap['capsui.CScrollView'];
            this.questTabs.init_scrollview(Laya.Handler.create(this, this.renderTabItem, null, false));
            this.questTabs.setElastic();
            this.questTabs.extraHeight = 30;
            this.comEmpty = this.comRoot.getChildByName('empty') as Laya.Sprite;
            this.txtEmpty = this.comEmpty.getChildByName('title') as Laya.Label;
            let aniRoot = this.me as ui.liandong.yh.activity_2510questcrew_entrustUI;
            this.aniShowBg = aniRoot.showbg;
            this.aniHideBg = aniRoot.hidebg;
        }

        private changeSelect(index: number) {
            if (this.selectedTabIndex == index) return;
            let showIndex = this.selectedTabIndex;
            this.selectedTabIndex = index;
            let completed = false;
            if (this.quests[showIndex]) {
                completed = !ActivityQuestCrewData.Inst.nowQuests.find(value => value.quest_id == this.quests[showIndex].id);
            }
            if (completed) {
                if (this.selectedTabIndex > showIndex) {
                    this.selectedTabIndex--;
                }
                this.onCheckedResult(showIndex);
            } else {
                if (showIndex >= 0) {
                    this.questTabs.wantToRefreshItem(showIndex);
                }
                this.questTabs.wantToRefreshItem(this.selectedTabIndex);
                this.refreshNowQuest();
            }
        }

        private refreshNowQuest(fromResult: boolean = false) {
            let quest = this.quests[this.selectedTabIndex];
            this.comEmpty.visible = !quest;
            if (quest) {
                this.questDetail.show(quest, this.members);
                this.questWork.show(quest, fromResult);
            } else {
                this.questDetail.hide();
                this.questWork.hide();
                let lockedCount = ActivityQuestCrewData.Inst.lockedQuests.length;
                this.txtEmpty.text = game.Tools.strOfLocalization(lockedCount > 0 ? 25101036 : 25101037);
            }
        }

        private renderTabItem(data) {
            let index = data.index;
            let cache_data = data.cache_data;
            let item: Laya.Sprite = data.container;
            if (!cache_data.head) {
                cache_data.head = new UI_QuestCrew_QuestHead(item.getChildByName('head') as Laya.Sprite);
            }
            let head = cache_data.head as UI_QuestCrew_QuestHead;
            head.me.scale(1, 1);
            head.me.alpha = 1;
            head.refresh(this.quests[index].config);
            head.setClickHandler(Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.changeSelect(index);
            }, null, false));
            head.selected = index == this.selectedTabIndex;
        }


        public show(doAnim: boolean = true) {
            this.enable = true;
            this.quests = [];
            this.members = [];
            let quests = ActivityQuestCrewData.Inst.nowQuests;
            if (ActivityQuestCrewData.Inst.duringGuide) {
                quests = [ActivityQuestCrewData.Inst.guideQuestData];
            }
            for (let i = 0; i < quests.length; i++) {
                let id = quests[i].quest_id;
                this.quests.push(new QuestCrew_QuestData(id, []));
            }
            this.quests.sort((a, b) => a.config.sort - b.config.sort);
            this.refreshQuests();
            this.aniShowBg.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShowBg.interval * this.aniShowBg.count, this, () => {
                this.locking = false;
            });
            let list = this.questTabs;
            list.me.mouseEnabled = false;
            let tween_config = { delay: 68, duration: 150, ease: Laya.Ease.quadInOut };
            let start_config = { alpha: 0, y_dis: 100 };
            let target_config = { alpha: 1 };
            let count = list.items.length > 5 ? 5 : list.items.length;
            let list_delay = 150 + (count - 1) * 68;
            game.Tools.listAnim(list, count, tween_config, start_config, target_config);
            Laya.timer.once(list_delay, this, () => {
                list.me.mouseEnabled = true;
            });
        }

        public refreshQuests() {
            this.selectedTabIndex = -1;
            this.questTabs.reset();
            this.questTabs.addItem(this.quests.length);
            this.changeSelect(0);
        }

        public onCheckedResult(index: number = -1) {
            ActivityQuestCrewData.Inst.checkEmployee();
            let checkedIndex = index < 0 ? this.selectedTabIndex : index;
            if (index < 0) {
                this.selectedTabIndex = 0;
            }
            this.quests.splice(checkedIndex, 1);
            this.delItemWithAnim(checkedIndex, index >= 0);
            this.refreshNowQuest(true);
        }

        public hide(onClose?: Laya.Handler) {
            this.aniHideBg.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHideBg.interval * this.aniHideBg.count, this, () => {
                this.enable = false;
                this.locking = false;
            })
        }

        public refreshNowProgress(quest: QuestCrew_QuestData) {
            this.questDetail.refreshProgress(quest);
        }

        public onDisable(): void {
            this.questDetail.hide();
            this.questWork.hide();
            this.questTabs.reset();
            this.questWork.resetOrder();
        }


        //删除某项 index 删除哪一项 haveselected 是否有目标选中
        private delItemWithAnim(index: number, haveSelected: boolean) {
            for (let i: number = 0; i < this.questTabs.items.length; i++) {
                if (this.questTabs.items[i].value_index == index) {
                    let head = this.questTabs.items[i].cache_data['head'] as UI_QuestCrew_QuestHead;
                    if (head) {
                        Laya.Tween.to(head.me, { scaleX: 0, scaleY: 0, alpha: 0 }, 200, Laya.Ease.quadInOut);
                    }
                }
            }
            let scrollY = this.questTabs._content.vScrollBar.value;
            let targetPos = this.selectedTabIndex * 190;
            if (targetPos + 190 < scrollY || targetPos > scrollY + this.questTabs._content.height) {
                scrollY = targetPos;
            }
            if (scrollY > 0 && scrollY + this.questTabs._content.height > this.quests.length * 190 + this.questTabs.extraHeight) {
                scrollY = this.quests.length * 190 + this.questTabs.extraHeight - this.questTabs._content.height;
            }
            this.questTabs.me.mouseEnabled = false;
            this.locking = true;
            Laya.timer.once(200, this, () => {
                this.questTabs.reset();
                this.questTabs.addItem(this.quests.length);
                this.questTabs.scrollDelta(scrollY);
                let startIndex = Math.floor(scrollY / 190);
                let aniCount = 0;
                let aniMaxCount = 6;
                startIndex = haveSelected && index > startIndex ? index : startIndex;
                for (let aniIndex: number = startIndex; aniIndex < startIndex + aniMaxCount; aniIndex++) {
                    for (let i: number = 0; i < this.questTabs.items.length; i++) {
                        if (this.questTabs.items[i].value_index == aniIndex) {
                            let targetY = this.questTabs.items[i].container.y;
                            this.questTabs.items[i].container.y = targetY + 100;
                            this.questTabs.items[i].container.alpha = 0;
                            Laya.Tween.to(this.questTabs.items[i].container, { y: targetY, alpha: 1 }, 150, Laya.Ease.quadInOut, null, (aniIndex - startIndex) * 68);
                            aniCount++;
                        }
                    }
                }
                Laya.timer.once(aniCount * 68 + 150, this, () => {
                    this.questTabs.me.mouseEnabled = true;
                    this.locking = false;
                })
            })
        }

        public initEffect(effect: Laya.Sprite3D) {
            this.questWork.initEffect(effect);
        }

        public destroyEffect(): void {
            this.questWork.destroyEffect();
        }

        public refreshGuideState(type: E_Act_Yindao_Type) {
            this.questWork.refreshGuideState(type);
        }
    }
}