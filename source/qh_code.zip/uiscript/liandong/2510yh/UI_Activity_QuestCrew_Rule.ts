/**
* 24ba提案界面
*/
module uiscript {

    export class UI_Activity_QuestCrew_Rule extends UIBase {
        public static Inst: UI_Activity_QuestCrew_Rule;
        constructor() {
            super(new ui.liandong.yh.activity_2510questcrew_ruleUI());
            UI_Activity_QuestCrew_Rule.Inst = this;
        }

        private bg: Laya.Image;
        private root: Laya.Sprite;
        private rootBg: Laya.Image;
        private img: Laya.Image;
        private btnLeft: Laya.Button;
        private btnRight: Laya.Button;
        private btnClose: Laya.Button;
        private imgSelected: Laya.Image;
        private pageCount: number = 4;
        private pageIndex: number = 0;
        private locking: boolean;
        private onClose: Laya.Handler;

        public onCreate() {
            this.root = this.me.getChildByName('root') as Laya.Sprite;
            this.bg = this.me.getChildByName('bg') as Laya.Image;

            this.rootBg = this.root.getChildByName('bg') as Laya.Image;
            this.img = this.root.getChildByName('img') as Laya.Image;
            this.btnLeft = this.root.getChildByName('btn_left') as Laya.Button;
            this.btnRight = this.root.getChildByName('btn_right') as Laya.Button;
            this.btnClose = this.root.getChildByName('btn_close') as Laya.Button;
            this.imgSelected = this.root.getChildByName('selected') as Laya.Image;
            this.btnLeft.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(this.pageIndex - 1);
            });

            this.btnRight.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.showPage(this.pageIndex + 1);
            });

            this.btnClose.clickHandler = (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.close();
            });
        }

        public show(extraConfig: IRuleExtraConfig) {
            this.onClose = extraConfig.onClose;
            this.enable = true;
            this.locking = true;
            this.bg.alpha = 0;
            Laya.Tween.to(this.bg, { alpha: 0.3 }, 200);
            this.root.scale(1, 1);
            UIBase.anim_pop_out(this.root, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
            this.showPage(0);
        }

        private close() {
            this.locking = true;
            Laya.Tween.to(this.bg, { alpha: 0 }, 200);
            UIBase.anim_pop_hide(this.root, Laya.Handler.create(this, () => {
                this.enable = false;
                this.locking = false;
                this.onClose?.run();
            }));
        }

        private showPage(index: number) {
            if (index < 0 || index >= this.pageCount) return;
            this.pageIndex = index;
            this.btnLeft.visible = index != 0;
            this.btnRight.visible = index != this.pageCount - 1;
            game.LoadMgr.setImgSkin(this.img, `myres/activity_2510questcrew/rule/${index + 1}.png`, null, 'UI_Activity_QuestCrew_Rule');
            this.imgSelected.x = 890 + index * 40;
        }

        public onEnable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_QuestCrew_Rule', true);
        }

        public onDisable(): void {
            game.TempImageMgr.setUIEnable('UI_Activity_QuestCrew_Rule', false);
        }
    }
}