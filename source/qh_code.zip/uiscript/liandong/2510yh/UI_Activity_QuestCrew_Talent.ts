module uiscript {
    class UI_QuestCrew_SelectItem extends UI_Component {
        private father: UI_Activity_QuestCrew_Talent;
        private head: UI_QuestCrew_EmployeeHead;
        private comRoot: Laya.Sprite;
        private comAnim: Laya.Sprite;
        private comCard: ui.liandong.yh.activity_2510questcrew_cardUI;
        private imgSelected: Laya.Image;
        private imgFrame: Laya.Image;
        private btnCard: Laya.Button;
        private index: number;
        private data: IQcChara;
        private aniShow: Laya.FrameAnimation;
        private aniClick: Laya.FrameAnimation;
        private locking: boolean;

        constructor(me: Laya.Sprite, father: UI_Activity_QuestCrew_Talent) {
            super(me);
            this.father = father;
            this.comCard = this.me.getChildByName('card') as ui.liandong.yh.activity_2510questcrew_cardUI;
            this.comAnim = this.comCard.getChildByName('anim') as Laya.Sprite;
            this.comRoot = this.comAnim.getChildByName('card') as Laya.Sprite;
            this.head = new UI_QuestCrew_EmployeeHead(this.comRoot);
            this.imgSelected = this.comRoot.getChildByName('selected') as Laya.Image;
            this.imgFrame = this.comRoot.getChildByName('frame') as Laya.Image;
            this.btnCard = this.comRoot.getChildByName('btn') as Laya.Button;
            this.imgSelected = this.comRoot.getChildByName('selected') as Laya.Image;
            this.btnCard.clickHandler = Laya.Handler.create(this, () => {
                if (this.father.locking) return;
                if (this.locking) return;
                if (this.data.character_id == this.father.selectedCharaId) return;
                this.aniClick.play(0, false);
                this.father.onItemSelected(this.index);
            }, null, false);
            this.aniShow = this.comCard.show;
            this.aniClick = this.comCard.click;
        }

        refreshShow(data: IQcChara, index: number) {
            this.data = data;
            this.index = index;
            this.head.refresh(data);
            this.imgSelected.visible = this.data.character_id == this.father.selectedCharaId;
            let charaType = data.item_id ? 1 : 2;
            this.imgFrame.skin = game.Tools.localUISrc('myres/activity_2510questcrew/employee_box_' + charaType + '.png');
        }

        doAnimShow() {
            this.aniClick.stop();
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.count * this.aniShow.interval, this, () => {
                this.locking = false;
            })
        }
    }

    enum EEmployeeDetailAnimType {
        hireShow,
        hireHide,
        hire,
        showDetail,
        changeSelect,
        afterHireShow
    }

    export class UI_QuestCrew_EmployeeDetail extends UI_Component {

        private comCard: Laya.Sprite;
        private card: UI_QuestCrew_EmployeeCard;
        private imgBg: Laya.Image;
        private txtName: Laya.Label;
        private txtSkill: Laya.Label;
        private imgSkillStar: Laya.Image;
        private btnCharge: Laya.Button;
        private btnHire: Laya.Button;
        public data: IQcChara;
        private isHire: boolean;
        private anims: Laya.FrameAnimation[];
        private imgPass: Laya.Image;
        private locking: boolean;
        private effectCharge: game.UIEffect;
        private originFontSize: number;
        private canHire: boolean;
        private canCharge: boolean;

        public constructor(me: Laya.Sprite, isHire: boolean) {
            super(me);
            this.isHire = isHire;
            this.comCard = this.me.getChildByName('card') as Laya.Sprite;
            this.card = new UI_QuestCrew_EmployeeCard(this.comCard.getChildByName('card') as Laya.Sprite);
            this.imgBg = this.comCard.getChildByName('bg') as Laya.Image;
            this.imgSkillStar = this.comCard.getChildByName('star') as Laya.Image;
            this.txtName = this.comCard.getChildByName('name') as Laya.Label;
            this.txtSkill = this.comCard.getChildByName('skill') as Laya.Label;
            this.btnCharge = this.me.getChildByName('charge') as Laya.Button;
            this.btnHire = this.me.getChildByName('hire') as Laya.Button;
            this.imgPass = this.comCard.getChildByName('pass') as Laya.Image;
            this.btnCharge.visible = !this.isHire;
            this.btnHire.visible = this.isHire;
            if (this.btnCharge.visible) {
                this.btnCharge.clickHandler = Laya.Handler.create(this, () => {
                    if (this.locking) return;
                    if (UI_Activity_QuestCrew_Talent.Inst.locking) return;
                    if (!this.canCharge) {
                        UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101061));
                        return;
                    }
                    const param: game.IReqQuestCrewActivityFeed = {
                        activity_id: ActivityQuestCrewData.Inst.activityId,
                        member_id: [this.data.character_id]
                    }
                    ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.ChargePower, param);
                }, null, false);
            }
            if (this.btnHire.visible) {
                this.btnHire.clickHandler = Laya.Handler.create(this, () => {
                    if (this.locking) return;
                    if (UI_Activity_QuestCrew_Talent.Inst.locking) return;
                    if (!this.canHire) {
                        UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101061));
                        return;
                    }
                    const param: game.IReqQuestCrewActivityHire = {
                        activity_id: ActivityQuestCrewData.Inst.activityId,
                        member_id: this.data.character_id
                    }
                    ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.HireEmployee, param);
                }, null, false);
            }
            let aniRoot = this.me as ui.liandong.yh.activity_2510questcrew_employee_detailUI;
            this.anims = [];
            this.anims.push(aniRoot.assign_show);
            this.anims.push(aniRoot.assign_hide);
            this.anims.push(aniRoot.recruit);
            this.anims.push(aniRoot.roster_show);
            this.anims.push(aniRoot.roster_toggle);
            this.anims.push(aniRoot.recruit_show);
            if (this.txtSkill && GameMgr.client_language == 'kr') {
                this.txtSkill.font = 'NotoSansKR';
            }
            this.originFontSize = this.txtSkill.fontSize;
        }

        refresh(data: IQcChara, animType?: EEmployeeDetailAnimType) {
            this.clearAnim();
            this.me.scale(1, 1);
            this.me.alpha = 1;
            this.data = data;
            this.card.refresh(data, this.isHire);
            this.imgSkillStar.visible = false;
            this.imgPass.visible = false;
            this.txtSkill.text = '';
            if (data.skill) {
                this.imgSkillStar.visible = true;
                this.txtSkill.text = UI_QuestCrew_Extension.iconReplaceStr + game.Tools.eventStrOfLocalization(data.skill);
                let scale = this.txtSkill.fontSize / this.originFontSize;
                this.imgSkillStar.scale(scale, scale);
            }
            this.txtName.text = data.charaName;
            let charaType = data.item_id ? 1 : 2;
            this.imgBg.skin = game.Tools.localUISrc('myres/activity_2510questcrew/talent_center_list_bottom_' + charaType + '.png')
            this.refreshBtnCharge();
            this.refreshBtnHire();
            this.playAnim(animType);
        }

        refreshState(rotation: number, x: number, doAnim: boolean = false, delay: number = null) {
            this.clearAnim();
            if (doAnim) {
                Laya.Tween.to(this.me, { x }, 200, Laya.Ease.quadInOut, null, delay);
                Laya.Tween.to(this.card.me, { rotation }, 100, null, null, delay);
            } else {
                this.me.x = x;
                this.card.me.rotation = rotation;
            }
        }

        refreshBtnCharge() {
            if (this.btnCharge.visible) {
                let isGrey = false;
                let count = ActivityQuestCrewData.Inst.getConsumedByCharaId(this.data.character_id);
                let feedCount = ActivityQuestCrewData.Inst.getFeedCount(1);
                if (count == this.data.sta) {
                    isGrey = true;
                } else if (count < this.data.sta) {
                    if (!ActivityQuestCrewData.Inst.isFishEnough(feedCount)) isGrey = true;
                }
                this.canCharge = !isGrey;
                (this.btnCharge.getChildByName('count') as Laya.Label).text = feedCount.toString();
                this.setBtnGrey(this.btnCharge, isGrey, count < this.data.sta);
            }
        }

        refreshBtnHire() {
            if (this.btnHire.visible) {
                let hirePrice = 0;
                if (this.data.hiring_price) {
                    hirePrice = Number(this.data.hiring_price.split('-')[1]);
                }
                (this.btnHire.getChildByName('count') as Laya.Label).text = hirePrice.toString();
                this.canHire = ActivityQuestCrewData.Inst.isFishEnough(hirePrice);
                this.setBtnGrey(this.btnHire, !this.canHire, true);
            }
        }

        setBtnGrey(btn: Laya.Button, isGrey: boolean, isMouseEnable: boolean) {
            btn.mouseEnabled = isMouseEnable;
            (btn.getChildByName('title') as Laya.Label).color = isGrey ? '#7f7896' : '#633d2d';
            (btn.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/button_long' + ((isGrey ? '_grey' : '')) + '.png');
            (btn.getChildByName('currency_bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/button_currency_end' + ((isGrey ? '_grey' : '')) + '.png');
        }

        hide(animType?: EEmployeeDetailAnimType) {
            if (animType == null) {
                this.visible = false;
                return;
            }
            this.locking = true;
            view.AudioMgr.PlayAudio(10361);
            this.playAnim(animType, Laya.Handler.create(this, () => {
                this.locking = false;
                this.visible = false;
            }))
        }

        clearAnim() {
            this.locking = false;
            Laya.timer.clearAll(this);
            Laya.Tween.clearAll(this.me);
            Laya.Tween.clearAll(this.card.me);
            this.anims.forEach(anim => anim.stop());
            if (this.effectCharge) {
                this.effectCharge.destory();
                this.effectCharge = null;
            }
        }

        playAnim(animType: EEmployeeDetailAnimType, onComplete?: Laya.Handler) {
            if (animType == null) {
                onComplete && onComplete.run();
                return;
            }
            if (animType == EEmployeeDetailAnimType.hire) {
                this.imgPass.visible = true;
            }
            this.anims.forEach(anim => anim.stop());
            let anim = this.anims[animType];
            anim.play(0, false);
            Laya.timer.once(anim.interval * anim.count, this, () => {
                onComplete && onComplete.run();
            })
        }

        public onDisable(): void {
            this.clearAnim();
        }

        onPowerChange() {
            this.effectCharge = game.FrontEffect.Inst.create_ui_effect(this.me, 'scene/effect_questcrew_charge.lh', new Laya.Point(60, 70), 1);
            Laya.timer.once(600, this, () => {
                this.card.refresh(this.data, this.isHire);
                this.refreshBtnCharge();
            })
        }
    }
    export class UI_Activity_QuestCrew_Talent extends UIBase {
        public static Inst: UI_Activity_QuestCrew_Talent;
        constructor() {
            super(new ui.liandong.yh.activity_2510questcrew_talentUI);
            UI_Activity_QuestCrew_Talent.Inst = this;
        }

        private comRoot: Laya.Sprite;
        private comBtns: Laya.Sprite;
        private tabGroups: UI_TabGroup_Base;
        private tabButtons: Array<Liandong_TabButton>;
        private comPage1: Laya.Sprite;
        private comPage2: Laya.Sprite;
        private scrollViewCharas: capsui.CScrollView;
        private comSelectedDetail: UI_QuestCrew_EmployeeDetail;
        private comTalents: UI_QuestCrew_EmployeeDetail[];
        private comSort: UI_QuestCrew_Sort;
        private btnRefresh: Laya.Button;
        private comEmpty: Laya.Sprite;
        private comCards: Laya.Sprite;
        private comLine: Laya.Sprite;
        private lineParent: Laya.Sprite;
        private lineTemplete: Laya.Sprite;

        public aniShow: Laya.FrameAnimation;
        public aniHide: Laya.FrameAnimation;

        public locking: boolean;
        public selectedCharaId: number = null;
        public employees: IQcChara[];
        private typeSort: EQuestCrewSort = EQuestCrewSort.sta;
        private marketTalents: IQcChara[];
        private effectAni: Catfood.CAnimator;
        private effect: Laya.Sprite3D;
        private canRefresh: boolean;

        public onCreate(): void {
            this.comRoot = this.me.getChildByName('root') as Laya.Sprite;
            this.comBtns = this.comRoot.getChildByName('tabs') as Laya.Sprite;
            this.comPage1 = this.comRoot.getChildByName('page1') as Laya.Sprite;
            this.comPage2 = this.comRoot.getChildByName('page2') as Laya.Sprite;
            let comContent = this.comPage2.getChildByName('content') as Laya.Sprite;
            this.scrollViewCharas = comContent.scriptMap['capsui.CScrollView'];
            this.scrollViewCharas.init_scrollview(new Laya.Handler(this, this.listItemRender), null, 4);
            this.comSelectedDetail = new UI_QuestCrew_EmployeeDetail(this.comPage2.getChildByName('detail') as Laya.Sprite, false);
            this.comSelectedDetail.refreshState(-1, this.comSelectedDetail.me.x);
            this.comSort = new UI_QuestCrew_Sort(this.comPage2.getChildByName('sort') as Laya.Sprite, this);
            this.comTalents = [];
            this.comCards = this.comPage1.getChildByName('cards') as Laya.Sprite;
            for (let i = 0; i < this.comCards.numChildren; i++) {
                this.comTalents.push(new UI_QuestCrew_EmployeeDetail(this.comCards.getChildAt(i) as Laya.Sprite, true));
            }
            this.comLine = this.comPage1.getChildByName('line_parent') as Laya.Sprite;
            this.comCards = this.comPage1.getChildByName('cards') as Laya.Sprite;
            this.btnRefresh = this.comPage1.getChildByName('refresh') as Laya.Button;
            this.comEmpty = this.comPage1.getChildByName('empty') as Laya.Sprite;
            this.initTabs();
            this.btnRefresh.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (!this.canRefresh) {
                    UI_Info_Small.Inst.show(game.Tools.strOfLocalization(25101061));
                    return;
                }
                const param: game.IReqQuestCrewActivityRefreshMarket = {
                    activity_id: ActivityQuestCrewData.Inst.activityId,
                }
                ActivityQuestCrewData.Inst.sendRequest(EQuestCrewEvent.RefreshMarket, param);
            }, null, false);
            this.lineParent = this.scrollViewCharas._content.getChildByName('line_parent') as Laya.Sprite;
            this.lineTemplete = this.lineParent.getChildAt(0) as Laya.Sprite;
            let aniRoot = this.me as ui.liandong.yh.activity_2510questcrew_talentUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
        }

        private initTabs() {
            //依次为 全部，未完成，已完成
            this.tabGroups = new UI_TabGroup_Base(this, () => {
                return this.locking;
            });
            this.tabButtons = [];
            let tabsName = ['hire', 'list'];
            for (let i = 0; i < tabsName.length; i++) {
                let btn = this.comBtns.getChildByName(tabsName[i]) as Laya.Button;
                this.tabGroups.AddTabButton(btn);
                let tabButton = new Liandong_TabButton(btn, '#fffeee', '#fffeee');
                this.tabButtons.push(tabButton);
            }
            this.tabGroups.onSelectChange = (index: number, btn: Laya.Button, manualSwitching: boolean) => {
                let tabBtn = this.tabButtons[index];
                if (index == this.tabGroups.selectedIndex) {
                    tabBtn.onSelect();
                    this.freshPage();
                }
                else {
                    tabBtn.onDeselect();
                }
            };
        }

        /**
         * 列表Item渲染的方法
         * @param data index: _value_index, container: item.container, cache_data: item.cache_data
         */
        private listItemRender(data) {
            let index = data.index;
            let cache_data = data.cache_data;
            let item: Laya.Sprite = data.container;
            if (!cache_data.card) {
                cache_data.card = new UI_QuestCrew_SelectItem(item, this);
            }
            let card = cache_data.card as UI_QuestCrew_SelectItem;
            card.refreshShow(this.employees[index], index);
        }

        onItemSelected(index: number) {
            let lastSelectedIndex = -1;
            if (this.selectedCharaId) {
                lastSelectedIndex = this.employees.findIndex(v => v.character_id == this.selectedCharaId);
            }
            this.selectedCharaId = this.employees[index].character_id;
            this.comSelectedDetail.refresh(this.employees[index], EEmployeeDetailAnimType.changeSelect);
            this.scrollViewCharas.wantToRefreshItem(index);
            if (lastSelectedIndex >= 0) {
                this.scrollViewCharas.wantToRefreshItem(lastSelectedIndex);
            }
        }

        private freshPage() {
            let pageIndex = this.tabGroups.selectedIndex;
            this.comPage1.visible = pageIndex == 0;
            this.comPage2.visible = pageIndex == 1;
            if (this.comPage1.visible) this.refreshPage1();
            if (this.comPage2.visible) this.refreshPage2();
        }


        onSortChange(index: EQuestCrewSort) {
            if (this.typeSort == index) return;
            this.typeSort = index;
            this.refreshContent();
        }


        public show(pageIndex: number = 0) {
            this.enable = true;
            this.typeSort = EQuestCrewSort.sta;
            this.comSort.reset();
            if (!pageIndex) {
                this.tabGroups.init();
            } else {
                this.tabGroups.selectedIndex = pageIndex;
            }
            this.locking = true;
            this.aniShow.play(0, false);
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.locking = false;
            })
            if (this.effect) {
                this.effect.active = false;
                Laya.timer.once(10 / 60 * 1000, this, () => {
                    this.effect.active = true;
                    let aniName = 'talent_show3';
                    this.effectAni.Play(aniName);
                    let delay = this.effectAni.GetDurationByAnimName(aniName) * 1000;
                    Laya.timer.once(delay, this, () => {
                        this.effectAni.Play('talent_show_idle3');
                    })
                });
            }
        }

        public refreshPage1AfterHire() {
            let nowMarketBoard = ActivityQuestCrewData.Inst.qcData.market_board;
            let lastMarketBoard = this.marketTalents.map(v => v.character_id);
            this.marketTalents = nowMarketBoard.map(id => ActivityQuestCrewData.Inst.charaPool.get(id));
            let startX = 0;
            let delay = 660;
            let removeIndex = -1;
            if (nowMarketBoard.length > 0) {
                let width = (330 * nowMarketBoard.length + 20 * (nowMarketBoard.length - 1));
                startX = 690 - width / 2;
            }
            this.locking = true;
            for (let i = 0; i < this.comTalents.length; i++) {
                let com = this.comTalents[i];
                if (com.visible) {
                    let index = nowMarketBoard.indexOf(com.data.character_id);
                    if (index == -1) {
                        removeIndex = i;
                        com.hide(EEmployeeDetailAnimType.hire);
                    } else {
                        let cardRotation = index % 2 == 1 ? -1 : 1;
                        let targetX = startX + index * 350;
                        com.refreshState(cardRotation, targetX, true, delay);
                        com.refreshBtnHire();
                    }
                }
            }
            let coms = this.comTalents.splice(removeIndex, 1);
            this.comTalents.push(coms[0]);
            Laya.timer.once(delay, this, () => {
                this.refreshPage1Btns();
                ActivityQuestCrewData.Inst.checkEmployee();
                if (nowMarketBoard.length == lastMarketBoard.length - 1) {
                    this.locking = false;
                } else {
                    for (let i = 0; i < this.comTalents.length; i++) {
                        let com = this.comTalents[i];
                        if (this.marketTalents[i]) {
                            com.visible = true;
                            let cardRotation = i % 2 == 1 ? -1 : 1;
                            let targetX = startX + i * 350;
                            if (com.data.character_id != this.marketTalents[i].character_id) {
                                com.refreshState(cardRotation, targetX, false);
                                com.refresh(this.marketTalents[i], EEmployeeDetailAnimType.afterHireShow);
                            } else {
                                com.refreshState(cardRotation, targetX, true);
                            }
                        } else {
                            com.visible = false;
                        }
                    }
                    Laya.timer.once(400, this, () => {
                        this.locking = false;
                    });
                }
            })
        }

        public refreshPage1() {
            if (ActivityQuestCrewData.Inst.duringGuide) {
                this.marketTalents = [ActivityQuestCrewData.Inst.charaPool.get(10002)];
            } else {
                this.marketTalents = ActivityQuestCrewData.Inst.qcData.market_board.map(id => ActivityQuestCrewData.Inst.charaPool.get(id));
            }
            let startX = 0;
            if (this.marketTalents.length) {
                let width = (330 * this.marketTalents.length + 20 * (this.marketTalents.length - 1));
                startX = 690 - width / 2;
            }
            for (let i = 0; i < this.comTalents.length; i++) {
                let com = this.comTalents[i];
                if (this.marketTalents[i]) {
                    com.visible = true;
                    let cardRotation = i % 2 == 1 ? -1 : 1;
                    com.refreshState(cardRotation, startX + i * 350, false);
                    com.refresh(this.marketTalents[i], EEmployeeDetailAnimType.hireShow);
                } else {
                    com.visible = false;
                }
            }
            this.refreshPage1Btns();
            this.locking = true;
            Laya.timer.once(800, this, () => {
                this.locking = false;
            })
        }

        public refreshPage1Btns() {
            this.comEmpty.visible = this.marketTalents.length == 0;
            let haveLeft = ActivityQuestCrewData.Inst.memberBuyCount + this.marketTalents.length < ActivityQuestCrewData.Inst.marketCount;
            // this.comLine.visible = this.marketTalents.length > 0;
            let refreshPrice = ActivityQuestCrewData.Inst.qcConfig.refreshPrice;
            (this.btnRefresh.getChildByName('count') as Laya.Label).text = refreshPrice.toString();
            this.canRefresh = haveLeft && ActivityQuestCrewData.Inst.isFishEnough(refreshPrice);
            this.btnRefresh.mouseEnabled = haveLeft;
            (this.btnRefresh.getChildByName('bg') as Laya.Image).skin = game.Tools.localUISrc('myres/activity_2510questcrew/talent_center_button_refresh' + (this.canRefresh ? '' : '_grey') + '.png');
        }

        public refreshPage2() {
            if (ActivityQuestCrewData.Inst.duringGuide) {
                this.employees = [10001, 10002].map((id) => ActivityQuestCrewData.Inst.charaPool.get(id));
            } else {
                this.employees = ActivityQuestCrewData.Inst.memberPool.keys().map((id) => ActivityQuestCrewData.Inst.charaPool.get(id));
            }
            this.selectedCharaId = null;
            this.refreshContent();
            let selectedIndex = ActivityQuestCrewData.Inst.duringGuide ? 1 : 0;
            if (this.employees[selectedIndex]) {
                this.selectedCharaId = this.employees[selectedIndex].character_id;
                this.comSelectedDetail.refresh(this.employees[selectedIndex]);
                this.scrollViewCharas.wantToRefreshItem(selectedIndex);
            } else {
                this.comSelectedDetail.hide();
            }
            let lineCount = Math.ceil(this.employees.length / 4);
            for (let i = 0; i < lineCount; i++) {
                let line = this.lineParent.getChildAt(i) as Laya.Image;
                if (!line) {
                    line = this.lineTemplete.scriptMap['capsui.UICopy']['getNodeClone']();
                    this.lineParent.addChild(line);
                    line.y = 6 + 310 * i;
                }
                line.visible = true;
            }
            if (this.lineParent.numChildren > lineCount) {
                for (let i = lineCount; i < this.lineParent.numChildren; i++) {
                    (this.lineParent.getChildAt(i) as Laya.Image).visible = false;
                }
            }
            this.comSelectedDetail.visible = false;
            let delay = Math.min(Math.floor(this.employees.length / 4) * 150, 300);
            Laya.timer.once(delay, this, () => {
                this.comSelectedDetail.visible = true;
                this.comSelectedDetail.playAnim(EEmployeeDetailAnimType.showDetail);
            })
        }

        refreshContent(doAnim: boolean = true) {
            this.employees.sort((a, b) => {
                if (this.typeSort == EQuestCrewSort.sta) {
                    let powerA = ActivityQuestCrewData.Inst.getConsumedByCharaId(a.character_id);
                    let powerB = ActivityQuestCrewData.Inst.getConsumedByCharaId(b.character_id);
                    if (powerB != powerA) return powerB - powerA;
                }
                if (this.typeSort == EQuestCrewSort.spd && a.spd != b.spd) return b.spd - a.spd;
                if (this.typeSort == EQuestCrewSort.luc && a.luc != b.luc) return b.luc - a.luc;
                if (this.typeSort == EQuestCrewSort.str && a.str != b.str) return b.str - a.str;
                return a.character_id - b.character_id;
            });
            this.scrollViewCharas.reset();
            if (this.employees.length > 0) {
                this.scrollViewCharas.addItem(this.employees.length);
            }
            if (!doAnim) {
                let index = -1;
                if (this.selectedCharaId) {
                    index = this.employees.findIndex(v => v.character_id == this.selectedCharaId);
                }
                if (index >= 0) {
                    this.scrollViewCharas._content.vScrollBar.value = Math.floor(index / 4) * 310;
                }
                return;
            }
            this.scrollViewCharas.me.mouseEnabled = false;
            //哪几行做了动画
            let lineIndexs = [];
            this.scrollViewCharas.items.forEach((data, index) => {
                let cache_data = data.cache_data;
                let card = cache_data['card'] as UI_QuestCrew_SelectItem;
                if (card) {
                    card.me.visible = false;
                    //当前属于第几行
                    let lineIndex = Math.floor((data.value_index) / 4);
                    if (lineIndexs.indexOf(lineIndex) == -1) lineIndexs.push(lineIndex);
                    Laya.timer.once(lineIndex * 150, this, () => {
                        card.me.visible = true;
                        card.doAnimShow();
                    });
                }
            });
            Laya.timer.once(lineIndexs.length * 150 + 100, this, () => {
                this.scrollViewCharas.me.mouseEnabled = true;
            })
        }

        onEmployeePowerChange() {
            view.AudioMgr.PlayAudio(10363);
            this.comSelectedDetail.onPowerChange();
            this.locking = true;
            Laya.timer.once(600, this, () => {
                this.locking = false;
                let index = -1;
                if (this.typeSort == EQuestCrewSort.sta) {
                    this.refreshContent(false);
                }
                if (this.selectedCharaId) {
                    index = this.employees.findIndex(v => v.character_id == this.selectedCharaId);
                }
                if (this.typeSort != EQuestCrewSort.sta) {
                    this.scrollViewCharas.wantToRefreshItem(index);
                }
            })
        }

        public hide() {
            this.locking = true;
            this.effectAni.Play('talent_show_hide3');
            this.aniHide.play(0, false);
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.enable = false;
                this.locking = false;
            })
        }

        public onEnable(): void {
            ActivityQuestCrewData.Inst.on(EQuestCrewEvent.HireEmployee, this, this.refreshPage1AfterHire);
            ActivityQuestCrewData.Inst.on(EQuestCrewEvent.RefreshMarket, this, this.refreshPage1);
            ActivityQuestCrewData.Inst.on(EQuestCrewEvent.ChargePower, this, this.onEmployeePowerChange);
        }

        public onDisable(): void {
            ActivityQuestCrewData.Inst.off(EQuestCrewEvent.HireEmployee, this, this.refreshPage1AfterHire);
            ActivityQuestCrewData.Inst.off(EQuestCrewEvent.RefreshMarket, this, this.refreshPage1);
            ActivityQuestCrewData.Inst.off(EQuestCrewEvent.ChargePower, this, this.onEmployeePowerChange);
            Laya.timer.clearAll(this);
            this.locking = false;
            if (this.effect) this.effect.active = false;
        }

        initEffect(effect: Laya.Sprite3D) {
            this.effect = effect;
            this.effect.active = false;
            this.effectAni = (this.effect.getChildAt(0).getChildAt(0) as Laya.Sprite3D).getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
        }

        public destroyEffect(): void {
            this.effect = null;
        }
    }
}