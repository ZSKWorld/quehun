module uiscript {

    export class UI_Activity_QuestCrew_Tip extends UIBase {
        public static Inst: UI_Activity_QuestCrew_Tip;
        constructor() {
            super(new ui.liandong.yh.activity_2510questcrew_tipUI);
            UI_Activity_QuestCrew_Tip.Inst = this;
        }

        private comRoot: Laya.Sprite;
        private head: UI_QuestCrew_EmployeeHead;
        private txtName: Laya.Label;
        private btnClose: Laya.Button;
        private data: IQcChara;
        private locking: boolean;
        private aniShow: Laya.FrameAnimation;
        private aniHide: Laya.FrameAnimation;

        public onCreate(): void {
            this.comRoot = this.me.getChildByName('root') as Laya.Sprite;
            this.btnClose = this.me.getChildByName('close') as Laya.Button;
            this.head = new UI_QuestCrew_EmployeeHead(this.comRoot.getChildByName('head') as Laya.Sprite);
            this.txtName = this.comRoot.getChildByName('name') as Laya.Label;
            ActivityQuestCrewData.Inst.on(EQuestCrewEvent.NewEmployee, this, this.show);
            this.btnClose.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                this.hide();
            }, null, false);
            let aniRoot = this.me as ui.liandong.yh.activity_2510questcrew_tipUI;
            this.aniShow = aniRoot.show;
            this.aniHide = aniRoot.hide;
        }

        show(id: number) {
            this.data = ActivityQuestCrewData.Inst.charaPool.get(id);
            this.head.refresh(this.data);
            this.txtName.text = this.data.charaName;
            this.enable = true;
            Laya.timer.clearAll(this);
            this.aniShow.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniShow.interval * this.aniShow.count, this, () => {
                this.locking = false;
            });
            view.AudioMgr.PlayAudio(10362);
        }

        hide() {
            this.aniShow.stop();
            this.aniHide.play(0, false);
            this.locking = true;
            Laya.timer.once(this.aniHide.interval * this.aniHide.count, this, () => {
                this.locking = false;
                this.enable = false;
            })
        }
    }
}