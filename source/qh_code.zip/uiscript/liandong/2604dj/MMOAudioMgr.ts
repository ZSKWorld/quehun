module uiscript {
    export class MMOAudioMgr {
        private static _instance: MMOAudioMgr;
        public static get Inst(): MMOAudioMgr {
            return this._instance || (this._instance = new MMOAudioMgr());
        }
        private audioIds: number[] = [];
        private get speed(): number {
            if (!MMOData.Inst.gaming) return 1;
            return MMOData.Inst.speed;
        }

        constructor() {
            MMOData.Inst.on(EMMOEvent.SPEED_CHANGE, this, this.onSpeedChange);
            MMOData.Inst.on(EMMOEvent.PAUSE_GAME, this, this.pauseAudio);
            MMOData.Inst.on(EMMOEvent.RESUME_GAME, this, this.resumeAudio);
        }

        onSpeedChange() {
            for (let i = 0; i < this.audioIds.length; i++) {
                const audio = view.AudioMgr.GetAudioChannel(this.audioIds[i]);
                if (audio) {
                    if (audio.setPlaybackRate) {
                        audio.setPlaybackRate(this.speed);
                    }
                }
            }
        }

        pauseAudio() {
            for (let i = 0; i < this.audioIds.length; i++) {
                view.AudioMgr.PauseAudio(this.audioIds[i]);
            }
        }

        resumeAudio() {
            for (let i = 0; i < this.audioIds.length; i++) {
                view.AudioMgr.ResumeAudio(this.audioIds[i]);
            }
        }

        playAudio(audio: string) {
            if (!audio) return 0;
            // app.Log.log("playAudio ================= " + audio);
            const id = view.AudioMgr.PlaySound(audio, view.AudioMgr.audioVolume, null, 0, view.EAudioType.audio, this.speed);
            this.audioIds.push(id);
            return id;
        }

        stopAudio(id: number) {
            view.AudioMgr.StopAudio(id);
            this.audioIds = this.audioIds.filter((item) => item != id);
        }
    }
}