module uiscript {
    export const MMOEquipmentBg1s = [
        "myres/activity_2604dj/item_icon/item_icon_base_000.png",
        "myres/activity_2604dj/item_icon/item_icon_base_001.png",
        "myres/activity_2604dj/item_icon/item_icon_base_002.png",
        "myres/activity_2604dj/item_icon/item_icon_base_003.png",
        "myres/activity_2604dj/item_icon/item_icon_base_004.png",
        "myres/activity_2604dj/item_icon/item_icon_base_005.png",
    ];
    /** 装备类型 */
    export const enum EMMOEquipType {
        /** 武器 */
        WuQi,
        /** 防具 */
        FangJu,
        /** 头饰 */
        TouShi,
    }
    /**
     * 事件枚举
     */
    export enum EMMOEvent {
        START_GAME = "MMOStartGame",
        FINISH_GAME = "MMOFinishGame",
        ABANDON_GAME = "MMOAbandonGame",
        GAME_UPDATE = "MMOGameUpdate",
        PAUSE_GAME = "MMOPauseGame",
        SPEED_CHANGE = "MMOSpeedChange",
        RESUME_GAME = "MMOResumeGame",
        SET_PROFESSION = "MMOSetProfession",
        SET_EQUIPMENT = "MMOSetEquipment",
        Set_TEAMMATE = "MMOSetTeammate",
        FUSION_EQUIPMENT = "MMOFusionEquipment",
        RECEIVE_SUPPORT = "MMOReceiveSupport",
        FETCH_ACCOUNT = "MMOFetchAccount",
        DO_ACTION = "MMODoAction",
        BUFF_CHANGED = "MMOBuffChanged"
    }

    export enum EMMOProfession {
        None = 0,
        /** 剑士 */
        Sword = 1,
        /** 战士 */
        Warrior = 2,
        /** 法师 */
        Mage = 3
    }

    export enum EMMOProfessionCharacter {
        None = 0,
        /** 剑士 */
        Sword = 1001,
        /** 战士 */
        Warrior = 1002,
        /** 法师 */
        Mage = 1003
    }

    export interface IMMOTeamMemberData {
        character_id: number;
        equipments: number[];
        id: number;
        profession: EMMOProfession;
        power: number;
        type: EMMOPlayerType;
    }

    export enum EMMOPlayerType {
        none,
        friend,
        npc,
        world
    }

    export interface IMMOActivityTeamCandidateData extends game.IMMOActivityTeamCandidateData {
        power: number;
        profession: EMMOProfession;
        type: EMMOPlayerType;
    }

    export interface IMMOEquipmentProp {
        type: string;
        icon: string;
        name: string;
        value: number;
        valueString: string;
    }
    export interface IMMOEquipmentData {
        id: number;
        type: number;
        name: string;
        typeIcon: string;
        rarity: number;
        rarityIcon: string;
        icon: string;
        props: IMMOEquipmentProp[];
        power: number;
    }

    export interface IMMOTickInfo {
        tick: number;
        action: game.IResMMOActivityStartBattle_MMOActivityBattleAction[];
        states: { [key: number]: number };
        anims: { [key: number]: game.EMMOAnimType }; //此tick的动画类型，一个人同一个tick只能有一个动作
        isEnd: boolean;
    }

    export interface IMMOEquipmentProp {
        type: string;
        icon: string;
        name: string;
        value: number;
        valueString: string;
        buffIds?: number[];
    }
    export interface IMMOEquipmentData {
        id: number;
        type: number;
        name: string;
        typeIcon: string;
        rarity: number;
        rarityIcon: string;
        icon: string;
        props: IMMOEquipmentProp[];
        power: number;
    }

    export interface IMMOPlayerInfo {
        account_id: number;
        avatar_id: number;
        nickname: string;
        avatar_frame: number;
        verified: number;
        title: number;
    }

    export interface IMMOBattleUnit {
        animConfig: lqc.Sheet_Mmo_MmoWeaponType;
        weaponId: number;
        hp: number;
    }

    const animNames = ['', 'move', 'attack', 'hit', 'cure', 'attack_recovery', 'back', 'cure_recovery', 'defeat', 'win', 'idle', 'war_idle', 'die', 'attack2', 'defeat_idle'];
    /**
     * 数据层：游戏核心数据管理
     */
    export class MMOData extends Laya.EventDispatcher {
        /** 
         * @param type 2-攻击动画 3-受击动画 4-治疗动画
         * @returns 动画名称
         */
        static getAnimName(type: game.EMMOAnimType, equipments: number[]): string {
            let name = animNames[type];
            if (!equipments || equipments.length == 0) return name;
            let equipId = equipments[0];
            if (!equipId) return name;
            let equipConig = MMOData.Inst.equipmentConfig.get(equipId);
            if (!equipConig) return name;
            let weaponConfig = MMOData.Inst.weaponConfig.get(equipConig.weapon_type_id);
            if (!weaponConfig) return name;
            let animType = weaponConfig.anim_type;
            if (animType) {
                return animType + '_' + name;
            } else {
                return name;
            }
        }

        static getAnimConfigByWeaponId(weaponId?: number): lqc.Sheet_Mmo_MmoWeaponType {
            let equipConig = MMOData.Inst.equipmentConfig.get(weaponId);
            if (!equipConig) return null;
            let weaponConfig = MMOData.Inst.weaponConfig.get(equipConig.weapon_type_id);
            return weaponConfig;
        }

        static getSpineEffectName(type: game.EMMOAnimType, weaponId: number) {
            let animName = animNames[type];
            let name = ''
            if (type == game.EMMOAnimType.cure) {
                return 'mage_cure';
            }
            if (type == game.EMMOAnimType.die) {
                return 'monster_die';
            }
            if (!weaponId) {
                let enemyId = MMOData.Inst.roundConfig.enemy_id;
                const enemyConfig = MMOData.Inst.enemyConfig.get(enemyId);
                name = `${enemyConfig.res_name}_${animName}`;
            } else {
                if (!weaponId) return name;
                let equipConfig = MMOData.Inst.equipmentConfig.get(weaponId);
                if (!equipConfig) return name;
                const jobNames = ['', 'sword', 'warrior', 'mage'];
                name = jobNames[equipConfig.type];
                let weaponConfig = MMOData.Inst.weaponConfig.get(equipConfig.weapon_type_id);
                if (!weaponConfig) return name;
                name += weaponConfig.anim_type + '_';
                const rarityToLevel = ['lv0', 'lv1', 'lv1', 'lv2', 'lv2', 'lv3'];
                name += rarityToLevel[equipConfig.rarity] || '';
                name += `_${animName}`;
            }
            return name;
        }

        public static ProfessionIcons1 = [
            "",
            "myres/activity_2604dj/talent_icon1.png",
            "myres/activity_2604dj/talent_icon2.png",
            "myres/activity_2604dj/talent_icon3.png",
        ];

        public static baseResPath: string = "myres/activity_2604dj/";
        public static breadId: number = 30900102;

        public static getEquipmentData(equipmentId: number): IMMOEquipmentData {
            const cfgEquip = MMOData.Inst.equipmentConfig.get(equipmentId);
            const cfgFuncItem = cfg.item_definition.function_item.get(equipmentId);
            if (!cfgEquip || !cfgFuncItem) return null;
            let profession = MMOData.Inst.getEquipProfession(equipmentId);
            let rarity = cfgEquip.rarity;
            let rarityPath = `${MMOData.baseResPath}item_icon_base${Math.max(cfgEquip.rarity, 1)}.png`;
            let professionIcon = MMOData.ProfessionIcons1[profession];
            let power = cfgEquip.power;
            let name = game.Tools.strOfLocalization(cfgFuncItem.name);

            const attributes: Array<IMMOEquipmentProp> = [];
            if (cfgEquip.atk_fixed) {
                attributes.push(
                    {
                        type: 'atk_fixed',
                        icon: MMOData.baseResPath + "equipment_atk_icon.png",
                        name: game.Tools.strOfLocalization('26041029'),
                        value: cfgEquip.atk_fixed,
                        valueString: cfgEquip.atk_fixed.toString()
                    }
                )
            }
            if (cfgEquip.atk_rate) {
                attributes.push(
                    {
                        type: 'atk_rate',
                        icon: MMOData.baseResPath + "equipment_atk_icon.png",
                        name: game.Tools.strOfLocalization('26041030'),
                        value: cfgEquip.atk_rate,
                        valueString: cfgEquip.atk_rate + "%"

                    }
                )
            }
            if (cfgEquip.critical_rate) {
                attributes.push(
                    {
                        type: 'critical_rate',
                        icon: MMOData.baseResPath + "equipment_crit_icon.png",
                        name: game.Tools.strOfLocalization('26041031'),
                        value: cfgEquip.critical_rate,
                        valueString: cfgEquip.critical_rate + "%"
                    }
                )
            }

            if (cfgEquip.critical_damage_fixed) {
                attributes.push(
                    {
                        type: 'critical_damage_fixed',
                        icon: MMOData.baseResPath + "equipment_critdamage_icon.png",
                        name: game.Tools.strOfLocalization('26041032'),
                        value: cfgEquip.critical_damage_fixed,
                        valueString: cfgEquip.critical_damage_fixed.toString()
                    }
                )
            }

            if (cfgEquip.critical_damage_rate) {
                attributes.push(
                    {
                        type: 'critical_damage_rate',
                        icon: MMOData.baseResPath + "equipment_critdamage_icon.png",
                        name: game.Tools.strOfLocalization('26041033'),
                        value: cfgEquip.critical_damage_rate,
                        valueString: cfgEquip.critical_damage_rate.toString() + "%"
                    }
                )
            }


            if (cfgEquip.hp_fixed) {
                attributes.push(
                    {
                        type: 'hp_fixed',
                        icon: MMOData.baseResPath + "equipment_hp_icon.png",
                        name: game.Tools.strOfLocalization('26041034'),
                        value: cfgEquip.hp_fixed,
                        valueString: cfgEquip.hp_fixed.toString()
                    }
                )
            }


            if (cfgEquip.hp_rate) {
                attributes.push(
                    {
                        type: 'hp_rate',
                        icon: MMOData.baseResPath + "equipment_hp_icon.png",
                        name: game.Tools.strOfLocalization('26041035'),
                        value: cfgEquip.hp_rate,
                        valueString: cfgEquip.hp_rate.toString() + "%"
                    }
                )
            }

            if (cfgEquip.heal_rate) {
                attributes.push(
                    {
                        type: 'heal_rate',
                        icon: MMOData.baseResPath + "equipment_hp_icon.png",
                        name: game.Tools.strOfLocalization('26041036'),
                        value: cfgEquip.heal_rate,
                        valueString: cfgEquip.heal_rate.toString() + "%"
                    }
                )
            }

            if (cfgEquip.buff_list) {
                const cfgEquipBuff = cfg.mmo.mmo_equipment_buff.get(cfgEquip.buff_list);
                attributes.push(
                    {
                        type: 'buff_list',
                        icon: null,
                        name: null,
                        value: null,
                        valueString: null,
                        buffIds: [cfgEquipBuff.equipment_buff_desc]

                    }
                );
            }

            let data: IMMOEquipmentData = {
                id: equipmentId,
                name: name,
                type: cfgEquip.type,
                typeIcon: professionIcon,
                rarity: rarity,
                rarityIcon: rarityPath,
                icon: cfgFuncItem.icon,
                props: attributes,
                power: power

            }
            return data;
        }

        private static _instance: MMOData;
        public static get Inst(): MMOData {
            return this._instance || (this._instance = new MMOData());
        }
        // 活动ID
        public initedBuff: boolean = false;
        public activityId: number = 260401;
        public maxEquipRarity: number = 0;
        public activityConfig: lqc.Sheet_Mmo_MmoActivity;
        public levelConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoLevel>;
        public characterConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoCharacter>;
        public equipmentConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoEquipment>;
        public enemyConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoEnemy>;
        public npcConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoNpc>;
        public weaponConfig: basic.Dictionary<number, lqc.Sheet_Mmo_MmoWeaponType>;
        // 根据buffid,获取对应等级的战力值
        public buffPowerConfig: basic.Dictionary<number, { [key: number]: number }>;
        // 根据武器类型，需要读哪些buff
        public weaponBuffConfig: basic.Dictionary<number, number[]>;

        // 游戏状态
        public gaming: boolean = false;
        public duringEnd: boolean = false;
        public lockNetwork: boolean = false;
        public requestMap: { [key: string]: string } = {};
        public data: game.IActivityMMOData;
        public teamData: IMMOTeamMemberData[] = [];
        public candidatePlayerList: IMMOActivityTeamCandidateData[] = [];
        public cachePlayerInfo: basic.Dictionary<number, game.IPlayerBaseView>;
        public defaultEquip: { [key in EMMOProfession]: { [key in EMMOEquipType] } } = {} as any;
        public gameData: game.IResMMOActivityStartBattle;
        public timer: Laya.Timer;
        public duringReceiveSupport: boolean = false;
        public tickInfos: IMMOTickInfo[];
        public nowTickInfo: IMMOTickInfo;
        public battleUnits: basic.Dictionary<number, IMMOBattleUnit> = new basic.Dictionary<number, IMMOBattleUnit>();
        private resultDelayTick: number = 0;

        private startTime: number = 0;
        public isPause: boolean = false;
        public speed: number = 1;
        public resultData: { breadCount: number; finishedLevel: number, nextLevel: number };

        public needFetch: boolean = true;

        public bagEnoughTip: boolean = true;

        get charProfession() { return this.getCharProfession(this.data.character.character_id); }
        /** 0：没有可合成装备，1：可随机合成(4个)，2：可指定合成(5个) */
        get canComposit() {
            const usingEquips = this.data.character.equipments;
            const equips = this.data.bag.equipments;
            const max = this.maxEquipRarity;
            for (let i = 1; i < max; i++) {
                const filterEquips = equips.filter(v => this.equipmentConfig.get(v.id).rarity == i);
                let total = 0;
                for (let j = 0; j < filterEquips.length; j++) {
                    let cnt = filterEquips[j].stack;
                    if (filterEquips[j].id == usingEquips[EMMOEquipType.WuQi]
                        || filterEquips[j].id == usingEquips[EMMOEquipType.FangJu]
                        || filterEquips[j].id == usingEquips[EMMOEquipType.TouShi]
                    )
                        cnt--;
                    total += cnt;
                    if (total >= 5) return 2;
                }
                if (total >= 4) return 1;
            }
            return 0;
        }

        private constructor() {
            super();
            if (!cfg.mmo || !cfg.mmo.mmo_activity) return;
            this.activityConfig = cfg.mmo.mmo_activity.get(this.activityId);
            this.levelConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoLevel>();
            cfg.mmo.mmo_level.getGroup(this.activityId).forEach(element => {
                this.levelConfig.set(element.level_id, element);
            });
            this.characterConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoCharacter>();
            cfg.mmo.mmo_character.getGroup(this.activityId).forEach(element => {
                this.characterConfig.set(element.character_id, element);
            });
            this.equipmentConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoEquipment>();
            cfg.mmo.mmo_equipment.getGroup(this.activityId).forEach(element => {
                this.maxEquipRarity = Math.max(this.maxEquipRarity, element.rarity);
                this.equipmentConfig.set(element.item_id, element);
            });
            this.enemyConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoEnemy>();
            cfg.mmo.mmo_enemy.getGroup(this.activityId).forEach(element => {
                this.enemyConfig.set(element.enemy_id, element);
            });
            this.npcConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoNpc>();
            cfg.mmo.mmo_npc.getGroup(this.activityId).forEach(element => {
                this.npcConfig.set(element.npc_id, element);
            });
            this.weaponConfig = new basic.Dictionary<number, lqc.Sheet_Mmo_MmoWeaponType>();
            cfg.mmo.mmo_weapon_type.getGroup(this.activityId).forEach(element => {
                this.weaponConfig.set(element.weapon_type_id, element);
            });
            this.cachePlayerInfo = new basic.Dictionary<number, game.IPlayerBaseView>();
            this.buffPowerConfig = new basic.Dictionary<number, { [key: number]: number }>();
            this.weaponBuffConfig = new basic.Dictionary<number, number[]>();
            cfg.mmo.mmo_team_talent.getGroup(UI_Activity_MMO_Talent.activityId).forEach(element => {
                element.weapon_type_id.split(',').forEach(v => {
                    let buffIds = this.weaponBuffConfig.get(Number(v));
                    if (!buffIds) {
                        buffIds = [];
                    }
                    if (buffIds.indexOf(Number(element.buff_id)) == -1) {
                        buffIds.push(Number(element.buff_id));
                    }
                    this.weaponBuffConfig.set(Number(v), buffIds);
                });
                let powerConfig = this.buffPowerConfig.get(Number(element.buff_id));
                if (!powerConfig) {
                    powerConfig = {};
                }
                powerConfig[element.buff_level] = element.power;
                this.buffPowerConfig.set(element.buff_id, powerConfig);
            });
            this.requestMap = {
                [EMMOEvent.START_GAME]: game.ERequest.mmoActivityStartBattle,
                [EMMOEvent.FINISH_GAME]: game.ERequest.mmoActivityFinishBattle,
                [EMMOEvent.SET_PROFESSION]: game.ERequest.mmoActivitySetCharacter,
                [EMMOEvent.SET_EQUIPMENT]: game.ERequest.mmoActivitySetEquip,
                [EMMOEvent.Set_TEAMMATE]: game.ERequest.mmoActivitySetTeamMember,
                [EMMOEvent.FUSION_EQUIPMENT]: game.ERequest.mmoActivityEquipFusion,
                [EMMOEvent.RECEIVE_SUPPORT]: game.ERequest.mmoActivityReceiveSupportReward,
            }

            const defaultEquip = this.defaultEquip;
            this.characterConfig.values().forEach(v => {
                const equips = v.init_equipment.split(',').map(Number);

                const equipType0 = this.getEquipType(equips[0]);
                const equipType1 = this.getEquipType(equips[1]);
                const equipType2 = this.getEquipType(equips[2]);

                const dataMap = {};
                dataMap[equipType0] = equips[0];
                dataMap[equipType1] = equips[1];
                dataMap[equipType2] = equips[2];
                defaultEquip[v.weapon_type] = dataMap;
            });
            this.timer = new Laya.Timer();
            app.NetAgent.addListener2Lobby(game.ENotify.NotifyAccountUpdate, Laya.Handler.create(this, (msg: game.INotifyAccountUpdate) => {
                if (msg && msg.update && msg.update.activity) {
                    if (msg.update.activity.mmo_data) {
                        const mmoData = msg.update.activity.mmo_data;
                        for (let i = 0; i < mmoData.length; i++) {
                            if (mmoData[i].activity_id == this.activityId) {

                                if (mmoData[i].bag) {
                                    //更新装备数据
                                    if (mmoData[i].bag.equipments && mmoData[i].bag.equipments.dirty) {
                                        this.data.bag.equipments = [...mmoData[i].bag.equipments.value];
                                    }
                                    //更新装备合成数据
                                    if (mmoData[i].bag.total_fusion_count) {
                                        this.data.bag.total_fusion_count = mmoData[i].bag.total_fusion_count.value;
                                    }
                                    //更新装备获取数据
                                    if (mmoData[i].bag.total_gain_count) {
                                        this.data.bag.total_gain_count = mmoData[i].bag.total_gain_count.value;
                                    }
                                }
                            }
                        }
                    }
                    if (msg.update.activity.activity_buff && msg.update.activity.activity_buff.dirty) {
                        this.onBuffChanged();
                        this.event(EMMOEvent.BUFF_CHANGED);
                    }
                }
            }));
            this.reset();
        }

        public initData(datas?: game.IActivityMMOData[]) {
            if (!cfg.mmo || !cfg.mmo.mmo_activity) return;
            this.data = {
                activity_id: this.activityId,
                bag: {
                    equipments: [],
                    total_gain_count: 0,
                    total_fusion_count: 0,
                    random_record: [],
                },
                character: {
                    character_id: 0,
                    equipments: [],
                },
                map: {
                    level: this.activityConfig.initial_level_id,
                    random_seed: 0,
                    won: 0,
                    failed: 0,
                },
                support: {
                    last_receive_time: 0,
                    most_supporter: null,
                    receive_support_count: 0,
                    support_record: [],
                },
                team: {
                    members: [],
                    friend_list: [],
                    random_friends: [],
                    daily_update_time: 0,
                    npc_list: [],
                    friend_list_expire: 0,
                },
            };
            if (datas) {
                for (let i: number = 0; i < datas.length; i++) {
                    let msg = datas[i];
                    if (msg && msg.activity_id == this.activityId) {
                        this.needFetch = false;
                        this.data = game.Tools.decodeProtoData(msg as any) as game.IActivityMMOData;
                        break;
                    }
                }
            }
            this.refreshTeamData();
            this.sortEquipType();
            this.refreshCandidateList();
            this.speed = Number(game.LocalStorage.getItem('mmoSpeed' + MMOData.Inst.activityId));
            if (!this.speed) this.speed = 1;
            MMO_Equipment_Main_Equip.refreshOldEquip();
        }

        private updateData(msg: game.IActivityMMODataChanges) {
            if (!msg || !this.data || msg.activity_id !== this.data.activity_id) {
                return;
            }
            // 遍历处理所有 dirty 字段
            this.updateDirtyFields(this.data, msg);
            this.refreshTeamData();
            this.sortEquipType();
            this.refreshCandidateList();
        }

        private updateDirtyFields(target: any, source: any) {
            if (!target || !source) return;
            for (let key in source) {
                const value = source[key];
                // 跳过 activity_id 字段
                if (key === 'activity_id') continue;
                // 如果是带有 dirty 标志的字段
                if (value && typeof value === 'object' && 'dirty' in value) {
                    if (value.dirty) {
                        // 特殊处理需要深拷贝的字段
                        if (Array.isArray(value.value)) {
                            target[key] = [...value.value];
                        }
                        // 特殊处理需要解码的字段
                        else if (key === 'most_supporter' && value.value) {
                            target[key] = game.Tools.decodeProtoData(value.value as any);
                        }
                        // 普通字段直接赋值
                        else {
                            target[key] = value.value !== undefined ? value.value : 0;
                        }
                    }
                }
                // 如果是嵌套对象，继续递归
                else if (typeof value === 'object' && target[key]) {
                    this.updateDirtyFields(target[key], value);
                }
            }
        }

        private refreshTeamData() {
            this.teamData = [];
            // 按照制定顺序排排好，首选是我自己的，其次是其他职业的
            let myProfession = EMMOProfession.None;
            if (this.data.character && this.data.character.character_id) {
                this.teamData.push({
                    character_id: this.data.character.character_id,
                    equipments: this.data.character.equipments,
                    id: GameMgr.Inst.account_id,
                    profession: this.getCharProfession(this.data.character.character_id),
                    power: this.getPowerByEquipIds(this.data.character.equipments),
                    type: 0
                });
                myProfession = this.teamData[0].profession;
            }
            // 连自己的数据都没有，组个p的队
            if (this.teamData.length == 0) return;
            let otherSort: EMMOProfession[] = [];
            if (myProfession == EMMOProfession.Sword) {
                otherSort = [EMMOProfession.Mage, EMMOProfession.Warrior];
            } else if (myProfession == EMMOProfession.Mage) {
                otherSort = [EMMOProfession.Sword, EMMOProfession.Warrior];
            } else if (myProfession == EMMOProfession.Warrior) {
                otherSort = [EMMOProfession.Sword, EMMOProfession.Mage];
            }
            const accountIds = [];
            for (let i = 0; i < otherSort.length; i++) {
                const profession = otherSort[i];
                const characterId = EMMOProfessionCharacter[EMMOProfession[profession]];
                let data: IMMOTeamMemberData = {
                    id: 0,
                    character_id: characterId,
                    equipments: [],
                    profession: otherSort[i],
                    power: 0,
                    type: 0
                }
                const member = this.data.team && this.data.team.members ? this.data.team.members.find(v => v.character_id == characterId) : null;
                if (member) {
                    data.equipments = [...member.equipments];
                    data.id = member.id;
                    data.power = this.getPowerByEquipIds(member.equipments);
                    data.type = member.type;
                    if (member.type != 2 && !this.cachePlayerInfo.get(member.id)) accountIds.push(member.id);
                }
                this.teamData.push(data);
            }
            if (accountIds.length > 0) {
                this.fetchAccountBrief(accountIds);
            }
        }

        fetchAccountBrief(accountIds: number[], onComplete?: Laya.Handler) {
            let request: game.IReqMultiAccountId = {
                account_id_list: accountIds
            };
            app.NetAgent.sendReq2Lobby(ServerType.LOBBY, ProtoCode.FETCH_MULTI_ACCOUNT_BRIEF, request, (err, res: game.IResMultiAccountBrief) => {
                if (err || res['error']) {
                } else if (res && res.players) {
                    for (let i = 0; i < res.players.length; i++) {
                        let info = res.players[i];
                        this.cachePlayerInfo.set(info.account_id, info);
                        this.event(EMMOEvent.FETCH_ACCOUNT, info);
                    }
                }
                onComplete && onComplete.run();
            });
        }

        private refreshCandidateList() {
            this.candidatePlayerList = [];
            if (!this.data.team) return;
            // 处理所有待选
            const checkLst = (data: game.IMMOActivityTeamCandidateData[], type: EMMOPlayerType) => {
                if (!data || data.length == 0) return;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].id) {
                        const player = {
                            character_id: data[i].character_id,
                            equipments: data[i].equipments,
                            id: data[i].id,
                            power: this.getPowerByEquipIds(data[i].equipments),
                            profession: this.getCharProfession(data[i].character_id),
                            type: type
                        };
                        const wq = player.equipments.find(v => this.getEquipType(v) == EMMOEquipType.WuQi);
                        const fj = player.equipments.find(v => this.getEquipType(v) == EMMOEquipType.FangJu);
                        const ts = player.equipments.find(v => this.getEquipType(v) == EMMOEquipType.TouShi);
                        player.equipments = [wq, fj, ts];
                        const index = this.candidatePlayerList.findIndex(v => v.id == player.id);
                        if (index >= 0) {
                            if (this.candidatePlayerList[index].power < player.power) {
                                this.candidatePlayerList[index] = player;
                            }
                        } else {
                            this.candidatePlayerList.push(player);
                        }
                    }
                }
            }
            checkLst(this.data.team.friend_list, EMMOPlayerType.friend);
            checkLst(this.data.team.npc_list, EMMOPlayerType.npc);
            checkLst(this.data.team.random_friends, EMMOPlayerType.world);
            // 战力高的在前 ＞ 玩家id小的在前 ＞ NPC
            this.candidatePlayerList.sort((a, b) => {
                if (b.power != a.power) {
                    return b.power - a.power;
                }
                if (b.id != a.id) {
                    return a.id - b.id;
                }
                return 0;
            });
        }

        public get remainTime(): number {
            return this.getTimeByTick(this.roundConfig.total_tick) - this.currentTime;
        }

        // 当前游戏时长
        public get currentTime(): number {
            if (!this.gaming) return 0;
            let duration = this.timer.currTimer - this.startTime;
            if (duration < 0) return 0;
            return duration;
        }

        // 当前tick
        public get currentTick(): number {
            return Math.floor(this.currentTime / 1000 * this.activityConfig.tick);
        }

        public getTimeByTick(tick: number): number {
            return tick / this.activityConfig.tick * 1000;
        }

        public getMinMsecByTime(time: number): string {
            time = Math.max(0, time);

            const totalSeconds = Math.ceil(time / 1000);
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;

            // const msPart = time % 1000;
            // const msTwoDigits = Math.floor(msPart / 10).toString().padStart(2, '0');

            const twoDigitsMinutes = minutes.toString().padStart(2, '0');
            const twoDigitsSeconds = seconds.toString().padStart(2, '0');

            return `${twoDigitsMinutes}:${twoDigitsSeconds}`;
        }

        public get playerStats(): IMMOTeamMemberData {
            if (this.teamData.length == 0) return null;
            return this.teamData[0];
        }

        public get roundConfig(): lqc.Sheet_Mmo_MmoLevel {
            let level = this.activityConfig.initial_level_id;
            if (this.data.map && this.data.map.level) {
                level = this.data.map.level;
            }
            const levelConfig = this.levelConfig.get(level);
            if (levelConfig) return levelConfig;
            return this.levelConfig.get(this.activityConfig.initial_level_id);
        }

        public get isLastPKLose(): boolean {
            if (this.data && this.data.map && this.data.map.failed) {
                return true;
            }
            return false;
        }

        public getPlayerMaxHP(id: number): number {
            return this.battleUnits.get(id)?.hp || 0;
        }

        public getTeamSortedDatas(): IMMOTeamMemberData[] {
            let datas: IMMOTeamMemberData[] = [];
            let sortIds = [1, 0, 2];
            for (let i = 0; i < sortIds.length; i++) {
                datas.push(this.teamData[sortIds[i]]);
            }
            return datas;
        }

        isLevelLocked(id: number) {
            const levelConfig = this.levelConfig.get(id);
            if (levelConfig && levelConfig.unlock_day) {
                let restSeconds = UI_Activity.getActivityUnLockTimeFrom5(MMOData.Inst.activityId, levelConfig.unlock_day);
                if (restSeconds > 0) {
                    return true;
                }
            }
            return false;
        }

        getPowerByEquipIds(equipIds: number[] = []): number {
            let power = 0;
            for (let i = 0; i < equipIds.length; i++) {
                const equipmentConfig = this.equipmentConfig.get(equipIds[i]);
                power += equipmentConfig?.power || 0;
                if (equipmentConfig && equipmentConfig.weapon_type_id) {
                    const buffIds = this.weaponBuffConfig.get(equipmentConfig.weapon_type_id);
                    if (buffIds && buffIds.length > 0) {
                        buffIds.forEach(id => {
                            let level = UI_Activity.getActivityBuffLevel(id);
                            if (level) {
                                power += this.buffPowerConfig.get(id)?.[level] || 0;
                            }
                        })
                    }
                }
            }
            return power;
        }

        getCharProfession(charId: number) {
            const cfgChar = this.characterConfig.get(charId);
            if (!cfgChar) return EMMOProfession.None;
            if (cfgChar.weapon_type == 1) return EMMOProfession.Sword;
            if (cfgChar.weapon_type == 2) return EMMOProfession.Warrior;
            if (cfgChar.weapon_type == 3) return EMMOProfession.Mage;
            return EMMOProfession.None;
        }

        getEquipProfession(equipId: number) {
            const cfgEquip = this.equipmentConfig.get(equipId);
            if (!cfgEquip) return EMMOProfession.None;
            if (cfgEquip.type == 1) return EMMOProfession.Sword;
            if (cfgEquip.type == 2) return EMMOProfession.Warrior;
            if (cfgEquip.type == 3) return EMMOProfession.Mage;
            return EMMOProfession.None;
        }

        getEquipType(equipId: number) {
            const cfgEquip = this.equipmentConfig.get(equipId);
            if (!cfgEquip) {
                app.Log.Error('未知的装备类型  ' + equipId);
                return;
            }
            if (cfgEquip.type == 1 || cfgEquip.type == 2 || cfgEquip.type == 3)
                return EMMOEquipType.WuQi;
            if (cfgEquip.type == 4) return EMMOEquipType.TouShi;
            if (cfgEquip.type == 5) return EMMOEquipType.FangJu;
            app.Log.Error('未知的装备类型');
        }

        public isBagFull(): boolean {
            const { activityConfig, data } = MMOData.Inst;
            const bagMax = activityConfig.equipment_bag_max;
            const equipCount = data.bag.equipments.reduce((pv, cv) => pv + cv.stack, 0);
            // 检查背包是否满了
            const isBagFull = equipCount >= bagMax;
            return isBagFull;
        }

        isDefaultEquip(equipId: number) {
            const defaultEquip = this.defaultEquip;
            for (const k1 in defaultEquip) {
                const e1 = defaultEquip[k1];
                for (const k2 in e1) {
                    if (e1[k2] == equipId) return true;
                }

            }
            return false;
        }

        /** 服务器传回的数据没有固定顺序，每次都要使用都要遍历查找，客户端约定角色和队伍里角色身上装备都按【武器，衣服，饰品】这样的顺序 */
        private sortEquipType() {
            const character = this.data.character;
            if (character) {
                const wq = character.equipments.find(v => this.getEquipType(v) == EMMOEquipType.WuQi);
                const fj = character.equipments.find(v => this.getEquipType(v) == EMMOEquipType.FangJu);
                const ts = character.equipments.find(v => this.getEquipType(v) == EMMOEquipType.TouShi);
                character.equipments = [wq, fj, ts];
            }
            this.teamData.forEach(v => {
                if (v.equipments.length > 0) {
                    const wqv = v.equipments.find(v => this.getEquipType(v) == EMMOEquipType.WuQi);
                    const fjv = v.equipments.find(v => this.getEquipType(v) == EMMOEquipType.FangJu);
                    const tsv = v.equipments.find(v => this.getEquipType(v) == EMMOEquipType.TouShi);
                    v.equipments = [wqv, fjv, tsv];
                }
            });
        }

        //  是否拥有最新的支援数据
        checkSupport(): boolean {
            // 没有角色数据，没有参与过活动不弹
            if (!this.data.character || !this.data.character.character_id) return false;
            if (!this.data.support || !this.data.support.last_receive_time) return true;
            if (!game.Tools.isPassedRefreshTimeServer(this.data.support.last_receive_time)) return true;
            return false;
        }

        //  是否拥有最新的好友列表数据
        isCandidateListNew(): boolean {
            if (this.candidatePlayerList.length == 0) return false;
            if (!this.data.team) return false;
            if (!this.data.team.friend_list_expire || this.data.team.friend_list_expire < (game.Tools.getServerTime() / 1000)) return false;
            if (!this.data.team.daily_update_time) return false;
            if (!game.Tools.isPassedRefreshTimeServer(this.data.team.daily_update_time)) return false;
            return true;
        }

        getRecommendTeammate() {
            let prosessions = [EMMOProfession.Sword, EMMOProfession.Warrior, EMMOProfession.Mage];
            for (let i = 0; i < prosessions.length; i++) {
                if (prosessions[i] == this.playerStats.profession) {
                    prosessions.splice(i, 1);
                    break;
                }
            }
            let member0;
            let member1;
            for (let i = 0; i < this.candidatePlayerList.length; i++) {
                const candidate = this.candidatePlayerList[i];
                if (candidate.profession == prosessions[0] && !member0) {
                    member0 = candidate;
                }
                if (candidate.profession == prosessions[1] && !member1) {
                    member1 = candidate;
                }
                if (member0 && member1) break;
            }
            return [member0, member1];
        }

        isSameMember(player1: IMMOTeamMemberData, player2: IMMOTeamMemberData): boolean {
            if (!player1 || !player2) return false;
            if (player1.id != player2.id) return false;
            if (player1.character_id != player2.character_id) return false;
            if (player1.equipments.length != player2.equipments.length) return false;
            //判断装备是否一致
            for (let i = 0; i < player1.equipments.length; i++) {
                let equipId = player1.equipments[i];
                if (player2.equipments.indexOf(equipId) == -1) {
                    return false;
                }
            }
            return true;
        }

        getNowMemberByCharaId(id: number): IMMOTeamMemberData {
            for (let i = 0; i < this.teamData.length; i++) {
                if (this.teamData[i].character_id == id && this.teamData[i].id > 0) {
                    return this.teamData[i];
                }
            }
            return null;
        }

        getPlayerInfo(member: IMMOTeamMemberData): IMMOPlayerInfo {
            if (member.type == EMMOPlayerType.npc) {
                let config = this.npcConfig.get(member.id);
                if (config) {
                    return {
                        account_id: member.id,
                        avatar_id: 0,
                        nickname: game.Tools.eventStrOfLocalization(config.npc_name),
                        avatar_frame: 0,
                        verified: 0,
                        title: 0
                    };
                }
            }
            let info = this.cachePlayerInfo.get(member.id);
            if (info) {
                if (info.is_banned) {
                    return {
                        account_id: member.id,
                        avatar_id: game.GameUtility.get_default_ai_skin(),
                        nickname: game.Tools.strOfLocalization(3060),
                        avatar_frame: 0,
                        verified: 0,
                        title: 0
                    };
                }
                return info;
            }
            if (member.id == GameMgr.Inst.account_id) {
                return GameMgr.Inst.account_data as IMMOPlayerInfo;
            }
            return null;
        }

        getBestTeamMember(): IMMOTeamMemberData {
            if (this.data.support && this.data.support.most_supporter) {
                const supporter = this.data.support.most_supporter;
                return {
                    id: supporter.id,
                    character_id: supporter.character_id,
                    equipments: supporter.equipments,
                    profession: EMMOProfession[EMMOProfessionCharacter[supporter.character_id]],
                    power: this.getPowerByEquipIds(supporter.equipments),
                    type: supporter.type
                };
            }
            return null;
        }

        pauseGame() {
            if (!this.gaming) return;
            this.isPause = true;
            this.timer.scale = 0;
            this.event(EMMOEvent.PAUSE_GAME);
        }

        resumeGame() {
            if (!this.gaming) return;
            this.isPause = false;
            this.timer.scale = this.speed;
            this.event(EMMOEvent.RESUME_GAME);
        }

        setSpeed(speed: number) {
            if (speed == this.speed) return;
            this.speed = speed;
            this.timer.scale = this.speed;
            this.event(EMMOEvent.SPEED_CHANGE, this.speed);
            game.LocalStorage.setItem('mmoSpeed' + MMOData.Inst.activityId, this.speed.toString());
        }

        reset() {
            this.duringEnd = false;
            this.gaming = false;
            this.timer.scale = this.speed;
            this.timer.clearAllEx();
            this.startTime = 0;
            this.tickInfos = [];
            this.nowTickInfo = null;
            this.isPause = false;
            this.battleUnits = new basic.Dictionary<number, IMMOBattleUnit>();
        }

        sendRequest(eventName: EMMOEvent, param: any, onComplete?: Laya.Handler) {
            if (this.lockNetwork) return;
            let requestName = this.requestMap[eventName];
            if (requestName) {
                this.lockNetwork = true;
                app.Log.log(requestName + ' req ==== ' + JSON.stringify(param));
                app.NetAgent.sendReq2Lobby('Lobby', requestName, param, (err, res) => {
                    this.lockNetwork = false;
                    onComplete?.run();
                    if (err || res['error']) {
                        this.onGameError(requestName, err, res);
                    } else {
                        app.Log.log(requestName + ' res ==== ' + JSON.stringify(res));
                        this.doEvent(eventName, res);
                    }
                });
            } else {
                onComplete?.run();
                this.doEvent(eventName, null);
            }
        }

        doEvent(eventName: EMMOEvent, res?: any) {
            if (res) this.updateData(res.changes);
            if (eventName == EMMOEvent.START_GAME) {
                this.initGameData(res);
            } else if (eventName == EMMOEvent.FINISH_GAME) {
                this.reset();
            } else if (eventName == EMMOEvent.ABANDON_GAME) {
                this.reset();
            }
            this.event(eventName, res);
        }

        initGameData(res: game.IResMMOActivityStartBattle) {
            this.reset();
            this.gameData = game.Tools.decodeProtoData(res as any) as game.IResMMOActivityStartBattle;
            let beginTickInfo: IMMOTickInfo = {
                tick: 0,
                anims: {},
                action: [],
                states: {},
                isEnd: false
            };
            if (this.gameData && this.gameData.units) {
                for (let i = 0; i < this.gameData.units.length; i++) {
                    let unit = this.gameData.units[i]
                    beginTickInfo.states[unit.id] = unit.hp || 0;
                    let animConfig: lqc.Sheet_Mmo_MmoWeaponType = null;
                    let weaponId: number = 0;
                    if (unit.id == this.roundConfig.enemy_id) {
                        const enemyConfig = MMOData.Inst.enemyConfig.get(unit.id);
                        const equipId = Number(enemyConfig.equipment_list);
                        animConfig = MMOData.getAnimConfigByWeaponId(equipId);
                    } else {
                        weaponId = this.teamData.find(v => v.character_id == unit.id)?.equipments?.[0];
                        animConfig = MMOData.getAnimConfigByWeaponId(weaponId || 0);
                    }
                    this.battleUnits.set(unit.id, {
                        animConfig,
                        hp: unit.hp || 0,
                        weaponId: weaponId
                    });
                }
            }
            this.tickInfos.push(beginTickInfo);
            let isEnd: boolean = false;
            let tickInfo = beginTickInfo;
            for (let i = 0; i < this.gameData.actions.length; i++) {
                let action = this.gameData.actions[i];
                if (tickInfo.tick == action.tick) {
                    tickInfo.action.push(action);
                } else {
                    tickInfo = game.Tools.deepCopy(tickInfo) as IMMOTickInfo;
                    this.tickInfos.push(tickInfo);
                    tickInfo.tick = action.tick;
                    tickInfo.action = [action];
                    tickInfo.anims = {};
                }
                if (action.type == 1) {
                    tickInfo.states[action.target] -= action.value;
                    if (tickInfo.states[action.target] <= 0) {
                        tickInfo.states[action.target] = 0;
                        //如果是敌人死了，可以欢呼了
                        if (action.target == this.roundConfig.enemy_id) {
                            tickInfo.anims[action.target] = game.EMMOAnimType.die;
                            for (let key in tickInfo.states) {
                                // 死了的别欢呼了,禁止诈尸
                                if (Number(key) != action.target && tickInfo.states[key] > 0) {
                                    tickInfo.anims[Number(key)] = game.EMMOAnimType.win;
                                }
                            }
                            isEnd = true;
                        } else {
                            tickInfo.anims[action.target] = game.EMMOAnimType.defeat;
                            //如果是玩家死了,敌人要欢呼了,敌人没有欢呼动作
                            isEnd = true;
                            for (let key in tickInfo.states) {
                                if (Number(key) != this.roundConfig.enemy_id && tickInfo.states[key] > 0) {
                                    isEnd = false;
                                    break;
                                }
                            }
                        }
                    }
                } else if (action.type == 2) {
                    tickInfo.states[action.target] += action.value;
                    tickInfo.states[action.target] = Math.min(tickInfo.states[action.target], this.getPlayerMaxHP(action.target));
                } else {
                    // 如果当前没分动画或者 动画是move可以被更高优先级的代替
                    if (!tickInfo.anims[action.from] || tickInfo.anims[action.from] == game.EMMOAnimType.move) {
                        if (action.value == game.EMMOAnimType.attack_recovery || action.value == game.EMMOAnimType.cure_recovery) {
                        } else if (action.value == game.EMMOAnimType.back) {
                            if (!this.battleUnits.get(action.from)?.animConfig?.counter_attack) tickInfo.anims[action.from] = game.EMMOAnimType.move;
                        } else {
                            tickInfo.anims[action.from] = action.value;
                        }
                    }
                }
                if (isEnd) {
                    tickInfo.isEnd = true;
                    break;
                }
            }
            if (isEnd) {
                if (tickInfo.states[this.roundConfig.enemy_id] <= 0) {
                    this.resultDelayTick = this.battleUnits.get(this.roundConfig.enemy_id)?.animConfig?.die_tick + 17
                } else {
                    this.resultDelayTick = 30;
                }
            }
        }

        public startGame() {
            this.gaming = true;
            this.startTime = this.timer.currTimer;
            this.nowTickInfo = this.tickInfos.splice(0, 1)[0];
            this.event(EMMOEvent.DO_ACTION, this.nowTickInfo);
            this.startGameUpdateTimer();
        }

        private startGameUpdateTimer() {
            this.event(EMMOEvent.GAME_UPDATE);
            this.timer.frameLoop(1, this, () => {
                if (!this.gaming || this.isPause) return;
                this.event(EMMOEvent.GAME_UPDATE);
                if (this.remainTime <= 0) {
                    this.checkGameEnd(true);
                } else if (this.tickInfos.length > 0 && this.tickInfos[0].tick < this.currentTick) {
                    this.nowTickInfo = this.tickInfos.splice(0, 1)[0];
                    this.event(EMMOEvent.DO_ACTION, this.nowTickInfo);
                    if (this.nowTickInfo.isEnd) {
                        this.checkGameEnd();
                    }
                }
            });
        }

        abandonGame(onComplete: Laya.Handler) {
            onComplete?.run();
            this.event(EMMOEvent.ABANDON_GAME);
        }

        checkGameEnd(isTimeOut: boolean = false) {
            this.duringEnd = true;
            this.timer.clearAll(this);
            this.resultData = {
                breadCount: UI_Bag.get_item_count(MMOData.breadId),
                finishedLevel: this.roundConfig.level_id,
                nextLevel: this.roundConfig.level_id
            };
            if (this.gameData.result == 1) {
                this.resultData.breadCount -= Number(this.roundConfig.consume.split('-')[1]);
                this.resultData.nextLevel = this.roundConfig.next_level;
            }
            const delay = isTimeOut ? 0 : this.resultDelayTick / 30 * 1000;
            this.timer.once(delay, this, () => {
                this.duringEnd = false;
                this.finishGame();
            })
        }

        finishGame() {
            this.gaming = false;
            if (this.gameData.result == 1) {
                MMOData.Inst.sendRequest(EMMOEvent.FINISH_GAME, { activity_id: MMOData.Inst.activityId });
            } else {
                this.doEvent(EMMOEvent.FINISH_GAME, null);
            }
        }

        updateFriendList(onComplete: Laya.Handler) {
            if (this.lockNetwork) return;
            this.lockNetwork = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.mmoActivityUpdateFriendList, { activity_id: this.activityId }, (err, res: game.IResMMOActivityUpdatehFriendList) => {
                this.lockNetwork = false;
                if (err || res['error']) {
                    this.onGameError(game.ERequest.mmoActivityUpdateFriendList, err, res);
                } else {
                    app.Log.log(game.ERequest.mmoActivityUpdateFriendList + ' res ==== ' + JSON.stringify(res));
                    if (res) {
                        this.data.team.friend_list = res.friend_list ? [...res.friend_list] : [];
                        this.data.team.friend_list_expire = res.expire_time || 0;
                        this.data.team.daily_update_time = game.Tools.getServerTime() / 1000;
                        this.data.team.npc_list = res.npc_list ? [...res.npc_list] : [];
                        this.data.team.random_friends = res.random_friends ? [...res.random_friends] : [];
                        this.candidatePlayerList = [];
                        this.updateData(res.changes);
                    }
                }
                onComplete?.run();
            });
        }

        // 自动选择最优队伍
        addAutoTeam(onComplete?: Laya.Handler) {
            let isDataNew = this.isCandidateListNew();
            if (!isDataNew) {
                this.updateFriendList(Laya.Handler.create(this, () => {
                    this.selectRecommendTeammate(onComplete);
                }));
            } else {
                this.selectRecommendTeammate(onComplete);
            }
        }

        selectRecommendTeammate(onComplete?: Laya.Handler) {
            let team = this.getRecommendTeammate();
            let changed = false;
            for (let i = 0; i < team.length; i++) {
                const member = team[i];
                if (member && !this.isSameMember(member, this.getNowMemberByCharaId(member.character_id))) {
                    changed = true;
                    break;
                }
            }
            if (!changed) {
                onComplete?.runWith(false);
                return;
            }
            const param: game.IReqMMOActivitySetTeamMember = {
                activity_id: MMOData.Inst.activityId,
                members: team
            }
            MMOData.Inst.sendRequest(EMMOEvent.Set_TEAMMATE, param, Laya.Handler.create(this, () => {
                onComplete?.runWith(true);
            }));
        }

        receiveSupport(onComplete: Laya.Handler) {
            if (!this.checkSupport()) {
                onComplete.run();
                return;
            }
            this.duringReceiveSupport = true;
            this.sendRequest(EMMOEvent.RECEIVE_SUPPORT, { activity_id: this.activityId }, Laya.Handler.create(this, () => {
                this.duringReceiveSupport = false;
                onComplete?.run();
            }));
        }



        findBetterEquip() {
            const weapon = EMMOEquipType.WuQi;
            const armor = EMMOEquipType.FangJu;
            const head = EMMOEquipType.TouShi;

            const curWq = this.data.character.equipments[weapon];
            const curFj = this.data.character.equipments[armor];
            const curTs = this.data.character.equipments[head];
            const charProfession = this.charProfession;

            const wqCfg = this.equipmentConfig.get(curWq);
            const fjCfg = this.equipmentConfig.get(curFj);
            const tsCfg = this.equipmentConfig.get(curTs);

            let bestWqId = curWq, bestWqPower = wqCfg.power, sameWqIds: number[] = [];
            let bestFjId = curFj, bestFjPower = fjCfg.power, sameFjIds: number[] = [];
            let bestTsId = curTs, bestTsPower = tsCfg.power, sameTsIds: number[] = [];

            this.data.bag.equipments.forEach(v => {
                const id = v.id;
                const equipType = this.getEquipType(id);
                const cfgEquip = this.equipmentConfig.get(id);

                if (equipType == weapon) {
                    const equipProfession = this.getEquipProfession(id);
                    if (equipProfession == charProfession) {
                        if (cfgEquip.power > bestWqPower) {
                            bestWqId = id;
                            bestWqPower = cfgEquip.power;
                        } else if (cfgEquip.power == bestWqPower) {
                            sameWqIds.push(id);
                        }
                    }
                } else if (equipType == armor) {
                    if (cfgEquip.power > bestFjPower) {
                        bestFjId = id;
                        bestFjPower = cfgEquip.power;
                    } else if (cfgEquip.power == bestFjPower) {
                        sameFjIds.push(id);
                    }
                } else if (equipType == head) {
                    if (cfgEquip.power > bestTsPower) {
                        bestTsId = id;
                        bestTsPower = cfgEquip.power;
                    } else if (cfgEquip.power == bestTsPower) {
                        sameTsIds.push(id);
                    }
                }
            });
            if (bestWqId == curWq && bestFjId == curFj && bestTsId == curTs) {
                return {
                    haveBetter: false,
                    equipments: [
                        sameWqIds[Math.floor(Math.random() * sameWqIds.length)] || bestWqId,
                        sameFjIds[Math.floor(Math.random() * sameFjIds.length)] || bestFjId,
                        sameTsIds[Math.floor(Math.random() * sameTsIds.length)] || bestTsId,
                    ],
                };
            }

            return {
                haveBetter: true,
                equipments: [bestWqId, bestFjId, bestTsId],
            };
        }

        public onBuffChanged() {
            this.initedBuff = true;
            this.refreshTeamData();
            this.refreshCandidateList();
        }

        public onGameError(method: string, err: any, res: any) {
            if (res && res['error'] && res['error']['code']) {
                if ((res['error']['code'] == 26123)) {
                    uiscript.UI_SecondConfirm.Inst.show_only_confirm(game.Tools.strOfLocalization(20093), Laya.Handler.create(this, () => {
                        game.Scene_Activity.Inst.QuitScene();
                    }));
                } else {
                    // 其他错误，下次进来需要重新获取数据，不踢回大厅
                    this.needFetch = true;
                    uiscript.UIMgr.Inst.showNetReqError(method, err, res);
                }
            } else {
                // 其他错误，踢回大厅强制拉新数据
                uiscript.UIMgr.Inst.showNetReqError(method, err, res, Laya.Handler.create(this, () => {
                    this.needFetch = true;
                    game.Scene_Activity.Inst.QuitScene();
                }));
            }
        }

        fetchMMOData(onComplete: Laya.Handler) {
            if (this.lockNetwork) {
                onComplete?.runWith(false);
                return;
            }
            if (!this.needFetch) {
                onComplete?.runWith(true);
                return;
            }
            this.lockNetwork = true;
            app.NetAgent.sendReq2Lobby('Lobby', game.ERequest.mmoActivityFetchData, { activity_id: UI_Activity_Liandong_Main.activityId }, (err, res: game.IResMMOActivityFetchData) => {
                this.lockNetwork = false;
                let isSuccess = false;
                if (err || res['error']) {
                    uiscript.UIMgr.Inst.showNetReqError(game.ERequest.mmoActivityFetchData, err, res);
                } else {
                    MMOData.Inst.initData([res.mmo_data]);
                    isSuccess = true;
                }
                onComplete?.runWith(isSuccess);
            });
        }

    }
}