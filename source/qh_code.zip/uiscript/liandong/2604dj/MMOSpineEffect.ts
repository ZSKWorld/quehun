module uiscript {
    const specialEffectLst = ['boss_5_attack'];
    export class MMOSpineEffect {
        // 获得特效在屏幕位置
        public static getTargetPos(target: Laya.Sprite, offset: Laya.Point): Laya.Vector3 {
            let pos: Laya.Point = uiscript.UIMgr.Inst.getWorldPosition(target, offset);
            pos.x = 0.5 - pos.x;
            pos.y = 0.5 - pos.y;
            return new Laya.Vector3(pos.x * game.FrontEffect.scene_width, pos.y * game.FrontEffect.scene_height, 0);
        }

        public destoryed: boolean = false;
        public target: Laya.Sprite;
        public effect: Laya.Sprite3D;
        private pos_offset: Laya.Point;
        private animator: Catfood.CAnimator;
        private followMove: boolean = true;
        private scale: number = 1;
        private targetIndex: number = 0;
        private particle_systems: Array<Laya.ShurikenParticleSystem> = [];

        public constructor(effect: Laya.Sprite3D, target: Laya.Sprite, pos_offset: Laya.Point, scale: number = 1, followMove: boolean = true, targetIndex: number = 0) {
            this.target = target;
            this.destoryed = false;
            this.pos_offset = pos_offset;
            this.effect = effect;
            this.scale = scale;
            this.targetIndex = targetIndex;
            const effectRoot = this.effect.getChildAt(0) as Laya.Sprite3D;
            this.animator = effectRoot.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            if (!this.animator) {
                const child = effectRoot.getChildAt(0) as Laya.Sprite3D;
                if (child) this.animator = child.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
            }
            if (this.animator) {
                this.animator.EnableAdvancedFeatures(true);
            }
            this.followMove = followMove;
            this.particle_systems = [];
            this.dfsParticleSystems(effectRoot);
            this.update(true);
        }

        private dfsParticleSystems(root: Laya.Sprite3D, type: string = '') {
            if (root instanceof Laya.ShuriKenParticle3D) {
                this.particle_systems.push(root.particleSystem);
            }
            for (let child of root._childs) {
                this.dfsParticleSystems(child, type);
            }
        }

        public update(isInit: boolean = false) {
            if (this.destoryed) return;
            if (!this.target) return;
            this.effect.active = true;
            if (isInit) {
                if (specialEffectLst.indexOf(this.effect.name) != -1) {
                    let aniName = this.effect.name + '_' + (this.targetIndex + 1);
                    this.animator.Play(aniName);
                }
                this.effect.transform.localScale = new Laya.Vector3(this.scale, this.scale, this.scale);
                this.effect.transform.localPosition = MMOSpineEffect.getTargetPos(this.target, this.pos_offset);
                this.onSpeedChange();
            } else if (this.followMove) {
                this.effect.transform.localPosition = MMOSpineEffect.getTargetPos(this.target, this.pos_offset);
            }
        }

        pause() {
            if (this.animator) {
                this.animator.Pause();
            }
            this.particle_systems.forEach(v => {
                v['simulationSpeed'] = 0;
            });
        }

        resume() {
            if (this.animator) {
                this.animator.Resume();
            }
            this.particle_systems.forEach(v => {
                v['simulationSpeed'] = MMOData.Inst.speed;
            });
        }

        onSpeedChange() {
            if (this.animator) {
                this.animator.SetSpeed(MMOData.Inst.speed);
            }
            this.particle_systems.forEach(v => {
                v['simulationSpeed'] = MMOData.Inst.speed;
            });
        }

        public destory() {
            if (this.destoryed) return;
            this.destoryed = true;
            this.animator = null;
            this.particle_systems = [];
            this.effect.removeSelf();
            this.effect.destroy();
        }
    }
    export class MMOSpineEffectMgr {
        private static _instance: MMOSpineEffectMgr;
        public static get Inst(): MMOSpineEffectMgr {
            return this._instance || (this._instance = new MMOSpineEffectMgr());
        }
        public static scene_width: number = 32;
        public static scene_height: number = 18;
        public static scene_spine_effect_path: string = 'scene/effect_mmo_spine_effect.ls';
        private effectScene: Laya.Scene = null;
        private _scene_spine_effect: Laya.Scene[] = null;
        private effectLst: { [key: string]: Laya.Sprite3D } = {};

        private effects: Array<MMOSpineEffect> = [];
        public update() {
            let index: number = 0;
            for (let i: number = 0; i < this.effects.length; i++) {
                if (!this.effects[i].destoryed) {
                    this.effects[i].update();
                    this.effects[index++] = this.effects[i];
                }
            }
            for (let i: number = this.effects.length - index; i > 0; i--) {
                this.effects.pop();
            }
        }

        constructor() {
            MMOData.Inst.on(EMMOEvent.SPEED_CHANGE, this, this.onSpeedChange);
            MMOData.Inst.on(EMMOEvent.PAUSE_GAME, this, this.pauseEffect);
            MMOData.Inst.on(EMMOEvent.RESUME_GAME, this, this.resumeEffect);
        }

        pauseEffect() {
            this.effects.forEach(v => {
                v.pause();
            });
        }

        resumeEffect() {
            this.effects.forEach(v => {
                v.resume();
            });
        }

        onSpeedChange() {
            this.effects.forEach(v => {
                v.onSpeedChange();
            });
        }

        public init(root: Laya.Sprite): void {
            if (GameMgr.Inst.bannedActivityEffect) return;
            this._init(root);
            Laya.timer.frameLoop(1, this, () => {
                this.update();
            });
        }

        destroy() {
            if (GameMgr.Inst.bannedActivityEffect) return;
            Laya.timer.clearAll(this);
            this.clearSpineEffect();
            this._scene_spine_effect.forEach(v => {
                v.removeSelf();
                v.destroy();
            });
            this.effectScene.destroy();
            this.effectScene = null;
            this._scene_spine_effect = [];
            this.effectLst = {};
        }

        private _init(root: Laya.Sprite) {
            this._scene_spine_effect = [];
            this.effectLst = {};
            this.effectScene = Laya.loader.getRes(MMOSpineEffectMgr.scene_spine_effect_path);
            const camera = this.effectScene.getChildAt(0) as Laya.Camera;
            for (let i = 1; i <= 3; i++) {
                const child = root.getChildByName('effect' + i);
                const scene = new Laya.Scene();
                const newCamera: Laya.Camera = new Laya.Camera();
                scene.addChild(newCamera);

                // 同步基本渲染参数
                newCamera.clearFlag = Laya.BaseCamera.CLEARFLAG_SOLIDCOLOR;
                newCamera.clearColor = new Laya.Vector4(0, 0, 0, 0);
                newCamera.fieldOfView = camera.fieldOfView;
                newCamera.orthographic = camera.orthographic;
                newCamera.orthographicVerticalSize = camera.orthographicVerticalSize;
                newCamera.nearPlane = camera.nearPlane;
                newCamera.farPlane = camera.farPlane;
                // 使用相对viewport以支持窗口缩放
                newCamera.normalizedViewport = new Laya.Viewport(0, 0, 1, 1);
                newCamera.transform.position = camera.transform.position.clone();
                newCamera.transform.rotation = camera.transform.rotation.clone();
                newCamera.transform.localScale = camera.transform.localScale.clone();
                newCamera.clearColor = new Laya.Vector4(0, 0, 0, 0);
                newCamera.clearFlag = Laya.BaseCamera.CLEARFLAG_NONE;
                newCamera.cullingMask = camera.cullingMask;
                newCamera.renderingOrder = camera.renderingOrder;

                this._scene_spine_effect.push(scene);
                child.addChild(scene);
                scene.visible = true;
            }
            if (this.effectScene._childs != null) {
                for (let i: number = 1; i < this.effectScene._childs.length; i++) {
                    game.EffectMgr.dfsCompileShader(this.effectScene, this.effectScene._childs[i]);
                }
            }
            const effectPlayers = this.effectScene.getChildByName('player') as Laya.Sprite3D;
            for (let i = 0; i < effectPlayers._childs.length; i++) {
                const child = effectPlayers._childs[i];
                this.effectLst[child.name] = child;
                child.active = false;
            }
            const effectEnemies = this.effectScene.getChildByName('enemy') as Laya.Sprite3D;
            for (let i = 0; i < effectEnemies._childs.length; i++) {
                const child = effectEnemies._childs[i];
                this.effectLst[child.name] = child;
                child.active = false;
            }
        }

        public createSpineEffect(target: Laya.Sprite, layerIndex: number, url: string, offset: Laya.Point, scale: number = 1, followMove: boolean = true) {
            if (GameMgr.Inst.bannedActivityEffect) return;
            if (!this.effectLst[url]) {
                // app.Log.log('SpineEffectMgr createSpineEffect url not found' + url);
                return null;
            }
            if (!this._scene_spine_effect[layerIndex]) {
                app.Log.Error('SpineEffectMgr createSpineEffect layerIndex not found' + layerIndex);
                return null;
            }
            // app.Log.log('target === ' + target.name + '    url ==== ' + url);
            const effect = this.effectLst[url].clone();
            this._scene_spine_effect[layerIndex].addChild(effect);
            let spineEffect: MMOSpineEffect = new MMOSpineEffect(effect, target, offset, scale, followMove, layerIndex);
            this.effects.push(spineEffect);
            MMOData.Inst.timer.once(3000, spineEffect, () => {
                spineEffect.destory();
            });
        }

        public clearSpineEffect() {
            if (GameMgr.Inst.bannedActivityEffect) return;
            this.effects.forEach((item) => {
                MMOData.Inst.timer.clearAll(item);
                item.destory()
            });
            this.effects = [];
        }
    }
}