module uiscript {
    // 酒馆页面
    export class UI_Activity_MMO_Confirm extends UI_PopupBase {
        public static Inst: UI_Activity_MMO_Confirm = null;
        private btnConfirm: Laya.Button;
        private btnCancel: Laya.Button;
        private txtInfo: Laya.Label;
        private confirmHandler: Laya.Handler;
        private cancelHandler: Laya.Handler;

        constructor() {
            super(new ui.liandong.activity_2604dj.activity_2604mmo_confirmUI);
            UI_Activity_MMO_Confirm.Inst = this;
        }

        public onCreate(): void {
            super.onCreate();
            this.btnConfirm = this.root.getChildByName('btn_confirm') as Laya.Button;
            this.btnCancel = this.root.getChildByName('btn_cancel') as Laya.Button;
            this.txtInfo = this.root.getChildByName('info') as Laya.Label;
            this.btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide(this.confirmHandler);
            }, null, false);
            this.btnCancel.clickHandler = this.closeHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide(this.cancelHandler);
            }, null, false);
            this.maskAlpha = 1;
        }

        show(info: string, confirmHandler?: Laya.Handler, cancelHandler?: Laya.Handler, showBtnCancel: boolean = true): void {
            super.show();
            this.txtInfo.text = info;
            this.confirmHandler = confirmHandler;
            this.cancelHandler = cancelHandler;
            this.outClose = true;
            this.txtInfo.align = this.txtInfo.trueHeight > 50 ? 'left' : 'center';

            this.btnCancel.visible = showBtnCancel;
            this.btnConfirm.x = showBtnCancel ? 525 : 360;
            this.btnConfirm.skin = game.Tools.localUISrc(showBtnCancel ? 'myres/activity_2604dj/popup_common_btn3.png' : 'myres/activity_2604dj/popup_common_btn.png');
            (this.btnConfirm.getChildByName('title') as Laya.Label).color = showBtnCancel ? '#6b4534' : '#33425f';

        }

    }

}

