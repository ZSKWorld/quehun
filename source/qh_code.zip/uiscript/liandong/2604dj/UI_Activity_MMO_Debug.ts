// ==DevDebug==
module uiscript {

    export class UI_Activity_MMO_Debug extends UIBase {
        public static Inst: UI_Activity_MMO_Debug;
        public logs: any[] = [];
        private closeEffect: boolean = true;

        public get meUI(): ui.liandong.activity_2604dj.activity_2604mmo_DevDebugUI {
            return this.me as ui.liandong.activity_2604dj.activity_2604mmo_DevDebugUI;
        }

        constructor() {
            super(new ui.liandong.activity_2604dj.activity_2604mmo_DevDebugUI());
            UI_Activity_MMO_Debug.Inst = this;
        }

        onCreate() {
            this.meUI.root.visible = false;
            (this.meUI.root.getChildByName('btn_close') as Laya.Button).clickHandler = new Laya.Handler(this, this.close);
            (this.me.getChildByName('btn') as Laya.Button).clickHandler = new Laya.Handler(this, () => {
                if (this.meUI.root.visible) {
                    this.meUI.root.visible = false;
                } else {
                    this.meUI.root.visible = true;
                }
            });
            MMOData.Inst.on(EMMOEvent.START_GAME, this, this.inputLog);
            MMOData.Inst.on(EMMOEvent.ABANDON_GAME, this, this.clearLog);
            this.meUI.btn_log.clickHandler = new Laya.Handler(this, () => {
                this.copyLog();
            });

            this.meUI.btn_btn3.clickHandler = new Laya.Handler(this, () => {
                this.exportToJson();
            });
            this.meUI.btn_npc.clickHandler = new Laya.Handler(this, () => {
                if (!UI_Activity_MMO_PickMember.Inst.enable) {
                    UIMgr.Inst.ShowErrorInfo('未打开选人界面');
                    return;
                }

                UI_Activity_MMO_PickMember.Inst.selectedData = null;
                UI_Activity_MMO_PickMember.Inst.candidateList = [];
                MMOData.Inst.npcConfig.values().forEach((v: lqc.Sheet_Mmo_MmoNpc) => {
                    const equipments = v.equipment_list.split(',').map(v => Number(v));
                    const wq = equipments.find(v => MMOData.Inst.getEquipType(v) == EMMOEquipType.WuQi);
                    const fj = equipments.find(v => MMOData.Inst.getEquipType(v) == EMMOEquipType.FangJu);
                    const ts = equipments.find(v => MMOData.Inst.getEquipType(v) == EMMOEquipType.TouShi);
                    const ids = [wq, fj, ts];
                    const player: IMMOActivityTeamCandidateData = {
                        character_id: v.character_id,
                        equipments: ids,
                        id: v.npc_id,
                        power: MMOData.Inst.getPowerByEquipIds(ids),
                        profession: MMOData.Inst.getCharProfession(v.character_id),
                        type: EMMOPlayerType.npc
                    };

                    UI_Activity_MMO_PickMember.Inst.candidateList.push(player);
                });

                UI_Activity_MMO_PickMember.Inst.next_index = 0;
                UI_Activity_MMO_PickMember.Inst.nolimitlst.reset();
                UI_Activity_MMO_PickMember.Inst.nolimitlst.total_count = 1;
            });
            this.clearLog();
        }

        clearLog() {
            this.meUI.log_panel.visible = false;
        }

        inputLog(battleData: game.IResMMOActivityStartBattle) {
            this.handleLog(battleData);
            this.meUI.log.text = this.logs[this.logs.length - 1] || "";
            this.meUI.log.height = this.meUI.log.trueHeight + 20;
            this.meUI.com_log.height = this.meUI.log.height;
            this.meUI.log_panel.visible = false;
            this.meUI.log_panel.refresh();
        }

        handleLog(battleData: game.IResMMOActivityStartBattle) {
            if (battleData && battleData.units && battleData.actions) {
                // 初始化日志内容
                const logLines: string[] = [];

                // 1. 战斗结果
                logLines.push("=== 战斗结果 ===");
                const battleResult = battleData.result === 1 ? "赢了" : battleData.result === 2 ? "输了" : "未知结果";
                logLines.push(`战斗结果：${battleResult}`);
                logLines.push(""); // 空行分隔

                // 2. 参战单位信息
                logLines.push("=== 参战单位初始信息 ===");
                if (battleData.units.length === 0) {
                    logLines.push("暂无参战单位");
                } else {
                    battleData.units.forEach((unit, index) => {
                        // 区分阵营（根据id规则：角色id=玩家，怪物id=敌方）
                        // 这里假设id规则可根据实际业务调整，暂时先通用描述
                        const campDesc = unit.id > 10000 ? "敌方阵营（怪物）" : "玩家阵营（角色）"; // 示例规则，可自定义
                        logLines.push(`单位${index + 1}：`);
                        logLines.push(`  ${campDesc}：id：${unit.id}`);
                        logLines.push(`  血量：${unit.hp}`);
                        logLines.push(`  装备id：${unit.equipments.length > 0 ? unit.equipments.join(", ") : "无"}`);
                        logLines.push(""); // 空行分隔
                    });
                }
                logLines.push(""); // 空行分隔
                const animNames = ['', 'move', 'attack', 'hit', 'cure', 'attack_recovery', 'back', 'cure_recovery', 'defeat', 'win', 'idle', 'war_idle', 'die'];

                // 3. 战斗行为记录
                logLines.push("=== 战斗行为记录 ===");
                if (battleData.actions.length === 0) {
                    logLines.push("暂无战斗行为");
                } else {
                    battleData.actions.forEach((action, index) => {
                        logLines.push(`  tick ：${action.tick}`);
                        if (action.type == 1) {
                            logLines.push(`  ${this.getNameByPlayerId(action.from)}  攻击了  ${this.getNameByPlayerId(action.target)}`);
                            logLines.push(`  血量减少：${action.value}, 是否暴击： ${action.critical === 1 ? "是" : "否"}`);
                            logLines.push(""); // 空行分隔
                        } else if (action.type == 2) {
                            logLines.push(`  ${this.getNameByPlayerId(action.from)}  治疗了  ${this.getNameByPlayerId(action.target)}`);
                            logLines.push(`  血量增加：${action.value}`);
                            logLines.push(""); // 空行分隔
                        } else {
                            logLines.push(`  ${this.getNameByPlayerId(action.from)}  开始了动作 :  ${animNames[action.value]}`);
                            logLines.push(""); // 空行分隔
                        }

                    });
                }

                // 4. 错误信息（如有）
                if (battleData.error && battleData.error.code !== 0) {
                    logLines.push("=== 错误信息 ===");
                    logLines.push(`错误码：${battleData.error.code}`);
                }

                // 拼接所有行并返回
                this.logs.push(logLines.join("\n"));
            }

        }

        private getNameByPlayerId(playerId: number) {
            if (MMOData.Inst.roundConfig.enemy_id == playerId) {
                return "敌方";
            }
            const data = MMOData.Inst.characterConfig.get(playerId);
            if (!data) return "未知";
            return game.Tools.eventStrOfLocalization(data.job_name);
        }


        // 关闭
        private close() {
            this.meUI.root.visible = false;
        }

        public copyLog() {
            if (game.Tools.copyItems(this.logs[this.logs.length - 1])) {
                UI_LightTips.Inst.show(game.Tools.strOfLocalization(2125));
            }
        }

        /** 导出并下载 log.json */
        public exportToJson() {
            if (this.logs.length === 0) {
                UIMgr.Inst.ShowErrorInfo('本次登录后的测试没有产生错误，无法导出日志');
                return;
            }
            const content = JSON.stringify(this.logs);
            const blob = new Blob([content], { type: "application/json" });
            const url = URL.createObjectURL(blob);

            // 创建一个隐藏的下载链接
            const a = document.createElement("a");
            a.href = url;
            a.download = `mmo_error_${Date.now()}.json`;
            a.click();

            // 释放内存
            URL.revokeObjectURL(url);
        }

        testSupport() {
            MMOData.Inst.data.support.most_supporter = {
                id: 6837252,
                count: 100,
                type: 1,
                character_id: 1002,
                equipments: [70001119, 70001188, 70001163],
            };
            MMOData.Inst.event(EMMOEvent.RECEIVE_SUPPORT, { support_count: 10, total_support_count: 1000 });
        }

    }
}