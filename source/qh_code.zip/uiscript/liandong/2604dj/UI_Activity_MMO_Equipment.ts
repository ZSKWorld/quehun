module uiscript {
    const TempResSign = 'UI_Activity_MMO_Equipment';
    const ProfessionIcons1 = [
        "",
        "myres/activity_2604dj/talent_icon1.png",
        "myres/activity_2604dj/talent_icon2.png",
        "myres/activity_2604dj/talent_icon3.png",
    ];
    const ProfessionIcons2 = [
        "",
        "myres/activity_2604dj/talent_icon1_selected.png",
        "myres/activity_2604dj/talent_icon2_selected.png",
        "myres/activity_2604dj/talent_icon3_selected.png",
    ];
    class MMO_Equipment_Base extends UIBase {
        onMainEnable() { }
        onMainDisable() { }
    }
    export class MMO_Equipment_Main_Equip extends MMO_Equipment_Base {
        private _attBg: Laya.Image;
        private _roleIcon: Laya.Image;
        private _txtName: Laya.Label;
        private _wq: MMOEquipmentItem;
        private _fj: MMOEquipmentItem;
        private _ts: MMOEquipmentItem;
        private _txtPowers: Laya.Image[];
        private _txtAttributes: Laya.Label[];
        private _btnAutoFill: Laya.Button;
        public _empty: Laya.Sprite;
        private _quickRedPoint: Laya.Image;
        private _spineRoot: Laya.Sprite;

        private _equipType = EMMOEquipType.WuQi;
        private _btnTabs: Laya.Button[];
        private _spine: UI_Activity_MMO_Spine;
        private _tip: Laya.Label;
        private _filter: MMO_Equipment_Filter;
        private scrollView: capsui.CScrollView;
        private _equipIndexList: number[] = [];
        private _equips: { [key in EMMOEquipType]: number[] } = {
            [EMMOEquipType.WuQi]: [], [EMMOEquipType.TouShi]: [], [EMMOEquipType.FangJu]: []
        };
        private static _oldEquips: { [key in EMMOEquipType]: { [key: number]: number } } = null;
        private _newEquips: { [key in EMMOEquipType]: boolean[] } = {
            [EMMOEquipType.WuQi]: [], [EMMOEquipType.TouShi]: [], [EMMOEquipType.FangJu]: []
        };
        private _usingIndex: { [key in EMMOEquipType]: number } = {
            [EMMOEquipType.WuQi]: -1, [EMMOEquipType.TouShi]: -1, [EMMOEquipType.FangJu]: -1
        };
        private _chooseIndex: { [key in EMMOEquipType]: number } = {
            [EMMOEquipType.WuQi]: -1, [EMMOEquipType.TouShi]: -1, [EMMOEquipType.FangJu]: -1
        };
        private locking: boolean = false;
        private lastPowerValue: number = 0;
        private nowPowerValue: number = 0;

        public static refreshOldEquip() {
            if (this._oldEquips) return;
            if (!MMOData.Inst.data.bag) return;
            this._oldEquips = {
                [EMMOEquipType.WuQi]: {}, [EMMOEquipType.TouShi]: {}, [EMMOEquipType.FangJu]: {}
            };
            const bagEquips = MMOData.Inst.data.bag.equipments;
            const wqEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.WuQi);
            const tsEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.TouShi);
            const fjEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.FangJu);

            const checkEquip = (arr: game.IActivityMMOEquipmentData[], type: EMMOEquipType) => {
                for (let i = 0; i < arr.length; i++) {
                    const v = arr[i];
                    this._oldEquips[type][v.id] = v.stack;
                }
            };
            checkEquip(wqEquips, EMMOEquipType.WuQi);
            checkEquip(fjEquips, EMMOEquipType.FangJu);
            checkEquip(tsEquips, EMMOEquipType.TouShi);
        }

        public onCreate() {
            const me = this.me;
            this._attBg = me.getChildByName('attBg') as Laya.Image;
            this._roleIcon = me.getChildByName('roleIcon') as Laya.Image;
            this._txtName = me.getChildByName('name') as Laya.Label;
            this._spineRoot = me.getChildByName('spineRoot') as Laya.Sprite;

            const charEquips = me.getChildByName('charEquips') as Laya.Sprite;
            this._wq = new MMOEquipmentItem(charEquips._childs[0]);
            this._fj = new MMOEquipmentItem(charEquips._childs[1]);
            this._ts = new MMOEquipmentItem(charEquips._childs[2]);
            const onEquipClick = (target: MMOEquipmentItem) => {
                const oldTarget = MMOEquipmentInfo.Inst.target;
                MMOEquipmentInfo.Inst.hide();
                if (oldTarget != target.me) {
                    target.selected = true;
                    const equipId = target.id;
                    const onTakeOff = MMOData.Inst.isDefaultEquip(equipId)
                        ? null : Laya.Handler.create(this, this.onEquipOperation, [equipId, false]);
                    MMOEquipmentInfo.Inst
                        .setMaskEnable(false)
                        .setBtnClick(null, onTakeOff, null, Laya.Handler.create(this, () => {
                            target.selected = false;
                        }))
                        .setLayoutAdapter(true, true, target.me)
                        .show(target.id);
                }
            };
            this._wq.me.on(Laya.Event.CLICK, this, onEquipClick, [this._wq]);
            this._fj.me.on(Laya.Event.CLICK, this, onEquipClick, [this._fj]);
            this._ts.me.on(Laya.Event.CLICK, this, onEquipClick, [this._ts]);

            this._txtPowers = [...me.getChildByName('power').getChildByName('value')._childs].reverse();

            const attributes = me.getChildByName('attributes') as Laya.Sprite;
            this._txtAttributes = attributes._childs.map(v => v.getChildByName('num'));

            const btnChangeChar = me.getChildByName('btn_changeChar') as Laya.Button;
            btnChangeChar.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_MMO_SelectProfession.Inst.show();
            });

            const tabs = me.getChildByName('tabs') as Laya.Sprite;
            this._btnTabs = [tabs._childs[0], tabs._childs[1], tabs._childs[2]];
            this._btnTabs.forEach((v, i) => (v.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.refreshEquipList(i);
            })));

            this._filter = new MMO_Equipment_Filter(me.getChildByName('filter') as Laya.Sprite, new Laya.Handler(this, () => {
                this.refreshEquipList(this._equipType);
            }), UI_Activity_MMO_Equipment.Inst.ui.btns_show2, UI_Activity_MMO_Equipment.Inst.ui.btns_hide2);

            this._tip = me.getChildByName('tip') as Laya.Label;

            const btnAutoFill = me.getChildByName('btn_autoFill') as Laya.Button;
            this._quickRedPoint = btnAutoFill.getChildByName('redPoint') as Laya.Image;
            this._btnAutoFill = btnAutoFill;
            btnAutoFill.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                const betterInfo = MMOData.Inst.findBetterEquip();
                const oldEquips = MMOData.Inst.data.character.equipments;
                if (oldEquips[EMMOEquipType.WuQi] == betterInfo.equipments[EMMOEquipType.WuQi]
                    && oldEquips[EMMOEquipType.FangJu] == betterInfo.equipments[EMMOEquipType.FangJu]
                    && oldEquips[EMMOEquipType.TouShi] == betterInfo.equipments[EMMOEquipType.TouShi]) {
                    UI_Activity_MMO_Info.Inst.show(game.Tools.strOfLocalization(26041107), 1000);
                    return;
                }
                this.sendSetEquipReq(betterInfo.equipments);
            });

            this.scrollView = me.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.onListItemRender), null, 6);

            MMOEquipmentInfo.Inst;
            MMOData.Inst.on(EMMOEvent.SET_EQUIPMENT, this, () => {
                UI_Activity_MMO_Equipment.Inst.showEquipChangeEffect();
                this.onDataChanged();
            });
            MMOData.Inst.on(EMMOEvent.FUSION_EQUIPMENT, this, this.onDataChanged);
        }

        private onDataChanged() {
            this.locking = false;
            this.refreshSpine();
            this.refreshCharInfo(true);
            this.refreshEquipData(true);
            this.refreshEquipList(this._equipType);
            this._quickRedPoint.visible = MMOData.Inst.findBetterEquip().haveBetter;
        }

        private onProfessionChanged() {
            this.refreshSpine();
            this.refreshCharInfo(true);
            this.refreshEquipData(true);
            this._filter.refresh(MMOData.Inst.charProfession);
            this._quickRedPoint.visible = MMOData.Inst.findBetterEquip().haveBetter;
        }

        show() {
            this.me.addChild(this._empty);
            this._empty.pos(907.5, 310.5);
            this._quickRedPoint.visible = MMOData.Inst.findBetterEquip().haveBetter;
            UI_Activity_MMO_Equipment.Inst.setEquipEffectActive(true);
            this.refreshSpine();
            this.enable = true;
            view.AudioMgr.PlayAudio(10397);
        }

        hide() {
            UI_Activity_MMO_Equipment.Inst.setEquipEffectActive(false);
            this.enable = false;
            this.refreshEquipData(true);
            this.refreshEquipList(this._equipType);
        }

        onMainEnable() {
            this.refreshCharInfo(false);
            this.refreshEquipData(true);
            this._filter.refresh(MMOData.Inst.charProfession);
            MMOData.Inst.on(EMMOEvent.SET_PROFESSION, this, this.onProfessionChanged);
        }

        onMainDisable() {
            this.clearSpine();
            this._chooseIndex[EMMOEquipType.WuQi] = -1;
            this._chooseIndex[EMMOEquipType.FangJu] = -1;
            this._chooseIndex[EMMOEquipType.TouShi] = -1;
            MMOData.Inst.off(EMMOEvent.SET_PROFESSION, this, this.onProfessionChanged);
        }

        private refreshSpine() {
            const { character_id, equipments } = MMOData.Inst.data.character;
            if (!this._spine || this._spine.roleId != character_id) {
                this.clearSpine();
                this._spine = UI_Activity_MMO_SpineMgr.Inst.getSpine(character_id);
                this._spine.init();
                this._spine.spine.root.pos(-1397, -553);
                this._spine.spine.offsetX = 0;
                this._spine.spine.offsetY = 1080;
                this._spine.spine.sx = 1;
                this._spine.spine.sy = 1;
                this._spineRoot.addChild(this._spine.spine.root);
            }

            this._spine.spine.customIdleAni = MMOData.getAnimName(game.EMMOAnimType.idle, equipments);
            this._spine.spine.updateSpineInfo();
            this._spine.play(this._spine.spine.customIdleAni);
        }

        private clearSpine() {
            if (this._spine) {
                this._spine.recover();
                this._spine = null;
            }
        }

        private refreshEquipData(refreshNew: boolean) {
            const charEquips = MMOData.Inst.data.character.equipments;
            const bagEquips = MMOData.Inst.data.bag.equipments;
            const wqEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.WuQi);
            const tsEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.TouShi);
            const fjEquips = bagEquips.filter(v => MMOData.Inst.getEquipType(v.id) == EMMOEquipType.FangJu);

            this._usingIndex[EMMOEquipType.WuQi] = -1;
            this._usingIndex[EMMOEquipType.FangJu] = -1;
            this._usingIndex[EMMOEquipType.TouShi] = -1;

            const oldWqEquips = MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.WuQi];
            const oldTsEquips = MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.TouShi];
            const oldFjEquips = MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.FangJu];
            MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.WuQi] = {};
            MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.TouShi] = {};
            MMO_Equipment_Main_Equip._oldEquips[EMMOEquipType.FangJu] = {};
            const checkEquip = (arr: game.IActivityMMOEquipmentData[], oldData: { [key: number]: number }, type: EMMOEquipType) => {
                this._equips[type].length = 0;
                this._newEquips[type].length = 0;
                for (let i = 0; i < arr.length; i++) {
                    const v = arr[i];
                    const oldCnt = oldData[v.id] || 0;
                    MMO_Equipment_Main_Equip._oldEquips[type][v.id] = v.stack;
                    if (v.id == charEquips[type])
                        this._usingIndex[type] = this._equips[type].length;
                    for (let j = 0; j < v.stack; j++) {
                        this._equips[type].push(v.id);
                        this._newEquips[type].push(refreshNew && oldCnt <= j);
                    }
                }
            };
            checkEquip(wqEquips, oldWqEquips, EMMOEquipType.WuQi);
            checkEquip(fjEquips, oldFjEquips, EMMOEquipType.FangJu);
            checkEquip(tsEquips, oldTsEquips, EMMOEquipType.TouShi);
        }

        private refreshEquipList(type: EMMOEquipType) {
            this._equipType = type;
            for (let i = 0; i < this._btnTabs.length; i++) {
                const img = this._btnTabs[i].getChildByName('selected') as Laya.Image;
                const title = this._btnTabs[i].getChildByName('title') as Laya.Label;
                img.visible = type == i;
                title.color = type == i ? '#2d4060' : '#87bfcb';
            }
            this._filter.enable = type == EMMOEquipType.WuQi;
            this._tip.visible = type == EMMOEquipType.WuQi;

            this._equipIndexList.length = 0;

            const equips = this._equips[type];
            const profession = this._filter.profession;
            for (let i = 0; i < equips.length; i++) {
                const v = equips[i];
                if (type == EMMOEquipType.WuQi && !!profession) {
                    if (profession == MMOData.Inst.getEquipProfession(v))
                        this._equipIndexList.push(i);
                } else
                    this._equipIndexList.push(i);
            }

            this._equipIndexList.sort((a, b) => {

                const usingA = this._usingIndex[type] == a;
                const usingB = this._usingIndex[type] == b;

                if (usingA != usingB) return usingA ? -1 : 1;

                const equipIdA = equips[a];
                const equipIdB = equips[b];
                const cfgA = MMOData.Inst.equipmentConfig.get(equipIdA);
                const cfgB = MMOData.Inst.equipmentConfig.get(equipIdB);
                if (cfgA.rarity != cfgB.rarity) return cfgB.rarity - cfgA.rarity;
                if (cfgA.power != cfgB.power) return cfgB.power - cfgA.power;
                return equipIdA - equipIdB;
            });

            
            this._empty.visible = this._equipIndexList.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(this._equipIndexList.length);
        }

        private refreshCharInfo(doAnim: boolean) {
            //左侧角色面板
            const { data, characterConfig, charProfession, equipmentConfig } = MMOData.Inst;
            const character = data.character;
            const cfgChar = characterConfig.get(character.character_id);
            this._roleIcon.skin = game.Tools.localUISrc(ProfessionIcons1[charProfession]);
            this._txtName.text = cfgChar ? game.Tools.eventStrOfLocalization(cfgChar.job_name) : '';

            const charInfoValue = this.getCharInfoValue(character.character_id, character.equipments);

            Laya.timer.clearAll(this);
            if (doAnim) {
                this.lastPowerValue = this.nowPowerValue;
                const startTime = Laya.timer.currTimer;
                const totalTime: number = 500;
                let anim = () => {
                    let t: number = Laya.timer.currTimer - startTime;
                    if (t >= totalTime) {
                        Laya.timer.clearAll(this);
                        this.lastPowerValue = charInfoValue.power;
                        this.refreshPower(charInfoValue.power);
                    } else {
                        let rate: number = Laya.Ease.quadOut(t, 0, 1, totalTime);
                        const newPowerValue = Math.floor(this.lastPowerValue + (charInfoValue.power - this.lastPowerValue) * rate);
                        this.refreshPower(newPowerValue);
                    }
                };
                Laya.timer.frameLoop(1, this, anim, null, true);
            } else {
                this.lastPowerValue = charInfoValue.power;
                this.refreshPower(charInfoValue.power);
            }

            const atts = [
                charInfoValue.atk, charInfoValue.hp, charInfoValue.cri + "%", charInfoValue.criDamage + "%", charInfoValue.heal + "%"
            ];
            this._txtAttributes.forEach((v, i) => {
                v.text = atts[i].toString();
                //治疗只有法师才显示
                (v.parent as Laya.Sprite).visible = i != 4 || (i == 4 && charProfession == EMMOProfession.Mage);
            });
            this._attBg.height = (this._txtAttributes[4].parent as Laya.Sprite).visible ? 254 : 204;

            this._wq.refresh(character.equipments[EMMOEquipType.WuQi]);
            this._fj.refresh(character.equipments[EMMOEquipType.FangJu]);
            this._ts.refresh(character.equipments[EMMOEquipType.TouShi]);

            this._spine.changeEquips(character.equipments);
        }

        private refreshPower(value: number) {
            this.nowPowerValue = value;
            const powerArr = value.toString().split('').reverse();
            this._txtPowers.forEach((v, i) => {
                const value = powerArr[i];
                v.visible = !!value;
                if (value)
                    v.skin = game.Tools.localUISrc(`myres/activity_2604dj/number/power_icon_number_${value}.png`);
            });
        }

        private onListItemRender(obj) {
            const container: Laya.Sprite = obj.container;
            const index: number = obj.index;

            const btn = container.getChildByName('btn') as Laya.Button;
            if (!obj.equipItem) obj.equipItem = new MMOEquipmentItem(btn);
            const using = btn.getChildByName('using') as Laya.Sprite;
            const newSp = btn.getChildByName('new') as Laya.Sprite;
            const bound = btn.getChildByName('bound') as Laya.Sprite;
            const lock = btn.getChildByName('lock') as Laya.Image;
            const lock0 = lock.getChildAt(0) as Laya.Image;

            const originIndex = this._equipIndexList[index];

            const equipId = this._equips[this._equipType][originIndex];
            const charProfession = MMOData.Inst.charProfession;
            const equipProfession = MMOData.Inst.getEquipProfession(equipId);

            (obj.equipItem as MMOEquipmentItem).refresh(equipId);
            using.visible = originIndex == this._usingIndex[this._equipType];
            newSp.visible = this._newEquips[this._equipType][originIndex];
            bound.visible = originIndex == this._chooseIndex[this._equipType];
            const locked = !!equipProfession && equipProfession != charProfession;
            lock.visible = locked;
            if (locked)
                lock0.skin = game.Tools.localUISrc(`myres/activity_2604dj/talent_icon${ equipProfession }.png`);

            btn.clickHandler && btn.clickHandler.recover();
            btn.clickHandler = Laya.Handler.create(this, () => {
                MMOEquipmentInfo.Inst.hide();
                if (MMOEquipmentInfo.Inst.target == btn) return;
                const onDressUp = locked || using.visible ? null : Laya.Handler.create(this, this.onEquipOperation, [equipId, true]);
                const onTakeOff = using.visible ? Laya.Handler.create(this, this.onEquipOperation, [equipId, false]) : null;
                const onNotSuit = locked ? Laya.Handler.create(this, null) : null;
                const onClose = Laya.Handler.create(this, () => {
                    this._chooseIndex[this._equipType] = -1;
                    this.scrollView.wantToRefreshAll();
                });
                MMOEquipmentInfo.Inst
                    .setMaskEnable(false)
                    .setBtnClick(onDressUp, onTakeOff, onNotSuit, onClose)
                    .setLayoutAdapter(false, false, btn, true)
                    .show(equipId);
                this._chooseIndex[this._equipType] = originIndex;
                this.scrollView.wantToRefreshAll();
            }, null, false);
        }

        private getCharInfoValue(charId: number, equips: number[]) {
            const cfgChar = MMOData.Inst.characterConfig.get(charId);
            let atk = 0, hp = 0, cri = 0, criDamage = 0, heal = 0;
            let atkR = 0, criDamageR = 0, hpR = 0, power = 0;
            atk += cfgChar.atk;
            hp += cfgChar.hp;
            cri += cfgChar.critical_rate;
            criDamage += cfgChar.critical_damage;
            equips.forEach(v => {
                const cfgEquip = MMOData.Inst.equipmentConfig.get(v);
                atk += cfgEquip.atk_fixed;
                atkR += cfgEquip.atk_rate;
                cri += cfgEquip.critical_rate;
                criDamage += cfgEquip.critical_damage_fixed;
                criDamageR += cfgEquip.critical_damage_rate;
                hp += cfgEquip.hp_fixed;
                hpR += cfgEquip.hp_rate;
                heal += cfgEquip.heal_rate;
                power += cfgEquip.power;
            });

            const cfgWq = MMOData.Inst.equipmentConfig.get(equips[EMMOEquipType.WuQi]);
            const buffs = MMOData.Inst.weaponBuffConfig.get(cfgWq.weapon_type_id);
            if (buffs && buffs.length > 0) {
                const hpBuffIds = {26040401:true, 26040421:true, 26040411:true, 26040431:true};
                const atkBuffIds = {26040402:true, 26040422:true, 26040412:true, 26040432:true};
                const criBuffIds = {26040403:true, 26040423:true, 26040413:true, 26040433:true};
                const healBuffIds = {26040434:true};
                buffs.forEach(id => {
                    let level = UI_Activity.getActivityBuffLevel(id);
                    if (level) {
                        power += MMOData.Inst.buffPowerConfig.get(id)?.[level] || 0;
                    }
                    if (hpBuffIds[id]) {
                        hpR += UI_Activity.getActivityBuffAdd(id);
                    } else if (atkBuffIds[id]) {
                        atkR += UI_Activity.getActivityBuffAdd(id);
                    } else if (criBuffIds[id]) {
                        cri += UI_Activity.getActivityBuffAdd(id);
                    } else if (healBuffIds[id]) {
                        heal += UI_Activity.getActivityBuffAdd(id);
                    }
                });
            }

            atk = Math.floor(atk * (1 + atkR / 100));
            criDamage = Math.floor(criDamage * (1 + criDamageR / 100));
            hp = Math.floor(hp * (1 + hpR / 100));
            return { atk, hp, cri, criDamage, heal, power };
        }

        private onEquipOperation(equipId: number, dressUp: boolean) {
            if (this.locking) return;
            const equips = [...MMOData.Inst.data.character.equipments];
            const equipType = MMOData.Inst.getEquipType(equipId);
            if (dressUp)
                equips[equipType] = equipId;
            else {
                equips[equipType] = MMOData.Inst.defaultEquip[MMOData.Inst.charProfession][equipType];
            }
            this.sendSetEquipReq(equips);
        }

        private sendSetEquipReq(equips: number[]) {
            this.locking = true;
            const param: game.IReqMMOActivitySetEquip = {
                activity_id: MMOData.Inst.activityId,
                equipments: equips,
            };
            MMOData.Inst.sendRequest(EMMOEvent.SET_EQUIPMENT, param, Laya.Handler.create(this, () => {
                this.locking = false;
            }));
        }
    }

    const ChoosePartIcon = [
        "",
        "myres/activity_2604dj/item_icon/item_icon_weapon_swordsman_empty.png",
        "myres/activity_2604dj/item_icon/item_icon_weapon_warrior_empty.png",
        "myres/activity_2604dj/item_icon/item_icon_weapon_wizard_empty.png",
        "myres/activity_2604dj/item_icon/item_icon_hat_empty.png",
        "myres/activity_2604dj/item_icon/item_icon_armor_empty.png",
    ];
    class MMO_Equipment_Main_Composit extends MMO_Equipment_Base {

        private _bg: Laya.Image;
        private _targetEquips: MMOEquipmentItem[];
        private _txtResultTip: Laya.Label;
        private _resultBg: Laya.Image;
        private _resultIcon: Laya.Image;
        private _btnAutoFill: Laya.Button;
        private _btnComposit: Laya.Button;
        private _btnChoosePart: Laya.Button;
        private _btnChoosePart2: Laya.Button;

        private _tabIndex: 0 | 1 | 2 | 3 = 0;
        private _btnTabs: Laya.Button[];
        private _filter: MMO_Equipment_Filter;
        private scrollView: capsui.CScrollView;
        private _btnSort: Laya.Button;
        public _empty:Laya.Sprite;

        private _compositType: 0 | 1 = 0;
        private _btnTabComposit: Laya.Button[];
        /** 指定合成选择的部位 */
        private _selectPart: 0 | 1 | 2 | 3 | 4 | 5 = 0;
        
        private locking: boolean = false;
        private _equips: number[];
        private _equipIndexList: number[] = [];
        private _chooseIndex: [number[], number[]] = [[], []];
        private _choosedIndex = -1;
        private _usingIndex: { [key in EMMOEquipType]: number } = {
            [EMMOEquipType.WuQi]: -1, [EMMOEquipType.TouShi]: -1, [EMMOEquipType.FangJu]: -1
        };
        /** 战力升序排序 */
        private _sortASC: boolean = true;
        private get needCount() { return this._compositType ? 5 : 4; }
        private get chooseEquips() { return this._chooseIndex[this._compositType]; }
        private get chooseRarity() {
            const originIndex = this.chooseEquips[0];
            if (originIndex == null) return 0;
            const equipId = this._equips[originIndex];
            const cfgEquip = MMOData.Inst.equipmentConfig.get(equipId);
            return cfgEquip.rarity;
        }
        public onCreate() {
            const me = this.me;
            this._bg = me.getChildByName('bg') as Laya.Image;
            const equips = me.getChildByName('equips') as Laya.Sprite;
            this._targetEquips = equips._childs.map(v => new MMOEquipmentItem(v));
            this._targetEquips.forEach((v, i) => {
                const func = () => {
                    if (this.locking) return;
                    if (!v.id) return;
                    this.setChooseEquip(this._chooseIndex[this._compositType][i], false);
                };
                if(v.btnDelete)
                    v.btnDelete.clickHandler = new Laya.Handler(this, func);
                v.icon.on(Laya.Event.CLICK, this, func);
            });
            const resultTipChs = me.getChildByName('result_tip_chs') as Laya.Sprite;
            const resultTipEn = me.getChildByName('result_tip_en') as Laya.Sprite;
            const isChs = GameMgr.client_language == "chs" || GameMgr.client_language == "chs_t";
            resultTipChs.visible = isChs;
            resultTipEn.visible = !isChs;
            this._txtResultTip = (isChs ? resultTipChs : resultTipEn).getChildByName('result_tip') as Laya.Label;
            this._txtResultTip.text = "";
            this._resultBg = me.getChildByName('result_bg') as Laya.Image;
            this._resultIcon = me.getChildByName('result_icon') as Laya.Image;

            const tabs = me.getChildByName('tabs') as Laya.Sprite;
            this._btnTabs = [...tabs._childs];
            this._btnTabs.forEach((v, i) => (v.clickHandler = new Laya.Handler(this, this.refreshEquipList, [i])));

            this._btnTabComposit = [
                me.getChildByName('tab0') as Laya.Button,
                me.getChildByName('tab1') as Laya.Button,
            ];
            this._btnTabComposit.forEach((v, i) => (v.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.refreshCompositType(i as any);
            })));

            this.scrollView = me.scriptMap['capsui.CScrollView'];
            this.scrollView.init_scrollview(new Laya.Handler(this, this.onListItemRender), null, 6);

            this._btnSort = me.getChildByName('btn_sort') as Laya.Button;
            this._btnSort.clickHandler = new Laya.Handler(this, () => {
                this.refreshSortType(!this._sortASC);
                this.refreshEquipList(this._tabIndex);
            });

            this._btnAutoFill = me.getChildByName('btn_autoFill') as Laya.Button;
            const findEquips = (equips:number[]) => {
                const arr = this.chooseEquips.slice();
                const { equipmentConfig, maxEquipRarity } = MMOData.Inst;
                const { chooseRarity, needCount, _equips } = this;
                if (chooseRarity) {
                    equips = equips.filter(v => equipmentConfig.get(_equips[v]).rarity == chooseRarity);
                }
                equips = equips.filter(v => {
                    return v != this._usingIndex[EMMOEquipType.WuQi]
                        && v != this._usingIndex[EMMOEquipType.TouShi]
                        && v != this._usingIndex[EMMOEquipType.FangJu];
                });
                equips.sort((a, b) => {
                    const idA = _equips[a];
                    const idB = _equips[b];
                    const cfgA = equipmentConfig.get(idA);
                    const cfgB = equipmentConfig.get(idB);
                    if (cfgA.rarity != cfgB.rarity) return cfgA.rarity - cfgB.rarity;
                    return idA - idB;
                });
                if (chooseRarity) {
                    let cnt = needCount - arr.length;
                    for (let i = 0; i < equips.length; i++) {
                        if (cnt <= 0) break;
                        if (!arr.includes(equips[i])) {
                            cnt--;
                            arr.push(equips[i]);
                        }
                    }
                    for (let i = 0; i < cnt; i++) {
                    }
                } else {
                    let firstEquips: number[];
                    let targetEqups: number[];
                    for (let i = 1; i < maxEquipRarity; i++) {
                        const tmp = equips.filter(v => equipmentConfig.get(_equips[v]).rarity == i);
                        if (!firstEquips && tmp.length > 0) firstEquips = tmp;
                        if (tmp.length >= needCount) {
                            targetEqups = tmp;
                            break;
                        }
                    }
                    targetEqups = targetEqups || firstEquips;
                    if (targetEqups) {
                        for (let i = 0; i < needCount; i++) {
                            targetEqups[i] != null && arr.push(targetEqups[i]);
                        }
                    }
                }
                return arr;
            };
            this._btnAutoFill.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                const needCount = this.needCount;
                if (this.chooseEquips.length >= needCount) return;
                let arr: number[];
                const curEquips = arr = findEquips(this._equipIndexList);
                if (curEquips.length < needCount) {
                    const allEquips = findEquips(this._equips.map((v, i) => i));
                    if(allEquips.length >= needCount) {
                        arr = allEquips;
                    }
                }
                if (arr.join('') == this.chooseEquips.join('')) {
                    UI_Activity_MMO_Info.Inst.show(game.Tools.strOfLocalization(26041109), 1000);
                    return;
                }
                this.chooseEquips.length = 0;
                this.chooseEquips.push(...arr);
                this.refreshCompositType(this._compositType);
            });

            this._btnComposit = me.getChildByName('btn_composition') as Laya.Button;
            this._btnComposit.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                if (this._compositType && !this._selectPart) {
                    this._btnChoosePart.clickHandler.run();
                    return;
                }
                const arr = this.chooseEquips;
                if (arr.length != this.needCount) return;

                const equip_list = arr.map(v => this._equips[v]);
                const tipRarity = equip_list.find(v => MMOData.Inst.equipmentConfig.get(v).rarity >= 4) != null;
                const callback = Laya.Handler.create(this, () => {
                    const param: game.IReqMMOActivityEquipFusion = {
                        activity_id: MMOData.Inst.activityId,
                        equip_list: equip_list,
                        target_type: this._compositType ? this._selectPart : 0,
                    };
                    this.locking = true;
                    MMOData.Inst.sendRequest(EMMOEvent.FUSION_EQUIPMENT, param, Laya.Handler.create(this, () => {
                        this.locking = false;
                    }));
                });
                if (tipRarity)
                    UI_Activity_MMO_Confirm.Inst.show(game.Tools.strOfLocalization(26041097), callback);
                else callback.run();
            });

            const btnClearFill = me.getChildByName('btn_clearFill') as Laya.Button;
            btnClearFill.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.chooseEquips.length = 0;
                this.refreshCompositType(this._compositType);
            });

            this._btnChoosePart = me.getChildByName('btn_choosePart') as Laya.Button;
            this._btnChoosePart2 = me.getChildByName('btn_choosePart2') as Laya.Button;
            this._btnChoosePart.clickHandler = this._btnChoosePart2.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                UI_Activity_MMO_Equipment.Inst.choosePart.show(this._selectPart, Laya.Handler.create(this, (part) => {
                    this._selectPart = part;
                    this.refreshCompositType(this._compositType);
                }));
            });

            this._filter = new MMO_Equipment_Filter(me.getChildByName('filter') as Laya.Sprite, new Laya.Handler(this, () => {
                this.enable && this.refreshEquipList(this._tabIndex);
            }), UI_Activity_MMO_Equipment.Inst.ui.btns_show1, UI_Activity_MMO_Equipment.Inst.ui.btns_hide1);

            MMOData.Inst.on(EMMOEvent.FUSION_EQUIPMENT, this, (res: game.IResMMOActivityEquipFusion) => {
                if (!res) {
                    this.locking = false;
                    return;
                }
                const { ui, eff_synthesis1, eff_synthesis2 } = UI_Activity_MMO_Equipment.Inst;
                const eff = this._compositType ? eff_synthesis2 : eff_synthesis1;
                if (eff) {
                    eff.active = true;
                    Laya.timer.frameOnce(60, this, () => {
                        eff.active = false;
                    });
                }
                ui.result_icon1_rotation.play(0, false);
                UI_Activity_MMO_Equipment.Inst.popResult.show(res.result);
                Laya.timer.frameOnce(40, this, () => {
                    this._chooseIndex = [[], []];
                    this.show();
                    this.locking = false;
                });

                view.AudioMgr.PlayAudio(10398);
            });
        }

        show() {
            const index = this.me.getChildIndex(this._filter.me);
            this.me.addChildAt(this._empty, index); //empty提示放到filter下面，不然会挡到filter
            this._empty.pos(879, 307);
            this.scrollView.reset();
            this.refreshData();
            this.refreshEquipList(this._tabIndex);
            this.refreshCompositType(this._compositType);
            this.enable = true;
        }

        hide() {
            this.enable = false;
            this._chooseIndex[0].length = 0;
            this._chooseIndex[1].length = 0;
        }

        onMainEnable(): void {
            this._tabIndex = 0;
            this._choosedIndex = -1;
            this.refreshSortType(true);
            this._filter.refresh(EMMOProfession.None);
            this._compositType = +Laya.LocalStorage.getItem('compositType') as 0 | 1 || 0;
        }

        onMainDisable(): void {
            this._selectPart = 0;
            this._chooseIndex[0].length = 0;
            this._chooseIndex[1].length = 0;
        }

        private refreshSortType(asc: boolean) {
            this._sortASC = asc;
            this._btnSort.skin = game.Tools.localUISrc(`myres/activity_2604dj/${ asc ? 'equipment_sort_btn_down' : 'equipment_sort_btn_rise' }.png`);
        }

        private refreshData() {
            const equips = MMOData.Inst.data.character.equipments;
            this._equips = MMOData.Inst.data.bag.equipments.map(v => new Array(v.stack).fill(v.id)).flat();
            this._usingIndex[EMMOEquipType.WuQi] = this._equips.indexOf(equips[EMMOEquipType.WuQi]);
            this._usingIndex[EMMOEquipType.FangJu] = this._equips.indexOf(equips[EMMOEquipType.FangJu]);
            this._usingIndex[EMMOEquipType.TouShi] = this._equips.indexOf(equips[EMMOEquipType.TouShi]);
            this.setChooseEquip(this._usingIndex[EMMOEquipType.WuQi], false);
            this.setChooseEquip(this._usingIndex[EMMOEquipType.FangJu], false);
            this.setChooseEquip(this._usingIndex[EMMOEquipType.TouShi], false);
        }

        /** type 0：随机， 1：指定 */
        private refreshCompositType(type: 0 | 1) {
            this._compositType = type;
            Laya.LocalStorage.setItem('compositType', type.toString());
            for (let i = 0; i < this._btnTabComposit.length; i++) {
                const img = this._btnTabComposit[i].getChildByName('selected') as Laya.Image;
                const title = this._btnTabComposit[i].getChildByName('title') as Laya.Label;
                img.visible = type == i;
                title.color = type == i ? '#2d4060' : '#87bfcb';
            }

            const chooseRarity = this.chooseRarity;
            this._bg.skin = game.Tools.localUISrc(`myres/activity_2604dj/${ !type ? 'equipment_composite_base1' : 'equipment_composite_base2' }.png`);
            const resultBgSkin = chooseRarity ? MMOEquipmentBg1s[chooseRarity + 1] : 'myres/activity_2604dj/item_icon/item_icon_base_000.png';

            const resultIconSkin = type ? (this._selectPart ? ChoosePartIcon[this._selectPart] : 'myres/activity_2604dj/item_icon/item_icon_add.png') : 'myres/activity_2604dj/item_icon/item_icon_random.png';

            this._resultBg.skin = game.Tools.localUISrc(resultBgSkin);
            this._resultIcon.skin = game.Tools.localUISrc(resultIconSkin);

            const resultTipStrId = type ? (this._selectPart ? 26041040 : 26041041) : 26041038;
            this._txtResultTip.text = game.Tools.strOfLocalization(resultTipStrId);

            const cnt = this.needCount;
            const startX = !type ? 42 : 0;
            const padding = !type ? 116 : 108;
            this._targetEquips.forEach((v, i) => {
                v.me.visible = i < cnt;
                if (v.me.visible) {
                    v.me.x = startX + padding * i;
                    v.refreshComposit(this._equips[this._chooseIndex[type][i]]);
                }
            });
            this._btnChoosePart.visible = !!type;
            this._btnChoosePart2.visible = !!type && this._selectPart > 0;
            this._btnAutoFill.visible = this._chooseIndex[type].length < cnt;
            this._btnComposit.visible = this._chooseIndex[type].length == cnt;
            this.scrollView.wantToRefreshAll();
        }

        /** 0:全部, 1:武器, 2:防具, 3:饰品, */
        private refreshEquipList(index: 0 | 1 | 2 | 3) {
            this._tabIndex = index;
            for (let i = 0; i < this._btnTabs.length; i++) {
                const img = this._btnTabs[i].getChildByName('selected') as Laya.Image;
                const title = this._btnTabs[i].getChildByName('title') as Laya.Label;
                img.visible = index == i;
                title.color = index == i ? '#2d4060' : '#87bfcb';
            }
            const profession = index == 1 ? this._filter.profession : EMMOProfession.None;
            this._equipIndexList.length = 0;
            const equipType = index - 1;
            for (let i = 0; i < this._equips.length; i++) {
                const e = this._equips[i];
                if (equipType < 0 || (MMOData.Inst.getEquipType(e) == equipType && (!profession || profession == MMOData.Inst.getEquipProfession(e))))
                    this._equipIndexList.push(i);
            }
            const equips = MMOData.Inst.data.character.equipments;
            this._equipIndexList.sort((a, b) => {
                const idA = this._equips[a];
                const idB = this._equips[b];
                const cfgA = MMOData.Inst.equipmentConfig.get(idA);
                const cfgB = MMOData.Inst.equipmentConfig.get(idB);
                const equipTypeA = MMOData.Inst.getEquipType(idA);
                const equipTypeB = MMOData.Inst.getEquipType(idB);
                const usingA = equips[equipTypeA] == idA;
                const usingB = equips[equipTypeB] == idB;
                
                if (cfgA.rarity != cfgB.rarity)
                    return this._sortASC ? (cfgA.rarity - cfgB.rarity) : (cfgB.rarity - cfgA.rarity);
                if (cfgA.power != cfgB.power)
                    return this._sortASC ? (cfgA.power - cfgB.power) : (cfgB.power - cfgA.power);
                if (usingA != usingB) return usingA ? -1 : 1;
                return idA - idB;
            });
            this._empty.visible = this._equipIndexList.length == 0;
            this.scrollView.reset();
            this.scrollView.addItem(this._equipIndexList.length);

            this._filter.enable = equipType == EMMOEquipType.WuQi;
        }

        private onListItemRender(obj) {

            const container: Laya.Sprite = obj.container;
            const index: number = obj.index;

            const btn = container.getChildByName('btn') as Laya.Button;
            const btnDelete = container.getChildByName('btn_delete') as Laya.Button;
            if (!obj.equipItem) obj.equipItem = new MMOEquipmentItem(btn);
            const using = btn.getChildByName('using') as Laya.Sprite;
            const lock = btn.getChildByName('lock') as Laya.Image;
            const bound = btn.getChildByName('bound') as Laya.Sprite;

            const originIndex = this._equipIndexList[index];
            const equipId = this._equips[originIndex];
            const equipType = MMOData.Inst.getEquipType(equipId);
            const cfgEquip = MMOData.Inst.equipmentConfig.get(equipId);

            (obj.equipItem as MMOEquipmentItem).refresh(equipId);
            using.visible = originIndex == this._usingIndex[equipType];

            const isMaxRarity = cfgEquip.rarity >= MMOData.Inst.maxEquipRarity;
            const chooseRarity = this.chooseRarity;
            const sameRarity = !chooseRarity || chooseRarity == cfgEquip.rarity;
            const choosed = this._chooseIndex[this._compositType].indexOf(originIndex) >= 0;
            lock.visible = isMaxRarity || using.visible || choosed || !sameRarity;
            bound.visible = this._choosedIndex == index;

            btn.clickHandler && btn.clickHandler.recover();
            btnDelete.clickHandler && btnDelete.clickHandler.recover();
            btn.clickHandler = btnDelete.clickHandler = null;

            btnDelete.visible = choosed;
            
            btn.clickHandler = Laya.Handler.create(this, () => {
                if (this.locking) return;
                if (choosed || MMOEquipmentInfo.Inst.target == btn) {
                    MMOEquipmentInfo.Inst.hide();
                    this._choosedIndex = -1;
                } else {
                    MMOEquipmentInfo.Inst
                        .setMaskEnable(false)
                        .setBtnClick(null, null, null, Laya.Handler.create(this, () => {
                            this._choosedIndex = -1;
                            this.scrollView.wantToRefreshAll();
                        }))
                        .setLayoutAdapter(false, false, btn, true)
                        .show(equipId);
                    this._choosedIndex = index;
                }
                if (choosed) {
                    this.setChooseEquip(originIndex, false);
                } else {
                    if(lock.visible || !this.setChooseEquip(originIndex, true))
                        this.scrollView.wantToRefreshAll();
                }
            }, null, false);
            if (btnDelete.visible)
                btnDelete.clickHandler = btn.clickHandler;
        }

        private setChooseEquip(originIndex: number, add: boolean) {
            const arr = this._chooseIndex[this._compositType];
            if (add && arr.length >= this.needCount) return false;
            const index = arr.indexOf(originIndex);
            if (add && index < 0)
                arr.push(originIndex);
            else if (!add && index >= 0)
                arr.splice(index, 1);
            this.refreshCompositType(this._compositType);
            return true;
        }
    }
    class MMO_Equipment_Filter extends UIBase {
        private _tabIndex = 0;
        private _btnTabs: Laya.Button[];
        private _btnFilter: Laya.Button;
        private _btnFilterTitle: Laya.Label;
        private _popFilter: Laya.Sprite;
        private _onChanged: Laya.Handler;
        private _showAni: Laya.FrameAnimation;
        private _closeAni: Laya.FrameAnimation;
        private _locking = false;

        get profession() { return this._tabIndex as EMMOProfession; }

        constructor(me: Laya.Sprite, onChanged: Laya.Handler, showAni: Laya.FrameAnimation, closeAni: Laya.FrameAnimation) {
            super(me);
            this._onChanged = onChanged;
            this._showAni = showAni;
            this._closeAni = closeAni;
        }

        public onCreate() {
            const me = this.me;
            this._btnFilter = me.getChildByName('btn_filter') as Laya.Button;
            this._btnFilterTitle = this._btnFilter.getChildByName('title') as Laya.Label;
            this._popFilter = me.getChildByName('popFilter') as Laya.Sprite;
            const btns = this._popFilter.getChildByName('btns') as Laya.Sprite;
            this._btnTabs = [...btns._childs];
            this._btnTabs.forEach((v, i) => {
                v.on(Laya.Event.CLICK, this, () => {
                    if (this._locking) return;
                    this.refreshTab(i, false);
                });
            });

            this._btnFilter.on(Laya.Event.CLICK, this, (e: Laya.Event) => {
                if (this._locking) return;
                this._locking = true;
                if (this._popFilter.visible) {
                    this.hidePop();
                } else {
                    this._popFilter.visible = true;
                    this._showAni.play(0, false);
                    Laya.timer.once(this._showAni.interval * this._showAni.count, this, () => {
                        this._locking = false;
                    });
                }
            });
            this.enable = true;
            this.hidePop(false);
        }

        refresh(profession: EMMOProfession) {
            this.refreshTab(profession, true);
        }

        private hidePop(ani: boolean = true) {
            if (ani) {
                this._locking = true;
                this._closeAni.play(0, false);
                Laya.timer.once(this._closeAni.interval * this._closeAni.count, this, () => {
                    this._locking = false;
                    this._popFilter.visible = false;
                });
            }else
                this._popFilter.visible = false;
        }

        private refreshTab(index: number, force: boolean) {
            if (!force && index == this._tabIndex) return;
            this._tabIndex = index;
            let selectedTitle: Laya.Label;
            for (let i = 0; i < this._btnTabs.length; i++) {
                const img = this._btnTabs[i].getChildByName('selected') as Laya.Image;
                const title = this._btnTabs[i].getChildByName('title') as Laya.Label;
                const selected = index == i;
                img.visible = selected;
                title.color = selected ? '#1f3857' : '#87bfcb';
                selected && (selectedTitle = title);
            }
            this._btnFilterTitle.text = selectedTitle.text;
            this.hidePop();
            this._onChanged && this._onChanged.run();
        }
    }


    export class MMOEquipmentInfo extends UIBase {
        private static _inst: MMOEquipmentInfo;
        static get Inst() {
            if (!this._inst) {
                const sp = new ui.liandong.activity_2604dj.component.mmo_equip_infoUI();
                this._inst = new MMOEquipmentInfo(sp);
                UIMgr.Inst.AddActivityUI(this._inst);
                this._inst._maskBg.visible = true;
                this._inst._maskBg.clickHandler = new Laya.Handler(this._inst, () => {
                    this._inst.hide();
                });
            }
            return this._inst;
        }
        private _bg: Laya.Image;
        private _maskBg: Laya.Button;
        private _type: Laya.Image;
        private _icon: Laya.Image;
        private _attBg: Laya.Image;
        private _name: Laya.Label;
        private _attributes: { parent: Laya.Sprite, icon: Laya.Image, desc: Laya.Label, num: Laya.Label, buff: Laya.Label }[] = [];
        private _btnParent: Laya.Sprite;
        private _btnDressup: Laya.Button;
        private _btnTakeOff: Laya.Button;
        private _btnNotSuit: Laya.Button;
        private _btnDressupHandler: Laya.Handler;
        private _btnTakeOffHandler: Laya.Handler;
        private _btnNotSuitHandler: Laya.Handler;
        private _onClose: Laya.Handler;
        private _txtTest: Laya.Label;

        private _id: number = 0;
        private _itemHeight: number = 0;
        private _alignRight: boolean = true;
        private _alignBottom: boolean = true;
        private _alignTarget: Laya.Sprite;
        private _showEquip: boolean = false;
        private _tmpPoint = new Laya.Point();
        private _obsShow = false;
        get equipId() { return this._id; }
        get target() { return this._alignTarget; }

        public constructor(me: Laya.Sprite) {
            super(me);
            this._bg = me.getChildByName('bg') as Laya.Image;
            this._maskBg = me.getChildByName("maskBg") as Laya.Button;
            this._type = me.getChildByName('type') as Laya.Image;
            this._icon = me.getChildByName('icon') as Laya.Image;
            this._attBg = me.getChildByName('attBg') as Laya.Image;
            this._name = me.getChildByName('name') as Laya.Label;
            this._txtTest = me.getChildByName('test') as Laya.Label;

            const isChs = GameMgr.client_language == "chs" || GameMgr.client_language == "chs_t";
            (me.getChildByName(isChs ? 'attributes_en' : 'attributes_chs') as Laya.Sprite).visible = false;
            const attributes = me.getChildByName(isChs ? 'attributes_chs' : 'attributes_en') as Laya.Sprite;
            for (let i = 0; i < 2; i++) {
                const child = attributes.getChildAt(i) as Laya.Sprite;
                this._attributes.push({
                    parent: child,
                    icon: child.getChildByName('icon') as Laya.Image,
                    desc: child.getChildByName('desc') as Laya.Label,
                    num: child.getChildByName('num') as Laya.Label,
                    buff: child.getChildByName('buff') as Laya.Label,
                });
            }
            this._itemHeight = this._attributes[0].parent.height;

            const btnParent = me.getChildByName('btns') as Laya.Sprite;
            btnParent.visible = false;
            this._btnParent = btnParent;
            const btnDressup = this._btnDressup = btnParent.getChildByName('btn_dressup') as Laya.Button;
            const btnTakeOff = this._btnTakeOff = btnParent.getChildByName('btn_takeoff') as Laya.Button;
            const btnNotSuit = this._btnNotSuit = btnParent.getChildByName('btn_not_suit') as Laya.Button;
            // me.on(Laya.Event.MOUSE_DOWN, this, (e: Laya.Event) => e.stopPropagation());
            btnDressup.on(Laya.Event.CLICK, this, this.onBtnClick, [1]);
            btnTakeOff.on(Laya.Event.CLICK, this, this.onBtnClick, [2]);
            btnNotSuit.on(Laya.Event.CLICK, this, this.onBtnClick, [3]);
        }

        setMaskEnable(enable: boolean) {
            enable = !!enable;
            this._maskBg.visible = enable;
            if(!enable && this == MMOEquipmentInfo.Inst) {
                this.me.on(Laya.Event.CLICK, this, (e: Laya.Event) => e.stopPropagation());
                Laya.stage.on(Laya.Event.CLICK, this, this.onMouseDownHide);
            } else {
                this.me.offAll(Laya.Event.CLICK);
                Laya.stage.off(Laya.Event.CLICK, this, this.onMouseDownHide);
            }
            return this;
        }

        /** 三个参数只能设置一个，设置哪个显示哪个按钮 */
        setBtnClick(onDressup?: Laya.Handler, onTakeoff?: Laya.Handler, onNotSuit?: Laya.Handler, onClose?:Laya.Handler) {
            this._btnDressupHandler && this._btnDressupHandler.recover();
            this._btnTakeOffHandler && this._btnTakeOffHandler.recover();
            this._btnNotSuitHandler && this._btnNotSuitHandler.recover();
            this._onClose && this._onClose.recover();
            this._btnDressupHandler = onDressup;
            this._btnTakeOffHandler = onTakeoff;
            this._btnNotSuitHandler = onNotSuit;
            this._onClose = onClose;

            this._btnDressup.visible = !!onDressup;
            this._btnTakeOff.visible = !!onTakeoff;
            this._btnNotSuit.visible = !!onNotSuit;
            this._btnParent.visible = !!(onDressup || onTakeoff || onNotSuit);
            return this;
        }

        /**
         * 设置布局适配方式
         * @param right 显示在左右哪侧，true右侧，false左侧，默认右侧
         * @param bottom 底对齐还是顶对齐，true底对齐，false顶对齐，默认顶对齐
         * @param alignTarget 对齐目标
         */
        setLayoutAdapter(right: boolean, bottom: boolean, alignTarget: Laya.Sprite, showEquip:boolean = false) {
            this._alignRight = right;
            this._alignBottom = bottom;
            this._alignTarget = alignTarget;
            this._showEquip = showEquip;
            return this;
        }

        show(id: number) {
            this._id = id;
            Laya.stage.event(EventCode.MMO_EQUIPMENT_INFO_CHANGE, id);
            const cfgEquip = MMOData.Inst.equipmentConfig.get(id);
            const cfgFuncItem = cfg.item_definition.function_item.get(cfgEquip.item_id);
            if (!cfgEquip || !cfgFuncItem) return 0 ;
            const equipProfession = MMOData.Inst.getEquipProfession(id);
            this._bg.skin = game.Tools.localUISrc(`myres/activity_2604dj/equipment_information_base_00${ Math.max(cfgEquip.rarity, 1) }.png`);
            this._type.skin = game.Tools.localUISrc(ProfessionIcons1[equipProfession]);
            game.LoadMgr.setImgSkin(this._icon, cfgFuncItem.icon_transparent, null, TempResSign);

            this._name.text = game.Tools.strOfLocalization(cfgFuncItem.name);

            const attributes: { icon: string, strId: number, value: string, buff?:string }[] = [];
            if (cfgEquip.atk_fixed) attributes.push({ icon: "equipment_atk_icon", strId: 26041029, value: cfgEquip.atk_fixed + "" });
            if (cfgEquip.atk_rate) attributes.push({ icon: "equipment_atk_icon", strId: 26041030, value: cfgEquip.atk_rate + "%" });

            if (cfgEquip.critical_rate) attributes.push({ icon: "equipment_crit_icon", strId: 26041031, value: cfgEquip.critical_rate + "%" });

            if (cfgEquip.critical_damage_fixed) attributes.push({ icon: "equipment_critdamage_icon", strId: 26041032, value: cfgEquip.critical_damage_fixed + "%" });
            if (cfgEquip.critical_damage_rate) attributes.push({ icon: "equipment_critdamage_icon", strId: 26041033, value: cfgEquip.critical_damage_rate + "%" });

            if (cfgEquip.hp_fixed) attributes.push({ icon: "equipment_hp_icon", strId: 26041034, value: cfgEquip.hp_fixed + "" });
            if (cfgEquip.hp_rate) attributes.push({ icon: "equipment_hp_icon", strId: 26041035, value: cfgEquip.hp_rate + "%" });

            if (cfgEquip.heal_rate) attributes.push({ icon: "equipment_hps_icon", strId: 26041036, value: cfgEquip.heal_rate + "%" });

            if (cfgEquip.buff_list) {
                const cfgEquipBuff = cfg.mmo.mmo_equipment_buff.get(cfgEquip.buff_list);
                attributes.push({ icon: "", strId: 0, value: "", buff: game.Tools.eventStrOfLocalization(cfgEquipBuff.equipment_buff_desc) });
            }

            if (cfgEquip.rarity == 0) {
                const equipType = MMOData.Inst.getEquipType(id);
                const strId = [26041102, 26041103, 26041104][equipType];
                attributes.push({ icon: "", strId: 0, value: "0", buff: game.Tools.strOfLocalization(strId) });
            }

            let itemCnt = 0;
            this._attributes.forEach((v, i) => {
                const att = attributes[i];
                v.parent.visible = !!att;
                if (att) {
                    itemCnt++;
                    v.icon.visible = !att.buff;
                    v.desc.visible = !att.buff;
                    v.num.visible = !att.buff;
                    v.buff.visible = !!att.buff;

                    v.icon.skin = game.Tools.localUISrc(`myres/activity_2604dj/${ att.icon }.png`);
                    v.desc.text = game.Tools.strOfLocalization(att.strId);
                    v.num.text = "+" + att.value;
                    v.buff.text = att.buff || "";
                }
            });

            this._attBg.height = itemCnt * this._itemHeight;
            const attBgVisible = this._attBg.height > 1;
            this._attBg.visible = attBgVisible;
            let totalHeight = this._attBg.y + (+attBgVisible * this._attBg.height);
            if (this._btnParent.visible) {
                totalHeight += 16;//16是间隔
                this._btnParent.y = totalHeight;
                totalHeight += this._btnParent.height;
            }
            if (totalHeight > this._attBg.y)
                totalHeight += 16;//16是间隔
            totalHeight = Math.max(totalHeight + 42 + 14, 364);//42是背景底部多余部分高度，14是背景y是-14需要加上，364是背景图原始高度
            this._bg.height = totalHeight;
            this.me.height = totalHeight - 47;//背景比组件多出来的高度

            if (this._showEquip) {
                this.me.pos(565, 260);
            } else if (this._alignTarget) {
                this._tmpPoint.setTo(0, 0);
                this._alignTarget.localToGlobal(this._tmpPoint, false);

                const { x, y } = this._tmpPoint;
                const { width, height, scaleX, scaleY } = this._alignTarget;
                let meX = 0, meY = 0, padding = 10;
                meX = this._alignRight ? (x + width * scaleX + padding) : (x - this.me.width - padding);
                if (meX < 0) meX = x + width * scaleX + padding;
                else if (meX + this.me.width > Laya.stage.width)
                    meX = x - this.me.width - padding;

                meY = this._alignBottom ? (y + height * scaleY - this.me.height) : y;
                if (meY < 0) meY = 0;
                else if (meY + this.me.height > Laya.stage.height) {
                    meY = Laya.stage.height - this.me.height;
                }
                this.me.pos(meX, meY);
            }
            this.enable = true;
            this._obsShow = true;
            return itemCnt;
        }

        onEnable() {
        }

        onDisable() {
            this._id = -1;
            this._obsShow = false;
            this._onClose?.run();
            this.setBtnClick();
            this.setMaskEnable(this == MMOEquipmentInfo._inst);
            this.setLayoutAdapter(false, false, null);
        }

        hide() {
            this.enable = false;
            Laya.stage.event(EventCode.MMO_EQUIPMENT_INFO_CHANGE, 0);
        }

        private onMouseDownHide() {
            if (this._obsShow) {
                this._obsShow = false;
                return;
            }
            this.hide();
        }

        private onBtnClick(type: number, e: Laya.Event) {
            type == 1 && this._btnDressupHandler && this._btnDressupHandler.run();
            type == 2 && this._btnTakeOffHandler && this._btnTakeOffHandler.run();
            type == 3 && this._btnNotSuitHandler && this._btnNotSuitHandler.run();
            type != 3 && this.hide();
        }
    }
    class MMO_Equipment_ChoosePart extends UIBase {
        private _chooseIndex = -1;
        private _btns: Laya.Button[];
        private _onConfirm: Laya.Handler;
        private locking: boolean = false;
        public onCreate() {
            const me = this.me;
            const bg = me.getChildByName('bg') as Laya.Image;
            bg.on(Laya.Event.CLICK, this, this.hide);
            const root = this.me.getChildByName('root') as Laya.Sprite;
            const btnClose = root.getChildByName('btn_close') as Laya.Button;
            btnClose.clickHandler = new Laya.Handler(this, this.hide);
            this._btns = [
                root.getChildByName('part1') as Laya.Button,
                root.getChildByName('part0') as Laya.Button,
                root.getChildByName('part2') as Laya.Button,
                root.getChildByName('part3') as Laya.Button,
                root.getChildByName('part4') as Laya.Button,
            ];
            this._btns.forEach((v, i) => v.on(Laya.Event.CLICK, this, () => {
                if (this.locking) return;
                this.setChooseIndex(i + 1);
            }));

            const btnConfirm = root.getChildByName('btn_confirm') as Laya.Button;
            btnConfirm.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this._onConfirm && this._onConfirm.runWith(this._chooseIndex);
                this.hide();
            });
        }

        show(selectedPart: number, onConfirm: Laya.Handler) {
            this._onConfirm = onConfirm;
            this.setChooseIndex(selectedPart);
            this.locking = true;
            const ani = UI_Activity_MMO_Equipment.Inst.ui.choosePart_show;
            ani.play(0, false);
            this.enable = true;
            Laya.timer.once(ani.interval * ani.count, this, () => {
                this.locking = false;
            });
        }

        hide() {
            this.locking = true;
            const ani = UI_Activity_MMO_Equipment.Inst.ui.choosePart_hide;
            ani.play(0, false);
            Laya.timer.once(ani.interval * ani.count, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public onDisable(): void {
            if (this._onConfirm)
                this._onConfirm.recover();
            this._onConfirm = null;
        }

        private setChooseIndex(index: number) {
            this._chooseIndex = index;
            for (let i = 0; i < this._btns.length; i++) {
                const btn = this._btns[i];
                const selected = btn.getChildByName('selected') as Laya.Image;
                selected.visible = (index - 1) == i;
            }
        }
    }
    class MMO_Equipment_PopResult extends UIBase {
        private _bg2: Laya.Image;
        private _equipInfo: MMOEquipmentInfo;
        private locking: boolean = false;
        private _attributesCnt: number = 0;
        public onCreate() {
            const me = this.me;
            const bg = me.getChildByName('bg') as Laya.Button;
            bg.clickHandler = new Laya.Handler(this, () => {
                if (this.locking) return;
                this.hide();
            });
            this._bg2 = me.getChildByName('bg2') as Laya.Image;
            this._equipInfo = new MMOEquipmentInfo(me.getChildByName('info') as Laya.Sprite);
            this._equipInfo.setBtnClick();
        }

        show(id: number) {
            this._attributesCnt = this._equipInfo.show(id);
            this.locking = true;
            const ani = UI_Activity_MMO_Equipment.Inst.ui.popResult_show;
            ani.play(0, false);
            this.enable = true;
            Laya.timer.once(1333, this, () => {
                UI_Activity_MMO_Equipment.Inst.ui.popResult_idle.play(0, true);
                this.locking = false;
            });
            Laya.timer.once(666, this, () => {
                const { eff_composition_1, eff_composition_2 } = UI_Activity_MMO_Equipment.Inst;
                const effect = this._attributesCnt > 1 ? eff_composition_2 : eff_composition_1;
                if (!effect) return;
                const animator = effect.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                effect.active = true;
                animator.Play("2604dj_composition_show");
            });
        }

        hide() {
            const { eff_composition_1, eff_composition_2 } = UI_Activity_MMO_Equipment.Inst;
            const effect = this._attributesCnt > 1 ? eff_composition_2 : eff_composition_1;
            if (effect) {
                const animator = effect.getComponentByType(Catfood.CAnimator) as Catfood.CAnimator;
                animator.Play("2604dj_composition_hide");
            }

            this.locking = true;
            const ani = UI_Activity_MMO_Equipment.Inst.ui.popResult_hide;
            ani.play(0, false);
            Laya.timer.once(ani.interval * ani.count, this, () => {
                if(effect) effect.active = false;
                UI_Activity_MMO_Equipment.Inst.ui.popResult_idle.stop();
                this.locking = false;
                this.enable = false;
            });
        }
    }
    export class UI_Activity_MMO_Equipment extends UIBase {
        public static Inst: UI_Activity_MMO_Equipment = null;
        public static activityId: number = 260201;
        public static carrotId: number = 30900098;
        public static trainId: number = 30900099;
        public static haveRedPoint() {
            return false;
        }

        private _bg: Laya.Image;
        private _bg0: Laya.Image;
        private _bg1: Laya.Image;
        private _bg2: Laya.Image;
        private _tabIndex: number = 0;
        private _btnTabs: Laya.Button[];
        private _txtCapacity: Laya.Label;
        private _canComposite: Laya.Image;
        private _mainEquip: MMO_Equipment_Main_Equip;
        private _mainComposit: MMO_Equipment_Main_Composit;
        choosePart: MMO_Equipment_ChoosePart;
        popResult: MMO_Equipment_PopResult;
        private _scene: Laya.Scene;
        eff_equip_show: Laya.Sprite3D;
        eff_synthesis1: Laya.Sprite3D;
        eff_synthesis2: Laya.Sprite3D;
        eff_composition_1: Laya.Sprite3D;
        eff_composition_2: Laya.Sprite3D;

        get ui() { return this.me as ui.liandong.activity_2604dj.activity_2604mmo_equipmentUI; }

        public locking: boolean;
        constructor() {
            super(new ui.liandong.activity_2604dj.activity_2604mmo_equipmentUI());
            UI_Activity_MMO_Equipment.Inst = this;
        }

        public onCreate(): void {
            const root = this.me.getChildByName('root') as Laya.Sprite;
            const main = root.getChildByName('main') as Laya.Sprite;
            const mainBg = root.getChildByName('bg') as Laya.Image;
            const doClose = () => {
                if (this.locking) return;
                this.hide();
            };
            // mainBg.on(Laya.Event.CLICK, this, doClose);
            this._bg = mainBg;
            this._bg0 = mainBg.getChildAt(0) as Laya.Image;
            this._bg1 = mainBg.getChildAt(1) as Laya.Image;
            this._bg2 = main.getChildByName('bg1') as Laya.Image;
            this._btnTabs = [main.getChildByName('tab0') as Laya.Button, main.getChildByName('tab1') as Laya.Button];
            this._btnTabs.forEach((v, i) => (v.clickHandler = new Laya.Handler(this, this.refreshTab, [i])));
            const btnClose = main.getChildByName('btn_close') as Laya.Button;
            btnClose.clickHandler = new Laya.Handler(this, doClose);
            this._txtCapacity = main.getChildByName('capacity') as Laya.Label;
            const txtCapacityTitle = this._txtCapacity.getChildAt(1) as Laya.Label;
            txtCapacityTitle.x = -txtCapacityTitle.trueWidth - 10;
            this._canComposite = main.getChildByName('canComposite') as Laya.Image;
            this._mainEquip = new MMO_Equipment_Main_Equip(main.getChildByName('equipment') as Laya.Sprite);
            this._mainComposit = new MMO_Equipment_Main_Composit(main.getChildByName('composition') as Laya.Sprite);
            this._mainEquip._empty = main.getChildByName('empty') as Laya.Sprite;
            this._mainComposit._empty = this._mainEquip._empty;
            this.choosePart = new MMO_Equipment_ChoosePart(root.getChildByName('choosePart') as Laya.Sprite);
            this.popResult = new MMO_Equipment_PopResult(root.getChildByName('popResult') as Laya.Sprite);

            MMOData.Inst.on(EMMOEvent.FUSION_EQUIPMENT, this, () => {
                this.refreshBagCapacity();
                this.refreshCanComposite();
            });
            MMOData.Inst.on(EMMOEvent.SET_EQUIPMENT, this, () => {
                this.refreshCanComposite();
            });
        }

        public show(): void {
            this.modifyEffect(false);
            this.locking = true;
            this.refreshTab(0);
            this.refreshBagCapacity(true);
            this.refreshCanComposite();
            const ani = this.ui.show;
            ani.play(0, false);
            this.enable = true;
            Laya.timer.once(ani.interval * ani.count, this, () => {
                this.locking = false;
            });
        }

        public hide() {
            this.locking = true;
            const ani = this.ui.hide;
            ani.play(0, false);
            Laya.timer.once(ani.interval * ani.count, this, () => {
                this.locking = false;
                this.enable = false;
            });
        }

        public showEquipChangeEffect() {
            if (!this.eff_equip_show) return;
            view.AudioMgr.PlayAudio(10397);
            this.eff_equip_show.active = false;
            this.eff_equip_show.active = true;
        }

        public setEquipEffectActive(active: boolean) {
            if (this.eff_equip_show) this.eff_equip_show.active = active;
        }

        public onDisable(): void {
            MMOData.Inst.off(EMMOEvent.SET_PROFESSION, this, this.showEquipChangeEffect);
            if (this.popResult.me.visible) this.popResult.hide();
            if (this.choosePart.me.visible) this.choosePart.hide();
            this.modifyEffect(true);
            this._mainEquip.onMainDisable();
            this._mainComposit.onMainDisable();
            game.TempImageMgr.setUIEnable(TempResSign, false);
        }

        public onEnable() {
            MMOData.Inst.on(EMMOEvent.SET_PROFESSION, this, this.showEquipChangeEffect);
            this._mainEquip.onMainEnable();
            this._mainComposit.onMainEnable();
            game.TempImageMgr.setUIEnable(TempResSign, true);
        }

        private refreshTab(index: 0 | 1) {
            this._tabIndex = index;
            for (let i = 0; i < this._btnTabs.length; i++) {
                const selected = index == i;
                const imgSelected = this._btnTabs[i].getChildByName('selected') as Laya.Image;
                const title = this._btnTabs[i].getChildByName('title') as Laya.Label;
                imgSelected.visible = selected;
                title.color = selected ? '#1f3857' : '#85a8c2';
            }
            if (index == 0) {
                this._mainEquip.show();
                this._mainComposit.hide();
            } else {
                this._mainEquip.hide();
                this._mainComposit.show();
            }
        }

        private refreshCanComposite() {
            this._canComposite.visible = !!MMOData.Inst.canComposit;
            if (this._canComposite.visible) this.ui.cancomposite_idle.play(0, true);
            else this.ui.cancomposite_idle.stop();
        }

        private refreshBagCapacity(showFullTip?: boolean) {
            const { activityConfig, data } = MMOData.Inst;
            const bagMax = activityConfig.equipment_bag_max;
            const equipCount = data.bag.equipments.reduce((pv, cv) => pv + cv.stack, 0);
            this._txtCapacity.text = `${ equipCount }/${ bagMax }`;
            this._txtCapacity.color = equipCount >= bagMax ? '#ff4040' : '#b0d1e2';
            if (showFullTip && equipCount >= bagMax)
                UI_Activity_MMO_Confirm.Inst.show(game.Tools.strOfLocalization(26041043), null, null, false);
        }

        private modifyEffect(clear: boolean) {
            if (clear) {
                this._scene && this._scene.removeSelf();
                this._scene = null;
                this.eff_equip_show = null;
                this.eff_synthesis1 = null;
                this.eff_synthesis2 = null;
                this.eff_composition_1 = null;
                this.eff_composition_2 = null;
                return;
            }
            const scene = this._scene = Laya.loader.getRes('scene/effect_2604mmo_equipment.ls') as Laya.Scene;
            if (!scene) return;
            this.eff_equip_show = scene.getChildByName('2604dj_equipment_show') as Laya.Sprite3D;
            this.eff_synthesis1 = scene.getChildByName('2604dj_synthesis_1') as Laya.Sprite3D;
            this.eff_synthesis2 = scene.getChildByName('2604dj_synthesis_2') as Laya.Sprite3D;
            const eff_composition_chs_1 = scene.getChildByName('2604dj_composition_chs_1') as Laya.Sprite3D;
            const eff_composition_chs_2 = scene.getChildByName('2604dj_composition_chs_2') as Laya.Sprite3D;
            const eff_composition_en_1 = scene.getChildByName('2604dj_composition_en_1') as Laya.Sprite3D;
            const eff_composition_en_2 = scene.getChildByName('2604dj_composition_en_2') as Laya.Sprite3D;
            this.eff_equip_show && (this.eff_equip_show.active = false);
            this.eff_synthesis1 && (this.eff_synthesis1.active = false);
            this.eff_synthesis2 && (this.eff_synthesis2.active = false);
            eff_composition_chs_1 && (eff_composition_chs_1.active = false);
            eff_composition_chs_2 && (eff_composition_chs_2.active = false);
            eff_composition_en_1 && (eff_composition_en_1.active = false);
            eff_composition_en_2 && (eff_composition_en_2.active = false);
            this.eff_composition_1 = GameMgr.client_language == "chs" || GameMgr.client_language == "chs_t" ? eff_composition_chs_1 : eff_composition_en_1;
            this.eff_composition_2 = GameMgr.client_language == "chs" || GameMgr.client_language == "chs_t" ? eff_composition_chs_2 : eff_composition_en_2;
            this.me.addChild(scene);
        }
    }
}