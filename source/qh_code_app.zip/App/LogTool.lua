LogTool = {}

local pt = require("PrintTable")

LogTool._cache_logs = {}
LogTool._cache_index = 0
local _cache_max_ = 20;

function LogTool._insertCacheLog(_info)
    if #LogTool._cache_logs < _cache_max_ then
        table.insert(LogTool._cache_logs, _info)
    else
        LogTool._cache_logs[(LogTool._cache_index % _cache_max_) + 1] = _info
        LogTool._cache_index = LogTool._cache_index + 1
    end
end

function LogTool.getCacheLog()
    if #LogTool._cache_logs == 0 then
        return 'nolog'
    else
        local s = ''
        for i = 0, #LogTool._cache_logs - 1 do
            local _index = (LogTool._cache_index + i) % #LogTool._cache_logs + 1
            if i ~= 0 then
                s = s .. '\n'
            end
            s = s .. LogTool._cache_logs[_index]
        end
        return s
    end
end


--- 该方法仅在开发环境使用，请勿提交到远端
--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.Debug(tag, msg, ...)
    local str = ": [Debug] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.Log(str) 
        end)
    else
        Debugger.Log(str)
    end
end

--- 该方法仅在开发环境使用，请勿提交到远端
--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.DebugDev(tag, msg, ...)
    -- ==DevDebug Start==

    local str = ": [DebugDev] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    str = str .. "\n" .. debug.traceback()
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.Log(str) 
        end)
    else
        Debugger.Log(str)
    end

    -- ==DevDebug End==

end

--- 该方法仅在开发环境使用，请勿提交到远端
--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.DebugError(tag, msg, ...)
    -- ==DevDebug Start==
    LogTool.Error(tag, msg, ...)
    -- ==DevDebug End==
end


--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.InfoNet(tag, msg, ...)
    local str = ": [InfoNet] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.Log(str) 
        end)
    else
        Debugger.Log(str)
    end
    LogTool._insertCacheLog(str)
end

--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.WarningNet(tag, msg, ...)
    local str = ": [WarningNet] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function()
            Debugger.Log(str)
        end)
    else
        Debugger.Log(str)
    end
    LogTool._insertCacheLog(str)
end

--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.ErrorNet(tag, msg, ...)
    local stackInfo = debug.getinfo(2)
    local stackStr = "[" .. stackInfo.short_src .. "." .. stackInfo.what .. ":" .. stackInfo.currentline .. "]"
    local str = stackStr .. ": [ErrorNet] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    str = str .. "\n" .. debug.traceback()
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.LogError(str) 
        end)
    else
        Debugger.LogError(str)
    end
    LogTool._insertCacheLog(str)
end

--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.Info(tag, msg, ...)
    local str = ": [Info] (" .. tag .. ") " .. tostring(msg)
    local str = ": [Info] (" .. tag .. ") " .. tostring(msg)
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.Log(str) 
        end)
    else
        Debugger.Log(str)
    end
    LogTool._insertCacheLog(str)
end

--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.Warning(tag, msg, ...)
    local str = ": [Warning] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.LogWarning(str) 
        end)
    else
        Debugger.LogWarning(str)
    end
    LogTool._insertCacheLog(str)
end

--- @param tag string
--- @param msg string
--- @param ... any
function LogTool.Error(tag, msg, ...)
    local stackInfo = debug.getinfo(2)
    local stackStr = "[" .. stackInfo.short_src .. "." .. stackInfo.what .. ":" .. stackInfo.currentline .. "]"
    local str = stackStr .. ": [Error] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then 
            str = str .. "," .. pt.block(arg)
        else
            str = str .. ",nil"
        end
    end
    str = str .. "\n" .. debug.traceback()
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function() 
            Debugger.LogError(str) 
        end)
    else
        Debugger.LogError(str)
    end
    LogTool._insertCacheLog(str)
end

---带颜色的打印，仅在开发环境使用
---@param tag string
---@param msg string
---@param color string 颜色使用#RRGGBB格式,不传默认使用绿色
---@param ... unknown
function LogTool.DebugDevColor(tag, msg, color, ...)
    -- ==DevDebug Start==
    local str = ": [DebugDev] (" .. tag .. ") " .. msg
    for i = 1, select('#', ...) do
        local arg = select(i, ...)
        if arg then
            str = str .. pt.block(arg)
        else
            str = str .. "nil"
        end
    end
    color = color or "#00ff00"
    str = "<color=" .. color .. ">" .. str .. "</color>"
    str = str .. "\n" .. debug.traceback()
    if GameMgr.Platform == EPlatform.StandaloneOSX then
        pcall(function()
            Debugger.Log(str)
        end)
    else
        Debugger.Log(str)
    end
    -- ==DevDebug End==
end

return LogTool
