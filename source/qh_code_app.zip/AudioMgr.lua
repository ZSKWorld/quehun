require('GameUtility')

---@class AudioSourceInfo
---@field public index number
---@field public playOnAwake boolean
---@field public loop boolean

local AudioSourceType = {
    --bgm播放器
    Music = {index = 1, playOnAwake = false, loop = true},
    --音效播放器
    Sound = {index = 2, playOnAwake = false, loop = false},
    --角色语音播放器
    Character = {index = 3, playOnAwake = false, loop = false},
    --氛围音效播放器
    Emo = {index = 4, playOnAwake = false, loop = false},
    --心理语音播放器
    Mind = {index = 5, playOnAwake = false, loop = false},
    --比较长的音效 和sound_audio_source共用volume 但是需要单独控制淡入淡出和停止
    Long = {index = 6, playOnAwake = false, loop = false},
    --需要无缝循环的音效播放器 AudioSource无法原生无缝循环
    Loop = {index = 7, playOnAwake = false, loop = false},
    --剧情专用音效特效
    SpotSE = {index = 8, playOnAwake = false, loop = false},
    --剧情专用角色气泡播放器
    BubbleSE = {index = 9, playOnAwake = true, loop = false},
    --剧情内环境音播放器
    SpotAmbient = {index = 10, playOnAwake = false, loop = true},
    --特殊语音播放器（声音大小随角色语音，与对局内的语音可互相打断）
    Special = {index = 11, playOnAwake = false, loop = true},
}

---@type UnityEngine.Transform
local audioContainer
---所有的audiosource
---@type UnityEngine.AudioSource[]
local allAudioSources

---@param sourceInfo AudioSourceInfo
local function GetAudioSource(sourceInfo)
    if not audioContainer then
        ---@type UnityEngine.AudioSource[]
        allAudioSources = {}
        audioContainer = LuaTools.LoadPrefab('audio/AudioSource', GameMgr.Inst.mainscene.transform)
        audioContainer.gameObject:SetActive(true)
        local audioSources = audioContainer:GetComponents(typeof(UnityEngine.AudioSource))
        local count = audioSources.Length
        for i = 0, count - 1 do
            table.insert(allAudioSources, audioSources:GetValue(i))
        end
    end
    local audioSource = allAudioSources[sourceInfo.index]
    if not audioSource then
        audioSource = audioContainer.gameObject:AddComponent(typeof(UnityEngine.AudioSource))
        audioSource.playOnAwake = sourceInfo.playOnAwake
        audioSource.loop = sourceInfo.loop
        allAudioSources[sourceInfo.index] = audioSource
    end
    return audioSource
end

AudioMgr = {}

--'none', 'liqi_bgm', 'bgm'
local EMusicType = GameUtility.EMusicType
--'none', 'start', 'during', 'end'
local EMusicState = GameUtility.EMusicState
local audio_volume = nil
local audio_muted = nil

local character_voice_muted = nil
local character_voice_volume = nil

local character_mind_voice_muted = nil
local character_mind_voice_volume = nil

local current_music = ''
local current_music_type = EMusicState.none
local cached_bgm_music = ''
local cached_liqi_bgm = ''
local cached_ambient_sound = ''
local bgm_volume = nil
local bgm_muted = nil

local liqi_bgm_volume = nil
local liqi_bgm_muted = nil

-- 剧情内用音效id
local current_se_id = 0
local current_bubble_se_id = 0

--BGM用timer
local timerMgr = TimerMgr:Init()
--语音用timer
local timer = TimerMgr:Init()
--long audio用timer
local longAudioTimer = TimerMgr:Init()
--loop audio用timer
local loopAudioTimer = TimerMgr:Init()
--spot audio用timer
local spotAudioTimer = TimerMgr:Init()
--spot bubble用timer
local bubbleAudioTimer = TimerMgr:Init()
-- 用于判断语音优先级的当前id
local cur_audio_id = nil

--BGM监听
AudioMgr.OnBgmChangedHandlers = {}

--- WebGL 下角色 CV 存 Laya 的 characterVolume{id} / characterMute{id}；非 WebGL 不经过 GameMgr，与改键前 PlayerPrefs 行为一致。
--- @param logical_key string
--- @return string key
local function audio_prefs_resolve_key(logical_key)
    if Tools.IsWebGL() then
        local id = string.match(logical_key, "^character_volume(%d+)$")
        if id then
            return "characterVolume" .. id
        end
        id = string.match(logical_key, "^character_mute(%d+)$")
        if id then
            return "characterMute" .. id
        end
    end
    return logical_key
end

---@param logical_key string
---@param default number
---@return number
local function audio_pref_get_float(logical_key, default)
    if not Tools.IsWebGL() then
        return Mathf.Clamp(Tools.getplayerprefshandler().GetFloat(logical_key, default), 0, 1)
    end
    local key, applyMap = audio_prefs_resolve_key(logical_key)
    local s = GameMgr.GetItem(key, false, '')
    if s ~= nil and s ~= '' then
        local n = tonumber(s)
        if n then
            return Mathf.Clamp(n, 0, 1)
        end
    end
    return default
end

---@param logical_key string
---@param v number
local function audio_pref_set_float(logical_key, v)
    if not Tools.IsWebGL() then
        Tools.getplayerprefshandler().SetFloat(logical_key, Mathf.Clamp(v, 0, 1))
        return
    end
    local key = audio_prefs_resolve_key(logical_key)
    GameMgr.SetItem(key, tostring(Mathf.Clamp(v, 0, 1)), false)
end

---@param logical_key string
---@param default_01 number 0 or 1
---@return number
local function audio_pref_get_mute_01(logical_key, default_01)
    if not Tools.IsWebGL() then
        return Tools.getplayerprefshandler().GetInt(logical_key, default_01)
    end
    local key = audio_prefs_resolve_key(logical_key)
    local s = GameMgr.GetItem(key, false, '')
    if s == 'true' then
        return 1
    end
    if s == 'false' then
        return 0
    end
    if s ~= nil and s ~= '' then
        local n = tonumber(s)
        if n ~= nil then
            return Mathf.Clamp(math.floor(n + 0.5), 0, 1)
        end
    end
    return default_01
end

---@param logical_key string
---@param muted_01 number 0 or 1
local function audio_pref_set_mute_01(logical_key, muted_01)
    if not Tools.IsWebGL() then
        Tools.getplayerprefshandler().SetInt(logical_key, muted_01)
        return
    end
    local key = audio_prefs_resolve_key(logical_key)
    GameMgr.SetItem(key, (muted_01 == 1) and 'true' or 'false', false)
end

-- 额外控制的audio，key type，value path
local controling_audio_path = {}
--音效计数器,key是path，value是count ==0时清理audio
local audio_counter = {}

AudioMgr.global_mute = false

function AudioMgr.Build()
    for _, v in pairs(AudioSourceType) do
        GetAudioSource(v)
    end

    audio_volume = audio_pref_get_float('audio_volume', 0.5)
    audio_muted = audio_pref_get_mute_01('audio_muted', 0)

    character_voice_muted = audio_pref_get_mute_01('voice_muted', 0)
    character_voice_volume = audio_pref_get_float('voice_volume', 0.5)

    character_mind_voice_muted = audio_pref_get_mute_01('mind_voice_muted', 0)
    character_mind_voice_volume = audio_pref_get_float('mind_voice_volume', character_voice_volume)

    bgm_volume = audio_pref_get_float('bgm_volume', 0.5)
    bgm_muted = audio_pref_get_mute_01('bgm_muted', 0)

    liqi_bgm_volume = audio_pref_get_float('liqi_bgm_volume', 0.5)
    liqi_bgm_muted = audio_pref_get_mute_01('liqi_bgm_muted', 0)
    
    AudioMgr.global_mute = audio_pref_get_mute_01('global_mute', 0) == 1
    -- 所有设置音量的地方都要乘上总音量
    AudioMgr.globalVolume = audio_pref_get_float('global_volume', 1.0)

    -- 后台静音相关
    if Tools.IsActualPC() then
        AudioMgr.focusCallback = function(hasFocus)
            AudioMgr.OnApplicationFocus(hasFocus)
        end
        AudioMgr.in_background = false
        AudioMgr.mute_in_background = (audio_pref_get_mute_01('background_mute_status', 0) == 1)
        UnityEngine.Application.focusChanged = UnityEngine.Application.focusChanged + AudioMgr.focusCallback
    end
    AudioMgr.RefreshAudioSourceMuteState()
end

--_char_info:Object, _type:string, complete:function
---@return {words:string,path:string}?
function AudioMgr.PlayCharacterSound(_char_info, _type, _complete,is_mind)
    local sound = Tools.get_chara_audio(_char_info, _type)
    if sound == nil then return nil end
    local finalCVVolume = AudioSettingModel:GetFinalCVVolume(_char_info.charid, is_mind)
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Special))
    ---@type UnityEngine.AudioSource
    local audioSource
    if is_mind then
        audioSource = GetAudioSource(AudioSourceType.Mind)
    else
        audioSource = GetAudioSource(AudioSourceType.Character)
    end
    local volume = sound.volume * finalCVVolume
    AudioMgr.PlayAudioSource(audioSource, sound.path, true, timer, nil, 0.5, _complete, volume)
    local result = {}
    result.words = sound.words
    result.path = sound.path
    return result
end

function AudioMgr.PlayCharacterSpecialSound(_char_info, _type, _complete)
    local sound = Tools.get_chara_audio(_char_info, _type)
    if sound == nil then return nil end
    local finalCVVolume = AudioSettingModel:GetFinalCVVolume(_char_info.charid)

    local volume = sound.volume * finalCVVolume
    local audioSource = GetAudioSource(AudioSourceType.Special)
    AudioMgr.PlayAudioSource(audioSource, sound.path, true, timer, nil, 0.5, _complete, volume)
    local result = {}
    result.words = sound.words
    return result
end

-- char_id:角色id，_type:音频类型
-- 仅在剧情使用
function AudioMgr.PlayCharacterSoundInSpot(_sound_id, onComplete)
    local sound = Tools.get_chara_audio_spot(_sound_id)
    if sound == nil then return end
    local finalCVVolume = AudioSettingModel:GetFinalCVVolume(sound.charId)
    local volume = sound.volume * finalCVVolume
    local audioSource = GetAudioSource(AudioSourceType.Character)
    AudioMgr.PlayAudioSource(audioSource, sound.path, true, timer, nil, nil, onComplete, volume)
end

function AudioMgr.StopCharacterSound()
    timer:ClearAllTimers()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Character))
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Mind))
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Special))
    cur_audio_id = nil
    if DesktopMgr and DesktopMgr.Inst then
        DesktopMgr.Inst:ResetGameVoice()
    end
    if GameMgr and GameMgr.Inst then
        GameMgr.Inst.during_playing_mind_voice = false
    end
end

function AudioMgr.PlayCharacterDetailSound(_char_info,_sound_info,_complete)
    local sound = Tools.get_chara_audio(_char_info, 'lobby_normal')
    if _sound_info == nil then return nil end

    local volume = sound.volume * AudioSettingModel:GetFinalCVVolume(_char_info.charid)
    local d_chara = ExcelMgr.GetData('item_definition', 'character', _char_info.charid)
    local audioSource = GetAudioSource(AudioSourceType.Character)
    AudioMgr.PlayAudioSource(audioSource, 'audio/sound/' .. d_chara.sound_folder .. "/" .. _sound_info.path, true, timer, nil, 0.5, _complete, volume)

    local result = {}
    result.words = _sound_info['words_'..GameMgr.Inst.prefer_language]
    return result
end
--_audio_id, loop, volume:int
function AudioMgr.PlayAudio(_audio_id, _volume)
    _volume = _volume or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    local sound = ExcelMgr.GetData('audio', 'audio', _audio_id)
    if not sound then return end
    local audioSource = GetAudioSource(AudioSourceType.Sound)
    audioSource.volume = _volume * seVolume
    AudioMgr.PlayAudioSource(audioSource, sound.path, true, nil, nil, nil, nil, audioSource.volume)
end

function AudioMgr.PlayEffectAudioById(_audio_id, _volume)
    local sound = ExcelMgr.GetData('audio', 'audio', _audio_id)
    if not (sound and sound.path) then
        return
    end
    AudioMgr.PlayEffectAudioByPath(sound.path, _volume)
end

function AudioMgr.PlayEffectAudioByPath(_audio_path, _volume)
    _volume = _volume or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    AudioMgr.AddAudioClip(_audio_path)
    local audioSource = GetAudioSource(AudioSourceType.Sound)
    audioSource.volume = _volume * seVolume
    AudioMgr.PlayAudioSource(audioSource, _audio_path, false)
end

function AudioMgr.PlayoneShotSEByPath(_audio_path)
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    AudioMgr.AddAudioClip(_audio_path)
    local audioSource = GetAudioSource(AudioSourceType.Sound)
    audioSource.volume = seVolume
    AudioMgr.PlayAudioSource(audioSource, _audio_path, true, nil, nil, nil, nil, seVolume)
end

function AudioMgr.StopEffectAudio()
    local audioSource = GetAudioSource(AudioSourceType.Sound)
    AudioMgr.StopAudioSource(audioSource, true)
    AudioMgr.RemoveAudioClipByType('effectAudio')
end


-- 需要单独控制的长音效 同一时间只能播一个
function AudioMgr.PlayLongAudio(_audio_id, _volume)
    _volume = _volume or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    local sound = ExcelMgr.GetData('audio', 'audio', _audio_id)
    if not sound then return end
    
    longAudioTimer:ClearAllTimers()
    local audioSource = GetAudioSource(AudioSourceType.Long)
    audioSource.volume = seVolume * _volume
    AudioMgr.PlayAudioSource(audioSource, sound.path, false)
end

function AudioMgr.StopLongAudio(_tweenTime)
    _tweenTime = _tweenTime or 0.5
    local audioSource = GetAudioSource(AudioSourceType.Long)
    if _tweenTime ~= 0 and audioSource.clip ~= nil then
        local _volume = audioSource.volume
        DG.Tweening.DOTween.To(
            DG.Tweening.Core.DOGetter_float(function() return audioSource.volume end),
            DG.Tweening.Core.DOSetter_float(function(x) audioSource.volume = x end),
            0, _tweenTime)

        timerMgr:Delay(_tweenTime + 0.05, function()
            audioSource.volume = _volume
            AudioMgr.StopAudioSource(audioSource)
            AudioMgr.RemoveAudioClipByType('longAudio')
        end)
    else
        AudioMgr.RemoveAudioClipByType('longAudio')
        AudioMgr.StopAudioSource(audioSource)
    end
end

function AudioMgr.PlayAudioByPath(path, _volume)
    _volume = _volume or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    local volume = _volume * seVolume
    local audioSource = GetAudioSource(AudioSourceType.Emo)
    AudioMgr.PlayAudioSource(audioSource, path, true, nil, nil, nil, nil, volume)
end

-- 淡入循环音效
function AudioMgr.LoopAudio(_audio_id, _tweenTime)
    _tweenTime = _tweenTime or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end
    
    loopAudioTimer:ClearAllTimers()
    local audioSource = GetAudioSource(AudioSourceType.Loop)
    audioSource.loop = true;
    audioSource.volume = 0
    local sound = ExcelMgr.GetData('audio', 'audio', _audio_id)
    AudioMgr.PlayAudioSource(audioSource, sound.path, false, loopAudioTimer, 0, 0, function ()
        DG.Tweening.DOTween.To(
            DG.Tweening.Core.DOGetter_float(function() return audioSource.volume end),
            DG.Tweening.Core.DOSetter_float(function(x) audioSource.volume = x end),
            seVolume, _tweenTime)
    end)
end

-- 淡出循环音效
function AudioMgr.StopLoopAudio(_tweenTime)
    _tweenTime = _tweenTime or 1
    loopAudioTimer:ClearAllTimers()
    local audioSource = GetAudioSource(AudioSourceType.Loop)
    --TODO: 播放和停止间隔太短时 tween渐变可能会有问题 需要测试下
    DG.Tweening.DOTween.To(
        DG.Tweening.Core.DOGetter_float(function() return audioSource.volume end),
        DG.Tweening.Core.DOSetter_float(function(x) audioSource.volume = x end),
        0, _tweenTime)

    timerMgr:Delay(_tweenTime + 0.1, function()
        AudioMgr.StopAudioSource(audioSource)
        AudioMgr.RemoveAudioClipByType('loopAudio')
    end)
end

function AudioMgr.PlayEventVoice(path, _volume, complete)
    _volume = _volume or 1
    local isMute = AudioSettingModel:GetCharacterMute()
    local charVolume = AudioSettingModel:GetFinalCharacterVolume()
    if (isMute or charVolume == 0) then return end
    local volume = _volume * charVolume
    local audioSource = GetAudioSource(AudioSourceType.Character)
    AudioMgr.PlayAudioSource(audioSource, path, true, timer, nil, 0.5, complete, volume)
end

function AudioMgr.StopEventVoice()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Character))
    timer:ClearAllTimers()
end

function AudioMgr.StopAudio()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Sound))
end

function AudioMgr.StopMindVoice()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Mind))
end

function AudioMgr.StopSpecialVoice()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.Special))
end

--_music_path:string, force:bool, _tweenTime:float(second)
function AudioMgr.PlayBgm(_music_path, force, _tweenTime, loop, volume)
    if force then
        current_music = ''
        cached_liqi_bgm = ''
        timerMgr:ClearAllTimers()
    end
    cached_bgm_music = _music_path
    _tweenTime = _tweenTime or 1
    AudioMgr.PlayMusic(_tweenTime, nil, loop, false, volume)
end

function AudioMgr.PlayTanfangBgm(_audio_id, _tweenTime, is_loop, force)
    if force then
        current_music = ''
    end
    cached_liqi_bgm = ''
    timerMgr:ClearAllTimers()
    local _music_path = ExcelMgr.GetData('audio', 'audio', _audio_id).path
    cached_bgm_music = _music_path
    _tweenTime = _tweenTime or 1
    AudioMgr.PlayMusic(_tweenTime, false, not not is_loop, true)
end

function AudioMgr.PlayLiqiBgm(_music_path, force, _tweenTime)
    if not force and _music_path == cached_liqi_bgm then return end
    AudioSettingModel.gameLiqibgm = _music_path
    if AudioSettingModel.isAudition then
        return
    end
    if force then
        current_music = ''
        timerMgr:ClearAllTimers()
    end
    cached_liqi_bgm = _music_path
    _tweenTime = _tweenTime or 1
    AudioMgr.PlayMusic(_tweenTime)
end

--播放立直音乐预览 忽略静音
function AudioMgr.PlayLiqiBgmPreview(_music_path, _tweenTime)
    current_music = ''
    timerMgr:ClearAllTimers()
    cached_liqi_bgm = _music_path
    _tweenTime = _tweenTime or 1
    AudioMgr.PlayMusic(_tweenTime, true)
end

--播放音乐预览 忽略静音
function AudioMgr.PlayBgmPreview(_music_path, _tweenTime)
    current_music = ''
    timerMgr:ClearAllTimers()
    cached_bgm_music = _music_path
    _tweenTime = _tweenTime or 1
    AudioMgr.PlayMusic(_tweenTime, true,true)
end

function AudioMgr.TryPlayMusic(music_path, volume, callback, force_length, ignoreGlobalMute)
    timerMgr:ClearAllTimers()
    for i = 1, #AudioMgr.OnBgmChangedHandlers do
       AudioMgr.OnBgmChangedHandlers[i](music_path)
    end
    cached_liqi_bgm = ''
    current_music_type = EMusicType.bgm
    local audioSource = GetAudioSource(AudioSourceType.Music)
    audioSource.volume = volume * 0.5
    if (ignoreGlobalMute) then
        audioSource.mute = false
    end
    AudioMgr.OnMusicStoped()
    AudioMgr.PlayAudioSource(audioSource, music_path, false, timerMgr, force_length, 0, function()
        AudioMgr.StopAudioSource(audioSource)
        if callback then callback() end
       current_music = ''
       AudioMgr.RemoveAudioClipByType('tryPlayMusic')
    end)
    current_music = music_path
end

function AudioMgr.TryPlayMusicShot(music_path, volume, callback,force_length)
    -- TODO 先屏蔽
    timerMgr:ClearAllTimers()
    
    for i = 1, #AudioMgr.OnBgmChangedHandlers do
       AudioMgr.OnBgmChangedHandlers[i](music_path)
    end
    
    current_music_type = EMusicType.bgm
    local audioSource = GetAudioSource(AudioSourceType.Music)
    audioSource.volume = volume * 0.5
    AudioMgr.PlayAudioSource(audioSource, music_path, true, timerMgr, force_length, 0, function()
       current_music = ''
       if callback then callback() end
    end)
    current_music = music_path
end

--_music_path:string, _tweenTime, _volume:float
---@param is_audio_bgm boolean | nil tanfang用的bgm 音量由audio音量控制
function AudioMgr.PlayMusic(_tweenTime, ignore_mute, loop, is_audio_bgm, volume)
    local _music_path = ''
    local _volume = 0
    local _isLoop = not not loop
    local isLiQiBgmMute = AudioSettingModel:GetLiQiBgmMute()
    local liQiBgmVolume = AudioSettingModel:GetFinalLiQiBgmVolume()
    if (ignore_mute or not isLiQiBgmMute) and cached_liqi_bgm ~= '' then
        _music_path = cached_liqi_bgm
        _volume = liQiBgmVolume * 0.5
        if ignore_mute then
            _volume = Mathf.Max(0.25, _volume)
        end
        current_music_type = EMusicType.liqi_bgm
        _isLoop = true
    end
    local isBgmMute, bgmVolume
    if (is_audio_bgm) then
        isBgmMute = AudioSettingModel:GetSEMute()
        bgmVolume = AudioSettingModel:GetFinalSEVolume()
    else
        isBgmMute = AudioSettingModel:GetBgmMute()
        bgmVolume = AudioSettingModel:GetFinalBgmVolume()
    end
    if _music_path == '' and (ignore_mute or not isBgmMute) and cached_bgm_music ~= '' then
       _music_path = cached_bgm_music
       _volume = bgmVolume * 0.5
       if ignore_mute then
           _volume = Mathf.Max(0.25, _volume)
       end
       current_music_type = EMusicType.bgm
    end

    if volume then
        _volume = _volume * volume
    end

    for i = 1, #AudioMgr.OnBgmChangedHandlers do
        AudioMgr.OnBgmChangedHandlers[i](_music_path)
    end

    if _music_path ~= '' then
       local audioSource = GetAudioSource(AudioSourceType.Music)
       if current_music ~= _music_path then
            --    music_version = music_version + 1
           AudioMgr.RemoveAudioClipByType('music')
           timerMgr:ClearAllTimers()
    
           ---@type fun()
           local delayCompleted = nil
            if _isLoop then
                audioSource.loop = true
            else
                audioSource.loop = false
                if not is_audio_bgm then
                    delayCompleted = function()
                        AudioSettingModel:PlayBgm(true)
                    end
                end
            end
           
           if current_music == '' then
               audioSource.volume = _volume
               AudioMgr.PlayAudioSource(audioSource, _music_path, false, timerMgr, nil, 0, delayCompleted);
               current_music = _music_path
           else
               DG.Tweening.DOTween.To(
                   DG.Tweening.Core.DOGetter_float(function() return audioSource.volume end),
                   DG.Tweening.Core.DOSetter_float(function(x) audioSource.volume = x end),
                   0, _tweenTime)
                   
               timerMgr:Delay(_tweenTime + 0.1, function()
                   AudioMgr.StopAudioSource(audioSource)
                   audioSource.volume = _volume
                   AudioMgr.PlayAudioSource(audioSource, _music_path, false, timerMgr, nil, 1 - _tweenTime - 0.1, delayCompleted)
                   current_music = _music_path
               end)
           end
        else
            audioSource.volume = _volume
        end
    
    else
       AudioMgr.RemoveAudioClipByType('music')
    end
end

---@param _tweenTime number 渐隐持续时长，不填默认1
function AudioMgr.StopMusic(_tweenTime, clearGameLiqiBgm)
    if clearGameLiqiBgm or clearGameLiqiBgm == nil then
        AudioSettingModel.gameLiqibgm = nil
    end
    timerMgr:ClearAllTimers()
    _tweenTime = _tweenTime or 1
    local audioSource = GetAudioSource(AudioSourceType.Music)
    if _tweenTime == 0 then
        AudioMgr.StopAudioSource(audioSource)
        AudioMgr.OnMusicStoped()
        current_music = ''
        for i = 1, #AudioMgr.OnBgmChangedHandlers do
            AudioMgr.OnBgmChangedHandlers[i]()
        end
        cached_bgm_music = ''
        cached_liqi_bgm = ''
        current_music_type = EMusicType.none
    else
        DG.Tweening.DOTween.To(
            DG.Tweening.Core.DOGetter_float(function() return audioSource.volume end),
            DG.Tweening.Core.DOSetter_float(function(x) audioSource.volume = x end),
            0, _tweenTime)
        timerMgr:Delay(_tweenTime, function()
            AudioMgr.StopAudioSource(audioSource)
            AudioMgr.OnMusicStoped()
            current_music = ''
            for i = 1, #AudioMgr.OnBgmChangedHandlers do
                AudioMgr.OnBgmChangedHandlers[i]('')
            end
            cached_bgm_music = ''
            cached_liqi_bgm = ''
            current_music_type = EMusicType.none
        end)
    end
end
function AudioMgr.PlayAmbientSound(_music_path, volume, force, _tweenTime)
    local _volume = 0

    local isMute = AudioSettingModel:GetBgmMute()
    local finalVolume = AudioSettingModel:GetFinalBgmVolume()
    if not isMute and not AudioMgr.global_mute then
        _volume = finalVolume
        if volume then
            _volume = _volume * volume
        end
    end
    local audioSource = GetAudioSource(AudioSourceType.SpotAmbient)
    if not force and _music_path == cached_ambient_sound then       
        audioSource.volume = _volume
        return 
    end
    
    _tweenTime = _tweenTime or 1
    timerMgr:ClearAllTimers()

    if cached_ambient_sound == '' then
        audioSource.volume = _volume
        AudioMgr.PlayAudioSource(audioSource, _music_path, false)
    elseif cached_ambient_sound ~= _music_path then
        DG.Tweening.DOTween.To(
            DG.Tweening.Core.DOGetter_float(function()
                return audioSource.volume
            end),
            DG.Tweening.Core.DOSetter_float(function(x)
                audioSource.volume = x
            end), 0, _tweenTime)
        timerMgr:Delay(_tweenTime + 0.1, function()
            AudioMgr.StopAudioSource(audioSource)
            audioSource.volume = _volume
            AudioMgr.PlayAudioSource(audioSource, _music_path, false)
        end)
    end 
    cached_ambient_sound = _music_path
end

function AudioMgr.StopAmbientSound(_tweenTime)
    --timerMgr:ClearAllTimers()
    _tweenTime = _tweenTime or 1
    local audioSource = GetAudioSource(AudioSourceType.SpotAmbient)
    DG.Tweening.DOTween.To(
        DG.Tweening.Core.DOGetter_float(function()
            return audioSource.volume
        end),
        DG.Tweening.Core.DOSetter_float(function(x)
            audioSource.volume = x
        end),
        0,
        _tweenTime)
    timerMgr:Delay(_tweenTime, function()
        AudioMgr.StopAudioSource(audioSource)
        cached_ambient_sound = ''
    end)
end

function AudioMgr.OnMusicStoped()
    AudioMgr.RemoveAudioClipByType('tryPlayMusic')
    AudioMgr.RemoveAudioClipByType('music')
end

function AudioMgr.GetCurrentMusicPath()
    return current_music
end

function AudioMgr.GetCurrentMusicType()
    return current_music_type
end

function AudioMgr.GetCacheMusicPath()
    return cached_bgm_music
end

function AudioMgr.GetCacheLiqiBgm()
    return cached_liqi_bgm
end

function AudioMgr.PlaySoundEffect(_audio_id, _delay, onComplete)
    local audioSource = GetAudioSource(AudioSourceType.SpotSE)
    if audioSource.isPlaying and _audio_id == current_se_id then
        if onComplete then onComplete() end
        return
    end
    local audio = ExcelMgr.GetData('spot', 'audio_spot', _audio_id)
    if not audio then
        if onComplete then onComplete() end
        return
    end
    current_se_id = _audio_id
    AudioMgr.PlaySoundEffectByPath(audio.path, _delay, 1, onComplete)
end

function AudioMgr.PlaySoundEffectByPath(_path, _delay, _volume, onComplete)
    _volume = _volume or 1
    _delay = _delay or 0
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end

    spotAudioTimer:ClearAllTimers()
    local audioSource = GetAudioSource(AudioSourceType.SpotSE)
    AudioMgr.StopAudioSource(audioSource)
    audioSource.volume = _volume * seVolume
    spotAudioTimer:Delay(_delay, function ()
        AudioMgr.PlayAudioSource(audioSource, _path, false, spotAudioTimer,0,0,onComplete)
    end)
end
function AudioMgr.StopSoundEffect()
    current_se_id = 0
    spotAudioTimer:ClearAllTimers()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.SpotSE))
end

function AudioMgr.PlayBubbleSoundEffect(_audio_id, _delay, _volume)
    local audioSource = GetAudioSource(AudioSourceType.BubbleSE)
    if audioSource.isPlaying and _audio_id == current_bubble_se_id then return end

    local audio = ExcelMgr.GetData('spot', 'audio_spot', _audio_id)
    if not audio then return end

    current_bubble_se_id = _audio_id
    _volume = _volume or 1
    _delay = _delay or 0
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end

    bubbleAudioTimer:ClearAllTimers()
    AudioMgr.StopAudioSource(audioSource)
    audioSource.volume = _volume * seVolume
    bubbleAudioTimer:Delay(_delay, function()
        AudioMgr.PlayAudioSource(audioSource, audio.path, false)
    end)
end

function AudioMgr.StopBubbleSoundEffect()
    current_bubble_se_id = 0
    bubbleAudioTimer:ClearAllTimers()
    AudioMgr.StopAudioSource(GetAudioSource(AudioSourceType.BubbleSE))
end

--CV
--char_id:int
function AudioMgr.get_cv_volume(char_id)
    local volumeData = {}
    local vol_key = 'character_volume' .. char_id
    local mute_key = 'character_mute' .. char_id
    volumeData.volume = audio_pref_get_float(vol_key, 0.5)
    volumeData.muted = audio_pref_get_mute_01(mute_key, 0)
    return volumeData
end

function AudioMgr.set_cv_volume(char_id, volume)
    audio_pref_set_float('character_volume' .. char_id, volume)
end

function AudioMgr.set_cv_mute(char_id, mute)
    audio_pref_set_mute_01('character_mute' .. char_id, mute)
end



---BGM
function AudioMgr.get_bgm_volume()
    local volumeData = {}
    volumeData.volume = audio_pref_get_float('bgm_volume', 0.5)
    volumeData.muted = audio_pref_get_mute_01('bgm_muted', 0)
    return volumeData
end

--_volume:float
function AudioMgr.set_bgm_volume(_volume)
    if current_music_type == EMusicType.bgm then
        local audioSource = GetAudioSource(AudioSourceType.Music)
        audioSource.volume = _volume * 0.5 * AudioMgr.globalVolume
    end
    audio_pref_set_float('bgm_volume', _volume)
end

--_muted:int
function AudioMgr.set_bgm_muted(_muted)
    audio_pref_set_mute_01('bgm_muted', Mathf.Clamp(_muted, 0 , 1))
    if current_music_type == EMusicType.bgm then
        if _muted == 1 then
            local audioSource = GetAudioSource(AudioSourceType.Music)
            if audioSource.clip ~= nil then
                for i = 1, #AudioMgr.OnBgmChangedHandlers do
                    AudioMgr.OnBgmChangedHandlers[i]('')
                end
            end
            AudioMgr.StopAudioSource(audioSource)
        else
            AudioSettingModel:PlayBgm(true)
        end 
    elseif current_music_type == EMusicType.none then
        AudioMgr.PlayBgm(cached_bgm_music, true)
    end
end


---LIQIBGM
function AudioMgr.get_liqi_bgm_volume()
    local volumeData = {}
    volumeData.volume = audio_pref_get_float('liqi_bgm_volume', 0.5)
    volumeData.muted = audio_pref_get_mute_01('liqi_bgm_muted', 0)
    return volumeData
end

--_volume:float
function AudioMgr.set_liqi_volume(_volume)
    if current_music_type == EMusicType.liqi_bgm then
        local audioSource = GetAudioSource(AudioSourceType.Music)
        audioSource.volume = _volume * 0.5 * AudioMgr.globalVolume
    end
    audio_pref_set_float('liqi_bgm_volume', _volume)
end

function AudioMgr.is_liqi_playing()
    return current_music_type == EMusicType.liqi_bgm
end

--_muted:int
function AudioMgr.set_liqi_muted(_muted)
    audio_pref_set_mute_01('liqi_bgm_muted', _muted)
    if _muted == 1 and current_music_type == EMusicType.liqi_bgm then
        local audioSource = GetAudioSource(AudioSourceType.Music)
        AudioMgr.StopAudioSource(audioSource)
        AudioMgr.PlayBgm(cached_bgm_music, true)
    elseif cached_liqi_bgm ~= '' then
        AudioMgr.PlayLiqiBgm(cached_liqi_bgm, true)
    end
end

---Audio
function AudioMgr.get_audio_volume()
    local volumeData = {}
    volumeData.volume = audio_pref_get_float('audio_volume', 0.5)
    volumeData.muted = audio_pref_get_mute_01('audio_muted', 0)
    return volumeData
end

--_volume:float
function AudioMgr.set_audio_volume(_volume)
    audio_pref_set_float('audio_volume', _volume)
end

--_muted:int
function AudioMgr.set_audio_muted(_muted)
    audio_pref_set_mute_01('audio_muted', Mathf.Clamp(_muted, 0 , 1))
    if _muted == 1 then
        AudioMgr.StopAudio()
    end
end

function AudioMgr.get_voice_volume(is_mind)
    local volumeData = {}
    if not is_mind then
        volumeData.volume = audio_pref_get_float('voice_volume', 0.5)
        volumeData.muted = audio_pref_get_mute_01('voice_muted', 0)
    else
        volumeData.volume = audio_pref_get_float('mind_voice_volume', audio_pref_get_float('voice_volume', 0.5))
        volumeData.muted = audio_pref_get_mute_01('mind_voice_muted', 0)
    end
    return volumeData
end

function AudioMgr.set_voice_volume(_volume)
    character_voice_volume = _volume
    audio_pref_set_float('voice_volume', _volume)
end

function AudioMgr.set_voice_muted(_muted)
    audio_pref_set_mute_01('voice_muted', Mathf.Clamp(_muted, 0 , 1))
    character_voice_muted = _muted
    if _muted == 1 then
        AudioMgr.StopEventVoice()
    end
end

function AudioMgr.set_mind_voice_volume(_volume)
    character_mind_voice_volume = _volume
    audio_pref_set_float('mind_voice_volume', _volume)
end

function AudioMgr.set_mind_voice_muted(_muted)
    audio_pref_set_mute_01('mind_voice_muted', Mathf.Clamp(_muted, 0 , 1))
    character_mind_voice_muted = _muted
    if _muted == 1 then
        AudioMgr.StopMindVoice()
    end
end

--- 全局静音
--- @param mute boolean
function AudioMgr.SetGlobalMute(mute)
    mute = not not mute
    AudioMgr.global_mute = mute
    local prefs_value
    if mute then
        prefs_value = 1
    else
        prefs_value = 0
    end
    audio_pref_set_mute_01('global_mute', prefs_value)
    AudioMgr.RefreshAudioSourceMuteState()
    if current_music_type == EMusicType.bgm then
        if (mute) then
            local audioSource = GetAudioSource(AudioSourceType.Music)
            if audioSource.clip ~= nil then
                for i = 1, #AudioMgr.OnBgmChangedHandlers do
                    AudioMgr.OnBgmChangedHandlers[i]('')
                end
            end
            AudioMgr.StopAudioSource(audioSource)
        else
            AudioSettingModel:PlayBgm(true)
        end
    elseif current_music_type == EMusicType.none then
        AudioMgr.PlayBgm(cached_bgm_music, true)
    end
end

function AudioMgr.RefreshAudioSourceMuteState()
    for k, v in pairs(allAudioSources) do
        if AudioMgr.in_background and AudioMgr.mute_in_background then
            -- 后台静音
            v.mute = true
        else
            v.mute = AudioMgr.global_mute
        end
    end
end

function AudioMgr.SetGlobalVolume(value)
    AudioMgr.globalVolume = value
    audio_pref_set_float('global_volume', value)
    local audioSource = GetAudioSource(AudioSourceType.Music)
    if (current_music_type == EMusicType.bgm) then
        audioSource.volume = value * 0.5 * AudioSettingModel:GetFinalBgmVolume()
    elseif (current_music_type == EMusicType.liqi_bgm) then
        audioSource.volume = value * 0.5 * AudioSettingModel:GetFinalLiQiBgmVolume()
    end
end

function AudioMgr.ResetAllSettings()
    current_music = ''
    
    AudioMgr.SetGlobalMute(false)

    audio_pref_set_float('audio_volume', 0.5)
    audio_pref_set_mute_01('audio_muted', 0)

    audio_pref_set_mute_01('voice_muted', 0)
    audio_pref_set_float('voice_volume', 0.5)

    audio_pref_set_mute_01('mind_voice_muted', 0)
    audio_pref_set_float('mind_voice_volume', 0.5)

    audio_pref_set_float('bgm_volume', 0.5)
    audio_pref_set_mute_01('bgm_muted', 0)

    audio_pref_set_float('liqi_bgm_volume', 0.5)
    audio_pref_set_mute_01('liqi_bgm_muted', 0)

    local char_data = ExcelMgr.GetTable('item_definition', 'character')
    for char_id, value in pairs(char_data) do
        if audio_pref_get_float('character_volume' .. char_id, 0.5) ~= 0.5 then
            audio_pref_set_float('character_volume' .. char_id, 0.5)
        end
        if audio_pref_get_mute_01('character_mute' .. char_id, 0) ~= 0 then
            audio_pref_set_mute_01('character_mute' .. char_id, 0)
        end
    end
end

--- 返回指定id动皮 指定动画对应的音频名称
---@return string 'XYW_SE/240228_qh_xiangyuanwu_celebrate.mp3'
---@param skin_id number 动皮id
---@param anim_name string 动画名称
function AudioMgr.get_skin_voice_by_id_name(skin_id,anim_name)
    local skin_info = ExcelMgr.GetData('character','skin',skin_id) -- 可能为空
    if not skin_info then
        return ''
    end
    if anim_name == 'idle' then
        return skin_info.audio_idle or ''
    elseif  anim_name == 'greeting' then
        return skin_info.audio_greeting or ''
    elseif  anim_name == 'click' then
        return skin_info.audio_click or ''
    elseif  anim_name == 'click2' then
        return skin_info.audio_click2 or ''
    elseif  anim_name == 'celebrate' then
        return skin_info.audio_celebrate or ''

    end
    return ''
end

-- --重新封装一次loadClip，添加lua侧的audio计数，仅针对单次播放，多余控制的请直接使用addAudioClip和remove
-- function AudioMgr.LoadAudioClip(path, audioType)
--     local clip = LuaTools.LoadClip(path)
--     if clip then
--         AudioMgr.AddAudioClip(path)
--         if not audioType then

--             timer:Delay(clip.length + 0.5,function()
--                 AudioMgr.RemoveAudioClip(path)
--             end)
--         else
--             if controling_audio_path[audioType] then
--                 LuaTools.RemoveClip(controling_audio_path[audioType])
--             end

--             controling_audio_path[audioType] = path
--         end

--     end
--     return clip
-- end

function AudioMgr.AddAudioClip(path)
--     if audio_counter[path] then
--         audio_counter[path] = audio_counter[path] + 1
--     else
--         audio_counter[path] = 1
--     end
end

function AudioMgr.RemoveAudioClip(path)
--     if audio_counter[path] then
--         audio_counter[path] = audio_counter[path] - 1
--     end
    -- LuaTools.RemoveClip(path)
end

function AudioMgr.RemoveAudioClipByType(audioType)
--     if controling_audio_path[audioType] ~= nil then
--         LuaTools.RemoveClip(controling_audio_path[audioType])
--         controling_audio_path[audioType] = nil
--     end
    
end

---@type table<UnityEngine.AudioSource, number>
AudioMgr.audioSourceLoadId = {}
---@type table<UnityEngine.AudioSource, string>
AudioMgr.audioSourcePlayClipMap = {}
---@type table<string, number>
AudioMgr.clipCounterMap = {}

---@private
---@param audioSource UnityEngine.AudioSource
---@param audioPath string
---@param oneShot? boolean default true
---@param delayTimer? TimerMgr
---@param delay? number
---@param comleted? fun()
---@param delayOffset? number
---@param oneShotVolume? number
function AudioMgr.PlayAudioSource(audioSource, audioPath, oneShot, delayTimer, delay, delayOffset, comleted, oneShotVolume)
    oneShot = oneShot == nil and true or (not not oneShot)

    AudioMgr.AddClipCounter(audioPath)
    AudioMgr.audioSourceLoadId[audioSource] = AudioMgr.audioSourceLoadId[audioSource] or 0

    local loadId = AudioMgr.audioSourceLoadId[audioSource]
    ---@param clip UnityEngine.AudioClip
    AudioLoaderManager.LoadClip(audioPath, nil, function (clip)
        if not clip then
            -- 2026.5.8 增加没有获取到音频资源的Log提示
            LogTool.DebugError('AudioMgr', 'there has no audio:' .. audioPath)
            AudioMgr.RemoveClipCounter(audioPath)
            return
        end
        if loadId ~= AudioMgr.audioSourceLoadId[audioSource] then
            AudioMgr.RemoveClipCounter(audioPath)
            return
        end
        if oneShot then
            audioSource:PlayOneShot(clip, oneShotVolume)
            TimeMgr.Delay(clip.length, function() AudioMgr.RemoveClipCounter(audioPath) end)
        else
            audioSource.clip = clip
            audioSource:Play()
            AudioMgr.audioSourcePlayClipMap[audioSource] = audioPath
        end
        if comleted then
            delayOffset = delayOffset == nil and 0 or delayOffset
            delayTimer:Delay(delay == nil and (clip.length + delayOffset) or delay, comleted)
        end
    end)
end

---@private
---@param audioSource UnityEngine.AudioSource
---@param play? boolean
function AudioMgr.StopAudioSource(audioSource, play)
    AudioMgr.RemoveClipCounter(AudioMgr.audioSourcePlayClipMap[audioSource])
    AudioMgr.audioSourcePlayClipMap[audioSource] = nil
    audioSource.clip = nil
    if play then
        audioSource:Play()
    else
        audioSource:Stop()
    end
    AudioMgr.audioSourceLoadId[audioSource] = (AudioMgr.audioSourceLoadId[audioSource] or 0) + 1
end

---@private
function AudioMgr.AddClipCounter(audioPath)
    if not audioPath then return end
    AudioMgr.clipCounterMap[audioPath] = (AudioMgr.clipCounterMap[audioPath] or 0) + 1
end

---@private
function AudioMgr.RemoveClipCounter(audioPath)
    if not audioPath then return end
    if not AudioMgr.clipCounterMap[audioPath] then return end
    if AudioMgr.clipCounterMap[audioPath] <= 0 then return end
    AudioMgr.clipCounterMap[audioPath] = AudioMgr.clipCounterMap[audioPath] - 1
    if AudioMgr.clipCounterMap[audioPath] == 0 then
        AudioLoaderManager.RemoveClip(audioPath)
    end
end

--- 后台状态切换
--- @param hasFocus boolean
function AudioMgr.OnApplicationFocus(hasFocus)
    AudioMgr.in_background = not hasFocus
    AudioMgr.RefreshAudioSourceMuteState()
end

--- 后台设置
--- @param mute boolean
function AudioMgr.SetMuteInBackground(mute)
    AudioMgr.mute_in_background = mute
    AudioMgr.RefreshAudioSourceMuteState()
end

--- lua环境重置时调用
function AudioMgr.Reset()
    if (Tools.IsActualPC())
        and AudioMgr.focusCallback then
        UnityEngine.Application.focusChanged = UnityEngine.Application.focusChanged - AudioMgr.focusCallback
    end
end

--region 语音优先级相关

local high_level_audio = {
    'act_chi',
    'act_pon',
    'act_kan',
    'act_babei',
    'act_ron',
    'act_tumo',
    'act_rich',
    'act_drich',
    'gameend_jiuzhongjiupai',
    'gameend_sanjiahule',
    'gameend_sifenglianda',
    'gameend_sijializhi',
    'gameend_sigangliuju',
}
local id = 0
-- local cur_audio_id = nil
local multi_ron = false

--- 通过id播放语音
--- @param audio_id integer
--- @param volume integer
function AudioMgr.PlaySoundNew(audio_id, volume)
    if not AudioMgr.CheckCanPlaySound() then
        return
    end
    id = id + 1
    local current_id = id
    volume = volume or 1
    local isMute = AudioSettingModel:GetSEMute()
    local seVolume = AudioSettingModel:GetFinalSEVolume()
    if (seVolume == 0 or isMute) then return end

    local sound = ExcelMgr.GetData('audio', 'audio', audio_id)
    if not sound then
        return
    end
    local audioSource = GetAudioSource(AudioSourceType.Sound)
    audioSource.volume = volume * seVolume
    AudioMgr.PlayAudioSource(audioSource, sound.path, true, nil, nil, nil, function()
        AudioMgr.OnPlayEnd(current_id)
    end, audioSource.volume)
    cur_audio_id = audio_id
end

--- 播放角色语音
--- @param char_info any
--- @param type string
--- @param complete function|nil
--- @param is_mind boolean|nil
function AudioMgr.PlayCharSoundNew(char_info, type, complete, is_mind)
    if not AudioMgr.CheckCanPlayCharSound(type) then
        return
    end
    id = id + 1
    local current_id = id
    local sound = AudioMgr.PlayCharacterSound(char_info, type, function()
        AudioMgr.OnPlayEnd(current_id)
        if complete then
            complete()
        end
    end, is_mind)
    if not sound then
        return
    end
    cur_audio_id = sound.path
    return sound
end

--- 是否可以播放语音
--- @return boolean
function AudioMgr.CheckCanPlaySound()
    if cur_audio_id then
        AudioMgr.StopCharacterSound()
        cur_audio_id = nil
    end
    return true
end

--- 是否可以播放角色语音
--- @param type string
--- @return boolean
function AudioMgr.CheckCanPlayCharSound(type)
    if multi_ron and type == 'act_ron' then
        return true
    end
    if cur_audio_id or (DesktopMgr and DesktopMgr.Inst and DesktopMgr.Inst:IsPlayingGameVoice()) then
        local is_high = false
        for _, value in ipairs(high_level_audio) do
            if value == type then
                is_high = true
                break
            end
        end
        if not is_high then
            return false
        end
        AudioMgr.StopCharacterSound()
        cur_audio_id = nil
    end
    return true
end

--- 播放完成
--- @param cur_id integer
function AudioMgr.OnPlayEnd(cur_id)
    if cur_id ~= id then
        return
    end
    cur_audio_id = nil
end

function AudioMgr.SetMultiRon(open)
    multi_ron = open or false
end

--endregion 语音优先级相关

function AudioMgr.GetMusicSource()
    return allAudioSources and allAudioSources[1]
end

function AudioMgr.GetLongAudioSource()
    return allAudioSources and allAudioSources[6]
end

--- 暂停
function AudioMgr.PauseMusic()
    local audioSource = GetAudioSource(AudioSourceType.Music)
    if audioSource then
        audioSource:Pause()
    end
end

--- 恢复
function AudioMgr.ResumeMusic()
    local audioSource = GetAudioSource(AudioSourceType.Music)
    if audioSource and audioSource.clip then
        audioSource:UnPause()
    end
end

--- 暂停
function AudioMgr.PauseLongAudio()
    local audioSource = GetAudioSource(AudioSourceType.Long)
    if audioSource then
        audioSource:Pause()
    end
end

--- 恢复
function AudioMgr.ResumeLongAudio()
    local audioSource = GetAudioSource(AudioSourceType.Long)
    if audioSource and audioSource.clip then
        audioSource:UnPause()
    end
end

AudioMgr.manualLockedPaths = {}

function AudioMgr.Lock(path)
    if not path or path == "" then
        return
    end
    if not AudioMgr.manualLockedPaths[path] then
        AudioMgr.manualLockedPaths[path] = true
        AudioMgr.AddClipCounter(path)
        AudioLoaderManager.LoadClip(path, nil, function(clip)
        end)
    end
end

function AudioMgr.Unlock(path)
    if not path or path == "" then
        return
    end
    if AudioMgr.manualLockedPaths[path] then
        AudioMgr.manualLockedPaths[path] = nil
        AudioMgr.RemoveClipCounter(path)
    end
end

return AudioMgr