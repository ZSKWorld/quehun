Basic = { }

--- 模拟枚举变量，提高可读性
---@return table<any, any>
function Basic.Enum(t)
	local result = {}
	local start_index = 0
	for k, v in ipairs(t) do
		if type(v) == 'string' then
			result[v] = start_index
			result[start_index] = v
		elseif type(v) == 'table' then
			for _k, _v in pairs(v) do
				assert(type(_k) == 'string')
				assert(type(_v) == 'number')
				start_index = _v
				result[_k] = start_index
				result[start_index] = _k
			end
		end
		start_index = start_index + 1
	end
	return result
end

return Basic