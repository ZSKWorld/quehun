
CONST = 
{
	USE_PROTO_DATA = false,
	USE_PROTO_LANG = false,
	USE_EXCEL_TEST = 2,
}

local __const__ = function() end;--标记静态类
setmetatable(CONST, {
	__index = function(_, k)
		if k == "__const__" then
			return __const__;
		end
	end;
	__metatable = false  -- 防止元表被修改
})