---@class CameraRatioLimitAreaMgr
CameraRatioLimitAreaMgr = {}

CameraRatioLimitAreaMgr.Inited = false

function CameraRatioLimitAreaMgr.Init()
    if CameraRatioLimitArea and typeof(CameraRatioLimitArea) ~= nil and CameraRatioLimitArea.Instance then
        CameraRatioLimitAreaMgr.Inited = true
    end
    if not CameraRatioLimitAreaMgr.Inited then
        return
    end
    CameraRatioLimitArea.Instance:Reset()
    CameraRatioLimitArea.Instance.MIN_RATIO = 4.0 / 3.0
    CameraRatioLimitArea.Instance:AddCamera(UnityEngine.Camera.main)
end

function CameraRatioLimitAreaMgr.AddCamera(camera)
    if not CameraRatioLimitAreaMgr.Inited then
        return
    end
    CameraRatioLimitArea.Instance:AddCamera(camera)
end

function CameraRatioLimitAreaMgr.GetScreenWidth()
    if CameraRatioLimitAreaMgr.Inited then
        return CameraRatioLimitArea.Instance.FullScreenCamera.pixelWidth
    else
        return UnityEngine.Screen.width
    end
end

function CameraRatioLimitAreaMgr.GetScreenHeight()
    if CameraRatioLimitAreaMgr.Inited then
        return CameraRatioLimitArea.Instance.FullScreenCamera.pixelHeight
    else
        return UnityEngine.Screen.height
    end
end

return CameraRatioLimitAreaMgr
