require "CapsLan.CodeTree"
require "CapsLan.CapsValue"
require "CapsLan.Word"

---@class CapsLanVM
CapsLanVM = {}
CapsLanVM.ECodeJumpType = Basic.Enum({ 'none', '_return', '_break', '_continue' })
local operatorPriority = {
    ['__lineEnd__'] = -99999,
    [','] = -1000,
    ['='] = 1000,
    ['or'] = 2000,
    ['and'] = 2001,
    ['not'] = 2002,
    ['=='] = 3000,
    ['!='] = 3000,
    ['<'] = 4000,
    ['<='] = 4000,
    ['>'] = 4000,
    ['>='] = 4000,
    ['+'] = 5000,
    ['-'] = 5000,
    ['*'] = 5000,
    ['/'] = 5000,
    ['%'] = 5001,
    ['+='] = 5002,
    ['-='] = 5002,
    ['*='] = 5002,
    ['/='] = 5002,
    ['%='] = 5002,
}

function CapsLanVM:new(o)
    ---@type CapsLanVM
    local o = o or {}
    setmetatable(o, self)
    self.__index = self
    self.vars = {}
    return o
end

function CapsLanVM:GetOperatorPriority(str)
    return operatorPriority[str] or -1
end

function CapsLanVM:GetRuntimeValue(var)
    if var.type == CapsValue.EValueType._var then
        local curVar = self.vars[tostring(var.value)]
        if curVar == nil then
            LogTool.Info('语法错误200001, 使用了未定义的变量: ' .. var.value)
            return CapsValue:new();
        end
        return self:GetRuntimeValue(curVar)
    end
    return var
end

function CapsLanVM:DoFunction(functionName, args)
    if functionName == 'print' then
        if #args ~= 1 then
            LogTool.Info('print参数数量不对: ' .. #args)
            return
        end
        LogTool.Info(self:GetRuntimeValue(args[1]))
        return
    elseif functionName == 'abs' then
        if #args ~= 1 then
            LogTool.Info('abs参数数量不对: ' .. #args)
            return
        end
        local result = CapsValue:new()
        result.type = CapsValue.EValueType.number
        result.value = math.abs(self:GetRuntimeValue(args[1]):GetFloatValue())
        return result
    elseif functionName == 'random' then
        if #args ~= 0 then
            LogTool.Info('random参数数量不对: ' .. #args)
            return
        end
        local result = CapsValue:new()
        result.type = CapsValue.EValueType.number
        result.value = math.randomseed(os.time())
        return result
    elseif functionName == 'len' then
        if #args ~= 1 then
            LogTool.Info('len参数数量不对: ' .. #args)
            return
        end
        local result = CapsValue:new()
        result.type = CapsValue.EValueType.number
        result.value = self:GetRuntimeValue(args[1]):GetLength()
        return result
    elseif functionName == 'push' then
        if #args ~= 2 then
            LogTool.Info('push参数数量不对: ' .. #args)
            return
        end
        self:GetRuntimeValue(args[1]):AddItem(args[2])
        return
    elseif functionName == 'insert' then
        if #args ~= 3 then
            LogTool.Info('insert参数数量不对: ' .. #args)
            return
        end
        self:GetRuntimeValue(args[1]):Insert(self:GetRuntimeValue(args[2]):GetFloatValue() + 1, args[3])
        return
    elseif functionName == 'removeAt' then
        if #args ~= 2 then
            LogTool.Info('removeAt参数数量不对: ' .. #args)
            return
        end
        self:GetRuntimeValue(args[1]):RemoveAt(self:GetRuntimeValue(args[2]):GetFloatValue() + 1)
        return
    end
    LogTool.Info('不认识的function: ' .. functionName)
end

function CapsLanVM:DoCodeTree(words, tree)
    if tree.type == CodeTree.EType.codeBlock then
        local ret
        for i = 1, #tree.sons do
            ret = self:DoCodeTree(words, tree.sons[i])
            if ret ~= nil and ret.jumpType ~= CapsLanVM.ECodeJumpType.none then
                return ret
            end
        end
        return ret
    elseif tree.type == CodeTree.EType._if then
        if #tree.sons < 2 then
            LogTool.Info('语法错误3001,[' .. words[tree.wordStartIndex].lineIndex .. ',' .. words[tree.wordStartIndex].charIndex .. ']处的if语句不合法')
            return
        end
        local condition = self:DoCodeTree(words, tree.sons[1])
        if condition == nil then
            LogTool.Info('语法错误3002,[' .. words[tree.wordStartIndex].lineIndex .. ',' .. words[tree.wordStartIndex].charIndex .. ']处的if条件无法判断')
            return
        end
        if condition.jumpType ~= CapsLanVM.ECodeJumpType.none then
            LogTool.Info('语法错误3003,[' .. words[tree.wordStartIndex].lineIndex .. ',' .. words[tree.wordStartIndex].charIndex .. ']处的if条件不应该会返回jumpType')
            return
        end
        local conditionResult = condition.value:GetItem(1):GetBoolValue()
        if conditionResult == nil then
            LogTool.Info('语法错误3004,[' .. words[tree.wordStartIndex].lineIndex .. ',' .. words[tree.wordStartIndex].charIndex .. ']处的if条件无法判断')
            return
        end
        local actionReturn = conditionResult and self:DoCodeTree(words, tree.sons[2]) or (#tree.sons == 3 and self:DoCodeTree(words, tree.sons[3]) or nil)
        return actionReturn
    elseif tree.type == CodeTree.EType._loop then
        local isBreak = false
        --- prevent infinite loop
        local loopMaxLimit = 100000000
        while true do
            if loopMaxLimit == 0 then
                LogTool.Info('语法错误3011,[' .. words[tree.wordStartIndex].lineIndex .. ',' .. words[tree.wordStartIndex].charIndex .. ']处的loop次数过多，疑似死循环')
                return nil
            end
            loopMaxLimit = loopMaxLimit - 1
            for i = 1, #tree.sons do
                local ret = self:DoCodeTree(words, tree.sons[i])
                if ret ~= nil then
                    if ret.jumpType == CapsLanVM.ECodeJumpType._return then
                        return ret
                    elseif ret.jumpType == CapsLanVM.ECodeJumpType._break then
                        isBreak = true
                        break
                    elseif ret.jumpType == CapsLanVM.ECodeJumpType._continue then
                        break
                    end
                end
            end
            if isBreak then break end
        end
        return nil
    elseif tree.type == CodeTree.EType._continue then
        return { jumpType = CapsLanVM.ECodeJumpType._continue }
    elseif tree.type == CodeTree.EType._break then
        return { jumpType = CapsLanVM.ECodeJumpType._break }
    elseif tree.type == CodeTree.EType.phrase then
        if #tree.phraseWords == 0 then
            local returnVal = { jumpType = CapsLanVM.ECodeJumpType.none, value = CapsValue:new() }
            returnVal.value.type = CapsValue.EValueType._list
            returnVal.value.value = {}
            return returnVal
        end
        local values = {}
        local operators = {}
        local singleOperator = ''
        local preIsOperator = true
        local lineIndex = 1
        local charIndex = 1

        local insertValue = function(value)
            if singleOperator ~= '' then
                if singleOperator == '+' then
                    if value.type ~= CapsValue.EValueType.number then
                        LogTool.Info('语法错误3071,[' .. lineIndex .. ',' .. charIndex .. ']处的单目操作符' .. singleOperator .. '后面不是数字')
                        return nil
                    end
                    table.insert(values, value)
                elseif singleOperator == '-' then
                    if value.type ~= CapsValue.EValueType.number then
                        LogTool.Info('语法错误3072,[' .. lineIndex .. ',' .. charIndex .. ']处的单目操作符' .. singleOperator .. '后面不是数字')
                        return nil
                    end
                    local newVal = CapsValue:new()
                    newVal.type = CapsValue.EValueType.number
                    newVal.value = -self:GetRuntimeValue(value):GetFloatValue()
                    table.insert(values, newVal)
                elseif singleOperator == 'not' then
                    local newVal = CapsValue:new()
                    newVal.type = CapsValue.EValueType._bool
                    newVal.value = not self:GetRuntimeValue(value):GetBoolValue()
                    table.insert(values, newVal)
                else
                    LogTool.Info('语法错误3070,[' .. lineIndex .. ',' .. charIndex .. ']处的单目操作符' .. singleOperator .. '不合法')
                    return nil
                end
                singleOperator = ''
            elseif preIsOperator == false then
                LogTool.Info('语法错误3071,[' .. lineIndex .. ',' .. charIndex .. ']处的连续两个值中间没有操作符')
                return nil
            else
                table.insert(values, value)
            end
            preIsOperator = false
        end
        local insertOperator = function(strOperator)
            if singleOperator ~= '' then
                LogTool.Info('语法错误3100,[' .. lineIndex .. ',' .. charIndex .. ']处有单目运算法符后面不应该带有操作符')
                return
            end
            if preIsOperator then
                if strOperator == '-' then
                    singleOperator = '-';
                    return
                end
                LogTool.Info('语法错误3101,[' .. lineIndex .. ',' .. charIndex .. ']处不应该连续有两个操作符')
                return
            end
            local priority = self:GetOperatorPriority(strOperator)
            while #operators > 0 and self:GetOperatorPriority(operators[#operators]) > priority do
                --- check value valid
                if #values < 2 then
                    LogTool.Info('运行时错误110005,[' .. lineIndex .. ',' .. charIndex .. ']前面的逻辑运算数值不够了')
                    return
                end
                local v1 = table.remove(values)
                if v1 == nil then
                    LogTool.Info('运行时错误110003,[' .. lineIndex .. ',' .. charIndex .. ']存在无效v1')
                    return
                end
                local v0 = table.remove(values)
                if v0 == nil then
                    LogTool.Info('运行时错误110004,[' .. lineIndex .. ',' .. charIndex .. ']存在无效v0')
                    return
                end
                --- check operator valid
                local sOp = table.remove(operators)
                preIsOperator = true
                if sOp == '=' then
                    if v0.type ~= CapsValue.EValueType._var then
                        LogTool.Info('运行时错误110001,[' .. lineIndex .. ',' .. charIndex .. ']赋值语句存在无效左值')
                        return
                    end
                    self.vars[v0:GetVarName()] = v1
                    table.insert(values, v1)
                elseif sOp == '+=' then
                    local newValue = CapsValue:new()
                    if v0.type ~= CapsValue.EValueType._var then
                        LogTool.Info('运行时错误110009, [' .. lineIndex .. ',' .. charIndex .. ']赋值语句存在无效左值')
                        return
                    end
                    local varName = v0:GetVarName()
                    v0 = self:GetRuntimeValue(v0)
                    if v1.type == CapsValue.EValueType._var then
                        if self.vars[v0:GetVarName()] == nil then
                            LogTool.Info('运行时错误110010,[' .. lineIndex .. ',' .. charIndex .. ']赋值语句使用了未声明的变量: ' .. v0:GetVarName())
                            return
                        end
                        v1 = self.vars[v1:GetVarName()]
                    end

                    if v1.type ~= CapsValue.EValueType._var and v1.type ~= CapsValue.EValueType.number and v1.type ~= CapsValue.EValueType.str then
                        LogTool.Info('运行时错误110011, [' .. lineIndex .. ',' .. charIndex .. ']错误的右值类型')
                        return
                    end

                    if v0.type == CapsValue.EValueType.str or v1.type == CapsValue.EValueType.str then
                        newValue.type = CapsValue.EValueType.str
                        newValue.value = v0:GetStringValue() .. v1:GetStringValue()
                    else
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() + v1:GetFloatValue()
                    end
                    self.vars[varName] = newValue
                elseif sOp == '-=' or sOp == '*=' or sOp == '/=' or sOp == '%=' then
                    local newValue = CapsValue:new()
                    if v0.type ~= CapsValue.EValueType._var then
                        LogTool.Info('运行时错误110012, [' .. lineIndex .. ',' .. charIndex .. ']赋值语句存在无效左值')
                        return
                    end
                    local varName = v0:GetVarName()
                    v0 = self:GetRuntimeValue(v0)
                    if v1.type == CapsValue.EValueType._var then
                        if self.vars[v0:GetVarName()] == nil then
                            LogTool.Info('运行时错误110013,[' .. lineIndex .. ',' .. charIndex .. ']赋值语句使用了未声明的变量: ' .. v0:GetVarName())
                            return
                        end
                        v1 = self.vars[v1:GetVarName()]
                    end

                    if v1.type ~= CapsValue.EValueType._var and v1.type ~= CapsValue.EValueType.number then
                        LogTool.Info('运行时错误110014, [' .. lineIndex .. ',' .. charIndex .. ']错误的右值类型')
                        return
                    end

                    if sOp == '-=' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() - v1:GetFloatValue()
                    elseif sOp == '*=' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() * v1:GetFloatValue()
                    elseif sOp == '/=' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() / v1:GetFloatValue()
                    elseif sOp == '%=' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() % v1:GetFloatValue()
                    end
                    self.vars[varName] = newValue
                else
                    if v0.type == CapsValue.EValueType._var then
                        if self.vars[v0:GetVarName()] == nil then
                            LogTool.Info('运行时错误110006,[' .. lineIndex .. ',' .. charIndex .. ']赋值语句使用了未声明的变量: ' .. v0:GetVarName())
                            return
                        end
                        v0 = self.vars[v0:GetVarName()]
                    end
                    if v1.type == CapsValue.EValueType._var then
                        if self.vars[v1:GetVarName()] == nil then
                            LogTool.Info('运行时错误110007,[' .. lineIndex .. ',' .. charIndex .. ']赋值语句使用了未声明的变量: ' .. v1:GetVarName())
                            return
                        end
                        v1 = self.vars[v1:GetVarName()]
                    end
                    local newValue = CapsValue:new()
                    if sOp == 'and' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = v0:GetBoolValue() and v1:GetBoolValue()
                    elseif sOp == 'or' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = v0:GetBoolValue() or v1:GetBoolValue()
                    elseif sOp == '==' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = v0:Equal(v1)
                    elseif sOp == '!=' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = not v0:Equal(v1)
                    elseif sOp == '<' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = not v0:Equal(v1) and not v0:BiggerThan(v1)
                    elseif sOp == '<=' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = not v0:BiggerThan(v1)
                    elseif sOp == '>' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = not v0:Equal(v1) and v0:BiggerThan(v1)
                    elseif sOp == '>=' then
                        newValue.type = CapsValue.EValueType._bool
                        newValue.value = v0:BiggerThan(v1) or v0:Equal(v1)
                    elseif sOp == '+' then
                        if v0.type == CapsValue.EValueType.str or v1.type == CapsValue.EValueType.str then
                            newValue.type = CapsValue.EValueType.str
                            newValue.value = v0:GetStringValue() .. v1:GetStringValue()
                        else
                            newValue.type = CapsValue.EValueType.number
                            newValue.value = v0:GetFloatValue() + v1:GetFloatValue()
                        end
                    elseif sOp == '-' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() - v1:GetFloatValue()
                    elseif sOp == '*' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() * v1:GetFloatValue()
                    elseif sOp == '/' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() / v1:GetFloatValue()
                    elseif sOp == '%' then
                        newValue.type = CapsValue.EValueType.number
                        newValue.value = v0:GetFloatValue() % v1:GetFloatValue()
                    else
                        LogTool.Info('语法错误3105,[' .. lineIndex .. ',' .. charIndex .. ']语句使用了不支持的操作符' .. sOp)
                        return
                    end
                    table.insert(values, newValue)
                end
            end
            table.insert(operators, strOperator)
            preIsOperator = true
        end

        --- multi return,only happen when use ',' split multi parameters as function
        local args = {}

        local onRunEnd = function(op)
            insertOperator(op)
            if #operators ~= 1 or singleOperator ~= '' then
                LogTool.Info('语法错误3117,[' .. lineIndex .. ']结尾有未运算的操作符:' .. singleOperator)
                return
            end
            if #values == 1 then
                if values[1] ~= nil then
                    local newVar = CapsValue:new()
                    newVar.type = values[1].type
                    newVar.value = values[1].value
                    table.insert(args, newVar)
                end
            elseif #values > 1 then
                LogTool.Info('语法错误3118,[' .. lineIndex .. ']还有数值没有计算完成')
                return
            else
                if op == ',' then
                    LogTool.Info('语法错误3119,[' .. lineIndex .. ']逗号前不能为空')
                    return
                end
            end
            singleOperator = ''
            preIsOperator = true
            values = {}
            operators = {}
        end
        for i = 1, #tree.phraseWords do
            local pw = tree.phraseWords[i]
            if pw.isCodeTree then
                local startOperator = words[pw.codeTree.wordStartIndex].strValue
                local ret = self:DoCodeTree(words, pw.codeTree)
                if ret == nil then
                    LogTool.Info('语法错误3021,[' .. lineIndex .. ',' .. charIndex .. ']处的没有正确的计算值')
                    return
                end
                if ret.jumpType ~= CapsLanVM.ECodeJumpType.none then
                    LogTool.Info('语法错误3021,[' .. lineIndex .. ',' .. charIndex .. ']处的不应该有跳出符')
                    return
                end
                if ret.value.type ~= CapsValue.EValueType._list then
                    LogTool.Info('语法错误3023,[' .. lineIndex .. ',' .. charIndex .. ']处的计算值无效')
                    return
                end
                local retArgs = ret.value.value
                if startOperator == '(' then
                    if preIsOperator then
                        if #retArgs ~= 1 then
                            LogTool.Info('语法错误3024,[' .. lineIndex .. ',' .. charIndex .. ']处的计算值数量不对: ' .. #retArgs)
                            return
                        end
                        insertValue(retArgs[1])
                    else
                        local v = table.remove(values)
                        preIsOperator = true
                        if v.type ~= CapsValue.EValueType._var then
                            LogTool.Info('语法错误3024,[' .. lineIndex .. ',' .. charIndex .. ']处不是函数')
                            return
                        end
                        local functionName = v:GetVarName()
                        if functionName == 'return' then
                            if #retArgs ~= 1 then
                                LogTool.Info('语法错误3026,[' .. lineIndex .. ',' .. charIndex .. ']处参数数量不对: ' .. #retArgs)
                                return
                            end
                            return { value = self:GetRuntimeValue(retArgs[1]), type = CapsLanVM.ECodeJumpType._return }
                        else
                            local _v = self:DoFunction(functionName, retArgs)
                            insertValue(_v)
                            --if _v == nil then
                            --    LogTool.Info('语法错误3027,[' .. lineIndex .. ',' .. charIndex .. ']处函数调用出错')
                            --    return
                            --else
                            --
                            --end
                        end
                    end
                elseif startOperator == '[' then
                    if preIsOperator then
                        insertValue(ret.value)
                    else
                        local v = table.remove(values)
                        preIsOperator = true
                        if #retArgs ~= 1 then
                            LogTool.Info('语法错误3029,[' .. lineIndex .. ',' .. charIndex .. ']处访问数组只能用一个int,Count: ' .. #retArgs)
                            return
                        end
                        insertValue(self:GetRuntimeValue(v):GetItem(self:GetRuntimeValue(retArgs[1]):GetFloatValue() + 1))
                    end
                else
                    if #retArgs ~= 1 then
                        LogTool.Info('语法错误3032,[' .. lineIndex .. ',' .. charIndex .. ']处计算值无效')
                        return
                    end
                    insertValue(retArgs[1])
                end

            else
                local w = words[pw.wordIndex]
                lineIndex = words[pw.wordIndex].lineIndex
                charIndex = words[pw.wordIndex].charIndex
                if w.type == Word.EType._operator then
                    local operatorStr = w.strValue
                    local jumpToNextLoop = false
                    if w.strValue == '+' or w.strValue == '-' or w.strValue == 'not' then
                        if #values == 0 and #operators == 0 then
                            if singleOperator ~= '' then
                                LogTool.Info('语法错误3050,[' .. lineIndex .. ',' .. charIndex .. ']处有重复的单目运算符')
                                return
                            end
                            singleOperator = operatorStr
                            jumpToNextLoop = true
                            -- goto continue
                        end
                    end
                    if not jumpToNextLoop then
                        if w.strValue == ',' then
                            onRunEnd(',')
                        else
                            insertOperator(operatorStr)
                        end
                    end
                elseif w.type == Word.EType.number then
                    local newVar = CapsValue:new()
                    newVar.type = CapsValue.EValueType.number
                    newVar.value = tonumber(w.strValue)
                    insertValue(newVar)
                elseif w.type == Word.EType.var then
                    local newVar = CapsValue:new()
                    if w.strValue == 'true' or w.strValue == 'false' then
                        newVar.type = CapsValue.EValueType._bool
                        newVar.value = w.strValue == 'true'
                    else
                        newVar.type = CapsValue.EValueType._var
                        newVar.value = w.strValue
                    end
                    insertValue(newVar)
                elseif w.type == Word.EType.str then
                    local newVar = CapsValue:new()
                    newVar.type = CapsValue.EValueType.str
                    newVar.value = w.strValue
                    insertValue(newVar)
                else
                    LogTool.Info('语法错误3051,[' .. lineIndex .. ',' .. charIndex .. ']处有不合法的类型: ' .. w)
                    return
                end
                -- ::continue::
            end
        end
        onRunEnd('__lineEnd__')
        local returnVal = CapsValue:new()
        returnVal.type = CapsValue.EValueType._list
        returnVal.value = args
        return { jumpType = CapsLanVM.ECodeJumpType.none, value = returnVal }
    end
    return
end

function CapsLanVM:DoScript(script)
    local lines = Tools.Split(script, '\n')
    --
    local words = {}
    local scriptStart = Word:new()
    scriptStart.lineIndex = -1
    scriptStart.charIndex = -1
    scriptStart.type = Word.EType.scriptStart
    table.insert(words, scriptStart);
    for lindeIndex = 1, #lines do
        local line = lines[lindeIndex]
        local _words = Word.ParseWord(lindeIndex, line)
        for i = 1, #_words do
            table.insert(words, _words[i])
        end
    end

    local scriptEnd = Word:new()
    scriptEnd.lineIndex = -1
    scriptEnd.charIndex = -1
    scriptEnd.type = Word.EType.scriptEnd
    table.insert(words, scriptEnd)
    
    local codeTree = CodeTree:Build(words, 1, nil)
    -- codeTree:PrintTree(0, words)
    local ret = self:DoCodeTree(words, codeTree)
    return ret
end

function CapsLanVM:DoScriptWithBoolReturn(script)
    local ret = self:DoScript(script)
    if ret == nil or ret.value == nil or ret.value.value == nil or ret.value.value[1] == nil then
        return false
    end
    return ret.value.value[1]:GetBoolValue()
end

function CapsLanVM:GetAllVarValue()
    local result = ''
    for key, value in pairs(self.vars) do
        result = result .. key .. '=' .. value.value .. '\n'
    end
    return result;
end

function CapsLanVM:Clear()
    self.vars = {}
end

return CapsLanVM
