CapsValue = {}
CapsValue.EValueType = Basic.Enum({ 'unknown', 'number', 'str', '_bool', '_var', '_list' })

function CapsValue:new(o)
    local o = o or {}
    setmetatable(o, self)
    self.lineIndex = lineIndex
    self.__index = self
    self.__tostring = function(self)
        local str = ''
        if self.type == CapsValue.EValueType.number then
            str = '数值类型: ' .. tonumber(self.value)
        elseif self.type == CapsValue.EValueType.str then
            str = '字符串: ' .. tostring(self.value)
        elseif self.type == CapsValue.EValueType._bool then
            local bool = "false"
            if self.value == "true" then
                bool = "true"
            end
            str = '布尔值: ' .. bool
        elseif self.type == CapsValue.EValueType._list then
            str = '数组类型，长度' .. #self.value .. ':['
            for i = 1, #self.value do
                if i > 1 then
                    str = str .. ','
                end
                str = str .. tostring(self.value[i])
            end
            str = str .. ']'
        elseif self.type == CapsValue.EValueType._var then
            str = '变量，值为(' .. tostring(self.value) .. ')'
        else
            str = '未知变量'
        end
        return str
    end
    self.type = CapsValue.EValueType.unknown
    return o
end

local toBool = function(bool)
    if bool == 'true' or bool then return true end
    return false
end

function CapsValue:GetBoolValue()
    if self.type == CapsValue.EValueType.number then
        return tonumber(self.value) ~= 0
    end
    if self.type == CapsValue.EValueType._bool then
        return toBool(self.value)
    end
    if self.type == CapsValue.EValueType.str then
        return str ~= nil and str ~= ''
    end
    if self.type == CapsValue.EValueType.unknown then
        return false
    end
    LogTool.Info("语法错误200003, 无法解析成bool类型:" .. self.__tostring(self))
    return false
end

function CapsValue:GetStringValue()
    if self.type == CapsValue.EValueType.number then
        return tostring(tonumber(self.value))
    end
    if self.type == CapsValue.EValueType._bool then
        return tostring(toBool(self.value))
    end
    if self.type == CapsValue.EValueType.str then
        return tostring(self.value)
    end
    if self.type == CapsValue.EValueType.unknown then
        return ''
    end
    LogTool.Info("语法错误200004, 无法解析成string类型:" .. self.__tostring(self))
    return ''
end

function CapsValue:GetFloatValue()
    if self.type == CapsValue.EValueType.number then
        return tonumber(self.value)
    end
    if self.type == CapsValue.EValueType.unknown then
        return 0
    end
    LogTool.Info("语法错误200005, 无法解析成float类型:" .. self.__tostring(self))
    return 0
end

function CapsValue:GetVarName()
    if self.type == CapsValue.EValueType._var then
        return tostring(self.value)
    end
    LogTool.Info("语法错误200006, 不是变量: " .. self.__tostring(self))
    return ''
end

--- array
function CapsValue:GetItem(index)
    if self.type ~= CapsValue.EValueType._list then
        LogTool.Info("语法错误200010, GetItem不是数组: " .. self.__tostring(self))
        return nil
    end
    if index < 1 or index > #self.value then
        LogTool.Info("语法错误200011, GetItem中出现了错误的index: " .. self.__tostring(self));
        return nil
    end
    return self.value[index]
end

function CapsValue:GetLength()
    if self.type ~= CapsValue.EValueType._list then
        LogTool.Info("语法错误200013, GetLength不是数组: " .. self.__tostring(self))
        return 0
    end
    return #self.value
end

function CapsValue:AddItem(item)
    if self.type ~= CapsValue.EValueType._list then
        LogTool.Info("语法错误200014, AddItem不是数组:" .. self.__tostring(self))
        return
    end
    table.insert(self.value, item)
end

function CapsValue:Insert(index, item)
    if self.type ~= CapsValue.EValueType._list then
        LogTool.Info("语法错误200018, Insert不是数组:" .. self.__tostring(self))
        return
    end
    table.insert(self.value, index, item)
end

function CapsValue:RemoveAt(index)
    if self.type ~= CapsValue.EValueType._list then
        LogTool.Info("语法错误200015, RemoveAt不是数组:" .. self.__tostring(self))
        return
    end
    if index < 1 or index > #self.value then
        LogTool.Info("语法错误200016, RemoveAt中出现了错误的index:" .. self.__tostring(self));
        return
    end
    table.remove(self.value, index)
end

function CapsValue:Equal(var)
    if var == nil then return false end
    if self.type ~= var.type then return false end
    if self.type == CapsValue.EValueType.number then
        return tonumber(self.value) == tonumber(var.value)
    elseif self.type == CapsValue.EValueType._bool then
        return toBool(self.value) == toBool(var.value)
    elseif self.type == CapsValue.EValueType.str then
        return tostring(self.value) == tostring(var.value)
    end
    return false
end

function CapsValue:BiggerThan(var)
    if var == nil then
        LogTool.Info('运行错误10000, null不能比较大小')
        return false
    end
    if self.type ~= CapsValue.EValueType.number or var.type ~= CapsValue.EValueType.number then
        LogTool.Info('运行错误10001, 两个非数字之间不能比较大小')
        return false
    end
    return tonumber(self.value) > tonumber(var.value)
end

return CapsValue
