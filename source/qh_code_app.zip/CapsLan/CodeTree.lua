CodeTree = {}
CodeTree.EType = Basic.Enum({ 'codeBlock', 'phrase', 'bracket', '_if', '_loop', '_break', '_continue' })

function CodeTree:new(o)
    local o = o or {}
    setmetatable(o, self)
    self.__index = self
    self.type = CodeTree.EType.codeBlock
    self.wordStartIndex = 1
    self.wordEndIndex = 1
    self.father = nil
    return o
end

function CodeTree:PrintTree(deep, words)
    --print(#self.sons)
    local str = ''
    for i = 0, deep do
        if i == 0 then
            str = str .. '|'
        end
        str = str .. '--'
    end
    str = str .. '[' .. self.wordStartIndex .. '-' .. self.wordEndIndex .. ']:\"'
    local lastStr = ''
    for i = self.wordStartIndex, self.wordEndIndex do
        if words[i].strValue ~= '' then
            if lastStr ~= '' then str = str .. ',' end
            str = str .. words[i].strValue
            lastStr = words[i].strValue
        end
    end
    str = str .. '\"'
    LogTool.Info(str)
    for i = 1, #self.sons do
        self.sons[i]:PrintTree(deep + 1, words)
    end
end

function CodeTree.GetNextIndex(words, startIndex)
    while startIndex <= #words do
        if words[startIndex].type == Word.EType.lineEnd then
            startIndex = startIndex + 1
        else
            return startIndex
        end
    end
    LogTool.Info('语法错误2005, 无法获取下一个字符')
    return -1
end

function CodeTree:BuildAsPhrase(words, startIndex)
    local tree = CodeTree:new()
    tree.wordStartIndex = startIndex
    tree.phraseWords = {}
    tree.sons = {}
    local endIndex = startIndex
    if words[endIndex].type == Word.EType._operator and words[endIndex].strValue == ',' then
        tree.type = CodeTree.EType.phrase
        tree.wordEndIndex = endIndex
        return tree
    end

    while true do
        if words[endIndex].type == Word.EType.lineEnd or words[endIndex].type == Word.EType.scriptEnd then
            break
        end
        if words[endIndex].type == Word.EType._operator and (words[endIndex].strValue == ')' or words[endIndex].strValue == ']' or words[endIndex].strValue == ',' or words[endIndex].strValue == '{') then
            break
        end
        if words[endIndex].type == Word.EType.reservedWord then
            LogTool.Info('语法错误2020, 在[' .. words[endIndex].lineIndex .. words[endIndex].charIndex .. ']处的出现不合法保留字:' .. words[endIndex].strValue)
            break
        end
        if words[endIndex].type == Word.EType._operator and (words[endIndex].strValue == "(" or words[endIndex].strValue == "[") then
            local rightBrackets = words[endIndex].strValue == '(' and ')' or ']'
            local treeBrackets = CodeTree:new()
            treeBrackets.phraseWords = {}
            treeBrackets.wordStartIndex = endIndex
            treeBrackets.father = tree
            endIndex = endIndex + 1
            while true do
                if words[endIndex].type == Word.EType._operator and words[endIndex].strValue == rightBrackets then
                    break
                end
                if words[endIndex].type == Word.EType.lineEnd or words[endIndex].type == Word.EType.scriptEnd then
                    LogTool.Info('语法错误2021，在[' .. words[endIndex].lineIndex .. words[endIndex].charIndex .. ']处的括号不匹配')
                    break
                end
                local w0 = { isCodeTree = true, wordIndex = -1 }
                w0.codeTree = CodeTree:BuildAsPhrase(words, endIndex)
                table.insert(treeBrackets.phraseWords, w0)
                endIndex = CodeTree.GetNextIndex(words, w0.codeTree.wordEndIndex + 1)
                if words[endIndex].type == Word.EType._operator and words[endIndex].strValue == ',' then
                    local w1 = { isCodeTree = false, wordIndex = endIndex }
                    table.insert(treeBrackets.phraseWords, w1)
                    endIndex = endIndex + 1
                end
            end
            treeBrackets.wordEndIndex = endIndex
            treeBrackets.type = CodeTree.EType.phrase
            local w2 = { isCodeTree = true, wordIndex = -1 }
            w2.codeTree = treeBrackets
            table.insert(tree.phraseWords, w2)
        else
            local w1 = { isCodeTree = false, wordIndex = endIndex }
            table.insert(tree.phraseWords, w1)
        end
        endIndex = endIndex + 1
    end
    tree.type = CodeTree.EType.phrase
    tree.wordEndIndex = endIndex - 1
    return tree
end

function CodeTree:Build(words, startIndex, father)
    startIndex = CodeTree.GetNextIndex(words, startIndex)
    local tree = CodeTree:new()
    tree.father = father
    tree.wordStartIndex = startIndex
    tree.sons = {}
    tree.phraseWords = {}

    local wordStart = words[startIndex]
    if wordStart.type == Word.EType.scriptStart then
        local endIndex = startIndex + 1
        while true do
            if words[endIndex].type == Word.EType.scriptEnd then
                break
            end
            local son = CodeTree:Build(words, endIndex, tree)
            table.insert(tree.sons, son)
            endIndex = CodeTree.GetNextIndex(words, son.wordEndIndex + 1)
        end
        tree.wordEndIndex = endIndex
        tree.type = CodeTree.EType.codeBlock
        return tree
    elseif wordStart.type == Word.EType._operator then
        if wordStart.strValue == '{' then
            local endIndex = startIndex + 1
            while true do
                if words[endIndex].type == Word.EType._operator and words[endIndex].strValue == '}' then
                    break
                end
                local son = CodeTree:Build(words, endIndex, tree)
                table.insert(tree.sons, son)
                endIndex = CodeTree.GetNextIndex(words, son.wordEndIndex + 1)
            end
            tree.wordEndIndex = endIndex
            tree.type = CodeTree.EType.codeBlock
            return tree
        else
            return CodeTree:BuildAsPhrase(words, startIndex)
        end
    elseif wordStart.type == Word.EType.reservedWord then
        if wordStart.strValue == 'if' then
            if startIndex + 1 > #words then
                LogTool.Info('语法错误2003, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处的if有误')
                return nil
            end
            if words[startIndex + 1].type ~= Word.EType._operator or words[startIndex + 1].strValue ~= "(" then
                LogTool.Info('语法错误2004, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处的if有误, 后面没有(')
                return nil
            end
            local codeCondition = CodeTree:Build(words, startIndex + 1, tree)
            table.insert(tree.sons, codeCondition)
            local codeIf = CodeTree:Build(words, codeCondition.wordEndIndex + 1, tree)
            table.insert(tree.sons, codeIf)
            local nextIndex = codeIf.wordEndIndex + 1
            while nextIndex <= #words do
                if words[nextIndex].type == Word.EType.lineEnd then
                    nextIndex = nextIndex + 1
                else
                    break
                end
            end
            if nextIndex <= #words then
                if words[nextIndex].type == Word.EType.reservedWord and words[nextIndex].strValue == 'else' then
                    local codeElse = CodeTree:Build(words, nextIndex + 1, tree)
                    table.insert(tree.sons, codeElse)
                end
            end
            tree.wordEndIndex = tree.sons[#tree.sons].wordEndIndex
            tree.type = CodeTree.EType._if
            return tree
        elseif wordStart.strValue == 'loop' then
            tree.type = CodeTree.EType._loop
            table.insert(tree.sons, CodeTree:Build(words, startIndex + 1, tree))
            tree.wordEndIndex = tree.sons[1].wordEndIndex
            return tree
        elseif wordStart.strValue == 'continue' then
            local f = tree.father
            while f ~= nil do
                if f.type == CodeTree.EType._loop then
                    break
                end
                f = f.father
            end
            if f == nil then
                LogTool.Info('语法错误2008, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处' .. wordStart.strValue .. '未被包含在loop中')
                return nil
            end
            tree.type = CodeTree.EType._continue
            tree.wordEndIndex = startIndex
            return tree
        elseif wordStart.strValue == 'break' then
            local f = tree.father
            while f ~= nil do
                if f.type == CodeTree.EType._loop then
                    break
                end
                f = f.father
            end
            if f == nil then
                LogTool.Info('语法错误2009, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处' .. wordStart.strValue .. '未被包含在loop中')
                return nil
            end
            tree.type = CodeTree.EType._break
            tree.wordEndIndex = startIndex
            return tree
        else
            LogTool.Info('语法错误2007, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处存在不合法的保留字：' .. wordStart.strValue)
            return nil
        end
    elseif wordStart.type == Word.EType.var or wordStart.type == Word.EType.str or wordStart.type == Word.EType.number then
        return CodeTree:BuildAsPhrase(words, startIndex)
    end
    LogTool.Info('语法错误2005, 在[' .. wordStart.lineIndex .. ',' .. wordStart.charIndex .. ']处无法解析')
    return nil
end

return CodeTree
