Word = {}
Word.EType = Basic.Enum({ 'unknown', 'number', 'str', 'var', 'reservedWord', '_operator', 'lineEnd', 'scriptStart', 'scriptEnd' })
local ECharType = Basic.Enum({ 'unknown', 'empty', 'letter', 'number', '_operator' })
local EWordState = Basic.Enum({ 'none', 'var', '_operator', 'number', 'str' })

function Word:new(o)
    local o = o or {}
    setmetatable(o, self)
    self.__index = self
    self.__tostring = function(self)
        local str = '[' .. self.lineIndex .. ', ' .. self.charIndex .. ']'
        local tab = {
            [Word.EType.var] = "变量",
            [Word.EType._operator] = "操作符",
            [Word.EType.lineEnd] = "句末结尾符",
            [Word.EType.scriptStart] = "代码开始符",
            [Word.EType.scriptEnd] = "代码结束符",
            [Word.EType.number] = "数字",
            [Word.EType.str] = "字符串",
            [Word.EType.reservedWord] = "保留字",
        }
        if tab[self.type] then
            str = str .. tab[self.type]
        else
            str = str .. '未知类型'
        end
        str = str .. ': ' .. self.strValue
        return str
    end
    self.lineIndex = 0
    self.charIndex = 0
    self.type = Word.EType.unknown
    self.strValue = ''
    return o
end

local GetCharType = function(c)
    if c == ' ' or c == '\t' or c == '\r' or c == '\n' then return ECharType.empty end
    if (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z') or c == '_' then return ECharType.letter end
    if c >= '0' and c <= '9' then return ECharType.number end
    if c == '+' or c == '-' or c == '*' or c == '/' or c == '>' or c == '<' or c == '=' or c == '(' or c == ')' or c == '{' or c == '}' or c == '[' or c == ']' or c == ';' or c == '\"' or c == '.' or c == ',' or c == '!' or c == '%' then return ECharType._operator end
    return ECharType.unknown
end

function Word.ParseWord(lineIndex, lineCode)
    local words = {}
    local state = EWordState.none
    local nowChars = ''
    local charIndex = 0
    for i = 1, #lineCode do
        local jumpToNextLoop = false -- 做continue用，如果=true，则不进行后续逻辑
        local c = string.sub(lineCode, i, i)
        --- check str
        if state == EWordState.str then
            if c == '\"' then
                local word = Word:new()
                word.lineIndex = lineIndex
                word.charIndex = charIndex
                word.type = Word.EType.str
                word.strValue = nowChars
                table.insert(words, word)
                state = EWordState.none
            else
                nowChars = nowChars .. c
            end
            -- goto continue
            jumpToNextLoop = true
        end

        if not jumpToNextLoop then
            --- when not in none state, find the whole word
            local wordContinue = false
            local charType = GetCharType(c)
            if charType == ECharType.unknown then
                LogTool.Info('语法错误1001，第' .. lineIndex .. '行，第' .. i .. '个字符为未知字符: ' .. c)
                return words
            elseif charType == ECharType.letter then
                wordContinue = state == EWordState.var
            elseif charType == ECharType._operator then
                wordContinue = false
                if state == EWordState._operator then
                    local op = nowChars .. c
                    if op == '>=' or op == '<=' or op == '==' or op == '!=' or op == '+=' or op == '-=' or op == '*=' or op == '/=' or op == '%=' then
                        local word = Word:new()
                        word.lineIndex = lineIndex
                        word.charIndex = charIndex
                        word.type = Word.EType._operator
                        word.strValue = op
                        table.insert(words, word)
                        state = EWordState.none
                        nowChars = ''
                        -- goto continue
                        jumpToNextLoop = true
                    end
                end
                if not jumpToNextLoop then
                    if c == '.' then
                        if state ~= EWordState.number then
                            LogTool.Info('语法错误1011，第' .. lineIndex .. '行，第' .. i .. '个的.意义不明 ')
                            return words
                        else
                            if string.find(nowChars, ".") then
                                LogTool.Info('语法错误1010，第' .. lineIndex .. '行，第' .. i .. '个小数点过多了')
                                return words
                            end
                            wordContinue = true
                        end
                    end
                end
            elseif charType == ECharType.number then
                wordContinue = state == EWordState.number
            end
            if not jumpToNextLoop then
                if wordContinue then
                    nowChars = nowChars .. c
                else
                    local word = Word:new()
                    word.lineIndex = lineIndex
                    word.charIndex = charIndex
                    word.strValue = nowChars
                    if state == EWordState.var then
                        local type = Word.EType.var
                        if nowChars == "and" or nowChars == "or" or nowChars == "not" then
                            type = Word.EType._operator
                        elseif nowChars == "if" or nowChars == "else" or nowChars == "loop" or nowChars == "break" or nowChars == "continue" then
                            type = Word.EType.reservedWord
                        end
                        word.type = type
                        table.insert(words, word)
                    elseif state == EWordState._operator then
                        word.type = Word.EType._operator
                        table.insert(words, word)
                    elseif state == EWordState.number then
                        word.type = Word.EType.number
                        table.insert(words, word)
                    end
        
                    --- reset and check state
                    state = EWordState.none
                    charIndex = i
                    nowChars = c
                    if charType == ECharType.letter then
                        state = EWordState.var
                    elseif charType == ECharType._operator then
                        if c == ';' then
                            word.type = Word.EType.lineEnd
                            word.strValue = c
                            table.insert(words, word)
                        elseif c == '\"' then
                            state = EWordState.str
                            nowChars = ''
                        else
                            state = EWordState._operator
                        end
                    elseif charType == ECharType.number then
                        state = EWordState.number
                    end
                end
                
            end
        end
        -- ::continue::
    end

    --- check if has single character at end of word
    local word = Word:new()
    word.lineIndex = lineIndex
    word.charIndex = charIndex
    word.strValue = nowChars
    if state == EWordState.var then
        word.type = Word.EType.var
        if nowChars == "and" or nowChars == "or" or nowChars == "not" then
            word.type = Word.EType._operator
        elseif nowChars == "if" or nowChars == "else" or nowChars == "loop" or nowChars == "break" or nowChars == "continue" then
            word.type = Word.EType.reservedWord
        end
        table.insert(words, word)
        charIndex = charIndex + 1
    end
    if state == EWordState._operator then
        word.type = Word.EType._operator
        table.insert(words, word)
        charIndex = charIndex + 1
    end
    if state == EWordState.number then
        word.type = Word.EType.number
        table.insert(words, word)
        charIndex = charIndex + 1
    end
    --- add end symbol
    local endWord = Word:new()
    endWord.lineIndex = lineIndex
    endWord.charIndex = charIndex
    endWord.strValue = ''
    endWord.type = Word.EType.lineEnd
    table.insert(words, endWord)
    return words
end

return Word
