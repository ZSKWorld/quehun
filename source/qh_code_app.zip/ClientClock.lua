--- @class ClientClock
--- 客户端时钟，以 UTC+8 时区为标准计时，在跨天(5:00am)或其他自定义时间报时，通知订阅对象，订阅对象需要实现 OnClockReport(notifyType:EClockNotifyType) 方法，
--- 其中 EClockNotifyType 类型的参数表明当前报时通知的类型。
---
--- 可选：订阅对象可额外实现 OnFilterClockReport(notifyType:EClockNotifyType):boolean 方法，来筛选需要的通知，不实现该方法的话则默认只接受跨天通知。
--- >！！！注意！！！ OnClockReport 内请勿无条件执行与服务端交互的逻辑，有条件判断也请错开执行时间，否则同一时间大量请求会导致服务端 qps 爆炸
ClientClock = {}

--- @class ClientClock.Alarm
--- @field time number 闹钟触发时间
--- @field callback function 闹钟触发回调
--- @field context any 回调上下文

--- @type HashSet
ClientClock.listeners = HashSet:New()
--- @type ClientClock.Alarm[]
ClientClock.alarmQueue = {}
ClientClock.realTime = 0
ClientClock.lastUTCDateMap = {}   -- 防止重复触发
ClientClock.tickInterval = 1    -- 每秒 Tick
ClientClock.timer = nil


local UTC8TimeDiff = 8 * 3600
local timePointMap = {}
timePointMap[EClockNotifyType.DayChange] = { 5, 0, 0 }

--- 订阅报时通知
--- @param listener table 订阅者对象
function ClientClock.AddListener(listener)
    if (not listener or not listener.OnClockReport) then
        LogTool.Warning("ClientClock", "Add clock listener error, listener is nil or OnClockReport func is nil!")
        return
    end
    ClientClock.listeners:Add(listener)
end

--- 移除订阅对象
--- @param listener table 订阅者对象
function ClientClock.RemoveListener(listener)
    ClientClock.listeners:Remove(listener)
end

--- @private
--- 通知所有订阅对象
--- @param notifyType EClockNotifyType
function ClientClock.Notify(notifyType)
    for _, l in ipairs(ClientClock.listeners:GetAll()) do
        if ((not l.OnFilterClockReport and notifyType == EClockNotifyType.DayChange) or l:OnFilterClockReport(notifyType)) then
            l:OnClockReport(notifyType)
        end
    end
end

--- 添加闹钟
--- @param time number Unix时间戳 或 相对当前的秒数
--- @param callback function 回调函数
--- @param isRelative boolean 是否是相对时间
--- @param context table? (可选) 回调上下文
--- @return ClientClock.Alarm
function ClientClock.AddAlarm(time, callback, isRelative, context)
    local triggerTime = isRelative and (ClientClock.realTime + time) or time

    local alarm = {
        time = triggerTime,
        callback = callback,
        context = context
    }
    -- 使用二分查找插入保证升序
    local index = ClientClock.GetInsertIndex(triggerTime)
    table.insert(ClientClock.alarmQueue, index, alarm)

    return alarm
end

--- @private
--- 使用二分查找获取插入索引
--- @param targetTime number 目标触发时间
--- @return number index 应该插入的位置
function ClientClock.GetInsertIndex(targetTime)
    local list = ClientClock.alarmQueue
    local low, high = 1, #list
    local mid = 1

    while low <= high do
        mid = math.floor((low + high) / 2)
        if list[mid].time < targetTime then
            low = mid + 1
        elseif list[mid].time > targetTime then
            high = mid - 1
        else
            return mid
        end
    end
    return low
end

--- 取消闹钟
--- @param alarm ClientClock.Alarm
function ClientClock.RemoveAlarm(alarm)
    if (not alarm) then return end
    for i, v in ipairs(ClientClock.alarmQueue) do
        if v == alarm then
            table.remove(ClientClock.alarmQueue, i)
            break
        end
    end
end

--- @private
--- 检测并触发闹钟
function ClientClock.CheckAlarms()
    if #ClientClock.alarmQueue == 0 then return end

    local now = ClientClock.realTime
    -- 因为是有序列表，只检查头部
    while #ClientClock.alarmQueue > 0 and ClientClock.alarmQueue[1].time <= now do
        local alarm = table.remove(ClientClock.alarmQueue, 1)
        if alarm.callback then
            local status, err
            if alarm.context then
                status, err = pcall(alarm.callback, alarm.context, alarm.time)
            else
                status, err = pcall(alarm.callback, alarm.time)
            end
            if (not status) then
                LogTool.Error("ClientClock", "Alarm callback error: " .. err)
            end
        end
    end
end

--- @private
--- 每秒 Tick 一次
function ClientClock.Tick()
    ClientClock.realTime = Tools.GetRealTime()
    -- 检测闹钟
    ClientClock.CheckAlarms()
    -- UTC+8 北京时间
    local utc8 = os.date("!*t", ClientClock.realTime + UTC8TimeDiff)
    for type, timePoint in pairs(timePointMap) do
        if (utc8.hour == timePoint[1] and utc8.min == timePoint[2] and utc8.sec == timePoint[3]) then
            if (ClientClock.lastUTCDateMap[type] ~= utc8.day) then
                ClientClock.lastUTCDateMap[type] = utc8.day
                ClientClock.Notify(type)
            end
        end
    end
end

--- 启动时钟
function ClientClock.Start()
    if (not ClientClock.timer) then
        ClientClock.timer = TimerMgr:Init()
    end
    ClientClock.timer:ClearAllTimers()
    ClientClock.running = true
    ClientClock.timer:Loop(ClientClock.tickInterval, -1, function()
        ClientClock.Tick()
    end)
end

--- 停止时钟
function ClientClock.Stop()
    ClientClock.running = false
    if (ClientClock.timer) then
        ClientClock.timer:ClearAllTimers()
    end
end

--- 获取当前 Unix 时间戳
--- @return number
function ClientClock.GetRealTime()
    return ClientClock.realTime
end

--- 获取 UTC+8 时间戳
--- @return number
function ClientClock.GetUTC8RealTime()
    return ClientClock.realTime + UTC8TimeDiff
end

--- 获取格式化可读时间字符串
--- @param formatStr string 格式化字符串，不传的话默认输出 YYYY/MM/DD HH:MM:SS 格式的文本
--- @return string
function ClientClock.GetFormatTimeStr(formatStr)
    formatStr = formatStr or "%Y/%m/%d %H:%M:%S"
    return os.date(formatStr, ClientClock.realTime)
end

local formatters = {}
formatters[ETimeFormatType.DayToMin] = function(timeSpan)
    local d = math.floor(timeSpan / 86400)
    local h = math.floor(timeSpan % 86400 / 3600)
    local m = math.floor(timeSpan % 86400 % 3600 / 60)
    return string.format("%02d% 02d:%02d", d, h, m)
end
formatters[ETimeFormatType.HourToMin] = function(timeSpan)
    local h = math.floor(timeSpan / 3600)
    local m = math.floor((timeSpan % 3600) / 60)
    return string.format("%02d:%02d", h, m)
end
formatters[ETimeFormatType.HourToSec] = function(timeSpan)
    local h = math.floor(timeSpan / 3600)
    local m = math.floor((timeSpan % 3600) / 60)
    local s = math.floor(timeSpan % 60)
    return string.format("%02d:%02d:%02d", h, m, s)
end
formatters[ETimeFormatType.MinToSec] = function(timeSpan)
    local m = math.floor(timeSpan / 60)
    local s = math.floor(timeSpan % 60)
    return string.format("%02d:%02d", m, s)
end

--- 将时间间隔转化为格式化可读时间字符串
--- @param timeSpan number 时间间隔
--- @param formatType ETimeFormatType 格式化类型
--- @return string
function ClientClock.TimeSpanToFormatTime(timeSpan, formatType)
    timeSpan = math.max(0, math.floor(timeSpan))
    return formatters[formatType](timeSpan)
end

--- 获取下个月刷新时间的秒级时间戳
--- @param resetHour number? (可选) 重置的目标时间（UTC+8时区，不传的话默认为早五点）
--- @return number 时间戳（秒）
function ClientClock.GetNextMonthlyResetTime(resetHour)
    resetHour = resetHour or 5
    local now = ClientClock.GetUTC8RealTime()

    -- 在 UTC+8 下的逻辑时间
    local logicTime = now - resetHour * 3600
    local logicDate = os.date('!*t', logicTime)

    -- 当前逻辑月
    local year = logicDate.year
    local month = logicDate.month

    -- 下个月
    month = month + 1
    if month > 12 then
        month = 1
        year = year + 1
    end

    -- 构造目标时间：下个月1号 resetHour 点
    local target_date = {
        year = year,
        month = month,
        day = 1,
        hour = resetHour,
        min = 0,
        sec = 0
    }

    -- os.time 直接得到的是把 UTC+8 的目标日期以当地时区为标准得到的 UTC+0 时间戳，需要处理时区偏移
    local localUTCDiff = os.time() - os.time(os.date("!*t", os.time()))
    local target_time = os.time(target_date) + (localUTCDiff - UTC8TimeDiff)

    return target_time
end

--- 获取当前时间到下个月刷新时间的时间间隔
--- @param resetHour number? (可选) 重置的目标时间（UTC+8时区，不传的话默认为早五点）
--- @return number 时间间隔（秒）
function ClientClock.GetRemainTimeToMonthlyReset(resetHour)
    local now = ClientClock.GetRealTime()
    local target = ClientClock.GetNextMonthlyResetTime(resetHour)

    local remain = math.floor(target - now)
    if remain < 0 then remain = 0 end

    return remain
end

--- 将秒级时间戳转换为可读 年月日时分 时间
--- @param timeStamp number
--- @return string
function ClientClock.TimeStamp2YearMonthDateHourMin(timeStamp)
    timeStamp = tonumber(timeStamp) or 0
    local utc8 = os.date("!*t", math.floor(timeStamp) + UTC8TimeDiff)
    return string.format("%04d/%02d/%02d %02d:%02d", utc8.year, utc8.month, utc8.day, utc8.hour, utc8.min)
end

return ClientClock
