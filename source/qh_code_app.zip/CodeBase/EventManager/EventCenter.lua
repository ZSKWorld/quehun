local EventDispatcher = require("CodeBase.EventManager.EventDispatcher")

--- @class EventCenter 全局事件中心
--- 说明：
--- 1. 业务层统一使用 EventCenter，不直接使用 EventDispatcher
--- 2. 数据相关、UI 通知、模块通信都可以通过 EventCenter 解耦
--- 3. UI、Controller、Model 等对象销毁时，建议调用 offByCaller(self)
--- 4. 使用方式，在代码中添加
--- local EventCenter = require("CodeBase.EventManager.EventCenter")
--- local EventName = require("CodeBase.EventManager.EventName")
local EventCenter = {}

--- @type EventDispatcher
local dispatcher = EventDispatcher.new()

--- 注册事件监听
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象
--- @param callback function 回调函数
--- @param priority number|nil 优先级，默认 0，数值越大越先执行
--- @return EventConnection | nil
function EventCenter.on(eventName, caller, callback, priority)
    return dispatcher:on(eventName, caller, callback, priority)
end

--- 注册一次性事件监听
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象
--- @param callback function 回调函数
--- @param priority number|nil 优先级，默认 0，数值越大越先执行
--- @return EventConnection
function EventCenter.once(eventName, caller, callback, priority)
    return dispatcher:once(eventName, caller, callback, priority)
end

--- 移除指定事件监听
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象
--- @param callback function 回调函数
function EventCenter.off(eventName, caller, callback)
    dispatcher:off(eventName, caller, callback)
end

--- 移除某个对象注册的所有事件
--- @param caller table 监听所属对象
function EventCenter.offByCaller(caller)
    dispatcher:offByCaller(caller)
end

--- 派发事件
--- @param eventName string 事件名
--- @param params table 事件参数
function EventCenter.emit(eventName, params)
    dispatcher:emit(eventName, params)
end

--- 判断事件是否有监听
--- @param eventName string 事件名
--- @return boolean
function EventCenter.hasListener(eventName)
    return dispatcher:hasListener(eventName)
end

--- 获取事件监听数量
--- @param eventName string 事件名
--- @return number
function EventCenter.listenerCount(eventName)
    return dispatcher:listenerCount(eventName)
end

--- 清理指定事件的所有监听
--- @param eventName string 事件名
function EventCenter.clear(eventName)
    dispatcher:clear(eventName)
end

--- 清理所有事件监听
--- 通常只建议在重登、切服、调试、热更新重置时使用
function EventCenter.clearAll()
    dispatcher:clearAll()
end

--- 打印当前事件监听信息
function EventCenter.dump()
    dispatcher:dump()
end

return EventCenter
