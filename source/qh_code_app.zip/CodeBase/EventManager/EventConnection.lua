--- @class EventConnection 事件连接对象
--- @field public dispatcher EventDispatcher 事件派发器
--- @field public eventName string 事件名
--- @field public listener EventListener 监听数据
--- @field public connected boolean 当前连接是否有效
local EventConnection = {}
EventConnection.__index = EventConnection

--- 创建事件连接对象
--- @param dispatcher EventDispatcher 事件派发器
--- @param eventName string 事件名
--- @param listener EventListener 监听数据
--- @return EventConnection
function EventConnection.new(dispatcher, eventName, listener)
    local self = setmetatable({}, EventConnection)
    self.dispatcher = dispatcher
    self.eventName = eventName
    self.listener = listener
    self.connected = true
    return self
end

--- 断开当前事件连接
--- 说明：
--- 1. 业务层可以保存 EventConnection 对象，并在需要时主动断开
--- 2. 重复调用 Disconnect 是安全的
function EventConnection:Disconnect()
    if not self.connected then
        return
    end

    self.connected = false

    if self.dispatcher then
        self.dispatcher:_removeListener(self.eventName, self.listener)
    end

    self.dispatcher = nil
    self.eventName = nil
    self.listener = nil
end

--- 判断当前连接是否有效
--- @return boolean
function EventConnection:IsConnected()
    return self.connected == true
end

return EventConnection
