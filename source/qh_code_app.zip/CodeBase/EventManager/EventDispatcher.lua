local EventConnection = require("CodeBase.EventManager.EventConnection")

--- @class EventListener 事件监听数据
--- @field public eventName string 事件名
--- @field public caller table|nil 监听所属对象
--- @field public callback function 回调函数
--- @field public once boolean 是否只执行一次
--- @field public priority number 事件优先级，数值越大越先执行
--- @field public removed boolean 是否已经被移除
--- @field public connection EventConnection 事件连接对象

--- @class EventDispatcher 事件派发器
--- @field private _listeners table<string, EventListener[]> 事件名到监听列表的映射
--- @field private _callerConnections table<table, EventConnection[]> 监听对象到连接列表的映射
--- @field private _dispatching table<string, boolean> 当前正在派发的事件标记
local EventDispatcher = {}
EventDispatcher.__index = EventDispatcher

--- 创建事件派发器
--- @return EventDispatcher
function EventDispatcher.new()
    local self = setmetatable({}, EventDispatcher)

    -- 事件监听表
    -- 结构：
    -- _listeners[eventName] = {
    --     listener1,
    --     listener2,
    -- }
    self._listeners = {}

    -- caller 反查表
    -- 用于 offByCaller，一次性移除某个对象注册的所有事件
    -- 使用弱 key，避免 caller 已经释放后还被事件系统强引用
    self._callerConnections = setmetatable({}, { __mode = "k" })

    -- 派发中标记
    -- 用于解决派发过程中删除监听导致数组下标错乱的问题
    self._dispatching = {}

    return self
end

--- 生成错误堆栈信息
--- @param err any 错误信息
--- @return string
local function tracebackError(err)
    return debug.traceback(tostring(err), 2)
end

--- 安全调用事件回调
--- 说明：
--- 1. 使用 xpcall，避免某个监听报错导致后续监听无法执行
--- 2. caller 不为空时，等价于 callback(caller, ...)
--- @param callback function 回调函数
--- @param caller table|nil 回调所属对象
--- @param data any 回调参数
--- @return boolean, any
local function safeCall(callback, caller, data)
    if caller ~= nil then
        return xpcall(function()
            return callback(caller, data)
        end, tracebackError)
    end

    return xpcall(function()
        return callback(data)
    end, tracebackError)
end

--- 注册事件监听
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象，可以为空
--- @param callback function 回调函数
--- @param priority number|nil 优先级，数值越大越先执行，默认 0
--- @return EventConnection | nil
function EventDispatcher:on(eventName, caller, callback, priority)
    if eventName == nil or eventName == "" then
        LogTool.Error("EventDispatcher", "[EventDispatcher] on eventName 不能为空")
        return nil
    end

    if callback == nil then
        LogTool.Error("EventDispatcher", "[EventDispatcher] on callback 不能为空")
        return nil
    end

    priority = priority or 0

    --- @type EventListener
    local listener = {
        eventName = eventName,
        caller = caller,
        callback = callback,
        once = false,
        priority = priority,
        removed = false,
        connection = nil,
    }

    local list = self._listeners[eventName]
    if list == nil then
        list = {}
        self._listeners[eventName] = list
    end

    table.insert(list, listener)

    -- 按优先级排序
    -- 说明：
    -- 优先级越高越早执行。
    -- 不建议业务层大量依赖优先级，否则事件执行顺序会变得难以维护。
    table.sort(list, function(a, b)
        return a.priority > b.priority
    end)

    local connection = EventConnection.new(self, eventName, listener)
    listener.connection = connection

    -- 如果 caller 不为空，则建立 caller 到 connection 的反查关系
    -- 这样 UI 关闭时可以直接 EventCenter.offByCaller(self)
    if caller ~= nil then
        local callerList = self._callerConnections[caller]
        if callerList == nil then
            callerList = {}
            self._callerConnections[caller] = callerList
        end

        table.insert(callerList, connection)
    end

    return connection
end

--- 注册一次性事件监听
--- 事件触发一次后会自动移除
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象，可以为空
--- @param callback function 回调函数
--- @param priority number|nil 优先级，数值越大越先执行，默认 0
--- @return EventConnection
function EventDispatcher:once(eventName, caller, callback, priority)
    local connection = self:on(eventName, caller, callback, priority)

    if connection and connection.listener then
        connection.listener.once = true
    end

    return connection
end

--- 移除指定事件监听
--- @param eventName string 事件名
--- @param caller table|nil 监听所属对象
--- @param callback function 回调函数
function EventDispatcher:off(eventName, caller, callback)
    local list = self._listeners[eventName]
    if list == nil then
        return
    end

    for i = #list, 1, -1 do
        local listener = list[i]

        if listener.caller == caller and listener.callback == callback then
            self:_removeListener(eventName, listener)
        end
    end
end

--- 移除某个对象注册过的所有事件
--- 常用于 UI 面板、控制器、模块销毁时统一清理事件
--- @param caller table 监听所属对象
function EventDispatcher:offByCaller(caller)
    if caller == nil then
        return
    end

    local callerList = self._callerConnections[caller]
    if callerList == nil then
        return
    end

    for i = #callerList, 1, -1 do
        local connection = callerList[i]
        if connection and connection:IsConnected() then
            connection:Disconnect()
        end
    end

    self._callerConnections[caller] = nil
end

--- 派发事件
--- @param eventName string 事件名
--- @param data table 事件参数
function EventDispatcher:emit(eventName, data)
    local list = self._listeners[eventName]
    if list == nil or #list == 0 then
        return
    end

    -- 标记当前事件正在派发
    self._dispatching[eventName] = true

    -- 拷贝快照，避免派发过程中新增/删除监听导致遍历异常
    local snapshot = {}
    for i = 1, #list do
        snapshot[i] = list[i]
    end

    for i = 1, #snapshot do
        local listener = snapshot[i]

        if listener and not listener.removed then
            local ok, err = safeCall(listener.callback, listener.caller, data)

            if not ok then
                LogTool.Error("EventDispatcher",string.format(
                    "[EventDispatcher] eventName=%s callback error:\n%s",
                    tostring(eventName),
                    tostring(err)
                ))
            end

            -- once 监听执行后自动移除
            if listener.once then
                self:_removeListener(eventName, listener)
            end
        end
    end

    self._dispatching[eventName] = nil

    -- 派发结束后，统一清理派发过程中被标记删除的监听
    self:_cleanupRemoved(eventName)
end

--- 判断某个事件是否存在监听
--- @param eventName string 事件名
--- @return boolean
function EventDispatcher:hasListener(eventName)
    local list = self._listeners[eventName]
    if list == nil then
        return false
    end

    for i = 1, #list do
        if not list[i].removed then
            return true
        end
    end

    return false
end

--- 获取某个事件当前有效监听数量
--- @param eventName string 事件名
--- @return number
function EventDispatcher:listenerCount(eventName)
    local list = self._listeners[eventName]
    if list == nil then
        return 0
    end

    local count = 0
    for i = 1, #list do
        if not list[i].removed then
            count = count + 1
        end
    end

    return count
end

--- 清理指定事件的所有监听
--- @param eventName string 事件名
function EventDispatcher:clear(eventName)
    local list = self._listeners[eventName]
    if list == nil then
        return
    end

    for i = 1, #list do
        local listener = list[i]
        listener.removed = true

        if listener.connection then
            listener.connection.connected = false
            listener.connection.dispatcher = nil
            listener.connection.eventName = nil
            listener.connection.listener = nil
        end
    end

    self._listeners[eventName] = nil
end

--- 清理所有事件监听
--- 注意：
--- 该接口通常只建议在重登、切服、热更新重置、调试场景下使用
function EventDispatcher:clearAll()
    for eventName, _ in pairs(self._listeners) do
        self:clear(eventName)
    end

    self._listeners = {}
    self._callerConnections = setmetatable({}, { __mode = "k" })
    self._dispatching = {}
end

--- 内部方法：移除指定监听
--- 说明：
--- 1. 如果当前事件正在派发，只标记 removed，不立即 table.remove
--- 2. 派发结束后统一清理，避免数组下标错乱
--- @param eventName string 事件名
--- @param listener EventListener 监听数据
function EventDispatcher:_removeListener(eventName, listener)
    if listener == nil or listener.removed then
        return
    end

    listener.removed = true

    if listener.connection then
        listener.connection.connected = false
        listener.connection.dispatcher = nil
        listener.connection.eventName = nil
        listener.connection.listener = nil
    end

    if self._dispatching[eventName] then
        return
    end

    self:_cleanupRemoved(eventName)
end

--- 内部方法：清理被标记删除的监听
--- @param eventName string 事件名
function EventDispatcher:_cleanupRemoved(eventName)
    local list = self._listeners[eventName]
    if list == nil then
        return
    end

    for i = #list, 1, -1 do
        local listener = list[i]
        if listener.removed then
            table.remove(list, i)
        end
    end

    if #list == 0 then
        self._listeners[eventName] = nil
    end
end

--- 打印当前所有事件监听信息
--- 用于调试事件泄漏、重复注册等问题
function EventDispatcher:dump()
    LogTool.DebugDevColor("EventDispatcher", "========== EventDispatcher Dump ==========", "#00ff00")

    for eventName, list in pairs(self._listeners) do
        local count = self:listenerCount(eventName)
        LogTool.DebugDevColor("EventDispatcher", string.format("eventName=%s, count=%d", tostring(eventName), count), "#00ff00")

        for i = 1, #list do
            local listener = list[i]
            if not listener.removed then
                LogTool.DebugDevColor("EventDispatcher", string.format(
                    "  [%d] caller=%s, callback=%s, once=%s, priority=%s",
                    i,
                    tostring(listener.caller),
                    tostring(listener.callback),
                    tostring(listener.once),
                    tostring(listener.priority)
                ), "#00ff00")
            end
        end
    end

    LogTool.DebugDevColor("EventDispatcher", "==========================================", "#00ff00")
end

return EventDispatcher
