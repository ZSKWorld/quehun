
--- 说明：
--- 1. 业务层不要直接写字符串事件名
--- 2. 所有事件统一维护在这里，方便搜索、重构和排查拼写错误
local EventName = {}

EventName.Activity = {
    --- 活动结束,参数：活动id列表 number[]
    ActivityEnd = "Activity.ActivityEnd"
  
}

return EventName
