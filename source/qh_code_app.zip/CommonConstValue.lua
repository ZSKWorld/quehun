MIN_HUN_TIAN_LEVEL_ID = 10701   -- 四麻魂天最低段位配置表 id
MAX_HUN_TIAN_LEVEL_ID = 10720   -- 四麻魂天最高段位配置表 id
MIN_HUN_TIAN_LEVEL3_ID = 20701   -- 三麻魂天最低段位配置表 id
MAX_HUN_TIAN_LEVEL3_ID = 20720   -- 三麻魂天最高段位配置表 id
