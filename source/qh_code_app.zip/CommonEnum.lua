--- @enum ESceneTypes 场景类型
ESceneTypes = { None = 0, Entrance = 1, Lobby = 2, Spot = 3, MJ = 4, Amulet = 5, Common = 6, MajorActivity = 7 }

--- @enum ELoadingType UI_Loading 的加载类型
ELoadingType = { EnterLobby = 1, EnterMJ = 2, WaitForOther = 3, LoadLobby = 4, EnterSpecial = 5, EnterStory = 6 }

--- @enum EUILifecycleState UI 实例当前的生命周期状态
EUILifecycleState = {
    -- 已初始化，未激活，随时可展示（展示 UI 时取的都是处于这个状态的实例）
    Inactive = 1,
    -- 正在加载资源（加载完毕后进入 PreProcessing 状态）
    LoadingRes = 2,
    -- 正在进行数据预处理（处理完毕后进入 PreShowing 状态）
    PreProcessing = 3,
    -- 正在进入展示状态（例如播放展示动画、进行预处理等，完毕后进入 Active 状态）
    PreShowing = 4,
    -- 展示中（需要跨实例修改 UI 内容时通常取这个状态的实例）
    Active = 5,
    -- 冻结中（不执行 OnClose 逻辑直接隐藏 UI，保留状态，冻结中的 UI 切换场景时不会被 Close）
    Freezing = 6,
    -- 正在关闭流程中（完成后根据 destroyOnClose 的值进入 Inactive 或 Destroying 状态）
    Closing = 7,
    -- 正在销毁中
    Destroying = 8,
    -- 已初始化，未激活,资源保留状态
    Reserved = 9,
}

--- @class EPoolType 卡池类型
EPoolType = { Normal = 1, UP = 2, SP = 3, Collab = 4, ChooseUp = 5 ,ChooseGroup = 6}

---@enum EPlatform
EPlatform = {
    StandaloneWindows64 = "StandaloneWindows64",
    StandaloneWindows = "StandaloneWindows",
    Android = "Android",
    iOS = "iOS",
    StandaloneOSX = "StandaloneOSX",
    AA32 = "AA32",
    WebGL = "WebGL",
}

--- @enum EClockNotifyType
EClockNotifyType = {
    DayChange = 1
}

--- @enum ETimeFormatType 时间格式化类型
ETimeFormatType = {
    -- 天
    Day = 1,
    -- 天小时
    DayToHour = 2,
    -- 天小时分钟
    DayToMin = 3,
    -- 天小时分钟秒
    DayToSec = 4,
    -- 小时
    Hour = 11,
    -- 小时分钟
    HourToMin = 12,
    -- 小时分钟秒
    HourToSec = 13,
    -- 分钟
    Min = 21,
    -- 分钟秒
    MinToSec = 22,
    -- 秒
    Sec = 31,
}

--- @enum EFormItemType 表单组件类型
EFormItemType = {
    Slider = 1,
    Dropdown = 2,
    Toggle = 3,
    VolumeSlider = 4
}

--- @enum EBGMType 背景音乐类型
EBGMType = {
    Unknown = 0,
    Lobby = 1,
    MJ = 2
}

--- @enum EFPSMode 移动端帧率模式
EFPSMode = {
    Fast = "fast",
    Slow = "slow"
}

--- @enum ECardPlayingClickMode 出牌模式
ECardPlayingClickMode = {
    Single = 0,
    Double = 1
}

--- @enum ECommentPermission 留言权限
ECommentPermission = {
    All = 0,
    Friend = 1,
    None = 2
}

--- @enum ELangStr 语言字符串
ELangStr = {
    Chs = "chs",
    ChsT = "chs_t",
    En = "en",
    Jp = "jp",
    Kr = "kr"
}

--- @enum EStreamerDetailSettingKey 主播模式详细设置项
EStreamerDetailSettingKey = {
    HideForeignNickName = "FOREIGN",
    HideLocalNickName = "MATCH",
    HideReplayNickName = "REPLAY",
    HideObserveNickName = "OBSERVE",
    HideMatchNickName = "MATCH_LOBBY",
    HideLeaderboardNickName = "LEADERBOARD",
}

--- @enum EInGameJumpType 游戏内跳转类型
EInGameJumpType = {
    MatchDetail = 1 -- 大会室详情
}

--- @enum EAccountSetKey 账户设置项
EAccountSetKey = {
    UserXieyi = 1,
}

--- @enum ECharVoiceType 角色语音类型
ECharVoiceType = {
    Greeting = "lobby_playerlogin",
    Click = "lobby_normal"
}