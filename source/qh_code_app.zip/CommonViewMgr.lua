CommonViewMgr = {}

CommonViewMgr.cached_rand_views = {}
CommonViewMgr.max_deco_group = 10

local type_rand = 1
local type_normal = 0

local ECommonView = GameUtility.ECommonView


function CommonViewMgr.Init()
end

---获取当前装扮 如果为随机模式 随机并缓存后返回
---@param view_type integer GameUtility.ECommonView
---@return integer item_id
function CommonViewMgr.RandAndGetView(view_type)
    local server_slot = CommonViewMgr.LocalSlot2ServerSlot(view_type)
    local view_data = GameMgr.Inst.commonviews[GameMgr.Inst.now_commonviews_index + 1][server_slot]
    if not view_data then
        return 0
    end
    if view_data.type == type_rand then
        local rand_res = view_data.item_id_list[math.random(#view_data.item_id_list)]
        CommonViewMgr.cached_rand_views[server_slot] = rand_res
        return rand_res
    else
        return view_data.item_id or 0
    end
end

---获取当前装扮 没有随机缓存时才随机
---@param view_type integer GameUtility.ECommonView
---@return integer item_id
function CommonViewMgr.GetCachedView(view_type)
    local server_slot = CommonViewMgr.LocalSlot2ServerSlot(view_type)
    local view_data = GameMgr.Inst.commonviews[GameMgr.Inst.now_commonviews_index + 1][server_slot]
    if not view_data then
        return 0
    end
    if view_data.type == type_rand then
        return CommonViewMgr.cached_rand_views[server_slot] or CommonViewMgr.RandAndGetView(view_type)
    else
        return view_data.item_id or 0
    end
end

---触发一次随机并刷新数据
---@param onComplete? fun()
function CommonViewMgr.RandAll(onComplete)
    --本地数据牌背 鸣牌指示 牌面 和桌布需要主动随机
    local mjp_view_item = CommonViewMgr.RandAndGetView(ECommonView.mjp)
    local mjpface_view_item = CommonViewMgr.RandAndGetView(ECommonView.mjpface)
    CommonViewMgr.RandAndGetView(ECommonView.desktop)
    CommonViewMgr.RandAndGetView(ECommonView.mingpaizhishi)

    local new_mjp_view = 'mjp_default'
    local d_view = ExcelMgr.GetData('item_definition', 'view', mjp_view_item)
    if d_view then new_mjp_view = d_view.res_name end

    local new_mjpface_view = 'mjpface_default'
    local d_view = ExcelMgr.GetData('item_definition', 'view', mjpface_view_item)
    if d_view then new_mjpface_view = d_view.res_name end

    LuaTools.LoadGroups({
        'deco/mjpai/' .. new_mjp_view .. '/3d',
        'deco/mjpface/' .. new_mjpface_view .. '/3d',
    }, function()
        GameMgr.Inst:ChangeMjpView(new_mjp_view, nil)
        GameMgr.Inst:ChangeMjpFaceView(new_mjpface_view, nil)
        Tools.SafeCall(onComplete)
    end, nil)
end

---刷新大厅背景 牌面 牌背
---@param view_type any 未指定时刷新全部
function CommonViewMgr.RefreshLocalViews(view_type, onComplete)
    local loadBackground = view_type == ECommonView.lobbybackground or view_type == nil
    local loadMjp = view_type == ECommonView.mjp or view_type == nil
    local loadMjpFace = view_type == ECommonView.mjpface or view_type == nil
    local loadCnt = 0
    if loadBackground then loadCnt = loadCnt + 1 end
    if loadMjp then loadCnt = loadCnt + 1 end
    if loadMjpFace then loadCnt = loadCnt + 1 end

    local onLoaded = nil
    if loadCnt > 0 then
        local loadedCnt = 0
        onLoaded = function()
            loadedCnt = loadedCnt + 1
            if loadedCnt >= loadCnt then
                Tools.SafeCall(onComplete)
            end
        end
    end

    if loadBackground then
        --背景外观
        local lobby_background = 0
        if GameMgr.Inst.commonview_slot[tonumber(ECommonView.lobbybackground)] and GameMgr.Inst.commonview_slot[tonumber(ECommonView.lobbybackground)].item_id then
            lobby_background = GameMgr.Inst.commonview_slot[tonumber(ECommonView.lobbybackground)].item_id
        end
        LobbyBackground.Inst:ChangeLobbyBackground(lobby_background, false, onLoaded)
    end
    if loadMjp then
        --获取麻将牌外观
        local mjp_view_item = CommonViewMgr.RandAndGetView(ECommonView.mjp)
        local new_mjp_view = 'mjp_default'
        local d_view = ExcelMgr.GetData('item_definition', 'view', mjp_view_item)
        if d_view then
            new_mjp_view = d_view.res_name
        end
        GameMgr.Inst:ChangeMjpView(new_mjp_view, onLoaded)
    end
    if loadMjpFace then
        local mjpface_view_item = CommonViewMgr.RandAndGetView(ECommonView.mjpface)
        local new_mjpface_view = 'mjpface_default'
        local d_view = ExcelMgr.GetData('item_definition', 'view', mjpface_view_item)
        if d_view then
            new_mjpface_view = d_view.res_name
        end
        GameMgr.Inst:ChangeMjpFaceView(new_mjpface_view, onLoaded)
    end
end

function CommonViewMgr.RefreshChestViews(chest_data, poolType, direction)
    return LobbyBackground.Inst:ChangeLobbyBackgroundForTreasure(chest_data, poolType, direction)
end

-- 上古遗留问题 本地slot是0到10 (GameUtility.ECommonView) 服务器slot和item表里的type是0-13  目前鸣牌指示和牌面的slot需要转换

---@param server_slot integer server的slot 或 item的type 0-13
---@return integer local_slot 本地用的slot 0-10 或 GameUtility.ECommonView
function CommonViewMgr.ServerSlot2LocalSlot(server_slot)
    if server_slot == 10 then
        -- 鸣牌指示
        return 9
    elseif server_slot == 13 then
        -- 牌面
        return 10
    else return server_slot
    end
end

---@param local_slot integer 本地用的slot 0-10 GameUtility.ECommonView
---@return integer server_slot server的slot或item的type 0-13
function CommonViewMgr.LocalSlot2ServerSlot(local_slot)
    if local_slot == 9 then
        -- 鸣牌指示
        return 10
    elseif local_slot == 10 then
        -- 牌面
        return 13
    else
        return local_slot
    end
end