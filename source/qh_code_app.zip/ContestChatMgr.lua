require("Basic")
require("GameUtility")
require("Tools")

---@class ContestChatMgr
ContestChatMgr = {}

local json = require 'cjson'
local pt = require("PrintTable")
local EConnectState = GameUtility.EConnectState
local error_msg = ''

-- 坤坤：这个线路协议用的不是Proto，也发不了requestConnect，暂时不改成NetRoute

function ContestChatMgr:Init()
    local o = {}
    setmetatable(o, self)
    self.__index = self
    ---@type ContestChatMgr
    self.Inst = o
    o:Build()
end

function ContestChatMgr:Close()
    self.load_over = false
    self:_setState(EConnectState.none)
    if self.net_connect then
        self.net_connect:Close()
    end
    self.url = ''
end

function ContestChatMgr:Build()
    error_msg = ''
    self.routeID = ''
    self.url = ''
    self.ssl = false
    self.token = ''
    self.game_uuid = ''
    self.urls = {}
    self.net_index = 0
    self.link_index = -1
    self.connect_state = EConnectState.none
    self.reconnect_count = 0
    self.reconnect_span = {}
    self.reconnect_span[1] = 0.5
    self.reconnect_span[2] = 1
    self.reconnect_span[3] = 3
    self.lasterrortime = 0
    self.load_over = false

    self.total_reconnect_count = 0
    self.net_connect = ChatSocket:New()
    self.net_connect:AddListener_Open(function() self:_onConnectOpen() end)
    self.net_connect:AddListener_Error(function(err) self:_onConnectError(err) end)
    self.net_connect:AddListener_Close(function() self:_onConnectClose() end)
    
end

function ContestChatMgr:GetDelay()
    if not self.net_connect then return 9999 end
    return self.net_connect.clientHandler._delay
end


--retry_count:int
function ContestChatMgr:_trytolinknext()
    self:_setState(EConnectState.reconnecting)
    self.reconnect_count = 0
    self:_reconnect()
    self.net_connect:SendSysMsg({
        type = 100,
        str = Tools.StrOfLocalization(10103)
    })
end


function ContestChatMgr:_setState(connect_state)
    self.connect_state = connect_state
    if connect_state == EConnectState.reconnecting then
        -- 重连提示
        -- self.net_connect:SendSysMsg({
        --     type = 100,
        --     str = '连接中'
        -- })
    end
    --TestFunctions
end

function ContestChatMgr:SendMessage(msg, callback)
    if self.connect_state == EConnectState.connecting then
        self.net_connect:SendMessage(msg, callback)
    else
        local s = '发送时,'
        if self.connect_state == EConnectState.none then
            s = s..'连接不存在'
        elseif self.connect_state == EConnectState.tryconnect then
            s = s..'连接正在尝试'
        elseif self.connect_state == EConnectState.reconnecting then
            s = s..'连接重试重连'
        elseif self.connect_state == EConnectState.closed then
            s = s..'连接已断开'
        end
        LogTool.Warning('Network', s)
        UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.Normal, msg = s })

    end
end

function ContestChatMgr:AddMsgListener(msg_name, handler)
    if self.net_connect then
        self.net_connect:AddMsgListener(msg_name, handler)
    else
        LogTool.Error('Network', 'Fatal Error, no net connect')
    end
end

function ContestChatMgr:RemoveMsgListener(msg_name, handler)
    if self.net_connect then
        self.net_connect:RemoveMsgListener('.lq.'..msg_name, handler)
    else
        LogTool.Error('Network', 'Fatal Error, no net connect')
    end
end

function ContestChatMgr:_onConnectOpen()
    self.net_index = self.net_index + 1
    if self.connect_state == EConnectState.tryconnect then
        self:_setState(EConnectState.connecting)
        self:_connectSuccess()
    elseif self.connect_state == EConnectState.reconnecting then
        self:_setState(EConnectState.connecting)
        self:_fastReconnectSuccess()
    end
    ContestChatMgr.connection_time = Tools.GetRealTime()
    error_msg = ''
end

function ContestChatMgr:_onConnectClose()
    self:_onConnectFailed()
end

function ContestChatMgr:_onConnectError(error)
    self:_onConnectFailed(error)
    error_msg = error
end

function ContestChatMgr:_onConnectFailed(error)
    if UnityEngine.Time.time - self.lasterrortime > 0.1 then
        self.lasterrortime = UnityEngine.Time.time
    else
        return
    end
    error_msg = error
    self.net_index = self.net_index + 1
    if self.connect_state == EConnectState.tryconnect then 
        self:_trytolinknext()
    elseif self.connect_state == EConnectState.connecting then
        if UI_MatchRoom and UI_MatchRoom.Inst and UI_MatchRoom.Inst.transform.gameObject.activeSelf then
            self:_setState(EConnectState.reconnecting)
            self.reconnect_count = 0
            self:_reconnect()

            self.net_connect:SendSysMsg({
                type = 100,
                str = Tools.StrOfLocalization(10103)
            })
        else
            self:_setState(EConnectState.closed)

            self.net_connect:SendSysMsg({
                type = 100,
                str = Tools.StrOfLocalization(10105)
            })
        end
    elseif self.connect_state == EConnectState.reconnecting then
        self.net_connect:SendSysMsg({
            type = 100,
            str = Tools.StrOfLocalization(10103)
            })
        self:_reconnect()
    end
end

function ContestChatMgr:force_reconnect()
    self.reconnect_count = 0
    self:_setState(EConnectState.reconnecting)
    self:_reconnect()
end

function ContestChatMgr:fast_reconnect()
    self.reconnect_count = 0
    self:_setState(EConnectState.reconnecting)
    self:_reconnect()
end

function ContestChatMgr:OnClose()
    self.net_connect:Close()
end

function ContestChatMgr:OnApplicationPause()
	self.net_connect:Close()
end

function ContestChatMgr:_reconnect()
    pcall(function()
        -- 尝试建立连接失败时上报信息
        local log_category = 'contest_chat'
        local match_id
        local token
        if UI_MatchRoom and UI_MatchRoom.Inst then
            match_id = UI_MatchRoom.Inst.match_id
            -- token = UI_MatchRoom.Inst.token
        end
        local content = {
            unique_id = match_id,
            token = token,
            current_time = Tools.gettime(),
            err = error_msg,
            code = self.connect_state
        }
        local str = json.encode(content)
        UI_ErrorInfo.HandleInfo(str, log_category)
        LogTool.Error('Network', 'report socket error: ' .. log_category .. ' ' .. str .. debug.traceback)
    end)

    LogTool.Info('Network', 'Contest Chat _reconnect in_count:' .. self.reconnect_count)
    local lobbyconnectstate = LobbyNetMgr.GetConnectState()
    self.total_reconnect_count = self.total_reconnect_count + 1
    if self.total_reconnect_count > 3 then
        -- 同一个聊天室重连三次直接不再连接
        self:_setState(EConnectState.closed)
        self.net_connect:SendSysMsg({
            type = 100,
            str = Tools.StrOfLocalization(10105)
        })
        return
    end
    if lobbyconnectstate == EConnectState.none or lobbyconnectstate == EConnectState.closed then
        self:_setState(EConnectState.closed)
    elseif lobbyconnectstate == EConnectState.usable and GameMgr.Inst.logined then
        if self.reconnect_count >= #self.reconnect_span then
            self:_setState(EConnectState.closed)
        else
            self.reconnect_count = self.reconnect_count + 1
            LogTool.Info('Network', 'Contest Chat _reconnect:' .. self.reconnect_count .. ' wait:' .. self.reconnect_span[self.reconnect_count] .. debug.traceback())
            TimeMgr.Delay(self.reconnect_span[self.reconnect_count], function()
                if self.connect_state == EConnectState.reconnecting then
                    xpcall(function()
                        LogTool.InfoNet('ContestChatMgr', '_reconnect url:' .. self.url .. ', GetRecentContentIDStr:' .. self:GetRecentContentIDStr())
                        self.net_connect:Connect(self.url .. self:GetRecentContentIDStr(), self.ssl)
                    end, function()
                        LogTool.Info('Network', 'socket reconnect fail')
                        self:_reconnect()
                    end)
                end
            end)
        end
    else
        TimeMgr.Delay(1, function()
            self:_reconnect()
        end)
    end
end

function ContestChatMgr:isOK()
    return ContestChatMgr.Inst and self.connect_state == EConnectState.connecting
end

--url:string, token:string, game_uuid: string
function ContestChatMgr:OpenConnect(token, func, on_reconnect_done_func)
    self.total_reconnect_count = 0
    self.trybackurl = false
    LogTool.InfoNet('ContestChatMgr', 'ContestChatMgr OpenConnect: ' .. 'token: ' .. token)
    
    TimeMgr.Delay(0.5, function()
        xpcall(function ()
            local routeMain = NetRouteGroup.Inst.routeMain
            self:_setState(EConnectState.tryconnect)
            self.token = token
            self.routeID = routeMain.routeID
            self.ssl = routeMain.ssl
            self.url = NetRouteGroup.Inst:GetChoosedUrl() .. '/contest-chat?stream=binary&token=' .. token .. '&supportid=true'
            self._open_func = func
            self.on_reconnect_done_func = on_reconnect_done_func
            LogTool.InfoNet('ContestChatMgr', 'OpenConnect url:' .. self.url)
            self.net_connect:Connect(self.url, self.ssl)
        end, function (msg)
            LogTool.ErrorNet('ContestChatMgr', 'OpenConnect err: ' .. pt.block(msg))
            self:_onConnectFailed()
        end)
    end)
end

function ContestChatMgr:_connectSuccess()
    self._open_func({open = true})
end

function ContestChatMgr:_fastReconnectSuccess()
    if self.on_reconnect_done_func then
        self.on_reconnect_done_func({open = true})
    end

    self.net_connect:SendSysMsg({
        type = 100,
        str = Tools.StrOfLocalization(10104)
    })
end

function ContestChatMgr:GetRecentContentIDStr()
    if UI_MatchRoom and UI_MatchRoom.Inst then
        local s = '&message_id=' .. UI_MatchRoom.Inst:GetRecentMessageID() .. '&system_id=' .. UI_MatchRoom.Inst:GetRecentSystemID()
        return s
    end
    return ''
end

return ContestChatMgr