---@class CustomEvent 模拟 C# 事件
CustomEvent = {}
CustomEvent.__index = CustomEvent

--- @class CustomEvent.ListenerInfo
--- @field func fun(...):void 回调函数
--- @field obj any 绑定对象
--- @field isDirty boolean 是否被标记删除

--- @return CustomEvent
function CustomEvent.New()
    --- @type CustomEvent
    local o = {}
    --- @type CustomEvent.ListenerInfo[]
    o.listeners = {}
    o.invokingCount = 0
    o.hasDirty = false
    return setmetatable(o, CustomEvent)
end

--- 添加监听 (类似 C# 的 += )
--- @param func function 回调函数
--- @param obj any 绑定对象(可选，用于处理回调中的 self)
function CustomEvent:AddListener(func, obj)
    for i = 1, #self.listeners do
        local info = self.listeners[i]
        if info.func == func and info.obj == obj then
            -- 如果该监听曾被标记删除，则恢复
            if info.isDirty then info.isDirty = false end
            return
        end
    end
    table.insert(self.listeners, { func = func, obj = obj, isDirty = false })
end

--- 移除监听 (类似 C# 的 -= )
--- @param func function
--- @param obj? any
function CustomEvent:RemoveListener(func, obj)
    for i = 1, #self.listeners do
        local info = self.listeners[i]
        if info.func == func and info.obj == obj then
            if self.invokingCount > 0 then
                -- 当前正在执行触发逻辑，则标记为脏数据，待执行完毕清理
                info.isDirty = true
                self.hasDirty = true
            else
                table.remove(self.listeners, i)
            end
            break
        end
    end
end

--- 触发事件 (类似 C# 的 Invoke )
function CustomEvent:Invoke(...)
    if #self.listeners == 0 then return end

    self.invokingCount = self.invokingCount + 1

    -- 使用固定长度遍历，防止在 Invoke 中 Add 的元素在本次被触发
    local limit = #self.listeners
    for i = 1, limit do
        local info = self.listeners[i]
        if not info.isDirty then
            if info.obj then
                info.func(info.obj, ...)
            else
                info.func(...)
            end
        end
    end

    self.invokingCount = self.invokingCount - 1

    -- 只有派发完全结束且有脏数据时才清理
    if self.invokingCount == 0 and self.hasDirty then
        self:Cleanup()
    end
end

--- @private
function CustomEvent:Cleanup()
    for i = #self.listeners, 1, -1 do
        if self.listeners[i].isDirty then
            table.remove(self.listeners, i)
        end
    end
    self.hasDirty = false
end

--- 清空所有监听
function CustomEvent:Clear()
    table.clear(self.listeners)
end

return CustomEvent
