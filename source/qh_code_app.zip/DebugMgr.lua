-- ==DevDebug== 
DebugMgr = {}

local KeyCode = UnityEngine.KeyCode
local targetKeySeq =
{
    KeyCode.UpArrow,
    KeyCode.UpArrow,
    KeyCode.DownArrow,
    KeyCode.DownArrow,
    KeyCode.LeftArrow,
    KeyCode.RightArrow,
    KeyCode.LeftArrow,
    KeyCode.RightArrow
};
local keyIndex = 1
local lastInputTime = 0
local maxGap = 1.0

-- 牌谱录制模式，开启时隐藏部分 UI
DebugMgr.recordReplayModeOn = false

function DebugMgr.Init()
    TimeMgr.LoopFrame(1, -1, function()
        if (DebugMgr.CheckDebugOn() and not UIMgr.Inst:IsUIEnabled(UI_DebugMain.className)) then
            UIMgr.Inst:ShowUIBase(UI_DebugMain)
        end
    end)
    DebugMgr.timer = TimerMgr:Init()
end

--- @private
--- @return boolean
function DebugMgr.CheckDebugOn()
    if (not UnityEngine.Input.anyKeyDown) then return false end
    if (UnityEngine.Input.GetKeyDown(targetKeySeq[keyIndex])) then
        local currentTime = UnityEngine.Time.time
        if (keyIndex == 1 or currentTime - lastInputTime <= maxGap) then
            keyIndex = keyIndex + 1
            if (keyIndex > #targetKeySeq) then
                keyIndex = 1
                return true
            end
        end
        lastInputTime = currentTime
    else
        keyIndex = 1
    end
    return false
end

function DebugMgr.SwitchDebugReplayMode(isOn)
    DebugMgr.timer:ClearAllTimers()
    if (Scene_MJ.Inst:is_in_mj() and DesktopMgr.Inst.mode == GameUtility.EMJ_Mode.paipu) then
        UI_Replay.Inst.root_replay.gameObject:SetActive(not isOn)
        UI_Replay.Inst.switch_replay.gameObject:SetActive(not isOn)
        UI_DesktopInfo.Inst.switch_tingpai.gameObject:SetActive(not isOn)
        if (isOn) then
            DebugMgr.timer:Delay(10, function()
                UI_Replay.Inst:set_auto_play(true)
            end)
        end
    end
end

return DebugMgr
