require("Basic")
require("GameUtility")
require("ExcelMgr")
require("Game.MJ.MJPai")
require("Game.MJ.ViewPlayer_Me")
require("Game.MJ.ViewPlayer_Other")
require("Game.MJ.Actions.ActionAnGangAddGang")
require("Game.MJ.Actions.ActionChiPengGang")
require("Game.MJ.Actions.ActionDealTile")
require("Game.MJ.Actions.ActionDiscardTile")
require("Game.MJ.Actions.ActionHule")
require("Game.MJ.Actions.ActionHuleXueZhanMid")
require("Game.MJ.Actions.ActionHuleXueZhanEnd")
require("Game.MJ.Actions.ActionLiqi")
require("Game.MJ.Actions.ActionLiuJu")
require("Game.MJ.Actions.ActionNewRound")
require("Game.MJ.Actions.ActionNewCard")
require("Game.MJ.Actions.ActionFillAwaitingTiles")
require("Game.MJ.Actions.ActionChangeTile")
require("Game.MJ.Actions.ActionSelectGap")
require("Game.MJ.Actions.ActionNoTile")
require("Game.MJ.Actions.ActionOperation")
require("Game.MJ.Actions.ActionBaBei")
require("Game.MJ.Actions.ActionGangResult")
require("Game.MJ.Actions.ActionGangResultEnd")
require("Game.MJ.Actions.ActionRevealTile")
require("Game.MJ.Actions.ActionUnveilTile")
require("Game.MJ.Actions.ActionLockTile")
require("Game.MJ.Actions.ActionSubmit")
require("Game.MJ.Actions.ActionTake")
require("UI.UI_DesktopInfo")
require("UI.UI_MJTaskProgress")
require("TimerMgr")
require("GameUtility.CameraClamp")

---@class DesktopMgr
DesktopMgr = {
    ---@type DesktopMgr
    Inst = nil
}

--- @class DesktopMgr.MatchInfo
--- @field isPartyMatch bool 是否是团队赛
--- @field needHandleForbidden bool 是否需要处理屏蔽词

--- @class DesktopMgr.BestHuData
--- @field originData IHuleInfo 原始数据
--- @field finalPaiList string[] 和牌时的牌型
--- @field score number 打点

local E_Ming = GameUtility.E_Ming           --'shunzi', 'kezi', 'gang_ming', 'gang_an', 'babei'
local E_PlayerOperation = GameUtility.E_PlayerOperation
local ELink_State = GameUtility.ELink_State --'NULL', 'AUTH', 'SYNCING', 'READY'
local ERule_Mode = GameUtility.ERule_Mode   --'Liqi4', 'Liqi3'
local EMJ_Mode = GameUtility.EMJ_Mode       --'play', 'paipu', 'live_broadcast'
local EplayerView = GameUtility.EplayerView --'liqibang', 'hupai_effect', 'liqi_effect', 'hand_model', 'liqi_bgm'
local pt = require("PrintTable")
local EZtestType = Basic.Enum { "none", "center", "top" } -- 1.麻将在特效上层，跟其他牌有遮挡关系 2.麻将在特效和其他所有牌上层
local EMJGameRule = GameUtility.EMJGameRule

DesktopMgr.PAIMODEL_HEIGHT = 0.0406315      --0.0455 * 0.95 * 0.94
DesktopMgr.PAIMODEL_WIDTH = 0.0308085       --0.0345 * 0.95 * 0.94
DesktopMgr.PAIMODEL_THICKNESS = 0.0209855   --0.0235 * 0.95 * 0.94
DesktopMgr.PAI_COUNT = 136

DesktopMgr.click_prefer = 0           --点击偏好，0.单击，1.双击
DesktopMgr.double_click_pass = 0      --过牌偏好，0.无,1.双击
DesktopMgr.right_click_pass = 0       --右键过牌，0.关闭,1.开启
DesktopMgr.tile_prefer = 0            --牌面偏好，0.普通， 1.带数字

DesktopMgr.BAIDA_COUNT = 13

function DesktopMgr:Init(transform)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    self.Inst = o
    o:Build(transform)
end

function DesktopMgr:Build(transform)
    -- TODO 这一坨实际不应该存在，用到的地方直接去 Model 取就可以了，热更保险起见先没改
    DesktopMgr.click_prefer = PrefSettingModel:GetCardPlayingClickMode()
    DesktopMgr.double_click_pass = PrefSettingModel:GetIsDoubleClickPassOn() and 1 or 0
    DesktopMgr.right_click_pass = PrefSettingModel:GetIsRightClickPassOn() and 1 or 0
    DesktopMgr.tile_prefer = PrefSettingModel:GetIsTileMarkOn() and 1 or 0

    self.operation_showing = false
    self.timerMgr = TimerMgr:Init()
    self.chainActionTimerMgr = TimerMgr:Init()
    self.chainTimer = TimerMgr:Init()

    ---General
    self.active = false

    self.duringReconnect = false
    self.paipu_config = 0           --一个int，在看牌谱时候可以带入特殊参数, 1:报番界面是否逐条显示
    self.player_link_state = {}
    for i = 1, 4 do
        table.insert(self.player_link_state, ELink_State.NULL)
    end
    self.effect_pai_canchi = nil    --吃牌特效
    self.effectMakaHelperTip = nil    -- 分析副露指示
    self.effect_shadow = nil        --在模型下的影子
    self.gameing = false            --处于游戏中
    self.player_count = function() end

    --Preferences
    self.bianjietishi = true        --是否开启便捷提示
    self.mjp_res_name = 'mjp_default'          --麻将牌资源名称
    self.auto_liqi = Tools.getplayerprefshandler().GetInt('auto_liqi', 1) == 1  --自动理牌
    self.auto_hule = false          --自动胡牌
    self.auto_moqie = false         --自动摸切
    self.auto_babei = false         --自动拔北
    self.auto_nofulu = false        --不要鸣牌

    ---@type ViewPlayer[]
    self.players = {}
    ---@type table|IAccount[]|IRecordGame_AccountInfo[]
    self.player_datas = {}
    self.player_datas_temp = {}
    ---@type IPlayer_Effect[]
    self.player_effects = {}

    ---MJ
    self.index_chang = -1          --场风
    self.index_ju = -1              --局 东1
    self.index_ben = -1             --本场
    self.index_player = -1          --当前轮到谁操作
    self.tingpais = {}              --MJPai[]
    self.md5 = ''
    self.sha256 = ''                -- 替代md5的字符串，如果该字段有值，则md5字段无效，牌山明文中会包含手牌明文
    self.saltSha256 = ''            -- 牌山字符串的加的盐的sha
    self.rule_mode = ERule_Mode.Liqi4
    ---@type IGameConfig
    self.game_config = nil
    self.myaccountid = -1
    self.mode = EMJ_Mode.play
    self.seat = 1                   --我的位置
    self.left_tile_count = -1       --剩余牌
    self.dora = {}                  --外朵拉
    self.hang_up_count = 0          --挂机次数
    self.num_left_show = {}         --剩余牌数
    self.num_left_show_en = {}      --剩余牌数
    self.plane_chang = nil          --场风的面片renderer
    self.plane_ju = nil             --局 的面片renderer
    ---@type ViewPai
    self.lastqipai = nil            --上一张弃牌
    self.lastqipai_seat = -1        --打出上一张弃牌的玩家位置
    self.choosed_pai = nil          --MJPai 选中的牌
    self.waiting_lingshang_deal_tile = false
    self.last_gang = 0              --上一次杠牌的时间
    self.liqi_select = {}           --立直的可选牌
    self.ptchange = 0               --delta段位点数
    self.misc_opens = {}                 --血战自摸的牌，用来计数
    self.liqibang_count = -1        --立直棒数量
    ---Game
    ---@type IGameEndResult
    self.game_end_result = nil
    self.level_change_info = nil
    self.activity_reward = nil      --活动奖励，游戏结束后显示
    self.reward_info = nil
    self.badge_info = nil           --高光时刻徽章进度更新
    self.time_stopped = false       --游戏暂停
    --- @type table<number, DesktopMgr.BestHuData> 
    self.bestHuDataMap = {}   -- 本场的最佳和牌数据
    ---@type IXiaKeShangInfo
    self.xiakeshangInfo = nil

    ---@type number 强夺之战 进贡状态， 0表示未处于换牌中，1表示在进贡，2表示在还供
    self.tributeState = 0
    
    -- Voice
    ---@class ILastRoundRecord
    ---@field hule boolean 是否和了
    ---@field zimo boolean 是否自摸
    ---最后一局的胡牌状态，使用
    ---@type ILastRoundRecord[]
    self.lastRoundRecord = {}
    self.extraGameSoundPlay = -1 -- 用来获取是否播放，app无法停止指定id的音效，标记用
    self.isPlayedPrepareAudio = false

    --Paipu
    self.record_show_hand = Tools.getplayerprefshandler().GetInt('record_show_hand', 1) == 1          --显示手牌
    self.record_show_paopai = Tools.getplayerprefshandler().GetInt('record_show_paopai', 1) == 1      --显示铳牌
    self.record_show_anim = Tools.getplayerprefshandler().GetInt('record_show_anim', 1) == 1          --显示动画
    --Live
    self.live_show_hand = true      --显示手牌
    self.live_show_paopai = true    --显示铳牌
    self.live_follow_dealer = false    --跟随庄家
    -- paipu & live
    self.record_show_tingpai = Tools.getplayerprefshandler().GetInt('record_show_tingpai', 0) == 1    --显示听牌

    ---Actions
    self.oplist = {}
    self.current_step = 0
    self.pt_change = 0
    self.actionList = {}
    self.action_running = false
    self.action_index = 1
    self.do_action_cd = 0           --下一个action可以执行的时间
    self.do_chain_fast = false
    self.handles_after_timerun = {} --时间开始之后，我该有的调用
    self.actionMap = {}
    self.actionMap.ActionMJStart = function(data)
        LogTool.Info('Desktop', 'ActionMJStart begin')
        local msg = data.msg
        self:ClearOperationShow(true)
        GameMgr.Inst:EnterMJ()
        UIMgr.Inst:ShowUI(UI_FightBegin.className, nil, function()
            UIMgr.Inst:CloseUIByClassName(UI_Loading.className)
            self:ActionRunComplete()
        end)
        return 2
    end
    self.actionMap.ActionNewCard = function (data)
        LogTool.Info('Desktop', 'ActionNewCard begin')
        self:ClearOperationShow(true)
        local msg = data.msg
        local fast = data.fast
        UIMgr.Inst:CloseUIByClassName(UI_Loading.className)
        GameMgr.Inst:EnterMJ()
        if fast then
            ActionNewCard.FastPlay(msg)
            return 0
        else
            return ActionNewCard.Play(msg)
        end
    end
    self.actionMap.ActionFillAwaitingTiles = function (data)
        LogTool.Info('Desktop', 'ActionFillAwaitingTiles begin')
        self:ClearOperationShow(true)
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionFillAwaitingTiles.FastPlay(msg)
            return 0
        else
            return ActionFillAwaitingTiles.Play(msg)
        end
    end
    self.actionMap.ActionNewRound = function(data)
        MJNetMgr.Inst:ResetLog()
        LogTool.Info('Desktop', 'ActionNewRound begin')
        local msg = data.msg
        local fast = data.fast

        self:OnNewRound()
        
        self:ClearOperationShow(true)
        
        UIMgr.Inst:CloseUIByClassName(UI_Loading.className)
        GameMgr.Inst:EnterMJ()
        if fast then
            UIMgr.Inst:CloseUIByClassName(UI_FightBegin.className)
            ActionNewRound.FastPlay(msg, -1)
            return 0
        else
            UIMgr.Inst:CloseUIByClassName(UI_FightBegin.className)
            local waittime = UI_FightBegin.waitTime
            self.timerMgr:Delay(waittime + 0.2, function()
                ActionNewRound.Play(msg)
                -- self:Reset()
            end)
            if msg.al and msg.al ~= '' then
                waittime = waittime + 1.3
            end
            return waittime + 0.2 + 1.2 + 0.4
        end
    end
    self.actionMap.ActionChangeTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionChangeTile.FastPlay(msg, -1)
            return 0
        else
            local waittime = ActionChangeTile.Play(msg)
            return waittime
        end
    end
    self.actionMap.ActionSubmit = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionSubmit.FastPlay(msg, -1)
            return 0
        else
            local waittime = ActionSubmit.Play(msg)
            return waittime
        end
    end
    self.actionMap.ActionTake = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionTake.FastPlay(msg, -1)
            return 0
        else
            local waittime = ActionTake.Play(msg)
            return waittime
        end
    end
    self.actionMap.ActionSelectGap = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionSelectGap.FastPlay(msg, -1)
            return 0
        else
            local waittime = ActionSelectGap.Play(msg)
            return waittime
        end
    end
    self.actionMap.ActionDiscardTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionDiscardTile.FastPlay(msg, -1)
            return 0
        else
            local extra_delay_time = ActionDiscardTile.Play(msg) or 0.5
            self.timerMgr:Delay(extra_delay_time, function()
                self:ActionRunComplete()
            end)
            return extra_delay_time
        end
    end
    self.actionMap.ActionDealTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionDealTile.FastPlay(msg, -1)
            return 0
        else
            local extra_delay_time = ActionDealTile.Play(msg) or 0.5
            return extra_delay_time
        end
    end
    self.actionMap.ActionChiPengGang = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionChiPengGang.FastPlay(msg, -1)
            return 0
        else
            ActionChiPengGang.Play(msg)
            return 0.5 + 0.6
        end
    end
    self.actionMap.ActionAnGangAddGang = function(data)
        LogTool.Info('Desktop', 'ActionGang: ' .. pt.block(data.msg))
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionAnGangAddGang.FastPlay(msg, -1)
            return 0
        else
            ActionAnGangAddGang.Play(msg)
            return 0.5 + 0.6
        end
    end
    --杠完打点为负
    self.actionMap.ActionGangResult = function(data)
        LogTool.Info('Desktop', 'ActionGangResult: ' .. pt.block(data.msg))
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionGangResult.FastPlay(msg, -1)
            return 0
        else
            ActionGangResult.Play(msg)
            return 0.5
        end
    end
    self.actionMap.ActionGangResultEnd = function(data)
        LogTool.Info('Desktop', 'ActionGangResult end: ' .. pt.block(data.msg))
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        self:UpdateBestHuInfo(msg.hules_history)
        if fast then
            ActionGangResultEnd.FastPlay(msg, -1)
            return 0
        else
            ActionGangResultEnd.Play(msg)
            return 0.5
        end
    end
    self.actionMap.ActionHule = function(data)
        MJNetMgr.Inst:CollectLog()
        self:ClearOperationShow()
        local msg = data.msg
        self:UpdateBestHuInfo(msg.hules)
        ActionHule.Play(msg)
        return 5
    end
    self.actionMap.ActionHuleXueZhanMid = function(data)
        MJNetMgr.Inst:CollectLog()
        self:ClearOperationShow(true)
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionHuleXueZhanMid.FastPlay(msg, -1)
            return 0
        else
            ActionHuleXueZhanMid.Play(msg)
            return 2
        end
    end

    self.actionMap.ActionHuleXueZhanEnd = function(data)
        MJNetMgr.Inst:CollectLog()
        self:ClearOperationShow(true)
        local msg = data.msg
        self:UpdateBestHuInfo(msg.hules_history)
        ActionHuleXueZhanEnd.Play(msg)
        return 2 + 5 --TODO
    end

    self.actionMap.ActionNoTile = function(data)
        MJNetMgr.Inst:CollectLog()
        self:ClearOperationShow()
        local msg = data.msg
        self:UpdateBestHuInfo(msg.hules_history)
        ActionNoTile.Play(msg)
        return 5
    end
    self.actionMap.ActionLiuJu = function(data)
        MJNetMgr.Inst:CollectLog()
        self:ClearOperationShow()
        local msg = data.msg
        self:UpdateBestHuInfo(msg.hules_history)
        ActionLiuJu.Play(msg)
        return 5
    end
    self.actionMap.ActionBaBei = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionBaBei.FastPlay(msg, -1)
            return 0
        else
            ActionBaBei.Play(msg)
            return 1
        end
    end
    self.actionMap.ActionRevealTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionRevealTile.FastPlay(msg, -1)
            return 0
        else
            ActionRevealTile.Play(msg)
            self.timerMgr:Delay(0.5, function()
                self:ActionRunComplete()
            end)
            return 1
        end
    end
    self.actionMap.ActionUnveilTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionUnveilTile.FastPlay(msg, -1)
            return 0
        else
            ActionUnveilTile.Play(msg)
            return 1
        end
    end
    self.actionMap.ActionLockTile = function(data)
        self:ClearOperationShow()
        local msg = data.msg
        local fast = data.fast
        if fast then
            ActionLockTile.FastPlay(msg, -1)
            return 0
        else
            ActionLockTile.Play(msg)
            return 1
        end
    end

    MJNetMgr.Inst:AddMsgListener('NotifyGameEndResult', function(msg)
        self.game_end_result = msg.result
        for i = 1, #self.game_end_result.players do
            self.game_end_result.players[i].seat = self.game_end_result.players[i].seat + 1
        end
        UI_Lobby.Inst.pending_fetch_activities = true
        UI_DesktopInfo.Inst.network_delay:CloseRefresh()
        TimeMgr.Delay(3, function()
            MJNetMgr.Inst:Close()
            LiveNetMgr.Inst:Close()
        end)
    end)
    MJNetMgr.Inst:AddMsgListener('ActionPrototype', function(msg)
        if self.duringReconnect then
            table.insert(self.actionList, msg)
        else
            if #self.actionList > 0 then
                table.insert(self.actionList, msg)
            else
                table.insert(self.actionList, msg)
                local t = self.do_action_cd - UnityEngine.Time.time
                if t < 0 then t = 0 end
                self:StartChainAction(t)
            end
        end
    end)

    LobbyNetMgr.AddMsgListener('NotifyGameFinishRewardV2', function(msg)
        LogTool.Info('Desktop', 'NotifyGameFinishRewardV2: ' .. pt.block(msg))
        self.level_change_info = msg.level_change
        self.reward_info = msg
    end)
    LobbyNetMgr.AddMsgListener('NotifyActivityRewardV2', function(msg)
        LogTool.Info('Desktop', 'NotifyActivityRewardV2: ' .. pt.block(msg))
        self.activity_reward = msg.activity_reward
    end)
    LobbyNetMgr.AddMsgListener('NotifyAccountUpdate', function(msg)
        LogTool.Info('Desktop', 'NotifyAccountUpdate: ' .. pt.block(msg))
        self:UpdateBadgeInfo(msg)
    end)
    MJNetMgr.Inst:AddMsgListener('NotifyGameFinishReward', function(msg)
        LogTool.Info('Desktop', 'NotifyGameFinishReward: ' .. pt.block(msg))
        self.level_change_info = msg.level_change
        self.reward_info = msg
    end)
    MJNetMgr.Inst:AddMsgListener('NotifyActivityReward', function(msg)
        LogTool.Info('Desktop', 'NotifyActivityReward: ' .. pt.block(msg))
        self.activity_reward = msg.activity_reward
    end)
    MJNetMgr.Inst:AddMsgListener('NotifyGameTerminate', function(msg)
        LogTool.Info('Desktop', 'NotifyGameTerminate: ' .. pt.block(msg))
        AudioMgr.StopMusic()
        if msg.reason ~= 'user-manual-terminate' then
            if UIMgr.Inst:IsUIActive(UI_MJVoteEnd.className) then
                UIMgr.Inst:CloseUIByClassName(UI_MJVoteEnd.className)
            end
            UITool.ShowSecondConfirmConfirmOnly(Tools.StrOfLocalization(2227), function()
                self:Reset()
                Scene_MJ.Inst:GameEnd()
            end)
        end
    end)
    MJNetMgr.Inst:AddMsgListener('NotifyGamePause', function(msg)
        LogTool.Info('Desktop', 'NotifyGamePause')
        self:SetGameStop(msg.paused)
    end)
    MJNetMgr.Inst:AddMsgListener('PlayerLeaving', function(msg)
        if msg and msg.seat + 1 == self.seat then
            UIMgr.Inst:ShowUI(UI_HangUpWarn.className)
        end
    end)

    -- 上次牌谱快速操作时间
    self.paipuLastQuickOperationTime = 0
    -- 牌谱快速操作最短间隔
    self.paipuQuickOperationCd = 50

    ----Load
    self:Load(transform)
end

function DesktopMgr:Load(transform)
    self.transform = transform
    self.transform.gameObject:SetActive(false)
    self.desktop = self.transform:Find('room')
    self.desktop:Find('all').gameObject:SetActive(false)
    self.reveal_discard_liqibang_num = nil
    local maqueContainer = self.desktop:Find('all')
    self.templeteMaque = maqueContainer:GetChild(0)
    self.maquepool = {}
    self.poss = self.desktop:Find('poss')
    self.players = {}
    ---@type ViewPlayer_Me
    self.mainrole = ViewPlayer_Me:_Init(1,
        Scene_MJ.Inst.desktop_hand:Find('root'):Find('hands'),
        self.poss:Find('ming_1'):GetChild(0),
        self.poss:Find('hai_1'):GetChild(0),
        self.poss:Find('man_1'),
        self.poss:Find('babei_1'):GetChild(0),
        self.poss:Find('changetile_1'):GetChild(0),
        self.poss:Find('tributetile_1'),
        Scene_MJ.Inst.desktop_hand:Find('root_full')
    )
    table.insert(self.players, self.mainrole)

    for i = 2, 4 do
        ---@type ViewPlayer_Other
        local p = ViewPlayer_Other:_Init(i,
            self.poss:Find('pai_'..tostring(i)):GetChild(0),
            self.poss:Find('ming_'..tostring(i)):GetChild(0),
            self.poss:Find('hai_'..tostring(i)):GetChild(0),
            self.poss:Find('man_'..tostring(i)),
            self.poss:Find('babei_'..tostring(i)):GetChild(0),
            self.poss:Find('changetile_'..tostring(i)):GetChild(0),
            self.poss:Find('tributetile_'..tostring(i)),
            Scene_MJ.Inst.desktop_hand:Find('root_full')
        )
        table.insert(self.players, p)
    end
    self.num_left_show = {}
    local trans_container_other = self.desktop:Find('other')
    local _trans_left = trans_container_other:Find('left')
    table.insert(self.num_left_show, _trans_left:Find('0'):GetComponent(typeof(UnityEngine.MeshRenderer)))
    table.insert(self.num_left_show, _trans_left:Find('1'):GetComponent(typeof(UnityEngine.MeshRenderer)))
    local _trans_chang = trans_container_other:Find('chang')
    self.plane_chang = _trans_chang:Find('chang'):GetComponent(typeof(UnityEngine.MeshRenderer))
    self.plane_ju = _trans_chang:Find('ju'):GetComponent(typeof(UnityEngine.MeshRenderer))
    self.plane_juzi = _trans_chang:Find('juzi'):GetComponent(typeof(UnityEngine.MeshRenderer))

    if GameMgr.Inst.prefer_language == 'kr' then
        self.plane_chang.sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/chang_kr')
        self.plane_ju.sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/ju')
        self.plane_juzi.sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/chang_kr')
        _trans_left:Find('left'):GetComponent(typeof(UnityEngine.MeshRenderer)).sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/word_left_kr')
        _trans_left:Find('left'):SetLocalScale(0.002, 0.002, 1)
    end
    self.num_left_show_en = {}
    local trans_container_other_en = self.desktop:Find('other_en')
    local _trans_left_en = trans_container_other_en:Find('left')
    table.insert(self.num_left_show_en, _trans_left_en:Find('0'):GetComponent(typeof(UnityEngine.MeshRenderer)))
    table.insert(self.num_left_show_en, _trans_left_en:Find('1'):GetComponent(typeof(UnityEngine.MeshRenderer)))
    local _trans_chang_en = trans_container_other_en:Find('chang')
    self.plane_chang_en = _trans_chang_en:Find('chang'):GetComponent(typeof(UnityEngine.MeshRenderer))
    self.plane_ju_en = _trans_chang_en:Find('ju'):GetComponent(typeof(UnityEngine.MeshRenderer))

    self:_setLeftPaiShow(0)
    self:_setChangJuShow(0, 0)

    self.trans_container_effect = self.desktop:Find('effect')
    self.effect_pai_canchi = self.trans_container_effect:Find('effect_pai_canchi')
    self.effect_pai_canchi.gameObject:SetActive(true)
    self.effectMakaHelperTip = self.trans_container_effect:Find("EffectMakaHelperTip")
    self.effectMakaHelperTip.gameObject:SetActive(false)
    self.effect_shadow = self.trans_container_effect:Find('effect_shadow')
    self.effect_shadow.gameObject:SetActive(true)
end

function DesktopMgr:ResetMaque(transform)
    transform:SetParent(self.desktop:Find('all'))
    transform:Find('effect_dora').gameObject:SetActive(false)
    transform:SetLocalPos(1.337, 0, -0.029)
    transform:SetLocalEuler(0, 0, 0)
    transform:SetLocalScale(1, 1, 1)
    pcall(function()
        for i = 1, transform.childCount do
            local child = transform:GetChild(i - 1)
            if Tools.StringContain(child.name, 'effect_liqi')
                or Tools.StringContain(child.name, 'effect_tuowei') then
                UnityEngine.GameObject.Destroy(child.gameObject)
            end
        end
    end)
    table.insert(self.maquepool, transform)
end

function DesktopMgr:SetGameStop(bool)
    if p == self.time_stopped then return end
    self.time_stopped = bool
    if self.time_stopped then
        self.handles_after_timerun = {}
        UIMgr.Inst:ShowUI(UI_GameStop.className)
    else
        UIMgr.Inst:CloseUIByClassName(UI_GameStop.className)
        if #self.handles_after_timerun > 0 then
            for i = 1, #self.handles_after_timerun do
                self.handles_after_timerun[i]()
            end
        end
        self.handles_after_timerun = {}
        self.hang_up_count = 0
    end
end

function DesktopMgr:ShowYiManEffect(data)
    AudioMgr.PlayAudio(262)
    self.playing_yiman_effect = true
    local fan_name = ExcelMgr.GetData('fan', 'fan', data.yiman_type).sound
    local audios = ExcelMgr.GetTable('audio', 'audio')
    local sound_data
    for key, value in pairs(audios) do
        local splits = Tools.Split(value.path, '/')
        local file_name = splits[#splits]
        if value and fan_name == file_name then
            sound_data = value
        end
    end
    if sound_data then
        TimeMgr.Delay(sound_data.time_length / 1000 + 0.15, function()
            AudioMgr.PlayAudioByPath(sound_data.path, 1)
        end)
    end

    self.timerMgr:Delay(0.15, function()
        local posX = data.pos.x
        local posY = data.pos.y
        local posZ = data.pos.z

        local _model = data.model
        local seat = data.seat
        local handpais = data.handpais
        
        local effect_baodian = LuaTools.LoadPrefab('scenes/mj/effect_yiman/main/prefab/effect_baodian', self.effectRoot)
        effect_baodian.transform:SetPos(posX, posY, posZ)
        
        local effect_tuowei = LuaTools.LoadPrefab('scenes/mj/effect_yiman/main/prefab/effect_tuowei', self.effectRoot)
        effect_tuowei.transform:SetParent(_model)
        effect_tuowei:ResetTransform()
        effect_baodian.gameObject:SetActive(true)
        TimeMgr.DelayFrame(25, function()
            effect_tuowei.gameObject:SetActive(true)
        end)

        local tweener0 = _model:DOShakeRotation(150 / 60, Vector3(20, 20, 20))
        tweener0:SetEase(DG.Tweening.Ease.InExpo)

        if data.zimo then
            _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y, _model.localPosition.z - 0.02), 2):SetEase(DG.Tweening.Ease.OutBack)
            _model.parent.parent:Find('effect_shadow(Clone)').gameObject:SetActive(false)
            TimeMgr.DelayFrame(45, function()
                TimeMgr.Delay(0.1, function()
                    _model:DOLocalRotate(Vector3(90, 180, 0), 0.5)
                end)
                TimeMgr.Delay(0.09, function()
                    tweener0:Kill()
                end)
                -- _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y, _model.localPosition.z), 0.5)
            end)
            TimeMgr.Delay(78 / 60 + 0.1, function()
                _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y, _model.localPosition.z - 0.653), 0.6):SetEase(DG.Tweening.Ease.InExpo)
            end)
        else
            _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y - 0.02, _model.localPosition.z), 2):SetEase(DG.Tweening.Ease.OutBack)
            _model:Find('effect_shadow').gameObject:SetActive(false)
            TimeMgr.DelayFrame(45, function()
                TimeMgr.Delay(0.1, function()
                    _model:DOLocalRotate(Vector3(179, 1, 1), 0.5)
                end)
                TimeMgr.Delay(0.09, function()
                    tweener0:Kill()
                end)
                -- _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y, _model.localPosition.z + 0.02), 0.5)
            end)
            TimeMgr.Delay(78 / 60 + 0.1, function()
                _model:DOLocalMove(Vector3(_model.localPosition.x, _model.localPosition.y - 0.653, _model.localPosition.z), 0.6):SetEase(DG.Tweening.Ease.InExpo)
            end)
        end

        TimeMgr.Delay(5, function()
            pcall(function()
                UnityEngine.GameObject.Destroy(effect_baodian.transform.gameObject)
            end)
            pcall(function()
                UnityEngine.GameObject.Destroy(effect_tuowei.transform.gameObject)
            end)
        end)

        local yiman_asset_name = ExcelMgr.GetData('fan', 'fan', data.yiman_type).sound
        local folder_path = string.sub(yiman_asset_name, 5)
        if #handpais > 14 then yiman_asset_name = yiman_asset_name .. '18' end
        local lang_folder = GameMgr.Inst.prefer_language
        local effect_yiman = LuaTools.LoadPrefab('scenes/mj/effect_yiman/' .. folder_path .. '/' .. lang_folder .. '/prefab/' ..yiman_asset_name, self.effectRoot)
        local camera_clamp

        xpcall(function()
            camera_clamp = CameraClamp:Init(
                effect_yiman:Find('camera'):Find('dapai_camera_gensui'):GetComponent(typeof(UnityEngine.Camera)),
                16 / 9, 23 / 9)
            -- effect camera 有单独的比例限制，bg camera 和 main camera保持一致
            CameraRatioLimitAreaMgr.AddCamera(effect_yiman:Find('camera/bg_cam'):GetComponent(typeof(UnityEngine.Camera)))
        end, function()
            UI_ErrorInfo.HandleInfo('effect_yiman LoadFailed: '..'prefab/effect_yiman/'..GameMgr.Inst.prefer_language..'/'..yiman_asset_name, 'ui')
        end)

        pcall(function()
            effect_yiman:Find('dapai_beijing_amin').transform:SetLocalScale(1.01, 1, 1)
        end)

        local canvas = effect_yiman.transform:Find('renwu_anim'):Find('Canvas')
        pcall(function()
            UnityEngine.GameObject.Destroy(effect_yiman.transform:Find('renwu_anim'):Find('canying').gameObject)
        end)
        local new_mask = UnityEngine.GameObject.Instantiate(canvas:Find('container_illust'):Find('illust'), canvas.transform)
        new_mask.name = 'mask'
        new_mask:GetComponent(typeof(UnityEngine.UI.Image)):SetColor(1,1,1,0)
        new_mask.transform:SetLocalScale(1000, 1000, 1000)

        local chara_skin = UI_Character_Skin:Init(effect_yiman.transform:Find('renwu_anim'):Find('Canvas'):Find('container_illust'):Find('illust'):GetComponent(typeof(UnityEngine.UI.Image)))
        local chara_skin_canying = UI_Character_Skin:Init(effect_yiman.transform:Find('renwu_anim'):Find('Canvas'):Find('container_illust_canying'):Find('illust'):GetComponent(typeof(UnityEngine.UI.Image)))
        chara_skin:SetType(GameUtility.EIllustType.yiMan)
        chara_skin:SetSkin({ skinId = self.player_datas[self:localPosition2Seat(seat)].character.skin, partName = "full", attachedHead = true, accountId = self.player_datas[self:localPosition2Seat(seat)].account_id, ignoreAnim = true })
        chara_skin_canying:SetSkin({ skinId = self.player_datas[self:localPosition2Seat(seat)].character.skin, partName = "full", attachedHead = true, accountId = self.player_datas[self:localPosition2Seat(seat)].account_id, ignoreAnim = true })
        local pai_coord = self:get_pai_pos(handpais[#handpais])
        -- effect_yiman.transform:Find('hepai_majiang_gensui'):Find('hepai_majiang_anim'):Find('maque'):GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 1)
        local _maque = effect_yiman.transform:Find('hepai_majiang_gensui'):Find('hepai_majiang_anim'):Find('maque')
        if string.match(handpais[#handpais]:ToString(),'[t]') then
            if DesktopMgr.Inst:is_tianming_mode() then
                --天命牌
                if _maque:Find('pai_face') then
                    _maque:Find('pai_face').gameObject:SetActive(false)
                end
                local cover = LuaTools.LoadPrefab('scenes/mj/effect_yiman/maquecommon/common/maque_cover', _maque, true)
                cover.transform.gameObject:SetActive(true)
                cover:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileTint(TileTint_Yellow.r, TileTint_Yellow.g, TileTint_Yellow.b, TileTint_Yellow.a)

                if _maque.transform:Find('mjp_transparent') then
                    _maque.transform:Find('mjp_transparent').gameObject:SetActive(false)
                end
                _maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = true
            else
                --透明牌
                local _face_plane = nil
                if _maque:Find('pai_face') then
                    _face_plane = _maque.transform:Find('pai_face')
                else
                    _face_plane = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/pai_face', _maque)
                    _face_plane.transform.gameObject.name = 'pai_face'
                    _face_plane.transform:SetLocalScale(0.0024,1,0.0033)
                    _face_plane.transform:SetLocalPos(0,0.0012,0.0099)
                    _face_plane.transform:SetLocalEuler(90,90,90)
                end

                _face_plane.transform.gameObject:SetActive(true)
                _face_plane:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 0)
                _face_plane:Find('pai_back'):GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 0)

                local mjp_transparent = nil
                if _maque.transform:Find('mjp_transparent') then
                    mjp_transparent = _maque.transform:Find('mjp_transparent')
                else
                    mjp_transparent = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/mjp_transparent', _maque.transform)
                    mjp_transparent.transform.gameObject.name = 'mjp_transparent'
                    mjp_transparent.transform:SetLocalScale(1,1,1)
                    mjp_transparent.transform:SetLocalPos(0,0,0)
                    mjp_transparent.transform:SetLocalEuler(0,0,0)
                end
                mjp_transparent.transform:SetAsFirstSibling()
                mjp_transparent.gameObject:SetActive(true)
                _maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = false

            end
        else
            if _maque:Find('pai_face') then
                _maque:Find('pai_face').gameObject:SetActive(false)
            end
            if _maque.transform:Find('mjp_transparent') then
                _maque.transform:Find('mjp_transparent').gameObject:SetActive(false)
            end
            _maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = true
        end
        -- _maque:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 1)
        self:setPai3DFace(_maque, pai_coord, handpais[#handpais].baida)


        for i = 0, effect_yiman.transform:Find('dapai_zhengpai_anim').childCount - 1 do
            effect_yiman.transform:Find('dapai_zhengpai_anim'):GetChild(i).transform.gameObject:SetActive(false)
            -- local child = effect_yiman.transform:Find('dapai_zhengpai_anim'):GetChild(i).transform
            -- if Tools.stringContainerSub(child.name, 'maque') then
            -- end
        end
        for i = 1, #handpais do
            local maque = effect_yiman.transform:Find('dapai_zhengpai_anim'):GetChild(i-1)
            maque.transform.gameObject:SetActive(true)
            local prefab = LuaTools.LoadPrefab('scenes/mj/effect_yiman/maquecommon/common/maque_outline', maque)
            prefab.gameObject:SetActive(true)
            prefab:SetLocalScale(1.06, 1.06, 1.06)
            prefab:SetLocalPos(0, 0, 0)

            local _pai_coord = self:get_pai_pos(handpais[i])
            if string.match(handpais[i]:ToString(),'[t]') then
                if DesktopMgr.Inst:is_tianming_mode() then
                    --天命牌
                    if _maque:Find('pai_face') then
                        _maque:Find('pai_face').gameObject:SetActive(false)
                    end
                    local cover = LuaTools.LoadPrefab('scenes/mj/effect_yiman/maquecommon/common/maque_cover', maque, true)
                    cover.transform.gameObject:SetActive(true)
                    cover:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileTint(TileTint_Yellow.r, TileTint_Yellow.g, TileTint_Yellow.b, TileTint_Yellow.a)

                    if maque.transform:Find('mjp_transparent') then
                        maque.transform:Find('mjp_transparent').gameObject:SetActive(false)
                    end
                    maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = true
                else
                    --透明牌
                    local face_plane = nil
                    if maque:Find('pai_face') then
                        face_plane = maque.transform:Find('pai_face')
                    else
                        face_plane = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/pai_face', maque)
                        face_plane.transform.gameObject.name = 'pai_face'
                        face_plane.transform:SetLocalScale(0.0024,1,0.0033)
                        face_plane.transform:SetLocalPos(0,0.0012,0.0099)
                        face_plane.transform:SetLocalEuler(90,90,90)
                    end

                    face_plane.transform.gameObject:SetActive(true)
                    face_plane:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(_pai_coord.lx, _pai_coord.ly, _pai_coord.x, _pai_coord.y, 0)
                    face_plane:Find('pai_back'):GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(_pai_coord.lx, _pai_coord.ly, _pai_coord.x, _pai_coord.y, 0)


                    local mjp_transparent = nil
                    if maque.transform:Find('mjp_transparent') then
                        mjp_transparent = maque.transform:Find('mjp_transparent')
                    else
                        mjp_transparent = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/mjp_transparent', maque.transform)
                        mjp_transparent.transform.gameObject.name = 'mjp_transparent'
                        mjp_transparent.transform:SetLocalScale(1,1,1)
                        mjp_transparent.transform:SetLocalPos(0,0,0)
                        mjp_transparent.transform:SetLocalEuler(0,0,0)
                    end
                    mjp_transparent.transform:SetAsFirstSibling()
                    mjp_transparent.gameObject:SetActive(true)
                    maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = false

                end
            else
                if maque:Find('pai_face') then
                    maque:Find('pai_face').gameObject:SetActive(false)
                end
                if maque.transform:Find('mjp_transparent') then
                    maque.transform:Find('mjp_transparent').gameObject:SetActive(false)
                end
                maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = true
            end
            -- maque:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(_pai_coord.lx, _pai_coord.ly, _pai_coord.x, _pai_coord.y, 1)
            self:setPai3DFace(maque, _pai_coord, handpais[i].baida)

        end


        TimeMgr.Delay(2, function()
            effect_yiman.transform.gameObject:SetActive(true)
            chara_skin:ClearWithoutCImage()
            TimeMgr.Delay(8, function()
                self.playing_yiman_effect = false
                UnityEngine.GameObject.Destroy(effect_yiman.transform.gameObject)
            end)
        end)
    end)
end


function DesktopMgr:ShowChiPengEffect()
    if self.lastqipai.model and self.lastqipai.model.transform then
        self.effect_pai_canchi:SetParent(self.lastqipai.model)
        local localPos = self.lastqipai.model.transform.localPosition
        local localRot = self.lastqipai.model.transform.localEulerAngles
        if self.lastqipai.isreveal then
            self.effect_pai_canchi.transform:SetLocalPos(0,0,0.02)
        else
            self.effect_pai_canchi.transform:SetLocalPos(0,0,0)
        end
        self.effect_pai_canchi.transform:SetLocalEuler(0,0,0)
        self.effect_pai_canchi.transform.gameObject:SetActive(true)
    end
end

function DesktopMgr:SetChiPengEffect(item_id)
    local _d
    if item_id then
        _d = ExcelMgr.GetData('item_definition','view',item_id)
    end
    self.trans_container_effect = self.desktop:Find('effect')
    if self.now_effect_mpzs and (not tolua.isnull(self.now_effect_mpzs)) then
        self.now_effect_mpzs.transform.gameObject:SetActive(false)
        UnityEngine.GameObject.Destroy(self.now_effect_mpzs.transform.gameObject)
    end
    if _d then
        self.now_effect_mpzs = LuaTools.LoadPrefab('deco/effect_mingpaizhishi/' .. _d.res_name .. "/3d/prefab/" .. _d.res_name, self.effect_pai_canchi.transform)
        -- self.effect_pai_canchi.transform:Find()
    else
        self.now_effect_mpzs = LuaTools.LoadPrefab('deco/effect_mingpaizhishi/effect_zhishi/3d/prefab/effect_zhishi', self.effect_pai_canchi.transform)
    end
    self.now_effect_mpzs.transform.gameObject:SetActive(true)
    -- self.effect_pai_canchi.localRotation = Vector3(-90,0,0)
end

function DesktopMgr:TryPlayBeginEffect()
    if self.index_chang == 1 and self.index_ju == 1 and self.index_ben == 0 then
        local effect_name

        local is_dianfeng = function()
            local mode_id = 0
            if self.game_config and self.game_config:HasField('meta') then
                mode_id = self.game_config.meta.mode_id
            end
            if (mode_id == 15 or mode_id == 16 or mode_id == 25 or mode_id == 26) and self.player_datas then
                for i = 1, #self.player_datas do
                    local player = self.player_datas[i]
                    local level = player.level.id
                    if self.rule_mode ~= ERule_Mode.Liqi4 then
                        level = player.level3.id
                    end
                    if ExcelMgr.GetData('level_definition', 'level_definition', level).primary_level ~= 6 then
                        return false
                    end
                end
                return true
            end
            return false
        end

        if self.game_config and
            self.game_config.mode and
            self.game_config.mode.detail_rule then
            local lang_suffix = GameMgr.Inst.prefer_language
            if self.game_config.meta.mode_id == 36 then
                effect_name = 'scenes/mj/game_mode/shilianzhidao/prefab/effect_shilianzhidao_'..lang_suffix
            elseif is_dianfeng() then
                effect_name = 'scenes/mj/effect_mj/locallize/' .. lang_suffix .. '/prefab/effect_dianfengduijue_'..lang_suffix
            elseif self:is_muyu_mode() then
                effect_name = 'scenes/mj/game_mode/longzhimuyu/prefab/effect_longzhimuyu_'..lang_suffix
            elseif self:is_chuanma_mode() then
                if self.ju_count == 1 then
                    effect_name = 'scenes/mj/game_mode/chiyuzhizhan/prefab/effect_chiyuzhizhan_'..lang_suffix
                end
            else
                for key, value in pairs(GameUtility.ESpecialModeRule) do
                    if self.game_config.mode.detail_rule[key] == 1 or self:IsTargetSpecialMode(GameUtility.EMJGameRule[key]) then
                        effect_name = 'scenes/mj/game_mode/' .. value .. '/prefab/effect_' .. value .. '_'..lang_suffix
                        break
                    end
                end
            end
        end

        if effect_name then
            UI_DesktopInfo.Inst:ShowEffect(effect_name, 50, 'dora3_begin')
            AudioMgr.PlayAudio(243)
            return true
        end
    end
    return false
end

function DesktopMgr:CloseChiPengEffect()
    self.effect_pai_canchi.transform.gameObject:SetActive(false)
    self.effect_pai_canchi.transform:SetParent(self.trans_container_effect)
end

-- 刷新团队赛相关表现
function DesktopMgr:RefreshPartyShow()
    if (not self.matchInfo or not self.matchInfo.isPartyMatch or not self.partyRoot) then return end

    for _, mesh in ipairs(self.partyNameMeshList) do
        mesh.gameObject:SetActive(false)
    end
    for i, player in ipairs(self.player_datas) do
        if (player.team_name and player.team_name ~= "") then
            local relativePos = 1
            if (i == self.seat) then
                relativePos = 1
            elseif (i > self.seat) then
                relativePos = i - self.seat + 1
            else
                relativePos = i + 5 - self.seat
            end
            self.partyNameMeshList[relativePos].gameObject:SetActive(true)
            -- 做屏蔽词判断
            if (self.matchInfo.needHandleForbidden) then
                self.partyNameItemList[relativePos].textName.text = Tools.StrContainsForbidden(player.team_name) and Tools.StrOfLocalization(25090114) or player.team_name
            else
                self.partyNameItemList[relativePos].textName.text = player.team_name
            end

        end
    end
end

-- 设置炮牌的mat为ztest off
function DesktopMgr.SetPaopaiZtestNew(paopai, delay, duration, custom_renderque, ztestType)
    if not paopai then
        return
    end
    if (not ztestType) or (ztestType <= 0) then
        return
    end
    delay = delay or 0
    duration = duration or 1.8
    custom_renderque = custom_renderque or {3090, 3090, 3090}
    local render = paopai.model:GetComponent(typeof(UnityEngine.MeshRenderer))
    local origin_mats = render.materials

    local midZtest = 'mjp_mid_zteston'
    local faceZtest = 'mjp_face_zteston'
    if ztestType == EZtestType.center then
        midZtest = 'mjp_mid_zteston'
        faceZtest = 'mjp_face_zteston'
    elseif ztestType == EZtestType.top then
        midZtest = 'mjp_mid_ztestoff'
        faceZtest = 'mjp_face_ztestoff'
    else
        return
    end

    local m1 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/'..midZtest)
    m1.renderQueue = custom_renderque[1]
    local m2 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/'..faceZtest)
    m2.renderQueue = custom_renderque[2]

    -- local m3 = LuaTools.LoadMaterial('mjpai/mjp_back_ztestoff')
    -- m3.renderQueue = custom_renderque[3]
    m1:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
    m1:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
    m2:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
    m2.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
    -- 改为在销毁后不触发
    DesktopMgr.Inst.timerMgr:Delay(delay, function ()
        render.sharedMaterials = {m1,m2}
    end)
    --特效结束后还原mat
    DesktopMgr.Inst.timerMgr:Delay(delay + duration, function ()
        render.sharedMaterials = origin_mats
    end)
end


-- 设置炮牌的mat为ztest off
function DesktopMgr.SetPaopaiZtest(paopai, delay, duration, custom_renderque)
    if not paopai then
        return
    end
    delay = delay or 0
    duration = duration or 1.8

    custom_renderque = custom_renderque or {3005, 3006, 3004}
    local render = paopai.model:GetComponent(typeof(UnityEngine.MeshRenderer))
    local origin_mats = render.materials
    local m1 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_mid_zteston')
    m1.renderQueue = custom_renderque[1]
    local m2 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_face_zteston')
    m2.renderQueue = custom_renderque[2]
    -- local m3 = LuaTools.LoadMaterial('mjpai/mjp_back_ztestoff')
    -- m3.renderQueue = custom_renderque[3]
    m1:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
    m1:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
    m2:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
    m2.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
    DesktopMgr.Inst.timerMgr:Delay(delay, function ()
        render.materials = {m1,m2}
    end)
    --特效结束后还原mat
    DesktopMgr.Inst.timerMgr:Delay(delay + duration, function ()
        render.materials = origin_mats
    end)
end

--- @class ShowHuleEffect.Param
--- @field pos table UnityEngine.Vector3
--- @field seat table UnityEngine.Vector3
--- @field model UnityEngine.GameObject
--- @field yiman_type number
--- @field handpais MJPai[]
--- @field zimo boolean

--- @param transform ShowHuleEffect.Param
--- @param zimo_pai HandPai3D
--- @param effect_info IEffect_Hupai
--- @param prewarm boolean 是否预热（预加载）
function DesktopMgr:ShowHuleEffect(transform, effect_info, zimo_pai, prewarm)
    if not effect_info then
        return
    end
    -- test code
    -- effect_info.path = 'prefab/effect_hupai/ron_24imas'

    if self.mode == EMJ_Mode.preview or self.mode == EMJ_Mode.tutorial then
    elseif self.mode ~= EMJ_Mode.play and not self:_record_show_anim() then
        return
    end
    LogTool.Info('Desktop', 'ShowHuleEffect: ' .. pt.block(effect_info))
    --播放役满特效
    self.playing_hule_effect = not prewarm
    if transform.yiman_type and not Tools.IsWebGL() then
        local deltaTime = 0
        deltaTime = deltaTime + Tools.RonDelay(effect_info)
        self.timerMgr:Delay(2 + deltaTime, function()
            self:ShowYiManEffect(transform)
        end)
    end
    local posX = transform.pos.x
    local posY = transform.pos.y
    local posZ = transform.pos.z

    local funcShowEffect = function(effectPrefab)
        if (effectPrefab == nil) then
            local content = {
                name = effect_info.path
            }
            local str = json.encode(content)
            LogStoreUtility.HandleSpecialInfo(str, LogStoreUtility.LogCategory.show_effect_error, false)
            --return
        end
        effectPrefab.transform:SetPos(posX, posY, posZ)
        effectPrefab.gameObject:SetActive(true)

        local audio_id = effect_info.audio_id or 213
        if prewarm then
            AudioMgr.PlayAudio(audio_id, 0)
        else
            AudioMgr.PlayAudio(audio_id)
        end

        local isNewRon = effect_info and effect_info.view and effect_info.view.old_effect_mark ~= 1
        if isNewRon then
            self:setNewHuleEffect(transform, effect_info, zimo_pai, prewarm, posX, posY, posZ, effectPrefab)
        else
            self:setOldHuleEffect(transform, effect_info, zimo_pai, prewarm, posX, posY, posZ, effectPrefab)
        end

        TimeMgr.Delay(2 + 4, function()
            pcall(function()
                if effectPrefab.gameObject then
                    UnityEngine.GameObject.Destroy(effectPrefab.gameObject)
                end
                self.playing_hule_effect = false
                -- if callback then
                --     callback()
                -- end
            end)
        end)
    end
    if (effect_info.seatRelated) then
        -- 座次相关，四个位置全部预热
        for i = 1, 4 do
            local effect = LuaTools.LoadPrefab(effect_info.path .. "_" .. i, self.effectRoot)
            funcShowEffect(effect)
        end
    else
        local effect = LuaTools.LoadPrefab(effect_info.path, self.effectRoot)
        funcShowEffect(effect)
    end
end


--- @param transform ShowHuleEffect.Param
--- @param zimo_pai HandPai3D
--- @param effect_info IEffect_Hupai
--- @param prewarm boolean 是否预热（预加载）
function DesktopMgr:setNewHuleEffect(transform, effect_info, zimo_pai, prewarm, posX, posY, posZ, effect)
    -- 根据命名来进行判断
    -- fx_skill_000_ron\fx_skill_000_liqi （父节点在牌桌中心，不做位移、旋转、缩放。）
    -- root_ani（控制牌的动画，例如saki和牌特效中，牌的旋转动画。）
    -- root_rot（继承牌到位后的位置position和旋转rotation，一般用在牌的发光、和立直等。）
    -- root_move（继承牌到位后的位置，不跟着牌旋转。）
    -- root_static(不做位移、旋转、缩放，用于立绘出现，或一些屏幕固定动画。）

    -- 新的胡牌放到桌面中间，下面的部分按照需求拆出来放到不同部位

    local pai3D = transform.model
    if not pai3D then
        return
    end

    ---@type ViewPai
    local paopai = self.lastqipai
    if zimo_pai then
        paopai = zimo_pai.pai3D
    end

    -- 把特效的原点放到中间
    effect.transform:SetPos(-1000, 0, 0)

    local root_move = effect.transform:Find('root_move') -- root_move（继承牌到位后的位置，不跟着牌旋转。）
    local root_rot = effect.transform:Find('root_rot') -- root_rot（继承牌到位后的位置position和旋转rotation，一般用在牌的发光、和立直等。）
    local root_ani = effect.transform:Find('root_ani') -- root_ani（控制牌的动画，例如saki和牌特效中，牌的旋转动画。） 只要不是抢杠胡就播
    local root_ani_zimo = effect.transform:Find('root_ani_zimo') -- _ani_zimo只有自摸胡才播
    local root_static = effect.transform:Find('root_static') -- root_static(不做位移、旋转、缩放，用于立绘出现，或一些屏幕固定动画。）
    local root_fly = effect.transform:Find('root_fly') -- root_fly(在特效播放n秒后，用时x秒，从A点移动到B点）

    if root_move then -- root_move（继承牌到位后的位置，不跟着牌旋转。）
        root_move.position = pai3D.position
    end

    if root_rot then
        root_rot.position = pai3D.position
        root_rot.rotation = pai3D.rotation
    end

    if root_ani then
        root_ani.position = pai3D.position
        -- root_ani.rotation = pai3D.rotation
    end

    if root_ani_zimo then
        root_ani_zimo.position = pai3D.position
        -- root_ani_zimo.rotation = pai3D.rotation
    end

    if root_static then
        root_static.transform:SetPos(-1000, 0, 0)
    end

    if root_fly then
        local flyMove = root_fly.transform:Find("move")
        local flyPosition = root_fly.transform:Find("positon")
        local cameraAreaPos = nil
        local delay = 0
        local duration = 0

        -- 特判起来了
        if effect_info.view and effect_info.view.id == 308046 then
            cameraAreaPos = Vector3(0.04959141, -0.04958072, 0.2411938)
            delay = 50 * 1 / 60
            duration = 15 * 1 / 60
        end

        if not cameraAreaPos then return end

        local targetPos = Tools.ConvertCameraToWorld(self.transform:Find('camera'),cameraAreaPos,root_fly.transform)

        if flyMove then
            flyMove.position = pai3D.position
            -- 创建动画序列
            local sequence = DG.Tweening.DOTween.Sequence()
            sequence:AppendInterval(delay)
            local tweenMove = DG.Tweening.DOTween.To(
                DG.Tweening.Core.DOGetter_UnityEngine_Vector3(function() return flyMove.localPosition end),
                DG.Tweening.Core.DOSetter_UnityEngine_Vector3(function(newPos)
                    flyMove.localPosition = newPos
                end),
                Vector3(targetPos.x, targetPos.y, targetPos.z), duration)
            sequence:Append(tweenMove)
            sequence:Play()
        end

        if flyPosition then
            flyPosition.position = targetPos
        end
    end

    local isLastMing = DesktopMgr.Inst:IsLastPaiMingPai() -- 上一张牌是不是鸣牌
    local isQiangGang = (not zimo_pai) and isLastMing  -- 上一张鸣牌的情况下自摸就是岭上，非自摸就是抢杠

    local animator_root = root_ani and root_ani:GetComponent(typeof(UnityEngine.Animator))
    local animator_zimo = root_ani_zimo and root_ani_zimo:GetComponent(typeof(UnityEngine.Animator))
    local haveSpecialAni = animator_root or animator_zimo
    -- LogTool.Error('Ronnnn',' ming :'..tostring(isLastMing or false)..' haveSpecialAni :'..tostring(haveSpecialAni or false))
    local animeTime = 1.9
    if (not isQiangGang) and haveSpecialAni then -- 和牌的牌动画特殊，如果是root_ani，那就是普通和自摸都播放牌动画；如果是root_ani_zimo，就只有自摸播放牌动画
        local animator_container
        if zimo_pai and animator_zimo then
            -- 自摸和
            animator_container = animator_zimo
        else
            -- 容和
            animator_container = animator_root
        end
        local _temp = HandPai3D:Init(animator_container.transform:GetChild(0))
        _temp:SetVal(paopai.pai)
        _temp.model.position = paopai.model.position
        _temp.pai3D.model.rotation = paopai.model.rotation

        paopai.model.transform.gameObject:SetActive(false)
        _temp.model.transform.gameObject:SetActive(true)

        local ztestType = effect_info and effect_info.view and effect_info.view.sargs and
            tonumber(effect_info.view.sargs[2])

        -- 临时牌要放在特效上方
        if ztestType and ztestType > 0 then
            local duration_time = 2.5
            local delay_data = ExcelMgr.GetData("outfit_config", "ron", effect_info.view.id)
            if delay_data and delay_data.queue_change_delay and tonumber(delay_data.queue_change_delay) > 0 then
                duration_time = delay_data.queue_change_delay / 1000
            elseif tonumber(effect_info.view.sargs[1]) then
                duration_time = tonumber(effect_info.view.sargs[1]) / 1000 + 2.0
            end
            DesktopMgr.SetPaopaiZtestNew(_temp.pai3D, 0, duration_time, nil, ztestType)
        end

        local clips = animator_container.runtimeAnimatorController.animationClips;
        if nil ~= clips and clips.Length > 0 then
            for j = 0, clips.Length - 1 do
                local clip = clips:GetValue(j)
                if clip ~= nil then
                    LogTool.Info('DesktopMgr ','setNewHuleEffect clip.name :'..tostring(clip.name)..' clip.length :'..clip.length)
                    animeTime = clip.length
                    break
                end
            end
        end
        TimeMgr.Delay(animeTime, function()
            pcall(function()
                paopai.model.transform.gameObject:SetActive(true)
                _temp.model.transform.gameObject:SetActive(false)
            end)
            _temp:Destroy()
        end)
    end

    effect.gameObject:SetActive(true)

    -- 麻将在特效上层的情况
    local ztestType = effect_info and effect_info.view and effect_info.view.sargs and
        tonumber(effect_info.view.sargs[2])

    if ztestType and ztestType > 0 and paopai then
        local duration_time = 2.5
        local delay_data = ExcelMgr.GetData("outfit_config", "ron", effect_info.view.id)
        if delay_data and delay_data.queue_change_delay and tonumber(delay_data.queue_change_delay) > 0 then
            -- 优先读取新配置
            duration_time = delay_data.queue_change_delay / 1000
        elseif tonumber(effect_info.view.sargs[1]) then
            -- 配置延迟时间的单位是毫秒
            duration_time = tonumber(effect_info.view.sargs[1]) / 1000 + 2.0
        end
        DesktopMgr.SetPaopaiZtestNew(paopai, 0, duration_time, nil, ztestType)
    end

    -- LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)     -- 记一下这个方法，需要传入sp，改变特效的parent，并且播放特效

    if root_static then
        if effect_info.view and effect_info.view.id == 30520009 then
            -- 璃央和牌特判
            TimeMgr.DelayFrame(1, function()
                local node_to_move = root_static.transform:Find('47/posi')
                if node_to_move then
                    local x, y, z = -1000, 0, 0
                    local zero_point = { x = 0, y = -50 }
                    local min_offset = { x = 200, y = 200 }
                    local max_offset = { x = 600, y = 400 }
                    local move_max_left = { x = 0.1, y = 0, z = 0 }
                    local move_max_right = { x = -0.1, y = 0, z = 0 }
                    local move_max_up = { x = 0, y = 0.05, z = -0.047 }
                    local move_max_down = { x = 0, y = -0.014, z = 0.013 }
                    local screen_pos = self.transform:Find('camera'):GetComponent(typeof(UnityEngine.Camera))
                                           :WorldToScreenPoint(paopai.model.position)
                    -- LogTool.Error("screen pos: ", "x: " .. screen_pos.x .. ", y: " .. screen_pos.y)
                    local ui_pos_x, ui_pos_y = Tools.GetUIPosByScreenPos(screen_pos.x, screen_pos.y,
                        UIMgr.Inst.rootFullScreen.transform)
                    -- LogTool.Error("ui pos: ", "x: " .. ui_pos_x .. ", y: " .. ui_pos_y)
                    local offset_x = ui_pos_x - zero_point.x
                    local offset_y = ui_pos_y - zero_point.y
                    local move_ratio_x = 0
                    local move_ratio_y = 0
                    -- X
                    if math.abs(offset_x) > min_offset.x then
                        local excess_x = math.abs(offset_x) - min_offset.x
                        local max_excess_x = max_offset.x - min_offset.x
                        move_ratio_x = math.min(excess_x / max_excess_x, 1.0)
                        if offset_x > 0 then
                            -- 右
                            x = x + move_max_right.x * move_ratio_x
                            y = y + move_max_right.y * move_ratio_x
                            z = z + move_max_right.z * move_ratio_x
                        else
                            -- 左
                            x = x + move_max_left.x * move_ratio_x
                            y = y + move_max_left.y * move_ratio_x
                            z = z + move_max_left.z * move_ratio_x
                        end
                    end
                    -- Y
                    if math.abs(offset_y) > min_offset.y then
                        local excess_y = math.abs(offset_y) - min_offset.y
                        local max_excess_y = max_offset.y - min_offset.y
                        move_ratio_y = math.min(excess_y / max_excess_y, 1.0)
                        if offset_y > 0 then
                            -- 上
                            x = x + move_max_up.x * move_ratio_y
                            y = y + move_max_up.y * move_ratio_y
                            z = z + move_max_up.z * move_ratio_y
                        else
                            -- 下
                            x = x + move_max_down.x * move_ratio_y
                            y = y + move_max_down.y * move_ratio_y
                            z = z + move_max_down.z * move_ratio_y
                        end
                    end
                    -- LogTool.Error("move pos: ", "x: " .. x .. ", y: " .. y .. ", z " .. z)
                    node_to_move:SetPos(x, y, z)
                end
            end)
        end
    end
end

--- @param transform ShowHuleEffect.Param
--- @param zimo_pai HandPai3D
--- @param effect_info IEffect_Hupai
--- @param prewarm boolean 是否预热（预加载）
function DesktopMgr:setOldHuleEffect(transform, effect_info, zimo_pai, prewarm, posX, posY, posZ, effect)

    -- 老的胡牌整体跟着牌走
    if effect_info.path == 'deco/effect_hupai/ron_hl/3d/prefab/ron_hl' then
        local rotA = 0
        local rotB = (transform.seat - 1) * 90
        local rotC = 0
        effect.transform:SetLocalEuler(rotA, rotB, rotC)
    elseif effect_info.path == 'deco/effect_hupai/ron_saki/3d/prefab/ron_saki' then
        local rotA = 0
        local rotB = 0
        local rotC = 0
        if transform.seat == 2 then
            rotB = -90
        elseif transform.seat == 3 then
            rotB = 180
        elseif transform.seat == 4 then
            rotB = 90
        end
        effect.transform:Find('pai_container'):SetLocalEuler(rotA, rotB, rotC)

    end

    if effect_info.path == 'deco/effect_hupai/ron_yanhua/3d/prefab/ron_yanhua' then
        -- 由于美术导出的是两个 prefab，爆炸的特效必须代码特判手动延时加载
        TimeMgr.Delay(0.6, function()
            local e_bang = LuaTools.LoadPrefab('deco/effect_hupai/ron_yanhua/3d/prefab/delay_boom', self.desktop)
            e_bang.gameObject:SetActive(true)
            e_bang.transform:SetLocalPos(0, 0, 0)
            if prewarm then
                e_bang.transform:SetLocalPos(1000, 1000, 1000)
            end
            TimeMgr.Delay(2, function()
                pcall(function()
                    if e_bang.gameObject then
                        UnityEngine.GameObject.Destroy(e_bang.gameObject)
                    end
                end)
            end)
        end)
    elseif effect_info.path == 'deco/effect_hupai/ron_kuangdu/3d/prefab/ron_kuangdu' then
        local pai_container = effect.transform:Find('pai_container')
        local rotA = 0
        local rotB = 0
        local rotC = 0
        pai_container:SetLocalEuler(rotA, rotB, rotC)
        local trans_pai
        if pai_container then
            trans_pai = pai_container:Find('pai')
        end
        local paopai = self.lastqipai
        if trans_pai and ((paopai and paopai.pai) or zimo_pai) then
            local _temp = HandPai3D:Init(trans_pai)
            if zimo_pai then
                if zimo_pai.model.parent.gameObject.name == 'pai_1' then
                    rotB = 0
                elseif zimo_pai.model.parent.gameObject.name == 'pai_2' then
                    rotB = -90
                elseif zimo_pai.model.parent.gameObject.name == 'pai_3' then
                    rotB = 180
                elseif zimo_pai.model.parent.gameObject.name == 'pai_4' then
                    rotB = 90
                else
                    rotB = 0
                end
                pai_container:SetLocalEuler(rotA,rotB, rotC)
                zimo_pai.pai3D.model.transform.gameObject:SetActive(false)
                zimo_pai.shadow.transform.gameObject:SetActive(false)
                _temp:SetVal(zimo_pai.pai)
                _temp:FullDown()
                _temp.model.transform:SetLocalPos(0, 0, 0.04)
                _temp.model.transform:SetLocalEuler(0, -180, 0)
            else
                if paopai.model.parent.gameObject.name == 'hai_1' or paopai.model.parent.gameObject.name == 'babei_1' then
                    rotB = -90
                elseif paopai.model.parent.gameObject.name == 'hai_2' or paopai.model.parent.gameObject.name == 'babei_2' then
                    rotB = 180
                elseif paopai.model.parent.gameObject.name == 'hai_3' or paopai.model.parent.gameObject.name == 'babei_3' then
                    rotB = 90
                elseif paopai.model.parent.gameObject.name == 'hai_4' then
                    rotB = 0
                end
                pai_container:SetLocalEuler(rotA,rotB- paopai.model.localRotation.eulerAngles.y, rotC)
                -- pai_container:SetLocalEuler(rotA,- paopai.model.parent.localEulerAngles.y - paopai.model.localRotation.eulerAngles.y, rotC)
                paopai.model.transform.gameObject:SetActive(false)
                _temp:SetVal(paopai.pai)
                _temp:FullDown()
                _temp.model.transform:SetLocalPos(0.03, 0, 0)
                _temp.model.transform:SetLocalEuler(0 , -90, 0)
            end

            local show_paopai = self:_record_show_paopai()
            -- if show_paopai then
            --     if transform.seat ~= 1 then
            --         show_paopai = self:_record_show_hand()
            --     end
            -- end

            if show_paopai then
                _temp.pai3D.ispaopai = true
            end
            _temp.pai3D:OnChoosed()
            TimeMgr.Delay(1.9, function()
                pcall(function()
                    if zimo_pai then
                        zimo_pai.pai3D.model.transform.gameObject:SetActive(true)
                        zimo_pai.shadow.transform.gameObject:SetActive(true)
                    else
                        paopai.model.position = _temp.pai3D.model.position
                        paopai.model.rotation = _temp.pai3D.model.rotation
                        if DesktopMgr.Inst.pending_liqi_failed then
                            DesktopMgr.Inst.pending_liqi_failed = false
                            paopai:DoAnim_Rotate()
                        end
                        paopai.model.gameObject:SetActive(true)
                        paopai.shadow.gameObject:SetActive(true)
                    end
                    -- self.lastqipai.shadow.transform.gameObject:SetActive(true)
                end)
                _temp:Destroy()
            end)
        end
    elseif  effect_info.path == 'deco/effect_hupai/ron_akagi/3d/prefab/ron_akagi' and not prewarm then
        local heidi_contianer = effect.transform:Find('heidi')
        heidi_contianer.transform:SetPos(-1000.0,0.189,0.228)
    elseif  effect_info.path == 'deco/effect_hupai/ron_22chunjie/3d/prefab/ron_22chunjie' and not prewarm then
        local hongdi_container = effect.transform:Find('hongdi')
        LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)
        hongdi_container:SetLocalPos(-0.01, 0.2, 0.3)
        hongdi_container:SetLocalEuler(-60, 0, 0)
        TimeMgr.Delay(5, function()
            pcall(function()
                if hongdi_container then
                    UnityEngine.GameObject.Destroy(hongdi_container.gameObject)
                    hongdi_container = nil
                end
            end)
        end)
        -- 鲁鲁修和牌 全屏特效
    elseif  effect_info.path == 'deco/effect_hupai/ron_llx/3d/prefab/ron_llx' and not prewarm then
        effect.gameObject:SetActive(false)
        TimeMgr.Delay(2, function ()
            effect.gameObject:SetActive(true)
        end)
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        DesktopMgr.SetPaopaiZtest(paopai, 2.1, 1.6)
        local hongdi_container = effect.transform:Find('01')
        LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)
        hongdi_container:SetLocalPos(0, 0, 0)
        hongdi_container:SetLocalEuler(0, 0, 0)
        TimeMgr.Delay(5, function()
            pcall(function()
                if hongdi_container then
                    UnityEngine.GameObject.Destroy(hongdi_container.gameObject)
                    hongdi_container = nil
                end
            end)
        end)
        -- 全屏和牌特效 sp角色beiyuanlili
    elseif  effect_info.path == 'deco/effect_hupai/ron_beiyuan/3d/prefab/ron_beiyuan' and not prewarm then
        local hongdi_container = effect.transform:Find('quanping')
        LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)
        hongdi_container:SetLocalPos(0, 0, 0.03)
        hongdi_container:SetLocalEuler(0, 0, 0)
        TimeMgr.Delay(5, function()
            pcall(function()
                if hongdi_container then
                    UnityEngine.GameObject.Destroy(hongdi_container.gameObject)
                    hongdi_container = nil
                end
            end)
        end)
        -- 全屏和牌特效 sp角色nanfenghua
    elseif  effect_info.path == 'deco/effect_hupai/ron_nanfenghua/3d/prefab/ron_nanfenghua' and not prewarm then
        local hongdi_container = effect.transform:Find('budong')
        LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)
        hongdi_container:SetLocalPos(0, 0, 0.03)
        hongdi_container:SetLocalEuler(0, 0, 0)

        -- 跟随牌面
        local paimian_effect = effect.transform:Find('paimian')
        -- local paimian_effect = effect.transform:Find('002/glow2')
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        DesktopMgr.SetPaopaiZtest(paopai, 1.5, 2)

        -- LuaTools.SetEffect(paopai.model.transform, 0, 0, paimian_effect)
        paimian_effect.transform:SetParent(paopai.model.transform)
        paimian_effect:SetLocalPos(-0.0002, 0, 0.0021)
        paimian_effect:SetLocalEuler(90, 0, 0)

        TimeMgr.Delay(5, function()
            pcall(function()
                if hongdi_container then
                    UnityEngine.GameObject.Destroy(hongdi_container.gameObject)
                    hongdi_container = nil
                end
            end)
            pcall(function()
                if paimian_effect then
                    UnityEngine.GameObject.Destroy(paimian_effect.gameObject)
                    paimian_effect = nil
                end
            end)
        end)
        -- 全屏和牌特效 sp角色dongcheng
    elseif  effect_info.path == 'deco/effect_hupai/ron_dongcheng/3d/prefab/ron_dongcheng' and not prewarm then
        local hongdi_container = effect.transform:Find('budong')
        LuaTools.SetEffect(DesktopMgr.Inst.poss, 0, 0, hongdi_container)
        hongdi_container:SetLocalPos(0, 0, 0.03)
        hongdi_container:SetLocalEuler(0, 0, 0)
        -- 跟随牌面
        local paimian_effect = effect.transform:Find('dong/eff/lizi/guangyun')
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        LuaTools.SetEffect(paopai.model.transform, 0, 0, paimian_effect)
        paimian_effect:SetLocalPos(-0.0013, 0, 0.0099)
        paimian_effect:SetLocalEuler(0, 0, 0)
        TimeMgr.Delay(5, function()
            pcall(function()
                if hongdi_container then
                    UnityEngine.GameObject.Destroy(hongdi_container.gameObject)
                    hongdi_container = nil
                end
            end)
            pcall(function()
                if paimian_effect then
                    UnityEngine.GameObject.Destroy(paimian_effect.gameObject)
                    paimian_effect = nil
                end
            end)
        end)
    elseif effect_info.path == 'deco/effect_hupai/ron_xiyuansi/3d/prefab/ron_xiyuansi' then
        local lizi_container = effect.transform:Find('lizi')
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        if paopai then
            effect.transform:SetPos(-1000.0,0,0)
            lizi_container:SetPos(posX,posY,posZ)
        end
        DesktopMgr.SetPaopaiZtest(paopai, 2.2, 1.5)
    elseif effect_info.path == 'deco/effect_hupai/ron_23wenquan/3d/prefab/ron_23wenquan' then
        -- 特效层级 在其他牌之上 炮牌之下
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        DesktopMgr.SetPaopaiZtest(paopai, 0, 1.8)
    elseif effect_info.path == 'deco/effect_hupai/ron_21winter/3d/prefab/ron_21winter' then
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        DesktopMgr.SetPaopaiZtest(paopai, 0, 1.8)
    elseif effect_info.path == 'deco/effect_hupai/ron_24chunjie/3d/prefab/ron_24chunjie' then
        local paimian_effect = effect.transform:Find('guang_alpha/guangkuang')
        local paopai = self.lastqipai
        if zimo_pai then
            paopai = zimo_pai.pai3D
        end
        if paopai then
            LuaTools.SetEffect(paopai.model.transform, 0, 0, paimian_effect)
            paimian_effect:SetLocalPos(0, -0.0012,0.0085)
            paimian_effect:SetLocalEuler(0, 0, 0)
        end

        TimeMgr.Delay(3, function()
            pcall(function()
                if paimian_effect then
                    UnityEngine.GameObject.Destroy(paimian_effect.gameObject)
                    paimian_effect = nil
                end
            end)
        end)
    else
        local pai_container = effect.transform:Find('pai_container')
        local trans_pai
        if pai_container then
            trans_pai = pai_container:Find('pai')
        end
        if trans_pai and zimo_pai then
            zimo_pai.pai3D.model.transform.gameObject:SetActive(false)
            zimo_pai.shadow.transform.gameObject:SetActive(false)
            local _temp = HandPai3D:Init(trans_pai)
            _temp:SetVal(zimo_pai.pai)
            _temp:FullDown()
            _temp.model.transform:SetLocalPos(0, -0.0104, 0.0302)
            _temp.model.transform:SetLocalEuler(0, 180, 0)

            local show_paopai = self:_record_show_paopai()
            -- if show_paopai then
            --     if transform.seat ~= 1 then
            --         show_paopai = self:_record_show_hand()
            --     end
            -- end

            if show_paopai then
                _temp.pai3D.ispaopai = true
            end
            _temp.pai3D:OnChoosed()
            TimeMgr.Delay(1.9, function()
                _temp:Destroy()
                pcall(function()
                    zimo_pai.pai3D.model.transform.gameObject:SetActive(true)
                    zimo_pai.shadow.transform.gameObject:SetActive(true)
                end)
            end)
        end
    end
end

--waittime:float
function DesktopMgr:StartChainAction(waittime)
    waittime = waittime or 0
    self.do_action_cd = UnityEngine.Time.time + waittime
    self.chainActionTimerMgr:LoopFrame(1, -1, function()
        self:DoChainAction()
    end)
end

function DesktopMgr:DoChainAction()
    if self.action_index > #self.actionList then
        self.action_index = 1
        self.actionList = {}
        self.do_chain_fast = false
        self.chainActionTimerMgr:ClearAllTimers()
        if self.duringReconnect then
            LogTool.Info('Desktop', 'finish sync game0')
            local request = ProtoMgr.CreateRequest('FastTest', 'finishSyncGame')
            MJNetMgr.Inst:SendRequest('FastTest', 'finishSyncGame', request, function() end)
            self.duringReconnect = false
        end
    else
        if not self.do_chain_fast then
            if self.action_running then return end
            if UnityEngine.Time.time <= self.do_action_cd - UnityEngine.Time.deltaTime then return end
            self.chainActionTimerMgr:ClearAllTimers()
        end
        if self.action_index == #self.actionList then
            if self.duringReconnect then
                self.duringReconnect = false
                LogTool.Info('Desktop', 'finish sync game1')
                local request = ProtoMgr.CreateRequest('FastTest', 'finishSyncGame')
                MJNetMgr.Inst:SendRequest('FastTest', 'finishSyncGame', request, function() end)
            end
        end
        if self.do_chain_fast then
            if self.action_index + 1 < #self.actionList then
                self:DoMJAction(self.actionList[self.action_index], true)
                self.action_index = self.action_index + 1
            else
                self.do_chain_fast = false
                self:DoMJAction(self.actionList[self.action_index], false)
                self.action_index = self.action_index + 1
            end
        else
            if self.action_index + 3 < #self.actionList then
                self.do_chain_fast = true
            end
            if self.do_chain_fast then
                self.chainTimer:ClearAllTimers()
                self.chainTimer:Delay(0.8, function()
                    local action_index = self.action_index
                    for i = #self.actionList, action_index, -1 do
                        if self.actionList[i].name == 'ActionNewRound' then
                            self.action_index = i
                            break
                        end
                    end
                    self:DoMJAction(self.actionList[self.action_index], self.action_index ~= #self.actionList )
                    self.action_index = self.action_index + 1
                end)
            else
                self:DoMJAction(self.actionList[self.action_index], false)
                self.action_index = self.action_index + 1
            end
        end
    end
end

--data:Object, fast:bool
function DesktopMgr:DoMJAction(data, fast, callback)
    local step = data.step
    local msg = ProtoMgr.CreateMsg(data.name)
    msg:ParseFromString(Tools.DecodeAction(data.data))
    LogTool.Info('DoMJAction', data.name)
    if step > 0 and step ~= self.current_step + 1 then
        LogTool.Warning('Desktop', 'step 不对 强制触发全数据重连 step:' .. step .. ' current_step:' .. self.current_step)
        self:_trySyncGame()
        return
    end
    LogTool.Info('DoMJAction True', data.name)
    local waittime = 0
    self.current_step = step
    if self.actionMap[data.name] then
        if not fast then
            self.action_running = true
        end
        local _msg = {}
        _msg.msg = msg
        _msg.fast = fast
        waittime = self.actionMap[data.name](_msg)
        -- xpcall(function()

        -- end, function()
        --     local _errorinfo = {}
        --     _errorinfo.error = 'DesktopMgr DoMJAction '..pt.block(data)..' fast: '..fast
        --     _errorinfo.stack = debug.traceback()
        --     _errorinfo.method = 'DoMJAction'
        --     _errorinfo.name = 'DesktopMgr'
        --     _errorinfo.name = data.name
        --     _errorinfo.data = data
        --     _errorinfo.step = step
        --     GameMgr.Inst:OnFatalError(_errorinfo, true)
        -- end)
    else
        LogTool.Warning('Desktop', '未监听的操作：' .. data.name)
    end

    if fast then
        self.timerMgr:DelayFrame(1, function()
            self:DoChainAction()
        end)
    else
        self.timerMgr:DelayFrame(2, function()
            self:StartChainAction(waittime)
        end)
    end
end

function DesktopMgr:_trySyncGame()
    self:Reset()
    self.duringReconnect = true
    self.hang_up_count = 0
    local request = ProtoMgr.CreateRequest('FastTest', 'syncGame')
    request.round_id = self:get_round_id()
    request.step = 0
    MJNetMgr.Inst:SendRequest('FastTest', 'syncGame', request, function(err, res)
        if err or not res or (res and res.error and res.error.code ~= 0) then
            if not res or (res.error and res.error.code ~= 0) then
                UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.Fatal, msg = Tools.StrOfLocalization(res.error.code) })

            else
                UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.Fatal })

            end
            Scene_MJ.Inst:ForceOut()
        else
            LogTool.Info('Desktop', '[SyncGame2]: ' .. pt.block(res))
            if res.isEnd then
                UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.Normal, msg = Tools.StrOfLocalization(2229) })

                Scene_MJ.Inst:GameEnd()
            else
                self:FetchLinks()
                self:Reset()
                self.duringReconnect = true
                self:SyncGameByStep(res.game_restore)
            end
        end
    end)
end

--msg:Object
function DesktopMgr:SyncGameByStep(msg)
    local isover = false
    self.time_stopped = false
    self.handles_after_timerun = {}
    self.action_running = false
    -- UIMgr.Inst:CloseUIByClassName(UI_GameStop.className)
    self.hang_up_count = 0
    -- UIMgr.Inst:CloseUIByClassName(UI_HangUpWarn.className)
    if msg and msg.game_state == 5 then
        self.time_stopped = true
    end
    GameMgr.Inst:EnterMJ()
    self.actionList = {}
    self.action_index = 1
    local includeNewRound = false
    if msg and msg.actions and #msg.actions > 0 then
        local usetime = -1
        usetime = msg.passed_waiting_time
        for i = 1, #msg.actions do
            local action = msg.actions[i]
            local _usetime = usetime
            if i ~= #msg.actions then
                _usetime = -1
            end
            
            local decodedMsg = ProtoMgr.CreateMsg(action.name)
            decodedMsg:ParseFromString(action.data)
            self.current_step = action.step
            self:ClearOperationShow()
            if (_usetime == -1 and action.name == 'ActionNewRound') then
                local finalAction = msg.actions[#msg.actions]
                local decodedMsg1 = ProtoMgr.CreateMsg(finalAction.name)
                decodedMsg1:ParseFromString(finalAction.data)
                LogTool.Error('SyncGameByStep Error' .. finalAction.name, pt.block(decodedMsg1))
            end
            if action.name == 'ActionNewRound' then
                ActionNewRound.FastPlay(decodedMsg, _usetime)
                includeNewRound = true
            elseif action.name == 'ActionChangeTile' then
                ActionChangeTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionSubmit' then
                ActionSubmit.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionTake' then
                ActionTake.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionSelectGap' then
                ActionSelectGap.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionDiscardTile' then
                ActionDiscardTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionDealTile' then
                ActionDealTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionChiPengGang' then
                ActionChiPengGang.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionAnGangAddGang' then
                ActionAnGangAddGang.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionGangResult' then
                ActionGangResult.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionGangResultEnd' then
                ActionGangResultEnd.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionHule' then
                ActionHule.FastPlay(decodedMsg, _usetime)
                isover = true
            elseif action.name == 'ActionHuleXueZhanMid' then
                ActionHuleXueZhanMid.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionHuleXueZhanEnd' then
                ActionHuleXueZhanEnd.FastPlay(decodedMsg, _usetime)
                isover = true
            elseif action.name == 'ActionLiuJu' then
                ActionLiuJu.FastPlay(decodedMsg, _usetime)
                isover = true
            elseif action.name == 'ActionNoTile' then
                ActionNoTile.FastPlay(decodedMsg, _usetime)
                isover = true
            elseif action.name == 'ActionBaBei' then
                ActionBaBei.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionRevealTile' then
                ActionRevealTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionUnveilTile' then
                ActionUnveilTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionLockTile' then
                ActionLockTile.FastPlay(decodedMsg, _usetime)
            elseif action.name == 'ActionNewCard' then
                ActionNewCard.FastPlay(decodedMsg)
            elseif action.name == 'ActionFillAwaitingTiles' then
                ActionFillAwaitingTiles.FastPlay(decodedMsg, _usetime)
            end
            self.recent_action = action
        end
        self.timerMgr:Delay(1, function()
            self.duringReconnect = false
            UIMgr.Inst:CloseUIByClassName(UI_Loading.className)
            if (not isover) and (not includeNewRound) then
                AudioSettingModel:PlayBgm()
            end
            self:DoChainAction()
        end)
    else
        self.duringReconnect = false
        if not self.time_stopped then
            local request = ProtoMgr.CreateRequest('FastTest', 'confirmNewRound')
            MJNetMgr.Inst:SendRequest('FastTest', 'confirmNewRound', request, function() end)
        else
            table.insert(self.handles_after_timerun, function()
                local request = ProtoMgr.CreateRequest('FastTest', 'confirmNewRound')
                MJNetMgr.Inst:SendRequest('FastTest', 'confirmNewRound', request, function() end)
            end)
        end
    end

    LogTool.Info('Desktop', '<<<<<<<<<<<<<<<<<<finishSyncGame>>>>>>>>>>>>>>>>>')
    local request = ProtoMgr.CreateRequest('FastTest', 'finishSyncGame')
    MJNetMgr.Inst:SendRequest('FastTest', 'finishSyncGame', request, function() end)
    self:FetchLinks()
    if self.time_stopped then
        UIMgr.Inst:ShowUI(UI_GameStop.className)
    end
end

function DesktopMgr:ActionRunComplete()
    self.action_running = false
end

--seat:int, tingpais:{tile:string, haveyi:bool}[]
function DesktopMgr:SetTingPai(seat, tingpais)
    local _haveChange = false
    local _tingpais = {}
    tingpais = tingpais or {}
    for i = 1, #tingpais do
        table.insert(_tingpais, MJPai:Init(tingpais[i].tile))
    end
    if not self.tingpais[seat] or #self.tingpais[seat] ~= #_tingpais then
        _haveChange = true
    end

    for i = 1, #_tingpais do
        if not _haveChange then
            if MJPai.Distance(_tingpais[i], self.tingpais[seat][i]) ~= 0 then
                _haveChange = true
            end
        end
    end

    if _haveChange then
        self.tingpais[seat] = _tingpais
        LogTool.Warning('Desktop', 'seat: ' .. seat .. ' tingpais: ' .. pt.block(_tingpais))
        UI_DesktopInfo.Inst:SetTingpaiModeData(seat,_tingpais)
        for i = 1, #self.players do
            local seat = self:localPosition2Seat(i)
            for j = 1, #self.players[i].container_qipai.pais do
                local pai = self.players[i].container_qipai.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end
            for j = 1, #self.players[i].container_babei.pais do
                local pai = self.players[i].container_babei.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end
            for j = 1, #self.players[i].container_ming.pais do
                local pai = self.players[i].container_ming.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end

            local pai = self.players[i].container_qipai.last_pai
            if pai then
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end

            if i == 1 then
                local __player = self.players[i]
                for j = 1, #__player._handpai do
                    local pai = __player._handpai[j]
                    pai.ispaopai = self:IsPaoPai(pai.pai)
                    pai:RefreshPaoPai()
                end
            else
                local __player = self.players[i]
                for j = 1, #__player._handpai3D do
                    local pai = __player._handpai3D[j]
                    if pai.is_open or self:_record_show_hand() or (pai.pai.open and DesktopMgr.Inst.mode == EMJ_Mode.paipu) then
                        pai.pai3D.ispaopai = self:IsPaoPai(pai.pai)
                        pai.pai3D:OnChoosed()
                    else
                        pai.pai3D.ispaopai = false
                    end
                end
            end
        end
    end
end

function DesktopMgr:Reset()
    --if (ActionNewRound.Playing) then
    --    LogTool.Error('Desktop', 'Start Reset DesktopMgr In Error Time')
    --else
    LogTool.Info('Desktop', 'Start Reset DesktopMgr')
    --end

    self.operation_showing = false
    self:CloseChiPengEffect()
    self.oplist = {}
    --清除定时器
    ActionAnGangAddGang.ClearTimers()
    ActionChiPengGang.ClearTimers()
    ActionDealTile.ClearTimers()
    ActionDiscardTile.ClearTimers()
    ActionHule.ClearTimers()
    ActionLiqi.ClearTimers()
    ActionLiuJu.ClearTimers()
    ActionNewRound.ClearTimers()
    ActionNewCard.ClearTimers()
    ActionFillAwaitingTiles.ClearTimers()
    ActionChangeTile.ClearTimers()
    ActionSubmit.ClearTimers()
    ActionTake.ClearTimers()
    ActionSelectGap.ClearTimers()
    ActionNoTile.ClearTimers()
    ActionOperation.ClearTimers()
    ActionBaBei.ClearTimers()
    ActionGangResult.ClearTimers()
    ActionGangResultEnd.ClearTimers()
    ActionHuleXueZhanEnd.ClearTimers()
    ActionHuleXueZhanMid.ClearTimers()
    self.timerMgr:ClearAllTimers()
    self.chainActionTimerMgr:ClearAllTimers()
    self.chainTimer:ClearAllTimers()
    UI_DesktopInfo.Inst:ResetRounds()
    if UI_TingPai and UI_TingPai.Inst then
        UI_TingPai.Inst:Reset()
    end
    if UI_Replay and UI_Replay.Inst then
        UI_Replay.Inst:Reset()
    end
    if (UIMgr.Inst:IsUIActive(UI_HuleShow.className)) then
        UIMgr.Inst:CloseUIByClassName(UI_HuleShow.className)
    end
    for i = 1, 4 do self.players[i]:_Reset() end
    self.tingpais = {{},{},{},{}}
    self.misc_opens = {}
    self.md5 = ''
    self.sha256 = ''
    self.saltSha256 = ''
    self.lastqipai = nil
    self.current_step = 0
    self.liqibang_count = -1
    self.action_running = false
    self:ResetSpecialModes()
    --清除所有的notify
end


-- 小局重开时，clear所有Action
function DesktopMgr:OnNewRound()
    ActionAnGangAddGang.ClearTimers()
    ActionChiPengGang.ClearTimers()
    ActionDealTile.ClearTimers()
    ActionDiscardTile.ClearTimers()
    ActionHule.ClearTimers()
    ActionLiqi.ClearTimers()
    ActionLiuJu.ClearTimers()
    ActionNewRound.ClearTimers()
    ActionNewCard.ClearTimers()
    ActionFillAwaitingTiles.ClearTimers()
    ActionChangeTile.ClearTimers()
    ActionSelectGap.ClearTimers()
    ActionNoTile.ClearTimers()
    ActionOperation.ClearTimers()
    ActionBaBei.ClearTimers()
    ActionGangResult.ClearTimers()
    ActionGangResultEnd.ClearTimers()
    ActionHuleXueZhanEnd.ClearTimers()
    ActionHuleXueZhanMid.ClearTimers()
end

--pai:MJPai
function DesktopMgr:SetChoosedPai(pai)
    local diff = false
    if not diff and pai and not self.choosed_pai then diff = true end
    if not diff and not pai and self.choosed_pai then diff = true end
    if not diff and pai and self.choosed_pai and MJPai.Distance(self.choosed_pai, pai) ~= 0 then diff = true end

    if diff then
        if pai then
            self.choosed_pai = pai
        else
            self.choosed_pai = nil
        end

        if self.bianjietishi then
            for i = 1, 4 do
                self.players[i]:_OnChoosedPai()
            end
            UI_TingPai.Inst:OnChooseTile(pai)
        end
    end
end

function DesktopMgr:ClearOperationShow(force)
    self.operation_showing = false
    self.oplist = {}
    UIMgr.Inst:CloseUIByClassName(UI_Win.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_ChiPengHu.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_LiqiZimo.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_ScoreChange.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_ConfirmNewRound.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_ChangeTile.className, nil, nil, true)
    UIMgr.Inst:CloseUIByClassName(UI_SelectGap.className, nil, nil, true)
    if force then
        UIMgr.Inst:CloseUIByClassName(UI_ScoreChange_Xuezhan.className, nil, nil, true)
    end
    if UIMgr.Inst:IsHaveInstance(UI_ChangeTile_Result.className) then
        UIMgr.Inst:CloseUIByClassName(UI_ChangeTile_Result.className, nil, nil, true)
    end
    UIMgr.Inst:CloseUIByClassName(UI_HuleShow.className, nil, nil, true)
    if UIMgr.Inst:IsHaveInstance(UI_TributeTile_Result.className) then
        UIMgr.Inst:CloseUIByClassName(UI_TributeTile_Result.className)
    end
    ActionOperation.ClearTimers()
    self.effect_pai_canchi.gameObject:SetActive(false)
    self.mainrole._can_discard = false
    self.pending_liqi_failed = false
    UI_DesktopInfo.Inst:CloseCountDown()
end

function DesktopMgr:WhenDoOperation()
    self.hang_up_count = 0
    if UI_HangUpWarn.Inst.transform.gameObject then
        UIMgr.Inst:CloseUIByClassName(UI_HangUpWarn.className)
    end
    self:ClearOperationShow()
end

--data:string[], fast:bool
function DesktopMgr:WhenDoras(data, fast, force)
    LogTool.Info('Desktop', 'WhenDoras: ' .. pt.block(data))
    if (not data or #data == 0 or #data <= #self.dora) and not force then return end

    local havenew = false
    for i = 1, #data do
        if #self.dora >= i then
            self.dora[i] = MJPai:Init(data[i])
        else
            table.insert(self.dora, MJPai:Init(data[i]))
        end

        UI_DesktopInfo.Inst:SetDora(i, self.dora[i])
    end

    self.timerMgr:DelayFrame(1, function()
        for i = 1, 4 do
            self.players[i]:_OnDoraRefresh()
        end
    end)

    if not fast then
        AudioMgr.PlayAudio(215)
    end
end

--pai:MJPai
function DesktopMgr:IsPaoPai(pai)
    if not self:_record_show_paopai() then return false end
    for i = 1, #self.tingpais do
        for j = 1, #self.tingpais[i] do
            if MJPai.Distance(self.tingpais[i][j], pai) == 0 then return true end
        end
    end
    return false
end

--清掉已经胡过的玩家的炮牌提示
function DesktopMgr:XueZhanHule(seat)
    if self.tingpais[seat] then
        self:SetTingPai(seat,{})
    end
end

--seat:int, pai:ViewPai
function DesktopMgr:SetLastQiPai(seat, pai)
    self.lastqipai = pai
    self.lastqipai_seat = seat
    self.effect_pai_canchi.gameObject:SetActive(false)
end

-- 检查上一张弃牌是否是鸣牌
function DesktopMgr:IsLastPaiMingPai()
    if self.players then
        for i = 1, #self.players do
            for j = 1, #self.players[i].container_ming.pais do
                if self.lastqipai == self.players[i].container_ming.pais[j] then
                    return true
                end

            end

        end

    end
end

function DesktopMgr:RefreshPaiMat()
    if #self.maquepool > 0 then
        local pai_materials = self.maquepool[1].transform:GetComponent(typeof(UnityEngine.MeshRenderer)).sharedMaterials
        pai_materials[0]:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
        pai_materials[0]:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        pai_materials[1]:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        pai_materials[1].mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
    end
    if self.sharedMaterial_jiuchao then
        self.sharedMaterial_jiuchao:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
        self.sharedMaterial_jiuchao2:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
        self.sharedMaterial_jiuchao_touyin:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
    end

    if self.sharedMaterial_anpai then
        self.sharedMaterial_anpai:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
        self.sharedMaterial_anpai:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        self.sharedMaterial_anpai2:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        self.sharedMaterial_anpai2.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
    end

    self.mainrole:_RefreshHandPai(true)
    if UI_Replay and UI_Replay.Inst and UI_Replay.Inst.transform.gameObject.activeSelf then
        UI_Replay.Inst.page_paishan.refresh_paimat()
    end
    if UI_DesktopInfo and UI_DesktopInfo.Inst and UI_DesktopInfo.Inst.transform.gameObject.activeSelf then
        local doras = {}
        for i = 1, #self.dora do
            table.insert(doras, self.dora[i].str)
        end
        self:WhenDoras(doras, true, true)
    end
end

--game_config:Object, players:Array<Object>, myaccountid:number, mode:EMJ_Mode, complete:function
---@param game_config IGameConfig
---@param players table|IAccount[]|IRecordGame_AccountInfo[]
function DesktopMgr:InitRoom(game_config, players, myaccountid, mode, complete,anonymous,url_access,game_record, matchInfo)
    LogTool.Info('InitMJRoom', 'DesktopMgr InitRoom: players: ' .. pt.block(players))
    LogTool.Info('InitMJRoom', 'Desktop game_config: ' .. pt.block(game_config))
    MJNetMgr.Inst:AppendLogInfo("玩家信息：" .. pt.block(players))
    MJNetMgr.Inst:AppendLogInfo("房间配置信息：" .. pt.block(game_config))
    self.desktop:Find('other_en').gameObject:SetActive(GameMgr.Inst.prefer_language == 'en')
    self.desktop:Find('other').gameObject:SetActive(GameMgr.Inst.prefer_language ~= 'en')
    self.game_config = game_config
    MJNetMgr.Inst:AppendLogInfo("开始刷新麻将牌装扮")
    self:RefreshPaiMat()
    MJNetMgr.Inst:AppendLogInfo("刷新麻将牌装扮完毕")
    if UI_FriendRoom and UI_FriendRoom.Inst then
        UI_FriendRoom.Inst:ResetData()
    end
    if UI_MJVoteEnd and UI_MJVoteEnd.Inst then
        UI_MJVoteEnd.Inst:Reset()
    end
    self.rule_mode = ERule_Mode.Liqi4
    if game_config.mode.mode then
        if game_config.mode.mode < 10 then
            self.rule_mode = ERule_Mode.Liqi4
        else
            self.rule_mode = ERule_Mode.Liqi3
        end
    end

    -- 特效根节点
    if (not self.effectRoot) then
        self.effectRoot = UnityEngine.GameObject.New("effectRoot").transform
    end

    self.mode = mode
    self.seat = -1
    self.ptchange = 0
    self.player_datas = players
    -- ==DevDebug Start==
    self.player_datas = Tools.ProtoToTable(players, false)
    -- ==DevDebug End==
    local index = Tools.FindInArray(players, nil, function(o)
        return o.account_id == myaccountid
    end)
    self.myPlayerData = players[index]
    self.game_record = game_record

    self.game_end_result = nil
    self.level_change_info = nil
    self.reward_info = nil
    self.activity_reward = nil
    self.badge_info = nil
    self.active = true
    self.transform.gameObject:SetActive(true)
    self.time_stopped = false
    self.action_running = false
    self.hang_up_count = 0
    self.handles_after_timerun = {}
    self.xiakeshangInfo = nil
    self.tributeState = 0

    -- Voice
    self.lastRoundRecord = {}
    UIMgr.Inst:CloseUIByClassName(UI_GameStop.className)


    self.record_show_hand = Tools.getplayerprefshandler().GetInt('record_show_hand', 1) == 1
    self.record_show_paopai = Tools.getplayerprefshandler().GetInt('record_show_paopai', 1) == 1
    self.record_show_anim = Tools.getplayerprefshandler().GetInt('record_show_anim', 1) == 1
    self.record_show_tingpai = Tools.getplayerprefshandler().GetInt('record_show_tingpai',0) == 1

    self.playing_hule_effect = false
    self.playing_yiman_effect = false

    self.live_show_hand = true
    self.live_show_paopai = true
    self.live_follow_dealer = false

    self.bestHuDataMap = {}

    if self.mode == EMJ_Mode.play then
        UI_Invite.canShow = false
        if game_config.category == 4 then
            GameMgr.Inst.custom_match_id = game_config.meta.customized_contest_uid
        end
        if (not GameMgr.Inst.maintenanceInfo[GameMgr.EMaintenanceName.performanceReport]) then
            MJNetMgr.Inst:AppendLogInfo("开始执行性能测试")
            Tools.TestPerformance()
            MJNetMgr.Inst:AppendLogInfo("性能测试执行完毕")
        end

    else
        UI_Invite.canShow = true
    end

    if JoyStick and JoyStick.Inst then
        JoyStick.Inst:TriggerGame(self.mode)
    end

    self.myaccountid = myaccountid
    -- local soundlist = {}
    -- for i = 1, #players do
    --     local d_skin = ExcelMgr.GetData('item_definition','skin',players[i].avatar_id)
    --     local d_chara = ExcelMgr.GetData('item_definition','character', d_skin.character_id)
    --     local soundTable = ExcelMgr.GetTable('voice','sound')
    --     local sounds = {}
    --     for key, value in pairs(soundTable) do
    --         if value and value.id == 1 then
    --             table.insert(self.tips, value.simple_chinese)
    --         end
    --     end
    -- end

    for i = 1, #self.player_datas do
        if self.player_datas[i].account_id == myaccountid and myaccountid ~= 0 then
            self.seat = i
            local zifeng = ''
            if i == 1 then
                zifeng = '东风'
            elseif i == 2 then
                zifeng = '南风'
            elseif i == 3 then
                zifeng = '西风'
            elseif i == 4 then
                zifeng = '北风'
            end
        end
    end
    if self.seat == -1 then
        if self.mode ~= EMJ_Mode.play then
            self.seat = 1
        else
            UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.Normal, msg = Tools.StrOfLocalization(2228) })

            return
        end
    end

    --Enable UI_Replay
    if self.mode == EMJ_Mode.paipu then
        -- TODO 一个特效修改
        LuaTools.LoadPrefabAsync("scenes/mj/effect_mj/extend/prefab/fx_skill_pp_mpts", self.effectMakaHelperTip, true, function(trans)
            trans.gameObject:SetActive(true)
        end)
        UIMgr.Inst:ShowUI(UI_Replay.className, nil, { anonymous = anonymous, urlAccess = url_access })
    end

    self.bianjietishi = true
    self.play_ingame_voice = true
    if self.mode == EMJ_Mode.play then
        if game_config.mode and game_config.mode.detail_rule and game_config.mode.detail_rule.init_point ~= 0 then
            local detail_rule = game_config.mode.detail_rule
            --心理语音跟着便捷提示走
            self.bianjietishi = detail_rule.bianjietishi
            self.play_ingame_voice = self.bianjietishi
        end
        if game_config.category == 2 and game_config.meta then
            local d_desk = ExcelMgr.GetData('desktop','matchmode',game_config.meta.mode_id)
            --王座之间关闭便捷提示
            if d_desk and d_desk.room == 6 then
                self.bianjietishi = false
                self.play_ingame_voice = false
            end
        end
        UI_MJTaskProgress.Record()
    end

    if game_config.mode then
        MJNetMgr.Inst:AppendLogInfo("开始加载特殊模式材质，mode: " .. pt.block(game_config.mode))
        local detail_rule = game_config.mode.detail_rule
        if detail_rule and detail_rule:HasField('begin_open_mode') and detail_rule.begin_open_mode == 1 then
            HandPaiPlane.sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjphand_open')
        else
            HandPaiPlane.sharedMaterial = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjphand')
        end
        HandPaiPlane.sharedMaterial:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/hand'))
        HandPaiPlane.sharedMaterial.mainTexture.mipMapBias = GameUtility.EMipMapBias.handpai_face
        HandPaiPlane.sharedMaterial_back = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjphand_back')
        HandPaiPlane.sharedMaterial_back:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/hand'))


        -- TODO 不同模式的材质和纹理根据模式加载
        if self:is_jiuchao_mode() then
            LogTool.Info('明镜之战', '')
            HandPaiPlane.sharedMaterial_jiuchao = LuaTools.LoadMaterial('scenes/mj/game_mode/mingjingzhizhan/material/mjphand_jiuchao')

            self.sharedMaterial_jiuchao = LuaTools.LoadMaterial('scenes/mj/game_mode/mingjingzhizhan/material/plane_pai_face')
            self.sharedMaterial_jiuchao2 = LuaTools.LoadMaterial('scenes/mj/game_mode/mingjingzhizhan/material/plane_pai_back')
            self.sharedMaterial_jiuchao_touyin = LuaTools.LoadMaterial('scenes/mj/game_mode/mingjingzhizhan/material/GlassPai_Face')
            self.sharedMaterial_jiuchao:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
            self.sharedMaterial_jiuchao2:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
            self.sharedMaterial_jiuchao_touyin:SetTexture('_MainTex', Tools.get_mjp_reveal_path(true))
        end
        if self:is_reveal_discard_mode() then
            self.sharedMaterial_anpai = LuaTools.LoadMaterial('scenes/mj/game_mode/anyezhizhan/material/anmjp_mid')
            self.sharedMaterial_anpai2 = LuaTools.LoadMaterial('scenes/mj/game_mode/anyezhizhan/material/anmjp_face')
            self.sharedMaterial_anpai3 = LuaTools.LoadMaterial('scenes/mj/game_mode/anyezhizhan/material/anmjp_back')
            self.sharedMaterial_anpai:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
            self.sharedMaterial_anpai:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
            self.sharedMaterial_anpai2:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
            self.sharedMaterial_anpai2.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
        end
        local m1 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_mid')
        local m2 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_face')
        m1:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(true, '/3d/texture/mjp'))
        m1:SetTexture('_TileTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        m2:SetTexture('_MainTex', GameMgr.Inst:get_mjp_final_path(false, '/3d/texture/mjp'))
        m2.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
        if self:is_wanxiangxiuluo_mode() then
            self.sharedMaterial_baida = LuaTools.LoadMaterial('scenes/mj/game_mode/wanxiangxiuluo/material/mjp_face')
            self.sharedMaterial_baida:SetTexture('_MainTex', 'scenes/mj/game_mode/wanxiangxiuluo/texture/mjp')
            self.sharedMaterial_baida.mainTexture.mipMapBias = GameUtility.EMipMapBias.mjpai_face
            self.sharedMaterial_baida2 = LuaTools.LoadMaterial('scenes/mj/game_mode/wanxiangxiuluo/material/mjphand')
            self.sharedMaterial_baida2:SetTexture('_MainTex', 'deco/mjpface/mjpface_special_mode/3d/texture/bd')
        end
    end

    UI_Activity.SetRPGNeedShow(game_config.meta.mode_id)

    self.mjp_res_name = GameUtility.get_common_view_res_name(GameUtility.ECommonView.mjp)
    self.player_effects = {}

    -- 测试服饰
    -- ==DevDebug Start== 
    UI_Lobby_Debug.DebugChangeSkinDataDesktop(self)
    -- ==DevDebug End==

    for i = 1, #self.player_datas do
        local d_character = self.player_datas[i].character
        ---@type IEffect_Hupai
        local effect_hupai = {
            path = "deco/effect_hupai/effect_hupai_default/3d/prefab/effect_hupai_default",
            audio_id = 213
        }
        ---@type IEffect_Liqi
        local effect_liqi = nil
        local liqibang = "deco/lizhibang/liqi_default/3d/prefab/liqi_default"
        local hand_type = 'hand_human'
        local liqi_bgm = ''
        local headframe = 0
        local mpzs = ''
        ---@type Sheet_ItemDefinition_View
        local liqibang_view = nil
        if d_character then
            local hand_version
            --联动：受限地区下为自己的皮肤显示为一姬
            local character_info = ExcelMgr.GetData('item_definition','character',d_character.charid)
            if Tools.CountryLock(self.player_datas[i].account_id, character_info) then
                self.player_datas[i].character.charid = 200001
                self.player_datas[i].avatar_id = 400101
                self.player_datas[i].character.skin = 400101
                self.player_datas[i].character.is_upgraded = false
            end
            local d_character_def = ExcelMgr.GetData('item_definition', 'character', d_character.charid)
            if d_character_def then
                local d_view = ExcelMgr.GetData('item_definition', 'view', d_character_def.hand)
                hand_type = d_view.res_name
                hand_version = d_view.hand_version
            end

            local views = self.player_datas[i].views
            if(views) then
                for j = 1, #views do
                    local slot = views[j].slot
                    local item_id = views[j].item_id
                    local d_view = ExcelMgr.GetData('item_definition', 'view', item_id)
                    -- 联动筛选
                    local d_item = ExcelMgr.GetData('item_definition', 'item', item_id)
                    if Tools.CountryLock(self.player_datas[i].account_id, d_item) then
                        d_view = nil
                    end
                    if d_view and d_view.res_name ~= '' then
                        if slot == EplayerView['hupai_effect'] then
                            ---@class IEffect_Hupai
                            effect_hupai = {
                                path = 'deco/effect_hupai/' .. d_view.res_name .. '/3d/prefab/' .. d_view.res_name,
                                audio_id = d_view.audio_id,
                                -- sargs = d_view.sargs,
                                view = d_view
                            }
                        elseif slot == EplayerView['liqi_effect'] then
                            ---@class IEffect_Liqi
                            effect_liqi = {
                                path = 'deco/effect_lizhi/' .. d_view.res_name .. '/3d/prefab/' .. d_view.res_name,
                                type = d_view.sargs[1] or 'shu',
                                seatRelated = d_view.seat_related and d_view.seat_related > 0,
                                audio_id = d_view.audio_id,
                                view = d_view
                            }
                        elseif slot == EplayerView['liqibang'] then
                            liqibang = 'deco/lizhibang/' .. d_view.res_name .. '/3d/prefab/' .. d_view.res_name
                            liqibang_view = d_view
                        elseif slot == EplayerView['hand_model'] then
                            hand_type = d_view.res_name
                            hand_version = d_view.hand_version
                        elseif slot == EplayerView['headframe'] then
                            headframe = item_id
                        elseif slot ==  EplayerView['mingpaizhishi'] then
                            mpzs = 'deco/effect_mingpaizhishi/' .. d_view.res_name .. '/3d/prefab/' .. d_view.res_name
                        else
                            LogTool.Warning('Desktop', '非法的装扮数据: ' .. pt.block(views[j]))
                        end
                    else
                        if slot == EplayerView['liqi_bgm'] then
                            local d_item = ExcelMgr.GetData('item_definition', 'item', item_id)
                            if d_item then
                                liqi_bgm = 'audio/'..Tools.GetPathForUnity(d_item.sargs[1])
                            end
                        end
                    end
                end
            end

            ---@class IPlayer_Effect
            local __player_effect = {}
            __player_effect.effect_hupai = effect_hupai
            __player_effect.effect_liqi = effect_liqi
            __player_effect.liqibang = liqibang
            __player_effect.hand = hand_type
            __player_effect.hand_version = hand_version
            __player_effect.liqi_bgm = liqi_bgm
            __player_effect.headframe = headframe
            __player_effect.liqibang_view = liqibang_view
            table.insert(self.player_effects, __player_effect)
        else
            local __player_character = {}
            __player_character.charid = 200001
            __player_character.level = 0
            __player_character.exp = 0
            __player_character.views = {}
            __player_character.skin = 400101
            __player_character.is_upgraded = false
            self.player_datas[i].character = __player_character
            ---@type IPlayer_Effect
            local __player_effect = {}
            __player_effect.effect_hupai = effect_hupai
            __player_effect.effect_liqi = effect_liqi
            __player_effect.liqibang = liqibang
            __player_effect.hand = hand_type
            __player_effect.liqi_bgm = liqi_bgm
            __player_effect.liqibang_view = liqibang_view
            table.insert(self.player_effects, __player_effect)
        end
    end

    --prewarm
    MJNetMgr.Inst:AppendLogInfo("开始预热玩家装扮特效")
    for i = 1, #self.player_effects do
        local transform = {
            pos = {
                x = 9999,
                y = 9999,
                z = 9999
            },
            seat = 0
        }
        self:ShowHuleEffect(transform, self.player_effects[i].effect_hupai, nil, true)
        if self.player_effects[i].effect_liqi ~= '' then
            self:ShowHuleEffect(transform, self.player_effects[i].effect_liqi, nil, true)
        end
        --if self.player_effects[i].liqi_bgm ~= '' then
        --    LuaTools.LoadClipAsync(self.player_effects[i].liqi_bgm)
        --end
    end
    MJNetMgr.Inst:AppendLogInfo("玩家装扮特效预热完毕")
    --LuaTools.LoadClipAsync('audio/music/game')

    --- 处理匿名
    if not anonymous then
        for i=1,#self.player_datas do
            self.player_datas_temp[i] = self.player_datas[i].nickname
        end
    else
        self.player_datas_temp = {}
    end
    self:SetNicknameAnonymous(anonymous)

    if UI_DesktopInfo and UI_DesktopInfo.Inst then
        UI_DesktopInfo.Inst:InitRoom()
        UI_DesktopInfo.Inst:RefreshSeat()
    end
    if UI_HangUpWarn and UI_HangUpWarn.Inst then
        UIMgr.Inst:CloseUIByClassName(UI_HangUpWarn.className)
    end
    if UI_TingPai and UI_TingPai.Inst then
        UI_TingPai.Inst.transform.gameObject:SetActive(true)
    end

    self.ju_count = 0
    self.index_chang = 0
    self.index_ju = 1
    self.index_ben = 0
    self.index_player = 0
    self.left_tile_count = 69
    self.duringReconnect = false
    self.current_step = 0
    self.action_index = 1
    self.do_chain_fast = false
    self.actionList = {}

    self:_setAutoHule(false)
    self:_setAutoMoQie(false)
    self:_setAutoNoFuLu(false)
    self:_setAutoBabei(false)

    UI_DesktopInfo.Inst:ResetFunc()
    if DesktopMgr.Inst:is_chuanma_mode() then
        self:_setChangJuShow(self.index_chang, self.ju_count)
    else
        self:_setChangJuShow(self.index_chang, self.index_ju)
    end
    UI_DesktopInfo.Inst:SetBen(self.index_ben)
    UI_DesktopInfo.Inst:SetZhenTing(false)
    for i = 1, 4 do
        self.players[i]:OnInitRoom(self:localPosition2Seat(i))
        self.players[i]:SetScore(0, 0)
        self.players[i].trans_ind.gameObject:SetActive(false)
        self.players[i].trans_lock.gameObject:SetActive(false)
        self.players[i]:RefreshDir()
    end
    self:RefreshPaiLeft()

    local chipeng_effect = Scene_MJ.Inst.mingPaiZhiShiId
    self:SetChiPengEffect(chipeng_effect)
    MJNetMgr.Inst:AppendLogInfo("鸣牌指示特效加载完毕")
    -- TODO
    -- UI_GameEnd.Inst.forceclose()
    -- UI_RankChange.Inst.close()
    -- UI_MJReward.Inst.close()

    MJNetMgr.Inst:AppendLogInfo("所有加载执行完毕，6 帧后调用回调")
    self.timerMgr:DelayFrame(6, function()
        MJNetMgr.Inst:AppendLogInfo("开始重设 DesktopMgr 状态")
        self:Reset()
        MJNetMgr.Inst:AppendLogInfo("重设 DesktopMgr 状态完毕，调用回调")
        if complete then
            complete()
        end
    end)

    if self.mode == EMJ_Mode.play then
        local d = DesktopMgr.Inst.game_config
        if d then
            local desc = Tools.get_room_desc(d).text
            Tools.UpdateSteamPresence(desc)

            if d:HasField('meta') then
                self.is_shilian = d.meta.mode_id == 36
            end
        end

        if UI_22Winter and UI_Activity.ActivityIsRunning(UI_22Winter.activity_id) then
            if not UI_22Winter.Inst then
                UIMgr.Inst:Init_22Winter()
            end
            self.cache_acitvity_point = UI_22Winter.Inst:GetCurPoint()
        end
        if UI_Activity_Dongri and UI_Activity.ActivityIsRunning(UI_Activity_Dongri.activity_id) then
            if not UI_Activity_Dongri.Inst then
                UIMgr.Inst:Init_DongRiJi()
            end
            self.cache_acitvity_point = UI_Activity_Dongri.point
        end

    elseif self.mode == EMJ_Mode.live_broadcast then
        Tools.UpdateSteamPresence('观战')
    elseif self.mode == EMJ_Mode.paipu then
        Tools.UpdateSteamPresence('牌谱')
    end

    self.isPlayedPrepareAudio = false
    UI_ErrorInfo.ClearLogReportCount()

    -- 赛事相关
    self.matchInfo = matchInfo or {}
    self.partyNameMeshList = {}
    self.partyNameItemList = {}
    -- 队伍名 RT 列表，退出局内场景时需要释放
    self.partyNameRTList = {}
    if (self.matchInfo.isPartyMatch) then
        local go = LuaTools.LoadPrefab("scenes/mj/party_match/prefab/party_name_root", self.desktop)
        self.partyShowInitiated = false
        self.partyRoot = go.transform
        self.partyNameMeshRoot = self.partyRoot:Find("mesh_root")
        self.partyNameUIRoot = self.partyRoot:Find("ui_root")
        for i = 1, 4 do
            table.insert(self.partyNameMeshList, self.partyNameMeshRoot:Find("name_" .. i):GetComponent(typeof(UnityEngine.MeshRenderer)))
            local item = {}
            item.transform = self.partyNameUIRoot:Find("name_" .. i)
            item.textName = item.transform:Find("Canvas/bg/name"):GetComponent(typeof(UnityEngine.UI.Text))
            item.cam = item.transform:Find("Camera"):GetComponent(typeof(UnityEngine.Camera))
            table.insert(self.partyNameItemList, item)
        end
        local templateRT = self.partyNameUIRoot:Find("Canvas/templateRT"):GetComponent(typeof(UnityEngine.UI.RawImage)).texture
        for i = 1, 4 do
            local rt = UnityEngine.RenderTexture.New(templateRT)
            table.insert(self.partyNameRTList, rt)
            self.partyNameMeshList[i].material.mainTexture = rt
            self.partyNameItemList[i].cam.targetTexture = rt
        end
        self.partyRoot.gameObject:SetActive(true)
        self:RefreshPartyShow()
    end
end

function DesktopMgr:SetNicknameAnonymous(anonymous)
    self.nickname_anonymous = anonymous
    if anonymous then
        local myplayerseat = -1
        for i =1,4 do
            if self.player_datas[i].account_id == self.myaccountid then
                self.player_datas[i].nickname = Tools.StrOfLocalization(3076)
                myplayerseat = i
            end
        end
        local _mode = 4
        if self.rule_mode == ERule_Mode.Liqi3 then
            _mode = 3
        end
        for i = 1, _mode do
            if i ~= myplayerseat then
                local name = ''
                if i == 1 then
                    name = Tools.StrOfLocalization(3073)
                elseif i == 2 then
                    name = Tools.StrOfLocalization(3074)
                elseif i == 3 then
                    name = Tools.StrOfLocalization(3075)
                elseif i == 4 then
                    name = Tools.StrOfLocalization(3079)
                end
                self.player_datas[i].nickname = name
            end
        end
    elseif #self.player_datas_temp > 0 then
        for i =1,4 do
            if self.player_datas[i] then
                self.player_datas[i].nickname = self.player_datas_temp[i]
            end
        end
    end
end

function DesktopMgr:OnApplicationPause(isPause)
    --在退出后台之前处于游戏模式

    if not self.last_pause_time then
        self.last_pause_time = 0
    end

    if not isPause and self.gameing and Mathf.Abs(self.last_pause_time - Tools.GetRealTime()) > 120 then
        GameMgr.Inst:ResetGame()
    end
    self.last_pause_time = Tools.GetRealTime()
end

function DesktopMgr:ChangeMainBody(seat)
    if self.mode == EMJ_Mode.play then
        return
    elseif self.mode == EMJ_Mode.paipu and not UI_Replay.Inst.canvas.interactable then
        return
    end
    self.seat = seat
    if (self.matchInfo and self.matchInfo.isPartyMatch) then
        self:RefreshPartyShow()
    end

    UI_DesktopInfo.Inst:RefreshSeat(true)
    for i = 1, 4 do
        self.players[i]:OnInitRoom(self:localPosition2Seat(i))
        self.players[i].trans_ind.gameObject:SetActive(false)
        self.players[i]:RefreshDir()
    end
    self:Reset()
    if self.mode == EMJ_Mode.paipu then
        UI_Replay.Inst:OnChangeMainBody()
    elseif self.mode == EMJ_Mode.live_broadcast then
        UI_LiveBroadcast_New.Inst:OnChangeMainBody()
    end
end

function DesktopMgr:RefreshPaiLeft()
    self:_setLeftPaiShow(self.left_tile_count)
end

--pai : MJPai
function DesktopMgr:CreatePai3D(pai)
    local maque
    if self.maquepool and #self.maquepool > 0 then
        maque = self.maquepool[#self.maquepool]
        table.remove(self.maquepool, #self.maquepool)
    else
        maque = UnityEngine.GameObject.Instantiate(self.templeteMaque.gameObject, self.desktop:Find('all')).transform
        maque:Find('maque_cover').gameObject:SetActive(false)
    end

    local pai_coord = self:get_pai_pos(pai)

    --todo 透明牌重构 不传is_toupai进来
    local pos = self:get_pai_pos(pai)
    if pai.open then
        local plane = nil
        if maque.transform:Find('pai_touyin') then
            plane = maque.transform:Find('pai_touyin')
        else
            plane = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/pai_touyin', maque.transform)
            plane.transform.gameObject.name = 'pai_touyin'
            plane.transform:SetLocalScale(0.0026,1,0.0039)
            plane.transform:SetLocalPos(0,-0.022,-0.0349)
        end

        local face_plane = nil
        if maque.transform:Find('pai_face') then
            face_plane = maque.transform:Find('pai_face')
        else
            face_plane = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/pai_face', maque.transform)
            face_plane.transform.gameObject.name = 'pai_face'
            face_plane.transform:SetLocalScale(0.0024,1,0.0033)
            face_plane.transform:SetLocalPos(0,0.0012,0.0099)
            face_plane.transform:SetLocalEuler(90,90,90)
        end
        plane.transform.gameObject:SetActive(true)
        face_plane.transform.gameObject:SetActive(true)
        plane:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 0)
        if pai.dora then
            plane.transform:Find('effect_dora').gameObject:SetActive(true)
        else
            plane.transform:Find('effect_dora').gameObject:SetActive(false)
        end
        face_plane:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 0)
        face_plane:Find('pai_back'):GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 0)

        -- 透明牌：禁用背景的render
        -- 使用一个新底板来制作
        local mjp_transparent = nil
        if maque.transform:Find('mjp_transparent') then
            mjp_transparent = maque.transform:Find('mjp_transparent')
        else
            mjp_transparent = LuaTools.LoadPrefab('scenes/mj/game_mode/mingjingzhizhan/prefab/mjp_transparent', maque.transform)
            mjp_transparent.transform.gameObject.name = 'mjp_transparent'
            mjp_transparent.transform:SetLocalScale(1,1,1)
            mjp_transparent.transform:SetLocalPos(0,0,0)
            mjp_transparent.transform:SetLocalEuler(0,0,0)
        end
        mjp_transparent.transform:SetAsFirstSibling()
        mjp_transparent.gameObject:SetActive(true)
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = false

        local pai_touyin = plane:Find('pai_touyin')
        if pai_touyin then
            local pai_touyin_mesh = pai_touyin:GetComponent(typeof(UnityEngine.MeshRenderer))
            if pai_touyin_mesh then
                pai_touyin_mesh.sharedMaterial = LuaTools.LoadMaterial("scenes/mj/game_mode/mingjingzhizhan/material/plane_touyin")
                Tools.GetLocalizedTexture("scenes/mj/game_mode/mingjingzhizhan/texture/touying", function(texture)
                    pai_touyin_mesh.sharedMaterial:SetTexture('_MainTex', texture)
                end)
            end
        end

    else
        if maque.transform:Find('pai_touyin') then
            maque.transform:Find('pai_touyin').gameObject:SetActive(false)
        end
        if maque.transform:Find('pai_face') then
            maque.transform:Find('pai_face').gameObject:SetActive(false)
        end
        if maque.transform:Find('mjp_transparent') then
            maque.transform:Find('mjp_transparent').gameObject:SetActive(false)
        end
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)).enabled = true
        self:setPai3DFace(maque, pai_coord, pai.baida)

    end

    return maque
end

function DesktopMgr:setPai3DFace(maque,pai_coord,baida)
    local m1 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_mid')
    local m2
    if baida then
        m2 = LuaTools.LoadMaterial('scenes/mj/game_mode/wanxiangxiuluo/material/mjp_face')
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)).sharedMaterials = {m1,m2}
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(1, 1, 0, 0, 1)
    else
        m2 = LuaTools.LoadMaterial('scenes/mj/mjtable/material/mjp_face')
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)).sharedMaterials = {m1,m2}
        maque:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 1)
    end
end

function DesktopMgr:SetPai3D(model,pai)
    local pai_coord = self:get_pai_pos(pai)
    model:GetComponent(typeof(UnityEngine.MeshRenderer)):SetTileOffset(pai_coord.lx, pai_coord.ly, pai_coord.x, pai_coord.y, 1)
end

function DesktopMgr:get_pai_pos(pai)
    local s = pai:ToString()
    return DesktopMgr.GetTextureOffsetByPaiStr(s)
end

function DesktopMgr.GetTextureOffsetByPaiStr(pai)
    local type = string.sub(pai, 2, 2)
    local index = tonumber(string.sub(pai, 1, 1)) or 0
    if type == 'p' then
        index = index + 10
    elseif type == 's' then
        index = index + 20
    elseif type == 'z' then
        index = index + 29
    end

    local offsetY = 18 / 1025
    local spacing = 4 / 1024
    local offsetX = 6 / 1024
    local lx = 100 / 1024
    local ly = 140 / 1024

    local x = index % 7
    local y = Mathf.Floor(index / 7)

    x = offsetX + x * (lx + spacing)
    y = 1 - ((y + 1) * (ly + spacing))

    return{
        lx = lx,
        ly = ly,
        x = x,
        y = y
    }
end

function DesktopMgr:FetchLinks()
    local request = ProtoMgr.CreateRequest('FastTest', 'fetchGamePlayerState')
    MJNetMgr.Inst:SendRequest('FastTest', 'fetchGamePlayerState', request, function(err, res)
        if err or (res.error and res.error.code ~= 0) then
            UIMgr.Inst:ShowUI(UI_ErrorInfo.className, nil, { errorType = UI_ErrorInfo.ErrorType.NetWork, method = 'fetchGamePlayerState', error = err, res = res })
        else
            for i = 1, #res.state_list do
                self.player_link_state[i] = res.state_list[i]
            end
            UI_DesktopInfo.Inst:RefreshLinks()
        end
    end)
end

function DesktopMgr:RefreshPlayerIndicator()
    for i = 1, 4 do
        self.players[i].trans_ind.gameObject:SetActive(i == self:seat2LocalPosition(self.index_player))
        self.players[i]:RefreshScore(self.mainrole.score)
    end
end

function DesktopMgr:OperationTimeOut()
    if #self.oplist == 0 then return end
    local needshow_chipeng = false
    local needshow_zimoangang = false
    local can_rong = false
    local can_zimo = false
    local can_discard = false
    local showing = self.operation_showing
    self.operation_showing = true
    local ban_discard_list = nil
    self.hang_up_count = self.hang_up_count + 1
    local flag = true
    for i = 1, #self.oplist do
        if self.oplist[i].type == E_PlayerOperation.eat or
            self.oplist[i].type == E_PlayerOperation.peng or
            self.oplist[i].type == E_PlayerOperation.ming_gang or
            self.oplist[i].type == E_PlayerOperation.rong or
            self.oplist[i].type == E_PlayerOperation.unveil then
            needshow_chipeng = true
        end

        if self.oplist[i].type == E_PlayerOperation.an_gang or
            self.oplist[i].type == E_PlayerOperation.add_gang or
            self.oplist[i].type == E_PlayerOperation.liqi or
            self.oplist[i].type == E_PlayerOperation.zimo or
            self.oplist[i].type == E_PlayerOperation.jiuzhongjiupai or
            self.oplist[i].type == E_PlayerOperation.reveal or
            self.oplist[i].type == E_PlayerOperation.revealliqi or
            self.oplist[i].type == E_PlayerOperation.locktile or
            self.oplist[i].type == E_PlayerOperation.babei then
            needshow_zimoangang = true
        end

        if self.oplist[i].type == E_PlayerOperation.dapai then
            can_discard = true
            ban_discard_list = self.oplist[i].combination
        end
        if self.oplist[i].type == E_PlayerOperation.liqi then
            can_discard = true
        end
        if self.oplist[i].type == E_PlayerOperation.rong then
            can_rong = true
        end
        if self.oplist[i].type == E_PlayerOperation.zimo then
            can_zimo = true
        end
    end

    if needshow_chipeng then
        if can_rong then
            local request = ProtoMgr.CreateRequest('FastTest', 'inputChiPengGang')
            request.type = E_PlayerOperation.rong
            request.index = 0
            request.timeuse = 1000000
            MJNetMgr.Inst:SendRequest('FastTest', 'inputChiPengGang', request, function(err, res) end)
        else
            local request = ProtoMgr.CreateRequest('FastTest', 'inputChiPengGang')
            request.cancel_operation = true
            request.timeuse = 1000000
            MJNetMgr.Inst:SendRequest('FastTest', 'inputChiPengGang', request, function(err, res) end)
        end
        self:ClearOperationShow()
    else
        local hule = false
        if can_zimo then
            local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
            request.type = E_PlayerOperation.zimo
            request.index = 0
            request.timeuse = 1000000
            MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res) end)
        elseif can_discard then
            if self.mainrole._during_liqi then
                local pai = nil
                local moqie = false
                local is_open = false
                for i = 1, #self.mainrole._handpai do
                    if self.mainrole._handpai[i].valid and (not self.mainrole._handpai[i].pai.baida)then
                        pai = self.mainrole._handpai[i].pai
                        moqie = self.mainrole._handpai[i] == self.mainrole._last_tile
                        is_open = self.mainrole._handpai[i].is_open
                    end
                end
                self:Action_LiQi(pai, moqie, is_open)
            else
                local pai = nil
                local moqie = false
                local is_open = false

                if self.mainrole._last_tile and self.mainrole._last_tile.valid and (not self.mainrole._last_tile.pai.baida) then
                    pai = self.mainrole._last_tile.pai
                    moqie = true
                    is_open = self.mainrole._last_tile.is_open
                end

                if not pai then
                    for i = 1, #self.mainrole._handpai do
                        if self.mainrole._handpai[i].valid and (not self.mainrole._handpai[i].pai.baida) then
                            pai = self.mainrole._handpai[i].pai
                            moqie = false
                            is_open = self.mainrole._handpai[i].is_open
                        end
                    end
                end
                self:Action_QiPai(pai, moqie, true, is_open)
            end
        elseif needshow_zimoangang then
            local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
            request.cancel_operation = true
            request.timeuse = 1000000
            MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res) end)
            self:ClearOperationShow()
        end
    end
end

--number:int[]
function DesktopMgr:SetScores(scores)
    for i = 1, #scores do
        self.players[self:seat2LocalPosition(i)]:SetScore(scores[i], scores[self.seat])
    end
end

function DesktopMgr:SetScoreDelta(value)
    for i = 2, 4 do
        self.players[i].duringShowDelta = value
        self.players[i]:RefreshScore(self.mainrole.score)
    end
end

--value:bool
function DesktopMgr:_setAutoLiPai(value)
    self.auto_liqi = value
    if self.auto_liqi then
        Tools.getplayerprefshandler().SetInt('auto_liqi', 1)
    else
        Tools.getplayerprefshandler().SetInt('auto_liqi', 0)
    end
    if value then
        if self.gameing and self.mainrole then
            self.mainrole:_LiPai(nil, true)
        end
    end
end

--value:bool
function DesktopMgr:_setAutoHule(value)
    self.auto_hule = value
    self:_PendingAuto()
end

--value:bool
function DesktopMgr:_setAutoMoQie(value)
    self.auto_moqie = value
    self:_PendingAuto()
end

--value:bool
function DesktopMgr:_setAutoBabei(value)
    self.auto_babei = value
    self:_PendingAuto()
end

--value:bool
function DesktopMgr:_setAutoNoFuLu(value)
    self.auto_nofulu = value
    self:_PendingAuto()
end

---处理oplist
---@return boolean 返回是否需要countdown
function DesktopMgr:_PendingAuto()
    if #self.oplist == 0 then return false end
    local needshow_chipeng = false
    local needshow_zimoangang = false
    local needshow_changetile = false
    local needshow_selectgap = false
    local needshow_selecttile = false
    local can_rong = false
    local can_zimo = false
    local can_discard = false
    local can_reveal = false
    local can_babei = false
    local showing = self.operation_showing
    local ban_discard_list = {}
    self.operation_showing = true
    self.liqi_select = {}
    for i = 1, #self.oplist do
        if self.oplist[i].type == E_PlayerOperation.eat or
            self.oplist[i].type == E_PlayerOperation.peng or
            self.oplist[i].type == E_PlayerOperation.ming_gang or
            self.oplist[i].type == E_PlayerOperation.rong or
            self.oplist[i].type == E_PlayerOperation.unveil then
            needshow_chipeng = true
        end

        if self.oplist[i].type == E_PlayerOperation.an_gang or
            self.oplist[i].type == E_PlayerOperation.add_gang or
            self.oplist[i].type == E_PlayerOperation.liqi or
            self.oplist[i].type == E_PlayerOperation.zimo or
            self.oplist[i].type == E_PlayerOperation.jiuzhongjiupai or
            (self.oplist[i].type == E_PlayerOperation.reveal and not self.auto_moqie) or
            self.oplist[i].type == E_PlayerOperation.revealliqi or
            self.oplist[i].type == E_PlayerOperation.locktile then
            -- self.oplist[i].type == E_PlayerOperation.babei then
            needshow_zimoangang = true
        end

        if self.oplist[i].type == E_PlayerOperation.dapai then
            can_discard = true
            ban_discard_list = self.oplist[i].combination
        end

        if self.oplist[i].type == E_PlayerOperation.reveal then
            can_reveal = true
        end
        if self.oplist[i].type == E_PlayerOperation.liqi then
            can_discard = true
            for j = 1, #self.oplist[i].combination do
                table.insert(self.liqi_select, MJPai:Init(self.oplist[i].combination[j]))
            end
        end
        if self.oplist[i].type == E_PlayerOperation.rong then
            can_rong = true
        end
        if self.oplist[i].type == E_PlayerOperation.zimo then
            can_zimo = true
        end

        if self.oplist[i].type == E_PlayerOperation.babei then
            can_babei = true
        end
        if self.oplist[i].type == E_PlayerOperation.changetile or self.oplist[i].type == E_PlayerOperation.po_tribute_choose_tile then
            needshow_changetile = true
            local data = self.oplist[i]
            if data and data.change_tiles and #data.change_tiles > 0 then
                local change_tiles = {}
                local change_tile_states = {}
                for i = 1, #data.change_tiles do
                    table.insert(change_tiles, data.change_tiles[i])
                    if self:IsTargetSpecialMode(EMJGameRule.QiangDuoZhiZhan) then
                        table.insert(change_tile_states, 0)
                    else
                        table.insert(change_tile_states, data.change_tile_states[i])
                    end
                end
                DesktopMgr.Inst.change_tiles = {}
                for i = 1, #change_tiles do
                    table.insert(DesktopMgr.Inst.change_tiles, MJPai:Init(data.change_tiles[i]))
                end
                DesktopMgr.Inst.change_tile_states = change_tile_states
            end
        end
        if self.oplist[i].type == E_PlayerOperation.selectgap then
            needshow_selectgap = true
            DesktopMgr.Inst.gap_type_recom = self.oplist[i].gap_type
        end

        if self.oplist[i].type == E_PlayerOperation.selecttile then
            needshow_selecttile = true
        end
    end

    local auto_hule = self.auto_hule
    local auto_nofulu = self.auto_nofulu
    local auto_moqie = self.auto_moqie
    local auto_babei = self.auto_babei

    if auto_hule and (can_rong or can_zimo) then
        self.timerMgr:Delay(0.8, function()
            if can_rong then
                local request = ProtoMgr.CreateRequest('FastTest', 'inputChiPengGang')
                request.type = E_PlayerOperation['rong']
                request.index = 0
                -- request.auto_operation = true
                MJNetMgr.Inst:SendRequest('FastTest', 'inputChiPengGang', request, function() end)
            elseif can_zimo then
                local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
                request.type = E_PlayerOperation['zimo']
                request.index = 0
                request.auto_operation = true
                MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function() end)
            end
        end)
        self:ClearOperationShow()
        return false
    end

    if needshow_chipeng then
        if auto_nofulu and not can_rong and not can_zimo then
            local request = ProtoMgr.CreateRequest('FastTest', 'inputChiPengGang')
            request.cancel_operation = true
            -- request.auto_operation = true
            MJNetMgr.Inst:SendRequest('FastTest', 'inputChiPengGang', request, function() end)
            self:ClearOperationShow()
            return false
        else
            if not showing then
                UIMgr.Inst:ShowUI(UI_ChiPengHu.className, nil, self.oplist)
            end
        end
    else
        if needshow_changetile then
            if not showing then
                self.timerMgr:Delay(0.7, function()
                    UIMgr.Inst:ShowUI(UI_ChangeTile.className)
                    DesktopMgr.Inst.mainrole:_ChangeTileSelect()
                end)
            end
        end

        if needshow_selectgap then
            if not showing then
                -- self.timerMgr:Delay(0.7, function()
                UIMgr.Inst:ShowUI(UI_SelectGap.className)
                -- end)
            end
        end

        if needshow_selecttile then
            if auto_moqie then
                UI_DesktopInfo.Inst:SelectTileAuto()
                return false
            elseif not showing then
                UI_DesktopInfo.Inst:ShowSelectTile()
            end
        end

        if needshow_zimoangang then
            if not showing then
                UIMgr.Inst:ShowUI(UI_LiqiZimo.className, nil, self.oplist)
            end
        elseif can_babei then

            if auto_babei then -- 同 UI_LiqiZimo.Container_Btns:Btn_Babei()

                local moqie = false
                if DesktopMgr.Inst.mainrole._last_tile and DesktopMgr.Inst.mainrole._last_tile.pai:ToString() == '4z' then
                    moqie = true
                end

                if DesktopMgr.Inst.mode == EMJ_Mode.play then
                    AudioMgr.PlayAudio(101)
                    local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
                    request.type = E_PlayerOperation['babei']
                    request.moqie = moqie
                    request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
                    request.auto_operation = true
                    MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function() end)
                    UI_LiqiZimo.Inst.on_do_operation = true
                    DesktopMgr.Inst:WhenDoOperation()
                end
            else
                if not showing then
                    UIMgr.Inst:ShowUI(UI_LiqiZimo.className, nil, self.oplist)
                end
            end
        end


        if can_discard then
            if auto_moqie then
                if not UI_LiqiZimo.Inst.transform.gameObject.activeSelf then
                    if self.mainrole._last_tile then
                        self:Action_QiPai(self.mainrole._last_tile.pai, true, true, self.mainrole._last_tile.is_open, true)
                        return false
                    end
                end
            end

            if not showing then
                self.mainrole._can_discard = true
                if #ban_discard_list > 0 then
                    local list = {}
                    for i = 1, #ban_discard_list do
                        table.insert(list, MJPai:Init(ban_discard_list[i]))
                    end
                    self.mainrole:_ChiTiSelect(list)
                end
            end
        else
            self.mainrole._can_discard = false
        end
        if can_reveal and auto_moqie then
            if not self.mainrole._can_discard and not UI_LiqiZimo.Inst.transform.gameObject.activeSelf then
                local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
                request.auto_operation = true
                request.cancel_operation = true
                request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
                MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function() end)
                DesktopMgr.Inst:WhenDoOperation()
            end
            return
        end
    end


    return true
end

--pai:MJPai, moqie, timeout:bool
function DesktopMgr:Action_QiPai(pai, moqie, timeout, is_open, isAuto)
    if not pai then return end
    xpcall(function()
        local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
        request.type = E_PlayerOperation['dapai']
        request.tile = pai:ToString()
        request.moqie = moqie
        request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
        request.tile_state = 0
        if is_open then
            request.tile_state = 1
        end
        if isAuto then
            request.auto_operation = true
        end
        MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res)
            if err or (res.error and res.error.code ~= 0) then
                LogTool.Warning('Desktop', 'Action_QiPai 失败: ' .. 'request: ' .. pt.block(request) .. ' err: ' .. pt.block(err) .. ' res: ' .. pt.block(res))
            end
        end)
    end, function()

    end)
    if timeout then
        self:ClearOperationShow()
    else
        self:WhenDoOperation()
    end
end

function DesktopMgr:Action_RevealLiqi(pai, moqie, is_open)
    if not self.liqi_select or #self.liqi_select == 0 then return false end
    local isOK = false
    for i = 1, #self.liqi_select do
        if MJPai.Distance(self.liqi_select[i], pai) == 0 then
            isOK = true
        end
    end
    if not isOK then return false end

    LogTool.Info('Desktop', 'Action_RevealLiqi: ' .. pai:ToString())
    local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
    request.type = E_PlayerOperation['revealliqi']
    request.tile = pai:ToString()
    request.moqie = moqie
    request.tile_state = 0
    if is_open then
        request.tile_state = 1
    end
    request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
    MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res)
        if err or (res.error and res.error.code ~= 0) then
            LogTool.Warning('Desktop', 'Action_RevealLiqi 失败: ' .. pt.block(res))
        end
    end)
    self:WhenDoOperation()
    return true
end

function DesktopMgr:Action_Reveal(pai, moqie, is_open)
    LogTool.Info('Desktop', 'Action_Reveal: ' .. pai:ToString())
    local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
    request.type = E_PlayerOperation['reveal']
    request.tile = pai:ToString()
    request.moqie = moqie
    request.tile_state = 0
    if is_open then
        request.tile_state = 1
    end
    request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
    MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res)
        if err or (res.error and res.error.code ~= 0) then
            LogTool.Warning('Desktop', 'Action_Reveal 失败: ' .. pt.block(res))
        end
    end)
    self:WhenDoOperation()
    return true
end

--pai:MJPai, moqie:bool
function DesktopMgr:Action_LiQi(pai, moqie, is_open)
    if not self.liqi_select or #self.liqi_select == 0 then return false end
    local isOK = false
    for i = 1, #self.liqi_select do
        if MJPai.Distance(self.liqi_select[i], pai) == 0 then
            isOK = true
        end
    end
    if not isOK then return false end
    local operateType = E_PlayerOperation.liqi
    if self:is_beishui_mode() and self.mainrole.liqiOperation then
        if (self.mainrole.liqiOperation == E_PlayerOperation.po_liqi_5000)
            or (self.mainrole.liqiOperation == E_PlayerOperation.po_liqi_10000) then
            operateType = self.mainrole.liqiOperation
        end
    end

    LogTool.Info('Desktop', 'Action_LiQi: ' .. pai:ToString())
    local request = ProtoMgr.CreateRequest('FastTest', 'inputOperation')
    request.type = operateType -- E_PlayerOperation['liqi']
    request.tile = pai:ToString()
    request.moqie = moqie
    request.tile_state = 0
    if is_open then
        request.tile_state = 1
    end
    request.timeuse = UI_DesktopInfo.Inst.time_cd:get_Time_Used()
    MJNetMgr.Inst:SendRequest('FastTest', 'inputOperation', request, function(err, res)
        if err or (res.error and res.error.code ~= 0) then
            LogTool.Warning('Desktop', 'Action_LiQi 失败: ' .. pt.block(res))
        end
    end)
    self:WhenDoOperation()
    return true
end

function DesktopMgr:OnShowHandChanged(bool)
    if self.mode == EMJ_Mode.live_broadcast then
        self.live_show_hand = bool
        --天命模式 开手牌后需要重新理牌
        if DesktopMgr.Inst:is_tianming_mode() then
            for i = 1, #self.players do
                self.players[i]:_LiPai()
            end
        end
        UI_DesktopInfo.Inst:refreshTingpaiShow()
    elseif self.mode == EMJ_Mode.paipu then
        self.record_show_hand = bool
        Tools.getplayerprefshandler().SetInt('record_show_hand', Tools.bool2int(bool))
        --天命模式 开手牌后需要重新理牌
        if DesktopMgr.Inst:is_tianming_mode() then
            for i = 1, #self.players do
                self.players[i]:_LiPai()
            end
        end
        UI_DesktopInfo.Inst:refreshTingpaiShow()
    elseif self.mode == EMJ_Mode.play then
        return
    end
    if not self.gameing then return end
    for i = 1, #self.players do
        self.players[i]:_OnShowHandChanged(bool)
    end
end

function DesktopMgr:OnShowPaopaiChanged(bool)
    if self.mode == EMJ_Mode.live_broadcast then
        self.live_show_paopai = bool
    elseif self.mode == EMJ_Mode.paipu then
        self.record_show_paopai = bool
        Tools.getplayerprefshandler().SetInt('record_show_paopai', Tools.bool2int(bool))
    elseif self.mode == EMJ_Mode.play then
        return
    end
    if not self.gameing then return end
    if self.mode == EMJ_Mode.play then return end
    for i = 1, #self.players do
        self.players[i]:_OnShowPaopaiChanged()
        local seat = self:localPosition2Seat(i)
        if seat > 0 then
            for j = 1, #self.players[i].container_qipai.pais do
                local pai = self.players[i].container_qipai.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end
            for j = 1, #self.players[i].container_babei.pais do
                local pai = self.players[i].container_babei.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end
            for j = 1, #self.players[i].container_ming.pais do
                local pai = self.players[i].container_ming.pais[j]
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end

            local pai = self.players[i].container_qipai.last_pai
            if pai then
                pai.ispaopai = self:IsPaoPai(pai.pai)
                pai:OnChoosed()
            end
        end
    end
end

function DesktopMgr:OnFollowDealerChanged(bool)
    if self.mode == EMJ_Mode.live_broadcast then
        self.live_follow_dealer = bool
    elseif self.mode == EMJ_Mode.paipu then
    elseif self.mode == EMJ_Mode.play then
        return
    end
    if not self.gameing then return end
    if self.mode == EMJ_Mode.play then return end
    if bool and self.seat ~= self.index_ju then
        self:ChangeMainBody(self.index_ju)
    end
end

-- data:{
--     seat:int,
--     count:int,
--     count_max:int,
--     id:int
-- }
function DesktopMgr:OnMuyuChange(data, do_anim)
    LogTool.Info('Desktop', 'onmuyuchanged: ' .. pt.block(data) .. ' do_anim: ' .. tostring(do_anim))
    info = {
        seat = data.seat + 1,
        count = data.count,
        count_max = data.count_max,
        id = data.id
    }
    local change_seat = false
    if not self.muyu_info or self.muyu_info.id ~= info.id then
        change_seat = true
    end
    if not do_anim then
        for i = 1, #self.players do
            self.players[i].container_muyu:Hide(0, do_anim)
        end
        self.muyu_info = info
        local seat = self:seat2LocalPosition(info.seat)
        self.players[seat].container_muyu:Show(info.count, do_anim)
    else
        local container_new = self.players[self:seat2LocalPosition(info.seat)].container_muyu
        if change_seat then
            if self.muyu_info then
                local container_old = self.players[self:seat2LocalPosition(self.muyu_info.seat)].container_muyu
                container_old:Hide(self.muyu_info.count, true)
            end
            container_new:Show(info.count, true)
        else
            if self.muyu_info.count ~= info.count then
                container_new:Show(info.count, true)
            end
        end
        self.muyu_info = info
    end
end

function DesktopMgr:ClearLiqiBang()
    for i = 1, #self.players do
        self.players[i]:HideLiqiBang()
    end
    UI_DesktopInfo.Inst:SetLiqibang(0)
end

function DesktopMgr:SetRevealModeLiqiBang(count, do_anim)
    local container = self.desktop:Find('other_special')
    if self:is_reveal_discard_mode() then
        if self.liqibang_count == count then
            return
        end
        container.gameObject:SetActive(true)
        if not self.reveal_discard_liqibang_num then
            self.reveal_discard_liqibang_num = {}
            for i = 1, 6 do
                table.insert(self.reveal_discard_liqibang_num, container:Find(tostring(i - 1)):GetComponent(typeof(UnityEngine.MeshRenderer)))
            end
        end
        for i = 1, #self.reveal_discard_liqibang_num do
            self.reveal_discard_liqibang_num[i].material.mainTextureOffset = Vector2(0,0.9)
        end
        -- AudioMgr.PlayAudio(222)
        local roulette_roller = function(obj, target)
            DG.Tweening.DOTween.To(
                DG.Tweening.Core.DOGetter_float(function()
                    return obj.material.mainTextureOffset.y
                end),
                DG.Tweening.Core.DOSetter_float(function(y)
                    obj.material.mainTextureOffset = Vector2(0,y)
                end),
                target,0.6)
        end

        if count == 0 then
            for i = 1, #self.reveal_discard_liqibang_num do
                self.reveal_discard_liqibang_num[i].gameObject:SetActive(false)
            end
            self.reveal_discard_liqibang_num[3].gameObject:SetActive(true)
        else
            local length = #tostring(count)
            local mod = 0
            if length < 3 then mod = 1 end
            for i = 1 + mod, length + 3 + mod do
                self.reveal_discard_liqibang_num[i].gameObject:SetActive(true)
            end
        end

        local index = 4
        if count < 100 then index = index + 1 end
        local temp_count = count
        local flag = false
        for i = 1, #tostring(count) do
            local pos = 0.1 * (9 - Mathf.Floor(temp_count % 10))
            local temp_y = self.reveal_discard_liqibang_num[index].material.mainTextureOffset.y
            if pos ~= temp_y and do_anim then
                roulette_roller(self.reveal_discard_liqibang_num[index], pos + 1)
                if not flag then
                    flag = true
                    TimeMgr.Loop(0.1,6,function()
                        AudioMgr.PlayAudio(222)
                    end)
                end
            else
                self.reveal_discard_liqibang_num[index].material.mainTextureOffset = Vector2(0, pos)
            end
            index = index + 1
            temp_count = Mathf.Floor(temp_count / 10)
        end

        self.liqibang_count = count
    else
        container.gameObject:SetActive(false)
    end
end

--主视角是否副露
function DesktopMgr:IsFulu()
    return self.mainrole.container_ming:IsFulu()
end

--num:int
function DesktopMgr:_setLeftPaiShow(num)
    if num >= 100 then num = 99
    elseif num < 0 then num = 0 end

    local nums = {}
    nums[1] = num % 10
    nums[2] = Mathf.Floor(num / 10)

    local container = nil
    for i = 1, 2 do
        local offset = nums[i] * 0.1
        if GameMgr.Inst.prefer_language ~= 'en' then
            self.num_left_show[i]:SetTileOffset(0.1, 1, offset, 0)
            container = self.num_left_show[i].transform.parent
        else
            self.num_left_show_en[i]:SetTileOffset(0.1, 1, offset, 0)
            container = self.num_left_show_en[i].transform.parent
        end
    end

    if self:is_reveal_discard_mode() then
        container:SetLocalScale(0.7, 0.7, 0.7)
        container:SetLocalPos(-0.00355, 0, -0.00681)
    else
        container:SetLocalScale(1, 1, 1)
        container:SetLocalPos(0, 0, -0.001)
    end
end

--chang, ju:int
function DesktopMgr:_setChangJuShow(chang, ju)
    local chang_offset = 0
    if GameMgr.Inst.prefer_language ~= 'en' then
        chang_offset = (chang) % 4 * 0.167
    else
        chang_offset = (chang) % 4
    end
    if DesktopMgr.Inst:is_chuanma_mode() then
        chang_offset = 0
    end
    local container = nil
    local ju_offset = (ju - 1) * 0.1
    if GameMgr.Inst.prefer_language ~= 'en' then
        self.plane_chang:SetTileOffset(0.167, 1, chang_offset, 0)
        self.plane_ju:SetTileOffset(0.1, 1, ju_offset, 0)
        container = self.plane_chang.transform.parent
    else
        LogTool.Info('Desktop', 'changplane: ' .. (0.8 - chang_offset * 0.2) .. ' ju_offset:' .. ju_offset)
        self.plane_chang_en:SetTileOffset(1, 0.2, 0,0.8 - chang_offset * 0.2)
        self.plane_ju_en:SetTileOffset(0.1, 1, ju_offset, 0)
        container = self.plane_chang_en.transform.parent
    end

    if self:is_reveal_discard_mode() then
        container:SetLocalScale(0.7, 0.7, 0.7)
        container:SetLocalPos(0.00424, 0, -0.011)
    else
        container:SetLocalScale(1, 1, 1)
        container:SetLocalPos(0.0028, 0, -0.011)
    end
end

--action: 0输1胡2流局
function DesktopMgr:_onRoundAction(seat, action)
    local localPosition = self:seat2LocalPosition(seat)
    self.players[localPosition]:OnRoundAction(action)
end

--- 获取玩家昵称
--- @param index number seat
--- @return string
--- @return string 应显示的昵称, boolean 是否是备注
function DesktopMgr:get_player_name(index)
    local _t =  Taboo.Inst:Test(self.player_datas[index].nickname)
    if _t and _t ~= '' and not Tools.IsSameZone(self.player_datas[index].account_id, GameMgr.Inst.account_id) then return Tools.StrOfLocalization(3060), false end
    local type = GameMgr.Inst:GetPlayerNicknameFilteredType(self.player_datas[index].account_id, self:get_name_filter_service_type())
    if not self.nickname_anonymous then
        if type == 1 or type == 2 then
            local value = nil
            local account_id = self.player_datas[index].account_id
            local set_name = function()
                if not UI_Name.replace_dics[account_id] then
                    local replace_lst = GameMgr.Inst:get_nickname_replace_lst(type)
                    local index = Mathf.Floor(Mathf.Random() * #replace_lst + 1)
                    UI_Name.replace_dics[account_id] =
                    replace_lst[index]
                end
                value = UI_Name.replace_dics[account_id]
                -- assert(value)
            end
            if not Tools.IsSameZone(account_id, GameMgr.Inst.account_id) and GameMgr.Inst.nickname_replace_enable then
                --GM后台配置
                set_name()
            else
                --主播模式
                if GameMgr.fake_name_pool[account_id] then
                    value = GameMgr.fake_name_pool[account_id] or ''
                    -- assert(value)
                else
                    set_name()
                end
            end

            return value, false
        else
            -- 检查备注
            local account_id = self.player_datas[index].account_id
            local needRemark = FriendMgr.HasRemark(account_id)
            if needRemark and type < 0 then
                local friendData = FriendMgr.Find(account_id)
                return friendData.remark, true
            end
        end
    end
    return self.player_datas[index].nickname, false
end

--seat:int 从1开始的
function DesktopMgr:seat2LocalPosition(seat)
    if self.rule_mode == ERule_Mode.Liqi3 then
        local __s = self.seat
        for i = 1, 4 do
            if seat == __s then return i end
            __s = __s + 1
            if __s >= 4 then __s = 0 end
        end
        return 0
    else
        return (seat - self.seat + 4) % 4 + 1
    end
end

--localPosition:int 从1开始的
function DesktopMgr:localPosition2Seat(localPosition)
    if self.rule_mode == ERule_Mode.Liqi3 then
        local __s = self.seat
        for i = 1, localPosition - 1 do
            __s = __s + 1
            if __s >= 4 then __s = 0 end
        end
        return __s
    else
        return (self.seat - 1 + localPosition - 1) % 4 + 1
    end
end

function DesktopMgr:get_main_role_character_info()
    return self.player_datas[self.seat].character
end

function DesktopMgr:get_round_id()
    return tostring(self.index_chang)..'-'..tostring(self.index_ju)..'-'..tostring(self.index_ben)
end

function DesktopMgr:get_player_count()
    if self.rule_mode == ERule_Mode.Liqi3 then
        return 3
    else
        return 4
    end
end

--- @param excludeHands boolean|any 排除其他三家的手牌
function DesktopMgr:get_pai_left(pai, excludeHands)
    local num = 0
    for i = 1, 4 do
        local p = self.players[i]
        for j = 1, #p.container_babei.pais do
            if MJPai.Distance(p.container_babei.pais[j].pai, pai) == 0 then
                num = num + 1
            end
        end
        for j = 1, #p.container_ming.pais do
            if MJPai.Distance(p.container_ming.pais[j].pai, pai) == 0 then
                num = num + 1
            end
        end
        for j = 1, #p.container_qipai.pais do
            if MJPai.Distance(p.container_qipai.pais[j].pai, pai) == 0 then
                if not p.container_qipai.pais[j].isreveal or excludeHands then
                    num = num + 1
                end
            end
        end
        if p.container_qipai.last_pai then
            if MJPai.Distance(p.container_qipai.last_pai.pai, pai) == 0 then
                if not p.container_qipai.last_pai.isreveal or excludeHands then
                    num = num + 1
                end
            end
        end
    end

    for i = 1, #self.mainrole._handpai do
        if MJPai.Distance(self.mainrole._handpai[i].pai, pai) == 0 then
            num = num + 1
        end
    end
    for i = 1, #self.dora do
        if MJPai.Distance(self.dora[i], pai) == 0 then
            num = num + 1
        end
    end

    for i = 1,#self.misc_opens do
        if MJPai.Distance(self.misc_opens[i], pai) == 0 then
            num = num + 1
        end
    end

    if excludeHands then
        for i = 2, 4 do
            local p = self.players[i]
            for j = 1, #p._handpai3D do
                if MJPai.Distance(p._handpai3D[j].pai, pai) == 0 then
                    num = num + 1
                end
            end
        end
    else
        for i = 2, 4 do
            local p = self.players[i]
            for j = 1, #p._handpai3D do
                if p._handpai3D[j].is_open or p._handpai3D[j].pai.open or (DesktopMgr.Inst:is_tianming_mode() and p._handpai3D[j].pai.tianming) then
                    if MJPai.Distance(p._handpai3D[j].pai, pai) == 0 then
                        num = num + 1
                    end
                end
            end
        end
    end

    local n = 4 - num
    return Mathf.Clamp(n, 0, 4)
end

function DesktopMgr:get_show_paopai()
    return self.mode ~= EMJ_Mode.play
end

function DesktopMgr:get_show_moqie()
    return (self.mode ~= EMJ_Mode.play and self.mode ~= EMJ_Mode.tutorial) or self:is_yongchang_mode()
end

--return int
function DesktopMgr:get_gang_count()
    local count = 0
    for i = 1, #self.players do
        local seat = self:localPosition2Seat(i)
        if seat > 0 then
            local mings = self.players[i].container_ming.mings
            for j = 1, #mings do
                if mings[j].type == E_Ming.gang_an or mings[j].type == E_Ming.gang_ming then
                    count = count + 1
                end
            end
        end
    end
    return count
end

function DesktopMgr:get_babei_count()
    local count = 0
    for i = 1, #self.players do
        local seat = self:localPosition2Seat(i)
        if seat > 0 then
            count = count + #self.players[i].container_babei.pais
        end
    end
    return count
end

function DesktopMgr:is_dora3_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.dora3_mode == 1
end

function DesktopMgr:IsSimulationOb()
    --模拟对局ob
    return self.game_config.is_simulation and self.game_config.is_ob
end

function DesktopMgr:_record_show_hand()
    if self:IsSimulationOb() then
        return false
    end
    if self.mode == EMJ_Mode.play then return false end
    if self.mode == EMJ_Mode.live_broadcast then return self.live_show_hand end
    if self.mode == EMJ_Mode.paipu then return self.record_show_hand end
end

function DesktopMgr:_record_show_paopai()
    if self:IsSimulationOb() then
        return false
    end
    if self.mode == EMJ_Mode.play then return false end
    if self.mode == EMJ_Mode.live_broadcast then return self.live_show_paopai end
    if self.mode == EMJ_Mode.paipu then return self.record_show_paopai end
end

function DesktopMgr:_record_show_anim()
    if self:IsSimulationOb() then
        return true
    end
    if self.mode == EMJ_Mode.play then return true end
    if self.mode == EMJ_Mode.live_broadcast then return true end
    if self.mode == EMJ_Mode.paipu then return self.record_show_anim end
end

function DesktopMgr:_record_show_tingpai()
    if self:IsSimulationOb() then
        return false
    end
    if self.mode == EMJ_Mode.play then return false end
    if self.mode == EMJ_Mode.live_broadcast then return self.record_show_tingpai end
    if self.mode == EMJ_Mode.paipu then return self.record_show_tingpai end
end

function DesktopMgr:_record_follow_dealer()
    if self:IsSimulationOb() then
        return false
    end
    if self.mode == EMJ_Mode.play then return false end
    if self.mode == EMJ_Mode.live_broadcast then return self.live_follow_dealer end
    if self.mode == EMJ_Mode.paipu then return false end
end

--血战/川麻
function DesktopMgr:is_xuezhandaodi_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        (self.game_config.mode.detail_rule.xuezhandaodi == 1 or self.game_config.mode.detail_rule.chuanma == 1 or self.game_config.mode.detail_rule.wanxiangxiuluo_mode == 1)
end

function DesktopMgr:IsXiuLuoMode()
    return self.game_config and self.game_config.mode and self.game_config.mode.detail_rule and self.game_config.mode.detail_rule.xuezhandaodi == 1
end

function DesktopMgr:IsChiYuMode()
    return self.game_config and self.game_config.mode and self.game_config.mode.detail_rule and self.game_config.mode.detail_rule.chuanma == 1
end

function DesktopMgr:is_jiuchao_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.jiuchao_mode == 1
end

function DesktopMgr:is_chuanma_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.chuanma == 1
end

function DesktopMgr:is_huansanzhang_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        (self.game_config.mode.detail_rule.huansanzhang == 1 or self.game_config.mode.detail_rule.wanxiangxiuluo_mode == 1)
end

function DesktopMgr:is_reveal_discard_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.reveal_discard == 1
end

function DesktopMgr:is_field_spell_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.field_spell_mode and
        self.game_config.mode.detail_rule.field_spell_mode ~= 0
end

function DesktopMgr:is_zhanxing_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.zhanxing and
        self.game_config.mode.detail_rule.zhanxing ~= 0
end

function DesktopMgr:is_field_spell_extra_dora()

    if not self:is_field_spell_mode() then
        return false
    end
    return UI_FieldSpell.Inst:IsExtraDora()
end

function DesktopMgr:is_tianming_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.tianming_mode and
        self.game_config.mode.detail_rule.tianming_mode == 1
end

function DesktopMgr:is_yongchang_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.yongchang_mode and
        self.game_config.mode.detail_rule.yongchang_mode == 1
end

function DesktopMgr:is_hunzhiyiji_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.hunzhiyiji_mode and
        self.game_config.mode.detail_rule.hunzhiyiji_mode == 1
end

function DesktopMgr:is_wanxiangxiuluo_mode()
    -- 万象牌修罗模式 wanxiangxiuluo == 1 
    -- 换三张时，百搭的牌不可选
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.wanxiangxiuluo_mode and
        self.game_config.mode.detail_rule.wanxiangxiuluo_mode == 1
end

function DesktopMgr:is_muyu_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.muyu_mode and
        self.game_config.mode.detail_rule.muyu_mode == 1
end

function DesktopMgr:is_beishui_mode()
    return self.game_config and
        self.game_config.mode and
        self.game_config.mode.detail_rule and
        self.game_config.mode.detail_rule.beishuizhizhan_mode and
        self.game_config.mode.detail_rule.beishuizhizhan_mode == 1
end

---@param mode EMJGameRule
function DesktopMgr:IsTargetSpecialMode(mode)
    if self.game_config and self.game_config.mode and self.game_config.mode.detail_rule and self.game_config.mode.detail_rule.amusement_switches then
        return Tools.IsTargetSpecialMode(mode, self.game_config.mode)
    end
    return false
end

--revealed:bool
function DesktopMgr:is_pai_revealing(revealed, seat)
    if not revealed then return false end
    if self.mode == EMJ_Mode.play then return DesktopMgr.Inst.seat ~= seat end
    if self.mode == EMJ_Mode.live_broadcast then return DesktopMgr.Inst.seat ~= seat and not self:_record_show_hand() end
    if self.mode == EMJ_Mode.paipu then return DesktopMgr.Inst.seat ~= seat and not self:_record_show_hand() end
end

function DesktopMgr:is_playing_effect()
    -- return self.playing_hule_effect or self.playing_yiman_effect
    return self.playing_yiman_effect
end

---@return GameUtility.ENameFilterServiceType
function DesktopMgr:get_name_filter_service_type()
    --友人房和友人昵称默认隐藏
    --匹配和大会室跟随设置
    local config = DesktopMgr.Inst.game_config
    if config and config.category == 1 then
        if self.mode == EMJ_Mode.paipu then
            return GameUtility.ENameFilterServiceType.REPLAY
        else
            return GameUtility.ENameFilterServiceType.FRIEND
        end
    elseif config and config.category == 2 then
        if self.mode == EMJ_Mode.play then
            return GameUtility.ENameFilterServiceType.MATCH
        elseif self.mode == EMJ_Mode.paipu then
            return GameUtility.ENameFilterServiceType.REPLAY
        elseif self.mode == EMJ_Mode.live_broadcast then
            return GameUtility.ENameFilterServiceType.OBSERVE
        end
    elseif config and config.category == 4 then
        --大会室
        return GameUtility.ENameFilterServiceType.MATCH_LOBBY
    end
    return GameUtility.ENameFilterServiceType.MATCH
end

function DesktopMgr:GetGuideTransByType(act_type)
    local camera = self.transform:Find('camera'):GetComponent(typeof(UnityEngine.Camera))
    if act_type == 3 then
        local obj = self.desktop:Find('other_guide/pos_3')
        return camera:WorldToScreenPoint(obj.transform.position)
    elseif act_type == 4 then
        local obj = self.desktop:Find('other_guide/pos_4')
        return camera:WorldToScreenPoint(obj.transform.position)
    elseif act_type == 5 then
        local obj = self.desktop:Find('other_guide/pos_5')
        return camera:WorldToScreenPoint(obj.transform.position)
    end
    return nil
end

-- 再来一局接口
function DesktopMgr:AnotherGame()
    -- 数据不对或非匹配则无视
    if not self.game_config or self.game_config.category ~= 2 or not self.game_config:HasField('meta') then
        return
    end

    GameMgr.Inst:SendGameStatusLog('start_another_game', {})
    self:ClearOperationShow()
    self.game_end_result = nil
    self.level_change_info = nil
    self.reward_info = nil
    self.activity_reward = nil
    self.badge_info = nil
    UIMgr.Inst:ShowUI(UI_PiPeiYuYue_MJ.className, nil, self.game_config.meta.mode_id)
end

-- 进入牌谱接口
function DesktopMgr:CheckPaipu()
    if UIMgr.Inst:IsUIActive(UI_PiPeiYuYue.className) then
        UIMgr.Inst:ShowUI(UI_PopOut_Small.className, nil,
            { showType = UI_PopOut_Small.EShowType.TextWithButton, desc = Tools.StrOfLocalization(204) })
        return
    end
    self:ClearOperationShow()
    self.game_end_result = nil
    self.level_change_info = nil
    self.reward_info = nil
    self.activity_reward = nil
    self.badge_info = nil
    if (self.partyRoot) then
        UnityEngine.GameObject.Destroy(self.partyRoot.gameObject)
    end
    GameMgr.Inst:CheckPaiPu(GameMgr.Inst.mj_game_uuid, GameMgr.Inst.account_id, 0)
end

-- 牌河超过4行是否另外起一行
function DesktopMgr:NeedChangeLine()
    return self:is_xuezhandaodi_mode() or self:is_hunzhiyiji_mode() or
        self:is_wanxiangxiuluo_mode()
end

--- 高光时刻徽章进度更新
function DesktopMgr:UpdateBadgeInfo(msg)
    if msg.update.badge and msg.update.badge.progresses then
        self.badge_info = {}
        if #msg.update.badge.progresses > 0 then
            for _, new_badge_info in pairs(msg.update.badge.progresses) do
                local found = false
                for _, badge in pairs(GameMgr.Inst.account_data.badges) do
                    if badge.id and new_badge_info.id and badge.id == new_badge_info.id then
                        local count_plus = new_badge_info.achieved_counter - badge.achieved_counter
                        if count_plus > 0 then
                            local badge_update = {}
                            badge_update.id = new_badge_info.id
                            badge_update.achieved_counter = count_plus
                            table.insert(self.badge_info, badge_update)
                        end

                        badge.achieved_counter = new_badge_info.achieved_counter
                        found = true
                        break
                    end
                end

                if not found then
                    table.insert(GameMgr.Inst.account_data.badges, new_badge_info)
                end
            end
        end
    end
end

-------------2025.5.9 由于UI_ScoreChange_Xuezhan改为异步显示，从UI_ScoreChange_Xuezhan拆出该功能，用于判断一些对局action操作
function DesktopMgr:XueZhanCheckScore(data, title, line, play_short_anim)
    local line_data
    if title == 'fangang' then
        line_data = nil
    else
        line_data = line
    end
    local delta_scores = data.delta_scores
    local line_cache_seat = {}
    if DesktopMgr.Inst:is_chuanma_mode() and line_data then
        local line_temp = {}
        for i = 1, #line_data do
            local line = {}
            local str = line_data[i]
            line.b = tonumber(string.sub(str, 1, 1))
            line.a = tonumber(string.sub(str, 2, 2))
            table.insert(line_temp, line)
        end
        for i = 1, #line_temp do
            local b = DesktopMgr.Inst:seat2LocalPosition(line_temp[i].b + 1)
            local a = DesktopMgr.Inst:seat2LocalPosition(line_temp[i].a + 1)
            if not line_cache_seat[b] then
                line_cache_seat[b] = 1
            end
            if not line_cache_seat[a] then
                line_cache_seat[a] = 1
            end
        end
    end
    for i = 1, #delta_scores do
        local localPos = DesktopMgr.Inst:seat2LocalPosition(i)
        --如果存在流局满贯，那么必须显示分数变动，即使为0
        local is_liujumanguan = false
        if data.liujumanguan_infos then
            for j = 1, #data.liujumanguan_infos do
                if data.liujumanguan_infos[j].seat + 1 == i then
                    is_liujumanguan = true
                end
            end
        end
        local is_chuanmaline = false
        if line_cache_seat[localPos] then
            is_chuanmaline = true
        end
        if delta_scores[i] ~= 0 or is_liujumanguan or is_chuanmaline then
            return true
        end
    end
    return false
end

function DesktopMgr:ResetSpecialModes()
    self.tributeState = 0
end

function DesktopMgr:InitSpecialMode(config, complete, progress)
    self.game_config = config
    ---这是强夺之战
    if self:IsTargetSpecialMode(GameUtility.EMJGameRule.QiangDuoZhiZhan) then
        self.tributeMove = LuaTools.LoadPrefab('scenes/mj/game_mode/qiangduozhizhan/prefab/tribute')
        self.tributePool = {}
    end
    -- todo 初始化特殊模式的3D特效；例如背水之站牌桌中间的东南西北发光特效
    local totalCount = #self.players
    local loadCount = 0
    for i = 1, #self.players do
        self.players[i]:InitSpecialMode(function()
            loadCount = loadCount + 1
            progress(loadCount / totalCount)
            if loadCount == totalCount then
                complete()
            end
        end)
    end
end

function DesktopMgr:ClearSpecialMode()
    -- todo 销毁特殊模式的3D特效；例如背水之站牌桌中间的东南西北发光特效
    for i = 1, #self.players do
        self.players[i]:ClearSpecialMode()
    end
    self.sharedMaterial_jiuchao = nil
    self.sharedMaterial_anpai = nil

    -- 清除团队赛队伍名对 RT 的引用
    for _, item in ipairs(self.partyNameItemList) do
        item.cam.targetTexture = nil
    end
    for _, mesh in ipairs(self.partyNameMeshList) do
        mesh.material.mainTexture = nil
    end
    -- 释放所有 RT
    for _, rt in ipairs(self.partyNameRTList) do
        rt:Release()
        ---这是强夺之战
        if self.tributeMove then
            UnityEngine.GameObject.Destroy(self.tributeMove.gameObject)
            self.tributeMove = nil
        end
        if self.tributePool and #self.tributePool > 0 then
            for i = 1, #self.tributePool do
                UnityEngine.GameObject.Destroy(self.tributePool[i].gameObject)
            end
            self.tributePool = {}
        end
    end
    -- 清除和牌记录
    self.bestHuDataMap = {}
end

-- 2025 角色新增语音
function DesktopMgr:IsBegin()
    return self.index_chang == 1 and self.index_ju == 1 and self.index_ben == 0
end

function DesktopMgr:PlayGameVoice(seat, audioType)
    if self.extraGameSoundPlay > 0 then
        return
    end
    if audioType == GameUtility.ECharVoiceType.ingame_start then
        if self.isPlayedPrepareAudio then -- 开始音效播放过就不播了
            return
        end
        self.isPlayedPrepareAudio = true
    end

    local soundInfo = AudioMgr.PlayCharacterSpecialSound(
        self.player_datas[seat].character,
        audioType,
        function()
            self.extraGameSoundPlay = -1
        end)
    if soundInfo then
        self.extraGameSoundPlay = 1
    end
end

function DesktopMgr:ResetGameVoice()
    if self.extraGameSoundPlay > 0 then
        AudioMgr.StopSpecialVoice()
    end
    self.extraGameSoundPlay = -1
end

function DesktopMgr:IsPlayingGameVoice()
    return self.extraGameSoundPlay > 0
end

---@param hules IHuleInfo[]|IHuInfoXueZhanMid[]
function DesktopMgr:UpdateLastRoundRecord(hules)
    local huleData = hules or {}
    if huleData then
        for _, hule in ipairs(huleData) do
            if hule and hule.seat ~= nil then
                self.lastRoundRecord[hule.seat + 1] = {
                    hule = true,
                    zimo = hule and hule.zimo or false
                }
            end
        end
    end
end

function DesktopMgr:RefreshSeatOnNewRound()
    if self:_record_follow_dealer() then
        if DesktopMgr.Inst.mode == EMJ_Mode.live_broadcast and not UI_LiveBroadcast_New.Inst.in_record and self.seat ~= self.index_ju then
            DesktopMgr.Inst.seat = DesktopMgr.Inst.index_ju
            if (self.matchInfo and self.matchInfo.isPartyMatch) then
                self:RefreshPartyShow()
            end
            UI_DesktopInfo.Inst:RefreshSeat(true)
            for i = 1, 4 do
                local seat = self:localPosition2Seat(i)
                if seat == 0 then
                    self.players[i]:_Reset()
                end
                self.players[i]:OnInitRoom(seat)
            end
        end
    end
end
function DesktopMgr:UpdateXiaKeShangInfo(data)
    if self:IsTargetSpecialMode(GameUtility.EMJGameRule.XiaKeShang) then
        DesktopMgr.Inst.xiakeshangInfo = data
    end
end

---@param isSubmit boolean true代表在上交牌，false代表在拿牌
function DesktopMgr:UpdateRetributeState(isSubmit)
    if isSubmit then
        self.tributeState = self.tributeState + 1
        if self.tributeState == 1 then
            self.mainrole:EnterReTributeState()
        end
        if UI_ChangeTile and UI_ChangeTile.Inst and UI_ChangeTile.Inst.transform.gameObject.activeSelf then
            UIMgr.Inst:CloseUIByClassName(UI_ChangeTile.className)
        end
    elseif self.tributeState == 2 then
        self.tributeState = 0
        self.mainrole:QuitReTributeState()
    end
end

--- 获取当前局内所有人的角色 ID 列表（不去重）
--- @return number[]
function DesktopMgr:GetDeskCharIds()
    local res = {}
    for _, player in ipairs(self.player_datas) do
        table.insert(res, player.character.charid)
    end
    return res
end

-- DesktopMgr当前是否激活的通用接口
function DesktopMgr.IsActive()
    return DesktopMgr.Inst and DesktopMgr.Inst.transform and DesktopMgr.Inst.transform.gameObject.activeSelf
end

function DesktopMgr.OnResetGame()
    if (DesktopMgr.Inst and DesktopMgr.Inst.effectRoot) then
        -- 直接销毁特效根节点，避免重启后遗留特效 GameObject 导致粉图
        UnityEngine.GameObject.Destroy(DesktopMgr.Inst.effectRoot.gameObject)
    end
end

---创建可移动的强夺子模块
---@param pais MJPai[]
---@param states number[]
---@return {tribute:UnityEngine.GameObject, maques:UnityEngine.GameObject[]}|nil
function DesktopMgr:CreateTribute3D(pais, states, parent)
    if not pais or #pais == 0 then return nil end
    ---@type UnityEngine.GameObject
    local tribute
    if self.tributePool and #self.tributePool > 0 then
        tribute = self.tributePool[#self.tributePool]
        table.remove(self.tributePool, #self.tributePool)
    else
        if not self.tributeMove then return nil end
        tribute = UnityEngine.GameObject.Instantiate(self.tributeMove.gameObject, parent)
    end
    tribute.transform:SetParent(parent)
    local maques = {}
    for i = 1, #pais do
        local maque = self:CreatePai3D(pais[i])
        local p = ViewPai:Init(pais[i], maque)
        if DesktopMgr.Inst:get_show_paopai() then
            p.ispaopai = DesktopMgr.Inst:IsPaoPai(p.pai)
        end
        p:OnChoosed()
        maque.transform.name = 'maque'
        if #pais == 1 then
            maque.transform:SetParent(tribute.transform:Find('anim'):Find(2))
        else
            maque.transform:SetParent(tribute.transform:Find('anim'):Find(i .. ''))
        end
        maque.transform.localPosition = Vector3.zero
        maque.transform.localRotation = Tools.Ternary(states[i] == 1, Quaternion.Euler(Vector3.zero), Quaternion.Euler(Vector3.New(0, 180, 0)))
        maque.transform.localScale = Vector3.one
        table.insert(maques, p)
    end
    tribute:SetActive(true)
    return { tribute = tribute, maques = maques }
end

function DesktopMgr:RecycleTribute3D(tribute)
    if not tribute then return end
    tribute:SetActive(false)
    tribute.transform:SetParent(nil)
    local maqueRoot = tribute.transform:Find('anim')
    for i = 1, maqueRoot.childCount do
        local maque = tribute.transform:Find('anim'):Find(i .. ''):Find('maque')
        if maque then
            self:ResetMaque(maque.transform)
        end
    end
    table.insert(self.tributePool, tribute)
end

--- @param infos IHuleInfo[]
function DesktopMgr:UpdateBestHuInfo(infos)
    if (self.mode ~= EMJ_Mode.play or self:is_wanxiangxiuluo_mode()) then
        return
    end
    for _, info in ipairs(infos) do
        local realSeat = info.seat + 1
        if (not self.bestHuDataMap[realSeat]) then
            self.bestHuDataMap[realSeat] = {}
        end
        local data = self.bestHuDataMap[realSeat]
        if (not data.originData or data.originData.dadian <= info.dadian) then
            data.originData = info
            data.finalPaiList = {}
            if (info.hand) then
                for _, pai in ipairs(info.hand) do
                    table.insert(data.finalPaiList, pai)
                end
            end
            if (info.ming) then
                for _, mingStr in ipairs(info.ming) do
                    local strLength = Tools.GetStringLength(mingStr)
                    for i = 1, strLength do
                        if string.sub(mingStr, i, i) == '(' then
                            local shoutList = Tools.Split(string.sub(mingStr, i + 1, -2), ',')
                            for _, pai in ipairs(shoutList) do
                                table.insert(data.finalPaiList, pai)
                            end
                        end
                    end
                end
            end
            if (not string.IsNullOrEmpty(info.hu_tile)) then
                table.insert(data.finalPaiList, info.hu_tile)
            end
            data.score = info.dadian
        end
    end
end

function DesktopMgr.TryGetChampionBestHuInfo()
    if (DesktopMgr.Inst and DesktopMgr.Inst.game_end_result) then
        local playerData = DesktopMgr.Inst.game_end_result.players
        if (playerData and #playerData > 0) then
            return DesktopMgr.Inst.bestHuDataMap[playerData[1].seat]
        end
    end
    return nil
end

-- ==DevDebug Start==
function DesktopMgr.ChangeLiqiEffect(effectId)
    if (not DesktopMgr.Inst) then return end
    local viewConfig = ExcelMgr.GetData("item_definition", "view", effectId)
    if (not viewConfig or string.IsNullOrEmpty(viewConfig.res_name)) then
        LogTool.Error("Debug", "非法的立直特效 ID")
        return
    end

    --- @type IEffect_Liqi
    local effect = {}
    effect.path = "deco/effect_lizhi/" .. viewConfig.res_name .. '/3d/prefab/' .. viewConfig.res_name
    effect.type = viewConfig.sargs[1] or "shu"
    effect.seatRelated = viewConfig.seat_related and viewConfig.seat_related > 0
    effect.audio_id = viewConfig.audio_id
    effect.view = viewConfig
    DesktopMgr.Inst.player_effects[1].effect_liqi = effect
end
-- ==DevDebug End==

return DesktopMgr
