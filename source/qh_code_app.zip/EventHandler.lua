---@class EventHandler
EventHandler = {}

function EventHandler:New()
    local o = {}
    setmetatable(o, { __index = EventHandler })
    o:_Init()
    return o
end

function EventHandler:_Init()
    self.events = {} -- Map<string eventName, List<{function func, bool once}>>
end

function EventHandler:AddListener(eventName, func, once)
    once = once or false
    if not self.events[eventName] then
        self.events[eventName] = {}
    end
    table.insert(self.events[eventName], {func = func, once = once})
end

function EventHandler:RemoveListener(eventName, func)
    local eventList = self.events[eventName]
    if not eventList then
        return
    end
    for i = 1, #eventList do
        if eventList[i].func == func then
            table.remove(eventList, i)
            break
        end
    end
end

-- 清理某个时间的所有监听器
function EventHandler:RemoveListenerAll(eventName)
    self.events[eventName] = nil
end

-- 全部清理
function EventHandler:Clear()
    self.events = {}
end

function EventHandler:Fire(eventName, ...)
    local eventList = self.events[eventName]
    if not eventList then
        return
    end

    local i = 1
    while i <= #eventList do
        eventList[i].func(...)
        if eventList[i].once then
            table.remove(eventList, i)
            i = i - 1
        end
        i = i + 1
    end
end

function EventHandler:HasListener(eventName)
    return self.events[eventName] ~= nil and #self.events[eventName] > 0
end



return EventHandler