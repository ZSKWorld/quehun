require("ProtoMgr")
local pt = require("PrintTable")
local ExcelTable = require("ExcelTable")
local ExcelTool = require("ExcelTool")
ExcelMgr = { }
local USE_PROTO_DATA = CONST.USE_PROTO_DATA
local USE_PROTO_LANG = CONST.USE_PROTO_LANG
if USE_PROTO_DATA then
local dataAll = {}
local excel_config = {}
local excel_data = {}

local name_map = {}
local ExcelDataParsed = {}
-- 格式化名字为驼峰命名
local function FormatTableName(_name)
    if name_map[_name] then
        return name_map[_name]
    end
    local _ret = ''
    local needUp = true
    for i = 1, string.len(_name) do
        local c = string.sub(_name, i, i)
        if c == '_' then
            needUp = true
        else
            if needUp then
                _ret = _ret .. string.upper(c)
            else
                _ret = _ret .. c
            end
            needUp = false
        end
    end
    name_map[_name] = _ret
    return _ret
end

local function IsTableParsed(tableName, sheetName)
    for i = 1, #ExcelDataParsed do
        local flag = ExcelDataParsed[i]
        if flag[1] == tableName and flag[2] == sheetName then
            return true
        end
    end
    return false
end


local function CreateFrozenMsg(category, msg_name, _data, d, keyName, tableName, sheetName)
    
    local msg_table = ProtoMgr.CreateMsg(msg_name)
    msg_table:ParseFromString(d)
    msg_table = Tools.ProtoToTable(msg_table, false, 1)
    ExcelTable.Assemble(msg_table, tableName, sheetName);
    if category == 'nokey' then
        _data[#_data + 1] = msg_table
    elseif msg_table[keyName] then
        if category == 'unique' then
            _data[msg_table[keyName]] = msg_table
    elseif category == 'group' then
        if not _data[msg_table[keyName]] then _data[msg_table[keyName]] = {} end
            _data[msg_table[keyName]][#_data[msg_table[keyName]] + 1] = msg_table
        elseif category == 'kv' then
            _data[msg_table[keyName]] = msg_table
        end
    end
    return msg_table;
end

--留作备用的按需加载excel
local function TryParseTable(tableName, sheetName)
    
    if not IsTableParsed(tableName, sheetName) then
        LogTool.Info('Excel', 'Try Parse Table tableName: ' .. tableName .. 'sheetName: ' .. sheetName)
        -- 填写表内容
        local dataLst = dataAll.datas
        if dataLst then
            for i = 1, #dataLst do 
                local d = dataLst[i]
                local tableName = d.table
                if d.table == tableName and d.sheet == sheetName then
                    if not excel_data[tableName] then
                        excel_data[tableName] = {}
                    end
                    local _data = {}
                    local sheetName = d.sheet
                    local category = excel_config[tableName][sheetName].category
                    local keyName = excel_config[tableName][sheetName].key
                    local msg_name = 'Sheet_' .. FormatTableName(tableName) .. '_' .. FormatTableName(sheetName)
                    if d.data then
                        for j = 1, #d.data do
                            local msg_table = CreateFrozenMsg(category, msg_name, _data, d.data[j], keyName, tableName, sheetName);
                        end
                    end
                    -- 1003ms
                    -- excel_data[tableName][sheetName] = _data
                    -- 2012ms
                    -- 在12700F上的测试结果
                    --excel_data[tableName][sheetName] = Tools.ProtoToTable(_data, true)
                    excel_data[tableName][sheetName] = _data
                    if tableName == 'item_definition' and sheetName == 'item' then
                        ExcelMgr.Localize()
                    end
                end
            end
        end
        table.insert(ExcelDataParsed, {tableName, sheetName})
    end
    
end

-- 游戏开始时候读取数据
function ExcelMgr.Build()
    
    local startTime = Tools.GetMilliseconds()
    LogTool.Info('Excel', '开始解析表数据')
    collectgarbage("collect")
    local pre = collectgarbage("count")
    LogTool.Info('Excel', 'ExcelMgr解析前内存占用：' .. pre)
    local text = LuaTools.LoadBytes('docs/excel/excel_data.bytes')
    dataAll = ProtoMgr.CreateMsg('ConfigTables')
    dataAll:ParseFromString(text)
    LogTool.Info('Excel', '解析表数据完成二进制解析，用时: ' .. ((Tools.GetMilliseconds() - startTime) / 1000.0) .. 's')
    -- 获取表结构，unique、group和key等
    local schemas = dataAll.schemas
    if schemas then
        for i = 1, #schemas do
            local _schema = schemas[i]
            local tableName = _schema.name
            local sheets = _schema.sheets
            excel_config[tableName] = { }
            for j = 1, #sheets do
                local _sheet = sheets[j]
                local sheetName = _sheet.name
                local config = { }
                local meta = _sheet.meta
                if meta.category then
                    config.category = meta.category
                end
                if meta.key then
                    config.key = meta.key
                end
                excel_config[tableName][sheetName] = Tools.ProtoToTable(config, true)
            end
        end
    end
    LogTool.Info('Excel', '解析表数据完成获取表结构，用时: ' .. ((Tools.GetMilliseconds() - startTime) / 1000.0) .. 's')
    if PhoneUtility.MemSize >= 2048 then
        -- 填写表内容
        local dataLst = dataAll.datas
        if dataLst then
            for i = 1, #dataLst do 
                local d = dataLst[i]
                local tableName = d.table
                if not excel_data[tableName] then
                    excel_data[tableName] = {}
                end
                local _data = {}
                local sheetName = d.sheet
                local category = excel_config[tableName][sheetName].category
                local keyName = excel_config[tableName][sheetName].key
                local msg_name = 'Sheet_' .. FormatTableName(tableName) .. '_' .. FormatTableName(sheetName)
                if d.data then
                    for j = 1, #d.data do
                        local msg_table = CreateFrozenMsg(category, msg_name,_data, d.data[j], keyName, tableName, sheetName);
                    end
                end
                -- 1003ms
                -- excel_data[tableName][sheetName] = _data
                -- 2012ms
                -- 在12700F上的测试结果
                --excel_data[tableName][sheetName] = Tools.ProtoToTable(_data, true)
                excel_data[tableName][sheetName] = _data
                table.insert(ExcelDataParsed, {tableName, sheetName})
            end
        end
        ExcelMgr.Localize()
    end
    LogTool.Info('Excel', '解析表数据完成，用时: ' .. ((Tools.GetMilliseconds() - startTime) / 1000.0) .. 's')
    local c2 = collectgarbage("count")
    LogTool.Info('Excel', 'ExcelMgr解析后增加内存占用：' .. ((c2-pre)/1024))
    collectgarbage("collect")
    local c3 = collectgarbage("count")
    LogTool.Info('Excel', 'ExcelMgr解析+gc后内存增加占用：' .. ((c3-pre)/1024))
    
end

function ExcelMgr.ParseTableAsync(tableName, sheetName, cb)
    
    local dataLst = dataAll.datas
    if not IsTableParsed(tableName, sheetName) then
        local dataLst = dataAll.datas
        if dataLst then
            for i = 1, #dataLst do 
                local d = dataLst[i]
                local tableName = d.table
                if d.table == tableName and d.sheet == sheetName then
                    if not excel_data[tableName] then
                        excel_data[tableName] = {}
                    end
                    local _data = {}
                    local sheetName = d.sheet
                    local category = excel_config[tableName][sheetName].category
                    local keyName = excel_config[tableName][sheetName].key
                    local msg_name = 'Sheet_' .. FormatTableName(tableName) .. '_' .. FormatTableName(sheetName)
                    if d.data then
                        local data_length = #d.data
                        local max_frame_index = Mathf.Ceil(data_length / 1000)
                        for j = 1, max_frame_index do
                            TimeMgr.DelayFrame(j, function ()
                                local start_index = (j - 1) * 1000 + 1
                                local end_index = j * 1000
                                for k = start_index, end_index do
                                    if k <= data_length then
                                        local msg_table = CreateFrozenMsg(category, msg_name,_data, d.data[k], keyName, tableName, sheetName);
                                    end
                                end
                                if j == max_frame_index then
                                    if cb then cb() end
                                    table.insert(ExcelDataParsed, {tableName, sheetName})
                                end
                            end)
                        end
                    end
                    --excel_data[tableName][sheetName] = Tools.ProtoToTable(_data, true)
                    excel_data[tableName][sheetName] = _data
                    collectgarbage('collect')
                end
            end
        end
    end
end

-- 根据id读取表中某一行
function ExcelMgr.GetData(tableName, sheetName, id)
    TryParseTable(tableName, sheetName)
    local d = excel_data[tableName]
    if not d then
        LogTool.Error('Excel', 'not find table tablename:' .. tableName)
        return nil
    end
    d = d[sheetName]
    if not d then
        LogTool.Error('Excel', 'not find sheet tablename:' .. tableName .. ' sheetname:' .. sheetName)
        return nil
    end
    d = d[id]
    if not d then
        return nil
    end
    return ExcelTable.Freeze(d, tableName, sheetName);
    --return Tools.DeepCopy(d)
end

-- 获取整个表，用来遍历
function ExcelMgr.GetTable(tableName, sheetName, notfreeze)
    TryParseTable(tableName, sheetName)
    local d = excel_data[tableName]
    if not d then
        LogTool.Error('Excel', 'not find table tablename:' .. tableName)
        return nil
    end
    d = d[sheetName];

    if notfreeze == true or not USE_PROTO_LANG then
        return d;
    else
        local tb = {};
        for k, v in pairs(d) do
            tb[k] = ExcelTable.Freeze(v, tableName, sheetName);
        end
        return tb
    end
end
    
function ExcelMgr.DelTable(tableName, sheetName)
    local d = excel_data[tableName]
    if not d then
        LogTool.Error('Excel', 'not find table tablename:' .. tableName)
        return nil
    end
    excel_data[tableName][sheetName] = nil
end

--日美服特殊道具数据本地化
function ExcelMgr.Localize()
    if GameMgr.Inst.client_language == 'en' then
        local item_ids = {303041, 303042, 303043, 303142, 303143}
        for i = 1, #item_ids do
            local item = excel_data['item_definition']['item'][item_ids[i]]
            item.name_chs_t = item.name_chs_t2
            item.desc_chs_t = item.desc_chs_t2
            -- item.desc_func_chs_t = item.desc_func_chs_t2
        end
    end
end

else
    
-- 游戏开始时候读取数据
function ExcelMgr.Build()
    
    if CONST.USE_EXCEL_TEST == 1 or UnityEngine.Application.isEditor and CONST.USE_EXCEL_TEST == 2 then
        collectgarbage("collect")
        local pre = collectgarbage("count")
        LogTool.Info('Excel', 'ExcelMgr加载表格前lua内存：' .. pre/1024 .. "M")
        local all = require("Excels.All");
        local startTime = Tools.GetMilliseconds()
        for i, v in ipairs(all) do
            local excel = require(string.format("Excels.Data.%s.%s", v.TableName, v.SheetName));
            if excel.b2i then
                ExcelTool.TryLoadBlock(excel, v.TableName, v.SheetName);
            end
            if v[GameMgr.Inst.prefer_language] then
                local langs = v[GameMgr.Inst.prefer_language];
                for i, v1 in ipairs(langs) do
                    require(v1);
                end
            end
        end
        LogTool.Info('Excel', '加载表数据，用时: ' .. ((Tools.GetMilliseconds() - startTime) / 1000.0) .. 's')
        collectgarbage("collect")
        local c1 = collectgarbage("count")
        LogTool.Info('Excel', '加载后表格内存占用：' .. ((c1-pre)/1024) .. "M      lua内存:" .. c1 / 1024 .. "M")
    end
end

function ExcelMgr.ParseTableAsync(tableName, sheetName, cb)
end

-- 根据id读取表中某一行
function ExcelMgr.GetData(tableName, sheetName, id)
    local excel = require(string.format("Excels.Data.%s.%s", tableName, sheetName));
    d = excel.tb[id];
    if not d then
        ExcelTool.TryLoadBlock(excel, tableName, sheetName, id);
        d = excel.tb[id];
        return d;
    end
    if excel.b2i and d.__load then
        d:__load();
    end
    return Tools.DeepCopy(d);
    --return ExcelTable.Freeze(d, tableName, sheetName);
end

local _gettable_waringing_ = nil
if UnityEngine.Application.isEditor then
    -- 编辑器模式：记录错误日志
    _gettable_waringing_ = function(excel, tableName, sheetName)
        if not excel.b2i then return; end
        LogTool.Warning("ExcelMgr", string.format(
            "<color=red>强烈建议不要用这种方式获取表格数据: tableName=%s sheetName=%s</color>", 
            tableName, sheetName))
    end
end

-- 获取整个表，用来遍历
function ExcelMgr.GetTable(tableName, sheetName, notfreeze)
    local excel = require(string.format("Excels.Data.%s.%s", tableName, sheetName));
    if _gettable_waringing_ then _gettable_waringing_(excel, tableName, sheetName); end
    ExcelTool.TryLoadBlock(excel, tableName, sheetName);
    if notfreeze == true or true then
        return excel.tb;
    else
        local tb = {};
        for k, v in pairs(d) do
            if v.__load then
                v:__load();
            end
            tb[k] = ExcelTable.Freeze(v, tableName, sheetName);
        end
        return tb
    end
end

function ExcelMgr.DelTable(tableName, sheetName)
    local module = string.format("Excels.Data.%s.%s", tableName, sheetName);
    package.loaded[module] = nil   -- 清除模块缓存
    _G[module] = nil               -- 清除全局变量（如果存在）
end

--日美服特殊道具数据本地化
function ExcelMgr.Localize()
    if GameMgr.Inst.client_language == 'en' then
        local item_ids = {303041, 303042, 303043, 303142, 303143}
        local items = require("Excels.item_definition.item");
        for i = 1, #item_ids do
            local item = items[item_ids[i]]
            item.name_chs_t = item.name_chs_t2
            item.desc_chs_t = item.desc_chs_t2
            -- item.desc_func_chs_t = item.desc_func_chs_t2
        end
    end
end
end
--- 获取表内满足指定过滤方法的数据列表
--- @param tableName string 表名
--- @param sheetName string sheet 页名
--- @param filterFunc function 过滤方法 function(element) 返回一个布尔值, 为 true 的元素加入结果列表
--- @return table 满足过滤条件的结果
function ExcelMgr.GetTableByFilter(tableName, sheetName, filterFunc)
    local d = ExcelMgr.GetTable(tableName, sheetName)
    local res = {}
    if (not d) then return {} end
    for _, v in pairs(d) do
        if (filterFunc(v)) then
            table.insert(res, v)
        end
    end
    return res
end

function ExcelMgr.GetTableSortBy(tableName, sheetName,func)
    local d = ExcelMgr.GetTable(tableName, sheetName, true)
    local sort_d = {}
    local sorted_d = {}
    for _, v in pairs(d) do
        if v and v.sort then
            table.insert(sort_d,{id = v.id,sort = v.sort})
        end
    end
    table.sort(sort_d,func)

    for _, v in ipairs(sort_d) do
         local data = ExcelMgr.GetData(tableName, sheetName, v.id)
         table.insert(sorted_d,data)
    end

    return sorted_d
end

function ExcelMgr.GetTableSortById(tableName, sheetName, key)

    if (not key) then
        key = 'id'    end
    local d = ExcelMgr.GetTable(tableName, sheetName, true)
    local sort_d = {}
    local sorted_d = {}
    for _, v in pairs(d) do
        if v then
            table.insert(sort_d, v[key])
        end
    end
    table.sort(sort_d, function(a, b)
        return a < b
    end)

    for _, v in ipairs(sort_d) do
        local data = ExcelMgr.GetData(tableName, sheetName, v)
        table.insert(sorted_d,data)
    end

    return sorted_d
end

return ExcelMgr
