-- 由 Excel 自动生成的 Lua 表
-- 文件:   [ab_match][consume_seq]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["match_count"] = 2; ["item_id"] = 3; ["item_count"] = 4;};

local df = {  9001, 1, 100002, 20000,};

local get = function(item, k) return G(item, k, n2i, df); end;


local consume_seq = { }
consume_seq[9001] = {
	P({D[1002], 0,0}, get),
	P({false,2}, get),
	P({false,3}, get),
};
consume_seq[9002] = {
	P({9002,false,0,0}, get),
	P({9002,2}, get),
};
consume_seq[9003] = {
	P({9003,false,0,0}, get),
};
return { tb = consume_seq };