-- 由 Excel 自动生成的 Lua 表
-- 文件:   [ab_match][match_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["ab_match_activity_id"] = 2; ["match_activity_id"] = 3; ["desktop_id_list"] = 1004; ["consume_id"] = 5; ["buy_in_condition"] = 1006; ["mail_template_id"] = 7; ["max_match_count"] = 8; ["reward_id"] = 9; ["point_id"] = 10; ["match_level"] = 11; ["priority"] = 12;};

local df = {  nil, 1120, 1118, "5,6,8,9,11,12,15,16,19,20,21,22,23,24,25,26", 9002, nil, 106, 4, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local match_info = { }
match_info[1001] = P({D[7008], 1001,false,1117,false,9001,"",5001,4001,0,1}, get);
match_info[1002] = P({D[2005], 1002,"1001-20",false,false,5002,4002,100,5}, get);
match_info[1003] = P({D[2005], 1003,"1001-50",false,false,5003,4003,200,10}, get);
match_info[1004] = P({D[7008], 1004,false,1119,false,9003,"1002-40,1003-40",5004,4004,300,15}, get);
match_info[1005] = P({D[7008], 1005,false,1119,false,9003,"1003-60",5005,4005,400,20}, get);
return { tb = match_info };