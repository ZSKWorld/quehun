-- 由 Excel 自动生成的 Lua 表
-- 文件:   [ab_match][point]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["rank"] = 2; ["desktop_id_list"] = 1003; ["point"] = 4;};

local df = {  4001, 1, "5,6,8,9,11,12,15,16", 20,};

local get = function(item, k) return G(item, k, n2i, df); end;


local point = { }
point[4001] = {
	P({}, get),
	P({false,2,false,15}, get),
	P({false,3,false,10}, get),
	P({false,4,false,5}, get),
	P({D[1002], "19,20,21,22,23,24,25,26"}, get),
	P({false,2,"19,20,21,22,23,24,25,26",12}, get),
	P({false,3,"19,20,21,22,23,24,25,26",5}, get),
};
point[4002] = {
	P({4002}, get),
	P({4002,2,false,15}, get),
	P({4002,3,false,10}, get),
	P({4002,4,false,5}, get),
	P({4002,false,"19,20,21,22,23,24,25,26"}, get),
	P({4002,2,"19,20,21,22,23,24,25,26",12}, get),
	P({4002,3,"19,20,21,22,23,24,25,26",5}, get),
};
point[4003] = {
	P({4003}, get),
	P({4003,2,false,15}, get),
	P({4003,3,false,10}, get),
	P({4003,4,false,5}, get),
	P({4003,false,"19,20,21,22,23,24,25,26"}, get),
	P({4003,2,"19,20,21,22,23,24,25,26",12}, get),
	P({4003,3,"19,20,21,22,23,24,25,26",5}, get),
};
point[4004] = {
	P({4004}, get),
	P({4004,2,false,15}, get),
	P({4004,3,false,10}, get),
	P({4004,4,false,5}, get),
	P({4004,false,"19,20,21,22,23,24,25,26"}, get),
	P({4004,2,"19,20,21,22,23,24,25,26",12}, get),
	P({4004,3,"19,20,21,22,23,24,25,26",5}, get),
};
point[4005] = {
	P({4005}, get),
	P({4005,2,false,15}, get),
	P({4005,3,false,10}, get),
	P({4005,4,false,5}, get),
	P({4005,false,"19,20,21,22,23,24,25,26"}, get),
	P({4005,2,"19,20,21,22,23,24,25,26",12}, get),
	P({4005,3,"19,20,21,22,23,24,25,26",5}, get),
};
return { tb = point };