-- 由 Excel 自动生成的 Lua 表
-- 文件:   [achievement][achievement]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["desc_chs"] = -3; ["desc_chs_t"] = -3; ["desc_jp"] = -3; ["desc_en"] = -3; ["desc_kr"] = -3; ["rare"] = 4; ["locked"] = 5; ["group_id"] = 6; ["sort"] = 7; ["segment_id"] = 8; ["base_task"] = 9; ["reward"] = 1010; ["hidden"] = 11; ["deprecated"] = 12;};

local df = {  nil,  nil,  nil, 1, nil, 10, 1, nil, 90501, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "achievement_achievement"); end;

local b2i = {100097,100185,100281,100392,800024,900001,}

local achievement = { }
return { tb = achievement, get = get, b2i = b2i };