-- 由 Excel 自动生成的 Lua 表
-- 文件:   [achievement][achievement_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["img"] = 1003; ["reward"] = 1004; ["percentage"] = 5; ["deprecated"] = 6; ["sort"] = 7;};

local df = {  nil,  nil, "senluowanxiang.png", "600032-1", 1, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "achievement_achievement_group"); end;


local achievement_group = { }
achievement_group[1] = P({D[5006], 1,1,"chengzhangzhilv.png","600031-1",1}, get);
achievement_group[2] = P({D[4005], 2,2,"lianshengzhidao.png",1,999}, get);
achievement_group[3] = P({D[5006], 3,3,"xingluoyunbu.png","600033-1",3}, get);
achievement_group[4] = P({D[5006], 4,4,"tianxuanzhizheng.png","600034-1",4}, get);
achievement_group[5] = P({D[5006], 5,5,"qianchuibailian.png","600035-1",5}, get);
achievement_group[6] = P({D[5006], 6,6,"paizhuojianwen.png","600036-1",6}, get);
achievement_group[7] = P({D[5006], 7,7,"lianghaoshimin.png","600037-1",7}, get);
achievement_group[8] = P({D[5006], 8,8,"shenshefangke.png","600038-1",8}, get);
achievement_group[9] = P({9,9,false,"600039-1",0,false,11}, get);
achievement_group[10] = P({10,10,"qiankewanlai.png","600040-1",0,false,12}, get);
achievement_group[11] = P({11,11,false,"",0,1,998}, get);
achievement_group[12] = P({D[4006], 12,2,"lianshengzhidao.png",2}, get);
achievement_group[13] = P({D[5006], 13,12,"chuleipangtong.png","600116-1",9}, get);
achievement_group[14] = P({D[5006], 14,13,"linlangmanmu.png","600117-1",10}, get);
return { tb = achievement_group };