-- 由 Excel 自动生成的 Lua 表
-- 文件:   [achievement][badge]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["base_task"] = 2; ["deprecated"] = 3;};

local df = {  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local badge = { }
badge[810001] = P({810001,800001}, get);
badge[810002] = P({810002,800002}, get);
badge[810003] = P({810003,800003}, get);
badge[810004] = P({810004,800004}, get);
badge[810005] = P({810005,800005}, get);
badge[810006] = P({810006,800006}, get);
badge[810011] = P({810011,800007}, get);
badge[810012] = P({810012,800008}, get);
badge[810013] = P({810013,800009}, get);
badge[810014] = P({810014,800010}, get);
badge[810015] = P({810015,800011}, get);
badge[810016] = P({810016,800012}, get);
badge[810021] = P({810021,800013}, get);
badge[810022] = P({810022,800014}, get);
badge[810023] = P({810023,800015}, get);
badge[810024] = P({810024,800016}, get);
badge[810025] = P({810025,800017}, get);
badge[810026] = P({810026,800018}, get);
return { tb = badge };