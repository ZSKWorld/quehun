-- 由 Excel 自动生成的 Lua 表
-- 文件:   [achievement][badge_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["badge_id"] = 2; ["name"] = 3; ["desc"] = 4; ["type"] = 5; ["img"] = 1006;};

local df = {  nil, nil, nil, nil, 1, "1.png",};

local get = function(item, k) return G(item, k, n2i, df); end;


local badge_group = { }
badge_group[1] = P({1,S({810001,}),20370,20307}, get);
badge_group[2] = P({2,S({810002,810003,}),20371,20308,false,"2.png"}, get);
badge_group[3] = P({3,S({810004,}),20372,20309,false,"3.png"}, get);
badge_group[4] = P({4,S({810005,}),20373,20310,false,"4.png"}, get);
badge_group[5] = P({5,S({810006,}),20374,20311,false,"5.png"}, get);
badge_group[11] = P({11,S({810011,}),20375,20312,2}, get);
badge_group[12] = P({12,S({810012,810013,}),20376,20313,2,"2.png"}, get);
badge_group[13] = P({13,S({810014,}),20377,20314,2,"3.png"}, get);
badge_group[14] = P({14,S({810015,}),20378,20315,2,"4.png"}, get);
badge_group[15] = P({15,S({810016,}),20379,20316,2,"6.png"}, get);
badge_group[21] = P({21,S({810021,}),20380,20317,3}, get);
badge_group[22] = P({22,S({810022,810023,}),20381,20318,3,"2.png"}, get);
badge_group[23] = P({23,S({810024,}),20382,20319,3,"3.png"}, get);
badge_group[24] = P({24,S({810025,}),20383,20320,3,"4.png"}, get);
badge_group[25] = P({25,S({810026,}),20384,20321,3,"7.png"}, get);
return { tb = badge_group };