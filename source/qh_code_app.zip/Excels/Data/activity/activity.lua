-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["type"] = 1003; ["need_popout"] = 4;};

local df = {  nil,  nil, "chest_up", nil,};

local get = function(item, k) return G(item, k, n2i, df, "activity_activity"); end;

local b2i = {1246,230603,240606,250333,260735,}

local activity = { }
return { tb = activity, get = get, b2i = b2i };