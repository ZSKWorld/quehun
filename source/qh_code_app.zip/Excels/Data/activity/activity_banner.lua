-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity_banner]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["sort"] = 2; ["banner_type"] = 3; ["enter_icon"] = 1004; ["banner_big"] = 1005; ["banner_left"] = 1006; ["banner_left_selected"] = 1007; ["banner_left_icon"] = 1008; ["time_remind"] = 9;};

local df = {  nil, 140, 2, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local activity_banner = { }
activity_banner[1] = P({D[4005], 1,2,1,"ui/activity/lobby/banner_tab/pic/level_1.png","ui/activity/lobby/banner_tab/pic/level_1_selected.png","ui/activity/lobby/banner_tab/pic/daily_mission.png"}, get);
activity_banner[2] = P({D[4005], 2,3,1,"ui/activity/lobby/banner_tab/pic/level_1.png","ui/activity/lobby/banner_tab/pic/level_1_selected.png","ui/activity/lobby/banner_tab/pic/weekly_mission.png"}, get);
activity_banner[3] = P({D[4005], 3,1,1,"ui/activity/lobby/banner_tab/pic/level_1.png","ui/activity/lobby/banner_tab/pic/level_1_selected.png","ui/activity/lobby/banner_tab/pic/fuhuo.png"}, get);
activity_banner[4] = P({D[4005], 4,4,1,"ui/activity/lobby/banner_tab/pic/level_2.png","ui/activity/lobby/banner_tab/pic/level_2_selected.png","ui/activity/lobby/banner_tab/pic/yushou.png",3}, get);
activity_banner[5] = P({D[4005], 5,999,1,"ui/activity/lobby/banner_tab/pic/24wenjuan1.png"}, get);
activity_banner[6] = P({D[4005], 6,998,1,"ui/activity/lobby/banner_tab/pic/24wenjuan2.png"}, get);
activity_banner[7] = P({D[4005], 7,997,1,"ui/activity/lobby/banner_tab/pic/24wenjuan3.png"}, get);
activity_banner[230143] = P({230143,5,1,false,"ui/activity/lobby/banner_tab/pic/25lunhuan_b.jpg","ui/activity/lobby/banner_tab/pic/25lunhuan.png"}, get);
activity_banner[240801] = P({240801,100,false,"ui/activity/lobby/banner_lobby/pic/24summer1_0.png",false,"ui/activity/lobby/banner_tab/pic/24summer1.png"}, get);
activity_banner[240811] = P({D[3005], 240811,101,"ui/activity/lobby/banner_tab/pic/24summer2.png"}, get);
activity_banner[240860] = P({D[3005], 240860,102,"ui/activity/lobby/banner_tab/pic/24zhongqiu1.png"}, get);
activity_banner[240901] = P({240901,103,false,"ui/activity/lobby/banner_lobby/pic/24sanliou1_0.png",false,"ui/activity/lobby/banner_tab/pic/24sanliou1.png"}, get);
activity_banner[241001] = P({D[3005], 241001,105,"ui/activity/lobby/banner_tab/pic/24wansheng1.png"}, get);
activity_banner[241002] = P({D[3005], 241002,104,"ui/activity/lobby/banner_tab/pic/24wansheng2.png"}, get);
activity_banner[241091] = P({241091,106,false,"ui/activity/lobby/banner_lobby/pic/24imas_signin_0.png"}, get);
activity_banner[241101] = P({241101,107,false,"ui/activity/lobby/banner_lobby/pic/24imas1_0.png",false,"ui/activity/lobby/banner_tab/pic/24imas1.png"}, get);
activity_banner[241201] = P({241201,108,false,"ui/activity/lobby/banner_lobby/pic/24winter1_0.png",false,"ui/activity/lobby/banner_tab/pic/24winter1.png"}, get);
activity_banner[250101] = P({250101,110,false,"ui/activity/lobby/banner_lobby/pic/25chunjie1_0.png",false,"ui/activity/lobby/banner_tab/pic/25chunjie1.png"}, get);
activity_banner[250111] = P({250111,109,false,"ui/activity/lobby/banner_lobby/pic/25chunjie2_0.png","ui/activity/lobby/banner_tab/pic/25chunjie2_b.jpg","ui/activity/lobby/banner_tab/pic/25chunjie2.png"}, get);
activity_banner[250201] = P({D[3004], 250201,112,"ui/activity/lobby/banner_tab/pic/25lifu1_b.jpg","ui/activity/lobby/banner_tab/pic/25lifu1.png"}, get);
activity_banner[250202] = P({D[3004], 250202,111,"ui/activity/lobby/banner_tab/pic/25lifu2_b.jpg","ui/activity/lobby/banner_tab/pic/25lifu2.png"}, get);
activity_banner[250301] = P({D[3004], 250301,114,"ui/activity/lobby/banner_tab/pic/25wenquan1_b.jpg","ui/activity/lobby/banner_tab/pic/25wenquan1.png"}, get);
activity_banner[250302] = P({D[3004], 250302,113,"ui/activity/lobby/banner_tab/pic/25wenquan2_b.jpg","ui/activity/lobby/banner_tab/pic/25wenquan2.png"}, get);
activity_banner[250391] = P({250391,115,false,"ui/activity/lobby/banner_lobby/pic/25fate_signin_0.png"}, get);
activity_banner[250401] = P({250401,116,false,"ui/activity/lobby/banner_lobby/pic/25hf_0.png","ui/activity/lobby/banner_tab/pic/25hf_b.jpg","ui/activity/lobby/banner_tab/pic/25hf.png"}, get);
activity_banner[250501] = P({250501,117,false,"ui/activity/lobby/banner_lobby/pic/25balei_0.png","ui/activity/lobby/banner_tab/pic/25balei_b.jpg","ui/activity/lobby/banner_tab/pic/25balei.png"}, get);
activity_banner[250601] = P({250601,118,false,"ui/activity/lobby/banner_lobby/pic/25xila_0.png","ui/activity/lobby/banner_tab/pic/25xila_b.jpg","ui/activity/lobby/banner_tab/pic/25xila.png"}, get);
activity_banner[250701] = P({D[3004], 250701,120,"ui/activity/lobby/banner_tab/pic/25jk1_b.jpg","ui/activity/lobby/banner_tab/pic/25jk1.png"}, get);
activity_banner[250702] = P({D[3004], 250702,119,"ui/activity/lobby/banner_tab/pic/25jk2_b.jpg","ui/activity/lobby/banner_tab/pic/25jk2.png"}, get);
activity_banner[250790] = P({D[3004], 250790,121,"ui/activity/lobby/banner_tab/pic/25fanpai_b.jpg","ui/activity/lobby/banner_tab/pic/25fanpai.png"}, get);
activity_banner[250811] = P({250811,122,false,"ui/activity/lobby/banner_lobby/pic/25summer2_0.png","ui/activity/lobby/banner_tab/pic/25summer2_b.jpg","ui/activity/lobby/banner_tab/pic/25summer2.png"}, get);
activity_banner[250820] = P({250820,123,false,"ui/activity/lobby/banner_lobby/pic/25summer1_0.png","ui/activity/lobby/banner_tab/pic/25summer1_b.jpg","ui/activity/lobby/banner_tab/pic/25summer1.png"}, get);
activity_banner[250890] = P({250890,124,false,"ui/activity/lobby/banner_lobby/pic/25toupiao_0.png","ui/activity/lobby/banner_tab/pic/25toupiao_b.jpg","ui/activity/lobby/banner_tab/pic/25toupiao.png"}, get);
activity_banner[250901] = P({D[3004], 250901,126,"ui/activity/lobby/banner_tab/pic/25wuxia1_b.jpg","ui/activity/lobby/banner_tab/pic/25wuxia1.png"}, get);
activity_banner[250902] = P({D[3004], 250902,125,"ui/activity/lobby/banner_tab/pic/25wuxia2_b.jpg","ui/activity/lobby/banner_tab/pic/25wuxia2.png"}, get);
activity_banner[250991] = P({250991,127,false,"ui/activity/lobby/banner_lobby/pic/25yh_signin_0.png"}, get);
activity_banner[251001] = P({251001,128,false,"ui/activity/lobby/banner_lobby/pic/25yh_0.png","ui/activity/lobby/banner_tab/pic/25yh_b.jpg","ui/activity/lobby/banner_tab/pic/25yh.png"}, get);
activity_banner[251101] = P({251101,129,false,"ui/activity/lobby/banner_lobby/pic/25yuehui_0.png","ui/activity/lobby/banner_tab/pic/25yuehui_b.jpg","ui/activity/lobby/banner_tab/pic/25yuehui.png"}, get);
activity_banner[251190] = P({D[3005], 251190,130,"ui/activity/lobby/banner_tab/pic/25bingo.png"}, get);
activity_banner[251201] = P({251201,131,false,"ui/activity/lobby/banner_lobby/pic/25dongri_0.png","ui/activity/lobby/banner_tab/pic/25dongri_b.jpg","ui/activity/lobby/banner_tab/pic/25dongri.png"}, get);
activity_banner[260101] = P({260101,132,false,"ui/activity/lobby/banner_lobby/pic/26lifu_0.png","ui/activity/lobby/banner_tab/pic/26lifu_b.jpg","ui/activity/lobby/banner_tab/pic/26lifu.png"}, get);
activity_banner[260190] = P({D[3004], 260190,133,"ui/activity/lobby/banner_tab/pic/26fanpai_b.jpg","ui/activity/lobby/banner_tab/pic/26fanpai.png"}, get);
activity_banner[260201] = P({260201,134,false,"ui/activity/lobby/banner_lobby/pic/26chunjie_0.png","ui/activity/lobby/banner_tab/pic/26chunjie_b.jpg","ui/activity/lobby/banner_tab/pic/26chunjie.png"}, get);
activity_banner[260301] = P({D[3004], 260301,136,"ui/activity/lobby/banner_tab/pic/26wenquan_b.jpg","ui/activity/lobby/banner_tab/pic/26wenquan1.png"}, get);
activity_banner[260302] = P({D[3004], 260302,135,"ui/activity/lobby/banner_tab/pic/26wenquan2_b.jpg","ui/activity/lobby/banner_tab/pic/26wenquan2.png"}, get);
activity_banner[260391] = P({260391,137,false,"ui/activity/lobby/banner_lobby/pic/26dj_signin_0.png"}, get);
activity_banner[260401] = P({260401,138,false,"ui/activity/lobby/banner_lobby/pic/26dj_0.png","ui/activity/lobby/banner_tab/pic/26dj_b.jpg","ui/activity/lobby/banner_tab/pic/26dj.png"}, get);
activity_banner[260511] = P({260511,139,false,"ui/activity/lobby/banner_lobby/pic/26qingyun_0.png","ui/activity/lobby/banner_tab/pic/26qingyun_b.jpg","ui/activity/lobby/banner_tab/pic/26qingyun.png"}, get);
activity_banner[260601] = P({D[2003], 260601,"ui/activity/lobby/banner_lobby/pic/26dp_0.png","ui/activity/lobby/banner_tab/pic/26dp_b.jpg","ui/activity/lobby/banner_tab/pic/26dp.png"}, get);
activity_banner[260692] = P({260692,141,false,"ui/activity/lobby/banner_lobby/pic/26toupiao_0.png","ui/activity/lobby/banner_tab/pic/26toupiao_b.jpg","ui/activity/lobby/banner_tab/pic/26toupiao.png"}, get);
activity_banner[260701] = P({D[3004], 260701,143,"ui/activity/lobby/banner_tab/pic/26huanxiang1_b.jpg","ui/activity/lobby/banner_tab/pic/26huanxiang1.png"}, get);
activity_banner[260702] = P({D[3004], 260702,142,"ui/activity/lobby/banner_tab/pic/26huanxiang2_b.jpg","ui/activity/lobby/banner_tab/pic/26huanxiang2.png"}, get);
activity_banner[260801] = P({D[2003], 260801,"ui/activity/lobby/banner_lobby/pic/26summer_0.png","ui/activity/lobby/banner_tab/pic/26summer_b.jpg","ui/activity/lobby/banner_tab/pic/26summer.png"}, get);
return { tb = activity_banner };