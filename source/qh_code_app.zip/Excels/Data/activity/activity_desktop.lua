-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity_desktop]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["desktop_id"] = 2; ["interval"] = 3; ["interval_type"] = 4;};

local df = {  230143, nil, nil, 2,};

local get = function(item, k) return G(item, k, n2i, df); end;


local activity_desktop = { }
activity_desktop[230143] = {
	P({false,33,1}, get),
	P({false,51,2}, get),
	P({false,46,3}, get),
	P({false,35,4}, get),
	P({false,47,5}, get),
	P({false,48,6}, get),
	P({false,49,7}, get),
	P({false,50,8}, get),
};
return { tb = activity_desktop };