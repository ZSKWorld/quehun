-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity_guide]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["guide_id"] = 1; ["activity_id"] = 2; ["guide_location"] = 3; ["char_id"] = 4; ["char_str_id"] = 5; ["content_str_id"] = 6;};

local df = {  nil, 240811, 1, 200095, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local activity_guide = { }
activity_guide[24081101] = P({D[2005], 24081101,3055}, get);
activity_guide[24081102] = P({D[2005], 24081102,3056}, get);
activity_guide[24081103] = P({D[2005], 24081103,3057}, get);
activity_guide[24081104] = P({24081104,false,0,0,false,3058}, get);
activity_guide[24081105] = P({D[2005], 24081105,3059}, get);
activity_guide[24081106] = P({24081106,false,0,0,false,3060}, get);
activity_guide[24081107] = P({D[2005], 24081107,3061}, get);
activity_guide[24081108] = P({D[2005], 24081108,3062}, get);
activity_guide[24081109] = P({24081109,false,0,0,false,3063}, get);
activity_guide[24081110] = P({D[2005], 24081110,3064}, get);
activity_guide[24081111] = P({D[2005], 24081111,3065}, get);
activity_guide[24081112] = P({24081112,false,0,0,false,3066}, get);
activity_guide[24081113] = P({D[2005], 24081113,3067}, get);
activity_guide[24081114] = P({D[2005], 24081114,3068}, get);
activity_guide[24081115] = P({24081115,false,0,0,false,3069}, get);
activity_guide[24081116] = P({D[2005], 24081116,3070}, get);
activity_guide[24081117] = P({24081117,false,0,0,false,3071}, get);
activity_guide[24081118] = P({D[2005], 24081118,3072}, get);
activity_guide[24081119] = P({D[2005], 24081119,3073}, get);
return { tb = activity_guide };