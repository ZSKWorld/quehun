-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity_item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["item_list"] = 1002;};

local df = {  nil, "309036-1",};

local get = function(item, k) return G(item, k, n2i, df); end;


local activity_item = { }
activity_item[221209] = P({221209,"307225-1,307226-1"}, get);
activity_item[230142] = P({230142,"307227-1,307228-1"}, get);
activity_item[230209] = P({230209,"307229-1"}, get);
activity_item[230309] = P({230309,"307230-1"}, get);
activity_item[230412] = P({230412,"307231-1"}, get);
activity_item[230509] = P({230509,"307233-1"}, get);
activity_item[230611] = P({230611,"307234-1,307235-1"}, get);
activity_item[230708] = P({230708,"307236-1"}, get);
activity_item[230818] = P({230818,"307237-1,307238-1,307239-1"}, get);
activity_item[230907] = P({230907,"307240-1"}, get);
activity_item[231021] = P({231021,"307241-1"}, get);
activity_item[231125] = P({231125,"307242-1"}, get);
activity_item[231220] = P({231220,"307243-1,307244-1"}, get);
activity_item[240113] = P({240113,"307245-1,307246-1,30900013-2,30900014-9,30900007-10"}, get);
activity_item[240208] = P({240208,"307247-1"}, get);
activity_item[240304] = P({240304,"30900016-188,307248-1,307249-1"}, get);
activity_item[240442] = P({240442,"307250-1"}, get);
activity_item[240504] = P({240504,"307251-1"}, get);
activity_item[240612] = P({240612,"307252-1,307253-1,30900028-5,30900029-36"}, get);
activity_item[240712] = P({240712,"307254-1"}, get);
activity_item[240821] = P({240821}, get);
activity_item[240823] = P({240823}, get);
activity_item[240824] = P({240824}, get);
activity_item[240825] = P({240825}, get);
activity_item[240826] = P({240826,"307255-1,307256-1,307257-1"}, get);
activity_item[240912] = P({240912,"307260-1"}, get);
activity_item[241012] = P({241012,"307261-1"}, get);
activity_item[241112] = P({241112,"307262-1"}, get);
activity_item[241212] = P({241212,"307263-1,307264-1"}, get);
activity_item[250122] = P({250122,"307265-1,307266-1"}, get);
activity_item[250212] = P({250212,"307268-1"}, get);
activity_item[250312] = P({250312,"307269-1,307270-1"}, get);
activity_item[250422] = P({250422,"307271-1"}, get);
activity_item[250512] = P({250512,"307272-1"}, get);
activity_item[250612] = P({250612,"307273-1"}, get);
activity_item[250712] = P({250712,"307274-1"}, get);
activity_item[250832] = P({250832,"307275-1,307276-1"}, get);
activity_item[250912] = P({250912,"307277-1"}, get);
activity_item[251022] = P({251022,"307278-1"}, get);
activity_item[251112] = P({251112,"307279-1"}, get);
activity_item[251212] = P({251212,"307280-1,307281-1"}, get);
activity_item[260104] = P({260104,"30900016-188,307282-1"}, get);
activity_item[260212] = P({260212,"307283-1,307284-1"}, get);
activity_item[260312] = P({260312,"307286-1"}, get);
activity_item[260412] = P({260412,"307287-1,307288-1"}, get);
activity_item[260542] = P({260542,"307289-1"}, get);
activity_item[260612] = P({260612,"307290-1,307291-1"}, get);
activity_item[260712] = P({260712,"307292-1"}, get);
activity_item[260812] = P({260812,"307293-1,307294-1"}, get);
return { tb = activity_item };