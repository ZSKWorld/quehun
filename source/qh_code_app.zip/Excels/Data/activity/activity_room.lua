-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][activity_room]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["sort"] = 2; ["str_name"] = 1003; ["str_rule"] = 1004; ["friend_room_id"] = 5; ["dora3_mode"] = 6; ["begin_open_mode"] = 7; ["muyu_mode"] = 8; ["xuezhan_mode"] = 9; ["huanzhang_mode"] = 10; ["chuanma_mode"] = 11; ["jiuchao_mode"] = 12; ["reveal_discard"] = 13; ["field_spell_mode"] = 14; ["zhanxing_mode"] = 15; ["tianming_mode"] = 16; ["yongchang_mode"] = 17; ["hunzhiyiji_mode"] = 18; ["wanxiangxiuluo_mode"] = 19; ["beishuizhizhan_mode"] = 20; ["xiakeshang_mode"] = 21; ["qiangduozhizhan_mode"] = 22;};

local df = {  nil, nil, "3384", "3390", 3, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local activity_room = { }
activity_room[1161] = P({D[3008], 1161,1,1,1}, get);
activity_room[1166] = P({D[3008], 1166,2,1,1}, get);
activity_room[1190] = P({D[3008], 1190,3,1,1}, get);
activity_room[1233] = P({D[6012], 1233,5,"3518","3528",5,1}, get);
activity_room[1296] = P({D[6009], 1296,6,"3394","3650",6,1,1}, get);
activity_room[1297] = P({1297,7,"3655","3651",7,1}, get);
activity_room[220410] = P({D[6013], 220410,8,"3586","3588",8,1}, get);
activity_room[221107] = P({D[6014], 221107,9,"3700","3705",9,1}, get);
activity_room[230408] = P({D[6015], 230408,10,"3877","3857",10,1}, get);
activity_room[231123] = P({D[6016], 231123,11,"3981","3987",11,1}, get);
activity_room[240412] = P({D[6017], 240412,12,"4206","4208",12,1}, get);
activity_room[241141] = P({D[6018], 241141,13,"20193","20194",13,1}, get);
activity_room[250412] = P({D[6019], 250412,14,"25040020","25040508",15,1}, get);
activity_room[251050] = P({D[6020], 251050,16,"25101012","25101014",16,1}, get);
activity_room[260451] = P({D[6021], 260451,17,"26041083","26041086",17,1}, get);
activity_room[260652] = P({D[6011], 260652,4,"3517","3527",4,1}, get);
return { tb = activity_room };