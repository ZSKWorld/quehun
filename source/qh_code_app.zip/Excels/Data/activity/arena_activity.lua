-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][arena_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["match_time"] = 1002; ["ticket_time_limit"] = 1003; ["ticket_item_id"] = 4; ["ticket_price"] = 1005; ["desktop_id"] = 6; ["max_win_count"] = 7; ["max_lose_count"] = 8; ["reward_group"] = 9; ["daily_ticket_limit"] = 10; ["mail_template"] = 11; ["arena_reward_display_group"] = 12; ["level_limit"] = 13;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local arena_activity = { }
arena_activity[1245] = P({1245,"0","2021-12-20 04:59:00+08",309040,"100002-75000",42,12,3,124501,5,108,124501,201}, get);
return { tb = arena_activity };