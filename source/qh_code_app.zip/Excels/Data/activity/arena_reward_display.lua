-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][arena_reward_display]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["win_count_min"] = 2; ["win_count_max"] = 3; ["reward_1"] = 4; ["reward_1_remark"] = 1005; ["reward_2"] = 6; ["reward_2_remark"] = 1007; ["reward_3"] = 8; ["reward_3_remark"] = 1009; ["reward_4"] = 10; ["reward_4_remark"] = 1011;};

local df = {  124501, nil, nil, 304007, "1-2", 100002, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local arena_reward_display = { }
arena_reward_display[124501] = {
	P({false,0,2}, get),
	P({false,3,5,false,"3-4"}, get),
	P({false,6,9,304008,false,304007,"0-3",100002}, get),
	P({false,10,11,304006,"1",304008,"0-2",100002}, get),
	P({false,12,12,304102,"1",304006,"1",304008,"2",100002}, get),
};
return { tb = arena_reward_display };