-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][bingo_card]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["card_id"] = 1; ["type"] = 1002; ["base_task_id"] = 3; ["pos"] = 4;};

local df = {  100001, "m", 23091, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local bingo_card = { }
bingo_card[100001] = {
	P({}, get),
	P({false,"s",23093,2}, get),
	P({false,"any",0,3}, get),
	P({false,"p",23092,4}, get),
	P({false,"any",0,5}, get),
	P({false,"p",23092,6}, get),
	P({false,"any",0,7}, get),
	P({false,"s",23093,8}, get),
	P({D[1003], 9}, get),
};
bingo_card[100002] = {
	P({100002}, get),
	P({100002,"p",23092,2}, get),
	P({100002,"any",0,3}, get),
	P({100002,"s",23093,4}, get),
	P({D[2003], 100002,5}, get),
	P({100002,"s",23093,6}, get),
	P({100002,"any",0,7}, get),
	P({100002,"p",23092,8}, get),
	P({100002,"w",23094,9}, get),
};
bingo_card[100003] = {
	P({100003,"y",23095}, get),
	P({100003,"p",23092,2}, get),
	P({100003,"w",23094,3}, get),
	P({D[2003], 100003,4}, get),
	P({100003,"any",0,5}, get),
	P({100003,"p",23092,6}, get),
	P({D[2003], 100003,7}, get),
	P({100003,"s",23093,8}, get),
	P({100003,"s",23093,9}, get),
};
bingo_card[100004] = {
	P({100004,"p",23092}, get),
	P({100004,"y",23095,2}, get),
	P({D[2003], 100004,3}, get),
	P({100004,"p",23092,4}, get),
	P({100004,"s",23093,5}, get),
	P({D[2003], 100004,6}, get),
	P({D[2003], 100004,7}, get),
	P({100004,"s",23093,8}, get),
	P({100004,"w",23094,9}, get),
};
bingo_card[100005] = {
	P({100005}, get),
	P({100005,"w",23094,2}, get),
	P({100005,"s",23093,3}, get),
	P({100005,"p",23092,4}, get),
	P({100005,"p",23092,5}, get),
	P({100005,false,23094,6}, get),
	P({100005,"y",23095,7}, get),
	P({100005,"s",23093,8}, get),
	P({100005,"w",23094,9}, get),
};
bingo_card[100006] = {
	P({100006,"y",23095}, get),
	P({100006,"y",23095,2}, get),
	P({100006,"p",23092,3}, get),
	P({100006,"p",23092,4}, get),
	P({100006,"w",23094,5}, get),
	P({D[2003], 100006,6}, get),
	P({100006,"s",23093,7}, get),
	P({D[2003], 100006,8}, get),
	P({100006,"s",23093,9}, get),
};
bingo_card[100007] = {
	P({100007}, get),
	P({100007,"p",23092,2}, get),
	P({100007,"w",23094,3}, get),
	P({D[2003], 100007,4}, get),
	P({100007,"y",23095,5}, get),
	P({100007,"s",23093,6}, get),
	P({100007,"y",23095,7}, get),
	P({100007,"s",23093,8}, get),
	P({100007,"w",23094,9}, get),
};
return { tb = bingo_card };