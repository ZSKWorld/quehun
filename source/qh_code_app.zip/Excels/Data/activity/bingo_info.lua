-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][bingo_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["card_id"] = 2; ["unlock_day"] = 3;};

local df = {  251190, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local bingo_info = { }
bingo_info[251190] = {
	P({false,100001,0}, get),
	P({false,100002,1}, get),
	P({false,100003,2}, get),
	P({false,100004,3}, get),
	P({false,100005,4}, get),
	P({false,100006,5}, get),
	P({false,100007,6}, get),
};
return { tb = bingo_info };