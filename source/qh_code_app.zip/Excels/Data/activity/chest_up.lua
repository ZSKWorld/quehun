-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][chest_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["activity_id"] = 1; ["chest_id"] = 2; ["title_str_id"] = 3; ["str_id"] = 1004; ["chara_str_id"] = 5; ["item_str_id"] = 6; ["img"] = 1007; ["title_img"] = 1008; ["title_img_2"] = 1009; ["typeset"] = 10; ["enter_animation"] = 1011; ["special_effect_front"] = 1012; ["special_effect_back"] = 1013; ["special_audio"] = 14; ["up_items_type"] = 15; ["up_items"] = 16;};

local df = {  1026, 1004, nil, nil, nil, nil, "chest_0", nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1157,220502,230610,240126,240422,241220,250150,250622,251227,260725,}

local chest_up = { }
return { tb = chest_up, get = get, b2i = b2i };