-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][chest_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local chest_up = require("Excels.Data.activity.chest_up")
local tb = chest_up.tb
local get = chest_up.get

tb[1003] = {
	P({D[8015], 1003,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1906_up.png",S({})}, get),
};
tb[1008] = {
	P({D[8015], 1008,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1906_up.png",S({})}, get),
	P({D[8015], 1008,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic1906_up.png",S({})}, get),
};
tb[1015] = {
	P({D[8015], 1015,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_up.png",S({})}, get),
	P({D[8015], 1015,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_up.png",S({})}, get),
};
tb[1016] = {
	P({D[8015], 1016,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_Mup1.png",S({})}, get),
	P({D[8015], 1016,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_Mup1.png",S({})}, get),
};
tb[1017] = {
	P({D[8015], 1017,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_Mup2.png",S({})}, get),
	P({D[8015], 1017,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic1908_Mup2.png",S({})}, get),
};
tb[1026] = {
	P({D[8015], false,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1910_up.png",S({305200,305300,305600,305700,200018,200019,306102,305051,})}, get),
	P({D[8015], false,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic1910_up.png",S({305200,305300,305600,305700,200018,200019,306102,305051,})}, get),
	P({D[8015], false,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic1910_Mup1.png",S({305200,305300,305600,305700,200011,200012,306102,305051,})}, get),
	P({D[8015], false,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic1910_Mup1.png",S({305200,305300,305600,305700,200011,200012,306102,305051,})}, get),
};
tb[1027] = {
	P({D[8015], 1027,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1911_up.png",S({200010,})}, get),
	P({D[8015], 1027,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic1911_up.png",S({200010,})}, get),
};
tb[1030] = {
	P({D[8015], 1030,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic1912_up.png",S({200003,200004,200007,})}, get),
	P({D[8015], 1030,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic1912_up.png",S({200003,200004,200007,})}, get),
	P({D[8015], 1030,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic1912_Mup.png",S({200013,})}, get),
	P({D[8015], 1030,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic1912_Mup.png",S({200013,})}, get),
};
tb[1033] = {
	P({D[8015], 1033,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20yd_up.png",S({200020,200021,305201,305202,305301,305302,305601,306102,})}, get),
	P({D[8015], 1033,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20yd_up.png",S({200020,200021,305201,305202,305301,305302,305601,306102,})}, get),
	P({D[8015], 1033,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20yd_Mup.png",S({200022,200023,305201,305202,305301,305302,305601,306102,})}, get),
	P({D[8015], 1033,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20yd_Mup.png",S({200022,200023,305201,305202,305301,305302,305601,306102,})}, get),
};
tb[1034] = {
	P({D[8015], 1034,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20ydsl_up.png",S({200016,})}, get),
	P({D[8015], 1034,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20ydsl_up.png",S({200016,})}, get),
};
tb[1039] = {
	P({D[8015], 1039,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj1_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200003,})}, get),
	P({D[8015], 1039,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj1_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200003,})}, get),
};
tb[1040] = {
	P({D[8015], 1040,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj2_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200004,})}, get),
	P({D[8015], 1040,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj2_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200004,})}, get),
};
tb[1041] = {
	P({D[8015], 1041,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj3_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200005,})}, get),
	P({D[8015], 1041,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj3_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200005,})}, get),
};
tb[1042] = {
	P({D[8015], 1042,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj4_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200006,})}, get),
	P({D[8015], 1042,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj4_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200006,})}, get),
};
tb[1043] = {
	P({D[8015], 1043,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj5_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200007,})}, get),
	P({D[8015], 1043,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj5_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200007,})}, get),
};
tb[1044] = {
	P({D[8015], 1044,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj6_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200008,})}, get),
	P({D[8015], 1044,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj6_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200008,})}, get),
};
tb[1045] = {
	P({D[8015], 1045,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj7_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200009,})}, get),
	P({D[8015], 1045,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj7_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200009,})}, get),
};
tb[1046] = {
	P({D[8015], 1046,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj8_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200010,})}, get),
	P({D[8015], 1046,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj8_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200010,})}, get),
};
tb[1047] = {
	P({D[8015], 1047,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj9_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200016,})}, get),
	P({D[8015], 1047,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj9_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200016,})}, get),
};
tb[1048] = {
	P({D[8015], 1048,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj10_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200017,})}, get),
	P({D[8015], 1048,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj10_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200017,})}, get),
};
tb[1049] = {
	P({D[8015], 1049,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj11_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200018,})}, get),
	P({D[8015], 1049,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj11_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200018,})}, get),
};
tb[1050] = {
	P({D[8015], 1050,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj12_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200019,})}, get),
	P({D[8015], 1050,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj12_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200019,})}, get),
};
tb[1051] = {
	P({D[8015], 1051,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj13_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200020,})}, get),
	P({D[8015], 1051,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj13_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200020,})}, get),
};
tb[1052] = {
	P({D[8015], 1052,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj14_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200021,})}, get),
	P({D[8015], 1052,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20cj14_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200021,})}, get),
};
tb[1053] = {
	P({D[8015], 1053,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM1_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200012,})}, get),
	P({D[8015], 1053,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM1_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200012,})}, get),
};
tb[1054] = {
	P({D[8015], 1054,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM2_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200013,})}, get),
	P({D[8015], 1054,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM2_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200013,})}, get),
};
tb[1055] = {
	P({D[8015], 1055,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM3_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200014,})}, get),
	P({D[8015], 1055,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM3_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200014,})}, get),
};
tb[1056] = {
	P({D[8015], 1056,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM4_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200011,})}, get),
	P({D[8015], 1056,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM4_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200011,})}, get),
};
tb[1057] = {
	P({D[8015], 1057,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM5_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200022,})}, get),
	P({D[8015], 1057,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM5_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200022,})}, get),
};
tb[1058] = {
	P({D[8015], 1058,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM6_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200023,})}, get),
	P({D[8015], 1058,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20cjM6_up.png",S({305027,305028,305029,305203,305303,305602,305701,305801,200023,})}, get),
};
tb[1068] = {
	P({D[8015], 1068,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20jpzn1_up.png",S({305204,305205,305304,305305,305603,200024,})}, get),
	P({D[8015], 1068,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20jpzn1_up.png",S({305204,305205,305304,305305,305603,200024,})}, get),
};
tb[1069] = {
	P({D[8015], 1069,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic20jpznM1_up.png",S({305204,305205,305304,305305,305603,200025,})}, get),
	P({D[8015], 1069,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic20jpznM1_up.png",S({305204,305205,305304,305305,305603,200025,})}, get),
};
tb[1071] = {
	P({D[8015], 1071,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic2005maid1_up.png",S({200008,})}, get),
	P({D[8015], 1071,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic2005maid1_up.png",S({200008,})}, get),
};
tb[1072] = {
	P({D[8015], 1072,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2005maidM1_up.png",S({200013,})}, get),
	P({D[8015], 1072,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2005maidM1_up.png",S({200013,})}, get),
};
tb[1082] = {
	P({D[8015], 1082,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic2006_up.png",S({305206,305207,305306,305307,200026,})}, get),
	P({D[8015], 1082,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic2006_up.png",S({305206,305207,305306,305307,200026,})}, get),
};
tb[1083] = {
	P({D[8015], 1083,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2006_Mup.png",S({305206,305207,305306,305307,200027,})}, get),
	P({D[8015], 1083,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2006_Mup.png",S({305206,305207,305306,305307,200027,})}, get),
};
tb[1086] = {
	P({D[8015], 1086,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20071_up.png",S({200018,})}, get),
	P({D[8015], 1086,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20071_up.png",S({200018,})}, get),
};
tb[1087] = {
	P({D[8015], 1087,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2007M1_up.png",S({200014,})}, get),
	P({D[8015], 1087,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2007M1_up.png",S({200014,})}, get),
};
tb[1088] = {
	P({D[8015], 1088,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20072_up.png",S({200024,})}, get),
	P({D[8015], 1088,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20072_up.png",S({200024,})}, get),
};
tb[1089] = {
	P({D[8015], 1089,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2007M2_up.png",S({200025,})}, get),
	P({D[8015], 1089,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2007M2_up.png",S({200025,})}, get),
};
tb[1098] = {
	P({D[8015], 1098,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20081_up.png",S({305208,305308,305604,305702,305802,200029,})}, get),
	P({D[8015], 1098,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20081_up.png",S({305208,305308,305604,305702,305802,200029,})}, get),
};
tb[1099] = {
	P({D[8015], 1099,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2008M1_up.png",S({305208,305308,305604,305702,305802,200030,})}, get),
	P({D[8015], 1099,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2008M1_up.png",S({305208,305308,305604,305702,305802,200030,})}, get),
};
tb[1100] = {
	P({D[8015], 1100,1000,false,false,false,false,"extendRes/treasurehead/treasure_pic20082_up.png",S({305208,305308,305604,305702,305802,200028,})}, get),
	P({D[8015], 1100,1001,false,false,false,false,"extendRes/treasurehead/treasure_pic20082_up.png",S({305208,305308,305604,305702,305802,200028,})}, get),
};
tb[1101] = {
	P({D[8015], 1101,1002,false,false,false,false,"extendRes/treasurehead/treasure_pic2008M2_up.png",S({305208,305308,305604,305702,305802,200031,})}, get),
	P({D[8015], 1101,1003,false,false,false,false,"extendRes/treasurehead/treasure_pic2008M2_up.png",S({305208,305308,305604,305702,305802,200031,})}, get),
};
tb[1111] = {
	P({D[8015], 1111,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20091_up.png",S({200010,})}, get),
	P({D[8015], 1111,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20091_up.png",S({200010,})}, get),
};
tb[1112] = {
	P({D[8015], 1112,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2009M1_up.png",S({200012,})}, get),
	P({D[8015], 1112,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2009M1_up.png",S({200012,})}, get),
};
tb[1113] = {
	P({D[8015], 1113,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20092_up.png",S({200004,})}, get),
	P({D[8015], 1113,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20092_up.png",S({200004,})}, get),
};
tb[1114] = {
	P({D[8015], 1114,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2009M2_up.png",S({200022,})}, get),
	P({D[8015], 1114,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2009M2_up.png",S({200022,})}, get),
};
tb[1115] = {
	P({D[8015], 1115,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20101_up.png",S({200007,})}, get),
	P({D[8015], 1115,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20101_up.png",S({200007,})}, get),
};
tb[1116] = {
	P({D[8015], 1116,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2010M1_up.png",S({200014,})}, get),
	P({D[8015], 1116,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2010M1_up.png",S({200014,})}, get),
};
tb[1121] = {
	P({D[8015], 1121,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20111_up.png",S({305209,305309,305605,200032,})}, get),
	P({D[8015], 1121,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20111_up.png",S({305209,305309,305605,200032,})}, get),
};
tb[1122] = {
	P({D[8015], 1122,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20112_up.png",S({305209,305309,305605,200033,})}, get),
	P({D[8015], 1122,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20112_up.png",S({305209,305309,305605,200033,})}, get),
};
tb[1123] = {
	P({D[8015], 1123,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2011M1_up.png",S({305209,305309,305605,200023,})}, get),
	P({D[8015], 1123,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2011M1_up.png",S({305209,305309,305605,200023,})}, get),
};
tb[1124] = {
	P({D[8015], 1124,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2011M2_up.png",S({305209,305309,305605,200011,})}, get),
	P({D[8015], 1124,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2011M2_up.png",S({305209,305309,305605,200011,})}, get),
};
tb[1126] = {
	P({D[8015], 1126,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20121_up.png",S({305703,305803,200029,})}, get),
	P({D[8015], 1126,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20121_up.png",S({305703,305803,200029,})}, get),
};
tb[1127] = {
	P({D[8015], 1127,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20122_up.png",S({305703,305803,200024,})}, get),
	P({D[8015], 1127,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20122_up.png",S({305703,305803,200024,})}, get),
};
tb[1128] = {
	P({D[8015], 1128,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20123_up.png",S({305703,305803,200008,})}, get),
	P({D[8015], 1128,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20123_up.png",S({305703,305803,200008,})}, get),
};
tb[1129] = {
	P({D[8015], 1129,false,false,false,false,false,"extendRes/treasurehead/treasure_pic20124_up.png",S({305703,305803,200028,})}, get),
	P({D[8015], 1129,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic20124_up.png",S({305703,305803,200028,})}, get),
};
tb[1130] = {
	P({D[8015], 1130,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2012M1_up.png",S({305703,305803,200013,})}, get),
	P({D[8015], 1130,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2012M1_up.png",S({305703,305803,200013,})}, get),
};
tb[1131] = {
	P({D[8015], 1131,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2012M2_up.png",S({305703,305803,200022,})}, get),
	P({D[8015], 1131,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2012M2_up.png",S({305703,305803,200022,})}, get),
};
tb[1133] = {
	P({D[2006], 1133,"extendRes/treasurehead/treasure_pic2101_up.jpg",false,false,2,false,false,false,false,false,S({200034,200035,200036,200037,308001,308002,308003,308004,308005,})}, get),
	P({D[11015], 1133,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic2101_up.jpg",false,false,2,S({200034,200035,200036,200037,308001,308002,308003,308004,308005,})}, get),
};
tb[1137] = {
	P({D[8015], 1137,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21021_up.png",S({200038,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1137,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21021_up.png",S({200038,305210,305310,305606,305804,306102,})}, get),
};
tb[1138] = {
	P({D[8015], 1138,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M1_up.png",S({200039,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1138,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M1_up.png",S({200039,305210,305310,305606,305804,306102,})}, get),
};
tb[1139] = {
	P({D[8015], 1139,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21022_up.png",S({200003,200004,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1139,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21022_up.png",S({200003,200004,305210,305310,305606,305804,306102,})}, get),
};
tb[1140] = {
	P({D[8015], 1140,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M2_up.png",S({200011,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1140,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M2_up.png",S({200011,305210,305310,305606,305804,306102,})}, get),
};
tb[1141] = {
	P({D[8015], 1141,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21023_up.png",S({200005,200006,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1141,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21023_up.png",S({200005,200006,305210,305310,305606,305804,306102,})}, get),
};
tb[1142] = {
	P({D[8015], 1142,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M3_up.png",S({200012,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1142,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M3_up.png",S({200012,305210,305310,305606,305804,306102,})}, get),
};
tb[1143] = {
	P({D[8015], 1143,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21024_up.png",S({200007,200008,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1143,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21024_up.png",S({200007,200008,305210,305310,305606,305804,306102,})}, get),
};
tb[1144] = {
	P({D[8015], 1144,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M4_up.png",S({200013,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1144,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M4_up.png",S({200013,305210,305310,305606,305804,306102,})}, get),
};
tb[1145] = {
	P({D[8015], 1145,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21025_up.png",S({200009,200010,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1145,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21025_up.png",S({200009,200010,305210,305310,305606,305804,306102,})}, get),
};
tb[1146] = {
	P({D[8015], 1146,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M5_up.png",S({200014,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1146,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M5_up.png",S({200014,305210,305310,305606,305804,306102,})}, get),
};
tb[1147] = {
	P({D[8015], 1147,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21026_up.png",S({200016,200017,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1147,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21026_up.png",S({200016,200017,305210,305310,305606,305804,306102,})}, get),
};
tb[1148] = {
	P({D[8015], 1148,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M6_up.png",S({200022,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1148,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M6_up.png",S({200022,305210,305310,305606,305804,306102,})}, get),
};
tb[1149] = {
	P({D[8015], 1149,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21027_up.png",S({200018,200019,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1149,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21027_up.png",S({200018,200019,305210,305310,305606,305804,306102,})}, get),
};
tb[1150] = {
	P({D[8015], 1150,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M7_up.png",S({200023,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1150,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M7_up.png",S({200023,305210,305310,305606,305804,306102,})}, get),
};
tb[1151] = {
	P({D[8015], 1151,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21028_up.png",S({200020,200021,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1151,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21028_up.png",S({200020,200021,305210,305310,305606,305804,306102,})}, get),
};
tb[1152] = {
	P({D[8015], 1152,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M8_up.png",S({200025,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1152,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M8_up.png",S({200025,305210,305310,305606,305804,306102,})}, get),
};
tb[1153] = {
	P({D[8015], 1153,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21029_up.png",S({200024,200026,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1153,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21029_up.png",S({200024,200026,305210,305310,305606,305804,306102,})}, get),
};
tb[1154] = {
	P({D[8015], 1154,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M9_up.png",S({200027,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1154,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M9_up.png",S({200027,305210,305310,305606,305804,306102,})}, get),
};
tb[1155] = {
	P({D[8015], 1155,false,false,false,false,false,"extendRes/treasurehead/treasure_pic210210_up.png",S({200028,200029,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1155,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic210210_up.png",S({200028,200029,305210,305310,305606,305804,306102,})}, get),
};
tb[1156] = {
	P({D[8015], 1156,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M10_up.png",S({200030,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1156,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M10_up.png",S({200030,305210,305310,305606,305804,306102,})}, get),
};
tb[1157] = {
	P({D[8015], 1157,false,false,false,false,false,"extendRes/treasurehead/treasure_pic210211_up.png",S({200032,200033,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1157,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic210211_up.png",S({200032,200033,305210,305310,305606,305804,306102,})}, get),
};