-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][chest_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local chest_up = require("Excels.Data.activity.chest_up")
local tb = chest_up.tb
local get = chest_up.get

tb[260120] = {
	P({D[11014], 260120,false,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200098,200099,305812,305542,305710,305614,})}, get),
	P({D[11014], 260120,1005,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200098,200099,305812,305542,305710,305614,})}, get),
};
tb[260121] = {
	P({D[11014], 260121,false,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200029,200093,305812,305542,305710,305614,})}, get),
	P({D[11014], 260121,1005,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200029,200093,305812,305542,305710,305614,})}, get),
};
tb[260122] = {
	P({D[11014], 260122,1006,5004,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200097,200023,305812,305542,305710,305614,})}, get),
	P({D[11014], 260122,1007,5004,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200097,200023,305812,305542,305710,305614,})}, get),
};
tb[260220] = {
	P({D[11014], 260220,1008,5024,"5102",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,1,S({20000119,30520012,30530012,30580027,30570017,})}, get),
	P({D[11014], 260220,1009,5024,"5102",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,1,S({20000119,30520012,30530012,30580027,30570017,})}, get),
};
tb[260221] = {
	P({D[11014], 260221,1012,5026,"5102",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,1,S({20000120,30520012,30530012,30580027,30570017,})}, get),
	P({D[11014], 260221,1013,5026,"5102",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,1,S({20000120,30520012,30530012,30580027,30570017,})}, get),
};
tb[260320] = {
	P({D[11014], 260320,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200009,200033,305203,305602,305801,305701,})}, get),
	P({D[11014], 260320,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200009,200033,305203,305602,305801,305701,})}, get),
};
tb[260321] = {
	P({D[11014], 260321,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200024,200094,305203,305602,305801,305701,})}, get),
	P({D[11014], 260321,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200024,200094,305203,305602,305801,305701,})}, get),
};
tb[260322] = {
	P({D[11014], 260322,1006,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200014,200031,305203,305602,305801,305701,})}, get),
	P({D[11014], 260322,1007,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200014,200031,305203,305602,305801,305701,})}, get),
};
tb[260420] = {
	P({260420,false,5013,"5106",5203,5207,"chest_0_dj","extendRes/treasurehead/yh_dj.png","extendRes/treasurehead/yh_dj2.png",3,"special","fx_ui_xm_2604_sakura_02","fx_ui_xm_2604_sakura_01",157,1,S({20000122,20000123,20000124,20000125,308052,308053,308054,308055,308057,})}, get),
	P({260420,1005,5013,"5106",5203,5207,"chest_0_dj","extendRes/treasurehead/yh_dj.png","extendRes/treasurehead/yh_dj2.png",3,"special","fx_ui_xm_2604_sakura_02","fx_ui_xm_2604_sakura_01",157,1,S({20000122,20000123,20000124,20000125,308052,308053,308054,308055,308057,})}, get),
};
tb[260421] = {
	P({260421,1006,5014,"5106",5203,5207,"chest_1_dj","extendRes/treasurehead/zl_dj.png","extendRes/treasurehead/zl_dj2.png",3,"special","fx_ui_xm_2604_bamboo_02","fx_ui_xm_2604_bamboo_01",157,1,S({20000122,20000123,20000124,20000125,308052,308053,308054,308055,308057,})}, get),
	P({260421,1007,5014,"5106",5203,5207,"chest_1_dj","extendRes/treasurehead/zl_dj.png","extendRes/treasurehead/zl_dj2.png",3,"special","fx_ui_xm_2604_bamboo_02","fx_ui_xm_2604_bamboo_01",157,1,S({20000122,20000123,20000124,20000125,308052,308053,308054,308055,308057,})}, get),
};
tb[260521] = {
	P({D[11014], 260521,false,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({20000106,200018,30560008,30580019,30570010,30610006,})}, get),
	P({D[11014], 260521,1005,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({20000106,200018,30560008,30580019,30570010,30610006,})}, get),
};
tb[260522] = {
	P({D[11014], 260522,1008,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200021,200059,30560008,30580019,30570010,30610006,})}, get),
	P({D[11014], 260522,1009,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200021,200059,30560008,30580019,30570010,30610006,})}, get),
};
tb[260523] = {
	P({D[11014], 260523,false,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({200066,200003,30560008,30580019,30570010,30610006,})}, get),
	P({D[11014], 260523,1005,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({200066,200003,30560008,30580019,30570010,30610006,})}, get),
};
tb[260524] = {
	P({D[11014], 260524,1008,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200069,200077,30560008,30580019,30570010,30610006,})}, get),
	P({D[11014], 260524,1009,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200069,200077,30560008,30580019,30570010,30610006,})}, get),
};
tb[260525] = {
	P({D[11014], 260525,1010,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200011,200092,30560008,30580019,30570010,30610006,})}, get),
	P({D[11014], 260525,1011,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200011,200092,30560008,30580019,30570010,30610006,})}, get),
};
tb[260620] = {
	P({260620,false,5013,"5106",5203,5206,"chest_0_dp","extendRes/treasurehead/yh_dp.png","extendRes/treasurehead/yh_dp2.png",3,"special","fx_ui_xm_2606_sakura_02","fx_ui_xm_2606_sakura_01",158,1,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
	P({260620,1005,5013,"5106",5203,5206,"chest_0_dp","extendRes/treasurehead/yh_dp.png","extendRes/treasurehead/yh_dp2.png",3,"special","fx_ui_xm_2606_sakura_02","fx_ui_xm_2606_sakura_01",158,1,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
};
tb[260621] = {
	P({260621,1006,5014,"5106",5203,5206,"chest_1_dp","extendRes/treasurehead/zl_dp.png","extendRes/treasurehead/zl_dp2.png",3,"special","fx_ui_xm_2606_bamboo_02","fx_ui_xm_2606_bamboo_01",158,1,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
	P({260621,1007,5014,"5106",5203,5206,"chest_1_dp","extendRes/treasurehead/zl_dp.png","extendRes/treasurehead/zl_dp2.png",3,"special","fx_ui_xm_2606_bamboo_02","fx_ui_xm_2606_bamboo_01",158,1,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
};
tb[260720] = {
	P({D[11014], 260720,false,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({20000117,200028,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260720,1005,5024,"5104",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,2,S({20000117,200028,305213,305313,305610,305705,305806,})}, get),
};
tb[260721] = {
	P({D[11014], 260721,1008,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200044,200009,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260721,1009,5026,"5104",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,2,S({200044,200009,305213,305313,305610,305705,305806,})}, get),
};
tb[260722] = {
	P({D[11014], 260722,1012,5028,"5104",5203,5206,false,"extendRes/treasurehead/yh3_lh.png",false,1,2,S({200008,200003,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260722,1013,5028,"5104",5203,5206,false,"extendRes/treasurehead/yh3_lh.png",false,1,2,S({200008,200003,305213,305313,305610,305705,305806,})}, get),
};
tb[260723] = {
	P({D[11014], 260723,1016,5030,"5104",5203,5206,false,"extendRes/treasurehead/yh4_lh.png",false,1,2,S({200066,200083,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260723,1017,5030,"5104",5203,5206,false,"extendRes/treasurehead/yh4_lh.png",false,1,2,S({200066,200083,305213,305313,305610,305705,305806,})}, get),
};
tb[260724] = {
	P({D[11014], 260724,1010,5025,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl1_lh.png",false,1,2,S({200031,200092,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260724,1011,5025,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl1_lh.png",false,1,2,S({200031,200092,305213,305313,305610,305705,305806,})}, get),
};
tb[260725] = {
	P({D[11014], 260725,1014,5027,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl2_lh.png",false,1,2,S({200011,200092,305213,305313,305610,305705,305806,})}, get),
	P({D[11014], 260725,1015,5027,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl2_lh.png",false,1,2,S({200011,200092,305213,305313,305610,305705,305806,})}, get),
};