-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][chest_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local chest_up = require("Excels.Data.activity.chest_up")
local tb = chest_up.tb
local get = chest_up.get

tb[1158] = {
	P({D[8015], 1158,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M11_up.png",S({200031,305210,305310,305606,305804,306102,})}, get),
	P({D[8015], 1158,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2102M11_up.png",S({200031,305210,305310,305606,305804,306102,})}, get),
};
tb[1169] = {
	P({D[8015], 1169,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21031_up.png",S({305211,305311,305607,200020,})}, get),
	P({D[8015], 1169,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21031_up.png",S({305211,305311,305607,200020,})}, get),
};
tb[1170] = {
	P({D[8015], 1170,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2103M1_up.png",S({305211,305311,305607,200013,})}, get),
	P({D[8015], 1170,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2103M1_up.png",S({305211,305311,305607,200013,})}, get),
};
tb[1171] = {
	P({D[8015], 1171,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21032_up.png",S({305211,305311,305607,200016,})}, get),
	P({D[8015], 1171,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21032_up.png",S({305211,305311,305607,200016,})}, get),
};
tb[1172] = {
	P({D[8015], 1172,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2103M2_up.png",S({305211,305311,305607,200027,})}, get),
	P({D[8015], 1172,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2103M2_up.png",S({305211,305311,305607,200027,})}, get),
};
tb[1180] = {
	P({D[2006], 1180,"extendRes/treasurehead/treasure_pic2104_up.jpg",false,false,3,false,false,false,false,false,S({200040,200041,200042,200043,308006,308007,308008,308009,308010,})}, get),
	P({D[11015], 1180,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic2104_up.jpg",false,false,3,S({200040,200041,200042,200043,308006,308007,308008,308009,308010,})}, get),
};
tb[1183] = {
	P({D[8015], 1183,false,false,false,false,false,"extendRes/treasurehead/treasure_pic2105_up.png",S({200044,305523,305608,305704,})}, get),
	P({D[8015], 1183,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic2105_up.png",S({200044,305523,305608,305704,})}, get),
};
tb[1184] = {
	P({D[8015], 1184,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2105M_up.png",S({200045,305523,305608,305704,})}, get),
	P({D[8015], 1184,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2105M_up.png",S({200045,305523,305608,305704,})}, get),
};
tb[1188] = {
	P({D[8015], 1188,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21052_up.png",S({200004,200019,305523,305608,305704,})}, get),
	P({D[8015], 1188,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21052_up.png",S({200004,200019,305523,305608,305704,})}, get),
};
tb[1189] = {
	P({D[8015], 1189,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2105M2_up.png",S({200030,200031,305523,305608,305704,})}, get),
	P({D[8015], 1189,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2105M2_up.png",S({200030,200031,305523,305608,305704,})}, get),
};
tb[1195] = {
	P({D[8015], 1195,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21061_up.png",S({200021,305201,305202,305301,305302,305601,})}, get),
	P({D[8015], 1195,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21061_up.png",S({200021,305201,305202,305301,305302,305601,})}, get),
};
tb[1196] = {
	P({D[8015], 1196,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2106M1_up.png",S({200012,305201,305202,305301,305302,305601,})}, get),
	P({D[8015], 1196,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2106M1_up.png",S({200012,305201,305202,305301,305302,305601,})}, get),
};
tb[1197] = {
	P({D[8015], 1197,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21062_up.png",S({200032,305201,305202,305301,305302,305601,})}, get),
	P({D[8015], 1197,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21062_up.png",S({200032,305201,305202,305301,305302,305601,})}, get),
};
tb[1198] = {
	P({D[8015], 1198,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2106M2_up.png",S({200022,305201,305202,305301,305302,305601,})}, get),
	P({D[8015], 1198,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2106M2_up.png",S({200022,305201,305202,305301,305302,305601,})}, get),
};
tb[1201] = {
	P({D[8015], 1201,false,false,false,false,false,"extendRes/treasurehead/treasure_pic2107_up.png",S({200046,305212,305312,305609,})}, get),
	P({D[8015], 1201,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic2107_up.png",S({200046,305212,305312,305609,})}, get),
};
tb[1202] = {
	P({D[8015], 1202,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2107M_up.png",S({200047,305212,305312,305609,})}, get),
	P({D[8015], 1202,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2107M_up.png",S({200047,305212,305312,305609,})}, get),
};
tb[1209] = {
	P({D[8015], 1209,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21081_up.png",S({200048,305213,305313,305610,305705,305806,})}, get),
	P({D[8015], 1209,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21081_up.png",S({200048,305213,305313,305610,305705,305806,})}, get),
};
tb[1210] = {
	P({D[8015], 1210,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2108M1_up.png",S({200049,305213,305313,305610,305705,305806,})}, get),
	P({D[8015], 1210,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2108M1_up.png",S({200049,305213,305313,305610,305705,305806,})}, get),
};
tb[1211] = {
	P({D[8015], 1211,1008,false,false,false,false,"extendRes/treasurehead/treasure_pic21082_up.png",S({200010,200017,305213,305313,305610,305705,305806,})}, get),
	P({D[8015], 1211,1009,false,false,false,false,"extendRes/treasurehead/treasure_pic21082_up.png",S({200010,200017,305213,305313,305610,305705,305806,})}, get),
};
tb[1212] = {
	P({D[8015], 1212,1010,false,false,false,false,"extendRes/treasurehead/treasure_pic2108M2_up.png",S({200014,200025,305213,305313,305610,305705,305806,})}, get),
	P({D[8015], 1212,1011,false,false,false,false,"extendRes/treasurehead/treasure_pic2108M2_up.png",S({200014,200025,305213,305313,305610,305705,305806,})}, get),
};
tb[1216] = {
	P({D[8015], 1216,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21092_up.png",S({200021,305204,305205,305304,305305,305603,})}, get),
	P({D[8015], 1216,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21092_up.png",S({200021,305204,305205,305304,305305,305603,})}, get),
};
tb[1217] = {
	P({D[8015], 1217,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2109M2_up.png",S({200045,305204,305205,305304,305305,305603,})}, get),
	P({D[8015], 1217,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2109M2_up.png",S({200045,305204,305205,305304,305305,305603,})}, get),
};
tb[1218] = {
	P({D[8015], 1218,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21091_up.png",S({200019,305204,305205,305304,305305,305603,})}, get),
	P({D[8015], 1218,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21091_up.png",S({200019,305204,305205,305304,305305,305603,})}, get),
};
tb[1219] = {
	P({D[8015], 1219,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2109M1_up.png",S({200023,305204,305205,305304,305305,305603,})}, get),
	P({D[8015], 1219,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2109M1_up.png",S({200023,305204,305205,305304,305305,305603,})}, get),
};
tb[1229] = {
	P({D[2006], 1229,"extendRes/treasurehead/treasure_pic2110_up.jpg",false,false,4,false,false,false,false,false,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
	P({D[11015], 1229,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic2110_up.jpg",false,false,4,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
};
tb[1230] = {
	P({D[11015], 1230,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2110M_up.jpg",false,false,4,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
	P({D[11015], 1230,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2110M_up.jpg",false,false,4,S({200050,200051,308011,308012,308013,308014,308015,})}, get),
};
tb[1236] = {
	P({D[8015], 1236,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21111_up.png",S({200003,305206,305207,305306,305307,})}, get),
	P({D[8015], 1236,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21111_up.png",S({200003,305206,305207,305306,305307,})}, get),
};
tb[1237] = {
	P({D[8015], 1237,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2111M1_up.png",S({200030,305206,305207,305306,305307,})}, get),
	P({D[8015], 1237,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2111M1_up.png",S({200030,305206,305207,305306,305307,})}, get),
};
tb[1238] = {
	P({D[8015], 1238,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21112_up.png",S({200009,200007,305206,305207,305306,305307,})}, get),
	P({D[8015], 1238,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21112_up.png",S({200009,200007,305206,305207,305306,305307,})}, get),
};
tb[1239] = {
	P({D[8015], 1239,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2111M2_up.png",S({200014,200012,305206,305207,305306,305307,})}, get),
	P({D[8015], 1239,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2111M2_up.png",S({200014,200012,305206,305207,305306,305307,})}, get),
};
tb[1249] = {
	P({D[11015], 1249,1008,false,false,false,false,"extendRes/treasurehead/treasure_pic2112SP_up.jpg",false,false,5,S({200052,305216,305316,305706,305807,})}, get),
	P({D[11015], 1249,1009,false,false,false,false,"extendRes/treasurehead/treasure_pic2112SP_up.jpg",false,false,5,S({200052,305216,305316,305706,305807,})}, get),
};
tb[1250] = {
	P({D[8015], 1250,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21121_up.png",S({200044,200024,305216,305316,305706,305807,})}, get),
	P({D[8015], 1250,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21121_up.png",S({200044,200024,305216,305316,305706,305807,})}, get),
};
tb[1251] = {
	P({D[8015], 1251,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21122_up.png",S({200044,200029,305216,305316,305706,305807,})}, get),
	P({D[8015], 1251,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21122_up.png",S({200044,200029,305216,305316,305706,305807,})}, get),
};
tb[1252] = {
	P({D[8015], 1252,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21123_up.png",S({200006,200008,305216,305316,305706,305807,})}, get),
	P({D[8015], 1252,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21123_up.png",S({200006,200008,305216,305316,305706,305807,})}, get),
};
tb[1253] = {
	P({D[8015], 1253,false,false,false,false,false,"extendRes/treasurehead/treasure_pic21124_up.png",S({200006,200028,305216,305316,305706,305807,})}, get),
	P({D[8015], 1253,1005,false,false,false,false,"extendRes/treasurehead/treasure_pic21124_up.png",S({200006,200028,305216,305316,305706,305807,})}, get),
};
tb[1254] = {
	P({D[8015], 1254,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2112M1_up.png",S({200031,200047,305216,305316,305706,305807,})}, get),
	P({D[8015], 1254,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2112M1_up.png",S({200031,200047,305216,305316,305706,305807,})}, get),
};
tb[1255] = {
	P({D[8015], 1255,1006,false,false,false,false,"extendRes/treasurehead/treasure_pic2112M2_up.png",S({200011,200022,305216,305316,305706,305807,})}, get),
	P({D[8015], 1255,1007,false,false,false,false,"extendRes/treasurehead/treasure_pic2112M2_up.png",S({200011,200022,305216,305316,305706,305807,})}, get),
};
tb[1264] = {
	P({D[8015], 1264,false,false,false,false,false,"extendRes/treasurehead/220101.png",S({200053,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1264,1005,false,false,false,false,"extendRes/treasurehead/220101.png",S({200053,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1265] = {
	P({D[8015], 1265,1006,false,false,false,false,"extendRes/treasurehead/2201M01.png",S({200054,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1265,1007,false,false,false,false,"extendRes/treasurehead/2201M01.png",S({200054,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1266] = {
	P({D[8015], 1266,false,false,false,false,false,"extendRes/treasurehead/220102.png",S({200029,200026,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1266,1005,false,false,false,false,"extendRes/treasurehead/220102.png",S({200029,200026,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1267] = {
	P({D[8015], 1267,1006,false,false,false,false,"extendRes/treasurehead/2201M02.png",S({200012,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1267,1007,false,false,false,false,"extendRes/treasurehead/2201M02.png",S({200012,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1268] = {
	P({D[8015], 1268,false,false,false,false,false,"extendRes/treasurehead/220103.png",S({200005,200032,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1268,1005,false,false,false,false,"extendRes/treasurehead/220103.png",S({200005,200032,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1269] = {
	P({D[8015], 1269,1006,false,false,false,false,"extendRes/treasurehead/2201M03.png",S({200045,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1269,1007,false,false,false,false,"extendRes/treasurehead/2201M03.png",S({200045,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1270] = {
	P({D[8015], 1270,false,false,false,false,false,"extendRes/treasurehead/220104.png",S({200007,200019,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1270,1005,false,false,false,false,"extendRes/treasurehead/220104.png",S({200007,200019,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1271] = {
	P({D[8015], 1271,1006,false,false,false,false,"extendRes/treasurehead/2201M04.png",S({200014,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1271,1007,false,false,false,false,"extendRes/treasurehead/2201M04.png",S({200014,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1272] = {
	P({D[8015], 1272,false,false,false,false,false,"extendRes/treasurehead/220105.png",S({200007,200006,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1272,1005,false,false,false,false,"extendRes/treasurehead/220105.png",S({200007,200006,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1273] = {
	P({D[8015], 1273,1006,false,false,false,false,"extendRes/treasurehead/2201M05.png",S({200047,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1273,1007,false,false,false,false,"extendRes/treasurehead/2201M05.png",S({200047,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1274] = {
	P({D[8015], 1274,false,false,false,false,false,"extendRes/treasurehead/220106.png",S({200010,200016,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1274,1005,false,false,false,false,"extendRes/treasurehead/220106.png",S({200010,200016,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1275] = {
	P({D[8015], 1275,1006,false,false,false,false,"extendRes/treasurehead/2201M06.png",S({200013,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1275,1007,false,false,false,false,"extendRes/treasurehead/2201M06.png",S({200013,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1276] = {
	P({D[8015], 1276,false,false,false,false,false,"extendRes/treasurehead/220107.png",S({200010,200003,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1276,1005,false,false,false,false,"extendRes/treasurehead/220107.png",S({200010,200003,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1277] = {
	P({D[8015], 1277,1006,false,false,false,false,"extendRes/treasurehead/2201M07.png",S({200011,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1277,1007,false,false,false,false,"extendRes/treasurehead/2201M07.png",S({200011,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1278] = {
	P({D[8015], 1278,false,false,false,false,false,"extendRes/treasurehead/220108.png",S({200004,200048,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1278,1005,false,false,false,false,"extendRes/treasurehead/220108.png",S({200004,200048,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1279] = {
	P({D[8015], 1279,1006,false,false,false,false,"extendRes/treasurehead/2201M08.png",S({200022,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1279,1007,false,false,false,false,"extendRes/treasurehead/2201M08.png",S({200022,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1280] = {
	P({D[8015], 1280,false,false,false,false,false,"extendRes/treasurehead/220109.png",S({200004,200020,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1280,1005,false,false,false,false,"extendRes/treasurehead/220109.png",S({200004,200020,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1281] = {
	P({D[8015], 1281,1006,false,false,false,false,"extendRes/treasurehead/2201M09.png",S({200023,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1281,1007,false,false,false,false,"extendRes/treasurehead/2201M09.png",S({200023,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1282] = {
	P({D[8015], 1282,false,false,false,false,false,"extendRes/treasurehead/220110.png",S({200021,200018,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1282,1005,false,false,false,false,"extendRes/treasurehead/220110.png",S({200021,200018,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1283] = {
	P({D[8015], 1283,1006,false,false,false,false,"extendRes/treasurehead/2201M10.png",S({200025,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1283,1007,false,false,false,false,"extendRes/treasurehead/2201M10.png",S({200025,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1284] = {
	P({D[8015], 1284,false,false,false,false,false,"extendRes/treasurehead/220111.png",S({200021,200044,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1284,1005,false,false,false,false,"extendRes/treasurehead/220111.png",S({200021,200044,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1285] = {
	P({D[8015], 1285,1006,false,false,false,false,"extendRes/treasurehead/2201M11.png",S({200027,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1285,1007,false,false,false,false,"extendRes/treasurehead/2201M11.png",S({200027,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1286] = {
	P({D[8015], 1286,false,false,false,false,false,"extendRes/treasurehead/220112.png",S({200017,200009,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1286,1005,false,false,false,false,"extendRes/treasurehead/220112.png",S({200017,200009,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1287] = {
	P({D[8015], 1287,1006,false,false,false,false,"extendRes/treasurehead/2201M12.png",S({200030,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1287,1007,false,false,false,false,"extendRes/treasurehead/2201M12.png",S({200030,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1288] = {
	P({D[8015], 1288,false,false,false,false,false,"extendRes/treasurehead/220113.png",S({200008,200033,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1288,1005,false,false,false,false,"extendRes/treasurehead/220113.png",S({200008,200033,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1289] = {
	P({D[8015], 1289,1006,false,false,false,false,"extendRes/treasurehead/2201M13.png",S({200031,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1289,1007,false,false,false,false,"extendRes/treasurehead/2201M13.png",S({200031,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1290] = {
	P({D[8015], 1290,false,false,false,false,false,"extendRes/treasurehead/220114.png",S({200024,200028,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1290,1005,false,false,false,false,"extendRes/treasurehead/220114.png",S({200024,200028,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1291] = {
	P({D[8015], 1291,1006,false,false,false,false,"extendRes/treasurehead/2201M14.png",S({200039,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1291,1007,false,false,false,false,"extendRes/treasurehead/2201M14.png",S({200039,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1292] = {
	P({D[8015], 1292,false,false,false,false,false,"extendRes/treasurehead/220115.png",S({200046,200038,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1292,1005,false,false,false,false,"extendRes/treasurehead/220115.png",S({200046,200038,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1293] = {
	P({D[8015], 1293,1006,false,false,false,false,"extendRes/treasurehead/2201M15.png",S({200049,305217,305317,305611,305707,305808,309500,})}, get),
	P({D[8015], 1293,1007,false,false,false,false,"extendRes/treasurehead/2201M15.png",S({200049,305217,305317,305611,305707,305808,309500,})}, get),
};
tb[1302] = {
	P({D[8015], 1302,false,false,false,false,false,"extendRes/treasurehead/22021.png",S({200007,200024,305605,305209,305309,})}, get),
	P({D[8015], 1302,1005,false,false,false,false,"extendRes/treasurehead/22021.png",S({200007,200024,305605,305209,305309,})}, get),
};
tb[1303] = {
	P({D[8015], 1303,1006,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200039,200049,305605,305209,305309,})}, get),
	P({D[8015], 1303,1007,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200039,200049,305605,305209,305309,})}, get),
};
tb[100000] = {
	P({D[9015], 100000,1000,5001,"5101",2586,2588,false,"extendRes/treasurehead/yh_cz.png",S({})}, get),
	P({D[9015], 100000,1001,5001,"5101",2586,2588,false,"extendRes/treasurehead/yh_cz.png",S({})}, get),
};
tb[100001] = {
	P({D[9015], 100001,1002,5002,"5107",2586,2588,"chest_1","extendRes/treasurehead/zl_cz.png",S({})}, get),
	P({D[9015], 100001,1003,5002,"5107",2586,2588,"chest_1","extendRes/treasurehead/zl_cz.png",S({})}, get),
};
tb[100100] = {
	P({D[9015], 100100,8000,5001,"5101",2586,2588,false,"extendRes/treasurehead/yh_cz.png",S({})}, get),
	P({D[9015], 100100,8001,5001,"5101",2586,2588,false,"extendRes/treasurehead/yh_cz.png",S({})}, get),
};
tb[100101] = {
	P({D[9015], 100101,8002,5002,"5107",2586,2588,"chest_1","extendRes/treasurehead/zl_cz.png",S({})}, get),
	P({D[9015], 100101,8003,5002,"5107",2586,2588,"chest_1","extendRes/treasurehead/zl_cz.png",S({})}, get),
};
tb[220301] = {
	P({D[8015], 220301,false,false,false,false,false,"extendRes/treasurehead/22021.png",S({200038,200020,305211,305311,305607,})}, get),
	P({D[8015], 220301,1005,false,false,false,false,"extendRes/treasurehead/22021.png",S({200038,200020,305211,305311,305607,})}, get),
};
tb[220302] = {
	P({D[8015], 220302,1006,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200054,200013,305211,305311,305607,})}, get),
	P({D[8015], 220302,1007,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200054,200013,305211,305311,305607,})}, get),
};
tb[220303] = {
	P({D[8015], 220303,false,false,false,false,false,"extendRes/treasurehead/22021.png",S({200038,200016,305211,305311,305607,})}, get),
	P({D[8015], 220303,1005,false,false,false,false,"extendRes/treasurehead/22021.png",S({200038,200016,305211,305311,305607,})}, get),
};
tb[220304] = {
	P({D[8015], 220304,1006,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200054,200027,305211,305311,305607,})}, get),
	P({D[8015], 220304,1007,false,false,false,false,"extendRes/treasurehead/2202M1.png",S({200054,200027,305211,305311,305607,})}, get),
};
tb[220408] = {
	P({D[2006], 220408,"extendRes/treasurehead/2204.jpg",false,false,4,false,false,false,false,false,S({200055,200056,200057,200058,308016,308017,308018,308019,308020,})}, get),
	P({D[11015], 220408,1005,false,false,false,false,"extendRes/treasurehead/2204.jpg",false,false,4,S({200055,200056,200057,200058,308016,308017,308018,308019,308020,})}, get),
};
tb[220411] = {
	P({D[11015], 220411,1006,false,false,false,false,"extendRes/treasurehead/2204M.jpg",false,false,4,S({200055,200056,200057,200058,308016,308017,308018,308019,308020,})}, get),
	P({D[11015], 220411,1007,false,false,false,false,"extendRes/treasurehead/2204M.jpg",false,false,4,S({200055,200056,200057,200058,308016,308017,308018,308019,308020,})}, get),
};
tb[220502] = {
	P({D[8015], 220502,false,false,false,false,false,"extendRes/treasurehead/22051.png",S({200026,200019,305523,305608,305704,})}, get),
	P({D[8015], 220502,1005,false,false,false,false,"extendRes/treasurehead/22051.png",S({200026,200019,305523,305608,305704,})}, get),
};