-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][chest_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local chest_up = require("Excels.Data.activity.chest_up")
local tb = chest_up.tb
local get = chest_up.get

tb[240511] = {
	P({D[11014], 240511,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200046,200066,305222,305322,305620,306103,})}, get),
	P({D[11014], 240511,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200046,200066,305222,305322,305620,306103,})}, get),
};
tb[240512] = {
	P({D[11014], 240512,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200084,200017,305222,305322,305620,306103,})}, get),
	P({D[11014], 240512,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200084,200017,305222,305322,305620,306103,})}, get),
};
tb[240513] = {
	P({D[11014], 240513,1006,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200039,200013,305222,305322,305620,306103,})}, get),
	P({D[11014], 240513,1007,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200039,200013,305222,305322,305620,306103,})}, get),
};
tb[240620] = {
	P({D[11014], 240620,false,5024,"5102",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,1,S({200093,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240620,1005,5024,"5102",5203,5206,false,"extendRes/treasurehead/yh1_lh.png",false,1,1,S({200093,30520004,30530004,30580006,30505002,})}, get),
};
tb[240621] = {
	P({D[11014], 240621,1008,5026,"5102",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,1,S({200094,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240621,1009,5026,"5102",5203,5206,false,"extendRes/treasurehead/yh2_lh.png",false,1,1,S({200094,30520004,30530004,30580006,30505002,})}, get),
};
tb[240622] = {
	P({D[11014], 240622,1012,5007,"5103",5203,5206,false,"extendRes/treasurehead/yh_x.png",false,1,1,S({200008,200024,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240622,1013,5007,"5103",5203,5206,false,"extendRes/treasurehead/yh_x.png",false,1,1,S({200008,200024,30520004,30530004,30580006,30505002,})}, get),
};
tb[240623] = {
	P({D[11014], 240623,1012,5007,"5103",5203,5206,false,"extendRes/treasurehead/yh_x.png",false,1,1,S({200032,200007,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240623,1013,5007,"5103",5203,5206,false,"extendRes/treasurehead/yh_x.png",false,1,1,S({200032,200007,30520004,30530004,30580006,30505002,})}, get),
};
tb[240624] = {
	P({D[11014], 240624,1014,5008,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_x.png",false,1,1,S({200039,200011,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240624,1015,5008,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_x.png",false,1,1,S({200039,200011,30520004,30530004,30580006,30505002,})}, get),
};
tb[240625] = {
	P({D[11014], 240625,1014,5008,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_x.png",false,1,1,S({200023,200022,30520004,30530004,30580006,30505002,})}, get),
	P({D[11014], 240625,1015,5008,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_x.png",false,1,1,S({200023,200022,30520004,30530004,30580006,30505002,})}, get),
};
tb[240720] = {
	P({D[11014], 240720,false,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200020,200019,305622,305814,305054,305716,305552,})}, get),
	P({D[11014], 240720,1005,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200020,200019,305622,305814,305054,305716,305552,})}, get),
};
tb[240721] = {
	P({D[11014], 240721,false,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200006,200059,305622,305814,305054,305716,305552,})}, get),
	P({D[11014], 240721,1005,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200006,200059,305622,305814,305054,305716,305552,})}, get),
};
tb[240722] = {
	P({D[11014], 240722,false,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200044,200024,305622,305814,305054,305716,305552,})}, get),
	P({D[11014], 240722,1005,5003,"5104",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,2,S({200044,200024,305622,305814,305054,305716,305552,})}, get),
};
tb[240723] = {
	P({D[11014], 240723,1006,5004,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200090,200085,305622,305814,305054,305716,305552,})}, get),
	P({D[11014], 240723,1007,5004,"5104",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,2,S({200090,200085,305622,305814,305054,305716,305552,})}, get),
};
tb[240830] = {
	P({240830,false,5022,"5108",5204,5206,"chest_0_nfh","extendRes/treasurehead/yh_nfh.png",false,2,"left","fx_ui_xunmi_nfh_002","fx_ui_xunmi_nfh_001",147,1,S({200095,30610003,30505003,30530005,30520005,30560003,})}, get),
	P({240830,1005,5022,"5108",5204,5206,"chest_0_nfh","extendRes/treasurehead/yh_nfh.png",false,2,"left","fx_ui_xunmi_nfh_002","fx_ui_xunmi_nfh_001",147,1,S({200095,30610003,30505003,30530005,30520005,30560003,})}, get),
};
tb[240831] = {
	P({D[11014], 240831,1008,5003,"5103",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200033,200059,30610003,30505003,30530005,30520005,30560003,})}, get),
	P({D[11014], 240831,1009,5003,"5103",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200033,200059,30610003,30505003,30530005,30520005,30560003,})}, get),
};
tb[240832] = {
	P({D[11014], 240832,1008,5003,"5103",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200038,200003,30610003,30505003,30530005,30520005,30560003,})}, get),
	P({D[11014], 240832,1009,5003,"5103",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200038,200003,30610003,30505003,30530005,30520005,30560003,})}, get),
};
tb[240833] = {
	P({D[11014], 240833,1010,5004,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200075,200031,30610003,30505003,30530005,30520005,30560003,})}, get),
	P({D[11014], 240833,1011,5004,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200075,200031,30610003,30505003,30530005,30520005,30560003,})}, get),
};
tb[240834] = {
	P({D[11014], 240834,1010,5004,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200012,200014,30610003,30505003,30530005,30520005,30560003,})}, get),
	P({D[11014], 240834,1011,5004,"5103",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200012,200014,30610003,30505003,30530005,30520005,30560003,})}, get),
};
tb[240920] = {
	P({D[11014], 240920,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,3,S({200005,200007,305039,305037,305041,305011,305046,})}, get),
	P({D[11014], 240920,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,3,S({200005,200007,305039,305037,305041,305011,305046,})}, get),
};
tb[240921] = {
	P({D[11014], 240921,false,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,3,S({200009,200038,305039,305037,305041,305011,305046,})}, get),
	P({D[11014], 240921,1005,5003,"5104",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,3,S({200009,200038,305039,305037,305041,305011,305046,})}, get),
};
tb[240922] = {
	P({D[11014], 240922,1006,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,3,S({200030,200049,305039,305037,305041,305011,305046,})}, get),
	P({D[11014], 240922,1007,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,3,S({200030,200049,305039,305037,305041,305011,305046,})}, get),
};
tb[240923] = {
	P({D[11014], 240923,1006,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,3,S({200054,200060,305039,305037,305041,305011,305046,})}, get),
	P({D[11014], 240923,1007,5004,"5104",5203,5206,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,3,S({200054,200060,305039,305037,305041,305011,305046,})}, get),
};
tb[241020] = {
	P({D[11014], 241020,false,5003,"5102",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200091,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241020,1005,5003,"5102",5203,5207,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({200091,30505004,30550017,30570006,30580009,})}, get),
};
tb[241021] = {
	P({D[11014], 241021,1006,5004,"5102",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200092,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241021,1007,5004,"5102",5203,5207,"chest_1","extendRes/treasurehead/zl_lh.png",false,1,1,S({200092,30505004,30550017,30570006,30580009,})}, get),
};
tb[241022] = {
	P({D[11014], 241022,1008,5009,"5103",5203,5207,false,"extendRes/treasurehead/yh_q.png",false,1,1,S({200048,200074,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241022,1009,5009,"5103",5203,5207,false,"extendRes/treasurehead/yh_q.png",false,1,1,S({200048,200074,30505004,30550017,30570006,30580009,})}, get),
};
tb[241023] = {
	P({D[11014], 241023,1008,5009,"5103",5203,5207,false,"extendRes/treasurehead/yh_q.png",false,1,1,S({200032,200004,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241023,1009,5009,"5103",5203,5207,false,"extendRes/treasurehead/yh_q.png",false,1,1,S({200032,200004,30505004,30550017,30570006,30580009,})}, get),
};
tb[241024] = {
	P({D[11014], 241024,1010,5010,"5103",5203,5207,"chest_1","extendRes/treasurehead/zl_q.png",false,1,1,S({200045,200013,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241024,1011,5010,"5103",5203,5207,"chest_1","extendRes/treasurehead/zl_q.png",false,1,1,S({200045,200013,30505004,30550017,30570006,30580009,})}, get),
};
tb[241025] = {
	P({D[11014], 241025,1010,5010,"5103",5203,5207,"chest_1","extendRes/treasurehead/zl_q.png",false,1,1,S({200047,200025,30505004,30550017,30570006,30580009,})}, get),
	P({D[11014], 241025,1011,5010,"5103",5203,5207,"chest_1","extendRes/treasurehead/zl_q.png",false,1,1,S({200047,200025,30505004,30550017,30570006,30580009,})}, get),
};
tb[241121] = {
	P({241121,false,5013,"5106",5203,5206,"chest_0_imas","extendRes/treasurehead/yh_imas.png","extendRes/treasurehead/yh_imas2.png",3,false,"fx_ui_xunmi_imas_002","fx_ui_xunmi_imas_pink_001",false,1,S({20000100,20000101,20000102,20000103,30520007,30530007,30560005,30570007,30580011,})}, get),
	P({241121,1005,5013,"5106",5203,5206,"chest_0_imas","extendRes/treasurehead/yh_imas.png","extendRes/treasurehead/yh_imas2.png",3,false,"fx_ui_xunmi_imas_002","fx_ui_xunmi_imas_pink_001",false,1,S({20000100,20000101,20000102,20000103,30520007,30530007,30560005,30570007,30580011,})}, get),
};
tb[241122] = {
	P({241122,1006,5014,"5106",5203,5206,"chest_1_imas","extendRes/treasurehead/zl_imas.png","extendRes/treasurehead/zl_imas2.png",3,false,"fx_ui_xunmi_imas_002","fx_ui_xunmi_imas_cyan_001",false,1,S({20000100,20000101,20000102,20000103,30520007,30530007,30560005,30570007,30580011,})}, get),
	P({241122,1007,5014,"5106",5203,5206,"chest_1_imas","extendRes/treasurehead/zl_imas.png","extendRes/treasurehead/zl_imas2.png",3,false,"fx_ui_xunmi_imas_002","fx_ui_xunmi_imas_cyan_001",false,1,S({20000100,20000101,20000102,20000103,30520007,30530007,30560005,30570007,30580011,})}, get),
};
tb[241220] = {
	P({D[11014], 241220,false,5003,"5102",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({20000107,30520008,30530008,30580012,30570008,})}, get),
	P({D[11014], 241220,1005,5003,"5102",5203,5206,false,"extendRes/treasurehead/yh_lh.png",false,1,1,S({20000107,30520008,30530008,30580012,30570008,})}, get),
};