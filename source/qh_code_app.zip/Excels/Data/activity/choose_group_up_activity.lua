-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][choose_group_up_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["group_id"] = 2; ["base_chest_id"] = 3; ["choose_type"] = 1004; ["type"] = 5; ["sort"] = 6; ["title_str_id"] = 7; ["str_id"] = 1008; ["chara_str_id"] = 9; ["item_str_id"] = 10; ["img"] = 1011; ["title_img"] = 1012; ["title_img_2"] = 1013; ["typeset"] = 14; ["enter_animation"] = 1015; ["special_effect_front"] = 1016; ["special_effect_back"] = 1017; ["special_audio"] = 18; ["up_items_type"] = 19; ["up_items"] = 20;};

local df = {  nil, nil, nil, "chara", nil, nil, nil, "5113", 5203, 5206, nil, nil, nil, 5, nil, nil, nil, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local choose_group_up_activity = { }
choose_group_up_activity[260224] = P({D[13019], 260224,2001,S({1016,1017,}),false,1,5,5034,false,false,false,"chest_0","extendRes/treasurehead/xczx_yh.png",S({30520012,30530012,30580027,30570017,})}, get);
choose_group_up_activity[260225] = P({D[13019], 260225,2002,S({1018,1019,}),false,2,4,5035,false,false,false,"chest_1","extendRes/treasurehead/xczx_zl.png",S({30520012,30530012,30580027,30570017,})}, get);
return { tb = choose_group_up_activity };