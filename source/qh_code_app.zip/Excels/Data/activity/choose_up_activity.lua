-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][choose_up_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["replace_id"] = 2; ["base_chest_id"] = 3; ["ban_list"] = 4; ["choose_type"] = 1005; ["sort"] = 6; ["title_str_id"] = 7; ["str_id"] = 1008; ["chara_str_id"] = 9; ["item_str_id"] = 10; ["img"] = 1011; ["title_img"] = 1012; ["title_img_2"] = 1013; ["typeset"] = 14; ["enter_animation"] = 1015; ["special_effect_front"] = 1016; ["special_effect_back"] = 1017; ["special_audio"] = 18; ["up_items_type"] = 19; ["up_items"] = 20;};

local df = {  nil, nil, 1004, nil, "chara", 100, 5018, "5110", 5203, nil, "chest_2", "extendRes/treasurehead/zx.png", nil, 4, nil, nil, nil, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local choose_up_activity = { }
choose_up_activity[250125] = P({D[11019], 250125,1001,S({1004,1005,1006,1007,}),S({}),false,false,false,false,false,5207,S({30580015,30570009,30560007,30505005,30550022,})}, get);
choose_up_activity[260215] = P({D[11019], 260215,1002,S({1004,1005,1006,1007,}),S({20000119,20000120,}),false,false,false,false,false,5206,S({30520012,30530012,30580027,30570017,})}, get);
return { tb = choose_up_activity };