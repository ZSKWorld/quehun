-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][choose_up_replace]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["chest_id"] = 2;};

local df = {  1001, 1004,};

local get = function(item, k) return G(item, k, n2i, df); end;


local choose_up_replace = { }
choose_up_replace[1001] = {
	P({false,S({1004,1005,})}, get),
	P({false,S({1006,1007,})}, get),
};
choose_up_replace[1002] = {
	P({1002,S({1004,1005,})}, get),
	P({1002,S({1006,1007,})}, get),
};
return { tb = choose_up_replace };