-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][combining_activity_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["craft_bin"] = 2; ["craft_bin_price"] = 1003; ["craft_bin_unlock"] = 4; ["point_item"] = 5; ["bonus_daily_limit"] = 6; ["multi_order_rate"] = 7; ["one_coin_num"] = 8; ["coin_num_max"] = 9;};

local df = {  nil, nil, "30900005-10", nil, nil, 10, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local combining_activity_info = { }
combining_activity_info[231201] = P({231201,S({23120101,23120102,}),S({"30900005-10","30900005-10",}),S({0,300,}),30900006,false,0,0,0}, get);
combining_activity_info[250601] = P({250601,S({25060101,25060102,}),S({"30900090-10","30900090-10",}),S({0,300,}),30900091,false,120,5,20}, get);
return { tb = combining_activity_info };