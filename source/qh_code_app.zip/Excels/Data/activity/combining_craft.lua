-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][combining_craft]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["group"] = 3; ["recycling_price"] = 1004; ["level"] = 5; ["upgrade_craft_id"] = 6; ["order_price"] = 1007; ["if_bonus"] = 8; ["img_name"] = 1009; ["craft_name"] = 10; ["craft_desc"] = 11;};

local df = {  nil, 231201, 1, "30900005-8", 1, nil, nil, nil, "e1.png", nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local combining_craft = { }
combining_craft[1001] = P({D[2005], 1001,1002,false,false,"a1.png"}, get);
combining_craft[1002] = P({D[2003], 1002,"30900005-16",2,1003,"30900006-20",false,"a2.png"}, get);
combining_craft[1003] = P({D[2003], 1003,"30900005-32",3,1004,"30900006-60",false,"a3.png"}, get);
combining_craft[1004] = P({D[2003], 1004,"30900005-64",4,1005,"30900006-160",false,"a4.png"}, get);
combining_craft[1005] = P({D[2003], 1005,"30900005-128",5,false,"30900006-380",false,"a5.png"}, get);
combining_craft[2001] = P({D[4005], 2001,false,2,2002,false,false,"b1.png"}, get);
combining_craft[2002] = P({2002,false,2,"30900005-16",2,2003,"30900006-20",false,"b2.png"}, get);
combining_craft[2003] = P({2003,false,2,"30900005-32",3,2004,"30900006-60",false,"b3.png"}, get);
combining_craft[2004] = P({2004,false,2,"30900005-64",4,2005,"30900006-160",false,"b4.png"}, get);
combining_craft[2005] = P({2005,false,2,"30900005-128",5,false,"30900006-380",false,"b5.png"}, get);
combining_craft[3001] = P({D[4005], 3001,false,3,3002,false,false,"c1.png"}, get);
combining_craft[3002] = P({3002,false,3,"30900005-16",2,3003,"30900006-20",false,"c2.png"}, get);
combining_craft[3003] = P({3003,false,3,"30900005-32",3,3004,"30900006-60",false,"c3.png"}, get);
combining_craft[3004] = P({3004,false,3,"30900005-64",4,3005,"30900006-160",false,"c4.png"}, get);
combining_craft[3005] = P({3005,false,3,"30900005-128",5,false,"30900006-380",false,"c5.png"}, get);
combining_craft[4001] = P({D[4005], 4001,false,4,4002,false,false,"d1.png"}, get);
combining_craft[4002] = P({4002,false,4,"30900005-16",2,4003,"30900006-20",false,"d2.png"}, get);
combining_craft[4003] = P({4003,false,4,"30900005-32",3,4004,"30900006-60",false,"d3.png"}, get);
combining_craft[4004] = P({4004,false,4,"30900005-64",4,4005,"30900006-160",false,"d4.png"}, get);
combining_craft[4005] = P({4005,false,4,"30900005-128",5,false,"30900006-380",false,"d5.png"}, get);
combining_craft[5001] = P({5001,false,5,"30900006-20",false,5002,false,1}, get);
combining_craft[5002] = P({5002,false,5,"30900006-70",2,5003,false,1,"e2.png"}, get);
combining_craft[5003] = P({D[6007], 5003,false,5,"30900006-200",3,1,"e3.png"}, get);
combining_craft[11001] = P({D[7008], 11001,250601,false,"30900090-8",false,11002,"2506_a1.png",25060101,25060201}, get);
combining_craft[11002] = P({11002,250601,false,"30900090-16",2,11003,"30900091-20",false,"2506_a2.png",25060102,25060202}, get);
combining_craft[11003] = P({11003,250601,false,"30900090-32",3,11004,"30900091-60",false,"2506_a3.png",25060103,25060203}, get);
combining_craft[11004] = P({11004,250601,false,"30900090-64",4,11005,"30900091-160",false,"2506_a4.png",25060104,25060204}, get);
combining_craft[11005] = P({11005,250601,false,"30900090-128",5,false,"30900091-380",false,"2506_a5.png",25060105,25060205}, get);
combining_craft[12001] = P({D[7008], 12001,250601,2,"30900090-8",false,12002,"2506_b1.png",25060106,25060206}, get);
combining_craft[12002] = P({12002,250601,2,"30900090-16",2,12003,"30900091-20",false,"2506_b2.png",25060107,25060207}, get);
combining_craft[12003] = P({12003,250601,2,"30900090-32",3,12004,"30900091-60",false,"2506_b3.png",25060108,25060208}, get);
combining_craft[12004] = P({12004,250601,2,"30900090-64",4,12005,"30900091-160",false,"2506_b4.png",25060109,25060209}, get);
combining_craft[12005] = P({12005,250601,2,"30900090-128",5,false,"30900091-380",false,"2506_b5.png",25060110,25060210}, get);
combining_craft[13001] = P({D[7008], 13001,250601,3,"30900090-8",false,13002,"2506_c1.png",25060111,25060211}, get);
combining_craft[13002] = P({13002,250601,3,"30900090-16",2,13003,"30900091-20",false,"2506_c2.png",25060112,25060212}, get);
combining_craft[13003] = P({13003,250601,3,"30900090-32",3,13004,"30900091-60",false,"2506_c3.png",25060113,25060213}, get);
combining_craft[13004] = P({13004,250601,3,"30900090-64",4,13005,"30900091-160",false,"2506_c4.png",25060114,25060214}, get);
combining_craft[13005] = P({13005,250601,3,"30900090-128",5,false,"30900091-380",false,"2506_c5.png",25060115,25060215}, get);
combining_craft[14001] = P({D[7008], 14001,250601,4,"30900090-8",false,14002,"2506_d1.png",25060116,25060216}, get);
combining_craft[14002] = P({14002,250601,4,"30900090-16",2,14003,"30900091-20",false,"2506_d2.png",25060117,25060217}, get);
combining_craft[14003] = P({14003,250601,4,"30900090-32",3,14004,"30900091-60",false,"2506_d3.png",25060118,25060218}, get);
combining_craft[14004] = P({14004,250601,4,"30900090-64",4,14005,"30900091-160",false,"2506_d4.png",25060119,25060219}, get);
combining_craft[14005] = P({14005,250601,4,"30900090-128",5,false,"30900091-380",false,"2506_d5.png",25060120,25060220}, get);
combining_craft[15001] = P({15001,250601,5,"30900091-20",false,15002,false,1,false,25060121,25060221}, get);
combining_craft[15002] = P({15002,250601,5,"30900091-70",2,15003,false,1,"e2.png",25060122,25060222}, get);
combining_craft[15003] = P({D[6007], 15003,250601,5,"30900091-200",3,1,"e3.png",25060123,25060223}, get);
return { tb = combining_craft };