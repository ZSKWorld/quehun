-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][combining_craft_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["bin_id"] = 1; ["craft_id"] = 2;};

local df = {  23120101, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local combining_craft_pool = { }
combining_craft_pool[23120101] = {
	P({false,1001}, get),
	P({false,1002}, get),
	P({false,2001}, get),
	P({false,2002}, get),
};
combining_craft_pool[23120102] = {
	P({23120102,3001}, get),
	P({23120102,3002}, get),
	P({23120102,4001}, get),
	P({23120102,4002}, get),
};
combining_craft_pool[23120103] = {
	P({23120103,5001}, get),
	P({23120103,5002}, get),
	P({23120103,5003}, get),
};
combining_craft_pool[25060101] = {
	P({25060101,11001}, get),
	P({25060101,11002}, get),
	P({25060101,12001}, get),
	P({25060101,12002}, get),
};
combining_craft_pool[25060102] = {
	P({25060102,13001}, get),
	P({25060102,13002}, get),
	P({25060102,14001}, get),
	P({25060102,14002}, get),
};
combining_craft_pool[25060103] = {
	P({25060103,15001}, get),
	P({25060103,15002}, get),
	P({25060103,15003}, get),
};
return { tb = combining_craft_pool };