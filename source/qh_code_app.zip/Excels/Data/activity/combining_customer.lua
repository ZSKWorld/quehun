-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][combining_customer]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["customer_id"] = 1; ["activity_id"] = 2; ["order_type"] = 3; ["customer_location"] = 4; ["customer_skin"] = 1005; ["customer_loading"] = 6; ["complete_sound"] = 1007;};

local df = {  nil, 250601, 1, 3, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local combining_customer = { }
combining_customer[1001] = P({D[2003], 1001,1,"left_0",false,"audio/sound/mingzhiyingshu/activity/gift_short"}, get);
combining_customer[1002] = P({D[2003], 1002,1,"left_1",false,"audio/sound/kawei/activity/gift_short"}, get);
combining_customer[1003] = P({D[2003], 1003,1,"left_2",false,"audio/sound/qianzhi/activity/gift_short"}, get);
combining_customer[1004] = P({D[2003], 1004,1,"left_3",false,"audio/sound/xiangyuanwu/lobby/lobby_gift"}, get);
combining_customer[1005] = P({D[2003], 1005,1,"left_4",false,"audio/sound/bamuwei/activity/gift_short"}, get);
combining_customer[1006] = P({D[2003], 1006,1,"left_5",false,"audio/sound/lianggongxingshu/spot/jtm_anj_240"}, get);
combining_customer[1007] = P({D[2003], 1007,1,"left_6",false,"audio/sound/xiaoniaoyouchutian/activity/gift_short"}, get);
combining_customer[1008] = P({D[2003], 1008,1,"left_7",false,"audio/sound/yuesefu/activity/gift_short"}, get);
combining_customer[1009] = P({D[2003], 1009,1,"left_8",false,"audio/sound/huiyeji/spot/jtm_kgy_240"}, get);
combining_customer[1010] = P({D[2003], 1010,1,"left_9",false,"audio/sound/qihailinai/activity/gift_short"}, get);
combining_customer[1011] = P({D[2003], 1011,1,"left_10",false,"audio/sound/laien/spot/jtm_rya_234"}, get);
combining_customer[1012] = P({D[2003], 1012,1,"left_11",false,"audio/sound/xiyuansiyiyu/activity/gift_short"}, get);
combining_customer[1013] = P({D[2003], 1013,1,"left_12",false,"audio/sound/xiaoyesiqiyu/activity/gift_short"}, get);
combining_customer[1014] = P({D[2003], 1014,1,"left_13",false,"audio/sound/qingluan/lobby/lobby_gift"}, get);
combining_customer[1015] = P({D[2003], 1015,1,"left_14",false,"audio/sound/weilai/spot/jtm_mri_231"}, get);
combining_customer[1016] = P({D[2003], 1016,1,"left_15",false,"audio/sound/ling/spot/jtm_rin_231"}, get);
combining_customer[1017] = P({D[2003], 1017,1,"left_16",false,"audio/sound/ailisha/activity/gift_short"}, get);
combining_customer[1018] = P({D[2003], 1018,1,"left_17",false,"audio/sound/siqiqiansuili/activity/gift_short"}, get);
combining_customer[1019] = P({D[2003], 1019,2,"mid_0",false,"audio/sound/fuzi/lobby/lobby_gift"}, get);
combining_customer[1020] = P({D[2003], 1020,2,"mid_1",false,"audio/sound/jiutiao/activity/gift_short"}, get);
combining_customer[1021] = P({D[2003], 1021,2,"mid_2",false,"audio/sound/wangcilang/lobby/lobby_gift_favor"}, get);
combining_customer[1022] = P({D[2003], 1022,2,"mid_3",false,"audio/sound/yiji/activity/gift_short"}, get);
combining_customer[1023] = P({D[2003], 1023,2,"mid_4",false,"audio/sound/yizhilaikong/lobby/lobby_gift"}, get);
combining_customer[1024] = P({D[2003], 1024,2,"mid_5",false,"audio/sound/chutao/activity/gift_short"}, get);
combining_customer[1025] = P({D[2003], 1025,2,"mid_6",false,"audio/sound/beijianshahezi/activity/gift_short"}, get);
combining_customer[1026] = P({D[2003], 1026,2,"mid_7",false,"audio/sound/baishinainai/lobby/lobby_gift"}, get);
combining_customer[1027] = P({D[2003], 1027,2,"mid_8",false,"audio/sound/shiyuanduihai/spot/jtm_usm_233"}, get);
combining_customer[1028] = P({D[2003], 1028,2,"mid_9",false,"audio/sound/tengbenqiluo/activity/gift_short"}, get);
combining_customer[1029] = P({D[2003], 1029,2,"mid_10",false,"audio/sound/a37/activity/gift_short"}, get);
combining_customer[1030] = P({D[2003], 1030,2,"mid_11",false,"audio/sound/senchuanlingzi/activity/gift_short"}, get);
combining_customer[1031] = P({D[2003], 1031,2,"mid_12",false,"audio/sound/jichuanxiang/activity/gift_short"}, get);
combining_customer[1032] = P({D[2003], 1032,2,"mid_13",false,"audio/sound/xiamier/activity/gift_short"}, get);
combining_customer[1033] = P({D[2003], 1033,2,"mid_14",false,"audio/sound/you/spot/jtm_yuz_231"}, get);
combining_customer[1034] = P({D[2003], 1034,2,"mid_15",false,"audio/sound/zekesi/spot/jtm_zks_239"}, get);
combining_customer[1035] = P({D[2003], 1035,2,"mid_16",false,"audio/sound/nanfenghua/spot/jtm_fuk_230"}, get);
combining_customer[1036] = P({D[2004], 1036,"right_0",false,"audio/sound/jianai/lobby/lobby_gift_favor"}, get);
combining_customer[1037] = P({D[2004], 1037,"right_1",false,"audio/sound/erjietang/spot/jtm_2_mik_086"}, get);
combining_customer[1038] = P({D[2004], 1038,"right_2",false,"audio/sound/sigongxiasheng/lobby/lobby_gift_favor"}, get);
combining_customer[1039] = P({D[2004], 1039,"right_3",false,"audio/sound/shala/activity/gift_short"}, get);
combining_customer[1040] = P({D[2004], 1040,"right_4",false,"audio/sound/zeniya/activity/gift_short"}, get);
combining_customer[1041] = P({D[2004], 1041,"right_5",false,"audio/sound/aiyin/activity/gift_short"}, get);
combining_customer[1042] = P({D[2004], 1042,"right_6",false,"audio/sound/zhaitengzhi/spot/jtm_osm_232"}, get);
combining_customer[1043] = P({D[2004], 1043,"right_7",false,"audio/sound/erzhigonghua/activity/gift_short"}, get);
combining_customer[1044] = P({D[2004], 1044,"right_8",false,"audio/sound/wushilanyangcai/activity/gift_short"}, get);
combining_customer[1045] = P({D[2004], 1045,"right_9",false,"audio/sound/ruyuelian/spot/jtm_ren_233"}, get);
combining_customer[1046] = P({D[2004], 1046,"right_10",false,"audio/sound/yuejianshan/activity/gift_short"}, get);
combining_customer[1047] = P({D[2004], 1047,"right_11",false,"audio/sound/qixi/spot/jtm_qix_238"}, get);
combining_customer[1048] = P({D[2004], 1048,"right_12",false,"audio/sound/fuji/spot/jtm_fuj_234"}, get);
combining_customer[1049] = P({D[2004], 1049,"right_13",false,"audio/sound/longchuanxiayan/activity/gift_short"}, get);
combining_customer[1050] = P({D[2004], 1050,"right_14",false,"audio/sound/beiyuanlili/spot/jtm_lil_238"}, get);
combining_customer[1051] = P({D[2004], 1051,"right_15",false,"audio/sound/sigongdongshi/spot/jtm_fym_236"}, get);
combining_customer[1052] = P({D[2004], 1052,"right_16",false,"audio/sound/ruyuecaiyin/spot/jtm_ayn_239"}, get);
combining_customer[1053] = P({D[2004], 1053,"right_17",false,"audio/sound/lanxing/spot/jtm_rns_239"}, get);
combining_customer[1054] = P({D[2004], 1054,"right_18",false,"audio/sound/dongchengxuanyin/spot/jtm_krn_238"}, get);
combining_customer[1055] = P({1055,false,2,1,"2506_left_100",0,"audio/sound/you/activity/qiululu1"}, get);
combining_customer[1056] = P({1056,false,2,2,"2506_mid_100",0,"audio/sound/you/activity/qiululu2"}, get);
combining_customer[1057] = P({1057,false,2,false,"2506_right_100",0,"audio/sound/you/activity/qiululu3"}, get);
combining_customer[1058] = P({1058,false,2,2,"2506_mid_101",0,"audio/sound/nianshou2025/activity/gift_short"}, get);
return { tb = combining_customer };