-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][combining_map]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["point_item_id"] = 2; ["point_item_count"] = 3; ["workbench_count"] = 4;};

local df = {  231201, 30900006, nil, 8,};

local get = function(item, k) return G(item, k, n2i, df); end;


local combining_map = { }
combining_map[231201] = {
	P({}, get),
	P({D[1002], 400,10}, get),
	P({D[1002], 800,12}, get),
	P({D[1002], 1300,16}, get),
	P({D[1002], 2300,24}, get),
};
combining_map[250601] = {
	P({250601,30900091}, get),
	P({250601,30900091,400,10}, get),
	P({250601,30900091,800,12}, get),
	P({250601,30900091,1300,16}, get),
	P({250601,30900091,2300,24}, get),
};
return { tb = combining_map };