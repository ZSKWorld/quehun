-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][daily_sign]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["reward_id"] = 2; ["reward_count"] = 3; ["day"] = 4;};

local df = {  1165, 100002, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local daily_sign = { }
daily_sign[1038] = {
	P({1038,false,16666}, get),
	P({1038,false,28888,1}, get),
	P({1038,304101,false,2}, get),
	P({1038,304101,false,3}, get),
	P({1038,304102,false,4}, get),
};
daily_sign[1162] = {
	P({1162,false,16666}, get),
	P({1162,false,28888,1}, get),
	P({1162,304005,false,2}, get),
	P({1162,304005,false,3}, get),
	P({1162,304006,false,4}, get),
};
daily_sign[1165] = {
	P({D[1002], 6666}, get),
	P({D[1002], 8888,1}, get),
	P({D[1002], 12888,2}, get),
	P({D[1002], 16888,3}, get),
	P({false,304005,false,4}, get),
	P({false,304005,false,5}, get),
	P({false,304006,false,6}, get),
};
daily_sign[1235] = {
	P({1235,false,8888}, get),
	P({1235,false,12888,1}, get),
	P({1235,false,16888,2}, get),
	P({1235,304005,false,3}, get),
	P({1235,304006,false,4}, get),
};
daily_sign[1295] = {
	P({1295,false,6666}, get),
	P({1295,false,8888,1}, get),
	P({1295,false,12888,2}, get),
	P({1295,false,16888,3}, get),
	P({1295,304005,false,4}, get),
	P({1295,304005,false,5}, get),
	P({1295,304006,false,6}, get),
};
daily_sign[220210] = {
	P({220210,false,6666}, get),
	P({220210,false,8888,1}, get),
	P({220210,false,12888,2}, get),
	P({220210,false,16888,3}, get),
	P({220210,304005,false,4}, get),
	P({220210,304005,false,5}, get),
	P({220210,304006,false,6}, get),
};
daily_sign[220309] = {
	P({220309,false,6666}, get),
	P({220309,false,8888,1}, get),
	P({220309,false,12888,2}, get),
	P({220309,false,16888,3}, get),
	P({220309,304005,false,4}, get),
	P({220309,304005,false,5}, get),
	P({220309,304006,false,6}, get),
};
daily_sign[220508] = {
	P({220508,false,8888}, get),
	P({220508,false,12888,1}, get),
	P({220508,false,16888,2}, get),
	P({220508,304005,false,3}, get),
	P({220508,304006,false,4}, get),
};
daily_sign[220911] = {
	P({220911,false,8888}, get),
	P({220911,false,12888,1}, get),
	P({220911,false,16888,2}, get),
	P({220911,304005,false,3}, get),
	P({220911,304006,false,4}, get),
};
daily_sign[221113] = {
	P({221113,false,8888}, get),
	P({221113,false,12888,1}, get),
	P({221113,false,16888,2}, get),
	P({221113,304005,false,3}, get),
	P({221113,304006,false,4}, get),
};
daily_sign[230401] = {
	P({230401,false,6666}, get),
	P({230401,false,8888,1}, get),
	P({230401,false,12888,2}, get),
	P({230401,false,16888,3}, get),
	P({230401,303994,false,4}, get),
	P({230401,303994,2,5}, get),
	P({230401,304006,false,6}, get),
};
daily_sign[230831] = {
	P({230831,false,6666}, get),
	P({230831,false,8888,1}, get),
	P({230831,false,12888,2}, get),
	P({230831,false,16888,3}, get),
	P({230831,304005,false,4}, get),
	P({230831,304005,false,5}, get),
	P({230831,304006,false,6}, get),
};
daily_sign[231101] = {
	P({231101,false,16888}, get),
	P({231101,false,28888,1}, get),
	P({231101,303994,false,2}, get),
	P({231101,303994,2,3}, get),
	P({231101,304006,false,4}, get),
};
daily_sign[231251] = {
	P({231251,false,6666}, get),
	P({231251,false,8888,1}, get),
	P({231251,false,12888,2}, get),
	P({231251,false,16888,3}, get),
	P({231251,304005,false,4}, get),
	P({231251,304005,false,5}, get),
	P({231251,304006,false,6}, get),
};
daily_sign[240351] = {
	P({240351,false,6666}, get),
	P({240351,false,8888,1}, get),
	P({240351,false,12888,2}, get),
	P({240351,false,16888,3}, get),
	P({240351,303994,false,4}, get),
	P({240351,303994,2,5}, get),
	P({240351,304006,false,6}, get),
};
daily_sign[240550] = {
	P({240550,false,6666}, get),
	P({240550,false,8888,1}, get),
	P({240550,false,12888,2}, get),
	P({240550,false,16888,3}, get),
	P({240550,304005,false,4}, get),
	P({240550,304005,false,5}, get),
	P({240550,304006,false,6}, get),
};
daily_sign[241091] = {
	P({241091,false,16888}, get),
	P({241091,false,28888,1}, get),
	P({241091,303994,false,2}, get),
	P({241091,303994,2,3}, get),
	P({241091,304006,false,4}, get),
};
daily_sign[241240] = {
	P({241240,false,8888}, get),
	P({241240,false,12888,1}, get),
	P({241240,false,16888,2}, get),
	P({241240,304005,false,3}, get),
	P({241240,304006,false,4}, get),
};
daily_sign[250391] = {
	P({250391,false,6666}, get),
	P({250391,false,8888,1}, get),
	P({250391,false,12888,2}, get),
	P({250391,false,16888,3}, get),
	P({250391,303994,false,4}, get),
	P({250391,303994,2,5}, get),
	P({250391,304006,false,6}, get),
};
daily_sign[250991] = {
	P({250991,false,6666}, get),
	P({250991,false,8888,1}, get),
	P({250991,false,12888,2}, get),
	P({250991,false,16888,3}, get),
	P({250991,303994,false,4}, get),
	P({250991,303994,2,5}, get),
	P({250991,304006,false,6}, get),
};
daily_sign[260281] = {
	P({260281,false,6666}, get),
	P({260281,false,8888,1}, get),
	P({260281,false,12888,2}, get),
	P({260281,false,16888,3}, get),
	P({260281,304005,false,4}, get),
	P({260281,304005,false,5}, get),
	P({260281,304006,false,6}, get),
};
daily_sign[260391] = {
	P({260391,false,6666}, get),
	P({260391,false,8888,1}, get),
	P({260391,false,12888,2}, get),
	P({260391,false,16888,3}, get),
	P({260391,303994,false,4}, get),
	P({260391,303994,2,5}, get),
	P({260391,304006,false,6}, get),
};
daily_sign[260591] = {
	P({260591,false,6666}, get),
	P({260591,false,8888,1}, get),
	P({260591,false,12888,2}, get),
	P({260591,false,16888,3}, get),
	P({260591,304005,false,4}, get),
	P({260591,304005,false,5}, get),
	P({260591,304006,false,6}, get),
};
daily_sign[260691] = {
	P({260691,false,16888}, get),
	P({260691,false,28888,1}, get),
	P({260691,303994,false,2}, get),
	P({260691,303994,2,3}, get),
	P({260691,304006,false,4}, get),
};
return { tb = daily_sign };