-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][exchange]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["reward_id"] = 3; ["reward_count"] = 4; ["consume_id"] = 5; ["consume_count"] = 6; ["exchange_limit"] = 7; ["item_limit_id"] = 8; ["item_limit_count"] = 9; ["unlock_day"] = 1010;};

local df = {  nil, 1035, 100002, 1, 309005, 1, 1, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1085009,22090801,26010304,}

local exchange = { }
return { tb = exchange, get = get, b2i = b2i };