-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][feed_activity_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["max_feed_count"] = 2; ["feed_reward_id"] = 3; ["friend_send_limit"] = 4; ["friend_recv_limit"] = 5; ["food_item_id"] = 6;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local feed_activity_info = { }
feed_activity_info[1260] = P({1260,30,126001,5,5,S({309048,309049,309050,309051,309052,})}, get);
return { tb = feed_activity_info };