-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][feed_activity_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["count"] = 2; ["reward"] = 1003; ["img_stage"] = 4;};

local df = {  126001, nil, "100002-5000", 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local feed_activity_reward = { }
feed_activity_reward[126001] = {
	P({false,1,"100002-1000",0}, get),
	P({false,2,"100002-1000,302005-1",0}, get),
	P({false,3,"100002-1000,304008-1",0}, get),
	P({false,4,"100002-1000",0}, get),
	P({false,5,"100002-5000,309110-1",0}, get),
	P({false,6,"100002-2000",0}, get),
	P({false,7,"100002-2000,302006-1",0}, get),
	P({false,8,"100002-2000,304008-1",0}, get),
	P({false,9,"100002-2000",0}, get),
	P({false,10,"100002-10000,304009-1"}, get),
	P({false,11,"100002-3000"}, get),
	P({false,12,"100002-3000,302007-1"}, get),
	P({false,13,"100002-3000,304008-1"}, get),
	P({false,14,"100002-3000"}, get),
	P({false,15,"100002-15000,304009-1"}, get),
	P({false,16,"100002-4000"}, get),
	P({false,17,"100002-4000,302008-1"}, get),
	P({false,18,"100002-4000,304008-1"}, get),
	P({false,19,"100002-4000"}, get),
	P({false,20,"100002-20000,302001-1",2}, get),
	P({false,21,false,2}, get),
	P({false,22,"100002-5000,302009-1",2}, get),
	P({false,23,"100002-5000,304008-1",2}, get),
	P({false,24,false,2}, get),
	P({false,25,"100002-20000,306201-1",2}, get),
	P({false,26,false,2}, get),
	P({false,27,"100002-5000,302010-1",2}, get),
	P({false,28,"100002-5000,304008-1",2}, get),
	P({false,29,false,2}, get),
	P({false,30,"100002-20000,302001-1",3}, get),
	P({false,9999,"100002-500",3}, get),
};
return { tb = feed_activity_reward };