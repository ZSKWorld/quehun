-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][festival_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["funds_id"] = 2; ["proposal_id"] = 3; ["proposal_consume"] = 4; ["daily_buy_limit"] = 5; ["arrow_amount"] = 6; ["max_amount"] = 7; ["max_proposal_pos"] = 8;};

local df = {  nil, nil, nil, nil, nil, 10, 999, 4,};

local get = function(item, k) return G(item, k, n2i, df); end;


local festival_activity = { }
festival_activity[240401] = P({240401,30900021,70000001,20,5}, get);
festival_activity[250101] = P({250101,30900080,70000010,0,0}, get);
return { tb = festival_activity };