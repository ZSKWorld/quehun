-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][festival_ending]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["group_id"] = 1; ["ending_id"] = 2; ["ending_type"] = 3; ["weight"] = 4; ["item_plus"] = 1005; ["item_minus"] = 1006; ["funds"] = 7; ["ending_text"] = 8;};

local df = {  100101, 61, nil, 1, "30900023-20", nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {200702,2002502,}

local festival_ending = { }
return { tb = festival_ending, get = get, b2i = b2i };