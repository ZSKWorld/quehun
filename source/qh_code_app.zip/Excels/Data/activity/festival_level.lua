-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][festival_level]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["level"] = 2; ["level_name"] = 3; ["level_require"] = 1004; ["level_res"] = 1005; ["unlock_event_count"] = 6;};

local df = {  240401, nil, nil, nil, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local festival_level = { }
festival_level[240401] = {
	P({D[1002], 2625,false,"festival_level_0.png"}, get),
	P({false,1,2626,"30900022-10,30900023-10,30900024-10","festival_level_1.png"}, get),
	P({false,2,2627,"30900022-30,30900023-30,30900024-30","festival_level_2.png"}, get),
	P({false,3,2628,"30900022-50,30900023-50,30900024-50","festival_level_3.png"}, get),
	P({false,4,2629,"30900022-80,30900023-80,30900024-80","festival_level_4.png"}, get),
	P({false,5,2630,"30900022-110,30900023-110,30900024-110","festival_level_5.png"}, get),
	P({false,6,2631,"30900022-140,30900023-140,30900024-140","festival_level_6.png"}, get),
	P({false,7,2632,"30900022-180,30900023-180,30900024-180","festival_level_7.png"}, get),
	P({false,8,2633,"30900022-220,30900023-220,30900024-220","festival_level_8.png"}, get),
	P({false,9,2634,"30900022-270,30900023-270,30900024-270","festival_level_9.png"}, get),
	P({false,10,2635,"30900022-330,30900023-330,30900024-330","festival_level_10.png"}, get),
	P({false,11,2636,"30900022-390,30900023-390,30900024-390","festival_level_11.png"}, get),
	P({false,12,2637,"30900022-450,30900023-450,30900024-450","festival_level_12.png"}, get),
	P({false,13,2638,"30900022-520,30900023-520,30900024-520","festival_level_13.png"}, get),
	P({false,14,2639,"30900022-590,30900023-590,30900024-590","festival_level_14.png"}, get),
	P({false,15,2640,"30900022-660,30900023-660,30900024-660","festival_level_15.png"}, get),
	P({false,16,2641,"30900022-730,30900023-730,30900024-730","festival_level_16.png"}, get),
	P({false,17,2642,"30900022-800,30900023-800,30900024-800","festival_level_17.png"}, get),
};
festival_level[250101] = {
	P({250101,false,3106,false,"miaohui_level_0.png"}, get),
	P({250101,1,3107,"30900081-10,30900082-10,30900083-10","miaohui_level_1.png"}, get),
	P({250101,2,3108,"30900081-30,30900082-30,30900083-30","miaohui_level_2.png"}, get),
	P({250101,3,3109,"30900081-50,30900082-50,30900083-50","miaohui_level_3.png"}, get),
	P({250101,4,3110,"30900081-80,30900082-80,30900083-80","miaohui_level_4.png"}, get),
	P({250101,5,3111,"30900081-110,30900082-110,30900083-110","miaohui_level_5.png"}, get),
	P({250101,6,3112,"30900081-140,30900082-140,30900083-140","miaohui_level_6.png"}, get),
	P({250101,7,3113,"30900081-170,30900082-170,30900083-170","miaohui_level_7.png"}, get),
	P({250101,8,3114,"30900081-200,30900082-200,30900083-200","miaohui_level_8.png"}, get),
	P({250101,9,3115,"30900081-230,30900082-230,30900083-230","miaohui_level_9.png"}, get),
	P({250101,10,3116,"30900081-270,30900082-270,30900083-270","miaohui_level_10.png"}, get),
	P({250101,11,3117,"30900081-310,30900082-310,30900083-310","miaohui_level_11.png"}, get),
	P({250101,12,3118,"30900081-350,30900082-350,30900083-350","miaohui_level_12.png"}, get),
	P({250101,13,3119,"30900081-400,30900082-400,30900083-400","miaohui_level_13.png"}, get),
	P({250101,14,3120,"30900081-450,30900082-450,30900083-450","miaohui_level_14.png"}, get),
	P({250101,15,3121,"30900081-500,30900082-500,30900083-500","miaohui_level_15.png"}, get),
	P({250101,16,3122,"30900081-550,30900082-550,30900083-550","miaohui_level_16.png"}, get),
	P({250101,17,3123,"30900081-600,30900082-600,30900083-600","miaohui_level_17.png"}, get),
};
return { tb = festival_level };