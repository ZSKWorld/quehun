-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][festival_proposal]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["proposal_id"] = 2; ["unlock_level"] = 3; ["ending_group"] = 4; ["client_name"] = 5; ["client_icon"] = 1006; ["proposal_text"] = 7; ["option_text_a"] = 8; ["option_text_b"] = 9;};

local df = {  240401, nil, nil, nil, nil, "deco/emo/activity/9.png", nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local festival_proposal = { }
festival_proposal[240401] = {
	P({false,10001,false,S({1000101,1000102,}),2502,"deco/emo/activity/2.png",2503,2504,2505}, get),
	P({false,10002,false,S({1000201,1000202,}),2506,"deco/emo/activity/3.png",2507,2508,2509}, get),
	P({false,10003,false,S({1000301,1000302,}),2510,"deco/emo/activity/7.png",2511,2512,2513}, get),
	P({false,10004,false,S({1000401,1000402,}),2514,"deco/emo/activity/1.png",2515,2516,2517}, get),
	P({false,10005,false,S({1000501,1000502,}),2518,"deco/emo/activity/7.png",2519,2520,2521}, get),
	P({false,10006,false,S({1000601,1000602,}),2522,"deco/emo/activity/2.png",2523,2524,2525}, get),
	P({false,10007,false,S({1000701,1000702,}),2526,"deco/emo/activity/4.png",2527,2528,2529}, get),
	P({false,10008,false,S({1000801,1000802,}),2530,"deco/emo/activity/1.png",2531,2532,2533}, get),
	P({false,10009,false,S({1000901,1000902,}),2534,"deco/emo/activity/2.png",2535,2536,2537}, get),
	P({false,10010,false,S({1001001,1001002,}),2538,"deco/emo/activity/5.png",2539,2540,2541}, get),
	P({false,10011,false,S({1001101,1001102,}),2542,"deco/emo/activity/3.png",2543,2544,2545}, get),
	P({false,10012,false,S({1001201,1001202,}),2546,"deco/emo/activity/7.png",2547,2548,2549}, get),
	P({false,10013,false,S({1001301,1001302,}),2550,"deco/emo/activity/6.png",2551,2552,2553}, get),
	P({false,10014,false,S({1001401,1001402,}),2554,"deco/emo/activity/3.png",2555,2556,2557}, get),
	P({false,10015,false,S({1001501,1001502,}),2558,"deco/emo/activity/8.png",2559,2560,2561}, get),
	P({false,10016,false,S({1001601,1001602,}),2562,"deco/emo/activity/5.png",2563,2564,2565}, get),
	P({false,10017,false,S({1001701,1001702,}),2566,"deco/emo/activity/1.png",2567,2568,2569}, get),
	P({false,10018,false,S({1001801,1001802,}),2570,"deco/emo/activity/8.png",2571,2572,2573}, get),
	P({false,10019,false,S({1001901,1001902,}),2574,"deco/emo/activity/6.png",2575,2576,2577}, get),
	P({false,10020,false,S({1002001,1002002,}),2578,"deco/emo/activity/7.png",2579,2580,2581}, get),
	P({false,10021,false,S({1002101,1002102,}),2582,"deco/emo/activity/4.png",2583,2584,2585}, get),
	P({false,10022,false,S({1002201,1002202,}),2586,"deco/emo/activity/5.png",2587,2588,2589}, get),
	P({false,10023,false,S({1002301,1002302,}),2590,"deco/emo/activity/1.png",2591,2592,2593}, get),
	P({false,10024,false,S({1002401,1002402,}),2594,"deco/emo/activity/7.png",2595,2596,2597}, get),
	P({false,10025,false,S({1002501,1002502,}),2598,"deco/emo/activity/1.png",2599,2600,2601}, get),
	P({false,10026,false,S({1002601,1002602,}),2602,"deco/emo/activity/2.png",2603,2604,2605}, get),
	P({false,10027,false,S({1002701,1002702,}),2606,"deco/emo/activity/8.png",2607,2608,2609}, get),
	P({false,10028,false,S({1002801,1002802,}),2610,"deco/emo/activity/2.png",2611,2612,2613}, get),
	P({false,10029,false,S({1002901,1002902,}),2614,"deco/emo/activity/2.png",2615,2616,2617}, get),
};
festival_proposal[250101] = {
	P({250101,20001,false,S({2000101,2000102,}),3290,false,3291,3292,3293}, get),
	P({250101,20002,false,S({2000201,2000202,}),3294,false,3295,3296,3297}, get),
	P({250101,20003,false,S({2000301,2000302,}),3298,false,3299,3300,3301}, get),
	P({250101,20004,false,S({2000401,2000402,}),3302,false,3303,3304,3305}, get),
	P({250101,20005,false,S({2000501,2000502,}),3306,false,3307,3308,3309}, get),
	P({250101,20006,false,S({2000601,2000602,}),3310,false,3311,3312,3313}, get),
	P({250101,20007,false,S({2000701,2000702,}),3314,false,3315,3316,3317}, get),
	P({250101,20008,false,S({2000801,2000802,}),3318,false,3319,3320,3321}, get),
	P({250101,20009,false,S({2000901,2000902,}),3322,false,3323,3324,3325}, get),
	P({250101,20010,false,S({2001001,2001002,}),3326,false,3327,3328,3329}, get),
	P({250101,20011,false,S({2001101,2001102,}),3330,false,3331,3332,3333}, get),
	P({250101,20012,false,S({2001201,2001202,}),3334,false,3335,3336,3337}, get),
	P({250101,20013,false,S({2001301,2001302,}),3338,false,3339,3340,3341}, get),
	P({250101,20014,false,S({2001401,2001402,}),3342,false,3343,3344,3345}, get),
	P({250101,20015,false,S({2001501,2001502,}),3346,false,3347,3348,3349}, get),
	P({250101,20016,false,S({2001601,2001602,}),3350,false,3351,3352,3353}, get),
	P({250101,20017,false,S({2001701,2001702,}),3354,false,3355,3356,3357}, get),
	P({250101,20018,false,S({2001801,2001802,}),3358,false,3359,3360,3361}, get),
	P({250101,20019,false,S({2001901,2001902,}),3362,false,3363,3364,3365}, get),
	P({250101,20020,false,S({2002001,2002002,}),3366,false,3367,3368,3369}, get),
	P({250101,20021,false,S({2002101,2002102,}),3370,false,3371,3372,3373}, get),
	P({250101,20022,false,S({2002201,2002202,}),3374,false,3375,3376,3377}, get),
	P({250101,20023,false,S({2002301,2002302,}),3378,false,3379,3380,3381}, get),
	P({250101,20024,false,S({2002401,2002402,}),3382,false,3383,3384,3385}, get),
	P({250101,20025,false,S({2002501,2002502,}),3386,false,3387,3388,3389}, get),
};
return { tb = festival_proposal };