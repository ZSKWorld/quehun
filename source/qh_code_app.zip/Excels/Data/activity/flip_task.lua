-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][flip_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["base_task_id"] = 3; ["reward"] = 1004; ["matrix_x"] = 5; ["matrix_y"] = 6; ["is_reward"] = 7;};

local df = {  nil, 1022, nil, "100002-3888", nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1070012,22090124,24086034,220501036,}

local flip_task = { }
return { tb = flip_task, get = get, b2i = b2i };