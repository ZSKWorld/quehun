-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][friend_gift_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["friend_send_limit"] = 2; ["friend_send_consume"] = 3; ["friend_recv_limit"] = 4; ["extra_gift"] = 5; ["gift_item_id"] = 6;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local friend_gift_activity = { }
friend_gift_activity[230102] = P({230102,3,0,3,1,S({309069,})}, get);
return { tb = friend_gift_activity };