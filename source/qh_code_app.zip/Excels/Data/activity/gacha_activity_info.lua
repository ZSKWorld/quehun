-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][gacha_activity_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["gacha_pool"] = 2; ["gacha_control"] = 3; ["sp_trigger_times"] = 4; ["sp_rewards"] = 1005; ["consume"] = 1006;};

local df = {  nil, nil, nil, 30, nil, "309072-1",};

local get = function(item, k) return G(item, k, n2i, df); end;


local gacha_activity_info = { }
gacha_activity_info[230301] = P({230301,101,101,false,"306006-1"}, get);
gacha_activity_info[231001] = P({231001,102,102,false,"30580001-1"}, get);
gacha_activity_info[240901] = P({240901,103,103,false,"307460-1","30900077-1"}, get);
gacha_activity_info[250501] = P({250501,104,104,false,"307472-1"}, get);
return { tb = gacha_activity_info };