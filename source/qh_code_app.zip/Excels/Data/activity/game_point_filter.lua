-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][game_point_filter]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["has_robot"] = 1002; ["category"] = 1003; ["room"] = 1004; ["mode"] = 1005; ["point_coe"] = 6;};

local df = {  1001, "1", "2", "1,2,3,4,6", "0", 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local game_point_filter = { }
game_point_filter[1001] = {
	P({D[1004], "1,2"}, get),
	P({D[1004], "11,12",3}, get),
	P({D[1003], "320","1",3}, get),
};
game_point_filter[221201] = {
	P({221201,"0","0","0"}, get),
};
game_point_filter[231151] = {
	P({231151,"0","0","0"}, get),
};
return { tb = game_point_filter };