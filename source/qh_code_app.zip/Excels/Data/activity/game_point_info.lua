-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][game_point_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["filter_id"] = 2; ["reward_mail_template"] = 3; ["max_point_limit_day"] = 4; ["should_rank"] = 5;};

local df = {  nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local game_point_info = { }
game_point_info[1135] = P({1135,1001,107,4,1}, get);
game_point_info[221201] = P({221201,221201,110}, get);
game_point_info[231151] = P({231151,231151,0}, get);
return { tb = game_point_info };