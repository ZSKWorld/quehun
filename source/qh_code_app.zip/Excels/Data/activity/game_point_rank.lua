-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][game_point_rank]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["rank_rate_lower"] = 2; ["rank_rate_upper"] = 3; ["reward"] = 1004;};

local df = {  1135, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local game_point_rank = { }
game_point_rank[1135] = {
	P({false,0,5,"100002-50000,304008-1,304009-1,302001-1"}, get),
	P({false,5,10,"100002-50000,304008-1,304009-1"}, get),
	P({false,10,25,"100002-50000,304008-1"}, get),
	P({false,25,50,"100002-50000"}, get),
};
return { tb = game_point_rank };