-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][game_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["base_task_id"] = 3; ["reward"] = 1004; ["hidden_reward"] = 1005; ["limit_id"] = 6; ["single_trigger"] = 7; ["deprecated"] = 8;};

local df = {  nil, 1024, 20179, "309013-4", nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1024051,1091009,1220032,22070541,24050109,26040607,}

local game_task = { }
return { tb = game_task, get = get, b2i = b2i };