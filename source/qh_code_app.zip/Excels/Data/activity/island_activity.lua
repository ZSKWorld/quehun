-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][island_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["food_id"] = 2; ["currency_id"] = 3; ["food_consume"] = 4; ["sell_discount"] = 5; ["guide_bottle_price"] = 6;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local island_activity = { }
island_activity[240601] = P({240601,30900028,30900029,1,100,12}, get);
return { tb = island_activity };