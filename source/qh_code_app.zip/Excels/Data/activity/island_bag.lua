-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][island_bag]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["bag_id"] = 2; ["bag_name"] = 3; ["bag_desc"] = 4; ["bag_icon_locked"] = 1005; ["bag_icon_unlocked"] = 1006; ["matrix"] = 1007; ["max_matrix"] = 1008; ["unlock_consume"] = 1009; ["initial"] = 10; ["unlock_task_id"] = 11;};

local df = {  240601, nil, nil, nil, nil, nil, "5,1,1,1,1,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1", nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local island_bag = { }
island_bag[240601] = {
	P({false,101,0,0,"","",false,"5,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1","30900029-20",1,0}, get),
	P({false,102,4350,4351,"backpack_pop_up_window_huiyeji.png","new_backpack_unlock_huiyeji.png","5,1,1,1,1,1,1,0,1,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1","5,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0","30900029-30",false,24060701}, get),
	P({false,103,4352,4353,"backpack_pop_up_window_wangjiro.png","new_backpack_unlock_wangjiro.png",false,"5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0","30900029-50",false,24060702}, get),
};
return { tb = island_bag };