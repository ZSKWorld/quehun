-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][island_goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["goods_id"] = 2; ["goods_name"] = 3; ["matrix"] = 1004; ["price"] = 5; ["goods_res"] = 1006; ["icon"] = 1007;};

local df = {  240601, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local island_goods = { }
island_goods[240601] = {
	P({false,1001,2650,"1,1,1",10,"prop1_water_bottle.png","prop_icon_1_water_bottle.png"}, get),
	P({false,1002,2651,"2,1,1,0,1",40,"prop2_shrimp.png","prop_icon_2_shrimp.png"}, get),
	P({false,1003,2652,"2,1,1,1,1",80,"prop3_shell.png","prop_icon_3_shell.png"}, get),
	P({false,1004,2653,"3,0,1,1,1,1,0",140,"prop4_pizza.png","prop_icon_4_pizza.png"}, get),
	P({false,1005,2654,"3,1,1,0,0,1,1",130,"prop5_wastepa.png","prop_icon_5_wastepa.png"}, get),
	P({false,1006,2655,"3,0,1,0,1,1,1",160,"prop6_bread.png","prop_icon_6_bread.png"}, get),
	P({false,1007,2656,"3,1,1,1,1,0,0",330,"prop7_water_gun.png","prop_icon_7_water_gun.png"}, get),
	P({false,1008,2657,"3,1,1,1,0,0,1",360,"prop8_fascia.png","prop_icon_8_fascia.png"}, get),
	P({false,1009,2658,"1,1,1,1,1",800,"prop9_umbrella.png","prop_icon_9_umbrella.png"}, get),
	P({false,1010,2659,"3,1,0,1,1,1,1",1000,"prop10_mahjong.png","prop_icon_10_mahjong.png"}, get),
	P({false,1011,2660,"3,1,1,1,0,1,0,0,1,0",1200,"prop11_stand_upright.png","prop_icon_11_stand_upright.png"}, get),
	P({false,1012,2661,"3,1,0,0,1,1,1,0,1,0",2000,"prop12_crystal_dinosaur.png","prop_icon_12_crystal_dinosaur.png"}, get),
	P({false,1013,2662,"3,0,0,1,1,1,1,0,1,0",3000,"prop13_golden_decoration.png","prop_icon_13_golden_decoration.png"}, get),
};
return { tb = island_goods };