-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][island_map]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["zone_id"] = 2; ["zone_name"] = 3; ["zone_icon_unlocked"] = 1004; ["currency_amount"] = 5; ["initial"] = 6; ["distance"] = 7; ["route"] = 1008; ["unlock_task_id"] = 9;};

local df = {  240601, nil, nil, nil, 20000, nil, 1, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local island_map = { }
island_map[240601] = {
	P({false,0,4313,"",10000,1,S({0,1,1,2,3,}),S({"","0,1","0,2","0,1,3","0,1,3,4",})}, get),
	P({false,1,4314,"new_map_unlock_bread_house.png",10000,1,S({1,0,2,1,2,}),S({"1,0","","1,0,2","1,3","1,3,4",})}, get),
	P({D[5006], false,2,4315,"new_map_unlock_primary_school.png",S({1,2,0,1,2,}),S({"2,0","2,0,1","","2,3","2,3,4",}),24060703}, get),
	P({D[5006], false,3,4316,"new_map_unlock_mahjong_cultural_street.png",S({2,1,1,0,1,}),S({"3,1,0","3,1","3,2","","3,4",}),24060704}, get),
	P({D[5006], false,4,4317,"new_map_unlock_resort.png",S({3,2,2,1,0,}),S({"4,3,1,0","4,3,1","4,3,2","4,3",}),24060705}, get),
};
return { tb = island_map };