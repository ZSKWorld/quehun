-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][island_news]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["day"] = 2; ["show_day"] = 3; ["news_date"] = 4; ["news_week"] = 5; ["zone"] = 6; ["news_desc"] = 7; ["goods_id"] = 8; ["effect"] = 9;};

local df = {  240601, 1, nil, 4400, 4368, -1, 2673, -1, 200,};

local get = function(item, k) return G(item, k, n2i, df); end;


local island_news = { }
island_news[240601] = {
	P({D[1006], 2664,1002}, get),
	P({D[1006], 2666,1003}, get),
	P({D[1007], 1009}, get),
	P({false,2,1,4401,4369,false,2663,1002,50}, get),
	P({false,2,1,4401,4369,false,2665,1003,50}, get),
	P({false,2,1,4401,4369,false,2670,1007}, get),
	P({false,3,2,4402,4370,false,2666,1003}, get),
	P({false,3,2,4402,4370,1,2667,false,50}, get),
	P({false,3,2,4402,4370,false,2671,1008,50}, get),
	P({false,4,3,4403,4371,false,2664,1002}, get),
	P({D[6007], false,4,3,4403,4371,1009}, get),
	P({false,4,3,4403,4371,4,2678,false,50}, get),
	P({false,5,4,4404,4372,false,2663,1002,50}, get),
	P({false,5,4,4404,4372,false,2669,1007,50}, get),
	P({false,5,4,4404,4372,3,2677}, get),
	P({false,6,5,4405,4366,false,2664,1002}, get),
	P({D[6007], false,6,5,4405,4366,1009}, get),
	P({false,6,5,4405,4366,2,2674,false,50}, get),
	P({false,7,6,4406,4367,false,2663,1002,50}, get),
	P({false,7,6,4406,4367,false,2666,1003}, get),
	P({false,7,6,4406,4367,false,2671,1008,50}, get),
	P({D[5006], false,8,7,4407,2665,1003,50}, get),
	P({false,8,7,4407,false,1,2667,false,50}, get),
	P({D[5006], false,8,7,4407,2670,1007}, get),
	P({false,9,8,4408,4369,false,2666,1003}, get),
	P({false,9,8,4408,4369,false,2669,1007,50}, get),
	P({false,9,8,4408,4369,false,2672,1008}, get),
	P({false,10,9,4409,4370,1,2667,false,50}, get),
	P({D[6007], false,10,9,4409,4370,1009}, get),
	P({false,10,9,4409,4370,2,2674,false,50}, get),
	P({false,11,10,4410,4371,false,2669,1007,50}, get),
	P({false,11,10,4410,4371,3,2677}, get),
	P({false,11,10,4410,4371,4,2678,false,50}, get),
	P({false,12,11,4411,4372,false,2665,1003,50}, get),
	P({false,12,11,4411,4372,1,2668}, get),
	P({false,12,11,4411,4372,false,2670,1007}, get),
	P({false,13,12,4412,4366,false,2663,1002,50}, get),
	P({false,13,12,4412,4366,2,2674,false,50}, get),
	P({false,13,12,4412,4366,3,2677}, get),
	P({false,14,13,4413,4367,1,2667,false,50}, get),
	P({D[6007], false,14,13,4413,4367,1009}, get),
	P({false,14,13,4413,4367,2,2675}, get),
	P({D[5006], false,15,14,4414,2666,1003}, get),
	P({D[5006], false,15,14,4414,2671,1008,50}, get),
	P({D[5007], false,15,14,4414,1009}, get),
	P({false,16,15,4415,4369,false,2663,1002,50}, get),
	P({false,16,15,4415,4369,3,2676,false,50}, get),
	P({false,16,15,4415,4369,4,2679}, get),
	P({false,17,16,4416,4370,false,2665,1003,50}, get),
	P({false,17,16,4416,4370,false,2671,1008,50}, get),
	P({false,17,16,4416,4370,4,2678,false,50}, get),
	P({false,18,17,4417,4371,1,2668}, get),
	P({false,18,17,4417,4371,false,2669,1007,50}, get),
	P({false,18,17,4417,4371,false,2672,1008}, get),
	P({false,19,18,4418,4372,false,2664,1002}, get),
	P({false,19,18,4418,4372,false,2670,1007}, get),
	P({false,19,18,4418,4372,3,2676,false,50}, get),
	P({false,20,19,4419,4366,false,2672,1008}, get),
	P({false,20,19,4419,4366,3,2677}, get),
	P({false,20,19,4419,4366,4,2679}, get),
};
return { tb = island_news };