-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][liver_event_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["follower_amount"] = 2; ["daily_follower_plus"] = 3; ["intro_text"] = 4; ["text_max_amount"] = 5; ["text_create_timer"] = 1006; ["text_create_weight"] = 1007; ["rolltext_speed"] = 8; ["gift_weight"] = 1009; ["rolltext_gift_time"] = 1010; ["key_item_id"] = 11; ["face_time_block"] = 1012; ["face_weight"] = 1013;};

local df = {  nil, 1145, 1, nil, 100, "800-1800", "1-20,2-5,3-70,4-5", 3600, "30900017-50,30900018-30,30900019-15,30900020-5", "30900017-5,30900018-10,30900019-20,30900020-30", 30900016, "3800-5600", "0-55,1-15,2-15,3-15",};

local get = function(item, k) return G(item, k, n2i, df); end;


local liver_event_info = { }
liver_event_info[240301] = P({D[2003], 240301,2230}, get);
liver_event_info[260101] = P({D[2003], 260101,26010001}, get);
return { tb = liver_event_info };