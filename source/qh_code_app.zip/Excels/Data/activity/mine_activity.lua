-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][mine_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["reward_group"] = 2; ["cost_item"] = 1003; ["map_size_x"] = 4; ["map_size_y"] = 5;};

local df = {  nil, nil, "309037-1", 9, 9,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mine_activity = { }
mine_activity[1194] = P({1194,1194}, get);
mine_activity[1301] = P({1301,1301}, get);
mine_activity[221002] = P({221002,221002}, get);
mine_activity[230502] = P({230502,230502}, get);
mine_activity[240202] = P({240202,240202}, get);
mine_activity[241002] = P({241002,241002}, get);
mine_activity[250702] = P({250702,250702}, get);
mine_activity[260702] = P({260702,260702}, get);
return { tb = mine_activity };