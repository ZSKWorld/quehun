-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][period_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["base_task_id"] = 3; ["reward"] = 1004; ["node_mark"] = 5; ["interval"] = 6; ["progress_limit"] = 7; ["progress_limit_interval"] = 8; ["reward_limit_day"] = 9; ["accessible_days"] = 1010; ["unlock_day"] = 11; ["deprecated"] = 12; ["omit_mail_reward"] = 13;};

local df = {  nil, 251202, 22620, "304008-1", nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1228008,22081304,23040403,23080319,23120421,24040317,24060705,24110418,25010322,25040209,25060436,25089202,25100345,26010124,26020425,26040347,26069605,}

local period_task = { }
return { tb = period_task, get = get, b2i = b2i };