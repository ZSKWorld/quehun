-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][progress_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["progress"] = 2; ["reward"] = 1003;};

local df = {  250895, 2500, "100002-12888",};

local get = function(item, k) return G(item, k, n2i, df); end;


local progress_reward = { }
progress_reward[250895] = {
	P({}, get),
	P({false,5000,"100002-16888"}, get),
	P({false,7500,"304005-1"}, get),
	P({false,10000,""}, get),
};
progress_reward[260697] = {
	P({260697}, get),
	P({260697,5000,"100002-16888"}, get),
	P({260697,7500,"304005-1"}, get),
	P({260697,10000,""}, get),
};
return { tb = progress_reward };