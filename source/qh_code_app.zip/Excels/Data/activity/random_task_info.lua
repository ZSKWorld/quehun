-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][random_task_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["pool_id"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local random_task_info = { }
random_task_info[1065] = P({1065,S({106501,106502,106503,})}, get);
random_task_info[1074] = P({1074,S({107401,107402,107403,})}, get);
random_task_info[1095] = P({1095,S({109501,109502,109503,})}, get);
random_task_info[1193] = P({1193,S({119301,119302,119303,})}, get);
random_task_info[1247] = P({1247,S({124701,124702,124703,})}, get);
random_task_info[1300] = P({1300,S({130001,130002,130003,})}, get);
random_task_info[221001] = P({221001,S({2210011,2210012,2210013,})}, get);
random_task_info[230302] = P({230302,S({2303021,2303022,2303023,})}, get);
random_task_info[230501] = P({230501,S({2305011,2305012,2305013,})}, get);
random_task_info[231002] = P({231002,S({2310021,2310022,2310023,})}, get);
random_task_info[240201] = P({240201,S({2402011,2402012,2402013,})}, get);
random_task_info[240902] = P({240902,S({2409021,2409022,2409023,})}, get);
random_task_info[241001] = P({241001,S({2410011,2410012,2410013,})}, get);
random_task_info[241202] = P({241202,S({2412021,2412022,2412023,})}, get);
random_task_info[250502] = P({250502,S({2505021,2505022,2505023,})}, get);
random_task_info[250701] = P({250701,S({2507011,2507012,2507013,})}, get);
random_task_info[260701] = P({260701,S({2607011,2607012,2607013,})}, get);
return { tb = random_task_info };