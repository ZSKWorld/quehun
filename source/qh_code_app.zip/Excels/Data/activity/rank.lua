-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][rank]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["leaderboard_id"] = 2; ["rank_reward_id"] = 3; ["require_point"] = 4;};

local df = {  nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local rank = { }
rank[1010] = {
	P({1010,1010,1010,0}, get),
};
return { tb = rank };