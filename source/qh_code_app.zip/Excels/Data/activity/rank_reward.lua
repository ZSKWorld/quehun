-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][rank_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["lower_rank_bound"] = 2; ["reward"] = 1003;};

local df = {  1010, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local rank_reward = { }
rank_reward[1010] = {
	P({false,1,"302001-10,304006-2,100002-50000"}, get),
	P({false,2,"302001-5,304006-2,100002-45000"}, get),
	P({false,5,"302001-3,304006-2,100002-40000"}, get),
	P({false,10,"302001-3,304006-1,100002-35000"}, get),
	P({false,200,"302001-2,304006-1,100002-30000"}, get),
	P({false,1000,"302001-1,304006-1,100002-25000"}, get),
	P({false,5000,"304006-1,100002-20000"}, get),
	P({false,20000,"304005-1,100002-15000"}, get),
};
return { tb = rank_reward };