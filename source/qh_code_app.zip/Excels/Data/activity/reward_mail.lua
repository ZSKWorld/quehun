-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][reward_mail]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["mail_template_id"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local reward_mail = { }
reward_mail[230803] = P({230803,113}, get);
reward_mail[231204] = P({231204,114}, get);
reward_mail[240103] = P({240103,115}, get);
reward_mail[240302] = P({240302,116}, get);
reward_mail[240404] = P({240404,117}, get);
reward_mail[240603] = P({240603,118}, get);
reward_mail[240802] = P({240802,119}, get);
reward_mail[240812] = P({240812,120}, get);
reward_mail[241105] = P({241105,122}, get);
reward_mail[241203] = P({241203,123}, get);
reward_mail[250104] = P({250104,124}, get);
reward_mail[250112] = P({250112,125}, get);
reward_mail[250202] = P({250202,126}, get);
reward_mail[250403] = P({250403,127}, get);
reward_mail[250604] = P({250604,128}, get);
reward_mail[250812] = P({250812,140}, get);
reward_mail[250821] = P({250821,129}, get);
reward_mail[250894] = P({250894,130}, get);
reward_mail[250902] = P({250902,131}, get);
reward_mail[251003] = P({251003,132}, get);
reward_mail[251190] = P({251190,133}, get);
reward_mail[251201] = P({251201,134}, get);
reward_mail[260102] = P({260102,135}, get);
reward_mail[260203] = P({260203,136}, get);
reward_mail[260204] = P({260204,137}, get);
reward_mail[260302] = P({260302,138}, get);
reward_mail[260403] = P({260403,139}, get);
reward_mail[260513] = P({260513,141}, get);
reward_mail[260603] = P({260603,142}, get);
reward_mail[260696] = P({260696,143}, get);
reward_mail[260790] = P({260790,145}, get);
reward_mail[260803] = P({260803,144}, get);
return { tb = reward_mail };