-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][richman_event]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["event_id"] = 1; ["activity_id"] = 2; ["event_type"] = 3; ["weight"] = 4; ["param"] = 5;};

local df = {  nil, 1064, 1, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local richman_event = { }
richman_event[106401] = P({D[2004], 106401,S({1,200,})}, get);
richman_event[106402] = P({D[2004], 106402,S({1,50,})}, get);
richman_event[106403] = P({106403,false,2,false,S({1,200,})}, get);
richman_event[106404] = P({106404,false,2,false,S({1,50,})}, get);
richman_event[106405] = P({106405,false,3,2,S({})}, get);
richman_event[106406] = P({106406,false,4,2,S({1,})}, get);
richman_event[107301] = P({D[3004], 107301,1073,S({1,200,})}, get);
richman_event[107302] = P({D[3004], 107302,1073,S({1,50,})}, get);
richman_event[107303] = P({107303,1073,2,false,S({1,200,})}, get);
richman_event[107304] = P({107304,1073,2,false,S({1,50,})}, get);
richman_event[107305] = P({107305,1073,3,2,S({})}, get);
richman_event[107306] = P({107306,1073,4,2,S({1,})}, get);
richman_event[109401] = P({D[3004], 109401,1094,S({1,200,})}, get);
richman_event[109402] = P({D[3004], 109402,1094,S({1,50,})}, get);
richman_event[109403] = P({109403,1094,2,false,S({1,200,})}, get);
richman_event[109404] = P({109404,1094,2,false,S({1,50,})}, get);
richman_event[109405] = P({109405,1094,3,2,S({})}, get);
richman_event[109406] = P({109406,1094,4,2,S({1,})}, get);
richman_event[124601] = P({D[3004], 124601,1246,S({1,200,})}, get);
richman_event[124602] = P({D[3004], 124602,1246,S({1,50,})}, get);
richman_event[124603] = P({124603,1246,2,false,S({1,200,})}, get);
richman_event[124604] = P({124604,1246,2,false,S({1,50,})}, get);
richman_event[124605] = P({124605,1246,3,2,S({})}, get);
richman_event[124606] = P({124606,1246,4,2,S({1,})}, get);
richman_event[24120101] = P({D[3004], 24120101,241201,S({1,200,})}, get);
richman_event[24120102] = P({D[3004], 24120102,241201,S({1,50,})}, get);
richman_event[24120103] = P({24120103,241201,2,false,S({1,200,})}, get);
richman_event[24120104] = P({24120104,241201,2,false,S({1,50,})}, get);
richman_event[24120105] = P({24120105,241201,3,2,S({})}, get);
richman_event[24120106] = P({24120106,241201,4,2,S({1,})}, get);
return { tb = richman_event };