-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][richman_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["map_id"] = 2; ["map_distance"] = 3; ["chest_id"] = 4; ["consume_item_id"] = 5; ["special_item_id"] = 6; ["step_bank_save"] = 7; ["finish_bank_save"] = 8; ["finish_reward_seq"] = 9; ["step_exp"] = 10; ["finish_exp"] = 11; ["item_worth_pool"] = 12; ["min_avg_worth"] = 13; ["max_avg_worth"] = 14; ["chest_pool_seq"] = 15;};

local df = {  nil, nil, 32, 60105, 309022, 309023, 200, 2000, 10101, 1, nil, 1064, 3000, 7600, 1003,};

local get = function(item, k) return G(item, k, n2i, df); end;


local richman_info = { }
richman_info[1064] = P({D[4012], 1064,106401,28,4550,9100}, get);
richman_info[1073] = P({D[4012], 1073,107301,28,4550,9100}, get);
richman_info[1094] = P({1094,109401}, get);
richman_info[1246] = P({D[3008], 1246,124601,0}, get);
richman_info[241201] = P({D[3008], 241201,24120101,0}, get);
return { tb = richman_info };