-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][richman_level]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["name"] = 1002; ["id"] = 3; ["exp"] = 4; ["buff"] = 5;};

local df = {  1064, "天然呆", 1, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local richman_level = { }
richman_level[1064] = {
	P({}, get),
	P({false,"实习萌新",2,10,5}, get),
	P({false,"打工能手",3,30,10}, get),
	P({false,"优秀员工",4,60,30}, get),
	P({false,"招财猫",5,90,50}, get),
};
richman_level[1073] = {
	P({1073}, get),
	P({1073,"实习萌新",2,10,5}, get),
	P({1073,"打工能手",3,30,10}, get),
	P({1073,"优秀员工",4,60,30}, get),
	P({1073,"招财猫",5,90,50}, get),
};
richman_level[1094] = {
	P({1094,"好感度Lv1"}, get),
	P({1094,"好感度Lv2",2,15,5}, get),
	P({1094,"好感度Lv3",3,40,10}, get),
	P({1094,"好感度Lv4",4,75,30}, get),
	P({1094,"好感度LvMax",5,120,50}, get),
};
richman_level[1246] = {
	P({1246,"西园寺Lv1"}, get),
	P({1246,"西园寺Lv2",2,15,5}, get),
	P({1246,"西园寺Lv3",3,40,10}, get),
	P({1246,"西园寺Lv4",4,75,30}, get),
	P({1246,"西园寺LvMax",5,120,50}, get),
};
richman_level[241201] = {
	P({241201,"新人"}, get),
	P({241201,"游园向导",2,15,5}, get),
	P({241201,"游园高手",3,40,10}, get),
	P({241201,"摊主鬼见愁",4,75,30}, get),
	P({241201,"小游戏之王",5,120,50}, get),
};
return { tb = richman_level };