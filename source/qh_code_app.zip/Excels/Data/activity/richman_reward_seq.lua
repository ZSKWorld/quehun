-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][richman_reward_seq]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["count"] = 2; ["reward"] = 1003;};

local df = {  10101, nil, "309029-3",};

local get = function(item, k) return G(item, k, n2i, df); end;


local richman_reward_seq = { }
richman_reward_seq[10101] = {
	P({false,1}, get),
	P({false,2}, get),
	P({false,3}, get),
	P({false,4}, get),
	P({false,5}, get),
	P({false,6}, get),
	P({false,7}, get),
	P({false,8}, get),
	P({false,9}, get),
	P({false,10}, get),
	P({false,11}, get),
	P({false,12}, get),
	P({false,13}, get),
	P({false,14}, get),
	P({false,15}, get),
	P({false,16}, get),
};
return { tb = richman_reward_seq };