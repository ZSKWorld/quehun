-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][rpg_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["base_hp"] = 2; ["base_atk"] = 3; ["base_dex"] = 4; ["base_luk"] = 5; ["ds_atk"] = 6; ["special_heal"] = 7; ["chain_atk"] = 8; ["monster_group"] = 9; ["sanma_debuff"] = 10; ["has_robot"] = 11; ["category"] = 1012; ["mode"] = 1013; ["room"] = 1014; ["daily_limit"] = 15;};

local df = {  nil, nil, nil, nil, nil, nil, nil, 100, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local rpg_activity = { }
rpg_activity[1206] = P({1206,100,100,0,0,0,0,S({100,100,100,100,100,100,}),120601,3,1,"2","1,2,11,12","2,3,4,6,323",15}, get);
return { tb = rpg_activity };