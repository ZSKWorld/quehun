-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][rpg_v2_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["base_atk"] = 2; ["monster_group"] = 3; ["sanma_debuff"] = 4; ["special_debuff"] = 5; ["has_robot"] = 6; ["category"] = 1007; ["mode"] = 1008; ["room"] = 1009; ["daily_limit"] = 10; ["mail_template_id"] = 11;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local rpg_v2_activity = { }
rpg_v2_activity[220811] = P({220811,100,22081101,3,3,0,"0","0","0",9,109}, get);
return { tb = rpg_v2_activity };