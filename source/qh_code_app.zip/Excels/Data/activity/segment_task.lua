-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][segment_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["base_task_id"] = 3; ["max_finish_count"] = 4; ["reward"] = 1005; ["interval"] = 6;};

local df = {  nil, 1261, 21500, 1, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local segment_task = { }
segment_task[126101] = P({126101,false,21196,false,"309047-2"}, get);
segment_task[126102] = P({126102,false,21197,false,"309047-3"}, get);
segment_task[126103] = P({126103,false,21198,10,"309047-1"}, get);
segment_task[22082201] = P({22082201,220822,false,5,"309065-1",0}, get);
segment_task[23010301] = P({23010301,230103,21700,20,"309069-1"}, get);
segment_task[23091101] = P({23091101,230911,false,4,"30900003-1",0}, get);
return { tb = segment_task };