-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][simulation_activity_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["stamina_item_id"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local simulation_activity_info = { }
simulation_activity_info[230801] = P({230801,309076}, get);
return { tb = simulation_activity_info };