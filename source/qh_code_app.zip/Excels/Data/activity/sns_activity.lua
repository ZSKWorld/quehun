-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][sns_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["disable"] = 2; ["pm"] = 3; ["period"] = 4; ["activity_id"] = 5; ["content_str_id"] = 6; ["parent_id"] = 7; ["char_id"] = 8; ["char_str_id"] = 9; ["reply_char_id"] = 10; ["reply_char_str_id"] = 11; ["choice_id"] = 12; ["like"] = 13; ["unlock_time"] = 1014; ["type"] = 15; ["content_head"] = 1016; ["content_image"] = 1017; ["unlock_item_id"] = 18; ["unlock_item_count"] = 19;};

local df = {  nil, nil, nil, nil, 251213, 426, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1001,1905,12050804,12220311,12440310,12441602,22110407,22170413,22920109,23050211,23051303,23070604,23071505,23100304,23101009,23102006,23120908,23121801,24060112,24061104,24062101,25086064,25086170,25121339,25121464,25121589,25121663,}

local sns_activity = { }
return { tb = sns_activity, get = get, b2i = b2i };