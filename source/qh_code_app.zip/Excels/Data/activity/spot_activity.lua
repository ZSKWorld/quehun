-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][spot_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["unique_id"] = 1; ["activity_id"] = 2; ["dep"] = 3; ["limit_day"] = 4; ["unlock_task_id"] = 5; ["unlock_task_activity_id"] = 6; ["spot_group"] = 7; ["unlock_spot_item"] = 1008; ["content_path"] = 1009; ["title"] = 10; ["subtitle_title"] = 11; ["unlock_item"] = 1012; ["unlock_by_ending_id"] = 13; ["unlock_ending_id"] = 1014; ["ending_id"] = 15; ["ending_res"] = 1016; ["ending_id_dep"] = 17; ["reward"] = 1018;};

local df = {  nil, 240604, nil, 1, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local spot_activity = { }
spot_activity[22082101] = P({D[5008], 22082101,220821,false,0,"event/220801",false,false,"309065-1",false,S({}),S({22080101,22080102,}),false,S({0,0,}),"100002-8888"}, get);
spot_activity[22082102] = P({D[4008], 22082102,220821,22082101,"event/220802",false,false,"309065-1",false,S({}),S({22080201,22080202,}),false,S({0,0,}),"100002-12888"}, get);
spot_activity[22082103] = P({D[5008], 22082103,220821,22082102,2,"event/220803",false,false,"309065-1",false,S({}),S({22080301,22080302,}),false,S({22080201,22080202,}),"100002-16888"}, get);
spot_activity[22082104] = P({D[5008], 22082104,220821,22082103,3,"event/220804",false,false,"309065-1",false,S({}),S({22080401,22080402,}),false,S({22080301,22080302,}),"304005-1"}, get);
spot_activity[22082105] = P({D[5008], 22082105,220821,22082104,4,"event/220805",false,false,"309065-1",false,S({}),S({22080501,22080502,}),false,S({22080401,22080402,}),"304006-1"}, get);
spot_activity[23091001] = P({D[10013], 23091001,230910,false,0,false,false,100,false,"event/23091401",S({"23091002,23091004,23091006,23091008","23091003,23091005,23091007,23091009",}),S({230914011,230914012,}),false,S({})}, get);
spot_activity[23091002] = P({D[4006], 23091002,230910,23091001,101,"30900003-1","event/23091402",false,false,false,230914011,S({}),S({}),false,S({})}, get);
spot_activity[23091003] = P({D[4006], 23091003,230910,23091001,101,"30900003-1","event/23091406",false,false,false,230914012,S({}),S({}),false,S({})}, get);
spot_activity[23091004] = P({D[10013], 23091004,230910,23091002,2,false,false,102,"30900003-1","event/23091403",S({}),S({}),false,S({})}, get);
spot_activity[23091005] = P({D[10013], 23091005,230910,23091003,2,false,false,102,"30900003-1","event/23091407",S({}),S({}),false,S({})}, get);
spot_activity[23091006] = P({D[10013], 23091006,230910,23091004,3,false,false,103,"30900003-1","event/23091404",S({}),S({}),false,S({})}, get);
spot_activity[23091007] = P({D[10013], 23091007,230910,23091005,3,false,false,103,"30900003-1","event/23091408",S({}),S({}),false,S({})}, get);
spot_activity[23091008] = P({D[10013], 23091008,230910,23091006,4,false,false,104,"30900003-1","event/23091405",S({}),S({}),false,S({})}, get);
spot_activity[23091009] = P({D[10013], 23091009,230910,23091007,4,false,false,104,"30900003-1","event/23091409",S({}),S({}),false,S({})}, get);
spot_activity[24060401] = P({D[5008], 24060401,false,false,0,"event/haidao0",2682,false,false,false,S({}),S({24060001,}),"plot_plot_diagram_11.jpg",S({})}, get);
spot_activity[24060402] = P({D[2008], 24060402,"event/haidao01",2683,false,false,false,S({}),S({24060101,}),"plot_plot_diagram_1.jpg",S({}),"30900030-1"}, get);
spot_activity[24060403] = P({D[5008], 24060403,false,false,2,"event/haidao02",2700,false,false,false,S({}),S({24060201,}),"plot_plot_diagram_2.jpg",S({}),"30900031-1"}, get);
spot_activity[24060404] = P({D[5008], 24060404,false,false,4,"event/haidao03",2701,false,false,false,S({}),S({24060301,}),"plot_plot_diagram_10.jpg",S({}),"30900032-1"}, get);
spot_activity[24060405] = P({D[5008], 24060405,false,false,6,"event/haidao04",2702,false,false,false,S({}),S({24060401,24060402,}),"plot_plot_diagram_3.jpg",S({}),"30900033-1,30900041-1"}, get);
spot_activity[24060406] = P({D[5008], 24060406,false,false,8,"event/haidao05",2703,false,false,false,S({}),S({24060502,24060501,}),"plot_plot_diagram_4.jpg",S({}),"30900038-1,30900039-1"}, get);
spot_activity[24060407] = P({D[5008], 24060407,false,false,10,"event/haidao06",2704,false,false,false,S({}),S({24060601,}),"plot_plot_diagram_7.jpg",S({}),"30900036-1"}, get);
spot_activity[24060408] = P({D[5008], 24060408,false,false,12,"event/haidao07",2705,false,false,false,S({}),S({24060702,24060701,}),"plot_plot_diagram_8.jpg",S({}),"30900037-1"}, get);
spot_activity[24060409] = P({D[5008], 24060409,false,false,14,"event/haidao08",2706,false,false,false,S({}),S({24060801,24060802,24060803,}),"plot_plot_diagram_9.jpg",S({}),"30900040-1"}, get);
spot_activity[24060410] = P({D[5008], 24060410,false,false,16,"event/haidao09",2707,false,false,false,S({}),S({24060901,}),"plot_plot_diagram_5.jpg",S({}),"30900034-1"}, get);
spot_activity[24060411] = P({D[5008], 24060411,false,false,18,"event/haidao10",2708,false,false,false,S({}),S({24061001,}),"plot_plot_diagram_6.jpg",S({}),"30900035-1"}, get);
spot_activity[24060412] = P({D[5008], 24060412,false,false,20,"event/haidao11",2709,false,false,false,S({}),S({24061101,}),"plot_plot_diagram_12.jpg",S({})}, get);
return { tb = spot_activity };