-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][story_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["story_id"] = 2; ["unlock_day"] = 3; ["unlock_item"] = 1004; ["unlock_story"] = 1005; ["unlock_ending"] = 1006; ["unlock_consume"] = 1007; ["finish_reward"] = 1008; ["all_finish_reward"] = 1009; ["content_path"] = 1010; ["title"] = 11; ["subtitle_title"] = 12;};

local df = {  240811, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local story_activity = { }
story_activity[240811] = {
	P({D[5009], false,24081101,false,"30900075-1,30900076-1","event/ZYQDmujian"}, get),
	P({D[5009], false,24081102,false,"30900045-12","event/ZYQDdaochu"}, get),
	P({D[5007], false,24081111,false,"30900054-1","30900045-1",false,"event/ZYQDzongci01",3020}, get),
	P({D[6007], false,24081112,false,"30900054-1","24081111","30900045-1",false,"event/ZYQDzongci02",3021}, get),
	P({D[6007], false,24081113,false,"30900054-1","24081112","30900045-1,30900075-1",false,"event/ZYQDzongci03",3022}, get),
	P({D[5007], false,24081121,25,"30900055-1","30900045-1",false,"event/ZYQDpaimaihang01",3023}, get),
	P({D[6007], false,24081122,25,"30900055-1","24081121","30900045-1",false,"event/ZYQDpaimaihang02",3024}, get),
	P({D[6007], false,24081123,25,"30900055-1","24081122","30900045-1,30900076-1",false,"event/ZYQDpaimaihang03",3025}, get),
	P({D[5007], false,24081131,64,"30900056-1","30900045-1",false,"event/ZYQDchalou01",3026}, get),
	P({D[6007], false,24081132,64,"30900056-1","24081131","30900045-1",false,"event/ZYQDchalou02",3027}, get),
	P({D[6007], false,24081133,64,"30900056-1","24081132","30900045-1",false,"event/ZYQDchalou03",3028}, get),
	P({D[5007], false,24081141,112,"30900057-1","30900045-1",false,"event/ZYQDzhuyun01",3029}, get),
	P({D[6007], false,24081142,112,"30900057-1","24081141","30900045-1",false,"event/ZYQDzhuyun02",3030}, get),
	P({D[6007], false,24081143,112,"30900057-1","24081142","30900045-1",false,"event/ZYQDzhuyun03",3031}, get),
};
story_activity[241107] = {
	P({D[3009], 241107,24110710,"event/SC01",3086}, get),
	P({D[4009], 241107,24110720,3,"event/SC02",3087}, get),
	P({D[4009], 241107,24110730,6,"event/SC03",3088}, get),
	P({D[4009], 241107,24110740,9,"event/SC04",3089}, get),
};
story_activity[250405] = {
	P({D[3009], 250405,2504051,"event/fate01",25040501,25040511}, get),
	P({D[4009], 250405,2504052,2,"event/fate02",25040502,25040512}, get),
	P({D[4009], 250405,2504053,4,"event/fate03",25040503,25040513}, get),
	P({D[4009], 250405,2504054,6,"event/fate04",25040504,25040514}, get),
	P({D[4009], 250405,2504055,8,"event/fate05",25040505,25040515}, get),
};
story_activity[251004] = {
	P({D[3009], 251004,2510041,"event/yinhun01",25103001}, get),
	P({D[4009], 251004,2510042,2,"event/yinhun02",25103002}, get),
	P({D[4009], 251004,2510043,4,"event/yinhun03",25103003}, get),
	P({D[4009], 251004,2510044,6,"event/yinhun04",25103004}, get),
	P({D[4009], 251004,2510045,8,"event/yinhun05",25103005}, get),
};
story_activity[260205] = {
	P({D[3009], 260205,2602051,"event/shenchijiyuan01",26022031}, get),
	P({D[3009], 260205,2602052,"event/shenchijiyuan02",26022032}, get),
};
story_activity[260407] = {
	P({D[3009], 260407,2604071,"event/SAO01",26042001}, get),
	P({D[6009], 260407,2604072,2,false,"2604071","event/SAO02",26042002}, get),
	P({D[6009], 260407,2604073,4,false,"2604072","event/SAO03",26042003}, get),
	P({D[6009], 260407,2604074,6,false,"2604073","event/SAO04",26042004}, get),
	P({D[6009], 260407,2604075,8,false,"2604074","event/SAO05",26042005}, get),
	P({D[6009], 260407,2604076,10,false,"2604075","event/SAO06",26042006}, get),
	P({D[6009], 260407,2604077,10,false,"2604071,2604072,2604073,2604074,2604075,2604076","event/SAO07",26042007}, get),
};
story_activity[260670] = {
	P({D[3009], 260670,2606701,"event/akagi00",26062001,26062003}, get),
	P({D[6009], 260670,2606702,7,false,"2606701","event/akagi01",26062002,26062004}, get),
};
return { tb = story_activity };