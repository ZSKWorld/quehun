-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][story_ending]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["story_id"] = 1; ["ending_id"] = 2; ["unlock_day"] = 3; ["unlock_item"] = 1004; ["unlock_story"] = 1005; ["unlock_ending"] = 1006; ["unlock_consume"] = 1007; ["reward"] = 1008;};

local df = {  24081102, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local story_ending = { }
story_ending[2504051] = {
	P({2504051,25040511}, get),
};
story_ending[2504052] = {
	P({2504052,25040521}, get),
};
story_ending[2504053] = {
	P({2504053,25040531}, get),
};
story_ending[2504054] = {
	P({2504054,25040541}, get),
};
story_ending[2504055] = {
	P({2504055,25040551}, get),
};
story_ending[2510041] = {
	P({2510041,25100411}, get),
};
story_ending[2510042] = {
	P({2510042,25100421}, get),
};
story_ending[2510043] = {
	P({2510043,25100431}, get),
};
story_ending[2510044] = {
	P({2510044,25100441}, get),
};
story_ending[2510045] = {
	P({2510045,25100451}, get),
};
story_ending[2602051] = {
	P({2602051,26020511}, get),
};
story_ending[2602052] = {
	P({2602052,26020521}, get),
};
story_ending[2604071] = {
	P({2604071,26040711}, get),
};
story_ending[2604072] = {
	P({2604072,26040721}, get),
};
story_ending[2604073] = {
	P({2604073,26040731}, get),
};
story_ending[2604074] = {
	P({2604074,26040741}, get),
};
story_ending[2604075] = {
	P({2604075,26040751}, get),
};
story_ending[2604076] = {
	P({2604076,26040761}, get),
};
story_ending[2604077] = {
	P({2604077,26040771}, get),
};
story_ending[2606701] = {
	P({2606701,26067011}, get),
};
story_ending[2606702] = {
	P({2606702,26067021}, get),
};
story_ending[24081101] = {
	P({24081101,24080001}, get),
};
story_ending[24081102] = {
	P({false,24080002}, get),
	P({false,24080003}, get),
};
story_ending[24081111] = {
	P({24081111,24080111}, get),
};
story_ending[24081112] = {
	P({24081112,24080121}, get),
};
story_ending[24081113] = {
	P({D[3007], 24081113,24080131,"30900046-1"}, get),
	P({D[3007], 24081113,24080132,"30900047-1"}, get),
};
story_ending[24081121] = {
	P({24081121,24080211}, get),
};
story_ending[24081122] = {
	P({24081122,24080221}, get),
};
story_ending[24081123] = {
	P({D[3007], 24081123,24080231,"30900049-1"}, get),
	P({D[3007], 24081123,24080232,"30900048-1"}, get),
};
story_ending[24081131] = {
	P({24081131,24080311}, get),
};
story_ending[24081132] = {
	P({24081132,24080321}, get),
};
story_ending[24081133] = {
	P({D[3007], 24081133,24080331,"30900051-1"}, get),
	P({D[3007], 24081133,24080332,"30900050-1"}, get),
};
story_ending[24081141] = {
	P({24081141,24080411}, get),
};
story_ending[24081142] = {
	P({24081142,24080421}, get),
};
story_ending[24081143] = {
	P({D[3007], 24081143,24080431,"30900052-1"}, get),
	P({D[3007], 24081143,24080432,"30900053-1"}, get),
};
story_ending[24110710] = {
	P({24110710,24110711}, get),
};
story_ending[24110720] = {
	P({24110720,24110721}, get),
};
story_ending[24110730] = {
	P({24110730,24110731}, get),
};
story_ending[24110740] = {
	P({24110740,24110741}, get),
};
return { tb = story_ending };