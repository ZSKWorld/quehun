-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][summer_story]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["id"] = 2; ["story_name"] = 3; ["building"] = 4; ["building_name"] = 5; ["exchange_activity"] = 6; ["building_unlock"] = 7; ["story_unlock"] = 1008; ["story_id"] = 1009; ["story_desc"] = 10; ["show_character"] = 1011;};

local df = {  240811, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local summer_story = { }
summer_story[240811] = {
	P({D[4008], false,1,3042,"",3035,"409501"}, get),
	P({false,2,3043,1,3049,240814,30900054,false,"24081111,24081112,24081113",3036}, get),
	P({false,3,3044,4,3050,240815,30900055,false,"24081121,24081122,24081123",3037}, get),
	P({false,4,3045,3,3051,240816,30900056,false,"24081131,24081132,24081133",3038}, get),
	P({false,5,3046,2,3052,240817,30900057,false,"24081141,24081142,24081143",3039}, get),
	P({D[4007], false,6,3047,"30900075-1,30900076-1","24081101",3040,"409501"}, get),
	P({D[4007], false,7,3048,"30900045-12","24081102",3041}, get),
};
return { tb = summer_story };