-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][summer_story_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["period_task_id"] = 2; ["building_icon"] = 1003; ["click_notice"] = 4;};

local df = {  240811, nil, "1", nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local summer_story_reward = { }
summer_story_reward[240811] = {
	P({false,24081201,false,3077}, get),
	P({false,24081202,false,3078}, get),
	P({false,24081203,"4",3079}, get),
	P({false,24081204,"4",3080}, get),
	P({false,24081205,"3",3081}, get),
	P({false,24081206,"3",3082}, get),
	P({false,24081207,"2",3083}, get),
	P({false,24081208,"2",3084}, get),
};
return { tb = summer_story_reward };