-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["day"] = 3; ["base_task_id"] = 4; ["reward_id"] = 5; ["reward_count"] = 6; ["hidden_reward"] = 1007; ["limit_id"] = 8; ["deprecated"] = 9;};

local df = {  nil, 240602, nil, 20001, 30900015, 3, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1084014,1240012,23020104,24010249,25020113,26030142,}

local task = { }
return { tb = task, get = get, b2i = b2i };