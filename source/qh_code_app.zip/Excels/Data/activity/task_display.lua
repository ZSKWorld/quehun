-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][task_display]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["day"] = 2; ["task_serial_number"] = 3; ["task_type"] = 4; ["period_task_id"] = 5; ["answer"] = 6; ["right_str"] = 7; ["wrong_str"] = 8;};

local df = {  230601, 1, 1, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local task_display = { }
task_display[230601] = {
	P({D[1002], 0,999,23060122}, get),
	P({D[1003], 1,23060101,1,7004,7035}, get),
	P({D[1002], 2,false,23060108}, get),
	P({D[1002], 3,false,23060115}, get),
	P({false,2,false,1,23060102,3,7009,7035}, get),
	P({false,2,2,false,23060109}, get),
	P({false,2,3,false,23060116}, get),
	P({false,3,false,1,23060103,1,7014,7035}, get),
	P({false,3,2,false,23060110}, get),
	P({false,3,3,false,23060117}, get),
	P({false,4,false,1,23060104,2,7019,7035}, get),
	P({false,4,2,false,23060111}, get),
	P({false,4,3,false,23060118}, get),
	P({false,5,false,1,23060105,3,7024,7035}, get),
	P({false,5,2,false,23060112}, get),
	P({false,5,3,false,23060119}, get),
	P({false,6,false,1,23060106,1,7029,7035}, get),
	P({false,6,2,false,23060113}, get),
	P({false,6,3,false,23060120}, get),
	P({false,7,false,1,23060107,2,7034,7035}, get),
	P({false,7,2,false,23060114}, get),
	P({false,7,3,false,23060121}, get),
};
return { tb = task_display };