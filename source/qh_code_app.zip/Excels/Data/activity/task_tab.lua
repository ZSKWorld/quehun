-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][task_tab]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["activity_id"] = 2; ["tab_id"] = 3;};

local df = {  nil, 260403, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local task_tab = { }
task_tab[26040301] = P({26040301}, get);
task_tab[26040302] = P({26040302}, get);
task_tab[26040303] = P({26040303}, get);
task_tab[26040304] = P({26040304}, get);
task_tab[26040305] = P({26040305}, get);
task_tab[26040306] = P({26040306}, get);
task_tab[26040307] = P({26040307}, get);
task_tab[26040308] = P({26040308}, get);
task_tab[26040309] = P({26040309}, get);
task_tab[26040310] = P({26040310}, get);
task_tab[26040311] = P({26040311}, get);
task_tab[26040312] = P({26040312}, get);
task_tab[26040313] = P({26040313}, get);
task_tab[26040314] = P({26040314}, get);
task_tab[26040315] = P({26040315}, get);
task_tab[26040316] = P({26040316}, get);
task_tab[26040317] = P({26040317}, get);
task_tab[26040318] = P({26040318}, get);
task_tab[26040319] = P({26040319}, get);
task_tab[26040320] = P({26040320}, get);
task_tab[26040321] = P({26040321,false,2}, get);
task_tab[26040322] = P({26040322,false,2}, get);
task_tab[26040323] = P({26040323,false,2}, get);
task_tab[26040324] = P({26040324,false,2}, get);
task_tab[26040325] = P({26040325,false,2}, get);
task_tab[26040326] = P({26040326,false,2}, get);
task_tab[26040327] = P({26040327,false,2}, get);
task_tab[26040328] = P({26040328,false,2}, get);
task_tab[26040329] = P({26040329,false,2}, get);
task_tab[26040330] = P({26040330,false,2}, get);
task_tab[26040331] = P({26040331,false,2}, get);
task_tab[26040332] = P({26040332,false,2}, get);
task_tab[26040333] = P({26040333,false,2}, get);
task_tab[26040334] = P({26040334,false,2}, get);
task_tab[26040335] = P({26040335,false,3}, get);
task_tab[26040336] = P({26040336,false,3}, get);
task_tab[26040337] = P({26040337,false,3}, get);
task_tab[26040338] = P({26040338,false,3}, get);
task_tab[26040339] = P({26040339,false,3}, get);
task_tab[26040340] = P({26040340,false,3}, get);
task_tab[26040341] = P({26040341,false,3}, get);
task_tab[26040342] = P({26040342,false,3}, get);
task_tab[26040343] = P({26040343,false,3}, get);
task_tab[26040344] = P({26040344,false,3}, get);
task_tab[26040345] = P({26040345,false,3}, get);
task_tab[26040346] = P({26040346,false,3}, get);
task_tab[26040347] = P({26040347,false,3}, get);
task_tab[26040348] = P({26040348,false,3}, get);
return { tb = task_tab };