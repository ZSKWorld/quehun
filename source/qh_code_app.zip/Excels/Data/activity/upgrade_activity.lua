-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][upgrade_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["mail_id"] = 2; ["consume_item"] = 1003; ["total_reward_id"] = 4; ["reward_id"] = 5;};

local df = {  nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local upgrade_activity = { }
upgrade_activity[230101] = P({230101,112,"309069-1",23010199,S({23010101,23010102,23010103,})}, get);
return { tb = upgrade_activity };