-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][upgrade_activity_display]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["display"] = 3;};

local df = {  23010101, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local upgrade_activity_display = { }
upgrade_activity_display[23010101] = {
	P({}, get),
	P({false,10,1}, get),
	P({false,20,2}, get),
	P({false,30,3}, get),
};
upgrade_activity_display[23010102] = {
	P({23010102}, get),
	P({23010102,10,1}, get),
	P({23010102,20,2}, get),
	P({23010102,30,3}, get),
};
upgrade_activity_display[23010103] = {
	P({23010103}, get),
	P({23010103,10,1}, get),
	P({23010103,20,2}, get),
	P({23010103,30,3}, get),
};
upgrade_activity_display[23010199] = {
	P({23010199}, get),
	P({23010199,60,1}, get),
	P({23010199,120,2}, get),
};
return { tb = upgrade_activity_display };