-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][upgrade_activity_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["reward"] = 1003; ["unlock_day"] = 4; ["highlight"] = 5;};

local df = {  23010199, 10, "304008-1", nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local upgrade_activity_reward = { }
upgrade_activity_reward[23010101] = {
	P({23010101,false,"100002-4000"}, get),
	P({23010101,20,"302005-1"}, get),
	P({23010101,30,"100002-8000"}, get),
	P({23010101,40}, get),
	P({23010101,50,"100002-12000"}, get),
	P({23010101,60}, get),
};
upgrade_activity_reward[23010102] = {
	P({23010102,false,"100002-4000"}, get),
	P({23010102,20,"302006-1"}, get),
	P({23010102,30,"100002-8000"}, get),
	P({23010102,40}, get),
	P({23010102,50,"100002-12000"}, get),
	P({23010102,60}, get),
};
upgrade_activity_reward[23010103] = {
	P({23010103,false,"100002-4000"}, get),
	P({23010103,20,"302007-1"}, get),
	P({23010103,30,"100002-8000"}, get),
	P({23010103,40}, get),
	P({23010103,50,"100002-12000"}, get),
	P({23010103,60}, get),
};
upgrade_activity_reward[23010199] = {
	P({D[1002], "309110-1"}, get),
	P({false,20,"307427-1"}, get),
	P({false,30,"100002-10000"}, get),
	P({false,40,"307428-1"}, get),
	P({false,50,"100002-10000"}, get),
	P({false,60,"304009-1"}, get),
	P({false,70,"100002-12000"}, get),
	P({false,80,"304009-1"}, get),
	P({false,90,"100002-12000"}, get),
	P({false,100,"302001-1",false,1}, get),
	P({false,110,"100002-15000"}, get),
	P({false,120,"304009-1"}, get),
	P({false,130,"100002-15000"}, get),
	P({false,140,"302001-1",false,1}, get),
	P({false,150,"100002-15000"}, get),
	P({false,160,"100002-15000"}, get),
	P({false,170,"100002-15000"}, get),
	P({false,180,"100002-15000"}, get),
};
return { tb = upgrade_activity_reward };