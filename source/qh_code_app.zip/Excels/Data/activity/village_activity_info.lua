-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][village_activity_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["worker_item_id"] = 2; ["round_consume"] = 1003; ["random_building"] = 1004; ["food_item_id"] = 5; ["trip_consume"] = 6; ["trip_cold_down"] = 7; ["trip_round"] = 8; ["trip_reward"] = 1009; ["stage_require"] = 1010;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local village_activity_info = { }
village_activity_info[240101] = P({240101,30900013,"30900015-1","300100,300200,300300",30900007,3,43200,3,S({"30900012-1","30900011-1","30900010-1",}),S({"30900014-0","30900014-40","30900014-70","30900014-100",})}, get);
return { tb = village_activity_info };