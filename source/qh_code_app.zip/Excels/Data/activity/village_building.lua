-- 由 Excel 自动生成的 Lua 表
-- 文件:   [activity][village_building]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["building_id"] = 2; ["initial"] = 3; ["building_name"] = 4; ["level"] = 5; ["next_level_id"] = 6; ["produce_item"] = 1007; ["base_produce"] = 1008; ["upgrade_item"] = 1009; ["max_worker_count"] = 10; ["upgrade_reward"] = 1011; ["building_stage"] = 12; ["worker_consume"] = 13; ["func"] = 1014; ["args"] = 15; ["type"] = 16;};

local df = {  240101, nil, nil, 4044, 1, nil, nil, nil, nil, nil, "30900014-1", nil, 1, "random", nil, 5001,};

local get = function(item, k) return G(item, k, n2i, df); end;


local village_building = { }
village_building[240101] = {
	P({D[12013], false,100101,1,4042,false,100102,"30900008-1",false,"30900009-2",1,"30900014-2","",false,1001}, get),
	P({D[12013], false,100102,false,4042,2,100103,"30900008-1",false,"30900009-7",2,"30900014-3","",false,1001}, get),
	P({D[12013], false,100103,false,4042,3,100104,"30900008-1",false,"30900009-14",3,"30900014-5","",false,1001}, get),
	P({D[8009], false,100104,false,4042,4,false,"30900008-1",4,"",false,false,"",false,1001}, get),
	P({D[10013], false,200100,1,4040,0,200101,"30900009-1",false,"30900008-1","",false,2001}, get),
	P({D[12013], false,200101,false,4040,false,200102,"30900009-1",false,"30900008-4",1,"30900014-2","",false,2001}, get),
	P({D[12013], false,200102,false,4040,2,200103,"30900009-1",false,"30900008-10",2,"30900014-3","",false,2001}, get),
	P({D[12013], false,200103,false,4040,3,200104,"30900009-1",false,"30900008-18",3,"30900014-5","",false,2001}, get),
	P({D[8009], false,200104,false,4040,4,false,"30900009-1",4,"",false,false,"",false,2001}, get),
	P({D[10015], false,300100,1,4047,0,300101,"30900012-1",false,"30900008-1,30900009-1",3001}, get),
	P({D[12015], false,300101,false,4047,false,300102,"30900012-1",false,"30900008-3,30900009-2",1,"30900014-2",3001}, get),
	P({D[12015], false,300102,false,4047,2,300103,"30900012-1",false,"30900008-7,30900009-8",2,"30900014-3",3001}, get),
	P({D[12015], false,300103,false,4047,3,300104,"30900012-1",false,"30900008-14,30900009-16",3,"30900014-5",3001}, get),
	P({D[12015], false,300104,false,4047,4,false,"30900012-1",false,false,4,"",3001}, get),
	P({D[10014], false,300200,1,4048,0,300201,"30900011-1",false,"30900008-1,30900009-1",1,3002}, get),
	P({D[12014], false,300201,false,4048,false,300202,"30900011-1",false,"30900008-3,30900009-2",1,"30900014-2",1,3002}, get),
	P({D[12014], false,300202,false,4048,2,300203,"30900011-1",false,"30900008-7,30900009-8",2,"30900014-3",1,3002}, get),
	P({D[12014], false,300203,false,4048,3,300204,"30900011-1",false,"30900008-14,30900009-16",3,"30900014-5",1,3002}, get),
	P({D[12014], false,300204,false,4048,4,false,"30900011-1",false,false,4,"",1,3002}, get),
	P({D[10014], false,300300,1,4049,0,300301,"30900010-1",false,"30900008-1,30900009-1",2,3003}, get),
	P({D[12014], false,300301,false,4049,false,300302,"30900010-1",false,"30900008-3,30900009-2",1,"30900014-2",2,3003}, get),
	P({D[12014], false,300302,false,4049,2,300303,"30900010-1",false,"30900008-7,30900009-8",2,"30900014-3",2,3003}, get),
	P({D[12014], false,300303,false,4049,3,300304,"30900010-1",false,"30900008-14,30900009-16",3,"30900014-5",2,3003}, get),
	P({D[12014], false,300304,false,4049,4,false,"30900010-1",false,false,4,"",2,3003}, get),
	P({D[12013], false,400101,1,4041,false,400102,"30900007-4","30900007-1","30900008-2,30900009-1",1,"30900014-2","",false,4001}, get),
	P({D[12013], false,400102,false,4041,2,400103,"30900007-4","30900007-1","30900008-6,30900009-2",2,"30900014-3","",false,4001}, get),
	P({D[12013], false,400103,false,4041,3,400104,"30900007-4","30900007-1","30900008-10,30900009-6",3,"30900014-5","",false,4001}, get),
	P({D[12013], false,400104,false,4041,4,false,"30900007-4","30900007-1",false,4,"","",false,4001}, get),
	P({D[4005], false,500101,1,500102,false,false,"30900008-2,30900009-1",false,false,1,0,"housing",3}, get),
	P({D[3004], false,500102,2,500103,false,false,"30900008-5,30900009-2",false,false,1,0,"housing",5}, get),
	P({D[3004], false,500103,3,500104,false,false,"30900008-7,30900009-5",false,false,2,0,"housing",7}, get),
	P({D[3004], false,500104,4,500105,false,false,"30900008-12,30900009-7",false,false,2,0,"housing",9}, get),
	P({D[3004], false,500105,5,500106,false,false,"30900008-11,30900009-15",false,false,3,0,"housing",11}, get),
	P({D[3004], false,500106,6,500107,false,false,"30900008-12,30900009-24",false,false,3,0,"housing",13}, get),
	P({D[3004], false,500107,7,500108,false,false,"30900008-18,30900009-28",false,false,4,0,"housing",15}, get),
	P({D[6010], false,500108,false,false,8,"",4,0,"housing",16}, get),
};
return { tb = village_building };