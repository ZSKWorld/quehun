-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["skill_item"] = 2; ["init_coin"] = 3; ["shop_count"] = 4; ["record_level_id"] = 5; ["record_level_node"] = 6; ["book_unlock_level_id"] = 7; ["book_unlock_level_node"] = 8; ["free_effect_goods_id"] = 9; ["shop_refresh_coin"] = 10; ["effect_max_count"] = 11; ["init_dora_indicator"] = 12; ["init_change_hand"] = 13; ["init_mount_count"] = 14; ["init_level"] = 15; ["advanced_shop_upgrade_count"] = 16;};

local df = {  nil, 30900044, 10, 2, 503, 1, 503, 1, 991, 5, 5, 1, 3, 10, 101, 3,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_activity = { }
amulet_activity[240801] = P({240801}, get);
amulet_activity[250111] = P({250111}, get);
amulet_activity[250811] = P({250811}, get);
amulet_activity[260511] = P({D[9014], 260511,false,false,false,11005,8,11005,8,11001}, get);
return { tb = amulet_activity };