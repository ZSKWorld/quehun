-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_advanced_shop]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["refresh_price_rate"] = 2; ["shop_refresh_coin"] = 3; ["effect_goods_pack"] = 4;};

local df = {  nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_advanced_shop = { }
amulet_advanced_shop[260511] = P({260511,150,5,981}, get);
return { tb = amulet_advanced_shop };