-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_advanced_shop_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["selection_desc"] = 3; ["price"] = 4; ["display_value"] = 5; ["args"] = 6;};

local df = {  nil, 4, 26055112, 10, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_advanced_shop_upgrade = { }
amulet_advanced_shop_upgrade[1] = P({1,1,S({26055101,26055112,}),15,false,S({10,})}, get);
amulet_advanced_shop_upgrade[2] = P({2,1,S({26055101,26055112,}),25,false,S({20,})}, get);
amulet_advanced_shop_upgrade[3] = P({3,1,S({26055101,26055112,}),35,false,S({30,})}, get);
amulet_advanced_shop_upgrade[4] = P({4,2,S({26055102,26055113,}),5,false,S({5,})}, get);
amulet_advanced_shop_upgrade[5] = P({D[4005], 5,2,S({26055102,26055113,}),S({8,})}, get);
amulet_advanced_shop_upgrade[6] = P({6,2,S({26055102,26055113,}),15,false,S({13,})}, get);
amulet_advanced_shop_upgrade[7] = P({7,3,S({26055103,26055113,}),5,false,S({5,})}, get);
amulet_advanced_shop_upgrade[8] = P({D[4005], 8,3,S({26055103,26055113,}),S({8,})}, get);
amulet_advanced_shop_upgrade[9] = P({9,3,S({26055103,26055113,}),15,false,S({13,})}, get);
amulet_advanced_shop_upgrade[10] = P({D[4005], 10,false,S({26055104,26055112,}),S({0,50,})}, get);
amulet_advanced_shop_upgrade[11] = P({D[4005], 11,false,S({26055104,26055112,}),S({1,10,})}, get);
amulet_advanced_shop_upgrade[12] = P({D[4005], 12,false,S({26055104,26055112,}),S({2,10,})}, get);
amulet_advanced_shop_upgrade[13] = P({D[4005], 13,false,S({26055104,26055112,}),S({3,15,})}, get);
amulet_advanced_shop_upgrade[14] = P({14,5,S({26055105,26055112,}),15,false,S({1,})}, get);
amulet_advanced_shop_upgrade[15] = P({15,5,S({26055105,26055112,}),50,false,S({3,})}, get);
amulet_advanced_shop_upgrade[16] = P({16,6,S({26055106,26055113,}),5,false,S({12,5,})}, get);
amulet_advanced_shop_upgrade[17] = P({17,6,S({26055106,26055113,}),5,false,S({29,5,})}, get);
amulet_advanced_shop_upgrade[18] = P({18,6,S({26055106,26055113,}),5,false,S({49,8,})}, get);
amulet_advanced_shop_upgrade[19] = P({19,7,S({26055107,26055111,}),25,false,S({600290,})}, get);
amulet_advanced_shop_upgrade[20] = P({20,7,S({26055107,26055111,}),25,false,S({600310,})}, get);
return { tb = amulet_advanced_shop_upgrade };