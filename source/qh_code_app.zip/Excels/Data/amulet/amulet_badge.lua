-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_badge]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["deprecated"] = 2; ["coverable"] = 3; ["weight"] = 4; ["rarity"] = 5; ["volume"] = 6; ["badge_name"] = 7; ["badge_desc"] = 8; ["badge_image"] = 1009; ["args"] = 10;};

local df = {  nil, nil, 1, 100, 2, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_badge = { }
amulet_badge[600010] = P({D[2004], 600010,1,false,25083001,25083051,"badge_600010",S({150,5,50,5,})}, get);
amulet_badge[600020] = P({D[2004], 600020,1,false,25083002,25083052,"badge_600020",S({8,})}, get);
amulet_badge[600030] = P({D[2004], 600030,1,false,25083003,25083053,"badge_600030",S({3,})}, get);
amulet_badge[600040] = P({D[2004], 600040,1,false,25083004,25083054,"badge_600040",S({3,})}, get);
amulet_badge[600050] = P({D[2004], 600050,1,false,25083005,25083055,"badge_600050",S({200,})}, get);
amulet_badge[600060] = P({D[2004], 600060,1,false,25083006,25083056,"badge_600060",S({100,})}, get);
amulet_badge[600070] = P({D[2004], 600070,1,false,25083007,25083057,"badge_600070",S({300,200,})}, get);
amulet_badge[600080] = P({D[2006], 600080,25083008,25083058,"badge_600080",S({1,})}, get);
amulet_badge[600090] = P({D[2006], 600090,25083009,25083059,"badge_600090",S({3,})}, get);
amulet_badge[600100] = P({D[5006], 600100,1,false,20,25083010,25083060,"badge_600100",S({})}, get);
amulet_badge[600110] = P({D[2006], 600110,25083011,25083061,"badge_600110",S({})}, get);
amulet_badge[600120] = P({D[2006], 600120,25083012,25083062,"badge_600120",S({1,})}, get);
amulet_badge[600130] = P({D[2006], 600130,25083013,25083063,"badge_600130",S({33,2,})}, get);
amulet_badge[600140] = P({D[2006], 600140,25083014,25083064,"badge_600140",S({5,})}, get);
amulet_badge[600150] = P({D[2006], 600150,25083015,25083065,"badge_600150",S({500,})}, get);
amulet_badge[600160] = P({D[2004], 600160,3,1,25083016,25083066,"badge_600160",S({2,2,})}, get);
amulet_badge[600170] = P({D[3004], 600170,1,3,false,25083017,25083067,"badge_600170",S({})}, get);
amulet_badge[600180] = P({D[2004], 600180,3,false,25083018,25083068,"badge_600180",S({})}, get);
amulet_badge[600190] = P({D[2004], 600190,3,false,25083019,25083069,"badge_600190",S({})}, get);
amulet_badge[600200] = P({D[3004], 600200,1,3,false,25083020,25083070,"badge_600200",S({})}, get);
amulet_badge[600210] = P({600210,false,0,0,3,false,25083021,25083071,"badge_600210",S({})}, get);
amulet_badge[600220] = P({D[2004], 600220,1,false,26056001,26056101,"badge_600220",S({1,})}, get);
amulet_badge[600230] = P({D[2004], 600230,1,false,26056002,26056102,"badge_600230",S({500,})}, get);
amulet_badge[600240] = P({D[2004], 600240,1,false,26056003,26056103,"badge_600240",S({1,})}, get);
amulet_badge[600250] = P({D[2006], 600250,26056004,26056104,"badge_600250",S({3,})}, get);
amulet_badge[600260] = P({D[2006], 600260,26056005,26056105,"badge_600260",S({1,})}, get);
amulet_badge[600270] = P({D[2006], 600270,26056006,26056106,"badge_600270",S({1,0,})}, get);
amulet_badge[600280] = P({D[2006], 600280,26056007,26056107,"badge_600280",S({200,10,})}, get);
amulet_badge[600290] = P({D[2004], 600290,3,false,26056008,26056108,"badge_600290",S({1,})}, get);
amulet_badge[600300] = P({D[2004], 600300,3,false,26056009,26056109,"badge_600300",S({1,})}, get);
amulet_badge[600310] = P({D[2004], 600310,3,false,26056010,26056110,"badge_600310",S({1,2,})}, get);
return { tb = amulet_badge };