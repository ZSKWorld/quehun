-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_bonfire_selection]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["selection_id"] = 2; ["random"] = 3; ["type"] = 4; ["selection_name"] = 5; ["selection_desc"] = 6; ["selection_image"] = 1007; ["args"] = 8;};

local df = {  260511, nil, 2, 5, 26055515, 26055505, "gamble_selection_001", nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_bonfire_selection = { }
amulet_bonfire_selection[260511] = {
	P({false,1,1,1,26055511,26055501,"gamble_selection_003",S({40,})}, get),
	P({false,2,1,2,26055512,26055502,"gamble_selection_009",S({6,})}, get),
	P({false,3,false,3,26055513,26055503,"gamble_selection_007",S({})}, get),
	P({false,4,false,4,26055514,26055504,"gamble_selection_002",S({15,})}, get),
	P({D[3007], false,5,S({974,})}, get),
	P({D[3007], false,6,S({975,})}, get),
	P({D[3007], false,7,S({976,})}, get),
	P({false,8,false,6,26055516,26055506,false,S({972,})}, get),
	P({false,9,false,7,26055517,26055507,"gamble_selection_005",S({973,})}, get),
};
return { tb = amulet_bonfire_selection };