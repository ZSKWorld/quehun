-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_buff]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["deprecated"] = 3; ["common_weight"] = 4; ["ex_weight"] = 5; ["can_stack"] = 6; ["desc"] = 7; ["invalid_type"] = 8; ["args"] = 9;};

local df = {  nil, 1, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_buff = { }
amulet_buff[901] = P({D[2003], 901,50,100,1,5550,false,S({3,})}, get);
amulet_buff[902] = P({D[2003], 902,50,100,1,5551,false,S({-5,})}, get);
amulet_buff[903] = P({D[2004], 903,100,1,5552,false,S({3,})}, get);
amulet_buff[904] = P({D[2003], 904,100,false,1,5553,1,S({})}, get);
amulet_buff[905] = P({D[2003], 905,100,100,1,5554,2,S({})}, get);
amulet_buff[906] = P({D[2003], 906,100,100,1,5555,3,S({})}, get);
amulet_buff[907] = P({D[2003], 907,100,false,1,5556,false,S({2,-1,})}, get);
amulet_buff[908] = P({D[2003], 908,100,100,1,5557,false,S({1,})}, get);
amulet_buff[909] = P({D[2004], 909,100,1,5558,false,S({1,})}, get);
amulet_buff[910] = P({D[2003], 910,100,100,1,5559,false,S({3,})}, get);
amulet_buff[911] = P({D[2005], 911,1,5560,false,S({1,})}, get);
amulet_buff[912] = P({D[2003], 912,50,100,1,5561,false,S({3,})}, get);
amulet_buff[913] = P({D[2003], 913,50,100,1,5562,false,S({3,})}, get);
amulet_buff[914] = P({D[2004], 914,100,1,5563,false,S({1,})}, get);
amulet_buff[915] = P({D[2004], 915,100,1,5564,false,S({})}, get);
amulet_buff[916] = P({D[2004], 916,100,1,5565,false,S({3,})}, get);
amulet_buff[917] = P({D[2003], 917,100,100,1,5566,false,S({5,})}, get);
amulet_buff[918] = P({D[2003], 918,100,100,1,5567,false,S({})}, get);
amulet_buff[919] = P({D[2003], 919,100,100,1,5568,false,S({})}, get);
amulet_buff[920] = P({D[2003], 920,100,100,1,5569,false,S({})}, get);
amulet_buff[921] = P({D[2003], 921,100,100,1,5570,false,S({20,})}, get);
amulet_buff[922] = P({D[2003], 922,100,100,1,5571,false,S({1,})}, get);
amulet_buff[923] = P({D[2003], 923,100,100,1,5572,false,S({})}, get);
amulet_buff[924] = P({D[2003], 924,100,100,1,5573,false,S({})}, get);
amulet_buff[925] = P({D[2003], 925,100,100,1,5574,false,S({})}, get);
amulet_buff[926] = P({D[2003], 926,100,100,1,5575,false,S({50,})}, get);
amulet_buff[927] = P({D[2006], 927,5576,false,S({50,})}, get);
amulet_buff[928] = P({D[2006], 928,5577,false,S({200,})}, get);
amulet_buff[8001] = P({D[4008], 8001,2,1,S({})}, get);
amulet_buff[8002] = P({D[3008], 8002,2,S({})}, get);
amulet_buff[8003] = P({D[3008], 8003,2,S({})}, get);
amulet_buff[8004] = P({D[3008], 8004,2,S({})}, get);
amulet_buff[9010] = P({D[3008], 9010,3,S({0,})}, get);
amulet_buff[9011] = P({D[3008], 9011,3,S({5,})}, get);
amulet_buff[9012] = P({D[3008], 9012,3,S({10,})}, get);
amulet_buff[9013] = P({D[3008], 9013,3,S({15,})}, get);
amulet_buff[9020] = P({D[3008], 9020,3,S({0,})}, get);
amulet_buff[9021] = P({D[3008], 9021,3,S({1,})}, get);
amulet_buff[9022] = P({D[3008], 9022,3,S({2,})}, get);
amulet_buff[9023] = P({D[3008], 9023,3,S({3,})}, get);
amulet_buff[9030] = P({D[3008], 9030,3,S({80,19,1,})}, get);
amulet_buff[9031] = P({D[3008], 9031,3,S({75,22,3,})}, get);
amulet_buff[9032] = P({D[3008], 9032,3,S({70,25,5,})}, get);
amulet_buff[9033] = P({D[3008], 9033,3,S({65,27,8,})}, get);
amulet_buff[9040] = P({D[3008], 9040,3,S({5,})}, get);
amulet_buff[9041] = P({D[3008], 9041,3,S({3,})}, get);
amulet_buff[9042] = P({D[3008], 9042,3,S({2,})}, get);
amulet_buff[9043] = P({D[3008], 9043,3,S({1,})}, get);
amulet_buff[9050] = P({D[3008], 9050,3,S({0,})}, get);
amulet_buff[9051] = P({D[3008], 9051,3,S({1,})}, get);
amulet_buff[9052] = P({D[3008], 9052,3,S({2,})}, get);
amulet_buff[9053] = P({D[3008], 9053,3,S({3,})}, get);
amulet_buff[9060] = P({D[3008], 9060,3,S({0,})}, get);
amulet_buff[9061] = P({D[3008], 9061,3,S({1,})}, get);
amulet_buff[9062] = P({D[3008], 9062,3,S({2,})}, get);
return { tb = amulet_buff };