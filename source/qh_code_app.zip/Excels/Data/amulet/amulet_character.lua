-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["character_id"] = 2; ["hp"] = 3; ["tile_score_map_id"] = 4; ["reload_count"] = 5; ["effect_weight_id"] = 6; ["unlock_item_id"] = 7; ["init_desktop_count"] = 8; ["init_open_desktop_count"] = 9; ["init_tian_count"] = 10; ["character_name"] = 11;};

local df = {  260511, nil, nil, nil, 12, nil, nil, 36, 6, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_character = { }
amulet_character[260511] = {
	P({D[7010], false,201,120,20101,9,20111,26050001}, get),
	P({D[7009], false,202,80,20201,false,20211,3,26050002}, get),
	P({D[7008], false,203,50,20301,15,20311,9,false,26050003}, get),
	P({D[7010], false,204,100,20401,false,20411,26050004}, get),
};
return { tb = amulet_character };