-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_effect]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["book_enabled"] = 2; ["deprecated"] = 3; ["group"] = 1004; ["effect_group"] = 5; ["shop_badge"] = 6; ["duplicate_enabled"] = 7; ["upgrade"] = 8; ["rarity"] = 9; ["price"] = 10; ["can_sell"] = 11; ["sell_price"] = 12; ["name"] = 13; ["desc"] = 14; ["card_image"] = 1015; ["card_remark"] = 16; ["init_param_view"] = 17; ["args"] = 18; ["tag_id"] = 19;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, 4, 6, 1, 3, nil, nil, "fu_0001", nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {340,740,1330,1611,2191,3220,3510,3881,}

local amulet_effect = { }
return { tb = amulet_effect, get = get, b2i = b2i };