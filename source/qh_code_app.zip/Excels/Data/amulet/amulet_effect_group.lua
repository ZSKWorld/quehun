-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_effect_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["merge_card"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_effect_group = { }
amulet_effect_group[1] = P({1,1730}, get);
amulet_effect_group[2] = P({2,1740}, get);
return { tb = amulet_effect_group };