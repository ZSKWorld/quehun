-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_effect_weight]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["effect_id"] = 2;};

local df = {  20121, 3670,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_effect_weight = { }
amulet_effect_weight[20121] = {
	P({false,30}, get),
	P({false,50}, get),
	P({false,150}, get),
	P({false,1070}, get),
	P({false,1170}, get),
	P({false,1510}, get),
	P({false,1580}, get),
	P({false,1610}, get),
	P({false,1680}, get),
	P({false,2010}, get),
	P({false,3080}, get),
	P({false,3090}, get),
	P({false,3300}, get),
	P({false,3550}, get),
	P({}, get),
	P({false,3750}, get),
	P({false,550}, get),
	P({false,1020}, get),
	P({false,1560}, get),
	P({false,3180}, get),
	P({false,3190}, get),
	P({false,3430}, get),
	P({false,3440}, get),
	P({false,3450}, get),
	P({false,3460}, get),
	P({false,3470}, get),
	P({false,3530}, get),
	P({false,3610}, get),
	P({false,3690}, get),
	P({false,3700}, get),
	P({false,3710}, get),
};
amulet_effect_weight[20131] = {
	P({20131,90}, get),
	P({20131,200}, get),
	P({20131,420}, get),
	P({20131,680}, get),
	P({20131,1240}, get),
	P({20131,1300}, get),
	P({20131,2170}, get),
	P({20131,3300}, get),
	P({20131,3720}, get),
	P({20131,50}, get),
	P({20131,150}, get),
	P({20131,430}, get),
	P({20131,440}, get),
	P({20131,1620}, get),
	P({20131,3240}, get),
	P({20131}, get),
	P({20131,3780}, get),
};
amulet_effect_weight[20141] = {
	P({20141,1130}, get),
	P({20141,1180}, get),
	P({20141,1200}, get),
	P({20141,1250}, get),
	P({20141,1300}, get),
	P({20141,1610}, get),
	P({20141,1680}, get),
	P({20141,2190}, get),
	P({20141,3410}, get),
	P({20141,3420}, get),
	P({20141,3640}, get),
	P({20141}, get),
	P({20141,1010}, get),
	P({20141,1050}, get),
	P({20141,1080}, get),
	P({20141,1120}, get),
	P({20141,1500}, get),
	P({20141,1600}, get),
	P({20141,2020}, get),
	P({20141,2080}, get),
	P({20141,2120}, get),
	P({20141,2330}, get),
	P({20141,3110}, get),
	P({20141,3140}, get),
	P({20141,3210}, get),
	P({20141,3320}, get),
	P({20141,3490}, get),
	P({20141,3570}, get),
	P({20141,3720}, get),
	P({20141,3730}, get),
	P({20141,3760}, get),
};
return { tb = amulet_effect_weight };