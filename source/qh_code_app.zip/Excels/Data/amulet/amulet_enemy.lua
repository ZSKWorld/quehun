-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_enemy]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["boss_id"] = 2; ["hp"] = 1003; ["damage_tile_count"] = 4; ["atk"] = 5; ["skill_pool"] = 6; ["type"] = 7; ["group"] = 8; ["enemy_name"] = 9;};

local df = {  nil, 3012, "400", 4, 1, nil, 1, 3, 26050207,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_enemy = { }
amulet_enemy[3001] = P({3001,3001,"200",2,2,false,0,1,26050201}, get);
amulet_enemy[3002] = P({D[4006], 3002,3002,"200",0,1,26050202}, get);
amulet_enemy[3003] = P({D[5006], 3003,3003,false,3,0,1,26050203}, get);
amulet_enemy[3004] = P({3004,3004,"100",3,2,false,0,1,26050204}, get);
amulet_enemy[3005] = P({3005,3005,"200",3,2,false,0,1,26050205}, get);
amulet_enemy[3011] = P({3011,3011,"300",false,2,30111,false,2,26050206}, get);
amulet_enemy[3012] = P({D[2003], 3012,6,3,30121}, get);
amulet_enemy[3013] = P({D[4005], 3013,3013,"2000",30131,false,false,26050208}, get);
amulet_enemy[3014] = P({D[7008], 3014,3014,false,5,4,30141,26050209}, get);
amulet_enemy[3015] = P({D[7008], 3015,3015,"200",18,false,30151,26050210}, get);
amulet_enemy[3016] = P({D[7008], 3016,3016,false,5,4,30161,26050211}, get);
amulet_enemy[3017] = P({D[7008], 3017,3017,"1200",false,3,30171,26050212}, get);
amulet_enemy[3018] = P({D[7008], 3018,3018,false,5,4,30181,26050213}, get);
amulet_enemy[3019] = P({D[2003], 3019,12,3,30121,false,4}, get);
amulet_enemy[3020] = P({3020,3013,"2000",8,false,30131,false,4,26050208}, get);
amulet_enemy[3021] = P({3021,3014,false,10,4,30141,false,4,26050209}, get);
amulet_enemy[3022] = P({3022,3015,"200",36,false,30151,false,4,26050210}, get);
amulet_enemy[3023] = P({3023,3016,false,10,4,30161,false,4,26050211}, get);
amulet_enemy[3024] = P({3024,3017,"1200",8,3,30171,false,4,26050212}, get);
amulet_enemy[3025] = P({3025,3018,false,10,4,30181,false,4,26050213}, get);
return { tb = amulet_enemy };