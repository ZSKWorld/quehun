-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_enemy_skill]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["buff_id"] = 2;};

local df = {  30111, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_enemy_skill = { }
amulet_enemy_skill[30111] = {
	P({false,901}, get),
	P({false,902}, get),
	P({false,903}, get),
	P({false,904}, get),
	P({false,905}, get),
	P({false,906}, get),
	P({false,907}, get),
	P({false,908}, get),
	P({false,909}, get),
	P({false,910}, get),
	P({false,911}, get),
	P({false,912}, get),
	P({false,913}, get),
	P({false,914}, get),
	P({false,915}, get),
	P({false,916}, get),
	P({false,917}, get),
};
amulet_enemy_skill[30121] = {
	P({30121,918}, get),
	P({30121,919}, get),
	P({30121,920}, get),
};
amulet_enemy_skill[30131] = {
	P({30131,921}, get),
};
amulet_enemy_skill[30141] = {
	P({30141,922}, get),
};
amulet_enemy_skill[30151] = {
	P({30151,923}, get),
};
amulet_enemy_skill[30161] = {
	P({30161,924}, get),
};
amulet_enemy_skill[30171] = {
	P({30171,925}, get),
};
amulet_enemy_skill[30181] = {
	P({30181,926}, get),
};
return { tb = amulet_enemy_skill };