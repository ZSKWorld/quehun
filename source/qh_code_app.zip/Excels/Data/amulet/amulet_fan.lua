-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_fan]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["val"] = 2; ["yiman"] = 3; ["name"] = 4; ["desc"] = 5; ["type"] = 6; ["case"] = 1007;};

local df = {  nil, 1, nil, nil, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_fan = { }
amulet_fan[1] = P({D[2004], 1,26057301,false,"1m1m1m3p3p3p3s4s5s7s8s9s4z|4z"}, get);
amulet_fan[2] = P({D[2005], 2,0}, get);
amulet_fan[3] = P({D[2005], 3,0}, get);
amulet_fan[4] = P({D[2004], 4,26057302,false,"2p3p4p5p5p5p3s4s5s6s|8s8s8s8s|3s"}, get);
amulet_fan[5] = P({D[2004], 5,26057303,false,"2p2p2p4p5p6p3s3s3s9s9s9s1z|1z"}, get);
amulet_fan[6] = P({D[2005], 6,0}, get);
amulet_fan[7] = P({D[2004], 7,26057304,false,"3p3p3p4p5p6p6s7s8s9s5z5z5z|9s"}, get);
amulet_fan[8] = P({D[2004], 8,26057305,false,"3p3p3p4p5p6p6s7s8s9s6z6z6z|9s"}, get);
amulet_fan[9] = P({D[2004], 9,26057306,false,"3p3p3p4p5p6p6s7s8s9s7z7z7z|9s"}, get);
amulet_fan[10] = P({D[2004], 10,26057307,false,"3p3p3p4p5p6p6s7s8s9s2z2z2z|9s"}, get);
amulet_fan[11] = P({D[2004], 11,26057308,false,"3p3p3p4p5p6p6s7s8s9s1z1z1z|9s"}, get);
amulet_fan[12] = P({D[2004], 12,26057309,false,"2p3p4p5p6p7p3s3s3s4s5s6s8s|8s"}, get);
amulet_fan[13] = P({D[2004], 13,26057310,false,"1p1p2p2p3p3p4p4p4p7p8p9p3s|3s"}, get);
amulet_fan[14] = P({D[2004], 14,26057311,false,"1p2p3p5p6p7p2s3s4s6s7s9s9s|5s"}, get);
amulet_fan[15] = P({D[3004], 15,2,26057312,false,"1p2p3p7p8p9p1s2s3s1z1z6z6z|1z"}, get);
amulet_fan[16] = P({D[3004], 16,2,26057313,false,"1p1p1p1s2s3s4s5s6s7s8s1z1z|9s"}, get);
amulet_fan[17] = P({D[3005], 17,2,0}, get);
amulet_fan[18] = P({D[3005], 18,2,0}, get);
amulet_fan[19] = P({D[3004], 19,2,26057314,false,"1m1m1m1p1p1p1s1s1s5s6s7s7z|7z"}, get);
amulet_fan[20] = P({D[3004], 20,2,26057315,false,"5s6s7s7z|7z|1m1m1m1m|3p3p3p3p|3s3s3s3s"}, get);
amulet_fan[21] = P({D[3004], 21,2,26057316,false,"1m1m1m4p4p4p3s3s3s1z1z2z2z|1z"}, get);
amulet_fan[22] = P({D[3004], 22,2,26057317,false,"1m1m1m4p4p4p3s3s3s5s6s2z2z|7s"}, get);
amulet_fan[23] = P({D[3004], 23,2,26057318,false,"2s3s4s5p6p7p5z5z5z6z6z7z7z|6z"}, get);
amulet_fan[24] = P({D[3004], 24,2,26057319,false,"1m1m1m9m9m9m1p1p1p1s1s1z1z|1s"}, get);
amulet_fan[25] = P({D[3004], 25,2,26057320,false,"1m2p2p3p3p4p4p6p6p7s7s4z4z|1m"}, get);
amulet_fan[26] = P({D[3004], 26,3,26057321,false,"1m1p2p3p7p8p9p1s2s3s9s9s9s|1m"}, get);
amulet_fan[27] = P({D[3004], 27,3,26057322,false,"1p1p1p2p3p4p5p6p7p2z2z2z|5z5z"}, get);
amulet_fan[28] = P({D[3004], 28,3,26057323,false,"2p2p3p3p4p4p1s1s2s2s3s3s1z|1z"}, get);
amulet_fan[29] = P({D[3004], 29,6,26057324,false,"1p2p3p3p4p5p5p6p7p8p8p9p9p|8p"}, get);
amulet_fan[30] = P({D[2005], 30,0}, get);
amulet_fan[31] = P({D[2004], 31,26057325,4,"3sbbbb|4s"}, get);
amulet_fan[32] = P({D[2004], 32,26057326,4,"0p|0s"}, get);
amulet_fan[33] = P({D[2005], 33,0}, get);
amulet_fan[36] = P({36,13,1,false,26057327,false,"1p2p3p9p9p5s5s5s6s6s6s9s9s|9p"}, get);
amulet_fan[37] = P({37,13,1,false,26057328,false,"1p2p3p9s9s5z5z5z6z6z6z7z7z|7z"}, get);
amulet_fan[38] = P({38,13,1,false,26057329,false,"1p1p1p2p2p2p1s1s1s3s3s1z1z|3s"}, get);
amulet_fan[39] = P({39,13,1,false,26057330,false,"1z1z1z3z3z3z4z4z4z5z5z6z6z|5z"}, get);
amulet_fan[40] = P({40,13,1,false,26057331,false,"2s2s3s4s6s6s6s8s8s8s6z6z6z|2s"}, get);
amulet_fan[41] = P({41,13,1,false,26057332,false,"1m1m1m9m9m9m1p1p1p9p9p1s1s|9p"}, get);
amulet_fan[42] = P({42,13,1,false,26057333,false,"9m1p9p1s9s1z2z3z4z5z6z7z7z|1m"}, get);
amulet_fan[43] = P({43,13,1,false,26057334,false,"1z1z1z2z2z2z3z3z3z4z4z1p1p|1p"}, get);
amulet_fan[44] = P({44,13,1,false,26057335,false,"1z|2p2p2p2p|9p9p9p9p|3s3s3s3s|9s9s9s9s|1z"}, get);
amulet_fan[45] = P({45,13,1,false,26057336,false,"1p1p1p2p2p3p4p5p6p7p8p9p9p|9p"}, get);
amulet_fan[47] = P({47,26,1,false,26057337,false,"1s1s1s2s3s4s5s6s7s8s9s9s9s|5s"}, get);
amulet_fan[48] = P({48,26,1,false,26057338,false,"1m1m1m9m9m9m3p3p3p5p5p5p1z|1z"}, get);
amulet_fan[49] = P({49,26,1,false,26057339,false,"1m9m1p9p1s9s1z2z3z4z5z6z7z|1m"}, get);
amulet_fan[50] = P({50,26,1,false,26057340,false,"1s1z1z1z2z2z2z3z3z3z4z4z4z|1s"}, get);
amulet_fan[100] = P({D[2003], 100,5080,5090,4,"1m1m1m3p3p3p3s4s5s7s8s9s4z|4z"}, get);
amulet_fan[101] = P({D[2003], 101,5081,5091,4,"1m1m1m3p3p3p3s4s5s7s8s9s4z|4z"}, get);
amulet_fan[201] = P({D[2003], 201,26057241,26057341,2,"1m1m1m1p2p3p4p5p6p3z3z5z5z|3z"}, get);
amulet_fan[202] = P({D[2003], 202,26057242,26057342,2,"1m1m1m1p2p3p4p5p6p4z4z5z5z|4z"}, get);
amulet_fan[203] = P({D[2003], 203,26057243,26057343,2,"1m1m1m3p3p3p3s4s5s7s8s9s4z|4z"}, get);
amulet_fan[204] = P({204,2,false,26057244,26057344,2,"1m1m1m1s2s3s3s4s5s5s6s1z1z|7s"}, get);
amulet_fan[205] = P({205,2,false,26057245,26057345,2,"1p1p1p1p2p3p3s4s5s7s8s1z1z|9s"}, get);
amulet_fan[206] = P({206,2,false,26057246,26057346,2,"1p1p1p2p2p2p3p3p3p4s5s8s8s|6s"}, get);
amulet_fan[207] = P({207,4,false,26057247,26057347,2,"1m1m1m1p1p4p4p2s2s5s5s8s8s|1m"}, get);
amulet_fan[208] = P({208,5,false,26057248,26057348,2,"4p4p4p6s6s6s1z1z1z2z2z2z4z|4z"}, get);
amulet_fan[209] = P({209,5,false,26057249,26057349,2,"9m9m8p8p7s8s9s111222z|8p"}, get);
amulet_fan[210] = P({210,5,false,26057250,26057350,2,"4p4p5p5p4s5s6s111222z|5p"}, get);
amulet_fan[211] = P({211,5,false,26057251,26057351,2,"1m1m1p2p2s2s2s111222z|3p"}, get);
amulet_fan[212] = P({212,8,false,26057252,26057352,2,"5s6s7s8s1z1z1z2z2z2z3z3z3z|8s"}, get);
amulet_fan[213] = P({213,13,1,26057253,26057353,2,"1p2p3p3p4p5p5p6p7p7p8p11z|9p"}, get);
amulet_fan[214] = P({214,13,1,26057254,26057354,2,"1m1m2s3s4s4p5p6p1z1z1z5z5z|5z"}, get);
amulet_fan[215] = P({215,13,1,26057255,26057355,2,"1s1s2s2s3s3s4s4s5s5s6s7s7s|6s"}, get);
amulet_fan[216] = P({216,26,1,26057256,26057356,2,"1z1z2z2z3z3z4z4z5z5z6z7z7z|6z"}, get);
amulet_fan[217] = P({217,5,false,26057257,26057357,2,"4p4p5p5p6p1z1z1z2z2z2z3z3z|6p"}, get);
amulet_fan[218] = P({218,13,1,26057258,26057358,3,"1p2p3p4p5p8p9p2s4s5s8s9s5z|8p"}, get);
amulet_fan[219] = P({219,13,1,26057259,26057359,2,"1m2p5p8p3s9s1z2z3z4z5z6z7z|6s"}, get);
amulet_fan[220] = P({220,13,1,26057260,26057360,3,"1s2s3s4s5s6s7s8s9s1z2z3z4z|6s"}, get);
amulet_fan[221] = P({221,13,1,26057261,26057361,3,"1m1p3p5p7p9p1s3s5s7s9s9s9s|1s"}, get);
amulet_fan[222] = P({222,13,1,26057262,26057362,3,"2s3s4s6s8s2p4p8p1z2z3z4z5z|2p"}, get);
amulet_fan[223] = P({223,26,1,26057263,26057363,3,"2p2p4p4p6p6p8p8p2s2s2s6s6s|6p"}, get);
amulet_fan[224] = P({224,26,1,26057264,26057364,3,"2p2p2p5p5p5p8p8p8p2s2s5s8s|2p"}, get);
return { tb = amulet_fan };