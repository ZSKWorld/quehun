-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_forge]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["type"] = 2; ["rarity"] = 3; ["price"] = 4;};

local df = {  260511, 1, 1, 12,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_forge = { }
amulet_forge[260511] = {
	P({D[1002], 5,0}, get),
	P({D[1002], 4,5}, get),
	P({D[1002], 3,15}, get),
	P({D[1002], 2,25}, get),
	P({D[1003], 35}, get),
	P({false,2,0,1}, get),
	P({false,2,false,6}, get),
	P({false,2,2}, get),
	P({false,2,3}, get),
};
return { tb = amulet_forge };