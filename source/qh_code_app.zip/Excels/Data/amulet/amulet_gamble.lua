-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_gamble]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["id"] = 2; ["level_range"] = 3; ["selection_group_id"] = 4; ["destroy_rate"] = 5; ["destroy_inc_rate"] = 6; ["price"] = 7; ["price_inc_rate"] = 8;};

local df = {  260511, nil, 11005, nil, 3, 150, 5, 150,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_gamble = { }
amulet_gamble[260511] = {
	P({false,1,S({11001,11002,}),5201}, get),
	P({false,2,S({11001,11005,}),5202}, get),
	P({false,3,S({11003,11005,}),5203}, get),
	P({false,4,S({11003,12199,}),5204}, get),
	P({false,5,S({11005,12199,}),5205}, get),
};
return { tb = amulet_gamble };