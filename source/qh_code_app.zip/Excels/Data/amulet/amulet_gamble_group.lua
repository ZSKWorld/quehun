-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_gamble_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["selection_id"] = 2; ["category"] = 3; ["count"] = 4;};

local df = {  5201, 50201, 1, 3,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_gamble_group = { }
amulet_gamble_group[5201] = {
	P({D[1003], 6}, get),
	P({D[1002], 2,0}, get),
};
amulet_gamble_group[5202] = {
	P({D[2003], 5202,5}, get),
	P({5202,false,2,1}, get),
};
amulet_gamble_group[5203] = {
	P({5203,50202,false,4}, get),
	P({5203,50202,2,2}, get),
};
amulet_gamble_group[5204] = {
	P({5204,50202}, get),
	P({5204,50202,2}, get),
};
amulet_gamble_group[5205] = {
	P({5205,50203,false,2}, get),
	P({5205,50203,2,4}, get),
};
return { tb = amulet_gamble_group };