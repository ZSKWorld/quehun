-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["guaranteed"] = 2; ["pack_name"] = 3; ["pack_desc"] = 4; ["price"] = 5;};

local df = {  nil, 2, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_goods = { }
amulet_goods[101] = P({101,4,5500,5503,5}, get);
amulet_goods[102] = P({102,3,5501,5504,10}, get);
amulet_goods[103] = P({103,false,5502,5505,15}, get);
amulet_goods[111] = P({111,4,5500,5503}, get);
amulet_goods[112] = P({112,3,5501,5504}, get);
amulet_goods[113] = P({113,false,5502,5505}, get);
amulet_goods[971] = P({971,0}, get);
amulet_goods[972] = P({972,0}, get);
amulet_goods[973] = P({973,0}, get);
amulet_goods[974] = P({974,4}, get);
amulet_goods[975] = P({975,3}, get);
amulet_goods[976] = P({976}, get);
amulet_goods[977] = P({977,1}, get);
amulet_goods[978] = P({978,5}, get);
amulet_goods[979] = P({979}, get);
amulet_goods[980] = P({980,1}, get);
amulet_goods[981] = P({981,0}, get);
amulet_goods[991] = P({991,4}, get);
return { tb = amulet_goods };