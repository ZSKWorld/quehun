-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_map_event]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["event_type"] = 2; ["event_desc"] = 3;};

local df = {  110011, 2, 26050104,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_map_event = { }
amulet_map_event[110011] = {
	P({false,1,26050103}, get),
	P({}, get),
	P({false,3,26050105}, get),
	P({false,4,26050106}, get),
	P({false,5,26050107}, get),
	P({false,6,26050108}, get),
};
amulet_map_event[110012] = {
	P({110012}, get),
	P({110012,5,26050107}, get),
};
amulet_map_event[110021] = {
	P({110021,1,26050103}, get),
	P({110021}, get),
	P({110021,3,26050105}, get),
	P({110021,4,26050106}, get),
	P({110021,5,26050107}, get),
	P({110021,6,26050108}, get),
};
amulet_map_event[110031] = {
	P({110031,1,26050103}, get),
	P({110031}, get),
	P({110031,3,26050105}, get),
	P({110031,4,26050106}, get),
	P({110031,5,26050107}, get),
	P({110031,6,26050108}, get),
};
amulet_map_event[110041] = {
	P({110041,1,26050103}, get),
	P({110041}, get),
	P({110041,3,26050105}, get),
	P({110041,4,26050106}, get),
	P({110041,5,26050107}, get),
	P({110041,6,26050108}, get),
};
amulet_map_event[110051] = {
	P({110051,1,26050103}, get),
	P({110051}, get),
	P({110051,3,26050105}, get),
	P({110051,4,26050106}, get),
	P({110051,5,26050107}, get),
	P({110051,6,26050108}, get),
};
amulet_map_event[120011] = {
	P({120011,1,26050103}, get),
	P({120011}, get),
	P({120011,3,26050105}, get),
	P({120011,4,26050106}, get),
	P({120011,5,26050107}, get),
	P({120011,6,26050108}, get),
};
return { tb = amulet_map_event };