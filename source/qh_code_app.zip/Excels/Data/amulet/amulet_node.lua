-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_node]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["node"] = 2; ["type"] = 3; ["node_name"] = 1004; ["node_sub_id"] = 5; ["hp_rate"] = 1006; ["atk_rate"] = 7; ["pack_reward"] = 1008; ["coin_reward"] = 9; ["clear_mark"] = 10; ["guaranteed_goods"] = 11; ["level_amulet_pool"] = 12;};

local df = {  19002, 1, 1, nil, 120011, nil, nil, nil, nil, nil, nil, 26051103,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {19131,19186,19240,19299,}

local amulet_node = { }
return { tb = amulet_node, get = get, b2i = b2i };