-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_rune_stone]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["deprecated"] = 2; ["weight"] = 3; ["price"] = 4; ["unlock_fan"] = 5; ["rune_stone_image"] = 1006;};

local df = {  nil, nil, 100, 5, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_rune_stone = { }
amulet_rune_stone[7201] = P({D[2004], 7201,201,"rune_stone_7201"}, get);
amulet_rune_stone[7202] = P({D[2004], 7202,202,"rune_stone_7202"}, get);
amulet_rune_stone[7203] = P({D[2004], 7203,203,"rune_stone_7212"}, get);
amulet_rune_stone[7204] = P({D[2004], 7204,204,"rune_stone_7206"}, get);
amulet_rune_stone[7205] = P({D[2004], 7205,205,"rune_stone_7208"}, get);
amulet_rune_stone[7206] = P({D[2004], 7206,206,"rune_stone_7214"}, get);
amulet_rune_stone[7207] = P({D[2004], 7207,207,"rune_stone_7210"}, get);
amulet_rune_stone[7208] = P({D[2004], 7208,208,"rune_stone_7215"}, get);
amulet_rune_stone[7209] = P({D[2004], 7209,209,"rune_stone_7216"}, get);
amulet_rune_stone[7210] = P({D[2004], 7210,210,"rune_stone_7217"}, get);
amulet_rune_stone[7211] = P({D[2004], 7211,211,"rune_stone_7218"}, get);
amulet_rune_stone[7212] = P({D[2004], 7212,212,"rune_stone_7203"}, get);
amulet_rune_stone[7213] = P({D[2004], 7213,213,"rune_stone_7209"}, get);
amulet_rune_stone[7214] = P({D[2004], 7214,214,"rune_stone_7213"}, get);
amulet_rune_stone[7215] = P({D[2004], 7215,215,"rune_stone_7222"}, get);
amulet_rune_stone[7216] = P({D[2004], 7216,216,"rune_stone_7207"}, get);
amulet_rune_stone[7217] = P({7217,false,20,false,217,"rune_stone_7205"}, get);
amulet_rune_stone[7218] = P({7218,false,20,15,218,"rune_stone_7204"}, get);
amulet_rune_stone[7219] = P({7219,false,20,false,219,"rune_stone_7223"}, get);
amulet_rune_stone[7220] = P({7220,false,20,15,220,"rune_stone_7211"}, get);
amulet_rune_stone[7221] = P({7221,false,20,15,221,"rune_stone_7220"}, get);
amulet_rune_stone[7222] = P({7222,false,20,15,222,"rune_stone_7224"}, get);
amulet_rune_stone[7223] = P({7223,false,20,15,223,"rune_stone_7219"}, get);
amulet_rune_stone[7224] = P({7224,false,20,15,224,"rune_stone_7221"}, get);
return { tb = amulet_rune_stone };