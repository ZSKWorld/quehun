-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_shop_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["price"] = 3; ["add_value"] = 4;};

local df = {  8003, 1, 10, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_shop_upgrade = { }
amulet_shop_upgrade[8001] = {
	P({8001,false,5}, get),
	P({8001,2,false,2}, get),
	P({8001,3,15,3}, get),
	P({8001,4,20,4}, get),
	P({8001,5,50,5}, get),
	P({8001,6,100,6}, get),
	P({8001,7,150,7}, get),
	P({8001,8,200,8}, get),
};
amulet_shop_upgrade[8002] = {
	P({8002,false,5}, get),
	P({8002,2,false,2}, get),
	P({8002,3,15,3}, get),
	P({8002,4,20,4}, get),
	P({8002,5,30,5}, get),
	P({8002,6,50,6}, get),
	P({8002,7,80,7}, get),
	P({8002,8,120,8}, get),
	P({8002,9,160,9}, get),
};
amulet_shop_upgrade[8003] = {
	P({D[1002], 2}, get),
	P({false,2,4,2}, get),
	P({false,3,6,3}, get),
	P({false,4,8,4}, get),
	P({false,5,false,5}, get),
	P({false,6,20,6}, get),
	P({false,7,30,7}, get),
	P({false,8,40,8}, get),
	P({false,9,50,9}, get),
	P({false,10,80,10}, get),
	P({false,11,120,11}, get),
	P({false,12,160,12}, get),
};
amulet_shop_upgrade[8004] = {
	P({8004}, get),
	P({8004,2,20,2}, get),
	P({8004,3,30,3}, get),
	P({8004,4,40,4}, get),
	P({8004,5,50,5}, get),
	P({8004,6,80,6}, get),
	P({8004,7,100,7}, get),
	P({8004,8,150,8}, get),
	P({8004,9,200,9}, get),
};
return { tb = amulet_shop_upgrade };