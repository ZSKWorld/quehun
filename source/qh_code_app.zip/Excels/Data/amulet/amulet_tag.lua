-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_tag]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["tag_id"] = 1; ["tag_name"] = 2; ["tag_desc"] = 3;};

local df = {  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_tag = { }
amulet_tag[25084001] = P({25084001,25084001,25084101}, get);
amulet_tag[25084002] = P({25084002,25084002,25084102}, get);
amulet_tag[25084003] = P({25084003,25084003,25084103}, get);
amulet_tag[25084004] = P({25084004,25084004,25084104}, get);
amulet_tag[25084005] = P({25084005,25084005,25084105}, get);
amulet_tag[25084006] = P({25084006,25084006,25084106}, get);
amulet_tag[25084007] = P({25084007,25084007,25084107}, get);
amulet_tag[25084008] = P({25084008,25084008,25084108}, get);
amulet_tag[25084009] = P({25084009,25084009,25084109}, get);
amulet_tag[25084010] = P({25084010,25084010,25084110}, get);
amulet_tag[25084011] = P({25084011,25084011,25084111}, get);
amulet_tag[25084012] = P({25084012,25084012,25084112}, get);
amulet_tag[25084013] = P({25084013,25084013,25084113}, get);
amulet_tag[25084014] = P({25084014,25084014,25084114}, get);
amulet_tag[25084015] = P({25084015,25084015,25084115}, get);
amulet_tag[25084016] = P({25084016,25084016,25084116}, get);
amulet_tag[25084017] = P({25084017,25084017,25084117}, get);
amulet_tag[25084018] = P({25084018,25084018,25084118}, get);
amulet_tag[25084019] = P({25084019,25084019,25084119}, get);
amulet_tag[25084020] = P({25084020,25084020,25084120}, get);
amulet_tag[25084021] = P({25084021,25084021,25084121}, get);
amulet_tag[25084022] = P({25084022,25084022,25084122}, get);
amulet_tag[25084023] = P({25084023,25084023,25084123}, get);
amulet_tag[25084024] = P({25084024,25084024,25084124}, get);
amulet_tag[25084025] = P({25084025,25084025,25084125}, get);
amulet_tag[26054001] = P({26054001,26054001,26054101}, get);
amulet_tag[26054002] = P({26054002,26054002,26054102}, get);
amulet_tag[26054003] = P({26054003,26054003,26054103}, get);
amulet_tag[26054004] = P({26054004,26054004,26054104}, get);
amulet_tag[26054005] = P({26054005,26054005,26054105}, get);
amulet_tag[26054006] = P({26054006,26054006,26054106}, get);
amulet_tag[26054007] = P({26054007,26054007,26054107}, get);
amulet_tag[26054008] = P({26054008,26054008,26054108}, get);
amulet_tag[26054009] = P({26054009,26054009,26054109}, get);
return { tb = amulet_tag };