-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["amulet_id"] = 2; ["activity_id"] = 3; ["base_task_id"] = 4; ["reward"] = 1005;};

local df = {  nil, nil, 250111, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_task = { }
amulet_task[25011301] = P({25011301,160,false,22598,"100002-1"}, get);
amulet_task[25011302] = P({25011302,280,false,22599,"100002-2"}, get);
amulet_task[25011303] = P({25011303,90,false,22600,"100002-3"}, get);
amulet_task[25011304] = P({25011304,360,false,22601,"100002-4"}, get);
amulet_task[25011305] = P({25011305,690,false,22602,"100002-5"}, get);
amulet_task[25011306] = P({25011306,700,false,22603,"100002-6"}, get);
amulet_task[25011307] = P({25011307,750,false,22604,"100002-7"}, get);
amulet_task[25011308] = P({25011308,1150,false,22605,"100002-8"}, get);
amulet_task[25011309] = P({25011309,1330,false,22606,"100002-9"}, get);
amulet_task[25011310] = P({25011310,1290,false,22607,"100002-10"}, get);
amulet_task[25011311] = P({25011311,1340,false,22608,"100002-11"}, get);
amulet_task[25011312] = P({25011312,1660,false,22609,"100002-12"}, get);
amulet_task[25011313] = P({25011313,1730,false,22610,"100002-13"}, get);
amulet_task[25011314] = P({25011314,1740,false,22611,"100002-14"}, get);
amulet_task[25011315] = P({25011315,1721,false,22612,"100002-15"}, get);
amulet_task[25011316] = P({25011316,1700,false,22613,"100002-16"}, get);
return { tb = amulet_task };