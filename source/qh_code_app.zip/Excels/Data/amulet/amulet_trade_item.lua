-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_trade_item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["deprecated"] = 2; ["type"] = 3; ["group"] = 4; ["value"] = 5; ["desc"] = 6; ["image"] = 1007; ["args"] = 8;};

local df = {  nil, nil, 1, 1, 20, 26055401, "gamble_selection_016", 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_trade_item = { }
amulet_trade_item[1] = P({D[2004], 1,10,false,false,S({20,50,5,})}, get);
amulet_trade_item[2] = P({D[2004], 2,35,false,false,S({75,100,20,})}, get);
amulet_trade_item[3] = P({3,false,2,2,false,26055402,"gamble_selection_026",S({1,1,1,})}, get);
amulet_trade_item[4] = P({4,false,3,3,15,26055403,"gamble_selection_017",S({20,50,5,})}, get);
amulet_trade_item[5] = P({5,false,3,3,30,26055403,"gamble_selection_017",S({75,95,15,})}, get);
amulet_trade_item[6] = P({6,false,4,4,false,26055404,"gamble_selection_022",S({1,})}, get);
amulet_trade_item[7] = P({7,false,5,5,10,26055405,"gamble_selection_028",S({4,6,})}, get);
amulet_trade_item[8] = P({8,false,5,5,30,26055405,"gamble_selection_028",S({7,9,})}, get);
amulet_trade_item[9] = P({9,false,2,6,25,26055402,"gamble_selection_026",S({1,1,1,})}, get);
return { tb = amulet_trade_item };