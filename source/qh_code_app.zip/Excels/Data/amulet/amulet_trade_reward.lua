-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_trade_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["deprecated"] = 2; ["min_value"] = 3; ["max_value"] = 4; ["desc"] = 5; ["type"] = 6; ["args"] = 7;};

local df = {  nil, nil, nil, 29, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_trade_reward = { }
amulet_trade_reward[1] = P({1,false,19,false,26055411,false,S({975,0,})}, get);
amulet_trade_reward[2] = P({2,1,24,false,26055413,2,S({})}, get);
amulet_trade_reward[3] = P({3,false,29,39,26055412,false,S({975,1,})}, get);
amulet_trade_reward[4] = P({4,false,39,49,26055414,false,S({976,0,})}, get);
amulet_trade_reward[5] = P({5,false,49,54,26055415,false,S({979,0,})}, get);
amulet_trade_reward[6] = P({6,false,54,59,26055416,false,S({976,1,})}, get);
amulet_trade_reward[7] = P({7,false,59,999,26055417,false,S({979,1,})}, get);
return { tb = amulet_trade_reward };