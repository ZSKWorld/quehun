-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_transport]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["price"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_transport = { }
amulet_transport[260511] = P({260511,30}, get);
return { tb = amulet_transport };