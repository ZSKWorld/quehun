-- 由 Excel 自动生成的 Lua 表
-- 文件:   [amulet][amulet_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["skill_point"] = 3; ["buff_id"] = 4; ["display_value"] = 5;};

local df = {  901, nil, nil, nil, 3,};

local get = function(item, k) return G(item, k, n2i, df); end;


local amulet_upgrade = { }
amulet_upgrade[901] = {
	P({D[1002], 1,9010,10}, get),
	P({false,1,2,9011,15}, get),
	P({false,2,3,9012,20}, get),
	P({false,3,false,9013,25}, get),
};
amulet_upgrade[902] = {
	P({902,false,1,9020,2}, get),
	P({902,1,2,9021}, get),
	P({902,2,3,9022,4}, get),
	P({902,3,false,9023,5}, get),
};
amulet_upgrade[903] = {
	P({903,false,2,9030,0}, get),
	P({903,1,4,9031,1}, get),
	P({903,2,6,9032,2}, get),
	P({903,3,false,9033}, get),
};
amulet_upgrade[904] = {
	P({904,false,2,9040,5}, get),
	P({904,1,4,9041}, get),
	P({904,2,6,9042,2}, get),
	P({904,3,false,9043,1}, get),
};
amulet_upgrade[905] = {
	P({905,false,3,9050,5}, get),
	P({905,1,6,9051,6}, get),
	P({905,2,9,9052,7}, get),
	P({905,3,false,9053,8}, get),
};
amulet_upgrade[906] = {
	P({906,false,3,9060}, get),
	P({906,1,6,9061,4}, get),
	P({906,2,false,9062,5}, get),
};
return { tb = amulet_upgrade };