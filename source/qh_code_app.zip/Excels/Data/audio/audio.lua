-- 由 Excel 自动生成的 Lua 表
-- 文件:   [audio][audio]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["path"] = 1002; ["time_length"] = 3; ["type"] = 1004;};

local df = {  nil, nil, nil, "event",};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {246,10152,10350,10432,308006,30530014,}

local audio = { }
return { tb = audio, get = get, b2i = b2i };