-- 由 Excel 自动生成的 Lua 表
-- 文件:   [audio][bgm]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["auto_hide"] = 2; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["path"] = 1004; ["time_length"] = 5; ["type"] = 1006; ["unlock_desc_chs"] = -7; ["unlock_desc_chs_t"] = -7; ["unlock_desc_jp"] = -7; ["unlock_desc_en"] = -7; ["unlock_desc_kr"] = -7; ["unlock_item"] = 8;};

local df = {  nil, 1,  nil, nil, nil, "mj",  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "audio_bgm"); end;


local bgm = { }
bgm[306001] = P({306001,0,1,"music/lobby.mp3",false,"lobby",false}, get);
bgm[306002] = P({306002,0,2,"music/zhongxialvdong.mp3",false,"lobby",1,306002}, get);
bgm[306003] = P({306003,0,3,"music/lobby_autumn.mp3",false,"lobby",1,306003}, get);
bgm[306004] = P({306004,0,4,"music/lobby_winter.mp3",false,"lobby",1,306004}, get);
bgm[306005] = P({306005,false,5,"music/lobby_bd.mp3",false,"lobby",2,306005}, get);
bgm[306006] = P({306006,false,6,"music/lobby_2303wenquan.mp3",false,"lobby",2,306006}, get);
bgm[306101] = P({D[5006], 306101,0,7,"music/game.mp3",false}, get);
bgm[306102] = P({D[5006], 306102,false,8,"music/game_master.mp3",2,306102}, get);
bgm[306103] = P({D[5006], 306103,false,9,"music/23yixinyizhi.mp3",2,306103}, get);
bgm[306104] = P({D[5006], 306104,0,10,"music/23ex_duiju1.mp3",3,306104}, get);
bgm[306105] = P({D[5006], 306105,0,11,"music/23ex_duiju2.mp3",3,306105}, get);
bgm[306106] = P({D[5006], 306106,0,12,"music/23ex_duiju3.mp3",3,306106}, get);
bgm[306107] = P({D[5006], 306107,0,13,"music/23ex_duiju4.mp3",3,306107}, get);
bgm[30600001] = P({30600001,false,14,"music/lobby_24anime.mp3",false,"lobby",2,30600001}, get);
bgm[30600002] = P({30600002,0,15,"music/lobby_yiji.mp3",false,"lobby",1,30600002}, get);
bgm[30600003] = P({30600003,false,16,"music/lobby_25dongri.mp3",false,"lobby",2,30600003}, get);
bgm[30610001] = P({D[5006], 30610001,false,17,"music/23wansheng.mp3",3,30610001}, get);
bgm[30610002] = P({D[5006], 30610002,false,18,"music/24chunjie.mp3",2,30610002}, get);
bgm[30610003] = P({D[5006], 30610003,false,19,"music/24summer_duiju.mp3",2,30610003}, get);
bgm[30610004] = P({D[5006], 30610004,false,20,"music/24wansheng_duiju.mp3",2,30610004}, get);
bgm[30610005] = P({D[5006], 30610005,false,21,"music/vip_duiju.mp3",2,30610005}, get);
bgm[30610006] = P({D[5006], 30610006,false,22,"music/25xila_duiju.mp3",3,30610006}, get);
return { tb = bgm };