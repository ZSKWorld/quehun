-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][cutin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["skinid"] = 1; ["cutin_name"] = 1002; ["effect"] = 1003; ["atlas"] = 1004; ["char_x"] = 5; ["char_y"] = 6; ["char_width"] = 7; ["char_height"] = 8; ["type"] = 9;};

local df = {  nil, "cutin_liyang", nil, "liyang", nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local cutin = { }
cutin[405201] = P({405201,"cutin_xiyuansi","cutin_xiyuansi","xiyuansi",15,503,1315,1960}, get);
cutin[405202] = P({405202,"cutin_xiyuansi","cutin_xiyuansi_0","xiyuansi",-294,479,2500,2137}, get);
cutin[406101] = P({406101,"cutin_beiyuan","cutin_beiyuan","beiyuanlili",412,576,1578,2054}, get);
cutin[406102] = P({406102,"cutin_beiyuan","cutin_beiyuan_0","beiyuanlili",188,420,3143,3164}, get);
cutin[407601] = P({407601,"cutin_dongcheng","cutin_dongcheng","dongcheng",-294,479,1009,1633}, get);
cutin[407602] = P({407602,"cutin_dongcheng","cutin_dongcheng_0","dongcheng",-147,456,1645,1615}, get);
cutin[409501] = P({409501,"cutin_nanfeng","cutin_nanfeng","nanfeng",-326,482,821,1488}, get);
cutin[409502] = P({409502,"cutin_nanfeng","cutin_nanfeng_0","nanfeng",-402,216,1317,1500}, get);
cutin[40011201] = P({D[4008], 40011201,false,"cutin_liyang",1}, get);
cutin[40011202] = P({D[4008], 40011202,false,"cutin_liyang_0",1}, get);
cutin[40011203] = P({D[4008], 40011203,false,"cutin_liyang_1",1}, get);
return { tb = cutin };