-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][emoji]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["charid"] = 1; ["sub_id"] = 2; ["unlock_desc_chs"] = -3; ["unlock_desc_chs_t"] = -3; ["unlock_desc_jp"] = -3; ["unlock_desc_en"] = -3; ["unlock_desc_kr"] = -3; ["type"] = 4; ["view"] = 1005; ["audio"] = 6; ["after_unlock_desc_chs"] = -7; ["after_unlock_desc_chs_t"] = -7; ["after_unlock_desc_jp"] = -7; ["after_unlock_desc_en"] = -7; ["after_unlock_desc_kr"] = -7; ["unlock_type"] = 8; ["unlock_param"] = 9;};

local df = {  200007, 10,  nil, 1, nil, nil,  nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df, "character_emoji"); end;

local b2i = {200007,200015,200026,200043,200061,200083,20000107,20000125,}

local emoji = { }
return { tb = emoji, get = get, b2i = b2i };