-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][emoji]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local emoji = require("Excels.Data.character.emoji")
local tb = emoji.tb
local get = emoji.get

tb[200062] = {
	P({D[4006], 200062,false,1,false,false,S({})}, get),
	P({D[4006], 200062,11,1,false,false,S({})}, get),
	P({D[4006], 200062,12,1,false,false,S({})}, get),
	P({200062,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200062,969,5,69,3,S({406203,})}, get),
};
tb[200063] = {
	P({D[4006], 200063,false,1,false,false,S({})}, get),
	P({D[4006], 200063,11,1,false,false,S({})}, get),
	P({D[4006], 200063,12,1,false,false,S({})}, get),
	P({200063,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200063,969,5,69,3,S({406303,})}, get),
};
tb[200064] = {
	P({D[4006], 200064,false,1,false,false,S({})}, get),
	P({D[4006], 200064,11,1,false,false,S({})}, get),
	P({D[4006], 200064,12,1,false,false,S({})}, get),
	P({200064,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200064,969,5,69,3,S({406403,})}, get),
};
tb[200065] = {
	P({D[4006], 200065,false,1,false,false,S({})}, get),
	P({D[4006], 200065,11,1,false,false,S({})}, get),
	P({D[4006], 200065,12,1,false,false,S({})}, get),
	P({200065,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200065,969,5,69,3,S({406503,})}, get),
};
tb[200066] = {
	P({D[4006], 200066,false,1,false,false,S({})}, get),
	P({D[4006], 200066,11,1,false,false,S({})}, get),
	P({D[4006], 200066,12,1,false,false,S({})}, get),
	P({200066,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200066,888,4,7,2,S({309159,})}, get),
	P({D[4006], 200066,962,5,48,3,S({406603,})}, get),
	P({D[4006], 200066,955,5,55,3,S({406604,})}, get),
	P({D[4006], 200066,951,5,75,3,S({406605,})}, get),
	P({D[4006], 200066,927,5,false,3,S({406606,})}, get),
};
tb[200067] = {
	P({D[4006], 200067,false,1,false,false,S({})}, get),
	P({D[4006], 200067,11,1,false,false,S({})}, get),
	P({D[4006], 200067,12,1,false,false,S({})}, get),
	P({200067,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200067,888,4,7,2,S({309160,})}, get),
	P({D[4006], 200067,954,5,53,3,S({406703,})}, get),
	P({D[4006], 200067,936,5,59,3,S({406704,})}, get),
};
tb[200068] = {
	P({D[4006], 200068,false,1,false,false,S({})}, get),
	P({D[4006], 200068,11,1,false,false,S({})}, get),
	P({D[4006], 200068,12,1,false,false,S({})}, get),
	P({200068,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200068,888,4,7,2,S({30910001,})}, get),
	P({D[4006], 200068,955,5,55,3,S({406803,})}, get),
	P({D[4006], 200068,944,5,74,3,S({406804,})}, get),
};
tb[200069] = {
	P({D[4006], 200069,false,1,false,false,S({})}, get),
	P({D[4006], 200069,11,1,false,false,S({})}, get),
	P({D[4006], 200069,12,1,false,false,S({})}, get),
	P({200069,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200069,888,4,7,2,S({30910002,})}, get),
	P({D[4006], 200069,953,5,78,3,S({406903,})}, get),
	P({D[4006], 200069,939,5,54,3,S({406904,})}, get),
};
tb[200070] = {
	P({D[4006], 200070,false,1,false,false,S({})}, get),
	P({D[4006], 200070,11,1,false,false,S({})}, get),
	P({D[4006], 200070,12,1,false,false,S({})}, get),
	P({200070,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200070,963,5,80,3,S({407003,})}, get),
};
tb[200071] = {
	P({D[4006], 200071,false,1,false,false,S({})}, get),
	P({D[4006], 200071,11,1,false,false,S({})}, get),
	P({D[4006], 200071,12,1,false,false,S({})}, get),
	P({200071,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200071,963,5,80,3,S({407103,})}, get),
};
tb[200072] = {
	P({D[4006], 200072,false,1,false,false,S({})}, get),
	P({D[4006], 200072,11,1,false,false,S({})}, get),
	P({D[4006], 200072,12,1,false,false,S({})}, get),
	P({200072,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200072,963,5,80,3,S({407203,})}, get),
};
tb[200073] = {
	P({D[4006], 200073,false,1,false,false,S({})}, get),
	P({D[4006], 200073,11,1,false,false,S({})}, get),
	P({D[4006], 200073,12,1,false,false,S({})}, get),
	P({200073,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200073,963,5,80,3,S({407303,})}, get),
};
tb[200074] = {
	P({D[4006], 200074,false,1,false,false,S({})}, get),
	P({D[4006], 200074,11,1,false,false,S({})}, get),
	P({D[4006], 200074,12,1,false,false,S({})}, get),
	P({200074,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200074,888,4,7,2,S({30910003,})}, get),
	P({D[4006], 200074,946,5,45,3,S({407403,})}, get),
	P({D[4006], 200074,933,5,64,3,S({407404,})}, get),
};
tb[200075] = {
	P({D[4006], 200075,false,1,false,false,S({})}, get),
	P({D[4006], 200075,11,1,false,false,S({})}, get),
	P({D[4006], 200075,12,1,false,false,S({})}, get),
	P({200075,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200075,888,4,7,2,S({30910004,})}, get),
	P({D[4006], 200075,948,5,17,3,S({407503,})}, get),
	P({D[4006], 200075,935,5,36,3,S({407504,})}, get),
};
tb[200076] = {
	P({D[4006], 200076,false,1,false,false,S({})}, get),
	P({D[4006], 200076,11,1,false,false,S({})}, get),
	P({D[4006], 200076,12,1,false,false,S({})}, get),
	P({200076,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200076,888,4,7,2,S({30910005,})}, get),
};
tb[200077] = {
	P({D[4006], 200077,false,1,false,false,S({})}, get),
	P({D[4006], 200077,11,1,false,false,S({})}, get),
	P({D[4006], 200077,12,1,false,false,S({})}, get),
	P({200077,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200077,888,4,7,2,S({30910006,})}, get),
	P({D[4006], 200077,953,5,78,3,S({407703,})}, get),
};
tb[200078] = {
	P({D[4006], 200078,false,1,false,false,S({})}, get),
	P({D[4006], 200078,11,1,false,false,S({})}, get),
	P({D[4006], 200078,12,1,false,false,S({})}, get),
	P({200078,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200078,888,4,7,2,S({30910007,})}, get),
};
tb[200079] = {
	P({D[4006], 200079,false,1,false,false,S({})}, get),
	P({D[4006], 200079,11,1,false,false,S({})}, get),
	P({D[4006], 200079,12,1,false,false,S({})}, get),
	P({200079,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200079,956,5,81,3,S({407903,})}, get),
};
tb[200080] = {
	P({D[4006], 200080,false,1,false,false,S({})}, get),
	P({D[4006], 200080,11,1,false,false,S({})}, get),
	P({D[4006], 200080,12,1,false,false,S({})}, get),
	P({200080,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200080,956,5,81,3,S({408003,})}, get),
};
tb[200081] = {
	P({D[4006], 200081,false,1,false,false,S({})}, get),
	P({D[4006], 200081,11,1,false,false,S({})}, get),
	P({D[4006], 200081,12,1,false,false,S({})}, get),
	P({200081,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200081,956,5,81,3,S({408103,})}, get),
};
tb[200082] = {
	P({D[4006], 200082,false,1,false,false,S({})}, get),
	P({D[4006], 200082,11,1,false,false,S({})}, get),
	P({D[4006], 200082,12,1,false,false,S({})}, get),
	P({200082,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200082,956,5,81,3,S({408203,})}, get),
};
tb[200083] = {
	P({D[4006], 200083,false,1,false,false,S({})}, get),
	P({D[4006], 200083,11,1,false,false,S({})}, get),
	P({D[4006], 200083,12,1,false,false,S({})}, get),
	P({200083,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200083,888,4,7,2,S({30910008,})}, get),
	P({D[4006], 200083,938,5,50,3,S({408303,})}, get),
	P({D[4006], 200083,930,5,72,3,S({408304,})}, get),
};