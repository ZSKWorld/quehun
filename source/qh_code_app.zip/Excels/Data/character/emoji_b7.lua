-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][emoji]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local emoji = require("Excels.Data.character.emoji")
local tb = emoji.tb
local get = emoji.get

tb[200084] = {
	P({D[4006], 200084,false,1,false,false,S({})}, get),
	P({D[4006], 200084,11,1,false,false,S({})}, get),
	P({D[4006], 200084,12,1,false,false,S({})}, get),
	P({200084,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200084,888,4,7,2,S({30910010,})}, get),
	P({D[4006], 200084,951,5,75,3,S({408403,})}, get),
	P({D[4006], 200084,932,5,67,3,S({408404,})}, get),
};
tb[200085] = {
	P({D[4006], 200085,false,1,false,false,S({})}, get),
	P({D[4006], 200085,11,1,false,false,S({})}, get),
	P({D[4006], 200085,12,1,false,false,S({})}, get),
	P({200085,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200085,888,4,7,2,S({30910011,})}, get),
	P({D[4006], 200085,935,5,36,3,S({408503,})}, get),
};
tb[200086] = {
	P({D[4006], 200086,false,1,false,false,S({})}, get),
	P({D[4006], 200086,11,1,false,false,S({})}, get),
	P({D[4006], 200086,12,1,false,false,S({})}, get),
	P({200086,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200086,952,5,82,3,S({408603,})}, get),
};
tb[200087] = {
	P({D[4006], 200087,false,1,false,false,S({})}, get),
	P({D[4006], 200087,11,1,false,false,S({})}, get),
	P({D[4006], 200087,12,1,false,false,S({})}, get),
	P({200087,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200087,952,5,82,3,S({408703,})}, get),
};
tb[200088] = {
	P({D[4006], 200088,false,1,false,false,S({})}, get),
	P({D[4006], 200088,11,1,false,false,S({})}, get),
	P({D[4006], 200088,12,1,false,false,S({})}, get),
	P({200088,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200088,952,5,82,3,S({408803,})}, get),
};
tb[200089] = {
	P({D[4006], 200089,false,1,false,false,S({})}, get),
	P({D[4006], 200089,11,1,false,false,S({})}, get),
	P({D[4006], 200089,12,1,false,false,S({})}, get),
	P({200089,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200089,952,5,82,3,S({408903,})}, get),
};
tb[200090] = {
	P({D[4006], 200090,false,1,false,false,S({})}, get),
	P({D[4006], 200090,11,1,false,false,S({})}, get),
	P({D[4006], 200090,12,1,false,false,S({})}, get),
	P({200090,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200090,888,4,7,2,S({30910009,})}, get),
	P({D[4006], 200090,936,5,59,3,S({409003,})}, get),
};
tb[200091] = {
	P({D[4006], 200091,false,1,false,false,S({})}, get),
	P({D[4006], 200091,11,1,false,false,S({})}, get),
	P({D[4006], 200091,12,1,false,false,S({})}, get),
	P({200091,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200091,888,4,7,2,S({30910015,})}, get),
	P({D[4006], 200091,933,5,64,3,S({409103,})}, get),
};
tb[200092] = {
	P({D[4006], 200092,false,1,false,false,S({})}, get),
	P({D[4006], 200092,11,1,false,false,S({})}, get),
	P({D[4006], 200092,12,1,false,false,S({})}, get),
	P({200092,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200092,888,4,7,2,S({30910016,})}, get),
	P({D[4006], 200092,930,5,72,3,S({409203,})}, get),
};
tb[200093] = {
	P({D[4006], 200093,false,1,false,false,S({})}, get),
	P({D[4006], 200093,11,1,false,false,S({})}, get),
	P({D[4006], 200093,12,1,false,false,S({})}, get),
	P({200093,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200093,888,4,7,2,S({30910012,})}, get),
	P({D[4006], 200093,942,5,63,3,S({409303,})}, get),
};
tb[200094] = {
	P({D[4006], 200094,false,1,false,false,S({})}, get),
	P({D[4006], 200094,11,1,false,false,S({})}, get),
	P({D[4006], 200094,12,1,false,false,S({})}, get),
	P({200094,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200094,888,4,7,2,S({30910013,})}, get),
	P({D[4006], 200094,941,5,47,3,S({409403,})}, get),
};
tb[200095] = {
	P({D[4006], 200095,false,1,false,false,S({})}, get),
	P({D[4006], 200095,11,1,false,false,S({})}, get),
	P({D[4006], 200095,12,1,false,false,S({})}, get),
	P({200095,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 200095,888,4,7,2,S({30910014,})}, get),
};
tb[200096] = {
	P({D[4006], 200096,false,1,false,false,S({})}, get),
	P({D[4006], 200096,11,1,false,false,S({})}, get),
	P({D[4006], 200096,12,1,false,false,S({})}, get),
	P({200096,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200096,888,4,7,2,S({30910017,})}, get),
};
tb[200097] = {
	P({D[4006], 200097,false,1,false,false,S({})}, get),
	P({D[4006], 200097,11,1,false,false,S({})}, get),
	P({D[4006], 200097,12,1,false,false,S({})}, get),
	P({200097,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200097,888,4,7,2,S({30910022,})}, get),
	P({D[4006], 200097,931,5,83,3,S({409703,})}, get),
};
tb[200098] = {
	P({D[4006], 200098,false,1,false,false,S({})}, get),
	P({D[4006], 200098,11,1,false,false,S({})}, get),
	P({D[4006], 200098,12,1,false,false,S({})}, get),
	P({200098,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 200098,888,4,7,2,S({30910020,})}, get),
	P({D[4006], 200098,931,5,83,3,S({409803,})}, get),
};
tb[200099] = {
	P({D[4006], 200099,false,1,false,false,S({})}, get),
	P({D[4006], 200099,11,1,false,false,S({})}, get),
	P({D[4006], 200099,12,1,false,false,S({})}, get),
	P({200099,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 200099,888,4,7,2,S({30910019,})}, get),
	P({D[4006], 200099,931,5,83,3,S({409903,})}, get),
};
tb[20000100] = {
	P({D[4006], 20000100,false,1,false,false,S({})}, get),
	P({D[4006], 20000100,11,1,false,false,S({})}, get),
	P({D[4006], 20000100,12,1,false,false,S({})}, get),
	P({20000100,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000100,945,5,84,3,S({40010003,})}, get),
};
tb[20000101] = {
	P({D[4006], 20000101,false,1,false,false,S({})}, get),
	P({D[4006], 20000101,11,1,false,false,S({})}, get),
	P({D[4006], 20000101,12,1,false,false,S({})}, get),
	P({20000101,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 20000101,945,5,84,3,S({40010103,})}, get),
};
tb[20000102] = {
	P({D[4006], 20000102,false,1,false,false,S({})}, get),
	P({D[4006], 20000102,11,1,false,false,S({})}, get),
	P({D[4006], 20000102,12,1,false,false,S({})}, get),
	P({20000102,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000102,945,5,84,3,S({40010203,})}, get),
};
tb[20000103] = {
	P({D[4006], 20000103,false,1,false,false,S({})}, get),
	P({D[4006], 20000103,11,1,false,false,S({})}, get),
	P({D[4006], 20000103,12,1,false,false,S({})}, get),
	P({20000103,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000103,945,5,84,3,S({40010303,})}, get),
};
tb[20000106] = {
	P({D[4006], 20000106,false,1,false,false,S({})}, get),
	P({D[4006], 20000106,11,1,false,false,S({})}, get),
	P({D[4006], 20000106,12,1,false,false,S({})}, get),
	P({20000106,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000106,888,4,7,2,S({30910021,})}, get),
	P({D[4006], 20000106,927,5,false,3,S({40010603,})}, get),
};
tb[20000107] = {
	P({D[4006], 20000107,false,1,false,false,S({})}, get),
	P({D[4006], 20000107,11,1,false,false,S({})}, get),
	P({D[4006], 20000107,12,1,false,false,S({})}, get),
	P({20000107,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000107,888,4,7,2,S({30910018,})}, get),
	P({D[4006], 20000107,935,5,36,3,S({40010703,})}, get),
};