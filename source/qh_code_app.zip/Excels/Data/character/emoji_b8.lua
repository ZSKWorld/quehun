-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][emoji]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local emoji = require("Excels.Data.character.emoji")
local tb = emoji.tb
local get = emoji.get

tb[20000107] = {
	P({D[4006], 20000107,false,1,false,false,S({})}, get),
	P({D[4006], 20000107,11,1,false,false,S({})}, get),
	P({D[4006], 20000107,12,1,false,false,S({})}, get),
	P({20000107,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000107,888,4,7,2,S({30910018,})}, get),
	P({D[4006], 20000107,935,5,36,3,S({40010703,})}, get),
	P({D[4006], 20000107,924,5,false,3,S({40010704,})}, get),
};
tb[20000108] = {
	P({D[4006], 20000108,false,1,false,false,S({})}, get),
	P({D[4006], 20000108,11,1,false,false,S({})}, get),
	P({D[4006], 20000108,12,1,false,false,S({})}, get),
	P({20000108,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000108,940,5,85,3,S({40010803,})}, get),
};
tb[20000109] = {
	P({D[4006], 20000109,false,1,false,false,S({})}, get),
	P({D[4006], 20000109,11,1,false,false,S({})}, get),
	P({D[4006], 20000109,12,1,false,false,S({})}, get),
	P({20000109,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000109,940,5,85,3,S({40010903,})}, get),
};
tb[20000110] = {
	P({D[4006], 20000110,false,1,false,false,S({})}, get),
	P({D[4006], 20000110,11,1,false,false,S({})}, get),
	P({D[4006], 20000110,12,1,false,false,S({})}, get),
	P({20000110,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 20000110,940,5,85,3,S({40011003,})}, get),
};
tb[20000111] = {
	P({D[4006], 20000111,false,1,false,false,S({})}, get),
	P({D[4006], 20000111,11,1,false,false,S({})}, get),
	P({D[4006], 20000111,12,1,false,false,S({})}, get),
	P({20000111,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000111,940,5,85,3,S({40011103,})}, get),
};
tb[20000112] = {
	P({D[4006], 20000112,false,1,false,false,S({})}, get),
	P({D[4006], 20000112,11,1,false,false,S({})}, get),
	P({D[4006], 20000112,12,1,false,false,S({})}, get),
	P({20000112,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000112,888,4,7,2,S({30910023,})}, get),
	P({D[4006], 20000112,936,5,86,3,S({40011203,})}, get),
	P({D[4006], 20000112,924,5,false,3,S({40012103,})}, get),
};
tb[20000113] = {
	P({D[4006], 20000113,false,1,false,false,S({})}, get),
	P({D[4006], 20000113,11,1,false,false,S({})}, get),
	P({D[4006], 20000113,12,1,false,false,S({})}, get),
	P({20000113,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000113,934,5,87,3,S({40011303,})}, get),
};
tb[20000114] = {
	P({D[4006], 20000114,false,1,false,false,S({})}, get),
	P({D[4006], 20000114,11,1,false,false,S({})}, get),
	P({D[4006], 20000114,12,1,false,false,S({})}, get),
	P({20000114,14,3,2,"effect_yuebing_jio",241,2,2,S({309201,})}, get),
	P({D[4006], 20000114,934,5,87,3,S({40011403,})}, get),
};
tb[20000115] = {
	P({D[4006], 20000115,false,1,false,false,S({})}, get),
	P({D[4006], 20000115,11,1,false,false,S({})}, get),
	P({D[4006], 20000115,12,1,false,false,S({})}, get),
	P({20000115,14,3,2,"effect_yuebing_yuan",241,2,2,S({309201,})}, get),
	P({D[4006], 20000115,934,5,87,3,S({40011503,})}, get),
};
tb[20000116] = {
	P({D[4006], 20000116,false,1,false,false,S({})}, get),
	P({D[4006], 20000116,11,1,false,false,S({})}, get),
	P({D[4006], 20000116,12,1,false,false,S({})}, get),
	P({20000116,14,3,2,"effect_yuebing_tou",241,2,2,S({309201,})}, get),
	P({D[4006], 20000116,934,5,87,3,S({40011603,})}, get),
};
tb[20000117] = {
	P({D[4006], 20000117,false,1,false,false,S({})}, get),
	P({D[4006], 20000117,11,1,false,false,S({})}, get),
	P({D[4006], 20000117,12,1,false,false,S({})}, get),
	P({D[4006], 20000117,888,4,7,2,S({30910024,})}, get),
	P({D[4006], 20000117,925,5,false,3,S({40011703,})}, get),
};
tb[20000118] = {
	P({D[4006], 20000118,false,1,false,false,S({})}, get),
	P({D[4006], 20000118,11,1,false,false,S({})}, get),
	P({D[4006], 20000118,12,1,false,false,S({})}, get),
	P({D[4006], 20000118,888,4,7,2,S({30910025,})}, get),
};
tb[20000119] = {
	P({D[4006], 20000119,false,1,false,false,S({})}, get),
	P({D[4006], 20000119,11,1,false,false,S({})}, get),
	P({D[4006], 20000119,12,1,false,false,S({})}, get),
	P({D[4006], 20000119,888,4,7,2,S({30910026,})}, get),
};
tb[20000120] = {
	P({D[4006], 20000120,false,1,false,false,S({})}, get),
	P({D[4006], 20000120,11,1,false,false,S({})}, get),
	P({D[4006], 20000120,12,1,false,false,S({})}, get),
	P({D[4006], 20000120,888,4,7,2,S({30910027,})}, get),
};
tb[20000122] = {
	P({D[4006], 20000122,false,1,false,false,S({})}, get),
	P({D[4006], 20000122,11,1,false,false,S({})}, get),
	P({D[4006], 20000122,12,1,false,false,S({})}, get),
	P({D[4006], 20000122,928,5,88,3,S({40012203,})}, get),
};
tb[20000123] = {
	P({D[4006], 20000123,false,1,false,false,S({})}, get),
	P({D[4006], 20000123,11,1,false,false,S({})}, get),
	P({D[4006], 20000123,12,1,false,false,S({})}, get),
	P({D[4006], 20000123,928,5,88,3,S({40012303,})}, get),
};
tb[20000124] = {
	P({D[4006], 20000124,false,1,false,false,S({})}, get),
	P({D[4006], 20000124,11,1,false,false,S({})}, get),
	P({D[4006], 20000124,12,1,false,false,S({})}, get),
	P({D[4006], 20000124,928,5,88,3,S({40012403,})}, get),
};
tb[20000125] = {
	P({D[4006], 20000125,false,1,false,false,S({})}, get),
	P({D[4006], 20000125,11,1,false,false,S({})}, get),
	P({D[4006], 20000125,12,1,false,false,S({})}, get),
	P({D[4006], 20000125,928,5,88,3,S({40012503,})}, get),
};