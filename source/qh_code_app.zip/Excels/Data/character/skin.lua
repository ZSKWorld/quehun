-- 由 Excel 自动生成的 Lua 表
-- 文件:   [character][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["skinid"] = 1; ["spine_layers"] = 2; ["has_effect"] = 3; ["audio_celebrate"] = 1004; ["audio_celebrate_idle"] = 1005; ["audio_idle"] = 1006; ["audio_greeting"] = 1007; ["audio_click"] = 1008; ["audio_click2"] = 1009; ["celebrate_delay"] = 10;};

local df = {  nil, 1, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local skin = { }
skin[400107] = P({D[2003], 400107,"YJ_SE_400107/celebrate",false,false,"YJ_SE_400107/greeting","YJ_SE_400107/click"}, get);
skin[400305] = P({D[2003], 400305,"TTJN_SE_400305/celebrate",false,false,"TTJN_SE_400305/greeting","TTJN_SE_400305/click",false,1}, get);
skin[400306] = P({D[2003], 400306,"TTJN_SE_400306/celebrate",false,false,"TTJN_SE_400306/greeting","TTJN_SE_400306/click",false,1}, get);
skin[400406] = P({D[2003], 400406,"SSQZ_SE_400406/celebrate",false,false,"SSQZ_SE_400406/greeting","SSQZ_SE_400406/click"}, get);
skin[400505] = P({D[2003], 400505,"XYW_SE_400505/celebrate",false,false,"XYW_SE_400505/greeting","XYW_SE_400505/click"}, get);
skin[400506] = P({D[5006], 400506,3,1,"XYW_SE/240228_qh_xiangyuanwu_celebrate","XYW_SE/240228_qh_xiangyuanwu_greeting","XYW_SE/240228_qh_xiangyuanwu_click",false,1}, get);
skin[400508] = P({D[5006], 400508,false,1,"XYW_SE_400508/celebrate","XYW_SE_400508/greeting","XYW_SE_400508/click"}, get);
skin[400706] = P({D[2003], 400706,"BMW_SE_400706/celebrate",false,false,"BMW_SE_400706/greeting","BMW_SE_400706/click"}, get);
skin[400709] = P({D[5006], 400709,2,false,"BMW_SE_400709/celebrate","BMW_SE_400709/greeting","BMW_SE_400709/click"}, get);
skin[400905] = P({D[2003], 400905,"ZNY_SE_400905/celebrate",false,false,"ZNY_SE_400905/greeting","ZNY_SE_400905/click"}, get);
skin[400907] = P({D[2003], 400907,"ZNY_SE_400907/celebrate",false,false,"ZNY_SE_400907/greeting","ZNY_SE_400907/click"}, get);
skin[400908] = P({D[5006], 400908,2,1,"zny_se_400908/celebrate","zny_se_400908/greeting","zny_se_400908/click"}, get);
skin[401004] = P({D[2003], 401004,"KW_SE_401004/celebrate",false,false,"KW_SE_401004/greeting","KW_SE_401004/click"}, get);
skin[401105] = P({D[2003], 401105,"SGXS_SE_401105/celebrate",false,false,"SGXS_SE_401105/greeting","SGXS_SE_401105/click"}, get);
skin[401305] = P({D[2003], 401305,"YZLK_SE_401305/celebrate",false,false,"YZLK_SE_401305/greeting","YZLK_SE_401305/click"}, get);
skin[401709] = P({D[2003], 401709,"EZGH_SE_401709/celebrate",false,false,"EZGH_SE_401709/greeting","EZGH_SE_401709/click",false,1}, get);
skin[401806] = P({D[2003], 401806,"bsnn_se_401806/celebrate",false,false,"bsnn_se_401806/greeting","bsnn_se_401806/click"}, get);
skin[401906] = P({D[5006], 401906,3,false,"XNYCT_SE_401906/celebrate","XNYCT_SE_401906/greeting","XNYCT_SE_401906/click",false,1}, get);
skin[401907] = P({D[2003], 401907,"XNYCT_SE_401907/celebrate",false,false,"XNYCT_SE_401907/greeting","XNYCT_SE_401907/click"}, get);
skin[402005] = P({D[2003], 402005,"WSLYC_SE_402005/celebrate",false,false,"WSLYC_SE_402005/greeting","WSLYC_SE_402005/click"}, get);
skin[402104] = P({D[2003], 402104,"LGXS_SE_402104/celebrate",false,false,"LGXS_SE_402104/greeting","LGXS_SE_402104/click"}, get);
skin[402106] = P({D[2003], 402106,"LGXS_SE_402106/celebrate",false,false,"LGXS_SE_402106/greeting","LGXS_SE_402106/click"}, get);
skin[402406] = P({D[2003], 402406,"BJSHZ_SE_402406/celebrate",false,false,"BJSHZ_SE_402406/greeting","BJSHZ_SE_402406/click",false,1}, get);
skin[402407] = P({D[2003], 402407,"BJSHZ_SE_402407/celebrate",false,false,"BJSHZ_SE_402407/greeting","BJSHZ_SE_402407/click",false,1}, get);
skin[402606] = P({D[2003], 402606,"CT_SE_402606/celebrate",false,false,"CT_SE_402606/greeting","CT_SE_402606/click"}, get);
skin[402704] = P({D[2003], 402704,"YJS_SE_402704/celebrate",false,false,"YJS_SE_402704/greeting","YJS_SE_402704/click"}, get);
skin[402904] = P({D[2003], 402904,"HYJ_SE_402904/celebrate",false,false,"HYJ_SE_402904/greeting","HYJ_SE_402904/click"}, get);
skin[402907] = P({D[2003], 402907,"HYJ_SE_402907/celebrate",false,false,"HYJ_SE_402907/greeting","HYJ_SE_402907/click"}, get);
skin[403004] = P({D[2003], 403004,"RYL_SE_403004/celebrate",false,false,"RYL_SE_403004/greeting","RYL_SE_403004/click"}, get);
skin[403204] = P({D[2003], 403204,"ALS_SE_403204/celebrate",false,false,"ALS_SE_403204/greeting","ALS_SE_403204/click"}, get);
skin[403206] = P({D[5006], 403206,false,1,"ALS_SE_403206/celebrate","ALS_SE_403206/greeting","ALS_SE_403206/click",false,1}, get);
skin[403304] = P({D[2003], 403304,"SQQSL_SE_403304/celebrate",false,false,"SQQSL_SE_403304/greeting","SQQSL_SE_403304/click",false,1}, get);
skin[403805] = P({D[5006], 403805,false,1,"FUJI_SE_403805/celebrate","FUJI_SE_403805/greeting","",false,1}, get);
skin[403807] = P({D[5006], 403807,false,1,"fj_se_403807/celebrate","fj_se_403807/greeting","fj_se_403807/click"}, get);
skin[404406] = P({D[5006], 404406,false,1,"qhln_se_404406/celebrate","qhln_se_404406/greeting","qhln_se_404406/click"}, get);
skin[404503] = P({D[2003], 404503,"A37_SE_404503/celebrate",false,false,"A37_SE_404503/greeting","A37_SE_404503/click"}, get);
skin[404505] = P({D[5006], 404505,2,1,"A37_SE_404505/celebrate","A37_SE_404505/greeting","A37_SE_404505/click",false,1}, get);
skin[404603] = P({D[2003], 404603,"JCX_SE_404603/celebrate",false,false,"JCX_SE_404603/greeting","JCX_SE_404603/click"}, get);
skin[404704] = P({D[2003], 404704,"LN_SE_404704/celebrate",false,false,"LN_SE_404704/greeting","LN_SE_404704/click"}, get);
skin[404803] = P({D[2003], 404803,"SCLZ_SE_404803/celebrate",false,false,"SCLZ_SE_404803/greeting","SCLZ_SE_404803/click"}, get);
skin[404805] = P({D[5006], 404805,2,1,"LZ_SE_404805/celebrate","LZ_SE_404805/greeting","LZ_SE_404805/click",false,1}, get);
skin[404806] = P({D[2003], 404806,"SCLZ_SE_404806/celebrate",false,false,"SCLZ_SE_404806/greeting","SCLZ_SE_404806/click"}, get);
skin[405004] = P({D[5006], 405004,2,1,"cmm_se_405004/celebrate","cmm_se_405004/greeting","cmm_se_405004/click"}, get);
skin[405104] = P({D[5006], 405104,2,1,"wxz_se_405104/celebrate","wxz_se_405104/greeting","wxz_se_405104/click"}, get);
skin[405202] = P({D[2003], 405202,"XYSYY_SE_405202/celebrate",false,false,"XYSYY_SE_405202/greeting","XYSYY_SE_405202/click","XYSYY_SE_405202/click2"}, get);
skin[405905] = P({D[5006], 405905,false,1,"Y_SE_405905/celebrate","Y_SE_405905/greeting","Y_SE_405905/click",false,1}, get);
skin[405906] = P({D[2003], 405906,"Y_SE_405906/celebrate",false,false,"Y_SE_405906/greeting","Y_SE_405906/click"}, get);
skin[406004] = P({D[2003], 406004,"ZKS_SE_406004/celebrate","ZKS_SE_406004/celebrate_idle",false,"ZKS_SE_406004/greeting","ZKS_SE_406004/click",false,1}, get);
skin[406102] = P({D[2003], 406102,"BYLL_SE_406102/celebrate",false,false,"BYLL_SE_406102/greeting","BYLL_SE_406102/click","BYLL_SE_406102/click2"}, get);
skin[406703] = P({D[2003], 406703,"QL_SE_406703/celebrate",false,false,"QL_SE_406703/greeting","QL_SE_406703/click"}, get);
skin[406704] = P({D[5006], 406704,false,1,"QL_SE_406704/celebrate","QL_SE_406704/greeting","QL_SE_406704/click"}, get);
skin[406803] = P({D[2003], 406803,"RYCY_SE_406803/celebrate",false,false,"RYCY_SE_406803/greeting","RYCY_SE_406803/click"}, get);
skin[406804] = P({D[2003], 406804,"RYCY_SE_406804/celebrate",false,false,"RYCY_SE_406804/greeting","RYCY_SE_406804/click",false,1}, get);
skin[407404] = P({D[5006], 407404,2,1,"LX_SE_407404/celebrate","LX_SE_407404/greeting","LX_SE_407404/click"}, get);
skin[407602] = P({D[2003], 407602,"DCXY_SE_407602/celebrate",false,false,"DCXY_SE_407602/greeting","DCXY_SE_407602/click","DCXY_SE_407602/click2"}, get);
skin[408304] = P({D[5006], 408304,3,1,"yf_se_408304/celebrate","yf_se_408304/greeting","yf_se_408304/click"}, get);
skin[408404] = P({D[2003], 408404,"LL_SE_408404/celebrate",false,false,"LL_SE_408404/greeting","LL_SE_408404/click"}, get);
skin[409003] = P({D[5006], 409003,2,false,"JS_SE_409003/celebrate","JS_SE_409003/greeting","JS_SE_409003/click"}, get);
skin[409203] = P({D[2003], 409203,"j_se_409203/celebrate",false,false,"j_se_409203/greeting","j_se_409203/click"}, get);
skin[409502] = P({D[2003], 409502,"NFH_SE_409502/celebrate",false,false,"NFH_SE_409502/greeting","NFH_SE_409502/click","NFH_SE_409502/click2",1}, get);
skin[409803] = P({D[2003], 409803,"HYQ_SE_409803/celebrate",false,false,"HYQ_SE_409803/greeting","HYQ_SE_409803/click"}, get);
skin[409903] = P({D[5006], 409903,false,1,"HYB_SE_409903/celebrate","HYB_SE_409903/greeting","HYB_SE_409903/click"}, get);
skin[40010703] = P({D[5006], 40010703,2,1,"YX_SE_40010703/celebrate","YX_SE_40010703/greeting","YX_SE_40010703/click"}, get);
skin[40010803] = P({D[5006], 40010803,3,1,"JTY_SE_40010803/celebrate","JTY_SE_40010803/greeting","JTY_SE_40010803/click"}, get);
skin[40010903] = P({D[5006], 40010903,2,1,"YBL_SE_40010903/celebrate","YBL_SE_40010903/greeting","YBL_SE_40010903/click"}, get);
skin[40011003] = P({D[5006], 40011003,2,1,"Saber_SE_40011003/celebrate","Saber_SE_40011003/greeting","Saber_SE_40011003/click"}, get);
skin[40011103] = P({D[5006], 40011103,2,1,"Archer_SE_40011103/celebrate","Archer_SE_40011103/greeting","Archer_SE_40011103/click"}, get);
skin[40011202] = P({D[5006], 40011202,2,1,"LY_SE_40011202/celebrate","LY_SE_40011202/greeting","LY_SE_40011202/click","LY_SE_40011202/click2"}, get);
skin[40011203] = P({D[5006], 40011203,3,1,"LY_SE_40011203/celebrate","LY_SE_40011203/greeting","LY_SE_40011203/click","LY_SE_40011203/click2"}, get);
skin[40011703] = P({D[2003], 40011703,"ml_se_40011703/celebrate",false,false,"ml_se_40011703/greeting","ml_se_40011703/click"}, get);
skin[40012203] = P({D[5006], 40012203,3,1,"tr_se_40012203/celebrate","tr_se_40012203/greeting","tr_se_40012203/click"}, get);
skin[40012303] = P({D[5006], 40012303,2,1,"ysn_se_40012303/celebrate","ysn_se_40012303/greeting","ysn_se_40012303/click"}, get);
skin[40012403] = P({D[5006], 40012403,false,1,"lf_se_40012403/celebrate","lf_se_40012403/greeting","lf_se_40012403/click"}, get);
skin[40012503] = P({D[5006], 40012503,3,1,"sn_se_40012503/celebrate","sn_se_40012503/greeting","sn_se_40012503/click"}, get);
return { tb = skin };