-- 由 Excel 自动生成的 Lua 表
-- 文件:   [chest][chest]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["sort"] = 3; ["name_chs"] = -4; ["name_jp"] = -4; ["name_en"] = -4; ["desc_chs"] = -5; ["desc_jp"] = -5; ["desc_en"] = -5; ["desc_kr"] = -5; ["img"] = 1006; ["gift"] = 7; ["currency"] = 8; ["price"] = 9; ["price10"] = 10; ["ticket_id"] = 11; ["ticket_10_id"] = 12; ["faith_id"] = 13; ["zone"] = 14;};

local df = {  nil, 1, 1,  nil,  nil, "extendRes/treasurehead/treasure_pic1910.png", nil, 100001, 200, 1800, 302001, 309064, 1000, nil,};

local get = function(item, k) return G(item, k, n2i, df, "chest_chest"); end;


local chest = { }
chest[1000] = P({1000,0,false,1,1}, get);
chest[1001] = P({D[6012], 1001,0,false,2,1,1001,1}, get);
chest[1002] = P({1002,0,0,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[1003] = P({D[7012], 1003,0,0,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
chest[1004] = P({1004,false,19,1,1}, get);
chest[1005] = P({D[6012], 1005,false,19,2,1,1001,1}, get);
chest[1006] = P({1006,false,18,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[1007] = P({D[7012], 1007,false,18,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
chest[1008] = P({1008,false,17,1,1}, get);
chest[1009] = P({D[6012], 1009,false,17,2,1,1001,1}, get);
chest[1010] = P({1010,false,5,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[1011] = P({D[7012], 1011,false,5,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
chest[1012] = P({1012,false,16,1,1}, get);
chest[1013] = P({D[6012], 1013,false,16,2,1,1001,1}, get);
chest[1014] = P({1014,false,4,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[1015] = P({D[7012], 1015,false,4,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
chest[1016] = P({1016,false,13,1,1}, get);
chest[1017] = P({D[6012], 1017,false,13,2,1,1001,1}, get);
chest[1018] = P({1018,false,2,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[1019] = P({D[7012], 1019,false,2,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
chest[8000] = P({8000,0,false,1,1}, get);
chest[8001] = P({D[6012], 8001,0,false,2,1,1001,1}, get);
chest[8002] = P({8002,0,0,1,1,"extendRes/treasurehead/treasure_pic0709.png"}, get);
chest[8003] = P({D[7012], 8003,0,0,2,1,"extendRes/treasurehead/treasure_pic0709.png",1001,1}, get);
return { tb = chest };