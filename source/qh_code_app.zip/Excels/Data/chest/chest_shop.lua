-- 由 Excel 自动生成的 Lua 表
-- 文件:   [chest][chest_shop]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["chest_id"] = 2; ["icon"] = 1003; ["name_chs"] = -4; ["name_chs_t"] = -4; ["name_jp"] = -4; ["name_en"] = -4; ["item_id"] = 5; ["price"] = 6; ["need_amount"] = 7; ["check_activity"] = 8; ["launch_time"] = 1009; ["remove_limit_mark"] = 10; ["sort"] = 11;};

local df = {  nil, 1000, nil,  nil, 305605, 50, nil, nil, nil, nil, 1001,};

local get = function(item, k) return G(item, k, n2i, df, "chest_chest_shop"); end;

local b2i = {1117,1231,1357,1480,3070,3163,3263,3369,3999,}

local chest_shop = { }
return { tb = chest_shop, get = get, b2i = b2i };