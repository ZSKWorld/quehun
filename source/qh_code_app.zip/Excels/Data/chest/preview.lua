-- 由 Excel 自动生成的 Lua 表
-- 文件:   [chest][preview]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["chest_id"] = 1; ["item_id"] = 2; ["type"] = 1003; ["check_activity"] = 4;};

local df = {  1004, 305007, "skin", nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {1002,1005,1008,1011,1013,1016,1019,8003,}

local preview = { }
return { tb = preview, get = get, b2i = b2i };