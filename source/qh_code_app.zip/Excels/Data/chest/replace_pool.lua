-- 由 Excel 自动生成的 Lua 表
-- 文件:   [chest][replace_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["resource_id"] = 2; ["is_replace"] = 3; ["add_count"] = 4;};

local df = {  1002, nil, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local replace_pool = { }
replace_pool[1001] = {
	P({1001,200003}, get),
	P({1001,200004}, get),
	P({1001,200005}, get),
	P({1001,200006}, get),
	P({1001,200007}, get),
	P({1001,200008}, get),
	P({1001,200009}, get),
	P({1001,200010}, get),
	P({1001,200016}, get),
	P({1001,200017}, get),
	P({1001,200018}, get),
	P({1001,200019}, get),
	P({1001,200020}, get),
	P({1001,200021}, get),
	P({1001,200024}, get),
	P({1001,200026}, get),
	P({1001,200029,1}, get),
	P({1001,200028,1}, get),
};
replace_pool[1002] = {
	P({false,305001}, get),
	P({false,305002}, get),
	P({false,305003}, get),
	P({false,305007}, get),
	P({false,305008}, get),
	P({false,305009}, get),
	P({false,305010}, get),
	P({false,305011}, get),
	P({false,305012}, get),
	P({false,305013}, get),
	P({false,305014}, get),
	P({false,305015}, get),
	P({false,305016}, get),
	P({false,305017}, get),
	P({false,305018}, get),
	P({false,305019}, get),
	P({false,305021}, get),
	P({false,305022}, get),
	P({false,305023}, get),
	P({false,305025}, get),
	P({false,305026}, get),
	P({false,305032}, get),
	P({false,305033}, get),
	P({false,305034}, get),
	P({false,305035}, get),
	P({false,305036}, get),
	P({false,305037}, get),
	P({false,305038}, get),
	P({false,305039}, get),
	P({false,305040}, get),
	P({false,305041}, get),
	P({false,305042}, get),
	P({false,305050}, get),
	P({false,305051}, get),
	P({false,305046}, get),
	P({false,305200}, get),
	P({false,305300}, get),
	P({false,305600}, get),
	P({false,305700}, get),
	P({false,305208,1}, get),
	P({false,305308,1}, get),
	P({false,305604,1}, get),
	P({false,305702,1}, get),
	P({false,305802,1}, get),
};
return { tb = replace_pool };