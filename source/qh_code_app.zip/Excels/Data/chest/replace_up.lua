-- 由 Excel 自动生成的 Lua 表
-- 文件:   [chest][replace_up]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["replace_pool_id"] = 2; ["count"] = 3; ["activity_id"] = 4; ["count_id"] = 5; ["type"] = 6;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local replace_up = { }
replace_up[100001] = P({100001,1001,3,109899,1001,1}, get);
return { tb = replace_up };