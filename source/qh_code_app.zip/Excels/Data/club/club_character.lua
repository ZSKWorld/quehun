-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["id"] = 2; ["name"] = 3; ["icon"] = 1004; ["image"] = 1005; ["period_task_id"] = 6; ["init_locked"] = 7; ["power"] = 8; ["init_tags"] = 9; ["locked_tags"] = 10; ["skills"] = 11; ["skill_name"] = 12; ["skill_desc"] = 13; ["power_upgrade"] = 14; ["power_upgrade_price"] = 1015; ["tag_upgrade_price"] = 1016; ["max_power"] = 17;};

local df = {  260801, nil, nil, nil, nil, nil, 1, 45, nil, nil, nil, nil, nil, 5, "30900105-1", "30900105-3", 90,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_character = { }
club_character[260801] = {
	P({D[14016], false,3001,20000121,"avatar_character_assistant_01","role_character_assistant_01",false,0,50,S({2,}),S({7,11,}),S({30011,}),26083001,26083101,120}, get),
	P({D[14016], false,3002,200001,"avatar_character_assistant_02","role_character_assistant_02",false,0,25,S({1,}),S({3,}),S({30021,}),26083002,26083102,80}, get),
	P({D[14016], false,3003,20000107,"avatar_character_assistant_03","role_character_assistant_03",26080349,false,60,S({6,}),S({2,}),S({30031,}),26083003,26083103,80}, get),
	P({D[14016], false,3004,200021,"avatar_character_assistant_04","role_character_assistant_04",26080350,false,35,S({1,}),S({6,}),S({30041,}),26083004,26083104,80}, get),
	P({D[14016], false,3005,200069,"avatar_character_assistant_05","role_character_assistant_05",26080351,false,false,S({3,}),S({7,}),S({30051,}),26083005,26083105,80}, get),
	P({D[14016], false,3006,200093,"avatar_character_assistant_06","role_character_assistant_06",26080352,false,75,S({7,}),S({8,}),S({30061,}),26083006,26083106,80}, get),
	P({false,3007,200047,"avatar_character_assistant_07","role_character_assistant_07",26080353,false,90,S({2,}),S({11,}),S({30071,}),26083007,26083107}, get),
	P({D[7008], false,3008,200029,"avatar_character_assistant_08","role_character_assistant_08",26080354,S({7,}),S({2,}),S({30081,}),26083008,26083108}, get),
	P({false,3009,200009,"avatar_character_assistant_09","role_character_assistant_09",26080355,false,85,S({8,}),S({6,3,}),S({30091,}),26083009,26083109}, get),
	P({false,3010,200048,"avatar_character_assistant_10","role_character_assistant_10",26080356,false,70,S({6,}),S({1,8,}),S({30101,}),26083010,26083110}, get),
	P({false,3011,200045,"avatar_character_assistant_11","role_character_assistant_11",26080357,false,75,S({7,}),S({8,2,}),S({30111,}),26083011,26083111}, get),
	P({false,3012,200012,"avatar_character_assistant_12","role_character_assistant_12",26080358,false,35,S({1,}),S({2,3,}),S({30121,}),26083012,26083112}, get),
	P({D[7008], false,3013,200007,"avatar_character_assistant_13","role_character_assistant_13",26080359,S({6,}),S({7,8,}),S({30131,}),26083013,26083113}, get),
	P({D[14016], false,3014,200039,"avatar_character_assistant_14","role_character_assistant_14",26080360,false,75,S({3,}),S({2,6,}),S({30141,}),26083014,26083114,100}, get),
	P({D[14016], false,3015,200044,"avatar_character_assistant_15","role_character_assistant_15",26080361,false,50,S({1,}),S({6,3,}),S({30151,}),26083015,26083115,100}, get),
	P({D[14016], false,3016,200023,"avatar_character_assistant_16","role_character_assistant_16",26080362,false,100,S({11,}),S({2,8,}),S({30161,}),26083016,26083116,100}, get),
};
return { tb = club_character };