-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_character_skill]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["cold_down_time"] = 3; ["args"] = 4;};

local df = {  nil, 6, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_character_skill = { }
club_character_skill[30011] = P({30011,1,false,S({1,})}, get);
club_character_skill[30021] = P({30021,2,false,S({2,1,200,})}, get);
club_character_skill[30031] = P({30031,3,false,S({2,100,5,})}, get);
club_character_skill[30041] = P({30041,4,false,S({2,})}, get);
club_character_skill[30051] = P({30051,5,false,S({2,67,30,})}, get);
club_character_skill[30061] = P({D[2003], 30061,S({2,7,8,200,})}, get);
club_character_skill[30071] = P({30071,7,false,S({2,200,200,})}, get);
club_character_skill[30081] = P({30081,8,false,S({2,200,})}, get);
club_character_skill[30091] = P({30091,9,false,S({2,10,})}, get);
club_character_skill[30101] = P({30101,10,false,S({2,200,})}, get);
club_character_skill[30111] = P({30111,11,false,S({2,60,})}, get);
club_character_skill[30121] = P({30121,12,false,S({2,1,})}, get);
club_character_skill[30131] = P({30131,13,5,S({1,})}, get);
club_character_skill[30141] = P({30141,14,false,S({2,80,})}, get);
club_character_skill[30151] = P({D[2003], 30151,S({2,1,2,200,})}, get);
club_character_skill[30161] = P({30161,17,false,S({2,3,100,})}, get);
return { tb = club_character_skill };