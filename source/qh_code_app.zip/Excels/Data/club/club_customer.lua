-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_customer]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name"] = 2; ["icon"] = 1003; ["image"] = 1004; ["patience"] = 5; ["power"] = 6; ["tags"] = 7; ["moodmin"] = 8; ["moodmax"] = 9; ["room_type"] = 10; ["skills"] = 11; ["skills_desc"] = 12; ["power_desc"] = 13; ["payment_rate"] = 14; ["bind_count"] = 15; ["tip"] = 16;};

local df = {  nil, nil, nil, nil, 40, 50, nil, nil, 4, 1, nil, 26083601, 26085101, 100, 1, 3,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_customer = { }
club_customer[3501] = P({D[9010], 3501,26083501,S({"avatar_character_guest_01",}),S({"role_character_guest_01",}),S({40,60,}),S({30,60,}),S({1,}),2,S({}),false,26085103,false,false,2}, get);
club_customer[3502] = P({3502,26083502,S({"avatar_character_guest_02",}),S({"role_character_guest_02",}),S({40,90,}),S({50,75,}),S({2,}),3,6,false,S({}),false,26085102,75}, get);
club_customer[3503] = P({3503,26083503,S({"avatar_character_guest_03",}),S({"role_character_guest_03",}),S({40,50,}),S({40,70,}),S({3,}),false,3,false,S({}),false,26085103,125,false,5}, get);
club_customer[3504] = P({3504,26083504,S({"avatar_character_guest_04",}),S({"role_character_guest_04",}),S({40,100,}),S({10,85,}),S({6,}),false,3,false,S({}),false,26085106,50,false,0}, get);
club_customer[3505] = P({3505,26083505,S({"avatar_character_guest_05",}),S({"role_character_guest_05",}),S({40,55,}),S({30,65,}),S({7,}),false,3,false,S({35051,}),26083602,26085104}, get);
club_customer[3506] = P({3506,26083506,S({"avatar_character_guest_06","avatar_character_guest_07",}),S({"role_character_guest_06","role_character_guest_07",}),S({40,60,}),S({10,40,}),S({8,}),1,3,false,S({}),26083603,26085105,false,2,6}, get);
club_customer[3507] = P({D[9010], 3507,26083507,S({"avatar_character_guest_08",}),S({"role_character_guest_08",}),S({40,65,}),S({60,95,}),S({3,}),2,S({}),26083604,26085102,false,4,2}, get);
club_customer[3508] = P({D[13015], 3508,26083508,S({"avatar_character_guest_09",}),S({"role_character_guest_09",}),S({40,100,}),S({70,90,}),S({2,}),false,5,2,S({35081,}),26083605,5}, get);
club_customer[3509] = P({3509,26083509,S({"avatar_character_guest_10",}),S({"role_character_guest_10",}),S({40,50,}),S({20,60,}),S({1,7,}),false,5,2,S({35091,}),26083606,26085104,125,false,10}, get);
club_customer[3510] = P({D[8009], 3510,26083510,S({"avatar_character_guest_11",}),S({"role_character_guest_11",}),S({40,60,}),S({40,70,}),S({1,8,}),2,S({35101,}),26083607,false,75,false,6}, get);
club_customer[3511] = P({3511,26083511,S({"avatar_character_guest_12",}),S({"role_character_guest_12",}),S({40,50,}),S({50,80,}),S({3,6,}),2,false,2,S({35111,}),26083608,26085102,125,false,4}, get);
club_customer[3512] = P({D[8010], 3512,26083512,S({"avatar_character_guest_13",}),S({"role_character_guest_13",}),S({40,50,}),S({80,90,}),S({2,7,}),S({35121,}),26083609,false,75,false,0}, get);
club_customer[3513] = P({D[8009], 3513,26083513,S({"avatar_character_guest_14",}),S({"role_character_guest_14",}),S({40,80,}),S({90,100,}),S({2,8,}),2,S({35131,35132,}),26083610,false,150,false,8}, get);
club_customer[3514] = P({D[8010], 3514,26083514,S({"avatar_character_guest_15",}),S({"role_character_guest_15",}),S({40,100,}),S({10,20,}),S({6,7,}),S({35141,}),26083611,26085105,150}, get);
club_customer[3515] = P({3515,26083515,S({"avatar_character_guest_16",}),S({"role_character_guest_16",}),S({40,50,}),S({50,50,}),S({1,8,}),false,1,2,S({35151,}),26083612,26085103,200,false,0}, get);
club_customer[3516] = P({D[8009], 3516,26083516,S({"avatar_character_guest_17",}),S({"role_character_guest_17",}),S({40,50,}),S({60,85,}),S({1,7,8,}),3,S({35161,}),26083613,26085102,125,false,8}, get);
club_customer[3517] = P({3517,26083517,S({"avatar_character_guest_18",}),S({"role_character_guest_18",}),S({40,60,}),S({85,95,}),S({2,3,8,}),false,1,3,S({35171,35172,}),26083614,false,200,false,15}, get);
club_customer[3518] = P({3518,26083518,S({"avatar_character_guest_19",}),S({"role_character_guest_19",}),S({40,50,}),S({50,75,}),S({3,6,7,}),2,false,3,S({35181,}),26083615,26085103,150,false,8}, get);
return { tb = club_customer };