-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_customer_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["customer_id"] = 2; ["weight"] = 3;};

local df = {  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_customer_pool = { }
club_customer_pool[26080011] = P({26080011,S({3501,}),S({100,})}, get);
club_customer_pool[26080021] = P({26080021,S({3501,3502,}),S({50,50,})}, get);
club_customer_pool[26080031] = P({26080031,S({3501,3502,3504,}),S({50,10,40,})}, get);
club_customer_pool[26080041] = P({26080041,S({3501,3502,3512,}),S({30,50,20,})}, get);
club_customer_pool[26080051] = P({26080051,S({3501,3502,3506,}),S({30,30,40,})}, get);
club_customer_pool[26080061] = P({26080061,S({3501,3502,3510,}),S({40,40,20,})}, get);
club_customer_pool[26080071] = P({26080071,S({3501,3502,3507,}),S({30,40,30,})}, get);
club_customer_pool[26080081] = P({26080081,S({3501,3502,3514,}),S({30,30,40,})}, get);
club_customer_pool[26080091] = P({26080091,S({3502,3508,3509,}),S({30,50,20,})}, get);
club_customer_pool[26080101] = P({26080101,S({3502,3513,3515,}),S({50,30,20,})}, get);
club_customer_pool[26080111] = P({26080111,S({3501,3516,3511,}),S({60,10,30,})}, get);
club_customer_pool[26080121] = P({26080121,S({3501,3516,3503,3505,}),S({20,20,30,30,})}, get);
club_customer_pool[26080131] = P({26080131,S({3512,3514,}),S({50,50,})}, get);
club_customer_pool[26080141] = P({26080141,S({3502,3503,3511,}),S({20,50,30,})}, get);
club_customer_pool[26080151] = P({26080151,S({3501,3502,3507,}),S({15,15,70,})}, get);
club_customer_pool[26080161] = P({26080161,S({3512,3505,3515,3509,}),S({10,50,30,10,})}, get);
club_customer_pool[26080171] = P({26080171,S({3501,3502,3508,3513,}),S({10,20,50,20,})}, get);
club_customer_pool[26080181] = P({26080181,S({3501,3502,3517,}),S({10,10,80,})}, get);
club_customer_pool[26080191] = P({26080191,S({3501,3502,3510,3516,}),S({20,20,30,30,})}, get);
club_customer_pool[26080201] = P({26080201,S({3501,3502,3518,3517,3515,}),S({15,15,40,15,15,})}, get);
club_customer_pool[26080211] = P({26080211,S({3518,}),S({100,})}, get);
club_customer_pool[26080221] = P({26080221,S({3518,}),S({100,})}, get);
club_customer_pool[26080231] = P({26080231,S({3518,}),S({100,})}, get);
club_customer_pool[26080241] = P({26080241,S({3518,}),S({100,})}, get);
club_customer_pool[26080251] = P({26080251,S({3518,}),S({100,})}, get);
club_customer_pool[26080261] = P({26080261,S({3518,}),S({100,})}, get);
club_customer_pool[26080271] = P({26080271,S({3518,}),S({100,})}, get);
club_customer_pool[26080281] = P({26080281,S({3518,}),S({100,})}, get);
club_customer_pool[26080291] = P({26080291,S({3518,}),S({100,})}, get);
club_customer_pool[26080301] = P({26080301,S({3518,}),S({100,})}, get);
return { tb = club_customer_pool };