-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_customer_skill]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["args"] = 3;};

local df = {  nil, 8, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_customer_skill = { }
club_customer_skill[35051] = P({35051,1,S({0,20,3512,3514,3518,})}, get);
club_customer_skill[35081] = P({35081,2,S({0,})}, get);
club_customer_skill[35091] = P({35091,4,S({1,})}, get);
club_customer_skill[35101] = P({35101,5,S({})}, get);
club_customer_skill[35111] = P({35111,6,S({0,20,})}, get);
club_customer_skill[35121] = P({35121,7,S({60,})}, get);
club_customer_skill[35131] = P({35131,false,S({1,25,})}, get);
club_customer_skill[35132] = P({35132,false,S({3,200,})}, get);
club_customer_skill[35141] = P({35141,14,S({3514,20,})}, get);
club_customer_skill[35151] = P({35151,10,S({75,500,})}, get);
club_customer_skill[35161] = P({35161,15,S({200,3503,3511,})}, get);
club_customer_skill[35171] = P({35171,12,S({200,})}, get);
club_customer_skill[35172] = P({35172,3,S({0,20,})}, get);
club_customer_skill[35181] = P({35181,13,S({50,})}, get);
return { tb = club_customer_skill };