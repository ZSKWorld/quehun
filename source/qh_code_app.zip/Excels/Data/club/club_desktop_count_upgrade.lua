-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_desktop_count_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["upgrade_id"] = 1; ["level"] = 2; ["additional_desktop_count"] = 3; ["price"] = 1004;};

local df = {  1021, 1, 1, "30900106-1000",};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_desktop_count_upgrade = { }
club_desktop_count_upgrade[1021] = {
	P({D[1003], "30900106-300"}, get),
	P({false,2,2,"30900106-600"}, get),
	P({false,3,3}, get),
};
club_desktop_count_upgrade[1022] = {
	P({D[2003], 1022,"30900106-600"}, get),
	P({1022,2,2}, get),
	P({1022,3,3,"30900106-1500"}, get),
};
club_desktop_count_upgrade[1023] = {
	P({1023}, get),
	P({1023,2,2,"30900106-2000"}, get),
};
return { tb = club_desktop_count_upgrade };