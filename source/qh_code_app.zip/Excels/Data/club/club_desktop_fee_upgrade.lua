-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_desktop_fee_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["upgrade_id"] = 1; ["level"] = 2; ["additional_desktop_fee"] = 3; ["price"] = 1004;};

local df = {  1011, 1, 20, "30900105-20",};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_desktop_fee_upgrade = { }
club_desktop_fee_upgrade[1011] = {
	P({D[1002], 10,"30900105-8"}, get),
	P({false,2,false,"30900105-13"}, get),
	P({false,3,30}, get),
};
club_desktop_fee_upgrade[1012] = {
	P({D[2003], 1012,"30900105-10"}, get),
	P({1012,2,50,"30900105-18"}, get),
	P({1012,3,90,"30900105-24"}, get),
};
club_desktop_fee_upgrade[1013] = {
	P({1013,false,50,"30900105-12"}, get),
	P({1013,2,120}, get),
	P({1013,3,220,"30900105-36"}, get),
};
return { tb = club_desktop_fee_upgrade };