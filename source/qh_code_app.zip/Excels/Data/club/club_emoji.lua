-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_emoji]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["mood"] = 2; ["mood_rate"] = 3; ["tip_rate"] = 4; ["tip_assistant_rate"] = 5; ["icon"] = 1006;};

local df = {  nil, 100, 100, nil, nil, "guest_emoji_4",};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_emoji = { }
club_emoji[1] = P({1,S({100,999999,}),150,75,100,"guest_emoji_1"}, get);
club_emoji[2] = P({2,S({80,100,}),120,50,75,"guest_emoji_2"}, get);
club_emoji[3] = P({3,S({60,80,}),110,40,65,"guest_emoji_3"}, get);
club_emoji[4] = P({4,S({40,60,}),false,30,55}, get);
club_emoji[5] = P({5,S({2,40,}),false,20,45}, get);
club_emoji[6] = P({6,S({1,2,}),false,10,35}, get);
club_emoji[7] = P({7,S({0,0,}),false,0,25}, get);
return { tb = club_emoji };