-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_event_effect]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["positivity"] = 3; ["result_desc"] = 4; ["args"] = 5;};

local df = {  nil, 2, 1, 26084802, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_event_effect = { }
club_event_effect[4501] = P({4501,1,3,26084801,S({})}, get);
club_event_effect[4502] = P({D[2004], 4502,S({30,})}, get);
club_event_effect[4503] = P({D[2004], 4503,S({60,})}, get);
club_event_effect[4504] = P({D[2004], 4504,S({100,})}, get);
club_event_effect[4505] = P({4505,3,2,26084803,S({30,})}, get);
club_event_effect[4506] = P({4506,3,2,26084803,S({60,})}, get);
club_event_effect[4507] = P({4507,3,2,26084803,S({2000,})}, get);
club_event_effect[4508] = P({4508,4,false,26084804,S({10,})}, get);
club_event_effect[4509] = P({4509,4,false,26084805,S({20,})}, get);
club_event_effect[4510] = P({4510,5,2,26084806,S({10,})}, get);
club_event_effect[4511] = P({4511,5,2,26084807,S({20,})}, get);
return { tb = club_event_effect };