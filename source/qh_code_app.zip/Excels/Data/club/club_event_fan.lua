-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_event_fan]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["val"] = 2; ["name"] = 3;};

local df = {  nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_event_fan = { }
club_event_fan[1] = P({1}, get);
club_event_fan[2] = P({2}, get);
club_event_fan[3] = P({3}, get);
club_event_fan[4] = P({4}, get);
club_event_fan[5] = P({5}, get);
club_event_fan[6] = P({6}, get);
club_event_fan[7] = P({7}, get);
club_event_fan[8] = P({8}, get);
club_event_fan[9] = P({9}, get);
club_event_fan[10] = P({10}, get);
club_event_fan[11] = P({11}, get);
club_event_fan[12] = P({12}, get);
club_event_fan[13] = P({13}, get);
club_event_fan[14] = P({14}, get);
club_event_fan[15] = P({15,2}, get);
club_event_fan[16] = P({16,2}, get);
club_event_fan[17] = P({17,2}, get);
club_event_fan[18] = P({18,2}, get);
club_event_fan[19] = P({19,2}, get);
club_event_fan[20] = P({20,2}, get);
club_event_fan[21] = P({21,2}, get);
club_event_fan[22] = P({22,2}, get);
club_event_fan[23] = P({23,2}, get);
club_event_fan[24] = P({24,2}, get);
club_event_fan[25] = P({25,2}, get);
club_event_fan[26] = P({26,3}, get);
club_event_fan[27] = P({27,3}, get);
club_event_fan[28] = P({28,3}, get);
club_event_fan[29] = P({29,6}, get);
club_event_fan[30] = P({30}, get);
club_event_fan[35] = P({35,13}, get);
club_event_fan[36] = P({36,13}, get);
club_event_fan[37] = P({37,13}, get);
club_event_fan[38] = P({38,13}, get);
club_event_fan[39] = P({39,13}, get);
club_event_fan[40] = P({40,13}, get);
club_event_fan[41] = P({41,13}, get);
club_event_fan[42] = P({42,13}, get);
club_event_fan[43] = P({43,13}, get);
club_event_fan[44] = P({44,13}, get);
club_event_fan[45] = P({45,13}, get);
club_event_fan[47] = P({47,26}, get);
club_event_fan[48] = P({48,26}, get);
club_event_fan[49] = P({49,26}, get);
club_event_fan[50] = P({50,26}, get);
return { tb = club_event_fan };