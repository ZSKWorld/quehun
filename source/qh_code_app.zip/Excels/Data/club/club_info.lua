-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["init_wait_time"] = 2; ["wait_zone_upgrade"] = 3; ["init_level"] = 4; ["init_moodmin"] = 5; ["init_moodmax"] = 6; ["tag_mood"] = 7; ["ticks_per_minute"] = 8; ["init_battle_time"] = 9; ["battle_time_min"] = 10; ["game_total_time"] = 11; ["game_hurry_time"] = 12; ["mood_judge_time"] = 13; ["event_judge_time"] = 14; ["tip_disappear_time"] = 15; ["event_rate"] = 16; ["tenpai_rate"] = 17;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_info = { }
club_info[260801] = P({260801,45,1001,2608001,-10,10,10,5,360,30,720,600,30,30,240,3,65}, get);
return { tb = club_info };