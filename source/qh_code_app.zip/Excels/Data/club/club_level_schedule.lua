-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_level_schedule]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["club_level_schedule_id"] = 1; ["time"] = 2; ["customer_weight"] = 3;};

local df = {  26080921, 600, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {26080918,26080927,26080934,26080940,}

local club_level_schedule = { }
return { tb = club_level_schedule, get = get, b2i = b2i };