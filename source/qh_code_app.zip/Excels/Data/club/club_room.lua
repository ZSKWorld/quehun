-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_room]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["room_id"] = 2; ["room_name"] = 3; ["init_locked"] = 4; ["init_desktop_count"] = 5; ["max_desktop_count"] = 6; ["init_desktop_fee"] = 7; ["unlock_price"] = 1008; ["desktop_fee_upgrade_id"] = 9; ["desktop_count_upgrade"] = 10;};

local df = {  260801, nil, nil, 1, 1, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_room = { }
club_room[260801] = {
	P({false,1,26081001,0,2,5,10,"",1011,1021}, get),
	P({D[4005], false,2,26081002,4,30,"30900106-1000",1012,1022}, get),
	P({D[4005], false,3,26081003,3,100,"30900106-3000",1013,1023}, get),
};
return { tb = club_room };