-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_tag]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name"] = 2; ["image"] = 1003;};

local df = {  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_tag = { }
club_tag[1] = P({1,26085001,"character_tag_01"}, get);
club_tag[2] = P({2,26085002,"character_tag_02"}, get);
club_tag[3] = P({3,26085003,"character_tag_03"}, get);
club_tag[4] = P({4,26085004,"character_tag_04"}, get);
club_tag[5] = P({5,26085005,"character_tag_05"}, get);
club_tag[6] = P({6,26085006,"character_tag_06"}, get);
club_tag[7] = P({7,26085007,"character_tag_07"}, get);
club_tag[8] = P({8,26085008,"character_tag_08"}, get);
club_tag[9] = P({9,26085009,"character_tag_09"}, get);
club_tag[10] = P({10,26085010,"character_tag_10"}, get);
club_tag[11] = P({11,26085011,"character_tag_11"}, get);
return { tb = club_tag };