-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_tip]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["count"] = 2; ["image"] = 1003; ["image_number"] = 1004;};

local df = {  nil, 100, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_tip = { }
club_tip[1] = P({1,S({100,99999999,}),"icon_jinbi_h","jinbi_h_{0}"}, get);
club_tip[2] = P({2,S({25,100,}),"icon_jinbi_m","jinbi_m_{0}"}, get);
club_tip[3] = P({3,S({0,25,}),"icon_jinbi_l","jinbi_l_{0}"}, get);
return { tb = club_tip };