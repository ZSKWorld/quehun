-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_wait_zone_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["additional_wait_time"] = 3; ["display_value"] = 4; ["price"] = 1005;};

local df = {  1001, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_wait_zone_upgrade = { }
club_wait_zone_upgrade[1001] = {
	P({false,1,30,150,"30900106-400"}, get),
	P({false,2,60,200,"30900106-700"}, get),
	P({false,3,90,250,"30900106-1000"}, get),
	P({false,4,120,300,"30900106-1300"}, get),
	P({false,5,150,350,"30900106-1600"}, get),
	P({false,6,180,400,"30900106-2000"}, get),
};
return { tb = club_wait_zone_upgrade };