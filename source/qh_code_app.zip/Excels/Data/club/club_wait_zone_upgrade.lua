-- 由 Excel 自动生成的 Lua 表
-- 文件:   [club][club_wait_zone_upgrade]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level"] = 2; ["additional_wait_time"] = 3; ["price"] = 1004;};

local df = {  1001, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local club_wait_zone_upgrade = { }
club_wait_zone_upgrade[1001] = {
	P({false,1,15,"30900106-400"}, get),
	P({false,2,30,"30900106-700"}, get),
	P({false,3,45,"30900106-1000"}, get),
	P({false,4,60,"30900106-1300"}, get),
	P({false,5,75,"30900106-1700"}, get),
	P({false,6,90,"30900106-2100"}, get),
};
return { tb = club_wait_zone_upgrade };