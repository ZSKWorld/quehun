-- 由 Excel 自动生成的 Lua 表
-- 文件:   [compose][characompose]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["item_id"] = 2; ["item_num"] = 3; ["chara_id"] = 4;};

local df = {  nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local characompose = { }
characompose[1] = P({1,300001,100,200004}, get);
return { tb = characompose };