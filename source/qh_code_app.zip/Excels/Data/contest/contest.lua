-- 由 Excel 自动生成的 Lua 表
-- 文件:   [contest][contest]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1001; ["int_value"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local contest = { }
contest["contest_create_price"] = P({"contest_create_price",60}, get);
return { tb = contest };