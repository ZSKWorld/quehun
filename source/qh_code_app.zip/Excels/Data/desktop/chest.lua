-- 由 Excel 自动生成的 Lua 表
-- 文件:   [desktop][chest]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["exp_step"] = 2; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["icon"] = 1004; ["reward_pool"] = 5; ["select_count"] = 6; ["repeated"] = 7;};

local df = {  nil, 1000, nil, nil, nil, 2, 1,};

local get = function(item, k) return G(item, k, n2i, df, "desktop_chest"); end;


local chest = { }
chest[1] = P({1,false,1,"extendRes/items/present_silver.png",10000}, get);
chest[2] = P({2,false,2,"extendRes/items/present_gold.png",10001}, get);
chest[3] = P({3,false,3,"extendRes/items/present_jade.png",10002}, get);
chest[4] = P({4,false,4,"extendRes/items/present_king.png",10003}, get);
chest[5] = P({5,false,5,"extendRes/items/present_yiji.png",10004}, get);
return { tb = chest };