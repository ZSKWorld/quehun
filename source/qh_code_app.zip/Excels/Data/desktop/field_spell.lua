-- 由 Excel 自动生成的 Lua 表
-- 文件:   [desktop][field_spell]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["field"] = 1; ["id"] = 2; ["cardname"] = 1003; ["sord_card_id"] = 4;};

local df = {  1, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local field_spell = { }
field_spell[1] = P({false,1,"风纪",1}, get);
field_spell[2] = P({false,2,"永夜",2}, get);
field_spell[3] = P({false,3,"没收",3}, get);
field_spell[4] = P({false,4,"炒作",4}, get);
field_spell[5] = P({false,5,"赠品",5}, get);
field_spell[100] = P({2,100,"里世界",6}, get);
field_spell[200] = P({2,200,"三倍速",7}, get);
field_spell[300] = P({2,300,"金闪闪",8}, get);
field_spell[400] = P({2,400,"超断幺",9}, get);
field_spell[500] = P({2,500,"胜负手",10}, get);
field_spell[10000] = P({3,10000,"夸大其词",11}, get);
field_spell[20000] = P({3,20000,"过度准备",12}, get);
field_spell[30000] = P({3,30000,"厄运沙漏",13}, get);
field_spell[40000] = P({3,40000,"暗中交易",14}, get);
field_spell[50000] = P({3,50000,"爱的代价",15}, get);
return { tb = field_spell };