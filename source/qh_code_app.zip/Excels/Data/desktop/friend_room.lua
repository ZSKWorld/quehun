-- 由 Excel 自动生成的 Lua 表
-- 文件:   [desktop][friend_room]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["pre_rule"] = 1002; ["sort"] = 3; ["str_name"] = 1004; ["str_rule"] = 1005; ["set_jushu"] = 6; ["rule_images"] = 1007;};

local df = {  nil, nil, nil, nil, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local friend_room = { }
friend_room[1] = P({1,false,1,"3294","4300",false,S({"extendRes/rules_room/siren.png",})}, get);
friend_room[2] = P({2,false,2,"3295","57",false,S({"extendRes/rules_room/sanren.png",})}, get);
friend_room[3] = P({3,"xuezhandaodi",3,"3384","3390",0,S({"extendRes/rules_room/xiuluo.png",})}, get);
friend_room[4] = P({4,"jiuchao",4,"3517","3527",false,S({"extendRes/rules_room/mingjing.png",})}, get);
friend_room[5] = P({5,"reveal_discard",5,"3518","3528",false,S({"extendRes/rules_room/anye1.png","extendRes/rules_room/anye2.png",})}, get);
friend_room[6] = P({6,"chuanma",6,"3394","3650",0,S({"extendRes/rules_room/chiyu1.png","extendRes/rules_room/chiyu2.png",})}, get);
friend_room[7] = P({7,"dora3",7,"3655","3651",false,S({"extendRes/rules_room/baopai.png",})}, get);
friend_room[8] = P({8,"field_spell",8,"3586","3588",0,S({"extendRes/rules_room/huanjing.png",})}, get);
friend_room[9] = P({9,"zhanxing",9,"3700","3705",false,S({"extendRes/rules_room/zhanxing.png",})}, get);
friend_room[10] = P({10,"tianming",10,"3877","3857",false,S({"extendRes/rules_room/tianming1.png","extendRes/rules_room/tianming2.png",})}, get);
friend_room[11] = P({11,"yongchang",11,"3981","3987",false,S({"extendRes/rules_room/yongchang1.png","extendRes/rules_room/yongchang2.png",})}, get);
friend_room[12] = P({12,"hunzhiyiji",12,"4206","4208",false,S({"extendRes/rules_room/hunzhiyiji1.png","extendRes/rules_room/hunzhiyiji2.png",})}, get);
friend_room[13] = P({13,"wanxiangxiuluo",13,"20193","20194",false,S({"extendRes/rules_room/wanxiang1.png","extendRes/rules_room/wanxiang2.png",})}, get);
friend_room[14] = P({14,"longzhimuyu",14,"20198","20422",false,S({"extendRes/rules_room/longzhimuyu1.png","extendRes/rules_room/longzhimuyu2.png",})}, get);
friend_room[15] = P({15,"beishui",15,"25040020","25040508",false,S({"extendRes/rules_room/beishui.png",})}, get);
friend_room[16] = P({16,"xiakeshang",16,"25101012","25101014",false,S({"extendRes/rules_room/xiakeshang.png",})}, get);
friend_room[17] = P({17,"qiangduozhizhan",17,"26041083","26041086",false,S({"extendRes/rules_room/qiangduozhizhan1.png","extendRes/rules_room/qiangduozhizhan2.png",})}, get);
return { tb = friend_room };