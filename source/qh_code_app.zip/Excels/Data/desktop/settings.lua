-- 由 Excel 自动生成的 Lua 表
-- 文件:   [desktop][settings]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["key"] = 1001; ["int_value"] = 2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local settings = { }
settings["account_friendship_bar_length"] = P({"account_friendship_bar_length",1000}, get);
settings["account_friendship_bar_reward_id"] = P({"account_friendship_bar_reward_id",303991}, get);
return { tb = settings };