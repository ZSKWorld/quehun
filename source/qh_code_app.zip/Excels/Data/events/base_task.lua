-- 由 Excel 自动生成的 Lua 表
-- 文件:   [events][base_task]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["desc_chs"] = -2; ["desc_chs_t"] = -2; ["desc_jp"] = -2; ["desc_en"] = -2; ["desc_kr"] = -2; ["type"] = 3; ["target"] = 4; ["param"] = 1005;};

local df = {  nil,  nil, 42, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df, "events_base_task"); end;

local b2i = {20183,20702,21063,21222,21541,21763,21910,22115,22314,22465,22639,22777,22951,23093,23231,23594,91506,93017,99027,800018,}

local base_task = { }
return { tb = base_task, get = get, b2i = b2i };