-- 由 Excel 自动生成的 Lua 表
-- 文件:   [events][dailyevent]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["reward_type"] = 2; ["reward_num"] = 3; ["desc_chs"] = -4; ["desc_chs_t"] = -4; ["desc_jp"] = -4; ["desc_en"] = -4; ["desc_kr"] = -4; ["active_type"] = 5; ["type"] = 6; ["target"] = 7; ["param"] = 1008; ["level_limit"] = 1009;};

local df = {  nil, 100002, 3800,  nil, nil, 22, 2, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "events_dailyevent"); end;

local b2i = {23020,30042,}

local dailyevent = { }
return { tb = dailyevent, get = get, b2i = b2i };