-- 由 Excel 自动生成的 Lua 表
-- 文件:   [events][soscoin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["level_limit"] = 2; ["level3_limit"] = 3; ["gold_limit"] = 4; ["gold_num"] = 5; ["desc_chs"] = -6; ["desc_chs_t"] = -6; ["desc_jp"] = -6; ["desc_en"] = -6; ["desc_kr"] = -6;};

local df = {  nil, nil, nil, 18000, 18000,  nil,};

local get = function(item, k) return G(item, k, n2i, df, "events_soscoin"); end;


local soscoin = { }
soscoin[101] = P({101,10101,20101,0,0,1}, get);
soscoin[102] = P({102,10102,20102,0,0,1}, get);
soscoin[103] = P({103,10103,20103,0,0,1}, get);
soscoin[104] = P({104,10201,20201,4500,4500,2}, get);
soscoin[105] = P({105,10202,20202,4500,4500,2}, get);
soscoin[106] = P({106,10203,20203,4500,4500,2}, get);
soscoin[107] = P({107,10301,20301,9000,9000,3}, get);
soscoin[108] = P({108,10302,20302,9000,9000,3}, get);
soscoin[109] = P({109,10303,20303,9000,9000,3}, get);
soscoin[110] = P({D[4005], 110,10401,20401,4}, get);
soscoin[111] = P({D[4005], 111,10402,20402,4}, get);
soscoin[112] = P({D[4005], 112,10403,20403,4}, get);
soscoin[113] = P({D[4005], 113,10501,20501,5}, get);
soscoin[114] = P({D[4005], 114,10502,20502,5}, get);
soscoin[115] = P({D[4005], 115,10503,20503,5}, get);
soscoin[116] = P({D[4005], 116,10601,20601,6}, get);
return { tb = soscoin };