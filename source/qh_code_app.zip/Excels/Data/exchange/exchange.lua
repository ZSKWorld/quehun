-- 由 Excel 自动生成的 Lua 表
-- 文件:   [exchange][exchange]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["source_currency"] = 2; ["source_value"] = 3; ["target_currency"] = 4; ["target_value"] = 5; ["icon"] = 1006; ["name_chs"] = -7; ["name_chs_t"] = -7; ["name_jp"] = -7; ["name_en"] = -7; ["name_kr"] = -7; ["desc_chs"] = -8; ["desc_chs_t"] = -8; ["desc_jp"] = -8; ["desc_en"] = -8; ["desc_kr"] = -8;};

local df = {  nil, 100001, nil, 100002, nil, nil, nil,  nil,};

local get = function(item, k) return G(item, k, n2i, df, "exchange_exchange"); end;


local exchange = { }
exchange[2001] = P({2001,false,10,false,5000,"extendRes/items/coin0.jpg",1,1}, get);
exchange[2002] = P({2002,false,60,false,30000,"extendRes/items/coin1.jpg",2,1}, get);
exchange[2003] = P({2003,false,120,false,60000,"extendRes/items/coin2.jpg",3,1}, get);
exchange[2004] = P({2004,false,600,false,300000,"extendRes/items/coin3.jpg",4,1}, get);
exchange[2005] = P({2005,false,1000,false,500000,"extendRes/items/coin4.jpg",5,1}, get);
exchange[2006] = P({2006,false,2000,false,1000000,"extendRes/items/coin5.jpg",6,1}, get);
return { tb = exchange };