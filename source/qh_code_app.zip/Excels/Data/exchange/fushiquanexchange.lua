-- 由 Excel 自动生成的 Lua 表
-- 文件:   [exchange][fushiquanexchange]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["source_currency"] = 2; ["source_value"] = 3; ["target_currency"] = 4; ["target_value"] = 5; ["icon"] = 1006; ["name_chs"] = -7; ["name_chs_t"] = -7; ["name_jp"] = -7; ["name_en"] = -7; ["name_kr"] = -7; ["desc_chs"] = -8; ["desc_chs_t"] = -8; ["desc_jp"] = -8; ["desc_en"] = -8; ["desc_kr"] = -8;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "exchange_fushiquanexchange"); end;


local fushiquanexchange = { }
fushiquanexchange[4001] = P({4001,100004,10,100001,10,"extendRes/items/jade0.jpg",1,1}, get);
return { tb = fushiquanexchange };