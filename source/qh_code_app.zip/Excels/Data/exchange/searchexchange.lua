-- 由 Excel 自动生成的 Lua 表
-- 文件:   [exchange][searchexchange]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["source_currency"] = 2; ["source_value"] = 3; ["target_currency"] = 4; ["target_value"] = 5; ["icon"] = 1006; ["name_chs"] = -7; ["name_chs_t"] = -7; ["name_jp"] = -7; ["name_en"] = -7; ["name_kr"] = -7; ["desc_chs"] = -8; ["desc_chs_t"] = -8; ["desc_jp"] = -8; ["desc_en"] = -8; ["desc_kor"] = 1009;};

local df = {  nil, 100001, nil, 302014, nil, "extendRes/items/xunmihuishi.jpg", nil,  nil, "기원에 필요한 휘석",};

local get = function(item, k) return G(item, k, n2i, df, "exchange_searchexchange"); end;


local searchexchange = { }
searchexchange[3001] = P({3001,false,200,false,200,false,1,1}, get);
searchexchange[3002] = P({3002,false,1800,false,1800,false,2,1}, get);
return { tb = searchexchange };