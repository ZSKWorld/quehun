-- 由 Excel 自动生成的 Lua 表
-- 文件:   [fandesc][fandesc]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["tag"] = 2; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["desc_chs"] = -4; ["desc_chs_t"] = -4; ["desc_jp"] = -4; ["desc_en"] = -4; ["desc_kr"] = -4; ["desc2_chs"] = -5; ["desc2_chs_t"] = -5; ["desc2_jp"] = -5; ["desc2_en"] = -5; ["desc2_kr"] = -5; ["case"] = 1006; ["show"] = 7; ["mode"] = 8;};

local df = {  nil, 1,  nil,  nil,  nil, "1m2m3m4p4p4p5s6s7s1z1z1z2z|2z", 1, nil,};

local get = function(item, k) return G(item, k, n2i, df, "fandesc_fandesc"); end;


local fandesc = { }
fandesc[101] = P({101,false,1,1,1}, get);
fandesc[102] = P({102,false,2,2,false,"2m3m4m|5m6m7m|3p3p3p|4s5s6s|8s|8s"}, get);
fandesc[103] = P({103,false,3,3,1,"1m1m1m2m3m4m3p3p3p7s8s9s4z|4z"}, get);
fandesc[104] = P({104,false,4,4,false,"3m3m3m4p5p6p7s8s9s|3z3z3z|1s|1s"}, get);
fandesc[105] = P({105,false,5,5,false,"3m3m3m4p5p6p7s8s9s|1z1z1z|1s|1s"}, get);
fandesc[106] = P({106,false,6,6,false,"3m3m3m4p5p6p7s8s9s|5z5z5z|1s|1s"}, get);
fandesc[107] = P({107,false,7,7,1,"1m2m3m5m6m7m2p3p4p6s7s9s9s|5s"}, get);
fandesc[108] = P({108,false,8,8,1,"1m2m3m1m2m3m4p4p4p7p8p9p3s|3s"}, get);
fandesc[109] = P({109,false,9,9,false,"1p1p1p|1p"}, get);
fandesc[110] = P({110,false,10,10,false,"2m3m4m5p5p5p3s4s5s6s|8s8s8s8s|3s"}, get);
fandesc[111] = P({111,false,11,11,false,"2m2m2m|4p5p6p|3s3s3s|9s9s9s|1z|1z"}, get);
fandesc[112] = P({112,false,12,12,false,"2m2m2m|4p5p6p|3s3s3s|9s9s9s|1z|1z"}, get);
fandesc[113] = P({113,false,13,13,2}, get);
fandesc[114] = P({114,false,14,14,3,"3sbbbb|4s"}, get);
fandesc[115] = P({115,false,15,15,3,"0m|0p|0s"}, get);
fandesc[116] = P({116,false,16,16,3,"4z"}, get);
fandesc[117] = P({117,false,17,17,4,"1m2m3m4p4p4p5s6s7s1z1z1z|2z|2z"}, get);
fandesc[118] = P({118,false,18,18,4,"1m2m3m4p4p4p5s6s7s1z1z1z|2z|2z"}, get);
fandesc[119] = P({119,false,19,19,4,"2m3m4m|5m6m7m|3p3p3p|4s5s6s|8s|8s"}, get);
fandesc[201] = P({201,2,20,20,1,"1m2m3m4m4m4m5p6p7p5z5z5z6z|6z"}, get);
fandesc[202] = P({202,2,21,21,false,"3m3m3m|3p3p3p|3s3s3s|5s6s7s|7z7z"}, get);
fandesc[203] = P({203,2,22,22,false,"5s6s7s|3m3m3m3m|3p3p3p3p|3s3s3s3s|7z7z"}, get);
fandesc[204] = P({204,2,23,23,false,"3m3m3m|4p4p4p|3s3s3s|1z1z1z|2z2z"}, get);
fandesc[205] = P({205,2,24,24,false,"1m1m1m1p1p1p1s1s1s|3s4s5s|1z|1z"}, get);
fandesc[206] = P({206,2,25,25,false,"2m3m4m5p6p7p|5z5z5z|6z6z6z|7z|7z"}, get);
fandesc[207] = P({207,2,26,26,false,"1m1m1m|9m9m9m|1p1p1p|1s1s1s|1z|1z"}, get);
fandesc[208] = P({208,2,27,27,1,"1m1m2m2m3p3p4p4p6p6p7s7s4z|4z"}, get);
fandesc[209] = P({209,2,28,28,5,"1m2m3m|7m8m9m|1p2p3p|1z1z1z|6z6z"}, get);
fandesc[210] = P({210,2,29,29,5,"1m2m3m4m5m6m7m8m9m|1p1p1p|1z1z"}, get);
fandesc[211] = P({211,2,30,30,5,"1m2m3m|1p2p3p|1s2s3s|6s6s6s|3z3z"}, get);
fandesc[212] = P({212,2,31,31,4,"1m2m3m|2p3p4p|5s5s5s|6z6z6z|2z2z"}, get);
fandesc[213] = P({213,2,32,32,4,"1m1m1m|2m2m2m|3m3m3m|5s6s7s|8p8p"}, get);
fandesc[301] = P({301,3,33,33,1,"1s2s3s1s2s3s|2p3p4p2p3p4p|1z1z"}, get);
fandesc[302] = P({302,3,34,34,5,"1m2m3m|7m8m9m|1p2p3p|9s9s9s|1s1s"}, get);
fandesc[303] = P({303,3,35,35,5,"1m1m1m2m3m4m5m6m7m2z2z2z|5z5z"}, get);
fandesc[304] = P({304,3,36,36,6,"1m2m3m|1m2m3m|1m2m3m|5s6s7s|8p8p"}, get);
fandesc[401] = P({401,4,37,37,5,"1m2m3m|2m3m4m|3m4m5m|6m6m6m|9m9m"}, get);
fandesc[501] = P({501,5,38,38,false,"9m1m1z1z2z2z7z2z3z3z3z9p9p9p9s6z4z9m"}, get);
fandesc[502] = P({502,5,39,39,4,"2m2m2m|4p5p6p|3s3s3s|9s9s9s|1p|1p"}, get);
fandesc[503] = P({503,5,40,40,4,"2m2m2m|4p5p6p|3s3s3s|9s9s9s|9p|9p"}, get);
fandesc[601] = P({601,6,41,41,7,"1m2m3m4p4p4p5s6s7s1z1z1z2z2z"}, get);
fandesc[602] = P({602,6,42,42,8}, get);
fandesc[603] = P({603,6,43,43,false,"1s2s3s|5z5z5z|6z6z6z|7z7z7z|9s9s"}, get);
fandesc[604] = P({604,6,44,44,1,"1m1m1m2m2m2m3p3p3p4p4p4p|5s5s"}, get);
fandesc[605] = P({605,6,45,45,false,"1z1z1z|2z2z2z|3z3z3z|5z5z5z|6z6z"}, get);
fandesc[606] = P({606,6,46,46,9,"2s2s2s|3s3s3s|4s4s4s|6s6s6s|6z6z"}, get);
fandesc[607] = P({607,6,47,47,false,"1m1m1m|9m9m9m|1p1p1p|9p9p9p|1s1s"}, get);
fandesc[608] = P({608,6,48,48,1,"1m9m1p9p9p1s9s1z2z3z4z5z6z|7z"}, get);
fandesc[609] = P({609,6,49,49,false,"1p2p3p|1z1z1z|2z2z2z|3z3z3z|4z4z"}, get);
fandesc[610] = P({610,6,50,50,false,"1m1m1m1m|2p2p2p2p|3s3s3s3s|1z1z1z1z|6z6z"}, get);
fandesc[611] = P({611,6,51,51,1,"1m1m1m1m2m3m4m5m6m7m8m9m9m|9m"}, get);
fandesc[612] = P({612,6,52,52,10}, get);
fandesc[613] = P({613,6,53,53,10,"2p2p3p3p4p4p5p5p6p6p7p7p8p8p"}, get);
fandesc[614] = P({614,6,54,54,10,"2s2s3s3s4s4s5s5s6s6s7s7s8s8s"}, get);
fandesc[615] = P({615,6,55,55,10,"2m2m3m3m4m4m5m5m6m6m7m7m8m8m"}, get);
fandesc[616] = P({616,6,56,56,10,"2m2m2m4p5p6p3s3s3s9s9s9s|1z|1z"}, get);
fandesc[701] = P({701,7,57,57,1,"1m1m1m2p2p2p5p5p5p7s7s7s4z|4z"}, get);
fandesc[702] = P({702,7,58,58,1,"1m9m1p9p1s9s1z2z3z4z5z6z7z|1m"}, get);
fandesc[703] = P({703,7,59,59,1,"1m1m1m2m3m4m5m6m7m8m9m9m9m|5m"}, get);
fandesc[704] = P({704,7,60,60,false,"1z1z1z|2z2z2z|3z3z3z|4z4z4z|5p5p"}, get);
fandesc[705] = P({705,7,61,61,10,"1z1z2z2z3z3z4z4z5z5z6z6z7z7z"}, get);
fandesc[801] = P({801,8,62,62,false,"4z|4z|4z|4z"}, get);
fandesc[802] = P({802,8,63,63,false,"1m1m1m1m|2p2p2p2p|5p5p5p5p|9s9s9s9s"}, get);
fandesc[803] = P({803,8,64,64,false,"1m9m1p8p9p3s3s4s7s9s1z3z6z|7z"}, get);
fandesc[804] = P({804,8,65,65,false,""}, get);
fandesc[1000] = P({1000,false,66,66,false,"1m2m3m5m5m5m8m8m8m|6p6p6p|8p|8p",false,1}, get);
fandesc[1001] = P({1001,false,67,67,false,"2p3p4p5p5p5p3s4s5s6s|8s8s8s8s|3s",false,1}, get);
fandesc[1002] = P({1002,false,68,68,false,"8s8s8s8s|2m",false,1}, get);
fandesc[1003] = P({1003,false,69,69,false,"1p1p1p|1p",false,1}, get);
fandesc[1004] = P({1004,false,70,70,false,"2m2m2m|4p5p6p|7p7p7p|8p8p8p|9p|9p",false,1}, get);
fandesc[1005] = P({1005,false,71,71,false,"2m3m3m3m3m4m|7m7m7m7m",false,1}, get);
fandesc[1101] = P({1101,2,23,72,false,"3m3m3m|4m4m4m|3s3s3s|6s6s6s|8s8s",false,1}, get);
fandesc[1102] = P({1102,3,37,73,false,"1m2m3m|2m3m4m|3m4m5m|6m6m6m|9m9m",false,1}, get);
fandesc[1103] = P({1103,3,72,74,false,"1m1m2m2m3p3p4p4p6p6p7p7p9p|9p",false,1}, get);
fandesc[1104] = P({1104,3,73,75,false,"1m1m1m|1m2m3m|7p8p9p|7p8p9p|9p9p",false,1}, get);
fandesc[1105] = P({1105,3,74,76,false,"3m3m3m|4m4m4m|3s3s3s|6s6s6s|8s|8s",false,1}, get);
fandesc[1106] = P({1106,4,75,77,false,"3m3m3m|4m4m4m|6m6m6m|7m7m7m|9m9m",false,1}, get);
fandesc[1107] = P({1107,4,76,78,false,"2m2m2m|5m5m5m|8m8m8m|2p2p2p|8p8p",false,1}, get);
fandesc[1108] = P({1108,4,77,79,false,"1m1m2m2m3p3p4p4p7p7p7p7p9p|9p",false,1}, get);
fandesc[1109] = P({1109,5,78,80,false,"1p1p2p2p4p4p5p5p6p6p8p8p9p|9p",false,1}, get);
fandesc[1110] = P({1110,5,79,81,false,"1m1m1m|1m2m3m|7m8m9m|7m8m9m|9m9m",false,1}, get);
fandesc[1111] = P({1111,5,80,82,false,"3m3m3m|4m4m4m|6m6m6m|7m7m7m|9m|9m",false,1}, get);
fandesc[1112] = P({1112,6,41,83,false,"1m2m3m4m4m4m5s6s7s8s8s8s9s9s",false,1}, get);
fandesc[1113] = P({1113,6,42,84,false,"1m2m3m4m4m4m5s6s7s8s8s8s9s|9s",false,1}, get);
fandesc[1114] = P({1114,6,81,85,false,"1p1p1p1p4p4p5p5p6p6p8p8p9p|9p",false,1}, get);
fandesc[1115] = P({1115,6,82,86,false,"1m1m1m1m|6m6m6m6m|2p2p2p2p|3p3p3p3p|5p5p",false,1}, get);
fandesc[1116] = P({1116,6,83,87,false,"1m1m1m1m|3m3m3m3m|6m6m6m6m|8m8m8m8m|9m9m",false,1}, get);
return { tb = fandesc };