-- 由 Excel 自动生成的 Lua 表
-- 文件:   [game_live][select_filters]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["category"] = 2; ["mode_id"] = 3; ["mode"] = 4; ["tournament_id"] = 5; ["open"] = 6; ["initial"] = 7; ["name1_chs"] = -8; ["name1_chs_t"] = -8; ["name1_jp"] = -8; ["name1_en"] = -8; ["name1_kr"] = -8; ["name2_chs"] = -9; ["name2_chs_t"] = -9; ["name2_jp"] = -9; ["name2_en"] = -9; ["name2_kr"] = -9;};

local df = {  nil, 2, nil, nil, nil, nil, nil,  nil,  nil,};

local get = function(item, k) return G(item, k, n2i, df, "game_live_select_filters"); end;


local select_filters = { }
select_filters[101] = P({D[5007], 101,1,false,1,1,1}, get);
select_filters[102] = P({D[5007], 102,1,false,2,1,2}, get);
select_filters[201] = P({D[4007], 201,false,1,2,3}, get);
select_filters[202] = P({D[4007], 202,false,2,2,1}, get);
select_filters[203] = P({D[4007], 203,false,3,2,2}, get);
select_filters[204] = P({D[4007], 204,false,4,3,3}, get);
select_filters[205] = P({D[4007], 205,false,5,3,1}, get);
select_filters[206] = P({D[4007], 206,false,6,3,2}, get);
select_filters[207] = P({D[4007], 207,false,7,4,3}, get);
select_filters[208] = P({D[4005], 208,false,8,1,false,4,1}, get);
select_filters[209] = P({D[4005], 209,false,9,1,false,4,2}, get);
select_filters[210] = P({D[4007], 210,false,10,5,3}, get);
select_filters[211] = P({D[4005], 211,false,11,1,false,5,1}, get);
select_filters[212] = P({D[4005], 212,false,12,1,false,5,2}, get);
select_filters[213] = P({D[4007], 213,false,13,6,1}, get);
select_filters[214] = P({D[4007], 214,false,14,6,2}, get);
select_filters[215] = P({D[4005], 215,false,15,1,false,7,1}, get);
select_filters[216] = P({D[4005], 216,false,16,1,1,7,2}, get);
select_filters[217] = P({D[4007], 217,false,17,2,4}, get);
select_filters[218] = P({D[4007], 218,false,18,2,5}, get);
select_filters[219] = P({D[4007], 219,false,19,3,4}, get);
select_filters[220] = P({D[4007], 220,false,20,3,5}, get);
select_filters[221] = P({D[4005], 221,false,21,1,false,4,4}, get);
select_filters[222] = P({D[4005], 222,false,22,1,false,4,5}, get);
select_filters[223] = P({D[4005], 223,false,23,1,false,5,4}, get);
select_filters[224] = P({D[4005], 224,false,24,1,false,5,5}, get);
select_filters[225] = P({D[4005], 225,false,25,1,false,7,4}, get);
select_filters[226] = P({D[4005], 226,false,26,1,false,7,5}, get);
select_filters[227] = P({D[4007], 227,false,27,6,4}, get);
select_filters[228] = P({D[4007], 228,false,28,6,5}, get);
return { tb = select_filters };