-- 由 Excel 自动生成的 Lua 表
-- 文件:   [global][global]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["args"] = 1002;};

local df = {  nil, "3000",};

local get = function(item, k) return G(item, k, n2i, df); end;


local global = { }
global[1] = P({1,"1800,1200,600,420,300,240,180,120,60,30,10"}, get);
global[2] = P({2,"20179"}, get);
global[3] = P({3,"5"}, get);
global[4] = P({4}, get);
global[5] = P({5}, get);
return { tb = global };