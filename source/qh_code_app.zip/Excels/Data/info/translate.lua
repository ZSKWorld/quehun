-- 由 Excel 自动生成的 Lua 表
-- 文件:   [info][translate]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["original"] = 1001; ["chs"] = -2; ["chs_t"] = -2; ["jp"] = -2; ["en"] = -2; ["kr"] = -2;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "info_translate"); end;


local translate = { }
translate["unknown error"] = P({"unknown error",1}, get);
translate["auth not found"] = P({"auth not found",2}, get);
translate["auth expired"] = P({"auth expired",3}, get);
translate["not authed"] = P({"not authed",4}, get);
translate["game not found"] = P({"game not found",5}, get);
translate["send existing error"] = P({"send existing error",6}, get);
translate["duplicate token"] = P({"duplicate token",7}, get);
translate["game not start"] = P({"game not start",8}, get);
translate["live stream not found"] = P({"live stream not found",9}, get);
translate["segment delay"] = P({"segment delay",10}, get);
translate["segment not found"] = P({"segment not found",11}, get);
return { tb = translate };