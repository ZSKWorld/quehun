-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["sort"] = 2; ["launch_time"] = 1003; ["name_chs"] = -4; ["name_chs_t"] = -4; ["name_jp"] = -4; ["name_en"] = -4; ["name_kr"] = -4; ["name_chs2"] = 1005; ["name_chs_t2"] = 1006; ["name_jp2"] = 1007; ["open"] = 8; ["init_skin"] = 9; ["full_fetter_skin"] = 10; ["hand"] = 11; ["favorite"] = 12; ["star_5_material"] = 1013; ["star_5_cost"] = 14; ["can_marry"] = 15; ["exchange_item_id"] = 16; ["exchange_item_num"] = 17; ["emo"] = 1018; ["sound"] = 19; ["sound_volume"] = 20; ["sound_folder"] = 1021; ["sex"] = 22; ["desc_stature_chs"] = -23; ["desc_stature_chs_t"] = -23; ["desc_stature_jp"] = -23; ["desc_stature_en"] = -23; ["desc_stature_kr"] = -23; ["desc_birth_chs"] = -24; ["desc_birth_chs_t"] = -24; ["desc_birth_jp"] = -24; ["desc_birth_en"] = -24; ["desc_birth_kr"] = -24; ["desc_age_chs"] = -25; ["desc_age_chs_t"] = -25; ["desc_age_jp"] = -25; ["desc_age_en"] = -25; ["desc_age_kr"] = -25; ["desc_bloodtype_chs"] = -26; ["desc_bloodtype_chs_t"] = -26; ["desc_bloodtype_jp"] = -26; ["desc_bloodtype_en"] = -26; ["desc_bloodtype_kr"] = -26; ["desc_cv_chs"] = -27; ["desc_cv_chs_t"] = -27; ["desc_cv_jp"] = -27; ["desc_cv_en"] = -27; ["desc_cv_kr"] = -27; ["desc_hobby_chs"] = -28; ["desc_hobby_chs_t"] = -28; ["desc_hobby_jp"] = -28; ["desc_hobby_en"] = -28; ["desc_hobby_kr"] = -28; ["desc_chs"] = -29; ["desc_chs_t"] = -29; ["desc_jp"] = -29; ["desc_en"] = -29; ["desc_kr"] = -29; ["desc_item_chs"] = -30; ["desc_item_chs_t"] = -30; ["desc_item_jp"] = -30; ["desc_item_en"] = -30; ["desc_item_kr"] = -30; ["collaboration"] = 31; ["region_limit"] = 32; ["skin_lib"] = 33; ["ur"] = 34; ["ur_ron"] = 35; ["ur_liqi"] = 36; ["ur_cutin"] = 1037; ["limited"] = 38; ["treasure_sp"] = 39;};

local df = {  nil, nil, nil,  nil, nil, nil, nil, 1, nil, nil, 309997, 3, "302005-10,302007-10,303143|303043-5,302002-10,302004-100", nil, 1, 302002, 75, nil, nil, 1, nil, 1,  nil,  nil,  nil,  nil,  nil,  nil,  nil,  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "item_definition_character"); end;

local b2i = {200028,200054,200080,20000107,20000125,}

local character = { }
return { tb = character, get = get, b2i = b2i };