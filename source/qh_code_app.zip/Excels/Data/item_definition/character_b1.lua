-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local character = require("Excels.Data.item_definition.character")
local tb = character.tb
local get = character.get

tb[200001] = P({D[5008], 200001,1,false,1,400101,400102,false,1,"302010-10,302011-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200001",1,false,"yiji",false,1,1,1,1,1,1,1,false,false,false,S({})}, get);
tb[200002] = P({D[5008], 200002,2,false,2,400201,400202,false,5,"302008-10,302009-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200002",2,false,"erjietang",false,2,2,2,1,2,2,2,false,false,false,S({})}, get);
tb[200003] = P({D[5008], 200003,3,false,3,400301,400302,false,2,"302005-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200003",3,false,"jianai",false,3,3,3,2,1,3,3,false,false,false,S({})}, get);
tb[200004] = P({D[5008], 200004,4,false,4,400401,400402,false,6,"302007-10,302010-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200004",4,false,"qianzhi",false,4,4,4,2,3,4,4,false,false,false,S({})}, get);
tb[200005] = P({D[5008], 200005,5,false,5,400501,400502,false,7,"302006-10,302012-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200005",5,false,"xiangyuanwu",false,5,5,5,3,3,5,5,false,false,false,S({})}, get);
tb[200006] = P({D[13017], 200006,6,false,6,false,false,false,false,400601,400602,false,4,"deco/emo/e200006",6,false,"fuzi",false,6,6,6,4,2,6,6,false,false,false,S({})}, get);
tb[200007] = P({D[5008], 200007,7,false,7,400701,400702,false,1,"302006-10,302009-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200007",7,1.2,"bamuwei",false,7,7,7,4,4,7,7,false,false,false,S({})}, get);
tb[200008] = P({D[5008], 200008,8,false,8,400801,400802,false,8,"302008-10,302012-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200008",8,false,"jiutiao",false,8,8,7,3,4,8,8,false,false,false,S({})}, get);
tb[200009] = P({D[5008], 200009,9,false,9,400901,400902,false,2,"302005-10,302006-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200009",9,false,"zeniya",false,9,9,3,3,5,9,9,false,false,false,S({})}, get);
tb[200010] = P({D[5008], 200010,10,false,10,401001,401002,false,5,"302007-10,302009-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200010",10,false,"kawei",false,5,10,2,1,5,10,10,false,false,false,S({})}, get);
tb[200011] = P({D[13017], 200011,11,false,11,false,false,false,false,401101,401102,309998,4,"deco/emo/e200011",11,false,"sigongxiasheng",2,10,11,2,4,6,11,11,false,false,false,S({}),false,false,false,false,false,1}, get);
tb[200012] = P({D[5008], 200012,12,false,12,401201,401202,309999,1,"302009-10,302011-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200012",12,false,"wangcilang",2,11,12,1,1,7,12,12,false,false,false,S({})}, get);
tb[200013] = P({D[5008], 200013,13,false,13,401301,401302,309998,2,"302009-10,302010-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200013",13,false,"yizhilaikong",2,12,13,8,2,8,13,13,false,false,false,S({})}, get);
tb[200014] = P({D[5008], 200014,14,false,14,401401,401402,309998,false,"302008-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200014",14,false,"mingzhiyingshu",2,13,14,9,3,9,14,14,false,false,false,S({})}, get);
tb[200015] = P({D[5008], 200015,15,false,15,401501,401502,false,7,"302007-10,302009-10,302005-10,302011-10,302015-10",false,false,false,0,"deco/emo/e200015",15,false,"qingkuniang",false,14,15,3,4,10,15,15,1,false,false,S({}),false,false,false,false,1}, get);
tb[200016] = P({D[34038], 200016,16,false,16,false,false,false,false,401601,401602,309995,8,"302008-10,302006-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200016",16,false,"shala",false,15,16,7,3,11,16,16,false,false,false,S({}),2}, get);
tb[200017] = P({D[5008], 200017,17,false,17,401701,401702,false,7,"302010-10,302012-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200017",17,false,"erzhigonghua",false,16,17,3,1,10,17,17,false,false,false,S({})}, get);
tb[200018] = P({D[34038], 200018,18,false,18,false,false,false,false,401801,401802,false,7,"302005-10,302012-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200018",18,false,"baishinainai",false,17,18,3,3,11,18,18,false,false,false,S({}),1}, get);
tb[200019] = P({D[5008], 200019,19,false,19,401901,401902,false,6,"302010-10,302011-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200019",19,0.9,"xiaoniaoyouchutian",false,16,19,9,1,12,19,19,false,false,false,S({})}, get);
tb[200020] = P({D[5008], 200020,20,false,20,402001,402002,false,2,"302008-10,302011-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200020",20,1.5,"wushilanyangcai",false,18,20,10,4,12,20,20,false,false,false,S({})}, get);
tb[200021] = P({D[5008], 200021,21,false,21,402101,402102,false,false,"302010-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200021",21,false,"lianggongxingshu",false,19,21,4,4,13,21,21,false,false,false,S({})}, get);
tb[200022] = P({D[13017], 200022,22,false,22,false,false,false,false,402201,402202,309996,4,"deco/emo/e200022",22,3,"yuesefu",2,20,22,11,1,14,22,22,false,false,false,S({})}, get);
tb[200023] = P({D[5008], 200023,23,false,23,402301,402302,309998,5,"302006-10,302009-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200023",23,1.3,"zhaitengzhi",2,21,23,12,3,14,23,23,false,false,false,S({})}, get);
tb[200024] = P({D[5008], 200024,24,false,24,402401,402402,false,8,"302006-10,302008-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200024",24,false,"beijianshahezi",false,22,24,13,2,13,24,24,false,false,false,S({})}, get);
tb[200025] = P({D[5008], 200025,25,false,25,402501,402502,309998,2,"302006-10,302011-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200025",25,false,"aiyin",2,23,25,5,4,15,25,25,false,false,false,S({})}, get);
tb[200026] = P({D[5008], 200026,26,false,26,402601,402602,false,6,"302007-10,302010-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200026",26,false,"chutao",false,24,26,10,1,16,26,26,false,false,false,S({})}, get);
tb[200027] = P({D[5008], 200027,27,false,27,402701,402702,309998,4,"302008-10,302012-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200027",27,false,"yuejianshan",2,25,27,14,2,17,27,27,false,false,false,S({})}, get);
tb[200028] = P({D[5008], 200028,28,false,28,402801,402802,309995,8,"302005-10,302010-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200028",28,false,"tengbenqiluo",false,26,28,5,2,18,28,28,false,false,false,S({})}, get);