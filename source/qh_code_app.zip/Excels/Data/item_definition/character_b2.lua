-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local character = require("Excels.Data.item_definition.character")
local tb = character.tb
local get = character.get

tb[200029] = P({D[5008], 200029,29,false,29,402901,402902,false,5,"302009-10,302012-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200029",29,false,"huiyeji",false,27,29,1,3,16,29,29,false,false,false,S({})}, get);
tb[200030] = P({D[5008], 200030,30,false,30,403001,403002,309998,false,"302007-10,302010-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200030",30,false,"ruyuelian",2,28,30,3,2,17,30,30,false,false,false,S({})}, get);
tb[200031] = P({D[5008], 200031,31,false,31,403101,403102,309998,1,"302006-10,302011-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200031",31,false,"shiyuanduihai",2,29,31,3,4,15,31,31,false,false,false,S({})}, get);
tb[200032] = P({D[5008], 200032,32,false,32,403201,403202,false,6,"302005-10,302007-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200032",32,false,"ailisha",false,30,32,3,2,19,32,32,false,false,false,S({})}, get);
tb[200033] = P({D[34038], 200033,33,false,33,false,false,false,false,403301,403302,false,false,"302006-10,302009-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200033",33,false,"siqiqiansuili",false,17,33,15,3,18,33,33,false,false,false,S({}),1}, get);
tb[200034] = P({D[5008], 200034,34,false,34,403401,403402,false,false,"302007-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200034",34,false,"gongyongxiao",false,16,34,16,false,20,false,34,false,2,false,S({}),false,false,false,false,1}, get);
tb[200035] = P({D[5008], 200035,35,false,35,403501,403502,false,8,"302008-10,302009-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200035",35,false,"yuancunhe",false,31,35,16,false,4,false,35,false,2,false,S({}),false,false,false,false,1}, get);
tb[200036] = P({D[5008], 200036,36,false,36,403601,403602,false,6,"302010-10,302012-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200036",36,false,"tianjiangyi",false,32,36,17,false,21,false,36,false,2,false,S({}),false,false,false,false,1}, get);
tb[200037] = P({D[5008], 200037,37,false,37,403701,403702,false,1,"302005-10,302006-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200037",37,false,"gongyongzhao",false,22,37,18,false,5,false,37,false,2,false,S({}),false,false,false,false,1}, get);
tb[200038] = P({D[5008], 200038,38,false,38,403801,403802,false,5,"302008-10,302009-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200038",38,false,"fuji",false,22,38,1,1,20,34,38,false,false,false,S({})}, get);
tb[200039] = P({D[5008], 200039,39,false,39,403901,403902,309998,1,"302011-10,302012-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200039",39,false,"qixi",2,33,39,1,4,20,35,39,false,false,false,S({})}, get);
tb[200040] = P({D[5008], 200040,40,false,40,404001,404002,309994,8,"302012-10,302007-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200040",40,false,"shecan",false,34,40,19,false,22,false,40,false,2,false,S({}),false,false,false,false,1}, get);
tb[200041] = P({D[5008], 200041,41,false,41,404101,404102,309994,5,"302011-10,302006-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200041",41,false,"zaoyinv",false,30,41,19,false,23,false,41,false,2,false,S({}),false,false,false,false,1}, get);
tb[200042] = P({D[5008], 200042,42,false,42,404201,404202,false,2,"302005-10,302010-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200042",42,false,"shengzhimo",false,35,40,19,false,24,false,42,false,2,false,S({}),false,false,false,false,1}, get);
tb[200043] = P({D[5008], 200043,43,false,43,404301,404302,309994,6,"302008-10,302009-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200043",43,false,"taocan",false,34,40,20,false,25,false,43,false,2,false,S({}),false,false,false,false,1}, get);
tb[200044] = P({D[5008], 200044,44,false,44,404401,404402,false,6,"302007-10,302011-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200044",44,false,"qihailinai",false,36,42,21,2,26,36,44,false,false,false,S({})}, get);
tb[200045] = P({D[5008], 200045,45,false,45,404501,404502,309996,false,"302005-10,302006-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200045",45,false,"a37",2,37,43,22,3,27,37,45,false,false,false,S({})}, get);
tb[200046] = P({D[34038], 200046,46,false,46,false,false,false,false,404601,404602,false,2,"302005-10,302009-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200046",46,false,"jichuanxiang",false,22,44,23,2,28,38,46,false,false,false,S({}),1}, get);
tb[200047] = P({D[5008], 200047,47,false,47,404701,404702,309998,6,"302006-10,302011-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200047",47,false,"laien",2,31,45,21,4,29,39,47,false,false,false,S({})}, get);
tb[200048] = P({D[5008], 200048,48,false,48,404801,404802,false,6,"302008-10,302012-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200048",48,false,"senchuanlingzi",false,38,46,21,1,19,40,48,false,false,false,S({})}, get);
tb[200049] = P({D[5008], 200049,49,false,49,404901,404902,309998,2,"302005-10,302007-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200049",49,false,"longchuanxiayan",2,37,47,3,3,27,41,49,false,false,false,S({})}, get);
tb[200050] = P({D[5008], 200050,50,false,50,405001,405002,309993,4,"302009-10,302011-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200050",50,false,"akagi",2,39,48,24,5,30,42,50,false,3,false,S({}),false,false,false,false,1}, get);
tb[200051] = P({D[5008], 200051,51,false,51,405101,405102,309993,5,"302005-10,302006-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200051",51,false,"washizu",2,39,48,24,5,31,43,51,false,3,false,S({}),false,false,false,false,1}, get);
tb[200052] = P({D[5008], 200052,52,false,52,405201,405202,false,false,"302005-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,150,"deco/emo/e200052",52,false,"xiyuansiyiyu",false,40,49,25,2,32,44,52,false,false,false,S({}),1,false,false,false,1}, get);
tb[200053] = P({D[5008], 200053,53,false,53,405301,405302,false,7,"302007-10,302009-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200053",53,false,"xiaoyesiqiyu",false,34,50,7,4,28,45,53,false,false,false,S({})}, get);
tb[200054] = P({D[5008], 200054,54,false,54,405401,405402,309998,false,"302008-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200054",54,false,"xiamier",2,28,51,25,2,29,46,54,false,false,false,S({})}, get);