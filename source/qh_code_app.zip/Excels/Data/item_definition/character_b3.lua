-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local character = require("Excels.Data.item_definition.character")
local tb = character.tb
local get = character.get

tb[200055] = P({D[5008], 200055,55,false,55,405501,405502,false,6,"302006-10,302010-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200055",55,false,"sigonghuiye",false,41,52,26,4,33,false,55,false,2,false,S({}),false,false,false,false,1}, get);
tb[200056] = P({D[5008], 200056,56,false,56,405601,405602,309998,5,"302005-10,302011-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200056",56,false,"baiyinyuxing",2,41,53,26,3,34,false,56,false,2,false,S({}),false,false,false,false,1}, get);
tb[200057] = P({D[5008], 200057,57,false,57,405701,405702,false,2,"302008-10,302009-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200057",57,false,"zaobanai",false,41,54,26,4,35,false,57,false,2,false,S({}),false,false,false,false,1}, get);
tb[200058] = P({D[5008], 200058,58,false,58,405801,405802,false,false,"302007-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200058",58,false,"baiyingui",false,41,55,27,2,36,false,58,false,2,false,S({}),false,false,false,false,1}, get);
tb[200059] = P({D[34038], 200059,59,false,59,false,false,false,false,405901,405902,false,6,"302007-10,302012-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200059",59,false,"you",false,42,56,5,2,37,47,59,false,false,false,S({}),4}, get);
tb[200060] = P({D[5008], 200060,60,false,60,406001,406002,309998,8,"302005-10,302006-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200060",60,false,"zekesi",2,13,25,5,3,38,48,60,false,false,false,S({})}, get);
tb[200061] = P({D[5008], 200061,61,false,61,406101,406102,false,4,"302008-10,302011-10,303143|303043-5,302002-10,302004-100",false,false,false,150,"deco/emo/e200061",61,false,"beiyuanlili",false,43,57,22,4,39,49,61,false,false,false,S({}),1,false,false,false,1}, get);
tb[200062] = P({D[5008], 200062,62,false,62,406201,406202,false,7,"302005-10,302009-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200062",62,1.3,"zhujingjiu",false,26,58,28,false,40,false,62,false,2,false,S({}),false,false,false,false,1}, get);
tb[200063] = P({D[5008], 200063,63,false,63,406301,406302,false,5,"302008-10,302012-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200063",63,1.3,"fulumeisuizi",false,15,59,29,false,26,false,63,false,2,false,S({}),false,false,false,false,1}, get);
tb[200064] = P({D[5008], 200064,64,false,64,406401,406402,false,2,"302007-10,302010-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200064",64,1.2,"xinzichong",false,44,60,30,false,41,false,64,false,2,false,S({}),false,false,false,false,1}, get);
tb[200065] = P({D[5008], 200065,65,false,65,406501,406502,false,1,"302006-10,302011-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200065",65,1.2,"yuanchengsilian",false,31,61,31,false,42,false,65,false,2,false,S({}),false,false,false,false,1}, get);
tb[200066] = P({D[5008], 200066,66,false,66,406601,406602,false,8,"302007-10,302009-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200066",66,false,"sigongdongshi",false,38,62,4,3,43,50,66,false,false,false,S({})}, get);
tb[200067] = P({D[34038], 200067,67,false,67,false,false,false,false,406701,406702,false,false,"302008-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200067",67,false,"qingluan",false,17,63,1,2,26,51,67,false,false,false,S({}),5}, get);
tb[200068] = P({D[5008], 200068,68,false,68,406801,406802,false,4,"302007-10,302008-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200068",68,false,"ruyuecaiyin",false,43,64,12,1,44,52,68,false,false,false,S({})}, get);
tb[200069] = P({D[34038], 200069,69,false,69,false,false,false,false,406901,406902,false,7,"302005-10,302009-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200069",69,false,"weilai",false,27,65,7,3,37,53,69,false,false,false,S({}),3}, get);
tb[200070] = P({D[14017], 200070,70,false,70,"鲁鲁修","魯路修","ルルーシュ",false,407001,407002,309998,1,"302006-10,302009-10,303113|303013-5,302002-10,302004-100","deco/emo/e200070",70,false,"luluxiu",2,39,66,3,1,6,false,70,false,4,false,S({}),false,false,false,false,1}, get);
tb[200071] = P({D[5008], 200071,71,false,71,407101,407102,false,false,"302008-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200071",71,false,"cc",false,39,48,24,5,45,false,71,false,4,false,S({}),false,false,false,false,1}, get);
tb[200072] = P({D[5008], 200072,72,false,72,407201,407202,309998,1,"302007-10,302012-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200072",72,false,"zhuque",2,39,67,3,3,46,false,72,false,4,false,S({}),false,false,false,false,1}, get);
tb[200073] = P({D[5008], 200073,73,false,73,407301,407302,false,false,"302005-10,302010-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200073",73,false,"kalian",false,39,68,3,2,4,false,73,false,4,false,S({}),false,false,false,false,1}, get);
tb[200074] = P({D[5008], 200074,74,false,74,407401,407402,false,1,"302005-10,302007-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200074",74,false,"lanxing",false,16,69,23,1,44,54,74,false,false,false,S({})}, get);
tb[200075] = P({D[5008], 200075,75,false,75,407501,407502,309998,2,"302006-10,302009-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200075",75,false,"ling",2,10,70,23,2,38,55,75,false,false,false,S({})}, get);
tb[200076] = P({D[5008], 200076,76,false,76,407601,407602,false,8,"302008-10,302009-10,303183|303083-5,302002-10,302004-100",false,false,false,150,"deco/emo/e200076",76,false,"dongchengxuanyin",false,17,71,15,1,47,56,76,false,false,false,S({}),1,false,false,false,1}, get);
tb[200077] = P({D[5008], 200077,77,false,77,407701,407702,309992,1,"302006-10,302008-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200077",77,false,"hanna",false,26,72,23,1,48,57,77,false,false,false,S({})}, get);
tb[200078] = P({D[13017], 200078,78,false,78,false,false,false,false,407801,407802,309991,4,"deco/emo/e200078",78,false,"musa",2,28,73,32,3,49,58,78,false,false,false,S({})}, get);
tb[200079] = P({D[5008], 200079,79,false,79,407901,407902,false,6,"302005-10,302011-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200079",79,1.2,"yiliya",false,41,74,33,6,50,false,79,false,4,1,S({}),false,false,false,false,1}, get);
tb[200080] = P({D[5008], 200080,80,false,80,408001,408002,false,false,"302008-10,302010-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200080",80,1.2,"meiyou",false,41,74,33,6,51,false,80,false,4,1,S({}),false,false,false,false,1}, get);