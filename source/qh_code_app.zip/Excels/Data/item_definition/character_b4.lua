-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local character = require("Excels.Data.item_definition.character")
local tb = character.tb
local get = character.get

tb[200081] = P({D[5008], 200081,81,false,81,408101,408102,309995,2,"302006-10,302007-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200081",81,1.2,"xiaohei",false,41,74,33,6,52,false,81,false,4,1,S({}),false,false,false,false,1}, get);
tb[200082] = P({D[5008], 200082,82,false,82,408201,408202,309998,5,"302009-10,302012-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200082",82,1.2,"jier",2,41,75,34,6,53,false,82,false,4,1,S({}),false,false,false,false,1}, get);
tb[200083] = P({D[14017], 200083,83,"2023-12-20 09:00:00+08",83,"伊芙","伊芙","イブ",false,408301,408302,false,6,"302005-10,302007-10,303163|303063-5,302002-10,302004-100","deco/emo/e200083",83,false,"yifu",false,45,76,15,3,54,59,83,false,false,false,S({})}, get);
tb[200084] = P({D[5008], 200084,85,"2024-01-31 05:00:00+08",84,408401,408402,false,5,"302008-10,302012-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200084",84,false,"linlang",false,46,77,1,7,55,60,84,false,false,false,S({})}, get);
tb[200085] = P({D[5008], 200085,86,"2024-01-31 05:00:00+08",85,408501,408502,309998,7,"302006-10,302009-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200085",85,false,"yuanfeng",2,10,78,35,1,49,61,85,false,false,false,S({})}, get);
tb[200086] = P({D[5008], 200086,87,false,86,408601,408602,false,1,"302005-10,302012-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200086",86,false,"shalangbaizi",false,false,21,23,5,42,false,86,false,4,false,S({}),false,false,false,false,1}, get);
tb[200087] = P({D[5008], 200087,88,false,87,408701,408702,false,false,"302008-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200087",87,false,"xiaoniaoyouxingye",false,false,79,3,5,56,false,87,false,4,false,S({}),false,false,false,false,1}, get);
tb[200088] = P({D[5008], 200088,89,false,88,408801,408802,false,5,"302006-10,302007-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200088",88,false,"lubamoailu",false,false,80,23,5,57,false,88,false,4,false,S({}),false,false,false,false,1}, get);
tb[200089] = P({D[5008], 200089,90,false,89,408901,408902,false,6,"302009-10,302010-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200089",89,false,"qianhuangmuyue",false,false,81,23,5,58,false,89,false,4,false,S({}),false,false,false,false,1}, get);
tb[200090] = P({D[5008], 200090,84,"2023-12-20 09:00:00+08",90,409001,409002,309998,1,"302006-10,302009-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200090",90,false,"jiushi",2,47,82,9,4,59,62,90,false,false,false,S({})}, get);
tb[200091] = P({D[5008], 200091,94,"2024-10-23 11:00:00+08",91,409101,409102,false,6,"302005-10,302006-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200091",91,false,"xili",false,48,83,15,2,60,63,91,false,false,false,S({})}, get);
tb[200092] = P({D[5008], 200092,95,"2024-10-23 11:00:00+08",92,409201,409202,309998,1,"302009-10,302006-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200092",92,false,"ju",2,23,84,35,3,61,64,92,false,false,false,S({})}, get);
tb[200093] = P({D[5008], 200093,91,false,93,409301,409302,false,4,"302008-10,302009-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200093",93,false,"laiya",false,49,85,11,4,62,65,93,false,false,false,S({})}, get);
tb[200094] = P({D[5008], 200094,92,false,94,409401,409402,false,8,"302005-10,302007-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200094",94,false,"xinxiya",false,29,86,2,4,63,66,94,false,false,false,S({})}, get);
tb[200095] = P({D[5008], 200095,93,false,95,409501,409502,false,4,"302009-10,302012-10,303143|303043-5,302002-10,302004-100",false,false,false,150,"deco/emo/e200095",95,false,"nanfenghua",false,50,87,22,3,64,67,95,false,false,false,S({}),1,false,false,false,1}, get);
tb[200096] = P({D[5008], 200096,101,"2024-12-19 11:00:00+08",96,409601,409602,309998,false,"302009-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200096",96,false,"feiming",2,28,88,1,1,65,68,96,false,false,false,S({})}, get);
tb[200097] = P({D[5008], 200097,109,"2025-06-25 11:00:00+08",97,409701,409702,309998,5,"302006-10,302011-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200097",97,1.2,"sataen",2,21,89,36,3,66,69,97,false,false,false,S({})}, get);
tb[200098] = P({D[5008], 200098,103,false,98,409801,409802,false,7,"302005-10,302012-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200098",98,false,"huayuqing",false,48,90,37,1,67,70,98,false,false,false,S({})}, get);
tb[200099] = P({D[5008], 200099,102,false,99,409901,409902,false,false,"302009-10,302008-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e200099",99,false,"huayubai",false,48,90,37,1,67,71,99,false,false,false,S({})}, get);
tb[20000100] = P({D[5008], 20000100,96,false,100,40010001,40010002,30990001,false,"302011-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000100",100,false,"qiancangtou",false,22,false,38,2,68,false,100,false,2,false,S({}),false,false,false,false,1}, get);
tb[20000101] = P({D[5008], 20000101,97,false,101,40010101,40010102,30990001,2,"302007-10,302009-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000101",101,false,"tongkouyuanxiang",false,14,false,38,2,69,false,101,false,2,false,S({}),false,false,false,false,1}, get);
tb[20000102] = P({D[5008], 20000102,98,false,102,40010201,40010202,30990001,6,"302010-10,302006-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000102",102,false,"fuwanxiaosi",false,19,false,39,3,70,false,102,false,2,false,S({}),false,false,false,false,1}, get);
tb[20000103] = P({D[5008], 20000103,99,false,103,40010301,40010302,30990001,7,"302008-10,302005-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000103",103,false,"shichuanchucai",false,11,false,39,1,71,false,103,false,2,false,S({}),false,false,false,false,1}, get);
tb[20000106] = P({D[5008], 20000106,108,"2025-06-25 11:00:00+08",104,40010601,40010602,false,7,"302009-10,302007-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000106",106,false,"jian",false,19,91,23,4,72,72,104,false,false,false,S({})}, get);
tb[20000107] = P({D[5008], 20000107,100,"2024-12-19 11:00:00+08",105,40010701,40010702,false,6,"302007-10,302005-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000107",107,false,"yuanxiao",false,15,34,40,3,73,73,105,false,false,false,S({})}, get);