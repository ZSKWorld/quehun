-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local character = require("Excels.Data.item_definition.character")
local tb = character.tb
local get = character.get

tb[20000108] = P({D[5008], 20000108,104,false,106,40010801,40010802,30990003,1,"302006-10,302008-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000108",108,1.35,"jiantongying",false,51,92,false,3,74,74,106,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000109] = P({D[5008], 20000109,105,false,107,40010901,40010902,30990004,5,"302007-10,302009-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000109",109,1.35,"yuanbanlin",false,14,93,false,3,20,75,107,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000110] = P({D[5008], 20000110,106,false,108,40011001,40011002,30990005,1,"302010-10,302012-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000110",110,false,"saber",false,31,48,false,5,60,76,108,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000111] = P({D[5008], 20000111,107,false,109,40011101,40011102,30990006,false,"302005-10,302011-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000111",111,false,"archer",2,25,48,false,5,75,77,109,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000112] = P({D[5008], 20000112,110,false,110,40011201,40011202,false,4,"302010-10,302008-10,303143|303043-5,302002-10,302004-100",false,false,false,150,"deco/emo/e20000112",112,false,"liyang",false,23,94,24,5,76,78,110,false,false,false,S({}),1,false,false,false,1}, get);
tb[20000113] = P({D[5008], 20000113,111,false,111,40011301,40011302,30990007,1,"302012-10,302006-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000113",113,false,"bantianyinshi",2,13,31,false,false,77,false,111,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000114] = P({D[5008], 20000114,112,false,112,40011401,40011402,30990008,2,"302010-10,302007-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000114",114,false,"guixiaotailang",2,23,5,false,false,78,false,112,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000115] = P({D[5008], 20000115,113,false,113,40011501,40011502,30990009,4,"302005-10,302006-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000115",115,false,"gaoshanjinzhu",2,35,47,false,false,79,false,113,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000116] = P({D[5008], 20000116,114,false,114,40011601,40011602,30990010,false,"302011-10,302009-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000116",116,false,"banbenchenma",2,52,33,false,false,80,false,114,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000117] = P({D[5008], 20000117,115,false,115,40011701,40011702,false,1,"302009-10,302007-10,303113|303013-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000117",117,false,"mila",false,30,95,41,1,81,79,115,false,false,false,S({})}, get);
tb[20000118] = P({D[5008], 20000118,116,false,116,40011801,40011802,309998,4,"302006-10,302011-10,303143|303043-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000118",118,false,"beiluo",2,53,96,42,2,82,80,116,false,false,false,S({})}, get);
tb[20000119] = P({D[5008], 20000119,117,false,117,40011901,40011902,false,6,"302005-10,302008-10,303163|303063-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000119",119,false,"miya",false,31,97,43,2,83,81,117,false,false,false,S({})}, get);
tb[20000120] = P({D[5008], 20000120,118,false,118,40012001,40012002,false,5,"302012-10,302010-10,303153|303053-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000120",120,false,"jinwu",false,44,98,1,3,84,82,118,false,false,false,S({})}, get);
tb[20000121] = P({D[5008], 20000121,123,"2026-08-19 11:00:00+08",119,40012101,40012102,false,1,"302005-10,302006-10,303113|303013-5,302002-10,302004-100",false,false,false,150,"deco/emo/e20000121",121,false,"chilin",false,50,99,1,5,85,83,119,false,false,false,S({}),1,false,false,false,1}, get);
tb[20000122] = P({D[5008], 20000122,119,false,120,40012201,40012202,30990011,2,"302011-10,302009-10,303123|303023-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000122",122,false,"tongren",2,false,100,false,false,86,84,120,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000123] = P({D[5008], 20000123,120,false,121,40012301,40012302,30990012,false,"302008-10,302012-10,303133|303033-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000123",123,false,"yasina",false,false,101,false,false,87,85,121,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000124] = P({D[5008], 20000124,121,false,122,40012401,40012402,30990013,8,"302010-10,302007-10,303183|303083-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000124",124,false,"lifa",false,false,102,false,false,88,86,122,false,4,false,S({}),false,false,false,false,1}, get);
tb[20000125] = P({D[5008], 20000125,122,false,123,40012501,40012502,30990014,7,"302006-10,302005-10,303173|303073-5,302002-10,302004-100",false,false,false,false,"deco/emo/e20000125",125,false,"shinai",false,false,103,false,false,89,3,123,false,4,false,S({}),false,false,false,false,1}, get);