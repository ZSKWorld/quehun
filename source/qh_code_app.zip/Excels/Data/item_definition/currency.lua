-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][currency]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["desc_chs"] = -3; ["desc_chs_t"] = -3; ["desc_jp"] = -3; ["desc_en"] = -3; ["desc_kr"] = -3; ["icon"] = 1004; ["icon_jpg"] = 1005;};

local df = {  nil,  nil,  nil, "extendRes/items/gold1.png", "extendRes/items/jade0.jpg",};

local get = function(item, k) return G(item, k, n2i, df, "item_definition_currency"); end;


local currency = { }
currency[100001] = P({100001,1,1}, get);
currency[100002] = P({100002,2,2,"extendRes/items/gold0.png","extendRes/items/coin0.jpg"}, get);
currency[100003] = P({100003,3,false,"",""}, get);
currency[100004] = P({100004,4,3,"extendRes/items/fushiquan_0.png","extendRes/items/fushiquan0.jpg"}, get);
currency[101001] = P({101001,1,1}, get);
return { tb = currency };