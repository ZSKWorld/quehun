-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][fake_random_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["stage_count"] = 2; ["stage_weight"] = 3;};

local df = {  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local fake_random_pool = { }
fake_random_pool[309047] = P({309047,S({150,250,}),S({85,105,})}, get);
return { tb = fake_random_pool };