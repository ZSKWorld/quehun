-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][function_item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["type"] = 2; ["args"] = 3; ["name"] = 4; ["desc_func"] = 5; ["desc"] = 6; ["icon"] = 1007; ["icon_transparent"] = 1008;};

local df = {  nil, 7, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {70001044,70001222,70001422,70001616,}

local function_item = { }
return { tb = function_item, get = get, b2i = b2i };