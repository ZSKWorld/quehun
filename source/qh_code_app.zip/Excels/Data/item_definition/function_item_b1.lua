-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][function_item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local function_item = require("Excels.Data.item_definition.function_item")
local tb = function_item.tb
local get = function_item.get

tb[700001] = P({700001,2,S({1010,}),2839,4301,false,"extendRes/items/24month.jpg"}, get);
tb[700002] = P({700002,2,S({2010,}),2839,4301,false,"extendRes/items/24month.jpg"}, get);
tb[700003] = P({700003,2,S({3010,}),2839,4301,false,"extendRes/items/24month.jpg"}, get);
tb[700004] = P({700004,2,S({5010,}),2839,4301,false,"extendRes/items/24month.jpg"}, get);
tb[70000001] = P({70000001,1,S({240401,}),4203,4204,4205,"extendRes/items/activity/unused/24ba1.jpg"}, get);
tb[70000002] = P({70000002,3,S({240601,101,})}, get);
tb[70000003] = P({D[4006], 70000003,3,S({240601,102,}),"extendRes/items/activity/unused/24haidao_bag2.jpg"}, get);
tb[70000004] = P({D[4006], 70000004,3,S({240601,103,}),"extendRes/items/activity/unused/24haidao_bag3.jpg"}, get);
tb[70000005] = P({70000005,4,S({240601,0,})}, get);
tb[70000006] = P({70000006,4,S({240601,1,})}, get);
tb[70000007] = P({D[4006], 70000007,4,S({240601,2,}),"extendRes/items/activity/unused/24haidao_zone3.jpg"}, get);
tb[70000008] = P({D[4006], 70000008,4,S({240601,3,}),"extendRes/items/activity/unused/24haidao_zone4.jpg"}, get);
tb[70000009] = P({D[4006], 70000009,4,S({240601,4,}),"extendRes/items/activity/unused/24haidao_zone5.jpg"}, get);
tb[70000010] = P({70000010,1,S({250101,}),4576,4577,4578,"extendRes/items/activity/unused/25chunjie2.jpg","extendRes/items/activity/unused/25chunjie2_0.png"}, get);
tb[70000011] = P({70000011,8,S({26040501,1,}),26040100,26040101,26040102,"ui/activity/extend/26dj/main/pic_scattered/26dj3.jpg","ui/activity/extend/26dj/main/pic_scattered/26dj3_0.png"}, get);
tb[70001000] = P({D[4006], 70001000,6,S({260401,6000,3300,500,170,30,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_000.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_000.png"}, get);
tb[70001001] = P({D[4006], 70001001,5,S({260401,0,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_001.png"}, get);
tb[70001002] = P({D[4006], 70001002,5,S({260401,0,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_002.png"}, get);
tb[70001003] = P({D[4006], 70001003,5,S({260401,0,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_003.png"}, get);
tb[70001004] = P({D[4006], 70001004,5,S({260401,0,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_004.png"}, get);
tb[70001005] = P({D[4006], 70001005,5,S({260401,0,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_random_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_random_005.png"}, get);
tb[70001011] = P({D[4006], 70001011,5,S({260401,1,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_empty_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_empty_001.png"}, get);
tb[70001012] = P({D[4006], 70001012,5,S({260401,2,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_empty_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_empty_001.png"}, get);
tb[70001013] = P({D[4006], 70001013,5,S({260401,3,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_wizard_empty_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_wizard_empty_001.png"}, get);
tb[70001014] = P({D[4006], 70001014,5,S({260401,4,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_hat_empty_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_hat_empty_001.png"}, get);
tb[70001015] = P({D[4006], 70001015,5,S({260401,5,1,}),"ui/activity/extend/26dj/main/pic_scattered/icon_armor_empty_001.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_armor_empty_001.png"}, get);
tb[70001021] = P({D[4006], 70001021,5,S({260401,1,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_empty_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_empty_002.png"}, get);
tb[70001022] = P({D[4006], 70001022,5,S({260401,2,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_empty_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_empty_002.png"}, get);
tb[70001023] = P({D[4006], 70001023,5,S({260401,3,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_wizard_empty_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_wizard_empty_002.png"}, get);
tb[70001024] = P({D[4006], 70001024,5,S({260401,4,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_hat_empty_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_hat_empty_002.png"}, get);
tb[70001025] = P({D[4006], 70001025,5,S({260401,5,2,}),"ui/activity/extend/26dj/main/pic_scattered/icon_armor_empty_002.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_armor_empty_002.png"}, get);
tb[70001031] = P({D[4006], 70001031,5,S({260401,1,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_empty_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_empty_003.png"}, get);
tb[70001032] = P({D[4006], 70001032,5,S({260401,2,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_empty_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_empty_003.png"}, get);
tb[70001033] = P({D[4006], 70001033,5,S({260401,3,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_wizard_empty_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_wizard_empty_003.png"}, get);
tb[70001034] = P({D[4006], 70001034,5,S({260401,4,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_hat_empty_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_hat_empty_003.png"}, get);
tb[70001035] = P({D[4006], 70001035,5,S({260401,5,3,}),"ui/activity/extend/26dj/main/pic_scattered/icon_armor_empty_003.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_armor_empty_003.png"}, get);
tb[70001041] = P({D[4006], 70001041,5,S({260401,1,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_empty_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_empty_004.png"}, get);
tb[70001042] = P({D[4006], 70001042,5,S({260401,2,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_empty_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_empty_004.png"}, get);
tb[70001043] = P({D[4006], 70001043,5,S({260401,3,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_wizard_empty_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_wizard_empty_004.png"}, get);
tb[70001044] = P({D[4006], 70001044,5,S({260401,4,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_hat_empty_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_hat_empty_004.png"}, get);