-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][function_item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local function_item = require("Excels.Data.item_definition.function_item")
local tb = function_item.tb
local get = function_item.get

tb[70001045] = P({D[4006], 70001045,5,S({260401,5,4,}),"ui/activity/extend/26dj/main/pic_scattered/icon_armor_empty_004.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_armor_empty_004.png"}, get);
tb[70001051] = P({D[4006], 70001051,5,S({260401,1,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_empty_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_empty_005.png"}, get);
tb[70001052] = P({D[4006], 70001052,5,S({260401,2,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_empty_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_empty_005.png"}, get);
tb[70001053] = P({D[4006], 70001053,5,S({260401,3,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_wizard_empty_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_wizard_empty_005.png"}, get);
tb[70001054] = P({D[4006], 70001054,5,S({260401,4,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_hat_empty_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_hat_empty_005.png"}, get);
tb[70001055] = P({D[4006], 70001055,5,S({260401,5,5,}),"ui/activity/extend/26dj/main/pic_scattered/icon_armor_empty_005.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_armor_empty_005.png"}, get);
tb[70001100] = P({D[5006], 70001100,false,S({260401,}),26040001,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00100.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00100.png"}, get);
tb[70001111] = P({D[5006], 70001111,false,S({260401,}),26040002,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00301.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00301.png"}, get);
tb[70001112] = P({D[5006], 70001112,false,S({260401,}),26040003,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00302.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00302.png"}, get);
tb[70001113] = P({D[5006], 70001113,false,S({260401,}),26040004,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00303.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00303.png"}, get);
tb[70001114] = P({D[5006], 70001114,false,S({260401,}),26040005,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00304.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00304.png"}, get);
tb[70001115] = P({D[5006], 70001115,false,S({260401,}),26040006,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00305.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00305.png"}, get);
tb[70001121] = P({D[5006], 70001121,false,S({260401,}),26040007,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00201.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00201.png"}, get);
tb[70001122] = P({D[5006], 70001122,false,S({260401,}),26040008,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00202.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00202.png"}, get);
tb[70001123] = P({D[5006], 70001123,false,S({260401,}),26040009,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00203.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00203.png"}, get);
tb[70001124] = P({D[5006], 70001124,false,S({260401,}),26040010,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00204.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00204.png"}, get);
tb[70001125] = P({D[5006], 70001125,false,S({260401,}),26040011,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00205.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00205.png"}, get);
tb[70001131] = P({D[5006], 70001131,false,S({260401,}),26040012,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00401.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00401.png"}, get);
tb[70001132] = P({D[5006], 70001132,false,S({260401,}),26040013,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00402.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00402.png"}, get);
tb[70001133] = P({D[5006], 70001133,false,S({260401,}),26040014,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00403.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00403.png"}, get);
tb[70001134] = P({D[5006], 70001134,false,S({260401,}),26040015,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00404.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00404.png"}, get);
tb[70001135] = P({D[5006], 70001135,false,S({260401,}),26040016,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_swordsman_00405.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_swordsman_00405.png"}, get);
tb[70001200] = P({D[5006], 70001200,false,S({260401,}),26040017,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00100.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00100.png"}, get);
tb[70001211] = P({D[5006], 70001211,false,S({260401,}),26040018,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00401.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00401.png"}, get);
tb[70001212] = P({D[5006], 70001212,false,S({260401,}),26040019,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00402.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00402.png"}, get);
tb[70001213] = P({D[5006], 70001213,false,S({260401,}),26040020,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00403.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00403.png"}, get);
tb[70001214] = P({D[5006], 70001214,false,S({260401,}),26040021,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00404.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00404.png"}, get);
tb[70001215] = P({D[5006], 70001215,false,S({260401,}),26040022,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00405.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00405.png"}, get);
tb[70001221] = P({D[5006], 70001221,false,S({260401,}),26040023,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00301.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00301.png"}, get);
tb[70001222] = P({D[5006], 70001222,false,S({260401,}),26040024,"ui/activity/extend/26dj/main/pic_scattered/icon_weapon_warrior_00302.png","ui/activity/extend/26dj/main/pic_scattered/item_icon_weapon_warrior_00302.png"}, get);