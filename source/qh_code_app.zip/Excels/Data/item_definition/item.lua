-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["sort"] = 2; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["name_chs_t2"] = 1004; ["desc_func_chs"] = -5; ["desc_func_chs_t"] = -5; ["desc_func_jp"] = -5; ["desc_func_en"] = -5; ["desc_func_kr"] = -5; ["desc_chs"] = -6; ["desc_chs_t"] = -6; ["desc_jp"] = -6; ["desc_en"] = -6; ["desc_kr"] = -6; ["desc_chs_t2"] = 1007; ["icon"] = 1008; ["icon_transparent"] = 1009; ["category"] = 10; ["type"] = 11; ["is_unique"] = 12; ["max_stack"] = 13; ["access"] = 1014; ["accessinfo"] = 15; ["func"] = 1016; ["iargs"] = 17; ["sargs"] = 1018; ["can_sell"] = 19; ["sell_reward_id"] = 20; ["sell_reward_count"] = 21; ["item_expire"] = 1022; ["expire_desc_chs"] = -23; ["expire_desc_chs_t"] = -23; ["expire_desc_jp"] = -23; ["expire_desc_en"] = -23; ["expire_desc_kr"] = -23; ["region_limit"] = 24; ["cross_view"] = 25; ["database_cache"] = 26;};

local df = {  nil, 6077,  nil, nil,  nil,  nil, nil, nil, nil, 5, nil, 1, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,  nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "item_definition_item"); end;

local b2i = {303062,305004,305053,305314,305545,305615,305810,307237,307294,307453,308017,309001,309039,309074,309160,30530014,30557011,30557067,30580013,30740011,30900030,30900085,30990016,}

local item = { }
return { tb = item, get = get, b2i = b2i };