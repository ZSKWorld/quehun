-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[300001] = P({D[19022], 300001,1,1,false,1,false,false,"extendRes/items/coin5.jpg",false,1,false,0,false,false,false,"characompose",S({}),S({}),false}, get);
tb[300002] = P({D[19022], 300002,2,2,false,2,false,false,"extendRes/items/coin5.jpg",false,1,false,0,false,false,false,"addcoin",S({}),S({}),false}, get);
tb[300003] = P({D[19022], 300003,3,3,false,3,false,false,"extendRes/items/coin3.jpg",false,1,false,0,false,false,false,"addcoin",S({}),S({}),false}, get);
tb[300004] = P({D[13016], 300004,4,4,false,4,false,false,"extendRes/items/jade0.jpg",false,1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[300005] = P({D[13016], 300005,5,5,false,5,1,false,"extendRes/items/coin3.jpg",false,1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[301001] = P({D[13016], 301001,6,6,false,6,2,false,"extendRes/items/coin3.jpg",false,1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302001] = P({D[13016], 302001,7,7,false,7,3,false,"extendRes/items/coupon.jpg","extendRes/items/coupon_0.png",1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302002] = P({D[19022], 302002,8,8,false,8,4,false,"extendRes/items/wishstone.jpg","extendRes/items/wishstone_0.png",1,false,0,false,"1",3027,false,S({}),S({}),false}, get);
tb[302003] = P({D[13016], 302003,9,9,false,9,5,false,"extendRes/items/starstone.jpg","extendRes/items/starstone_0.png",1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302004] = P({D[19022], 302004,10,10,false,10,6,false,"extendRes/items/stardust.jpg","extendRes/items/stardust_0.png",1,false,0,false,"11",3026,false,S({}),S({}),false}, get);
tb[302005] = P({D[19022], 302005,11,11,false,11,7,false,"extendRes/items/jade_courage.jpg","extendRes/items/jade_courage_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302006] = P({D[19022], 302006,12,12,false,11,8,false,"extendRes/items/jade_will.jpg","extendRes/items/jade_will_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302007] = P({D[19022], 302007,13,13,false,11,9,false,"extendRes/items/jade_honest.jpg","extendRes/items/jade_honest_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302008] = P({D[19022], 302008,14,14,false,11,10,false,"extendRes/items/jade_tender.jpg","extendRes/items/jade_tender_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302009] = P({D[19022], 302009,15,15,false,11,11,false,"extendRes/items/jade_knowledge.jpg","extendRes/items/jade_knowledge_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302010] = P({D[19022], 302010,16,16,false,11,12,false,"extendRes/items/jade_pure.jpg","extendRes/items/jade_pure_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302011] = P({D[19022], 302011,17,17,false,11,13,false,"extendRes/items/jade_hope.jpg","extendRes/items/jade_hope_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302012] = P({D[19022], 302012,18,18,false,11,14,false,"extendRes/items/jade_bright.jpg","extendRes/items/jade_bright_0.png",1,false,0,false,"3",3025,false,S({}),S({}),false}, get);
tb[302013] = P({D[19022], 302013,19,19,false,12,15,false,"extendRes/items/gaimingka.jpg","extendRes/items/gaimingka_0.png",1,false,0,false,false,false,"modify-nickname",S({}),S({}),false}, get);
tb[302014] = P({D[13016], 302014,20,20,false,13,16,false,"extendRes/items/xunmihuishi.jpg","extendRes/items/unused/xunmihuishi_0.png",0,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302015] = P({D[13016], 302015,21,21,false,14,17,false,"extendRes/items/qingxiaoshuo.jpg",false,1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302016] = P({D[13016], 302016,22,6,false,6,2,false,"-",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[302999] = P({D[13016], 302999,18001,22,false,false,false,false,"extendRes/items/Glasses.jpg",false,1,1,0,S({0,10001,}),S({}),false,false,false,false,false}, get);
tb[303011] = P({303011,23,23,false,15,18,false,"extendRes/items/biscuit0.jpg",false,2,1,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303012] = P({303012,24,24,false,16,19,false,"extendRes/items/biscuit1.jpg",false,2,1,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303013] = P({303013,25,25,false,17,20,false,"extendRes/items/biscuit2.jpg",false,2,1,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303021] = P({303021,26,26,false,18,21,false,"extendRes/items/console0.jpg",false,2,2,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303022] = P({303022,27,27,false,19,22,false,"extendRes/items/console1.jpg",false,2,2,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303023] = P({303023,28,28,false,20,23,false,"extendRes/items/console2.jpg",false,2,2,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303031] = P({303031,29,29,false,21,24,false,"extendRes/items/art0.jpg",false,2,3,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303032] = P({303032,30,30,false,22,25,false,"extendRes/items/art1.jpg",false,2,3,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303033] = P({303033,31,31,false,23,26,false,"extendRes/items/art2.jpg",false,2,3,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303041] = P({303041,32,32,"普通酒杯",24,27,"日常可見的酒杯。","extendRes/items/wine0.jpg",false,2,4,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303042] = P({303042,33,33,"精緻酒杯",25,28,"精緻典雅的酒杯。","extendRes/items/wine1.jpg",false,2,4,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303043] = P({303043,34,34,"高檔酒杯",26,29,"高檔奢華的酒杯。","extendRes/items/wine2.jpg",false,2,4,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303051] = P({303051,35,35,false,27,30,false,"extendRes/items/diamond0.jpg",false,2,5,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303052] = P({303052,36,36,false,28,31,false,"extendRes/items/diamond1.jpg",false,2,5,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303053] = P({303053,37,37,false,29,32,false,"extendRes/items/diamond2.jpg",false,2,5,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303061] = P({303061,38,38,false,30,33,false,"extendRes/items/toy0.jpg",false,2,6,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303062] = P({303062,39,39,false,31,34,false,"extendRes/items/toy1.jpg",false,2,6,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);