-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[308021] = P({D[12016], 308021,18022,425,false,191,414,false,"deco/effect_hupai/ron_2211saki/pic/ron_2211saki.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308022] = P({D[12016], 308022,18023,426,false,192,415,false,"deco/effect_lizhi/effect_liqi_2211saki/pic/effect_liqi_2211saki.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308023] = P({D[9016], 308023,18024,427,false,149,416,false,"deco/lizhibang/liqi_2211saki/pic/liqi_2211saki.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308024] = P({D[12016], 308024,18025,428,false,184,417,false,"deco/tablecloth/tablecloth_2211saki/pic/tablecloth_2211saki.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308025] = P({D[12016], 308025,18026,429,false,185,418,false,"deco/mjpai/mjp_2211saki/pic/mjp_2211saki.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308026] = P({D[12016], 308026,18027,430,false,191,419,false,"deco/effect_hupai/ron_llx/pic/ron_llx.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308027] = P({D[12016], 308027,18028,431,false,192,420,false,"deco/effect_lizhi/effect_liqi_llx/pic/effect_liqi_llx.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308028] = P({D[9016], 308028,18029,432,false,149,421,false,"deco/lizhibang/liqi_llx/pic/liqi_llx.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308029] = P({D[12016], 308029,18030,433,false,184,422,false,"deco/tablecloth/tablecloth_llx/pic/tablecloth_llx.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308030] = P({D[12016], 308030,18031,434,false,185,423,false,"deco/mjpai/mjp_llx/pic/mjp_llx.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308031] = P({D[12016], 308031,18032,435,false,186,424,false,"deco/effect_hupai/ron_yly/pic/ron_yly.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false,1}, get);
tb[308032] = P({D[12016], 308032,18033,436,false,187,425,false,"deco/effect_lizhi/effect_liqi_yly/pic/effect_liqi_yly.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false,1}, get);
tb[308033] = P({D[9016], 308033,18034,437,false,188,426,false,"deco/lizhibang/liqi_yly/pic/liqi_yly.jpg",S({302003,5,}),S({}),false,false,false,false,false,1}, get);
tb[308034] = P({D[12016], 308034,18035,438,false,189,427,false,"deco/tablecloth/tablecloth_yly/pic/tablecloth_yly.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false,1}, get);
tb[308035] = P({D[12016], 308035,18036,439,false,190,428,false,"deco/mjpai/mjp_yly/pic/mjp_yly.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false,1}, get);
tb[308036] = P({D[12016], 308036,18037,440,false,191,429,false,"deco/effect_hupai/ron_24ba/pic/ron_24ba.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308037] = P({D[12016], 308037,18038,441,false,192,430,false,"deco/effect_lizhi/effect_liqi_24ba/pic/effect_liqi_24ba.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308038] = P({D[9016], 308038,18039,442,false,149,431,false,"deco/lizhibang/liqi_24ba/pic/liqi_24ba.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308039] = P({D[12016], 308039,18040,443,false,184,432,false,"deco/tablecloth/tablecloth_24ba/pic/tablecloth_24ba.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308040] = P({D[12016], 308040,18041,444,false,185,433,false,"deco/mjpai/mjp_24ba/pic/mjp_24ba.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308041] = P({D[12016], 308041,18051,445,false,191,434,false,"deco/effect_hupai/ron_25hf/pic/ron_25hf.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308042] = P({D[12016], 308042,18052,446,false,192,435,false,"deco/effect_lizhi/effect_liqi_25hf/pic/effect_liqi_25hf.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308043] = P({D[9016], 308043,18053,447,false,149,436,false,"deco/lizhibang/liqi_25hf/pic/liqi_25hf.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308044] = P({D[12016], 308044,18054,448,false,184,437,false,"deco/tablecloth/tablecloth_25hf/pic/tablecloth_25hf.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308045] = P({D[12016], 308045,18055,449,false,185,438,false,"deco/mjpai/mjp_25hf/pic/mjp_25hf.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308046] = P({D[12016], 308046,18056,450,false,191,439,false,"deco/effect_hupai/ron_25yh/pic/ron_25yh.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308047] = P({D[12016], 308047,18057,451,false,192,440,false,"deco/effect_lizhi/effect_liqi_25yh/pic/effect_liqi_25yh.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308048] = P({D[9016], 308048,18058,452,false,149,441,false,"deco/lizhibang/liqi_25yh/pic/liqi_25yh.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308049] = P({D[12016], 308049,18059,453,false,184,442,false,"deco/tablecloth/tablecloth_25yh/pic/tablecloth_25yh.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308050] = P({D[12016], 308050,18060,454,false,185,443,false,"deco/mjpai/mjp_25yh/pic/mjp_25yh.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[308051] = P({D[12016], 308051,18061,455,false,125,444,false,"deco/head_frame/headframe_25yh/pic/headframe_25yh.jpg",false,false,5,S({302003,10,}),S({}),false,false,false,false,false,false,1}, get);
tb[308052] = P({D[12016], 308052,18062,456,false,191,445,false,"deco/effect_hupai/ron_26dj/pic/ron_26dj.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308053] = P({D[12016], 308053,18063,457,false,192,446,false,"deco/effect_lizhi/effect_liqi_26dj/pic/effect_liqi_26dj.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308054] = P({D[9016], 308054,18064,458,false,149,447,false,"deco/lizhibang/liqi_26dj/pic/liqi_26dj.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308055] = P({D[12016], 308055,18065,459,false,184,448,false,"deco/tablecloth/tablecloth_26dj/pic/tablecloth_26dj.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308056] = P({D[12016], 308056,18066,460,false,185,449,false,"deco/mjpai/mjp_26dj/pic/mjp_26dj.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[308057] = P({D[12016], 308057,18067,461,false,125,450,false,"deco/head_frame/headframe_26dj/pic/headframe_26dj.jpg",false,false,5,S({302003,10,}),S({}),false,false,false,false,false,false,1}, get);
tb[308996] = P({D[12016], 308996,19001,462,false,76,451,false,"deco/mjpai/mjp_official/pic/mjp_official.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308997] = P({D[12016], 308997,19002,463,false,75,452,false,"deco/tablecloth/tablecloth_official_qlz/pic/tablecloth_official_qlz.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308998] = P({D[12016], 308998,19003,464,false,75,453,false,"deco/tablecloth/tablecloth_official_sxz/pic/tablecloth_official_sxz.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[308999] = P({D[12016], 308999,19004,465,false,75,454,false,"deco/tablecloth/tablecloth_official/pic/tablecloth_official.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[309000] = P({D[19022], 309000,20001,466,false,193,455,false,"extendRes/items/activity/unused/trailpoint.jpg",false,6,false,0,100,false,false,false,S({}),S({}),false}, get);
tb[309001] = P({D[13016], 309001,20002,467,false,194,456,false,"extendRes/items/activity/unused/christmas_bell.jpg","extendRes/items/activity/unused/christmas_bell_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309002] = P({D[13016], 309002,20003,468,false,195,457,false,"extendRes/items/activity/unused/christmas_socks.jpg","extendRes/items/activity/unused/christmas_socks_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309003] = P({D[13016], 309003,20004,469,false,196,458,false,"extendRes/items/activity/unused/denglong.jpg","extendRes/items/activity/unused/denglong_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);