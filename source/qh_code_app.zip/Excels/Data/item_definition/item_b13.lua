-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[309004] = P({D[13016], 309004,20005,470,false,196,458,false,"extendRes/items/activity/unused/baozhu.jpg","extendRes/items/activity/unused/baozhu_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309005] = P({D[13016], 309005,20006,471,false,196,459,false,"extendRes/items/activity/unused/fu.jpg","extendRes/items/activity/unused/fu_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309006] = P({D[13016], 309006,20007,472,false,197,460,false,"extendRes/items/activity/unused/tool.jpg","extendRes/items/activity/unused/tool_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309007] = P({D[13016], 309007,20008,473,false,197,461,false,"extendRes/items/Glasses.jpg","extendRes/items/activity/unused/Glasses_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309008] = P({D[13016], 309008,20009,474,false,197,462,false,"extendRes/items/activity/unused/fengling.jpg","extendRes/items/activity/unused/fengling_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309009] = P({D[13016], 309009,20010,475,false,197,463,false,"extendRes/items/activity/unused/xuegao.jpg","extendRes/items/activity/unused/xuegao_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309010] = P({D[13016], 309010,20011,476,false,197,464,false,"extendRes/items/activity/unused/xigua.jpg","extendRes/items/activity/unused/xigua_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309011] = P({D[13016], 309011,20012,477,false,197,465,false,"extendRes/items/activity/unused/guihuajiu.jpg","extendRes/items/activity/unused/guihuajiu_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309012] = P({D[13016], 309012,20013,478,false,197,466,false,"extendRes/items/activity/unused/wurenyuebing.jpg","extendRes/items/activity/unused/wurenyuebing_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309013] = P({D[13016], 309013,20014,479,false,197,467,false,"extendRes/items/activity/unused/monvnangua.jpg","extendRes/items/activity/unused/monvnangua_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309014] = P({D[13016], 309014,20015,480,false,197,468,false,"extendRes/items/activity/unused/daodantangguo.jpg","extendRes/items/activity/unused/daodantangguo_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309015] = P({D[13016], 309015,20016,481,false,197,469,false,"extendRes/items/activity/unused/xinshouyouling.jpg","extendRes/items/activity/unused/xinshouyouling_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309016] = P({D[13016], 309016,20017,482,false,197,470,false,"extendRes/items/activity/unused/jingbing.jpg","extendRes/items/activity/unused/jingbing_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309017] = P({D[13016], 309017,20018,483,false,197,471,false,"extendRes/items/activity/unused/daocaoquan.jpg","extendRes/items/activity/unused/daocaoquan_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309018] = P({D[13016], 309018,20019,484,false,198,472,false,"extendRes/items/activity/unused/touzi.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309019] = P({D[13016], 309019,20020,485,false,199,473,false,"extendRes/items/activity/unused/chizi.jpg","extendRes/items/activity/unused/chizi_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309020] = P({D[13016], 309020,20021,486,false,199,474,false,"extendRes/items/activity/unused/qianbi.jpg","extendRes/items/activity/unused/qianbi_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309021] = P({D[13016], 309021,20022,487,false,199,475,false,"extendRes/items/activity/unused/shouzhang.jpg","extendRes/items/activity/unused/shouzhang_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309022] = P({D[13016], 309022,20023,488,false,200,476,false,"extendRes/items/activity/unused/touzi.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309023] = P({D[13016], 309023,20024,489,false,201,477,false,"extendRes/items/activity/unused/yaokongtouzi.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309024] = P({D[13016], 309024,20025,490,false,199,478,false,"extendRes/items/activity/unused/zongziA.jpg","extendRes/items/activity/unused/zongziA_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309025] = P({D[13016], 309025,20026,491,false,199,479,false,"extendRes/items/activity/unused/zongziB.jpg","extendRes/items/activity/unused/zongziB_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309026] = P({D[13016], 309026,20027,492,false,199,480,false,"extendRes/items/activity/unused/zongziC.jpg","extendRes/items/activity/unused/zongziC_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309027] = P({D[13016], 309027,20028,493,false,199,481,false,"extendRes/items/activity/unused/laba.jpg","extendRes/items/activity/unused/laba_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309028] = P({D[13016], 309028,20029,494,false,199,482,false,"ui/activity/extend/2403broadcast/main/pic_scattered/huaqiu.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/huaqiu_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309029] = P({D[13016], 309029,20030,495,false,202,false,false,"extendRes/items/activity/unused/qingkuquan.jpg","extendRes/items/activity/unused/qingkuquan_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309030] = P({D[13016], 309030,20031,496,false,203,483,false,"ui/activity/extend/2403broadcast/main/pic_scattered/diaoyushao.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/diaoyushao_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309031] = P({D[13016], 309031,20032,497,false,199,484,false,"extendRes/items/activity/unused/tizhongcheng.jpg","extendRes/items/activity/unused/tizhongcheng_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309032] = P({D[13016], 309032,20033,498,false,199,485,false,"extendRes/items/activity/unused/tingzhenqi.jpg","extendRes/items/activity/unused/tingzhenqi_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309033] = P({D[13016], 309033,20034,499,false,199,486,false,"extendRes/items/activity/unused/wenduji.jpg","extendRes/items/activity/unused/wenduji_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309034] = P({D[13016], 309034,20035,500,false,204,487,false,"extendRes/items/activity/unused/xiongmao.jpg","extendRes/items/activity/unused/xiongmao_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309035] = P({D[13016], 309035,20036,501,false,205,488,false,"extendRes/items/activity/unused/xiuxuept.jpg","extendRes/items/activity/unused/xiuxuept_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309036] = P({D[13016], 309036,20037,false,false,false,false,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309037] = P({D[13016], 309037,20038,502,false,206,489,false,"extendRes/items/fankaijihui.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309038] = P({D[13016], 309038,20039,503,false,199,490,false,"extendRes/items/activity/unused/bingqiling.jpg","extendRes/items/activity/unused/bingqiling_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309039] = P({D[13016], 309039,20040,504,false,199,491,false,"extendRes/items/activity/unused/baobing.jpg","extendRes/items/activity/unused/baobing_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309040] = P({D[13016], 309040,20041,505,false,207,492,false,"extendRes/items/activity/unused/lzhdticket.jpg","extendRes/items/activity/unused/lzhdticket_0.png",6,false,0,S({}),S({}),false,false,false,"2021-12-20 10:00:00",false}, get);
tb[309041] = P({D[13016], 309041,20042,506,false,208,493,false,"extendRes/items/activity/unused/yijilevelpoint.jpg","extendRes/items/activity/unused/yijilevelpoint_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);