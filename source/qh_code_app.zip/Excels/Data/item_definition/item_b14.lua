-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[309040] = P({D[13016], 309040,20041,507,false,207,494,false,"extendRes/items/activity/unused/lzhdticket.jpg","extendRes/items/activity/unused/lzhdticket_0.png",6,false,0,S({}),S({}),false,false,false,"2021-12-20 10:00:00",false}, get);
tb[309041] = P({D[13016], 309041,20042,508,false,208,495,false,"extendRes/items/activity/unused/yijilevelpoint.jpg","extendRes/items/activity/unused/yijilevelpoint_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309042] = P({D[13016], 309042,20043,509,false,199,496,false,"extendRes/items/activity/unused/21YY_apple.jpg","extendRes/items/activity/unused/21YY_apple_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309043] = P({D[13016], 309043,20044,510,false,199,497,false,"extendRes/items/activity/unused/21YY_banana.jpg","extendRes/items/activity/unused/21YY_banana_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309044] = P({D[13016], 309044,20045,511,false,199,498,false,"extendRes/items/activity/unused/21YY_taco.jpg","extendRes/items/activity/unused/21YY_taco_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309045] = P({D[13016], 309045,20046,512,false,209,499,false,"extendRes/items/activity/unused/21WS_choco.jpg","extendRes/items/activity/unused/21WS_choco_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309046] = P({D[13016], 309046,20047,513,false,209,500,false,"extendRes/items/activity/unused/21WS_letter.jpg","extendRes/items/activity/unused/21WS_letter_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309047] = P({D[13016], 309047,20048,514,false,210,501,false,"extendRes/items/21CJ0.jpg",false,1,4,0,S({309047,309048,309049,309050,309051,309052,}),S({}),false,false,false,false,103}, get);
tb[309048] = P({D[13016], 309048,20049,515,false,211,502,false,"extendRes/items/activity/unused/22CJ1.jpg","extendRes/items/activity/unused/22CJ1_0.png",6,false,0,S({}),S({}),false,false,false,false,103,false,false,1}, get);
tb[309049] = P({D[13016], 309049,20050,516,false,211,503,false,"extendRes/items/activity/unused/22CJ2.jpg","extendRes/items/activity/unused/22CJ2_0.png",6,false,0,S({}),S({}),false,false,false,false,103,false,false,1}, get);
tb[309050] = P({D[13016], 309050,20051,517,false,211,504,false,"extendRes/items/activity/unused/22CJ3.jpg","extendRes/items/activity/unused/22CJ3_0.png",6,false,0,S({}),S({}),false,false,false,false,103,false,false,1}, get);
tb[309051] = P({D[13016], 309051,20052,518,false,211,505,false,"extendRes/items/activity/unused/22CJ4.jpg","extendRes/items/activity/unused/22CJ4_0.png",6,false,0,S({}),S({}),false,false,false,false,103,false,false,1}, get);
tb[309052] = P({D[13016], 309052,20053,519,false,211,506,false,"extendRes/items/activity/unused/22CJ5.jpg","extendRes/items/activity/unused/22CJ5_0.png",6,false,0,S({}),S({}),false,false,false,false,103,false,false,1}, get);
tb[309053] = P({D[13016], 309053,20054,520,false,212,507,false,"extendRes/items/activity/unused/22WQ_milk.jpg","extendRes/items/activity/unused/22WQ_milk_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309054] = P({D[13016], 309054,20055,521,false,213,508,false,"extendRes/items/activity/unused/22WQ_soap.jpg","extendRes/items/activity/unused/22WQ_soap_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309055] = P({D[13016], 309055,20056,522,false,213,509,false,"extendRes/items/activity/unused/22WQ_sake.jpg","extendRes/items/activity/unused/22WQ_sake_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309056] = P({D[13016], 309056,20057,503,false,214,510,false,"extendRes/items/activity/unused/xiuxuept.jpg","extendRes/items/activity/unused/xiuxuept_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309057] = P({D[13016], 309057,20058,523,false,215,511,false,"ui/activity/extend/2403broadcast/main/pic_scattered/22rpg_wolf.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/22rpg_wolf_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309058] = P({D[13016], 309058,20059,524,false,215,512,false,"extendRes/items/activity/unused/22rpg_panda.jpg","extendRes/items/activity/unused/22rpg_panda_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309059] = P({D[13016], 309059,20060,525,false,216,513,false,"ui/activity/extend/voteskin/main/pic_scattered/22toupiao.jpg","ui/activity/extend/voteskin/main/pic_scattered/22toupiao_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309060] = P({D[13016], 309060,20061,526,false,217,514,false,"extendRes/items/activity/unused/22shuiyi1.jpg","extendRes/items/activity/unused/22shuiyi1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309061] = P({D[13016], 309061,20062,527,false,217,515,false,"extendRes/items/activity/unused/22shuiyi2.jpg","extendRes/items/activity/unused/22shuiyi2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309062] = P({D[13016], 309062,20063,528,false,217,516,false,"ui/activity/extend/2403broadcast/main/pic_scattered/22shuiyi3.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/22shuiyi3_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309063] = P({D[19022], 309063,20064,529,false,218,517,false,"extendRes/items/selectskin.jpg","extendRes/items/selectskin_0.png",1,1,0,false,false,false,"selectskin",S({309063,}),S({}),false}, get);
tb[309064] = P({D[13016], 309064,20065,530,false,219,518,false,"extendRes/items/10coupon.jpg","extendRes/items/10coupon_0.png",1,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309065] = P({D[13016], 309065,20066,531,false,220,519,false,"extendRes/items/activity/unused/22summerstory.jpg","extendRes/items/activity/unused/22summerstory_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309066] = P({D[13016], 309066,20067,532,false,221,520,false,"extendRes/items/activity/unused/22yuyi1.jpg","extendRes/items/activity/unused/22yuyi1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309067] = P({D[13016], 309067,20068,533,false,221,521,false,"extendRes/items/activity/unused/22yuyi2.jpg","extendRes/items/activity/unused/22yuyi2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309068] = P({D[13016], 309068,20069,534,false,222,522,false,"extendRes/items/activity/unused/2211saki_wish.jpg","extendRes/items/activity/unused/2211saki_wish_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309069] = P({D[13016], 309069,20070,535,false,223,523,false,"extendRes/items/activity/unused/2301_lvpt.jpg","extendRes/items/activity/unused/2301_lvpt_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309070] = P({D[13016], 309070,20071,536,false,224,524,false,"extendRes/items/activity/unused/2302_tarot.jpg","extendRes/items/activity/unused/2302_tarot_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309071] = P({D[13016], 309071,20072,537,false,224,525,false,"extendRes/items/activity/unused/2302_bouquet.jpg","extendRes/items/activity/unused/2302_bouquet_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309072] = P({D[13016], 309072,20073,538,false,225,526,false,"extendRes/items/activity/unused/2505balei_coin.jpg","extendRes/items/activity/unused/2505balei_coin_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309073] = P({D[13016], 309073,20074,539,false,226,527,false,"extendRes/items/activity/unused/23rpg1.jpg","extendRes/items/activity/unused/23rpg1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[309074] = P({D[13016], 309074,20075,540,false,226,528,false,"extendRes/items/activity/unused/23rpg2.jpg","extendRes/items/activity/unused/23rpg2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);