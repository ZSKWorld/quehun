-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[30560009] = P({D[9016], 30560009,7036,700,false,149,605,false,"deco/lizhibang/liqi_25summer/pic/liqi_25summer.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30560010] = P({D[9016], 30560010,7037,701,false,149,606,false,"deco/lizhibang/liqi_25dongri/pic/liqi_25dongri.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570001] = P({D[12016], 30570001,8026,702,false,154,607,false,"deco/mjpai/mjp_23winter/pic/mjp_23winter.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570002] = P({D[12016], 30570002,8027,703,false,153,608,false,"deco/mjpai/mjp_24chunjie/pic/mjp_24chunjie.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570003] = P({D[12016], 30570003,8028,704,false,154,609,false,"deco/mjpai/mjp_24anime/pic/mjp_24anime.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570004] = P({D[12016], 30570004,8029,705,false,154,610,false,"deco/mjpai/mjp_24haidao/pic/mjp_24haidao.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570005] = P({D[12016], 30570005,18044,706,false,154,611,false,"deco/mjpai/mjp_24sanliou/pic/mjp_24sanliou.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570006] = P({D[12016], 30570006,8031,707,false,154,612,false,"deco/mjpai/mjp_24wansheng/pic/mjp_24wansheng.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570007] = P({D[12016], 30570007,18049,708,false,154,613,false,"deco/mjpai/mjp_24imas/pic/mjp_24imas.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570008] = P({D[12016], 30570008,8033,709,false,154,614,false,"deco/mjpai/mjp_24winter/pic/mjp_24winter.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570009] = P({D[12016], 30570009,8034,710,false,153,615,false,"deco/mjpai/mjp_25chunjie/pic/mjp_25chunjie.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570010] = P({D[12016], 30570010,8035,711,false,153,616,false,"deco/mjpai/mjp_25xila1/pic/mjp_25xila1.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570011] = P({D[12016], 30570011,8036,712,false,154,617,false,"deco/mjpai/mjp_25xila2/pic/mjp_25xila2.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570012] = P({D[12016], 30570012,8037,713,false,153,618,false,"deco/mjpai/mjp_25summer/pic/mjp_25summer.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30570013] = P({D[12016], 30570013,8038,714,false,154,619,false,"deco/mjpai/mjp_25achivement1/pic/mjp_25achivement1.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570014] = P({D[12016], 30570014,8039,715,false,154,620,false,"deco/mjpai/mjp_25achivement2/pic/mjp_25achivement2.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570015] = P({D[12016], 30570015,8040,716,false,154,621,false,"deco/mjpai/mjp_25achivement3/pic/mjp_25achivement3.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570016] = P({D[12016], 30570016,8041,717,false,154,622,false,"deco/mjpai/mjp_25achivement4/pic/mjp_25achivement4.jpg",false,false,7,S({}),S({}),false,false,false,false,false}, get);
tb[30570017] = P({D[12016], 30570017,8042,718,false,153,623,false,"deco/mjpai/mjp_26chunjie/pic/mjp_26chunjie.jpg",false,false,7,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580001] = P({D[12016], 30580001,10021,719,false,165,624,false,"deco/tablecloth/tablecloth_23wansheng/pic/tablecloth_23wansheng.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580002] = P({D[12016], 30580002,10022,720,false,165,625,false,"deco/tablecloth/tablecloth_23winter/pic/tablecloth_23winter.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580003] = P({D[12016], 30580003,10023,721,false,160,626,false,"deco/tablecloth/tablecloth_24chunjie/pic/tablecloth_24chunjie.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580004] = P({D[12016], 30580004,10024,722,false,165,627,false,"deco/tablecloth/tablecloth_24douyu/pic/tablecloth_24douyu.jpg",false,false,6,S({}),S({}),false,false,false,"2027-01-31 00:00:00",165}, get);
tb[30580005] = P({D[12016], 30580005,10025,723,false,165,628,false,"deco/tablecloth/tablecloth_24anime/pic/tablecloth_24anime.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580006] = P({D[12016], 30580006,10026,724,false,160,629,false,"deco/tablecloth/tablecloth_24haidao/pic/tablecloth_24haidao.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580007] = P({D[12016], 30580007,10027,725,false,165,630,false,"deco/tablecloth/tablecloth_24summer/pic/tablecloth_24summer.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580008] = P({D[12016], 30580008,18045,726,false,165,631,false,"deco/tablecloth/tablecloth_24sanliou/pic/tablecloth_24sanliou.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580009] = P({D[12016], 30580009,10029,727,false,165,632,false,"deco/tablecloth/tablecloth_24wansheng/pic/tablecloth_24wansheng.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580010] = P({D[12016], 30580010,10029,728,false,165,633,false,"deco/tablecloth/tablecloth_24qilinzhan/pic/tablecloth_24qilinzhan.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580011] = P({D[12016], 30580011,18050,729,false,165,634,false,"deco/tablecloth/tablecloth_24imas/pic/tablecloth_24imas.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580012] = P({D[12016], 30580012,10031,730,false,165,635,false,"deco/tablecloth/tablecloth_24winter/pic/tablecloth_24winter.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580013] = P({D[12016], 30580013,10032,731,false,165,636,false,"deco/tablecloth/tablecloth_25catfoodbowl/pic/tablecloth_25catfoodbowl.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580014] = P({D[12016], 30580014,10033,732,false,308,637,false,"deco/tablecloth/tablecloth_25mkc/pic/tablecloth_25mkc.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580015] = P({D[12016], 30580015,10034,733,false,160,638,false,"deco/tablecloth/tablecloth_25chunjie1/pic/tablecloth_25chunjie1.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580016] = P({D[12016], 30580016,10035,734,false,165,639,false,"deco/tablecloth/tablecloth_25chunjie2/pic/tablecloth_25chunjie2.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580017] = P({D[12016], 30580017,10036,735,false,308,640,false,"deco/tablecloth/tablecloth_25krsaishi/pic/tablecloth_25krsaishi.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580018] = P({D[12016], 30580018,10037,736,false,165,641,false,"deco/tablecloth/tablecloth_25sanyuanbei/pic/tablecloth_25sanyuanbei.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580019] = P({D[12016], 30580019,10038,737,false,160,642,false,"deco/tablecloth/tablecloth_25xila/pic/tablecloth_25xila.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580020] = P({D[12016], 30580020,10039,738,false,160,643,false,"deco/tablecloth/tablecloth_25summer/pic/tablecloth_25summer.jpg",false,false,6,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30580021] = P({D[12016], 30580021,10040,739,false,165,644,false,"deco/tablecloth/tablecloth_25achievement1/pic/tablecloth_25achievement1.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580022] = P({D[12016], 30580022,10041,740,false,165,645,false,"deco/tablecloth/tablecloth_25achievement2/pic/tablecloth_25achievement2.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580023] = P({D[12016], 30580023,10042,741,false,165,646,false,"deco/tablecloth/tablecloth_25achievement3/pic/tablecloth_25achievement3.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580024] = P({D[12016], 30580024,10043,742,false,165,647,false,"deco/tablecloth/tablecloth_25achievement4/pic/tablecloth_25achievement4.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30580025] = P({D[12016], 30580025,10044,743,false,308,648,false,"deco/tablecloth/tablecloth_26mkc/pic/tablecloth_26mkc.jpg",false,false,6,S({}),S({}),false,false,false,false,false}, get);