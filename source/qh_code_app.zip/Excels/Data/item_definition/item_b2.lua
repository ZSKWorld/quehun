-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[303063] = P({303063,40,40,false,32,35,false,"extendRes/items/toy2.jpg",false,2,6,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303071] = P({303071,41,41,false,33,36,false,"extendRes/items/comic0.jpg",false,2,7,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303072] = P({303072,42,42,false,34,37,false,"extendRes/items/comic1.jpg",false,2,7,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303073] = P({303073,43,43,false,35,38,false,"extendRes/items/comic2.jpg",false,2,7,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303081] = P({303081,44,44,false,36,39,false,"extendRes/items/dress0.jpg",false,2,8,0,false,"2",3025,false,S({200,}),S({}),1,302004,1,false,false}, get);
tb[303082] = P({303082,45,45,false,37,40,false,"extendRes/items/dress1.jpg",false,2,8,0,false,"4",3025,false,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303083] = P({303083,46,46,false,38,41,false,"extendRes/items/dress2.jpg",false,2,8,0,false,"3",3025,false,S({5000,}),S({}),1,302004,25,false,false}, get);
tb[303112] = P({D[19022], 303112,52,24,false,39,42,false,"extendRes/items/biscuit1_limit.jpg",false,2,1,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303113] = P({D[19022], 303113,53,25,false,40,43,false,"extendRes/items/biscuit2_limit.jpg",false,2,1,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303122] = P({D[19022], 303122,54,27,false,41,44,false,"extendRes/items/console1_limit.jpg",false,2,2,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303123] = P({D[19022], 303123,55,28,false,42,45,false,"extendRes/items/console2_limit.jpg",false,2,2,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303132] = P({D[19022], 303132,56,30,false,43,46,false,"extendRes/items/art1_limit.jpg",false,2,3,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303133] = P({D[19022], 303133,57,31,false,44,47,false,"extendRes/items/art2_limit.jpg",false,2,3,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303142] = P({D[19022], 303142,58,33,"精緻酒杯",45,48,"精緻典雅的酒杯。","extendRes/items/wine1_limit.jpg",false,2,4,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303143] = P({D[19022], 303143,59,34,"高檔酒杯",46,49,"高檔奢華的酒杯。","extendRes/items/wine2_limit.jpg",false,2,4,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303152] = P({D[19022], 303152,60,36,false,47,50,false,"extendRes/items/diamond1_limit.jpg",false,2,5,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303153] = P({D[19022], 303153,61,37,false,48,51,false,"extendRes/items/diamond2_limit.jpg",false,2,5,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303162] = P({D[19022], 303162,62,39,false,49,52,false,"extendRes/items/toy1_limit.jpg",false,2,6,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303163] = P({D[19022], 303163,63,40,false,50,53,false,"extendRes/items/toy2_limit.jpg",false,2,6,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303172] = P({D[19022], 303172,64,42,false,51,54,false,"extendRes/items/comic1_limit.jpg",false,2,7,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303173] = P({D[19022], 303173,65,43,false,52,55,false,"extendRes/items/comic2_limit.jpg",false,2,7,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303182] = P({D[19022], 303182,66,45,false,53,56,false,"extendRes/items/dress1_limit.jpg",false,2,8,0,false,"4",3025,false,S({1000,}),S({}),false}, get);
tb[303183] = P({D[19022], 303183,67,46,false,54,57,false,"extendRes/items/dress2_limit.jpg",false,2,8,0,false,"3",3025,false,S({5000,}),S({}),false}, get);
tb[303991] = P({D[13016], 303991,47,47,false,55,58,false,"extendRes/items/gift_heart.jpg","extendRes/items/gift_heart_0.png",2,99,0,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303992] = P({D[13016], 303992,48,48,false,56,59,false,"extendRes/items/tongxinjie.jpg",false,2,99,0,S({1000,}),S({}),1,302004,5,false,false}, get);
tb[303993] = P({D[13016], 303993,49,49,false,57,60,false,"extendRes/items/qiaokeli.jpg",false,2,99,0,S({1000,}),S({}),false,false,false,false,false}, get);
tb[303994] = P({D[13016], 303994,50,50,false,58,61,false,"extendRes/items/coffeeticket.png",false,2,99,0,S({1000,}),S({}),false,false,false,false,false}, get);
tb[303995] = P({D[13016], 303995,51,51,false,59,62,false,"extendRes/items/redbull.jpg",false,2,99,0,S({283,}),S({}),false,false,false,false,false}, get);
tb[304001] = P({D[13016], 304001,68,52,false,60,63,false,"extendRes/items/fudai_lvren.jpg",false,3,false,0,S({10201,1,0,}),S({}),false,false,false,false,false}, get);
tb[304002] = P({D[13016], 304002,69,53,false,61,64,false,"extendRes/items/fudai_guiren.jpg",false,3,false,0,S({10202,1,0,}),S({}),false,false,false,false,false}, get);
tb[304003] = P({D[13016], 304003,70,54,false,62,65,false,"extendRes/items/fudai_xianren.jpg",false,3,false,0,S({10203,1,0,}),S({}),false,false,false,false,false}, get);
tb[304004] = P({D[13016], 304004,71,55,false,63,66,false,"extendRes/items/coin3.jpg",false,3,false,0,S({10001,1,0,}),S({}),false,false,false,false,false}, get);
tb[304005] = P({D[13016], 304005,72,56,false,64,67,false,"extendRes/items/fudai_moon.jpg",false,1,2,0,S({10212,1,0,}),S({}),false,false,false,false,false}, get);
tb[304006] = P({D[13016], 304006,73,57,false,65,68,false,"extendRes/items/fudai_sun.jpg",false,1,2,0,S({10213,1,0,}),S({}),false,false,false,false,false}, get);
tb[304007] = P({D[13016], 304007,74,58,false,66,69,false,"extendRes/items/fudai_lvren.jpg",false,1,2,0,S({10201,1,0,}),S({}),false,false,false,false,false}, get);
tb[304008] = P({D[13016], 304008,75,59,false,67,70,false,"extendRes/items/fudai_guiren.jpg",false,1,2,0,S({10202,1,0,}),S({}),false,false,false,false,false}, get);
tb[304009] = P({D[13016], 304009,76,60,false,68,71,false,"extendRes/items/fudai_xianren.jpg",false,1,2,0,S({10203,1,0,}),S({}),false,false,false,false,false}, get);
tb[304101] = P({D[13016], 304101,77,61,false,69,72,false,"extendRes/items/yueguangbaohe.jpg",false,1,1,0,S({304101,}),S({}),false,false,false,false,false}, get);
tb[304102] = P({D[13016], 304102,78,62,false,70,73,false,"extendRes/items/riguangbaohe.jpg",false,1,1,0,S({304102,}),S({}),false,false,false,false,false}, get);
tb[305001] = P({D[9016], 305001,1001,63,false,71,74,false,"deco/lizhibang/liqi_fish/pic/liqi_fish.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305002] = P({D[9016], 305002,1002,64,false,71,75,false,"deco/lizhibang/liqi_scallion/pic/liqi_scallion.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305003] = P({D[9016], 305003,1003,65,false,71,76,false,"deco/lizhibang/liqi_bone/pic/liqi_bone.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305004] = P({D[9016], 305004,1004,66,false,71,77,false,"deco/lizhibang/liqi_chocolate/pic/liqi_chocolate.jpg",S({302003,5,}),S({}),false,false,false,false,false}, get);