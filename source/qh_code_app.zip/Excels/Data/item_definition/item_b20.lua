-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[30610002] = P({D[12016], 30610002,13009,751,false,177,656,false,"deco/bgm/pic/duijubgm.jpg",false,false,9,S({}),S({}),false,false,false,false,false}, get);
tb[30610003] = P({D[12016], 30610003,13010,752,false,176,657,false,"deco/bgm/pic/duijubgm.jpg",false,false,9,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30610004] = P({D[12016], 30610004,13011,753,false,177,658,false,"deco/bgm/pic/duijubgm.jpg",false,false,9,S({}),S({}),false,false,false,false,false}, get);
tb[30610005] = P({D[12016], 30610005,13012,754,false,177,659,false,"deco/bgm/pic/duijubgm.jpg",false,false,9,S({}),S({}),false,false,false,false,false}, get);
tb[30610006] = P({D[12016], 30610006,13013,755,false,176,660,false,"deco/bgm/pic/duijubgm.jpg",false,false,9,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[30700001] = P({D[12016], 30700001,14014,756,false,179,661,false,"deco/lobby_background/beijing_jiuba/pic/beijing_jiuba.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700002] = P({D[12016], 30700002,14015,757,false,179,662,false,"deco/lobby_background/beijing_fenwoshi/pic/beijing_fenwoshi.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700003] = P({D[12016], 30700003,14016,758,false,179,663,false,"deco/lobby_background/beijing_gufengwoshi/pic/beijing_gufengwoshi.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700004] = P({D[12016], 30700004,14017,759,false,179,664,false,"deco/lobby_background/beijing_tangquan/pic/beijing_tangquan.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700005] = P({D[12016], 30700005,14900,760,false,179,665,false,"deco/lobby_background/beijing_dongmudaqiao/pic/beijing_dongmudaqiao.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700006] = P({D[12016], 30700006,14018,761,false,179,666,false,"deco/lobby_background/beijing_shamo/pic/beijing_shamo.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700007] = P({D[12016], 30700007,14019,762,false,179,667,false,"deco/lobby_background/beijing_yuanlin/pic/beijing_yuanlin.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30700008] = P({D[12016], 30700008,14901,763,false,179,668,false,"deco/lobby_background/beijing_akagi/pic/beijing_akagi.jpg",false,false,8,S({}),S({}),false,false,false,false,false}, get);
tb[30710001] = P({D[12016], 30710001,21001,764,false,154,669,false,"deco/mjpface/mjpface_25summer/pic/mjpface_25summer.jpg",false,false,13,S({}),S({}),false,false,false,false,false}, get);
tb[30740001] = P({D[12016], 30740001,16001,765,false,182,670,false,"deco/loading_cg/CG200001/thumb/CG200001_thumb.jpg",false,8,12,S({30740001,}),S({}),false,false,false,false,false}, get);
tb[30740002] = P({D[12016], 30740002,16002,766,false,182,671,false,"deco/loading_cg/CG200002/thumb/CG200002_thumb.jpg",false,8,12,S({30740002,}),S({}),false,false,false,false,false}, get);
tb[30740003] = P({D[12016], 30740003,16003,767,false,182,672,false,"deco/loading_cg/CG200021/thumb/CG200021_thumb.jpg",false,8,12,S({30740003,}),S({}),false,false,false,false,false}, get);
tb[30740004] = P({D[12016], 30740004,16004,768,false,182,673,false,"deco/loading_cg/CG200022/thumb/CG200022_thumb.jpg",false,8,12,S({30740004,}),S({}),false,false,false,false,false}, get);
tb[30740005] = P({D[12016], 30740005,16005,769,false,182,674,false,"deco/loading_cg/CG200005/thumb/CG200005_thumb.jpg",false,8,12,S({30740005,}),S({}),false,false,false,false,false}, get);
tb[30740006] = P({D[12016], 30740006,16006,770,false,182,675,false,"deco/loading_cg/CG200013/thumb/CG200013_thumb.jpg",false,8,12,S({30740006,}),S({}),false,false,false,false,false}, get);
tb[30740007] = P({D[12016], 30740007,16007,771,false,182,676,false,"deco/loading_cg/CG200006/thumb/CG200006_thumb.jpg",false,8,12,S({30740007,}),S({}),false,false,false,false,false}, get);
tb[30740008] = P({D[12016], 30740008,16008,772,false,182,677,false,"deco/loading_cg/CG200014/thumb/CG200014_thumb.jpg",false,8,12,S({30740008,}),S({}),false,false,false,false,false}, get);
tb[30740009] = P({D[12016], 30740009,16009,773,false,182,678,false,"deco/loading_cg/CG200016/thumb/CG200016_thumb.jpg",false,8,12,S({30740009,}),S({}),false,false,false,false,false}, get);
tb[30740010] = P({D[12016], 30740010,16010,774,false,182,679,false,"deco/loading_cg/CG200003/thumb/CG200003_thumb.jpg",false,8,12,S({30740010,}),S({}),false,false,false,false,false}, get);
tb[30740011] = P({D[12016], 30740011,16011,775,false,182,680,false,"deco/loading_cg/CG200017/thumb/CG200017_thumb.jpg",false,8,12,S({30740011,}),S({}),false,false,false,false,false}, get);
tb[30740012] = P({D[12016], 30740012,16012,776,false,182,681,false,"deco/loading_cg/CG200004/thumb/CG200004_thumb.jpg",false,8,12,S({30740012,}),S({}),false,false,false,false,false}, get);
tb[30740013] = P({D[12016], 30740013,16013,777,false,182,682,false,"deco/loading_cg/CG200018/thumb/CG200018_thumb.jpg",false,8,12,S({30740013,}),S({}),false,false,false,false,false}, get);
tb[30740014] = P({D[12016], 30740014,16014,778,false,182,683,false,"deco/loading_cg/CG200025/thumb/CG200025_thumb.jpg",false,8,12,S({30740014,}),S({}),false,false,false,false,false}, get);
tb[30740015] = P({D[12016], 30740015,16015,779,false,182,684,false,"deco/loading_cg/CG200008/thumb/CG200008_thumb.jpg",false,8,12,S({30740015,}),S({}),false,false,false,false,false}, get);
tb[30740016] = P({D[12016], 30740016,16016,780,false,182,685,false,"deco/loading_cg/CG200020/thumb/CG200020_thumb.jpg",false,8,12,S({30740016,}),S({}),false,false,false,false,false}, get);
tb[30740017] = P({D[12016], 30740017,16017,781,false,182,686,false,"deco/loading_cg/CG200094/thumb/CG200094_thumb.jpg",false,8,12,S({30740017,}),S({}),false,false,false,false,false}, get);
tb[30740018] = P({D[12016], 30740018,16018,782,false,182,687,false,"deco/loading_cg/CG200007/thumb/CG200007_thumb.jpg",false,8,12,S({30740018,}),S({}),false,false,false,false,false}, get);
tb[30740019] = P({D[12016], 30740019,16019,783,false,182,688,false,"deco/loading_cg/CG200009/thumb/CG200009_thumb.jpg",false,8,12,S({30740019,}),S({}),false,false,false,false,false}, get);
tb[30740020] = P({D[12016], 30740020,16020,784,false,182,689,false,"deco/loading_cg/CG200011/thumb/CG200011_thumb.jpg",false,8,12,S({30740020,}),S({}),false,false,false,false,false}, get);
tb[30740021] = P({D[12016], 30740021,16021,785,false,182,690,false,"deco/loading_cg/CG200019/thumb/CG200019_thumb.jpg",false,8,12,S({30740021,}),S({}),false,false,false,false,false}, get);
tb[30740022] = P({D[12016], 30740022,16022,786,false,182,691,false,"deco/loading_cg/CG20000106/thumb/CG20000106_thumb.jpg",false,8,12,S({30740022,}),S({}),false,false,false,false,false}, get);
tb[30740023] = P({D[12016], 30740023,16023,787,false,182,692,false,"deco/loading_cg/CG200044/thumb/CG200044_thumb.jpg",false,8,12,S({30740023,}),S({}),false,false,false,false,false}, get);
tb[30900001] = P({D[13016], 30900001,20078,788,false,309,693,false,"extendRes/items/activity/unused/23yuyi1.jpg","extendRes/items/activity/unused/23yuyi1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900002] = P({D[13016], 30900002,20079,789,false,309,694,false,"extendRes/items/activity/unused/23yuyi2.jpg","extendRes/items/activity/unused/23yuyi2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900003] = P({D[13016], 30900003,20080,790,false,310,695,false,"extendRes/items/activity/unused/23yuyi_hu.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900004] = P({D[13016], 30900004,20081,791,false,311,696,false,"extendRes/items/activity/unused/2311_magic.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900005] = P({D[13016], 30900005,20082,792,false,312,697,false,"extendRes/items/activity/unused/23winter1.jpg","extendRes/items/activity/unused/23winter1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900006] = P({D[13016], 30900006,20083,793,false,312,698,false,"extendRes/items/activity/unused/23winter2.jpg","extendRes/items/activity/unused/23winter2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900007] = P({D[13016], 30900007,20084,794,false,313,699,false,"extendRes/items/activity/unused/24chunjie1.jpg","extendRes/items/activity/unused/24chunjie1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);