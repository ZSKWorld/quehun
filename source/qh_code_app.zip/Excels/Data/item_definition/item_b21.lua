-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[30740012] = P({D[12016], 30740012,16012,790,false,182,694,false,"deco/loading_cg/CG200004/thumb/CG200004_thumb.jpg",false,8,12,S({30740012,}),S({}),false,false,false,false,false}, get);
tb[30740013] = P({D[12016], 30740013,16013,791,false,182,695,false,"deco/loading_cg/CG200018/thumb/CG200018_thumb.jpg",false,8,12,S({30740013,}),S({}),false,false,false,false,false}, get);
tb[30740014] = P({D[12016], 30740014,16014,792,false,182,696,false,"deco/loading_cg/CG200025/thumb/CG200025_thumb.jpg",false,8,12,S({30740014,}),S({}),false,false,false,false,false}, get);
tb[30740015] = P({D[12016], 30740015,16015,793,false,182,697,false,"deco/loading_cg/CG200008/thumb/CG200008_thumb.jpg",false,8,12,S({30740015,}),S({}),false,false,false,false,false}, get);
tb[30740016] = P({D[12016], 30740016,16016,794,false,182,698,false,"deco/loading_cg/CG200020/thumb/CG200020_thumb.jpg",false,8,12,S({30740016,}),S({}),false,false,false,false,false}, get);
tb[30740017] = P({D[12016], 30740017,16017,795,false,182,699,false,"deco/loading_cg/CG200094/thumb/CG200094_thumb.jpg",false,8,12,S({30740017,}),S({}),false,false,false,false,false}, get);
tb[30740018] = P({D[12016], 30740018,16018,796,false,182,700,false,"deco/loading_cg/CG200007/thumb/CG200007_thumb.jpg",false,8,12,S({30740018,}),S({}),false,false,false,false,false}, get);
tb[30740019] = P({D[12016], 30740019,16019,797,false,182,701,false,"deco/loading_cg/CG200009/thumb/CG200009_thumb.jpg",false,8,12,S({30740019,}),S({}),false,false,false,false,false}, get);
tb[30740020] = P({D[12016], 30740020,16020,798,false,182,702,false,"deco/loading_cg/CG200011/thumb/CG200011_thumb.jpg",false,8,12,S({30740020,}),S({}),false,false,false,false,false}, get);
tb[30740021] = P({D[12016], 30740021,16021,799,false,182,703,false,"deco/loading_cg/CG200019/thumb/CG200019_thumb.jpg",false,8,12,S({30740021,}),S({}),false,false,false,false,false}, get);
tb[30740022] = P({D[12016], 30740022,16022,800,false,182,704,false,"deco/loading_cg/CG20000106/thumb/CG20000106_thumb.jpg",false,8,12,S({30740022,}),S({}),false,false,false,false,false}, get);
tb[30740023] = P({D[12016], 30740023,16023,801,false,182,705,false,"deco/loading_cg/CG200044/thumb/CG200044_thumb.jpg",false,8,12,S({30740023,}),S({}),false,false,false,false,false}, get);
tb[30900001] = P({D[13016], 30900001,20078,802,false,310,706,false,"extendRes/items/activity/unused/23yuyi1.jpg","extendRes/items/activity/unused/23yuyi1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900002] = P({D[13016], 30900002,20079,803,false,310,707,false,"extendRes/items/activity/unused/23yuyi2.jpg","extendRes/items/activity/unused/23yuyi2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900003] = P({D[13016], 30900003,20080,804,false,311,708,false,"extendRes/items/activity/unused/23yuyi_hu.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900004] = P({D[13016], 30900004,20081,805,false,312,709,false,"extendRes/items/activity/unused/2311_magic.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900005] = P({D[13016], 30900005,20082,806,false,313,710,false,"extendRes/items/activity/unused/23winter1.jpg","extendRes/items/activity/unused/23winter1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900006] = P({D[13016], 30900006,20083,807,false,313,711,false,"extendRes/items/activity/unused/23winter2.jpg","extendRes/items/activity/unused/23winter2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900007] = P({D[13016], 30900007,20084,808,false,314,712,false,"extendRes/items/activity/unused/24chunjie1.jpg","extendRes/items/activity/unused/24chunjie1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900008] = P({D[13016], 30900008,20085,809,false,314,713,false,"extendRes/items/activity/unused/24chunjie2.jpg","extendRes/items/activity/unused/24chunjie2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900009] = P({D[13016], 30900009,20086,810,false,314,714,false,"extendRes/items/activity/unused/24chunjie3.jpg","extendRes/items/activity/unused/24chunjie3_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900010] = P({D[13016], 30900010,20087,811,false,314,715,false,"extendRes/items/activity/unused/24chunjie4.jpg","extendRes/items/activity/unused/24chunjie4_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900011] = P({D[13016], 30900011,20088,812,false,314,716,false,"extendRes/items/activity/unused/24chunjie5.jpg","extendRes/items/activity/unused/24chunjie5_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900012] = P({D[13016], 30900012,20089,813,false,314,717,false,"extendRes/items/activity/unused/24chunjie6.jpg","extendRes/items/activity/unused/24chunjie6_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900013] = P({D[13016], 30900013,20090,814,false,314,718,false,"extendRes/items/activity/unused/24chunjie7.jpg","extendRes/items/activity/unused/24chunjie7_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900014] = P({D[13016], 30900014,20091,815,false,314,719,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900015] = P({D[13016], 30900015,20092,816,false,314,720,false,"extendRes/items/activity/unused/24chunjie9.jpg","extendRes/items/activity/unused/24chunjie9_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900016] = P({D[13016], 30900016,20093,817,false,315,721,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900017] = P({D[13016], 30900017,20094,818,false,315,722,false,"ui/activity/extend/2403broadcast/main/pic_scattered/huaqiu.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/huaqiu_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900018] = P({D[13016], 30900018,20095,819,false,315,723,false,"ui/activity/extend/2403broadcast/main/pic_scattered/diaoyushao.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/diaoyushao_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900019] = P({D[13016], 30900019,20096,820,false,315,724,false,"ui/activity/extend/2403broadcast/main/pic_scattered/22rpg_wolf.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/22rpg_wolf_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900020] = P({D[13016], 30900020,20097,821,false,315,725,false,"ui/activity/extend/2403broadcast/main/pic_scattered/22shuiyi3.jpg","ui/activity/extend/2403broadcast/main/pic_scattered/22shuiyi3_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900021] = P({D[13016], 30900021,20093,822,false,316,726,false,"extendRes/items/activity/unused/24ba2.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900022] = P({D[13016], 30900022,20094,823,false,317,false,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900023] = P({D[13016], 30900023,20095,824,false,317,false,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900024] = P({D[13016], 30900024,20096,825,false,317,false,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900025] = P({D[13016], 30900025,20097,826,false,318,727,false,"extendRes/items/activity/unused/24ouxiang1.jpg","extendRes/items/activity/unused/24ouxiang1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900026] = P({D[13016], 30900026,20098,827,false,318,728,false,"extendRes/items/activity/unused/24ouxiang2.jpg","extendRes/items/activity/unused/24ouxiang2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900027] = P({D[13016], 30900027,20099,828,false,318,729,false,"extendRes/items/activity/unused/24ouxiang3.jpg","extendRes/items/activity/unused/24ouxiang3_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900028] = P({D[13016], 30900028,20100,829,false,319,730,false,"extendRes/items/activity/unused/24haidao1.jpg","extendRes/items/activity/unused/24haidao1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900029] = P({D[13016], 30900029,20101,830,false,319,731,false,"extendRes/items/activity/unused/24haidao2.jpg","extendRes/items/activity/unused/24haidao2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900030] = P({D[13016], 30900030,20102,false,false,false,false,false,false,false,6,false,0,S({}),S({}),false,false,false,false,false}, get);