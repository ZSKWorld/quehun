-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[30900053] = P({D[11016], 30900053,20125,827,false,322,729,false,"extendRes/items/activity/unused/24summer41.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900054] = P({D[11016], 30900054,20126,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900055] = P({D[11016], 30900055,20127,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900056] = P({D[11016], 30900056,20128,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900057] = P({D[11016], 30900057,20129,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900058] = P({D[11016], 30900058,20130,828,false,316,false,false,"extendRes/items/activity/unused/24summer101.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900059] = P({D[11016], 30900059,20131,829,false,316,false,false,"extendRes/items/activity/unused/24summer102.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900060] = P({D[11016], 30900060,20132,830,false,316,730,false,"extendRes/items/activity/unused/24summer103.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900061] = P({D[11016], 30900061,20133,831,false,316,731,false,"extendRes/items/activity/unused/24summer104.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900062] = P({D[11016], 30900062,20134,832,false,316,732,false,"extendRes/items/activity/unused/24summer105.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900063] = P({D[11016], 30900063,20135,833,false,316,733,false,"extendRes/items/activity/unused/24summer106.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900064] = P({D[11016], 30900064,20136,834,false,316,734,false,"extendRes/items/activity/unused/24summer107.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900065] = P({D[11016], 30900065,20137,835,false,316,false,false,"extendRes/items/activity/unused/24summer108.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900066] = P({D[11016], 30900066,20138,836,false,316,735,false,"extendRes/items/activity/unused/24summer109.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900067] = P({D[11016], 30900067,20139,837,false,316,736,false,"extendRes/items/activity/unused/24summer110.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900068] = P({D[11016], 30900068,20140,false,false,316,false,false,"extendRes/items/activity/unused/24summer111.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900069] = P({D[11016], 30900069,20141,false,false,316,false,false,"extendRes/items/activity/unused/24summer112.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900070] = P({D[11016], 30900070,20142,false,false,316,false,false,"extendRes/items/activity/unused/24summer113.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900071] = P({D[11016], 30900071,20143,false,false,316,false,false,"extendRes/items/activity/unused/24summer114.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900072] = P({D[11016], 30900072,20144,false,false,316,false,false,"extendRes/items/activity/unused/24summer115.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900073] = P({D[11016], 30900073,20145,false,false,316,false,false,"extendRes/items/activity/unused/24summer116.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900074] = P({D[11016], 30900074,20146,false,false,316,false,false,"extendRes/items/activity/unused/24summer117.jpg",false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900075] = P({D[11016], 30900075,20147,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900076] = P({D[11016], 30900076,20148,false,false,316,false,false,false,false,6,S({}),S({}),false,false,false,false,false}, get);
tb[30900077] = P({D[13016], 30900077,20149,838,false,323,737,false,"extendRes/items/activity/unused/2409sanliou_coin.jpg","extendRes/items/activity/unused/2409sanliou_coin_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900078] = P({D[13016], 30900078,20150,839,false,324,738,false,"extendRes/items/activity/unused/24imas1.jpg","extendRes/items/activity/unused/24imas1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900079] = P({D[19022], 30900079,20151,840,false,324,739,false,"extendRes/items/activity/unused/24imas2.jpg",false,6,false,0,9999999,false,false,false,S({}),S({}),false}, get);
tb[30900080] = P({D[13016], 30900080,20152,841,false,325,740,false,"extendRes/items/activity/unused/25chunjie1.jpg","extendRes/items/activity/unused/25chunjie1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900081] = P({D[13016], 30900081,20153,842,false,325,741,false,"extendRes/items/activity/unused/25chunjie3.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900082] = P({D[13016], 30900082,20154,843,false,325,742,false,"extendRes/items/activity/unused/25chunjie4.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900083] = P({D[13016], 30900083,20155,844,false,325,743,false,"extendRes/items/activity/unused/25chunjie5.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900084] = P({D[13016], 30900084,20156,845,false,326,744,false,"extendRes/items/activity/unused/25lifu1.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900085] = P({D[13016], 30900085,20157,846,false,326,745,false,"extendRes/items/activity/unused/25lifu2.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900086] = P({D[13016], 30900086,20158,847,false,327,746,false,"extendRes/items/activity/unused/25wenquan1.jpg","extendRes/items/activity/unused/25wenquan1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900087] = P({D[13016], 30900087,20159,848,false,327,747,false,"extendRes/items/activity/unused/25wenquan2.jpg","extendRes/items/activity/unused/25wenquan2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900088] = P({D[13016], 30900088,20160,849,false,327,748,false,"extendRes/items/activity/unused/25wenquan3.jpg","extendRes/items/activity/unused/25wenquan3_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900089] = P({D[13016], 30900089,20161,850,false,328,749,false,"extendRes/items/activity/unused/25fate1.jpg","extendRes/items/activity/unused/25fate1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900090] = P({D[13016], 30900090,20162,792,false,329,750,false,"ui/activity/extend/2312combine/main/pic_scattered/25xila1.jpg","ui/activity/extend/2312combine/main/pic_scattered/25xila1_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900091] = P({D[13016], 30900091,20163,793,false,329,751,false,"ui/activity/extend/2312combine/main/pic_scattered/25xila2.jpg","ui/activity/extend/2312combine/main/pic_scattered/25xila2_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900092] = P({D[13016], 30900092,20164,851,false,330,752,false,"ui/activity/extend/2508voyage/main/pic_scattered/25summer.jpg","ui/activity/extend/2508voyage/main/pic_scattered/25summer_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900093] = P({D[13016], 30900093,20165,852,false,331,753,false,"extendRes/items/25wuxia1.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900094] = P({D[13016], 30900094,20166,853,false,331,754,false,"extendRes/items/25wuxia2.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900095] = P({D[13016], 30900095,20167,854,false,332,755,false,"ui/activity/extend/2510questcrew/main/pic_scattered/25yh.jpg","ui/activity/extend/2510questcrew/main/pic_scattered/25yh_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900096] = P({D[13016], 30900096,20168,855,false,333,756,false,"ui/activity/extend/2509wuxia/main/pic_scattered/25yuehui.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900097] = P({D[13016], 30900097,20169,856,false,334,757,false,"ui/activity/extend/snowball/main/pic_scattered/25dongri.jpg","ui/activity/extend/snowball/main/pic_scattered/25dongri_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);