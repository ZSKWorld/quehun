-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[30900101] = P({D[13016], 30900101,20173,860,false,336,761,false,"ui/activity/extend/26wenquan/main/pic_scattered/26wenquan2.jpg",false,6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30900102] = P({D[19022], 30900102,20174,861,false,337,762,false,"ui/activity/extend/26dj/main/pic_scattered/26dj1.jpg","ui/activity/extend/26dj/main/pic_scattered/26dj1_0.png",6,false,0,9999,false,false,false,S({}),S({}),false}, get);
tb[30900103] = P({D[19022], 30900103,20175,862,false,337,763,false,"ui/activity/extend/26dj/main/pic_scattered/26dj2.jpg","ui/activity/extend/26dj/main/pic_scattered/26dj2_0.png",6,false,0,9999,false,false,false,S({}),S({}),false}, get);
tb[30900104] = P({D[13016], 30900104,20176,863,false,338,764,false,"ui/activity/extend/26dp/main/pic_scattered/26dp.jpg","ui/activity/extend/26dp/main/pic_scattered/26dp_0.png",6,false,0,S({}),S({}),false,false,false,false,false}, get);
tb[30910001] = P({D[11016], 30910001,90060,864,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910002] = P({D[11016], 30910002,90061,865,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910003] = P({D[11016], 30910003,90062,866,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910004] = P({D[11016], 30910004,90063,867,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910005] = P({D[11016], 30910005,90064,868,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910006] = P({D[11016], 30910006,90065,869,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910007] = P({D[11016], 30910007,90066,870,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910008] = P({D[11016], 30910008,90067,871,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910009] = P({D[11016], 30910009,90068,872,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910010] = P({D[11016], 30910010,90069,873,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910011] = P({D[11016], 30910011,90070,874,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910012] = P({D[11016], 30910012,90071,875,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910013] = P({D[11016], 30910013,90072,876,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910014] = P({D[11016], 30910014,90073,877,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910015] = P({D[11016], 30910015,90074,878,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910016] = P({D[11016], 30910016,90075,879,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910017] = P({D[11016], 30910017,90076,880,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910018] = P({D[11016], 30910018,90077,881,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910019] = P({D[11016], 30910019,90078,882,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910020] = P({D[11016], 30910020,90079,883,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910021] = P({D[11016], 30910021,90080,884,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910022] = P({D[11016], 30910022,90081,885,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910023] = P({D[11016], 30910023,90082,886,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910024] = P({D[11016], 30910024,90083,887,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910025] = P({D[11016], 30910025,90084,888,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910026] = P({D[11016], 30910026,90085,889,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30910027] = P({D[11016], 30910027,90086,890,false,false,false,false,false,false,6,S({}),S({}),false,false,false,"2026-03-11 04:59:00",false}, get);
tb[30990001] = P({D[12016], 30990001,17011,891,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990002] = P({D[12016], 30990002,17012,892,false,339,765,false,"deco/hand/hand_vip/pic/hand_vip.jpg",false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990003] = P({D[12016], 30990003,17013,893,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990004] = P({D[12016], 30990004,17014,894,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990005] = P({D[12016], 30990005,17015,895,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990006] = P({D[12016], 30990006,17016,896,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990007] = P({D[12016], 30990007,17017,897,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990008] = P({D[12016], 30990008,17018,898,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990009] = P({D[12016], 30990009,17019,899,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990010] = P({D[12016], 30990010,17020,900,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990011] = P({D[12016], 30990011,17021,901,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990012] = P({D[12016], 30990012,17022,902,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990013] = P({D[12016], 30990013,17023,903,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);
tb[30990014] = P({D[12016], 30990014,17024,904,false,false,false,false,false,false,false,3,S({}),S({}),false,false,false,false,false}, get);