-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local item = require("Excels.Data.item_definition.item")
local tb = item.tb
local get = item.get

tb[305054] = P({D[12016], 305054,2005,114,false,93,125,false,"deco/lizhi_bgm/pic/liqibgm.jpg",false,false,4,S({302003,5,}),S({"music/liqi_23summer.mp3",}),false,false,false,false,false}, get);
tb[305055] = P({D[12016], 305055,2006,115,false,94,126,false,"deco/lizhi_bgm/pic/liqibgm.jpg",false,false,4,S({302003,5,}),S({"music/liqi_23ex_xiyang.mp3",}),false,false,false,false,false}, get);
tb[305056] = P({D[12016], 305056,2007,116,false,95,127,false,"deco/lizhi_bgm/pic/liqibgm.jpg",false,false,4,S({302003,5,}),S({"music/liqi_23ex_rpg.mp3",}),false,false,false,false,false}, get);
tb[305200] = P({D[12016], 305200,3001,117,false,72,128,false,"deco/effect_hupai/ron_youlingaoao/pic/ron_youlingaoao.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305201] = P({D[12016], 305201,3002,118,false,96,129,false,"deco/effect_hupai/ron_gejumeiying/pic/ron_gejumeiying.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305202] = P({D[12016], 305202,3003,119,false,96,130,false,"deco/effect_hupai/ron_mofashaonv/pic/ron_mofashaonv.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305203] = P({D[12016], 305203,3004,120,false,83,131,false,"deco/effect_hupai/ron_20chunjie/pic/ron_20chunjie.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305204] = P({D[12016], 305204,3005,121,false,96,132,false,"deco/effect_hupai/ron_szx/pic/ron_szx.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305205] = P({D[12016], 305205,3006,122,false,96,133,false,"deco/effect_hupai/ron_xhzy/pic/ron_xhzy.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305206] = P({D[12016], 305206,3007,123,false,96,134,false,"deco/effect_hupai/ron_nws/pic/ron_nws.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305207] = P({D[12016], 305207,3008,124,false,96,135,false,"deco/effect_hupai/ron_jd/pic/ron_jd.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305208] = P({D[12016], 305208,3009,125,false,96,136,false,"deco/effect_hupai/ron_hl/pic/ron_hl.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305209] = P({D[12016], 305209,3010,126,false,96,137,false,"deco/effect_hupai/ron_music/pic/ron_music.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305210] = P({D[12016], 305210,3011,127,false,96,138,false,"deco/effect_hupai/ron_21chunjie/pic/ron_21chunjie.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305211] = P({D[12016], 305211,3012,128,false,96,139,false,"deco/effect_hupai/ron_21cyber/pic/ron_21cyber.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305212] = P({D[12016], 305212,3013,129,false,96,140,false,"deco/effect_hupai/ron_21magic/pic/ron_21magic.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305213] = P({D[12016], 305213,3014,130,false,83,141,false,"deco/effect_hupai/ron_21zhounian/pic/ron_21zhounian.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305214] = P({D[12016], 305214,3015,131,false,97,false,false,false,false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305215] = P({D[12016], 305215,3016,132,false,98,142,false,"deco/effect_hupai/ron_xiyuansi/pic/ron_xiyuansi.jpg",false,false,1,S({}),S({}),false,false,false,false,false}, get);
tb[305216] = P({D[12016], 305216,3017,133,false,99,143,false,"deco/effect_hupai/ron_21winter/pic/ron_21winter.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305217] = P({D[12016], 305217,3018,134,false,100,144,false,"deco/effect_hupai/ron_22chunjie/pic/ron_22chunjie.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305218] = P({D[12016], 305218,3019,135,false,96,145,false,"deco/effect_hupai/ron_22rpg/pic/ron_22rpg.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305219] = P({D[12016], 305219,3020,136,false,101,146,false,"deco/effect_hupai/ron_beiyuan/pic/ron_beiyuan.jpg",false,false,1,S({}),S({}),false,false,false,false,false}, get);
tb[305220] = P({D[12016], 305220,3021,137,false,102,147,false,"deco/effect_hupai/ron_22summer/pic/ron_22summer.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305221] = P({D[12016], 305221,3022,138,false,96,148,false,"deco/effect_hupai/ron_23wenquan/pic/ron_23wenquan.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305222] = P({D[12016], 305222,3023,139,false,83,149,false,"deco/effect_hupai/ron_23rpg/pic/ron_23rpg.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305223] = P({D[12016], 305223,3024,140,false,103,150,false,"deco/effect_hupai/ron_dongcheng/pic/ron_dongcheng.jpg",false,false,1,S({}),S({}),false,false,false,false,false}, get);
tb[305224] = P({D[12016], 305224,3025,141,false,72,151,false,"deco/effect_hupai/ron_23ex_heidong/pic/ron_23ex_heidong.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305225] = P({D[12016], 305225,3026,142,false,72,152,false,"deco/effect_hupai/ron_23ex_liandao/pic/ron_23ex_liandao.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305226] = P({D[12016], 305226,3027,143,false,72,153,false,"deco/effect_hupai/ron_23ex_shuizhu/pic/ron_23ex_shuizhu.jpg",false,false,1,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305300] = P({D[12016], 305300,4001,144,false,73,154,false,"deco/effect_lizhi/effect_liqi_bianfujiejie/pic/effect_liqi_bianfujiejie.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305301] = P({D[12016], 305301,4002,145,false,104,155,false,"deco/effect_lizhi/effect_liqi_feichangshitai/pic/effect_liqi_feichangshitai.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305302] = P({D[12016], 305302,4003,146,false,104,156,false,"deco/effect_lizhi/effect_liqi_mofashaonv/pic/effect_liqi_mofashaonv.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305303] = P({D[12016], 305303,4004,147,false,104,157,false,"deco/effect_lizhi/effect_liqi_20chunjie/pic/effect_liqi_20chunjie.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305304] = P({D[12016], 305304,4005,148,false,104,158,false,"deco/effect_lizhi/effect_liqi_szx/pic/effect_liqi_szx.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305305] = P({D[12016], 305305,4006,149,false,104,159,false,"deco/effect_lizhi/effect_liqi_xhzy/pic/effect_liqi_xhzy.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305306] = P({D[12016], 305306,4007,150,false,104,160,false,"deco/effect_lizhi/effect_liqi_nws/pic/effect_liqi_nws.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305307] = P({D[12016], 305307,4008,151,false,104,161,false,"deco/effect_lizhi/effect_liqi_jd/pic/effect_liqi_jd.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305308] = P({D[12016], 305308,4009,152,false,104,162,false,"deco/effect_lizhi/effect_liqi_hl/pic/effect_liqi_hl.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305309] = P({D[12016], 305309,4010,153,false,104,163,false,"deco/effect_lizhi/effect_liqi_music/pic/effect_liqi_music.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305310] = P({D[12016], 305310,4011,154,false,104,164,false,"deco/effect_lizhi/effect_liqi_21chunjie/pic/effect_liqi_21chunjie.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305311] = P({D[12016], 305311,4012,155,false,104,165,false,"deco/effect_lizhi/effect_liqi_21cyber/pic/effect_liqi_21cyber.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305312] = P({D[12016], 305312,4013,156,false,104,166,false,"deco/effect_lizhi/effect_liqi_21magic/pic/effect_liqi_21magic.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305313] = P({D[12016], 305313,4014,157,false,105,167,false,"deco/effect_lizhi/effect_liqi_21zhounian/pic/effect_liqi_21zhounian.jpg",false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);
tb[305314] = P({D[12016], 305314,4015,131,false,97,false,false,false,false,false,2,S({302003,5,}),S({}),false,false,false,false,false}, get);