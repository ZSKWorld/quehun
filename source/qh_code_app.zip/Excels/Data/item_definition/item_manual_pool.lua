-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item_manual_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["res_id"] = 2; ["res_count"] = 3;};

local df = {  309063, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local item_manual_pool = { }
item_manual_pool[10001] = {
	P({10001,100001,100}, get),
	P({10001,100002,50000}, get),
	P({10001,302002,100}, get),
	P({10001,200004}, get),
};
item_manual_pool[304101] = {
	P({304101,303112}, get),
	P({304101,303122}, get),
	P({304101,303132}, get),
	P({304101,303142}, get),
	P({304101,303152}, get),
	P({304101,303162}, get),
	P({304101,303172}, get),
	P({304101,303182}, get),
};
item_manual_pool[304102] = {
	P({304102,303113}, get),
	P({304102,303123}, get),
	P({304102,303133}, get),
	P({304102,303143}, get),
	P({304102,303153}, get),
	P({304102,303163}, get),
	P({304102,303173}, get),
	P({304102,303183}, get),
};
item_manual_pool[309063] = {
	P({false,400103}, get),
	P({false,400104}, get),
	P({false,400105}, get),
	P({false,400203}, get),
	P({false,400206}, get),
	P({false,400303}, get),
	P({false,400304}, get),
	P({false,400403}, get),
	P({false,400404}, get),
	P({false,400405}, get),
	P({false,400503}, get),
	P({false,400504}, get),
	P({false,400603}, get),
	P({false,400604}, get),
	P({false,400703}, get),
	P({false,400704}, get),
	P({false,400705}, get),
	P({false,400803}, get),
	P({false,400804}, get),
	P({false,400805}, get),
	P({false,400903}, get),
	P({false,400904}, get),
	P({false,401003}, get),
	P({false,401103}, get),
	P({false,401104}, get),
	P({false,401203}, get),
	P({false,401303}, get),
	P({false,401304}, get),
	P({false,401403}, get),
	P({false,401404}, get),
	P({false,401405}, get),
	P({false,401603}, get),
	P({false,401604}, get),
	P({false,401605}, get),
	P({false,401706}, get),
	P({false,401707}, get),
	P({false,401803}, get),
	P({false,401903}, get),
	P({false,401904}, get),
	P({false,401905}, get),
	P({false,402003}, get),
	P({false,402004}, get),
	P({false,402103}, get),
	P({false,402203}, get),
	P({false,402303}, get),
	P({false,402403}, get),
	P({false,402404}, get),
	P({false,402503}, get),
	P({false,402603}, get),
	P({false,402604}, get),
	P({false,402703}, get),
	P({false,402803}, get),
	P({false,402804}, get),
	P({false,402903}, get),
	P({false,403003}, get),
	P({false,403103}, get),
	P({false,403203}, get),
	P({false,403303}, get),
	P({false,403803}, get),
	P({false,403903}, get),
	P({false,404403}, get),
	P({false,404504}, get),
	P({false,405403}, get),
};
return { tb = item_manual_pool };