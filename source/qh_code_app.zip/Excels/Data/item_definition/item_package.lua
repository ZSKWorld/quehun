-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][item_package]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["res_id"] = 2; ["res_count"] = 3;};

local df = {  1001, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local item_package = { }
item_package[1001] = {
	P({false,309111}, get),
	P({false,309112}, get),
	P({false,309113}, get),
	P({false,309114}, get),
	P({false,309115}, get),
	P({false,309116}, get),
	P({false,309117}, get),
	P({false,309118}, get),
	P({false,309119}, get),
	P({false,309120}, get),
	P({false,309121}, get),
	P({false,309122}, get),
	P({false,309123}, get),
	P({false,309124}, get),
	P({false,309125}, get),
	P({false,309126}, get),
	P({false,309127}, get),
	P({false,309128}, get),
	P({false,309129}, get),
	P({false,309130}, get),
	P({false,309131}, get),
	P({false,309132}, get),
	P({false,309133}, get),
	P({false,309134}, get),
	P({false,309135}, get),
	P({false,309136}, get),
	P({false,309137}, get),
	P({false,309138}, get),
	P({false,309139}, get),
	P({false,309140}, get),
	P({false,309141}, get),
	P({false,309142}, get),
	P({false,309143}, get),
	P({false,309144}, get),
	P({false,309145}, get),
	P({false,309147}, get),
	P({false,309148}, get),
	P({false,309149}, get),
	P({false,309150}, get),
	P({false,309151}, get),
	P({false,309152}, get),
	P({false,309153}, get),
	P({false,309154}, get),
	P({false,309155}, get),
	P({false,309156}, get),
	P({false,309157}, get),
	P({false,309158}, get),
	P({false,309159}, get),
	P({false,309160}, get),
	P({false,30910001}, get),
	P({false,30910002}, get),
	P({false,30910003}, get),
	P({false,30910004}, get),
	P({false,30910005}, get),
	P({false,30910006}, get),
	P({false,30910007}, get),
	P({false,30910008}, get),
	P({false,30910009}, get),
	P({false,30910010}, get),
	P({false,30910011}, get),
	P({false,30910012}, get),
	P({false,30910013}, get),
	P({false,30910014}, get),
	P({false,30910015}, get),
	P({false,30910016}, get),
	P({false,30910017}, get),
	P({false,30910018}, get),
	P({false,30910019}, get),
	P({false,30910020}, get),
	P({false,30910021}, get),
	P({false,30910022}, get),
	P({false,30910023}, get),
	P({false,30910024}, get),
	P({false,30910025}, get),
	P({false,30910026}, get),
	P({false,30910027}, get),
};
return { tb = item_package };