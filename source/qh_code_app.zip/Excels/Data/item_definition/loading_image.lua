-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][loading_image]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["img_path"] = 1002; ["thumb_path"] = 1003; ["sort"] = 4; ["unlock_items"] = 5; ["args"] = 6;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {240301,30740023,}

local loading_image = { }
return { tb = loading_image, get = get, b2i = b2i };