-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["type"] = 2; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["desc_chs"] = -4; ["desc_chs_t"] = -4; ["desc_jp"] = -4; ["desc_en"] = -4; ["desc_kr"] = -4; ["desc_jp2"] = 1005; ["character_id"] = 6; ["lock_tips_chs"] = -7; ["lock_tips_chs_t"] = -7; ["lock_tips_jp"] = -7; ["lock_tips_en"] = -7; ["lock_tips_kr"] = -7; ["path"] = 1008; ["exchange_item_id"] = 9; ["exchange_item_num"] = 10; ["direction"] = 11; ["no_reverse"] = 12; ["lock_reverse"] = 13; ["offset_x"] = 14; ["offset_y"] = 15; ["spot_scale"] = 1016; ["effective_time"] = 1017; ["lobby_offset"] = 1018; ["liaoshe_offset"] = 1019; ["shop_offset"] = 1020; ["win_offset"] = 1021; ["gameend_offset"] = 1022; ["starup_offset"] = 1023; ["treasure_offset"] = 1024; ["ck_full_0_offset"] = 1025; ["ck_full_1_offset"] = 1026; ["ck_full_2_offset"] = 1027; ["ck_full_3_offset"] = 1028; ["ck_full_single_offset"] = 1029; ["ck_half_0_offset"] = 1030; ["ck_half_1_offset"] = 1031; ["ck_half_2_offset"] = 1032; ["ck_half_3_offset"] = 1033; ["ck_half_single_offset"] = 1034; ["smallhead_x"] = 35; ["smallhead_y"] = 36; ["smallhead_width"] = 37; ["full_x"] = 38; ["full_y"] = 39; ["full_width"] = 40; ["full_height"] = 41; ["half_x"] = 42; ["half_y"] = 43; ["half_width"] = 44; ["half_height"] = 45; ["spine_type"] = 46; ["spine_width"] = 47; ["spine_height"] = 48; ["pivot_x"] = 49; ["pivot_y"] = 50; ["idle"] = 51; ["greeting"] = 52; ["celebrate"] = 53; ["click"] = 54; ["greeting_init"] = 55; ["click2"] = 56; ["celebrate_idle"] = 57; ["illust_data"] = 1058; ["blink"] = 59;};

local df = {  nil, nil,  nil,  nil, nil, 200007,  nil, nil, nil, nil, nil, nil, nil, nil, nil, "0", nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, 1261, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "item_definition_skin"); end;

local b2i = {400303,400502,400702,400904,401202,401406,401709,401907,402203,402503,402802,403002,403206,403704,404101,404504,404804,405202,405802,406102,406702,407002,407602,408303,408703,409203,409801,40010301,40011203,40012503,}

local skin = { }
return { tb = skin, get = get, b2i = b2i };