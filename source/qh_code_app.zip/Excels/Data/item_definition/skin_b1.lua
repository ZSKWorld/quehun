-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[400000] = P({D[11023], 400000,false,1,false,false,0,false,"deco/character/default_girl",302002,60,"0,110,0.9",false,false,false,false,false,false,false,false,false,false,1739,790,541,1201,737,1620,2804,1201,737,1620,1084}, get);
tb[400001] = P({D[11023], 400001,false,2,false,false,0,false,"deco/character/default_man",302002,60,"0,380,0.89",false,false,false,false,false,false,false,false,false,false,1803,792,539,1581,737,968,3052,1581,737,968,1085}, get);
tb[400101] = P({D[17030], 400101,false,3,1,false,200001,false,"deco/character/yiji",302002,60,false,1,false,false,-64,"1","-160,0,1",false,false,false,1829,845,400,1189,701,1716,2582,1189,701,1716,1104,false,false,false,false,false,false,false,false,false,false,false,false,"yiji"}, get);
tb[400102] = P({D[13044], 400102,1,4,2,"「にゃ？にゃにゃ〜！\n契約までしたのに、まだ猫語がわからないのかにゃ、ご主人？」",200001,1,"deco/character/yiji_0",302002,60,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"yiji_0"}, get);
tb[400103] = P({D[9044], 400103,2,5,3,false,200001,2,"deco/character/yiji_haitanpaidui",0,false,false,false,false,false,false,false,false,false,false,false,false,"yiji_xr"}, get);
tb[400104] = P({D[9044], 400104,5,6,4,"「ご主人、ちんたらしてないでさっさと手伝うにゃ！　今日は一年でいっちばん忙しい日にゃ……にゃにゃ？　一姫は一番大事なお仕事……料理の味見係でそれはもうてんてこ舞いにゃ！！」",200001,2,"deco/character/yiji_xinnianchuzhi",0,false,false,false,false,false,false,false,false,false,false,false,false,"yiji_yd"}, get);
tb[400105] = P({D[21044], 400105,10,7,5,"「にゃむらい一姫参上！　そなたの凛々しい姿……きっと一姫の主にゃ！　主の安全と牌運は一姫が守ってやるにゃ！」",200001,2,"deco/character/yiji_SP",false,false,false,1,false,false,false,false,false,false,false,"260,-30,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yiji_zg"}, get);
tb[400106] = P({D[21044], 400106,6,8,6,"「獅子の頭は一姫が持つから、尻尾の方はご主人に任せるにゃ！　魂天神社の獅子舞コンビの力を見せつける時が来たにゃ！」",200001,2,"deco/character/yiji_CJ",false,false,false,false,false,false,false,"1",false,false,false,"260,-90,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yiji_cj"}, get);
tb[400107] = P({D[17044], 400107,18,9,7,"「にゃにゃ！？ ご主人、見るにゃ！\n一姫の大好きなおやつがタイムセール中だにゃ～！\nご主人、いい子にしてた一姫には、ご褒美があってもいいんじゃないかにゃ～？」",200001,2,"deco/character/yiji_kxj",false,false,false,false,false,false,false,"",0,1,4093,5000,2086,2334,5333,4333,8266,5333,15633,6666,5333,"yiji_kxj"}, get);
tb[400201] = P({D[17023], 400201,false,10,8,false,200002,false,"deco/character/erjietang",302002,60,false,1,false,false,-81,"1","80,120,1",false,false,false,false,false,"0,-40,1","0,-40,1",false,false,false,1891,788,387,1161,700,1733,2714,1161,700,1733,1042}, get);
tb[400202] = P({D[13034], 400202,1,4,9,"「いいわ、今日は特別に、あなたに独り占めさせてあ・げ・る。\nどうやって素敵な夜を過ごすか、考えておいて」",200002,1,"deco/character/erjietang_0",302002,60,false,1,1823,792,420,1112,704,1976,2780,1112,704,1976,1058}, get);
tb[400203] = P({D[12034], 400203,3,11,10,"「もし今夜の舞踏会が物足りないなら、お姉さんが他の楽しいことを教えてあげるわね？」",200002,2,"deco/character/erjietang_WSJ",false,false,1,2019,873,448,1033,552,2326,2809,1033,596,2326}, get);
tb[400206] = P({D[16034], 400206,6,12,11,"「あら、女の子がお化粧しているところを覗くなんて悪い子ね～？　今日はおめかしした私を見てもらいたいの。おりこうさんで待っててちょうだい？」",200002,2,"deco/character/erjietang_CJ",false,false,false,false,false,false,550,1730,1012,400,1357,933,1590,1910,1357,933,1590,1039}, get);
tb[400207] = P({D[24034], 400207,12,13,12,"「あら、知らなかったの？　今夜はみんな、あなたのためにここに集まっているのよ。」",200002,2,"deco/character/erjietang_LF",false,false,false,false,false,false,false,"1",false,"0,0,0.98","0,0,0.98","180,140,0.84","0,0,0.98","0,0,0.98","40,0,0.98",1842,796,400,922,389,2189,3518,922,495,2189}, get);
tb[400208] = P({D[24034], 400208,2,14,13,"「こんなところに隠れて、隙を見て私を海に落とすつもりだったのかしら？　ふふっ。そうね、あなたがどうしてもって言うなら、乗ってあげるわよ？　あなたが聞きたかったであろう悲鳴を聞かせてあげるわ。」",200002,2,"deco/character/erjietang_YZ",false,false,false,false,false,false,false,"1",false,"40,20,1","40,20,1","240,-240,1","40,20,1","40,20,1","40,20,1",1815,829,400,589,107,2946,2894,611,528,2902}, get);
tb[400301] = P({D[46057], 400301,false,15,14,false,200003,false,"deco/character/tengtianjianai",302002,60,false,false,false,false,-54,"0.99",false,false,false,false,false,false,false,"0,160,1","-70,30,0.99","0,20,0.99","0,0,0.99","0,0,0.99","0,0,0.99","-90,20,0.99","-60,20,0.99","0,0,0.99",false,false,1902,873,420,1432,768,1140,2668,1432,768,1140,1075,"tengtianjianai"}, get);
tb[400302] = P({D[12034], 400302,1,4,15,"「次はショッピングに行こっ！」\n少女は小首を傾けてそう誘った。",200003,1,"deco/character/tengtianjianai_0",302002,60,1,1819,911,420,1220,776,1820,2728,1220,776,1820,1105,false,false,false,false,false,false,false,false,false,false,false,false,"tengtianjianai_0"}, get);
tb[400303] = P({D[12034], 400303,4,16,16,"「皆さ～ん、佳奈ちゃんのクリスマスライブへようこそ！　この曲は、大切な皆さんへ！」",200003,2,"deco/character/tengtianjianai_sd",false,false,1,1941,898,400,1209,730,1867,2558,1209,730,1867,1128,false,false,false,false,false,false,false,false,false,false,false,false,"tengtianjianai_sd"}, get);