-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[402202] = P({D[12034], 402202,1,4,135,"「Oh！ My Partnerじゃないか！\n次の目的地はもう決まってるぜ！ Let\'s go!」",200022,1,"deco/character/yuesefu_0",302002,60,1,1984,959,414,1014,558,2181,2865,1014,665,2181,1261}, get);
tb[402203] = P({D[21034], 402203,5,41,136,"「Happy New Year！　My Friend。エスニックで伝統的なファッションだが、意外とジェントルマンなオーラが出てる感じがしないか？」",200022,2,"deco/character/yuesefu_YD",false,false,1,1,false,false,false,"1","2020-12-30 05:00:00+08",false,false,"0,-400,1",1951,984,315,1041,419,2118,2158,1041,641,2118,1261}, get);
tb[402301] = P({D[17023], 402301,false,74,137,false,200023,false,"deco/character/zhaitengzhi",302002,60,1,false,false,false,-154,"1","120,630,0.94","-90,20,1.02","0,20,1",false,false,false,"-80,-20,1","-30,-20,1",false,false,false,1860,774,400,1284,724,1479,3311,1284,724,1479,1010}, get);
tb[402302] = P({D[11034], 402302,1,4,138,"「そうかしこまるな、もっと近付いてくれて構わない。\n私の前ではありのままのあなたでいいと言ったはずだ。\n私が好ましいと思うのは、そういうあなただからな」",200023,1,"deco/character/zhaitengzhi_0",302002,60,1610,966,400,1131,874,2444,2732,1131,874,2444,1052}, get);
tb[402303] = P({D[13034], 402303,11,64,139,"「私は花火大会に行くよりも決算書を確認していた方が有意義だと、なんなら麻雀でも打っていた方が性に合うと思っていた。……だが、あなたからの誘いを無下にはできないな。」",200023,2,"deco/character/zhaitengzhi_YY",false,false,1,1,1777,733,436,519,645,3047,3284,592,645,2901,1066}, get);
tb[402304] = P({D[24034], 402304,4,75,140,"「慌てるな、今日はあなたは遅刻していない。私が早く着いただけだ。……そうだな、確かに私は今日を楽しみにしていた。何か問題でも？」",200023,2,"deco/character/zhaitengzhi_SD",false,false,false,false,false,false,false,"1",false,false,"-60,0,1","180,230,0.8","-40,0,1","-40,0,1","-70,0,1",2011,799,406,625,false,3095,3970,722,501,2901,1261}, get);
tb[402401] = P({D[46057], 402401,false,76,141,false,200024,false,"deco/character/beijianshahezi",302002,60,1,false,false,false,false,"1",false,false,false,false,false,false,false,"80,80,1","-80,0,1","0,-30,1",false,false,false,"-60,-40,1","0,-40,1",false,false,false,1894,849,400,1059,722,1788,2580,1059,722,1788,1087,"beijianshahezi"}, get);
tb[402402] = P({D[11034], 402402,1,4,142,"「もうすぐ夏ね〜。あなたと出会ってから初めての夏、すごく楽しみにしてるのよ」",200024,1,"deco/character/beijianshahezi_0",302002,60,1894,853,400,872,485,2478,2899,1110,552,2002,1261,false,false,false,false,false,false,false,false,false,false,false,false,"beijianshahezi_0"}, get);
tb[402403] = P({D[9034], 402403,4,77,143,"「子どもたちにクリスマスプレゼントを用意する時に、あなたの分も用意しておいたのよ！　さぁ、はやくこっちに座って。プレゼントを見たあなたがどんなリアクションを見せてくれるのか、楽しみだわ。」",200024,2,"deco/character/beijianshahezi_SD",1804,982,376,832,143,2336,2894,832,669,2336,1261,false,false,false,false,false,false,false,false,false,false,false,false,"beijianshahezi_sd"}, get);
tb[402404] = P({D[12034], 402404,12,37,144,"「シーッ。こんな素敵な夜はただ楽しむだけでいいの。主婦は時間管理が大事、この時間も有効活用しないと。そうね……今なんかは、お酒とダンスをめいっぱい楽しまなきゃ！」",200024,2,"deco/character/beijianshahezi_LF",false,false,1,1809,851,361,1033,715,2290,2269,1033,715,2290,1077,false,false,false,false,false,false,false,false,false,false,false,false,"beijianshahezi_lf"}, get);
tb[402405] = P({D[21034], 402405,9,78,145,"「一日中忙しくて、この時間くらいしか気が休まらないのよね……。ごめんなさい、つい愚痴っちゃって……あら？　ふふっ、幸せそうな寝顔。聞かれたかなんて、心配するまでもなさそうね。」",200024,2,"deco/character/beijianshahezi_SY",false,false,false,false,false,false,false,"1",false,false,false,"0,-140,1",1671,924,390,866,424,2952,2616,891,618,2902,1261,false,false,false,false,false,false,false,false,false,false,false,false,"beijianshahezi_sy"}, get);
tb[402406] = P({D[21034], 402406,16,43,146,"「あら……君に見つめられちゃうなんて、なんだかいい気分ね。でも、私なんかより、ハンドルの方に集中しなきゃダメよ。だって……万が一コースアウトでもしちゃったら、大惨事でしょう？」",200024,2,"deco/character/beijianshahezi_SC",false,false,1,false,false,false,false,"1",false,false,false,"240,-320,1",1893,813,390,815,258,2742,2640,815,507,2742,1261,1,4464,5000,2170,2840,13333,13333,13333,13333,12000,8000,13333,"beijianshahezi_sc"}, get);
tb[402407] = P({D[9045], 402407,13,57,147,"「あら？　もうこんな時間……。うふふ……ここはお湯加減もちょうど良いし、邪魔も入らないから……つい長湯しちゃうわね。でも、たまには細かいことを忘れて、ゆ～っくり羽を伸ばしても、大丈夫よね？」",200024,2,"deco/character/beijianshahezi_WQ",1,2816,5000,1390,889,10666,8000,5633,4333,14000,8000,5333,"beijianshahezi_wq"}, get);
tb[402501] = P({D[46057], 402501,false,79,148,false,200025,false,"deco/character/aiyin",302002,60,1,false,false,false,-74,"1",false,false,false,false,false,false,false,"0,250,0.98","-50,0,1",false,false,false,false,"-40,-20,1","0,-20,1",false,false,false,1833,836,400,1254,657,1731,2879,1254,657,1731,1139,"aiyin"}, get);