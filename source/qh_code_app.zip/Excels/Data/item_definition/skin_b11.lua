-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[402502] = P({D[12034], 402502,1,4,149,"「尻尾、ちゃんと掴んどけよ？ 狩りの間にはぐれたらまずいからな。\nまぁ安心してくれ、本当に迷子になっちまっても、俺が絶対見つけてやるから！ ハハハッ！」",200025,1,"deco/character/aiyin_0",302002,60,1,1865,824,400,938,643,2418,3291,938,643,2418,1141,false,false,false,false,false,false,false,false,false,false,false,false,"aiyin_0"}, get);
tb[402503] = P({D[21034], 402503,2,47,150,"「俺普段は森で狩ってばっかだけど、波に乗るのも上手いんだぜ。一緒に海の鼓動を感じてみねぇ？　ハッハー！」",200025,2,"deco/character/aiyin_YZ",false,false,false,false,false,false,false,false,false,false,false,"160,0,0.9315",1977,869,436,621,537,2625,3093,621,586,2625,1261,false,false,false,false,false,false,false,false,false,false,false,false,"aiyin_xr"}, get);
tb[402504] = P({D[21034], 402504,3,24,151,"「へえ？　さすがハロウィン、獲物の方からのこのこ現れるなんてな。道にでも迷ったのか？　可愛い顔しやがって。そうだな……ハンデをやるよ、先に39メートル走っていいぜ。後から追ってやるから。」",200025,2,"deco/character/aiyin_WS",false,false,1,false,false,false,false,false,false,false,false,"170,0,0.94",1796,843,403,241,212,3590,3366,585,544,2902,1261,false,false,false,false,false,false,false,false,false,false,false,false,"aiyin_ws"}, get);
tb[402505] = P({D[17057], 402505,5,30,152,"「うわー、すっげーキレーな雪だな。新年早々縁起がいいぜ。\n今年は初詣に来る人がめちゃくちゃ多いんだってな、もう列がすげーとか何とか。\nいや、俺はそんな人混みに行く気はないけど。だって、今日俺が一番捕まえたい『獲物』は、目の前にいるからな。ハハハ！\n……いや、冗談だって。つか寒ぃだろ？ だったら、もうちょいこっち寄りな。\n一つ秘密を教えてやる。狐の懐ってのは、冬で一番温かい罠なんだ。\n一度目をつけられたら、もう逃げられねぇぞ。」",200025,2,"deco/character/aiyin_yd",false,false,false,false,false,false,false,"","aiyin_yd"}, get);
tb[402601] = P({D[32057], 402601,false,80,153,false,200026,false,"deco/character/chutao",302002,60,false,false,false,false,-38,"1",false,false,false,false,false,false,false,"0,-180,1.04","-70,-50,1","0,-50,1",false,false,false,"-40,-40,1","-30,-40,1","chutao"}, get);
tb[402602] = P({D[13057], 402602,1,4,154,"「はわわー！ どうしよう、お茶会に間に合わなくなっちゃうのです……！\nうさぎさん、助けてほしいのです！」",200026,1,"deco/character/chutao_0",302002,60,false,1,"chutao_0"}, get);
tb[402603] = P({D[13057], 402603,6,26,155,"「雛桃がうさぎさんを好きな理由？　えー？　黄梅が咲いたら春はすぐそこっていうのと同じような感じかな～と思うのです！」",200026,2,"deco/character/chutao_CJ",false,false,false,1,"chutao_cj"}, get);
tb[402604] = P({D[12057], 402604,8,81,156,"「今日も遅刻せずに来てくれたのですね～。お茶会は、もうすぐ始まるのです！　大きなお茶会でお給仕するのは初めてだけど、うさぎさんのために雛桃頑張るのです！　だからうさぎさん、いっぱい楽しんでいってね！」",200026,2,"deco/character/chutao_NP",false,false,1,"chutao_np"}, get);
tb[402605] = P({D[21057], 402605,4,51,157,"「不思議の国も、今は雪なのです……？　ウサギさんと一緒に、見に行きたいのです。」",200026,2,"deco/character/chutao_SD",false,false,false,false,false,false,false,"1",false,false,false,"240,-300,1","chutao_sd"}, get);
tb[402606] = P({D[17045], 402606,2,82,158,"「わぁ……！　雛桃、レモネードの海をおよぐ人魚さんになったのです！\nということは、つぎのお茶会のテーマは、ふしぎの国でのプールあそびなのです？\nこんないいことがおこるのは、うさぎさんといっしょにいるからなのです！」",200026,2,"deco/character/chutao_xr",false,false,false,false,false,false,false,"",1,3816,5000,2038,3806,6666,5900,10000,5533,12000,8000,3333,"chutao_xr"}, get);
tb[402701] = P({D[13023], 402701,false,83,159,false,200027,false,"deco/character/yuejianshan",302002,60,1,1,"20,460,0.95","-90,50,1","-50,20,1",false,false,false,"-90,0,1","-40,0,1",false,false,false,1880,836,400,1242,740,1832,3080,1242,740,1832,1056}, get);
tb[402702] = P({D[13034], 402702,1,4,160,"「別に、なんてことはない日だが……今日をおじさんとお前さんの記念日にしない？\n皆には内緒の、二人だけの記念日ってやつだ。どうだ？」",200027,1,"deco/character/yuejianshan_0",302002,60,false,1,1909,960,400,983,458,2545,2209,1255,659,2001,1261}, get);
tb[402703] = P({D[9034], 402703,7,53,161,"「次はお前さんの番だ。ほら、靴脱いで体重計に乗ってくれ。面倒かもしれないけど、毎年の健康診断は大事だぞ。身長と体重は秘密にしてやるから、心配するなって。」",200027,2,"deco/character/yuejianshan_KX",1902,783,382,520,685,2917,3285,528,685,2901,1049}, get);
tb[402704] = P({D[23034], 402704,3,27,162,"「ここまで追い詰められたのは初めてだ……なんたる不覚。しかし、人狼の誇りにかけて誓おう。我が剣が折れ、骨が粉々になるまで、何人たりともここは通さん！」",200027,2,"deco/character/402704",false,false,false,false,false,false,false,false,false,false,false,"0,-220,1","-280,0,1","-260,0,1",2191,938,380,722,76,2821,2675,722,627,2821,1261,1,7214,5000,3937,5859,8000,11500,6000,8000,10000,8000,8000,false,false,0}, get);