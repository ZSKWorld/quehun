-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[402504] = P({D[21034], 402504,3,24,150,"「へえ？　さすがハロウィン、獲物の方からのこのこ現れるなんてな。道にでも迷ったのか？　可愛い顔しやがって。そうだな……ハンデをやるよ、先に39メートル走っていいぜ。後から追ってやるから。」",200025,2,"deco/character/aiyin_WS",false,false,1,false,false,false,false,false,false,false,false,"170,0,0.94",1796,843,403,241,212,3590,3366,585,544,2902,false,false,false,false,false,false,false,false,false,false,false,false,false,"aiyin_ws"}, get);
tb[402505] = P({D[17044], 402505,5,30,151,"「うわー、すっげーキレーな雪だな。新年早々縁起がいいぜ。\n今年は初詣に来る人がめちゃくちゃ多いんだってな、もう列がすげーとか何とか。\nいや、俺はそんな人混みに行く気はないけど。だって、今日俺が一番捕まえたい『獲物』は、目の前にいるからな。ハハハ！\n……いや、冗談だって。つか寒ぃだろ？ だったら、もうちょいこっち寄りな。\n一つ秘密を教えてやる。狐の懐ってのは、冬で一番温かい罠なんだ。\n一度目をつけられたら、もう逃げられねぇぞ。」",200025,2,"deco/character/aiyin_yd",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"aiyin_yd"}, get);
tb[402601] = P({D[32044], 402601,false,79,152,false,200026,false,"deco/character/chutao",302002,60,false,false,false,false,-38,"1",false,false,false,false,false,false,false,"0,-180,1.04","-70,-50,1","0,-50,1",false,false,false,"-40,-40,1","-30,-40,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"chutao"}, get);
tb[402602] = P({D[13044], 402602,1,4,153,"「はわわー！ どうしよう、お茶会に間に合わなくなっちゃうのです……！\nうさぎさん、助けてほしいのです！」",200026,1,"deco/character/chutao_0",302002,60,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"chutao_0"}, get);
tb[402603] = P({D[13044], 402603,6,26,154,"「雛桃がうさぎさんを好きな理由？　えー？　黄梅が咲いたら春はすぐそこっていうのと同じような感じかな～と思うのです！」",200026,2,"deco/character/chutao_CJ",false,false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"chutao_cj"}, get);
tb[402604] = P({D[12044], 402604,8,80,155,"「今日も遅刻せずに来てくれたのですね～。お茶会は、もうすぐ始まるのです！　大きなお茶会でお給仕するのは初めてだけど、うさぎさんのために雛桃頑張るのです！　だからうさぎさん、いっぱい楽しんでいってね！」",200026,2,"deco/character/chutao_NP",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"chutao_np"}, get);
tb[402605] = P({D[21044], 402605,4,51,156,"「不思議の国も、今は雪なのです……？　ウサギさんと一緒に、見に行きたいのです。」",200026,2,"deco/character/chutao_SD",false,false,false,false,false,false,false,"1",false,false,false,"240,-300,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"chutao_sd"}, get);
tb[402606] = P({D[17044], 402606,2,81,157,"「わぁ……！　雛桃、レモネードの海をおよぐ人魚さんになったのです！\nということは、つぎのお茶会のテーマは、ふしぎの国でのプールあそびなのです？\nこんないいことがおこるのは、うさぎさんといっしょにいるからなのです！」",200026,2,"deco/character/chutao_xr",false,false,false,false,false,false,false,"",0,1,3816,5000,2038,3806,6666,5900,10000,5533,12000,8000,3333,"chutao_xr"}, get);
tb[402701] = P({D[13023], 402701,false,82,158,false,200027,false,"deco/character/yuejianshan",302002,60,1,1,"20,460,0.95","-90,50,1","-50,20,1",false,false,false,"-90,0,1","-40,0,1",false,false,false,1880,836,400,1242,740,1832,3080,1242,740,1832,1056}, get);
tb[402702] = P({D[13034], 402702,1,4,159,"「別に、なんてことはない日だが……今日をおじさんとお前さんの記念日にしない？\n皆には内緒の、二人だけの記念日ってやつだ。どうだ？」",200027,1,"deco/character/yuejianshan_0",302002,60,false,1,1909,960,400,983,458,2545,2209,1255,659,2001}, get);
tb[402703] = P({D[9034], 402703,7,53,160,"「次はお前さんの番だ。ほら、靴脱いで体重計に乗ってくれ。面倒かもしれないけど、毎年の健康診断は大事だぞ。身長と体重は秘密にしてやるから、心配するなって。」",200027,2,"deco/character/yuejianshan_KX",1902,783,382,520,685,2917,3285,528,685,2901,1049}, get);
tb[402704] = P({D[23034], 402704,3,27,161,"「ここまで追い詰められたのは初めてだ……なんたる不覚。しかし、人狼の誇りにかけて誓おう。我が剣が折れ、骨が粉々になるまで、何人たりともここは通さん！」",200027,2,"deco/character/402704",false,false,false,false,false,false,false,false,false,false,false,"0,-220,1","-280,0,1","-260,0,1",2191,938,380,722,76,2821,2675,722,627,2821,false,1,7214,5000,3937,5859,8000,11500,6000,8000,10000,8000,8000}, get);
tb[402705] = P({D[21034], 402705,13,28,162,"「肉体の休息は精神の休息。麻雀で負けて落ち込んでる時こそ、こういう癒しを心と体で実感できるってもんだ。もちろん、こうしてお前さんと遠出してること自体が一番嬉しいんだけどな。いや〜、癒されるな〜！　はははっ！」",200027,2,"deco/character/yuejianshan_WQ",false,false,false,false,false,false,false,"1",false,false,false,"150,-220,1",1918,868,399,752,175,2818,2789,752,567,2818}, get);
tb[402801] = P({D[32044], 402801,false,83,163,false,200028,false,"deco/character/tengbenqiluo",302002,60,1,false,false,false,65,false,false,false,false,false,false,false,false,false,"-100,0,1",false,false,false,false,"-60,0,1","-90,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo"}, get);
tb[402802] = P({D[11044], 402802,1,4,164,"「こっちみて〜！ はいチーズっ！\n……ヤバっ、初デートの記念写真、超盛れてんじゃん！」",200028,1,"deco/character/tengbenqiluo_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo_0"}, get);