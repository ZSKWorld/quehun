-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[402803] = P({D[18044], 402803,5,41,165,"「ジャジャーン！　ピッチピチの新春ギャル登場～！　ギャルにかかれば、伝統的なヤツだって全然イマドキでいけるし！」",200028,2,"deco/character/tengbenqiluo_YD",false,false,false,1,false,false,false,false,"2020-12-30 05:00:00+08",0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo_yd"}, get);
tb[402804] = P({D[23044], 402804,9,84,166,"「一局どぉ？　はぁ？　確かに30分前に寝るっつったけど、おやすみ～って言ってからの夜更かしはキホンっしょ？　だからさぁ、麻雀しよーよ、ね？」",200028,2,"deco/character/tengbenqiluo_SY",false,false,1,false,false,false,false,"1",false,false,false,"0,-140,1","-362,0,1","-370,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo_sy"}, get);
tb[402805] = P({D[24044], 402805,13,28,167,"「なにそんなとこで突っ立ってんの？　疲れてる時の温泉より惹かれるものがあるとか？　へへっ、一日ずっと付き合ってもらったんだし、これくらいのご褒美はちゃんと用意したげるって。」",200028,2,"deco/character/tengbenqiluo_WQ",false,false,false,false,false,false,false,"1",false,false,"-150,0,1","200,-350,1","-100,0,1","-100,0,1","-140,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo_wq"}, get);
tb[402806] = P({D[17044], 402806,18,9,168,"「もーマジおっそーい！\nモタモタしてるうちに、メイク直しまで済んじゃったんだけど！ 遅れた分のデートの時間、今から取り返すよ！\nんじゃ飛ばすから、しっかり腰んとこつかまってて！ わかった！？」",200028,2,"deco/character/tengbenqiluo_kxj",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"tengbenqiluo_kxj"}, get);
tb[402901] = P({D[45057], 402901,false,85,169,false,200029,false,"deco/character/huiyeji",302002,60,1,false,false,false,81,"1",false,false,false,false,false,false,false,"0,-60,1.05","-60,120,1.02","-50,100,1",false,false,false,"-100,100,1.02","-40,100,1",false,false,false,1925,986,400,1069,504,2161,2590,1069,685,2161,"huiyeji"}, get);
tb[402902] = P({D[12034], 402902,1,4,170,"「わらわに奉仕したいと言う者は、この世にいくらでもおる。\nしかし、やはり汝こそ、わらわが最も好む凡人じゃな。\n今日からは、わらわの世界征服軍の総大将になってもらうのじゃ〜！」",200029,1,"deco/character/huiyeji_0",302002,60,1,1910,959,400,702,464,3134,2869,818,658,2902,false,false,false,false,false,false,false,false,false,false,false,false,false,"huiyeji_0"}, get);
tb[402903] = P({D[12034], 402903,4,76,171,"「凡人の体力はそれっぽっちか？　早う付いて参れ！　ぐひひ……！　今宵この神様が、クリスマスプレゼントを心待ちにしておる人間どもに、しかと『サプライズ』を届けてやるのじゃ～！」",200029,2,"deco/character/huiyeji_SD",false,false,1,1652,1053,385,702,261,2692,2864,702,745,2692,false,false,false,false,false,false,false,false,false,false,false,false,false,"huiyeji_sd"}, get);
tb[402904] = P({D[21034], 402904,6,86,172,"「金屋貯嬌という熟語の成り立ちを聞いたことはあるか？　汝が願うなら、宝石で造った宮殿に妾を囲って独り占めすること程度、叶えてやっても……ぐひひ、妾はあえて許そうぞ」",200029,2,"deco/character/huiyeji_CJ",false,false,1,false,false,false,false,false,false,false,false,"480,-300,1",1960,939,361,459,false,2570,3273,459,619,2570,false,1,6858,5000,3990,7032,4000,4666,8333,4333,8000,false,4000,"huiyeji_cj"}, get);
tb[402905] = P({D[12034], 402905,13,87,173,"「無礼者、わらわの貸切温泉に勝手に入るでない！　……何じゃ、当然ここら一帯の温泉は全部わらわの貸切りじゃ！　ほれ、あっちの小さい池なら入ってよいぞ。そうじゃ、一番小さいやつじゃ。さっさと行かんか！」",200029,2,"deco/character/huiyeji_WQ",false,false,1,2053,892,388,498,193,2879,3449,498,585,2879,false,false,false,false,false,false,false,false,false,false,false,false,false,"huiyeji_wq"}, get);
tb[402906] = P({D[12044], 402906,12,88,174,"「ドレスコードじゃと！？わらわは神様じゃぞ、俗世のルールに縛られる謂れなどないわ！ぐひひ、そうじゃ、今夜は一晩中、わらわの傍におれ。礼儀が大切と言うのなら、神様にも謹んで仕えるべきじゃからのう！」",200029,2,"deco/character/huiyeji_LF",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"huiyeji_lf"}, get);
tb[402907] = P({D[12044], 402907,20,89,175,"「こっち、こっちじゃ！\nぼけ～っとしおって。わらわ直々に写真に納めてやったわ。\nせっかくのデートじゃというに、凡人ごときが神様であるこのわらわを待たせるなど……罰が当たっても知らぬぞ。\nまぁ、汝が誠心誠意わらわの身を揉み解し、その後わらわの美しい姿を撮ると言うなら、許してやっても構わぬがのう……ぐひひ。」",200029,2,"deco/character/huiyeji_yh",false,false,1,0,1,3627,5000,1933,3561,8000,9666,8633,8333,13000,8000,8000,"huiyeji_yh"}, get);
tb[403001] = P({D[16023], 403001,false,90,176,false,200030,false,"deco/character/ruyuelian",302002,60,false,false,false,false,-138,"0,350,0.94","-100,-20,1","-50,-20,1",false,false,false,"-120,0,1","-80,0,1",false,false,false,1916,801,400,1640,715,998,2997,1640,715,998,1046}, get);
tb[403002] = P({D[12034], 403002,1,4,177,"「なんです。いつから人の着替えを覗く趣味を持つようになったんですか。\nそこまでして『問題児リスト』に載りたいんですか？」",200030,1,"deco/character/ruyuelian_0",302002,60,1,1891,805,400,778,733,2354,3040,778,733,2354,1032}, get);