-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[403003] = P({D[21034], 403003,3,17,178,"「ここは立ち入り禁止にしていたはずですよ。今引き返せば見なかったことにしましょう。それとも……私に捕まえられたいのですか？」",200030,2,"deco/character/ruyuelian_WS",false,false,false,false,false,false,false,"1",false,false,false,"0,140,0.88",1793,813,412,469,663,3389,3468,713,663,2901,1116}, get);
tb[403004] = P({D[24034], 403004,5,91,179,"「今回滞在する旅館は、そば打ちの名人なんです。近くには商店街もあって、珍しい食べ物もたくさんあるとか。……い、いえ、せっかく旅行に行くんですから事前にきっちり調べておこうと思っただけで、決して食べたいわけでは……。」",200030,2,"deco/character/ruyuelian_YD",false,false,1,false,1,false,false,"1",false,false,"-50,0,1","170,40,0.9","-100,0,1","-100,0,1","-120,0,1",2012,887,390,168,118,3409,3424,422,581,2901,false,1,4813,5000,4097,5319,6666,6333,7000,8333,14000,8000,6666}, get);
tb[403101] = P({D[46057], 403101,false,92,180,false,200031,false,"deco/character/shiyuanduihai",302002,60,false,false,false,false,-215,"1",false,false,false,false,false,false,false,"0,380,0.94","-100,-20,1","-50,0,1",false,false,false,"-110,0,1","-40,0,1",false,false,false,1908,798,400,1274,649,1438,3140,1274,649,1438,1109,"shiyuanduihai"}, get);
tb[403102] = P({D[12034], 403102,1,4,181,"「君ももう部員なんだから、試食専門って訳にはいかないよ！\nさっさと手伝わないと、今週はおやつ抜きにしちゃおっかな～？」",200031,1,"deco/character/shiyuanduihai_0",302002,60,1,1884,854,400,1564,768,1253,2864,1564,768,1253,1046,false,false,false,false,false,false,false,false,false,false,false,false,"shiyuanduihai_0"}, get);
tb[403103] = P({D[12034], 403103,4,93,182,"「クリスマスの定番と言えば、雪降る夜にサンタクロースを待つ、って感じ？　でも俺は君と一緒に、エテルニテのフォレノワールを食べに行きたいけど……なんでって、クリスマスは親しい人と幸せを分け合うものだろ？」",200031,2,"deco/character/shiyuanduihai_SD",false,false,1,1832,801,400,1010,448,2263,3444,1010,500,2263,false,false,false,false,false,false,false,false,false,false,false,false,false,"shiyuanduihai_sd"}, get);
tb[403104] = P({D[21034], 403104,2,18,183,"「ひゃっほーう！　やっぱ夏といったら海とかき氷！　もちろん君と一緒にいることもマストだね。それより知ってた？　バニラアイスにチョコソースをかけてクッキークランチをトッピングすれば、いつもの2倍美味しいよ！」",200031,2,"deco/character/shiyuanduihai_YZ",false,false,false,false,false,false,false,"1",false,false,false,"0,-140,1",1932,866,396,760,561,2895,2354,760,563,2895,false,false,false,false,false,false,false,false,false,false,false,false,false,"shiyuanduihai_xr"}, get);
tb[403105] = P({D[9044], 403105,22,94,184,"「いかなる時でも、心がスイーツを求める限り、おとぎの国のお茶会は、いつでも君をお招きするよ。\nあらゆる悩みと疲れを消し去る、特製魔法スイーツをお望みなら、俺の名前を呼んで。」",200031,2,"deco/character/shiyuanduihai_hxsw",0,false,false,false,false,false,false,false,false,false,false,false,false,"shiyuanduihai_hxsw"}, get);
tb[403201] = P({D[46057], 403201,false,95,185,false,200032,false,"deco/character/ailisha",302002,60,false,false,false,false,118,"0.949999988079071",false,false,false,false,false,false,false,"60,190,0.97","0,100,0.95","0,70,0.95","0,0,0.95","0,0,0.95","0,0,0.95","0,80,0.95","0,80,0.95","0,0,0.95",false,false,1888,968,422,1173,840,1735,2664,1173,840,1735,1099,"ailisha"}, get);
tb[403202] = P({D[11034], 403202,1,4,186,"「オオカミさん、見て見て！\n今年は大豊作だったから、おばあちゃんがたくさん送ってきてくれたんだ。\nオオカミさんにもどうぞって！ えへへっ。」",200032,1,"deco/character/ailisha_0",302002,60,1829,941,410,438,442,3181,3346,578,645,2901,false,false,false,false,false,false,false,false,false,false,false,false,false,"ailisha_0"}, get);
tb[403203] = P({D[21034], 403203,9,69,187,"「リサリサが羊を数えてあげるね。羊が1匹……2匹……さん……ふぁ～」",200032,2,"deco/character/ailisha_SY",false,false,1,false,false,false,false,"1",false,false,false,"80,-130,1",1807,1006,382,808,468,2243,2378,808,696,2243,false,false,false,false,false,false,false,false,false,false,false,false,false,"ailisha_sy"}, get);
tb[403204] = P({D[9020], 403204,6,86,188,"「オオカミさーん！　魚の丸揚げの甘酢あんかけを手土産に持ってきたよ！　オオカミさんのお腹が空いたら、リサリサとぽややんを食べないでお魚さんを食べてね！」",200032,2,"deco/character/ailisha_CJ","-85,0,1","-110,0,1",false,false,false,false,false,false,false,false,false,false,false,false,1852,876,361,1086,671,2090,2770,1086,671,2090,1146,1,5330,7065,2650,4950,6667,6667,6667,6667,6667,false,6667,"ailisha_cj"}, get);
tb[403205] = P({D[21034], 403205,3,24,189,"「ガ、ガオー！　リサリサ、大勝利～……って、あわわわ！　オオカミさん避けてー！　むむ、このチェーンソーやっぱり重いよ～。……そうだ、明日からリサリサもオオカミさんと一緒にトレーニングしよっかな！　えへへ。」",200032,2,"deco/character/ailisha_WS",false,false,1,false,false,false,false,false,false,false,false,"100,-220,1",1965,870,384,802,322,2546,2790,802,561,2546,false,false,false,false,false,false,false,false,false,false,false,false,false,"ailisha_ws"}, get);
tb[403206] = P({D[23034], 403206,16,43,190,"「うわあ～！　サーキットって、いいね！　牧場みたいな雰囲気だー！　どんな雰囲気かって？　むむむ……なんかこう、風をうけて、前へ自由に進める感じ、かなぁ？　えへへ。オオカミさん、リサリサともう一周走ろ？」",200032,2,"deco/character/ailisha_SC",false,false,1,false,false,false,false,"1",false,false,false,"240,-130,1",false,"-200,0,1",1730,918,384,1230,668,2154,2283,1230,668,2154,1202,1,3786,5000,1397,2411,8000,13333,13833,14400,12000,8000,8000,"ailisha_sc"}, get);