-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[403207] = P({D[17044], 403207,4,96,191,"「わ～っ、今日の雪、ふわふわ。踏んでみると、まるで刈った羊さんの毛の山みたい！\nオオカミさん、一緒に雪だるま作ろ？ リサリサは、かわいい雪の羊さんを作るね！\nオオカミさんは、かっこよくて、いつもリサリサを守ってくれる、優しいオオカミさんを作って！ ぽややんは、指導役をお願い！\nリサリサと、オオカミさん、それにぽややんで、今日は世界でいっちばん幸せなクリスマス牧場を作っちゃおう！」",200032,2,"deco/character/ailisha_sd",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"ailisha_sd"}, get);
tb[403301] = P({D[17044], 403301,false,97,192,false,200033,false,"deco/character/siqiqiansuili",302002,60,false,false,false,false,124,"0.949999988079071",0,false,false,false,false,false,false,false,false,false,false,false,false,"siqiqiansuili"}, get);
tb[403302] = P({D[12044], 403302,1,4,193,"「君の影響で、こうしてゆったりとした午後を過ごしているけれど……良いんだか悪いんだか。\nどうやら私も『堕ちた』ようね、ふふっ。」",200033,1,"deco/character/siqiqiansuili_0",302002,60,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"siqiqiansuili_0"}, get);
tb[403303] = P({D[17044], 403303,11,56,194,"「早くしないと置いてくわよ！　……二人きりのお出かけなのに、仕事のことを優先しちゃうなんて、悪いとは思ってるわ。でもね、あれは結構な特ダネなのよ！　終わったらどこにでも付き合うから、今は許して！　ね？」",200033,2,"deco/character/siqiqiansuili_YY",false,false,1,1,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"siqiqiansuili_yy"}, get);
tb[403304] = P({D[17044], 403304,2,14,195,"「さ、こっちに座って。一緒に飲みながら、日光浴を楽しみましょ。そうだ、日焼け止めを塗ってあげるわ。私の塗りの技術、しっかり肌で感じてね。後でじっくりとインタビューさせてもらうから。」",200033,2,"deco/character/siqiqiansuili_YZ",false,false,false,false,false,false,false,"1",0,1,3858,5000,1655,3999,13333,6666,6666,13366,15000,8000,13333,"siqiqiansuili_xr"}, get);
tb[403305] = P({D[17044], 403305,13,45,196,"「噂の真偽に対する探求心は、ジャーナリストの性のようなものね。\nこの『みかんの湯』のうるおい効果がどれほどのものか……ふふっ、一緒に検証しましょうか。」",200033,2,"deco/character/siqiqiansuili_wq",false,false,1,1,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"siqiqiansuili_wq"}, get);
tb[403401] = P({D[17034], 403401,false,98,197,false,200034,false,"deco/character/gongyongxiao",302002,60,false,false,false,false,245,"1",1851,977,429,1599,931,1164,2139,1599,931,1164,1021}, get);
tb[403402] = P({D[12034], 403402,1,4,198,false,200034,1,"deco/character/gongyongxiao_0",302002,60,1,1874,942,454,1380,928,1637,2237,1380,928,1637,1001}, get);
tb[403403] = P({D[9034], 403403,999,99,199,false,200034,3,"deco/character/gongyongxiao_flower",1867,954,419,1324,884,1361,2090,1324,884,1361,1040}, get);
tb[403404] = P({D[9034], 403404,998,100,200,false,200034,3,"deco/character/gongyongxiao_bunny",1886,1011,408,912,399,2108,2628,912,714,2108}, get);
tb[403501] = P({D[17034], 403501,false,101,201,false,200035,false,"deco/character/yuancunhe",302002,60,1,false,false,false,286,"1",1849,1002,436,1592,971,1081,2078,1592,971,1081,1009}, get);
tb[403502] = P({D[11034], 403502,1,4,202,false,200035,1,"deco/character/yuancunhe_0",302002,60,1871,988,433,1355,912,1464,2140,1355,912,1464,1053}, get);
tb[403503] = P({D[9034], 403503,999,99,203,false,200035,3,"deco/character/yuancunhe_flower",1746,1104,432,1246,1023,1764,1823,1246,1023,1764,1057}, get);
tb[403504] = P({D[9034], 403504,998,100,204,false,200035,3,"deco/character/yuancunhe_bunny",1844,932,408,903,551,2234,2353,903,635,2234}, get);
tb[403601] = P({D[16034], 403601,false,102,205,false,200036,false,"deco/character/tianjiangyi",302002,60,false,false,false,false,210,1959,1088,448,1497,760,1216,2019,1497,811,1216}, get);
tb[403602] = P({D[11034], 403602,1,4,206,false,200036,1,"deco/character/tianjiangyi_0",302002,60,1964,1068,448,1285,795,1644,2059,1285,795,1644,1257}, get);
tb[403603] = P({D[9034], 403603,999,99,207,false,200036,3,"deco/character/tianjiangyi_flower",2036,1044,448,975,748,1937,2137,975,767,1937}, get);
tb[403604] = P({D[12034], 403604,998,100,208,false,200036,3,"deco/character/tianjiangyi_bunny",false,false,1,1971,1014,408,324,681,2747,2689,324,717,2747}, get);
tb[403701] = P({D[16034], 403701,false,103,209,false,200037,false,"deco/character/gongyongzhao",302002,60,false,false,false,false,310,1889,945,427,1483,897,1003,2086,1483,897,1003,1022}, get);
tb[403702] = P({D[11034], 403702,1,4,210,false,200037,1,"deco/character/gongyongzhao_0",302002,60,1876,925,455,1446,889,1315,2063,1446,889,1315,1024}, get);
tb[403703] = P({D[9034], 403703,999,99,211,false,200037,3,"deco/character/gongyongzhao_flower",2132,1076,439,727,613,2114,2094,727,795,2114}, get);
tb[403704] = P({D[12034], 403704,998,100,212,false,200037,3,"deco/character/gongyongzhao_bunny",false,false,1,1932,924,408,995,414,1942,2830,995,627,1942}, get);