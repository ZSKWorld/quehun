-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[403801] = P({D[16044], 403801,false,104,213,false,200038,false,"deco/character/fuji",302002,60,1,false,false,false,171,0,false,false,false,false,false,false,false,false,false,false,false,false,"fuji"}, get);
tb[403802] = P({D[11044], 403802,1,4,214,"「あんさん、ここんとこ益々福がついてきたんちゃう？\n毎日ウチに来とるからやろうね。うんうん、ええ子やな。\nこれからも毎日来るように、ええな？ あはは！」",200038,1,"deco/character/fuji_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"fuji_0"}, get);
tb[403803] = P({D[9044], 403803,13,105,215,"「福寿双全館の他にこんなええお湯があるとは……。こんな上等にもてなしてくれるやなんて、あんさんはほんまにええ子やなぁ。ならウチもお返しを用意せんと……せやな、今年の福寿双全館での場代、2割くらいまけたろか？」",200038,2,"deco/character/fuji_WQ",0,false,false,false,false,false,false,false,false,false,false,false,false,"fuji_wq"}, get);
tb[403804] = P({D[9044], 403804,4,106,216,"「なになに？　どうやって空に箱飛ばしとるんかって？　そらもちろん、神様の力や……って、まさか信じた訳やあらへんよね？　中身が空やからに決まっとるやないの。も～、あんさんの分にはちゃんと入っとるから安心しぃ。」",200038,2,"deco/character/fuji_SD",0,false,false,false,false,false,false,false,false,false,false,false,false,"fuji_sd"}, get);
tb[403805] = P({D[17044], 403805,2,18,217,"「あんさんがウチのこと、どうしても～ゆうて一生懸命誘ってくれたんやろ？　なに日差しでバテとんねん！　ほら、はよウチと一緒に水に入ったらどうや？」",200038,2,"deco/character/fuji_YZ",false,false,false,false,false,false,false,"1",0,1,4633,5000,2197,5358,14666,7333,7333,12166,12000,8000,7333,"fuji_xr"}, get);
tb[403806] = P({D[17044], 403806,999,29,218,false,200038,3,"deco/character/fuji_SLO",false,false,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"fuji_slo"}, get);
tb[403807] = P({D[17044], 403807,6,107,219,"「新年おめでとさん！\nちょうど今、金魚を何匹か描いたところや。\n墨の滲み具合も上出来……あとは仕上げの『点睛』を残すのみやで。\n目を描いてあげたら、この子らはただの絵やのうなって、ほんまに泳げるようになる。\nほんで、福を携えて、すいーっと人の心ん中に入っていけるようになるんや。\nウチが新春で一番大事にしとるこの『福の儀』、あんさんと一緒に仕上げたい思て待っとったんやで。」",200038,2,"deco/character/fuji_cj",false,false,1,false,false,false,false,"1",0,1,4117,5000,2140,4150,5333,8433,7333,8133,11967,8133,3000,"fuji_cj"}, get);
tb[403901] = P({D[46057], 403901,false,108,220,false,200039,false,"deco/character/qixi",302002,60,1,false,false,false,171,"1",false,false,false,false,false,false,false,"30,-160,1.1","0,60,1","60,30,1",false,false,false,"0,80,1","40,80,1",false,false,false,1778,989,409,1437,828,1312,1958,1437,828,1312,1126,"qixi"}, get);
tb[403902] = P({D[13034], 403902,1,4,221,"「毎日毎日、ババアのお使いばっかだし、たまにはこうしてサボらねーとな。\nどうだ、オレ様の赤い糸、綺麗だろ？\nふふん、一本だけなら分けてやってもいいぜ？」",200039,1,"deco/character/qixi_0",302002,60,1,1,1767,973,423,1110,493,2229,2504,1110,684,2229,false,false,false,false,false,false,false,false,false,false,false,false,false,"qixi_0"}, get);
tb[403903] = P({D[21034], 403903,2,38,222,"「チェ、見る目ねぇなぁ……。この砂の城、オレ様が何時間かけて作ったと思ってんだ？　そこらのヤツとは違ぇんだよ。んなことより、いたずらで壊されたら困るからちゃんと警戒しねぇとな！　お前も暇なら手伝ってくれ。」",200039,2,"deco/character/qixi_YZ",false,false,false,false,false,false,false,false,false,false,false,"0,-180,1",1827,978,380,878,460,2424,2605,878,667,2424,false,false,false,false,false,false,false,false,false,false,false,false,false,"qixi_xr"}, get);
tb[403904] = P({D[45057], 403904,14,33,223,"「近接戦闘が出来ないから、アーチャーは弱い？　誰がそんなでたらめ言ったんだ。オレ様の弓さばき、近づける敵なんていやしねーぞ！」",200039,2,"deco/character/qixi_YSJ",false,false,false,false,false,false,false,false,false,"0,120,1.01","-110,110,1.01","0,60,1.01","-220,100,1.01","-220,180,1.01",false,false,false,false,false,false,false,false,false,false,false,false,2101,1073,380,674,false,2713,3324,674,762,2713,"qixi_ysj"}, get);
tb[403905] = P({D[17044], 403905,4,96,224,"「勘違いすんなよ、たまたまここで仕事してただけだ！ 誰がお前なんかのこと待つってんだ……\nま、来たからには、勝手にどっか行くんじゃねぇぞ。この後、クリスマスのベルが鳴る頃に、下の広場で花火が上がんだ。\nオレ様には……じゃなくて、オレ様の『人類恋愛攻略ガイド』には、まだ聖夜のパターンが欠けてんだよな～。」",200039,2,"deco/character/qixi_sd",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"qixi_sd"}, get);
tb[404001] = P({D[25034], 404001,false,109,225,false,200040,false,"deco/character/shecan",302002,60,false,false,false,false,-69,"1",false,false,false,false,false,false,false,"160,90,1",1754,858,405,1188,681,1638,2712,1188,681,1638,1140}, get);
tb[404002] = P({D[12034], 404002,1,110,226,false,200040,1,"deco/character/shecan_0",302002,60,1,1965,882,383,1100,729,1817,2508,1100,729,1817,1105}, get);
tb[404003] = P({D[9034], 404003,999,111,227,false,200040,3,"deco/character/shecan_flower",1863,822,400,929,534,2188,3028,929,534,2188,1248}, get);
tb[404101] = P({D[25034], 404101,false,112,228,false,200041,false,"deco/character/zaoyinv",302002,60,false,false,false,false,80,"1",false,false,false,false,false,false,false,"0,-100,1",1919,891,410,1361,742,1512,2374,1361,742,1512,1114}, get);