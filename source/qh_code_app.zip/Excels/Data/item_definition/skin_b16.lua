-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[404102] = P({D[12034], 404102,1,110,229,false,200041,1,"deco/character/zaoyinv_0",302002,60,1,1737,842,412,1099,750,1752,2618,1099,750,1752,1058}, get);
tb[404103] = P({D[12034], 404103,999,111,230,false,200041,3,"deco/character/zaoyinv_flower",false,false,1,1833,892,387,1175,799,1732,2294,1175,799,1732,1047}, get);
tb[404201] = P({D[25034], 404201,false,113,231,false,200042,false,"deco/character/shengzhimo",302002,60,false,false,false,false,-81,"1",false,false,false,false,false,false,false,"80,200,1",1769,809,441,1217,711,1573,2740,1217,711,1573,1079}, get);
tb[404202] = P({D[11034], 404202,1,110,232,false,200042,1,"deco/character/shengzhimo_0",302002,60,1821,850,421,816,743,2293,2302,816,743,2293,1078}, get);
tb[404203] = P({D[12034], 404203,999,111,233,false,200042,3,"deco/character/shengzhimo_flower",false,false,1,1792,812,400,1160,638,1818,2704,1160,638,1818,1134}, get);
tb[404301] = P({D[25034], 404301,false,114,234,false,200043,false,"deco/character/taocan",302002,60,false,false,false,false,-131,"0.949999988079071",false,false,false,false,false,false,false,"20,290,0.94",1803,832,430,1252,681,1581,2974,1252,681,1581,1126}, get);
tb[404302] = P({D[12034], 404302,1,110,235,false,200043,1,"deco/character/taocan_0",302002,60,1,1740,826,400,843,482,2178,2997,843,525,2178}, get);
tb[404303] = P({D[9034], 404303,999,111,236,false,200043,3,"deco/character/taocan_flower",1903,876,395,952,628,1988,2572,952,628,1988,1206}, get);
tb[404401] = P({D[46057], 404401,false,115,237,false,200044,false,"deco/character/404401",302002,60,false,false,false,false,54,"1",false,"180,0,1","180,0,1",false,"180,0,1","180,0,1","180,0,1","180,-320,1.05","170,10,1","220,0,0.98",false,false,false,"180,20,1","200,20,0.98",false,false,false,1642,890,402,1089,751,1750,2010,1089,751,1750,1100,"qihailinai"}, get);
tb[404402] = P({D[11034], 404402,1,4,238,"「次のお散歩は、どこにする？\n雀士さんが歩いた道を、全部歩いてみたいんだぁ。」",200044,1,"deco/character/qihailinai_0",302002,60,1846,899,417,1187,668,1578,2248,1187,668,1578,1200,false,false,false,false,false,false,false,false,false,false,false,false,"qihailinai_0"}, get);
tb[404403] = P({D[9034], 404403,4,93,239,"「今年もサンタさんは忙しいらしいから、雀士さんに贈りそびれたプレゼントは私が代わりに渡してあげるね。はい、あったかいダークチョコモカだよ。お返しは、雀士さんの笑顔がいいなぁ～。」",200044,2,"deco/character/qihailinai_SD",1957,898,400,891,780,2302,2220,891,780,2302,1078,false,false,false,false,false,false,false,false,false,false,false,false,"qihailinai_sd"}, get);
tb[404404] = P({D[21034], 404404,9,77,240,"「ご、ごめんなさい！　いつの間にか寝ちゃってた……。れいなの寝相、変じゃなかったよね？」",200044,2,"deco/character/qihailinai_SY",false,false,false,false,false,false,false,"1",false,false,false,"0,-140,1",1911,912,380,1214,683,1945,2113,1214,683,1945,1179,false,false,false,false,false,false,false,false,false,false,false,false,"qihailinai_sy"}, get);
tb[404405] = P({D[45057], 404405,5,116,241,"「願いごとを書いた紙を折り鶴にすると叶うって聞いて、折り紙を用意したんだ。雀士さんは、どんな願いごとをするの？　れいなの願いごとは……今年は、雀士さんと一緒に外の世界をもっと見られますように、かな。」",200044,2,"deco/character/qihailinai_YD",false,false,1,false,false,false,false,"1",false,false,"-50,0,1","240,-440,1.05","-50,0,1","-50,0,1",false,false,false,false,false,false,false,false,false,false,false,false,1907,986,399,838,244,2546,2424,838,685,2546,"qihailinai_yd"}, get);
tb[404406] = P({D[9044], 404406,22,94,242,"「んむむぅ……もう朝？\nわ～……！ お花の海に、虹……外の世界って、夢で見るよりずっと綺麗！\n起こしてくれてありがとう。これからも、ずっと手を繋いでいてくれる？\nそばにいてくれたら、もっと高く、もっと遠くまで飛べる気がするから！」",200044,2,"deco/character/404406",0,1,false,false,false,false,false,false,false,false,false,false,false,"qihailinai_hxsw"}, get);
tb[404501] = P({D[17023], 404501,false,117,243,false,200045,false,"deco/character/a37",302002,60,false,false,false,false,-212,"1","0,620,0.92","0,20,1","30,20,1",false,false,false,"-50,0,1",false,false,false,false,1822,816,388,1368,686,1336,3364,1368,686,1336,1088}, get);
tb[404502] = P({D[24034], 404502,1,4,244,"「心配するな、どこにいても絶対に見つける」",200045,1,"deco/character/a37_0",302002,60,1,false,false,false,false,"1",false,"0,-60,1","0,-60,1",false,"0,-60,1","0,-60,1","0,-60,1",1909,748,400,686,534,2737,3666,686,534,2737,1174}, get);
tb[404503] = P({D[23034], 404503,11,64,245,"「花火……？　知らん。雇い主の動向から目を離すなんてこと、少なくとも俺はしない。強いて言うなら、花火より君の方がずっと綺麗だ。」",200045,2,"deco/character/404503",false,false,false,1,false,false,false,false,false,false,false,false,"-180,0,1","-200,0,1",1904,789,436,621,485,2930,3582,635,506,2902,false,1,5346,6536,2757,2600,8000,8000,8000,8000,8000,false,8000}, get);
tb[404504] = P({D[21034], 404504,8,80,246,"「差し入れは口実で、本当は猫目当てに来たんだろう。手触りの良い小動物に夢中になるのは人間の性というもの。だが、小動物を見るような目で俺を見るのはやめろ。俺は猫ではないし猫缶で買収されるわけもない。」",200045,2,"deco/character/a37_NP",false,false,1,false,false,false,false,"1",false,false,false,"100,-200,1",1828,801,432,1003,211,2128,2600,1003,516,2128}, get);