-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[404802] = P({D[12034], 404802,1,4,259,"「こ、これが、君が好きな、お日さまの日差しなの？\nもっと日差しを浴びたら、私も君みたいに、お友達がたくさん出来るかな……。\n頑張ってみるから、明日も、一緒にひなたぼっこしたいの。」",200048,1,"deco/character/senchuanlingzi_0",302002,60,1,1839,913,399,766,644,2468,2556,766,644,2468,1229,false,false,false,false,false,false,false,false,false,false,false,false,"senchuanlingzi_0"}, get);
tb[404803] = P({D[21034], 404803,9,85,260,"「こ、これは……いい夢を見せるための魔法陣なの。お泊りに来てもらった友達は君が初めてだから、その…いい夢を見てもらいたいな……って……」",200048,2,"deco/character/404803",false,false,false,false,false,false,false,"1",false,false,false,"0,-140,1",1953,950,380,1005,562,2128,1997,1005,639,2128,1261,1,3475,5000,1801,3207,8000,13333,6333,3166,10000,false,8000,"senchuanlingzi_sy",false,0}, get);
tb[404804] = P({D[12034], 404804,12,48,261,"「私と一緒に踊りたい、の……？　嬉しいけど、踊るってことは、両手が君の体に触れることになっちゃうの。君に不幸が移るのが怖いの……。君はずっと、この世で一番幸運な人でいて欲しいの。」",200048,2,"deco/character/senchuanlingzi_LF",false,false,1,1924,873,388,836,688,2472,2707,836,688,2472,1139,false,false,false,false,false,false,false,false,false,false,false,false,"senchuanlingzi_lf"}, get);
tb[404805] = P({D[24034], 404805,3,54,262,"「あの、私の役は『幽霊の花嫁』で……。それで、もし良かったら、台詞の練習に付き合って欲しいの。　じ、じゃあ、始めるの……『ヒ、ヒッヒッヒ、ここまで来たからには、私の魂の、は、半身として残ってもらいます！』」",200048,2,"deco/character/senchuanlingzi_WS",false,false,false,false,false,false,false,"1",false,false,"-150,0,1","240,-140,1","-150,0,1","-280,0,1","-150,0,1",2081,842,393,596,473,2868,2869,596,538,2868,1261,1,5437,5000,3086,2651,8000,15666,14166,12666,15000,8000,8000,"senchuanlingzi_ws"}, get);
tb[404806] = P({D[17045], 404806,4,97,263,"「雪、なの……。\nごめんなさい……こんな日に呼び出して。髪に雪が積もってるし、手もきっと、冷たくなってるの。\nじ、実は今日、花子が、「鹿の角をつけて、大切な人と会えば、その人は鹿の角を持つ精霊の加護を受けられる」って言ったの……\nそ、それで……私、わがままなの……？」",200048,2,"deco/character/senchuanlingzi_sd",false,false,false,false,false,false,false,"",1,1959,5000,986,2117,5333,10233,12699,8366,10000,8000,5333,"senchuanlingzi_sd"}, get);
tb[404901] = P({D[33057], 404901,false,123,264,false,200049,false,"deco/character/longchuanxiayan",302002,60,false,false,false,false,-85,"0.949999988079071",false,false,false,false,false,false,false,"0,470,0.94","-60,30,0.95","0,30,0.95","0,0,0.95","0,0,0.95","0,0,0.95","-70,30,0.95","0,30,0.95","0,0,0.95","longchuanxiayan"}, get);
tb[404902] = P({D[11057], 404902,1,4,265,"「そういやさ、さっきの試合、あれだけの歓声の中で、お前の声だけはすっごくハッキリ聞こえたんだ。\nだから、絶対このシュートを決めてやる！ って思ったんだよな、ハハッ。」",200049,1,"deco/character/longchuanxiayan_0",302002,60,"longchuanxiayan_0"}, get);
tb[404903] = P({D[12057], 404903,13,88,266,"「湯口の近くはやっぱり水温が高いなあ、いきなりこっちの方に入るのはちょっと無茶かも、ははっ！　浅いところで体を慣らしてから、こっちに来ればいいって。……ふう～。試合後の温泉ってサイッコー！」",200049,2,"deco/character/longchuanxiayan_WQ",false,false,1,"longchuanxiayan_wq"}, get);
tb[404904] = P({D[24057], 404904,6,70,267,"「謎解き提灯……？　いや、遠慮しとくわ。俺こういうやつマジで苦手なんだよ。でも賞品が欲しいってことなら、なぞなぞを選ばなくてもいいんじゃないか？　獅子舞ならぬ龍舞大会なら任しとけ、体力なら絶対負けないからな！」",200049,2,"deco/character/longchuanxiayan_CJ",false,false,false,false,false,false,false,"1",false,"-20,920,1","-20,920,1","120,920,0.91","-20,920,1","-20,920,1","-100,920,1","longchuanxiayan_cj"}, get);
tb[404905] = P({D[9057], 404905,20,90,268,"「ひゅーっ！\nおっ、お前か！ 俺、スケートボードできるようになったんだ！\n案外簡単だし、お前もやってみないか？\n今日は一日暇だし、スケボーじゃなくても、何でも付き合うぜ。」",200049,2,"deco/character/longchuanxiayan_yh","longchuanxiayan_yh"}, get);
tb[405001] = P({D[46057], 405001,false,124,269,false,200050,false,"deco/character/akagi",302002,60,false,false,false,false,-85,"1",false,false,false,false,false,false,false,"40,310,1",false,false,false,false,false,false,false,false,false,false,1887,827,417,1436,721,1122,2880,1436,721,1122,1075,"chimumao"}, get);
tb[405002] = P({D[11034], 405002,1,4,270,false,200050,1,"deco/character/akagi_0",302002,60,1892,846,417,1226,626,1522,2636,1226,626,1522,1189,false,false,false,false,false,false,false,false,false,false,false,false,"chimumao_0"}, get);
tb[405003] = P({D[9034], 405003,999,125,271,"天下無双・降龍威光",200050,3,"deco/character/akagi_SP",1959,815,402,416,698,3326,3100,628,698,2902,1078,false,false,false,false,false,false,false,false,false,false,false,false,"chimumao_1"}, get);
tb[405004] = P({D[9045], 405004,998,126,272,"「その殺意の源は、つまるところ死を恐れる心さ……！」",200050,3,"deco/character/akagi_SP2",1,4400,5000,2356,2063,8000,8000,8000,8000,13000,8000,8000,"chimumao_2"}, get);