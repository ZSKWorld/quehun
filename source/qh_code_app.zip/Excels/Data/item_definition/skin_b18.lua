-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[404805] = P({D[24034], 404805,3,54,260,"「あの、私の役は『幽霊の花嫁』で……。それで、もし良かったら、台詞の練習に付き合って欲しいの。　じ、じゃあ、始めるの……『ヒ、ヒッヒッヒ、ここまで来たからには、私の魂の、は、半身として残ってもらいます！』」",200048,2,"deco/character/senchuanlingzi_WS",false,false,false,false,false,false,false,"1",false,false,"-150,0,1","240,-140,1","-150,0,1","-280,0,1","-150,0,1",2081,842,393,596,473,2868,2869,596,538,2868,false,1,5437,5000,3086,2651,8000,15666,14166,12666,15000,8000,8000,"senchuanlingzi_ws"}, get);
tb[404806] = P({D[17044], 404806,4,96,261,"「雪、なの……。\nごめんなさい……こんな日に呼び出して。髪に雪が積もってるし、手もきっと、冷たくなってるの。\nじ、実は今日、花子が、「鹿の角をつけて、大切な人と会えば、その人は鹿の角を持つ精霊の加護を受けられる」って言ったの……\nそ、それで……私、わがままなの……？」",200048,2,"deco/character/senchuanlingzi_sd",false,false,false,false,false,false,false,"",0,1,1959,5000,986,2117,5333,10233,12699,8366,10000,8000,5333,"senchuanlingzi_sd"}, get);
tb[404901] = P({D[33044], 404901,false,122,262,false,200049,false,"deco/character/longchuanxiayan",302002,60,false,false,false,false,-85,"0.949999988079071",false,false,false,false,false,false,false,"0,470,0.94","-60,30,0.95","0,30,0.95","0,0,0.95","0,0,0.95","0,0,0.95","-70,30,0.95","0,30,0.95","0,0,0.95",0,false,false,false,false,false,false,false,false,false,false,false,false,"longchuanxiayan"}, get);
tb[404902] = P({D[11044], 404902,1,4,263,"「そういやさ、さっきの試合、あれだけの歓声の中で、お前の声だけはすっごくハッキリ聞こえたんだ。\nだから、絶対このシュートを決めてやる！ って思ったんだよな、ハハッ。」",200049,1,"deco/character/longchuanxiayan_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"longchuanxiayan_0"}, get);
tb[404903] = P({D[12044], 404903,13,87,264,"「湯口の近くはやっぱり水温が高いなあ、いきなりこっちの方に入るのはちょっと無茶かも、ははっ！　浅いところで体を慣らしてから、こっちに来ればいいって。……ふう～。試合後の温泉ってサイッコー！」",200049,2,"deco/character/longchuanxiayan_WQ",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"longchuanxiayan_wq"}, get);
tb[404904] = P({D[24044], 404904,6,70,265,"「謎解き提灯……？　いや、遠慮しとくわ。俺こういうやつマジで苦手なんだよ。でも賞品が欲しいってことなら、なぞなぞを選ばなくてもいいんじゃないか？　獅子舞ならぬ龍舞大会なら任しとけ、体力なら絶対負けないからな！」",200049,2,"deco/character/longchuanxiayan_CJ",false,false,false,false,false,false,false,"1",false,"-20,920,1","-20,920,1","120,920,0.91","-20,920,1","-20,920,1","-100,920,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"longchuanxiayan_cj"}, get);
tb[404905] = P({D[9044], 404905,20,89,266,"「ひゅーっ！\nおっ、お前か！ 俺、スケートボードできるようになったんだ！\n案外簡単だし、お前もやってみないか？\n今日は一日暇だし、スケボーじゃなくても、何でも付き合うぜ。」",200049,2,"deco/character/longchuanxiayan_yh",0,false,false,false,false,false,false,false,false,false,false,false,false,"longchuanxiayan_yh"}, get);
tb[405001] = P({D[46057], 405001,false,123,267,false,200050,false,"deco/character/akagi",302002,60,false,false,false,false,-85,"1",false,false,false,false,false,false,false,"40,310,1",false,false,false,false,false,false,false,false,false,false,1887,827,417,1436,721,1122,2880,1436,721,1122,1075,"chimumao"}, get);
tb[405002] = P({D[11034], 405002,1,4,268,false,200050,1,"deco/character/akagi_0",302002,60,1892,846,417,1226,626,1522,2636,1226,626,1522,1189,false,false,false,false,false,false,false,false,false,false,false,false,"chimumao_0"}, get);
tb[405003] = P({D[9034], 405003,999,124,269,"天下無双・降龍威光",200050,3,"deco/character/akagi_SP",1959,815,402,416,698,3326,3100,628,698,2902,1078,false,false,false,false,false,false,false,false,false,false,false,false,"chimumao_1"}, get);
tb[405004] = P({D[9044], 405004,998,125,270,"「その殺意の源は、つまるところ死を恐れる心さ……！」",200050,3,"deco/character/akagi_SP2",0,1,4400,5000,2356,2063,8000,8000,8000,8000,13000,8000,8000,"chimumao_2"}, get);
tb[405101] = P({D[46057], 405101,false,126,271,false,200051,false,"deco/character/washizu",302002,60,1,false,false,false,-29,"1",false,false,false,false,false,false,false,"0,180,1",false,false,false,false,false,false,false,false,false,false,1909,828,397,1421,638,1232,2826,1421,638,1232,1149,"jiuchaoyan"}, get);
tb[405102] = P({D[14034], 405102,1,4,272,false,200051,1,"deco/character/washizu_0",302002,60,false,1,1,1935,834,412,1109,777,1996,2818,1109,777,1996,1023,false,false,false,false,false,false,false,false,false,false,false,false,"jiuchaoyan_0"}, get);
tb[405103] = P({D[9034], 405103,999,124,273,"三界臣服・暗黒帝王",200051,3,"deco/character/washizu_SP",1956,844,384,518,false,3016,3721,575,535,2902,false,false,false,false,false,false,false,false,false,false,false,false,false,"jiuchaoyan_1"}, get);
tb[405104] = P({D[9044], 405104,998,125,274,"「さぁ、見せろ……！　貴様の苦悶、戦慄、そして絶望を……！」",200051,3,"deco/character/washizu_SP2",0,1,5206,5000,2907,2983,8000,7166,9666,6666,8333,8000,8000,"jiuchaoyan_2"}, get);
tb[405201] = P({D[27034], 405201,false,127,275,false,200052,false,"deco/character/xiyuansiyiyu",302002,60,false,false,false,false,-110,"1",false,false,false,false,false,false,false,"160,150,1",false,"50,0,1",1838,865,387,1047,708,1810,2700,1047,708,1810,1111}, get);
tb[405202] = P({D[11034], 405202,1,4,276,"「『剣は心なり』と、父上はよくおっしゃっていた。\n剣は大義と理想のためにのみ抜くべき……それと同じように、剣士の心も善良さと正義感を有するべきだ。\n貴殿の心は、まさに拙者の迷いを払い得る光であり、善良と正義そのもの。\n貴殿のためであれば、拙者は決して退かぬ。」",200052,1,"deco/character/405202",302002,60,1962,935,386,32,392,3085,2636,124,627,2901,false,2,4769,4077,2700,4114,8000,8000,8000,8000,6000,8000,8000,false,false,0}, get);