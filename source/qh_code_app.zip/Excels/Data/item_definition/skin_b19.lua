-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[405301] = P({D[32044], 405301,false,128,277,false,200053,false,"deco/character/xiaoyesiqiyu",302002,60,false,false,false,false,-70,"1",false,false,false,false,false,false,false,"160,200,0.98","-50,10,1",false,false,false,false,"-40,0,1","-30,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoyesiqiyu"}, get);
tb[405302] = P({D[12044], 405302,1,4,278,"「真実は幻想、愛は欲望。\n理想を追い求め、心血を注いで築き上げたこの世界へようこそ。\n読み終えたら、ぜひ感想を教えてくださいね。」",200053,1,"deco/character/xiaoyesiqiyu_0",302002,60,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoyesiqiyu_0"}, get);
tb[405303] = P({D[21044], 405303,11,129,279,"「ん？　……ふふっ、こんな知る人ぞ知るような場所であなたに会えるなんて、私達、心が通じ合っているのかもしれませんね。それではご褒美に、このお菓子でもあげましょうか。」",200053,2,"deco/character/xiaoyesiqiyu_YY",false,false,false,false,1,false,false,false,false,false,false,"40,-180,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoyesiqiyu_yy"}, get);
tb[405304] = P({D[17044], 405304,2,81,280,"「波の音を聞いてインスピレーションを得ようと思ったのですが、あなたの視線は無視しにくいですね。\n……まあいいでしょう。夏の夜の風が運んできた物語を、一緒に聞きましょうか。」",200053,2,"deco/character/xiaoyesiqiyu_xr",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoyesiqiyu_xr"}, get);
tb[405401] = P({D[46057], 405401,false,130,281,false,200054,false,"deco/character/xiamier",302002,60,false,false,false,false,-40,"1",false,false,false,false,false,false,false,"70,340,1","-60,10,1","30,10,1",false,false,false,"-40,0,1",false,false,false,false,1863,812,407,1433,752,1213,2849,1433,752,1213,1024,"xiamier"}, get);
tb[405402] = P({D[23034], 405402,1,4,282,"「聴きたい曲はない？ それとも、即興で何か歌おうか。\n君が歩いてくるのを見た瞬間、急にメロディーが降ってきてね。\nきっと、ロマンチックな曲になると思うんだ。」",200054,1,"deco/character/xiamier_0",302002,60,1,false,false,false,false,false,false,false,false,false,"-112,0,1","-97,0,1",1976,870,426,785,812,2329,1964,785,812,2329,1031,false,false,false,false,false,false,false,false,false,false,false,false,"xiamier_0"}, get);
tb[405403] = P({D[21034], 405403,13,105,283,"「ここは貸切風呂のはずなんだけど……いや、僕が勘違いしていたのかもしれない。お騒がせしたお詫びに後で何か奢らせて。この温泉のたこ焼きは種類が豊富なことで有名でね。君好みのたこ焼きもあると思うんだ。」",200054,2,"deco/character/xiamier_WQ",false,false,false,false,false,false,false,false,false,false,false,"0,312,1",1835,885,444,835,169,2614,2525,835,606,2614,false,false,false,false,false,false,false,false,false,false,false,false,false,"xiamier_wq"}, get);
tb[405404] = P({D[45057], 405404,12,131,284,"「はは……今まで何度も盛大な祝祭に参加してきたけど、今日のこのプライベートな場ほど緊張したことはないよ。僕の心の音楽、聴いてくれるかい？」",200054,2,"deco/character/xiamier_LF",false,false,1,false,false,false,false,"1",false,false,"-420,0,1","150,0,0.98","-420,0,1","-420,0,1","-80,0,1",false,false,false,false,false,false,false,false,false,false,false,2284,856,420,516,198,2773,2998,516,565,2773,"xiamier_lf"}, get);
tb[405405] = P({D[17044], 405405,18,65,285,"「ずっと寝返りを打ってるけど、もしかして眠れない？　それなら、星座にまつわる話をしてあげようか。\n……大変？　ぜーんぜん、そんなことないよ。むしろ、君のためなら喜んで話すとも。\nそうだね、まずは君の星座の話からしようか。それは遠い、遠い昔のこと……。」",200054,2,"deco/character/xiamier_xl",false,false,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"xiamier_xl"}, get);
tb[405501] = P({D[25034], 405501,false,132,286,false,200055,false,"deco/character/sigonghuiye",302002,60,false,false,false,false,-135,"1.10000002384186",false,false,false,false,false,false,false,"50,50,1.05",1833,855,385,1540,797,877,2436,1540,797,877,1011}, get);
tb[405502] = P({D[11034], 405502,1,110,287,false,200055,1,"deco/character/sigonghuiye_0",302002,60,1952,882,374,922,173,2319,3128,922,568,2319}, get);
tb[405503] = P({D[23034], 405503,999,133,288,false,200055,3,"deco/character/sigonghuiye_phantom",false,false,false,false,false,false,false,false,false,"0,130,1","0,140,1",false,"0,160,1","0,150,1",1871,1006,361,663,false,2664,3144,663,686,2664}, get);
tb[405601] = P({D[25034], 405601,false,134,289,false,200056,false,"deco/character/baiyinyuxing",302002,60,false,false,false,false,-19,"1.08000004291534",false,false,false,false,false,false,false,"10,200,1.02",1831,840,400,1665,794,952,2646,1665,794,952,1006}, get);
tb[405602] = P({D[11034], 405602,1,110,290,false,200056,1,"deco/character/baiyinyuxing_0",302002,60,1839,863,412,1207,646,1884,2098,1207,646,1884,1183}, get);
tb[405603] = P({D[12034], 405603,999,133,291,false,200056,3,"deco/character/baiyinyuxing_phantom",false,false,1,1834,855,409,799,496,2152,2670,799,559,2152}, get);
tb[405701] = P({D[25034], 405701,false,135,292,false,200057,false,"deco/character/zaobanai",302002,60,1,false,false,false,-12,"1.08000004291534",false,false,false,false,false,false,false,"80,-30,1.04",1786,858,406,1377,808,1377,2331,1377,808,1377,1013}, get);
tb[405702] = P({D[23034], 405702,1,110,293,false,200057,1,"deco/character/zaobanai_0",302002,60,false,false,false,false,false,false,false,false,false,false,"-112,0,1","-97,0,1",2013,920,381,1088,570,1813,2290,1088,610,1813}, get);
tb[405703] = P({D[23034], 405703,999,133,294,false,200057,3,"deco/character/zaobanai_phantom",false,false,1,false,false,false,false,false,false,false,false,false,"-218,0,1","-226,0,1",2202,865,366,966,486,2158,2548,966,547,2158}, get);
tb[405801] = P({D[25034], 405801,false,136,295,false,200058,false,"deco/character/baiyingui",302002,60,false,false,false,false,-62,"1.0900000333786",false,false,false,false,false,false,false,"60,0,1",1844,881,375,1328,821,1185,2414,1328,821,1185,1008}, get);
tb[405802] = P({D[12034], 405802,1,110,296,false,200058,1,"deco/character/baiyingui_0",302002,60,1,1915,870,375,1139,674,1702,2321,1139,674,1702,1144}, get);