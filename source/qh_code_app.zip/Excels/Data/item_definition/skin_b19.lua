-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[405101] = P({D[46057], 405101,false,127,273,false,200051,false,"deco/character/washizu",302002,60,1,false,false,false,-29,"1",false,false,false,false,false,false,false,"0,180,1",false,false,false,false,false,false,false,false,false,false,1909,828,397,1421,638,1232,2826,1421,638,1232,1149,"jiuchaoyan"}, get);
tb[405102] = P({D[14034], 405102,1,4,274,false,200051,1,"deco/character/washizu_0",302002,60,false,1,1,1935,834,412,1109,777,1996,2818,1109,777,1996,1023,false,false,false,false,false,false,false,false,false,false,false,false,"jiuchaoyan_0"}, get);
tb[405103] = P({D[9034], 405103,999,125,275,"三界臣服・暗黒帝王",200051,3,"deco/character/washizu_SP",1956,844,384,518,false,3016,3721,575,535,2902,1261,false,false,false,false,false,false,false,false,false,false,false,false,"jiuchaoyan_1"}, get);
tb[405104] = P({D[9045], 405104,998,126,276,"「さぁ、見せろ……！　貴様の苦悶、戦慄、そして絶望を……！」",200051,3,"deco/character/washizu_SP2",1,5206,5000,2907,2983,8000,7166,9666,6666,8333,8000,8000,"jiuchaoyan_2"}, get);
tb[405201] = P({D[27034], 405201,false,128,277,false,200052,false,"deco/character/xiyuansiyiyu",302002,60,false,false,false,false,-110,"1",false,false,false,false,false,false,false,"160,150,1",false,"50,0,1",1838,865,387,1047,708,1810,2700,1047,708,1810,1111}, get);
tb[405202] = P({D[11034], 405202,1,4,278,"「『剣は心なり』と、父上はよくおっしゃっていた。\n剣は大義と理想のためにのみ抜くべき……それと同じように、剣士の心も善良さと正義感を有するべきだ。\n貴殿の心は、まさに拙者の迷いを払い得る光であり、善良と正義そのもの。\n貴殿のためであれば、拙者は決して退かぬ。」",200052,1,"deco/character/405202",302002,60,1962,935,386,32,392,3085,2636,124,627,2901,1261,2,4769,4077,2700,4114,8000,8000,8000,8000,6000,8000,8000,false,false,0}, get);
tb[405301] = P({D[32057], 405301,false,129,279,false,200053,false,"deco/character/xiaoyesiqiyu",302002,60,false,false,false,false,-70,"1",false,false,false,false,false,false,false,"160,200,0.98","-50,10,1",false,false,false,false,"-40,0,1","-30,0,1","xiaoyesiqiyu"}, get);
tb[405302] = P({D[12057], 405302,1,4,280,"「真実は幻想、愛は欲望。\n理想を追い求め、心血を注いで築き上げたこの世界へようこそ。\n読み終えたら、ぜひ感想を教えてくださいね。」",200053,1,"deco/character/xiaoyesiqiyu_0",302002,60,1,"xiaoyesiqiyu_0"}, get);
tb[405303] = P({D[21057], 405303,11,130,281,"「ん？　……ふふっ、こんな知る人ぞ知るような場所であなたに会えるなんて、私達、心が通じ合っているのかもしれませんね。それではご褒美に、このお菓子でもあげましょうか。」",200053,2,"deco/character/xiaoyesiqiyu_YY",false,false,false,false,1,false,false,false,false,false,false,"40,-180,1","xiaoyesiqiyu_yy"}, get);
tb[405304] = P({D[17057], 405304,2,82,282,"「波の音を聞いてインスピレーションを得ようと思ったのですが、あなたの視線は無視しにくいですね。\n……まあいいでしょう。夏の夜の風が運んできた物語を、一緒に聞きましょうか。」",200053,2,"deco/character/xiaoyesiqiyu_xr",false,false,false,false,false,false,false,"","xiaoyesiqiyu_xr"}, get);
tb[405401] = P({D[46057], 405401,false,131,283,false,200054,false,"deco/character/xiamier",302002,60,false,false,false,false,-40,"1",false,false,false,false,false,false,false,"70,340,1","-60,10,1","30,10,1",false,false,false,"-40,0,1",false,false,false,false,1863,812,407,1433,752,1213,2849,1433,752,1213,1024,"xiamier"}, get);
tb[405402] = P({D[23034], 405402,1,4,284,"「聴きたい曲はない？ それとも、即興で何か歌おうか。\n君が歩いてくるのを見た瞬間、急にメロディーが降ってきてね。\nきっと、ロマンチックな曲になると思うんだ。」",200054,1,"deco/character/xiamier_0",302002,60,1,false,false,false,false,false,false,false,false,false,"-112,0,1","-97,0,1",1976,870,426,785,812,2329,1964,785,812,2329,1031,false,false,false,false,false,false,false,false,false,false,false,false,"xiamier_0"}, get);
tb[405403] = P({D[21034], 405403,13,106,285,"「ここは貸切風呂のはずなんだけど……いや、僕が勘違いしていたのかもしれない。お騒がせしたお詫びに後で何か奢らせて。この温泉のたこ焼きは種類が豊富なことで有名でね。君好みのたこ焼きもあると思うんだ。」",200054,2,"deco/character/xiamier_WQ",false,false,false,false,false,false,false,false,false,false,false,"0,312,1",1835,885,444,835,169,2614,2525,835,606,2614,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiamier_wq"}, get);
tb[405404] = P({D[46057], 405404,12,132,286,"「はは……今まで何度も盛大な祝祭に参加してきたけど、今日のこのプライベートな場ほど緊張したことはないよ。僕の心の音楽、聴いてくれるかい？」",200054,2,"deco/character/xiamier_LF",false,false,1,false,false,false,false,"1",false,false,"-420,0,1","150,0,0.98","-420,0,1","-420,0,1","-80,0,1",false,false,false,false,false,false,false,false,false,false,false,2284,856,420,516,198,2773,2998,516,565,2773,1261,"xiamier_lf"}, get);
tb[405405] = P({D[17057], 405405,18,65,287,"「ずっと寝返りを打ってるけど、もしかして眠れない？　それなら、星座にまつわる話をしてあげようか。\n……大変？　ぜーんぜん、そんなことないよ。むしろ、君のためなら喜んで話すとも。\nそうだね、まずは君の星座の話からしようか。それは遠い、遠い昔のこと……。」",200054,2,"deco/character/xiamier_xl",false,false,false,false,false,false,false,"1","xiamier_xl"}, get);
tb[405501] = P({D[25034], 405501,false,133,288,false,200055,false,"deco/character/sigonghuiye",302002,60,false,false,false,false,-135,"1.10000002384186",false,false,false,false,false,false,false,"50,50,1.05",1833,855,385,1540,797,877,2436,1540,797,877,1011}, get);