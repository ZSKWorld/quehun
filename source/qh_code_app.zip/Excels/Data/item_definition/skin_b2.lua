-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[400305] = P({D[9034], 400305,2,18,18,"「ライブ大成功を祝して、アイスクリームとココナッツウォーターをたっぷり堪能しちゃおーっ☆　その前に一枚パシャリと……。え、ええ？　太るよって？　ちょっとぐらい気を緩めたっていいじゃん……。」",200003,2,"deco/character/tengtianjianai_xr",1902,885,380,624,776,2506,3056,624,776,2506,1059,1,4093,5000,2496,4922,8000,13833,16333,8000,11000,8000,8000,"tengtianjianai_xr"}, get);
tb[400306] = P({D[21034], 400306,6,19,19,"「え～、もう来ちゃったの？　まだメイク終わってないのにー。あっでも、これってつまり、春節で私が一番最初に会った人はファンさんってことになるよね。佳奈ちゃん嬉しい！　あけましておめでとっ！」",200003,2,"deco/character/tengtianjianai_cj",false,false,false,false,false,false,false,"1",false,false,false,"240,-140,0.95",1926,885,400,1113,false,2076,3235,1113,584,2076,1261,1,1905,5000,906,2860,5333,8666,7566,11033,16000,8000,5333,"tengtianjianai_cj"}, get);
tb[400307] = P({D[9057], 400307,21,20,20,"「ライブ前に緊張してた時にはいつも、ファンさんが応援してくれた。\nだから今日は、佳奈ちゃんがファンさんの応援をするよ！\nフレー、フレー！ ゴー！ ゴー！」",200003,2,"deco/character/tengtianjianai_ydh","tengtianjianai_ydh"}, get);
tb[400401] = P({D[17023], 400401,false,21,21,false,200004,false,"deco/character/qianzhi",302002,60,false,false,false,false,-6,"1","0,-40,1","-50,70,1","0,60,1",false,false,false,"-40,90,1","-10,90,1",false,false,false,1853,1001,420,1351,700,1472,2520,1351,710,1472,1261}, get);
tb[400402] = P({D[11034], 400402,1,4,22,"口ではイヤイヤ言いつつも、一つずつぬいぐるみコレクションを手に取る千織は、やっぱりかわいい！",200004,1,"deco/character/qianzhi_0",302002,60,1821,990,410,1172,572,1992,2612,1172,694,1992,1261}, get);
tb[400403] = P({D[9034], 400403,4,16,23,"「毎年クリスマスになると、プレゼントがいっぱいね。そこのあんた、早くプレゼントを開けるのを手伝いなさい！　フン！　これはあんたへのプレゼントじゃないわ、お駄賃よお駄賃！」",200004,2,"deco/character/qianzhi_SDJ",1841,1009,401,1150,704,2015,2049,1150,709,2015,1261}, get);
tb[400404] = P({D[12034], 400404,2,22,24,"「この千織様の可愛さに見合う水着を選ぶなんて、庶民のくせに、センスは悪くないじゃない。まあ……御褒美に写真くらいは撮らせてあげるわ、ふん！」",200004,2,"deco/character/qianzhi_YZ",false,false,1,2080,1076,400,1164,730,1714,1678,1164,775,1714,1261}, get);
tb[400405] = P({D[12034], 400405,8,23,25,"「10分経ってもまだ決まらないなんて、どうせ千織のことジロジロ見てたんでしょ？」",200004,2,"deco/character/qianzhi_NP",false,false,1,1767,929,395,960,559,2010,2657,960,626,2010,1261}, get);
tb[400406] = P({D[21034], 400406,3,24,26,"「ボーっと突っ立ってんじゃないわよ！　さっさと千織の服を直しなさい！　……じ、自分で出来ないなんて、そんなわけないじゃない！　下僕のくせにろくに働かないから、わざわざこの千織様自ら注意してやってるの！」",200004,2,"deco/character/400406",false,false,false,false,false,false,false,false,false,false,false,"100,-180,1",1962,999,412,983,793,1975,1838,983,793,1975,1172,1,2676,2550,1472,2473,8000,12333,8000,8000,12000,false,8000,false,false,0}, get);
tb[400407] = P({D[21034], 400407,6,19,27,"「商売繫盛、千ドラ万来、国士十三面待ち！　どう？　千織様からの新年を祝う言葉よ。　気に入ったわよね？　アンタはこれから、感激の涙を流しながら、千織と麻雀を打つの。今の言葉が現実になるかもしれないわ！」",200004,2,"deco/character/qianzhi_CJ",false,false,false,false,false,false,false,"1",false,false,false,"240,-180,0.95",1854,871,410,877,82,2543,2783,877,575,2543,1261}, get);
tb[400501] = P({D[46057], 400501,false,25,28,false,200005,false,"deco/character/xiangyuanwu",302002,60,false,1,false,false,-7,"0.97",false,false,false,false,false,false,false,"0,190,0.98","0,0,0.97","80,0,0.97","0,0,0.97","0,0,0.97","0,0,0.97","0,0,0.97","0,0,0.97","0,0,0.97",false,false,1830,883,430,1614,798,1044,2701,1614,798,1044,1060,"xiangyuanwu"}, get);
tb[400502] = P({D[13034], 400502,1,4,29,"「旦那様に捧げるお神楽……これからもずっと、ずっと見ていてくださいね」\nそう言って舞う姿は、なんとも幻想的だった。",200005,1,"deco/character/xiangyuanwu_0",302002,60,false,1,1841,988,393,1028,677,2146,2822,1100,684,2002,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiangyuanwu_0"}, get);
tb[400503] = P({D[9034], 400503,2,5,30,false,200005,2,"deco/character/xiangyuanwu_haitanpaidui",1943,873,400,1398,653,1514,2563,1398,653,1514,1180,false,false,false,false,false,false,false,false,false,false,false,false,"xiangyuanwu_xr"}, get);
tb[400504] = P({D[12034], 400504,6,26,31,"「旦那様が時間を作って舞と一緒に過ごしてくださるなんて、舞はとても嬉しいです。なので、今回は特別に、普段したことのない装いに挑戦してみたのですが……旦那様、に、似合うでしょうか？」",200005,2,"deco/character/xiangyuanwu_CJ",false,false,1,1876,852,400,1242,803,1662,2465,1242,803,1662,1009,false,false,false,false,false,false,false,false,false,false,false,false,"xiangyuanwu_cj"}, get);