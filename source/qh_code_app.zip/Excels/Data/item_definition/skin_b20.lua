-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[405502] = P({D[11034], 405502,1,111,289,false,200055,1,"deco/character/sigonghuiye_0",302002,60,1952,882,374,922,173,2319,3128,922,568,2319,1261}, get);
tb[405503] = P({D[23034], 405503,999,134,290,false,200055,3,"deco/character/sigonghuiye_phantom",false,false,false,false,false,false,false,false,false,"0,130,1","0,140,1",false,"0,160,1","0,150,1",1871,1006,361,663,false,2664,3144,663,686,2664,1261}, get);
tb[405601] = P({D[25034], 405601,false,135,291,false,200056,false,"deco/character/baiyinyuxing",302002,60,false,false,false,false,-19,"1.08000004291534",false,false,false,false,false,false,false,"10,200,1.02",1831,840,400,1665,794,952,2646,1665,794,952,1006}, get);
tb[405602] = P({D[11034], 405602,1,111,292,false,200056,1,"deco/character/baiyinyuxing_0",302002,60,1839,863,412,1207,646,1884,2098,1207,646,1884,1183}, get);
tb[405603] = P({D[12034], 405603,999,134,293,false,200056,3,"deco/character/baiyinyuxing_phantom",false,false,1,1834,855,409,799,496,2152,2670,799,559,2152,1261}, get);
tb[405701] = P({D[25034], 405701,false,136,294,false,200057,false,"deco/character/zaobanai",302002,60,1,false,false,false,-12,"1.08000004291534",false,false,false,false,false,false,false,"80,-30,1.04",1786,858,406,1377,808,1377,2331,1377,808,1377,1013}, get);
tb[405702] = P({D[23034], 405702,1,111,295,false,200057,1,"deco/character/zaobanai_0",302002,60,false,false,false,false,false,false,false,false,false,false,"-112,0,1","-97,0,1",2013,920,381,1088,570,1813,2290,1088,610,1813,1261}, get);
tb[405703] = P({D[23034], 405703,999,134,296,false,200057,3,"deco/character/zaobanai_phantom",false,false,1,false,false,false,false,false,false,false,false,false,"-218,0,1","-226,0,1",2202,865,366,966,486,2158,2548,966,547,2158,1261}, get);
tb[405801] = P({D[25034], 405801,false,137,297,false,200058,false,"deco/character/baiyingui",302002,60,false,false,false,false,-62,"1.0900000333786",false,false,false,false,false,false,false,"60,0,1",1844,881,375,1328,821,1185,2414,1328,821,1185,1008}, get);
tb[405802] = P({D[12034], 405802,1,111,298,false,200058,1,"deco/character/baiyingui_0",302002,60,1,1915,870,375,1139,674,1702,2321,1139,674,1702,1144}, get);
tb[405803] = P({D[12034], 405803,999,134,299,false,200058,3,"deco/character/baiyingui_phantom",false,false,1,1833,895,362,1015,397,2246,2236,1015,575,2246,1261}, get);
tb[405901] = P({D[46057], 405901,false,138,300,false,200059,false,"deco/character/you",302002,60,1,false,false,false,-135,false,false,false,false,false,false,false,false,"70,-200,1.02","130,0,1","0,-40,1","130,0,1","0,40,1",false,"0,20,1","0,-20,1","0,20,1","0,-20,1",false,1843,866,393,934,411,2121,2622,934,562,2121,1261,"you"}, get);
tb[405902] = P({D[12034], 405902,1,4,301,"「ここまで来るとは、なかなかやるのだ。魔女の試練を突破したことにしてやるぞ。\n褒美として、この『100日でなれる！ 魔女指南』をやろう。ゆずが書いた本だぞ、何か文句があるか？\nそうか、ないならいい。レッパンズが見守ってやるから、今日からしっかり本の通りに特訓するのだ！」",200059,1,"deco/character/you_0",302002,60,1,1841,898,393,832,209,2455,2634,832,594,2455,1261,false,false,false,false,false,false,false,false,false,false,false,false,"you_0"}, get);
tb[405903] = P({D[23034], 405903,9,78,302,"「しーっ！　レッパンズが起きちゃうのだ！　寝かしつけるのはゆずの役目なんだぞ。大変なんだからな！」",200059,2,"deco/character/you_SY",false,false,1,false,false,false,false,"1",false,false,false,"0,-140,1","-120,0,1","-120,0,1",1976,914,380,1156,643,2053,2043,1156,643,2053,1221,false,false,false,false,false,false,false,false,false,false,false,false,"you_sy"}, get);
tb[405904] = P({D[46057], 405904,5,92,303,"「キュルルルゥー！　こ、こけちゃうぞー！　おまえ、助けてくれー！　……ふぅ。キュルル、まさか新年初日からこんな目に遭うなんてな。でもおまえの強力な正義の力によってゆずとゆずの晩ごはんが助かったのだ。」",200059,2,"deco/character/you_YD",false,false,false,false,1,false,false,"1",false,false,"-140,0,1","80,-180,0.94","-100,0,1","-100,0,1","-120,0,1",false,false,false,false,false,false,false,false,false,false,false,2061,872,391,862,337,2157,2795,862,567,2157,1261,"you_yd"}, get);
tb[405905] = P({D[21034], 405905,2,14,304,"「キュルルゥ、どうだ！　魔法に頼らずとも、水鉄砲合戦はゆずの方が一枚上手だったぞ！　……ち、ちょっと待つのだ！　二回戦の合図はまだ……ルール違反なのだ！　正義を蔑ろにするやつは、裁きを受けるがいいのだー！」",200059,2,"deco/character/you_YZ",false,false,false,false,false,false,false,"1",false,false,false,"240,-250,1",1844,917,391,946,121,2423,2664,946,612,2423,1261,1,3592,5000,1734,3050,8000,8000,5600,4333,13000,6666,2666,"you_yz"}, get);
tb[405906] = P({D[9045], 405906,17,71,305,"キュルルゥ……遅いのだ。ゆずの出番に間に合わなくなるとこだったぞ！\n……別に、おまえの励ましが欲しかったわけじゃないのだ。ほ、ほら、出番の前に会う約束してたし、おまえを約束も守れない奴にするわけにはいかないからな！",200059,2,"deco/character/you_BL",1,3318,5000,1600,3856,2666,7333,9333,6666,14000,6666,2666,"you_bl",false,0}, get);
tb[406001] = P({D[16023], 406001,false,139,306,false,200060,false,"deco/character/zekesi",302002,60,1,false,false,false,-90,"0,420,1","-30,20,1","20,20,1",false,false,false,"-40,0,1",false,false,false,false,1849,838,390,1143,688,2159,2993,1143,688,2159,1105}, get);
tb[406002] = P({D[11034], 406002,1,4,307,"「む、んむむぅ！ ……っ、おい！\n今のは『今くわえてる布を取れ』じゃなくて、『そこの布をよこせ』って意味だ！\nどんだけ長く一緒にいると思ってんだ、目配せの意図くらい読めてもいいだろーが。\n……オイ、なに怒ってんだよ、俺様とつうかあの仲になんのがそんなに嫌か！？」",200060,1,"deco/character/zekesi_0",302002,60,1899,888,389,807,548,2470,2592,807,582,2470,1261}, get);