-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[406004] = P({D[21034], 406004,6,19,309,"「……ほら、手ぇ出せ。なんでって、引っ張ってやるために決まってんだろーが。日の光を照り返す雪と千本松、見てェだろ？　……別に、せっかくのハレの日だしな、テメェとこうして眺めんのも悪かねェ。そう思っただけだ！」",200060,2,"deco/character/zekesi_CJ",false,false,false,false,1,false,false,"1",false,"160,0,1",false,"280,-80,0.95",1901,827,399,437,450,3118,2647,545,526,2902,1261,1,1523,5000,800,985,5333,7166,7266,7333,15000,8000,10666}, get);
tb[406101] = P({D[17023], 406101,false,140,310,false,200061,false,"deco/character/beiyuanlili",302002,60,1,false,false,false,43,"1.02999997138977","-30,70,1.02","0,0,1.03","0,0,1.03","0,0,1.03","0,0,1.03","0,0,1.03","0,0,1.03",false,"0,0,1.03",false,false,1862,859,387,1348,789,1926,2508,1348,789,1926,1024}, get);
tb[406102] = P({D[12034], 406102,1,4,311,"「もっと、こちらに。\n……そう、恐れずに、もっと。そのお顔に触れさせてくださいませ。\nなぜ、背を向けるのです？ いけません、きちんとわたくしの方を向いて。\nよくご覧になれましたか？\nあなた様の愛、そして欲望。……あなた様の、神様を。」",200061,1,"deco/character/beiyuanlili_0",302002,60,1,1847,895,386,137,false,3859,3884,616,587,2901,1261,2,3594,5000,1743,2220,16000,16000,16000,12633,10000,16000,16000}, get);
tb[406201] = P({D[16034], 406201,false,141,312,false,200062,false,"deco/character/zhujingjiu",302002,60,1,false,false,false,165,1824,877,408,1436,808,1483,2415,1436,808,1483,1033}, get);
tb[406202] = P({D[12034], 406202,1,4,313,false,200062,1,"deco/character/zhujingjiu_0",302002,60,1,1819,861,408,1120,608,2205,2869,1120,608,2205,1217}, get);
tb[406203] = P({D[23034], 406203,998,101,314,false,200062,3,"deco/character/zhujingjiu_bunny",false,false,1,false,false,false,false,false,false,false,false,false,"-280,0,1","-294,0,1",2130,945,408,779,274,2405,3253,779,648,2405,1261}, get);
tb[406301] = P({D[25034], 406301,false,142,315,false,200063,false,"deco/character/fulumeisuizi",302002,60,false,1,false,false,95,false,false,false,false,false,false,false,false,"0,-40,1.05",1819,847,408,1532,800,828,2346,1532,800,828,1011}, get);
tb[406302] = P({D[13034], 406302,1,4,316,false,200063,1,"deco/character/fulumeisuizi_0",302002,60,1,1,1889,887,408,903,789,2236,2448,903,789,2236,1062}, get);
tb[406303] = P({D[13034], 406303,998,101,317,false,200063,3,"deco/character/fulumeisuizi_bunny",false,false,false,1,1784,833,408,1039,516,2268,2880,1039,536,2268,1261}, get);
tb[406401] = P({D[25034], 406401,false,143,318,false,200064,false,"deco/character/xinzichong",302002,60,false,false,false,false,110,"1",false,false,false,false,false,false,false,"70,-30,1.08",1868,934,408,1281,878,1134,2230,1281,878,1134,1020}, get);
tb[406402] = P({D[11034], 406402,1,4,319,false,200064,1,"deco/character/xinzichong_0",302002,60,1919,915,408,922,509,2227,2594,922,618,2227,1261}, get);
tb[406403] = P({D[9034], 406403,998,101,320,false,200064,3,"deco/character/xinzichong_bunny",1759,970,408,1018,338,2356,3122,1018,673,2356,1261}, get);
tb[406501] = P({D[25034], 406501,false,144,321,false,200065,false,"deco/character/yuanchengsilian",302002,60,false,false,false,false,255,"1",false,false,false,false,false,false,false,"0,-80,1.1",1824,869,408,1679,837,928,2187,1679,837,928,996}, get);
tb[406502] = P({D[12034], 406502,1,4,322,false,200065,1,"deco/character/yuanchengsilian_0",302002,60,1,1984,858,408,643,824,2514,2681,643,824,2514,998}, get);
tb[406503] = P({D[9034], 406503,998,101,323,false,200065,3,"deco/character/yuanchengsilian_bunny",1869,933,408,930,370,1993,2822,930,636,1993,1261}, get);
tb[406601] = P({D[46057], 406601,false,145,324,false,200066,false,"deco/character/sigongdongshi",302002,60,1,false,false,false,65,"1",false,false,false,false,false,false,false,"30,-110,1.04","-30,0,1",false,false,false,false,"-40,0,1","0,20,1",false,false,false,1868,881,392,1406,770,1045,2323,1406,770,1045,1067,"sigongdongshi"}, get);
tb[406602] = P({D[12034], 406602,1,4,325,"「うぅ……もう笑わないでよ。\n何回もメリーゴーランドに乗ったら、こうなるのも当然でしょ……だって、今日はあなたと一緒に遊園地に来られて、楽しかったもん。\nいつかまた、一緒に来ようね。」",200066,1,"deco/character/sigongdongshi_0",302002,60,1,1894,920,392,1110,415,2047,2798,1110,615,2047,1261,false,false,false,false,false,false,false,false,false,false,false,false,"sigongdongshi_0"}, get);
tb[406603] = P({D[13034], 406603,8,61,326,"「やば、こっそりサボってたのバレちゃったかー。オーナーにチクられたら罰金だし……そーだ、このケーキ半分こしよーよ。えへへ、これであたしたち共犯だよねっ！」",200066,2,"deco/character/sigongdongshi_NP",false,false,1,1,1929,923,388,946,339,2262,2710,946,616,2262,1261,false,false,false,false,false,false,false,false,false,false,false,false,"sigongdongshi_np"}, get);
tb[406604] = P({D[46057], 406604,4,75,327,"「あたしとのデート大作戦、またの名をクリスマス遊園地の旅、まもなく始まりまーす！　えへへ、まずは最初のミッション、あたしの手作りチョコクッキー、美味しそうに食べられるかなのコーナー！　はい、あ～ん♪」",200066,2,"deco/character/sigongdongshi_SD",false,false,false,false,false,false,false,"1",false,false,"-100,0,1","80,-80,1",false,"-100,0,1","-100,0,1",false,false,false,false,false,false,false,false,false,false,false,2110,917,388,936,418,2104,2754,936,610,2104,1261,"sigongdongshi_sd"}, get);