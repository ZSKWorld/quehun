-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[406201] = P({D[16034], 406201,false,140,310,false,200062,false,"deco/character/zhujingjiu",302002,60,1,false,false,false,165,1824,877,408,1436,808,1483,2415,1436,808,1483,1033}, get);
tb[406202] = P({D[12034], 406202,1,4,311,false,200062,1,"deco/character/zhujingjiu_0",302002,60,1,1819,861,408,1120,608,2205,2869,1120,608,2205,1217}, get);
tb[406203] = P({D[23034], 406203,998,100,312,false,200062,3,"deco/character/zhujingjiu_bunny",false,false,1,false,false,false,false,false,false,false,false,false,"-280,0,1","-294,0,1",2130,945,408,779,274,2405,3253,779,648,2405}, get);
tb[406301] = P({D[25034], 406301,false,141,313,false,200063,false,"deco/character/fulumeisuizi",302002,60,false,1,false,false,95,false,false,false,false,false,false,false,false,"0,-40,1.05",1819,847,408,1532,800,828,2346,1532,800,828,1011}, get);
tb[406302] = P({D[13034], 406302,1,4,314,false,200063,1,"deco/character/fulumeisuizi_0",302002,60,1,1,1889,887,408,903,789,2236,2448,903,789,2236,1062}, get);
tb[406303] = P({D[13034], 406303,998,100,315,false,200063,3,"deco/character/fulumeisuizi_bunny",false,false,false,1,1784,833,408,1039,516,2268,2880,1039,536,2268}, get);
tb[406401] = P({D[25034], 406401,false,142,316,false,200064,false,"deco/character/xinzichong",302002,60,false,false,false,false,110,"1",false,false,false,false,false,false,false,"70,-30,1.08",1868,934,408,1281,878,1134,2230,1281,878,1134,1020}, get);
tb[406402] = P({D[11034], 406402,1,4,317,false,200064,1,"deco/character/xinzichong_0",302002,60,1919,915,408,922,509,2227,2594,922,618,2227}, get);
tb[406403] = P({D[9034], 406403,998,100,318,false,200064,3,"deco/character/xinzichong_bunny",1759,970,408,1018,338,2356,3122,1018,673,2356}, get);
tb[406501] = P({D[25034], 406501,false,143,319,false,200065,false,"deco/character/yuanchengsilian",302002,60,false,false,false,false,255,"1",false,false,false,false,false,false,false,"0,-80,1.1",1824,869,408,1679,837,928,2187,1679,837,928,996}, get);
tb[406502] = P({D[12034], 406502,1,4,320,false,200065,1,"deco/character/yuanchengsilian_0",302002,60,1,1984,858,408,643,824,2514,2681,643,824,2514,998}, get);
tb[406503] = P({D[9034], 406503,998,100,321,false,200065,3,"deco/character/yuanchengsilian_bunny",1869,933,408,930,370,1993,2822,930,636,1993}, get);
tb[406601] = P({D[46057], 406601,false,144,322,false,200066,false,"deco/character/sigongdongshi",302002,60,1,false,false,false,65,"1",false,false,false,false,false,false,false,"30,-110,1.04","-30,0,1",false,false,false,false,"-40,0,1","0,20,1",false,false,false,1868,881,392,1406,770,1045,2323,1406,770,1045,1067,"sigongdongshi"}, get);
tb[406602] = P({D[12034], 406602,1,4,323,"「うぅ……もう笑わないでよ。\n何回もメリーゴーランドに乗ったら、こうなるのも当然でしょ……だって、今日はあなたと一緒に遊園地に来られて、楽しかったもん。\nいつかまた、一緒に来ようね。」",200066,1,"deco/character/sigongdongshi_0",302002,60,1,1894,920,392,1110,415,2047,2798,1110,615,2047,false,false,false,false,false,false,false,false,false,false,false,false,false,"sigongdongshi_0"}, get);
tb[406603] = P({D[13034], 406603,8,61,324,"「やば、こっそりサボってたのバレちゃったかー。オーナーにチクられたら罰金だし……そーだ、このケーキ半分こしよーよ。えへへ、これであたしたち共犯だよねっ！」",200066,2,"deco/character/sigongdongshi_NP",false,false,1,1,1929,923,388,946,339,2262,2710,946,616,2262,false,false,false,false,false,false,false,false,false,false,false,false,false,"sigongdongshi_np"}, get);
tb[406604] = P({D[45057], 406604,4,74,325,"「あたしとのデート大作戦、またの名をクリスマス遊園地の旅、まもなく始まりまーす！　えへへ、まずは最初のミッション、あたしの手作りチョコクッキー、美味しそうに食べられるかなのコーナー！　はい、あ～ん♪」",200066,2,"deco/character/sigongdongshi_SD",false,false,false,false,false,false,false,"1",false,false,"-100,0,1","80,-80,1",false,"-100,0,1","-100,0,1",false,false,false,false,false,false,false,false,false,false,false,2110,917,388,936,418,2104,2754,936,610,2104,"sigongdongshi_sd"}, get);
tb[406605] = P({D[45057], 406605,15,119,326,"「すぅ……はぁ……。この歌は、普通の子な私に、私が持つ特別さに気付かせてくれた人のために、ありったけの想いを込めて書きました。だから……私の気持ち、聴いてください。じゃあ、行くよー！　3、2、1――！」",200066,2,"deco/character/sigongdongshi_OX",false,false,false,false,false,false,false,"1",false,false,"-60,0,1","240,-140,0.94","-100,0,1","-100,0,1","-110,0,1",false,false,false,false,false,false,false,false,false,false,false,2023,891,388,374,238,3026,3071,436,584,2902,"sigongdongshi_ox"}, get);
tb[406606] = P({D[9044], 406606,21,20,327,"「雀士さん、お疲れさま！\nはい、はちみつドリンク。疲れによく効くよ！\nあ……うん、これ、あたしがいつも使ってる水筒。おうちで作って、そのまま持ってきたから……。\n気にしないで、よかったらそのまま使って！\n……あ、あの。\n……頑張ってね！ 応援してます！」",200066,2,"deco/character/sigongdongshi_ydh",0,false,false,false,false,false,false,false,false,false,false,false,false,"sigongdongshi_ydh"}, get);
tb[406701] = P({D[46057], 406701,false,145,328,false,200067,false,"deco/character/qingluan",302002,60,false,false,false,false,85,"1",false,false,false,false,false,false,false,"150,-20,1",false,"-30,100,1",false,"-30,100,1",false,"-10,60,1","0,60,1","-10,60,1","0,60,1","0,40,1",false,false,false,false,false,false,false,false,false,false,0,"qingluan"}, get);
tb[406702] = P({D[12044], 406702,1,4,329,"「何れにせよ、青き鳥は雲の果てへ帰りゆくであろう。\nその時は、そなたも共に喜んでくれるか？」",200067,1,"deco/character/qingluan_0",302002,60,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"qingluan_0"}, get);