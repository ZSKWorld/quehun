-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[406903] = P({D[46057], 406903,12,132,340,"「全く、こんな複雑なデザイン、端から一人で着ることを想定してないんだろうね。まぁいいや。僕はキミのためにこれを着たんだから、この後メンテしなきゃいけなくなったら最後まできっちり付き合ってくれよ。」",200069,2,"deco/character/weilai_LF",false,false,1,false,false,false,false,"1",false,false,"-80,0,1",false,"-60,0,1","-60,0,1","-100,0,1",false,false,false,false,false,false,false,false,false,false,false,1956,883,392,1068,714,2063,2510,1068,714,2063,1125,"weilai_lf"}, get);
tb[406904] = P({D[9057], 406904,17,71,341,"優雅に踊るヒューマノイドを開発するには、モニタの前でひたすらデータとにらめっこしててもしょうがない。やっぱり、自分で色々なダンスをやってみる必要があると思うんだ。\nほっ……ねえ、ちょっと、足を支えててくれない？ あと少しで、つま先に届く、はず、なんだけ、ど……。\nそう、そんな感じで……！　って、あれ？　なんだか、キミの手のひら、すごく熱くない？",200069,2,"deco/character/weilai_BL","weilai_bl"}, get);
tb[407001] = P({D[25034], 407001,false,149,342,false,200070,false,"deco/character/luluxiu",302002,60,1,false,false,false,-160,"1",false,false,false,false,false,false,false,"40,590,0.94",1872,863,388,1507,780,1016,3194,1507,780,1016,1037}, get);
tb[407002] = P({D[24034], 407002,1,4,343,false,200070,1,"deco/character/luluxiu_0",302002,60,false,false,1,false,false,false,false,"0,-104,1","0,-88,1",false,"0,-90,1",false,"0,-110,1",1837,744,388,683,388,3455,3812,960,437,2901,1261}, get);
tb[407003] = P({D[12034], 407003,999,150,344,false,200070,3,"deco/character/luluxiu_dress",false,false,1,1734,912,388,823,416,3079,3013,912,605,2901,1261}, get);
tb[407101] = P({D[25034], 407101,false,151,345,false,200071,false,"deco/character/cc",302002,60,1,false,false,false,-73,"1",false,false,false,false,false,false,false,"60,340,0.94",1846,876,388,1323,815,1609,2876,1323,815,1609,1015}, get);
tb[407102] = P({D[12034], 407102,1,4,346,false,200071,1,"deco/character/cc_0",302002,60,1,1980,937,388,579,false,2888,3926,579,630,2888,1261}, get);
tb[407103] = P({D[12034], 407103,999,150,347,false,200071,3,"deco/character/cc_dress",false,false,1,1879,872,388,1130,112,2217,3091,1130,565,2217,1261}, get);
tb[407201] = P({D[25034], 407201,false,152,348,false,200072,false,"deco/character/zhuque",302002,60,false,false,false,false,-210,"0.980000019073486",false,false,false,false,false,false,false,"20,610,0.94",1850,826,388,1484,719,1084,3292,1484,719,1084,1061}, get);
tb[407202] = P({D[12034], 407202,1,4,349,false,200072,1,"deco/character/zhuque_0",302002,60,1,1848,820,388,809,512,2670,3688,809,513,2670,1261}, get);
tb[407203] = P({D[12034], 407203,999,150,350,false,200072,3,"deco/character/zhuque_dress",false,false,1,1901,912,388,371,380,3184,3076,512,605,2902,1261}, get);
tb[407301] = P({D[25034], 407301,false,153,351,false,200073,false,"deco/character/kalian",302002,60,1,false,false,false,-105,"0.990000009536743",false,false,false,false,false,false,false,"0,340,0.94",1840,860,388,1626,764,894,2953,1626,764,894,1050}, get);
tb[407302] = P({D[12034], 407302,1,4,352,false,200073,1,"deco/character/kalian_0",302002,60,1,1895,878,388,664,298,2588,3030,664,571,2588,1261}, get);
tb[407303] = P({D[9034], 407303,999,150,353,false,200073,3,"deco/character/kalian_dress",1874,855,388,939,502,2579,2989,939,548,2579,1261}, get);
tb[407401] = P({D[35057], 407401,false,154,354,false,200074,false,"deco/character/lanxing",302002,60,1,1,false,false,-50,"1",false,false,false,false,false,false,false,"0,-20,1","-80,-10,1","0,-20,1",false,false,false,"-80,10,1","0,10,1",false,false,"-40,0,1","lanxing"}, get);
tb[407402] = P({D[13057], 407402,1,4,355,"「この装束……お師匠が認めてくれた証でござるか！？\nみ、見えるでござる！ 拙者が秘技・国士無双十三面待ちを会得する日は近いでござるよ！」",200074,1,"deco/character/lanxing_0",302002,60,false,1,"lanxing_0"}, get);
tb[407403] = P({D[24057], 407403,3,54,356,"「お師匠！　この嵐星が先陣を切って道を開くでござる！　百鬼夜行程度、お師匠と力を合わせれば必ずや阻止でき……むっ？　あがり！？　本当に、拙者のあがりでござるか！？　であれば、皆の者、神妙に点棒を納めるでござる～！」",200074,2,"deco/character/lanxing_WS",false,false,false,false,false,false,false,"1",false,false,false,"240,-210,1",false,false,"-100,0,1","lanxing_ws"}, get);
tb[407404] = P({D[12045], 407404,20,90,357,"「一飜市に、斯様な忍具があるとは……！\nどうやら、柔らかそうなもののようでござるな。如何にして使えば良いのか、見当もつかないでござる。\nお師匠、もし良ければ、これを一つ買い求め、使い方をご教示いただけないだろうか！」",200074,2,"deco/character/lanxing_yh",false,false,1,1,3731,5000,1858,4467,5333,9833,6833,10766,12183,8000,2666,"lanxing_yh"}, get);
tb[407501] = P({D[46057], 407501,false,155,358,false,200075,false,"deco/character/ling",302002,60,false,false,false,false,-230,"1",false,false,false,false,false,false,false,"40,520,0.92","-50,0,1",false,false,false,false,"-40,-20,1","0,-20,1",false,false,"0,-40,1",1877,824,390,1303,705,1358,3252,1303,705,1358,1074,"ling"}, get);
tb[407502] = P({D[14034], 407502,1,4,359,"「あとすこし……もうすぐで、ハッキングが完了する。ここまでやりあえた相手は、久しぶりだ。\nこんなに夜遅くまで、付き合ってくれてありがと。なんていうか……色々助かった。主に精神面で」",200075,1,"deco/character/ling_0",302002,60,1,false,1,1942,889,389,620,775,2929,2176,634,775,2901,1069,false,false,false,false,false,false,false,false,false,false,false,false,"ling_0"}, get);