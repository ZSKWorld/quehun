-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[407003] = P({D[12034], 407003,999,149,342,false,200070,3,"deco/character/luluxiu_dress",false,false,1,1734,912,388,823,416,3079,3013,912,605,2901}, get);
tb[407101] = P({D[25034], 407101,false,150,343,false,200071,false,"deco/character/cc",302002,60,1,false,false,false,-73,"1",false,false,false,false,false,false,false,"60,340,0.94",1846,876,388,1323,815,1609,2876,1323,815,1609,1015}, get);
tb[407102] = P({D[12034], 407102,1,4,344,false,200071,1,"deco/character/cc_0",302002,60,1,1980,937,388,579,false,2888,3926,579,630,2888}, get);
tb[407103] = P({D[12034], 407103,999,149,345,false,200071,3,"deco/character/cc_dress",false,false,1,1879,872,388,1130,112,2217,3091,1130,565,2217}, get);
tb[407201] = P({D[25034], 407201,false,151,346,false,200072,false,"deco/character/zhuque",302002,60,false,false,false,false,-210,"0.980000019073486",false,false,false,false,false,false,false,"20,610,0.94",1850,826,388,1484,719,1084,3292,1484,719,1084,1061}, get);
tb[407202] = P({D[12034], 407202,1,4,347,false,200072,1,"deco/character/zhuque_0",302002,60,1,1848,820,388,809,512,2670,3688,809,513,2670}, get);
tb[407203] = P({D[12034], 407203,999,149,348,false,200072,3,"deco/character/zhuque_dress",false,false,1,1901,912,388,371,380,3184,3076,512,605,2902}, get);
tb[407301] = P({D[25034], 407301,false,152,349,false,200073,false,"deco/character/kalian",302002,60,1,false,false,false,-105,"0.990000009536743",false,false,false,false,false,false,false,"0,340,0.94",1840,860,388,1626,764,894,2953,1626,764,894,1050}, get);
tb[407302] = P({D[12034], 407302,1,4,350,false,200073,1,"deco/character/kalian_0",302002,60,1,1895,878,388,664,298,2588,3030,664,571,2588}, get);
tb[407303] = P({D[9034], 407303,999,149,351,false,200073,3,"deco/character/kalian_dress",1874,855,388,939,502,2579,2989,939,548,2579}, get);
tb[407401] = P({D[46057], 407401,false,153,352,false,200074,false,"deco/character/lanxing",302002,60,1,1,false,false,-50,"1",false,false,false,false,false,false,false,"0,-20,1","-80,-10,1","0,-20,1",false,false,false,"-80,10,1","0,10,1",false,false,"-40,0,1",false,false,false,false,false,false,false,false,false,false,0,"lanxing"}, get);
tb[407402] = P({D[13044], 407402,1,4,353,"「この装束……お師匠が認めてくれた証でござるか！？\nみ、見えるでござる！ 拙者が秘技・国士無双十三面待ちを会得する日は近いでござるよ！」",200074,1,"deco/character/lanxing_0",302002,60,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"lanxing_0"}, get);
tb[407403] = P({D[24044], 407403,3,54,354,"「お師匠！　この嵐星が先陣を切って道を開くでござる！　百鬼夜行程度、お師匠と力を合わせれば必ずや阻止でき……むっ？　あがり！？　本当に、拙者のあがりでござるか！？　であれば、皆の者、神妙に点棒を納めるでござる～！」",200074,2,"deco/character/lanxing_WS",false,false,false,false,false,false,false,"1",false,false,false,"240,-210,1",false,false,"-100,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"lanxing_ws"}, get);
tb[407404] = P({D[12044], 407404,20,89,355,"「一飜市に、斯様な忍具があるとは……！\nどうやら、柔らかそうなもののようでござるな。如何にして使えば良いのか、見当もつかないでござる。\nお師匠、もし良ければ、これを一つ買い求め、使い方をご教示いただけないだろうか！」",200074,2,"deco/character/lanxing_yh",false,false,1,0,1,3731,5000,1858,4467,5333,9833,6833,10766,12183,8000,2666,"lanxing_yh"}, get);
tb[407501] = P({D[46057], 407501,false,154,356,false,200075,false,"deco/character/ling",302002,60,false,false,false,false,-230,"1",false,false,false,false,false,false,false,"40,520,0.92","-50,0,1",false,false,false,false,"-40,-20,1","0,-20,1",false,false,"0,-40,1",1877,824,390,1303,705,1358,3252,1303,705,1358,1074,"ling"}, get);
tb[407502] = P({D[14034], 407502,1,4,357,"「あとすこし……もうすぐで、ハッキングが完了する。ここまでやりあえた相手は、久しぶりだ。\nこんなに夜遅くまで、付き合ってくれてありがと。なんていうか……色々助かった。主に精神面で」",200075,1,"deco/character/ling_0",302002,60,1,false,1,1942,889,389,620,775,2929,2176,634,775,2901,1069,false,false,false,false,false,false,false,false,false,false,false,false,"ling_0"}, get);
tb[407503] = P({D[45057], 407503,2,14,358,"「水遊びが出来ればいいなら、別に家でも出来るだろ。日差しにも、くだらない社交辞令にも苦しめられる必要もない……。けど、せっかく来たし、一緒に遊ぶか？　その辺に二人用のがあったはず。」",200075,2,"deco/character/ling_YZ",false,false,false,false,false,false,false,"1",false,false,"-300,0,1","150,-130,1","-300,0,1","-300,0,1","-300,0,1",false,false,false,false,false,false,false,false,false,false,false,2208,836,389,653,202,3010,3483,707,530,2902,"ling_xr"}, get);
tb[407504] = P({D[9044], 407504,19,39,359,"「潜入に最適な恰好してても、満月の夜だとバレるんだな。\nはぁ……めんど。\nでも、アンタに怪我がなくて良かった。\nこっからは、俺たちが反撃に打って出る番だ。」",200075,2,"deco/character/ling_gf",0,false,false,false,false,false,false,false,false,false,false,false,false,"ling_gf"}, get);
tb[407601] = P({D[25033], 407601,false,155,360,false,200076,false,"deco/character/dongchengxuanyin",302002,60,1,false,1,false,-290,"1",false,false,false,false,false,false,false,"0,250,1","-140,0,1",1927,862,392,1137,265,2018,3266,1137,557,2018}, get);
tb[407602] = P({D[14034], 407602,1,4,361,"「『旦那さんにとって、うちは所詮ただの一匹の狐。他の狐とさして変わらんかもしれまへん。けど、旦那さんがうちを選んで、飼ってくれたからには、お互いに唯一無二の存在になっていくもんどす。』\n……どうどす？　本に書いてあったこのセリフは。\n……ふふっ、そうどすか。けどうちは、『飼う』という言葉はどうにも好きになれまへん。旦那さんにとっての唯一の存在になる方法は、他にいくらでもおますのになあ。」",200076,1,"deco/character/407602",302002,60,false,false,1,1912,907,392,687,377,3049,2991,761,602,2901,false,2,6474,5000,3107,5430,6666,6666,6666,6666,10000,13333,6666,false,false,0}, get);