-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[407701] = P({D[17023], 407701,false,156,362,false,200077,false,"deco/character/hanna",302002,60,1,false,false,false,-80,"0.98","-120,130,0.98","0,0,0.98","0,0,0.98","0,0,0.98","0,0,0.98","0,0,0.98","30,-40,1","30,-40,1","0,0,0.98",false,"0,-30,1",1726,841,390,1525,709,1824,2752,1525,709,1824,1087}, get);
tb[407702] = P({D[24034], 407702,1,4,363,"「おめさ見らいでらば、なんだがドキドキするじゃ……。んだけどもさ、そいでも傍さいで欲しじゃ。もう、どうせばいいんだべ……。」",200077,1,"deco/character/hanna_0",302002,60,false,false,false,false,false,"1",false,false,false,false,false,false,"-80,80,1",2010,1050,390,923,248,2358,2622,923,744,2358}, get);
tb[407703] = P({D[24034], 407703,12,131,364,"「ガオ〜！　真のれでーにはごーじゃすな服だけでね、素敵なダンスパートナーもいるんだべ。だはんで、こごでずっとおめを待っでだんず！　ほれ、一、二の三……一、二の三……ガウ！？　笑わねんで！」",200077,2,"deco/character/hanna_LF",false,false,1,false,false,false,false,"1",false,false,"-120,0,1",false,"-80,0,1","-80,0,1","-120,0,1",1956,883,390,1027,false,2107,3095,1027,577,2107}, get);
tb[407801] = P({D[17023], 407801,false,157,365,false,200078,false,"deco/character/musa",302002,60,1,false,false,false,-90,"1","20,280,0.98","-100,0,1","-160,0,1",false,false,false,"-180,-40,1","-180,-40,1",false,false,"-120,-40,1",1992,846,390,1129,658,2108,2965,1129,658,2108,1143}, get);
tb[407802] = P({D[24034], 407802,1,4,366,"「手当？ 自分で、やる。\n……さけてる？ おまえを？\n……違う。おれ、すごく強い。誰か頼るオス、弱い」",200078,1,"deco/character/musa_0",302002,60,false,false,false,false,false,"1",false,"0,150,1","-220,150,1",false,"-180,150,1","-200,150,1","-140,140,1",2209,1087,390,577,false,2735,3495,577,781,2735}, get);
tb[407901] = P({D[17034], 407901,false,158,367,false,200079,false,"deco/character/yiliya",302002,60,false,false,1,false,-20,"1",1852,979,422,1560,914,954,2320,1560,914,954,1036}, get);
tb[407902] = P({D[24034], 407902,1,4,368,false,200079,1,"deco/character/yiliya_0",302002,60,false,false,1,false,false,"1",false,"0,0,0.99","-60,0,0.99",false,"0,0,0.99","0,0,0.99","0,0,0.99",2028,936,422,false,449,3416,2502,257,646,2902}, get);
tb[407903] = P({D[24034], 407903,999,159,369,false,200079,3,"deco/character/yiliya_live",false,false,false,false,1,false,false,"1",false,false,"-80,0,1","0,0,0.9","-50,0,1","-50,0,1","-50,0,1",1947,962,411,645,502,3074,3207,731,667,2902}, get);
tb[408001] = P({D[17034], 408001,false,160,370,false,200080,false,"deco/character/meiyou",302002,60,false,false,1,false,-90,"1",1888,982,422,1682,719,834,2522,1682,719,834,1234}, get);
tb[408002] = P({D[24034], 408002,1,4,371,false,200080,1,"deco/character/meiyou_0",302002,60,false,false,1,false,false,"1",false,false,"-100,0,1",false,false,"-100,0,1","-100,0,0.99",2019,895,422,994,539,2256,2920,994,605,2256}, get);
tb[408003] = P({D[24034], 408003,999,159,372,false,200080,3,"deco/character/meiyou_live",false,false,false,false,1,false,false,"1",false,"0,0,0.98","-120,0,0.98","100,110,0.9","-50,0,0.98","-50,0,0.98","-50,0,0.98",1969,920,422,808,815,2428,3015,808,815,2428,1076}, get);
tb[408101] = P({D[17034], 408101,false,161,373,false,200081,false,"deco/character/xiaohei",302002,60,false,false,1,false,-20,"1",1890,995,422,1664,815,922,2412,1664,815,922,1151}, get);
tb[408102] = P({D[24034], 408102,1,4,374,false,200081,1,"deco/character/xiaohei_0",302002,60,false,false,1,false,false,"1",false,"0,0,0.99","-60,0,0.99",false,"-50,0,0.99","-50,0,0.99","-80,0,0.99",1899,959,422,364,255,3524,3225,675,669,2902}, get);
tb[408103] = P({D[24034], 408103,999,159,375,false,200081,3,"deco/character/xiaohei_live",false,false,false,false,1,false,false,"1",false,"0,0,0.98","0,0,0.98","100,0,0.9","0,0,0.98","0,0,0.98","0,0,0.98",1931,817,399,545,479,3127,3198,658,516,2901}, get);
tb[408201] = P({D[17034], 408201,false,162,376,false,200082,false,"deco/character/jier",302002,60,false,false,1,false,20,"1",1884,979,422,1739,911,1058,2361,1739,911,1058,1039}, get);
tb[408202] = P({D[24034], 408202,1,4,377,false,200082,1,"deco/character/jier_0",302002,60,false,false,1,false,false,"1",false,"0,0,1.01","-140,0,1",false,"-100,0,1","-100,0,1","-200,0,1",2032,899,388,false,false,4200,3146,649,592,2902}, get);
tb[408203] = P({D[24034], 408203,999,159,378,false,200082,3,"deco/character/jier_live",false,false,false,false,1,false,false,"1",false,false,false,"0,0,0.95",false,false,"-80,0,1",1842,903,388,718,588,2784,2819,718,596,2784}, get);
tb[408301] = P({D[46057], 408301,false,163,379,false,200083,false,"deco/character/yifu",302002,60,1,false,false,false,20,"1",false,false,false,false,false,"-80,0,1","-80,0,1","0,190,0.98","-80,0,1","-100,0,1",false,false,false,"-120,10,1","-100,10,1",false,false,"-90,0,1",1953,872,390,1110,798,1777,2709,1110,798,1777,1029,"yifu"}, get);
tb[408302] = P({D[11034], 408302,1,4,380,"「夜の風、気持ちいいですね。\nこんな落ち着いた夜を、貴方と一緒にお散歩出来るなんて……うーん、なんというか……素敵すぎて、現実味に欠けるといいますか。\nこの道も、もう少し長ければいいのにと思ってしまいます。\nそうすれば、貴方ともっと一緒に歩けますから。」",200083,1,"deco/character/yifu_0",302002,60,1836,904,390,979,44,2268,3298,979,598,2268,false,false,false,false,false,false,false,false,false,false,false,false,false,"yifu_0"}, get);
tb[408303] = P({D[9044], 408303,18,65,381,"「すみません。こんな姿を見せるつもりはありませんでした。\n……頭をなでてくれるのは、慰めているのですか？\n……そう、心配させていたんですね。\n……あっ、今夜のことは、二人の秘密にしてください。お願いします。」",200083,2,"deco/character/yifu_xl",0,false,false,false,false,false,false,false,false,false,false,false,false,"yifu_xl"}, get);