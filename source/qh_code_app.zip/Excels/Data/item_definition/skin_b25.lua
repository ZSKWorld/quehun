-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[408304] = P({D[17044], 408304,6,107,382,"「花火に連れてきてくださり、ありがとうございます。\n貴方に会うと、いつも子供の頃を……友人と当たり前のように会えていた頃を思い出します。\n『心寄せる者とは何度でも会うことです。共に過ごす時間が、互いにとって最上の贈り物になりますから』\nこれは、かつてシスターが私たちに授けてくれた教えです。\n貴方と会えること、その一回一回を、私はとても大切にしています。\nそして……叶うなら、これからも、貴方ともっとたくさんの花火が見たいと思っています。」",200083,2,"deco/character/yifu_cj",false,false,1,false,false,false,false,"1",0,1,3672,5000,1737,2652,3000,11166,12566,8566,12500,8000,3000,"yifu_cj"}, get);
tb[408401] = P({D[46057], 408401,false,164,383,false,200084,false,"deco/character/linlang",302002,60,false,false,false,false,120,"1",false,false,false,false,false,false,"-60,0,1","110,-300,1.06",false,"-100,0,1",false,false,false,"-100,40,0.95","-100,40,0.95",false,false,"-20,60,1",1958,973,390,1046,832,1905,2007,1046,832,1905,1096,"linlang"}, get);
tb[408402] = P({D[45057], 408402,1,4,384,"「んぇ！？ 今から晩ご飯なの！？」\n「琳琅、さっき食べたばかりだけど、きみに免じて、あとちょっとだけ……二人前くらい食べよっかな！」",200084,1,"deco/character/linlang_0",302002,60,1,false,false,false,false,"1",false,false,"-300,0,1",false,"-300,0,1","-300,0,1","-200,0,1",false,false,false,false,false,false,false,false,false,false,false,2201,1020,390,612,476,2814,2502,612,714,2814,"linlang_0"}, get);
tb[408403] = P({D[45057], 408403,15,119,385,"「あそこのドラム、ちょっと遠い。でも大丈夫、こうやって尻尾で叩けば……ほら、ドン！　っていい音が鳴るだろ？　琳琅、賢い。尻尾もちょー器用。」",200084,2,"deco/character/linlang_OX",false,false,1,false,false,false,false,"1",false,false,"-60,0,1","200,80,0.9","-60,0,1","-60,0,1","-60,60,1",false,false,false,false,false,false,false,false,false,false,false,1868,1034,423,767,144,3049,3343,841,745,2901,"linlang_ox"}, get);
tb[408404] = P({D[17044], 408404,4,96,386,"「琳琅、全部食べれる！ きみが買ってくれたアイス、絶対無駄にしない。\nきみのクリスマスプレゼントは、琳琅だけのもの！ 他の龍にわけるの、ダメ。\n琳琅がお腹いっぱいにならなかったら、すっっごく大変なことになるから！」",200084,2,"deco/character/linlang_sd",false,false,false,false,false,false,false,"",0,1,3525,5000,1800,3150,5333,8533,9000,7033,12767,8000,5333,"linlang_sd"}, get);
tb[408501] = P({D[46057], 408501,false,165,387,false,200085,false,"deco/character/yuanfeng",302002,60,false,false,false,false,-100,"1",false,"0,-50,1","0,-50,1",false,"0,-50,1","0,-50,1","0,-50,1","0,380,0.98",false,false,false,false,false,"-60,0,1","-40,0,1",false,false,"-30,-50,1",1874,818,390,1481,710,1385,2964,1481,710,1385,1063,"yuanfeng"}, get);
tb[408502] = P({D[45057], 408502,1,4,388,"「せっかく我が同朋が来てくれたんだ、自分の家だと思ってくつろいでネ。\nいやいや、そう畏まらなくていいヨ。ボクたちの仲でしょ、ボクのものは同朋のものさ。\nどうしても気が済まないなら、同朋の秘密の一つか二つ、教えてくれたらいいヨ～！」",200085,1,"deco/character/yuanfeng_0",302002,60,1,false,1,false,false,"1",false,false,false,false,false,false,"-100,0,1",false,false,false,false,false,false,false,false,false,false,false,1935,920,390,827,345,2773,3071,827,614,2773,"yuanfeng_0"}, get);
tb[408503] = P({D[9044], 408503,19,39,389,"「おお、我が同朋～！ さては占いに来ましたネ？\nなんとも得難い半日の余暇だけど、ボクにはとっくにわかってたヨ――「白日高く昇りて縁有る者来たる」ってネ。占いの通りになったヨ。\nさて、銀杏の葉も綺麗さっぱり払ったことだし、じっくり同朋の見た夢の卦象を解釈していくとしますかネ！」",200085,2,"deco/character/yuanfeng_gf",0,false,false,false,false,false,false,false,false,false,false,false,false,"yuanfeng_gf"}, get);
tb[408601] = P({D[30031], 408601,false,166,390,false,200086,false,"deco/character/shalangbaizi",302002,60,1,false,1,false,210,"1",false,"0,60,1","0,60,1",false,"0,60,1","0,60,1","-80,60,1","0,-60,1.1","0,0,1.08","0,0,1.08","0,0,1.08","0,0,1.08","0,0,1.08","0,0,1.08",false,false,1900,950,388,1502,782,1001,2261,1502,782,1001,1122}, get);
tb[408602] = P({D[24034], 408602,1,4,391,false,200086,1,"deco/character/shalangbaizi_0",302002,60,1,false,1,false,false,"1",false,"60,60,1","0,60,1",false,"120,60,1","120,60,1","-80,60,1",1652,1101,388,996,732,2306,2326,996,794,2306}, get);
tb[408603] = P({D[24034], 408603,999,167,392,false,200086,3,"deco/character/shalangbaizi_qp",false,false,1,false,1,false,false,"1",false,"0,90,1","-180,90,1","120,-200,1","-120,90,1","-120,90,1","-160,90,1",1990,1006,395,736,450,2681,2551,736,703,2681}, get);
tb[408701] = P({D[17023], 408701,false,168,393,false,200087,false,"deco/character/xiaoniaoyouxingye",302002,60,1,false,1,false,260,"1","0,-160,1.1","0,0,1.08","0,0,1.08","0,0,1.08","0,0,1.08","0,0,1.08",false,false,"0,0,1.08",false,false,1894,1036,388,1597,736,1288,2157,1597,736,1288,1254}, get);
tb[408702] = P({D[24034], 408702,1,4,394,false,200087,1,"deco/character/xiaoniaoyouxingye_0",302002,60,false,false,1,false,false,"1",false,"0,0,1.02","-160,0,1.02",false,"-60,0,1.02","-140,0,1.02","-120,0,1.02",2065,1025,388,1182,798,1832,1570,1182,798,1832,1181}, get);
tb[408703] = P({D[24034], 408703,999,167,395,false,200087,3,"deco/character/xiaoniaoyouxingye_qp",false,false,1,false,1,false,false,"1",false,"0,60,1","60,60,1","20,-240,1.08","100,60,1","100,60,1","-250,60,1",1554,1198,388,1143,481,2371,2158,1143,891,2371}, get);