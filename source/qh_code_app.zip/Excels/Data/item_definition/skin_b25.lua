-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[408103] = P({D[24034], 408103,999,160,377,false,200081,3,"deco/character/xiaohei_live",false,false,false,false,1,false,false,"1",false,"0,0,0.98","0,0,0.98","100,0,0.9","0,0,0.98","0,0,0.98","0,0,0.98",1931,817,399,545,479,3127,3198,658,516,2901,1261}, get);
tb[408201] = P({D[17034], 408201,false,163,378,false,200082,false,"deco/character/jier",302002,60,false,false,1,false,20,"1",1884,979,422,1739,911,1058,2361,1739,911,1058,1039}, get);
tb[408202] = P({D[24034], 408202,1,4,379,false,200082,1,"deco/character/jier_0",302002,60,false,false,1,false,false,"1",false,"0,0,1.01","-140,0,1",false,"-100,0,1","-100,0,1","-200,0,1",2032,899,388,false,false,4200,3146,649,592,2902,1261}, get);
tb[408203] = P({D[24034], 408203,999,160,380,false,200082,3,"deco/character/jier_live",false,false,false,false,1,false,false,"1",false,false,false,"0,0,0.95",false,false,"-80,0,1",1842,903,388,718,588,2784,2819,718,596,2784,1261}, get);
tb[408301] = P({D[46057], 408301,false,164,381,false,200083,false,"deco/character/yifu",302002,60,1,false,false,false,20,"1",false,false,false,false,false,"-80,0,1","-80,0,1","0,190,0.98","-80,0,1","-100,0,1",false,false,false,"-120,10,1","-100,10,1",false,false,"-90,0,1",1953,872,390,1110,798,1777,2709,1110,798,1777,1029,"yifu"}, get);
tb[408302] = P({D[11034], 408302,1,4,382,"「夜の風、気持ちいいですね。\nこんな落ち着いた夜を、貴方と一緒にお散歩出来るなんて……うーん、なんというか……素敵すぎて、現実味に欠けるといいますか。\nこの道も、もう少し長ければいいのにと思ってしまいます。\nそうすれば、貴方ともっと一緒に歩けますから。」",200083,1,"deco/character/yifu_0",302002,60,1836,904,390,979,44,2268,3298,979,598,2268,1261,false,false,false,false,false,false,false,false,false,false,false,false,"yifu_0"}, get);
tb[408303] = P({D[9057], 408303,18,65,383,"「すみません。こんな姿を見せるつもりはありませんでした。\n……頭をなでてくれるのは、慰めているのですか？\n……そう、心配させていたんですね。\n……あっ、今夜のことは、二人の秘密にしてください。お願いします。」",200083,2,"deco/character/yifu_xl","yifu_xl"}, get);
tb[408304] = P({D[17045], 408304,6,108,384,"「花火に連れてきてくださり、ありがとうございます。\n貴方に会うと、いつも子供の頃を……友人と当たり前のように会えていた頃を思い出します。\n『心寄せる者とは何度でも会うことです。共に過ごす時間が、互いにとって最上の贈り物になりますから』\nこれは、かつてシスターが私たちに授けてくれた教えです。\n貴方と会えること、その一回一回を、私はとても大切にしています。\nそして……叶うなら、これからも、貴方ともっとたくさんの花火が見たいと思っています。」",200083,2,"deco/character/yifu_cj",false,false,1,false,false,false,false,"1",1,3672,5000,1737,2652,3000,11166,12566,8566,12500,8000,3000,"yifu_cj"}, get);
tb[408401] = P({D[46057], 408401,false,165,385,false,200084,false,"deco/character/linlang",302002,60,false,false,false,false,120,"1",false,false,false,false,false,false,"-60,0,1","110,-300,1.06",false,"-100,0,1",false,false,false,"-100,40,0.95","-100,40,0.95",false,false,"-20,60,1",1958,973,390,1046,832,1905,2007,1046,832,1905,1096,"linlang"}, get);
tb[408402] = P({D[46057], 408402,1,4,386,"「んぇ！？ 今から晩ご飯なの！？」\n「琳琅、さっき食べたばかりだけど、きみに免じて、あとちょっとだけ……二人前くらい食べよっかな！」",200084,1,"deco/character/linlang_0",302002,60,1,false,false,false,false,"1",false,false,"-300,0,1",false,"-300,0,1","-300,0,1","-200,0,1",false,false,false,false,false,false,false,false,false,false,false,2201,1020,390,612,476,2814,2502,612,714,2814,1261,"linlang_0"}, get);
tb[408403] = P({D[46057], 408403,15,120,387,"「あそこのドラム、ちょっと遠い。でも大丈夫、こうやって尻尾で叩けば……ほら、ドン！　っていい音が鳴るだろ？　琳琅、賢い。尻尾もちょー器用。」",200084,2,"deco/character/linlang_OX",false,false,1,false,false,false,false,"1",false,false,"-60,0,1","200,80,0.9","-60,0,1","-60,0,1","-60,60,1",false,false,false,false,false,false,false,false,false,false,false,1868,1034,423,767,144,3049,3343,841,745,2901,1261,"linlang_ox"}, get);
tb[408404] = P({D[17045], 408404,4,97,388,"「琳琅、全部食べれる！ きみが買ってくれたアイス、絶対無駄にしない。\nきみのクリスマスプレゼントは、琳琅だけのもの！ 他の龍にわけるの、ダメ。\n琳琅がお腹いっぱいにならなかったら、すっっごく大変なことになるから！」",200084,2,"deco/character/linlang_sd",false,false,false,false,false,false,false,"",1,3525,5000,1800,3150,5333,8533,9000,7033,12767,8000,5333,"linlang_sd"}, get);
tb[408501] = P({D[46057], 408501,false,166,389,false,200085,false,"deco/character/yuanfeng",302002,60,false,false,false,false,-100,"1",false,"0,-50,1","0,-50,1",false,"0,-50,1","0,-50,1","0,-50,1","0,380,0.98",false,false,false,false,false,"-60,0,1","-40,0,1",false,false,"-30,-50,1",1874,818,390,1481,710,1385,2964,1481,710,1385,1063,"yuanfeng"}, get);
tb[408502] = P({D[46057], 408502,1,4,390,"「せっかく我が同朋が来てくれたんだ、自分の家だと思ってくつろいでネ。\nいやいや、そう畏まらなくていいヨ。ボクたちの仲でしょ、ボクのものは同朋のものさ。\nどうしても気が済まないなら、同朋の秘密の一つか二つ、教えてくれたらいいヨ～！」",200085,1,"deco/character/yuanfeng_0",302002,60,1,false,1,false,false,"1",false,false,false,false,false,false,"-100,0,1",false,false,false,false,false,false,false,false,false,false,false,1935,920,390,827,345,2773,3071,827,614,2773,1261,"yuanfeng_0"}, get);