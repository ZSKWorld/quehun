-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[408801] = P({D[17023], 408801,false,169,396,false,200088,false,"deco/character/lubamoailu",302002,60,false,false,1,false,-10,"1","0,-20,1.02","0,0,1.06","0,0,1.06","0,0,1.06","0,0,1.06","0,0,1.06",false,false,"0,0,1.06",false,false,1879,872,388,1220,593,2028,2619,1220,593,2028,1233}, get);
tb[408802] = P({D[24034], 408802,1,4,397,false,200088,1,"deco/character/lubamoailu_0",302002,60,false,false,1,false,false,"1",false,"0,0,1.02","0,0,1.02",false,"0,0,1.02","0,0,1.02","-110,30,1.02",1874,962,388,1044,772,2298,1815,1044,772,2298,1144}, get);
tb[408803] = P({D[24034], 408803,999,167,398,false,200088,3,"deco/character/lubamoailu_qp",false,false,1,false,1,false,false,"1",false,false,"-240,0,1","140,-340,1","-240,0,1","-240,0,1","-80,0,1",2128,966,388,1018,248,2234,2499,1018,659,2234}, get);
tb[408901] = P({D[30031], 408901,false,170,399,false,200089,false,"deco/character/qianhuangmuyue",302002,60,1,false,1,false,270,"1",false,"0,0,1.02","0,0,1.02",false,"0,0,1.02","0,0,1.02","-40,0,1.02","0,-200,1.08","0,0,1.07","0,0,1.07","0,0,1.07","0,0,1.07","0,0,1.07","0,0,1.07",false,false,1712,1151,388,1600,753,1634,2158,1600,844,1634}, get);
tb[408902] = P({D[24034], 408902,1,4,400,false,200089,1,"deco/character/qianhuangmuyue_0",302002,60,false,false,1,false,false,"1",false,"0,60,1.02","0,60,1.02",false,"0,60,1.02","0,60,1.02","-100,60,1.02",1893,1036,388,1169,720,1849,2141,1169,729,1849}, get);
tb[408903] = P({D[24034], 408903,999,167,401,false,200089,3,"deco/character/qianhuangmuyue_qp",false,false,1,false,1,false,false,"1",false,"0,0,1.02","0,0,1.02","200,-300,1","0,0,1.02","0,0,1.02","-40,0,1",1917,944,388,1177,441,1860,2144,1177,637,1860}, get);
tb[409001] = P({D[46057], 409001,false,171,402,false,200090,false,"deco/character/jiushi",302002,60,1,false,false,false,-130,"1",false,false,false,false,false,"-50,0,1","-80,0,1","0,430,0.94","-100,0,1","-100,0,1",false,false,false,"-120,0,1","-80,0,1",false,false,"-80,0,1",false,false,false,false,false,false,false,false,false,false,0,"jiushi"}, get);
tb[409002] = P({D[23044], 409002,1,4,403,"「旦那ァ、その手に持ってるネクタイはなんだ、俺にくれるモンだったりして？\nまったく……男にネクタイを結ぶってのは、犬にリードをつけんのと一緒だぜ。\nま、俺ァ忠犬になんかなるつもりはねェけどな。なぁ、旦那？」",200090,1,"deco/character/jiushi_0",302002,60,1,false,false,false,false,"1",false,false,"-40,0,1",false,false,"-40,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiushi_0"}, get);
tb[409003] = P({D[17044], 409003,2,81,404,"「旦那って奴は……隠れようったって、こっちは腐っても情報屋だぜ？\nああもこの日差しよりアツい視線をくれちゃ、どこにいるのかバレバレだ。\nま、一日くらいなら遊びに付き合ってやってもいいぜ。\nやるよ、旦那好みのドリンクだ。……ん？ 当然、来るのがわかってたんで用意しといたモンだ、それがどうかしたか？」",200090,2,"deco/character/jiushi_xr",false,false,false,false,false,false,false,"",0,1,2913,5000,1429,2732,5333,6333,7566,10666,15933,8000,5333,"jiushi_xr"}, get);
tb[409101] = P({D[46057], 409101,false,172,405,false,200091,false,"deco/character/xili",302002,60,false,false,false,false,50,"1",false,"0,20,1","0,20,1",false,"0,20,1","0,20,1","0,20,1","0,130,1","-30,40,1","-20,20,1",false,false,"0,40,1","-80,20,1","-20,20,1",false,false,"-40,0,1",false,false,false,false,false,false,false,false,false,false,0,"xili"}, get);
tb[409102] = P({D[24044], 409102,1,4,406,"「あは、あははっ！ もー、やめてってば！ モヒート！\nモヒートもあんたのこと、家族だって認めたみたいだね。どんなに凶暴な猛獣でも、家族には優しいんだ」",200091,1,"deco/character/xili_0",302002,60,false,false,false,false,false,"1",false,"0,100,1","0,100,1",false,"0,100,1","0,100,1","-100,100,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"xili_0"}, get);
tb[409103] = P({D[9044], 409103,20,89,407,"「『Soul』のオフに、一緒にジョギングできてよかった。ありがとう。\n長い距離を走って疲れたでしょう。バテる前に水分とって。\nあれ、ボトル持ってきてないの？\nじゃあ……あんたがいいなら、私の、飲んでもいいよ。」",200091,2,"deco/character/xili_yh",0,false,false,false,false,false,false,false,false,false,false,false,false,"xili_yh"}, get);
tb[409201] = P({D[17044], 409201,false,173,408,false,200092,false,"deco/character/ju",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"ju"}, get);
tb[409202] = P({D[17044], 409202,1,4,409,"「とある都市伝説をご存知ですか？\n『クラウンのメイクに隠された本当の顔は絶対に見てはいけない。さもないとクラウンの世界に閉じ込められてしまう。そう、永遠に……』\n「ふ、フフフ。そんな顔をしないでください。都市伝説を実際の出来事にしたい人が出て来るのは自然なことでしょう。\nさて……親愛なる雀士様、クラウンの世界へようこそ。……もう、逃げられませんよ？」",200092,1,"deco/character/ju_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"ju_0"}, get);
tb[409203] = P({D[17044], 409203,6,107,410,"「ドッカーン！\nくくっ……花火の音は、実に心地良いものですねぇ。\n人々は『また一年無事に過ごせてハッピー』な～んて浮かれておいでのようで。\nどなた様もまぁ嬉しそうに……実にくだらないですよ。\n……あぁ、そう構えないでください。スペシャルゲストであるあなたがこうしてお見えになったことですし、クラウンとしてきっちりおもてなしいたしましょう。\n本物の『お祭り騒ぎ』とやらをお知りになりたいのであれば、ぜひその足で、絵の中へとおいでください。」",200092,2,"deco/character/ju_cj",false,false,1,false,false,false,false,"1",0,1,4665,5000,2274,4756,5333,6900,7599,7266,12400,8000,2666,"ju_cj"}, get);