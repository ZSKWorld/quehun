-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[409301] = P({D[46057], 409301,false,174,411,false,200093,false,"deco/character/laiya",302002,60,false,false,false,false,-160,"1",false,false,false,false,false,false,false,"0,340,0.97","-60,0,1","-20,0,1",false,false,false,"-80,0,1","-40,-20,1",false,false,"-30,-40,1",1890,824,398,1226,746,1808,3018,1226,746,1808,1037,"laiya"}, get);
tb[409302] = P({D[17034], 409302,1,4,412,"「そう。君がありったけの知恵を絞った末に考えた言い訳がそれなのね。\n……そこまで考えたところ残念だけど、ダ・メ。\n私を説得したいのなら、もっと頑張ってもらわないとね。」",200093,1,"deco/character/laiya_0",302002,60,false,false,false,false,false,"1",1941,944,390,897,385,2389,2877,897,638,2389,false,false,false,false,false,false,false,false,false,false,false,false,false,"laiya_0"}, get);
tb[409303] = P({D[12044], 409303,12,88,413,"「私の蒐集室へようこそ。本当に好奇心旺盛ね……そういう子、先生は嫌いじゃないわ。気になるものがあったら教えて、じっくり解説してあげる。部屋の主の方が気になる？わがままな子も、教育しがいがあって好きよ。」",200093,2,"deco/character/laiya_LF",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"laiya_lf"}, get);
tb[409401] = P({D[46057], 409401,false,175,414,false,200094,false,"deco/character/xinxiya",302002,60,1,false,false,false,-90,"1",false,false,false,false,false,false,false,"0,390,0.98",false,false,false,false,false,"-60,20,1","-40,0,1",false,false,"-20,-20,1",1860,841,398,1635,761,1246,2944,1635,761,1246,1039,"xinxiya"}, get);
tb[409402] = P({D[17034], 409402,1,4,415,"「ちょっとこっちに来て、もう少し。そう、そのままで。この距離だったら、あなたの顔がよく見えるから。\n今日の撮影には、『優しく微笑んで』ってオーダーがきてるの。\nあなたがよく見えないと、良い表情が出せない気がしてね」",200094,1,"deco/character/xinxiya_0",302002,60,1,false,false,false,false,"",1957,916,398,406,141,3301,3661,606,614,2901,false,false,false,false,false,false,false,false,false,false,false,false,false,"xinxiya_0"}, get);
tb[409403] = P({D[9044], 409403,13,57,416,"「ここの温泉は、疲労回復の効能があって、美肌効果もかなりあるって、モデル仲間によくおすすめされるの。ほら、あなた、最近疲れてるでしょ。いい機会だし、一緒に温泉の効果を確かめましょう。」",200094,2,"deco/character/xinxiya_WQ",0,false,false,false,false,false,false,false,false,false,false,false,false,"xinxiya_wq"}, get);
tb[409501] = P({D[25034], 409501,false,176,417,false,200095,false,"deco/character/nanfenghua",302002,60,false,false,false,false,-90,"1",false,false,false,false,false,false,false,"140,350,1",1922,840,398,1209,667,1643,2976,1209,667,1643,1132}, get);
tb[409502] = P({D[24034], 409502,1,4,418,"「鳳凰が止まり木を選ぶように、あたくしも近くに置く人間をよく選んでおりますの。\nあなたには色々任せていますし、今後も全幅の信頼を寄せるつもりでいてよ。\nですから、あまり考え過ぎずに、思う存分腕をお振るいあそばせ」",200095,1,"deco/character/nanfenghua_0",302002,60,1,false,false,false,false,"1",false,false,"-160,0,1",false,"-160,0,1","-260,-120,1","-160,0,1",2100,819,398,443,164,3149,3398,567,517,2901,false,2,4643,5000,1745,5025,8000,14333,8000,13333,13000,12000,8000}, get);
tb[409601] = P({D[25033], 409601,false,177,419,false,200096,false,"deco/character/feiming",302002,60,false,false,false,false,-120,"1",false,false,false,false,false,false,false,"0,380,0.93","0,-40,1",1813,833,390,1312,741,1222,3038,1312,741,1222,1047}, get);
tb[409602] = P({D[24034], 409602,1,4,420,"「ええ酒はあらへんけど、こないな月夜にぴったりなお茶なら、ええもんがありますよ。\n……なんや、えらい嬉しそうやって？　……まぁ、そうかもしれへんなあ。\nお茶も景色も、一緒に味わう人がおってこそ、えも言われぬ風情を感じられるんやろうなあ。」",200096,1,"deco/character/feiming_0",302002,60,false,false,false,false,false,"1",false,"0,540,0.95","-50,540,0.95",false,"-50,540,0.95","-50,540,0.95","50,520,0.95",1825,1397,390,534,307,2799,3691,534,1091,2799}, get);
tb[409701] = P({D[17044], 409701,false,178,421,false,200097,false,"deco/character/sataen",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"sataen"}, get);
tb[409702] = P({D[17044], 409702,1,4,422,"「この銃創は、奴らからのメッセージだ。『死にかけの信者は、いくら敬虔であっても神の捨て駒に過ぎない。』\n……今は、私が北国全体をチェスボードにする番だ。キングにチェックメイトをかけるに最も効果的なやり方、それは攻め続けることではなく、相手に自分がすべてを掌握していると勘違いさせること。\nそうだ、次の手は君の判断に任せよう。氷山を切り崩す決めの一手にしてみせるよ」",200097,1,"deco/character/sataen_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"sataen_0"}, get);
tb[409703] = P({D[9044], 409703,12,179,423,"「輝く宝石はこれまで数え切れぬほど見てきたが、光が君を照らした瞬間思ったよ、やっと手にしたい一粒を見つけた、とね。\nさぁ、こちらまで来なさい。頂から見る景色こそ、あなたのその輝きにふさわしい。」",200097,2,"deco/character/sataen_LF",0,false,false,false,false,false,false,false,false,false,false,false,false,"sataen_lf"}, get);
tb[409801] = P({D[46057], 409801,false,180,424,false,200098,false,"deco/character/huayuqing",302002,60,false,false,false,false,false,"1",false,"0,-10,1","0,-10,1",false,"0,-10,1","0,-10,1","0,-10,1","0,40,1",false,false,false,false,false,"-20,-50,1","-20,-50,1",false,false,"-20,-70,1",1833,834,390,1038,737,1658,2569,1038,737,1658,1052,"huayuqing"}, get);