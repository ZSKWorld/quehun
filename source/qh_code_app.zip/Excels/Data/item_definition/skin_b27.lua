-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[409103] = P({D[9057], 409103,20,90,409,"「『Soul』のオフに、一緒にジョギングできてよかった。ありがとう。\n長い距離を走って疲れたでしょう。バテる前に水分とって。\nあれ、ボトル持ってきてないの？\nじゃあ……あんたがいいなら、私の、飲んでもいいよ。」",200091,2,"deco/character/xili_yh","xili_yh"}, get);
tb[409201] = P({D[17057], 409201,false,174,410,false,200092,false,"deco/character/ju",302002,60,false,false,false,false,false,"1","ju"}, get);
tb[409202] = P({D[17057], 409202,1,4,411,"「とある都市伝説をご存知ですか？\n『クラウンのメイクに隠された本当の顔は絶対に見てはいけない。さもないとクラウンの世界に閉じ込められてしまう。そう、永遠に……』\n「ふ、フフフ。そんな顔をしないでください。都市伝説を実際の出来事にしたい人が出て来るのは自然なことでしょう。\nさて……親愛なる雀士様、クラウンの世界へようこそ。……もう、逃げられませんよ？」",200092,1,"deco/character/ju_0",302002,60,false,false,false,false,false,"1","ju_0"}, get);
tb[409203] = P({D[17045], 409203,6,108,412,"「ドッカーン！\nくくっ……花火の音は、実に心地良いものですねぇ。\n人々は『また一年無事に過ごせてハッピー』な～んて浮かれておいでのようで。\nどなた様もまぁ嬉しそうに……実にくだらないですよ。\n……あぁ、そう構えないでください。スペシャルゲストであるあなたがこうしてお見えになったことですし、クラウンとしてきっちりおもてなしいたしましょう。\n本物の『お祭り騒ぎ』とやらをお知りになりたいのであれば、ぜひその足で、絵の中へとおいでください。」",200092,2,"deco/character/ju_cj",false,false,1,false,false,false,false,"1",1,4665,5000,2274,4756,5333,6900,7599,7266,12400,8000,2666,"ju_cj"}, get);
tb[409301] = P({D[46057], 409301,false,175,413,false,200093,false,"deco/character/laiya",302002,60,false,false,false,false,-160,"1",false,false,false,false,false,false,false,"0,340,0.97","-60,0,1","-20,0,1",false,false,false,"-80,0,1","-40,-20,1",false,false,"-30,-40,1",1890,824,398,1226,746,1808,3018,1226,746,1808,1037,"laiya"}, get);
tb[409302] = P({D[17034], 409302,1,4,414,"「そう。君がありったけの知恵を絞った末に考えた言い訳がそれなのね。\n……そこまで考えたところ残念だけど、ダ・メ。\n私を説得したいのなら、もっと頑張ってもらわないとね。」",200093,1,"deco/character/laiya_0",302002,60,false,false,false,false,false,"1",1941,944,390,897,385,2389,2877,897,638,2389,1261,false,false,false,false,false,false,false,false,false,false,false,false,"laiya_0"}, get);
tb[409303] = P({D[12057], 409303,12,89,415,"「私の蒐集室へようこそ。本当に好奇心旺盛ね……そういう子、先生は嫌いじゃないわ。気になるものがあったら教えて、じっくり解説してあげる。部屋の主の方が気になる？わがままな子も、教育しがいがあって好きよ。」",200093,2,"deco/character/laiya_LF",false,false,1,"laiya_lf"}, get);
tb[409304] = P({D[9045], 409304,2,72,416,"tbd",200093,2,"deco/character/409304",1,4625,5000,2378,4030,5333,4666,6000,4433,8000,8000,5333,"laiya_xr"}, get);
tb[409401] = P({D[46057], 409401,false,176,417,false,200094,false,"deco/character/xinxiya",302002,60,1,false,false,false,-90,"1",false,false,false,false,false,false,false,"0,390,0.98",false,false,false,false,false,"-60,20,1","-40,0,1",false,false,"-20,-20,1",1860,841,398,1635,761,1246,2944,1635,761,1246,1039,"xinxiya"}, get);
tb[409402] = P({D[17034], 409402,1,4,418,"「ちょっとこっちに来て、もう少し。そう、そのままで。この距離だったら、あなたの顔がよく見えるから。\n今日の撮影には、『優しく微笑んで』ってオーダーがきてるの。\nあなたがよく見えないと、良い表情が出せない気がしてね」",200094,1,"deco/character/xinxiya_0",302002,60,1,false,false,false,false,"",1957,916,398,406,141,3301,3661,606,614,2901,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xinxiya_0"}, get);
tb[409403] = P({D[9057], 409403,13,57,419,"「ここの温泉は、疲労回復の効能があって、美肌効果もかなりあるって、モデル仲間によくおすすめされるの。ほら、あなた、最近疲れてるでしょ。いい機会だし、一緒に温泉の効果を確かめましょう。」",200094,2,"deco/character/xinxiya_WQ","xinxiya_wq"}, get);
tb[409501] = P({D[25034], 409501,false,177,420,false,200095,false,"deco/character/nanfenghua",302002,60,false,false,false,false,-90,"1",false,false,false,false,false,false,false,"140,350,1",1922,840,398,1209,667,1643,2976,1209,667,1643,1132}, get);
tb[409502] = P({D[24034], 409502,1,4,421,"「鳳凰が止まり木を選ぶように、あたくしも近くに置く人間をよく選んでおりますの。\nあなたには色々任せていますし、今後も全幅の信頼を寄せるつもりでいてよ。\nですから、あまり考え過ぎずに、思う存分腕をお振るいあそばせ」",200095,1,"deco/character/nanfenghua_0",302002,60,1,false,false,false,false,"1",false,false,"-160,0,1",false,"-160,0,1","-260,-120,1","-160,0,1",2100,819,398,443,164,3149,3398,567,517,2901,1261,2,4643,5000,1745,5025,8000,14333,8000,13333,13000,12000,8000}, get);
tb[409601] = P({D[25033], 409601,false,178,422,false,200096,false,"deco/character/feiming",302002,60,false,false,false,false,-120,"1",false,false,false,false,false,false,false,"0,380,0.93","0,-40,1",1813,833,390,1312,741,1222,3038,1312,741,1222,1047}, get);