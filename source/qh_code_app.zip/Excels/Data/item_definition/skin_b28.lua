-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[409802] = P({D[23034], 409802,1,4,425,"「はーやーくー！ せっかくお姉ちゃんを説得して、あなたにお化粧してもらえることになったのにー。もたもたしてたら開演時間になっちゃうよ！\nえっ、この前は上手くできなかったから自信がない？\nもー、数をこなして慣れるしかないし、こういう機会には目一杯やらなきゃ！\nそれに、あなたが一生懸命わたしに化粧してる時の顔、すっごく好きだから、もっとたくさん見たいしね♪」",200098,1,"deco/character/huayuqing_0",302002,60,false,false,1,false,false,"1",false,false,"-340,0,1",false,"-340,0,1","-340,0,1",2385,987,390,746,873,2328,2014,746,873,2328,1069,false,false,false,false,false,false,false,false,false,false,false,false,"huayuqing_0"}, get);
tb[409803] = P({D[9044], 409803,12,179,426,"「おや～、そこのお客さん？ 怪盗の正体は、絶対にバレちゃいけない秘密なんだ～。\nこうなったらわたしと共犯になるか、今夜の月明かりに消えてもらうしかないね～？\n……なーんてねっ、くすくすっ。\n全部演技だし、そう緊張しないでってば。今日は新作の劇のインスピレーションを得るために、ゲスト出演してるだけなの。\nさて、そろそろ戻るから、わたしの活躍、よ～～く目に焼き付けてね！」",200098,2,"deco/character/huayuqing_LF",0,1,4206,5000,2160,2472,3000,10300,10600,6533,14917,8000,3000,"huayuqing_lf"}, get);
tb[409901] = P({D[46057], 409901,false,181,427,false,200099,false,"deco/character/huayubai",302002,60,false,false,false,false,-30,"1",false,"0,-10,1","0,-10,1",false,"0,-10,1","0,-10,1","-140,-10,1","0,50,1","-190,-20,1","-140,-20,1",false,false,"-170,-20,1","-180,-60,1","-180,-60,1",false,false,"-170,-90,1",1989,818,390,1015,721,1985,2605,1015,721,1985,1052,"huayubai"}, get);
tb[409902] = P({D[45057], 409902,1,4,428,"「今日は化粧班に欠員が出てしまって、君まで駆り出す事態になってしまったわ。本当にごめんなさい。\n私はもうすぐ出来上がるけど、そうね……腰の帯を締めていただけるかしら。\nあ、そうだ、口紅がまだだったわね。もしよかったら、後でお願いしても良いかしら？」",200099,1,"deco/character/huayubai_0",302002,60,false,false,false,false,false,"1",false,"50,0,1",false,false,false,false,"0,40,1",false,false,false,false,false,false,false,false,false,false,false,1676,994,390,646,464,2654,2510,646,688,2654,"huayubai_0"}, get);
tb[409903] = P({D[9044], 409903,12,179,429,"「あなたが付き添いを引き受けてくださったおかげで、このどうしても断りきれなかった立食パーティーも、多少気が楽になりました。\n……とはいえ、今のような二人きりの方が、やはり居心地がいいものですね。\n静かに過ごすこの時間は、お芝居のハッピーエンドよりも……ずっと、真実味がありますから。」",200099,2,"deco/character/huayubai_LF",0,1,3938,5000,1850,3905,5333,8166,9333,8666,14067,8000,2666,"huayubai_lf"}, get);
tb[40010001] = P({D[25034], 40010001,false,182,430,false,20000100,false,"deco/character/qiancangtou",302002,60,1,false,1,false,-60,"1",false,"80,0,1","80,0,1",false,"80,0,1","80,0,1","80,0,1","70,70,1",1783,853,393,1576,736,820,2575,1576,736,820,1074}, get);
tb[40010002] = P({D[19034], 40010002,1,4,431,false,20000100,1,"deco/character/qiancangtou_0",302002,60,false,false,1,false,false,"1",false,"100,0,1",1782,833,398,851,352,2518,3047,851,531,2518}, get);
tb[40010003] = P({D[24034], 40010003,999,183,432,false,20000100,3,"deco/character/qiancangtou_ol",false,false,1,false,1,false,false,"1",false,"0,40,1","-60,40,1","240,-40,0.97","0,40,1","-60,40,1","-60,40,1",1937,907,398,774,409,2532,2865,774,605,2532}, get);
tb[40010101] = P({D[25034], 40010101,false,184,433,false,20000101,false,"deco/character/tongkouyuanxiang",302002,60,1,false,1,false,-80,"1",false,false,false,false,false,false,false,"70,70,1",1840,851,398,1633,684,782,2619,1633,684,782,1126}, get);
tb[40010102] = P({D[19034], 40010102,1,4,434,false,20000101,1,"deco/character/tongkouyuanxiang_0",302002,60,1,false,1,false,false,"1",false,"160,0,1",1759,849,398,969,362,2288,2453,969,547,2288}, get);
tb[40010103] = P({D[24034], 40010103,999,183,435,false,20000101,3,"deco/character/tongkouyuanxiang_ol",false,false,1,false,1,false,false,"1",false,"0,30,1","0,30,1","240,-80,1","0,30,1","0,30,1","-100,30,1",1947,892,395,981,834,2229,2210,981,834,2229,1016}, get);
tb[40010201] = P({D[25034], 40010201,false,185,436,false,20000102,false,"deco/character/fuwanxiaosi",302002,60,false,false,1,false,160,"1",false,false,false,false,false,false,false,"70,-70,1",1934,1025,398,1485,920,1054,2224,1485,920,1054,1064}, get);
tb[40010202] = P({D[24034], 40010202,1,4,437,false,20000102,1,"deco/character/fuwanxiaosi_0",302002,60,1,false,1,false,false,"1",false,"0,40,1","-100,40,1",false,"-100,40,1","-100,40,1","-100,40,1",1949,914,398,939,363,2310,2631,939,612,2310}, get);
tb[40010203] = P({D[24034], 40010203,999,183,438,false,20000102,3,"deco/character/fuwanxiaosi_ol",false,false,1,false,1,false,false,"1",false,"0,60,1","-140,60,1","240,-180,1","-140,60,1","-140,60,1","-140,60,1",1978,976,398,996,689,2089,2206,996,689,2089,1246}, get);
tb[40010301] = P({D[25034], 40010301,false,186,439,false,20000103,false,"deco/character/shichuanchucai",302002,60,1,false,1,false,-70,"1",false,"100,0,1","100,0,1",false,"100,0,1","100,0,1","100,0,1","100,80,1",1762,802,398,1525,736,994,2645,1525,736,994,1025}, get);