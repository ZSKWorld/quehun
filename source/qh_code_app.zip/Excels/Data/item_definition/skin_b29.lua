-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[40010302] = P({D[24034], 40010302,1,4,440,false,20000103,1,"deco/character/shichuanchucai_0",302002,60,1,false,1,false,false,"1",false,"0,150,1","0,150,1",false,"0,150,1","0,150,1","0,150,1",1732,1056,431,1151,112,1983,3111,1151,771,1983}, get);
tb[40010303] = P({D[24034], 40010303,999,183,441,false,20000103,3,"deco/character/shichuanchucai_ol",false,false,1,false,1,false,false,"1",false,"20,20,1","0,20,1","240,50,0.89","0,20,1","0,20,1","0,20,1",1794,836,417,812,578,2277,3040,812,578,2277,1227}, get);
tb[40010601] = P({D[17044], 40010601,false,187,442,false,20000106,false,"deco/character/jian",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jian"}, get);
tb[40010602] = P({D[17044], 40010602,1,4,443,"「事件現場に君の足跡があったのよ？　素直に認めれば、情状酌量の余地がまだあるかもしれないわ。はやく白状することね！　\n……くっくっく、今の、どうだった？　この名探偵ジェーンの真に迫った口ぶりに身が震えたでしょう？」",20000106,1,"deco/character/jian_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jian_0"}, get);
tb[40010603] = P({D[9044], 40010603,21,20,444,"「ピピーッ！\nいい？ この名探偵ジェーンが、真実を見通す目で全てを公正にジャッジしてあげる！\n助手さんの勝利を阻まんと工作する者、不正を目論む不届き者は全部捕まえてやるんだから！\nさぁ、思い切ってやってきなさい！」",20000106,2,"deco/character/jian_ydh",0,false,false,false,false,false,false,false,false,false,false,false,false,"jian_ydh"}, get);
tb[40010701] = P({D[46057], 40010701,false,188,445,false,20000107,false,"deco/character/yuanxiao",302002,60,false,false,1,false,-30,"1",false,false,false,false,false,false,false,"0,50,1",false,false,false,false,false,false,false,false,false,"0,-30,1",false,false,false,false,false,false,false,false,false,false,0,"yuanxiao"}, get);
tb[40010702] = P({D[24044], 40010702,1,4,446,"「お、お人好し君！？ なんでここに！？\n今のは、ほんとに、たまたま、うっかり転んだだけだから！ 絶対誰にも言わないでね！\nだから、もう笑わないでって！ パンダだって木から落ちることあるんだよ？\nお茶をこぼすことくらい、どうってことないもん……！」",20000107,1,"deco/character/yuanxiao_0",302002,60,false,false,1,false,false,"1",false,false,"-50,0,1",false,"-50,0,1","-50,0,1","-50,0,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yuanxiao_0"}, get);
tb[40010703] = P({D[9044], 40010703,19,39,447,"「ふん！ やっ！ 四風連打ぁ！\nねえ、お人好し君も、この役名って拳法の名前に似てると思うでしょ？\nそこで、功夫の要領で拳法を考えてみたんだけど、どうかなあ？」",20000107,2,"deco/character/yuanxiao_gf",0,1,4625,5000,2378,4030,5333,4666,6000,4433,11017,8000,5333,"yuanxiao_gf"}, get);
tb[40010801] = P({D[17044], 40010801,false,189,448,false,20000108,false,"deco/character/jiantongying",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiantongying"}, get);
tb[40010802] = P({D[17044], 40010802,1,4,449,false,20000108,1,"deco/character/jiantongying_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiantongying_0"}, get);
tb[40010803] = P({D[17044], 40010803,999,190,450,false,20000108,3,"deco/character/jiantongying_hf",false,false,false,false,1,false,false,"1",0,1,5000,5000,2668,6044,8000,9333,10266,8000,18000,8000,8000,"jiantongying_1"}, get);
tb[40010901] = P({D[17044], 40010901,false,191,451,false,20000109,false,"deco/character/yuanbanlin",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yuanbanlin"}, get);
tb[40010902] = P({D[17044], 40010902,1,4,452,false,20000109,1,"deco/character/yuanbanlin_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yuanbanlin_0"}, get);
tb[40010903] = P({D[17044], 40010903,999,190,453,false,20000109,3,"deco/character/yuanbanlin_hf",false,false,false,false,1,false,false,"1",0,1,5286,5000,2779,5093,5333,5000,11766,4000,10000,8000,5333,"yuanbanlin_1"}, get);
tb[40011001] = P({D[17044], 40011001,false,192,454,false,20000110,false,"deco/character/saber",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"aertuoliya"}, get);
tb[40011002] = P({D[17044], 40011002,1,4,455,false,20000110,1,"deco/character/saber_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"aertuoliya_0"}, get);
tb[40011003] = P({D[17044], 40011003,999,190,456,false,20000110,3,"deco/character/saber_hf",false,false,false,false,1,false,false,"1",0,1,5245,5000,2504,6039,8000,8466,6933,5400,12000,8000,2666,"aertuoliya_1"}, get);
tb[40011101] = P({D[17044], 40011101,false,193,457,false,20000111,false,"deco/character/archer",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yinglingweigong"}, get);
tb[40011102] = P({D[17044], 40011102,1,4,458,false,20000111,1,"deco/character/archer_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yinglingweigong_0"}, get);
tb[40011103] = P({D[17044], 40011103,999,190,459,false,20000111,3,"deco/character/archer_hf",false,false,false,false,1,false,false,"1",0,1,5523,5000,3032,2920,64000,20233,22400,21400,12000,8000,16000,"yinglingweigong_1"}, get);
tb[40011201] = P({D[17044], 40011201,false,194,460,false,20000112,false,"deco/character/liyang",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"liyang"}, get);
tb[40011202] = P({D[17044], 40011202,1,4,461,"「人間の両足って素晴らしいわよね、さっと足を引っ掛けたりもできるし、獲物を踏んで逃がさないようにもできるもの。とはいえ、確実に獲物を絞め上げるには、やはり蛇の尾の方が使いやすいわ。……それで、あなたは今夜、どんな風に捕えられたいのかしら？」",20000112,1,"deco/character/liyang_0",302002,60,false,false,false,false,false,"1",0,2,4657,5000,2421,3923,3333,10000,6666,8000,12000,6666,false,"liyang_0"}, get);
tb[40011203] = P({D[17044], 40011203,998,195,462,"「蛇は本来、こういう月が明るい夜には求愛の舞なんてしないのよ。これはあくまで予行演習……\nしかし、あなたは見てしまった。可愛いあなたであっても、罰を与えなくてはね。\nそうね……では、あなたのために準備していたこの儀式を、前もって味わわせてあげようかしら？」",20000112,2,"deco/character/liyang_1",false,false,false,false,false,false,false,"1",0,2,5318,5000,2715,4510,3333,8000,8000,8000,18400,8000,8000,"liyang_1"}, get);