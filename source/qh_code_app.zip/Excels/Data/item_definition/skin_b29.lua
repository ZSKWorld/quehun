-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[40010002] = P({D[19034], 40010002,1,4,434,false,20000100,1,"deco/character/qiancangtou_0",302002,60,false,false,1,false,false,"1",false,"100,0,1",1782,833,398,851,352,2518,3047,851,531,2518,1261}, get);
tb[40010003] = P({D[24034], 40010003,999,184,435,false,20000100,3,"deco/character/qiancangtou_ol",false,false,1,false,1,false,false,"1",false,"0,40,1","-60,40,1","240,-40,0.97","0,40,1","-60,40,1","-60,40,1",1937,907,398,774,409,2532,2865,774,605,2532,1261}, get);
tb[40010101] = P({D[25034], 40010101,false,185,436,false,20000101,false,"deco/character/tongkouyuanxiang",302002,60,1,false,1,false,-80,"1",false,false,false,false,false,false,false,"70,70,1",1840,851,398,1633,684,782,2619,1633,684,782,1126}, get);
tb[40010102] = P({D[19034], 40010102,1,4,437,false,20000101,1,"deco/character/tongkouyuanxiang_0",302002,60,1,false,1,false,false,"1",false,"160,0,1",1759,849,398,969,362,2288,2453,969,547,2288,1261}, get);
tb[40010103] = P({D[24034], 40010103,999,184,438,false,20000101,3,"deco/character/tongkouyuanxiang_ol",false,false,1,false,1,false,false,"1",false,"0,30,1","0,30,1","240,-80,1","0,30,1","0,30,1","-100,30,1",1947,892,395,981,834,2229,2210,981,834,2229,1016}, get);
tb[40010201] = P({D[25034], 40010201,false,186,439,false,20000102,false,"deco/character/fuwanxiaosi",302002,60,false,false,1,false,160,"1",false,false,false,false,false,false,false,"70,-70,1",1934,1025,398,1485,920,1054,2224,1485,920,1054,1064}, get);
tb[40010202] = P({D[24034], 40010202,1,4,440,false,20000102,1,"deco/character/fuwanxiaosi_0",302002,60,1,false,1,false,false,"1",false,"0,40,1","-100,40,1",false,"-100,40,1","-100,40,1","-100,40,1",1949,914,398,939,363,2310,2631,939,612,2310,1261}, get);
tb[40010203] = P({D[24034], 40010203,999,184,441,false,20000102,3,"deco/character/fuwanxiaosi_ol",false,false,1,false,1,false,false,"1",false,"0,60,1","-140,60,1","240,-180,1","-140,60,1","-140,60,1","-140,60,1",1978,976,398,996,689,2089,2206,996,689,2089,1246}, get);
tb[40010301] = P({D[25034], 40010301,false,187,442,false,20000103,false,"deco/character/shichuanchucai",302002,60,1,false,1,false,-70,"1",false,"100,0,1","100,0,1",false,"100,0,1","100,0,1","100,0,1","100,80,1",1762,802,398,1525,736,994,2645,1525,736,994,1025}, get);
tb[40010302] = P({D[24034], 40010302,1,4,443,false,20000103,1,"deco/character/shichuanchucai_0",302002,60,1,false,1,false,false,"1",false,"0,150,1","0,150,1",false,"0,150,1","0,150,1","0,150,1",1732,1056,431,1151,112,1983,3111,1151,771,1983,1261}, get);
tb[40010303] = P({D[24034], 40010303,999,184,444,false,20000103,3,"deco/character/shichuanchucai_ol",false,false,1,false,1,false,false,"1",false,"20,20,1","0,20,1","240,50,0.89","0,20,1","0,20,1","0,20,1",1794,836,417,812,578,2277,3040,812,578,2277,1227}, get);
tb[40010601] = P({D[17057], 40010601,false,188,445,false,20000106,false,"deco/character/jian",302002,60,false,false,false,false,false,"1","jian"}, get);
tb[40010602] = P({D[17057], 40010602,1,4,446,"「事件現場に君の足跡があったのよ？　素直に認めれば、情状酌量の余地がまだあるかもしれないわ。はやく白状することね！　\n……くっくっく、今の、どうだった？　この名探偵ジェーンの真に迫った口ぶりに身が震えたでしょう？」",20000106,1,"deco/character/jian_0",302002,60,false,false,false,false,false,"1","jian_0"}, get);
tb[40010603] = P({D[9057], 40010603,21,20,447,"「ピピーッ！\nいい？ この名探偵ジェーンが、真実を見通す目で全てを公正にジャッジしてあげる！\n助手さんの勝利を阻まんと工作する者、不正を目論む不届き者は全部捕まえてやるんだから！\nさぁ、思い切ってやってきなさい！」",20000106,2,"deco/character/jian_ydh","jian_ydh"}, get);
tb[40010701] = P({D[35057], 40010701,false,189,448,false,20000107,false,"deco/character/yuanxiao",302002,60,false,false,1,false,-30,"1",false,false,false,false,false,false,false,"0,50,1",false,false,false,false,false,false,false,false,false,"0,-30,1","yuanxiao"}, get);
tb[40010702] = P({D[24057], 40010702,1,4,449,"「お、お人好し君！？ なんでここに！？\n今のは、ほんとに、たまたま、うっかり転んだだけだから！ 絶対誰にも言わないでね！\nだから、もう笑わないでって！ パンダだって木から落ちることあるんだよ？\nお茶をこぼすことくらい、どうってことないもん……！」",20000107,1,"deco/character/yuanxiao_0",302002,60,false,false,1,false,false,"1",false,false,"-50,0,1",false,"-50,0,1","-50,0,1","-50,0,1","yuanxiao_0"}, get);
tb[40010703] = P({D[9045], 40010703,19,39,450,"「ふん！ やっ！ 四風連打ぁ！\nねえ、お人好し君も、この役名って拳法の名前に似てると思うでしょ？\nそこで、功夫の要領で拳法を考えてみたんだけど、どうかなあ？」",20000107,2,"deco/character/yuanxiao_gf",1,4625,5000,2378,4030,5333,4666,6000,4433,11017,8000,5333,"yuanxiao_gf"}, get);
tb[40010704] = P({D[9045], 40010704,2,72,451,"tbd",20000107,2,"deco/character/40010704",1,4625,5000,2378,4030,5333,4666,6000,4433,8000,8000,5333,"yuanxiao_xr"}, get);
tb[40010801] = P({D[17057], 40010801,false,190,452,false,20000108,false,"deco/character/jiantongying",302002,60,false,false,1,false,false,"1","jiantongying"}, get);
tb[40010802] = P({D[17057], 40010802,1,4,453,false,20000108,1,"deco/character/jiantongying_0",302002,60,false,false,1,false,false,"1","jiantongying_0"}, get);
tb[40010803] = P({D[17045], 40010803,999,191,454,false,20000108,3,"deco/character/jiantongying_hf",false,false,false,false,1,false,false,"1",1,5000,5000,2668,6044,8000,9333,10266,8000,18000,8000,8000,"jiantongying_1"}, get);
tb[40010901] = P({D[17057], 40010901,false,192,455,false,20000109,false,"deco/character/yuanbanlin",302002,60,false,false,1,false,false,"1","yuanbanlin"}, get);