-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[400505] = P({D[23034], 400505,3,27,32,"「え、獲物、ですか？　舞のことはいつでも旦那様の思うままに……。違う？　旦那様の方が、獲物？　それはちょっと予想外でした……。で、では、旦那様。舞から……舞から行きますね……！」",200005,2,"deco/character/xiangyuanwu_WS",false,false,1,false,false,false,false,false,false,false,false,false,"-280,0,1","-270,0,1",2162,898,380,1017,802,2077,2184,1017,802,2077,1046,1,3330,5000,1705,3209,6666,6666,6666,6666,10000,8000,6666,"xiangyuanwu_ws"}, get);
tb[400506] = P({D[24034], 400506,13,28,33,"「すみません、こんなはしたない姿をお見せしてしまい……そ、それより、ここの温泉は、心身を清め、霊力を高める効果があるそうです。牌運の向上にも繋がるかも……なので、旦那様も、試してみませんか？」",200005,2,"deco/character/xiangyuanwu_WQ",false,false,1,false,false,false,false,"1",false,"0,50,0.96","0,50,0.96","220,-220,1","0,50,0.96","0,50,0.96","0,0,0.96",1832,856,380,564,276,2981,2606,604,545,2901,1261,1,4520,5000,2367,2757,8000,false,13000,10666,15000,8000,8000,"xiangyuanwu_wq"}, get);
tb[400507] = P({D[21034], 400507,999,29,34,false,200005,3,"deco/character/xiangyuanwu_SLO",false,false,false,false,1,false,false,"1",false,false,false,"240,-280,1",1868,872,398,948,421,2439,2393,948,570,2439,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiangyuanwu_slo"}, get);
tb[400508] = P({D[17045], 400508,5,30,35,"「あけましておめでとうございます、旦那様。\n舞、今年は伊達巻きも手作りしてみました。最初の一口は、ぜひ旦那様に……。\nど、どうでしょうか？ お口に合いましたか？\n……良かったです。初めてだったので、失敗していないかずっと心配で……無事に出来上がったみたいで、安心しました。\nこ、これからも、新年にはこうして、旦那様におせちを用意して差し上げたいです。」",200005,2,"deco/character/xiangyuanwu_yd",false,false,false,false,false,false,false,"",1,3164,5000,1627,3067,8000,8666,16666,5500,14000,8000,8000,"xiangyuanwu_yd"}, get);
tb[400601] = P({D[16023], 400601,false,31,36,false,200006,false,"deco/character/fuzi",302002,60,false,false,false,false,-97,"50,260,0.98","50,-40,1","60,-30,1",false,false,false,"40,-30,1","0,-30,1",false,false,false,1788,780,400,1313,701,1800,2846,1313,701,1800,1039}, get);
tb[400602] = P({D[11034], 400602,1,4,37,"「バイクでツーリングに行くか、マンツーマンの麻雀コーチングか、選びな。」",200006,1,"deco/character/fuzi_0",302002,60,1969,830,400,647,743,2373,3114,833,743,2001,1047}, get);
tb[400603] = P({D[12034], 400603,2,5,38,false,200006,2,"deco/character/fuzi_haitanpaidui",false,false,1,1990,933,400,1086,817,2195,2086,1086,817,2195,1076}, get);
tb[400604] = P({D[9034], 400604,5,32,39,"「あたしが着物を着たくらいでそんなに驚くことか？　それとも何、似合わないとでも言いたいわけ？　……ふふっ、せっかくの正月だ、そんなに固くなりなさんな。ちゃんとお参りした後でツーリングに連れてってやるから、な？」",200006,2,"deco/character/fuzi_XN",1941,867,376,933,672,2340,2838,933,672,2340,1143}, get);
tb[400605] = P({D[22034], 400605,14,33,40,"「あんた達、サクサク働きな！　今夜の宴会に間に合うかは全部あんたらにかかってるんだよ！」",200006,2,"deco/character/fuzi_YSJ",false,false,false,false,false,false,false,"1",false,false,false,"80,80,0.86","0,0,0.99",1910,848,380,295,227,3526,3914,607,537,2902,1261}, get);
tb[400606] = P({D[21034], 400606,9,34,41,"「コントローラーはそっちにもあるから、適当に座って。全クリまでは……思ったよりあるね。これはそこそこ頑張ってもらわないとね、ダーリン。大丈夫、詰んだらあたしも手伝ってあげるから。それとも先に何か飲むか？」",200006,2,"deco/character/fuzi_SY",false,false,false,false,false,false,false,"1",false,false,false,"240,-240,1",1872,861,399,954,284,2481,2708,954,560,2481,1261}, get);
tb[400701] = P({D[46057], 400701,false,35,42,false,false,false,"deco/character/bamuwei",302002,60,false,false,false,false,23,false,false,false,false,false,false,false,false,"0,60,1.01","-50,10,1","60,10,1",false,false,false,"-20,10,1","-10,10,1",false,false,false,1860,898,400,1504,784,1080,2512,1504,784,1080,1074,"bamuwei",1}, get);
tb[400702] = P({D[11034], 400702,1,4,43,"「先輩、ブランコ、乗ってみる？\nブランコに乗ってる先輩の顔、面白い。写真、撮った」",false,1,"deco/character/bamuwei_0",302002,60,1764,898,430,1112,320,2008,2672,1112,612,2008,1261,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_0"}, get);
tb[400703] = P({D[12034], 400703,4,16,44,"「先輩……ずっと私の脚を見てる……やはり脚フェチ？　じゃあ……一番好きなのは白スト？　黒スト？　それとも裸足がいい？」",false,2,"deco/character/bamuwei_SDJ",false,false,1,1907,920,400,1246,643,1554,2316,1246,643,1554,1237,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_sd"}, get);
tb[400704] = P({D[18034], 400704,3,36,45,"「飛んで、蝶たちよ――あの人を連れて私の元に戻ってきて。」",false,2,"deco/character/bamuwei_WSJ",false,false,false,false,false,false,false,false,"2020-10-29 05:00:00+08",1965,828,457,718,751,2296,2792,718,751,2296,1066,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_ws"}, get);