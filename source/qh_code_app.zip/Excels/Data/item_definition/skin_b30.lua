-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[40011301] = P({D[17044], 40011301,false,196,463,false,20000113,false,"deco/character/bantianyinshi",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"bantianyinshi"}, get);
tb[40011302] = P({D[17044], 40011302,1,4,464,false,20000113,1,"deco/character/bantianyinshi_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"bantianyinshi_0"}, get);
tb[40011303] = P({D[17044], 40011303,999,197,465,"「ちょっと待て、もう一局だ！」",20000113,3,"deco/character/bantianyinshi_1",false,false,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"bantianyinshi_1"}, get);
tb[40011401] = P({D[17044], 40011401,false,198,466,false,20000114,false,"deco/character/guixiaotailang",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"guixiaotailang"}, get);
tb[40011402] = P({D[17044], 40011402,1,4,467,false,20000114,1,"deco/character/guixiaotailang_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"guixiaotailang_0"}, get);
tb[40011403] = P({D[17044], 40011403,999,197,468,"「おおエリザベス、やはり天才だったか！」",20000114,3,"deco/character/guixiaotailang_1",false,false,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"guixiaotailang_1"}, get);
tb[40011501] = P({D[17044], 40011501,false,199,469,false,20000115,false,"deco/character/gaoshanjinzhu",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"gaoshanjinzhu"}, get);
tb[40011502] = P({D[17044], 40011502,1,4,470,false,20000115,1,"deco/character/gaoshanjinzhu_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"gaoshanjinzhu_0"}, get);
tb[40011503] = P({D[17044], 40011503,999,197,471,"「これで終局だ。」",20000115,3,"deco/character/gaoshanjinzhu_1",false,false,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"gaoshanjinzhu_1"}, get);
tb[40011601] = P({D[17044], 40011601,false,200,472,false,20000116,false,"deco/character/banbenchenma",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"banbenchenma"}, get);
tb[40011602] = P({D[17044], 40011602,1,4,473,false,20000116,1,"deco/character/banbenchenma_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"banbenchenma_0"}, get);
tb[40011603] = P({D[17044], 40011603,999,197,474,"「アッハッハッハッハッハ！　こいつはついちょるのう！」",20000116,3,"deco/character/banbenchenma_1",false,false,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"banbenchenma_1"}, get);
tb[40011701] = P({D[17044], 40011701,false,201,475,false,20000117,false,"deco/character/mila",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"mila"}, get);
tb[40011702] = P({D[17044], 40011702,1,4,476,"「そういえば、人のシャツを着るっていうのは、その人のものになるって宣言らしいけど、本当なのかな？\n私、そういうのあんまり信じないんだけど……でも、このシャツを着たあなたと初めて会った時から、いつか着てみたいなってずっと思ってたんだー。」",20000117,1,"deco/character/mila_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"mila_0"}, get);
tb[40011703] = P({D[9044], 40011703,22,94,477,"「あなたなら必ず探しに来てくれると、わかっていました。\nこんな不器用な私のために危険を冒して来てくれるのは、あなただけだもの。\n……安心したせいか、なんだか、力が抜けてしまったみたいです。\n少しだけ、肩を貸してもらえませんか？」",20000117,2,"deco/character/40011703",0,1,4864,5000,2380,3095,5333,8333,6500,10333,8000,8000,5333,"mila_hxsw",false,0}, get);
tb[40011801] = P({D[17044], 40011801,false,202,478,false,20000118,false,"deco/character/beiluo",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"beiluo"}, get);
tb[40011802] = P({D[17044], 40011802,1,4,479,"「日頃は道場で稽古をつけてばかりだからな、このような閑暇は滅多にない。\n良い所に来たな、お前。ちょうど、秘蔵の品を味わおうとしてたところだ。\nせっかくの休みだ、人生の恩讐も卓上の勝敗も忘れると良い。\n今宵はただ風流を楽しみ、俗世の些事は問わずにいよう。」",20000118,1,"deco/character/beiluo_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"beiluo_0"}, get);
tb[40011901] = P({D[17044], 40011901,false,203,480,false,20000119,false,"deco/character/miya",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"miya"}, get);
tb[40011902] = P({D[17044], 40011902,1,4,481,"「ん～～……\n人が多い所だと撮られちゃうし～、穴場スポットも全部行っちゃったし～、次のデート、どこですればいいかなぁ？\nせっかくのオフの日だもん、スウィーティーとゆっくり羽を伸ばしたいんだよね。\nねぇねぇ、一緒に考えてよぉ。絶対に邪魔されない場所がいいの、おねがぁい♡」",20000119,1,"deco/character/miya_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"miya_0"}, get);
tb[40012001] = P({D[17044], 40012001,false,204,482,false,20000120,false,"deco/character/jinwu",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jinwu"}, get);
tb[40012002] = P({D[17044], 40012002,1,4,483,"「梅雨は……嫌いでち。\n羽根がいつまで経っても乾きまちぇん……。\nキンウのこと、助けてくだちゃい……！」",20000120,1,"deco/character/jinwu_0",302002,60,false,false,false,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"jinwu_0"}, get);
tb[40012201] = P({D[17044], 40012201,false,205,484,false,20000122,false,"deco/character/tongren",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"tongren"}, get);
tb[40012202] = P({D[17044], 40012202,1,4,485,false,20000122,1,"deco/character/tongren_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"tongren_0"}, get);
tb[40012203] = P({D[17044], 40012203,999,206,486,"「よし、次は全力であの大波を越えるぞ！」",20000122,3,"deco/character/tongren_1",false,false,false,false,1,false,false,"1",0,1,6035,5000,2830,4654,10000,6800,9833,6266,9000,8000,1666,"tongren_1"}, get);
tb[40012301] = P({D[17044], 40012301,false,207,487,false,20000123,false,"deco/character/yasina",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yasina"}, get);
tb[40012302] = P({D[17044], 40012302,1,4,488,false,20000123,1,"deco/character/yasina_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"yasina_0"}, get);
tb[40012303] = P({D[17044], 40012303,999,206,489,"「ん～……たまにはこうやって、のんびり過ごすのも良いよね。」",20000123,3,"deco/character/yasina_1",false,false,false,false,1,false,false,"1",0,1,5263,5000,2743,2672,12000,8000,8000,8000,12000,8000,8000,"yasina_1"}, get);
tb[40012401] = P({D[17044], 40012401,false,208,490,false,20000124,false,"deco/character/lifa",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"lifa"}, get);
tb[40012402] = P({D[17044], 40012402,1,4,491,false,20000124,1,"deco/character/lifa_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"lifa_0"}, get);
tb[40012403] = P({D[17044], 40012403,999,206,492,"「楽しかったなー！ 日が沈むまでちょっと一休みして、潮風に当たらない？」",20000124,3,"deco/character/lifa_1",false,false,false,false,1,false,false,"1",0,1,4348,5000,2140,3481,6000,5333,9666,5666,13000,8000,2666,"lifa_1"}, get);
tb[40012501] = P({D[17044], 40012501,false,209,493,false,20000125,false,"deco/character/shinai",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"shinai"}, get);
tb[40012502] = P({D[17044], 40012502,1,4,494,false,20000125,1,"deco/character/shinai_0",302002,60,false,false,1,false,false,"1",0,false,false,false,false,false,false,false,false,false,false,false,false,"shinai_0"}, get);
tb[40012503] = P({D[17044], 40012503,999,206,495,"「今日はこのまま、ここで静かに過ごすのも悪くないわね。」",20000125,3,"deco/character/shinai_1",false,false,false,false,1,false,false,"1",0,1,4695,5000,2402,3060,4000,5733,8000,8000,11967,8000,8000,"shinai_1"}, get);