-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[40010902] = P({D[17057], 40010902,1,4,456,false,20000109,1,"deco/character/yuanbanlin_0",302002,60,false,false,1,false,false,"1","yuanbanlin_0"}, get);
tb[40010903] = P({D[17045], 40010903,999,191,457,false,20000109,3,"deco/character/yuanbanlin_hf",false,false,false,false,1,false,false,"1",1,5286,5000,2779,5093,5333,5000,11766,4000,10000,8000,5333,"yuanbanlin_1"}, get);
tb[40011001] = P({D[17057], 40011001,false,193,458,false,20000110,false,"deco/character/saber",302002,60,false,false,1,false,false,"1","aertuoliya"}, get);
tb[40011002] = P({D[17057], 40011002,1,4,459,false,20000110,1,"deco/character/saber_0",302002,60,false,false,1,false,false,"1","aertuoliya_0"}, get);
tb[40011003] = P({D[17045], 40011003,999,191,460,false,20000110,3,"deco/character/saber_hf",false,false,false,false,1,false,false,"1",1,5245,5000,2504,6039,8000,8466,6933,5400,12000,8000,2666,"aertuoliya_1"}, get);
tb[40011101] = P({D[17057], 40011101,false,194,461,false,20000111,false,"deco/character/archer",302002,60,false,false,1,false,false,"1","yinglingweigong"}, get);
tb[40011102] = P({D[17057], 40011102,1,4,462,false,20000111,1,"deco/character/archer_0",302002,60,false,false,1,false,false,"1","yinglingweigong_0"}, get);
tb[40011103] = P({D[17045], 40011103,999,191,463,false,20000111,3,"deco/character/archer_hf",false,false,false,false,1,false,false,"1",1,5523,5000,3032,2920,64000,20233,22400,21400,12000,8000,16000,"yinglingweigong_1"}, get);
tb[40011201] = P({D[17057], 40011201,false,195,464,false,20000112,false,"deco/character/liyang",302002,60,false,false,false,false,false,"1","liyang"}, get);
tb[40011202] = P({D[17045], 40011202,1,4,465,"「人間の両足って素晴らしいわよね、さっと足を引っ掛けたりもできるし、獲物を踏んで逃がさないようにもできるもの。とはいえ、確実に獲物を絞め上げるには、やはり蛇の尾の方が使いやすいわ。……それで、あなたは今夜、どんな風に捕えられたいのかしら？」",20000112,1,"deco/character/liyang_0",302002,60,false,false,false,false,false,"1",2,4657,5000,2421,3923,3333,10000,6666,8000,12000,6666,false,"liyang_0"}, get);
tb[40011203] = P({D[17045], 40011203,998,196,466,"「蛇は本来、こういう月が明るい夜には求愛の舞なんてしないのよ。これはあくまで予行演習……\nしかし、あなたは見てしまった。可愛いあなたであっても、罰を与えなくてはね。\nそうね……では、あなたのために準備していたこの儀式を、前もって味わわせてあげようかしら？」",20000112,2,"deco/character/liyang_1",false,false,false,false,false,false,false,"1",2,5318,5000,2715,4510,3333,8000,8000,8000,18400,8000,8000,"liyang_1"}, get);
tb[40011301] = P({D[17057], 40011301,false,197,467,false,20000113,false,"deco/character/bantianyinshi",302002,60,false,false,1,false,false,"1","bantianyinshi"}, get);
tb[40011302] = P({D[17057], 40011302,1,4,468,false,20000113,1,"deco/character/bantianyinshi_0",302002,60,false,false,1,false,false,"1","bantianyinshi_0"}, get);
tb[40011303] = P({D[17057], 40011303,999,198,469,"「ちょっと待て、もう一局だ！」",20000113,3,"deco/character/bantianyinshi_1",false,false,false,false,1,false,false,"1","bantianyinshi_1"}, get);
tb[40011401] = P({D[17057], 40011401,false,199,470,false,20000114,false,"deco/character/guixiaotailang",302002,60,false,false,1,false,false,"1","guixiaotailang"}, get);
tb[40011402] = P({D[17057], 40011402,1,4,471,false,20000114,1,"deco/character/guixiaotailang_0",302002,60,false,false,1,false,false,"1","guixiaotailang_0"}, get);
tb[40011403] = P({D[17057], 40011403,999,198,472,"「おおエリザベス、やはり天才だったか！」",20000114,3,"deco/character/guixiaotailang_1",false,false,false,false,1,false,false,"1","guixiaotailang_1"}, get);
tb[40011501] = P({D[17057], 40011501,false,200,473,false,20000115,false,"deco/character/gaoshanjinzhu",302002,60,false,false,1,false,false,"1","gaoshanjinzhu"}, get);
tb[40011502] = P({D[17057], 40011502,1,4,474,false,20000115,1,"deco/character/gaoshanjinzhu_0",302002,60,false,false,1,false,false,"1","gaoshanjinzhu_0"}, get);
tb[40011503] = P({D[17057], 40011503,999,198,475,"「これで終局だ。」",20000115,3,"deco/character/gaoshanjinzhu_1",false,false,false,false,1,false,false,"1","gaoshanjinzhu_1"}, get);
tb[40011601] = P({D[17057], 40011601,false,201,476,false,20000116,false,"deco/character/banbenchenma",302002,60,false,false,1,false,false,"1","banbenchenma"}, get);
tb[40011602] = P({D[17057], 40011602,1,4,477,false,20000116,1,"deco/character/banbenchenma_0",302002,60,false,false,1,false,false,"1","banbenchenma_0"}, get);
tb[40011603] = P({D[17057], 40011603,999,198,478,"「アッハッハッハッハッハ！　こいつはついちょるのう！」",20000116,3,"deco/character/banbenchenma_1",false,false,false,false,1,false,false,"1","banbenchenma_1"}, get);
tb[40011701] = P({D[17057], 40011701,false,202,479,false,20000117,false,"deco/character/mila",302002,60,false,false,false,false,false,"1","mila"}, get);
tb[40011702] = P({D[17057], 40011702,1,4,480,"「そういえば、人のシャツを着るっていうのは、その人のものになるって宣言らしいけど、本当なのかな？\n私、そういうのあんまり信じないんだけど……でも、このシャツを着たあなたと初めて会った時から、いつか着てみたいなってずっと思ってたんだー。」",20000117,1,"deco/character/mila_0",302002,60,false,false,false,false,false,"1","mila_0"}, get);
tb[40011703] = P({D[9045], 40011703,22,95,481,"「あなたなら必ず探しに来てくれると、わかっていました。\nこんな不器用な私のために危険を冒して来てくれるのは、あなただけだもの。\n……安心したせいか、なんだか、力が抜けてしまったみたいです。\n少しだけ、肩を貸してもらえませんか？」",20000117,2,"deco/character/mila_hxsw",1,4864,5000,2380,3095,5333,8333,6500,10333,8000,8000,5333,"mila_hxsw"}, get);
tb[40011801] = P({D[17057], 40011801,false,203,482,false,20000118,false,"deco/character/beiluo",302002,60,false,false,false,false,false,"1","beiluo"}, get);
tb[40011802] = P({D[17057], 40011802,1,4,483,"「日頃は道場で稽古をつけてばかりだからな、このような閑暇は滅多にない。\n良い所に来たな、お前。ちょうど、秘蔵の品を味わおうとしてたところだ。\nせっかくの休みだ、人生の恩讐も卓上の勝敗も忘れると良い。\n今宵はただ風流を楽しみ、俗世の些事は問わずにいよう。」",20000118,1,"deco/character/beiluo_0",302002,60,false,false,false,false,false,"1","beiluo_0"}, get);