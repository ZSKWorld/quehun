-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[40011801] = P({D[17057], 40011801,false,203,482,false,20000118,false,"deco/character/beiluo",302002,60,false,false,false,false,false,"1","beiluo"}, get);
tb[40011802] = P({D[17057], 40011802,1,4,483,"「日頃は道場で稽古をつけてばかりだからな、このような閑暇は滅多にない。\n良い所に来たな、お前。ちょうど、秘蔵の品を味わおうとしてたところだ。\nせっかくの休みだ、人生の恩讐も卓上の勝敗も忘れると良い。\n今宵はただ風流を楽しみ、俗世の些事は問わずにいよう。」",20000118,1,"deco/character/beiluo_0",302002,60,false,false,false,false,false,"1","beiluo_0"}, get);
tb[40011901] = P({D[17057], 40011901,false,204,484,false,20000119,false,"deco/character/miya",302002,60,false,false,false,false,false,"1","miya"}, get);
tb[40011902] = P({D[17057], 40011902,1,4,485,"「ん～～……\n人が多い所だと撮られちゃうし～、穴場スポットも全部行っちゃったし～、次のデート、どこですればいいかなぁ？\nせっかくのオフの日だもん、スウィーティーとゆっくり羽を伸ばしたいんだよね。\nねぇねぇ、一緒に考えてよぉ。絶対に邪魔されない場所がいいの、おねがぁい♡」",20000119,1,"deco/character/miya_0",302002,60,false,false,false,false,false,"1","miya_0"}, get);
tb[40012001] = P({D[17057], 40012001,false,205,486,false,20000120,false,"deco/character/jinwu",302002,60,false,false,false,false,false,"1","jinwu"}, get);
tb[40012002] = P({D[17057], 40012002,1,4,487,"「梅雨は……嫌いでち。\n羽根がいつまで経っても乾きまちぇん……。\nキンウのこと、助けてくだちゃい……！」",20000120,1,"deco/character/jinwu_0",302002,60,false,false,false,false,false,"1","jinwu_0"}, get);
tb[40012101] = P({D[17057], 40012101,false,206,488,false,20000121,false,"deco/character/40012101",302002,60,false,false,false,false,false,"1","chilin",false,0}, get);
tb[40012102] = P({D[17045], 40012102,1,4,489,"「く～！ たまには、一杯やるのも乙なもんだな。\nいつもはとにかく前に前に！ って走ってるけど、今日くらいは……\nや、君のそばにいる時は、少しペースを落としてみてもいいかなと思ってさ。\nほら、もう少しこっちに寄ってくれ。\n貴重な休息の時、一緒に満喫しよう！」",20000121,1,"deco/character/40012102",302002,60,false,false,false,false,false,"1",2,4075,5000,2154,3715,false,4900,6833,5600,8000,5166,false,"chilin_0",false,0}, get);
tb[40012103] = P({D[17045], 40012103,999,207,490,"「ふははははっ！ どうだ、我のこの姿を見るのは初めてであろう！\n案ずるな、この燃え盛る赤き炎は我が意のまま。汝を傷つけるような真似は決してせぬ！\nなんといっても、蔓延る怠惰と厄運をもろとも焼き尽くし、民の安寧を護り抜くのが我が役目ゆえな。\nたまにはこうして、本気を出してやらねばならぬのだ！」",20000121,2,"deco/character/40012103",false,false,false,false,false,false,false,"1",2,5908,5000,3050,4993,2666,8000,8000,8000,8000,8000,8000,"chilin_1",false,0}, get);
tb[40012201] = P({D[17057], 40012201,false,208,491,false,20000122,false,"deco/character/tongren",302002,60,false,false,1,false,false,"1","tongren"}, get);
tb[40012202] = P({D[17057], 40012202,1,4,492,false,20000122,1,"deco/character/tongren_0",302002,60,false,false,1,false,false,"1","tongren_0"}, get);
tb[40012203] = P({D[17045], 40012203,999,209,493,"「よし、次は全力であの大波を越えるぞ！」",20000122,3,"deco/character/tongren_1",false,false,false,false,1,false,false,"1",1,6035,5000,2830,4654,10000,6800,9833,6266,9000,8000,1666,"tongren_1"}, get);
tb[40012301] = P({D[17057], 40012301,false,210,494,false,20000123,false,"deco/character/yasina",302002,60,false,false,1,false,false,"1","yasina"}, get);
tb[40012302] = P({D[17057], 40012302,1,4,495,false,20000123,1,"deco/character/yasina_0",302002,60,false,false,1,false,false,"1","yasina_0"}, get);
tb[40012303] = P({D[17045], 40012303,999,209,496,"「ん～……たまにはこうやって、のんびり過ごすのも良いよね。」",20000123,3,"deco/character/yasina_1",false,false,false,false,1,false,false,"1",1,5263,5000,2743,2672,12000,8000,8000,8000,12000,8000,8000,"yasina_1"}, get);
tb[40012401] = P({D[17057], 40012401,false,211,497,false,20000124,false,"deco/character/lifa",302002,60,false,false,1,false,false,"1","lifa"}, get);
tb[40012402] = P({D[17057], 40012402,1,4,498,false,20000124,1,"deco/character/lifa_0",302002,60,false,false,1,false,false,"1","lifa_0"}, get);
tb[40012403] = P({D[17045], 40012403,999,209,499,"「楽しかったなー！ 日が沈むまでちょっと一休みして、潮風に当たらない？」",20000124,3,"deco/character/lifa_1",false,false,false,false,1,false,false,"1",1,4348,5000,2140,3481,6000,5333,9666,5666,13000,8000,2666,"lifa_1"}, get);
tb[40012501] = P({D[17057], 40012501,false,212,500,false,20000125,false,"deco/character/shinai",302002,60,false,false,1,false,false,"1","shinai"}, get);
tb[40012502] = P({D[17057], 40012502,1,4,501,false,20000125,1,"deco/character/shinai_0",302002,60,false,false,1,false,false,"1","shinai_0"}, get);
tb[40012503] = P({D[17045], 40012503,999,209,502,"「今日はこのまま、ここで静かに過ごすのも悪くないわね。」",20000125,3,"deco/character/shinai_1",false,false,false,false,1,false,false,"1",1,4695,5000,2402,3060,4000,5733,8000,8000,11967,8000,8000,"shinai_1"}, get);