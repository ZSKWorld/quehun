-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[400703] = P({D[12034], 400703,4,16,44,"「先輩……ずっと私の脚を見てる……やはり脚フェチ？　じゃあ……一番好きなのは白スト？　黒スト？　それとも裸足がいい？」",false,2,"deco/character/bamuwei_SDJ",false,false,1,1907,920,400,1246,643,1554,2316,1246,643,1554,1237,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_sd"}, get);
tb[400704] = P({D[18034], 400704,3,36,45,"「飛んで、蝶たちよ――あの人を連れて私の元に戻ってきて。」",false,2,"deco/character/bamuwei_WSJ",false,false,false,false,false,false,false,false,"2020-10-29 05:00:00+08",1965,828,457,718,751,2296,2792,718,751,2296,1066,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_ws"}, get);
tb[400705] = P({D[9034], 400705,12,37,46,"「先輩、私と一曲踊りたいの……？　今日のためにダンスを練習してはきたけど……先輩の足、踏んじゃうかも。それでも良ければ……」",false,2,"deco/character/bamuwei_LF",1877,954,361,1074,667,1982,2121,1074,667,1982,1228,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_lf"}, get);
tb[400706] = P({D[9034], 400706,2,38,47,"「『蝶は美しい花に引き寄せられる』……うん、そうだね。でも、先輩、どうして私に言うの？」",false,2,"deco/character/400706",1787,852,380,1014,650,2416,2339,1014,650,2416,1152,1,3910,5000,1943,3415,8000,8000,11500,11333,9000,false,8000,"bamuwei_xr"}, get);
tb[400707] = P({D[21034], 400707,14,33,48,"「理解できない。魔法、こんなに悠長に詠唱してても、攻撃されない……非合理的。」",false,2,"deco/character/bamuwei_YSJ",false,false,false,false,1,false,false,false,false,false,false,"0,70,0.94",1841,872,380,790,437,2817,3193,790,561,2817,false,false,false,false,false,false,false,false,false,false,false,false,false,"bamuwei_ysj"}, get);
tb[400708] = P({D[45057], 400708,999,29,49,false,false,3,"deco/character/bamuwei_SLO",false,false,false,false,1,false,false,"1",false,false,"-120,0,1","240,-280,1","-120,0,1","-120,0,1","-120,0,1",false,false,false,false,false,false,false,false,false,false,false,2040,878,398,909,314,2551,2526,909,576,2551,"bamuwei_slo"}, get);
tb[400709] = P({D[9044], 400709,19,39,50,"「湖の上、ランタンの明かりを見る……結構、楽しい。先輩も、一緒にやる？\n不安？ ……大丈夫。軽身功を習得したから、沈まない。\n……先輩は、私にしっかり掴まってればいい。」",false,2,"deco/character/bamuwei_gf",0,1,4644,5000,2378,3653,6000,8666,8333,5000,13233,8000,6000,"bamuwei_gf"}, get);
tb[400801] = P({D[32044], 400801,false,40,51,false,200008,false,"deco/character/jiutiao",302002,60,false,false,false,false,-52,false,false,false,false,false,false,false,false,"0,60,0.99","0,-20,1","80,-40,0.98",false,false,false,"20,-10,1","0,-10,0.98",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu"}, get);
tb[400802] = P({D[11044], 400802,1,4,52,"「紅茶はいかがです？\nこうも付き合いが長くなると、自ずと好みもわかってくるものです」",200008,1,"deco/character/jiutiao_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_0"}, get);
tb[400803] = P({D[9044], 400803,2,5,53,false,200008,2,"deco/character/jiutiao_haitanpaidui",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_xr"}, get);
tb[400804] = P({D[18044], 400804,5,41,54,"「では、もう一筆。頑張らないと、もうあなたの顔に墨を入れられるスペースがなくなりますよ。わたくしに誠心誠意お願いなさるなら、手加減してあげないこともありませんけれど。」",200008,2,"deco/character/jiutiao_YD",false,false,false,1,false,false,false,false,"2020-12-30 05:00:00+08",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_yd"}, get);
tb[400805] = P({D[12044], 400805,14,42,55,"「姫様の命とあらば、我が鉄拳は何処へでも飛んでいく！　姫様の威名を心に刻みし者よ、私と共に忠誠を誓え！」",200008,2,"deco/character/jiutiao_YSJ",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_ysj"}, get);
tb[400806] = P({D[24044], 400806,16,43,56,"「なんと、初戦から勝利を収めたのですか？　お疲れでしょうから、こちらで休んでください。な、私の写真を撮りたい？　そんなバカなことを言える元気がまだ残っているなら、さっさとサポーターをしまってください！」",200008,2,"deco/character/jiutiao_SC",false,false,false,false,false,false,false,"1",false,"90,60,1.02","90,60,1.02","240,-240,1.14","90,60,1.02","90,60,1.02","-30,30,1.02",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_sc"}, get);
tb[400807] = P({D[17044], 400807,18,9,57,"「しーっ。今は自習ですので、お話はあとで……\nこ、告白でもダメ！ とにかくダメです！\n……もう、そういったお話は、もう少しムードというか、そういうことを考えてしていただきたいものです。」",200008,2,"deco/character/jiutiao_kxj",false,false,false,false,false,false,false,"",0,false,false,false,false,false,false,false,false,false,false,false,false,"jiutiaoliyu_kxj"}, get);
tb[400901] = P({D[32044], 400901,false,44,58,false,200009,false,"deco/character/zeniya",302002,60,1,false,false,false,60,"1",false,false,false,false,false,false,false,"0,0,1.05","-70,40,1","40,40,1",false,false,false,"-60,30,1","-30,30,1",0,false,false,false,false,false,false,false,false,false,false,false,false,"zeniya",1}, get);
tb[400902] = P({D[11044], 400902,1,4,59,"「一緒に旅をすると、約束しましたでしょう？」\n大きなトランクを手にした少女は、すぐに出発するつもりらしい。",200009,1,"deco/character/zeniya_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"zeniya_0"}, get);
tb[400903] = P({D[12044], 400903,3,11,60,"「これはわたくしの国でサキュバスと呼ばれている、人の心を惑わす存在の装束ですわ。\nですから今夜は……気・を・つ・け・て♡」",200009,2,"deco/character/zeniya_WSJ",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"zeniya_ws"}, get);
tb[400904] = P({D[12044], 400904,2,22,61,"「どこの国でも、海が好きな気持ちは同じですわね。でしたら、きっとわたくしが準備したサンドイッチと紅茶も気に入っていただけるはずですわ。」",200009,2,"deco/character/zeniya_YZ",false,false,1,0,false,false,false,false,false,false,false,false,false,false,false,false,"zeniya_xr"}, get);