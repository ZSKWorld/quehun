-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[400905] = P({D[21044], 400905,6,8,62,"「いかがでしょう？　お祭りに合わせて東方の伝統衣装を着てみたのですけれど、似合いまして？　この金色の刺繍には、本物の金の糸が織り交ぜられていると店員さんが仰ってましたの。実際に作ってるところを見てみたいものですわ。」",200009,2,"deco/character/400905",false,false,1,false,false,false,false,"1",false,false,false,"340,0,1",0,1,2337,5000,1161,3608,8000,14666,9000,8000,12040,false,8000,"zeniya_cj",false,0}, get);
tb[400906] = P({D[21044], 400906,999,29,63,false,200009,3,"deco/character/zeniya_SLO",false,false,false,false,1,false,false,"1",false,false,false,"240,-280,1.02",0,false,false,false,false,false,false,false,false,false,false,false,false,"zeniya_slo"}, get);
tb[400907] = P({D[17044], 400907,18,9,64,"「わたくしの制服姿、意外に思われました？ \nあなたが会う度に朝葉高校のことばかりお話するものだから、わたくしもつい興味を引かれてしまいましたの。\nここが本当にあなたの称賛に見合う場所なのかどうか、確かめてみようかと。」",200009,2,"deco/character/zeniya_kxj",false,false,false,false,false,false,false,"",0,1,4455,5000,1915,2650,4000,5266,8266,4533,16067,6666,5333,"zeniya_kxj"}, get);
tb[400908] = P({D[17044], 400908,13,45,65,"「いかがかしら？\nロケーション、スイーツの種類、バスローブ……どれも、わたくしが隅々までこだわったものです。\n特にじっくりと選んだのは、共に夜を過ごしてくれる人……そう、あなたのことですわ。\nせっかくの羽を伸ばせる時間ですもの、思う存分素晴らしい夜を楽しみましょう？」",200009,2,"deco/character/zeniya_wq",false,false,false,false,false,false,false,"",0,1,3401,5000,1563,3215,5333,10666,10433,8166,8167,8000,5333,"zeniya_wq"}, get);
tb[401001] = P({D[17023], 401001,false,46,66,false,200010,false,"deco/character/kawei",302002,60,1,false,false,false,-132,"1","0,240,0.98","-20,60,1","-40,30,1","-20,60,1","-40,30,1",false,"-80,40,1","-90,40,1","-80,40,1","-90,40,1",false,1871,899,400,1342,557,1866,2996,1342,598,1866}, get);
tb[401002] = P({D[12034], 401002,1,4,67,"「こんな夜更けに人の家に来るなんて、礼儀がなってないわね。\nでもまあ、女難君に免じて、特別に一回占ってあげましょう。」",200010,1,"deco/character/kawei_0",302002,false,1,1813,924,400,1106,493,1950,2764,1106,623,1950}, get);
tb[401003] = P({D[12034], 401003,2,47,68,"「太陽と砂浜、青い波と美酒……確かに今回の海は期待できそうね。さて、君はどんなサプライズを用意したのか、当ててみせましょうか？」",200010,2,"deco/character/kawei_YZ",false,false,1,1821,870,382,1115,476,1879,2913,1115,560,1879}, get);
tb[401004] = P({D[9034], 401004,12,48,69,"「占いで示された、鐘が鳴る時刻までもう少しあります。どうせ暇ですし、私ともう一曲踊りません？　せっかくの舞踏会を無為に過ごしては勿体無いですから。」",200010,2,"deco/character/401004",1892,875,399,1279,479,1543,2763,1279,574,1543,false,1,724,5000,367,1257,5333,5333,10666,10666,7000,false,5333,false,false,0}, get);
tb[401101] = P({D[17044], 401101,false,49,70,false,200011,false,"deco/character/sigongxiasheng",302002,60,1,false,false,false,-160,"0.97",0,false,false,false,false,false,false,false,false,false,false,false,false,"sigongxiasheng",1}, get);
tb[401102] = P({D[11044], 401102,1,4,71,"「しーっ！\n……今は『白夜』って呼んでくれ」\n舞い落ちる花弁の向こうから、彼の視線がまっすぐこちらに届く。",200011,1,"deco/character/sigongxiasheng_0",302002,60,0,false,false,false,false,false,false,false,false,false,false,false,false,"sigongxiasheng_0"}, get);
tb[401103] = P({D[21034], 401103,3,11,72,"「フフッ、その柔肌の下にある美しき血管が僕を惑わす……今宵、君は僕の眷属だ。」",200011,2,"deco/character/xiasheng_WSJ",false,false,false,false,false,false,false,"1",false,false,false,"0,40,0.88",1848,886,450,1157,377,2341,3143,1157,610,2341}, get);
tb[401104] = P({D[13034], 401104,5,32,73,"「勝負するなら、何か賭けようか？　僕が勝ったら、そうだな……『白夜』の助手役、今年もよろしく頼むよ。万が一僕が負けた場合は、君の言うことを何でも一つ聞いてあげよう。」",200011,2,"deco/character/sigongxiasheng_XN",false,false,false,1,1953,823,400,573,748,2424,3012,573,748,2424,1035}, get);
tb[401105] = P({D[21034], 401105,2,38,74,"「カモメが僕のカバンの中身を漁ってる？　まさかな、パンとか入れてる訳じゃないし……って、マジで漁ってる……だと！？　おい！　やめろー！！」",200011,2,"deco/character/401105",false,false,1,false,false,false,false,false,false,false,false,"0,90,0.9315",1737,843,380,210,374,3990,3826,754,532,2902,false,1,4041,5000,2108,3977,8000,8000,8833,4000,11000,false,8000,false,false,0}, get);
tb[401201] = P({D[17023], 401201,false,50,75,false,200012,false,"deco/character/wangcilang",302002,60,false,1,false,false,208,"1","0,0,1.04","-60,40,0.97","-20,50,0.97","-60,40,0.97","-20,50,0.97",false,"-100,40,0.92","-60,40,0.92","-100,40,0.92","-60,40,0.92",false,1878,826,486,1340,720,1438,2360,1340,720,1438,1109}, get);
tb[401202] = P({D[11034], 401202,1,4,76,"「前にも言ったと思うが、俺様は魂天神社の元雀士の一人なんだワン！\nどうだ、この服、まだイケるだろ？」",200012,1,"deco/character/wangcilang_0",302002,60,1878,826,486,1094,696,1933,2402,1094,696,1933,1133}, get);