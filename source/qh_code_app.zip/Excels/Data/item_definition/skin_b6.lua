-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[401203] = P({D[21034], 401203,3,11,77,"「しーっ、静かに！　今夜の俺はただの物言わぬカカシだぜ！」",200012,2,"deco/character/wangcilang_WSJ",false,false,false,false,false,false,false,"1",false,false,false,"120,-100,0.98",1883,907,456,1198,397,1810,2636,1198,634,1810}, get);
tb[401204] = P({D[21034], 401204,2,18,78,"「ここからが腕の見せ所……波に乗りながらラーメンを完食してみせるワン！」",200012,2,"deco/character/wangcilang_YZ",false,false,false,false,false,false,false,"1",false,false,false,"0,0,0.9",1918,819,515,713,false,3382,3360,953,576,2902}, get);
tb[401205] = P({D[24034], 401205,4,51,79,"「俺様はスペシャルなサンタクロース……だったら、当然トナカイもグレードアップしていいはずだワン！　このバイクはカッチョイイし、プレゼントを配る効率もぐーんと上がるワン！」",200012,2,"deco/character/wangcilang_SD",false,false,false,false,false,false,false,"1",false,false,false,"240,-60,0.94",false,false,"-80,0,1",1819,830,515,929,502,2584,2782,929,587,2584}, get);
tb[401301] = P({D[17023], 401301,false,52,80,false,200013,false,"deco/character/yizhilaikong",302002,60,false,false,false,false,106,"1","0,-70,1.05","-60,50,1.02","0,40,1.02",false,false,false,"-40,60,1.02","0,60,1.02",false,false,false,1835,960,468,1672,887,768,2213,1672,887,768,1067}, get);
tb[401302] = P({D[12034], 401302,1,4,81,"「キューブパズル以外にも、キミと一緒にやりたいことがいっぱいあるんだ。\n付き合ってくれる？」",200013,1,"deco/character/yizhilaikong_0",302002,60,1,1777,948,468,1146,805,2142,2730,1146,805,2142,1137}, get);
tb[401303] = P({D[12034], 401303,4,16,82,"「キミと一緒に過ごすクリスマスは初めてだね、これから先のクリスマスもずっと一緒に過ごせるといいな」",200013,2,"deco/character/yizhilaikong_SDJ",false,false,1,1891,973,429,1165,709,1753,2484,1165,709,1753,1239}, get);
tb[401304] = P({D[12034], 401304,7,53,83,"「お久しぶり……？　お休み中もずっと会ってたじゃないですか。でもたしかに学校で会うのは久しぶりかもです。そ、そうだ、新しい本を買ったんだ、一緒に読みませんか？」",200013,2,"deco/character/yizhilaikong_KX",false,false,1,1768,934,409,852,624,2195,2500,852,638,2195}, get);
tb[401305] = P({D[21034], 401305,6,8,84,"「春節は春の到来を意味すると言われてるけど、科学的に言うと春はまだ遠いんだ。でも、この季節になると周りが賑やかになるし、キミにもよく会える気がするから、ボクも嬉しいよ。」",200013,2,"deco/character/401305",false,false,false,false,false,false,false,"1",false,false,false,"120,0,1",1900,1014,380,1252,700,1770,2464,1252,703,1770,false,1,3387,5000,1499,4537,16000,16666,14333,4666,12960,false,10666}, get);
tb[401306] = P({D[24034], 401306,3,54,85,"「はい、どうぞ。このクリームを塗れば、怖いものが近づいてこなくなるから、今夜は安心して過ごせるよ。……え？　蚊が寄って来なくなるもの？　ちょっと待ってて、今すぐ虫よけの薬の研究を……！」",200013,2,"deco/character/yizhilaikong_WS",false,false,false,false,false,false,false,"1",false,false,"-30,0,1","240,-400,1","-30,0,1","-30,0,1","-30,0,1",1865,1045,380,967,223,2176,2294,967,734,2176}, get);
tb[401401] = P({D[46057], 401401,false,55,86,false,200014,false,"deco/character/mingzhiyingshu",302002,60,1,false,false,false,-228,false,false,false,false,false,false,false,false,"-40,650,0.91","-100,20,1","-60,20,1",false,false,false,"-100,30,1","-60,30,1",false,false,false,1901,856,430,1657,778,1034,3299,1657,778,1034,1053,"mingzhiyingshu"}, get);
tb[401402] = P({D[11034], 401402,1,4,87,"「少し休みましょうか。\nなにもせず、ただ一緒に座るだけ。どうでしょう？」",200014,1,"deco/character/mingzhiyingshu_0",302002,60,1915,895,447,995,594,2213,2801,995,618,2213,false,false,false,false,false,false,false,false,false,false,false,false,false,"mingzhiyingshu_0"}, get);
tb[401403] = P({D[18034], 401403,3,36,88,"「こんばんは。黒羽の使者・明智英樹が、お迎えに上がりました。僕と共にあの月光満ちる国へ参りましょう。貴方は断れない……そうでしょう？」",200014,2,"deco/character/mingzhiyingshu_WSJ",false,false,false,false,false,false,false,false,"2020-10-29 05:00:00+08",1995,920,361,939,595,2538,3434,939,600,2538,false,false,false,false,false,false,false,false,false,false,false,false,false,"mingzhiyingshu_ws"}, get);
tb[401404] = P({D[21034], 401404,2,47,89,"「今は風がそんなに強くないので、この辺りでしばらく休憩しましょうか。このペースなら、日が沈むまでに砂のお城が完成しそうです。思い描いた通りのお城になるといいですね。」",200014,2,"deco/character/mingzhiyingshu_YZ",false,false,false,false,false,false,false,false,false,false,false,"0,-90,1",1756,818,415,953,738,2649,2260,953,738,2649,1048,false,false,false,false,false,false,false,false,false,false,false,false,"mingzhiyingshu_xr"}, get);
tb[401405] = P({D[9034], 401405,11,56,90,"「ちょっと驚きですね、ここで会えるなんて。ええ、家族と一緒に来たんですが、ご覧の通りはぐれてしまいまして……。もし君も一人なら、これから一緒に花火を見に行きませんか？」",200014,2,"deco/character/mingzhiyingshu_YY",1836,860,380,767,697,3025,2865,829,697,2901,1113,false,false,false,false,false,false,false,false,false,false,false,false,"mingzhiyingshu_yy"}, get);
tb[401406] = P({D[9044], 401406,13,57,91,"「ああ……ついウトウトしてしまいました。サークルも順調で、悩み事も減ってきた、というのもあるでしょう。ただそれ以上に、君が傍にいる、というごくシンプルな理由で、気が緩んでしまったようです。」",200014,2,"deco/character/mingzhiyingshu_WQ",0,false,false,false,false,false,false,false,false,false,false,false,false,"mingzhiyingshu_wq"}, get);