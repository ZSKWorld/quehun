-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[401801] = P({D[46057], 401801,false,62,108,false,200018,false,"deco/character/baishinainai",302002,60,1,false,false,false,false,"1",false,false,false,false,false,false,false,"70,20,1",false,false,false,false,false,"0,-20,1","0,-20,1","0,-20,1","0,-20,1",false,1839,856,422,1403,714,1343,2549,1403,714,1343,1113,"baishinainai"}, get);
tb[401802] = P({D[12034], 401802,1,4,109,"「えっ、EX-Gamesのチケット売り切れてんじゃん！ 5時間も前に来たのになんで？\n……って、発売日、昨日だったのー！？」",200018,1,"deco/character/baishinainai_0",302002,60,1,1703,888,456,1451,741,1445,2438,1451,741,1445,1135,false,false,false,false,false,false,false,false,false,false,false,false,"baishinainai_0"}, get);
tb[401803] = P({D[12034], 401803,2,22,110,"「掃除が終わったらここで思いっきり泳げるんだ！　って思ったら、やる気が出てきたよ！　頑張れ後輩クン、ファイトーっ！」",200018,2,"deco/character/baishinainai_xr",false,false,1,1778,818,400,407,663,2844,2481,407,663,2844,1115,false,false,false,false,false,false,false,false,false,false,false,false,"baishinainai_xr"}, get);
tb[401804] = P({D[13034], 401804,8,61,111,"「お店の中をキレイにするのがメイドのお仕事だよ。それに、今後輩クンはお客さんなんだから、掃除はウチにまかせちゃって～！　ウチにご奉仕される機会なんて滅多に無いんだから、大事にしてよね！」",200018,2,"deco/character/baishinainai_NP",false,false,1,1,1938,846,388,678,474,2820,3114,678,539,2820,1261,false,false,false,false,false,false,false,false,false,false,false,false,"baishinainai_np"}, get);
tb[401805] = P({D[21034], 401805,4,51,112,"「クリスマスの朝に、当日限定の衣装に身を包んだ美少女の先輩と一緒に運動できるなんて……なかなか贅沢な青春だねっ、後輩クン！」",200018,2,"deco/character/baishinainai_SD",false,false,1,false,false,false,false,"1",false,false,false,"240,50,0.94",1882,871,388,237,635,3625,2993,599,635,2901,1190,false,false,false,false,false,false,false,false,false,false,false,false,"baishinainai_sd"}, get);
tb[401806] = P({D[12045], 401806,21,20,113,"「白石奈々、応援に参りました〜！\n後輩クンのウォーミングアップ、付き合ってあげる！\nなになに？ わざわざ自分一人だけのために大げさって？\nそんなことないよ！\n後輩クンの大事な試合なんだから、先輩のウチが全力でサポートしないと！\n優勝、期待してるよ！」",200018,2,"deco/character/baishinainai_ydh",false,false,1,1,2464,5000,1207,1512,2666,5333,4033,5166,11000,8000,2666,"baishinainai_ydh"}, get);
tb[401901] = P({D[46057], 401901,false,63,114,false,200019,false,"deco/character/xiaoniaoyouchutian",302002,60,false,false,false,false,60,"1",false,false,false,false,false,false,false,"60,-30,1.02","-60,50,1","0,10,1",false,false,false,"-40,40,1","-20,40,1",false,false,false,1918,891,398,1286,756,1697,2408,1286,756,1697,1094,"xiaoniaoyouchutian",1}, get);
tb[401902] = P({D[23034], 401902,1,4,115,"「お休みの日に何をしようか迷ってたんだけど、一緒にピクニックできてよかった〜。\n次のお休みも、一緒にデート、したいな〜！」",200019,1,"deco/character/xiaoniaoyouchutian_0",302002,60,1,false,false,-100,-100,"0.9",false,false,false,false,"-100,0,1","-100,0,1",1937,892,414,1028,384,2390,2786,1028,598,2390,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoniaoyouchutian_0"}, get);
tb[401903] = P({D[9034], 401903,8,23,116,"「いらっしゃいませ！　大三元オムライスはいかがですか？」",200019,2,"deco/character/xiaoniaoyouchutian_NP",1999,879,363,696,79,2916,3359,703,560,2902,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoniaoyouchutian_np"}, get);
tb[401904] = P({D[13034], 401904,11,64,117,"「わたあめとたこ焼き、どっちを先に食べようか～。あ！　あっちにはたい焼きもあるよ～！　……雀士さん、見て見て～、金魚すくいだ～！　わぁ～い！　今夜全部見て回る時間足りるかな～。」",200019,2,"deco/character/xiaoniaoyouchutian_YY",false,false,1,1,2028,841,396,789,380,2679,2944,789,538,2679,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoniaoyouchutian_yy"}, get);
tb[401905] = P({D[9034], 401905,14,42,118,"「偉大なるフリット・ドーナツの名の下に命じる、召喚に応えたまえ―って、あれれ～？　なんか属性すら違う子が出てきちゃった～……えっと……な、汝は、この魂天戦争に参加する覚悟は出来ておるか～？」",200019,2,"deco/character/xiaoniaoyouchutian_YSJ",1909,883,380,155,31,3272,3364,340,572,2902,1261,false,false,false,false,false,false,false,false,false,false,false,false,"xiaoniaoyouchutian_ysj"}, get);
tb[401906] = P({D[23034], 401906,9,34,119,"「お日様までなんだかふわふわ……ふぁ～……寝ちゃいそう～……。ダメダメ、これじゃせっかくの雀士さんと二人きりの時間がもったいない。あ、そうだ！　よかったら一緒にアイスクリーム食べませんか～？」",200019,2,"deco/character/xiaoniaoyouchutian_SY",false,false,false,false,false,false,false,"1",false,false,false,"120,-380,1","100,0,1","100,0,1",1614,1161,397,896,44,2792,2669,896,859,2792,1261,1,4513,5000,2154,3162,5333,5333,10666,5333,12000,8000,5333,"xiaoniaoyouchutian_sy"}, get);
tb[401907] = P({D[9045], 401907,18,65,120,"「ブランコが一番高い所まで上がった時にお願い事をすると、十二神様たちの耳に早く届くんだって～。\nあ、でも、一緒にいたいな～ってお願いなら、神様じゃなくて、あなたが叶えてくれるよね～！ えへへ～」",200019,2,"deco/character/xiaoniaoyouchutian_xl",1,2351,5000,1106,2148,6666,10333,8000,10000,17000,10000,6666,"xiaoniaoyouchutian_xl"}, get);