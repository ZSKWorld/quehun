-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][skin]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local skin = require("Excels.Data.item_definition.skin")
local tb = skin.tb
local get = skin.get

tb[402001] = P({D[17023], 402001,false,66,121,false,200020,false,"deco/character/wushilanyangcai",302002,60,1,false,false,false,300,"1","0,-230,1.1","-80,80,1","-50,60,1",false,false,false,"-80,80,1","0,80,1",false,false,false,1845,1035,390,1682,849,1161,1780,1682,849,1161,1141}, get);
tb[402002] = P({D[11034], 402002,1,4,122,"「じゃじゃーん！ 陽菜の猫ちゃんカフェ、オープンしたよー！\nお客さま、アイスキャンディーはいかがですか？」",200020,1,"deco/character/wushilanyangcai_0",302002,60,1948,971,390,621,576,2922,2538,631,665,2902}, get);
tb[402003] = P({D[12034], 402003,2,22,123,"「約束だよ～！　今日の水鉄砲バトルで陽菜が勝ったら、アイス10本奢ってもらうからね～！」",200020,2,"deco/character/wushilanyangcai_YZ",false,false,1,1852,975,400,1161,838,1964,1620,1161,838,1964,1097}, get);
tb[402004] = P({D[9034], 402004,7,53,124,"「陽菜が書いた猫ちゃん、かっこいいでしょー！　お母さんが買ってくれたクレヨンで陽菜の猫ちゃん軍団を強くしていくぞー！」",200020,2,"deco/character/wushilanyangcai_KX",1834,1061,420,1010,763,1895,1814,1010,770,1895}, get);
tb[402005] = P({D[12034], 402005,5,67,125,"「猫ちゃん軍団、かかれー！　最初にこの『大吉』を雀士さんの額に貼り付けた子には、ご褒美のにぼしをあげちゃうぞー！」",200020,2,"deco/character/402005",false,false,1,1907,918,399,955,571,2361,2506,955,617,2361,false,1,4514,5000,2095,4593,6000,6000,6000,6000,9000,false,6000,false,false,0}, get);
tb[402006] = P({D[21034], 402006,9,34,126,"「あれ？　チョコアイスが、風船みたいにぷ〜かぷか……陽菜をねこちゃんランドに連れてってくれるのぉ？　えへへ～、このアイス、雀士さんの手みたいにあったか～い……え！？　雀士さん！？　いつからいたの！？　う、うわあぁぁー！」",200020,2,"deco/character/wushilanyangcai_SY",false,false,false,false,false,false,false,"1",false,false,false,"240,-400,1",1838,1005,399,800,346,2663,2230,800,704,2663}, get);
tb[402101] = P({D[46057], 402101,false,68,127,false,200021,false,"deco/character/lianggongxingshu",302002,60,false,false,false,false,68,"1",false,false,false,false,false,false,false,"0,-220,1.06","-90,0,1","0,-20,1",false,false,false,"-40,0,1","-40,0,1",false,false,false,1915,873,400,1491,730,1594,2177,1491,730,1594,1103,"lianggongxingshu"}, get);
tb[402102] = P({D[12034], 402102,1,4,128,"質問：なぜ、雀士さんの日常活動記録にて、KR-976の出現頻度が上昇しているのでしょうか」",200021,1,"deco/character/lianggongxingshu_0",302002,60,1,1921,901,400,1229,778,1674,2009,1229,778,1674,1083,false,false,false,false,false,false,false,false,false,false,false,false,"lianggongxingshu_0"}, get);
tb[402103] = P({D[9034], 402103,9,69,129,"「警告。KR-976のバッテリー駆動時間は残り2時間半になりました」",200021,2,"deco/character/lianggongxingshu_SY",1712,1078,382,541,643,2671,2684,541,768,2671,false,false,false,false,false,false,false,false,false,false,false,false,false,"lianggongxingshu_sy"}, get);
tb[402104] = P({D[13034], 402104,11,64,130,"「質問、雀士さんが今楽しいと思ってるのは食べ物が美味しいからですか？　KR-976は嬉しい感情を感知しましたが、ソースを解析できませんでした。KR-976は、今後雀士さんにより楽しい体験を提供したいです。」",200021,2,"deco/character/402104",false,false,1,1,1857,975,425,734,false,2784,3520,734,687,2784,false,1,1550,5000,716,1756,8000,8000,8000,8000,8000,8000,8000,"lianggongxingshu_yy",false,0}, get);
tb[402105] = P({D[46057], 402105,6,70,131,"「質問：現在KR-976が所持しているお年玉を雀士さんに渡す場合、適したタイミングはいつでしょうか。後輩はあげるんじゃなくてもらう方？　え、えっと……。回答：KR-976はこのお年玉を雀士さんと分け合うべきだと考えます。」",200021,2,"deco/character/lianggongxingshu_CJ",false,false,1,false,false,false,false,"1",false,"0,0,1.04","-80,0,1.04","60,-140,1.04","0,0,1.04","-80,0,1.04","-100,20,1.04",false,false,false,false,false,false,false,false,false,false,false,1984,987,390,747,739,2769,2586,747,739,2769,1203,"lianggongxingshu_cj"}, get);
tb[402106] = P({D[9044], 402106,17,71,132,"分析：本日の雀士さんのKR-976への注視度……通常の2倍以上。\n結論：雀士さんは白いチュチュが好み。\n……対応する嗜好リストを更新し、関連情報をKR-976の最高機密ファイルにバックアップ。",200021,2,"deco/character/lianggongxingshu_BL",0,1,869,5000,464,765,5333,5000,7000,8333,14000,8000,5333,"lianggongxingshu_bl"}, get);
tb[402201] = P({D[16023], 402201,false,72,133,false,200022,false,"deco/character/yuesefu",302002,60,false,false,false,false,-27,"90,550,0.94","-90,40,1","0,30,1",false,false,false,"-60,60,1","-40,60,1",false,false,false,1903,867,400,1393,752,1520,3178,1393,752,1520,1075}, get);
tb[402202] = P({D[12034], 402202,1,4,134,"「Oh！ My Partnerじゃないか！\n次の目的地はもう決まってるぜ！ Let\'s go!」",200022,1,"deco/character/yuesefu_0",302002,60,1,1984,959,414,1014,558,2181,2865,1014,665,2181}, get);
tb[402203] = P({D[21034], 402203,5,41,135,"「Happy New Year！　My Friend。エスニックで伝統的なファッションだが、意外とジェントルマンなオーラが出てる感じがしないか？」",200022,2,"deco/character/yuesefu_YD",false,false,1,1,false,false,false,"1","2020-12-30 05:00:00+08",false,false,"0,-400,1",1951,984,315,1041,419,2118,2158,1041,641,2118}, get);