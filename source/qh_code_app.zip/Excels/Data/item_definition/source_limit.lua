-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][source_limit]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["item_id"] = 2; ["item_limit"] = 3;};

local df = {  10008, 309036, 10,};

local get = function(item, k) return G(item, k, n2i, df); end;


local source_limit = { }
source_limit[10000] = {
	P({10000,309008}, get),
	P({10000,309009}, get),
	P({10000,309010}, get),
};
source_limit[10001] = {
	P({10001,309013}, get),
	P({10001,309014}, get),
	P({10001,309015}, get),
};
source_limit[10002] = {
	P({10002,309019}, get),
	P({10002,309020}, get),
	P({10002,309021}, get),
};
source_limit[10003] = {
	P({10003,309024}, get),
	P({10003,309025}, get),
	P({10003,309026}, get),
};
source_limit[10004] = {
	P({10004,309030,50}, get),
};
source_limit[10005] = {
	P({10005,309031}, get),
	P({10005,309032}, get),
	P({10005,309033}, get),
};
source_limit[10006] = {
	P({10006,309035,50000}, get),
};
source_limit[10007] = {
	P({10007,false,3}, get),
};
source_limit[10008] = {
	P({D[1002], 3}, get),
	P({false,309042}, get),
	P({false,309043}, get),
	P({false,309044}, get),
	P({D[1002], 1}, get),
};
source_limit[10009] = {
	P({10009,309053}, get),
	P({10009,309054}, get),
	P({10009,309055}, get),
};
source_limit[10010] = {
	P({10010,309060}, get),
	P({10010,309061}, get),
	P({10010,309062}, get),
};
source_limit[10011] = {
	P({10011,false,1}, get),
};
source_limit[10012] = {
	P({10012,false,2}, get),
};
source_limit[10013] = {
	P({10013,309073}, get),
	P({10013,309074}, get),
	P({10013,309075}, get),
};
source_limit[10014] = {
	P({10014,30900007,99999}, get),
};
source_limit[10015] = {
	P({10015,30900025}, get),
	P({10015,30900026}, get),
	P({10015,30900027}, get),
};
source_limit[10016] = {
	P({10016,30900086}, get),
	P({10016,30900087}, get),
	P({10016,30900088}, get),
};
return { tb = source_limit };