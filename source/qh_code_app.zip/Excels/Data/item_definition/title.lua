-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][title]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["desc_chs"] = -3; ["desc_chs_t"] = -3; ["desc_jp"] = -3; ["desc_en"] = -3; ["desc_kr"] = -3; ["icon"] = 1004; ["icon_item"] = 1005; ["priority"] = 6; ["unlock_type"] = 7; ["unlock_param"] = 8; ["cross_view"] = 9;};

local df = {  nil,  nil,  nil, "deco/title/24sxz2/pic/24sxz2.png", "deco/title/24sxz2/pic/24sxz2_item.jpg", nil, 1, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "item_definition_title"); end;

local b2i = {600040,600102,600169,}

local title = { }
return { tb = title, get = get, b2i = b2i };