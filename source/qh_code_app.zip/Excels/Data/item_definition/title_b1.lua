-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][title]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local title = require("Excels.Data.item_definition.title")
local tb = title.tb
local get = title.get

tb[600001] = P({600001,1,false,"deco/title/notitle/pic/notitle.png","deco/title/notitle/pic/notitle.png",1,0,S({})}, get);
tb[600002] = P({600002,2,1,"deco/title/yuanchuzhihuo/pic/yuanchuzhihuo.png","deco/title/yuanchuzhihuo/pic/yuanchuzhihuo.png",2,0,S({})}, get);
tb[600003] = P({600003,3,2,"deco/title/yinghuozhiguang/pic/yinghuozhiguang.png","deco/title/yinghuozhiguang/pic/yinghuozhiguang.png",3,0,S({})}, get);
tb[600004] = P({600004,4,3,"deco/title/zuichuquesheng/pic/zuichuquesheng.png","deco/title/zuichuquesheng/pic/zuichuquesheng.png",4,0,S({})}, get);
tb[600005] = P({600005,5,4,"deco/title/hunzhiqiyuezhe1/pic/hunzhiqiyuezhe1.png","deco/title/hunzhiqiyuezhe1/pic/hunzhiqiyuezhe1.png",10001,0,S({})}, get);
tb[600006] = P({600006,6,5,"deco/title/hunzhiqiyuezhe2/pic/hunzhiqiyuezhe2.png","deco/title/hunzhiqiyuezhe2/pic/hunzhiqiyuezhe2.png",10002,0,S({})}, get);
tb[600007] = P({600007,7,6,"deco/title/hunzhiqiyuezhe3/pic/hunzhiqiyuezhe3.png","deco/title/hunzhiqiyuezhe3/pic/hunzhiqiyuezhe3.png",10003,0,S({})}, get);
tb[600008] = P({600008,8,7,"deco/title/hunzhiqidizhe1/pic/hunzhiqidizhe1.png","deco/title/hunzhiqidizhe1/pic/hunzhiqidizhe1.png",10004,0,S({})}, get);
tb[600009] = P({600009,9,8,"deco/title/hunzhiqidizhe2/pic/hunzhiqidizhe2.png","deco/title/hunzhiqidizhe2/pic/hunzhiqidizhe2.png",10005,0,S({})}, get);
tb[600010] = P({600010,10,9,"deco/title/hunzhiqidizhe3/pic/hunzhiqidizhe3.png","deco/title/hunzhiqidizhe3/pic/hunzhiqidizhe3.png",10006,0,S({})}, get);
tb[600011] = P({600011,11,10,"deco/title/hunzhidizaozhe1/pic/hunzhidizaozhe1.png","deco/title/hunzhidizaozhe1/pic/hunzhidizaozhe1.png",10007,0,S({})}, get);
tb[600012] = P({600012,12,11,"deco/title/hunzhidizaozhe2/pic/hunzhidizaozhe2.png","deco/title/hunzhidizaozhe2/pic/hunzhidizaozhe2.png",10008,0,S({})}, get);
tb[600013] = P({600013,13,12,"deco/title/hunzhidizaozhe3/pic/hunzhidizaozhe3.png","deco/title/hunzhidizaozhe3/pic/hunzhidizaozhe3.png",10009,0,S({})}, get);
tb[600014] = P({600014,14,13,"deco/title/hunzhichaoyuezhe/pic/hunzhichaoyuezhe.png","deco/title/hunzhichaoyuezhe/pic/hunzhichaoyuezhe.png",10010,0,S({})}, get);
tb[600015] = P({600015,15,14,"deco/title/maolianggongyingshang/pic/maolianggongyingshang.png","deco/title/maolianggongyingshang/pic/maolianggongyingshang.png",10011,0,S({})}, get);
tb[600016] = P({600016,16,15,"deco/title/zuichuhuntian/pic/zuichuhuntian.png","deco/title/zuichuhuntian/pic/zuichuhuntian.png",5,0,S({})}, get);
tb[600017] = P({600017,17,16,"deco/title/gai/pic/gai.png","deco/title/gai/pic/gai.png",6,0,S({})}, get);
tb[600018] = P({600018,18,17,"deco/title/12dora/pic/12dora.png","deco/title/12dora/pic/12dora_item.jpg",7,0,S({})}, get);
tb[600019] = P({600019,19,18,"deco/title/ganjunwudi/pic/ganjunwudi.png","deco/title/ganjunwudi/pic/ganjunwudi_item.jpg",8,0,S({})}, get);
tb[600020] = P({600020,20,19,"deco/title/zuocangshayejia/pic/zuocangshayejia.png","deco/title/zuocangshayejia/pic/zuocangshayejia_item.jpg",9,0,S({})}, get);
tb[600021] = P({600021,21,20,"deco/title/miaoguodahufa/pic/miaoguodahufa.png","deco/title/miaoguodahufa/pic/miaoguodahufa.jpg",10012,0,S({})}, get);
tb[600022] = P({600022,4,21,"deco/title/zuichuquesheng3/pic/zuichuquesheng3.png","deco/title/zuichuquesheng3/pic/zuichuquesheng3_item.jpg",10,0,S({})}, get);
tb[600023] = P({600023,16,22,"deco/title/zuichuhuntian3/pic/zuichuhuntian3.png","deco/title/zuichuhuntian3/pic/zuichuhuntian3_item.jpg",11,0,S({})}, get);
tb[600024] = P({600024,22,23,"deco/title/2434chudai/pic/2434chudai.png","deco/title/2434chudai/pic/2434chudai_item.jpg",40001,0,S({})}, get);
tb[600025] = P({600025,23,24,"deco/title/2434chudai/pic/2434chudai.png","deco/title/2434chudai/pic/2434chudai_item.jpg",0,false,S({305556,})}, get);
tb[600026] = P({600026,24,25,"deco/title/japan_g/pic/japan_g.png","deco/title/japan_g/pic/japan_g_item.jpg",12,0,S({})}, get);
tb[600027] = P({600027,25,26,"deco/title/wanxianggengxin/pic/wanxianggengxin.png","deco/title/wanxianggengxin/pic/wanxianggengxin_item.jpg",13,0,S({})}, get);
tb[600028] = P({600028,26,27,"deco/title/trial/pic/trial.png","deco/title/trial/pic/trial_item.jpg",30001,0,S({})}, get);
tb[600029] = P({600029,27,28,"deco/title/interhigh/pic/interhigh.png","deco/title/interhigh/pic/interhigh_item.jpg",40002,false,S({305557,})}, get);
tb[600031] = P({600031,28,29,"deco/title/achievementgroup1/pic/achievementgroup1.png","deco/title/achievementgroup1/pic/achievementgroup1_item.jpg",20099,0,S({})}, get);
tb[600032] = P({600032,29,30,"deco/title/achievementgroup2/pic/achievementgroup2.png","deco/title/achievementgroup2/pic/achievementgroup2_item.jpg",20098,0,S({})}, get);
tb[600033] = P({600033,30,31,"deco/title/achievementgroup3/pic/achievementgroup3.png","deco/title/achievementgroup3/pic/achievementgroup3_item.jpg",20097,0,S({})}, get);
tb[600034] = P({600034,31,32,"deco/title/achievementgroup4/pic/achievementgroup4.png","deco/title/achievementgroup4/pic/achievementgroup4_item.jpg",20096,0,S({})}, get);
tb[600035] = P({600035,32,33,"deco/title/achievementgroup5/pic/achievementgroup5.png","deco/title/achievementgroup5/pic/achievementgroup5_item.jpg",20095,0,S({})}, get);
tb[600036] = P({600036,33,34,"deco/title/achievementgroup6/pic/achievementgroup6.png","deco/title/achievementgroup6/pic/achievementgroup6_item.jpg",20094,0,S({})}, get);
tb[600037] = P({600037,34,35,"deco/title/achievementgroup7/pic/achievementgroup7.png","deco/title/achievementgroup7/pic/achievementgroup7_item.jpg",20093,0,S({})}, get);
tb[600038] = P({600038,35,36,"deco/title/achievementgroup8/pic/achievementgroup8.png","deco/title/achievementgroup8/pic/achievementgroup8_item.jpg",20092,0,S({})}, get);
tb[600039] = P({600039,36,37,"deco/title/achievementgroup9/pic/achievementgroup9.png","deco/title/achievementgroup9/pic/achievementgroup9_item.jpg",20091,0,S({})}, get);
tb[600040] = P({600040,37,38,"deco/title/achievementgroup10/pic/achievementgroup10.png","deco/title/achievementgroup10/pic/achievementgroup10_item.jpg",20090,0,S({})}, get);