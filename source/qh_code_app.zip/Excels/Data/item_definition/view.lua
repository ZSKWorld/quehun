-- 由 Excel 自动生成的 Lua 表
-- 文件:   [item_definition][view]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["id"] = 1; ["res_name"] = 1002; ["audio_id"] = 3; ["character_id"] = 4; ["sargs"] = 1005; ["old_effect_mark"] = 6; ["hand_version"] = 7; ["seat_related"] = 8; ["old_lobby_background_mark"] = 9;};

local df = {  nil, "headframe_sxz", nil, nil, nil, 1, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {305719,30990014,}

local view = { }
return { tb = view, get = get, b2i = b2i };