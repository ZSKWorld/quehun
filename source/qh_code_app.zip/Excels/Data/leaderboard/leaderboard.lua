-- 由 Excel 自动生成的 Lua 表
-- 文件:   [leaderboard][leaderboard]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["start_time"] = 1002; ["end_time"] = 1003; ["refresh_cd"] = 4; ["max_count"] = 5; ["show_list"] = 1006;};

local df = {  nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local leaderboard = { }
leaderboard[1010] = P({1010,"2019-05-28 05:00:00+08","2019-06-28 04:59:00+08",60,20000,"1,2,3,4,5,6,7,8,9,10,100,200"}, get);
return { tb = leaderboard };