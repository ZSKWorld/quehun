-- 由 Excel 自动生成的 Lua 表
-- 文件:   [level_definition][character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["level"] = 1; ["character_id"] = 2; ["exp"] = 3; ["reward"] = 1004; ["unlock_says"] = 5; ["unlock_desc_chs"] = -6; ["unlock_desc_chs_t"] = -6; ["unlock_desc_jp"] = -6; ["unlock_desc_en"] = -6; ["unlock_desc_kr"] = -6;};

local df = {  1, nil, 2000, nil, nil,  nil,};

local get = function(item, k) return G(item, k, n2i, df, "level_definition_character"); end;


local character = { }
character[0] = {
	P({D[1005], 1}, get),
	P({D[4005], 2,false,6000,2}, get),
	P({D[4005], 3,false,10000,2}, get),
	P({D[4005], 4,false,20000,3}, get),
	P({D[4005], 5,false,50000,4}, get),
};
character[200052] = {
	P({D[3005], false,200052,1}, get),
	P({2,200052,6000,"305315-1",false,2}, get),
	P({3,200052,10000,"305215-1",false,2}, get),
	P({4,200052,20000,"305529-1",false,3}, get),
	P({D[4005], 5,200052,50000,4}, get),
};
character[200061] = {
	P({D[3005], false,200061,1}, get),
	P({2,200061,6000,"305319-1",false,2}, get),
	P({3,200061,10000,"305219-1",false,2}, get),
	P({4,200061,20000,"305537-1",false,3}, get),
	P({D[4005], 5,200061,50000,4}, get),
};
character[200076] = {
	P({D[3005], false,200076,1}, get),
	P({2,200076,6000,"305323-1",false,2}, get),
	P({3,200076,10000,"305223-1",false,2}, get),
	P({4,200076,20000,"305551-1",false,3}, get),
	P({D[4005], 5,200076,50000,4}, get),
};
character[200095] = {
	P({D[3005], false,200095,1}, get),
	P({2,200095,6000,"30530006-1",false,2}, get),
	P({3,200095,10000,"30520006-1",false,2}, get),
	P({4,200095,20000,"30550012-1",false,3}, get),
	P({D[4005], 5,200095,50000,4}, get),
};
character[20000112] = {
	P({D[3005], false,20000112,1}, get),
	P({2,20000112,6000,"30530009-1",false,2}, get),
	P({3,20000112,10000,"30520009-1",false,2}, get),
	P({4,20000112,20000,"30550030-1",false,3}, get),
	P({D[4005], 5,20000112,50000,4}, get),
};
return { tb = character };