-- 由 Excel 自动生成的 Lua 表
-- 文件:   [level_definition][level_definition]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["primary_level"] = 3; ["secondary_level"] = 4; ["init_point"] = 5; ["end_point"] = 6; ["primary_icon"] = 1007; ["name_chs"] = -8; ["name_chs_t"] = -8; ["name_jp"] = -8; ["name_en"] = -8; ["name_kr"] = -8; ["full_name_chs"] = -9; ["full_name_chs_t"] = -9; ["full_name_jp"] = -9; ["full_name_en"] = -9; ["full_name_kr"] = -9; ["can_degrade"] = 10; ["can_upgrade"] = 11; ["can_getpoint"] = 12; ["rankpt1"] = 13; ["rankpt2"] = 14; ["top_rank_id"] = 15;};

local df = {  nil, 1, 6, 3, 1000, 2000, "ui/common/main/pic/sima_huntian.png",  nil,  nil, 1, 1, 1, nil, nil, 1001,};

local get = function(item, k) return G(item, k, n2i, df, "level_definition_level_definition"); end;


local level_definition = { }
level_definition[10101] = P({D[11014], 10101,false,1,1,0,20,"ui/common/main/pic/sima_fish.png",1,1,0,0}, get);
level_definition[10102] = P({D[11014], 10102,false,1,2,0,80,"ui/common/main/pic/sima_fish.png",1,2,0,0}, get);
level_definition[10103] = P({D[11014], 10103,false,1,false,0,200,"ui/common/main/pic/sima_fish.png",1,3,0,0}, get);
level_definition[10201] = P({D[11012], 10201,false,2,1,300,600,"ui/common/main/pic/sima_queshi.png",2,4,0,-10,-20,0}, get);
level_definition[10202] = P({D[10012], 10202,false,2,2,400,800,"ui/common/main/pic/sima_queshi.png",2,5,-20,-40,0}, get);
level_definition[10203] = P({D[10012], 10203,false,2,false,500,1000,"ui/common/main/pic/sima_queshi.png",2,6,-30,-60,0}, get);
level_definition[10301] = P({D[10012], 10301,false,3,1,600,1200,"ui/common/main/pic/sima_quejie.png",3,7,-40,-80,0}, get);
level_definition[10302] = P({D[10012], 10302,false,3,2,700,1400,"ui/common/main/pic/sima_quejie.png",3,8,-50,-100,0}, get);
level_definition[10303] = P({D[4006], 10303,false,3,"ui/common/main/pic/sima_quejie.png",3,9,false,false,false,-60,-120,0}, get);
level_definition[10401] = P({D[10012], 10401,false,4,1,1400,2800,"ui/common/main/pic/sima_quehao.png",4,10,-80,-165,0}, get);
level_definition[10402] = P({D[10012], 10402,false,4,2,1600,3200,"ui/common/main/pic/sima_quehao.png",4,11,-90,-180,0}, get);
level_definition[10403] = P({D[10012], 10403,false,4,false,1800,3600,"ui/common/main/pic/sima_quehao.png",4,12,-100,-195,0}, get);
level_definition[10501] = P({D[10012], 10501,false,5,1,2000,4000,"ui/common/main/pic/sima_quesheng.png",5,13,-110,-210,0}, get);
level_definition[10502] = P({D[10012], 10502,false,5,2,3000,6000,"ui/common/main/pic/sima_quesheng.png",5,14,-120,-225,0}, get);
level_definition[10503] = P({D[10012], 10503,false,5,false,4500,9000,"ui/common/main/pic/sima_quesheng.png",5,15,-130,-240,0}, get);
level_definition[10601] = P({10601,false,0,false,10000,99999,false,6,16,0,0,false,-140,-255,0}, get);
level_definition[10701] = P({D[5007], 10701,false,false,1,6,17}, get);
level_definition[10702] = P({D[5007], 10702,false,false,2,6,18}, get);
level_definition[10703] = P({D[2007], 10703,6,19}, get);
level_definition[10704] = P({D[5007], 10704,false,false,4,6,20}, get);
level_definition[10705] = P({D[5007], 10705,false,false,5,6,21}, get);
level_definition[10706] = P({D[5007], 10706,false,false,6,6,22}, get);
level_definition[10707] = P({D[5007], 10707,false,false,7,6,23}, get);
level_definition[10708] = P({D[5007], 10708,false,false,8,6,24}, get);
level_definition[10709] = P({D[5007], 10709,false,false,9,6,25}, get);
level_definition[10710] = P({D[5007], 10710,false,false,10,6,26}, get);
level_definition[10711] = P({D[5007], 10711,false,false,11,6,27}, get);
level_definition[10712] = P({D[5007], 10712,false,false,12,6,28}, get);
level_definition[10713] = P({D[5007], 10713,false,false,13,6,29}, get);
level_definition[10714] = P({D[5007], 10714,false,false,14,6,30}, get);
level_definition[10715] = P({D[5007], 10715,false,false,15,6,31}, get);
level_definition[10716] = P({D[5007], 10716,false,false,16,6,32}, get);
level_definition[10717] = P({D[5007], 10717,false,false,17,6,33}, get);
level_definition[10718] = P({D[5007], 10718,false,false,18,6,34}, get);
level_definition[10719] = P({D[5007], 10719,false,false,19,6,35}, get);
level_definition[10720] = P({D[2003], 10720,20,false,99999,false,6,36,false,0}, get);
level_definition[20101] = P({D[11014], 20101,2,1,1,0,20,"ui/common/main/pic/sanma_fish.png",1,1,0,0}, get);
level_definition[20102] = P({D[11014], 20102,2,1,2,0,80,"ui/common/main/pic/sanma_fish.png",1,2,0,0}, get);
level_definition[20103] = P({D[11014], 20103,2,1,false,0,200,"ui/common/main/pic/sanma_fish.png",1,3,0,0}, get);
level_definition[20201] = P({D[11012], 20201,2,2,1,300,600,"ui/common/main/pic/sanma_queshi.png",2,4,0,-10,-20,0}, get);
level_definition[20202] = P({D[10012], 20202,2,2,2,400,800,"ui/common/main/pic/sanma_queshi.png",2,5,-20,-40,0}, get);
level_definition[20203] = P({D[10012], 20203,2,2,false,500,1000,"ui/common/main/pic/sanma_queshi.png",2,6,-30,-60,0}, get);
level_definition[20301] = P({D[10012], 20301,2,3,1,600,1200,"ui/common/main/pic/sanma_quejie.png",3,7,-40,-80,0}, get);
level_definition[20302] = P({D[10012], 20302,2,3,2,700,1400,"ui/common/main/pic/sanma_quejie.png",3,8,-50,-100,0}, get);
level_definition[20303] = P({D[4006], 20303,2,3,"ui/common/main/pic/sanma_quejie.png",3,9,false,false,false,-60,-120,0}, get);
level_definition[20401] = P({D[10012], 20401,2,4,1,1400,2800,"ui/common/main/pic/sanma_quehao.png",4,10,-80,-165,0}, get);
level_definition[20402] = P({D[10012], 20402,2,4,2,1600,3200,"ui/common/main/pic/sanma_quehao.png",4,11,-95,-190,0}, get);
level_definition[20403] = P({D[10012], 20403,2,4,false,1800,3600,"ui/common/main/pic/sanma_quehao.png",4,12,-110,-215,0}, get);
level_definition[20501] = P({D[10012], 20501,2,5,1,2000,4000,"ui/common/main/pic/sanma_quesheng.png",5,13,-125,-240,0}, get);
level_definition[20502] = P({D[10012], 20502,2,5,2,3000,6000,"ui/common/main/pic/sanma_quesheng.png",5,14,-140,-265,0}, get);
level_definition[20503] = P({D[10012], 20503,2,5,false,4500,9000,"ui/common/main/pic/sanma_quesheng.png",5,15,-160,-290,0}, get);
level_definition[20601] = P({20601,2,0,false,10000,99999,"ui/common/main/pic/sanma_huntian.png",6,16,0,0,false,-175,-320,0}, get);
level_definition[20701] = P({D[5006], 20701,2,false,1,"ui/common/main/pic/sanma_huntian.png",6,17}, get);
level_definition[20702] = P({D[5006], 20702,2,false,2,"ui/common/main/pic/sanma_huntian.png",6,18}, get);
level_definition[20703] = P({D[3006], 20703,2,"ui/common/main/pic/sanma_huntian.png",6,19}, get);
level_definition[20704] = P({D[5006], 20704,2,false,4,"ui/common/main/pic/sanma_huntian.png",6,20}, get);
level_definition[20705] = P({D[5006], 20705,2,false,5,"ui/common/main/pic/sanma_huntian.png",6,21}, get);
level_definition[20706] = P({D[5006], 20706,2,false,6,"ui/common/main/pic/sanma_huntian.png",6,22}, get);
level_definition[20707] = P({D[5006], 20707,2,false,7,"ui/common/main/pic/sanma_huntian.png",6,23}, get);
level_definition[20708] = P({D[5006], 20708,2,false,8,"ui/common/main/pic/sanma_huntian.png",6,24}, get);
level_definition[20709] = P({D[5006], 20709,2,false,9,"ui/common/main/pic/sanma_huntian.png",6,25}, get);
level_definition[20710] = P({D[5006], 20710,2,false,10,"ui/common/main/pic/sanma_huntian.png",6,26}, get);
level_definition[20711] = P({D[5006], 20711,2,false,11,"ui/common/main/pic/sanma_huntian.png",6,27}, get);
level_definition[20712] = P({D[5006], 20712,2,false,12,"ui/common/main/pic/sanma_huntian.png",6,28}, get);
level_definition[20713] = P({D[5006], 20713,2,false,13,"ui/common/main/pic/sanma_huntian.png",6,29}, get);
level_definition[20714] = P({D[5006], 20714,2,false,14,"ui/common/main/pic/sanma_huntian.png",6,30}, get);
level_definition[20715] = P({D[5006], 20715,2,false,15,"ui/common/main/pic/sanma_huntian.png",6,31}, get);
level_definition[20716] = P({D[5006], 20716,2,false,16,"ui/common/main/pic/sanma_huntian.png",6,32}, get);
level_definition[20717] = P({D[5006], 20717,2,false,17,"ui/common/main/pic/sanma_huntian.png",6,33}, get);
level_definition[20718] = P({D[5006], 20718,2,false,18,"ui/common/main/pic/sanma_huntian.png",6,34}, get);
level_definition[20719] = P({D[5006], 20719,2,false,19,"ui/common/main/pic/sanma_huntian.png",6,35}, get);
level_definition[20720] = P({20720,2,false,20,false,99999,"ui/common/main/pic/sanma_huntian.png",6,36,false,0}, get);
return { tb = level_definition };