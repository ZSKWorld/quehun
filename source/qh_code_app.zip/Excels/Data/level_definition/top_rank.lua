-- 由 Excel 自动生成的 Lua 表
-- 文件:   [level_definition][top_rank]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["rank_pt"] = 2; ["top_rank_pt"] = 3; ["mode"] = 4;};

local df = {  1001, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local top_rank = { }
top_rank[1001] = {
	P({false,S({30,10,-10,-30,}),S({60,20,-20,-60,}),1}, get),
	P({false,S({50,20,-20,-50,}),S({100,40,-40,-100,}),2}, get),
	P({false,S({30,0,-30,}),S({60,0,-60,}),11}, get),
	P({false,S({50,0,-50,}),S({100,0,-100,}),12}, get),
};
return { tb = top_rank };