-- 由 Excel 自动生成的 Lua 表
-- 文件:   [level_definition][trail]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["init_level"] = 2; ["end_level"] = 3; ["trail_icon"] = 4; ["trail_fire"] = 5;};

local df = {  nil, nil, nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local trail = { }
trail[1] = P({1,1,4}, get);
trail[2] = P({2,5,9,false,1}, get);
trail[3] = P({3,10,14,false,2}, get);
trail[4] = P({4,15,19,false,3}, get);
trail[5] = P({5,20,24,2}, get);
trail[6] = P({6,25,29,2,1}, get);
trail[7] = P({7,30,34,2,2}, get);
trail[8] = P({8,35,39,2,3}, get);
trail[9] = P({9,40,44,3}, get);
trail[10] = P({10,45,49,3,1}, get);
trail[11] = P({11,50,54,3,2}, get);
trail[12] = P({12,55,59,3,3}, get);
trail[13] = P({13,60,9999,4,-1}, get);
return { tb = trail };