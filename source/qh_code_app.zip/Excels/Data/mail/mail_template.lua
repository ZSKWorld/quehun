-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mail][mail_template]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["title"] = 1002; ["title_chs"] = -3; ["title_chs_t"] = -3; ["title_jp"] = -3; ["title_en"] = -3; ["title_kr"] = -3; ["content_template"] = 1004; ["content_template_chs"] = -5; ["content_template_chs_t"] = -5; ["content_template_jp"] = -5; ["content_template_en"] = -5; ["content_template_kr"] = -5; ["expire_type"] = 6; ["expire_param"] = 1007; ["attachments"] = 1008;};

local df = {  nil, nil,  nil, nil,  nil, 1, "30d", nil,};

local get = function(item, k) return G(item, k, n2i, df, "mail_mail_template"); end;


local mail_template = { }
mail_template[101] = P({101,"信仰值返还",false,"您曾经使用300信仰值兑换过雀士，目前信仰值兑换价格已下调为150，现已退还150信仰值到您的账户，感谢您的支持！",false,0,"",S({})}, get);
mail_template[102] = P({102,"辉玉返还",false,"根据您过往充值金额返还您30%的辉玉，感谢您对猫粮工作室的支持！",false,0,"",S({})}, get);
mail_template[103] = P({103,"月势御守补偿",false,"由于网站整改期间无法登陆游戏，您的月势御守有无法领取的情况，现按您未领取的天数返还，并根据您当前最高段位和未领取天数补偿铜币，感谢您的耐心等待和对我们的支持！",false,0,"",S({})}, get);
mail_template[104] = P({104,"輝玉轉換",false,"目前尋覓可通過消耗輝玉直接進行，已將您背包中的${xunmi}尋覓石轉換為等額的輝玉，感謝您對遊戲的理解與支持。",false,0,"",S({})}, get);
mail_template[105] = P({105,"開運御守の補填",false,"いつも「雀魂-じゃんたま-」を遊んでいただき、誠にありがとうございます。\n\n9月28日(月)に発生した不具合及び緊急メンテナンスの影響により、\n開運御守の毎日ボーナス(輝石60個)を正常に受領できなかった雀士の皆様に該当アイテム(輝石60個)を補填いたします。\n\nこの度はご迷惑をおかけしましたこと、深くお詫び申し上げます。\n\n※本メールは、9月29日(火)17:00～10月6日(火)16:59まで配布いたします。\n※9月28日(月)21:29までに作成されたアカウントが対象となります\n※メールは受信後、7日で削除されますのでご注意ください。",false,false,"7d",S({})}, get);
mail_template[106] = P({D[6007], 106,false,1,false,1,S({})}, get);
mail_template[107] = P({D[6007], 107,false,2,false,2,S({})}, get);
mail_template[108] = P({D[6007], 108,false,1,false,1,S({})}, get);
mail_template[109] = P({D[6007], 109,false,3,false,3,S({})}, get);
mail_template[110] = P({D[6007], 110,false,4,false,4,S({})}, get);
mail_template[111] = P({111,false,5,false,5,false,"7d",S({})}, get);
mail_template[112] = P({D[6007], 112,false,6,false,6,S({})}, get);
mail_template[113] = P({D[6007], 113,false,7,false,7,S({})}, get);
mail_template[114] = P({D[6007], 114,false,8,false,8,S({})}, get);
mail_template[115] = P({D[6007], 115,false,9,false,9,S({})}, get);
mail_template[116] = P({D[6007], 116,false,10,false,10,S({})}, get);
mail_template[117] = P({D[6007], 117,false,11,false,11,S({})}, get);
mail_template[118] = P({D[6007], 118,false,12,false,12,S({})}, get);
mail_template[119] = P({D[6007], 119,false,13,false,13,S({})}, get);
mail_template[120] = P({D[6007], 120,false,14,false,14,S({})}, get);
mail_template[121] = P({D[6007], 121,false,15,false,15,S({})}, get);
mail_template[122] = P({D[6007], 122,false,16,false,16,S({})}, get);
mail_template[123] = P({D[6007], 123,false,17,false,17,S({})}, get);
mail_template[124] = P({D[6007], 124,false,18,false,18,S({})}, get);
mail_template[125] = P({D[6007], 125,false,19,false,19,S({})}, get);
mail_template[126] = P({D[6007], 126,false,20,false,20,S({})}, get);
mail_template[127] = P({D[6007], 127,false,21,false,21,S({})}, get);
mail_template[128] = P({D[6007], 128,false,22,false,22,S({})}, get);
mail_template[129] = P({D[6007], 129,false,23,false,23,S({})}, get);
mail_template[130] = P({D[6007], 130,false,24,false,24,S({})}, get);
mail_template[131] = P({D[6007], 131,false,25,false,25,S({})}, get);
mail_template[132] = P({D[6007], 132,false,26,false,26,S({})}, get);
mail_template[133] = P({D[6007], 133,false,27,false,27,S({})}, get);
mail_template[134] = P({D[6007], 134,false,28,false,28,S({})}, get);
mail_template[135] = P({D[6007], 135,false,29,false,29,S({})}, get);
mail_template[136] = P({D[6007], 136,false,30,false,30,S({})}, get);
mail_template[137] = P({D[6007], 137,false,31,false,30,S({})}, get);
mail_template[138] = P({D[6007], 138,false,32,false,31,S({})}, get);
mail_template[139] = P({D[6007], 139,false,33,false,32,S({})}, get);
mail_template[140] = P({D[6007], 140,false,34,false,33,S({})}, get);
mail_template[141] = P({D[6007], 141,false,35,false,34,S({})}, get);
mail_template[142] = P({D[6007], 142,false,36,false,35,S({})}, get);
mail_template[143] = P({D[6007], 143,false,24,false,24,S({})}, get);
mail_template[144] = P({D[6007], 144,false,37,false,36,S({})}, get);
mail_template[145] = P({D[6007], 145,false,38,false,37,S({})}, get);
mail_template[10001] = P({10001,false,39,false,38,false,"2d",S({})}, get);
mail_template[10002] = P({10002,false,40,false,39,false,"7d",S({})}, get);
mail_template[10003] = P({10003,false,41,false,40,false,"7d",S({})}, get);
mail_template[10004] = P({10004,false,42,false,41,false,"7d",S({})}, get);
mail_template[10005] = P({10005,false,43,false,42,false,"7d",S({})}, get);
mail_template[10006] = P({10006,false,44,false,43,false,"7d",S({})}, get);
mail_template[10007] = P({10007,false,40,false,44,false,"7d",S({})}, get);
mail_template[10008] = P({10008,false,41,false,40,false,"7d",S({})}, get);
mail_template[10009] = P({10009,false,42,false,42,false,"7d",S({})}, get);
mail_template[10010] = P({10010,false,43,false,45,false,"7d",S({})}, get);
return { tb = mail_template };