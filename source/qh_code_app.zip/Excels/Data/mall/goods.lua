-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["desc"] = 1003; ["desc_chs"] = -4; ["desc_chs_t"] = -4; ["desc_jp"] = -4; ["desc_en"] = -4; ["desc_kr"] = -4; ["icon"] = 1005; ["resource_id"] = 6; ["resource_count"] = 7; ["vip_exp"] = 8; ["cny"] = 9; ["price"] = 1010; ["first_desc_chs"] = -11; ["first_desc_chs_t"] = -11; ["first_desc_jp"] = -11; ["first_desc_en"] = -11; ["first_desc_kr"] = -11; ["first_extend_add"] = 12; ["normal_desc_chs"] = -13; ["normal_desc_chs_t"] = -13; ["normal_desc_jp"] = -13; ["normal_desc_en"] = -13; ["normal_desc_kr"] = -13; ["normal_extend_add"] = 14; ["type"] = 15;};

local df = {  nil,  nil, "充满灵力的玉石，可以用来购买各种道具。",  nil, "extendRes/items/jade0.jpg", 100001, 1200, 30, nil, "12元",  nil, nil,  nil, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df, "mall_goods"); end;


local goods = { }
goods[1001] = P({D[5006], 1001,1,false,1,120,12,12,false,1,120,false}, get);
goods[1002] = P({1002,2,false,1,"extendRes/items/jade1.jpg",false,300,false,30,"30元",2,300,1,10}, get);
goods[1003] = P({1003,3,false,1,"extendRes/items/jade2.jpg",false,600,60,60,"60元",3,600,2,30}, get);
goods[1004] = P({1004,4,false,1,"extendRes/items/jade3.jpg",false,980,98,98,"98元",4,980,3,80}, get);
goods[1005] = P({1005,5,false,1,"extendRes/items/jade4.jpg",false,1280,128,128,"128元",5,1280,4,120}, get);
goods[1006] = P({1006,6,false,1,"extendRes/items/jade5.jpg",false,1980,198,198,"198元",6,1980,5,240}, get);
goods[1007] = P({1007,7,false,1,"extendRes/items/jade6.jpg",false,3280,328,328,"328元",7,3280,6,600}, get);
goods[1008] = P({1008,8,false,1,"extendRes/items/jade7.jpg",false,6480,648,648,"648元",8,6480,7,1800}, get);
goods[1101] = P({D[9010], 1101,9,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan0.jpg",100004,120,12,false,false,false,false,2}, get);
goods[1102] = P({D[8009], 1102,10,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan1.jpg",100004,300,"30元",false,false,false,false,2}, get);
goods[1103] = P({1103,11,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan2.jpg",100004,600,60,false,"60元",false,false,false,false,2}, get);
goods[1104] = P({1104,12,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan3.jpg",100004,980,98,false,"98元",false,false,false,false,2}, get);
goods[1105] = P({1105,13,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan4.jpg",100004,1280,128,false,"128元",false,false,false,false,2}, get);
goods[1106] = P({1106,14,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan5.jpg",100004,1980,198,false,"198元",false,false,false,false,2}, get);
goods[1107] = P({1107,15,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan6.jpg",100004,3280,328,false,"328元",false,false,false,false,2}, get);
goods[1108] = P({1108,16,"服装商店专用货币，可以用来给购买精美服饰送给心仪的角色。",2,"extendRes/items/fushiquan7.jpg",100004,6480,648,false,"648元",false,false,false,false,2}, get);
goods[2001] = P({D[5006], 2001,17,"さまざまな道具を買うのに使います。",1,80,9,12,"160円",9,80,8}, get);
goods[2002] = P({2002,18,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade1.jpg",false,325,37,30,"650円",10,325,9,5}, get);
goods[2003] = P({2003,19,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade2.jpg",false,500,57,60,"1,000円",11,500,10,10}, get);
goods[2004] = P({2004,20,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade3.jpg",false,900,104,98,"1,800円",12,900,11,60}, get);
goods[2005] = P({D[6007], 2005,21,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade4.jpg",139,128,"2,400円",13,1200,12,110}, get);
goods[2006] = P({2006,22,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade5.jpg",false,1900,221,198,"3,800円",14,1900,13,250}, get);
goods[2007] = P({2007,23,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade6.jpg",false,2450,285,328,"4,900円",15,2450,14,550}, get);
goods[2008] = P({2008,24,"さまざまな道具を買うのに使います。",1,"extendRes/items/jade7.jpg",false,5000,582,648,"10,000円",16,5000,15,1300}, get);
goods[2101] = P({2101,25,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan0.jpg",100004,80,9,false,"160円",17,false,16,false,2}, get);
goods[2102] = P({2102,26,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan1.jpg",100004,325,37,false,"650円",18,false,17,false,2}, get);
goods[2103] = P({2103,27,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan2.jpg",100004,500,57,false,"1,000円",19,false,18,false,2}, get);
goods[2104] = P({2104,28,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan3.jpg",100004,900,104,false,"1,800円",20,false,19,false,2}, get);
goods[2105] = P({2105,29,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan4.jpg",100004,false,139,false,"2,400円",21,false,20,false,2}, get);
goods[2106] = P({2106,30,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan5.jpg",100004,1900,221,false,"3,800円",22,false,21,false,2}, get);
goods[2107] = P({2107,31,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan6.jpg",100004,2450,285,false,"4,900円",23,false,22,false,2}, get);
goods[2108] = P({2108,32,"着せ替え衣装と交換するためのアイテム",2,"extendRes/items/fushiquan7.jpg",100004,5000,582,false,"10,000円",24,false,23,false,2}, get);
goods[3001] = P({D[5006], 3001,33,"Can be used to buy props.",1,60,6,12,"$0.99",25,60,false}, get);
goods[3002] = P({3002,2,"Can be used to buy props.",1,"extendRes/items/jade1.jpg",false,300,false,30,"$4.99",2,300,1,10}, get);
goods[3003] = P({3003,34,"Can be used to buy props.",1,"extendRes/items/jade2.jpg",false,480,48,60,"$7.99",26,480,24,30}, get);
goods[3004] = P({3004,35,"Can be used to buy props.",1,"extendRes/items/jade3.jpg",false,900,90,98,"$14.99",12,900,25,100}, get);
goods[3005] = P({D[6007], 3005,36,"Can be used to buy props.",1,"extendRes/items/jade4.jpg",120,128,"$19.99",13,1200,26,150}, get);
goods[3006] = P({3006,37,"Can be used to buy props.",1,"extendRes/items/jade5.jpg",false,1800,180,198,"$29.99",27,1800,27,300}, get);
goods[3007] = P({3007,38,"Can be used to buy props.",1,"extendRes/items/jade6.jpg",false,2400,240,328,"$39.99",28,2400,28,600}, get);
goods[3008] = P({3008,39,"Can be used to buy props.",1,"extendRes/items/jade7.jpg",false,4900,490,648,"$79.99",29,4900,29,1400}, get);
goods[3101] = P({3101,40,"A currency used to purchase outfits",2,"extendRes/items/fushiquan0.jpg",100004,60,6,false,"$0.99",false,false,false,false,2}, get);
goods[3102] = P({D[8009], 3102,10,"A currency used to purchase outfits",2,"extendRes/items/fushiquan1.jpg",100004,300,"$4.99",false,false,false,false,2}, get);
goods[3103] = P({3103,41,"A currency used to purchase outfits",2,"extendRes/items/fushiquan2.jpg",100004,480,48,false,"$7.99",false,false,false,false,2}, get);
goods[3104] = P({3104,42,"A currency used to purchase outfits",2,"extendRes/items/fushiquan3.jpg",100004,900,90,false,"$14.99",false,false,false,false,2}, get);
goods[3105] = P({3105,43,"A currency used to purchase outfits",2,"extendRes/items/fushiquan4.jpg",100004,false,120,false,"$19.99",false,false,false,false,2}, get);
goods[3106] = P({3106,44,"A currency used to purchase outfits",2,"extendRes/items/fushiquan5.jpg",100004,1800,180,false,"$29.99",false,false,false,false,2}, get);
goods[3107] = P({3107,45,"A currency used to purchase outfits",2,"extendRes/items/fushiquan6.jpg",100004,2400,240,false,"$39.99",false,false,false,false,2}, get);
goods[3108] = P({3108,46,"A currency used to purchase outfits",2,"extendRes/items/fushiquan7.jpg",100004,4900,490,false,"$79.99",false,false,false,false,2}, get);
goods[4001] = P({D[5006], 4001,47,"充滿靈力的玉石，可以用來購買各種道具。",1,65,7,12,"NT$33",30,65,false}, get);
goods[4002] = P({4002,48,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade1.jpg",false,340,34,30,"NT$170",31,340,30,10}, get);
goods[4003] = P({4003,49,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade2.jpg",false,660,66,60,"NT$330",32,660,31,60}, get);
goods[4004] = P({D[6007], 4004,36,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade3.jpg",120,98,"NT$590",13,1200,32,120}, get);
goods[4005] = P({4005,50,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade4.jpg",false,2100,210,128,"NT$990",33,2100,33,220}, get);
goods[4006] = P({4006,51,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade5.jpg",false,2800,280,198,"NT$1320",34,2800,34,310}, get);
goods[4007] = P({4007,52,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade6.jpg",false,3660,366,328,"NT$1690",35,3660,35,500}, get);
goods[4008] = P({4008,8,"充滿靈力的玉石，可以用來購買各種道具。",1,"extendRes/items/jade7.jpg",false,6480,648,648,"NT$2990",8,6480,36,1600}, get);
goods[4101] = P({4101,53,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan0.jpg",100004,65,7,false,"NT$33",false,false,false,false,2}, get);
goods[4102] = P({4102,54,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan1.jpg",100004,340,34,false,"NT$170",false,false,false,false,2}, get);
goods[4103] = P({4103,55,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan2.jpg",100004,660,66,false,"NT$330",false,false,false,false,2}, get);
goods[4104] = P({4104,43,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan3.jpg",100004,false,120,false,"NT$590",false,false,false,false,2}, get);
goods[4105] = P({4105,56,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan4.jpg",100004,2100,210,false,"NT$990",false,false,false,false,2}, get);
goods[4106] = P({4106,57,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan5.jpg",100004,2800,280,false,"NT$1320",false,false,false,false,2}, get);
goods[4107] = P({4107,58,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan6.jpg",100004,3660,366,false,"NT$1690",false,false,false,false,2}, get);
goods[4108] = P({4108,16,"服裝商店專用貨幣，可以用來給購買精美服飾送給心儀的角色。",2,"extendRes/items/fushiquan7.jpg",100004,6480,648,false,"NT$2990",false,false,false,false,2}, get);
goods[5001] = P({D[5006], 5001,59,"각종 아이템을 구매하는 데 쓰인다.",1,70,7,12,"₩1,500",36,70,false}, get);
goods[5002] = P({5002,60,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade1.jpg",false,350,35,30,"₩7,500",37,350,37,10}, get);
goods[5003] = P({5003,61,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade2.jpg",false,560,56,60,"₩12,000",38,560,38,30}, get);
goods[5004] = P({5004,62,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade3.jpg",false,1100,110,98,"₩23,000",39,1100,39,100}, get);
goods[5005] = P({5005,63,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade4.jpg",false,1450,145,128,"₩30,000",40,1450,40,150}, get);
goods[5006] = P({5006,64,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade5.jpg",false,2200,220,198,"₩45,000",41,2200,41,300}, get);
goods[5007] = P({5007,65,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade6.jpg",false,2930,293,328,"₩60,000",42,2930,42,600}, get);
goods[5008] = P({5008,66,"각종 아이템을 구매하는 데 쓰인다.",1,"extendRes/items/jade7.jpg",false,5800,580,648,"₩119,000",43,5800,43,1400}, get);
goods[5101] = P({5101,67,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan0.jpg",100004,70,7,false,"₩1,500",false,false,false,false,2}, get);
goods[5102] = P({5102,68,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan1.jpg",100004,350,35,false,"₩7,500",false,false,false,false,2}, get);
goods[5103] = P({5103,69,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan2.jpg",100004,560,56,false,"₩12,000",false,false,false,false,2}, get);
goods[5104] = P({5104,70,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan3.jpg",100004,1100,110,false,"₩23,000",false,false,false,false,2}, get);
goods[5105] = P({5105,71,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan4.jpg",100004,1450,145,false,"₩30,000",false,false,false,false,2}, get);
goods[5106] = P({5106,72,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan5.jpg",100004,2200,220,false,"₩45,000",false,false,false,false,2}, get);
goods[5107] = P({5107,73,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan6.jpg",100004,2930,293,false,"₩60,000",false,false,false,false,2}, get);
goods[5108] = P({5108,74,"스킨 상점 전용 화폐, 아름다운 옷을 구매하여 원하는 캐릭터에게 선물할 수 있다.",2,"extendRes/items/fushiquan7.jpg",100004,5800,580,false,"₩119,000",false,false,false,false,2}, get);
return { tb = goods };