-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][goods_shelves]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1001; ["goods_id"] = 2; ["currency_code"] = 1003; ["currency_price"] = 4; ["price"] = 1005; ["is_monthcard"] = 6;};

local df = {  "shelves_001", 1010, "JPY", 650000, "CNY 30", nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local goods_shelves = { }
goods_shelves["shelves_001"] = {
	P({D[1002], "CNY",30000,false,1}, get),
	P({false,1001,"CNY",12000,"CNY 12"}, get),
	P({false,1002,"CNY",30000}, get),
	P({false,1003,"CNY",60000,"CNY 60"}, get),
	P({false,1004,"CNY",98000,"CNY 98"}, get),
	P({false,1005,"CNY",128000,"CNY 128"}, get),
	P({false,1006,"CNY",198000,"CNY 198"}, get),
	P({false,1007,"CNY",328000,"CNY 328"}, get),
	P({false,1008,"CNY",648000,"CNY 648"}, get),
	P({false,1101,"CNY",12000,"CNY 12"}, get),
	P({false,1102,"CNY",30000}, get),
	P({false,1103,"CNY",60000,"CNY 60"}, get),
	P({false,1104,"CNY",98000,"CNY 98"}, get),
	P({false,1105,"CNY",128000,"CNY 128"}, get),
	P({false,1106,"CNY",198000,"CNY 198"}, get),
	P({false,1107,"CNY",328000,"CNY 328"}, get),
	P({false,1108,"CNY",648000,"CNY 648"}, get),
};
goods_shelves["shelves_002"] = {
	P({D[3004], "shelves_002",2010,"JPY 650",1}, get),
	P({"shelves_002",2001,false,160000,"JPY 160"}, get),
	P({D[3004], "shelves_002",2002,"JPY 650"}, get),
	P({"shelves_002",2003,false,1000000,"JPY 1000"}, get),
	P({"shelves_002",2004,false,1800000,"JPY 1800"}, get),
	P({"shelves_002",2005,false,2400000,"JPY 2400"}, get),
	P({"shelves_002",2006,false,3800000,"JPY 3800"}, get),
	P({"shelves_002",2007,false,4900000,"JPY 4900"}, get),
	P({"shelves_002",2008,false,10000000,"JPY 10000"}, get),
	P({"shelves_002",2101,false,160000,"JPY 160"}, get),
	P({D[3004], "shelves_002",2102,"JPY 650"}, get),
	P({"shelves_002",2103,false,1000000,"JPY 1000"}, get),
	P({"shelves_002",2104,false,1800000,"JPY 1800"}, get),
	P({"shelves_002",2105,false,2400000,"JPY 2400"}, get),
	P({"shelves_002",2106,false,3800000,"JPY 3800"}, get),
	P({"shelves_002",2107,false,4900000,"JPY 4900"}, get),
	P({"shelves_002",2108,false,10000000,"JPY 10000"}, get),
};
goods_shelves["shelves_003"] = {
	P({"shelves_003",3010,"USD",4990,"USD 4.99",1}, get),
	P({"shelves_003",3001,"USD",990,"USD 0.99"}, get),
	P({"shelves_003",3002,"USD",4990,"USD 4.99"}, get),
	P({"shelves_003",3003,"USD",7990,"USD 7.99"}, get),
	P({"shelves_003",3004,"USD",14990,"USD 14.99"}, get),
	P({"shelves_003",3005,"USD",19990,"USD 19.99"}, get),
	P({"shelves_003",3006,"USD",29990,"USD 29.99"}, get),
	P({"shelves_003",3007,"USD",39990,"USD 39.99"}, get),
	P({"shelves_003",3008,"USD",79990,"USD 79.99"}, get),
	P({"shelves_003",3101,"USD",990,"USD 0.99"}, get),
	P({"shelves_003",3102,"USD",4990,"USD 4.99"}, get),
	P({"shelves_003",3103,"USD",7990,"USD 7.99"}, get),
	P({"shelves_003",3104,"USD",14990,"USD 14.99"}, get),
	P({"shelves_003",3105,"USD",19990,"USD 19.99"}, get),
	P({"shelves_003",3106,"USD",29990,"USD 29.99"}, get),
	P({"shelves_003",3107,"USD",39990,"USD 39.99"}, get),
	P({"shelves_003",3108,"USD",79990,"USD 79.99"}, get),
};
goods_shelves["shelves_004"] = {
	P({"shelves_004",false,"NTD",170000,"NTD 170",1}, get),
	P({"shelves_004",4001,"NTD",33000,"NTD 33"}, get),
	P({"shelves_004",4002,"NTD",170000,"NTD 170"}, get),
	P({"shelves_004",4003,"NTD",330000,"NTD 330"}, get),
	P({"shelves_004",4004,"NTD",590000,"NTD 590"}, get),
	P({"shelves_004",4005,"NTD",990000,"NTD 990"}, get),
	P({"shelves_004",4006,"NTD",1320000,"NTD 1320"}, get),
	P({"shelves_004",4007,"NTD",1690000,"NTD 1690"}, get),
	P({"shelves_004",4008,"NTD",2990000,"NTD 2990"}, get),
	P({"shelves_004",4101,"NTD",33000,"NTD 33"}, get),
	P({"shelves_004",4102,"NTD",170000,"NTD 170"}, get),
	P({"shelves_004",4103,"NTD",330000,"NTD 330"}, get),
	P({"shelves_004",4104,"NTD",590000,"NTD 590"}, get),
	P({"shelves_004",4105,"NTD",990000,"NTD 990"}, get),
	P({"shelves_004",4106,"NTD",1320000,"NTD 1320"}, get),
	P({"shelves_004",4107,"NTD",1690000,"NTD 1690"}, get),
	P({"shelves_004",4108,"NTD",2990000,"NTD 2990"}, get),
};
goods_shelves["shelves_005"] = {
	P({D[3004], "shelves_005",2010,"650 ポイント",1}, get),
	P({"shelves_005",2001,false,160000,"160 ポイント"}, get),
	P({D[3004], "shelves_005",2002,"650 ポイント"}, get),
	P({"shelves_005",2003,false,1000000,"1000 ポイント"}, get),
	P({"shelves_005",2004,false,1800000,"1800 ポイント"}, get),
	P({"shelves_005",2005,false,2400000,"2400 ポイント"}, get),
	P({"shelves_005",2006,false,3800000,"3800 ポイント"}, get),
	P({"shelves_005",2007,false,4900000,"4900 ポイント"}, get),
	P({"shelves_005",2008,false,10000000,"10000 ポイント"}, get),
	P({"shelves_005",2101,false,160000,"160 ポイント"}, get),
	P({D[3004], "shelves_005",2102,"650 ポイント"}, get),
	P({"shelves_005",2103,false,1000000,"1000 ポイント"}, get),
	P({"shelves_005",2104,false,1800000,"1800 ポイント"}, get),
	P({"shelves_005",2105,false,2400000,"2400 ポイント"}, get),
	P({"shelves_005",2106,false,3800000,"3800 ポイント"}, get),
	P({"shelves_005",2107,false,4900000,"4900 ポイント"}, get),
	P({"shelves_005",2108,false,10000000,"10000 ポイント"}, get),
};
goods_shelves["shelves_006"] = {
	P({"shelves_006",false,"USD",5500,"USD 5.50",1}, get),
	P({"shelves_006",4001,"USD",1100,"USD 1.10"}, get),
	P({"shelves_006",4002,"USD",5500,"USD 5.50"}, get),
	P({"shelves_006",4003,"USD",10500,"USD 10.50"}, get),
	P({"shelves_006",4004,"USD",18990,"USD 18.99"}, get),
	P({"shelves_006",4005,"USD",32990,"USD 32.99"}, get),
	P({"shelves_006",4006,"USD",43990,"USD 43.99"}, get),
	P({"shelves_006",4007,"USD",56990,"USD 56.99"}, get),
	P({"shelves_006",4008,"USD",99990,"USD 99.99"}, get),
	P({"shelves_006",4101,"USD",1100,"USD 1.10"}, get),
	P({"shelves_006",4102,"USD",5500,"USD 5.50"}, get),
	P({"shelves_006",4103,"USD",10500,"USD 10.50"}, get),
	P({"shelves_006",4104,"USD",18990,"USD 18.99"}, get),
	P({"shelves_006",4105,"USD",32990,"USD 32.99"}, get),
	P({"shelves_006",4106,"USD",43990,"USD 43.99"}, get),
	P({"shelves_006",4107,"USD",56990,"USD 56.99"}, get),
	P({"shelves_006",4108,"USD",99990,"USD 99.99"}, get),
};
goods_shelves["shelves_007"] = {
	P({"shelves_007",5010,"KPW",7500000,"₩7,500",1}, get),
	P({"shelves_007",5001,"KPW",1500000,"₩1,500"}, get),
	P({"shelves_007",5002,"KPW",7500000,"₩7,500"}, get),
	P({"shelves_007",5003,"KPW",12000000,"₩12,000"}, get),
	P({"shelves_007",5004,"KPW",23000000,"₩23,000"}, get),
	P({"shelves_007",5005,"KPW",30000000,"₩30,000"}, get),
	P({"shelves_007",5006,"KPW",45000000,"₩45,000"}, get),
	P({"shelves_007",5007,"KPW",60000000,"₩60,000"}, get),
	P({"shelves_007",5008,"KPW",119000000,"₩119,000"}, get),
	P({"shelves_007",5101,"KPW",1500000,"₩1,500"}, get),
	P({"shelves_007",5102,"KPW",7500000,"₩7,500"}, get),
	P({"shelves_007",5103,"KPW",12000000,"₩12,000"}, get),
	P({"shelves_007",5104,"KPW",23000000,"₩23,000"}, get),
	P({"shelves_007",5105,"KPW",30000000,"₩30,000"}, get),
	P({"shelves_007",5106,"KPW",45000000,"₩45,000"}, get),
	P({"shelves_007",5107,"KPW",60000000,"₩60,000"}, get),
	P({"shelves_007",5108,"KPW",119000000,"₩119,000"}, get),
};
goods_shelves["shelves_008"] = {
	P({"shelves_008",false,"HKD",43000,"HKD 43",1}, get),
	P({"shelves_008",4001,"HKD",8000,"HKD 8"}, get),
	P({"shelves_008",4002,"HKD",43000,"HKD 43"}, get),
	P({"shelves_008",4003,"HKD",82000,"HKD 82"}, get),
	P({"shelves_008",4004,"HKD",150000,"HKD 150"}, get),
	P({"shelves_008",4005,"HKD",260000,"HKD 260"}, get),
	P({"shelves_008",4006,"HKD",340000,"HKD 340"}, get),
	P({"shelves_008",4007,"HKD",450000,"HKD 450"}, get),
	P({"shelves_008",4008,"HKD",780000,"HKD 780"}, get),
	P({"shelves_008",4101,"HKD",8000,"HKD 8"}, get),
	P({"shelves_008",4102,"HKD",43000,"HKD 43"}, get),
	P({"shelves_008",4103,"HKD",82000,"HKD 82"}, get),
	P({"shelves_008",4104,"HKD",150000,"HKD 150"}, get),
	P({"shelves_008",4105,"HKD",260000,"HKD 260"}, get),
	P({"shelves_008",4106,"HKD",340000,"HKD 340"}, get),
	P({"shelves_008",4107,"HKD",450000,"HKD 450"}, get),
	P({"shelves_008",4108,"HKD",780000,"HKD 780"}, get),
};
return { tb = goods_shelves };