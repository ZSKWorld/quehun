-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][month_ticket]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name_chs"] = -2; ["name_chs_t"] = -2; ["name_jp"] = -2; ["name_en"] = -2; ["name_kr"] = -2; ["resource_id"] = 3; ["resource_count"] = 4; ["vip_exp"] = 5; ["effective_time"] = 6; ["icon"] = 1007; ["desc_chs"] = -8; ["desc_chs_t"] = -8; ["desc_jp"] = -8; ["desc_en"] = -8; ["desc_kr"] = -8; ["desc_detail_chs"] = -9; ["desc_detail_chs_t"] = -9; ["desc_detail_jp"] = -9; ["desc_detail_en"] = -9; ["desc_detail_kr"] = -9; ["desc_detail2_chs"] = -10; ["desc_detail2_chs_t"] = -10; ["desc_detail2_jp"] = -10; ["desc_detail2_en"] = -10; ["desc_detail2_kr"] = -10;};

local df = {  nil,  nil, 100001, nil, nil, 30, "extendRes/items/monthcard.jpg",  nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "mall_month_ticket"); end;


local month_ticket = { }
month_ticket[1010] = P({D[6007], 1010,1,false,340,34,1,1,1}, get);
month_ticket[2010] = P({D[6007], 2010,1,false,325,37,false,2,2}, get);
month_ticket[3010] = P({D[6007], 3010,1,false,300,30,false,3,3}, get);
month_ticket[5010] = P({D[6007], 5010,1,false,350,35,false,4,4}, get);
return { tb = month_ticket };