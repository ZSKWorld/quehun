-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][month_ticket_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1;};

local df = {  nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local month_ticket_info = { }
month_ticket_info[1] = P({1}, get);
return { tb = month_ticket_info };