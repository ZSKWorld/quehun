-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][product]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["payment_platform"] = 1; ["goods_id"] = 2; ["product_type"] = 3; ["product_id"] = 1004; ["currency_code"] = 1005; ["currency_price"] = 6; ["actual_code"] = 1007; ["actual_price"] = 8; ["brief_desc"] = 1009; ["detail_desc"] = 1010;};

local df = {  73, 2001, 1, "com.yostarjp.mahjongsoul.jade60", "JPY", 650000, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {31,38,51,64,72,91,97,}

local product = { }
return { tb = product, get = get, b2i = b2i };