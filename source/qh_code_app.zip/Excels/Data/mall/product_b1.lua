-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][product]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local product = require("Excels.Data.mall.product")
local tb = product.tb
local get = product.get

tb[10] = {
	P({D[7008], 10,1010,2,"com.soulgamechst.mahjongsoul.fortunecharm30","NTD",170000,"雀魂-月勢御守"}, get),
	P({D[7008], 10,4001,false,"com.soulgamechst.mahjongsoul.jade65","NTD",33000,"雀魂-65輝玉"}, get),
	P({D[7008], 10,4002,false,"com.soulgamechst.mahjongsoul.jade340","NTD",170000,"雀魂-340輝玉"}, get),
	P({D[7008], 10,4003,false,"com.soulgamechst.mahjongsoul.jade660","NTD",330000,"雀魂-660輝玉"}, get),
	P({D[7008], 10,4004,false,"com.soulgamechst.mahjongsoul.jade1200","NTD",590000,"雀魂-1200輝玉"}, get),
	P({D[7008], 10,4005,false,"com.soulgamechst.mahjongsoul.jade2100","NTD",990000,"雀魂-2100輝玉"}, get),
	P({D[7008], 10,4006,false,"com.soulgamechst.mahjongsoul.jade2800","NTD",1320000,"雀魂-2800輝玉"}, get),
	P({D[7008], 10,4007,false,"com.soulgamechst.mahjongsoul.jade3660","NTD",1690000,"雀魂-3660輝玉"}, get),
	P({D[7008], 10,4008,false,"com.soulgamechst.mahjongsoul.jade6480","NTD",2990000,"雀魂-6480輝玉"}, get),
	P({D[7008], 10,4101,false,"com.soulgamechst.mahjongsoul.outfitvoucher65","NTD",33000,"雀魂-65服飾券"}, get),
	P({D[7008], 10,4102,false,"com.soulgamechst.mahjongsoul.outfitvoucher340","NTD",170000,"雀魂-340服飾券"}, get),
	P({D[7008], 10,4103,false,"com.soulgamechst.mahjongsoul.outfitvoucher660","NTD",330000,"雀魂-660服飾券"}, get),
	P({D[7008], 10,4104,false,"com.soulgamechst.mahjongsoul.outfitvoucher1200","NTD",590000,"雀魂-1200服飾券"}, get),
	P({D[7008], 10,4105,false,"com.soulgamechst.mahjongsoul.outfitvoucher2100","NTD",990000,"雀魂-2100服飾券"}, get),
	P({D[7008], 10,4106,false,"com.soulgamechst.mahjongsoul.outfitvoucher2800","NTD",1320000,"雀魂-2800服飾券"}, get),
	P({D[7008], 10,4107,false,"com.soulgamechst.mahjongsoul.outfitvoucher3660","NTD",1690000,"雀魂-3660服飾券"}, get),
	P({D[7008], 10,4108,false,"com.soulgamechst.mahjongsoul.outfitvoucher6480","NTD",2990000,"雀魂-6480服飾券"}, get),
};
tb[11] = {
	P({D[7008], 11,1010,2,"liqi.wx.1010","CNY",30000,"雀魂-月势御守"}, get),
	P({D[7008], 11,1001,false,"liqi.wx.1001","CNY",12000,"雀魂-120辉玉"}, get),
	P({D[7008], 11,1002,false,"liqi.wx.1002","CNY",30000,"雀魂-300辉玉"}, get),
	P({D[7008], 11,1003,false,"liqi.wx.1003","CNY",60000,"雀魂-600辉玉"}, get),
	P({D[7008], 11,1004,false,"liqi.wx.1004","CNY",98000,"雀魂-980辉玉"}, get),
	P({D[7008], 11,1005,false,"liqi.wx.1005","CNY",128000,"雀魂-1280辉玉"}, get),
	P({D[7008], 11,1006,false,"liqi.wx.1006","CNY",198000,"雀魂-1980辉玉"}, get),
	P({D[7008], 11,1007,false,"liqi.wx.1007","CNY",328000,"雀魂-3280辉玉"}, get),
	P({D[7008], 11,1008,false,"liqi.wx.1008","CNY",648000,"雀魂-6480辉玉"}, get),
	P({D[7008], 11,1101,false,"liqi.wx.1101","CNY",12000,"雀魂-120服饰券"}, get),
	P({D[7008], 11,1102,false,"liqi.wx.1102","CNY",30000,"雀魂-300服饰券"}, get),
	P({D[7008], 11,1103,false,"liqi.wx.1103","CNY",60000,"雀魂-600服饰券"}, get),
	P({D[7008], 11,1104,false,"liqi.wx.1104","CNY",98000,"雀魂-980服饰券"}, get),
	P({D[7008], 11,1105,false,"liqi.wx.1105","CNY",128000,"雀魂-1280服饰券"}, get),
	P({D[7008], 11,1106,false,"liqi.wx.1106","CNY",198000,"雀魂-1980服饰券"}, get),
	P({D[7008], 11,1107,false,"liqi.wx.1107","CNY",328000,"雀魂-3280服饰券"}, get),
	P({D[7008], 11,1108,false,"liqi.wx.1108","CNY",648000,"雀魂-6480服饰券"}, get),
};
tb[12] = {
	P({D[7008], 12,1010,2,"liqi.ali.1010","CNY",30000,"雀魂-月势御守"}, get),
	P({D[7008], 12,1001,false,"liqi.ali.1001","CNY",12000,"雀魂-120辉玉"}, get),
	P({D[7008], 12,1002,false,"liqi.ali.1002","CNY",30000,"雀魂-300辉玉"}, get),
	P({D[7008], 12,1003,false,"liqi.ali.1003","CNY",60000,"雀魂-600辉玉"}, get),
	P({D[7008], 12,1004,false,"liqi.ali.1004","CNY",98000,"雀魂-980辉玉"}, get),
	P({D[7008], 12,1005,false,"liqi.ali.1005","CNY",128000,"雀魂-1280辉玉"}, get),
	P({D[7008], 12,1006,false,"liqi.ali.1006","CNY",198000,"雀魂-1980辉玉"}, get),
	P({D[7008], 12,1007,false,"liqi.ali.1007","CNY",328000,"雀魂-3280辉玉"}, get),
	P({D[7008], 12,1008,false,"liqi.ali.1008","CNY",648000,"雀魂-6480辉玉"}, get),
	P({D[7008], 12,1101,false,"liqi.ali.1101","CNY",12000,"雀魂-120服饰券"}, get),
	P({D[7008], 12,1102,false,"liqi.ali.1102","CNY",30000,"雀魂-300服饰券"}, get),
	P({D[7008], 12,1103,false,"liqi.ali.1103","CNY",60000,"雀魂-600服饰券"}, get),
	P({D[7008], 12,1104,false,"liqi.ali.1104","CNY",98000,"雀魂-980服饰券"}, get),
	P({D[7008], 12,1105,false,"liqi.ali.1105","CNY",128000,"雀魂-1280服饰券"}, get),
	P({D[7008], 12,1106,false,"liqi.ali.1106","CNY",198000,"雀魂-1980服饰券"}, get),
	P({D[7008], 12,1107,false,"liqi.ali.1107","CNY",328000,"雀魂-3280服饰券"}, get),
	P({D[7008], 12,1108,false,"liqi.ali.1108","CNY",648000,"雀魂-6480服饰券"}, get),
};
tb[21] = {
	P({D[7008], 21,1010,2,"liqi.hcwx.1010","CNY",30000,"雀魂-月势御守"}, get),
	P({D[7008], 21,1001,false,"liqi.hcwx.1001","CNY",12000,"雀魂-120辉玉"}, get),
	P({D[7008], 21,1002,false,"liqi.hcwx.1002","CNY",30000,"雀魂-300辉玉"}, get),
	P({D[7008], 21,1003,false,"liqi.hcwx.1003","CNY",60000,"雀魂-600辉玉"}, get),
	P({D[7008], 21,1004,false,"liqi.hcwx.1004","CNY",98000,"雀魂-980辉玉"}, get),
	P({D[7008], 21,1005,false,"liqi.hcwx.1005","CNY",128000,"雀魂-1280辉玉"}, get),
	P({D[7008], 21,1006,false,"liqi.hcwx.1006","CNY",198000,"雀魂-1980辉玉"}, get),
	P({D[7008], 21,1007,false,"liqi.hcwx.1007","CNY",328000,"雀魂-3280辉玉"}, get),
	P({D[7008], 21,1008,false,"liqi.hcwx.1008","CNY",648000,"雀魂-6480辉玉"}, get),
	P({D[7008], 21,1101,false,"liqi.hcwx.1101","CNY",12000,"雀魂-120服饰券"}, get),
	P({D[7008], 21,1102,false,"liqi.hcwx.1102","CNY",30000,"雀魂-300服饰券"}, get),
	P({D[7008], 21,1103,false,"liqi.hcwx.1103","CNY",60000,"雀魂-600服饰券"}, get),
	P({D[7008], 21,1104,false,"liqi.hcwx.1104","CNY",98000,"雀魂-980服饰券"}, get),
	P({D[7008], 21,1105,false,"liqi.hcwx.1105","CNY",128000,"雀魂-1280服饰券"}, get),
	P({D[7008], 21,1106,false,"liqi.hcwx.1106","CNY",198000,"雀魂-1980服饰券"}, get),
	P({D[7008], 21,1107,false,"liqi.hcwx.1107","CNY",328000,"雀魂-3280服饰券"}, get),
	P({D[7008], 21,1108,false,"liqi.hcwx.1108","CNY",648000,"雀魂-6480服饰券"}, get),
};
tb[22] = {
	P({D[7008], 22,1010,2,"liqi.hcali.1010","CNY",30000,"雀魂-月势御守"}, get),
	P({D[7008], 22,1001,false,"liqi.hcali.1001","CNY",12000,"雀魂-120辉玉"}, get),
	P({D[7008], 22,1002,false,"liqi.hcali.1002","CNY",30000,"雀魂-300辉玉"}, get),
	P({D[7008], 22,1003,false,"liqi.hcali.1003","CNY",60000,"雀魂-600辉玉"}, get),
	P({D[7008], 22,1004,false,"liqi.hcali.1004","CNY",98000,"雀魂-980辉玉"}, get),
	P({D[7008], 22,1005,false,"liqi.hcali.1005","CNY",128000,"雀魂-1280辉玉"}, get),
	P({D[7008], 22,1006,false,"liqi.hcali.1006","CNY",198000,"雀魂-1980辉玉"}, get),
	P({D[7008], 22,1007,false,"liqi.hcali.1007","CNY",328000,"雀魂-3280辉玉"}, get),
	P({D[7008], 22,1008,false,"liqi.hcali.1008","CNY",648000,"雀魂-6480辉玉"}, get),
	P({D[7008], 22,1101,false,"liqi.hcali.1101","CNY",12000,"雀魂-120服饰券"}, get),
	P({D[7008], 22,1102,false,"liqi.hcali.1102","CNY",30000,"雀魂-300服饰券"}, get),
	P({D[7008], 22,1103,false,"liqi.hcali.1103","CNY",60000,"雀魂-600服饰券"}, get),
	P({D[7008], 22,1104,false,"liqi.hcali.1104","CNY",98000,"雀魂-980服饰券"}, get),
	P({D[7008], 22,1105,false,"liqi.hcali.1105","CNY",128000,"雀魂-1280服饰券"}, get),
	P({D[7008], 22,1106,false,"liqi.hcali.1106","CNY",198000,"雀魂-1980服饰券"}, get),
	P({D[7008], 22,1107,false,"liqi.hcali.1107","CNY",328000,"雀魂-3280服饰券"}, get),
	P({D[7008], 22,1108,false,"liqi.hcali.1108","CNY",648000,"雀魂-6480服饰券"}, get),
};
tb[31] = {
	P({D[5008], 31,2010,2,"liqi.rfcc.1010","雀魂-開運御守"}, get),
	P({D[2003], 31,"liqi.rfcc.2001",false,160000,false,false,"雀魂-60輝石"}, get),
	P({D[5008], 31,2002,false,"liqi.rfcc.2002","雀魂-300輝石"}, get),
	P({D[7008], 31,2003,false,"liqi.rfcc.2003",false,1000000,"雀魂-480輝石"}, get),
	P({D[7008], 31,2004,false,"liqi.rfcc.2004",false,1800000,"雀魂-900輝石"}, get),
	P({D[7008], 31,2005,false,"liqi.rfcc.2005",false,2400000,"雀魂-1200輝石"}, get),
	P({D[7008], 31,2006,false,"liqi.rfcc.2006",false,3800000,"雀魂-1800輝石"}, get),
	P({D[7008], 31,2007,false,"liqi.rfcc.2007",false,4900000,"雀魂-2400輝石"}, get),
	P({D[7008], 31,2008,false,"liqi.rfcc.2008",false,10000000,"雀魂-4900輝石"}, get),
	P({D[7008], 31,2101,false,"liqi.rfcc.2101",false,160000,"雀魂-60着せ替え引換券"}, get),
	P({D[5008], 31,2102,false,"liqi.rfcc.2102","雀魂-306着せ替え引換券"}, get),
	P({D[7008], 31,2103,false,"liqi.rfcc.2103",false,1000000,"雀魂-492着せ替え引換券"}, get),
	P({D[7008], 31,2104,false,"liqi.rfcc.2104",false,1800000,"雀魂-924着せ替え引換券"}, get),
	P({D[7008], 31,2105,false,"liqi.rfcc.2105",false,2400000,"雀魂-1226着せ替え引換券"}, get),
	P({D[7008], 31,2106,false,"liqi.rfcc.2106",false,3800000,"雀魂-1850着せ替え引換券"}, get),
	P({D[7008], 31,2107,false,"liqi.rfcc.2107",false,4900000,"雀魂-2470着せ替え引換券"}, get),
	P({D[7008], 31,2108,false,"liqi.rfcc.2108",false,10000000,"雀魂-5050着せ替え引換券"}, get),
};