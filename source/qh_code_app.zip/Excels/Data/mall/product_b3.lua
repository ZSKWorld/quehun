-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][product]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap
local product = require("Excels.Data.mall.product")
local tb = product.tb
local get = product.get

tb[41] = {
	P({D[7008], 41,3010,2,"liqi.mfpp.1010","USD",4990,"Mahjong Soul-Fortune Charm"}, get),
	P({D[7008], 41,3001,false,"liqi.mfpp.3001","USD",990,"Mahjong Soul-60Jade"}, get),
	P({D[7008], 41,3002,false,"liqi.mfpp.3002","USD",4990,"Mahjong Soul-300Jade"}, get),
	P({D[7008], 41,3003,false,"liqi.mfpp.3003","USD",7990,"Mahjong Soul-480Jade"}, get),
	P({D[7008], 41,3004,false,"liqi.mfpp.3004","USD",14990,"Mahjong Soul-900Jade"}, get),
	P({D[7008], 41,3005,false,"liqi.mfpp.3005","USD",19990,"Mahjong Soul-1200Jade"}, get),
	P({D[7008], 41,3006,false,"liqi.mfpp.3006","USD",29990,"Mahjong Soul-1800Jade"}, get),
	P({D[7008], 41,3007,false,"liqi.mfpp.3007","USD",39990,"Mahjong Soul-2400Jade"}, get),
	P({D[7008], 41,3008,false,"liqi.mfpp.3008","USD",79990,"Mahjong Soul-4900Jade"}, get),
	P({D[7008], 41,3101,false,"liqi.mfpp.3101","USD",990,"Mahjong Soul-60Outfit Voucher"}, get),
	P({D[7008], 41,3102,false,"liqi.mfpp.3102","USD",4990,"Mahjong Soul-300Outfit Voucher"}, get),
	P({D[7008], 41,3103,false,"liqi.mfpp.3103","USD",7990,"Mahjong Soul-480Outfit Voucher"}, get),
	P({D[7008], 41,3104,false,"liqi.mfpp.3104","USD",14990,"Mahjong Soul-900Outfit Voucher"}, get),
	P({D[7008], 41,3105,false,"liqi.mfpp.3105","USD",19990,"Mahjong Soul-1200Outfit Voucher"}, get),
	P({D[7008], 41,3106,false,"liqi.mfpp.3106","USD",29990,"Mahjong Soul-1800Outfit Voucher"}, get),
	P({D[7008], 41,3107,false,"liqi.mfpp.3107","USD",39990,"Mahjong Soul-2400Outfit Voucher"}, get),
	P({D[7008], 41,3108,false,"liqi.mfpp.3108","USD",79990,"Mahjong Soul-4900Outfit Voucher"}, get),
};
tb[42] = {
	P({D[7008], 42,3010,2,"liqi.mc.1010","USD",4990,"Mahjong Soul-Fortune Charm"}, get),
	P({D[7008], 42,3001,false,"liqi.mc.3001","USD",990,"Mahjong Soul-60Jade"}, get),
	P({D[7008], 42,3002,false,"liqi.mc.3002","USD",4990,"Mahjong Soul-300Jade"}, get),
	P({D[7008], 42,3003,false,"liqi.mc.3003","USD",7990,"Mahjong Soul-480Jade"}, get),
	P({D[7008], 42,3004,false,"liqi.mc.3004","USD",14990,"Mahjong Soul-900Jade"}, get),
	P({D[7008], 42,3005,false,"liqi.mc.3005","USD",19990,"Mahjong Soul-1200Jade"}, get),
	P({D[7008], 42,3006,false,"liqi.mc.3006","USD",29990,"Mahjong Soul-1800Jade"}, get),
	P({D[7008], 42,3007,false,"liqi.mc.3007","USD",39990,"Mahjong Soul-2400Jade"}, get),
	P({D[7008], 42,3008,false,"liqi.mc.3008","USD",79990,"Mahjong Soul-4900Jade"}, get),
	P({D[7008], 42,3101,false,"liqi.mc.3101","USD",990,"Mahjong Soul-60Outfit Voucher"}, get),
	P({D[7008], 42,3102,false,"liqi.mc.3102","USD",4990,"Mahjong Soul-300Outfit Voucher"}, get),
	P({D[7008], 42,3103,false,"liqi.mc.3103","USD",7990,"Mahjong Soul-480Outfit Voucher"}, get),
	P({D[7008], 42,3104,false,"liqi.mc.3104","USD",14990,"Mahjong Soul-900Outfit Voucher"}, get),
	P({D[7008], 42,3105,false,"liqi.mc.3105","USD",19990,"Mahjong Soul-1200Outfit Voucher"}, get),
	P({D[7008], 42,3106,false,"liqi.mc.3106","USD",29990,"Mahjong Soul-1800Outfit Voucher"}, get),
	P({D[7008], 42,3107,false,"liqi.mc.3107","USD",39990,"Mahjong Soul-2400Outfit Voucher"}, get),
	P({D[7008], 42,3108,false,"liqi.mc.3108","USD",79990,"Mahjong Soul-4900Outfit Voucher"}, get),
};
tb[43] = {
	P({D[7008], 43,3010,2,"liqi.visa.1010","USD",4990,"Mahjong Soul-Fortune Charm"}, get),
	P({D[7008], 43,3001,false,"liqi.visa.3001","USD",990,"Mahjong Soul-60Jade"}, get),
	P({D[7008], 43,3002,false,"liqi.visa.3002","USD",4990,"Mahjong Soul-300Jade"}, get),
	P({D[7008], 43,3003,false,"liqi.visa.3003","USD",7990,"Mahjong Soul-480Jade"}, get),
	P({D[7008], 43,3004,false,"liqi.visa.3004","USD",14990,"Mahjong Soul-900Jade"}, get),
	P({D[7008], 43,3005,false,"liqi.visa.3005","USD",19990,"Mahjong Soul-1200Jade"}, get),
	P({D[7008], 43,3006,false,"liqi.visa.3006","USD",29990,"Mahjong Soul-1800Jade"}, get),
	P({D[7008], 43,3007,false,"liqi.visa.3007","USD",39990,"Mahjong Soul-2400Jade"}, get),
	P({D[7008], 43,3008,false,"liqi.visa.3008","USD",79990,"Mahjong Soul-4900Jade"}, get),
	P({D[7008], 43,3101,false,"liqi.visa.3101","USD",990,"Mahjong Soul-60Outfit Voucher"}, get),
	P({D[7008], 43,3102,false,"liqi.visa.3102","USD",4990,"Mahjong Soul-300Outfit Voucher"}, get),
	P({D[7008], 43,3103,false,"liqi.visa.3103","USD",7990,"Mahjong Soul-480Outfit Voucher"}, get),
	P({D[7008], 43,3104,false,"liqi.visa.3104","USD",14990,"Mahjong Soul-900Outfit Voucher"}, get),
	P({D[7008], 43,3105,false,"liqi.visa.3105","USD",19990,"Mahjong Soul-1200Outfit Voucher"}, get),
	P({D[7008], 43,3106,false,"liqi.visa.3106","USD",29990,"Mahjong Soul-1800Outfit Voucher"}, get),
	P({D[7008], 43,3107,false,"liqi.visa.3107","USD",39990,"Mahjong Soul-2400Outfit Voucher"}, get),
	P({D[7008], 43,3108,false,"liqi.visa.3108","USD",79990,"Mahjong Soul-4900Outfit Voucher"}, get),
};
tb[44] = {
	P({D[7008], 44,3010,2,"liqi.jcb.1010","USD",4990,"Mahjong Soul-Fortune Charm"}, get),
	P({D[7008], 44,3001,false,"liqi.jcb.3001","USD",990,"Mahjong Soul-60Jade"}, get),
	P({D[7008], 44,3002,false,"liqi.jcb.3002","USD",4990,"Mahjong Soul-300Jade"}, get),
	P({D[7008], 44,3003,false,"liqi.jcb.3003","USD",7990,"Mahjong Soul-480Jade"}, get),
	P({D[7008], 44,3004,false,"liqi.jcb.3004","USD",14990,"Mahjong Soul-900Jade"}, get),
	P({D[7008], 44,3005,false,"liqi.jcb.3005","USD",19990,"Mahjong Soul-1200Jade"}, get),
	P({D[7008], 44,3006,false,"liqi.jcb.3006","USD",29990,"Mahjong Soul-1800Jade"}, get),
	P({D[7008], 44,3007,false,"liqi.jcb.3007","USD",39990,"Mahjong Soul-2400Jade"}, get),
	P({D[7008], 44,3008,false,"liqi.jcb.3008","USD",79990,"Mahjong Soul-4900Jade"}, get),
	P({D[7008], 44,3101,false,"liqi.jcb.3101","USD",990,"Mahjong Soul-60Outfit Voucher"}, get),
	P({D[7008], 44,3102,false,"liqi.jcb.3102","USD",4990,"Mahjong Soul-300Outfit Voucher"}, get),
	P({D[7008], 44,3103,false,"liqi.jcb.3103","USD",7990,"Mahjong Soul-480Outfit Voucher"}, get),
	P({D[7008], 44,3104,false,"liqi.jcb.3104","USD",14990,"Mahjong Soul-900Outfit Voucher"}, get),
	P({D[7008], 44,3105,false,"liqi.jcb.3105","USD",19990,"Mahjong Soul-1200Outfit Voucher"}, get),
	P({D[7008], 44,3106,false,"liqi.jcb.3106","USD",29990,"Mahjong Soul-1800Outfit Voucher"}, get),
	P({D[7008], 44,3107,false,"liqi.jcb.3107","USD",39990,"Mahjong Soul-2400Outfit Voucher"}, get),
	P({D[7008], 44,3108,false,"liqi.jcb.3108","USD",79990,"Mahjong Soul-4900Outfit Voucher"}, get),
};
tb[45] = {
	P({D[7008], 45,3010,2,"liqi.mfal.1010","USD",4990,"Mahjong Soul-Fortune Charm"}, get),
	P({D[7008], 45,3001,false,"liqi.mfal.3001","USD",990,"Mahjong Soul-60Jade"}, get),
	P({D[7008], 45,3002,false,"liqi.mfal.3002","USD",4990,"Mahjong Soul-300Jade"}, get),
	P({D[7008], 45,3003,false,"liqi.mfal.3003","USD",7990,"Mahjong Soul-480Jade"}, get),
	P({D[7008], 45,3004,false,"liqi.mfal.3004","USD",14990,"Mahjong Soul-900Jade"}, get),
	P({D[7008], 45,3005,false,"liqi.mfal.3005","USD",19990,"Mahjong Soul-1200Jade"}, get),
	P({D[7008], 45,3006,false,"liqi.mfal.3006","USD",29990,"Mahjong Soul-1800Jade"}, get),
	P({D[7008], 45,3007,false,"liqi.mfal.3007","USD",39990,"Mahjong Soul-2400Jade"}, get),
	P({D[7008], 45,3008,false,"liqi.mfal.3008","USD",79990,"Mahjong Soul-4900Jade"}, get),
	P({D[7008], 45,3101,false,"liqi.mfal.3101","USD",990,"Mahjong Soul-60Outfit Voucher"}, get),
	P({D[7008], 45,3102,false,"liqi.mfal.3102","USD",4990,"Mahjong Soul-300Outfit Voucher"}, get),
	P({D[7008], 45,3103,false,"liqi.mfal.3103","USD",7990,"Mahjong Soul-480Outfit Voucher"}, get),
	P({D[7008], 45,3104,false,"liqi.mfal.3104","USD",14990,"Mahjong Soul-900Outfit Voucher"}, get),
	P({D[7008], 45,3105,false,"liqi.mfal.3105","USD",19990,"Mahjong Soul-1200Outfit Voucher"}, get),
	P({D[7008], 45,3106,false,"liqi.mfal.3106","USD",29990,"Mahjong Soul-1800Outfit Voucher"}, get),
	P({D[7008], 45,3107,false,"liqi.mfal.3107","USD",39990,"Mahjong Soul-2400Outfit Voucher"}, get),
	P({D[7008], 45,3108,false,"liqi.mfal.3108","USD",79990,"Mahjong Soul-4900Outfit Voucher"}, get),
};
tb[51] = {
	P({D[7008], 51,1010,2,"com.soulgamechst.mahjongsoul.fortunecharm30","NTD",170000,"雀魂-月勢御守","twios"}, get),
	P({D[7008], 51,4001,false,"com.soulgamechst.majongsoul.jade65","NTD",33000,"雀魂-65輝玉"}, get),
	P({D[7008], 51,4002,false,"com.soulgamechst.majongsoul.jade340","NTD",170000,"雀魂-340輝玉"}, get),
	P({D[7008], 51,4003,false,"com.soulgamechst.majongsoul.jade660","NTD",330000,"雀魂-660輝玉"}, get),
	P({D[7008], 51,4004,false,"com.soulgamechst.majongsoul.jade1200","NTD",590000,"雀魂-1200輝玉"}, get),
	P({D[7008], 51,4005,false,"com.soulgamechst.majongsoul.jade2100","NTD",990000,"雀魂-2100輝玉"}, get),
	P({D[7008], 51,4006,false,"com.soulgamechst.majongsoul.jade2800","NTD",1320000,"雀魂-2800輝玉"}, get),
	P({D[7008], 51,4007,false,"com.soulgamechst.majongsoul.jade3660","NTD",1690000,"雀魂-3660輝玉"}, get),
	P({D[7008], 51,4008,false,"com.soulgamechst.majongsoul.jade6480","NTD",2990000,"雀魂-6480輝玉"}, get),
	P({D[7008], 51,4101,false,"com.soulgamechst.majongsoul.outfitvoucher65","NTD",33000,"雀魂-65服飾券"}, get),
	P({D[7008], 51,4102,false,"com.soulgamechst.majongsoul.outfitvoucher340","NTD",170000,"雀魂-340服飾券"}, get),
	P({D[7008], 51,4103,false,"com.soulgamechst.majongsoul.outfitvoucher660","NTD",330000,"雀魂-660服飾券"}, get),
	P({D[7008], 51,4104,false,"com.soulgamechst.majongsoul.outfitvoucher1200","NTD",590000,"雀魂-1200服飾券"}, get),
	P({D[7008], 51,4105,false,"com.soulgamechst.majongsoul.outfitvoucher2100","NTD",990000,"雀魂-2100服飾券"}, get),
	P({D[7008], 51,4106,false,"com.soulgamechst.majongsoul.outfitvoucher2800","NTD",1320000,"雀魂-2800服飾券"}, get),
	P({D[7008], 51,4107,false,"com.soulgamechst.majongsoul.outfitvoucher3660","NTD",1690000,"雀魂-3660服飾券"}, get),
	P({D[7008], 51,4108,false,"com.soulgamechst.majongsoul.outfitvoucher6480","NTD",2990000,"雀魂-6480服飾券"}, get),
};