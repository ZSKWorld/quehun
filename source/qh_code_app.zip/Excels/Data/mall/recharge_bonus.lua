-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][recharge_bonus]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["zone_id"] = 1; ["reset_time"] = 1002;};

local df = {  2, "2018-04-23 07:00+08",};

local get = function(item, k) return G(item, k, n2i, df); end;


local recharge_bonus = { }
recharge_bonus[1] = {
	P({1,"2018-08-20 08:00+08"}, get),
	P({1,"2025-08-20 08:00+08"}, get),
};
recharge_bonus[2] = {
	P({}, get),
	P({false,"2025-04-23 07:00+08"}, get),
	P({false,"2026-04-22 08:00+08"}, get),
};
recharge_bonus[3] = {
	P({3}, get),
	P({3,"2025-04-23 07:00+08"}, get),
	P({3,"2026-04-22 08:00+08"}, get),
};
return { tb = recharge_bonus };