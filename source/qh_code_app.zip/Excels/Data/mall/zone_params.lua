-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mall][zone_params]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["zone_id"] = 1001; ["key"] = 1002; ["string_value"] = 1003;};

local df = {  nil, "first_charge_reset", "2025-04-23 07:00+08",};

local get = function(item, k) return G(item, k, n2i, df); end;


local zone_params = { }
zone_params["1"] = {
	P({"1",false,"2025-08-20 08:00+08"}, get),
};
zone_params["2"] = {
	P({"2"}, get),
};
zone_params["3"] = {
	P({"3"}, get),
};
return { tb = zone_params };