-- 由 Excel 自动生成的 Lua 表
-- 文件:   [marathon][marathon_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["tick"] = 2; ["hands_count"] = 3; ["start_time"] = 4; ["fever_speed"] = 5; ["fever_time_bonus"] = 6; ["fever_time_duration"] = 7; ["wall_tile_count"] = 8; ["wall_max_same_tile"] = 9; ["wall_group_id"] = 10; ["tile_group"] = 11; ["reward_group"] = 12; ["item_group"] = 13; ["point_item_id"] = 14; ["fever_item_type"] = 15; ["distance_item_id"] = 16; ["distance_reward_rate"] = 17; ["max_distance_reward"] = 18; ["wall_empty_pos"] = 19;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local marathon_info = { }
marathon_info[260201] = P({260201,30,8,900,30,100,15,7,2,1001,2001,3001,4001,30900098,2,30900099,100,10,S({1,3,5,})}, get);
return { tb = marathon_info };