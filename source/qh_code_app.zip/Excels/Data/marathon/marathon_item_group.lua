-- 由 Excel 自动生成的 Lua 表
-- 文件:   [marathon][marathon_item_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["type"] = 2; ["weight"] = 3;};

local df = {  4001, 2, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local marathon_item_group = { }
marathon_item_group[4001] = {
	P({false,1,30}, get),
	P({D[1002], 70}, get),
};
marathon_item_group[4002] = {
	P({4002,1,15}, get),
	P({4002,false,85}, get),
};
marathon_item_group[4003] = {
	P({4003,false,100}, get),
};
return { tb = marathon_item_group };