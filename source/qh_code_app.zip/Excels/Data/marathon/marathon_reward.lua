-- 由 Excel 自动生成的 Lua 表
-- 文件:   [marathon][marathon_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["type"] = 2; ["point"] = 3; ["time"] = 4;};

local df = {  3001, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local marathon_reward = { }
marathon_reward[3001] = {
	P({false,1,50}, get),
	P({false,2,75}, get),
	P({false,3,100,60}, get),
	P({false,4,200}, get),
	P({false,5,0,150}, get),
};
return { tb = marathon_reward };