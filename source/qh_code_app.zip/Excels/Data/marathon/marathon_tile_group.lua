-- 由 Excel 自动生成的 Lua 表
-- 文件:   [marathon][marathon_tile_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["tile"] = 1002; ["weight"] = 3; ["fever_weight"] = 4;};

local df = {  2001, nil, nil, 100,};

local get = function(item, k) return G(item, k, n2i, df); end;


local marathon_tile_group = { }
marathon_tile_group[2001] = {
	P({false,"1m",false,0}, get),
	P({false,"2m",false,0}, get),
	P({false,"3m",false,0}, get),
	P({false,"4m",false,0}, get),
	P({false,"5m",false,0}, get),
	P({false,"6m",false,0}, get),
	P({false,"7m",false,0}, get),
	P({false,"8m",false,0}, get),
	P({false,"9m",false,0}, get),
	P({false,"1p",40}, get),
	P({false,"2p",60}, get),
	P({false,"3p",80}, get),
	P({false,"4p",100}, get),
	P({false,"5p",100}, get),
	P({false,"6p",100}, get),
	P({false,"7p",80}, get),
	P({false,"8p",60}, get),
	P({false,"9p",40}, get),
	P({false,"1s",40}, get),
	P({false,"2s",60}, get),
	P({false,"3s",80}, get),
	P({false,"4s",100}, get),
	P({false,"5s",100}, get),
	P({false,"6s",100}, get),
	P({false,"7s",80}, get),
	P({false,"8s",60}, get),
	P({false,"9s",40}, get),
	P({false,"1z",false,0}, get),
	P({false,"2z",false,0}, get),
	P({false,"3z",false,0}, get),
	P({false,"4z",false,0}, get),
	P({false,"5z",false,0}, get),
	P({false,"6z",false,0}, get),
	P({false,"7z",false,0}, get),
};
return { tb = marathon_tile_group };