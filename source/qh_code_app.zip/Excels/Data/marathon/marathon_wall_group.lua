-- 由 Excel 自动生成的 Lua 表
-- 文件:   [marathon][marathon_wall_group]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["lower"] = 2; ["upper"] = 3; ["speed"] = 4; ["speed_bonus"] = 5; ["final_mode"] = 6; ["fever_weight_addition"] = 7; ["near_fever_weight_addition"] = 8; ["must_fever_count"] = 9; ["finish_hands_check"] = 10; ["strong_hands_check"] = 11; ["weak_hands_check"] = 12; ["item_rate"] = 13; ["item_group_id"] = 14;};

local df = {  1001, nil, nil, 30, 150, nil, nil, nil, nil, nil, nil, 25, 5, 4003,};

local get = function(item, k) return G(item, k, n2i, df); end;


local marathon_wall_group = { }
marathon_wall_group[1001] = {
	P({false,1,2,90,25,false,15,5,1,100,80,false,40,4001}, get),
	P({false,3,5,85,25,false,15,5,false,100,80,false,40,4001}, get),
	P({false,6,8,80,25,false,15,5,1,100,80,false,40,4001}, get),
	P({false,9,11,75,25,false,15,5,false,100,80,false,35,4001}, get),
	P({false,12,14,70,25,false,15,false,1,94,75,false,35,4001}, get),
	P({D[8009], false,15,17,65,25,false,15,88,70,false,35,4001}, get),
	P({false,18,20,63,50,false,15,false,1,82,65,false,30,4001}, get),
	P({D[8009], false,21,23,61,50,false,10,76,60,false,30,4001}, get),
	P({false,24,26,59,50,false,10,false,1,70,55,false,30,4001}, get),
	P({D[8009], false,27,29,57,50,false,10,64,50,false,30,4001}, get),
	P({false,30,32,55,50,false,10,false,1,58,45,false,25,4001}, get),
	P({D[8009], false,33,35,53,75,false,10,52,40,false,25,4001}, get),
	P({false,36,38,51,75,false,10,false,1,46,35,false,25,4001}, get),
	P({D[8009], false,39,41,49,75,false,10,40,30,false,25,4001}, get),
	P({false,42,44,47,75,false,10,false,1,33,30,false,20,4001}, get),
	P({D[8009], false,45,47,45,75,false,10,30,29,false,20,4002}, get),
	P({false,48,50,44,75,false,10,false,1,27,28,false,20,4002}, get),
	P({D[8009], false,51,53,43,75,false,10,24,27,false,20,4002}, get),
	P({false,54,56,42,100,false,10,false,1,21,26,false,20,4002}, get),
	P({D[8009], false,57,59,41,100,false,10,18,25,false,15,4002}, get),
	P({D[8009], false,60,62,40,100,false,5,15,24,false,15,4002}, get),
	P({D[8009], false,63,65,39,100,false,5,12,23,false,15,4002}, get),
	P({D[8009], false,66,68,38,100,false,5,9,22,false,10,4002}, get),
	P({D[8009], false,69,71,37,100,false,5,6,21,false,10}, get),
	P({D[8009], false,72,74,36,125,false,5,3,20,false,10}, get),
	P({D[8010], false,75,77,35,125,false,5,19,15,10}, get),
	P({D[8010], false,78,80,34,125,false,5,17,15}, get),
	P({D[8010], false,81,83,33,125,false,5,15,15}, get),
	P({D[6010], false,84,86,32,125,13,15}, get),
	P({D[6010], false,87,89,31,125,11,15}, get),
	P({D[6010], false,90,93,false,125,9,15}, get),
	P({D[6010], false,94,97,false,125,7,15}, get),
	P({D[4010], false,98,101,5,15}, get),
	P({D[4010], false,102,105,3,15}, get),
	P({D[4010], false,106,109,1,15}, get),
	P({D[4011], false,110,113,15}, get),
	P({D[4011], false,114,117,5,2}, get),
	P({D[4011], false,118,123,5,2}, get),
	P({D[4011], false,124,130,5,2}, get),
	P({D[4011], false,131,140,5,2}, get),
	P({D[4011], false,141,150,5,2}, get),
	P({D[4011], false,151,160,0,1}, get),
	P({D[4011], false,161,170,0,1}, get),
	P({D[4011], false,171,200,0,1}, get),
	P({D[4011], false,201,300,0,1}, get),
	P({D[4011], false,301,400,0,1}, get),
	P({D[7011], false,401,0,false,false,1,0,0}, get),
};
return { tb = marathon_wall_group };