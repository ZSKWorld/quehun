-- 由 Excel 自动生成的 Lua 表
-- 文件:   [match_shilian][shilian]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["name"] = 1002; ["ticket_id"] = 3; ["currency_id"] = 4; ["currency_count"] = 5; ["mode"] = 6; ["mode1"] = 7; ["mode2"] = 8; ["init_point"] = 9; ["back_point"] = 10;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local shilian = { }
shilian[1] = P({1,"试炼之道",300005,100002,10000,0,0,0,10000,20000}, get);
return { tb = shilian };