-- 由 Excel 自动生成的 Lua 表
-- 文件:   [match_shilian][shilian_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["reward_id"] = 2; ["reward_count"] = 3;};

local df = {  1, 100001, 2,};

local get = function(item, k) return G(item, k, n2i, df); end;


local shilian_reward = { }
shilian_reward[1] = {
	P({}, get),
	P({false,100002,50}, get),
};
shilian_reward[2] = {
	P({2}, get),
	P({2,100002,50}, get),
};
shilian_reward[3] = {
	P({3}, get),
	P({3,100002,50}, get),
};
shilian_reward[4] = {
	P({4}, get),
	P({4,100002,50}, get),
};
shilian_reward[5] = {
	P({5}, get),
	P({5,100002,50}, get),
};
return { tb = shilian_reward };