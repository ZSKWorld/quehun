-- 由 Excel 自动生成的 Lua 表
-- 文件:   [misc_function][daily_sign_in]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["reward_id"] = 2; ["reward_count"] = 3;};

local df = {  nil, 100002, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local daily_sign_in = { }
daily_sign_in[1] = P({1,false,101}, get);
daily_sign_in[2] = P({2,false,102}, get);
daily_sign_in[3] = P({3,false,103}, get);
daily_sign_in[4] = P({4,false,104}, get);
daily_sign_in[5] = P({5,false,105}, get);
daily_sign_in[6] = P({6,false,106}, get);
daily_sign_in[7] = P({7,false,107}, get);
return { tb = daily_sign_in };