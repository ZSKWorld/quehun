-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_activity]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["equipment_bag_max"] = 2; ["random_equipment_count"] = 3; ["appoint_equipment_count"] = 4; ["initial_level_id"] = 5; ["next_level_time"] = 6; ["tick"] = 7; ["total_tick_red"] = 8;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_activity = { }
mmo_activity[260401] = P({260401,999,4,5,1,5,30,300}, get);
return { tb = mmo_activity };