-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_buff_banned]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["ban_rare"] = 2;};

local df = {  102, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_buff_banned = { }
mmo_buff_banned[101] = {
	P({101}, get),
};
mmo_buff_banned[102] = {
	P({}, get),
	P({false,2}, get),
};
return { tb = mmo_buff_banned };