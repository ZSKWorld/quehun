-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_character]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["character_id"] = 2; ["hp"] = 3; ["atk"] = 4; ["critical_rate"] = 5; ["critical_damage"] = 6; ["aggro"] = 7; ["action_seq"] = 8; ["weapon_type"] = 9; ["init_equipment"] = 1010; ["job_name"] = 11; ["job_desc"] = 12; ["res_name"] = 1013;};

local df = {  260401, nil, nil, nil, nil, 150, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_character = { }
mmo_character[260401] = {
	P({false,1001,10,7,20,false,50,1,1,"70001100,70001400,70001500",26040001,26040004,"sword"}, get),
	P({false,1002,20,4,2,180,99,3,2,"70001200,70001400,70001500",26040002,26040005,"warrior"}, get),
	P({false,1003,5,10,5,false,1,4,3,"70001300,70001400,70001500",26040003,26040006,"mage"}, get),
};
return { tb = mmo_character };