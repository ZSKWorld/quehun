-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_equipment_buff]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["buff_id"] = 1; ["type"] = 2; ["args"] = 3; ["equipment_buff_desc"] = 4;};

local df = {  nil, 1, 2, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_equipment_buff = { }
mmo_equipment_buff[1001] = P({1001,false,S({3,2,}),26040007}, get);
mmo_equipment_buff[1002] = P({1002,false,S({3,2,}),26040008}, get);
mmo_equipment_buff[1003] = P({1003,false,S({3,2,}),26040009}, get);
mmo_equipment_buff[1004] = P({1004,false,S({2,2,}),26040010}, get);
mmo_equipment_buff[1005] = P({1005,false,S({2,2,}),26040011}, get);
return { tb = mmo_equipment_buff };