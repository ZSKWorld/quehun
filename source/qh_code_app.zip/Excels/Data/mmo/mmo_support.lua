-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_support]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["support_count_range"] = 2; ["reward"] = 1003;};

local df = {  260401, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_support = { }
mmo_support[260401] = {
	P({false,S({1,10,}),"30900102-2"}, get),
	P({false,S({11,20,}),"30900102-4"}, get),
	P({false,S({21,30,}),"30900102-6"}, get),
	P({false,S({31,40,}),"30900102-8"}, get),
	P({false,S({41,0,}),"30900102-10"}, get),
};
return { tb = mmo_support };