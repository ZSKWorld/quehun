-- 由 Excel 自动生成的 Lua 表
-- 文件:   [mmo][mmo_team_talent]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["buff_id"] = 2; ["buff_level"] = 3; ["weapon_type_id"] = 1004; ["power"] = 5;};

local df = {  260404, 26040401, 1, "1000,1001,1002,1003,2000,2001,2002,2003,3000,3003,3002,3001", 100,};

local get = function(item, k) return G(item, k, n2i, df); end;


local mmo_team_talent = { }
mmo_team_talent[260404] = {
	P({}, get),
	P({D[1002], 2,false,500}, get),
	P({D[1002], 3,false,2000}, get),
	P({false,26040402}, get),
	P({false,26040402,2,false,500}, get),
	P({false,26040402,3,false,2000}, get),
	P({false,26040403}, get),
	P({false,26040403,2,false,500}, get),
	P({false,26040403,3,false,2000}, get),
	P({false,26040411,false,"2000,2001,2002,2003"}, get),
	P({false,26040411,2,"2000,2001,2002,2003",500}, get),
	P({false,26040411,3,"2000,2001,2002,2003",2000}, get),
	P({false,26040412,false,"2000,2001,2002,2003"}, get),
	P({false,26040412,2,"2000,2001,2002,2003",500}, get),
	P({false,26040412,3,"2000,2001,2002,2003",2000}, get),
	P({false,26040413,false,"2000,2001,2002,2003"}, get),
	P({false,26040413,2,"2000,2001,2002,2003",500}, get),
	P({false,26040413,3,"2000,2001,2002,2003",2000}, get),
	P({false,26040421,false,"1000,1001,1002,1003"}, get),
	P({false,26040421,2,"1000,1001,1002,1003",500}, get),
	P({false,26040421,3,"1000,1001,1002,1003",2000}, get),
	P({false,26040422,false,"1000,1001,1002,1003"}, get),
	P({false,26040422,2,"1000,1001,1002,1003",500}, get),
	P({false,26040422,3,"1000,1001,1002,1003",2000}, get),
	P({false,26040423,false,"1000,1001,1002,1003"}, get),
	P({false,26040423,2,"1000,1001,1002,1003",500}, get),
	P({false,26040423,3,"1000,1001,1002,1003",2000}, get),
	P({false,26040431,false,"3000,3003,3002,3001"}, get),
	P({false,26040431,2,"3000,3003,3002,3001",500}, get),
	P({false,26040431,3,"3000,3003,3002,3001",2000}, get),
	P({false,26040432,false,"3000,3003,3002,3001"}, get),
	P({false,26040432,2,"3000,3003,3002,3001",500}, get),
	P({false,26040432,3,"3000,3003,3002,3001",2000}, get),
	P({false,26040433,false,"3000,3003,3002,3001"}, get),
	P({false,26040433,2,"3000,3003,3002,3001",500}, get),
	P({false,26040433,3,"3000,3003,3002,3001",2000}, get),
	P({false,26040434,false,"3003,3002"}, get),
	P({false,26040434,2,"3003,3002",500}, get),
	P({false,26040434,3,"3003,3002",2000}, get),
};
return { tb = mmo_team_talent };