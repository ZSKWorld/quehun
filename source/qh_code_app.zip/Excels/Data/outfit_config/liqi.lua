-- 由 Excel 自动生成的 Lua 表
-- 文件:   [outfit_config][liqi]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["hide_direction"] = 1002;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local liqi = { }
liqi[308048] = P({308048,"1,0,1,0"}, get);
return { tb = liqi };