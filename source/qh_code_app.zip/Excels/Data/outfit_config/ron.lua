-- 由 Excel 自动生成的 Lua 表
-- 文件:   [outfit_config][ron]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["is_fullscreen"] = 2; ["queue_change_delay"] = 3;};

local df = {  nil, 1, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local ron = { }
ron[300001] = P({300001,0}, get);
ron[305215] = P({305215}, get);
ron[305217] = P({305217}, get);
ron[305219] = P({305219}, get);
ron[305223] = P({305223}, get);
ron[308011] = P({308011}, get);
ron[308026] = P({308026}, get);
ron[308041] = P({308041}, get);
ron[30520006] = P({30520006}, get);
ron[30520007] = P({30520007,false,2500}, get);
ron[30520009] = P({30520009,false,1860}, get);
ron[30520013] = P({30520013,false,5000}, get);
return { tb = ron };