-- 由 Excel 自动生成的 Lua 表
-- 文件:   [quest_crew][qc_character_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["character_id"] = 2; ["sta"] = 3; ["str"] = 4; ["spd"] = 5; ["luc"] = 6; ["effect"] = 7; ["show_in_market"] = 8; ["hiring_price"] = 1009; ["item_id"] = 10; ["name"] = 11; ["skill"] = 12; ["npc_code"] = 1013; ["display_change"] = 14;};

local df = {  1001, nil, 3, 10, 10, 10, nil, 1, "30900095-6", nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local qc_character_pool = { }
qc_character_pool[1001] = {
	P({D[3004], false,10001,30,30,10001,0,"",200001,false,25100201}, get),
	P({false,10002,false,30,30,30,10002,0,"",20000113,false,25100202,false,1}, get),
	P({D[3004], false,10003,50,30,10003,0,"",200003,false,25100203}, get),
	P({false,10004,false,35,30,25,10004,0,"",200017,false,25100204,false,1}, get),
	P({false,10005,false,30,false,50,10005,0,"",200019,false,25100205}, get),
	P({D[8009], false,10006,false,20,25,25,10006,200002,false,25100206}, get),
	P({D[8009], false,10007,false,40,20,false,10007,200012,false,25100207}, get),
	P({D[3004], false,10008,20,40,10008,false,false,200029,false,25100208}, get),
	P({D[8009], false,10009,false,5,55,20,10009,200005,false,25100209,false,1}, get),
	P({D[8009], false,10010,false,50,15,15,10010,200006,false,25100210,false,1}, get),
	P({D[8009], false,10011,false,20,false,50,10011,200016,false,25100211,false,1}, get),
	P({D[8009], false,10012,false,5,45,30,10012,200028,false,25100212,false,1}, get),
	P({D[8009], false,10013,false,70,5,5,10013,200022,false,25100213}, get),
	P({D[3004], false,10014,40,20,10014,false,false,200031,false,25100214,false,1}, get),
	P({D[8009], false,10015,false,30,false,20,10015,200030,false,25100215,false,1}, get),
	P({D[8009], false,10016,false,30,30,false,10016,200098,false,25100216,false,1}, get),
	P({D[8009], false,10017,false,15,15,40,10017,200099,false,25100217,false,1}, get),
	P({D[8009], false,10018,false,15,30,15,10018,200004,false,25100218,false,1}, get),
	P({D[5006], false,10019,false,40,10019,false,false,200008,false,25100219,false,1}, get),
	P({D[8009], false,10020,false,20,20,20,10020,200021,false,25100220,false,1}, get),
	P({D[8009], false,10021,false,30,false,20,10021,200032,false,25100221,false,1}, get),
	P({false,10022,false,15,15,15,10022,false,"30900095-12",200010,false,25100222,false,1}, get),
	P({false,10023,false,5,5,30,10023,false,"30900095-12",200044,false,25100223,false,1}, get),
	P({D[3004], false,10024,15,25,10024,false,"30900095-12",200048,false,25100224,false,1}, get),
	P({false,10025,false,70,25,5,10025,false,"30900095-12",200038,false,25100225,false,1}, get),
	P({false,10026,false,65,5,30,10026,false,"30900095-12",200084,false,25100226,false,1}, get),
	P({false,10027,false,5,70,25,10027,false,"30900095-12",200046,false,25100227,false,1}, get),
	P({false,10028,false,25,65,false,10028,false,"30900095-12",200045,false,25100228,false,1}, get),
	P({D[3004], false,10029,20,70,10029,false,"30900095-12",200007,false,25100229,false,1}, get),
	P({false,10030,false,5,30,65,10030,false,"30900095-12",200009,false,25100230,false,1}, get),
	P({false,10031,false,50,50,20,10031,false,"30900095-18",200052,false,25100231,false,1}, get),
	P({false,10032,false,15,70,35,10032,false,"30900095-18",200061,false,25100232}, get),
	P({D[3004], false,10033,20,90,10033,false,"30900095-18",200095,false,25100233,false,1}, get),
	P({false,10034,false,35,15,70,10034,false,"30900095-18",200076,false,25100234,false,1}, get),
	P({D[7008], false,10101,false,5,30,5,"30900095-3",false,25100101,false,"0007"}, get),
	P({D[3004], false,10102,15,15,false,false,"30900095-3",false,25100102,false,"0008"}, get),
	P({D[5008], false,10103,false,20,"30900095-3",false,25100103,false,"0009"}, get),
	P({D[7008], false,10104,false,30,5,5,"30900095-3",false,25100104,false,"0010"}, get),
	P({D[7008], false,10105,false,5,5,5,"30900095-3",false,25100105,false,"0011"}, get),
	P({D[3008], false,10106,"30900095-3",false,25100106,false,"0012"}, get),
	P({D[7008], false,10107,false,5,false,20,"30900095-3",false,25100107,false,"0013"}, get),
	P({D[6008], false,10108,false,false,0,"30900095-3",false,25100108,false,"0014"}, get),
	P({D[7008], false,10109,false,5,5,0,"30900095-3",false,25100109,false,"0015"}, get),
	P({D[3004], false,10110,30,0,false,false,"30900095-3",false,25100110,false,"0016"}, get),
	P({D[7010], false,10111,false,25,15,20,25100111,false,"0001"}, get),
	P({D[6010], false,10112,false,30,30,25100112,false,"0001"}, get),
	P({D[7010], false,10113,false,false,20,30,25100113,false,"0002"}, get),
	P({D[7010], false,10114,false,15,30,25,25100114,false,"0002"}, get),
	P({D[7010], false,10115,false,25,15,30,25100115,false,"0003"}, get),
	P({D[6010], false,10116,false,45,25,25100116,false,"0003"}, get),
	P({D[7010], false,10117,false,false,false,50,25100117,false,"0004"}, get),
	P({D[7010], false,10118,false,false,40,30,25100118,false,"0004"}, get),
	P({D[7010], false,10119,false,30,15,15,25100119,false,"0005"}, get),
	P({D[7010], false,10120,false,15,false,45,25100120,false,"0005"}, get),
	P({D[7010], false,10121,false,25,false,25,25100121,false,"0006"}, get),
	P({D[6010], false,10122,false,5,55,25100122,false,"0006"}, get),
};
return { tb = qc_character_pool };