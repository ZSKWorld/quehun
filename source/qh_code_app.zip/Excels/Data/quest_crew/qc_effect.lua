-- 由 Excel 自动生成的 Lua 表
-- 文件:   [quest_crew][qc_effect]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["type"] = 2; ["args"] = 3;};

local df = {  nil, 114, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local qc_effect = { }
qc_effect[10001] = P({10001,101,S({10,})}, get);
qc_effect[10002] = P({10002,102,S({3,10,})}, get);
qc_effect[10003] = P({10003,103,S({20,30900095,2,})}, get);
qc_effect[10004] = P({10004,102,S({1,50,})}, get);
qc_effect[10005] = P({10005,119,S({2,30,})}, get);
qc_effect[10006] = P({10006,101,S({20,})}, get);
qc_effect[10007] = P({10007,101,S({20,})}, get);
qc_effect[10008] = P({10008,101,S({20,})}, get);
qc_effect[10009] = P({10009,120,S({2,20,})}, get);
qc_effect[10010] = P({10010,120,S({1,20,})}, get);
qc_effect[10011] = P({10011,120,S({3,20,})}, get);
qc_effect[10012] = P({10012,121,S({})}, get);
qc_effect[10013] = P({10013,122,S({30,30900095,2,})}, get);
qc_effect[10014] = P({10014,108,S({10015,30,})}, get);
qc_effect[10015] = P({10015,109,S({10101,1,})}, get);
qc_effect[10016] = P({10016,108,S({10017,30,})}, get);
qc_effect[10017] = P({10017,108,S({10016,30,})}, get);
qc_effect[10018] = P({10018,108,S({10019,30,})}, get);
qc_effect[10019] = P({10019,108,S({10018,30,})}, get);
qc_effect[10020] = P({10020,110,S({10102,10103,1,})}, get);
qc_effect[10021] = P({10021,109,S({10104,1,})}, get);
qc_effect[10022] = P({10022,111,S({-20,})}, get);
qc_effect[10023] = P({10023,112,S({20,})}, get);
qc_effect[10024] = P({10024,113,S({2,50,})}, get);
qc_effect[10025] = P({10025,false,S({1,50,})}, get);
qc_effect[10026] = P({10026,false,S({1,50,})}, get);
qc_effect[10027] = P({10027,false,S({2,50,})}, get);
qc_effect[10028] = P({10028,false,S({2,50,})}, get);
qc_effect[10029] = P({10029,false,S({3,50,})}, get);
qc_effect[10030] = P({10030,false,S({3,50,})}, get);
qc_effect[10031] = P({10031,115,S({30,})}, get);
qc_effect[10032] = P({10032,116,S({20,})}, get);
qc_effect[10033] = P({10033,117,S({})}, get);
qc_effect[10034] = P({10034,118,S({-20,})}, get);
return { tb = qc_effect };