-- 由 Excel 自动生成的 Lua 表
-- 文件:   [quest_crew][qc_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["character_pool_id"] = 2; ["quest_pool_id"] = 3; ["refresh_market_price"] = 1004; ["market_count"] = 5; ["character_charging_price"] = 1006; ["great_success_effect_ceo"] = 7; ["great_success_ceo"] = 8; ["init_character_id"] = 9;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local qc_info = { }
qc_info[251001] = P({251001,1001,2001,"30900095-3",4,"30900095-1",50,150,S({10001,10002,})}, get);
return { tb = qc_info };