-- 由 Excel 自动生成的 Lua 表
-- 文件:   [season][level_ticket_pool]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["pool_id"] = 1; ["level_lower"] = 2; ["level_upper"] = 3; ["ticket_level"] = 4;};

local df = {  100101, nil, nil, 10,};

local get = function(item, k) return G(item, k, n2i, df); end;


local level_ticket_pool = { }
level_ticket_pool[100101] = {
	P({false,1,9,1}, get),
	P({false,10,27,2}, get),
	P({false,28,42,3}, get),
	P({false,43,54,4}, get),
	P({false,55,64,5}, get),
	P({false,65,74,6}, get),
	P({false,75,82,7}, get),
	P({false,83,90,8}, get),
	P({false,91,95,9}, get),
	P({false,96,100}, get),
	P({false,101,9999}, get),
};
return { tb = level_ticket_pool };