-- 由 Excel 自动生成的 Lua 表
-- 文件:   [season][season]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["start_time"] = 1002; ["end_time"] = 1003; ["disappear_time"] = 1004; ["match_mode"] = 5; ["level_ticket_pool"] = 6; ["ticket_retry"] = 7; ["point_item_id"] = 8; ["point_consume"] = 9; ["desc_chs"] = -10; ["desc_chs_t"] = -10; ["desc_jp"] = -10; ["desc_en"] = -10; ["desc_kr"] = -10; ["desktop_type"] = 11;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil,  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df, "season_season"); end;


local season = { }
season[1001] = P({1001,"2020-07-27 04:59:00+08","2020-10-25 06:59:00+08","2020-11-01 04:59:00+08",300,100101,100102,309000,100,1,1}, get);
return { tb = season };