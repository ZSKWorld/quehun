-- 由 Excel 自动生成的 Lua 表
-- 文件:   [season][season_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["season_id"] = 1; ["rank_lower"] = 2; ["rank_upper"] = 3; ["rewards"] = 1004;};

local df = {  1001, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local season_reward = { }
season_reward[1001] = {
	P({false,1,1,"305522-1"}, get),
	P({false,2,10,"305521-1"}, get),
	P({false,11,100,"305520-1"}, get),
};
return { tb = season_reward };