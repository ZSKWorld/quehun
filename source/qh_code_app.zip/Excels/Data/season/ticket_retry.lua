-- 由 Excel 自动生成的 Lua 表
-- 文件:   [season][ticket_retry]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["count"] = 2; ["cost"] = 3;};

local df = {  100102, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local ticket_retry = { }
ticket_retry[100102] = {
	P({false,1,0}, get),
	P({false,2,2000}, get),
	P({false,3,5000}, get),
	P({false,4,10000}, get),
	P({false,5,20000}, get),
};
return { tb = ticket_retry };