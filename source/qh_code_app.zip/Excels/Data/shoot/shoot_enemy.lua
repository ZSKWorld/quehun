-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shoot][shoot_enemy]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["enemy_id"] = 2; ["hp"] = 3; ["reward_group_id"] = 4; ["x"] = 5; ["y"] = 6; ["width"] = 7;};

local df = {  1011, nil, 1, 101103, 1, 1, 2,};

local get = function(item, k) return G(item, k, n2i, df); end;


local shoot_enemy = { }
shoot_enemy[1011] = {
	P({false,101101,3,101101,4,3,6}, get),
	P({false,101102,3,101101,14,3,6}, get),
	P({false,101103,3,101101,24,3,6}, get),
	P({false,101104,2,101102,false,2,4}, get),
	P({false,101105,2,101102,8,2,4}, get),
	P({false,101106,2,101102,15,2,4}, get),
	P({false,101107,2,101102,22,2,4}, get),
	P({false,101108,2,101102,29,2,4}, get),
	P({false,101109}, get),
	P({D[3004], false,101110,6}, get),
	P({D[3004], false,101111,11}, get),
	P({D[3004], false,101112,16}, get),
	P({D[3004], false,101113,21}, get),
	P({D[3004], false,101114,26}, get),
	P({D[3004], false,101115,31}, get),
};
shoot_enemy[1012] = {
	P({1012,101201,3,101201,4,3,6}, get),
	P({1012,101202,3,101201,14,3,6}, get),
	P({1012,101203,3,101201,24,3,6}, get),
	P({1012,101204,2,101202,false,2,4}, get),
	P({1012,101205,2,101202,8,2,4}, get),
	P({1012,101206,2,101202,15,2,4}, get),
	P({1012,101207,2,101202,22,2,4}, get),
	P({1012,101208,2,101202,29,2,4}, get),
	P({1012,101209,false,101203}, get),
	P({1012,101210,false,101203,6}, get),
	P({1012,101211,false,101203,11}, get),
	P({1012,101212,false,101203,16}, get),
	P({1012,101213,false,101203,21}, get),
	P({1012,101214,false,101203,26}, get),
	P({1012,101215,false,101203,31}, get),
};
shoot_enemy[1013] = {
	P({1013,101301,3,101301,4,3,6}, get),
	P({1013,101302,3,101301,14,3,6}, get),
	P({1013,101303,3,101301,24,3,6}, get),
	P({1013,101304,2,101302,false,2,4}, get),
	P({1013,101305,2,101302,8,2,4}, get),
	P({1013,101306,2,101302,15,2,4}, get),
	P({1013,101307,2,101302,22,2,4}, get),
	P({1013,101308,2,101302,29,2,4}, get),
	P({1013,101309,false,101303}, get),
	P({1013,101310,false,101303,6}, get),
	P({1013,101311,false,101303,11}, get),
	P({1013,101312,false,101303,16}, get),
	P({1013,101313,false,101303,21}, get),
	P({1013,101314,false,101303,26}, get),
	P({1013,101315,false,101303,31}, get),
};
return { tb = shoot_enemy };