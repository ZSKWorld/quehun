-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shoot][shoot_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["missions_group_id"] = 2; ["level_count"] = 3; ["bullet_item_id"] = 4;};

local df = {  nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local shoot_info = { }
shoot_info[251101] = P({251101,101,3,30900096}, get);
return { tb = shoot_info };