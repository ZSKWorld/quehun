-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shoot][shoot_mission]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["level"] = 2; ["enemy_group_id"] = 3;};

local df = {  101, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local shoot_mission = { }
shoot_mission[101] = {
	P({false,1011,1011}, get),
	P({false,1012,1012}, get),
	P({false,1013,1013}, get),
};
return { tb = shoot_mission };