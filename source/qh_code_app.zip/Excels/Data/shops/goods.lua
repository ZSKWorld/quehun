-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.LangGet

local n2i = {  ["id"] = 1; ["category"] = 2; ["category_goods"] = 3; ["icon"] = 1004; ["name_chs"] = -5; ["name_chs_t"] = -5; ["name_jp"] = -5; ["name_en"] = -5; ["name_kr"] = -5; ["desc_chs"] = -6; ["desc_chs_t"] = -6; ["desc_jp"] = -6; ["desc_en"] = -6; ["desc_kr"] = -6; ["item_id"] = 7; ["price"] = 1008; ["show_original_price"] = 1009; ["need_amount"] = 10; ["buy_limit"] = 11; ["show_has"] = 12; ["sort"] = 13; ["discount"] = 14; ["sell_activity"] = 15; ["launch_time"] = 1016; ["func"] = 1017; ["discount_activity"] = 18; ["zone"] = 1019;};

local df = {  nil, 5, 1, "extendRes/skin_shop/yijihaitanpaidui_shop.jpg",  nil,  nil, 400103, "100004-880", nil, 1, 1, nil, 2, 10000, nil, nil, nil, nil, "1,2,3",};

local get = function(item, k) return G(item, k, n2i, df, "shops_goods"); end;

local b2i = {5024,5115,5198,5282,5359,5428,6011,9046,9080,}

local goods = { }
return { tb = goods, get = get, b2i = b2i };