-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local goods = require("Excels.Data.shops.goods")
local tb = goods.tb
local get = goods.get

tb[6012] = P({D[11012], 6012,7,0,"extendRes/skin_shop/beijing_yuanlin.jpg",143,false,30700007,"100004-600",false,0,93}, get);
tb[9001] = P({9001,9,0,"deco/loading_cg/201201/thumb/201201_thumb.jpg",144,false,307401,"302005-8",false,0}, get);
tb[9002] = P({D[11012], 9002,9,0,"deco/loading_cg/210201/thumb/210201_thumb.jpg",145,false,307402,"302006-8",false,0,3}, get);
tb[9003] = P({D[11012], 9003,9,0,"deco/loading_cg/201202/thumb/201202_thumb.jpg",146,false,307403,"302007-8",false,0,1}, get);
tb[9004] = P({D[11012], 9004,9,0,"deco/loading_cg/210601/thumb/210601_thumb.jpg",147,false,307404,"302008-8",false,0,4}, get);
tb[9005] = P({D[11012], 9005,9,0,"deco/loading_cg/210701/thumb/210701_thumb.jpg",148,false,307405,"302009-8",false,0,5}, get);
tb[9006] = P({D[11012], 9006,9,0,"deco/loading_cg/210801/thumb/210801_thumb.jpg",149,false,307406,"302010-8",false,0,6}, get);
tb[9007] = P({D[11012], 9007,9,0,"deco/loading_cg/210802/thumb/210802_thumb.jpg",150,false,307407,"302011-8",false,0,7}, get);
tb[9008] = P({D[11012], 9008,9,0,"deco/loading_cg/210803/thumb/210803_thumb.jpg",151,false,307408,"302012-8",false,0,8}, get);
tb[9009] = P({D[11012], 9009,9,0,"deco/loading_cg/210901/thumb/210901_thumb.jpg",152,false,307409,"302005-8",false,0,9}, get);
tb[9010] = P({D[11012], 9010,9,0,"deco/loading_cg/211101/thumb/211101_thumb.jpg",153,false,307410,"302006-8",false,0,10}, get);
tb[9011] = P({D[11012], 9011,9,0,"deco/loading_cg/211201/thumb/211201_thumb.jpg",154,false,307411,"302007-8",false,0,11}, get);
tb[9012] = P({D[11012], 9012,9,0,"deco/loading_cg/211202/thumb/211202_thumb.jpg",155,false,307412,"302008-8",false,0,12}, get);
tb[9013] = P({D[11012], 9013,9,0,"deco/loading_cg/220101/thumb/220101_thumb.jpg",156,false,307413,"302009-8",false,0,13}, get);
tb[9014] = P({D[11012], 9014,9,0,"deco/loading_cg/220102/thumb/220102_thumb.jpg",157,false,307414,"302010-8",false,0,14}, get);
tb[9015] = P({D[11012], 9015,9,0,"deco/loading_cg/220201/thumb/220201_thumb.jpg",158,false,307415,"302011-8",false,0,15}, get);
tb[9016] = P({D[11012], 9016,9,0,"deco/loading_cg/220301/thumb/220301_thumb.jpg",159,false,307416,"302012-8",false,0,16}, get);
tb[9017] = P({D[11012], 9017,9,0,"deco/loading_cg/220501/thumb/220501_thumb.jpg",160,false,307417,"302005-8",false,0,17}, get);
tb[9018] = P({D[11012], 9018,9,0,"deco/loading_cg/220601/thumb/220601_thumb.jpg",161,false,307418,"302006-8",false,0,18}, get);
tb[9019] = P({D[11012], 9019,9,0,"deco/loading_cg/220701/thumb/220701_thumb.jpg",162,false,307419,"302007-8",false,0,19}, get);
tb[9020] = P({D[11012], 9020,9,0,"deco/loading_cg/220801/thumb/220801_thumb.jpg",163,false,307420,"302008-8",false,0,20}, get);
tb[9021] = P({D[11012], 9021,9,0,"deco/loading_cg/220802/thumb/220802_thumb.jpg",164,false,307421,"302009-8",false,0,21}, get);
tb[9022] = P({D[11012], 9022,9,0,"deco/loading_cg/220803/thumb/220803_thumb.jpg",165,false,307422,"302010-8",false,0,22}, get);
tb[9023] = P({D[11012], 9023,9,0,"deco/loading_cg/220901/thumb/220901_thumb.jpg",166,false,307423,"302011-8",false,0,23}, get);
tb[9024] = P({D[11012], 9024,9,0,"deco/loading_cg/221001/thumb/221001_thumb.jpg",167,false,307424,"302012-8",false,0,24}, get);
tb[9025] = P({D[11012], 9025,9,0,"deco/loading_cg/221201/thumb/221201_thumb.jpg",168,false,307425,"302005-8",false,0,25}, get);
tb[9026] = P({D[11012], 9026,9,0,"deco/loading_cg/201202/thumb/201202_thumb.jpg",169,false,307426,"302006-8",false,0,26}, get);
tb[9027] = P({D[11012], 9027,9,0,"deco/loading_cg/230101/thumb/230101_thumb.jpg",170,false,307427,"302007-8",false,0,27}, get);
tb[9028] = P({D[11012], 9028,9,0,"deco/loading_cg/230102/thumb/230102_thumb.jpg",171,false,307428,"302008-8",false,0,28}, get);
tb[9029] = P({D[11012], 9029,9,0,"deco/loading_cg/230201/thumb/230201_thumb.jpg",172,false,307429,"302009-8",false,0,29}, get);
tb[9030] = P({D[11012], 9030,9,0,"deco/loading_cg/230301/thumb/230301_thumb.jpg",173,false,307430,"302010-8",false,0,30}, get);
tb[9031] = P({D[11012], 9031,9,0,"deco/loading_cg/230302/thumb/230302_thumb.jpg",174,false,307432,"302011-8",false,0,31}, get);
tb[9033] = P({D[11012], 9033,9,0,"deco/loading_cg/230501/thumb/230501_thumb.jpg",175,false,307433,"302012-8",false,0,33}, get);
tb[9034] = P({D[11012], 9034,9,0,"deco/loading_cg/230601/thumb/230601_thumb.jpg",176,false,307434,"302005-8",false,0,34}, get);
tb[9035] = P({D[11012], 9035,9,0,"deco/loading_cg/230602/thumb/230602_thumb.jpg",177,false,307435,"302006-8",false,0,35}, get);
tb[9036] = P({D[11012], 9036,9,0,"deco/loading_cg/230701/thumb/230701_thumb.jpg",178,false,307436,"302007-8",false,0,36}, get);
tb[9037] = P({D[11012], 9037,9,0,"deco/loading_cg/230801/thumb/230801_thumb.jpg",179,false,307437,"302008-8",false,0,37}, get);
tb[9038] = P({D[11012], 9038,9,0,"deco/loading_cg/230802/thumb/230802_thumb.jpg",180,false,307438,"302009-8",false,0,38}, get);
tb[9039] = P({D[11012], 9039,9,0,"deco/loading_cg/230803/thumb/230803_thumb.jpg",false,false,307439,"302010-8",false,0,39}, get);
tb[9040] = P({D[11012], 9040,9,0,"deco/loading_cg/230901/thumb/230901_thumb.jpg",181,false,307440,"302011-8",false,0,40}, get);
tb[9041] = P({D[11012], 9041,9,0,"deco/loading_cg/231001/thumb/231001_thumb.jpg",182,false,307441,"302012-8",false,0,41}, get);
tb[9043] = P({D[11012], 9043,9,0,"deco/loading_cg/231201/thumb/231201_thumb.jpg",false,false,307443,"302005-8",false,0,43}, get);
tb[9044] = P({D[11012], 9044,9,0,"deco/loading_cg/231202/thumb/231202_thumb.jpg",false,false,307444,"302006-8",false,0,44}, get);
tb[9045] = P({D[11012], 9045,9,0,"deco/loading_cg/240101/thumb/240101_thumb.jpg",false,false,307445,"302007-8",false,0,45}, get);
tb[9046] = P({D[11012], 9046,9,0,"deco/loading_cg/240102/thumb/240102_thumb.jpg",false,false,307446,"302008-8",false,0,46}, get);