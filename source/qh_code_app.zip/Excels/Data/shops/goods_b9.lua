-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap
local goods = require("Excels.Data.shops.goods")
local tb = goods.tb
local get = goods.get

tb[9047] = P({D[11012], 9047,9,0,"deco/loading_cg/240201/thumb/240201_thumb.jpg",false,false,307447,"302009-8",false,0,47}, get);
tb[9048] = P({D[11012], 9048,9,0,"deco/loading_cg/240301/thumb/240301_thumb.jpg",false,false,307448,"302010-8",false,0,48}, get);
tb[9049] = P({D[11012], 9049,9,0,"deco/loading_cg/240302/thumb/240302_thumb.jpg",false,false,307449,"302011-8",false,0,49}, get);
tb[9051] = P({D[11012], 9051,9,0,"deco/loading_cg/240501/thumb/240501_thumb.jpg",false,false,307451,"302012-8",false,0,51}, get);
tb[9052] = P({D[11012], 9052,9,0,"deco/loading_cg/240601/thumb/240601_thumb.jpg",false,false,307452,"302005-8",false,0,52}, get);
tb[9053] = P({D[11012], 9053,9,0,"deco/loading_cg/240602/thumb/240602_thumb.jpg",false,false,307453,"302006-8",false,0,53}, get);
tb[9054] = P({D[11012], 9054,9,0,"deco/loading_cg/240701/thumb/240701_thumb.jpg",false,false,307454,"302007-8",false,0,54}, get);
tb[9055] = P({D[11012], 9055,9,0,"deco/loading_cg/240801/thumb/240801_thumb.jpg",false,false,307455,"302008-8",false,0,55}, get);
tb[9056] = P({D[11012], 9056,9,0,"deco/loading_cg/240802/thumb/240802_thumb.jpg",false,false,307456,"302009-8",false,0,56}, get);
tb[9057] = P({D[11012], 9057,9,0,"deco/loading_cg/240803/thumb/240803_thumb.jpg",false,false,307457,"302010-8",false,0,57}, get);
tb[9058] = P({D[11012], 9058,9,0,"deco/loading_cg/241001/thumb/241001_thumb.jpg",false,false,307461,"302011-8",false,0,58}, get);
tb[9059] = P({D[11012], 9059,9,0,"deco/loading_cg/241201/thumb/241201_thumb.jpg",false,false,307463,"302012-8",false,0,59}, get);
tb[9060] = P({D[11012], 9060,9,0,"deco/loading_cg/241202/thumb/241202_thumb.jpg",false,false,307464,"302005-8",false,0,60}, get);
tb[9061] = P({D[11012], 9061,9,0,"deco/loading_cg/250101/thumb/250101_thumb.jpg",false,false,307465,"302006-8",false,0,61}, get);
tb[9062] = P({D[11012], 9062,9,0,"deco/loading_cg/250102/thumb/250102_thumb.jpg",false,false,307466,"302007-8",false,0,62}, get);
tb[9063] = P({D[11012], 9063,9,0,"deco/loading_cg/250201/thumb/250201_thumb.jpg",false,false,307468,"302008-8",false,0,63}, get);
tb[9064] = P({D[11012], 9064,9,0,"deco/loading_cg/250301/thumb/250301_thumb.jpg",false,false,307469,"302009-8",false,0,64}, get);
tb[9065] = P({D[11012], 9065,9,0,"deco/loading_cg/250302/thumb/250302_thumb.jpg",false,false,307470,"302010-8",false,0,65}, get);
tb[9066] = P({D[11012], 9066,9,0,"deco/loading_cg/250501/thumb/250501_thumb.jpg",false,false,307472,"302011-8",false,0,66}, get);
tb[9067] = P({D[11012], 9067,9,0,"deco/loading_cg/250601/thumb/250601_thumb.jpg",false,false,307473,"302012-8",false,0,67}, get);
tb[9068] = P({D[11012], 9068,9,0,"deco/loading_cg/250701/thumb/250701_thumb.jpg",false,false,307474,"302005-8",false,0,68}, get);
tb[9069] = P({D[11012], 9069,9,0,"deco/loading_cg/250801/thumb/250801_thumb.jpg",false,false,307475,"302006-8",false,0,69}, get);
tb[9070] = P({D[11012], 9070,9,0,"deco/loading_cg/250802/thumb/250802_thumb.jpg",false,false,307476,"302007-8",false,0,70}, get);
tb[9071] = P({D[11012], 9071,9,0,"deco/loading_cg/250901/thumb/250901_thumb.jpg",false,false,307477,"302008-8",false,0,71}, get);
tb[9072] = P({D[11012], 9072,9,0,"deco/loading_cg/251101/thumb/251101_thumb.jpg",false,false,307479,"302009-8",false,0,72}, get);
tb[9073] = P({D[11012], 9073,9,0,"deco/loading_cg/251201/thumb/251201_thumb.jpg",false,false,307480,"302010-8",false,0,73}, get);
tb[9074] = P({D[11012], 9074,9,0,"deco/loading_cg/251202/thumb/251202_thumb.jpg",false,false,307481,"302011-8",false,0,74}, get);
tb[9075] = P({D[11012], 9075,9,0,"deco/loading_cg/260101/thumb/260101_thumb.jpg",false,false,307482,"302012-8",false,0,75}, get);
tb[9076] = P({D[11012], 9076,9,0,"deco/loading_cg/260201/thumb/260201_thumb.jpg",false,false,307483,"302005-8",false,0,76}, get);
tb[9077] = P({D[11012], 9077,9,0,"deco/loading_cg/260202/thumb/260202_thumb.jpg",false,false,307484,"302006-8",false,0,77}, get);
tb[9078] = P({D[11012], 9078,9,0,"deco/loading_cg/260301/thumb/260301_thumb.jpg",false,false,307486,"302007-8",false,0,78}, get);
tb[9079] = P({D[11012], 9079,9,0,"deco/loading_cg/260501/thumb/260501_thumb.jpg",false,false,307489,"302008-8",false,0,79}, get);
tb[9080] = P({D[11012], 9080,9,0,"deco/loading_cg/260701/thumb/260701_thumb.jpg",false,false,307492,"302009-8",false,0,80}, get);