-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][goods_package]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["good_id"] = 2; ["good_count"] = 3;};

local df = {  700001, nil, 1,};

local get = function(item, k) return G(item, k, n2i, df); end;


local goods_package = { }
goods_package[700001] = {
	P({false,5001}, get),
	P({false,5002}, get),
	P({false,5003}, get),
	P({false,5004}, get),
	P({false,2201}, get),
};
return { tb = goods_package };