-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][interval_refresh_goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["group_id"] = 1; ["goods_id"] = 2; ["interval"] = 3; ["interval_type"] = 4;};

local df = {  1001, nil, 1, 2,};

local get = function(item, k) return G(item, k, n2i, df); end;


local interval_refresh_goods = { }
interval_refresh_goods[1001] = {
	P({false,9002}, get),
	P({false,9004}, get),
	P({false,9001}, get),
	P({false,9005}, get),
	P({false,9006}, get),
	P({false,9008}, get),
	P({false,9040}, get),
	P({false,9049}, get),
	P({false,9052}, get),
	P({false,9059}, get),
	P({false,9062}, get),
	P({false,9068}, get),
	P({false,9070}, get),
	P({false,9074}, get),
	P({false,9076}, get),
	P({false,9011,2}, get),
	P({false,9029,2}, get),
	P({false,9033,2}, get),
	P({false,9007,2}, get),
	P({false,9009,2}, get),
	P({false,9010,2}, get),
	P({false,9047,2}, get),
	P({false,9055,2}, get),
	P({false,9060,2}, get),
	P({false,9064,2}, get),
	P({false,9075,2}, get),
	P({false,9077,2}, get),
	P({false,9026,3}, get),
	P({false,9019,3}, get),
	P({false,9028,3}, get),
	P({false,9017,3}, get),
	P({false,9018,3}, get),
	P({false,9027,3}, get),
	P({false,9016,3}, get),
	P({false,9014,3}, get),
	P({false,9045,3}, get),
	P({false,9053,3}, get),
	P({false,9065,3}, get),
	P({false,9079,3}, get),
	P({false,9044,4}, get),
	P({false,9021,4}, get),
	P({false,9024,4}, get),
	P({false,9022,4}, get),
	P({false,9020,4}, get),
	P({false,9037,4}, get),
	P({false,9025,4}, get),
	P({false,9048,4}, get),
	P({false,9054,4}, get),
	P({false,9058,4}, get),
	P({false,9063,4}, get),
	P({false,9067,4}, get),
	P({false,9071,4}, get),
	P({false,9012,5}, get),
	P({false,9031,5}, get),
	P({false,9034,5}, get),
	P({false,9035,5}, get),
	P({false,9036,5}, get),
	P({false,9039,5}, get),
	P({false,9023,5}, get),
	P({false,9057,5}, get),
	P({false,9066,5}, get),
	P({false,9080,5}, get),
	P({false,9043,6}, get),
	P({false,9003,6}, get),
	P({false,9038,6}, get),
	P({false,9015,6}, get),
	P({false,9013,6}, get),
	P({false,9030,6}, get),
	P({false,9041,6}, get),
	P({false,9046,6}, get),
	P({false,9051,6}, get),
	P({false,9056,6}, get),
	P({false,9061,6}, get),
	P({false,9069,6}, get),
	P({false,9072,6}, get),
	P({false,9073,6}, get),
	P({false,9078,6}, get),
};
return { tb = interval_refresh_goods };