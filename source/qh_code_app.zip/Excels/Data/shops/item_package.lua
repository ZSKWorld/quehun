-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][item_package]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["item_info"] = 1002;};

local df = {  nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local item_package = { }
item_package[700002] = P({700002,"400207-1,30580005-1,30570003-1"}, get);
item_package[700003] = P({700003,"30550014-1,30560004-1,30570005-1,30580008-1"}, get);
return { tb = item_package };