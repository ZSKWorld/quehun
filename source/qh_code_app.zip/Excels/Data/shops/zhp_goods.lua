-- 由 Excel 自动生成的 Lua 表
-- 文件:   [shops][zhp_goods]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.LangGet
local D = ExcelTool.Dmap

local n2i = {  ["id"] = 1; ["icon"] = 1002; ["name_chs"] = -3; ["name_chs_t"] = -3; ["name_jp"] = -3; ["name_en"] = -3; ["name_kr"] = -3; ["item_id"] = 4; ["buy_limit"] = 5; ["currency"] = 6; ["price"] = 7; ["need_amount"] = 8; ["show_has"] = 9;};

local df = {  nil, nil,  nil, nil, 4, 100002, 15000, 1, 1,};

local get = function(item, k) return G(item, k, n2i, df, "shops_zhp_goods"); end;


local zhp_goods = { }
zhp_goods[1] = P({1,"extendRes/items/biscuit0.jpg",1,303011}, get);
zhp_goods[2] = P({2,"extendRes/items/console0.jpg",2,303021}, get);
zhp_goods[3] = P({3,"extendRes/items/art0.jpg",3,303031}, get);
zhp_goods[4] = P({4,"extendRes/items/wine0.jpg",4,303041}, get);
zhp_goods[5] = P({5,"extendRes/items/diamond0.jpg",5,303051}, get);
zhp_goods[6] = P({6,"extendRes/items/toy0.jpg",6,303061}, get);
zhp_goods[7] = P({7,"extendRes/items/comic0.jpg",7,303071}, get);
zhp_goods[8] = P({8,"extendRes/items/dress0.jpg",8,303081}, get);
zhp_goods[9] = P({9,"extendRes/items/biscuit1.jpg",9,303012,2,false,75000}, get);
zhp_goods[10] = P({10,"extendRes/items/console1.jpg",10,303022,2,false,75000}, get);
zhp_goods[11] = P({11,"extendRes/items/art1.jpg",11,303032,2,false,75000}, get);
zhp_goods[12] = P({12,"extendRes/items/wine1.jpg",12,303042,2,false,75000}, get);
zhp_goods[13] = P({13,"extendRes/items/diamond1.jpg",13,303052,2,false,75000}, get);
zhp_goods[14] = P({14,"extendRes/items/toy1.jpg",14,303062,2,false,75000}, get);
zhp_goods[15] = P({15,"extendRes/items/comic1.jpg",15,303072,2,false,75000}, get);
zhp_goods[16] = P({16,"extendRes/items/dress1.jpg",16,303082,2,false,75000}, get);
zhp_goods[17] = P({17,"extendRes/items/jade_courage.jpg",17,302005,1,false,50000,0}, get);
zhp_goods[18] = P({18,"extendRes/items/jade_will.jpg",18,302006,1,false,50000,0}, get);
zhp_goods[19] = P({19,"extendRes/items/jade_honest.jpg",19,302007,1,false,50000,0}, get);
zhp_goods[20] = P({20,"extendRes/items/jade_tender.jpg",20,302008,1,false,50000,0}, get);
zhp_goods[21] = P({21,"extendRes/items/jade_knowledge.jpg",21,302009,1,false,50000,0}, get);
zhp_goods[22] = P({22,"extendRes/items/jade_pure.jpg",22,302010,1,false,50000,0}, get);
zhp_goods[23] = P({23,"extendRes/items/jade_hope.jpg",23,302011,1,false,50000,0}, get);
zhp_goods[24] = P({24,"extendRes/items/jade_bright.jpg",24,302012,1,false,50000,0}, get);
return { tb = zhp_goods };