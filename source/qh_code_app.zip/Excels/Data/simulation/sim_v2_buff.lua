-- 由 Excel 自动生成的 Lua 表
-- 文件:   [simulation][sim_v2_buff]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Block
local G = ExcelTool.PackGet

local n2i = {  ["buff_id"] = 1; ["buff_result_desc"] = 2; ["buff_desc"] = 3; ["type"] = 4; ["match_effect"] = 5; ["param"] = 1006;};

local df = {  nil, 25049003, 25049003, 12003, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;

local b2i = {10650111,10840211,11000411,}

local sim_v2_buff = { }
return { tb = sim_v2_buff, get = get, b2i = b2i };