-- 由 Excel 自动生成的 Lua 表
-- 文件:   [simulation][sim_v2_effect]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["effect_id"] = 1; ["luk"] = 2; ["tec"] = 3; ["ins"] = 4; ["int"] = 5; ["res"] = 6; ["effect_title"] = 7; ["effect_desc"] = 8;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local sim_v2_effect = { }
sim_v2_effect[9001] = P({D[3004], 9001,600,-100,false,25040001,25041001}, get);
sim_v2_effect[9002] = P({D[3006], 9002,300,25040002,25041002}, get);
sim_v2_effect[9003] = P({9003,false,-100,false,700,false,25040003,25041003}, get);
sim_v2_effect[9004] = P({D[2005], 9004,300,25040004,25041004}, get);
sim_v2_effect[9005] = P({D[2003], 9005,800,false,false,25040005,25041005}, get);
sim_v2_effect[9006] = P({D[2004], 9006,200,false,25040006,25041006}, get);
sim_v2_effect[9007] = P({D[2003], 9007,400,false,false,25040007,25041007}, get);
sim_v2_effect[9008] = P({D[2005], 9008,600,25040008,25041008}, get);
sim_v2_effect[9009] = P({D[3006], 9009,500,25040009,25041009}, get);
sim_v2_effect[9010] = P({D[4006], 9010,false,700,25040010,25041010}, get);
sim_v2_effect[9011] = P({D[2005], 9011,500,25040011,25041011}, get);
sim_v2_effect[9012] = P({D[2003], 9012,-300,1000,false,25040012,25041012}, get);
sim_v2_effect[9013] = P({D[2004], 9013,400,false,25040013,25041013}, get);
sim_v2_effect[9014] = P({D[3005], 9014,-100,500,25040014,25041014}, get);
sim_v2_effect[9015] = P({D[4006], 9015,false,500,25040015,25041015}, get);
sim_v2_effect[9016] = P({D[2003], 9016,400,false,false,25040016,25041016}, get);
sim_v2_effect[9017] = P({D[2003], 9017,400,false,false,25040017,25041017}, get);
sim_v2_effect[9018] = P({D[5006], 9018,false,1000,-100,25040018,25041018}, get);
sim_v2_effect[9019] = P({D[3005], 9019,500,-100,25040019,25041019}, get);
sim_v2_effect[9020] = P({D[4006], 9020,false,600,25040020,25041020}, get);
return { tb = sim_v2_effect };