-- 由 Excel 自动生成的 Lua 表
-- 文件:   [simulation][sim_v2_info]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["player_chara_id"] = 2; ["event_group_id"] = 3; ["train_result_fail"] = 4; ["train_result_normal"] = 5; ["train_result_great"] = 6; ["train_cap"] = 7; ["find_ting_adj"] = 8; ["shunweima_2"] = 9; ["shunweima_3"] = 10; ["shunweima_4"] = 11; ["match_event_cd"] = 12; ["show_arrow_buff"] = 1013; ["add_sub_buff"] = 1014; ["attribute_add_buff"] = 1015; ["arrow_amount_12001"] = 16; ["arrow_amount_12002"] = 17; ["arrow_amount_12004"] = 18; ["arrow_amount_12005"] = 19; ["arrow_amount_12014"] = 20;};

local df = {  nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local sim_v2_info = { }
sim_v2_info[250401] = P({250401,200001,25040101,180,270,540,10000,5,5,-5,-15,10,"12001,12002,12004,12005,12014","12003,12033,12013","12032",100,100,100,100,100}, get);
return { tb = sim_v2_info };