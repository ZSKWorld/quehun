-- 由 Excel 自动生成的 Lua 表
-- 文件:   [simulation][sim_v2_reward]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["activity_id"] = 1; ["rank"] = 2; ["ability"] = 3; ["random_effect"] = 4;};

local df = {  250401, nil, 500, nil,};

local get = function(item, k) return G(item, k, n2i, df); end;


local sim_v2_reward = { }
sim_v2_reward[250401] = {
	P({false,1}, get),
	P({false,2}, get),
	P({false,3,0,1}, get),
	P({false,4,0,1}, get),
};
return { tb = sim_v2_reward };