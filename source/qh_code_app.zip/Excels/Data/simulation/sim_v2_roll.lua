-- 由 Excel 自动生成的 Lua 表
-- 文件:   [simulation][sim_v2_roll]
-- Author:  Robert

local ExcelTool = require("ExcelTool")
local P = ExcelTool.Pack
local S = ExcelTool.Sub
local G = ExcelTool.PackGet
local D = ExcelTool.Dmap

local n2i = {  ["event_group_id"] = 1; ["name"] = 2; ["value"] = 3; ["weight"] = 4;};

local df = {  25040101, 3, 1, 2000,};

local get = function(item, k) return G(item, k, n2i, df); end;


local sim_v2_roll = { }
sim_v2_roll[25040101] = {
	P({false,1,false,6000}, get),
	P({false,1,2}, get),
	P({false,1,3}, get),
	P({false,2,6,500}, get),
	P({false,2,5,1000}, get),
	P({false,2,4,4500}, get),
	P({false,2,3,5000}, get),
	P({false,2,2,4000}, get),
	P({false,2,false,3000}, get),
	P({false,2,0}, get),
	P({D[1003], 1800}, get),
	P({D[1002], 2,1800}, get),
	P({D[1002], 3,2200}, get),
	P({D[1002], 4,2100}, get),
	P({D[1002], 5}, get),
	P({D[1002], 6,1500}, get),
	P({D[1002], 7,1500}, get),
	P({D[1002], 8,1400}, get),
	P({D[1002], 9,1400}, get),
	P({D[1002], 10,900}, get),
	P({D[1002], 11,900}, get),
	P({D[1002], 12,900}, get),
	P({D[1002], 13,800}, get),
	P({D[1002], 14,800}, get),
	P({false,4,0,11000}, get),
	P({false,4,false,9000}, get),
	P({false,5,0,7000}, get),
	P({false,5,false,13000}, get),
	P({false,6,false,1500}, get),
	P({false,6,0,18500}, get),
	P({false,7,0,5500}, get),
	P({false,7,false,14500}, get),
	P({false,8,0}, get),
	P({false,8,false,18000}, get),
	P({false,9,0,3500}, get),
	P({false,9,false,16500}, get),
	P({false,10,0,5000}, get),
	P({false,10,false,15000}, get),
	P({false,11,0,6000}, get),
	P({false,11,false,14000}, get),
	P({false,12,0,6500}, get),
	P({false,12,false,13000}, get),
	P({false,13,0,7000}, get),
	P({false,13,false,13000}, get),
	P({false,14,0}, get),
	P({false,14,false,18000}, get),
};
return { tb = sim_v2_roll };